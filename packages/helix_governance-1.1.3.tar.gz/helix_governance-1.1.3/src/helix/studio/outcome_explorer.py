from __future__ import annotations

from dataclasses import dataclass, replace, field
from typing import Any, Iterable, List, Mapping, Sequence, Optional
import hashlib
from enum import Enum, auto
import csv
from pathlib import Path
import math
import json
import os
from PySide6.QtGui import QDesktopServices
from PySide6.QtCore import QUrl

from PySide6.QtCore import QPoint, QRect, QRectF, QSize, Qt, Signal, QTimer, QItemSelectionModel, QSettings
from PySide6.QtGui import (
    QAction,
    QColor,
    QFont,
    QFontMetrics,
    QIcon,
    QImage,
    QImageWriter,
    QLinearGradient,
    QMouseEvent,
    QPalette,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLayout,
    QLayoutItem,
    QLabel,
    QMenu,
    QMessageBox,
    QFileDialog,
    QToolButton,
    QToolTip,
    QPushButton,
    QSlider,
    QSplitter,
    QStackedLayout,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
    QSizePolicy,
    QScrollArea,
    QPlainTextEdit,
)
from PySide6.QtCore import QBuffer, QIODevice

from helix.bioinformatics import normalize_sequence
from helix.gui.modern.builders_2p5d import _heat_from_outcomes
from helix.studio.reports.session_report import save_session_report
from helix.studio.governance_stamp import (
    extract_decision_grade_proof_from_artifact,
    extract_decision_grade_proof_from_summary,
    governance_csv_prefix,
    governance_stamp_lines,
    interpretation_for_mode,
    export_watermark_label,
    ui_mode_label,
    ui_mode_subtext,
)
from helix.studio.limitations import limitations_csv_prefix, limitations_stamp
from helix.studio.export_labels import build_governance_provenance
from helix.studio.export_provenance import (
    build_export_provenance_v1,
    export_provenance_c14n_bytes,
    export_provenance_sha256,
    validate_export_provenance_v1,
)
from helix.studio.png_provenance import build_png_provenance_v1, write_png_provenance_sidecar
from helix.studio.export_image_settings import write_image_provenance_sidecars_enabled
from helix.studio.models import EngineInfo, RunModel
from helix.studio import run_metrics
from .ui_tokens import base_font, MARGIN_PANEL, SPACING_MEDIUM, SPACING_SMALL
from helix.core.offtarget_heat import compute_offtarget_heat
from helix.studio.offtarget_heat_widget import OffTargetHeatWidget
from helix.studio.prime_inspector import PrimeInspector
from helix.studio.summary_contract_v2 import repair_model_ui_label, top_outcome_ui_label
from PySide6.QtWidgets import QSpacerItem
from helix.studio.export_gate import build_export_context
from helix.studio.ui.export_gate import ensure_export_allowed
from helix.studio.semantic_schema import (
    CalibrationBadge,
    ScalarValue,
    ThermoContext,
    UncertaintySpec,
    Unit,
    UnknownValue,
    build_provenance,
    build_scalar,
    build_uncertainty,
    format_scalar,
    scalar_value,
    unknown,
)
from helix.studio.ordinal_bins import tier_fill_fraction, tier_for_rank
from helix.studio.repair_pathways import (
    RepairPathway,
    build_repair_pathway_mixture,
    build_stochastic_narrative_v1,
    classify_repair_pathway,
    PATHWAY_ORDER,
    PATHWAY_UI_LABEL,
)


CATEGORY_COLORS: dict[str, QColor] = {
    # Semantics-first palette (muted, consistent):
    # - intended: success
    # - no_cut: neutral
    # - frameshift / large deletions: risk
    "intended": QColor(58, 232, 200),
    "intended_edit": QColor(58, 232, 200),
    "no_cut": QColor(138, 147, 168),
    "small_deletion": QColor(246, 186, 90),
    "small_insertion": QColor(169, 133, 255),
    "large_deletion": QColor(242, 106, 128),
    "large_insertion": QColor(200, 122, 240),
    "other": QColor(143, 152, 180),
}

PRIME_COLORS: dict[str, QColor] = {
    "desired": QColor(84, 214, 163),
    "byproduct": QColor(246, 186, 90),
    "indel": CATEGORY_COLORS["large_deletion"],
    "no_cut": CATEGORY_COLORS["no_cut"],
}


_CUT_COLOR = QColor(255, 176, 96)
_CUT_BAND_ALPHA = 18  # ~7% opacity anchor band
_CUT_LINE_ALPHA = 235
_CUT_LINE_WIDTH = 3.2

_BAR_ALPHA_PRIMARY = 0.90
_BAR_ALPHA_INSPECT = 0.72
_BAR_ALPHA_MUTED = 0.34

_BAR_THICKNESS_MIN_PX = 7.0
_BAR_THICKNESS_MAX_PX = 18.0
_BAR_THICKNESS_MAX_PRIMARY_PX = 22.0
_SUMMARY_CANONICAL_SPAN_BP = 40.0
_SUMMARY_AXIS_MAX_BP = 120.0


_ROOT_CAUSE_LABELS: dict[str, str] = {
    "TARGET_LOCUS_UNRESOLVED": "Target locus unresolved",
    "PAM_INDEX_MISSING": "Genome index missing for whole-genome off-target search",
    "NO_TERMINAL_REACHABLE": "No terminal outcomes reachable",
    "TERMINAL_MASS_NOT_ONE": "Terminal outcome mass not conserved",
    "PRUNING_REMOVED_ALL_TERMINALS": "Pruning removed all terminal outcomes",
    "CALIBRATION_MISSING": "Calibration missing for probabilistic output",
    "CALIBRATION_OUT_OF_DOMAIN": "Calibration out of domain (coverage mismatch)",
    "CLAIMS_UNSUPPORTED": "Claims unsupported (provenance incomplete)",
    "PROVENANCE_INCOMPLETE": "Provenance incomplete (decision grade blocked)",
    "UNCERTAINTY_INCOMPLETE": "Uncertainty not computed (decision grade blocked)",
    "INTENDED_EDIT_SPEC_INCOMPLETE": "Intended edit spec incomplete (assay/allele missing; decision grade blocked)",
    "SPECIES_UNRESOLVED": "Species detection unresolved (decision grade blocked)",
    "GRAPH_CYCLE_DETECTED": "Graph contains a cycle",
    "CUT_INDEX_UNAVAILABLE": "Cut index unavailable",
    "off_target_required_but_not_computed": "Off-target risk required but not computed",
    "structural_risk_required_but_not_computed": "Structural risk required but not computed",
    "structural_screening_used_but_policy_requires_genome": "Genome structural screening required but not executed",
    "splice_risk_required_but_not_computed": "Splice risk required but not computed",
    "regulatory_risk_required_but_not_computed": "Regulatory risk required but not computed",
    "claims_required_but_not_computed": "Claims required but not computed",
    "claims_dirty": "Claims dirty",
    "perturbations_required_but_unsupported": "Perturbations required but unsupported",
}


def _label_from_root_cause(code: str) -> str:
    return _ROOT_CAUSE_LABELS.get(code, code)


def _value_label(mode: str) -> str:
    return "Probability" if str(mode) == "probability" else "Score"


def _value_label_lower(mode: str) -> str:
    return "probability" if str(mode) == "probability" else "score"


def _value_label_plural(mode: str) -> str:
    return "probabilities" if str(mode) == "probability" else "scores"


def _format_value(
    value: float,
    *,
    mode: str,
    digits: int = 1,
    annotate: bool = True,
) -> str:
    if str(mode) == "probability":
        return f"{value * 100:.{digits}f}%"
    text = f"{value:.{digits}f}"
    return text if not annotate else f"{text} score"


def intended_functional_auditability(intended_edit_spec: Mapping[str, Any] | None) -> tuple[bool, str]:
    """Return (auditable, reason) for intended_functional.

    Intended functional is only auditable when it is tied to:
    - A declared measurement/assay, and
    - A specified allele/edit definition (assayable target event).
    """
    if not isinstance(intended_edit_spec, Mapping):
        return False, "intended edit spec missing"

    meas = intended_edit_spec.get("measurement") if isinstance(intended_edit_spec.get("measurement"), Mapping) else {}
    m_status = str(meas.get("status") or "").strip().lower()
    if m_status != "declared":
        reason = str(meas.get("reason") or "").strip()
        return False, reason or "assay not declared"
    if not (meas.get("assay_type") or meas.get("assay_definition_id")):
        return False, "assay not declared"

    allele = intended_edit_spec.get("allele") if isinstance(intended_edit_spec.get("allele"), Mapping) else {}
    a_status = str(allele.get("status") or "").strip().lower()
    if a_status in {"", "not_specified", "absent"}:
        reason = str(allele.get("reason") or "").strip()
        return False, reason or "allele definition not specified"
    return True, ""


def _srgb_luma(c: QColor) -> float:
    # Relative luminance in sRGB-ish space; good enough for text contrast decisions.
    r = c.redF()
    g = c.greenF()
    b = c.blueF()
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _exploratory_desaturate(c: QColor) -> QColor:
    """Convert an accent/category color into a neutral exploratory presentation.

    This intentionally makes outcome bars look "non-final" when decision grade is
    disabled, reducing the chance users visually anchor on saturated category colors.
    """
    luma = _srgb_luma(c)
    # Map luminance into a legible gray band (dark UI background).
    g = int(70 + max(0.0, min(1.0, float(luma))) * 140)
    return QColor(g, g, g)


def _label_for_outcome(value: str) -> str:
    # Keep underscores readable without "biology vibes" typography.
    return str(value).replace("_", " ")


def _choose_outcome_ribbon_labels(
    bars: Sequence["OutcomeBar"],
    *,
    display_values: Mapping[str, float],
    max_labels: int,
    inspect_mode: bool,
    selected_label: str | None,
    hovered_label: str | None,
    highlighted_label: str | None,
    primary_label: str | None,
) -> list[str]:
    """Choose which outcome ribbons should get an always-visible label chip.

    In Inspect mode we try to label many outcomes, but cap it to avoid clutter.
    Selection + hover + highlight + primary are always preferred.
    """
    labels_present = {str(b.label) for b in (bars or []) if getattr(b, "label", None) is not None}
    if not labels_present:
        return []

    pinned: list[str] = []
    for candidate in (selected_label, hovered_label, highlighted_label, primary_label):
        if candidate is None:
            continue
        label = str(candidate)
        if label in labels_present and label not in pinned:
            pinned.append(label)

    if not inspect_mode:
        # Summary shows a single ribbon; keep it verdict-like.
        return pinned[:1] if pinned else []

    max_labels = int(max_labels)
    if max_labels <= 0:
        max_labels = 1

    ranked = sorted(
        (b for b in (bars or []) if getattr(b, "label", None) is not None),
        key=lambda b: float(display_values.get(str(b.label), float(getattr(b, "probability", 0.0) or 0.0))),
        reverse=True,
    )
    ranked_labels = [str(b.label) for b in ranked if str(b.label) in labels_present]

    # If the view isn't dense, label everything (but keep pinned first).
    if len(ranked_labels) <= max_labels:
        return pinned + [lab for lab in ranked_labels if lab not in pinned]

    budget = max(0, max_labels - len(pinned))
    if budget <= 0:
        return pinned
    auto = [lab for lab in ranked_labels if lab not in pinned][:budget]
    return pinned + auto


def _pick_energy_margin(phys: Mapping[str, Any] | None) -> float | None:
    if not isinstance(phys, Mapping):
        return None
    candidates = []
    for key in ("pbs_dG", "flap_ddG", "E_pred", "dG_total", "delta_g"):
        if key in phys and phys.get(key) is not None:
            try:
                candidates.append(float(phys.get(key)))
            except Exception:
                continue
    if not candidates:
        return None
    return float(min(candidates))


def _pick_kinetic_rate(payload: Mapping[str, Any] | None) -> float | None:
    if not isinstance(payload, Mapping):
        return None
    for key in ("kon", "processivity", "r_bind", "kcat"):
        if key in payload and payload.get(key) is not None:
            try:
                return float(payload.get(key))
            except Exception:
                continue
    return None


def _build_thermo_context(phys: Mapping[str, Any] | None, issues: list[str]) -> ThermoContext | None:
    if not isinstance(phys, Mapping):
        return None
    ctx = phys.get("context") if isinstance(phys.get("context"), Mapping) else phys.get("thermo_context") if isinstance(phys.get("thermo_context"), Mapping) else {}
    prov = build_provenance(
        ctx.get("provenance") if isinstance(ctx.get("provenance"), Mapping) else None,
        default_source="simulation",
        default_method="thermo_context",
        issues=issues,
    )
    temperature = build_scalar(
        ctx.get("temperature") if ctx else None,
        Unit.KELVIN,
        prov,
        issues=issues,
        field_label="thermo.temperature",
        missing_reason="temperature missing",
    )
    ionic_strength = build_scalar(
        ctx.get("ionic_strength") if ctx else None,
        Unit.MOLARITY,
        prov,
        issues=issues,
        field_label="thermo.ionic_strength",
        missing_reason="ionic strength missing",
    )
    magnesium = build_scalar(
        ctx.get("magnesium") if ctx else None,
        Unit.MOLARITY,
        prov,
        issues=issues,
        field_label="thermo.magnesium",
        missing_reason="magnesium missing",
    )
    crowding = build_scalar(
        ctx.get("crowding") if ctx else None,
        Unit.UNITLESS,
        prov,
        issues=issues,
        field_label="thermo.crowding",
        missing_reason="crowding missing",
    )
    model = ctx.get("model") if isinstance(ctx.get("model"), str) else unknown("thermo model missing")
    salt_model = ctx.get("salt_model") if isinstance(ctx.get("salt_model"), str) else unknown("salt model missing")
    mismatch_model = ctx.get("mismatch_model") if isinstance(ctx.get("mismatch_model"), str) else unknown("mismatch model missing")
    return ThermoContext(
        temperature=temperature,
        ionic_strength=ionic_strength,
        magnesium=magnesium,
        crowding=crowding,
        model=model,
        salt_model=salt_model,
        mismatch_model=mismatch_model,
        provenance=prov,
    )


def _calibration_priority(badge: CalibrationBadge) -> int:
    order = {
        CalibrationBadge.MEASURED: 3,
        CalibrationBadge.COMPUTED: 2,
        CalibrationBadge.ESTIMATED: 1,
        CalibrationBadge.UNKNOWN: 0,
    }
    return order.get(badge, 0)


def _format_thermo_context(ctx: ThermoContext | None) -> str:
    if ctx is None:
        return "Context: unknown (no thermodynamic context)"
    parts = [
        f"T={format_scalar(ctx.temperature)}",
        f"I={format_scalar(ctx.ionic_strength)}",
        f"Mg={format_scalar(ctx.magnesium)}",
        f"crowding={format_scalar(ctx.crowding)}",
        f"model={ctx.model}",
        f"salt={ctx.salt_model}",
        f"mismatch={ctx.mismatch_model}",
    ]
    return "Context: " + " · ".join(parts)


def _is_flat_context(context: Mapping[str, Any] | None) -> bool:
    if not isinstance(context, Mapping) or not context:
        return True
    keys = {k for k, v in context.items() if v not in (None, "", [], {})}
    if not keys:
        return True
    flat_keys = {"priors", "pam_mask_scale"}
    return keys.issubset(flat_keys)

def _draw_elevated_panel(p: QPainter, rect: QRect, *, radius: int = 10) -> None:
    """
    Draw a calm chart container: flat fill, crisp border, minimal depth cues.
    """
    if rect.isEmpty():
        return
    bg = QColor(12, 18, 34)
    border = QColor(44, 60, 92, 160)

    panel_rect = rect.adjusted(0, 0, -1, -1)
    path = QPainterPath()
    path.addRoundedRect(panel_rect, radius, radius)

    p.save()
    p.setPen(Qt.NoPen)
    p.fillPath(path, bg)

    # Border only (no glow/inner bevel).
    pen = QPen(border)
    pen.setWidthF(1.0)
    p.setPen(pen)
    p.setBrush(Qt.NoBrush)
    p.drawPath(path)
    p.restore()


def _simulate_cut_shift(bars: list["OutcomeBar"], delta_bp: int) -> list["OutcomeBar"]:
    """
    Deterministic, mass-conserving perturbation heuristic for cut shift ±1 bp.
    - Shifts positional context (relative to cut) by -delta.
    - Nudges probability toward outcomes whose peak lies on the shift side.
    """

    if delta_bp == 0 or not bars:
        return [replace(b) for b in bars]

    k = 0.1 * abs(delta_bp)  # 10% reallocation for ±1 bp
    winners = [b for b in bars if (b.peak_pos * delta_bp) >= 0]
    total_loss = 0.0
    updated: list[OutcomeBar] = []
    for b in bars:
        new_prob = max(0.0, b.probability * (1.0 - k))
        total_loss += b.probability - new_prob
        updated.append(
            replace(
                b,
                probability=new_prob,
                peak_pos=b.peak_pos - delta_bp,
                pos_range=(b.pos_range[0] - delta_bp, b.pos_range[1] - delta_bp),
            )
        )

    if winners and total_loss > 0.0:
        weights = [abs(w.peak_pos) + 1.0 for w in winners]
        denom = sum(weights) or 1.0
        for b, w in zip(winners, weights):
            share = total_loss * (w / denom)
            # apply to updated copy with same label
            for ub in updated:
                if ub.label == b.label:
                    ub.probability += share
                    break

    # renormalize to exactly 1.0
    total = sum(b.probability for b in updated) or 1.0
    updated = [replace(b, probability=b.probability / total) for b in updated]
    return updated


def _contract_hashes_from_evs(evs: Mapping[str, Any] | None) -> tuple[str | None, str | None, str | None]:
    if not isinstance(evs, Mapping):
        return None, None, None
    sim = evs.get("simulation", {}) if isinstance(evs.get("simulation"), Mapping) else {}
    hdr = evs.get("header", {}) if isinstance(evs.get("header"), Mapping) else {}
    policy_hash = hdr.get("policyHash") or sim.get("policyHash") or evs.get("policyHash")
    semantic_hash = hdr.get("semanticHash") or sim.get("semanticHash") or evs.get("semanticHash")
    determinism = hdr.get("determinismClass") or evs.get("determinismClass")
    try:
        policy_hash = str(policy_hash) if policy_hash is not None else None
    except Exception:
        policy_hash = None
    try:
        semantic_hash = str(semantic_hash) if semantic_hash is not None else None
    except Exception:
        semantic_hash = None
    try:
        determinism = str(determinism) if determinism is not None else None
    except Exception:
        determinism = None
    # Fallback to env for hardening
    if policy_hash is None:
        env_pol = os.getenv("HELIX_POLICY_HASH")
        policy_hash = env_pol.strip() if env_pol else None
    if semantic_hash is None:
        env_sem = os.getenv("HELIX_SEMANTIC_HASH")
        semantic_hash = env_sem.strip() if env_sem else None
    if determinism is None:
        env_det = os.getenv("HELIX_DETERMINISM_CLASS")
        determinism = env_det.strip() if env_det else None
    return policy_hash, semantic_hash, determinism

def _matches_intent(intent: str, outcome: Mapping[str, Any], delta_bp: int, frameshift: bool) -> bool:
    """
    Light-weight intent matcher:
    - knockout/ko: frameshift or any indel
    - prime: any outcome tagged/intended/HDR-like
    - base: substitutions/HDR-like
    - fallback: run_metrics._is_intended_outcome heuristic
    """

    intent_norm = (intent or "").strip().lower()
    if intent_norm in {"knockout", "ko"}:
        return frameshift or delta_bp != 0
    diff_kind = str((outcome.get("diff") or {}).get("kind", "")).lower()
    label = str(outcome.get("label") or outcome.get("name") or "").lower()
    tags = {str(t).lower() for t in outcome.get("tags", [])} if isinstance(outcome.get("tags"), list) else set()
    if intent_norm in {"prime_edit", "prime-edit", "prime"}:
        return "prime" in diff_kind or "hdr" in diff_kind or "intended" in label or "intended" in tags
    if intent_norm in {"base_edit", "base-edit", "base"}:
        return "substitution" in diff_kind or "base" in diff_kind or "intended" in label or "intended" in tags
    try:
        return run_metrics._is_intended_outcome(outcome)
    except Exception:
        return False


class ProbabilityMassMeter(QWidget):
    """
    Compact horizontal meter that encodes total probability mass (fill) and the
    currently highlighted outcome mass (foreground slice).
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._total = 0.0
        self._highlight = 0.0
        self._quantitative_allowed = True
        self.setFixedHeight(18)
        self.setMinimumWidth(160)

    def set_values(self, total: float, highlight: float | None = None) -> None:
        self._total = max(0.0, min(1.2, float(total)))
        self._highlight = max(0.0, min(1.0, float(highlight or 0.0)))
        self.update()

    def set_quantitative_allowed(self, allowed: bool) -> None:
        allowed = bool(allowed)
        if allowed == self._quantitative_allowed:
            return
        self._quantitative_allowed = allowed
        self.update()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        p = QPainter(self)
        try:
            p.setRenderHint(QPainter.Antialiasing, True)
            rect = self.rect().adjusted(1, 3, -1, -3)
            bg = QColor(26, 32, 48)
            track = QColor(64, 82, 116)
            fill = QColor(111, 197, 255)
            highlight = QColor(120, 255, 196)
            p.setPen(Qt.NoPen)
            p.setBrush(bg)
            p.drawRoundedRect(rect, 8, 8)

            # total mass fill
            w_total = int(rect.width() * max(0.0, min(1.0, self._total)))
            total_rect = QRect(rect.left(), rect.top(), w_total, rect.height())
            p.setBrush(track)
            p.drawRoundedRect(total_rect, 7, 7)

            # highlight slice
            if self._highlight > 0.0:
                w_hi = int(rect.width() * max(0.0, min(self._highlight, 1.0)))
                hi_rect = QRect(rect.left(), rect.top(), max(6, w_hi), rect.height())
                p.setBrush(highlight)
                p.drawRoundedRect(hi_rect, 7, 7)

            # subtle label
            if self._quantitative_allowed:
                p.setPen(QPen(QColor(196, 208, 235)))
                txt = f"{self._total*100:.1f}%"
                p.drawText(rect.adjusted(6, 0, -6, 0), Qt.AlignRight | Qt.AlignVCenter, txt)
        finally:
            p.end()


def _chart_color_for_bar(bar: "OutcomeBar") -> QColor:
    """Pick a semantic color for the bar (success/neutral/risk) with subtle category hints."""
    try:
        if getattr(bar, "intended", False) or "intended" in (bar.label or "").lower():
            return CATEGORY_COLORS["intended"]
    except Exception:
        pass
    try:
        if str(getattr(bar, "category", "") or "").lower() == "no_cut" or "no_cut" in (bar.label or "").lower():
            return CATEGORY_COLORS["no_cut"]
    except Exception:
        pass
    try:
        if getattr(bar, "frameshift", False):
            return CATEGORY_COLORS["large_deletion"]
    except Exception:
        pass
    try:
        if getattr(bar, "delta_bp", 0) <= -5 or getattr(bar, "microhomology", 0) >= 4:
            return CATEGORY_COLORS["large_deletion"]
    except Exception:
        pass
    try:
        cat = str(getattr(bar, "category", "") or "").lower()
        if "insertion" in cat:
            return CATEGORY_COLORS.get("small_insertion", CATEGORY_COLORS["other"])
        if "deletion" in cat:
            # Large deletions should already be caught above; this is "caution" not "danger".
            return CATEGORY_COLORS.get("small_deletion", CATEGORY_COLORS["other"])
    except Exception:
        pass
    return CATEGORY_COLORS.get(getattr(bar, "category", ""), CATEGORY_COLORS["other"])


def _why_for_outcome(bar: "OutcomeBar", *, run_kind: str) -> str:
    label = str(getattr(bar, "label", "") or "").strip()
    if run_kind == "prime":
        try:
            cls = _classify_prime_outcome(bar)
        except Exception:
            cls = None
        if cls == PrimeOutcomeClass.DESIRED:
            return "it is the intended edit (desired prime outcome)."
        if cls == PrimeOutcomeClass.BYPRODUCT:
            return "it is a competing/byproduct outcome (alternate edit outcome)."
        if cls == PrimeOutcomeClass.INDEL:
            return "it is a harmful indel byproduct."
        if cls == PrimeOutcomeClass.NO_CUT:
            return "no cut occurs (escape / no edit)."
        return "it is a prime outcome (unclassified)."

    try:
        if getattr(bar, "intended", False) or "intended" in label.lower():
            return "it is the intended edit (target outcome)."
    except Exception:
        pass
    try:
        cat = str(getattr(bar, "category", "") or "").lower()
        if cat == "no_cut" or "no_cut" in label.lower():
            return "no cut occurs (escape / no edit)."
        if getattr(bar, "frameshift", False):
            return "it is a harmful repair outcome (frameshift)."
        if getattr(bar, "delta_bp", 0) <= -5:
            return "it is a harmful repair outcome (large deletion)."
        if "insertion" in cat or "deletion" in cat:
            return "it is a competing repair outcome (indel)."
    except Exception:
        pass
    return "it is a repair outcome (unclassified)."


def _score_color(value: float) -> str:
    clamped = max(0.0, min(1.0, float(value)))
    red = int((1.0 - clamped) * 200 + 55)
    green = int(clamped * 200 + 55)
    return QColor(red, green, 90).name()


def _classify_prime_outcome(bar: OutcomeBar) -> PrimeOutcomeClass:
    # Precedence: desired -> byproduct -> indel -> no-cut
    label = (bar.label or "").lower()
    if "desired" in label or "intended" in label or getattr(bar, "intended", False):
        return PrimeOutcomeClass.DESIRED
    # byproduct: category hints or small templated edits near cut
    if "byproduct" in label or "edit" in label:
        return PrimeOutcomeClass.BYPRODUCT
    if bar.delta_bp != 0:
        return PrimeOutcomeClass.INDEL
    return PrimeOutcomeClass.NO_CUT


class PrimePhysicsExplainer:
    @staticmethod
    def explain(prime_meta, seq_ctx, outcome) -> list[str]:
        hints: list[str] = []
        if prime_meta is None:
            return hints

        # RTT GC content
        rtt = getattr(prime_meta, "rtt_sequence", "") or ""
        if rtt:
            gc = (rtt.count("G") + rtt.count("C")) / len(rtt)
            if gc > 0.70:
                hints.append("RTT GC very high; may reduce extension efficiency")
            elif gc < 0.30:
                hints.append("RTT GC very low; may destabilize primer binding")

        # PBS length sanity
        pbs_len = getattr(prime_meta, "pbs_length", None)
        if pbs_len is not None:
            if pbs_len < 8:
                hints.append("PBS too short for stable priming")
            elif pbs_len > 17:
                hints.append("PBS may be excessively long")

        # Mismatch check in RTT vs reference (naive)
        rtt_span = getattr(prime_meta, "rtt_span", None)
        if seq_ctx and rtt_span and seq_ctx.ref_window and seq_ctx.alt_window:
            try:
                s, e = rtt_span
                ref_slice = seq_ctx.ref_window[s:e]
                alt_slice = seq_ctx.alt_window[s:e]
                mismatches = sum(1 for a, b in zip(ref_slice, alt_slice) if a != b)
                if mismatches > 2:
                    hints.append("Multiple RTT mismatches relative to reference")
            except Exception:
                pass

        # Microhomology near nick (simple flank match)
        nick = getattr(prime_meta, "nick_index", None)
        window = getattr(seq_ctx, "ref_window", "") if seq_ctx else ""
        if nick is not None and window:
            try:
                if 2 <= nick < len(window) - 2:
                    left = window[nick-2:nick]
                    right = window[nick:nick+2]
                    if left and left == right:
                        hints.append("Microhomology near nick may cause slippage")
            except Exception:
                pass

        return hints


@dataclass
class OutcomeBar:
    label: str
    category: str
    probability: float  # 0..1
    delta_bp: int
    frameshift: bool
    peak_pos: float
    pos_range: tuple[float, float]
    example: str
    microhomology: int | None = None
    pbs_dg: float | None = None
    flap_ddg: float | None = None
    e_pred: float | None = None
    start: int | None = None
    end: int | None = None
    replacement: str | None = None
    guide_id: str = ""
    run_id: int | str | None = None
    run_kind: str | None = None
    intended: bool = False
    energy_margin: ScalarValue | UnknownValue | None = None  # kcal/mol (negative = favorable)
    kinetic_rate: ScalarValue | UnknownValue | None = None  # 1/s or contextual rate proxy
    thermo_favorability: ScalarValue | UnknownValue | None = None  # kcal/mol mirror for color mapping
    uncertainty: UncertaintySpec | None = None
    evidence: tuple[str, ...] = ()
    calibration: CalibrationBadge = CalibrationBadge.UNKNOWN
    schema_issues: tuple[str, ...] = ()
    pathway: str | None = None


@dataclass
class OutcomeRow:
    label: str
    category: str
    frameshift: bool
    delta_bp: int
    probability: float
    peak_pos: float
    example: str
    microhomology: int | None = None
    pbs_dg: float | None = None
    flap_ddg: float | None = None
    e_pred: float | None = None
    start: int | None = None
    end: int | None = None
    replacement: str | None = None
    guide_id: str = ""
    run_id: int | str | None = None
    energy_margin: ScalarValue | UnknownValue | None = None
    kinetic_rate: ScalarValue | UnknownValue | None = None
    thermo_favorability: ScalarValue | UnknownValue | None = None
    uncertainty: UncertaintySpec | None = None
    evidence: tuple[str, ...] = ()
    calibration: CalibrationBadge = CalibrationBadge.UNKNOWN
    schema_issues: tuple[str, ...] = ()
    run_kind: str | None = None
    intended: bool = False
    pathway: str | None = None


@dataclass
class OutcomeSummary:
    cut_prob: float
    no_cut_prob: float
    frameshift_prob: float
    median_indel: float
    expected_indel: float
    top_outcome: str
    intended_functional_p: float = 0.0
    dominance_ratio: float = 0.0
    entropy_bits: float = 0.0
    tail_p99_del_bp: float | None = None
    tail_cvar99_del_bp: float | None = None
    e_pred: float | None = None
    pbs_dg: float | None = None
    flap_ddg: float | None = None


@dataclass
class OutcomeExplorerData:
    summary: OutcomeSummary
    bars: list[OutcomeBar]
    rows: list[OutcomeRow]
    positions: list[int]
    heat_values: list[float]
    cut_index: int
    sequence: str
    run_id: int | str | None
    guide_id: str
    backend_name: str | None = None
    backend_kind: str | None = None
    fingerprint: str | None = None
    trust: str = "core_verified"
    provenance: list[Mapping[str, Any]] | None = None
    view_hash: str | None = None
    viz_transform_path: str | None = None
    policy_hash: str | None = None
    semantic_hash: str | None = None
    determinism_class: str | None = None
    fingerprint: str | None = None
    thermo_context: ThermoContext | None = None
    calibration_badge: CalibrationBadge = CalibrationBadge.UNKNOWN
    repair_pathways: tuple[RepairPathway, ...] = field(default_factory=tuple)
    stochastic_narrative: Mapping[str, Any] | None = None


@dataclass
class OutcomeSelection:
    run_id: int | str | None
    guide_id: str
    outcome_name: str
    probability: float | None
    delta_bp: int
    position_range: tuple[int, int]
    peak_position: int


@dataclass
class SequenceContext:
    ref_window: str
    alt_window: str
    cut_index: int
    edit_start: int
    edit_end: int
    label: Optional[str] = None
    baseline_alt_window: Optional[str] = None
    baseline_label: Optional[str] = None
    pbs_len: Optional[int] = None
    rtt_len: Optional[int] = None
    pbs_sequence: Optional[str] = None
    rtt_sequence: Optional[str] = None
    nick_index: Optional[int] = None
    pbs_span: Optional[tuple[int, int]] = None
    rtt_span: Optional[tuple[int, int]] = None


@dataclass
class PrimeMeta:
    rtt_sequence: Optional[str] = None
    pbs_sequence: Optional[str] = None
    pbs_length: Optional[int] = None
    rtt_span: Optional[tuple[int, int]] = None
    pbs_span: Optional[tuple[int, int]] = None
    nick_index: Optional[int] = None


@dataclass
class PcrDesignContext:
    run_id: int | str | None
    guide_id: str
    outcome_name: str
    delta_bp: int
    position_range: tuple[int, int]
    peak_position: int
    ref_sequence: str
    cut_index: int | None = None


def _delta_bp(diff: Mapping[str, Any] | None) -> int:
    if not diff:
        return 0
    edit = str(diff.get("edit") or diff.get("kind") or "").lower()
    start = diff.get("start")
    end = diff.get("end")
    repl = diff.get("replacement")

    # If a replacement string is present, use it directly.
    if repl is not None and start is not None and end is not None:
        try:
            return len(str(repl)) - (int(end) - int(start))
        except Exception:
            return 0

    # If we know the span but no replacement, assume a deletion of that span.
    if repl is None and start is not None and end is not None:
        try:
            span = int(end) - int(start)
            if span > 0:
                return -span
        except Exception:
            return 0

    # Fall back to parsing the edit token (e.g., "del2", "ins1")
    if edit.startswith("del"):
        try:
            mag = int("".join(ch for ch in edit if ch.isdigit()) or "0")
            return -mag
        except Exception:
            return 0
    if edit.startswith("ins"):
        try:
            mag = int("".join(ch for ch in edit if ch.isdigit()) or "0")
            return mag
        except Exception:
            return 0
    return 0


def _category(delta: int, diff: Mapping[str, Any] | None) -> str:
    if diff and str(diff.get("edit") or diff.get("kind") or "").lower() in {"no_cut", "none", "noedit"}:
        return "no_cut"
    if delta < 0:
        return "small_deletion" if abs(delta) <= 5 else "large_deletion"
    if delta > 0:
        return "small_insertion" if delta <= 2 else "large_insertion"
    return "no_cut"


def _frameshift(delta: int) -> bool:
    return delta != 0 and (delta % 3) != 0


def _example(delta: int, peak: float) -> str:
    if delta < 0:
        return f"del{abs(delta)}@{peak:+.0f}"
    if delta > 0:
        return f"ins{delta}@{peak:+.0f}"
    return "no_cut"


def _median_weighted(values: Sequence[int], weights: Sequence[float]) -> float:
    if not values or not weights:
        return 0.0
    paired = sorted(zip(values, weights), key=lambda t: t[0])
    total = sum(w for _, w in paired)
    if total <= 0.0:
        return 0.0
    acc = 0.0
    for val, wt in paired:
        acc += wt
        if acc >= 0.5 * total:
            return float(val)
    return float(paired[-1][0])


def _quantile_weighted(values: Sequence[float], weights: Sequence[float], q: float) -> float:
    if not values or not weights:
        return 0.0
    q = max(0.0, min(1.0, float(q)))
    paired = sorted(zip(values, weights), key=lambda t: float(t[0]))
    total = sum(float(w) for _, w in paired)
    if total <= 0.0:
        return 0.0
    target = q * total
    acc = 0.0
    for val, wt in paired:
        acc += float(wt)
        if acc >= target:
            return float(val)
    return float(paired[-1][0])


def _cvar_weighted(values: Sequence[float], weights: Sequence[float], q: float) -> float:
    if not values or not weights:
        return 0.0
    threshold = _quantile_weighted(values, weights, q)
    tail_total = 0.0
    tail_sum = 0.0
    for val, wt in zip(values, weights):
        if float(wt) <= 0.0:
            continue
        if float(val) >= threshold:
            tail_total += float(wt)
            tail_sum += float(val) * float(wt)
    if tail_total <= 0.0:
        return float(threshold)
    return float(tail_sum / tail_total)


def _compute_cut_index(seq_len: int, guide: Mapping[str, Any]) -> int:
    # Prefer explicit indices when available; EVS payloads often carry them even when
    # start/end are omitted (e.g. snapshot → EVS adapters).
    for key in ("cut_index", "cutIndex", "cut"):
        if key not in guide:
            continue
        try:
            idx = int(guide.get(key) or 0)
        except Exception:
            continue
        if 0 <= idx < seq_len:
            return idx
    start = int(guide.get("start", 0) or 0)
    end = int(guide.get("end", start + 1) or start + 1)
    strand = str(guide.get("strand", "+") or "+")
    if strand == "+":
        return max(0, min(seq_len - 1, end - 3))
    return max(0, min(seq_len - 1, start + 3))


def _choose_position_ticks(radius: int) -> list[int]:
    r = max(1, int(radius))
    if r <= 15:
        step = 5
    elif r <= 40:
        step = 10
    elif r <= 120:
        step = 20
    else:
        step = 50
    low = -((r // step) * step)
    high = ((r // step) * step)
    ticks = list(range(low, high + 1, step))
    if 0 not in ticks:
        ticks.append(0)
        ticks.sort()
    return ticks


def build_outcome_explorer_data(
    sequence: str,
    guide: Mapping[str, Any],
    outcomes: Iterable[Mapping[str, Any]],
    *,
    run_id: int | str | None = None,
    physics_run: Mapping[str, Any] | None = None,
    backend_name: str | None = None,
    backend_kind: str | None = None,
) -> OutcomeExplorerData:
    seq = normalize_sequence(sequence)
    seq_len = len(seq)
    cut_index = _compute_cut_index(seq_len, guide)
    positions = list(range(seq_len))

    no_cut_prob = 0.0
    deltas: List[int] = []
    weights: List[float] = []
    frameshift_prob = 0.0
    intended_functional_p = 0.0
    rows: List[OutcomeRow] = []
    bars: List[OutcomeBar] = []

    guide_id = str(guide.get("id") or guide.get("name") or "guide")
    intent = str(guide.get("intent") or guide.get("goal") or guide.get("desired_outcome") or "").strip().lower()
    if not intent:
        intent = "knockout"

    thermo_issues: list[str] = []
    thermo_context = _build_thermo_context(physics_run if isinstance(physics_run, Mapping) else None, thermo_issues)
    if thermo_context is None:
        for oc in outcomes:
            phys = oc.get("physics") if isinstance(oc, Mapping) else None
            thermo_context = _build_thermo_context(phys if isinstance(phys, Mapping) else None, thermo_issues)
            if thermo_context is not None:
                break

    for oc in outcomes:
        prob = float(oc.get("probability", oc.get("prob", 0.0)))
        diff = oc.get("diff") or {}
        delta = oc.get("delta_bp") if oc.get("delta_bp") is not None else _delta_bp(diff)
        cat = _category(delta, diff)
        frameshift = bool(oc.get("frameshift", _frameshift(delta)))

        start = diff.get("start") if isinstance(diff, Mapping) else None
        end = diff.get("end") if isinstance(diff, Mapping) else None
        pos_min = oc.get("position_min") if oc.get("position_min") is not None else None
        pos_max = oc.get("position_max") if oc.get("position_max") is not None else None
        peak_val = oc.get("peak_position") if oc.get("peak_position") is not None else None

        start_idx = cut_index
        end_idx = cut_index + 1
        pos_range: tuple[float, float] = (0.0, 1.0)

        if pos_min is not None and pos_max is not None:
            try:
                pmin = int(pos_min)
                pmax = int(pos_max)
                # position_min/max are usually relative offsets to cut (demo/session payloads),
                # but some producers emit absolute indices into the reference window (EVS).
                # Decide by whichever interpretation is "closer to cut" overall.
                dist_rel = abs(pmin) + abs(pmax)
                dist_abs = abs(pmin - cut_index) + abs(pmax - cut_index)
                treat_as_abs = (0 <= pmin <= seq_len and 0 <= pmax <= seq_len and dist_abs < dist_rel)
                if treat_as_abs:
                    start_idx = pmin
                    end_idx = pmax
                    pos_range = (start_idx - cut_index, end_idx - cut_index)
                else:
                    start_idx = cut_index + pmin
                    end_idx = cut_index + pmax
                    pos_range = (pmin, pmax)
            except Exception:
                start_idx = cut_index
                end_idx = cut_index + 1
                pos_range = (0.0, 1.0)
        else:
            try:
                start_idx = int(start) if start is not None else cut_index
            except Exception:
                start_idx = cut_index
            try:
                end_idx = int(end) if end is not None else start_idx + 1
            except Exception:
                end_idx = start_idx + 1
            pos_range = (start_idx - cut_index, end_idx - cut_index)

        # Peak position is typically relative-to-cut (Studio sessions), but may be absolute in EVS.
        mid: float
        if peak_val is not None:
            try:
                peak_f = float(peak_val)
                span_lo = min(float(start_idx), float(end_idx))
                span_hi = max(float(start_idx), float(end_idx))
                if 0.0 <= peak_f <= float(seq_len) and span_lo <= peak_f <= span_hi:
                    mid = peak_f - float(cut_index)
                else:
                    mid = peak_f
            except Exception:
                mid = 0.5 * (start_idx + end_idx) - cut_index
        else:
            mid = 0.5 * (start_idx + end_idx) - cut_index

        # Clamp for sequence previews / downstream tooling; pos_range may legitimately exceed window.
        start_idx = max(0, min(seq_len, int(start_idx)))
        end_idx = max(0, min(seq_len, int(end_idx)))
        label = str(oc.get("label") or oc.get("name") or cat)
        example = _example(delta, mid)

        if cat == "no_cut":
            no_cut_prob += prob
        else:
            deltas.append(delta)
            weights.append(prob)
            if frameshift:
                frameshift_prob += prob

        phys = oc.get("physics") if isinstance(oc, Mapping) else None
        if not isinstance(phys, Mapping):
            phys = {}

        issues: list[str] = []
        energy_margin_val = _pick_energy_margin(phys)
        kinetic_rate_val = _pick_kinetic_rate(
            phys.get("kinetics") if isinstance(phys.get("kinetics"), Mapping) else oc.get("kinetics") if isinstance(oc, Mapping) else None
        )
        energy_prov = build_provenance(
            phys.get("provenance") if isinstance(phys.get("provenance"), Mapping) else None,
            default_source="simulation",
            default_method="energy_model",
            issues=issues,
        )
        kinetic_prov = build_provenance(
            (phys.get("kinetics_provenance") if isinstance(phys.get("kinetics_provenance"), Mapping) else None),
            default_source="simulation",
            default_method="kinetic_model",
            issues=issues,
        )
        energy_margin = build_scalar(
            energy_margin_val,
            Unit.KCAL_PER_MOL,
            energy_prov,
            issues=issues,
            field_label="energy_margin",
            missing_reason="energy margin missing",
        )
        kinetic_rate = build_scalar(
            kinetic_rate_val,
            Unit.PER_S,
            kinetic_prov,
            issues=issues,
            field_label="kinetic_rate",
            missing_reason="kinetic rate missing",
        )
        thermo_favorability = energy_margin
        uncertainty_spec = build_uncertainty(
            oc.get("uncertainty") if isinstance(oc, Mapping) and isinstance(oc.get("uncertainty"), Mapping) else None,
            provenance=build_provenance(
                oc.get("uncertainty_provenance") if isinstance(oc, Mapping) and isinstance(oc.get("uncertainty_provenance"), Mapping) else None,
                default_source="simulation",
                default_method="uncertainty_model",
                issues=issues,
            ),
            issues=issues,
        )
        try:
            uncertainty_spec.params["probability"] = ScalarValue(
                value=float(prob), unit=Unit.PROBABILITY, provenance=energy_prov
            )
        except Exception:
            issues.append("uncertainty.probability invalid")
        evidence_entries = oc.get("evidence", []) if isinstance(oc, Mapping) else []
        evidence = tuple(str(e.get("detail") or e) for e in evidence_entries if isinstance(e, Mapping) and (e.get("detail") or e.get("label"))) if isinstance(evidence_entries, list) else ()
        if not evidence and isinstance(evidence_entries, list):
            evidence = tuple(str(e) for e in evidence_entries if e)
        polarities: set[str] = set()
        if isinstance(evidence_entries, list):
            for entry in evidence_entries:
                if isinstance(entry, Mapping):
                    pol = str(entry.get("polarity") or entry.get("verdict") or "").lower()
                    if pol in {"support", "conflict", "contradict", "refute"}:
                        polarities.add("conflict" if pol in {"conflict", "contradict", "refute"} else "support")
                elif isinstance(entry, str):
                    lower = entry.lower()
                    if "conflict" in lower or "contradict" in lower:
                        polarities.add("conflict")
                    if "support" in lower:
                        polarities.add("support")
        if "support" in polarities and "conflict" in polarities:
            issues.append("conflicting evidence")
        cal_raw = oc.get("calibration") if isinstance(oc, Mapping) and isinstance(oc.get("calibration"), Mapping) else {}
        cal_badge = str(cal_raw.get("badge") or cal_raw.get("status") or "unknown").lower()
        try:
            calibration = CalibrationBadge(cal_badge)
        except Exception:
            issues.append(f"calibration badge unknown: {cal_badge}")
            calibration = CalibrationBadge.UNKNOWN

        intended_flag = _matches_intent(intent, oc, delta, frameshift)
        if intended_flag:
            intended_functional_p += prob

        pathway = classify_repair_pathway(label=label, category=cat)
        row = OutcomeRow(
            label=label,
            category=cat,
            frameshift=frameshift,
            delta_bp=delta,
            probability=prob,
            peak_pos=mid,
            example=example,
            microhomology=diff.get("microhomology") if isinstance(diff, Mapping) else None,
            pbs_dg=phys.get("pbs_dG") if isinstance(phys, Mapping) else None,
            flap_ddg=phys.get("flap_ddG") if isinstance(phys, Mapping) else None,
            e_pred=phys.get("E_pred") if isinstance(phys, Mapping) else None,
            start=start_idx,
            end=end_idx,
            replacement=diff.get("replacement") if isinstance(diff, Mapping) else None,
            guide_id=guide_id,
            run_id=run_id,
            energy_margin=energy_margin,
            kinetic_rate=kinetic_rate,
            thermo_favorability=thermo_favorability,
            uncertainty=uncertainty_spec,
            evidence=evidence,
            calibration=calibration,
            schema_issues=tuple(issues),
            intended=intended_flag,
            pathway=pathway,
        )
        rows.append(row)

        bar = OutcomeBar(
            label=label,
            category=cat,
            probability=prob,
            delta_bp=delta,
            frameshift=frameshift,
            peak_pos=mid,
            pos_range=pos_range,
            example=example,
            microhomology=diff.get("microhomology") if isinstance(diff, Mapping) else None,
            pbs_dg=row.pbs_dg,
            flap_ddg=row.flap_ddg,
            e_pred=row.e_pred,
            start=start_idx,
            end=end_idx,
            replacement=diff.get("replacement") if isinstance(diff, Mapping) else None,
            guide_id=guide_id,
            run_id=run_id,
            energy_margin=energy_margin,
            kinetic_rate=kinetic_rate,
            thermo_favorability=thermo_favorability,
            uncertainty=uncertainty_spec,
            evidence=evidence,
            calibration=calibration,
            schema_issues=tuple(issues),
            intended=intended_flag,
            pathway=pathway,
        )
        bars.append(bar)

    total_prob = sum(r.probability for r in rows)
    if total_prob <= 0.0:
        total_prob = 0.0
    renormalized = False
    if total_prob > 0.0 and abs(total_prob - 1.0) > 1e-6:
        scale = 1.0 / total_prob
        for row in rows:
            row.probability *= scale
        for bar in bars:
            bar.probability *= scale
        no_cut_prob *= scale
        frameshift_prob *= scale
        intended_functional_p *= scale
        if weights:
            weights[:] = [w * scale for w in weights]
        total_prob = 1.0
        renormalized = True
    cut_prob = max(0.0, 1.0 - no_cut_prob)
    expected_indel = sum(d * w for d, w in zip(deltas, weights)) / (sum(weights) or 1.0)
    median_indel = _median_weighted(deltas, weights)
    top_outcome = max(rows, key=lambda r: r.probability, default=None)
    top_label = top_outcome.label if top_outcome else "--"

    # Contract-style control metrics (computed on the full distribution, before truncation).
    probs_all = [max(0.0, float(r.probability)) for r in rows]
    probs_sorted = sorted(probs_all, reverse=True)
    p_top = probs_sorted[0] if probs_sorted else 0.0
    p_second = probs_sorted[1] if len(probs_sorted) > 1 else 0.0
    dominance_ratio = (p_top / p_second) if p_second > 0.0 else (float("inf") if p_top > 0.0 else 0.0)
    entropy_bits = 0.0
    for p in probs_all:
        if p > 0.0:
            entropy_bits -= p * math.log(p, 2)
    del_lengths = [float(abs(r.delta_bp)) if r.delta_bp < 0 else 0.0 for r in rows]
    del_p99 = _quantile_weighted(del_lengths, probs_all, 0.99) if rows else 0.0
    del_cvar99 = _cvar_weighted(del_lengths, probs_all, 0.99) if rows else 0.0

    heat = _heat_from_outcomes(seq_len, guide, outcomes)
    heat_values = heat.tolist()
    positions_rel = [p - cut_index for p in positions]

    MAX_POS_BINS = 201
    if len(heat_values) > MAX_POS_BINS:
        bin_size = len(heat_values) / MAX_POS_BINS
        binned_heat: list[float] = []
        binned_pos: list[int] = []
        for i in range(MAX_POS_BINS):
            start = int(i * bin_size)
            end = int((i + 1) * bin_size)
            slice_vals = heat_values[start:end] or [0.0]
            binned_heat.append(sum(slice_vals) / len(slice_vals))
            mid = positions_rel[max(0, min(len(positions_rel) - 1, (start + end) // 2))]
            binned_pos.append(mid)
        heat_values = binned_heat
        positions_rel = binned_pos
    MAX_OUTCOMES = 50
    rows_sorted = sorted(rows, key=lambda r: r.probability, reverse=True)
    bars_sorted = sorted(bars, key=lambda b: b.probability, reverse=True)
    if len(rows_sorted) > MAX_OUTCOMES:
        keep_count = max(1, MAX_OUTCOMES - 1)
        kept_rows = rows_sorted[:keep_count]
        kept_bars = bars_sorted[:keep_count]
        tail_rows = rows_sorted[keep_count:]
        tail_mass = sum(r.probability for r in tail_rows)
        if tail_mass > 0.0:
            other_label = "Other (hidden mass)"
            other_issues: list[str] = []
            other_prov = build_provenance(None, default_source="projection", default_method="tail_bucket", issues=other_issues)
            other_pathway = classify_repair_pathway(label=other_label, category="other")
            other_row = OutcomeRow(
                label=other_label,
                category="other",
                frameshift=False,
                delta_bp=0,
                probability=float(tail_mass),
                peak_pos=0.0,
                example="",
                microhomology=None,
                pbs_dg=None,
                flap_ddg=None,
                e_pred=None,
                start=cut_index,
                end=cut_index + 1,
                replacement=None,
                guide_id=guide_id,
                run_id=run_id,
                energy_margin=build_scalar(None, Unit.KCAL_PER_MOL, other_prov, issues=other_issues, field_label="energy_margin", missing_reason="tail bucket"),
                kinetic_rate=build_scalar(None, Unit.PER_S, other_prov, issues=other_issues, field_label="kinetic_rate", missing_reason="tail bucket"),
                thermo_favorability=build_scalar(None, Unit.KCAL_PER_MOL, other_prov, issues=other_issues, field_label="thermo_favorability", missing_reason="tail bucket"),
                uncertainty=build_uncertainty(None, provenance=other_prov, issues=other_issues),
                evidence=(),
                calibration=CalibrationBadge.UNKNOWN,
                schema_issues=tuple(other_issues),
                intended=False,
                pathway=other_pathway,
            )
            other_bar = OutcomeBar(
                label=other_label,
                category="other",
                probability=float(tail_mass),
                delta_bp=0,
                frameshift=False,
                peak_pos=0.0,
                pos_range=(0, 0),
                example="",
                microhomology=None,
                pbs_dg=None,
                flap_ddg=None,
                e_pred=None,
                start=cut_index,
                end=cut_index + 1,
                replacement=None,
                guide_id=guide_id,
                run_id=run_id,
                energy_margin=other_row.energy_margin,
                kinetic_rate=other_row.kinetic_rate,
                thermo_favorability=other_row.thermo_favorability,
                uncertainty=other_row.uncertainty,
                evidence=other_row.evidence,
                calibration=other_row.calibration,
                schema_issues=other_row.schema_issues,
                intended=False,
                pathway=other_pathway,
            )
            kept_rows.append(other_row)
            kept_bars.append(other_bar)
        rows = kept_rows
        bars = kept_bars
    else:
        rows = rows_sorted
        bars = bars_sorted

    calibration_badge = CalibrationBadge.UNKNOWN
    for bar in bars:
        if _calibration_priority(bar.calibration) > _calibration_priority(calibration_badge):
            calibration_badge = bar.calibration

    repair_pathways = build_repair_pathway_mixture(
        [{"label": r.label, "category": r.category, "probability": r.probability} for r in rows]
    )
    stochastic_narrative = build_stochastic_narrative_v1(repair_pathways)

    summary = OutcomeSummary(
        cut_prob=cut_prob,
        no_cut_prob=no_cut_prob,
        frameshift_prob=frameshift_prob,
        median_indel=median_indel,
        expected_indel=expected_indel,
        top_outcome=top_label,
        intended_functional_p=float(intended_functional_p),
        dominance_ratio=float(dominance_ratio),
        entropy_bits=float(entropy_bits),
        tail_p99_del_bp=float(del_p99),
        tail_cvar99_del_bp=float(del_cvar99),
        e_pred=float(physics_run.get("E_pred")) if isinstance(physics_run, Mapping) and physics_run.get("E_pred") is not None else None,
        pbs_dg=float(physics_run.get("pbs_dG")) if isinstance(physics_run, Mapping) and physics_run.get("pbs_dG") is not None else None,
        flap_ddg=float(physics_run.get("flap_ddG")) if isinstance(physics_run, Mapping) and physics_run.get("flap_ddG") is not None else None,
    )

    provenance = []
    if renormalized:
        provenance.append({"kind": "renormalized", "reason": "outcome_mass_not_one", "tolerance": 1e-6})
    data = OutcomeExplorerData(
        summary=summary,
        bars=bars,
        rows=rows,
        positions=positions_rel,
        heat_values=heat_values,
        cut_index=cut_index,
        sequence=seq,
        run_id=run_id,
        guide_id=guide_id,
        backend_name=backend_name,
        backend_kind=backend_kind,
        fingerprint=None,
        trust="core_verified",
        provenance=provenance,
        policy_hash=None,
        semantic_hash=None,
        determinism_class=None,
        thermo_context=thermo_context,
        calibration_badge=calibration_badge,
        repair_pathways=repair_pathways,
        stochastic_narrative=stochastic_narrative,
    )
    # fingerprint for cache invalidation (stable across ordering)
    fp = hashlib.sha256()
    fp.update(seq.encode("utf-8"))
    fp.update(str(cut_index).encode("utf-8"))
    fp.update(str(run_id).encode("utf-8"))
    fp.update(guide_id.encode("utf-8"))
    for b in sorted(bars, key=lambda x: x.label):
        fp.update(b.label.encode("utf-8"))
        fp.update(str(round(b.probability, 6)).encode("utf-8"))
        fp.update(str(round(b.peak_pos, 3)).encode("utf-8"))
    data.fingerprint = fp.hexdigest()
    data.view_hash = data.fingerprint
    return data


def build_outcome_explorer_data_from_evs(evs: dict) -> OutcomeExplorerData | None:
    """Adapt EVS simulation results into OutcomeExplorerData (module-level helper)."""
    if not isinstance(evs, dict):
        return None
    policy_hash, semantic_hash, determinism = _contract_hashes_from_evs(evs)

    def _looks_like_sequence(val: object) -> bool:
        if not isinstance(val, str):
            return False
        stripped = val.strip()
        if not stripped:
            return False
        letters = [ch.upper() for ch in stripped if not ch.isspace()]
        if not letters:
            return False
        allowed = {"A", "C", "G", "T", "N", "U"}
        dna_like = sum(1 for ch in letters if ch in allowed)
        return dna_like >= max(4, int(len(letters) * 0.8))

    def _safe_int(val: object) -> int | None:
        try:
            return int(val)  # type: ignore[arg-type]
        except Exception:
            return None

    visited: set[int] = set()

    def _extract_sequence(node: Mapping[str, Any] | None) -> str:
        if not isinstance(node, Mapping):
            return ""
        node_id = id(node)
        if node_id in visited:
            return ""
        visited.add(node_id)

        for key in ("sequence", "ref", "ref_sequence", "refSequence", "windowSequence"):
            val = node.get(key)
            if isinstance(val, str) and _looks_like_sequence(val):
                return val

        seq_map = node.get("sequence")
        if isinstance(seq_map, Mapping):
            for key in ("ref", "sequence", "seq", "windowSequence"):
                val = seq_map.get(key)
                if isinstance(val, str) and _looks_like_sequence(val):
                    return val

        genome = node.get("genome")
        if isinstance(genome, Mapping):
            for val in genome.values():
                if isinstance(val, str) and _looks_like_sequence(val):
                    return val

        for child_key in (
            "reference_context",
            "referenceContext",
            "context",
            "site",
            "config",
            "sim_payload",
            "payload",
            "viz_spec_payload",
            "viz_spec",
            "posterior",
            "state",
        ):
            child = node.get(child_key)
            if isinstance(child, Mapping):
                found = _extract_sequence(child)
                if found:
                    return found
        return ""

    seq_hint = _extract_sequence(evs)
    length_hint: int | None = None
    seq_block = evs.get("sequence") if isinstance(evs.get("sequence"), Mapping) else None
    if isinstance(seq_block, Mapping):
        length_hint = _safe_int(seq_block.get("length") or seq_block.get("refLength") or seq_block.get("len"))

    seq = seq_hint if seq_hint else ""
    if not seq:
        seq_len = length_hint or 120
        seq = "N" * max(1, int(seq_len))

    cfg = evs.get("config") if isinstance(evs.get("config"), Mapping) else None
    if cfg is None:
        sim = evs.get("simulation") if isinstance(evs.get("simulation"), Mapping) else {}
        cfg = sim.get("params") if isinstance(sim.get("params"), Mapping) else None
    if cfg is None:
        cfg = {}

    edit_plan = evs.get("editPlan") or evs.get("edit_plan")
    targets = edit_plan.get("targets") if isinstance(edit_plan, Mapping) else []
    guide = targets[0] if targets else {}
    cfg_guide: Mapping[str, Any] | None = None
    if isinstance(cfg, Mapping):
        cfg_guide = cfg.get("guide") if isinstance(cfg.get("guide"), Mapping) else None
        sim_payload = cfg.get("sim_payload") if isinstance(cfg.get("sim_payload"), Mapping) else None
        payload_guide = sim_payload.get("guide") if isinstance(sim_payload, Mapping) and isinstance(sim_payload.get("guide"), Mapping) else None
        # Merge: prefer rich guide metadata from config/sim_payload, but preserve editPlan label/gRNA.
        merged: dict[str, Any] = {}
        for src in (cfg_guide, payload_guide, guide):
            if isinstance(src, Mapping):
                for k, v in src.items():
                    if v is None:
                        continue
                    merged[k] = v
        guide = merged
    guide_dict: dict[str, object] = {}
    if isinstance(guide, dict):
        guide_dict = dict(guide)
        grna = guide.get("gRNA") or guide.get("guide") or {}
        if isinstance(grna, dict):
            guide_dict.setdefault("sequence", grna.get("sequence"))
            guide_dict.setdefault("pam", grna.get("pam"))
    if "id" not in guide_dict or not guide_dict.get("id"):
        for key in ("targetId", "label", "name"):
            val = guide_dict.get(key)
            if isinstance(val, str) and val.strip():
                guide_dict["id"] = val.strip()
                break
    if "start" not in guide_dict or "end" not in guide_dict:
        mid = max(1, len(seq) // 2)
        guide_dict.setdefault("start", max(0, mid - 10))
        guide_dict.setdefault("end", max(1, mid + 10))
    guide_dict.setdefault("strand", "+")

    results = evs.get("simulation", {}).get("results", {}) if isinstance(evs.get("simulation"), dict) else {}
    alleles_raw = results.get("alleles") if isinstance(results, Mapping) and "alleles" in results else None

    def _coerce_outcome(entry: object) -> dict[str, object] | None:
        if isinstance(entry, Mapping):
            return dict(entry)
        to_dict = getattr(entry, "to_dict", None)
        if callable(to_dict):
            try:
                payload = to_dict()
            except Exception:
                return None
            if isinstance(payload, Mapping):
                return dict(payload)
        return None

    outcomes: list[dict[str, object]] = []

    # 1) EVS vX.Y style: simulation.results.alleles
    if alleles_raw is not None:
        if not isinstance(alleles_raw, list):
            return None
        for al in alleles_raw:
            if not isinstance(al, Mapping):
                continue
            prob = al.get("probability")
            if prob is None:
                prob = al.get("frequency") or al.get("prob") or 0.0
            delta_bp = al.get("deltaBp")
            if delta_bp is None:
                delta_bp = al.get("delta_bp")
            pos_range = al.get("position_range")
            if pos_range is None:
                pos_range = al.get("positionRange")
            pos_min = pos_max = None
            if isinstance(pos_range, (list, tuple)) and len(pos_range) == 2:
                pos_min, pos_max = pos_range[0], pos_range[1]
            peak_pos = al.get("peak_position")
            if peak_pos is None:
                peak_pos = al.get("peakPosition")
            if peak_pos is None:
                peak_pos = al.get("peak_pos")
            outcomes.append(
                {
                    "label": al.get("label") or al.get("name") or "outcome",
                    "probability": float(prob),
                    "delta_bp": delta_bp,
                    "frameshift": al.get("frameshift"),
                    "category": al.get("category"),
                    "diff": al.get("diff") or {},
                    "position_min": pos_min,
                    "position_max": pos_max,
                    "peak_position": peak_pos,
                    "physics": al.get("physics") if isinstance(al.get("physics"), Mapping) else None,
                    "uncertainty": al.get("uncertainty") if isinstance(al.get("uncertainty"), Mapping) else None,
                    "evidence": al.get("evidence") if isinstance(al.get("evidence"), list) else None,
                    "calibration": al.get("calibration") if isinstance(al.get("calibration"), Mapping) else None,
                }
            )

    # 2) Studio session snapshot state: outcomes list (or config.sim_payload.outcomes)
    if not outcomes:
        outcomes_raw = evs.get("outcomes")
        if not isinstance(outcomes_raw, list):
            cfg = evs.get("config") if isinstance(evs.get("config"), Mapping) else {}
            sim_payload = cfg.get("sim_payload") if isinstance(cfg, Mapping) and isinstance(cfg.get("sim_payload"), Mapping) else {}
            outcomes_raw = sim_payload.get("outcomes") if isinstance(sim_payload, Mapping) else None
        if isinstance(outcomes_raw, list):
            for entry in outcomes_raw:
                coerced = _coerce_outcome(entry)
                if coerced is not None:
                    outcomes.append(coerced)

    if not outcomes:
        return None

    run_id = evs.get("id")
    if run_id is None:
        run_id = evs.get("run_id")
    if run_id is None:
        state = evs.get("state")
        if isinstance(state, Mapping):
            run_id = state.get("run_id")

    physics_run = results.get("physics") if isinstance(results.get("physics"), Mapping) else None
    if physics_run is None:
        cfg = evs.get("config") if isinstance(evs.get("config"), Mapping) else {}
        sim_payload = cfg.get("sim_payload") if isinstance(cfg, Mapping) and isinstance(cfg.get("sim_payload"), Mapping) else None
        if isinstance(sim_payload, Mapping):
            physics_run = sim_payload.get("physics_score") if isinstance(sim_payload.get("physics_score"), Mapping) else None

    backend_name = evs.get("simulation", {}).get("engine") if isinstance(evs.get("simulation"), dict) else None
    if backend_name is None:
        cfg = evs.get("config") if isinstance(evs.get("config"), Mapping) else {}
        sim_settings = cfg.get("sim_settings") if isinstance(cfg, Mapping) and isinstance(cfg.get("sim_settings"), Mapping) else None
        if isinstance(sim_settings, Mapping):
            backend_name = sim_settings.get("backend")

    data = build_outcome_explorer_data(
        seq,
        guide_dict,
        outcomes,
        run_id=run_id,
        physics_run=physics_run,
        backend_name=backend_name,
    )
    if data is not None:
        data.policy_hash = policy_hash
        data.semantic_hash = semantic_hash
        data.determinism_class = determinism
        evs.setdefault("header", {})
        if isinstance(evs["header"], dict):
            if policy_hash:
                evs["header"].setdefault("policyHash", policy_hash)
            if semantic_hash:
                evs["header"].setdefault("semanticHash", semantic_hash)
            if determinism:
                evs["header"].setdefault("determinismClass", determinism)
    return data


# -------------------- Qt widgets --------------------


class Chip(QLabel):
    def __init__(
        self,
        label: str,
        value: str,
        parent: QWidget | None = None,
        *,
        variant: str = "default",
        accent: QColor | None = None,
    ) -> None:
        super().__init__(parent)
        self._variant = variant
        self.setText(f"{label}: <b>{value}</b>")
        if variant == "primary":
            c = accent or QColor(58, 232, 200)
            bg = QColor(c)
            bg.setAlphaF(0.14)
            border = QColor(c)
            border.setAlphaF(0.35)
            self.setStyleSheet(
                "padding:5px 12px; border-radius:12px; "
                f"background-color: {bg.name(QColor.HexArgb)}; border: 1px solid {border.name(QColor.HexArgb)}; "
                "color: palette(window-text); font-size: 13px; font-weight: 600;"
            )
        elif variant == "muted":
            self.setStyleSheet(
                "padding:4px 10px; border-radius:12px; "
                "background-color: palette(base); border: 1px solid palette(mid); "
                "color: palette(window-text); font-size: 11px;"
            )
        else:
            self.setStyleSheet(
                "padding:4px 10px; border-radius:10px; "
                "background-color: palette(base); border: 1px solid palette(mid); "
                "color: palette(window-text); font-size: 11px;"
            )


class FlowLayout(QLayout):
    """Simple flow layout that wraps items when space is tight."""

    def __init__(self, parent: QWidget | None = None, *, hspacing: int = 8, vspacing: int = 6) -> None:
        super().__init__(parent)
        self._items: list[QLayoutItem] = []
        self._hspacing = hspacing
        self._vspacing = vspacing
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item: QLayoutItem) -> None:  # type: ignore[override]
        self._items.append(item)
        self.invalidate()

    def addWidget(self, widget: QWidget) -> None:
        # Delegate to the base implementation so Qt constructs QWidgetItem correctly.
        # Instantiating QWidgetItem(...) directly from Python can yield broken
        # size hints (0,0) under PySide6, collapsing the layout.
        super().addWidget(widget)

    def count(self) -> int:  # type: ignore[override]
        return len(self._items)

    def itemAt(self, index: int) -> QLayoutItem | None:  # type: ignore[override]
        if 0 <= index < len(self._items):
            return self._items[index]
        return None

    def takeAt(self, index: int) -> QLayoutItem | None:  # type: ignore[override]
        if 0 <= index < len(self._items):
            item = self._items.pop(index)
            self.invalidate()
            return item
        return None

    def expandingDirections(self) -> Qt.Orientations:  # type: ignore[override]
        return Qt.Orientations(Qt.Orientation(0))

    def hasHeightForWidth(self) -> bool:  # type: ignore[override]
        return True

    def heightForWidth(self, width: int) -> int:  # type: ignore[override]
        width = max(0, width)
        return self._do_layout(QRect(0, 0, width, 0), test_only=True)

    def setGeometry(self, rect: QRect) -> None:  # type: ignore[override]
        super().setGeometry(rect)
        self._do_layout(rect, test_only=False)

    def sizeHint(self) -> QSize:  # type: ignore[override]
        return self.minimumSize()

    def minimumSize(self) -> QSize:  # type: ignore[override]
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.sizeHint())
        margins = self.contentsMargins()
        size += QSize(margins.left() + margins.right(), margins.top() + margins.bottom())
        return size

    def _do_layout(self, rect: QRect, *, test_only: bool) -> int:
        margins = self.contentsMargins()
        x = rect.x() + margins.left()
        y = rect.y() + margins.top()
        line_height = 0
        max_x = rect.x() + rect.width() - margins.right()

        for item in self._items:
            hint = item.sizeHint()
            next_x = x + hint.width()
            if x > rect.x() + margins.left() and next_x > max_x:
                x = rect.x() + margins.left()
                y += line_height + self._vspacing
                next_x = x + hint.width()
                line_height = 0
            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x = next_x + self._hspacing
            line_height = max(line_height, hint.height())

        return y + line_height + margins.bottom()


class SummaryStrip(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._current_run = None
        layout = FlowLayout(self, hspacing=8, vspacing=6)
        layout.setContentsMargins(0, 0, 0, 0)

    def set_groups(
        self,
        groups: Sequence[
            tuple[
                str,
                Sequence[
                    tuple[str, str, str]
                    | tuple[str, str, str, QColor | None]
                    | tuple[str, str, str, str]
                    | tuple[str, str, str, QColor | None, str]
                ],
            ]
        ],
    ) -> None:
        """
        groups: [(group_label, [(chip_label, chip_value, variant[, accent][, tooltip]), ...]), ...]
        """
        layout: FlowLayout = self.layout()  # type: ignore[assignment]
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        for gi, (group_label, chips) in enumerate(groups):
            group = QWidget(self)
            group_layout = QHBoxLayout(group)
            group_layout.setContentsMargins(0, 0, 0, 0)
            group_layout.setSpacing(6)
            if group_label:
                title = QLabel(group_label.upper(), group)
                title.setStyleSheet("color: palette(mid); font-size: 10px; font-weight: 600; letter-spacing: 0.5px;")
                group_layout.addWidget(title)
            for spec in chips:
                label, value, variant = spec[:3]
                accent: QColor | None = None
                tooltip: str | None = None
                if len(spec) == 4:
                    maybe = spec[3]
                    if isinstance(maybe, str):
                        tooltip = maybe
                    else:
                        accent = maybe
                elif len(spec) >= 5:
                    maybe_accent = spec[3]
                    maybe_tip = spec[4]
                    if not isinstance(maybe_accent, str):
                        accent = maybe_accent
                    if isinstance(maybe_tip, str):
                        tooltip = maybe_tip
                chip = Chip(label, value, group, variant=variant, accent=accent)
                if tooltip:
                    chip.setToolTip(tooltip)
                group_layout.addWidget(chip)
            layout.addWidget(group)
        # FlowLayout handles wrapping; no separators or stretch to avoid awkward line starts.

    def set_values(self, pairs: Sequence[tuple[str, str]]) -> None:
        self.set_groups([("", [(label, value, "default") for (label, value) in pairs])])


class DecisionAuthorityBanner(QFrame):
    clicked = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("DecisionAuthorityBanner")
        self.setFrameShape(QFrame.NoFrame)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(3)

        self.headline = QLabel("—", self)
        self.headline.setObjectName("DecisionAuthorityHeadline")
        self.headline.setAlignment(Qt.AlignCenter)

        self.mode_line = QLabel("", self)
        self.mode_line.setObjectName("DecisionAuthorityModeLine")
        self.mode_line.setAlignment(Qt.AlignCenter)
        self.mode_line.setWordWrap(False)
        self.mode_line.hide()

        self.blockers_line = QLabel("", self)
        self.blockers_line.setObjectName("DecisionAuthorityBlockersLine")
        self.blockers_line.setAlignment(Qt.AlignCenter)
        self.blockers_line.setWordWrap(False)
        self.blockers_line.hide()

        self.next_action_line = QLabel("", self)
        self.next_action_line.setObjectName("DecisionAuthorityNextActionLine")
        self.next_action_line.setAlignment(Qt.AlignCenter)
        self.next_action_line.setWordWrap(False)
        self.next_action_line.hide()

        layout.addWidget(self.headline)
        layout.addWidget(self.blockers_line)
        layout.addWidget(self.next_action_line)
        layout.addWidget(self.mode_line)

        # Stable height for the boss signal: small viewports still need a legible
        # verdict + one subordinate line when possible.
        self.setMinimumHeight(56)

        self._mode_full = ""
        self._blockers_full = ""
        self._next_action_full = ""
        self._accent = QColor(120, 120, 120)
        self._density = ""
        self._headline_px = 26
        self._line_px = 11
        self._pending_reflow = False
        self._pressed = False
        self._apply_density()
        self._apply_style()

    def mousePressEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        if event.button() == Qt.LeftButton:
            self._pressed = True
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        super().mouseReleaseEvent(event)
        pressed = event.button() == Qt.LeftButton and bool(getattr(self, "_pressed", False))
        self._pressed = False
        if pressed:
            try:
                pos = event.position().toPoint() if hasattr(event, "position") else event.pos()
                if self.rect().contains(pos):
                    self.clicked.emit()
            except Exception:
                self.clicked.emit()

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self._apply_density()
        self._apply_vertical_compact_state()
        self._apply_elide()

    def set_state(
        self,
        verb: str,
        *,
        accent: QColor,
        mode_line: str | None = None,
        blockers: Sequence[str] | None = None,
        next_action: str | None = None,
        tooltip: str | None = None,
    ) -> None:
        self.headline.setText(str(verb or "").strip() or "—")

        self._mode_full = str(mode_line or "").strip()
        if self._mode_full:
            self.mode_line.setText(self._mode_full)
            self.mode_line.show()
        else:
            self.mode_line.hide()

        blocker_items = [str(i).strip() for i in (blockers or []) if str(i).strip()]
        if blocker_items:
            max_items = 3
            display = list(blocker_items[:max_items])
            extra = len(blocker_items) - len(display)
            if extra > 0:
                display.append(f"+{extra} more")
            self._blockers_full = "Blockers: " + ", ".join(display)
            self.blockers_line.setText(self._blockers_full)
            self.blockers_line.show()
        else:
            self._blockers_full = ""
            self.blockers_line.hide()

        self._next_action_full = str(next_action or "").strip()
        if self._next_action_full:
            self._next_action_full = "Next action: " + self._next_action_full
            self.next_action_line.setText(self._next_action_full)
            self.next_action_line.show()
        else:
            self.next_action_line.hide()

        self.setToolTip(str(tooltip or "").strip())
        self._set_accent(accent)
        self.updateGeometry()
        self._request_reflow()
        self.show()

    def _request_reflow(self) -> None:
        if self._pending_reflow:
            return
        self._pending_reflow = True
        QTimer.singleShot(0, self._reflow_after_layout)

    def _reflow_after_layout(self) -> None:
        self._pending_reflow = False
        if self.width() <= 0 or self.height() <= 0:
            return
        self._apply_density()
        self._apply_vertical_compact_state()
        self._apply_elide()

    def _set_accent(self, accent: QColor) -> None:
        self._accent = QColor(accent)
        self._apply_style()

    def _apply_density(self) -> None:
        height_px = int(self.height()) if self.height() > 0 else int(self.sizeHint().height())
        if height_px < 64:
            density = "xs"
            headline_px = 20
            line_px = 10
            margins = (10, 6, 10, 6)
            spacing = 2
        elif height_px < 86:
            density = "sm"
            headline_px = 24
            line_px = 11
            margins = (12, 8, 12, 8)
            spacing = 3
        else:
            density = "md"
            headline_px = 26
            line_px = 11
            margins = (14, 10, 14, 10)
            spacing = 3

        if density == self._density:
            return
        self._density = density
        self._headline_px = headline_px
        self._line_px = line_px
        layout = self.layout()
        if isinstance(layout, QVBoxLayout):
            layout.setContentsMargins(*margins)
            layout.setSpacing(spacing)
        self._apply_style()

    def _apply_style(self) -> None:
        c = QColor(self._accent)
        bg = QColor(c)
        bg.setAlphaF(0.14)
        border = QColor(c)
        border.setAlphaF(0.65)
        self.setStyleSheet(
            f"QFrame#DecisionAuthorityBanner {{ border-radius: 12px; "
            f"background-color: {bg.name(QColor.HexArgb)}; border: 1px solid {border.name(QColor.HexArgb)}; }}"
            f"QLabel#DecisionAuthorityHeadline {{ color: {c.name()}; font-size: {self._headline_px}px; font-weight: 900; letter-spacing: 0.5px; }}"
            f"QLabel#DecisionAuthorityModeLine {{ color: palette(mid); font-size: {self._line_px}px; }}"
            f"QLabel#DecisionAuthorityBlockersLine {{ color: palette(window-text); font-size: {self._line_px}px; }}"
            f"QLabel#DecisionAuthorityNextActionLine {{ color: palette(window-text); font-size: {self._line_px}px; font-weight: 700; }}"
        )

    def _apply_elide(self) -> None:
        layout = self.layout()
        if not isinstance(layout, QLayout):
            return
        margins = layout.contentsMargins()
        avail = max(0, int(self.width() - margins.left() - margins.right()))

        if self._mode_full:
            self.mode_line.setText(self.mode_line.fontMetrics().elidedText(self._mode_full, Qt.ElideRight, avail))
        if self._blockers_full:
            self.blockers_line.setText(self.blockers_line.fontMetrics().elidedText(self._blockers_full, Qt.ElideRight, avail))
        if self._next_action_full:
            self.next_action_line.setText(
                self.next_action_line.fontMetrics().elidedText(self._next_action_full, Qt.ElideRight, avail)
            )

    def _apply_vertical_compact_state(self) -> None:
        layout = self.layout()
        if not isinstance(layout, QVBoxLayout):
            return
        margins = layout.contentsMargins()
        spacing = layout.spacing()

        # Always show the boss signal.
        self.headline.show()

        def _h(widget: QWidget) -> int:
            try:
                return int(widget.sizeHint().height())
            except Exception:
                return 0

        want_mode = bool(self._mode_full)
        want_blockers = bool(self._blockers_full)
        want_next = bool(self._next_action_full)

        show_mode = want_mode
        show_blockers = want_blockers
        show_next = want_next

        def _needed(show_mode: bool, show_blockers: bool, show_next: bool) -> int:
            parts = [_h(self.headline)]
            if show_blockers:
                parts.append(_h(self.blockers_line))
            if show_next:
                parts.append(_h(self.next_action_line))
            if show_mode:
                parts.append(_h(self.mode_line))
            active = [p for p in parts if p > 0]
            if not active:
                return 0
            return margins.top() + margins.bottom() + sum(active) + spacing * (len(active) - 1)

        available = int(self.height())
        while _needed(show_mode, show_blockers, show_next) > available:
            if show_mode:
                show_mode = False
                continue
            if show_next:
                show_next = False
                continue
            if show_blockers:
                show_blockers = False
                continue
            break

        self.mode_line.setVisible(show_mode)
        self.blockers_line.setVisible(show_blockers)
        self.next_action_line.setVisible(show_next)


class AuditRibbon(QFrame):
    """Thin, always-on audit ribbon (single line, clickable)."""

    clicked = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("AuditRibbon")
        self.setFrameShape(QFrame.NoFrame)
        self.setCursor(Qt.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setMinimumHeight(22)
        self.setMaximumHeight(24)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 2, 10, 2)
        layout.setSpacing(6)

        self._label = QLabel("—", self)
        self._label.setObjectName("AuditRibbonLabel")
        self._label.setAlignment(Qt.AlignVCenter | Qt.AlignLeft)
        self._label.setWordWrap(False)
        layout.addWidget(self._label, stretch=1)

        self._accent = QColor(120, 120, 120)
        self._full_text = "—"
        self._pressed = False
        self._apply_style()

    def mousePressEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        if event.button() == Qt.LeftButton:
            self._pressed = True
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        super().mouseReleaseEvent(event)
        pressed = event.button() == Qt.LeftButton and bool(getattr(self, "_pressed", False))
        self._pressed = False
        if pressed:
            try:
                pos = event.position().toPoint() if hasattr(event, "position") else event.pos()
                if self.rect().contains(pos):
                    self.clicked.emit()
            except Exception:
                self.clicked.emit()

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self._apply_elide()

    def set_state(self, text: str, *, accent: QColor, tooltip: str | None = None) -> None:
        self._full_text = str(text or "").strip() or "—"
        self._accent = QColor(accent)
        self._apply_style()
        self._apply_elide()
        self.setToolTip(str(tooltip or "").strip())
        self.show()

    def _apply_elide(self) -> None:
        avail = max(0, int(self.width() - 22))
        try:
            self._label.setText(self._label.fontMetrics().elidedText(self._full_text, Qt.ElideRight, avail))
        except Exception:
            self._label.setText(self._full_text)

    def _apply_style(self) -> None:
        c = QColor(self._accent)
        bg = QColor(c)
        bg.setAlphaF(0.12)
        border = QColor(c)
        border.setAlphaF(0.55)
        self.setStyleSheet(
            f"QFrame#AuditRibbon {{ border-radius: 8px; "
            f"background-color: {bg.name(QColor.HexArgb)}; border: 1px solid {border.name(QColor.HexArgb)}; }}"
            f"QLabel#AuditRibbonLabel {{ color: {c.name()}; font-size: 11px; font-weight: 800; }}"
        )


@dataclass(frozen=True)
class DecisionDetailRow:
    label: str
    value: str
    required: bool | None = None
    computed: bool | None = None
    blocks: bool = False
    tooltip: str | None = None


class DecisionDetailsPanel(QFrame):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("DecisionDetailsPanel")
        self.setFrameShape(QFrame.NoFrame)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(8)

        self._required_section, self._required_grid = self._make_section("Decision readiness", parent=self)
        self._risk_section, self._risk_grid = self._make_section("Risk modifiers", parent=self)

        self._expl_toggle = QToolButton(self)
        self._expl_toggle.setCheckable(True)
        self._expl_toggle.setChecked(False)
        self._expl_toggle.toggled.connect(self._on_expl_toggled)
        self._expl_toggle.setStyleSheet(
            "QToolButton { padding: 0px; color: palette(mid); font-size: 11px; font-weight: 600; }"
        )
        self._expl_container, self._expl_grid = self._make_section("Exploratory diagnostics", parent=self, with_header=False)
        self._expl_container.setVisible(False)

        root.addWidget(self._required_section)
        root.addWidget(self._risk_section)
        root.addWidget(self._expl_toggle)
        root.addWidget(self._expl_container)

        self._update_expl_toggle_text()

    def set_details(
        self,
        *,
        required: Sequence[DecisionDetailRow],
        risk: Sequence[DecisionDetailRow],
        exploratory: Sequence[DecisionDetailRow],
        exploratory_visible: bool | None,
    ) -> None:
        self._set_rows(self._required_section, self._required_grid, list(required))
        self._set_rows(self._risk_section, self._risk_grid, list(risk))
        self._set_rows(self._expl_container, self._expl_grid, list(exploratory))

        has_expl = bool(exploratory)
        self._expl_toggle.setVisible(has_expl)
        if not has_expl:
            self._expl_container.setVisible(False)
        elif exploratory_visible is not None:
            self._expl_toggle.setChecked(bool(exploratory_visible))
        self._update_expl_toggle_text()

    def _update_expl_toggle_text(self) -> None:
        arrow = "▾" if self._expl_toggle.isChecked() else "▸"
        self._expl_toggle.setText(f"{arrow} Exploratory diagnostics")

    def _on_expl_toggled(self, checked: bool) -> None:
        try:
            self._expl_container.setVisible(bool(checked))
        except Exception:
            pass
        self._update_expl_toggle_text()

    def _make_section(
        self,
        title: str,
        *,
        parent: QWidget,
        with_header: bool = True,
    ) -> tuple[QWidget, QGridLayout]:
        section = QWidget(parent)
        layout = QVBoxLayout(section)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        if with_header:
            header = QLabel(title.upper(), section)
            header.setStyleSheet("color: palette(mid); font-size: 10px; font-weight: 600; letter-spacing: 0.5px;")
            layout.addWidget(header)
        grid = QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(4)
        grid.setColumnStretch(3, 1)
        layout.addLayout(grid)
        return section, grid

    def _set_rows(self, section: QWidget, grid: QGridLayout, rows: list[DecisionDetailRow]) -> None:
        while grid.count():
            item = grid.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        if not rows:
            section.setVisible(False)
            return
        section.setVisible(True)
        for idx, row in enumerate(rows):
            self._add_row(grid, idx, row)

    def _add_row(self, grid: QGridLayout, row_idx: int, row: DecisionDetailRow) -> None:
        name = QLabel(str(row.label), self)
        name.setObjectName("DecisionDetailName")
        name.setStyleSheet("color: palette(window-text); font-size: 11px; font-weight: 600;")
        name.setTextInteractionFlags(Qt.TextSelectableByMouse)
        name.setFocusPolicy(Qt.StrongFocus)

        req_txt = ""
        if row.required is True:
            req_txt = "REQUIRED"
        elif row.required is False:
            req_txt = "OPTIONAL"
        req = QLabel(req_txt, self)
        req.setStyleSheet("color: palette(mid); font-size: 10px;")

        status_txt = "—"
        status_color = "palette(mid)"
        value_color = "palette(window-text)"
        try:
            from PySide6.QtWidgets import QApplication

            app = QApplication.instance()
        except Exception:
            app = None

        def _app_prop_qss(name: str) -> str | None:
            if app is None:
                return None
            try:
                val = app.property(name)
            except Exception:
                return None
            if isinstance(val, str) and val.strip():
                return val.strip()
            return None

        success_qss = _app_prop_qss("helixSuccess")
        error_qss = _app_prop_qss("helixError")
        if row.computed is True:
            status_txt = "COMPUTED"
            status_color = success_qss or "palette(highlight)"
            value_color = "palette(window-text)"
        elif row.computed is False:
            status_txt = "MISSING" if row.blocks else "NOT COMPUTED"
            if row.blocks:
                status_color = error_qss or "palette(mid)"
                value_color = error_qss or "palette(mid)"
            else:
                status_color = "palette(mid)"
                value_color = "palette(mid)"

        status = QLabel(status_txt, self)
        status.setObjectName("DecisionDetailStatus")
        status.setStyleSheet(f"color: {status_color}; font-size: 10px; font-weight: 700;")

        value = QLabel(str(row.value or "").strip() or "—", self)
        value.setObjectName("DecisionDetailValue")
        value.setStyleSheet(f"color: {value_color}; font-size: 11px;")
        value.setWordWrap(True)
        value.setTextInteractionFlags(Qt.TextSelectableByMouse)

        tooltip = str(row.tooltip or "").strip()
        if tooltip:
            for w in (name, req, status, value):
                w.setToolTip(tooltip)

        grid.addWidget(name, row_idx, 0)
        grid.addWidget(req, row_idx, 1)
        grid.addWidget(status, row_idx, 2)
        grid.addWidget(value, row_idx, 3)


class LegendSwatch(QFrame):
    def __init__(self, color: QColor, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFixedSize(10, 10)
        self.setFrameShape(QFrame.NoFrame)
        c = QColor(color)
        bg = QColor(c)
        bg.setAlphaF(0.92)
        border = QColor(c)
        border.setAlphaF(0.65)
        self.setStyleSheet(
            "QFrame { border-radius: 3px; "
            f"background-color: {bg.name(QColor.HexArgb)}; border: 1px solid {border.name(QColor.HexArgb)}; }}"
        )


class OutcomeLegendRow(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("OutcomeLegendRow")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)
        self._items: list[QWidget] = []
        self._run_kind = "crispr"
        self._muted = False
        self.set_run_kind("crispr")

    def set_muted(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if enabled == self._muted:
            return
        self._muted = enabled
        self.set_run_kind(self._run_kind)

    def set_run_kind(self, kind: str | None) -> None:
        self._run_kind = (kind or "crispr").lower()

        def _maybe_muted(color: QColor) -> QColor:
            return _exploratory_desaturate(color) if self._muted else QColor(color)

        layout: QHBoxLayout = self.layout()  # type: ignore[assignment]
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        title = QLabel("Legend", self)
        title.setStyleSheet("color: palette(mid); font-size: 11px; font-weight: 600;")
        layout.addWidget(title)

        if self._run_kind == "prime":
            self._add_item("Desired", [_maybe_muted(PRIME_COLORS["desired"])])
            self._add_item("Byproduct", [_maybe_muted(PRIME_COLORS["byproduct"])])
            self._add_item("Indel", [_maybe_muted(PRIME_COLORS["indel"])])
            self._add_item("No cut", [_maybe_muted(PRIME_COLORS["no_cut"])])
        else:
            self._add_item("Intended", [_maybe_muted(CATEGORY_COLORS["intended"])])
            self._add_item(
                "Competing repair",
                [_maybe_muted(CATEGORY_COLORS["small_deletion"]), _maybe_muted(CATEGORY_COLORS["small_insertion"])],
            )
            self._add_item("No cut / escape", [_maybe_muted(CATEGORY_COLORS["no_cut"])])
            self._add_item("Harmful", [_maybe_muted(CATEGORY_COLORS["large_deletion"])])

        layout.addStretch(1)

    def _add_item(self, label: str, colors: Sequence[QColor]) -> None:
        item = QWidget(self)
        row = QHBoxLayout(item)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(6)
        for c in colors:
            row.addWidget(LegendSwatch(c, item))
        txt = QLabel(label, item)
        txt.setStyleSheet("color: palette(mid); font-size: 11px;")
        row.addWidget(txt)
        self.layout().addWidget(item)  # type: ignore[union-attr]


class TierLegendRow(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("TierLegendRow")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)

        title = QLabel("Tiers", self)
        title.setStyleSheet("color: palette(mid); font-size: 11px; font-weight: 600;")
        layout.addWidget(title)

        self._add_item("Tier 1", ":/icons/check.svg", role=QPalette.ColorRole.Highlight)
        self._add_item("Tier 2", ":/icons/warning.svg", role=QPalette.ColorRole.Mid)
        self._add_item("Tier 3+", ":/icons/hazard.svg", role=QPalette.ColorRole.Mid)

        layout.addStretch(1)

    def _tinted_icon(self, resource_path: str, size: int, role: QPalette.ColorRole) -> QPixmap:
        base = QIcon(resource_path).pixmap(size, size)
        if base.isNull():
            return base
        tinted = QPixmap(base.size())
        tinted.setDevicePixelRatio(base.devicePixelRatio())
        tinted.fill(Qt.transparent)
        painter = QPainter(tinted)
        painter.drawPixmap(0, 0, base)
        painter.setCompositionMode(QPainter.CompositionMode_SourceIn)
        painter.fillRect(tinted.rect(), self.palette().color(role))
        painter.end()
        return tinted

    def _add_item(self, label: str, icon_path: str, *, role: QPalette.ColorRole) -> None:
        item = QWidget(self)
        row = QHBoxLayout(item)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(6)
        icon = QLabel(item)
        icon.setPixmap(self._tinted_icon(icon_path, 12, role))
        icon.setFixedSize(12, 12)
        txt = QLabel(label, item)
        txt.setStyleSheet("color: palette(mid); font-size: 11px;")
        row.addWidget(icon)
        row.addWidget(txt)
        self.layout().addWidget(item)  # type: ignore[union-attr]


@dataclass(frozen=True)
class TraceSeries:
    label: str
    values: Sequence[float]
    color: QColor


class MiniTraceChart(QFrame):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._series: list[TraceSeries] = []
        self._y_max: float | None = None
        self.setMinimumHeight(86)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def set_series(self, series: Sequence[TraceSeries], *, y_max: float | None = None) -> None:
        self._series = list(series)
        self._y_max = y_max
        self.update()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        rect = self.rect()
        _draw_elevated_panel(p, rect, radius=8)
        inner = rect.adjusted(10, 8, -10, -8)
        if inner.isEmpty():
            return
        if not self._series or not any(len(s.values) > 0 for s in self._series):
            p.setPen(self.palette().color(self.foregroundRole()))
            p.drawText(inner, Qt.AlignCenter, "No iteration trace")
            return
        max_val = self._y_max
        if max_val is None:
            max_val = 0.0
            for s in self._series:
                for v in s.values:
                    max_val = max(max_val, float(v))
        if max_val <= 0.0:
            max_val = 1.0
        for series in self._series:
            values = [float(v) for v in series.values]
            if not values:
                continue
            if len(values) == 1:
                x = inner.left()
                y = inner.bottom() - (inner.height() * values[0] / max_val)
                p.setPen(QPen(series.color, 2.0))
                p.drawEllipse(QPoint(int(x), int(y)), 2, 2)
                continue
            path = QPainterPath()
            for idx, val in enumerate(values):
                t = idx / float(len(values) - 1)
                x = inner.left() + inner.width() * t
                y = inner.bottom() - (inner.height() * val / max_val)
                if idx == 0:
                    path.moveTo(x, y)
                else:
                    path.lineTo(x, y)
            p.setPen(QPen(series.color, 1.6))
            p.drawPath(path)


class IterationTracePanel(QFrame):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("IterationTracePanel")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(SPACING_SMALL)

        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        self._toggle = QToolButton(self)
        self._toggle.setCheckable(True)
        self._toggle.setChecked(False)
        self._toggle.setAutoRaise(True)
        self._toggle.setStyleSheet("QToolButton { padding: 0px; color: palette(window-text); font-size: 11px; font-weight: 700; }")
        self._toggle.toggled.connect(self._on_toggled)
        self._meta = QLabel("", self)
        self._meta.setStyleSheet("color: palette(mid); font-size: 10px;")
        header.addWidget(self._toggle)
        header.addStretch(1)
        header.addWidget(self._meta)
        layout.addLayout(header)

        self._charts_container = QWidget(self)
        charts = QHBoxLayout(self._charts_container)
        charts.setContentsMargins(0, 0, 0, 0)
        charts.setSpacing(SPACING_SMALL)

        left = QVBoxLayout()
        left.setContentsMargins(0, 0, 0, 0)
        left.setSpacing(4)
        left_label = QLabel("Mass fractions", self)
        left_label.setStyleSheet("color: palette(mid); font-size: 10px;")
        self._mass_chart = MiniTraceChart(self)
        left.addWidget(left_label)
        left.addWidget(self._mass_chart)

        right = QVBoxLayout()
        right.setContentsMargins(0, 0, 0, 0)
        right.setSpacing(4)
        right_label = QLabel("Entropy & kappa", self)
        right_label.setStyleSheet("color: palette(mid); font-size: 10px;")
        self._stability_chart = MiniTraceChart(self)
        right.addWidget(right_label)
        right.addWidget(self._stability_chart)

        charts.addLayout(left, stretch=1)
        charts.addLayout(right, stretch=1)
        layout.addWidget(self._charts_container)

        self.setVisible(False)
        self._charts_container.setVisible(False)
        self._update_toggle_text()

    def _update_toggle_text(self) -> None:
        arrow = "▾" if self._toggle.isChecked() else "▸"
        self._toggle.setText(f"{arrow} Iteration traces")

    def _on_toggled(self, expanded: bool) -> None:
        self._charts_container.setVisible(bool(expanded))
        self._update_toggle_text()

    def set_trace(self, iteration: Mapping[str, Any] | None) -> None:
        if not isinstance(iteration, Mapping):
            self.setVisible(False)
            return
        status = str(iteration.get("status") or "")
        if status != "computed":
            self.setVisible(False)
            return
        intended = iteration.get("intended") if isinstance(iteration.get("intended"), list) else []
        uncut = iteration.get("uncut") if isinstance(iteration.get("uncut"), list) else []
        harmful = iteration.get("harmful") if isinstance(iteration.get("harmful"), list) else []
        kappa_max = iteration.get("kappa_max") if isinstance(iteration.get("kappa_max"), list) else []
        entropy = iteration.get("entropy_joint_bits") if isinstance(iteration.get("entropy_joint_bits"), list) else []
        steps = int(iteration.get("steps") or max(len(intended), 0) - 1)
        transition = str(iteration.get("transition_model") or "identity")
        self._meta.setText(f"steps={steps} · T={transition}")

        mass_series = [
            TraceSeries("Intended", [float(v) for v in intended], CATEGORY_COLORS["intended"]),
            TraceSeries("Uncut", [float(v) for v in uncut], CATEGORY_COLORS["no_cut"]),
            TraceSeries("Harmful", [float(v) for v in harmful], CATEGORY_COLORS["large_deletion"]),
        ]
        self._mass_chart.set_series(mass_series, y_max=1.0)

        stability_series = [
            TraceSeries("Kappa", [float(v) for v in kappa_max], CATEGORY_COLORS["small_insertion"]),
            TraceSeries("Entropy", [float(v) for v in entropy], CATEGORY_COLORS["small_deletion"]),
        ]
        self._stability_chart.set_series(stability_series)
        self.setVisible(True)
        self._charts_container.setVisible(bool(self._toggle.isChecked()))
        self._update_toggle_text()


def _exploratory_ack_button_qss(widget: QWidget) -> str:
    """
    Build a QToolButton stylesheet using theme palette colors (with alpha) without raw literals.

    This keeps strict color-lint clean for `src/helix/studio/*` while preserving the "chip" look.
    """
    try:
        pal = widget.palette()
        bg = QColor(pal.color(QPalette.ColorRole.Window))
        bg.setAlpha(170)
        border = QColor(pal.color(QPalette.ColorRole.Mid))
        border.setAlpha(140)
        text = QColor(pal.color(QPalette.ColorRole.WindowText))
        text.setAlpha(200)
        hover = QColor(pal.color(QPalette.ColorRole.WindowText))
        hover.setAlpha(170)
        focus = QColor(pal.color(QPalette.ColorRole.WindowText))
        focus.setAlpha(220)
        bg_hex = bg.name(QColor.HexArgb)
        border_hex = border.name(QColor.HexArgb)
        text_hex = text.name(QColor.HexArgb)
        hover_hex = hover.name(QColor.HexArgb)
        focus_hex = focus.name(QColor.HexArgb)
        return (
            "QToolButton { padding: 6px 10px; border-radius: 10px; "
            f"background: {bg_hex}; border: 1px solid {border_hex}; "
            f"color: {text_hex}; font-size: 11px; font-weight: 700; }}"
            f"QToolButton:hover {{ border-color: {hover_hex}; }}"
            f"QToolButton:focus {{ outline: none; border-color: {focus_hex}; }}"
        )
    except Exception:
        return "QToolButton { padding: 6px 10px; border-radius: 10px; font-size: 11px; font-weight: 700; }"


class OutcomeChartWidget(QFrame):
    barSelected = Signal(str)
    outcomeSelected = Signal(str)
    outcomeHovered = Signal(object)
    exploratoryAckRequested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFont(base_font())
        self._bars: list[OutcomeBar] = []
        self._positions: list[int] = []
        self._heat: list[float] = []
        self._run_kind = ""
        self._value_mode = "score"
        self._selected: str | None = None
        self._hovered: str | None = None
        self._min_prob = 0.0
        self._category_filter = "all"
        self._pathway_filter = "all"
        self._external_highlight: str | None = None
        self._display_values: dict[str, float] = {}
        self._anim_start: dict[str, float] = {}
        self._anim_target: dict[str, float] = {}
        self._anim_elapsed_ms = 0
        self._anim_duration_ms = 180
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(16)
        self._anim_timer.timeout.connect(self._tick_animation)
        self._animating = False
        self._tip_label: str | None = None
        self._perf_simple = False
        self._overlay_values: dict[str, float] | None = None
        self._overlay_label: str | None = None
        self._inspect_mode = False
        self._exploratory_mode = False
        self._exploratory_color_ack = False
        self._rank_by_label: dict[str, int] = {}
        self._last_painted_colors: dict[str, QColor] = {}
        self._watermark_visible = False
        self.setMouseTracking(True)
        self.setFrameShape(QFrame.NoFrame)
        # Allow small-window layouts (e.g. 1024x640) to preserve the boss-signal
        # banner + decision rows instead of forcing the chart to dominate vertical space.
        self.setMinimumHeight(90)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        layout.setSpacing(SPACING_SMALL)

        self._legend = QLabel(self._legend_text(), self)
        self._legend.setStyleSheet("color: palette(mid); font-size: 11px;")
        layout.addWidget(self._legend, alignment=Qt.AlignTop | Qt.AlignLeft)
        self._context_label = QLabel("", self)
        self._context_label.setStyleSheet("color: palette(mid); font-size: 10px;")
        self._context_label.setWordWrap(True)
        self._context_label.hide()
        layout.addWidget(self._context_label, alignment=Qt.AlignTop | Qt.AlignLeft)
        layout.addStretch(1)

        self._axis_label = f"Outcome {_value_label_lower(self._value_mode)} (%)"

        self._ack_btn = QToolButton(self)
        self._ack_btn.setObjectName("ExploratoryAckButton")
        self._ack_btn.setText("Enable color")
        self._ack_btn.setToolTip("Enable saturated category colors (exploratory mode only).")
        self._ack_btn.setCursor(Qt.PointingHandCursor)
        self._ack_btn.setFocusPolicy(Qt.TabFocus)
        self._ack_btn.setVisible(False)
        self._ack_btn.clicked.connect(self.exploratoryAckRequested.emit)
        self._ack_btn.setStyleSheet(_exploratory_ack_button_qss(self._ack_btn))
        self._update_accessibility()

    def set_exploratory_mode(self, enabled: bool, *, color_acknowledged: bool) -> None:
        enabled = bool(enabled)
        ack = bool(color_acknowledged)
        if enabled == self._exploratory_mode and ack == self._exploratory_color_ack:
            return
        self._exploratory_mode = enabled
        self._exploratory_color_ack = ack
        try:
            self._ack_btn.setVisible(enabled and (not ack))
        except Exception:
            pass
        self._position_ack_btn()
        self._update_accessibility()
        try:
            self._start_animation(list(getattr(self, "_bars", []) or []))
        except Exception:
            pass
        self.update()

    def _update_accessibility(self) -> None:
        try:
            self.setAccessibleName("Outcome distribution (position vs cut)")
        except Exception:
            pass
        if self._exploratory_mode:
            if self._exploratory_color_ack:
                desc = "Exploratory mode: non-comparable scores. Colors enabled after acknowledgement."
            else:
                desc = "Exploratory mode: non-comparable scores. Colors muted until acknowledged."
        else:
            desc = "Decision-grade mode: calibrated, comparable probabilities."
        try:
            self.setAccessibleDescription(desc)
        except Exception:
            pass
        try:
            self._ack_btn.setAccessibleName("Enable exploratory colors")
            self._ack_btn.setAccessibleDescription(desc)
        except Exception:
            pass

    def _position_ack_btn(self) -> None:
        try:
            plot = self.rect().adjusted(70, 24, -32, -36)
            btn = self._ack_btn
            if not btn.isVisible():
                return
            hint = btn.sizeHint()
            w = int(hint.width())
            h = int(hint.height())
            x = int(plot.right() - w - 10)
            y = int(plot.top() + 10)
            btn.setGeometry(QRect(max(0, x), max(0, y), w, h))
            btn.raise_()
        except Exception:
            return

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self._position_ack_btn()

    def set_inspect_mode(self, enabled: bool) -> None:
        self._inspect_mode = bool(enabled)
        try:
            self._legend.setVisible(bool(enabled))
            self._context_label.setVisible(bool(self._context_label.text()))
        except Exception:
            pass
        self.update()

    def set_context(self, context_text: str | None, calibration: CalibrationBadge | None) -> None:
        if not context_text and not calibration:
            self._context_label.hide()
            return
        cal_text = f"Calibration: {calibration.value}" if calibration is not None else "Calibration: unknown"
        text = context_text or "Context: unknown"
        self._context_label.setText(f"{text}\n{cal_text}")
        self._context_label.setVisible(True)

    def set_value_mode(self, mode: str) -> None:
        mode = "probability" if str(mode) == "probability" else "score"
        if mode == self._value_mode:
            return
        self._value_mode = mode
        self._axis_label = f"Outcome {_value_label_lower(self._value_mode)} (%)"
        try:
            self._legend.setText(self._legend_text())
        except Exception:
            pass
        self.update()

    def sizeHint(self) -> QSize:  # type: ignore[override]
        return QSize(800, 320)

    def set_run_kind(self, kind: str | None) -> None:
        self._run_kind = (kind or "").lower()
        self.update()

    def set_data(self, bars: list[OutcomeBar], positions: list[int], heat: list[float]) -> None:
        self._bars = bars
        self._positions = positions
        self._heat = heat
        # Bars are generally passed in probability-sorted order; use that to build
        # a stable ordinal rank mapping for exploratory/non-calibrated UI.
        self._rank_by_label = {str(b.label): int(i + 1) for i, b in enumerate(bars or []) if getattr(b, "label", None)}
        self._start_animation(bars)
        self.update()

    def set_overlay(self, values: dict[str, float] | None, label: str | None = None) -> None:
        self._overlay_values = values
        self._overlay_label = label
        self.update()

    def set_lens(self, lens: str) -> None:
        self._lens = lens
        self.update()

    def _start_animation(self, bars: list[OutcomeBar]) -> None:
        if self._perf_simple:
            self._animating = False
            if bool(getattr(self, "_exploratory_mode", False)):
                self._display_values = {
                    str(b.label): tier_fill_fraction(tier_for_rank(self._rank_by_label.get(str(b.label), 10**9)))
                    for b in (bars or [])
                }
            else:
                self._display_values = {b.label: b.probability for b in bars}
            return
        if bool(getattr(self, "_exploratory_mode", False)):
            targets = {
                str(b.label): tier_fill_fraction(tier_for_rank(self._rank_by_label.get(str(b.label), 10**9)))
                for b in (bars or [])
            }
        else:
            targets = {b.label: b.probability for b in bars}
        keys = set(targets) | set(self._display_values.keys())
        if not keys:
            self._display_values = {}
            self._anim_timer.stop()
            self._animating = False
            return
        self._anim_start = {k: self._display_values.get(k, 0.0) for k in keys}
        self._anim_target = {k: targets.get(k, 0.0) for k in keys}
        self._display_values = dict(self._anim_start)
        self._anim_elapsed_ms = 0
        self._animating = True
        self._anim_timer.start()

    def _tick_animation(self) -> None:
        self._anim_elapsed_ms += self._anim_timer.interval()
        t = min(1.0, self._anim_elapsed_ms / float(self._anim_duration_ms)) if self._anim_duration_ms else 1.0
        # ease-out quad for a quick but smooth settle
        ease = 1.0 - (1.0 - t) * (1.0 - t)
        for key, target in self._anim_target.items():
            start = self._anim_start.get(key, 0.0)
            self._display_values[key] = start + (target - start) * ease
        self.update()
        if t >= 1.0:
            self._anim_timer.stop()
        self._display_values = dict(self._anim_target)
        self._animating = False

    def _bar_height_px(self, bar: OutcomeBar, *, is_primary: bool, summary_mode: bool) -> int:
        base = 10
        if summary_mode and is_primary:
            base = 16
        energy = scalar_value(bar.energy_margin)
        if energy is None:
            return base
        # More negative ΔG → larger margin → thicker bar (clamped for readability).
        margin = min(max(-energy, 0.0), 40.0)
        return int(min(22.0, base + 0.25 * margin))

    def _alpha_for_bar(self, bar: OutcomeBar, base_alpha: float) -> float:
        rate = scalar_value(bar.kinetic_rate)
        if rate is None:
            return base_alpha
        # Map kinetic accessibility to [0.35, 1.0].
        clamped = min(max(rate, 0.0), 5.0)
        return min(1.0, max(0.35, base_alpha * (0.55 + 0.09 * clamped)))

    def _thermo_color(self, base_color: QColor, bar: OutcomeBar) -> QColor:
        favor = scalar_value(bar.thermo_favorability)
        if favor is None:
            return base_color
        # More negative free energy → darker/more saturated to denote favorability.
        try:
            span = max(-40.0, min(0.0, float(favor)))
            factor = 100 + int(abs(span) * 1.2)
            return base_color.darker(max(100, min(180, factor)))
        except Exception:
            return base_color

    def _legend_text(self) -> str:
        if bool(getattr(self, "_exploratory_mode", False)):
            return (
                "DEMO (NON-CALIBRATED): quantitative outputs suppressed. "
                "Vertical axis = position vs cut (0 bp). Bar length encodes ordinal tier only."
            )
        label = _value_label_lower(self._value_mode)
        return (
            "Vertical axis = position vs cut (0 bp). "
            f"Bar length = outcome {label}, thickness = ΔG margin (kcal/mol), "
            "opacity = kinetic accessibility, color hue = thermodynamic favorability. "
            "Click a bar for full semantics."
        )

    def _hover_text(self, bar: OutcomeBar) -> str:
        if bool(getattr(self, "_exploratory_mode", False)):
            why = _why_for_outcome(bar, run_kind=str(self._run_kind or "crispr"))
            rank = int(self._rank_by_label.get(str(bar.label), 0) or 0)
            tier = tier_for_rank(rank or 10**9).label
            base_txt = f"{bar.label} · {tier}" + (f" · rank #{rank}" if rank else "")
            base_txt += f" · frameshift: {'yes' if bar.frameshift else 'no'}"
            if getattr(bar, "pathway", None):
                base_txt += f" · pathway: {PATHWAY_UI_LABEL.get(str(bar.pathway), str(bar.pathway))}"
            base_txt += f" · calibration {bar.calibration.value}"
            if bar.schema_issues:
                base_txt += f" · schema: {', '.join(bar.schema_issues)}"
            # Never include baseline deltas/percentages in non-calibrated mode.
            if self._overlay_values and bar.label in self._overlay_values:
                base_txt += " · baseline comparison suppressed"
            return f"<b>This outcome exists because {why}</b><br/>{base_txt}"

        label = _value_label_lower(self._value_mode)
        why = _why_for_outcome(bar, run_kind=str(self._run_kind or "crispr"))
        base_txt = f"{bar.label} · {label} {bar.probability*100:.1f}% · frameshift: {'yes' if bar.frameshift else 'no'}"
        if getattr(bar, "pathway", None):
            base_txt += f" · pathway: {PATHWAY_UI_LABEL.get(str(bar.pathway), str(bar.pathway))}"
        if bar.energy_margin is not None:
            base_txt += f" · ΔG margin {format_scalar(bar.energy_margin)}"
        if bar.kinetic_rate is not None:
            base_txt += f" · kinetic {format_scalar(bar.kinetic_rate)}"
        if bar.uncertainty is not None:
            base_txt += f" · uncertainty {bar.uncertainty.type.value}/{bar.uncertainty.distribution_family.value}"
        base_txt += f" · calibration {bar.calibration.value}"
        if bar.schema_issues:
            base_txt += f" · schema: {', '.join(bar.schema_issues)}"
        energy_val = scalar_value(bar.energy_margin)
        rate_val = scalar_value(bar.kinetic_rate)
        if energy_val is not None and rate_val is not None and energy_val < -10.0 and rate_val < 0.1:
            base_txt += " · dominance: kinetic-limited"
        if self._overlay_values and bar.label in self._overlay_values:
            base = self._overlay_values.get(bar.label, 0.0)
            delta = bar.probability - base
            delta_txt = f"Δ {delta*100:+.1f}%"
            base_line = f"Baseline{f' ({self._overlay_label})' if self._overlay_label else ''}: {base*100:.1f}%"
            return f"<b>This outcome exists because {why}</b><br/>{base_txt}<br/>{base_line}<br/>{delta_txt}"
        return f"<b>This outcome exists because {why}</b><br/>{base_txt}"

    def _show_hover_tooltip(self, bar: OutcomeBar, anchor: QPoint) -> None:
        text = self._hover_text(bar)
        if text != self._tip_label:
            QToolTip.showText(self.mapToGlobal(anchor), text, self)
            self._tip_label = text

    def set_filters(self, min_prob: float, category: str, pathway: str = "all") -> None:
        self._min_prob = max(0.0, min(1.0, min_prob))
        self._category_filter = category
        self._pathway_filter = str(pathway or "all").strip().lower() or "all"
        self.update()

    def _filtered_bars(self) -> list[OutcomeBar]:
        filtered = [b for b in self._bars if b.probability >= self._min_prob]
        if self._category_filter == "insertions":
            filtered = [b for b in filtered if "insertion" in b.category]
        elif self._category_filter == "deletions":
            filtered = [b for b in filtered if "deletion" in b.category]
        elif self._category_filter == "no_cut":
            filtered = [b for b in filtered if b.category == "no_cut"]
        elif self._category_filter == "frameshift":
            filtered = [b for b in filtered if b.frameshift]
        if self._pathway_filter != "all":
            filtered = [
                b
                for b in filtered
                if str(getattr(b, "pathway", None) or "").strip().lower() == self._pathway_filter
            ]
        return filtered

    def paintEvent(self, event) -> None:  # type: ignore[override]
        p = QPainter(self)
        try:
            p.setRenderHint(QPainter.Antialiasing, True)
            _draw_elevated_panel(p, self.rect(), radius=8)

            rect = self.rect().adjusted(70, 24, -32, -36)
            exploratory = bool(getattr(self, "_exploratory_mode", False))
            color_ack = bool(getattr(self, "_exploratory_color_ack", False))
            self._watermark_visible = False
            self._last_painted_colors = {}
            filtered = self._filtered_bars()
            summary_mode = not bool(getattr(self, "_inspect_mode", False))

            primary_label: str | None = None
            if filtered:
                intended = [b for b in filtered if bool(getattr(b, "intended", False))]
                primary_bar = max(intended, key=lambda b: float(b.probability), default=None) if intended else max(filtered, key=lambda b: float(b.probability), default=None)
                primary_label = primary_bar.label if primary_bar is not None else None

            if self._positions:
                min_y_raw = min(self._positions)
                max_y_raw = max(self._positions)
            else:
                min_y_raw, max_y_raw = -20, 20
            radius = max(abs(min_y_raw), abs(max_y_raw))
            if radius < 2:
                radius = 2
            visible_radius = min(radius, 100)
            clamp_note = radius > visible_radius
            min_y = -visible_radius
            max_y = visible_radius
            span_y = max(1.0, float(max_y - min_y))

            # Heat strip on the left
            if self._positions and self._heat:
                stripe = QRect(rect.left() - 24, rect.top(), 16, rect.height())
                for pos, val in zip(self._positions, self._heat):
                    if pos < min_y or pos > max_y:
                        continue
                    y_norm = 1.0 - float(pos - min_y) / span_y
                    y = stripe.top() + int(y_norm * stripe.height())
                    h = max(1, int(stripe.height() / span_y))
                    color = QColor(250, 136, 60)
                    color.setAlphaF(0.08 + 0.55 * float(val))
                    p.fillRect(QRect(stripe.left(), y, stripe.width(), h), color)

            # Axes
            axis_color = QColor(120, 140, 176, 190)
            axis_pen = QPen(axis_color)
            axis_pen.setWidthF(1.1)
            grid_pen = QPen(QColor(255, 255, 255, 14))
            grid_pen.setWidthF(1.0)
            p.setPen(axis_pen)
            p.drawRect(rect)

            # Cut line (y=0)
            cut_y = rect.bottom() - (-min_y) / span_y * rect.height()
            band_h = 12
            band = QRect(rect.left(), int(cut_y - band_h * 0.5), rect.width(), band_h)
            band_color = QColor(_CUT_COLOR)
            band_color.setAlpha(int(_CUT_BAND_ALPHA))
            p.fillRect(band, band_color)

            # Y ticks
            tick_pen = QPen(QColor(120, 138, 172))
            tick_pen.setWidthF(1.0)
            p.setPen(tick_pen)
            ticks = _choose_position_ticks(int(span_y * 0.5))
            for t in ticks:
                y = rect.bottom() - (t - min_y) / span_y * rect.height()
                # grid line
                if t != 0:
                    p.setPen(grid_pen)
                    p.drawLine(rect.left(), int(y), rect.right(), int(y))
                    p.setPen(tick_pen)
                p.drawLine(rect.left() - 6, int(y), rect.left(), int(y))
                p.drawText(rect.left() - 52, int(y) + 4, f"{t:+d}")

            # X ticks (quantitative axis only)
            if not exploratory:
                p.setPen(grid_pen)
                for pct in (0, 20, 40, 60, 80, 100):
                    x = rect.left() + pct / 100.0 * rect.width()
                    if pct not in (0, 100):
                        p.drawLine(int(x), rect.top(), int(x), rect.bottom())
                    p.setPen(tick_pen)
                    p.drawLine(int(x), rect.bottom(), int(x), rect.bottom() + 6)
                    p.drawText(int(x) - 12, rect.bottom() + 18, f"{pct}")
                    p.setPen(grid_pen)
                p.setPen(QPen(QColor(160, 178, 210)))
                p.drawText(rect.center().x() - 40, rect.bottom() + 32, self._axis_label)
            else:
                p.setPen(QPen(QColor(160, 178, 210)))
                p.drawText(rect.center().x() - 55, rect.bottom() + 32, "Outcome tier (ordinal)")
            if clamp_note:
                note = f"Showing ±{visible_radius} bp around cut (full window ±{radius} bp)."
                p.setPen(QPen(QColor(156, 178, 212)))
                p.drawText(rect.left(), rect.top() - 6, note)

            p.save()

            # Bars
            for bar in filtered:
                y = rect.bottom() - (bar.peak_pos - min_y) / span_y * rect.height()
                x0 = rect.left()
                prob_val = self._display_values.get(bar.label, bar.probability)
                x1 = rect.left() + min(1.0, prob_val) * rect.width()
                if self._run_kind == "prime":
                    cls = _classify_prime_outcome(bar)
                    if cls == PrimeOutcomeClass.DESIRED:
                        color = PRIME_COLORS["desired"]
                    elif cls == PrimeOutcomeClass.BYPRODUCT:
                        color = PRIME_COLORS["byproduct"]
                    elif cls == PrimeOutcomeClass.INDEL:
                        color = PRIME_COLORS["indel"]
                    else:
                        color = PRIME_COLORS["no_cut"]
                else:
                    color = _chart_color_for_bar(bar)
                color = self._thermo_color(color, bar)
                if exploratory and not color_ack:
                    color = _exploratory_desaturate(color)
                self._last_painted_colors[str(bar.label)] = QColor(color)
                hovered = self._hovered == bar.label or self._external_highlight == bar.label
                selected = self._selected == bar.label

                is_primary = primary_label is not None and bar.label == primary_label
                bar_h = self._bar_height_px(bar, is_primary=is_primary, summary_mode=summary_mode)

                alpha = _BAR_ALPHA_PRIMARY if is_primary else (_BAR_ALPHA_MUTED if summary_mode else _BAR_ALPHA_INSPECT)
                if hovered or selected:
                    alpha = min(1.0, float(alpha) + 0.10)
                alpha = self._alpha_for_bar(bar, float(alpha))
                fill = QColor(color)
                fill.setAlphaF(float(alpha))

                bar_rect = QRect(int(x0), int(y - bar_h * 0.5), int(max(0.0, x1 - x0)), int(bar_h))
                p.fillRect(bar_rect, fill)

                border = QColor(color)
                border.setAlphaF(min(1.0, float(alpha) + 0.12))
                pen = QPen(border.darker(120))
                pen.setWidthF(2.0 if is_primary else (1.4 if selected else (1.2 if hovered else 1.0)))
                p.setPen(pen)
                p.drawRect(bar_rect)

                # Crisp focus outline in Inspect (no glow).
                if (not summary_mode) and selected:
                    focus = QColor(color)
                    focus = focus.lighter(175) if _srgb_luma(fill) < 0.6 else focus.darker(155)
                    focus.setAlphaF(min(1.0, float(alpha) + 0.35))
                    focus_pen = QPen(focus)
                    focus_pen.setWidthF(2.4)
                    p.setPen(focus_pen)
                    p.setBrush(Qt.NoBrush)
                    p.drawRect(bar_rect.adjusted(-1, -1, 1, 1))

                # Embed a single label inside the bar (primary in Summary; selected in Inspect).
                if (summary_mode and is_primary) or ((not summary_mode) and selected):
                    inner = bar_rect.adjusted(8, 0, -8, 0)
                    label = _label_for_outcome(bar.label)
                    if exploratory and not color_ack:
                        label = f"{label} (non-calibrated)"
                    value_txt = ""
                    if exploratory:
                        rank = int(self._rank_by_label.get(str(bar.label), 0) or 0)
                        value_txt = tier_for_rank(rank or 10**9).label
                    else:
                        value_txt = f"{prob_val*100:.1f}%"
                    font = QFont("Inter", 9)
                    font.setBold(True)
                    p.setFont(font)
                    metrics = QFontMetrics(font)
                    text_col = QColor(245, 248, 255, 235)
                    if _srgb_luma(fill) > 0.72:
                        text_col = QColor(8, 10, 18, 235)
                    p.setPen(QPen(text_col))
                    if inner.width() >= 70:
                        val_w = metrics.horizontalAdvance(value_txt)
                        label_w = max(0, int(inner.width()) - int(val_w) - 10)
                        label_fit = metrics.elidedText(label, Qt.ElideRight, label_w) if label_w > 10 else ""
                        text = f"{label_fit}  {value_txt}" if label_fit else value_txt
                        p.drawText(inner, Qt.AlignLeft | Qt.AlignVCenter, text)
                    else:
                        x = min(rect.right() - 8 - 180, bar_rect.right() + 8)
                        x = max(rect.left() + 8, int(x))
                        y_txt = int(bar_rect.center().y() - 9)
                        label_w = 180 - int(metrics.horizontalAdvance(value_txt)) - 10
                        label_fit = metrics.elidedText(label, Qt.ElideRight, label_w) if label_w > 10 else ""
                        text = f"{label_fit}  {value_txt}" if label_fit else value_txt
                        p.drawText(QRect(x, y_txt, 180, 18), Qt.AlignLeft | Qt.AlignVCenter, text)

            p.restore()

            if exploratory and not rect.isEmpty():
                self._watermark_visible = True
                p.save()
                wm_alpha = 24 if color_ack else 46
                wm = QColor(255, 255, 255, wm_alpha)
                p.setPen(QPen(wm))
                font = QFont("Inter")
                font.setBold(True)
                font.setPixelSize(max(30, int(min(rect.width(), rect.height()) * 0.26)))
                p.setFont(font)
                p.translate(rect.center())
                p.rotate(-18)
                w_box = rect.width() * 4
                h_box = rect.height() * 4
                p.drawText(QRect(-w_box // 2, -h_box // 2, w_box, h_box), Qt.AlignCenter, "DEMO (NON-CALIBRATED)")
                p.restore()

            # Cut anchor must stay visible (never occluded by bars).
            baseline_h = QColor(axis_color)
            baseline_h.setAlpha(min(int(baseline_h.alpha()), 90))
            baseline_pen = QPen(baseline_h)
            baseline_pen.setWidthF(1.0)
            p.setPen(baseline_pen)
            p.drawLine(rect.left(), int(cut_y), rect.right(), int(cut_y))

            cut_pen = QPen(QColor(_CUT_COLOR.red(), _CUT_COLOR.green(), _CUT_COLOR.blue(), int(_CUT_LINE_ALPHA)))
            cut_pen.setWidthF(float(_CUT_LINE_WIDTH))
            p.setPen(cut_pen)
            p.drawLine(rect.left(), int(cut_y), rect.right(), int(cut_y))
            p.setPen(QPen(QColor(_CUT_COLOR.red(), _CUT_COLOR.green(), _CUT_COLOR.blue(), int(_CUT_LINE_ALPHA))))
            axis_font_size = 10
            if rect.height() < 260:
                axis_font_size = 9
            if rect.height() < 220:
                axis_font_size = 8
            p.setFont(QFont("Inter", axis_font_size))
            p.drawText(rect.left() + 4, int(cut_y) - 6, "Cut site (0 bp)")
        finally:
            p.end()

    def mousePressEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        pos = event.position().toPoint()
        rect = self.rect().adjusted(70, 24, -32, -36)
        if not rect.contains(pos):
            return
        if self._animating:
            return
        # Pick bar by y distance
        filtered = self._filtered_bars()
        if not filtered:
            return
        min_y = min(self._positions) if self._positions else -20
        max_y = max(self._positions) if self._positions else 20
        span_y = max(1.0, float(max_y - min_y))
        target_pos = (rect.bottom() - pos.y()) / rect.height() * span_y + min_y
        closest = None
        dist_best = 1e9
        for bar in filtered:
            dy = abs(bar.peak_pos - target_pos)
            if dy < dist_best:
                dist_best = dy
                closest = bar
        if closest:
            self._selected = closest.label
            self.barSelected.emit(closest.label)
            self.outcomeSelected.emit(closest.label)
            self.update()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        pos = event.position().toPoint()
        rect = self.rect().adjusted(70, 24, -32, -36)
        filtered = self._filtered_bars()
        if not rect.contains(pos) or not filtered:
            if self._hovered is not None:
                self._hovered = None
                self.outcomeHovered.emit(None)
                QToolTip.hideText()
                self._tip_label = None
                self.update()
            return

        summary_mode = not bool(getattr(self, "_inspect_mode", False))
        primary_label: str | None = None
        if filtered:
            intended = [b for b in filtered if bool(getattr(b, "intended", False))]
            primary_bar = (
                max(intended, key=lambda b: float(b.probability), default=None)
                if intended
                else max(filtered, key=lambda b: float(b.probability), default=None)
            )
            primary_label = primary_bar.label if primary_bar is not None else None

        if self._positions:
            min_y_raw = min(self._positions)
            max_y_raw = max(self._positions)
        else:
            min_y_raw, max_y_raw = -20, 20
        radius = max(abs(min_y_raw), abs(max_y_raw))
        if radius < 2:
            radius = 2
        visible_radius = min(radius, 100)
        min_y = -visible_radius
        max_y = visible_radius
        span_y = max(1.0, float(max_y - min_y))

        hit_pad = 3.0
        closest: OutcomeBar | None = None
        dist_best = 1e9
        for bar in filtered:
            y = rect.bottom() - (bar.peak_pos - min_y) / span_y * rect.height()
            x0 = rect.left()
            prob_val = self._display_values.get(bar.label, bar.probability)
            x1 = rect.left() + min(1.0, prob_val) * rect.width()
            is_primary = primary_label is not None and bar.label == primary_label
            bar_h = self._bar_height_px(bar, is_primary=is_primary, summary_mode=summary_mode)
            bar_rect = QRectF(float(x0), float(y - bar_h * 0.5), float(max(0.0, x1 - x0)), float(bar_h)).adjusted(
                -hit_pad, -hit_pad, hit_pad, hit_pad
            )
            if not bar_rect.contains(pos):
                continue
            dx = abs(pos.x() - bar_rect.center().x())
            dy = abs(pos.y() - bar_rect.center().y())
            dist = dx + dy
            if dist < dist_best:
                dist_best = dist
                closest = bar
        new_hover = closest.label if closest else None
        if new_hover != self._hovered:
            self._hovered = new_hover
            self.outcomeHovered.emit(new_hover)
            if closest is not None:
                y = rect.bottom() - (closest.peak_pos - min_y) / span_y * rect.height()
                x1 = rect.left() + min(1.0, self._display_values.get(closest.label, closest.probability)) * rect.width()
                anchor = QPoint(int(x1) + 12, int(y))
                self._show_hover_tooltip(closest, anchor)
            else:
                QToolTip.hideText()
                self._tip_label = None
            self.update()

    def leaveEvent(self, event):  # type: ignore[override]
        if self._hovered is not None:
            self._hovered = None
            self.outcomeHovered.emit(None)
            QToolTip.hideText()
            self._tip_label = None
            self.update()
        super().leaveEvent(event)

    def setHighlighted(self, outcome_id: str | None) -> None:
        self._external_highlight = outcome_id
        self.update()

    def setSelected(self, outcome_id: str | None) -> None:
        self._selected = outcome_id
        self.update()


class OutcomeProbabilityChartWidget(QFrame):
    barSelected = Signal(str)
    outcomeSelected = Signal(str)
    outcomeHovered = Signal(object)
    exploratoryAckRequested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFont(base_font())
        self._bars: list[OutcomeBar] = []
        self._value_mode = "score"
        self._selected: str | None = None
        self._hovered: str | None = None
        self._min_prob = 0.0
        self._category_filter = "all"
        self._pathway_filter = "all"
        self._lens = "all"
        self._run_kind = ""
        self._external_highlight: str | None = None
        self._display_values: dict[str, float] = {}
        self._anim_start: dict[str, float] = {}
        self._anim_target: dict[str, float] = {}
        self._anim_elapsed_ms = 0
        self._anim_duration_ms = 180
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(16)
        self._anim_timer.timeout.connect(self._tick_animation)
        self._animating = False
        self._anim_progress = 1.0  # 0..1 fade/length animation factor
        self._tip_label: str | None = None
        self._overlay_values: dict[str, float] | None = None
        self._inspect_mode = False
        self._exploratory_mode = False
        self._exploratory_color_ack = False
        self._rank_by_label: dict[str, int] = {}
        self._last_painted_colors: dict[str, QColor] = {}
        self._watermark_visible = False
        self.setMouseTracking(True)
        self.setFrameShape(QFrame.NoFrame)
        # Same rationale as OutcomeChartWidget: let the rest of the UI breathe on
        # short viewports.
        self.setMinimumHeight(90)
        self._lane_offsets: dict[str, float] = {}
        self._lane_threshold = 14  # start lane-packing when many ribbons
        # Extra lane spacing makes dense outcome sets easier to visually parse.
        self._lane_spacing_px = 12.0

        self._ack_btn = QToolButton(self)
        self._ack_btn.setObjectName("ExploratoryAckButton")
        self._ack_btn.setText("Enable color")
        self._ack_btn.setToolTip("Enable saturated category colors (exploratory mode only).")
        self._ack_btn.setCursor(Qt.PointingHandCursor)
        self._ack_btn.setFocusPolicy(Qt.TabFocus)
        self._ack_btn.setVisible(False)
        self._ack_btn.clicked.connect(self.exploratoryAckRequested.emit)
        self._ack_btn.setStyleSheet(_exploratory_ack_button_qss(self._ack_btn))
        self._update_accessibility()

    def sizeHint(self) -> QSize:  # type: ignore[override]
        return QSize(800, 320)

    def set_run_kind(self, kind: str | None) -> None:
        self._run_kind = (kind or "").lower()
        self.update()

    def set_value_mode(self, mode: str) -> None:
        mode = "probability" if str(mode) == "probability" else "score"
        if mode == self._value_mode:
            return
        self._value_mode = mode
        self.update()

    def set_inspect_mode(self, enabled: bool) -> None:
        self._inspect_mode = bool(enabled)
        self.update()

    def set_exploratory_mode(self, enabled: bool, *, color_acknowledged: bool) -> None:
        enabled = bool(enabled)
        ack = bool(color_acknowledged)
        if enabled == self._exploratory_mode and ack == self._exploratory_color_ack:
            return
        self._exploratory_mode = enabled
        self._exploratory_color_ack = ack
        try:
            self._ack_btn.setVisible(enabled and (not ack))
        except Exception:
            pass
        self._position_ack_btn()
        self._update_accessibility()
        try:
            self._start_animation(list(getattr(self, "_bars", []) or []))
        except Exception:
            pass
        self.update()

    def _update_accessibility(self) -> None:
        try:
            self.setAccessibleName("Outcome distribution (bp offset)")
        except Exception:
            pass
        if self._exploratory_mode:
            if self._exploratory_color_ack:
                desc = "Exploratory mode: non-comparable scores. Colors enabled after acknowledgement."
            else:
                desc = "Exploratory mode: non-comparable scores. Colors muted until acknowledged."
        else:
            desc = "Decision-grade mode: calibrated, comparable probabilities."
        try:
            self.setAccessibleDescription(desc)
        except Exception:
            pass
        try:
            self._ack_btn.setAccessibleName("Enable exploratory colors")
            self._ack_btn.setAccessibleDescription(desc)
        except Exception:
            pass

    def _position_ack_btn(self) -> None:
        try:
            plot = self.rect().adjusted(28, 24, -24, -32)
            btn = self._ack_btn
            if not btn.isVisible():
                return
            hint = btn.sizeHint()
            w = int(hint.width())
            h = int(hint.height())
            x = int(plot.right() - w - 10)
            y = int(plot.top() + 10)
            btn.setGeometry(QRect(max(0, x), max(0, y), w, h))
            btn.raise_()
        except Exception:
            return

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self._position_ack_btn()

    def set_data(self, bars: list[OutcomeBar]) -> None:
        self._bars = bars
        self._rank_by_label = {str(b.label): int(i + 1) for i, b in enumerate(bars or []) if getattr(b, "label", None)}
        self._assign_lanes(bars)
        self._start_animation(bars)
        self.update()

    def set_overlay(self, values: dict[str, float] | None, label: str | None = None) -> None:
        """Set overlay bars; accepts optional label for legend compatibility."""
        self._overlay_values = values
        self._overlay_label = label
        self.update()

    def set_overlay_with_label(self, values: dict[str, float] | None, label: str | None = None) -> None:
        # backwards compatibility alias
        self.set_overlay(values, label)

    def set_lens(self, lens: str) -> None:
        self._lens = lens or "all"
        self.update()

    def _start_animation(self, bars: list[OutcomeBar]) -> None:
        if bool(getattr(self, "_exploratory_mode", False)):
            targets = {
                str(b.label): tier_fill_fraction(tier_for_rank(self._rank_by_label.get(str(b.label), 10**9)))
                for b in (bars or [])
            }
        else:
            targets = {b.label: b.probability for b in bars}
        keys = set(targets) | set(self._display_values.keys())
        if not keys:
            self._display_values = {}
            self._anim_timer.stop()
            self._animating = False
            return
        self._anim_start = {k: self._display_values.get(k, 0.0) for k in keys}
        self._anim_target = {k: targets.get(k, 0.0) for k in keys}
        self._display_values = dict(self._anim_start)
        self._anim_elapsed_ms = 0
        self._animating = True
        self._anim_progress = 0.0
        self._anim_timer.start()

    def _tick_animation(self) -> None:
        self._anim_elapsed_ms += self._anim_timer.interval()
        t = min(1.0, self._anim_elapsed_ms / float(self._anim_duration_ms)) if self._anim_duration_ms else 1.0
        ease = 1.0 - (1.0 - t) * (1.0 - t)
        self._anim_progress = ease
        for key, target in self._anim_target.items():
            start = self._anim_start.get(key, 0.0)
            self._display_values[key] = start + (target - start) * ease
        self.update()
        if t >= 1.0:
            self._anim_timer.stop()
            self._display_values = dict(self._anim_target)
            self._animating = False
            self._anim_progress = 1.0

    def _hover_text(self, bar: OutcomeBar) -> str:
        if bool(getattr(self, "_exploratory_mode", False)):
            why = _why_for_outcome(bar, run_kind=str(self._run_kind or "crispr"))
            rank = int(self._rank_by_label.get(str(bar.label), 0) or 0)
            tier = tier_for_rank(rank or 10**9).label
            parts = [
                f"{bar.label}",
                tier + (f" · rank #{rank}" if rank else ""),
                f"Δbp {bar.delta_bp:+d}",
                f"span {bar.pos_range[0]:+.0f}..{bar.pos_range[1]:+.0f}",
                f"frameshift: {'yes' if bar.frameshift else 'no'}",
                f"calibration {bar.calibration.value}",
            ]
            if getattr(bar, "pathway", None):
                parts.insert(5, f"pathway: {PATHWAY_UI_LABEL.get(str(bar.pathway), str(bar.pathway))}")
            if bar.category == "no_cut":
                parts.append("no cut / no edit")
            if bar.microhomology is not None:
                parts.append(f"microhomology {bar.microhomology} bp (asymmetric repair)")
            if bar.schema_issues:
                parts.append("schema " + ",".join(bar.schema_issues))
            details = "<br/>".join(parts)
            return f"<b>This outcome exists because {why}</b><br/>{details}"

        label = _value_label_lower(self._value_mode)
        why = _why_for_outcome(bar, run_kind=str(self._run_kind or "crispr"))
        parts = [
            f"{bar.label}",
            f"{label} {bar.probability*100:.1f}%",
            f"Δbp {bar.delta_bp:+d}",
            f"span {bar.pos_range[0]:+.0f}..{bar.pos_range[1]:+.0f}",
            f"frameshift: {'yes' if bar.frameshift else 'no'}",
        ]
        if getattr(bar, "pathway", None):
            parts.append(f"pathway: {PATHWAY_UI_LABEL.get(str(bar.pathway), str(bar.pathway))}")
        if bar.category == "no_cut":
            parts.append("no cut / no edit")
        if bar.microhomology is not None:
            parts.append(f"microhomology {bar.microhomology} bp (asymmetric repair)")
        if bar.energy_margin is not None:
            parts.append(f"ΔG {format_scalar(bar.energy_margin)}")
        if bar.kinetic_rate is not None:
            parts.append(f"kinetic {format_scalar(bar.kinetic_rate)}")
        parts.append(f"calibration {bar.calibration.value}")
        if bar.schema_issues:
            parts.append("schema " + ",".join(bar.schema_issues))
        details = "<br/>".join(parts)
        return f"<b>This outcome exists because {why}</b><br/>{details}"

    def _show_hover_tooltip(self, bar: OutcomeBar, anchor: QPoint) -> None:
        text = self._hover_text(bar)
        if text != self._tip_label:
            QToolTip.showText(self.mapToGlobal(anchor), text, self)
            self._tip_label = text

    def set_filters(self, min_prob: float, category: str, pathway: str = "all") -> None:
        self._min_prob = max(0.0, min(1.0, min_prob))
        self._category_filter = category
        self._pathway_filter = str(pathway or "all").strip().lower() or "all"
        self.update()

    def _filtered(self) -> list[OutcomeBar]:
        filtered = [b for b in self._bars if b.probability >= self._min_prob]
        if self._category_filter == "insertions":
            filtered = [b for b in filtered if "insertion" in b.category]
        elif self._category_filter == "deletions":
            filtered = [b for b in filtered if "deletion" in b.category]
        elif self._category_filter == "no_cut":
            filtered = [b for b in filtered if b.category == "no_cut"]
        elif self._category_filter == "frameshift":
            filtered = [b for b in filtered if b.frameshift]
        elif self._category_filter.startswith("pe:"):
            # prime lenses only apply to prime runs
            def _keep(bar: OutcomeBar) -> bool:
                if (bar.run_kind or "").lower() != "prime":
                    return False
                cls = _classify_prime_outcome(bar)
                if self._category_filter == "pe:desired":
                    return cls == PrimeOutcomeClass.DESIRED
                if self._category_filter == "pe:byproduct":
                    return cls == PrimeOutcomeClass.BYPRODUCT
                if self._category_filter == "pe:indel":
                    return cls == PrimeOutcomeClass.INDEL
                return True

            filtered = [b for b in filtered if _keep(b)]
        if self._pathway_filter != "all":
            filtered = [
                b
                for b in filtered
                if str(getattr(b, "pathway", None) or "").strip().lower() == self._pathway_filter
            ]
        # Lens filter
        def _matches_lens(bar: OutcomeBar, lens: str) -> bool:
            if lens == "all":
                return True
            if lens == "frameshift":
                return bar.frameshift
            if lens == "in_frame":
                return not bar.frameshift
            if lens == "intendedish":
                try:
                    return abs(bar.delta_bp) <= 1 or "intended" in bar.category.lower()
                except Exception:
                    return False
            if lens == "large_del":
                try:
                    return bar.delta_bp <= -5
                except Exception:
                    return False
            if lens.startswith("pe:"):
                if (bar.run_kind or "").lower() != "prime":
                    return False
                cls = _classify_prime_outcome(bar)
            if lens == "pe:desired":
                return cls == PrimeOutcomeClass.DESIRED
            if lens == "pe:byproduct":
                return cls == PrimeOutcomeClass.BYPRODUCT
            if lens == "pe:indel":
                return cls == PrimeOutcomeClass.INDEL
            return True

        filtered = [b for b in filtered if _matches_lens(b, self._lens)]
        return sorted(filtered, key=lambda b: b.probability, reverse=True)

    def _assign_lanes(self, bars: list[OutcomeBar]) -> None:
        """Assign small vertical offsets to improve legibility when many ribbons."""
        n = len(bars)
        if n <= self._lane_threshold:
            self._lane_offsets = {b.label: 0.0 for b in bars}
            return
        labels = sorted({b.label for b in bars})
        # Generate stable symmetric sequence: 0, -1, +1, -2, +2, ...
        seq: list[int] = [0]
        k = 1
        while len(seq) < len(labels):
            seq.append(-k)
            if len(seq) >= len(labels):
                break
            seq.append(k)
            k += 1
        self._lane_offsets = {
            label: seq[idx] * self._lane_spacing_px for idx, label in enumerate(labels)
        }

    def paintEvent(self, event) -> None:  # type: ignore[override]
        p = QPainter(self)
        try:
            p.setRenderHint(QPainter.Antialiasing, True)
            _draw_elevated_panel(p, self.rect(), radius=8)

            rect = self.rect().adjusted(28, 24, -24, -32)
            filtered = self._filtered()
            inspect_mode = bool(getattr(self, "_inspect_mode", False))
            summary_mode = not inspect_mode
            exploratory = bool(getattr(self, "_exploratory_mode", False))
            color_ack = bool(getattr(self, "_exploratory_color_ack", False))
            self._watermark_visible = False
            self._last_painted_colors = {}

            primary_label: str | None = None
            if filtered:
                # Summary defaults to "top outcome", but if a selection exists we treat it as the current primary.
                sel = self._selected or self._external_highlight
                if sel and any(b.label == str(sel) for b in filtered):
                    primary_label = str(sel)
                else:
                    intended = [b for b in filtered if bool(getattr(b, "intended", False))]
                    primary_bar = max(intended, key=lambda b: float(self._display_values.get(b.label, b.probability)), default=None) if intended else max(
                        filtered, key=lambda b: float(self._display_values.get(b.label, b.probability)), default=None
                    )
                    primary_label = primary_bar.label if primary_bar is not None else None

            if not filtered:
                p.setPen(QPen(QColor(180, 200, 230)))
                p.drawText(rect, Qt.AlignCenter, "No outcomes match filters")
                return

            min_pos = min(min(b.pos_range) for b in filtered)
            max_pos = max(max(b.pos_range) for b in filtered)
            span_full = max(abs(min_pos), abs(max_pos), 1.0)
            span = span_full
            if summary_mode:
                # Keep the Summary view verdict-like: stable scale, centered on cut, no "long bar implies genomic span".
                span = max(_SUMMARY_CANONICAL_SPAN_BP * 1.5, min(span_full, _SUMMARY_AXIS_MAX_BP))
            usable_half = max(20.0, rect.width() * 0.5 - 16.0)
            scale = usable_half / span
            cut_x = rect.center().x()
            rail_y = rect.center().y()

            # Direction + ruler
            tick_span = max(5, int(span))
            ticks = _choose_position_ticks(tick_span)
            p.setPen(QPen(QColor(255, 255, 255, 14)))
            for t in ticks:
                x = rect.center().x() + t * (usable_half) / span
                p.drawLine(int(x), rect.top(), int(x), rect.bottom())
                if t != 0:
                    p.drawText(int(x) - 10, rect.bottom() + 14, f"{t:+d}")
            p.setPen(QPen(QColor(156, 178, 212, 160)))
            p.drawText(rect.left(), rect.top() - 6, "Upstream (-bp)")
            p.drawText(rect.right() - 110, rect.top() - 6, "Downstream (+bp)")
            p.setPen(QPen(QColor(156, 178, 212, 150)))
            p.drawText(rect.center().x() - 58, rect.bottom() + 26, "bp offset (schematic)")
            if summary_mode:
                p.setPen(QPen(QColor(156, 178, 212, 135)))
                hint = "Showing dominant outcome. Enable Inspect to explore alternatives."
                p.drawText(rect.adjusted(0, 0, -6, -8), Qt.AlignRight | Qt.AlignBottom, hint)

            # Baseline rail + cut marker
            axis_pen = QPen(QColor(108, 126, 158, 180))
            axis_pen.setWidthF(1.2)
            p.setPen(axis_pen)
            p.drawLine(rect.left(), int(rail_y), rect.right(), int(rail_y))
            band_w = 12
            band = QRect(int(cut_x - band_w * 0.5), rect.top(), band_w, rect.height())
            band_color = QColor(_CUT_COLOR)
            band_color.setAlpha(int(_CUT_BAND_ALPHA))
            p.fillRect(band, band_color)

            # No-cut (and other outcomes) are communicated by the ribbons themselves; avoid glow/halos.

            max_prob = max((float(self._display_values.get(b.label, b.probability)) for b in filtered), default=1.0) or 1.0

            def _geom(bar: OutcomeBar) -> QRectF:
                is_primary = primary_label is not None and bar.label == primary_label
                if summary_mode and is_primary:
                    start, end = (-_SUMMARY_CANONICAL_SPAN_BP, _SUMMARY_CANONICAL_SPAN_BP)
                else:
                    start, end = bar.pos_range
                if start == end:
                    end = start + (0.2 if start >= 0 else -0.2)
                x0 = cut_x + float(start) * scale
                x1 = cut_x + float(end) * scale
                width = max(6.0, abs(x1 - x0))
                prob_val = float(self._display_values.get(bar.label, bar.probability))
                if summary_mode and is_primary:
                    # Let probability modulate thickness a bit so confidence reads without numbers.
                    p01 = max(0.0, min(1.0, prob_val))
                    thickness = 14.0 * (1.0 + 0.6 * p01)
                    thickness = max(_BAR_THICKNESS_MIN_PX, min(float(_BAR_THICKNESS_MAX_PRIMARY_PX), float(thickness)))
                else:
                    norm = math.sqrt(max(0.0, prob_val) / float(max_prob)) if max_prob > 1e-9 else 0.0
                    thickness = _BAR_THICKNESS_MIN_PX + norm * (_BAR_THICKNESS_MAX_PX - _BAR_THICKNESS_MIN_PX)
                lane_offset = self._lane_offsets.get(bar.label, 0.0)
                return QRectF(min(x0, x1), rail_y + lane_offset - thickness * 0.5, width, thickness)

            # Draw muted context first, then the primary on top for clarity.
            if summary_mode and primary_label is not None:
                ordered = [b for b in filtered if b.label == primary_label]
            else:
                ordered = [b for b in filtered if primary_label is None or b.label != primary_label]
                if primary_label is not None:
                    ordered += [b for b in filtered if b.label == primary_label]

            for bar in ordered:
                geom = _geom(bar)
                if (bar.run_kind or "").lower() == "prime":
                    cls = _classify_prime_outcome(bar)
                    if cls == PrimeOutcomeClass.DESIRED:
                        base_color = PRIME_COLORS["desired"]
                    elif cls == PrimeOutcomeClass.BYPRODUCT:
                        base_color = PRIME_COLORS["byproduct"]
                    elif cls == PrimeOutcomeClass.INDEL:
                        base_color = PRIME_COLORS["indel"]
                    else:
                        base_color = PRIME_COLORS["no_cut"]
                else:
                    base_color = _chart_color_for_bar(bar)
                if exploratory and not color_ack:
                    base_color = _exploratory_desaturate(base_color)
                self._last_painted_colors[str(bar.label)] = QColor(base_color)
                hovered = self._hovered == bar.label or self._external_highlight == bar.label
                selected = self._selected == bar.label
                is_primary = primary_label is not None and bar.label == primary_label

                alpha = _BAR_ALPHA_INSPECT if inspect_mode else (_BAR_ALPHA_PRIMARY if is_primary else _BAR_ALPHA_MUTED)
                if inspect_mode and (hovered or selected):
                    alpha = min(1.0, float(alpha) + 0.10)
                if not inspect_mode and not is_primary and (hovered or selected):
                    alpha = min(1.0, float(alpha) + 0.06)

                fill = QColor(base_color)
                fill.setAlphaF(float(alpha) * float(self._anim_progress))
                p.setPen(Qt.NoPen)
                p.setBrush(fill)
                p.drawRect(geom)

                border = QColor(base_color).darker(125)
                border.setAlphaF(min(1.0, float(alpha) + 0.12))
                pen = QPen(border)
                pen.setWidthF(2.0 if is_primary else (1.6 if selected else 1.0))
                p.setPen(pen)
                p.setBrush(Qt.NoBrush)
                p.drawRect(geom)

                # Crisp focus outline in Inspect (no glow).
                if inspect_mode and selected:
                    focus = QColor(base_color)
                    focus = focus.lighter(175) if _srgb_luma(fill) < 0.6 else focus.darker(155)
                    focus.setAlphaF(min(1.0, float(alpha) + 0.35))
                    focus_pen = QPen(focus)
                    focus_pen.setWidthF(2.6)
                    p.setPen(focus_pen)
                    p.setBrush(Qt.NoBrush)
                    p.drawRect(geom.adjusted(-0.8, -0.8, 0.8, 0.8))

                if self._overlay_values and bar.label in self._overlay_values:
                    base_prob = float(self._overlay_values.get(bar.label, 0.0))
                    norm = math.sqrt(max(0.0, base_prob) / float(max_prob)) if max_prob > 1e-9 else 0.0
                    overlay_thickness = _BAR_THICKNESS_MIN_PX + norm * (_BAR_THICKNESS_MAX_PX - _BAR_THICKNESS_MIN_PX)
                    overlay_rect = QRectF(
                        geom.center().x() - geom.width() * 0.5,
                        geom.center().y() - overlay_thickness * 0.5,
                        geom.width(),
                        overlay_thickness,
                    )
                    pen = QPen(QColor(200, 210, 230, 150))
                    pen.setStyle(Qt.DashLine)
                    pen.setWidthF(1.4)
                    p.setPen(pen)
                    p.setBrush(Qt.NoBrush)
                    p.drawRect(overlay_rect)

            # Label chips (Inspect): make outcomes identifiable without click/tooltip.
            # Draw after ribbons so text never gets occluded by later bars.
            label_height = 18
            if inspect_mode and len(filtered) <= 24:
                label_budget = len(filtered)
            else:
                label_budget = max(4, min(18, int(rect.height() / float(label_height + 6))))
            label_order = _choose_outcome_ribbon_labels(
                filtered,
                display_values=self._display_values,
                max_labels=label_budget,
                inspect_mode=inspect_mode,
                selected_label=self._selected,
                hovered_label=self._hovered,
                highlighted_label=self._external_highlight,
                primary_label=primary_label,
            )
            if label_order:
                p.save()
                font = QFont("Inter", 9)
                font.setBold(True)
                p.setFont(font)
                metrics = QFontMetrics(font)
                bar_by_label = {str(b.label): b for b in (filtered or []) if getattr(b, "label", None) is not None}
                placed: list[QRect] = []
                pinned = {
                    str(v)
                    for v in (self._selected, self._hovered, self._external_highlight, primary_label)
                    if v is not None
                }

                def _collides(candidate: QRect) -> bool:
                    cand = candidate.adjusted(-2, -2, 2, 2)
                    return any(cand.intersects(prev) for prev in placed)

                def _place_chip(anchor: QRectF, w: int, h: int, *, prefer_inside: bool) -> QRect | None:
                    y0 = int(anchor.center().y() - h * 0.5)
                    y0 = max(rect.top() + 2, min(y0, rect.bottom() - h - 2))
                    x_candidates: list[float] = []
                    if prefer_inside and anchor.width() >= float(w + 10):
                        x_candidates.append(anchor.right() - w - 6)
                        x_candidates.append(anchor.left() + 6)
                    x_candidates.append(anchor.right() + 8)
                    x_candidates.append(anchor.left() - w - 8)
                    x_candidates.append(anchor.center().x() - w * 0.5)
                    y_candidates = [y0, y0 - (h + 4), y0 + (h + 4)]
                    for y in y_candidates:
                        y = max(rect.top() + 2, min(int(y), rect.bottom() - h - 2))
                        for x in x_candidates:
                            x = max(rect.left() + 2, min(int(x), rect.right() - w - 2))
                            cand = QRect(int(x), int(y), int(w), int(h))
                            if cand.isEmpty():
                                continue
                            if not _collides(cand):
                                return cand
                    return None

                for lab in label_order:
                    bar = bar_by_label.get(str(lab))
                    if bar is None:
                        continue
                    geom = _geom(bar)
                    accent = QColor(self._last_painted_colors.get(str(bar.label), QColor(180, 200, 230)))
                    prob_val = float(self._display_values.get(bar.label, bar.probability))
                    value_txt = ""
                    if exploratory:
                        rank = int(self._rank_by_label.get(str(bar.label), 0) or 0)
                        value_txt = tier_for_rank(rank or 10**9).label
                    else:
                        value_txt = f"{prob_val*100:.1f}%"

                    label = _label_for_outcome(str(bar.label))
                    max_text_w = 190
                    val_w = metrics.horizontalAdvance(value_txt) if value_txt else 0
                    label_w = max(40, int(max_text_w) - int(val_w) - 10) if value_txt else int(max_text_w)
                    label_fit = metrics.elidedText(label, Qt.ElideRight, label_w)
                    text = f"{label_fit}  {value_txt}" if value_txt else label_fit
                    text_w = metrics.horizontalAdvance(text)
                    pad_left = 22  # room for accent dot
                    pad_right = 10
                    chip_w = int(min(240, max(64, text_w + pad_left + pad_right)))
                    chip_h = int(label_height)

                    is_pinned = str(lab) in pinned
                    chip = _place_chip(geom, chip_w, chip_h, prefer_inside=True)
                    if chip is None:
                        if not is_pinned:
                            continue
                        # Pinned labels are worth showing even if they overlap.
                        chip = QRect(
                            int(max(rect.left() + 2, min(int(geom.right() + 8), rect.right() - chip_w - 2))),
                            int(max(rect.top() + 2, min(int(geom.center().y() - chip_h * 0.5), rect.bottom() - chip_h - 2))),
                            chip_w,
                            chip_h,
                        )

                    placed.append(chip)

                    bg = QColor(20, 24, 34, 220 if is_pinned else 190)
                    shadow = QColor(0, 0, 0, 90)
                    border = QColor(accent)
                    border = border.lighter(155) if _srgb_luma(border) < 0.6 else border.darker(130)
                    border.setAlpha(210 if is_pinned else 160)

                    p.setPen(Qt.NoPen)
                    p.setBrush(shadow)
                    p.drawRoundedRect(chip.translated(1, 1), 7, 7)
                    p.setPen(QPen(border))
                    p.setBrush(bg)
                    p.drawRoundedRect(chip, 7, 7)

                    dot = QColor(accent)
                    dot.setAlpha(230)
                    p.setPen(Qt.NoPen)
                    p.setBrush(dot)
                    p.drawEllipse(QRect(chip.left() + 8, chip.center().y() - 3, 6, 6))

                    text_col = QColor(235, 240, 255, 230)
                    p.setPen(QPen(text_col))
                    p.drawText(chip.adjusted(pad_left, 0, -pad_right, 0), Qt.AlignLeft | Qt.AlignVCenter, text)

                p.restore()

            if exploratory and not rect.isEmpty():
                self._watermark_visible = True
                p.save()
                wm_alpha = 24 if color_ack else 46
                wm = QColor(255, 255, 255, wm_alpha)
                p.setPen(QPen(wm))
                font = QFont("Inter")
                font.setBold(True)
                font.setPixelSize(max(30, int(min(rect.width(), rect.height()) * 0.26)))
                p.setFont(font)
                p.translate(rect.center())
                p.rotate(-18)
                w_box = rect.width() * 4
                h_box = rect.height() * 4
                p.drawText(QRect(-w_box // 2, -h_box // 2, w_box, h_box), Qt.AlignCenter, "DEMO (NON-CALIBRATED)")
                p.restore()

            # Cut anchor must stay visible (never occluded by ribbons).
            baseline_v = QColor(axis_pen.color())
            baseline_v.setAlpha(min(int(baseline_v.alpha()), 90))
            baseline_pen = QPen(baseline_v)
            baseline_pen.setWidthF(1.0)
            p.setPen(baseline_pen)
            p.drawLine(int(cut_x), rect.top(), int(cut_x), rect.bottom())

            cut_pen = QPen(QColor(_CUT_COLOR.red(), _CUT_COLOR.green(), _CUT_COLOR.blue(), int(_CUT_LINE_ALPHA)))
            cut_pen.setWidthF(float(_CUT_LINE_WIDTH))
            p.setPen(cut_pen)
            p.drawLine(int(cut_x), rect.top(), int(cut_x), rect.bottom())
            p.setPen(QPen(QColor(_CUT_COLOR.red(), _CUT_COLOR.green(), _CUT_COLOR.blue(), int(_CUT_LINE_ALPHA))))
            p.setFont(QFont("Inter", 10))
            p.drawText(int(cut_x) - 46, rect.top() - 6, "Cut site (0 bp)")

            if self._run_kind == "prime":
                self._draw_prime_legend(p)
        finally:
            p.end()

    def mousePressEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        pos = event.position().toPoint()
        rect = self.rect().adjusted(28, 24, -24, -32)
        filtered = self._filtered()
        inspect_mode = bool(getattr(self, "_inspect_mode", False))
        summary_mode = not inspect_mode
        if not rect.contains(pos) or not filtered or self._animating:
            return

        primary_label: str | None = None
        if filtered:
            sel = self._selected or self._external_highlight
            if sel and any(b.label == str(sel) for b in filtered):
                primary_label = str(sel)
            else:
                intended = [b for b in filtered if bool(getattr(b, "intended", False))]
                primary_bar = (
                    max(intended, key=lambda b: float(self._display_values.get(b.label, b.probability)), default=None)
                    if intended
                    else max(filtered, key=lambda b: float(self._display_values.get(b.label, b.probability)), default=None)
                )
                primary_label = primary_bar.label if primary_bar is not None else None

        bars = filtered
        if summary_mode and primary_label is not None:
            bars = [b for b in filtered if b.label == primary_label]
            if not bars:
                return

        min_pos = min(min(b.pos_range) for b in bars)
        max_pos = max(max(b.pos_range) for b in bars)
        span_full = max(abs(min_pos), abs(max_pos), 1.0)
        span = span_full
        if summary_mode:
            span = max(_SUMMARY_CANONICAL_SPAN_BP * 1.5, min(span_full, _SUMMARY_AXIS_MAX_BP))
        scale = (max(20.0, rect.width() * 0.5 - 16.0)) / span
        cut_x = rect.center().x()
        rail_y = rect.center().y()
        max_prob = max((float(self._display_values.get(b.label, b.probability)) for b in bars), default=1.0) or 1.0

        def _geom(bar: OutcomeBar) -> QRectF:
            is_primary = primary_label is not None and bar.label == primary_label
            if summary_mode and is_primary:
                start, end = (-_SUMMARY_CANONICAL_SPAN_BP, _SUMMARY_CANONICAL_SPAN_BP)
            else:
                start, end = bar.pos_range
            if start == end:
                end = start + (0.2 if start >= 0 else -0.2)
            x0 = cut_x + float(start) * scale
            x1 = cut_x + float(end) * scale
            width = max(6.0, abs(x1 - x0))
            prob_val = float(self._display_values.get(bar.label, bar.probability))
            if summary_mode and is_primary:
                p01 = max(0.0, min(1.0, prob_val))
                thickness = 14.0 * (1.0 + 0.6 * p01)
                thickness = max(_BAR_THICKNESS_MIN_PX, min(float(_BAR_THICKNESS_MAX_PRIMARY_PX), float(thickness)))
            else:
                norm = math.sqrt(max(0.0, prob_val) / float(max_prob)) if max_prob > 1e-9 else 0.0
                thickness = _BAR_THICKNESS_MIN_PX + norm * (_BAR_THICKNESS_MAX_PX - _BAR_THICKNESS_MIN_PX)
            lane_offset = self._lane_offsets.get(bar.label, 0.0)
            return QRectF(min(x0, x1), rail_y + lane_offset - thickness * 0.5, width, thickness)

        best = None
        best_dist = 1e9
        for bar in bars:
            g = _geom(bar)
            dx = abs(pos.x() - g.center().x())
            dy = abs(pos.y() - g.center().y())
            dist = dx + dy
            if g.contains(pos):
                dist *= 0.2
            if dist < best_dist:
                best_dist = dist
                best = bar
        if best:
            self._selected = best.label
            self.barSelected.emit(best.label)
            self.outcomeSelected.emit(best.label)
            self.update()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        pos = event.position().toPoint()
        rect = self.rect().adjusted(28, 24, -24, -32)
        filtered = self._filtered()
        inspect_mode = bool(getattr(self, "_inspect_mode", False))
        summary_mode = not inspect_mode
        if not rect.contains(pos) or not filtered:
            if self._hovered is not None:
                self._hovered = None
                self.outcomeHovered.emit(None)
                QToolTip.hideText()
                self._tip_label = None
                self.update()
            return

        primary_label: str | None = None
        if filtered:
            sel = self._selected or self._external_highlight
            if sel and any(b.label == str(sel) for b in filtered):
                primary_label = str(sel)
            else:
                intended = [b for b in filtered if bool(getattr(b, "intended", False))]
                primary_bar = (
                    max(intended, key=lambda b: float(self._display_values.get(b.label, b.probability)), default=None)
                    if intended
                    else max(filtered, key=lambda b: float(self._display_values.get(b.label, b.probability)), default=None)
                )
                primary_label = primary_bar.label if primary_bar is not None else None

        bars = filtered
        if summary_mode and primary_label is not None:
            bars = [b for b in filtered if b.label == primary_label]
            if not bars:
                return

        min_pos = min(min(b.pos_range) for b in bars)
        max_pos = max(max(b.pos_range) for b in bars)
        span_full = max(abs(min_pos), abs(max_pos), 1.0)
        span = span_full
        if summary_mode:
            span = max(_SUMMARY_CANONICAL_SPAN_BP * 1.5, min(span_full, _SUMMARY_AXIS_MAX_BP))
        scale = (max(20.0, rect.width() * 0.5 - 16.0)) / span
        cut_x = rect.center().x()
        rail_y = rect.center().y()
        max_prob = max((float(self._display_values.get(b.label, b.probability)) for b in bars), default=1.0) or 1.0

        def _geom(bar: OutcomeBar) -> QRectF:
            is_primary = primary_label is not None and bar.label == primary_label
            if summary_mode and is_primary:
                start, end = (-_SUMMARY_CANONICAL_SPAN_BP, _SUMMARY_CANONICAL_SPAN_BP)
            else:
                start, end = bar.pos_range
            if start == end:
                end = start + (0.2 if start >= 0 else -0.2)
            x0 = cut_x + float(start) * scale
            x1 = cut_x + float(end) * scale
            width = max(6.0, abs(x1 - x0))
            prob_val = float(self._display_values.get(bar.label, bar.probability))
            if summary_mode and is_primary:
                p01 = max(0.0, min(1.0, prob_val))
                thickness = 14.0 * (1.0 + 0.6 * p01)
                thickness = max(_BAR_THICKNESS_MIN_PX, min(float(_BAR_THICKNESS_MAX_PRIMARY_PX), float(thickness)))
            else:
                norm = math.sqrt(max(0.0, prob_val) / float(max_prob)) if max_prob > 1e-9 else 0.0
                thickness = _BAR_THICKNESS_MIN_PX + norm * (_BAR_THICKNESS_MAX_PX - _BAR_THICKNESS_MIN_PX)
            lane_offset = self._lane_offsets.get(bar.label, 0.0)
            return QRectF(min(x0, x1), rail_y + lane_offset - thickness * 0.5, width, thickness)

        hit_pad = 3.0
        closest: OutcomeBar | None = None
        dist_best = 1e9
        for bar in bars:
            g = _geom(bar).adjusted(-hit_pad, -hit_pad, hit_pad, hit_pad)
            if not g.contains(pos):
                continue
            dx = abs(pos.x() - g.center().x())
            dy = abs(pos.y() - g.center().y())
            dist = dx + dy
            if dist < dist_best:
                dist_best = dist
                closest = bar

        new_hover = closest.label if closest else None
        if new_hover != self._hovered:
            self._hovered = new_hover
            self.outcomeHovered.emit(new_hover)
            if closest is not None and not self._perf_simple:
                self._show_hover_tooltip(closest, pos)
            else:
                QToolTip.hideText()
                self._tip_label = None
            self.update()

    def _draw_prime_legend(self, painter: QPainter) -> None:
        x = self.width() - 150
        y = 10
        entries = [
            ("Desired", PRIME_COLORS["desired"]),
            ("Byproduct", PRIME_COLORS["byproduct"]),
            ("Indel", PRIME_COLORS["indel"]),
            ("No cut", PRIME_COLORS["no_cut"]),
        ]
        painter.save()
        font = painter.font()
        font.setPointSize(9)
        painter.setFont(font)
        for label, color in entries:
            painter.setBrush(color)
            painter.setPen(Qt.NoPen)
            painter.drawRect(x, y, 12, 12)
            painter.setPen(QPen(QColor(210, 220, 240)))
            painter.drawText(x + 18, y + 11, label)
            y += 16
        painter.restore()

    def leaveEvent(self, event):  # type: ignore[override]
        if self._hovered is not None:
            self._hovered = None
            self.outcomeHovered.emit(None)
            QToolTip.hideText()
            self._tip_label = None
            self.update()
        super().leaveEvent(event)

    def setHighlighted(self, outcome_id: str | None) -> None:
        self._external_highlight = outcome_id
        self.update()

    def setSelected(self, outcome_id: str | None) -> None:
        self._selected = outcome_id
        self.update()


class OutcomeDetailsCard(QFrame):
    outcomeSelected = Signal(object)
    designPcrRequested = Signal(object)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFrameShape(QFrame.StyledPanel)
        self.setStyleSheet("background-color: palette(window); border: 1px solid palette(mid); border-radius: 8px;")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(6)
        self.title = QLabel("Click an outcome bar to inspect its edit.", self)
        self.title.setStyleSheet("color: palette(window-text); font-size: 14px; font-weight: 600;")
        layout.addWidget(self.title)
        self.subtitle = QLabel("", self)
        self.subtitle.setStyleSheet("color: palette(mid);")
        layout.addWidget(self.subtitle)
        self.meta = QLabel("", self)
        self.meta.setWordWrap(True)
        self.meta.setStyleSheet("color: palette(window-text);")
        layout.addWidget(self.meta)
        self.diff_ref = QLabel("", self)
        self.diff_alt = QLabel("", self)
        for lab in (self.diff_ref, self.diff_alt):
            lab.setStyleSheet("font-family: Consolas, monospace; color: palette(window-text);")
            layout.addWidget(lab)
        self.physics = QLabel("", self)
        self.physics.setStyleSheet("color: palette(window-text); font-size: 12px;")
        layout.addWidget(self.physics)
        self.physics_hints = QLabel("", self)
        self.physics_hints.setWordWrap(True)
        self.physics_hints.setStyleSheet("color: palette(window-text); font-size: 11px;")
        self.physics_hints.setVisible(False)
        layout.addWidget(self.physics_hints)
        self.next_experiment_label = QLabel("Next data (v0)", self)
        self.next_experiment_label.setStyleSheet("color: palette(window-text); font-size: 12px; font-weight: 600;")
        layout.addWidget(self.next_experiment_label)
        self.next_experiment_text = QLabel("", self)
        self.next_experiment_text.setWordWrap(True)
        self.next_experiment_text.setStyleSheet("color: palette(window-text); font-size: 11px;")
        layout.addWidget(self.next_experiment_text)
        self.posterior_label = QLabel("Posterior context", self)
        self.posterior_label.setStyleSheet("color: palette(window-text); font-size: 12px; font-weight: 600;")
        layout.addWidget(self.posterior_label)
        self.posterior_warning = QLabel("", self)
        self.posterior_warning.setWordWrap(True)
        self.posterior_warning.setStyleSheet("color: palette(mid); font-size: 11px;")
        self.posterior_warning.setVisible(False)
        layout.addWidget(self.posterior_warning)
        self.posterior_text = QPlainTextEdit(self)
        self.posterior_text.setReadOnly(True)
        self.posterior_text.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.posterior_text.setObjectName("PosteriorContextText")
        self.posterior_text.setMinimumHeight(140)
        layout.addWidget(self.posterior_text)
        self.view_link = QLabel(self)
        self.view_link.setTextFormat(Qt.RichText)
        self.view_link.setText('<a href="view-helix">View this outcome on helix</a>')
        self.view_link.setTextInteractionFlags(Qt.TextBrowserInteraction)
        self.view_link.setStyleSheet("color: palette(link);")
        self.view_link.linkActivated.connect(self._on_view_link)
        layout.addWidget(self.view_link)

        self.pcr_button = QPushButton("Design PCR assay for this outcome", self)
        self.pcr_button.clicked.connect(self._on_design_pcr)
        layout.addWidget(self.pcr_button)
        layout.addStretch(1)

        self._value_mode = "score"
        self._quantitative_allowed = True
        self._current_bar: OutcomeBar | None = None
        self._current_selection: OutcomeSelection | None = None
        self._run_fallback: OutcomeSummary | None = None
        self._ref_sequence: str = ""

    def set_quantitative_allowed(self, allowed: bool) -> None:
        allowed = bool(allowed)
        if allowed == self._quantitative_allowed:
            return
        self._quantitative_allowed = allowed
        if self._current_bar is not None:
            try:
                self.set_selection(
                    self._current_bar,
                    self._ref_sequence,
                    self._current_selection,
                    run_physics=self._run_fallback,
                )
            except Exception:
                pass

    def set_value_mode(self, mode: str) -> None:
        mode = "probability" if str(mode) == "probability" else "score"
        self._value_mode = mode
        if self._current_bar is not None:
            try:
                self.set_selection(
                    self._current_bar,
                    self._ref_sequence,
                    self._current_selection,
                    run_physics=self._run_fallback,
                )
            except Exception:
                pass

    def set_selection(
        self,
        bar: OutcomeBar | None,
        sequence: str,
        selection: OutcomeSelection | None,
        *,
        run_physics: OutcomeSummary | None = None,
    ) -> None:
        self._current_bar = bar
        self._current_selection = selection
        self._run_fallback = run_physics
        self._ref_sequence = sequence
        if bar is None:
            self.title.setText("Click an outcome bar to inspect its edit.")
            self.subtitle.setText("")
            self.meta.setText("")
            self.diff_ref.setText("")
            self.diff_alt.setText("")
            self.physics.setText("")
            return
        frameshift_txt = "Frameshift" if bar.frameshift else "In-frame"
        if self._quantitative_allowed:
            prob_txt = _format_value(bar.probability, mode=self._value_mode, digits=1, annotate=True)
            self.title.setText(f"{bar.label} · {prob_txt}")
        else:
            self.title.setText(f"{bar.label} · suppressed")
        self.subtitle.setText(f"{frameshift_txt} · Δbp {bar.delta_bp:+d} at position {bar.peak_pos:+.0f}")
        mech_parts: list[str] = []
        if bar.microhomology is not None:
            mech_parts.append(f"Repair used {bar.microhomology} bp microhomology at {bar.pos_range[0]:+.0f}..{bar.pos_range[1]:+.0f}")
        elif bar.delta_bp < 0:
            mech_parts.append(f"Deletion {abs(bar.delta_bp)} bp spanning {bar.pos_range[0]:+.0f}..{bar.pos_range[1]:+.0f}")
        elif bar.delta_bp > 0:
            mech_parts.append(f"Insertion {bar.delta_bp} bp at {bar.pos_range[0]:+.0f}")
        else:
            mech_parts.append("No edit at cut")
        mech_text = " · ".join(mech_parts)
        intent_txt = "Intended label" if getattr(bar, "intended", False) else ""
        tag = f" [{bar.category}]" if bar.category else ""
        meta_line = mech_text + tag
        if intent_txt:
            meta_line += f" · {intent_txt}"
        self.meta.setText(meta_line)

        # Diff preview
        if bar.start is not None and bar.end is not None and sequence:
            s = min(bar.start, bar.end)
            e = max(bar.start, bar.end)
            left = sequence[max(0, s - 5) : s]
            mid = sequence[s:e]
            right = sequence[e : e + 5]
            repl = bar.replacement or "" if bar.replacement is not None else ""
            ref_txt = f"Ref: ...{left}[{mid}]{right}..."
            alt_mid = repl if bar.delta_bp >= 0 else ""
            alt_txt = f"Alt: ...{left}[{alt_mid}]{right}..."
            self.diff_ref.setText(ref_txt)
            self.diff_alt.setText(alt_txt)
        else:
            self.diff_ref.setText("")
            self.diff_alt.setText("")

        phys_parts: list[str] = []
        if self._quantitative_allowed:
            if bar.pbs_dg is not None:
                phys_parts.append(f"PBS ΔG: {bar.pbs_dg:.2f} kcal/mol")
            if bar.flap_ddg is not None:
                phys_parts.append(f"Flap ΔΔG: {bar.flap_ddg:.2f}")
            if bar.e_pred is not None:
                color = _score_color(bar.e_pred)
                phys_parts.append(f"<span style='color:{color}'>E_pred: {bar.e_pred:.3f}</span>")
            if not phys_parts and run_physics is not None:
                if run_physics.pbs_dg is not None:
                    phys_parts.append(f"Run PBS ΔG: {run_physics.pbs_dg:.2f}")
                if run_physics.flap_ddg is not None:
                    phys_parts.append(f"Run Flap ΔΔG: {run_physics.flap_ddg:.2f}")
                if run_physics.e_pred is not None:
                    color = _score_color(run_physics.e_pred)
                    phys_parts.append(f"<span style='color:{color}'>Run E_pred: {run_physics.e_pred:.3f}</span>")
                if phys_parts:
                    phys_parts.append("(run-wide)")
        self.physics.setText(" · ".join(phys_parts))

    def set_posterior_context(
        self,
        edit_spec: Mapping[str, Any] | None,
        context: Mapping[str, Any] | None,
    ) -> None:
        exp_spec = None
        edit_plan = None
        if isinstance(edit_spec, Mapping):
            exp_spec = edit_spec.get("experiment_spec")
            edit_plan = edit_spec.get("edit_plan")

        def _format_payload(payload: Any) -> str:
            if not isinstance(payload, Mapping):
                return "not provided"
            if not payload:
                return "not provided"
            try:
                return json.dumps(payload, indent=2, sort_keys=True)
            except Exception:
                return str(payload)

        text = "\n".join(
            [
                "experiment_spec:",
                _format_payload(exp_spec),
                "",
                "edit_plan:",
                _format_payload(edit_plan),
                "",
                "context:",
                _format_payload(context),
            ]
        )
        self.posterior_text.setPlainText(text)

        warn = ""
        if _is_flat_context(context):
            warn = "Sensitivity warning: context is flat prior; predictions may shift with cell or assay inputs."
        self.posterior_warning.setText(warn)
        self.posterior_warning.setVisible(bool(warn))

    def set_next_experiment(self, text: str, *, tooltip: str = "") -> None:
        if not hasattr(self, "next_experiment_text"):
            return
        self.next_experiment_text.setText(str(text or ""))
        self.next_experiment_text.setToolTip(str(tooltip or ""))

    def _on_view_link(self, href: str) -> None:
        if href != "view-helix":
            return
        if self._current_selection is None:
            return
        self.outcomeSelected.emit(self._current_selection)

    def _on_design_pcr(self) -> None:
        if self._current_selection is None:
            return
        ctx = PcrDesignContext(
            run_id=self._current_selection.run_id,
            guide_id=self._current_selection.guide_id,
            outcome_name=self._current_selection.outcome_name,
            delta_bp=self._current_selection.delta_bp,
            position_range=self._current_selection.position_range,
            peak_position=self._current_selection.peak_position,
            ref_sequence=self._ref_sequence,
            cut_index=None,
        )
        self.designPcrRequested.emit(ctx)

    def set_physics_hints(self, hints: list[str] | None) -> None:
        if not hints:
            self.physics_hints.clear()
            self.physics_hints.setVisible(False)
            return
        self.physics_hints.setText(" • ".join(hints))
        self.physics_hints.setVisible(True)


class RunTimelineWidget(QWidget):
    """Lightweight scrubber to step through runs in focus mode."""

    runSelected = Signal(str)
    overlaySelected = Signal(str)
    physicsToggled = Signal(bool)
    lensChanged = Signal(str)
    seqModeChanged = Signal(str)
    cloneRequested = Signal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)

        self._runs: list[tuple[str, str | None]] = []
        self._timer = QTimer(self)
        self._timer.setInterval(900)
        self._timer.timeout.connect(self._advance)
        self._playing = False

        self._prev_btn = QToolButton(self)
        self._prev_btn.setText("◀")
        self._prev_btn.clicked.connect(self._step_prev)
        layout.addWidget(self._prev_btn)

        self._play_btn = QToolButton(self)
        self._play_btn.setText("▶")
        self._play_btn.setCheckable(True)
        self._play_btn.clicked.connect(self._toggle_play)
        layout.addWidget(self._play_btn)

        self._overlay_btn = QToolButton(self)
        self._overlay_btn.setText("Overlay")
        self._overlay_btn.setToolTip("Set current run as overlay baseline")
        self._overlay_btn.clicked.connect(self._emit_overlay)
        layout.addWidget(self._overlay_btn)

        self._clone_btn = QToolButton(self)
        self._clone_btn.setText("Clone")
        self._clone_btn.setToolTip("Clone this run into Sim Builder")
        self._clone_btn.clicked.connect(self._emit_clone)
        layout.addWidget(self._clone_btn)

        self._physics_btn = QToolButton(self)
        self._physics_btn.setText("Hints")
        self._physics_btn.setToolTip("Toggle model hints overlay")
        self._physics_btn.setCheckable(True)
        self._physics_btn.toggled.connect(self.physicsToggled.emit)
        layout.addWidget(self._physics_btn)

        self._lens = QComboBox(self)
        self._lens.addItem("All outcomes", "all")
        self._lens.addItem("Frameshift", "frameshift")
        self._lens.addItem("In-frame", "in_frame")
        self._lens.addItem("Intended-ish", "intendedish")
        self._lens.addItem("Large deletions", "large_del")
        self._lens.currentIndexChanged.connect(lambda _: self.lensChanged.emit(self._lens.currentData()))
        layout.addWidget(self._lens)

        self._seq_mode = QComboBox(self)
        self._seq_mode.addItem("Seq: current", "current")
        self._seq_mode.addItem("Seq: baseline", "baseline")
        self._seq_mode.addItem("Seq: diff", "diff")
        self._seq_mode.currentIndexChanged.connect(lambda _: self.seqModeChanged.emit(self._seq_mode.currentData()))
        layout.addWidget(self._seq_mode)

        legend = QLabel("● base   ◆ clone   ○ has children", self)
        legend.setStyleSheet("color: palette(mid); font-size: 10px;")
        layout.addWidget(legend)

        self._slider = QSlider(Qt.Horizontal, self)
        self._slider.valueChanged.connect(self._on_slider_changed)
        layout.addWidget(self._slider, stretch=1)

        self._next_btn = QToolButton(self)
        self._next_btn.setText("▶")
        self._next_btn.clicked.connect(self._step_next)
        layout.addWidget(self._next_btn)

        self._label = QLabel("", self)
        self._label.setStyleSheet("color: palette(mid); font-size: 11px;")
        layout.addWidget(self._label)

        self.setFocusPolicy(Qt.StrongFocus)

    def set_runs(self, runs: list[tuple[str, str | None]], parent_map: dict[str, str] | None = None) -> None:
        self._runs = runs or []
        self._parents = parent_map or {}
        self._has_children = {p: False for p in self._parents.values()}
        for child, parent in self._parents.items():
            self._has_children[parent] = True
        self._slider.blockSignals(True)
        if self._runs:
            self._slider.setRange(0, len(self._runs) - 1)
            self._slider.setValue(len(self._runs) - 1)
        else:
            self._slider.setRange(0, 0)
            self._slider.setValue(0)
        self._slider.blockSignals(False)
        self._update_label()
        if self._runs:
            self.runSelected.emit(self._runs[self._slider.value()][0])

    def set_prime_mode(self, enabled: bool) -> None:
        """Rebuild lens options for prime runs."""
        base_items = [
            ("All outcomes", "all"),
            ("Frameshift", "frameshift"),
            ("In-frame", "in_frame"),
            ("Intended-ish", "intendedish"),
            ("Large deletions", "large_del"),
        ]
        prime_items = [
            ("Prime desired", "pe:desired"),
            ("Prime byproducts", "pe:byproduct"),
            ("Prime indels", "pe:indel"),
        ]
        desired_items = base_items + (prime_items if enabled else [])
        current = self._lens.currentData()
        existing = [self._lens.itemData(i) for i in range(self._lens.count())]
        if existing == [d for _, d in desired_items]:
            return
        self._lens.blockSignals(True)
        self._lens.clear()
        for label, val in desired_items:
            self._lens.addItem(label if not enabled else (f"{label}"), val)
        # restore selection if possible
        idx = self._lens.findData(current)
        if idx < 0:
            idx = 0
        self._lens.setCurrentIndex(idx)
        self._lens.blockSignals(False)
        self.lensChanged.emit(self._lens.currentData())
        self._lens.setToolTip("Lenses (Prime)" if enabled else "Outcome lenses")

    def _on_slider_changed(self, idx: int) -> None:
        if not self._runs:
            return
        idx = max(0, min(idx, len(self._runs) - 1))
        run_id, _ = self._runs[idx]
        self._update_label()
        self.runSelected.emit(run_id)

    def _step_prev(self) -> None:
        if not self._runs:
            return
        self._slider.setValue(max(0, self._slider.value() - 1))

    def _step_next(self) -> None:
        if not self._runs:
            return
        self._slider.setValue(min(len(self._runs) - 1, self._slider.value() + 1))

    def _toggle_play(self) -> None:
        self._playing = not self._playing
        if self._playing:
            self._play_btn.setText("⏸")
            self._timer.start()
        else:
            self._play_btn.setText("▶")
            self._timer.stop()

    def _advance(self) -> None:
        if not self._runs:
            self._toggle_play()
            return
        next_idx = self._slider.value() + 1
        if next_idx >= len(self._runs):
            next_idx = 0
        self._slider.setValue(next_idx)

    def _update_label(self) -> None:
        if not self._runs:
            self._label.setText("No runs")
            return
        idx = self._slider.value()
        rid, label = self._runs[idx]
        suffix = f" · {label}" if label else ""
        parent = self._parents.get(rid)
        if parent:
            suffix += f"  (clone of {parent})"
        self._label.setText(f"{idx+1}/{len(self._runs)} {rid}{suffix}")

    def _emit_overlay(self) -> None:
        if not self._runs:
            return
        idx = self._slider.value()
        rid, _ = self._runs[idx]
        self.overlaySelected.emit(rid)

    def _emit_clone(self) -> None:
        if not self._runs:
            return
        idx = self._slider.value()
        rid, _ = self._runs[idx]
        self.cloneRequested.emit(rid)

    def keyPressEvent(self, event) -> None:  # type: ignore[override]
        if event.key() == Qt.Key_Left:
            self._step_prev()
            event.accept()
            return
        if event.key() == Qt.Key_Right:
            self._step_next()
            event.accept()
            return
        if event.key() in (Qt.Key_Space, Qt.Key_K):
            self._toggle_play()
            event.accept()
            return
        super().keyPressEvent(event)


class SequenceContextWidget(QWidget):
    """Show reference/alternative sequence window for the selected outcome."""

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self._context: Optional[SequenceContext] = None
        self._mode: str = "current"  # current | baseline | diff

        self._label = QLabel("Sequence context", self)
        self._label.setStyleSheet("color: palette(window-text); font-size: 12px;")

        self._text = QPlainTextEdit(self)
        self._text.setReadOnly(True)
        self._text.setLineWrapMode(QPlainTextEdit.NoWrap)
        self._text.setObjectName("SequenceContextText")
        self._text.setMinimumHeight(120)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 4, 0, 0)
        layout.setSpacing(4)
        layout.addWidget(self._label)
        layout.addWidget(self._text)
        self.setVisible(False)

    def set_mode(self, mode: str) -> None:
        if mode not in ("current", "baseline", "diff"):
            return
        if self._mode == mode:
            return
        self._mode = mode
        self._refresh()

    def set_context(self, ctx: Optional[SequenceContext]) -> None:
        self._context = ctx
        self._refresh()

    def _refresh(self) -> None:
        if self._context is None:
            self._text.clear()
            self.setVisible(False)
            return
        self.setVisible(True)
        self._text.setPlainText(self._render_context(self._context, self._mode))

    def _render_context(self, ctx: SequenceContext, mode: str) -> str:
        ref = ctx.ref_window or ""
        alt = ctx.alt_window or ref
        base_alt = ctx.baseline_alt_window or ""
        cut = ctx.cut_index
        edit_start = ctx.edit_start
        edit_end = ctx.edit_end

        # caret for cut site
        ruler = [" "] * len(ref)
        if 0 <= cut < len(ruler):
            ruler[cut] = "^"

        # nick marker (prime editing)
        nick_line = [" "] * len(ref)
        if ctx.nick_index is not None and 0 <= ctx.nick_index < len(nick_line):
            nick_line[ctx.nick_index] = "n"

        # edit span brackets
        span = [" "] * len(ref)
        s = max(0, min(edit_start, len(span)))
        e = max(s, min(edit_end, len(span)))
        if s < len(span):
            span[s] = "["
        if e - 1 < len(span) and e - 1 >= 0:
            span[e - 1] = "]"

        lines = []
        lines.append(f"REF  {ref}")
        if mode == "baseline" and base_alt:
            lines.append(f"ALT₀ {base_alt}")
        elif mode == "diff" and base_alt:
            lines.append(f"ALT  {alt}")
            lines.append(f"ALT₀ {base_alt}")
        else:
            lines.append(f"ALT  {alt}")
        lines.append(f"     {''.join(ruler)} cut")
        if any(c != " " for c in nick_line):
            lines.append(f"     {''.join(nick_line)} nick")
        if ctx.pbs_span or ctx.rtt_span:
            pe_line = [" "] * len(ref)
            if ctx.pbs_span:
                ps, pe = ctx.pbs_span
                for i in range(max(0, ps), min(len(pe_line), pe)):
                    pe_line[i] = "P"
            if ctx.rtt_span:
                rs, re = ctx.rtt_span
                for i in range(max(0, rs), min(len(pe_line), re)):
                    pe_line[i] = "R" if pe_line[i] == " " else "X"
            lines.append(f"     {''.join(pe_line)} PBS/RTT")
        lines.append(f"     {''.join(span)} edit")

        meta = []
        if ctx.label:
            meta.append(f"current: {ctx.label}")
        if ctx.baseline_label:
            meta.append(f"baseline: {ctx.baseline_label}")
        if ctx.pbs_len:
            meta.append(f"PBS {ctx.pbs_len}bp")
        if ctx.rtt_len:
            meta.append(f"RTT {ctx.rtt_len}bp")
        if ctx.nick_index is not None:
            meta.append(f"nick @ {ctx.nick_index}")
        if meta:
            lines.append("")
            lines.append("  " + "   ".join(meta))
        return "\n".join(lines)


class OutcomeTable(QTableWidget):
    rowSelected = Signal(str)
    outcomeSelected = Signal(str)
    outcomeHovered = Signal(object)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(0, 8, parent)
        self.setObjectName("OutcomeTable")
        self._value_mode = "score"
        self._quantitative_allowed = True
        self._dim_tier3_plus = True
        self._primary_label: str | None = None
        self.setHorizontalHeaderLabels(
            [
                "Outcome",
                "Primary",
                "Type",
                "Frameshift",
                "Δbp",
                _value_label(self._value_mode),
                "Peak pos",
                "Example allele",
            ]
        )
        self.setSelectionBehavior(self.SelectionBehavior.SelectRows)
        self.setEditTriggers(self.EditTrigger.NoEditTriggers)
        self.setAlternatingRowColors(True)
        self.setMouseTracking(True)
        self.viewport().setMouseTracking(True)
        self._rows: list[OutcomeRow] = []
        self._row_index: dict[str, int] = {}
        self._locked_outcome: str | None = None
        self._bold_row_idx: int | None = None
        self._pinned_label: str | None = None
        header = self.horizontalHeader()
        header.setProperty("outcome-header", True)
        self.itemSelectionChanged.connect(self._on_selected)
        self.cellEntered.connect(self._on_cell_entered)

    def set_dim_tier3_plus(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if enabled == self._dim_tier3_plus:
            return
        self._dim_tier3_plus = enabled
        if self._rows:
            self.set_rows(self._rows, primary_label=self._primary_label)

    def set_quantitative_allowed(self, allowed: bool) -> None:
        allowed = bool(allowed)
        if allowed == self._quantitative_allowed:
            return
        self._quantitative_allowed = allowed
        try:
            self.setHorizontalHeaderLabels(
                [
                    "Outcome",
                    "Primary",
                    "Type",
                    "Frameshift",
                    "Δbp",
                    (_value_label(self._value_mode) if allowed else "Tier"),
                    "Peak pos",
                    "Example allele",
                ]
            )
        except Exception:
            pass
        if self._rows:
            self.set_rows(self._rows)

    def set_value_mode(self, mode: str) -> None:
        mode = "probability" if str(mode) == "probability" else "score"
        if mode == self._value_mode:
            return
        self._value_mode = mode
        try:
            self.setHorizontalHeaderLabels(
                [
                    "Outcome",
                    "Primary",
                    "Type",
                    "Frameshift",
                    "Δbp",
                    (_value_label(self._value_mode) if self._quantitative_allowed else "Tier"),
                    "Peak pos",
                    "Example allele",
                ]
            )
        except Exception:
            return
        if self._rows:
            self.set_rows(self._rows)

    def set_rows(self, rows: list[OutcomeRow], *, primary_label: str | None = None) -> None:
        self._rows = rows
        if primary_label is None and rows:
            try:
                primary_label = max(rows, key=lambda r: float(r.probability), default=None).label
            except Exception:
                primary_label = None
        self._primary_label = primary_label
        self.setRowCount(len(rows))
        self._row_index = {}
        self._bold_row_idx = None
        pal = self.palette()
        primary_color = pal.color(QPalette.ColorRole.Highlight)
        dim_color = pal.color(QPalette.ColorRole.Mid)
        for i, row in enumerate(rows):
            if self._quantitative_allowed:
                prob_txt = _format_value(row.probability, mode=self._value_mode, digits=1, annotate=False)
            else:
                tier = tier_for_rank(i + 1)
                prob_txt = tier.label
            items = [
                QTableWidgetItem(("★ " if self._pinned_label and row.label == self._pinned_label else "") + row.label),
                QTableWidgetItem("Primary" if (primary_label is not None and row.label == primary_label) else ""),
                QTableWidgetItem(row.category),
                QTableWidgetItem("yes" if row.frameshift else "no"),
                QTableWidgetItem(f"{row.delta_bp:+d}"),
                QTableWidgetItem(prob_txt),
                QTableWidgetItem(f"{row.peak_pos:+.0f}"),
                QTableWidgetItem(row.example),
            ]
            for col, item in enumerate(items):
                if col in (3, 4, 5, 6):
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                elif col == 1:
                    item.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                else:
                    item.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter)
                if col == 1 and item.text():
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
                    item.setForeground(primary_color)
                self.setItem(i, col, item)

            # Tier iconography + optional emphasis/dimming (exploratory mode only).
            if not self._quantitative_allowed:
                tier_item = items[5]
                try:
                    tier_lvl = int(tier.level)  # type: ignore[has-type]
                except Exception:
                    tier_lvl = 4
                tier_icon = "check" if tier_lvl == 1 else ("warning" if tier_lvl == 2 else "hazard")
                try:
                    icon = QIcon(f":/icons/{tier_icon}.svg")
                    if not icon.isNull():
                        tier_item.setIcon(icon)
                        tier_item.setToolTip(f"{tier.label} (rank #{i+1})")
                except Exception:
                    pass

                if bool(self._dim_tier3_plus) and tier_lvl >= 3 and not (primary_label is not None and row.label == primary_label):
                    for item in items:
                        try:
                            item.setForeground(dim_color)
                        except Exception:
                            pass
            if row.label not in self._row_index:
                self._row_index[row.label] = i
        self.resizeColumnsToContents()
        self._restore_locked_selection()

    def set_pinned_label(self, label: str | None) -> None:
        self._pinned_label = label

    def _select_row_by_id(self, outcome_id: str | None, *, ensure_visible: bool = False) -> None:
        model = self.selectionModel()
        if model is None:
            return
        if outcome_id is None:
            model.clearSelection()
            return
        row = self._row_index.get(outcome_id)
        if row is None:
            model.clearSelection()
            return
        index = self.model().index(row, 0)
        model.select(index, QItemSelectionModel.ClearAndSelect | QItemSelectionModel.Rows)
        if ensure_visible:
            item = self.item(row, 0)
            if item is not None:
                self.scrollToItem(item, QAbstractItemView.PositionAtCenter)

    def _restore_locked_selection(self) -> None:
        if self._locked_outcome:
            self.setHighlighted(self._locked_outcome, lock=True)

    def _set_row_bold(self, row: int, bold: bool) -> None:
        item = self.item(row, 0)
        if item is None:
            return
        font = item.font()
        font.setBold(bold)
        item.setFont(font)
        self._bold_row_idx = row if bold else None

    def setHighlighted(self, outcome_id: str | None, *, lock: bool = False, ensure_visible: bool = False) -> None:
        if lock:
            self._locked_outcome = outcome_id
        self.blockSignals(True)
        if outcome_id is None:
            if self._locked_outcome:
                self._select_row_by_id(self._locked_outcome, ensure_visible=ensure_visible)
            else:
                self.clearSelection()
            if self._bold_row_idx is not None:
                self._set_row_bold(self._bold_row_idx, False)
        else:
            self._select_row_by_id(outcome_id, ensure_visible=ensure_visible)
            if self._bold_row_idx is not None and self._bold_row_idx != self._row_index.get(outcome_id, -1):
                self._set_row_bold(self._bold_row_idx, False)
            row_idx = self._row_index.get(outcome_id)
            if row_idx is not None:
                self._set_row_bold(row_idx, True)
        self.blockSignals(False)

    def _on_selected(self) -> None:
        idxs = self.selectionModel().selectedRows()
        if not idxs:
            return
        row = idxs[0].row()
        if 0 <= row < len(self._rows):
            outcome_id = self._rows[row].label
            self._locked_outcome = outcome_id
            if self._bold_row_idx is not None and self._bold_row_idx != row:
                self._set_row_bold(self._bold_row_idx, False)
            self._set_row_bold(row, True)
            self.rowSelected.emit(outcome_id)
            self.outcomeSelected.emit(outcome_id)

    def _on_cell_entered(self, row: int, _col: int) -> None:
        if 0 <= row < len(self._rows):
            self.outcomeHovered.emit(self._rows[row].label)

    def leaveEvent(self, event):  # type: ignore[override]
        self.outcomeHovered.emit(None)
        super().leaveEvent(event)


class FilterWidget(QWidget):
    filtersChanged = Signal(float, str, str, str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._quantitative_allowed = True
        self._outcome_count = 0
        self._pathway_ids: list[str] = []
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        self.sort_combo = QComboBox(self)
        self.sort_combo.addItems(["Probability", "Frameshift impact", "Δbp size"])
        self.sort_combo.currentIndexChanged.connect(self._emit)
        self.sort_label = QLabel("Sort by", self)
        layout.addWidget(self.sort_label)
        layout.addWidget(self.sort_combo)
        self.slider = QSlider(Qt.Horizontal, self)
        self.slider.setRange(0, 50)
        self.slider.setValue(0)
        self.slider.valueChanged.connect(self._emit)
        self.slider_label = QLabel("Show outcomes >", self)
        layout.addWidget(self.slider_label)
        layout.addWidget(self.slider)
        self.toggle_combo = QComboBox(self)
        self.toggle_combo.addItems(["All", "Insertions", "Deletions", "No cut", "Frameshift only"])
        self.toggle_combo.currentIndexChanged.connect(self._emit)
        layout.addWidget(self.toggle_combo)

        self.pathway_combo = QComboBox(self)
        self.pathway_combo.setToolTip("Repair pathway mixture component (derived)")
        self.pathway_combo.currentIndexChanged.connect(self._emit)
        self.pathway_combo.setVisible(False)
        layout.addWidget(self.pathway_combo)
        layout.addStretch(1)
        self.set_outcome_count(0)

    def set_quantitative_allowed(self, allowed: bool) -> None:
        allowed = bool(allowed)
        if allowed == self._quantitative_allowed:
            return
        self._quantitative_allowed = allowed
        # Re-apply visibility rules based on current count + policy.
        self.set_outcome_count(int(getattr(self, "_outcome_count", 0) or 0))

    def set_outcome_count(self, count: int) -> None:
        """Reduce chrome for small outcome sets (progressive disclosure)."""
        try:
            n = int(count)
        except Exception:
            n = 0
        self._outcome_count = n

        show_advanced = bool(self._quantitative_allowed) and (n > 30)
        for w in (self.sort_label, self.sort_combo, self.slider_label, self.slider):
            try:
                w.setVisible(bool(show_advanced))
            except Exception:
                pass
        if not show_advanced:
            try:
                self.sort_combo.setCurrentIndex(0)
                self.slider.setValue(0)
            except Exception:
                pass

    def set_pathways(self, pathway_ids: Sequence[str]) -> None:
        ids: list[str] = []
        seen: set[str] = set()
        for pid in pathway_ids:
            p = str(pid or "").strip().lower()
            if not p or p in seen:
                continue
            seen.add(p)
            ids.append(p)
        # Canonical ordering for stable UX.
        ids = [p for p in PATHWAY_ORDER if p in seen] + [p for p in ids if p not in PATHWAY_ORDER]
        self._pathway_ids = ids

        cur = None
        try:
            cur = self.pathway_combo.currentData()
        except Exception:
            cur = None
        cur = str(cur or "all")

        self.pathway_combo.blockSignals(True)
        self.pathway_combo.clear()
        self.pathway_combo.addItem("All pathways", userData="all")
        for pid in ids:
            self.pathway_combo.addItem(str(PATHWAY_UI_LABEL.get(pid, pid)), userData=pid)
        # If the previous selection isn't available, fall back to "all".
        if cur != "all" and cur in ids:
            idx = self.pathway_combo.findData(cur)
            if idx >= 0:
                self.pathway_combo.setCurrentIndex(idx)
        else:
            self.pathway_combo.setCurrentIndex(0)
        self.pathway_combo.blockSignals(False)

        # Only show when there is something to compare.
        self.pathway_combo.setVisible(len(ids) > 1)

    def set_value_mode(self, mode: str) -> None:
        if not bool(self._quantitative_allowed):
            label = "Rank"
        else:
            label = _value_label(mode)
        try:
            if self.sort_combo.count() > 0:
                self.sort_combo.setItemText(0, label)
        except Exception:
            pass

    def _emit(self) -> None:
        cat_map = {
            0: "all",
            1: "insertions",
            2: "deletions",
            3: "no_cut",
            4: "frameshift",
        }
        cat = cat_map.get(self.toggle_combo.currentIndex(), "all")
        sort_idx = self.sort_combo.currentIndex()
        sort_key = "probability" if sort_idx == 0 else ("frameshift" if sort_idx == 1 else "delta")
        min_prob = self.slider.value() / 100.0
        pathway = "all"
        try:
            pathway = str(self.pathway_combo.currentData() or "all")
        except Exception:
            pathway = "all"
        if not bool(self._quantitative_allowed):
            # In demo/non-calibrated mode, quantitative thresholds are suppressed.
            min_prob = 0.0
            sort_key = "probability"
        self.filtersChanged.emit(min_prob, cat, sort_key, pathway)


class OutcomeExplorerWidget(QWidget):
    compareRunRequested = Signal(str)
    cloneRunRequested = Signal(str)
    outcomeSelected = Signal(object)
    designPcrRequested = Signal(object)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFont(base_font())
        self._settings = QSettings("Helix", "Studio")
        self._apply_calibration_bundle_dir_from_settings()
        self._current_run: RunModel | None = None
        self._evs: dict | None = None
        self._outcomes_layer: dict | None = None
        self._prime_meta: PrimeMeta | None = None
        self._current_sequence_ctx: SequenceContext | None = None
        self._baseline_data: OutcomeExplorerData | None = None
        self._current_shift: int = 0
        self._perturbation_provider = None  # optional callable (delta_bp: int, strand_flip=False, target_id=None) -> OutcomeExplorerData
        self._perturbation_cache: dict[tuple[int, bool, str | None], OutcomeExplorerData] = {}
        self._perturbation_cache_fp: str | None = None
        self._strand_flipped: bool = False
        self._compact_mode = False
        self._compact_prev_view_mode: int | None = None
        self._compact_view_mode_auto = False
        self._detail_level: str = "overview"
        self._pending_blocker_focus_cb = None
        self._export_blocked_reason: str | None = None
        self._export_prompt_suppressed_by_key: dict[str, bool] = {}
        self._decision_mode_eligible = False
        self._artifact_valid: bool | None = None
        self._decision_mode_reasons: list[str] = []
        self._decision_mode: str = "filter_only"
        self._probability_mode = "score"
        self._exploratory_color_ack = False
        self._exploratory_color_ack_key: str | None = None
        self._exploratory_color_ack_by_key: dict[str, bool] = {}
        self._export_tooltip_hint: str = ""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        layout.setSpacing(SPACING_MEDIUM)

        # ---- Header band (primary controls + boss signal) ----
        header_container = QWidget(self)
        header_container.setObjectName("EVSHeaderBar")
        header_layout = QVBoxLayout(header_container)
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(SPACING_SMALL)
        self._header_container = header_container

        row1 = QHBoxLayout()
        row1.setContentsMargins(0, 0, 0, 0)
        row1.setSpacing(SPACING_SMALL)
        self.title = QLabel("CRISPR – g2 (rail_3d)", self)
        self.title.setStyleSheet("font-weight: 600;")
        self._help_btn = QPushButton("?")
        self._help_btn.setFixedSize(22, 22)
        self._help_btn.setObjectName("SecondaryButton")
        self._help_btn.clicked.connect(self._show_help)
        self.rank_chip = QLabel(self)
        self.rank_chip.setVisible(False)
        self.rank_chip.setStyleSheet(
            "border-radius: 999px; padding: 2px 8px; "
            "background: palette(base); "
            "border: 1px solid palette(mid); "
            "font-size: 11px; color: palette(window-text);"
        )
        self._models_btn = QToolButton(self)
        self._models_btn.setObjectName("ModelsButton")
        self._models_btn.setText("Models ▾")
        self._models_btn.setPopupMode(QToolButton.InstantPopup)
        self._models_btn.setToolTip("Model stack (copy) · Calibration · Reference")
        self._models_btn.setStyleSheet(
            "QToolButton { padding:3px 8px; border-radius:10px; "
            "background: palette(base); border: 1px solid palette(mid); "
            "color: palette(window-text); font-size: 11px; } "
            "QToolButton::menu-indicator { image: none; }"
        )
        self._models_menu = QMenu(self._models_btn)
        self._models_btn.setMenu(self._models_menu)

        self._header_more_btn = QToolButton(self)
        self._header_more_btn.setObjectName("HeaderMoreButton")
        self._header_more_btn.setText("▾")
        self._header_more_btn.setCheckable(True)
        self._header_more_btn.setChecked(False)
        self._header_more_btn.setAutoRaise(True)
        self._header_more_btn.setToolTip("Show more controls")
        self._header_more_btn.toggled.connect(self._on_header_more_toggled)
        self._header_more_btn.hide()

        self.export_btn = QToolButton(self)
        self.export_btn.setText("Export")
        self.export_btn.setPopupMode(QToolButton.InstantPopup)
        self.export_btn.setStyleSheet(
            "QToolButton { padding:4px 8px; border:1px solid palette(mid); border-radius:6px; color:palette(window-text); } "
            "QToolButton::menu-indicator { image: none; }"
        )

        self.focus_btn = QToolButton(self)
        self.focus_btn.setText("Focus")
        self.focus_btn.setCheckable(True)
        self.focus_btn.setToolTip("Outcomes Focus Mode (F11)")
        self.focus_btn.setStyleSheet(
            "QToolButton { padding:4px 8px; border:1px solid palette(mid); border-radius:6px; color:palette(window-text); }"
        )
        self.focus_btn.toggled.connect(self._request_global_focus_mode)

        self._view_label = QLabel("View:", self)
        self._view_label.setStyleSheet("color: palette(mid); font-size: 11px;")

        self.detail_level = QComboBox(self)
        self.detail_level.addItems(["Overview", "Analysis", "Debug"])
        self.detail_level.setMinimumWidth(130)
        self.detail_level.setMaximumWidth(130)
        self.detail_level.setToolTip("Detail level: Overview (minimal), Analysis (interactive), Debug (full context)")
        self.detail_level.currentIndexChanged.connect(self._on_detail_level_changed)

        self.chart_view = QComboBox(self)
        self.chart_view.addItems([f"Outcome {_value_label_plural(self._probability_mode)}", "Position around cut"])
        self.chart_view.setMinimumWidth(190)
        self.chart_view.setMaximumWidth(190)
        self.chart_view.currentIndexChanged.connect(self._on_chart_view_changed)

        self.view_mode = QComboBox(self)
        self.view_mode.addItems(["Balanced", "Chart focus", "Table focus"])
        self.view_mode.setMinimumWidth(140)
        self.view_mode.setMaximumWidth(140)
        self.view_mode.currentIndexChanged.connect(self._on_view_mode_changed)

        self.heat_toggle = QCheckBox("Show off-target heat", self)
        self.heat_toggle.setChecked(False)
        self.heat_toggle.setToolTip(
            "Show window-local off-target heat (proxy-only; mismatch position-aware; not genome-wide)."
        )
        self.heat_toggle.stateChanged.connect(lambda state: self._on_toggle_offtarget_heat(state == Qt.Checked))
        menu = QMenu(self.export_btn)
        act_chart = QAction("Export chart (PNG)", menu)
        act_csv = QAction("Export outcomes (CSV)", menu)
        act_report = QAction("Export report (HTML)", menu)
        act_focus = QAction("Export focus snapshot", menu)
        menu.addAction(act_chart)
        menu.addAction(act_csv)
        menu.addAction(act_report)
        menu.addAction(act_focus)
        menu.addSeparator()
        act_copy_export_prov = QAction("Copy export provenance (JSON)", menu)
        act_copy_export_sha = QAction("Copy export provenance SHA256", menu)
        act_open_export_prov = QAction("Open export provenance…", menu)
        menu.addAction(act_copy_export_prov)
        menu.addAction(act_copy_export_sha)
        menu.addAction(act_open_export_prov)
        act_chart.triggered.connect(self._export_chart_png)
        act_csv.triggered.connect(self._export_outcomes_csv)
        act_report.triggered.connect(self._export_report_html)
        act_focus.triggered.connect(self._export_focus_snapshot)
        act_copy_export_prov.triggered.connect(self._copy_export_provenance_json_to_clipboard)
        act_copy_export_sha.triggered.connect(self._copy_export_provenance_sha_to_clipboard)
        act_open_export_prov.triggered.connect(self._open_export_provenance_file)
        self.export_btn.setMenu(menu)
        self._export_actions = [act_chart, act_csv, act_report, act_focus]
        self._export_provenance_actions = [act_copy_export_prov, act_copy_export_sha, act_open_export_prov]
        self._viz_badge = QToolButton(self)
        self._viz_badge.setCheckable(False)
        self._viz_badge.setAutoRaise(True)
        self._viz_badge.setVisible(False)
        self._viz_badge.setStyleSheet(
            "QToolButton { padding:3px 8px; border-radius:10px; "
            "background: palette(base); border: 1px solid palette(mid); "
            "color: palette(window-text); font-size: 11px; }"
        )
        self._viz_badge.clicked.connect(self._on_viz_badge_clicked)
        self._mode_badge = QToolButton(self)
        self._mode_badge.setCheckable(False)
        self._mode_badge.setAutoRaise(True)
        self._mode_badge.setVisible(True)
        self._mode_badge.setText("EXPLORATORY")
        self._mode_badge.setToolTip("Decision mode label derived from readiness gates.")
        self._mode_badge.setStyleSheet(
            "QToolButton { padding:3px 8px; border-radius:10px; "
            "background: palette(base); border: 1px solid palette(mid); "
            "color: palette(window-text); font-size: 11px; font-weight: 650; }"
        )

        # Secondary header row includes both interactive controls and informational badges.
        # Keep the badges visible even when collapsing controls behind the chevron so we
        # don't hide key context (model + domain) in compact mode.
        self._header_primary_controls = QWidget(self)
        # Back-compat alias (tests and older integrations).
        self._header_secondary_controls = self._header_primary_controls  # type: ignore[attr-defined]
        primary_controls_layout = QHBoxLayout(self._header_primary_controls)
        primary_controls_layout.setContentsMargins(0, 0, 0, 0)
        primary_controls_layout.setSpacing(SPACING_SMALL)
        primary_controls_layout.addWidget(self._help_btn)
        primary_controls_layout.addWidget(self.chart_view)
        primary_controls_layout.addWidget(self.view_mode)
        primary_controls_layout.addWidget(self.heat_toggle)

        self._header_badges = QWidget(self)
        badge_layout = QHBoxLayout(self._header_badges)
        badge_layout.setContentsMargins(0, 0, 0, 0)
        badge_layout.setSpacing(SPACING_SMALL)
        badge_layout.addWidget(self._mode_badge)
        badge_layout.addWidget(self._models_btn)
        badge_layout.addWidget(self._viz_badge)

        row1.addWidget(self.title)
        row1.addWidget(self.rank_chip)
        row1.addStretch(1)
        row1.addWidget(self._header_primary_controls)
        row1.addWidget(self._header_badges)
        row1.addWidget(self._header_more_btn)
        row1.addWidget(self._view_label)
        row1.addWidget(self.detail_level)
        row1.addWidget(self.focus_btn)
        row1.addWidget(self.export_btn)

        self._provenance_label = QLabel("", self)
        self._provenance_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._provenance_label.setStyleSheet("color: palette(mid); font-size: 10px;")
        self._provenance_copy_btn = QToolButton(self)
        self._provenance_copy_btn.setText("Copy")
        self._provenance_copy_btn.setObjectName("SecondaryButton")
        self._provenance_copy_btn.setToolTip("Copy full provenance JSON to clipboard")
        self._provenance_copy_btn.clicked.connect(self._copy_provenance_to_clipboard)
        self._provenance_strip = QWidget(self)
        prov_layout = QHBoxLayout(self._provenance_strip)
        prov_layout.setContentsMargins(0, 0, 0, 0)
        prov_layout.setSpacing(6)
        prov_layout.addWidget(self._provenance_label)
        prov_layout.addWidget(self._provenance_copy_btn)
        self._provenance_strip.setVisible(False)

        header_layout.addLayout(row1)
        layout.addWidget(header_container)

        # ---- Decision summary (scrollable) + provenance strip ----
        self.summary = DecisionDetailsPanel(self)
        self._summary_scroll = QScrollArea(self)
        self._summary_scroll.setWidgetResizable(True)
        self._summary_scroll.setFrameShape(QFrame.NoFrame)
        self._summary_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._summary_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self._summary_scroll.setWidget(self.summary)
        self._summary_scroll.setMinimumHeight(0)
        self._summary_scroll.setMaximumHeight(260)
        self._summary_scroll.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)
        self._summary_scroll.setVisible(False)

        self._decision_summary_toggle = QToolButton(self)
        self._decision_summary_toggle.setObjectName("DecisionSummaryToggle")
        self._decision_summary_toggle.setCheckable(True)
        self._decision_summary_toggle.setChecked(False)
        self._decision_summary_toggle.setAutoRaise(True)
        self._decision_summary_toggle.setToolTip("Show decision readiness details")
        self._decision_summary_toggle.toggled.connect(self._on_decision_details_toggled)
        self._decision_summary_toggle.setStyleSheet(
            "QToolButton { padding: 0px; color: palette(window-text); font-size: 11px; font-weight: 700; }"
        )
        self._decision_summary_line = "Decision readiness: —"
        self._update_decision_summary_toggle_text()

        self._summary_row = QWidget(self)
        summary_outer = QVBoxLayout(self._summary_row)
        summary_outer.setContentsMargins(0, 0, 0, 0)
        summary_outer.setSpacing(6)

        summary_header = QHBoxLayout()
        summary_header.setContentsMargins(0, 0, 0, 0)
        summary_header.setSpacing(SPACING_SMALL)
        summary_header.addWidget(self._decision_summary_toggle)
        summary_header.addStretch(1)
        summary_header.addWidget(self._provenance_strip)
        summary_outer.addLayout(summary_header)
        summary_outer.addWidget(self._summary_scroll)

        layout.addWidget(self._summary_row)

        self._gate_banner = QLabel("", self)
        self._gate_banner.setWordWrap(True)
        self._gate_banner.setStyleSheet(
            "QLabel { padding: 6px 8px; border-radius: 6px; "
            "background: palette(highlight); color: palette(highlighted-text); "
            "font-size: 11px; }"
        )
        self._gate_banner.hide()
        layout.addWidget(self._gate_banner)

        # Run context chips
        self._run_chip_row = QWidget(self)
        run_layout = FlowLayout(self._run_chip_row, hspacing=8, vspacing=6)
        run_layout.setContentsMargins(0, 4, 0, 0)
        self._run_chips: list[QLabel] = []
        self._run_chip_row.hide()
        layout.addWidget(self._run_chip_row)

        header_divider = QFrame(self)
        header_divider.setFrameShape(QFrame.HLine)
        header_divider.setObjectName("HelixDivider")
        self._header_divider = header_divider
        layout.addWidget(header_divider)

        # Metadata chips (project / sample / author)
        self._meta_chip_row = QWidget(self)
        meta_layout = QHBoxLayout(self._meta_chip_row)
        meta_layout.setContentsMargins(0, 0, 0, 0)
        meta_layout.setSpacing(SPACING_SMALL)

        def _make_meta_chip() -> QLabel:
            chip = QLabel(self._meta_chip_row)
            chip.setStyleSheet(
                "border-radius: 999px; padding: 2px 8px; "
                "background: palette(base); "
                "border: 1px solid palette(mid); "
                "font-size: 11px; color: palette(window-text);"
            )
            chip.hide()
            return chip

        self._meta_project_chip = _make_meta_chip()
        self._meta_sample_chip = _make_meta_chip()
        self._meta_author_chip = _make_meta_chip()
        self._meta_index_label = QLabel("", self)
        self._meta_index_label.setStyleSheet("color: palette(mid); font-size: 11px;")
        self._meta_index_label.hide()

        for chip in (self._meta_project_chip, self._meta_sample_chip, self._meta_author_chip):
            meta_layout.addWidget(chip)
        meta_layout.addWidget(self._meta_index_label)

        self._meta_chip_row.hide()
        layout.addWidget(self._meta_chip_row)

        # ---- Main area: chart vs details split ----
        vsplit = QSplitter(Qt.Vertical, self)

        # Chart panel
        chart_panel = QWidget(self)
        cp_layout = QVBoxLayout(chart_panel)
        cp_layout.setContentsMargins(0, 0, 0, 0)
        cp_layout.setSpacing(SPACING_SMALL)
        self._audit_ribbon = AuditRibbon(chart_panel)
        self._audit_ribbon.hide()
        self._audit_ribbon.clicked.connect(self._jump_to_first_blocker)
        cp_layout.addWidget(self._audit_ribbon)
        self.chart_legend = QLabel(self._chart_legend_text(0), self)
        self.chart_legend.setStyleSheet("color: palette(mid); font-size: 11px;")
        cp_layout.addWidget(self.chart_legend)
        self.tier_legend = TierLegendRow(self)
        self.tier_legend.setVisible(False)
        cp_layout.addWidget(self.tier_legend)
        self.outcome_legend = OutcomeLegendRow(self)
        cp_layout.addWidget(self.outcome_legend)
        self._pathway_mix_label = QLabel("", self)
        self._pathway_mix_label.setStyleSheet("color: palette(mid); font-size: 10px;")
        self._pathway_mix_label.setVisible(False)
        cp_layout.addWidget(self._pathway_mix_label)
        self.chart_hint = QLabel("Lanes are visual only; vertical offset is for readability, not biology.", self)
        self.chart_hint.setStyleSheet("color: palette(mid); font-size: 10px;")
        self.chart_hint.setVisible(False)
        cp_layout.addWidget(self.chart_hint)

        self.filters = FilterWidget(self)
        cp_layout.addWidget(self.filters)
        self.chart_stack = QStackedLayout()
        self.chart_prob = OutcomeProbabilityChartWidget(self)
        self.chart_pos = OutcomeChartWidget(self)
        self.chart_prob.outcomeSelected.connect(lambda oid: self._on_outcome_selected(oid, user=True))
        self.chart_pos.outcomeSelected.connect(lambda oid: self._on_outcome_selected(oid, user=True))
        self.chart_prob.outcomeHovered.connect(self._on_chart_hovered)
        self.chart_pos.outcomeHovered.connect(self._on_chart_hovered)
        self.chart_prob.exploratoryAckRequested.connect(self._ack_exploratory_colors)
        self.chart_pos.exploratoryAckRequested.connect(self._ack_exploratory_colors)
        self.chart_stack.addWidget(self.chart_prob)
        self.chart_stack.addWidget(self.chart_pos)

        chart_holder = QWidget(self)
        chart_holder.setLayout(self.chart_stack)
        cp_layout.addWidget(chart_holder, stretch=2)

        self._iteration_panel = IterationTracePanel(self)
        cp_layout.addWidget(self._iteration_panel)

        self.heat_widget = OffTargetHeatWidget(self)
        self.heat_widget.setVisible(False)
        cp_layout.addWidget(self.heat_widget)
        self.heat_caption = QLabel("Off-target heat: brighter = higher predicted off-target risk at this locus.", self)
        self.heat_caption.setStyleSheet("color: palette(mid); font-size: 11px;")
        self.heat_caption.setVisible(False)
        cp_layout.addWidget(self.heat_caption)

        # Core state
        self._data: OutcomeExplorerData | None = None
        self._last_filter = (0.0, "all", "probability", "all")
        self._current_selection: OutcomeSelection | None = None
        self._last_selection_per_run: dict[int | str, OutcomeSelection] = {}
        self._rank: int | None = None
        self._rank_total: int | None = None
        self._backend_name: str | None = None
        self._backend_kind: str | None = None
        self._engine_info: EngineInfo | None = None
        self._heat_layer: dict | None = None
        self._perf_simple = False
        self._baseline_overlay: OutcomeExplorerData | None = None
        self._current_run_label: str | None = None
        self._baseline_label: str | None = None
        self._focus_mode = False
        self._inspect_mode = False
        self._inspect_prev_heat_enabled: bool | None = None
        self._run_list: list[tuple[str, str | None]] = []
        self._parent_map: dict[str, str] = {}
        self._has_children: dict[str, bool] = {}
        self._run_select_handler = None
        self._physics_overlay_enabled = False
        self._sequence_context_mode = "current"
        self._prob_mass_total = 0.0
        self._prob_mass_highlight = 0.0
        self._posterior_payload: Mapping[str, Any] | None = None
        self._window_offtarget_proxy_cache_key: str | None = None
        self._window_offtarget_proxy_cache: dict[str, Any] | None = None

        self.chart_stack.setCurrentIndex(0)
        self._on_chart_view_changed(0)

        # Details panel (split inspector/table)
        details_split = QSplitter(Qt.Horizontal, self)
        details_split.setChildrenCollapsible(False)

        inspector_container = QScrollArea(self)
        inspector_container.setFrameShape(QFrame.NoFrame)
        inspector_container.setWidgetResizable(True)
        self.details = OutcomeDetailsCard(self)
        self.details.setMinimumWidth(320)
        inspector_container.setWidget(self.details)

        table_container = QWidget(self)
        table_layout = QVBoxLayout(table_container)
        table_layout.setContentsMargins(0, 0, 0, 0)
        table_layout.setSpacing(4)
        self.table = OutcomeTable(self)
        self.table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        table_layout.addWidget(self.table)
        control_row = QHBoxLayout()
        control_row.setContentsMargins(0, 0, 0, 0)
        control_row.setSpacing(6)
        self._overlay_toggle = QCheckBox("Overlay baseline/candidate", table_container)
        self._overlay_toggle.setObjectName("OverlayToggle")
        self._overlay_toggle.setVisible(False)
        self._overlay_toggle.setToolTip("Overlay baseline run from Compare on this chart.")
        self._overlay_toggle.toggled.connect(self._apply_overlay)
        control_row.addWidget(self._overlay_toggle, alignment=Qt.AlignLeft)
        self._dim_tier_toggle = QCheckBox("Dim Tier 3+", table_container)
        self._dim_tier_toggle.setObjectName("DimTierToggle")
        self._dim_tier_toggle.setToolTip("Gray out Tier 3+ outcomes in exploratory mode.")
        dim_pref = True
        try:
            raw_pref = self._settings.value("outcomeExplorer/dimTier3Plus", True)
            if isinstance(raw_pref, str):
                dim_pref = raw_pref.strip().lower() not in {"0", "false", "no", "off", ""}
            else:
                dim_pref = bool(raw_pref)
        except Exception:
            dim_pref = True
        self._dim_tier_toggle.setChecked(dim_pref)
        self._dim_tier_toggle.setVisible(False)
        self._dim_tier_toggle.toggled.connect(self.table.set_dim_tier3_plus)
        self._dim_tier_toggle.toggled.connect(
            lambda v: self._settings.setValue("outcomeExplorer/dimTier3Plus", bool(v))
        )
        control_row.addWidget(self._dim_tier_toggle, alignment=Qt.AlignLeft)
        control_row.addStretch(1)
        self._overlay_legend = QWidget(table_container)
        self._overlay_legend.setObjectName("OverlayLegend")
        legend_layout = QHBoxLayout(self._overlay_legend)
        legend_layout.setContentsMargins(0, 0, 0, 0)
        legend_layout.setSpacing(8)
        self._legend_candidate = QLabel("", self._overlay_legend)
        self._legend_baseline = QLabel("", self._overlay_legend)
        legend_layout.addWidget(self._legend_candidate)
        legend_layout.addWidget(self._legend_baseline)
        legend_layout.addStretch(1)
        self._overlay_legend.setVisible(False)
        control_row.addWidget(self._overlay_legend, alignment=Qt.AlignRight)
        self._mass_meter = ProbabilityMassMeter(table_container)
        control_row.addWidget(self._mass_meter, alignment=Qt.AlignRight)
        self._delta_label = QLabel("", table_container)
        self._delta_label.setStyleSheet("color: palette(mid); font-size: 11px;")
        control_row.addWidget(self._delta_label, alignment=Qt.AlignRight)
        self._delta_detail_label = QLabel("", table_container)
        self._delta_detail_label.setStyleSheet("color: palette(mid); font-size: 10px;")
        control_row.addWidget(self._delta_detail_label, alignment=Qt.AlignRight)
        self._cut_minus_btn = QPushButton("Cut −1 bp", table_container)
        self._cut_minus_btn.setObjectName("TertiaryButton")
        self._cut_minus_btn.clicked.connect(lambda: self._on_cut_shift_step(-1))
        self._cut_plus_btn = QPushButton("Cut +1 bp", table_container)
        self._cut_plus_btn.setObjectName("TertiaryButton")
        self._cut_plus_btn.clicked.connect(lambda: self._on_cut_shift_step(+1))
        self._cut_reset_btn = QPushButton("Reset", table_container)
        self._cut_reset_btn.setObjectName("TertiaryButton")
        self._cut_reset_btn.clicked.connect(lambda: self._on_cut_shift_step(0, absolute=True))
        control_row.addWidget(self._cut_minus_btn, alignment=Qt.AlignRight)
        control_row.addWidget(self._cut_plus_btn, alignment=Qt.AlignRight)
        control_row.addWidget(self._cut_reset_btn, alignment=Qt.AlignRight)
        self._strand_flip_btn = QPushButton("Flip strand", table_container)
        self._strand_flip_btn.setObjectName("TertiaryButton")
        self._strand_flip_btn.setEnabled(False)
        self._strand_flip_btn.setToolTip("Requires recompute provider; no heuristic strand flip.")
        self._strand_flip_btn.clicked.connect(self._on_strand_flip)
        control_row.addWidget(self._strand_flip_btn, alignment=Qt.AlignRight)
        self._export_chart_btn = QPushButton("Export chart PNG", table_container)
        self._export_chart_btn.setObjectName("SecondaryButton")
        self._export_chart_btn.setMinimumHeight(26)
        self._export_chart_btn.setMaximumHeight(26)
        self._export_chart_btn.clicked.connect(self._export_chart_png)
        control_row.addWidget(self._export_chart_btn, alignment=Qt.AlignRight)
        table_layout.addLayout(control_row)

        self._prime_inspector = PrimeInspector(table_container)
        self._prime_inspector.hide()
        table_layout.addWidget(self._prime_inspector)

        details_split.addWidget(inspector_container)
        details_split.addWidget(table_container)
        details_split.setStretchFactor(0, 2)
        details_split.setStretchFactor(1, 5)

        vsplit.addWidget(chart_panel)
        # Sequence context (focus mode only)
        self._sequence_context = SequenceContextWidget(self)
        self._sequence_context.setVisible(False)
        vsplit.addWidget(self._sequence_context)
        vsplit.addWidget(details_split)
        vsplit.setStretchFactor(0, 7)
        vsplit.setStretchFactor(2, 3)

        # Make the main split area the flexible part of the layout so short
        # viewports preserve the boss-signal banner + decision rows.
        layout.addWidget(vsplit, stretch=1)
        self._vsplit = vsplit
        self._details_split = details_split
        self._apply_view_mode("balanced")

        self.filters.filtersChanged.connect(self._on_filters_changed)
        self.table.outcomeSelected.connect(lambda oid: self._on_outcome_selected(oid, user=True))
        self.table.outcomeHovered.connect(self._on_table_hovered)
        self.details.outcomeSelected.connect(self.outcomeSelected.emit)
        self.details.designPcrRequested.connect(self.designPcrRequested.emit)

        # Timeline scrubber (focus mode only)
        self._timeline = RunTimelineWidget(self)
        self._timeline.runSelected.connect(self._on_timeline_selected)
        self._timeline.overlaySelected.connect(self._on_overlay_selected)
        self._timeline.physicsToggled.connect(self._on_physics_toggled)
        self._timeline.lensChanged.connect(self._on_lens_changed)
        self._timeline.seqModeChanged.connect(self._on_seq_mode_changed)
        self._timeline.cloneRequested.connect(self._on_clone_requested)
        self._timeline.setVisible(False)
        layout.addWidget(self._timeline)

        # Restore detail level (progressive disclosure by intent).
        level = ""
        try:
            level = str(self._settings.value("outcomeExplorer/detailLevel", "") or "").strip().lower()
        except Exception:
            level = ""
        if level not in {"overview", "analysis", "debug"}:
            # Back-compat: older builds persisted "inspectMode" only.
            inspect_enabled = False
            try:
                inspect_enabled = bool(self._settings.value("outcomeExplorer/inspectMode", False))
            except Exception:
                inspect_enabled = False
            # Default to Analysis for interactive work; Overview is explicitly user-selected.
            level = "analysis" if inspect_enabled else "analysis"
        try:
            self._set_detail_level(level, persist=False)
        except Exception:
            pass

        self._apply_probability_mode()

        self.setFocusPolicy(Qt.StrongFocus)

    def _apply_exploratory_visual_state(self) -> None:
        try:
            exploratory = self._effective_decision_mode() != "decision_grade"
        except Exception:
            exploratory = True
        always_show = self._always_show_exploratory_color_pref()
        effective_ack = bool(always_show or self._exploratory_color_ack)
        try:
            self.chart_prob.set_exploratory_mode(exploratory, color_acknowledged=effective_ack)
        except Exception:
            pass
        try:
            self.chart_pos.set_exploratory_mode(exploratory, color_acknowledged=effective_ack)
        except Exception:
            pass
        try:
            self.outcome_legend.set_muted(exploratory and (not effective_ack))
        except Exception:
            pass

    def _ack_exploratory_colors(self) -> None:
        # Explicit click-through: default is muted/gray; user must opt in to saturated colors.
        self._exploratory_color_ack = True
        key = self._exploratory_color_ack_key
        if key:
            self._exploratory_color_ack_by_key[key] = True
        self._apply_exploratory_visual_state()

    def _always_show_exploratory_color_pref(self) -> bool:
        try:
            return bool(self._settings.value("outcomeExplorer/alwaysShowExploratoryColor", False))
        except Exception:
            return False

    def _exploratory_ack_key_for_data(self, data: OutcomeExplorerData | None) -> str | None:
        if data is None:
            return None
        fp = (
            getattr(data, "fingerprint", None)
            or getattr(data, "semantic_hash", None)
            or getattr(data, "view_hash", None)
            or getattr(data, "policy_hash", None)
        )
        rid = getattr(data, "run_id", None)
        gid = str(getattr(data, "guide_id", "") or "")
        if rid is None and not gid and not fp:
            return None
        base = f"{rid}:{gid}"
        return f"{base}:{fp}" if fp else base

    def _sync_exploratory_color_ack_for_data(self, data: OutcomeExplorerData | None) -> None:
        key = self._exploratory_ack_key_for_data(data)
        if key == self._exploratory_color_ack_key:
            return
        self._exploratory_color_ack_key = key
        self._exploratory_color_ack = bool(self._exploratory_color_ack_by_key.get(key, False)) if key else False

    def refresh_preferences(self) -> None:
        """Refresh preference-driven visual state (safe to call globally)."""
        self._apply_exploratory_visual_state()
        self.update()

    def minimumSizeHint(self) -> QSize:  # type: ignore[override]
        # Keep this widget shrinkable so the Studio window can adapt to laptop
        # screens and DPI scaling changes (sidebars can collapse as needed).
        return QSize(320, 240)

    def set_focus_mode(self, enabled: bool) -> None:
        """
        Focus mode hides the inspector/table stack and lets the chart fill space.
        """
        if self._focus_mode == enabled:
            return
        self._focus_mode = enabled
        try:
            if hasattr(self, "focus_btn") and self.focus_btn is not None:
                self.focus_btn.blockSignals(True)
                self.focus_btn.setChecked(bool(enabled))
                self.focus_btn.blockSignals(False)
        except Exception:
            pass
        try:
            if enabled:
                self._details_split.hide()
                self._vsplit.setStretchFactor(0, 1)
            else:
                self._details_split.show()
                self._vsplit.setStretchFactor(0, 7)
                self._vsplit.setStretchFactor(2, 3)
        except Exception:
            pass
        try:
            self._timeline.setVisible(enabled and bool(self._run_list))
        except Exception:
            pass
        self._refresh_sequence_context()

    def _request_global_focus_mode(self, enabled: bool) -> None:
        """
        Request main-window focus mode so the outcome explorer can own horizontal space
        (collapse side panels + console) without forcing users to remember F11.
        """
        win = self.window()
        action = getattr(win, "_focus_action", None)
        if isinstance(action, QAction):
            try:
                action.setChecked(bool(enabled))
                return
            except Exception:
                pass
        setter = getattr(win, "_set_focus_mode", None)
        if callable(setter):
            try:
                setter(bool(enabled))
            except Exception:
                pass
            return
        # Standalone embedding fallback: at least focus the explorer layout.
        try:
            self.set_focus_mode(bool(enabled))
        except Exception:
            pass

    def _on_timeline_selected(self, run_id: str) -> None:
        handler = getattr(self, "_run_select_handler", None)
        if callable(handler):
            try:
                handler(run_id)
            except Exception:
                pass

    def _on_overlay_selected(self, run_id: str) -> None:
        self.compareRunRequested.emit(run_id)

    def _on_physics_toggled(self, enabled: bool) -> None:
        self._physics_overlay_enabled = bool(enabled)
        self._apply_physics_overlay()

    def _on_lens_changed(self, lens: str) -> None:
        self._lens = lens
        try:
            self.chart_prob.set_lens(lens)
            self.chart_prob.update()
        except Exception:
            pass

    def _on_seq_mode_changed(self, mode: str) -> None:
        self._sequence_context_mode = mode
        try:
            self._sequence_context.set_mode(mode)
        except Exception:
            pass
        self._refresh_sequence_context()

    def _on_clone_requested(self, run_id: str) -> None:
        # Separate signal for cloning; consumers can prefill builder.
        try:
            if hasattr(self, "cloneRunRequested"):
                self.cloneRunRequested.emit(run_id)  # type: ignore[attr-defined]
            else:
                self.compareRunRequested.emit(run_id)
        except Exception:
            pass

    def _build_physics_hints(self, bar: OutcomeBar | None) -> list[str]:
        if bar is None or not self._physics_overlay_enabled:
            return []
        hints: list[str] = []
        is_prime = self._is_prime_run() or (bar.run_kind and "prime" in str(bar.run_kind).lower())
        try:
            if is_prime:
                hints.extend(PrimePhysicsExplainer.explain(self._prime_meta, self._current_sequence_ctx, bar))
            else:
                if bar.frameshift:
                    hints.append("Frameshift outcome; indel shifts reading frame")
                if bar.delta_bp <= -5:
                    hints.append("Large deletion—microhomology may stabilize this cut")
                if "insertion" in bar.category.lower():
                    hints.append("Insertion-heavy; local GC clamp could stabilize")
            overlay_values = getattr(self, "_overlay_values", None)
            if overlay_values is None and hasattr(self, "chart_pos"):
                overlay_values = getattr(self.chart_pos, "_overlay_values", None)
            if overlay_values and bar.label in overlay_values:
                base = overlay_values.get(bar.label, 0.0)
                delta = bar.probability - base
                if str(getattr(self, "_decision_mode", "filter_only")) == "decision_grade":
                    if abs(delta) >= 0.05:
                        direction = "higher" if delta > 0 else "lower"
                        hints.append(f"{abs(delta)*100:.1f}% {direction} than baseline")
            if bar.evidence:
                hints.append("Evidence: " + ", ".join(bar.evidence))
            else:
                hints.append("Resolution evidence missing; treat as probabilistic claim")
            if any("conflicting evidence" in issue for issue in bar.schema_issues):
                hints.append("Conflicting evidence; do not average or smooth claims")
            if bar.calibration == CalibrationBadge.UNKNOWN:
                hints.append("Calibration unknown; treat visuals as heuristic")
            else:
                hints.append(f"Calibration: {bar.calibration.value}")
        except Exception:
            pass
        return hints

    # Sequence context helpers ----------------------------------------
    def _build_sequence_context(self, bar: OutcomeBar | None) -> Optional[SequenceContext]:
        if bar is None or self._data is None:
            return None
        ref = self._data.sequence or ""
        if not ref:
            return None
        cut = getattr(self._data, "cut_index", len(ref) // 2)
        edit_start = int(bar.pos_range[0]) if bar.pos_range else cut
        edit_end = int(bar.pos_range[1]) if bar.pos_range else edit_start

        alt = self._apply_edit_to_sequence(ref, edit_start, bar.delta_bp, bar.replacement)

        # baseline alt if available
        base_alt = None
        base_label = None
        if self._baseline_overlay is not None:
            base_bar = next((b for b in self._baseline_overlay.bars if b.label == bar.label), None)
            if base_bar is not None:
                base_alt = self._apply_edit_to_sequence(ref, edit_start, base_bar.delta_bp, base_bar.replacement)
                base_label = self._baseline_label

        pbs_len = None
        rtt_len = None
        nick_index = cut
        pbs_span = None
        rtt_span = None
        pbs_seq = None
        rtt_seq = None
        try:
            if isinstance(self._evs, dict):
                cfg = self._evs.get("config", {}) if isinstance(self._evs.get("config"), dict) else {}
                peg = cfg.get("prime") or cfg.get("peg") or self._evs.get("peg")
                if isinstance(peg, dict):
                    pbs = peg.get("pbs") or ""
                    rtt = peg.get("rtt") or ""
                    pbs_seq = pbs if isinstance(pbs, str) else None
                    rtt_seq = rtt if isinstance(rtt, str) else None
                    pbs_len = len(pbs_seq) if pbs_seq else None
                    rtt_len = len(rtt_seq) if rtt_seq else None
                    nick_index = peg.get("nick_index", nick_index)
                    # naive spans relative to cut: PBS upstream, RTT downstream
                    if pbs_len:
                        pbs_span = (max(0, cut - pbs_len), cut)
                    if rtt_len:
                        rtt_span = (cut, min(len(ref), cut + rtt_len))
        except Exception:
            pass

        # window around cut
        radius = 40
        start = max(0, cut - radius)
        end = min(len(ref), cut + radius)
        ref_window = ref[start:end]
        alt_window = alt[start:end] if alt else ref_window
        base_window = base_alt[start:end] if base_alt else None
        cut_idx = cut - start
        edit_start_rel = max(0, edit_start - start)
        edit_end_rel = max(edit_start_rel, min(len(ref_window), edit_end - start))

        # keep a simple prime meta object for physics hints
        self._prime_meta = PrimeMeta(
            rtt_sequence=rtt_seq,
            pbs_sequence=pbs_seq,
            pbs_length=pbs_len,
            rtt_span=(rtt_span[0] - start, rtt_span[1] - start) if rtt_span else None,
            pbs_span=(pbs_span[0] - start, pbs_span[1] - start) if pbs_span else None,
            nick_index=nick_index - start if nick_index is not None else None,
        ) if (pbs_seq or rtt_seq or pbs_len or rtt_len) else None

        return SequenceContext(
            ref_window=ref_window,
            alt_window=alt_window,
            cut_index=cut_idx,
            edit_start=edit_start_rel,
            edit_end=edit_end_rel,
            label=bar.label,
            baseline_alt_window=base_window,
            baseline_label=base_label,
            pbs_len=pbs_len,
            rtt_len=rtt_len,
            pbs_sequence=pbs_seq,
            rtt_sequence=rtt_seq,
            nick_index=nick_index - start if nick_index is not None else None,
            pbs_span=(pbs_span[0] - start, pbs_span[1] - start) if pbs_span else None,
            rtt_span=(rtt_span[0] - start, rtt_span[1] - start) if rtt_span else None,
        )

    def _apply_edit_to_sequence(self, ref: str, start: int, delta_bp: int, replacement: Optional[str]) -> str:
        start = max(0, min(len(ref), start))
        if delta_bp is None:
            delta_bp = 0
        if delta_bp < 0:
            end = max(start, min(len(ref), start + abs(delta_bp)))
            return ref[:start] + ref[end:]
        if delta_bp > 0:
            ins = replacement if isinstance(replacement, str) and replacement else "N" * delta_bp
            return ref[:start] + ins + ref[start:]
        return ref

    def _apply_physics_overlay(self) -> None:
        """
        Simple physics hint: show/hide off-target heat layer as overlay stand-in.
        Future work can add richer annotations; this keeps UI responsive now.
        """
        if self._heat_layer is None:
            # Nothing to show
            self.heat_widget.setVisible(False)
            self.heat_caption.setVisible(False)
            return
        self.heat_widget.setVisible(self._physics_overlay_enabled)
        self.heat_caption.setVisible(self._physics_overlay_enabled)
        if self._physics_overlay_enabled:
            self._heat_layer["visible"] = True
            self._update_offtarget_heat()
        else:
            self._heat_layer["visible"] = False
            self._update_offtarget_heat()

    def _help_text(self) -> str:
        label = _value_label_lower(self._probability_mode)
        return (
            f"This view summarizes outcome {label}s for a run. "
            "Hover bars/rows to inspect; click to lock. Mode and comparability are shown in the banner."
        )

    def _show_help(self) -> None:
        try:
            QMessageBox.information(self, "Outcome Explorer", self._help_text())
        except Exception:
            pass

    def _format_prob_value(self, value: float, *, digits: int = 1, annotate: bool = True) -> str:
        # In non-decision-grade mode, suppress quantitative-looking values entirely.
        # If we ever support synthetic numeric demos, that mode must be explicitly
        # labeled and enforced at the data model/export layers.
        if str(getattr(self, "_decision_mode", "filter_only")) != "decision_grade":
            return "suppressed"
        return _format_value(value, mode=self._probability_mode, digits=digits, annotate=annotate)

    def _chart_legend_text(self, idx: int) -> str:
        # Keep copy minimal; mode/comparability are already carried by the global banner.
        if idx == 1:
            # One-line story compression for the rail schematic.
            return "Predicted edit outcomes ranked by repair mechanism and risk tier"

        if self._decision_mode == "filter_only":
            return "Bars show outcome tiers (ordinal). Click a bar to inspect details."

        plural = _value_label_plural(self._probability_mode)
        return f"Bars show per-outcome {plural}. Click a bar to inspect details."

    def _apply_probability_mode(self) -> None:
        mode = self._probability_mode
        try:
            decision_mode = self._effective_decision_mode()
        except Exception:
            decision_mode = "filter_only"
        quantitative_allowed = bool(decision_mode == "decision_grade")
        try:
            if hasattr(self, "chart_view") and self.chart_view.count() > 0:
                self.chart_view.setItemText(0, f"Outcome {_value_label_plural(mode)}")
        except Exception:
            pass
        try:
            self.filters.set_value_mode(mode)
            self.filters.set_quantitative_allowed(quantitative_allowed)
        except Exception:
            pass
        try:
            self.table.set_value_mode(mode)
            self.table.set_quantitative_allowed(quantitative_allowed)
        except Exception:
            pass
        try:
            self.chart_prob.set_value_mode(mode)
        except Exception:
            pass
        try:
            self.chart_pos.set_value_mode(mode)
        except Exception:
            pass
        try:
            if hasattr(self, "details"):
                self.details.set_value_mode(mode)
                self.details.set_quantitative_allowed(quantitative_allowed)
        except Exception:
            pass
        try:
            if hasattr(self, "chart_legend"):
                idx = self.chart_stack.currentIndex() if hasattr(self, "chart_stack") else 0
                self.chart_legend.setText(self._chart_legend_text(idx))
        except Exception:
            pass
        try:
            self._apply_exploratory_visual_state()
        except Exception:
            pass
        try:
            self._update_contract_badges()
        except Exception:
            pass
        try:
            self._update_domain_badge()
        except Exception:
            pass
        try:
            if hasattr(self, "_mass_meter") and self._mass_meter is not None:
                self._mass_meter.set_quantitative_allowed(quantitative_allowed)
                self._mass_meter.setVisible(bool(quantitative_allowed))
        except Exception:
            pass
        try:
            if hasattr(self, "tier_legend") and self.tier_legend is not None:
                self.tier_legend.setVisible(not quantitative_allowed)
        except Exception:
            pass
        try:
            if hasattr(self, "_dim_tier_toggle") and self._dim_tier_toggle is not None:
                self._dim_tier_toggle.setVisible(not quantitative_allowed)
                self.table.set_dim_tier3_plus(bool(self._dim_tier_toggle.isChecked()))
        except Exception:
            pass

    def _refresh_decision_authority_banner(self, contract: Mapping[str, Any] | None = None) -> None:
        ribbon = getattr(self, "_audit_ribbon", None)
        if ribbon is None:
            return
        if contract is None:
            contract = self._run_summary_v2()
        contract = contract if isinstance(contract, Mapping) else {}

        decision_mode = str(getattr(self, "_decision_mode", "filter_only") or "filter_only")
        validity = contract.get("validity") if isinstance(contract.get("validity"), Mapping) else {}
        verdict = contract.get("verdict") if isinstance(contract.get("verdict"), Mapping) else {}

        decision = str(verdict.get("decision") or "").strip().lower()
        decision_txt = self._decision_label(decision)
        grade = str(verdict.get("grade") or "").strip().upper()
        grade_headline = str(verdict.get("headline") or "").strip()

        artifact_valid = getattr(self, "_artifact_valid", True)
        decision_mode_eligible = bool(getattr(self, "_decision_mode_eligible", False))
        is_artifact_ok = artifact_valid is not False
        is_decision_mode = bool(decision_mode == "decision_grade" and decision_mode_eligible and is_artifact_ok)
        decision_ready = bool(is_decision_mode and decision in {"go", "no_go"})

        accent_go = QColor(32, 194, 128)
        accent_stop = QColor(220, 70, 70)
        accent_explore = QColor(246, 186, 90)

        def _is_demo_run() -> bool:
            run = getattr(self, "_current_run", None)
            meta = None
            if isinstance(run, Mapping):
                meta_raw = run.get("metadata")
                meta = meta_raw if isinstance(meta_raw, Mapping) else None
            elif run is not None:
                meta_raw = getattr(run, "metadata", None)
                meta = meta_raw if isinstance(meta_raw, Mapping) else None
            if isinstance(meta, Mapping) and str(meta.get("scenario") or "").strip().lower() == "demo":
                return True
            evs = getattr(self, "_evs", None)
            if isinstance(evs, Mapping):
                cfg = evs.get("config") if isinstance(evs.get("config"), Mapping) else {}
                meta2 = cfg.get("metadata") if isinstance(cfg.get("metadata"), Mapping) else {}
                preset_id = str(meta2.get("preset_id") or "").strip().lower()
                if preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"):
                    return True
            return False

        is_demo = _is_demo_run()

        proceed = bool(is_decision_mode and decision == "go")
        if not is_artifact_ok:
            verb = "STOP"
            accent = accent_stop
        elif is_decision_mode:
            verb = "PROCEED" if proceed else "STOP"
            accent = accent_go if proceed else accent_stop
        else:
            verb = ui_mode_label(decision_mode=decision_mode, is_demo=is_demo)
            accent = accent_explore

        # Context/mode line: always explicit about exploratory vs decision-grade comparability.
        mode_line = ""
        if getattr(self, "_artifact_valid", True) is False:
            mode_line = "Run blocked — artifact invalid (decision disabled)."
        elif is_decision_mode:
            if grade and grade_headline:
                mode_line = f"Grade {grade} — {grade_headline}"
            elif grade:
                mode_line = f"Grade {grade}"
            elif grade_headline:
                mode_line = grade_headline
            elif decision_txt:
                mode_line = f"Decision: {decision_txt}"
        else:
            value_label = _value_label_plural(getattr(self, "_probability_mode", "score"))
            mode_line = f"Outcome {value_label} — non-comparable"

        def _blocker_from_row(row: DecisionDetailRow) -> str:
            label = str(row.label or "").strip()
            val = str(row.value or "").strip()
            if not label:
                return ""
            if label == "Decision grade":
                return "Not decision grade"
            if label == "Run validity":
                return "Run invalid" if row.blocks else ""
            if label == "Policy":
                return "Policy noncompliant" if row.blocks else ""
            if label in {"Uncertainty", "Off-target risk", "Splice risk", "Regulatory risk"}:
                return f"{label} not computed" if row.blocks else ""
            if label == "Intended edit spec":
                if not row.blocks:
                    return ""
                if "not specified" in val.lower() or "missing" in val.lower():
                    return "Intended edit spec missing"
                return "Intended edit spec incomplete"
            if label == "Claims":
                if not row.blocks:
                    return ""
                if "dirty" in val.lower():
                    return "Claims dirty"
                return "Claims missing"
            if label == "Species":
                return "Species unresolved" if row.blocks else ""
            if row.computed is False:
                return f"{label} missing"
            if row.blocks:
                return f"{label}: {val}" if val else label
            return ""

        blockers: list[str] = []
        full = getattr(self, "_summary_details_full", None)
        required_rows: Sequence[DecisionDetailRow] = []
        if isinstance(full, tuple) and len(full) >= 1 and isinstance(full[0], (list, tuple)):
            required_rows = full[0]
        for row in required_rows:
            if not bool(getattr(row, "blocks", False)):
                continue
            txt = _blocker_from_row(row)
            if txt:
                blockers.append(txt)

        # Decision-grade blockers that are not captured as required rows (e.g., "Insufficient evidence").
        notes = verdict.get("decision_notes") if isinstance(verdict.get("decision_notes"), list) else []

        def _label_note(note: str) -> str:
            raw = str(note or "").strip()
            if not raw:
                return ""
            if ":" in raw:
                prefix, rest = raw.split(":", 1)
                prefix = prefix.strip().lower()
                rest = rest.strip()
                if prefix == "not_decision_grade":
                    mapping = {
                        "calibration_bundle_missing": "CALIBRATION_MISSING",
                        "calibration_out_of_domain": "CALIBRATION_OUT_OF_DOMAIN",
                        "uncertainty_not_computed": "UNCERTAINTY_INCOMPLETE",
                        "provenance_incomplete": "PROVENANCE_INCOMPLETE",
                    }
                    return _label_from_root_cause(mapping.get(rest, rest))
                if prefix == "invalid":
                    return _label_from_root_cause(rest)
            return _label_from_root_cause(raw)

        if not decision_ready:
            blockers.extend([_label_note(str(n)) for n in notes if isinstance(n, str) and str(n).strip()])
        elif decision == "no_go" and not blockers:
            if grade_headline:
                blockers.append(grade_headline)
            elif decision_txt:
                blockers.append(decision_txt)

        # Tooltip can be exhaustive; banner line stays short.
        tooltip_sources: list[str] = []
        tooltip_sources.extend([_label_from_root_cause(str(c)) for c in (getattr(self, "_decision_mode_reasons", None) or [])])
        causes = validity.get("root_causes") if isinstance(validity.get("root_causes"), list) else []
        tooltip_sources.extend([_label_from_root_cause(str(c)) for c in causes])
        tooltip_sources.extend(blockers)

        seen: set[str] = set()
        blockers_dedup: list[str] = []
        for raw in blockers:
            txt = str(raw or "").strip()
            if not txt or txt in seen:
                continue
            seen.add(txt)
            blockers_dedup.append(txt)

        def _next_action_from_row(row: DecisionDetailRow) -> str:
            label = str(row.label or "").strip()
            if label == "Decision grade":
                return "Enable decision grade"
            if label == "Run validity":
                return "Resolve run artifact"
            if label == "Policy":
                return "Fix policy violations"
            if label == "Uncertainty":
                return "Compute uncertainty"
            if label == "Intended edit spec":
                return "Specify intended edit"
            if label == "Off-target risk":
                return "Compute off-target"
            if label == "Splice risk":
                return "Compute splice risk"
            if label == "Regulatory risk":
                return "Compute regulatory risk"
            if label == "Claims":
                return "Fix claims"
            if label == "Species":
                return "Resolve species"
            if label == "Iteration cap":
                return "Adjust iteration cap"
            return f"Resolve {label.lower()}" if label else ""

        next_action = ""
        first_blocking = next((r for r in required_rows if getattr(r, "blocks", False)), None)
        if first_blocking is not None:
            next_action = _next_action_from_row(first_blocking)
        elif decision == "no_go":
            next_action = "Redesign guide"
        elif decision_mode != "decision_grade":
            next_action = "Enable decision grade"

        tooltip_lines: list[str] = []
        if mode_line:
            tooltip_lines.append(mode_line)
        if tooltip_sources:
            seen_tip: set[str] = set()
            tip_items: list[str] = []
            for s in tooltip_sources:
                t = str(s or "").strip()
                if not t or t in seen_tip:
                    continue
                seen_tip.add(t)
                tip_items.append(t)
            if tip_items:
                tooltip_lines.append("")
                tooltip_lines.append("Blockers:")
                tooltip_lines.extend([f"• {t}" for t in tip_items])
        tooltip = "\n".join([l for l in tooltip_lines if l or l == ""]).strip()

        blocker_count = len(blockers_dedup)
        parts: list[str] = [verb]
        if is_decision_mode:
            if grade:
                parts.append(f"Grade {grade}")
            if decision_txt:
                parts.append(decision_txt)
        if blocker_count and (not decision_ready):
            tail = f"Evidence incomplete ({blocker_count})" if not is_decision_mode else f"Blockers ({blocker_count})"
            parts.append(tail)
        audit_line = " — ".join([p for p in parts if p])

        if not is_decision_mode:
            subtext = ui_mode_subtext(decision_mode=str(decision_mode)) or ""
            if subtext:
                tooltip = (subtext + "\n\n" + tooltip).strip() if tooltip else subtext

        ribbon.set_state(audit_line, accent=accent, tooltip=tooltip or None)

        try:
            if not is_artifact_ok:
                summary_line = "Decision readiness: Blocked (artifact invalid)"
            elif is_decision_mode and decision_ready:
                summary_line = "Decision readiness: Decision-grade"
                if blocker_count:
                    summary_line += f" ({blocker_count} blockers)"
            else:
                summary_line = "Decision readiness: Not decision-grade"
                if blocker_count:
                    summary_line += f" ({blocker_count} blockers)"
            self._decision_summary_line = summary_line
            self._update_decision_summary_toggle_text()
        except Exception:
            pass
        try:
            header = getattr(self, "_header_container", None)
            if isinstance(header, QWidget):
                header.updateGeometry()
        except Exception:
            pass

    def _jump_to_first_blocker(self) -> None:
        # Clicking the boss-signal banner is explicit intent: ensure the detail panel is visible.
        try:
            if str(getattr(self, "_detail_level", "overview")) == "overview":
                self._set_detail_level("analysis", persist=True)
        except Exception:
            pass
        try:
            self._set_decision_details_expanded(True, user=False)
        except Exception:
            pass

        try:
            # In Qt-for-Python, `QTimer.singleShot` callables can be GC-sensitive; use a
            # persistent timer to reliably land focus in headless/offscreen runs.
            timer = getattr(self, "_blocker_focus_timer", None)
            if not isinstance(timer, QTimer):
                timer = QTimer(self)
                timer.setInterval(20)
                timer.timeout.connect(self._tick_blocker_focus)  # type: ignore[attr-defined]
                self._blocker_focus_timer = timer
            try:
                timer.stop()
            except Exception:
                pass
            self._blocker_focus_attempts = 0  # type: ignore[attr-defined]
            self._blocker_focus_streak = 0  # type: ignore[attr-defined]
            timer.start()
        except Exception:
            pass

    def _update_decision_summary_toggle_text(self) -> None:
        toggle = getattr(self, "_decision_summary_toggle", None)
        if toggle is None:
            return
        arrow = "▾" if toggle.isChecked() else "▸"
        line = str(getattr(self, "_decision_summary_line", "") or "Decision readiness: —").strip()
        toggle.setText(f"{arrow} {line}")

    def _on_decision_details_toggled(self, expanded: bool) -> None:
        self._set_decision_details_expanded(bool(expanded), user=True)

    def _set_decision_details_expanded(self, expanded: bool, *, user: bool) -> None:
        scroll = getattr(self, "_summary_scroll", None)
        toggle = getattr(self, "_decision_summary_toggle", None)
        if scroll is None or toggle is None:
            return
        expanded = bool(expanded)
        try:
            toggle.blockSignals(True)
            toggle.setChecked(expanded)
            toggle.blockSignals(False)
        except Exception:
            pass
        try:
            scroll.setVisible(expanded)
        except Exception:
            pass
        self._update_decision_summary_toggle_text()

        # Persist user intent for Analysis view; Debug always auto-expands.
        if user and str(getattr(self, "_detail_level", "overview")) != "debug":
            try:
                self._settings.setValue("outcomeExplorer/decisionDetailsExpanded", bool(expanded))
            except Exception:
                pass

    def _apply_decision_details_expand_policy(self) -> None:
        level = str(getattr(self, "_detail_level", "overview") or "overview")
        if level == "debug":
            self._set_decision_details_expanded(True, user=False)
            return
        if level == "analysis":
            pref = False
            try:
                pref = bool(self._settings.value("outcomeExplorer/decisionDetailsExpanded", False))
            except Exception:
                pref = False
            self._set_decision_details_expanded(pref, user=False)
            return
        self._set_decision_details_expanded(False, user=False)

    def _focus_decision_detail_row(self, target_label: str) -> None:
        label = str(target_label or "").strip()
        if not label:
            return
        tgt = next(
            (c for c in self.summary.findChildren(QLabel, "DecisionDetailName") if c.text().strip() == label),
            None,
        )
        if tgt is None:
            return
        # Ensure the parent window is activated so focus changes stick in headless/CI runs.
        try:
            win = tgt.window()
            if isinstance(win, QWidget):
                try:
                    win.activateWindow()
                except Exception:
                    pass
                try:
                    win.raise_()
                except Exception:
                    pass
                try:
                    win.setFocus(Qt.OtherFocusReason)
                except Exception:
                    pass
        except Exception:
            pass
        scroll = getattr(self, "_summary_scroll", None)
        if isinstance(scroll, QScrollArea):
            scroll.ensureWidgetVisible(tgt, 0, 10)
        tgt.setFocus(Qt.OtherFocusReason)

    def _pick_first_blocker_label(self) -> str | None:
        full = getattr(self, "_summary_details_full", None)
        if not full or not isinstance(full, tuple) or len(full) < 1:
            return None
        required = full[0]
        if not isinstance(required, (list, tuple)):
            return None
        first_blocking = next((r for r in required if getattr(r, "blocks", False)), None)
        if first_blocking is None:
            return None
        label = str(getattr(first_blocking, "label", "") or "").strip()
        return label or None

    def _tick_blocker_focus(self) -> None:
        timer = getattr(self, "_blocker_focus_timer", None)
        if not isinstance(timer, QTimer):
            return
        attempts = int(getattr(self, "_blocker_focus_attempts", 0) or 0) + 1
        self._blocker_focus_attempts = attempts  # type: ignore[attr-defined]

        label = self._pick_first_blocker_label()
        if label:
            try:
                self._focus_decision_detail_row(label)
            except Exception:
                pass
            try:
                fw = self.focusWidget()
                if isinstance(fw, QLabel) and fw.objectName() == "DecisionDetailName" and fw.text().strip() == label:
                    streak = int(getattr(self, "_blocker_focus_streak", 0) or 0) + 1
                    self._blocker_focus_streak = streak  # type: ignore[attr-defined]
                    # Keep asserting focus for a short window: the decision panel can rebuild
                    # widgets during mode transitions, which would otherwise drop focus.
                    if attempts >= 10 and streak >= 2:
                        timer.stop()
                        return
                else:
                    self._blocker_focus_streak = 0  # type: ignore[attr-defined]
            except Exception:
                pass
        else:
            self._blocker_focus_streak = 0  # type: ignore[attr-defined]
        if attempts >= 20:
            timer.stop()

    def _update_gate_banner(self) -> None:
        banner = getattr(self, "_gate_banner", None)
        if banner is None:
            return
        # Prefer the single "decision authority" banner; keep the legacy gate banner hidden.
        try:
            banner.hide()
        except Exception:
            pass
        try:
            self._refresh_decision_authority_banner()
        except Exception:
            pass
        return

    def set_decision_mode_gate(
        self,
        *,
        valid: bool,
        decision_mode_eligible: bool,
        reasons: Sequence[str] | None = None,
    ) -> None:
        self._artifact_valid = bool(valid)
        if not self._artifact_valid:
            # New run artifacts can invalidate previous acknowledgements; reset per-run state.
            key = self._exploratory_color_ack_key
            if key:
                self._exploratory_color_ack_by_key.pop(key, None)
            self._exploratory_color_ack = False
        self._decision_mode_eligible = bool(decision_mode_eligible)
        self._decision_mode_reasons = [str(r) for r in (reasons or [])]
        self._probability_mode = "probability" if self._decision_mode_eligible else "score"
        self._apply_probability_mode()
        self._update_gate_banner()
        try:
            self._refresh_export_block()
            self._set_export_enabled(True)
        except Exception:
            pass

    def set_run_model(self, run: RunModel | None) -> None:
        """Store the current RunModel for metadata/export."""
        self._current_run = run
        posterior = None
        if isinstance(run, Mapping):
            posterior = self._extract_posterior_payload(run)
        else:
            meta = getattr(run, "metadata", None)
            if isinstance(meta, Mapping):
                if isinstance(meta.get("posterior"), Mapping):
                    posterior = meta.get("posterior")
                artifact = meta.get("run_artifact")
                if isinstance(artifact, Mapping):
                    try:
                        from helix.studio.run_artifact import (
                            artifact_is_valid,
                            artifact_root_causes,
                            artifact_decision_mode_eligible,
                        )

                        self.set_decision_mode_gate(
                            valid=artifact_is_valid(artifact),
                            decision_mode_eligible=artifact_decision_mode_eligible(artifact),
                            reasons=artifact_root_causes(artifact),
                        )
                    except Exception:
                        pass
        if posterior is not None:
            self._posterior_payload = posterior
        self._update_metadata_chips()
        self._update_search_mode_badge(run)
        self._update_contract_badges()
        self._update_provenance_strip()
        try:
            self._refresh_decision_authority_banner(self._run_summary_v2())
        except Exception:
            pass
        self._refresh_posterior_context_panel()
        self._refresh_export_block()
        self._set_export_enabled(True)

    def _run_summary_v2(self) -> Mapping[str, Any] | None:
        run = self._current_run
        meta: Mapping[str, Any] | None = None
        if isinstance(run, Mapping):
            meta_raw = run.get("metadata")
            meta = meta_raw if isinstance(meta_raw, Mapping) else None
        elif run is not None:
            meta_raw = getattr(run, "metadata", None)
            meta = meta_raw if isinstance(meta_raw, Mapping) else None
        if isinstance(meta, Mapping):
            if meta.get("invalid") or meta.get("claims_disabled"):
                return None
            summary = meta.get("run_summary")
            if isinstance(summary, Mapping):
                return summary

        # Fallback: EVS/session-state surface.
        evs = getattr(self, "_evs", None)
        if isinstance(evs, Mapping):
            cfg = evs.get("config") if isinstance(evs.get("config"), Mapping) else {}
            meta2 = cfg.get("metadata") if isinstance(cfg.get("metadata"), Mapping) else {}
            cand = meta2.get("run_summary")
            if isinstance(cand, Mapping):
                return cand
        return None

    def _is_demo_run(self) -> bool:
        run = getattr(self, "_current_run", None)
        meta = None
        if isinstance(run, Mapping):
            meta_raw = run.get("metadata")
            meta = meta_raw if isinstance(meta_raw, Mapping) else None
        elif run is not None:
            meta_raw = getattr(run, "metadata", None)
            meta = meta_raw if isinstance(meta_raw, Mapping) else None
        if isinstance(meta, Mapping) and str(meta.get("scenario") or "").strip().lower() == "demo":
            return True
        evs = getattr(self, "_evs", None)
        if isinstance(evs, Mapping):
            cfg = evs.get("config") if isinstance(evs.get("config"), Mapping) else {}
            meta2 = cfg.get("metadata") if isinstance(cfg.get("metadata"), Mapping) else {}
            preset_id = str(meta2.get("preset_id") or "").strip().lower()
            if preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"):
                return True
        return False

    def _effective_decision_mode(self) -> str:
        summary = self._run_summary_v2()
        if not isinstance(summary, Mapping):
            return "filter_only"
        mode = str(summary.get("decision_mode") or "").strip().lower()
        if mode != "decision_grade":
            return "filter_only"
        if not bool(getattr(self, "_decision_mode_eligible", False)):
            return "filter_only"
        if getattr(self, "_artifact_valid", True) is False:
            return "filter_only"
        return "decision_grade"
        return "filter_only"

    def _export_filename_prefix(self, *, decision_mode_override: str | None = None) -> str:
        mode = str(decision_mode_override or "").strip().lower()
        if not mode:
            try:
                mode = self._effective_decision_mode()
            except Exception:
                mode = "filter_only"
        decision_mode = "decision_grade" if mode == "decision_grade" else "filter_only"
        if decision_mode == "decision_grade":
            return ""

        run_id = getattr(self._data, "run_id", None) if getattr(self, "_data", None) is not None else None
        token = str(run_id).strip() if run_id is not None else ""
        if not token:
            token = "run"
        token = token.replace(os.sep, "_").replace(" ", "_")
        tag = "DEMO_exploratory" if self._is_demo_run() else "EXPLORATORY"
        return f"{tag}_{token}_"

    def _current_provenance(self) -> dict[str, Any] | None:
        summary = self._run_summary_v2()
        if not isinstance(summary, Mapping):
            return None
        prov = summary.get("provenance")
        return dict(prov) if isinstance(prov, Mapping) else None

    def _format_provenance_compact(self, prov: Mapping[str, Any]) -> str:
        backend = prov.get("backend") if isinstance(prov.get("backend"), Mapping) else {}
        model = prov.get("model") if isinstance(prov.get("model"), Mapping) else {}
        params = prov.get("params") if isinstance(prov.get("params"), Mapping) else {}
        name = str(backend.get("name") or "backend")
        version = str(backend.get("version") or "—")
        git_sha = str(backend.get("git_commit") or "—")
        git_short = git_sha[:8] if git_sha and git_sha != "—" else "—"
        model_id = str(model.get("model_id") or "model")
        model_ver = str(model.get("model_version") or "—")
        params_hash = str(params.get("params_hash") or "—")
        params_short = params_hash.replace("sha256:", "")[:10] if params_hash.startswith("sha256:") else params_hash
        return f"{name} {version} · {git_short} · {model_id}@{model_ver} · params {params_short}"

    def _update_provenance_strip(self) -> None:
        strip = getattr(self, "_provenance_strip", None)
        label = getattr(self, "_provenance_label", None)
        btn = getattr(self, "_provenance_copy_btn", None)
        if strip is None or label is None or btn is None:
            return
        prov = self._current_provenance()
        if not isinstance(prov, Mapping):
            strip.setVisible(False)
            return
        label.setText(self._format_provenance_compact(prov))
        strip.setVisible(True)

    def _copy_provenance_to_clipboard(self) -> None:
        prov = self._current_provenance()
        if not isinstance(prov, Mapping):
            return
        try:
            from PySide6.QtWidgets import QApplication

            QApplication.clipboard().setText(json.dumps(dict(prov), indent=2, sort_keys=True) + "\n")
        except Exception:
            return

    def _apply_calibration_bundle_dir_from_settings(self) -> None:
        try:
            raw = str(self._settings.value("outcomeExplorer/calibrationBundleDir", "") or "").strip()
        except Exception:
            return
        if not raw:
            return
        try:
            if Path(raw).expanduser().exists():
                os.environ["HELIX_CALIBRATION_BUNDLE_DIR"] = str(Path(raw).expanduser())
        except Exception:
            return

    def _select_calibration_bundle_dir(self) -> None:
        start = os.getenv("HELIX_CALIBRATION_BUNDLE_DIR") or ""
        if not start:
            try:
                start = str(self._settings.value("outcomeExplorer/calibrationBundleDir", "") or "").strip()
            except Exception:
                start = ""
        try:
            picked = QFileDialog.getExistingDirectory(self, "Select calibration bundle directory", start)
        except Exception:
            picked = ""
        if not picked:
            return
        try:
            self._settings.setValue("outcomeExplorer/calibrationBundleDir", picked)
        except Exception:
            pass
        try:
            os.environ["HELIX_CALIBRATION_BUNDLE_DIR"] = picked
        except Exception:
            pass
        try:
            self._update_contract_badges()
        except Exception:
            pass

    def _clear_calibration_bundle_dir(self) -> None:
        stored = ""
        try:
            stored = str(self._settings.value("outcomeExplorer/calibrationBundleDir", "") or "").strip()
        except Exception:
            stored = ""
        try:
            self._settings.remove("outcomeExplorer/calibrationBundleDir")
        except Exception:
            try:
                self._settings.setValue("outcomeExplorer/calibrationBundleDir", "")
            except Exception:
                pass
        try:
            if stored and os.getenv("HELIX_CALIBRATION_BUNDLE_DIR") == stored:
                os.environ.pop("HELIX_CALIBRATION_BUNDLE_DIR", None)
        except Exception:
            pass
        try:
            self._update_contract_badges()
        except Exception:
            pass

    def _open_evidence_dialog(self) -> None:
        summary = self._run_summary_v2()
        if not isinstance(summary, Mapping):
            try:
                QMessageBox.information(self, "Evidence & Calibration", "No run summary/provenance is available for this run.")
            except Exception:
                pass
            return
        try:
            from helix.studio.ui.evidence_dialog import EvidenceDialog

            dlg = EvidenceDialog(run_summary_v2=summary, parent=self)
            dlg.show()
            dlg.raise_()
            dlg.activateWindow()
            self._evidence_dialog = dlg  # type: ignore[attr-defined]
        except Exception:
            return

    def _export_provenance_paths_for_last_export(self) -> tuple[Path | None, Path | None]:
        """
        Return (export_path, provenance_path) for the most recent export, if available.

        - For CSV: provenance_path is <csv>.provenance.json
        - For HTML: provenance is embedded in the HTML itself (provenance_path=html)
        """
        last = getattr(self, "_last_export_path", None)
        if not isinstance(last, str) or not last.strip():
            return None, None
        export_path = Path(last).expanduser()
        name = export_path.name.lower()
        if name.endswith(".csv"):
            return export_path, export_path.with_name(export_path.name + ".provenance.json")
        if name.endswith(".html") or name.endswith(".htm"):
            return export_path, export_path
        return export_path, None

    def _load_export_provenance_for_last_export(self) -> tuple[dict[str, Any] | None, str | None, str | None]:
        """
        Return (payload, sha256_hex, error) for last export provenance.
        """
        export_path, prov_path = self._export_provenance_paths_for_last_export()
        if export_path is None:
            return None, None, "No prior export found in this session."
        if prov_path is None:
            return None, None, f"No provenance available for export type: {export_path.suffix}"
        if not prov_path.exists():
            return None, None, f"Provenance not found: {prov_path}"
        try:
            text = prov_path.read_text(encoding="utf-8")
        except Exception as exc:
            return None, None, f"Failed to read provenance: {exc}"

        payload: dict[str, Any] | None = None
        if prov_path.suffix.lower() == ".json":
            try:
                obj = json.loads(text)
                payload = obj if isinstance(obj, dict) else None
            except Exception as exc:
                return None, None, f"Invalid provenance JSON: {exc}"
        else:
            # HTML: embedded JSON in <script id="helix-export-provenance" …>
            import re

            m = re.search(
                r"<script[^>]*\bid=[\"']helix-export-provenance[\"'][^>]*>(?P<body>.*?)</script>",
                text,
                flags=re.IGNORECASE | re.DOTALL,
            )
            if not m:
                return None, None, "Missing embedded export provenance script in HTML."
            body = m.group("body").strip()
            try:
                obj = json.loads(body)
                payload = obj if isinstance(obj, dict) else None
            except Exception as exc:
                return None, None, f"Invalid embedded export provenance JSON: {exc}"

        if not isinstance(payload, dict):
            return None, None, "Export provenance must be a JSON object."
        try:
            validate_export_provenance_v1(payload)
        except Exception as exc:
            return None, None, f"Export provenance schema invalid: {exc}"
        try:
            sha = export_provenance_sha256(payload)
        except Exception as exc:
            return payload, None, f"Failed to hash export provenance: {exc}"
        return payload, sha, None

    def _copy_export_provenance_json_to_clipboard(self) -> None:
        payload, _sha, err = self._load_export_provenance_for_last_export()
        if err or not isinstance(payload, dict):
            try:
                QMessageBox.information(self, "Export provenance", err or "No export provenance available.")
            except Exception:
                pass
            return
        try:
            from PySide6.QtWidgets import QApplication

            QApplication.clipboard().setText(export_provenance_c14n_bytes(payload).decode("utf-8"))
        except Exception:
            return

    def _copy_export_provenance_sha_to_clipboard(self) -> None:
        _payload, sha, err = self._load_export_provenance_for_last_export()
        if err or not sha:
            try:
                QMessageBox.information(self, "Export provenance", err or "No export provenance SHA available.")
            except Exception:
                pass
            return
        try:
            from PySide6.QtWidgets import QApplication

            QApplication.clipboard().setText(f"sha256:{sha}")
        except Exception:
            return

    def _open_export_provenance_file(self) -> None:
        export_path, prov_path = self._export_provenance_paths_for_last_export()
        if export_path is None:
            return
        target = prov_path if prov_path is not None and prov_path.exists() else export_path
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(target)))
        except Exception:
            return

    def _current_run_invalid_reason(self) -> str | None:
        run = self._current_run
        if self._artifact_valid is False:
            return "Export disabled: run artifact invalid."
        if run is not None:
            meta = getattr(run, "metadata", None)
            if isinstance(meta, Mapping) and (meta.get("invalid") or meta.get("claims_disabled")):
                reason = str(meta.get("invalid_reason") or "Run marked invalid")
                return f"Export disabled: {reason}"
        if self._data is not None and not self._data.rows:
            return "Export disabled: run produced 0 outcomes."
        return None

    def _refresh_export_block(self) -> None:
        self._export_blocked_reason = self._current_run_invalid_reason()
        decision_mode = "filter_only"
        try:
            decision_mode = self._effective_decision_mode()
        except Exception:
            decision_mode = "filter_only"
        is_demo = False
        try:
            is_demo = bool(self._is_demo_run())
        except Exception:
            is_demo = False
        try:
            if decision_mode == "decision_grade":
                self._export_tooltip_hint = "Exports embed provenance (decision-grade)."
                if getattr(self, "export_btn", None) is not None:
                    self.export_btn.setText("Export")
            else:
                wm = export_watermark_label(decision_mode="filter_only", is_demo=is_demo)
                self._export_tooltip_hint = f"Will be watermarked: {wm}"
                if getattr(self, "export_btn", None) is not None:
                    self.export_btn.setText("Export (Exploratory)")
        except Exception:
            return

    def _set_export_enabled(self, enabled: bool, reason: str | None = None) -> None:
        blocked = self._export_blocked_reason
        final_reason = blocked or reason
        final_enabled = bool(enabled) and final_reason is None
        for act in getattr(self, "_export_actions", []):
            act.setEnabled(final_enabled)
            if final_reason:
                act.setToolTip(final_reason)
            else:
                act.setToolTip("")
        if hasattr(self, "_export_chart_btn") and self._export_chart_btn is not None:
            self._export_chart_btn.setEnabled(final_enabled)
            self._export_chart_btn.setToolTip(final_reason or self._export_tooltip_hint or "")
        if getattr(self, "export_btn", None) is not None:
            self.export_btn.setEnabled(final_enabled)
            self.export_btn.setToolTip(final_reason or self._export_tooltip_hint or "")

    def _prompt_export_class(self, title: str) -> str | None:
        reason = self._export_blocked_reason
        if reason:
            try:
                QMessageBox.warning(self, title, reason)
            except Exception:
                pass
            return None

        try:
            decision_mode = self._effective_decision_mode()
        except Exception:
            decision_mode = "filter_only"
        decision_grade_enabled = bool(decision_mode == "decision_grade")
        if decision_grade_enabled:
            return "decision_grade"

        ctx = build_export_context(
            decision_mode="filter_only",
            is_demo=self._is_demo_run(),
            run_id=getattr(self._data, "run_id", None) if getattr(self, "_data", None) is not None else None,
        )
        evs = getattr(self, "_evs", None)
        exp_spec = None
        intent_spec = None
        if isinstance(evs, Mapping):
            exp_spec = evs.get("experiment_spec") or evs.get("experimentSpec") or evs.get("experimentSpecV1")
            intent_spec = (
                evs.get("experiment_intent_spec")
                or evs.get("experimentIntentSpec")
                or evs.get("experimentIntentSpecV1")
            )
        allowed = ensure_export_allowed(
            self,
            action_title=title,
            ctx=ctx,
            session_acks=self._export_prompt_suppressed_by_key,
            run_summary_v2=self._run_summary_v2(),
            experiment_intent_spec=intent_spec if isinstance(intent_spec, Mapping) else None,
            experiment_spec=exp_spec if isinstance(exp_spec, Mapping) else None,
        )
        return "exploratory" if allowed else None

    def _ensure_export_allowed(self, title: str) -> bool:
        return self._prompt_export_class(title) is not None

    def _update_contract_badges(self) -> None:
        self._update_models_button()
        badge = getattr(self, "_mode_badge", None)
        if badge is None:
            return
        try:
            mode = self._effective_decision_mode()
        except Exception:
            mode = "filter_only"
        label = "DECISION_GRADE" if str(mode).strip().lower() == "decision_grade" else "EXPLORATORY"
        badge.setText(label)
        badge.setVisible(True)

    def _update_models_button(self) -> None:
        btn = getattr(self, "_models_btn", None)
        menu = getattr(self, "_models_menu", None)
        if btn is None or menu is None:
            return
        run_summary = self._run_summary_v2() or {}
        model_stack = run_summary.get("model_stack") if isinstance(run_summary.get("model_stack"), Mapping) else {}
        repair_model = model_stack.get("repair_model") if isinstance(model_stack.get("repair_model"), Mapping) else {}
        off_target_model = model_stack.get("off_target_model") if isinstance(model_stack.get("off_target_model"), Mapping) else {}

        def _model_descriptor(model: Mapping[str, Any]) -> tuple[str, str]:
            name = str(model.get("name") or model.get("model_id") or "model").strip() or "model"
            model_id = str(model.get("model_id") or "").strip()
            ver = str(model.get("model_version") or "").strip()
            h = str(model.get("model_hash") or "").strip()
            h_short = h.replace("sha256:", "")[:10] if h.startswith("sha256:") else ""
            parts = [name]
            if model_id and model_id != name:
                parts.append(model_id)
            if ver:
                parts.append(f"v{ver}")
            if h_short:
                parts.append(f"sha256:{h_short}")
            desc = " · ".join([p for p in parts if p])
            try:
                payload = json.dumps(dict(model), indent=2, sort_keys=True)
            except Exception:
                payload = desc
            return desc, payload

        repair_desc, repair_json = _model_descriptor(repair_model)
        ot_desc, ot_json = _model_descriptor(off_target_model)

        # Calibration summary (short, stable).
        cal_status = "Uncalibrated"
        cal_tooltip = "No calibration bundle attached."
        context = None
        cal = None
        if isinstance(self._posterior_payload, Mapping):
            cal = self._posterior_payload.get("calibration")
            context = self._posterior_payload.get("context")
        if isinstance(cal, Mapping):
            raw_status = str(cal.get("status") or "").strip().lower()
            if raw_status in {"calibrated", "calibrated_in_domain", "in_domain"}:
                cal_status = "Calibrated"
            elif raw_status in {"out_of_domain", "ood"}:
                cal_status = "Out of domain"
            elif raw_status in {"evidence_conflicted", "conflicted", "evidence-conflicted"}:
                cal_status = "Evidence conflicted"
            elif raw_status:
                cal_status = "Uncalibrated"
                cal_tooltip = f"Calibration status: {raw_status}"
            notes = cal.get("notes") if isinstance(cal.get("notes"), str) else None
            if notes:
                cal_tooltip = notes
        if _is_flat_context(context if isinstance(context, Mapping) else None):
            cal_tooltip = (cal_tooltip + " " if cal_tooltip else "") + "Context incomplete (flat prior)."

        # Reference id (e.g. hg38) from provenance data.
        ref_id = ""
        prov = run_summary.get("provenance") if isinstance(run_summary.get("provenance"), Mapping) else {}
        pdata = prov.get("data") if isinstance(prov.get("data"), Mapping) else {}
        refg = pdata.get("reference_genome") if isinstance(pdata.get("reference_genome"), Mapping) else {}
        ref_id = str(refg.get("id") or "").strip()

        # Species summary (if present).
        species_value = ""
        species_block = run_summary.get("species_detection") if isinstance(run_summary.get("species_detection"), Mapping) else {}
        if isinstance(species_block, Mapping) and species_block:
            status = str(species_block.get("status") or "unknown").strip()
            taxon_name = str(species_block.get("taxon_name") or "").strip()
            resolution = species_block.get("resolution") if isinstance(species_block.get("resolution"), Mapping) else {}
            taxon_id = str(resolution.get("taxon_id") or "").strip()
            if status == "resolved":
                species_value = taxon_name or taxon_id
            elif status == "genus":
                base = taxon_name or taxon_id
                species_value = f"Genus {base}".strip() if base else "Genus"
            elif status:
                species_value = status.replace("_", " ").title()

        label_parts = ["Models ▾", cal_status]
        if ref_id:
            label_parts.append(ref_id)
        btn.setText(" · ".join([p for p in label_parts if p]))

        tooltip_lines = [
            f"Repair model: {repair_desc}" if repair_desc else "Repair model: —",
            f"Off-target model: {ot_desc}" if ot_desc else "Off-target model: —",
            f"Calibration: {cal_status}",
        ]
        if cal_tooltip:
            tooltip_lines.append(cal_tooltip)
        if species_value:
            tooltip_lines.append(f"Species: {species_value}")
        if ref_id:
            tooltip_lines.append(f"Reference: {ref_id}")
        btn.setToolTip("\n".join([l for l in tooltip_lines if l]).strip())

        menu.clear()

        def _add_info(text: str) -> None:
            act = menu.addAction(text)
            act.setEnabled(False)

        def _add_copy(label: str, payload: str) -> None:
            act = menu.addAction(label)
            act.setEnabled(bool(payload))

            def _copy() -> None:
                try:
                    from PySide6.QtWidgets import QApplication

                    QApplication.clipboard().setText(payload)
                except Exception:
                    return

            act.triggered.connect(_copy)

        _add_info("Repair model")
        _add_info(repair_desc or "—")
        _add_copy("Copy repair model (JSON)", repair_json or "")
        menu.addSeparator()

        _add_info("Off-target model")
        _add_info(ot_desc or "—")
        _add_copy("Copy off-target model (JSON)", ot_json or "")
        menu.addSeparator()

        _add_info(f"Calibration: {cal_status}")
        if ref_id:
            _add_info(f"Reference: {ref_id}")
        if species_value:
            _add_info(f"Species: {species_value}")

        menu.addSeparator()
        act_evidence = menu.addAction("Evidence & calibration…")
        act_evidence.triggered.connect(self._open_evidence_dialog)

        menu.addSeparator()
        act_set_cal = menu.addAction("Set calibration bundle directory…")
        act_set_cal.triggered.connect(self._select_calibration_bundle_dir)
        act_clear_cal = menu.addAction("Clear calibration bundle directory")
        act_clear_cal.triggered.connect(self._clear_calibration_bundle_dir)
        try:
            act_clear_cal.setEnabled(bool(str(self._settings.value("outcomeExplorer/calibrationBundleDir", "") or "").strip()))
        except Exception:
            act_clear_cal.setEnabled(False)

        menu.addSeparator()
        act_copy_prov = menu.addAction("Copy run provenance (JSON)")
        act_copy_prov.triggered.connect(self._copy_provenance_to_clipboard)

    def _update_domain_badge(self) -> None:
        # Back-compat: calibration now lives under Models ▾.
        self._update_models_button()

    def _decision_label(self, decision: str) -> str:
        mapping = {
            "go": "Go",
            "no_go": "No Go",
            "insufficient_evidence": "Insufficient evidence",
            "redesign_required": "Redesign required",
        }
        return mapping.get(str(decision or "").strip().lower(), str(decision or "").strip() or "Insufficient evidence")

    def _format_intended_edit_spec_short(self, intended: Mapping[str, Any] | None) -> tuple[str, str]:
        if not isinstance(intended, Mapping):
            return "edit: not specified", ""
        edit_class = str(intended.get("edit_class") or "unknown")
        target = intended.get("target") if isinstance(intended.get("target"), Mapping) else {}
        chrom = str(target.get("chrom") or "unknown")
        start = target.get("start")
        end = target.get("end")
        locus = chrom
        if isinstance(start, int) and isinstance(end, int):
            locus = f"{chrom}:{start}-{end}"
        cut_site = target.get("cut_site") if isinstance(target.get("cut_site"), Mapping) else {}
        cut_pos = cut_site.get("pos")
        cut_txt = f"cut@{int(cut_pos)}" if isinstance(cut_pos, int) else "cut@?"
        meas = intended.get("measurement") if isinstance(intended.get("measurement"), Mapping) else {}
        assay = str(meas.get("assay_type") or meas.get("assay_definition_id") or "")
        if not assay:
            assay = "assay=absent"
        short = f"{edit_class} · {locus} · {cut_txt} · {assay}"
        try:
            tooltip = json.dumps(intended, indent=2, sort_keys=True)
        except Exception:
            tooltip = ""
        return short, tooltip

    def _uncertainty_interval(self, uncertainty: Mapping[str, Any] | None, metric_path: str) -> Mapping[str, Any] | None:
        if not isinstance(uncertainty, Mapping):
            return None
        if str(uncertainty.get("status") or "") != "computed":
            return None
        cis = uncertainty.get("credible_intervals") if isinstance(uncertainty.get("credible_intervals"), Mapping) else {}
        ci = cis.get(metric_path)
        return ci if isinstance(ci, Mapping) else None

    def _format_uncertainty_band(self, uncertainty: Mapping[str, Any] | None, metric_path: str, *, digits: int = 1) -> tuple[str, str]:
        if str(getattr(self, "_decision_mode", "filter_only")) != "decision_grade":
            return "suppressed", ""
        ci = self._uncertainty_interval(uncertainty, metric_path)
        if not isinstance(ci, Mapping):
            status = str(uncertainty.get("status") or "not_computed") if isinstance(uncertainty, Mapping) else "not_computed"
            return ("uncertainty not computed" if status != "computed" else "uncertainty invalid"), ""
        lower = float(ci.get("lower") or 0.0)
        upper = float(ci.get("upper") or 0.0)
        level = ci.get("level")
        level_txt = f"{int(round(float(level) * 100))}%" if isinstance(level, (int, float)) else "—"
        band = f"{level_txt} CI {lower*100:.{digits}f}–{upper*100:.{digits}f}%"
        try:
            tooltip = json.dumps(ci, indent=2, sort_keys=True)
        except Exception:
            tooltip = ""
        return band, tooltip

    def _format_intended_with_context(
        self,
        intended_txt: str,
        intended_edit_spec: Mapping[str, Any] | None,
        uncertainty: Mapping[str, Any] | None,
        *,
        require_band: bool,
    ) -> str:
        spec_short, _spec_tip = self._format_intended_edit_spec_short(intended_edit_spec)
        auditable, _reason = intended_functional_auditability(intended_edit_spec)
        if not auditable:
            return " · ".join([p for p in ["Not auditable", spec_short] if p])

        parts: list[str] = []
        band = ""
        if require_band:
            band, _band_tip = self._format_uncertainty_band(uncertainty, "control.intended_functional_p", digits=1)
            if band.startswith("uncertainty"):
                # Do not show a point estimate when an uncertainty interval is required but missing.
                parts.extend([spec_short, band])
                return " · ".join([p for p in parts if p])

        parts.append(str(intended_txt or "").strip() or "—")
        parts.append(spec_short)
        if band:
            parts.append(band)
        return " · ".join([p for p in parts if p])

    def _format_intended_tooltip(
        self,
        intended_edit_spec: Mapping[str, Any] | None,
        uncertainty: Mapping[str, Any] | None,
        *,
        require_band: bool,
    ) -> str:
        lines: list[str] = []
        _short, spec_tip = self._format_intended_edit_spec_short(intended_edit_spec)
        auditable, reason = intended_functional_auditability(intended_edit_spec)
        if not auditable:
            msg = "Intended functional is not auditable with the current intended edit spec."
            if reason:
                msg = msg + f" Reason: {reason}"
            lines.append(msg)
        if spec_tip:
            lines.append("Intended edit spec:\n" + spec_tip)

        if auditable and require_band:
            band, band_tip = self._format_uncertainty_band(uncertainty, "control.intended_functional_p", digits=1)
            if band_tip:
                lines.append("Uncertainty interval:\n" + band_tip)
            else:
                status = str(uncertainty.get("status") or "not_computed") if isinstance(uncertainty, Mapping) else "not_computed"
                if status != "computed":
                    reason = str(uncertainty.get("reason") or "").strip() if isinstance(uncertainty, Mapping) else ""
                    msg = "Uncertainty not computed." + (f" Reason: {reason}" if reason else "")
                    msg = msg + " Intended functional value is suppressed."
                    lines.append(msg)
        return "\n\n".join([s for s in lines if s]).strip()

    def _format_off_target_chip(self, contract_risk: Mapping[str, Any] | None) -> str:
        risk = contract_risk if isinstance(contract_risk, Mapping) else {}
        offt = risk.get("off_target") if isinstance(risk.get("off_target"), Mapping) else None
        if not isinstance(offt, Mapping):
            return "Not computed"
        status = str(offt.get("status") or "")
        if status == "computed":
            worst = float(offt.get("worst_site_score") or 0.0)
            p_coding = float(offt.get("p_hits_coding_exon") or 0.0)
            mode = str(offt.get("mode") or "").strip().lower()
            executed = str(offt.get("executed_mode") or "").strip().lower()
            annotation_ok = bool(offt.get("annotation_computed")) if "annotation_computed" in offt else True
            if mode == "screening":
                prefix = "Screening (window-only)"
            elif mode == "full":
                prefix = "Full (ran screening)" if executed and executed != "full" else "Full"
            else:
                prefix = "Computed"
            if str(getattr(self, "_decision_mode", "filter_only")) != "decision_grade":
                return f"{prefix} · computed"
            p_txt = self._format_prob_value(p_coding, digits=2) if annotation_ok else "—"
            return f"{prefix} · worst {worst:.3g} · P(coding) {p_txt}"
        if status == "not_computed":
            reason = str(offt.get("reason") or "").strip()
            severity = str(offt.get("severity") or "").strip()
            sev_txt = f" ({severity})" if severity else ""
            if reason:
                return f"Not computed{sev_txt} · {reason}"
            return f"Not computed{sev_txt}"
        return "Unknown"

    def _window_local_offtarget_interaction_proxy(self) -> dict[str, Any]:
        """Return a window-local off-target sweep with interaction proxy fields.

        This is UI-only diagnostics: it is not a genome-wide off-target engine and
        does not imply kinetics/thermodynamics.
        """

        cached_key = getattr(self, "_window_offtarget_proxy_cache_key", None)
        cached_payload = getattr(self, "_window_offtarget_proxy_cache", None)

        evs = self._evs if isinstance(self._evs, Mapping) else None
        if not isinstance(evs, Mapping):
            return {"status": "not_computed", "reason": "missing_evs"}

        seq_block = evs.get("sequence") if isinstance(evs.get("sequence"), Mapping) else {}
        seq_ref = seq_block.get("ref") if isinstance(seq_block, Mapping) else None
        if not isinstance(seq_ref, str) or not seq_ref:
            return {"status": "not_computed", "reason": "missing_sequence"}

        plan = evs.get("editPlan") if isinstance(evs.get("editPlan"), Mapping) else {}
        targets = plan.get("targets") if isinstance(plan.get("targets"), list) else []
        if not targets or not isinstance(targets[0], Mapping):
            return {"status": "not_computed", "reason": "missing_target"}

        target0: Mapping[str, Any] = targets[0]
        grna = target0.get("gRNA") if isinstance(target0.get("gRNA"), Mapping) else {}
        guide_seq_raw = grna.get("sequence") if isinstance(grna, Mapping) else None
        if not isinstance(guide_seq_raw, str) or not guide_seq_raw.strip():
            return {"status": "not_computed", "reason": "missing_guide_sequence"}

        guide_seq = normalize_sequence(guide_seq_raw)
        if not guide_seq:
            return {"status": "not_computed", "reason": "invalid_guide_sequence"}
        if len(guide_seq) > 64:
            return {"status": "not_computed", "reason": "guide_len_gt_64"}

        pam = "NGG"
        if isinstance(grna, Mapping) and isinstance(grna.get("pam"), str) and str(grna.get("pam") or "").strip():
            pam = str(grna.get("pam") or "").strip()

        sim = evs.get("simulation") if isinstance(evs.get("simulation"), Mapping) else {}
        params = sim.get("params") if isinstance(sim.get("params"), Mapping) else {}
        off_params = params.get("offTarget") if isinstance(params.get("offTarget"), Mapping) else {}

        mismatch_max_raw = (
            off_params.get("mismatchMax")
            if "mismatchMax" in off_params
            else off_params.get("max_mm", off_params.get("mismatch_max", 3))
        )
        try:
            mismatch_max = int(mismatch_max_raw)
        except Exception:
            mismatch_max = 3
        mismatch_max = max(0, min(10, mismatch_max))

        seed_len_raw = off_params.get("seedLen") if "seedLen" in off_params else off_params.get("seed_len")
        if seed_len_raw is None:
            seed_len = max(1, len(guide_seq) // 2)
        else:
            try:
                seed_len = int(seed_len_raw)
            except Exception:
                seed_len = max(1, len(guide_seq) // 2)
        seed_len = max(1, min(len(guide_seq), seed_len))

        cache_key = f"{hash(seq_ref)}:{guide_seq}:{pam}:{mismatch_max}:{seed_len}"
        if cache_key == cached_key and isinstance(cached_payload, dict):
            return cached_payload

        try:
            from helix.crispr import score as crispr_score
        except Exception as exc:
            return {
                "status": "not_computed",
                "reason": f"crispr_score_import_failed:{exc.__class__.__name__}",
            }

        weights = dict(crispr_score.DEFAULT_WEIGHTS.get("off_target") or {})
        weights["seed_len"] = seed_len

        guide_id = str(target0.get("label") or target0.get("id") or "guide")
        guide_obj = {
            "id": guide_id,
            "sequence": guide_seq,
            "start": 0,
            "end": len(guide_seq),
            "strand": "+",
        }

        try:
            hits = crispr_score.enumerate_off_targets(seq_ref, guide_obj, pam, max_mm=mismatch_max)
            scored = crispr_score.score_off_targets(hits, weights)
        except Exception as exc:
            payload = {"status": "not_computed", "reason": f"sweep_failed:{exc.__class__.__name__}"}
            self._window_offtarget_proxy_cache_key = cache_key
            self._window_offtarget_proxy_cache = payload
            return payload

        intended_start = target0.get("start")
        intended_end = target0.get("end")
        intended_strand = target0.get("strand")
        intended_key: tuple[int, int, str] | None = None
        if intended_start is not None and intended_end is not None and intended_strand is not None:
            try:
                intended_key = (int(intended_start), int(intended_end), str(intended_strand))
            except Exception:
                intended_key = None

        intended_hit: dict[str, Any] | None = None
        candidates: list[dict[str, Any]] = []
        for hit in scored:
            if not isinstance(hit, dict):
                continue
            try:
                dist = int(hit.get("distance") or 0)
            except Exception:
                dist = 0
            if intended_key is not None:
                try:
                    k = (int(hit.get("start", -1)), int(hit.get("end", -1)), str(hit.get("strand") or ""))
                except Exception:
                    k = None
                if k == intended_key:
                    intended_hit = hit
                    continue
            if dist > 0:
                candidates.append(hit)

        def _hit_score(h: Mapping[str, Any]) -> float:
            try:
                return float(h.get("cleavage_probability_proxy", h.get("score", 0.0)) or 0.0)
            except Exception:
                return 0.0

        worst_hit = max(candidates, key=_hit_score, default=None)

        payload = {
            "status": "computed",
            "scope": "window_local",
            "params": {
                "pam": pam,
                "mismatch_max": mismatch_max,
                "seed_len": seed_len,
                "guide_len": len(guide_seq),
            },
            "intended": intended_hit,
            "worst_offtarget": worst_hit,
            "n_candidates": len(candidates),
        }
        self._window_offtarget_proxy_cache_key = cache_key
        self._window_offtarget_proxy_cache = payload
        return payload

    def _format_cas_dna_interaction_chip(
        self,
        *,
        quantitative_allowed: bool,
    ) -> tuple[str, str, bool]:
        diag = self._window_local_offtarget_interaction_proxy()
        status = str(diag.get("status") or "not_computed")
        if status != "computed":
            reason = str(diag.get("reason") or "").strip() or "not_computed"
            tooltip = (
                "Cas–DNA interaction proxies are unavailable.\n\n"
                f"Reason: {reason}\n\n"
                "This UI diagnostic requires a guide sequence and a reference window."
            )
            return "Not available", tooltip, False

        params = diag.get("params") if isinstance(diag.get("params"), Mapping) else {}
        pam = str(params.get("pam") or "—")
        try:
            mismatch_max = int(params.get("mismatch_max") or 0)
        except Exception:
            mismatch_max = 0
        try:
            seed_len = int(params.get("seed_len") or 0)
        except Exception:
            seed_len = 0

        worst = diag.get("worst_offtarget") if isinstance(diag.get("worst_offtarget"), Mapping) else None
        intended = diag.get("intended") if isinstance(diag.get("intended"), Mapping) else None

        if worst is None:
            value = f"window-only · no candidates (≤{mismatch_max} mm)"
            tooltip = (
                "Window-local sweep found no off-target candidates.\n\n"
                f"PAM: {pam}\n"
                f"max_mm: {mismatch_max}\n"
                f"seed_len: {seed_len}\n\n"
                "Note: this is not a genome-wide off-target search."
            )
            return value, tooltip, True

        def _mismatch_vector_text(proxy: Mapping[str, Any] | None) -> str:
            if not isinstance(proxy, Mapping):
                return "—"
            vec = proxy.get("mismatch_vector")
            if not isinstance(vec, list) or not vec:
                return "—"
            chars = []
            for x in vec:
                try:
                    chars.append("X" if int(x) else ".")
                except Exception:
                    chars.append("?")
            return "".join(chars)

        proxy = worst.get("interaction_proxy") if isinstance(worst.get("interaction_proxy"), Mapping) else None
        vector = _mismatch_vector_text(proxy)

        try:
            dist = int(worst.get("distance") or 0)
        except Exception:
            dist = 0
        seed_mm = 0
        if isinstance(proxy, Mapping):
            try:
                seed_mm = int(proxy.get("pam_proximal_mismatch_count") or 0)
            except Exception:
                seed_mm = 0

        if quantitative_allowed:
            try:
                bind = float(worst.get("binding_affinity_proxy") or 0.0)
            except Exception:
                bind = 0.0
            try:
                cleave_bound = float(worst.get("cleavage_given_bound_proxy") or 0.0)
            except Exception:
                cleave_bound = 0.0
            try:
                cleave = float(worst.get("cleavage_probability_proxy", worst.get("score", 0.0)) or 0.0)
            except Exception:
                cleave = 0.0
            value = (
                f"window worst · bind {bind:.2f} · cleave|bound {cleave_bound:.2f} · cleave {cleave:.2f} "
                f"· mm {dist} (seed {seed_mm})"
            )
        else:
            value = f"window worst · mm {dist} (seed {seed_mm}) · proxies suppressed"

        tooltip_lines: list[str] = [
            "Cas–DNA interaction (proxy). Window-local sweep; not genome-wide.",
            "",
            f"PAM: {pam}",
            f"max_mm: {mismatch_max}",
            f"seed_len: {seed_len} (PAM-proximal positions)",
        ]
        try:
            tooltip_lines.append(f"window_candidates: {int(diag.get('n_candidates') or 0)}")
        except Exception:
            pass

        if intended is not None:
            try:
                tooltip_lines.extend(
                    [
                        "",
                        "Intended target (if resolved in-window):",
                        f"start={int(intended.get('start', -1))} end={int(intended.get('end', -1))} strand={str(intended.get('strand') or '')}",
                        f"mismatches={int(intended.get('distance') or 0)} pam_ok={bool(intended.get('pam_ok', True))}",
                    ]
                )
            except Exception:
                pass

        try:
            tooltip_lines.extend(
                [
                    "",
                    "Worst off-target (window):",
                    f"start={int(worst.get('start', -1))} end={int(worst.get('end', -1))} strand={str(worst.get('strand') or '')}",
                    f"mismatches={dist} seed_mismatches={seed_mm} pam_ok={bool(worst.get('pam_ok', True))}",
                    f"mismatch_vector: {vector}",
                ]
            )
        except Exception:
            pass

        mismatches = worst.get("mismatches") if isinstance(worst.get("mismatches"), list) else []
        if mismatches:
            mm_lines: list[str] = []
            for mm in mismatches:
                if not isinstance(mm, Mapping):
                    continue
                try:
                    pos = int(mm.get("position", 0))
                except Exception:
                    pos = 0
                ref = str(mm.get("target", "N"))
                alt = str(mm.get("guide", "N"))
                mm_lines.append(f"pos {pos}: {ref}>{alt}")
            if mm_lines:
                tooltip_lines.append("mismatches: " + ", ".join(mm_lines))

        if quantitative_allowed:
            try:
                tooltip_lines.extend(
                    [
                        "",
                        "Proxies (not calibrated probabilities):",
                        f"binding_affinity_proxy={float(worst.get('binding_affinity_proxy') or 0.0):.4f}",
                        f"cleavage_given_bound_proxy={float(worst.get('cleavage_given_bound_proxy') or 0.0):.4f}",
                        f"cleavage_probability_proxy={float(worst.get('cleavage_probability_proxy', worst.get('score', 0.0)) or 0.0):.4f}",
                    ]
                )
            except Exception:
                pass
        else:
            tooltip_lines.extend(
                [
                    "",
                    "Proxy magnitudes are suppressed in exploratory mode.",
                    "Enable decision grade to view proxy values.",
                ]
            )

        return value, "\n".join([l for l in tooltip_lines if l or l == ""]).strip(), True

    def _exportable_cas_dna_interaction_proxy(self, *, quantitative_allowed: bool) -> dict[str, Any]:
        """Return an export-safe snapshot of Cas–DNA interaction proxy diagnostics.

        Mirrors the UI diagnostic but:
        - always JSON-serializable
        - suppresses proxy magnitudes unless decision grade is enabled
        """

        if self._is_prime_run():
            return {"status": "not_applicable", "reason": "prime_run"}

        diag = self._window_local_offtarget_interaction_proxy()
        status = str(diag.get("status") or "not_computed")
        if status != "computed":
            return {
                "status": status,
                "reason": str(diag.get("reason") or "").strip() or None,
                "scope": "window_local",
                "quantitative_suppressed": bool(not quantitative_allowed),
                "notes": "UI diagnostic only; not genome-wide; proxy-only.",
            }

        params = diag.get("params") if isinstance(diag.get("params"), Mapping) else {}

        def _summarize_hit(hit: Mapping[str, Any] | None) -> dict[str, Any] | None:
            if not isinstance(hit, Mapping):
                return None
            out: dict[str, Any] = {}
            try:
                out["start"] = int(hit.get("start", -1))
                out["end"] = int(hit.get("end", -1))
            except Exception:
                out["start"] = None
                out["end"] = None
            out["strand"] = str(hit.get("strand") or "")
            try:
                out["mismatches"] = int(hit.get("distance") or 0)
            except Exception:
                out["mismatches"] = 0
            out["pam_ok"] = bool(hit.get("pam_ok", True))
            out["pam_orientation"] = str(hit.get("pam_orientation") or "")

            proxy = hit.get("interaction_proxy") if isinstance(hit.get("interaction_proxy"), Mapping) else None
            if isinstance(proxy, Mapping):
                out["seed_len"] = int(proxy.get("seed_len") or 0) if "seed_len" in proxy else None
                out["mismatch_vector"] = (
                    [int(x) for x in proxy.get("mismatch_vector") if isinstance(x, (int, float))]
                    if isinstance(proxy.get("mismatch_vector"), list)
                    else None
                )
                try:
                    out["seed_mismatches"] = int(proxy.get("pam_proximal_mismatch_count") or 0)
                except Exception:
                    out["seed_mismatches"] = 0
                try:
                    out["distal_mismatches"] = int(proxy.get("distal_mismatch_count") or 0)
                except Exception:
                    out["distal_mismatches"] = 0

            mismatches = hit.get("mismatches") if isinstance(hit.get("mismatches"), list) else []
            mm_out: list[dict[str, Any]] = []
            for mm in mismatches:
                if not isinstance(mm, Mapping):
                    continue
                try:
                    pos = int(mm.get("position", 0))
                except Exception:
                    pos = 0
                mm_out.append(
                    {
                        "position": pos,
                        "target": str(mm.get("target", "N")),
                        "guide": str(mm.get("guide", "N")),
                    }
                )
            out["mismatch_list"] = mm_out

            if quantitative_allowed:
                for key in (
                    "binding_affinity_proxy",
                    "binding_stability_proxy",
                    "off_rate_proxy",
                    "cleavage_given_bound_proxy",
                    "cleavage_probability_proxy",
                ):
                    if key not in hit:
                        continue
                    try:
                        out[key] = float(hit.get(key) or 0.0)
                    except Exception:
                        out[key] = None
            else:
                out["quantitative_suppressed"] = True
            return out

        return {
            "status": "computed",
            "scope": str(diag.get("scope") or "window_local"),
            "params": {
                "pam": str(params.get("pam") or ""),
                "mismatch_max": int(params.get("mismatch_max") or 0) if "mismatch_max" in params else None,
                "seed_len": int(params.get("seed_len") or 0) if "seed_len" in params else None,
                "guide_len": int(params.get("guide_len") or 0) if "guide_len" in params else None,
            },
            "n_candidates": int(diag.get("n_candidates") or 0),
            "intended": _summarize_hit(diag.get("intended") if isinstance(diag.get("intended"), Mapping) else None),
            "worst_offtarget": _summarize_hit(
                diag.get("worst_offtarget") if isinstance(diag.get("worst_offtarget"), Mapping) else None
            ),
            "quantitative_suppressed": bool(not quantitative_allowed),
            "notes": "Window-local sweep; proxy-only; not genome-wide.",
        }

    def _cas_dna_interaction_csv_prefix(self, *, quantitative_allowed: bool) -> str:
        """Return comment-prefixed lines for embedding in exported CSV text."""

        payload = self._exportable_cas_dna_interaction_proxy(quantitative_allowed=quantitative_allowed)
        status = str(payload.get("status") or "not_computed")
        if status == "not_applicable":
            return ""

        lines: list[str] = []
        lines.append(f"# cas_dna_interaction_proxy_status: {status}")
        reason = str(payload.get("reason") or "").strip()
        if reason and status != "computed":
            lines.append(f"# cas_dna_interaction_proxy_reason: {reason}")
        lines.append("# cas_dna_interaction_proxy_note: window-local sweep; not genome-wide; proxy-only")

        if status != "computed":
            return "\n".join(lines) + "\n"

        params = payload.get("params") if isinstance(payload.get("params"), Mapping) else {}
        pam = str(params.get("pam") or "—")
        mm = params.get("mismatch_max")
        seed = params.get("seed_len")
        gl = params.get("guide_len")
        lines.append(f"# cas_dna_params: pam={pam} max_mm={mm} seed_len={seed} guide_len={gl}")
        lines.append(f"# cas_dna_window_candidates: {int(payload.get('n_candidates') or 0)}")

        worst = payload.get("worst_offtarget") if isinstance(payload.get("worst_offtarget"), Mapping) else {}
        try:
            start = int(worst.get("start", -1))
            end = int(worst.get("end", -1))
        except Exception:
            start = -1
            end = -1
        strand = str(worst.get("strand") or "")
        mismatches = int(worst.get("mismatches") or 0) if "mismatches" in worst else 0
        seed_mm = int(worst.get("seed_mismatches") or 0) if "seed_mismatches" in worst else 0
        pam_ok = bool(worst.get("pam_ok", True)) if "pam_ok" in worst else True
        lines.append(
            f"# cas_dna_worst_offtarget: start={start} end={end} strand={strand} mismatches={mismatches} seed_mismatches={seed_mm} pam_ok={pam_ok}"
        )
        vec = worst.get("mismatch_vector") if isinstance(worst.get("mismatch_vector"), list) else None
        if vec:
            vec_txt = "".join("X" if int(x) else "." for x in vec if isinstance(x, int))
            lines.append(f"# cas_dna_worst_mismatch_vector: {vec_txt}")

        if quantitative_allowed:
            try:
                bind = float(worst.get("binding_affinity_proxy") or 0.0)
            except Exception:
                bind = 0.0
            try:
                cleave = float(worst.get("cleavage_probability_proxy") or 0.0)
            except Exception:
                cleave = 0.0
            lines.append(f"# cas_dna_worst_binding_affinity_proxy: {bind:.6f}")
            lines.append(f"# cas_dna_worst_cleavage_probability_proxy: {cleave:.6f}")
        else:
            lines.append("# cas_dna_proxy_values: suppressed (decision-grade only)")

        return "\n".join(lines) + "\n"

    def _format_escape_risk_chip(self, contract_control: Mapping[str, Any] | None) -> str:
        control = contract_control if isinstance(contract_control, Mapping) else {}
        conv = control.get("convergence") if isinstance(control.get("convergence"), Mapping) else None
        if not isinstance(conv, Mapping):
            return "Not computed"
        status = str(conv.get("status") or "")
        if status == "computed":
            escape_risk = float(conv.get("escape_risk") or 0.0)
            worst_uncut = float(conv.get("escape_worst_case_uncut_p_gen20") or 0.0)
            escape_txt = self._format_prob_value(escape_risk, digits=2)
            worst_txt = self._format_prob_value(worst_uncut, digits=1)
            return f"{escape_txt} · worst uncut@20 {worst_txt}"
        if status == "not_computed":
            reason = str(conv.get("reason") or "").strip()
            severity = str(conv.get("severity") or "").strip()
            sev_txt = f" ({severity})" if severity else ""
            if reason:
                return f"Not computed{sev_txt} · {reason}"
            return f"Not computed{sev_txt}"
        return "Unknown"

    def _build_iteration_chips(
        self, iteration: Mapping[str, Any] | None
    ) -> tuple[list[tuple[str, str, str] | tuple[str, str, str, str]], int]:
        if not isinstance(iteration, Mapping):
            step = 5
            placeholder = "—"
            return [
                ("κ max", placeholder, "muted"),
                (f"Intended@{step}", placeholder, "muted"),
                (f"Uncut@{step}", placeholder, "muted"),
                (f"Harmful@{step}", placeholder, "muted"),
                (f"Escape@{step}", placeholder, "muted"),
            ], step
        status = str(iteration.get("status") or "")
        steps = int(iteration.get("steps") or 5)
        step_idx = max(0, steps)
        intended = iteration.get("intended") if isinstance(iteration.get("intended"), list) else []
        uncut = iteration.get("uncut") if isinstance(iteration.get("uncut"), list) else []
        harmful = iteration.get("harmful") if isinstance(iteration.get("harmful"), list) else []
        escape = iteration.get("escape") if isinstance(iteration.get("escape"), list) else []
        kappa_max = iteration.get("kappa_max") if isinstance(iteration.get("kappa_max"), list) else []
        kappa_overall = iteration.get("kappa_max_overall")
        kappa_avg_overall = iteration.get("kappa_avg_overall")
        limitations = str(iteration.get("limitations") or "").strip()
        reason = str(iteration.get("reason") or "").strip()
        transition = str(iteration.get("transition_model") or "identity")

        def _val(series: list[float]) -> float:
            if not series:
                return 0.0
            idx = min(step_idx, len(series) - 1)
            return float(series[idx])

        if status != "computed":
            msg = reason or "Not computed"
            return [
                ("κ max", msg, "muted"),
                (f"Intended@{step_idx}", "—", "muted"),
                (f"Uncut@{step_idx}", "—", "muted"),
                (f"Harmful@{step_idx}", "—", "muted"),
                (f"Escape@{step_idx}", "—", "muted"),
            ], step_idx

        kappa_val = float(kappa_overall) if isinstance(kappa_overall, (int, float)) else max([float(v) for v in kappa_max] or [0.0])
        escape_val = _val([float(v) for v in escape]) if escape else _val([float(v) for v in uncut])
        tooltip = f"T={transition}"
        if isinstance(kappa_avg_overall, (int, float)) and str(getattr(self, "_decision_mode", "filter_only")) == "decision_grade":
            tooltip = f"{tooltip}\nκ_avg {float(kappa_avg_overall):.2f}"
        if limitations:
            tooltip = f"{tooltip}\n{limitations}"
        if str(getattr(self, "_decision_mode", "filter_only")) != "decision_grade":
            chips: list[tuple[str, str, str] | tuple[str, str, str, str]] = [
                ("κ max", "suppressed", "default", tooltip),
                (f"Intended@{step_idx}", "suppressed", "default"),
                (f"Uncut@{step_idx}", "suppressed", "default"),
                (f"Harmful@{step_idx}", "suppressed", "default"),
                (f"Escape@{step_idx}", "suppressed", "default"),
            ]
            return chips, step_idx
        chips: list[tuple[str, str, str] | tuple[str, str, str, str]] = [
            ("κ max", f"{kappa_val:.2f}", "default", tooltip),
            (f"Intended@{step_idx}", self._format_prob_value(_val([float(v) for v in intended]), digits=1), "default"),
            (f"Uncut@{step_idx}", self._format_prob_value(_val([float(v) for v in uncut]), digits=1), "default"),
            (f"Harmful@{step_idx}", self._format_prob_value(_val([float(v) for v in harmful]), digits=1), "default"),
            (f"Escape@{step_idx}", self._format_prob_value(escape_val, digits=1), "default"),
        ]
        return chips, step_idx

    def _format_stability_chip(self, contract_control: Mapping[str, Any] | None) -> tuple[str, str]:
        control = contract_control if isinstance(contract_control, Mapping) else {}
        stab = control.get("stability") if isinstance(control.get("stability"), Mapping) else None
        if not isinstance(stab, Mapping):
            return "Not computed", "Missing control.stability in v2 contract."
        status = str(stab.get("status") or "")
        if status == "computed":
            score = float(stab.get("stability_score") or 0.0)
            interp = str(stab.get("interpretation") or "").strip().lower()
            interp_txt = interp.title() if interp else "Low"
            if str(getattr(self, "_decision_mode", "filter_only")) != "decision_grade":
                return interp_txt, "DEMO (NON-CALIBRATED): quantitative stability metrics suppressed."
            show_grade = bool(getattr(self, "_decision_mode", "filter_only") == "decision_grade")
            mode = getattr(self, "_probability_mode", "probability")

            def _fmt_point(v: float, *, decimals: int | None = None, sig: int | None = None) -> str:
                if sig is not None:
                    vv = float(v)
                    if str(mode) == "probability":
                        return f"{vv*100:.{int(sig)}g}%"
                    return f"{vv:.{int(sig)}g}"
                d = 1 if decimals is None else int(decimals)
                return _format_value(float(v), mode=str(mode), digits=d, annotate=False)

            def _fmt_range(lo: float, hi: float, *, decimals: int | None = None, sig: int | None = None) -> str:
                lo_txt = _fmt_point(float(lo), decimals=decimals, sig=sig)
                hi_txt = _fmt_point(float(hi), decimals=decimals, sig=sig)
                if str(mode) == "probability":
                    return f"{lo_txt}–{hi_txt}"
                return f"{lo_txt}–{hi_txt} score"

            def _fmt_delta(w: float, *, decimals: int | None = None, sig: int | None = None) -> str:
                txt = _fmt_point(float(w), decimals=decimals, sig=sig)
                if str(mode) == "probability":
                    return f"Δ{txt}"
                return f"Δ{txt} score"

            ranges = stab.get("ranges") if isinstance(stab.get("ranges"), Mapping) else {}
            grade_min = str(ranges.get("grade_min") or "?")
            grade_max = str(ranges.get("grade_max") or "?")
            intended_min = float(ranges.get("intended_min") or 0.0)
            intended_max = float(ranges.get("intended_max") or 0.0)
            escape_min = float(ranges.get("escape_min") or 0.0)
            escape_max = float(ranges.get("escape_max") or 0.0)
            splice_min = float(ranges.get("splice_min") or 0.0)
            splice_max = float(ranges.get("splice_max") or 0.0)
            reg_min = float(ranges.get("regulatory_min") or 0.0)
            reg_max = float(ranges.get("regulatory_max") or 0.0)

            intended_w = max(0.0, float(intended_max) - float(intended_min))
            escape_w = max(0.0, float(escape_max) - float(escape_min))
            splice_w = max(0.0, float(splice_max) - float(splice_min))
            reg_w = max(0.0, float(reg_max) - float(reg_min))

            tooltip_lines = [
                f"Score: {score:.2f} ({interp_txt})",
                "Widths: intended "
                + _fmt_delta(intended_w, decimals=1)
                + " · escape "
                + _fmt_delta(escape_w, decimals=2)
                + " · splice "
                + _fmt_delta(splice_w, sig=3)
                + " · regulatory "
                + _fmt_delta(reg_w, sig=3),
            ]
            if show_grade:
                tooltip_lines.append(f"Grade range: {grade_min}…{grade_max}")
            tooltip_lines += [
                f"Intended: {_fmt_range(intended_min, intended_max, decimals=1)}",
                f"Escape risk: {_fmt_range(escape_min, escape_max, decimals=2)}",
                f"Splice risk: {_fmt_range(splice_min, splice_max, sig=3)}",
                f"Regulatory risk: {_fmt_range(reg_min, reg_max, sig=3)}",
            ]
            variants = stab.get("variants") if isinstance(stab.get("variants"), list) else []
            if variants:
                tooltip_lines.append("")
                tooltip_lines.append("Variants:")
                for v in variants:
                    if not isinstance(v, Mapping):
                        continue
                    preset = str(v.get("preset") or "?")
                    vtype = str(v.get("variant_type") or "convergence_preset")
                    esc = float(v.get("escape_risk") or 0.0)
                    if vtype == "off_target_sweep":
                        otp = v.get("off_target_params") if isinstance(v.get("off_target_params"), Mapping) else {}
                        mm = otp.get("max_mm", "?")
                        mh = otp.get("max_hits", "?")
                        status = str(v.get("off_target_status") or otp.get("status") or "")
                        worst = v.get("off_target_worst_site_score")
                        worst_txt = f", worst {float(worst):.3g}" if isinstance(worst, (int, float)) else ""
                        if show_grade:
                            grade = str(v.get("grade") or "?")
                            tooltip_lines.append(f"OT sweep: mm≤{mm}, hits≤{mh}, {status}{worst_txt}, grade {grade}")
                        else:
                            tooltip_lines.append(f"OT sweep: mm≤{mm}, hits≤{mh}, {status}{worst_txt}")
                    else:
                        esc_txt = self._format_prob_value(esc, digits=2, annotate=True)
                        if show_grade:
                            grade = str(v.get("grade") or "?")
                            tooltip_lines.append(f"{preset}: grade {grade} · escape {esc_txt}")
                        else:
                            tooltip_lines.append(f"{preset}: escape {esc_txt}")
            return interp_txt, "\n".join(tooltip_lines)
        if status == "not_computed":
            reason = str(stab.get("reason") or "").strip()
            severity = str(stab.get("severity") or "").strip()
            sev_txt = f" ({severity})" if severity else ""
            if reason:
                return f"Not computed{sev_txt} · {reason}", f"{reason}\nSeverity: {severity or 'unknown'}"
            return f"Not computed{sev_txt}", f"Severity: {severity or 'unknown'}"
        return "Unknown", ""

    def _format_splice_risk_chip(self, contract_risk: Mapping[str, Any] | None) -> str:
        risk = contract_risk if isinstance(contract_risk, Mapping) else {}
        hazard = risk.get("hazard") if isinstance(risk.get("hazard"), Mapping) else None
        if not isinstance(hazard, Mapping):
            return "Not computed"
        status = str(hazard.get("status") or "")
        if status == "computed":
            p_donor = float(hazard.get("p_hits_splice_donor") or 0.0)
            p_acc = float(hazard.get("p_hits_splice_acceptor") or 0.0)
            donor_txt = self._format_prob_value(p_donor, digits=3)
            acc_txt = self._format_prob_value(p_acc, digits=3)
            return f"Donor {donor_txt} · Acc {acc_txt}"
        if status == "not_computed":
            reason = str(hazard.get("reason") or "").strip()
            return f"Not computed · {reason}" if reason else "Not computed"
        return "Unknown"

    def _format_regulatory_risk_chip(self, contract_risk: Mapping[str, Any] | None) -> str:
        risk = contract_risk if isinstance(contract_risk, Mapping) else {}
        hazard = risk.get("hazard") if isinstance(risk.get("hazard"), Mapping) else None
        if not isinstance(hazard, Mapping):
            return "Not computed"
        status = str(hazard.get("status") or "")
        if status == "computed":
            p_promoter = float(hazard.get("p_hits_promoter") or 0.0)
            p_enhancer = float(hazard.get("p_hits_enhancer") or 0.0)
            prom_txt = self._format_prob_value(p_promoter, digits=3)
            enh_txt = self._format_prob_value(p_enhancer, digits=3)
            return f"Prom {prom_txt} · Enh {enh_txt}"
        if status == "not_computed":
            reason = str(hazard.get("reason") or "").strip()
            return f"Not computed · {reason}" if reason else "Not computed"
        return "Unknown"

    def _update_search_mode_badge(self, run: RunModel | None) -> None:
        if not hasattr(self, "_meta_chip_row"):
            return
        if run is None:
            try:
                self._meta_project_chip.hide()
            except Exception:
                pass
            return
        meta = getattr(run, "metadata", {}) or {}
        if meta.get("project_id") or meta.get("project"):
            # Project metadata already occupies the chip; don't override with search mode.
            return
        cfg = getattr(run, "config", {}) or {}
        genome = cfg.get("genome", {}) if isinstance(cfg, dict) else {}
        if not genome:
            return
        gid = genome.get("genome_id", "?")
        mode = (genome.get("search_mode") or "window").lower()
        fm_path = genome.get("fm_index_path") or ""
        fm_builder = genome.get("fm_builder") or ""
        if mode == "whole" and fm_path:
            badge = f"[WHOLE GENOME] {gid}"
            tooltip = f"Off-target search via FM index: {fm_path}"
            accent = QColor(58, 232, 200)
            bg = QColor(accent)
            bg.setAlphaF(0.18)
            border = QColor(accent)
            border.setAlphaF(0.85)
            style = (
                "border-radius: 999px; padding: 2px 8px; "
                f"background: {bg.name(QColor.HexArgb)}; "
                f"border: 1px solid {border.name(QColor.HexArgb)}; "
                "font-size: 11px; color: palette(window-text);"
            )
        else:
            badge = f"[WINDOW] {gid}"
            tooltip = "Off-targets limited to active window"
            style = self._meta_project_chip.styleSheet()
        try:
            self._meta_project_chip.setText(badge)
            self._meta_project_chip.setToolTip(tooltip)
            self._meta_project_chip.setStyleSheet(style)
            self._meta_project_chip.show()
            self._meta_chip_row.show()
            if fm_path or fm_builder:
                fm_name = Path(fm_path).name if fm_path else ""
                builder_txt = fm_builder or ""
                self._meta_index_label.setText(f"Index: {fm_name} {builder_txt}")
                self._meta_index_label.show()
            else:
                self._meta_index_label.hide()
        except Exception:
            pass

    # Run timeline ----------------------------------------------------
    def set_run_list(self, runs: list[RunModel]) -> None:
        """Provide an ordered list of runs for the focus-mode scrubber."""
        items: list[tuple[str, str | None]] = []
        for r in runs or []:
            run_id = getattr(r, "run_id", None)
            if run_id is None:
                continue
            label = getattr(r, "run_label", None) or getattr(r, "guide_id", None) or None
            edit_type = str(getattr(r, "edit_type", ""))
            if "prime" in edit_type.lower():
                label = f"{label or run_id} [PE]"
            items.append((str(run_id), label))
        self._run_list = items
        # Build parent/child maps from run metadata if present
        self._parent_map = {}
        self._has_children = {}
        for r in runs or []:
            pid = getattr(r, "parent_run_id", None)
            rid = getattr(r, "run_id", None)
            if rid is not None and pid:
                rid_s = str(rid)
                pid_s = str(pid)
                self._parent_map[rid_s] = pid_s
                self._has_children[pid_s] = True
        try:
            self._timeline.set_runs(items, self._parent_map)
            self._timeline.setVisible(self._focus_mode and bool(items))
        except Exception:
            pass
        # reset lens chart filter on new list
        try:
            self.chart_prob.set_lens(self._lens)
        except Exception:
            pass

    def set_run_select_handler(self, handler) -> None:
        """Set a callable(run_id: str) to invoke when timeline selection changes."""
        self._run_select_handler = handler

    def _update_metadata_chips(self) -> None:
        if self._current_run is None:
            self._meta_chip_row.hide()
            return

        meta = getattr(self._current_run, "metadata", {}) or {}
        project = meta.get("project_id") or meta.get("project")
        sample = meta.get("sample_id") or meta.get("sample")
        author = meta.get("author")

        any_visible = False

        if project:
            self._meta_project_chip.setText(f"Project: {project}")
            self._meta_project_chip.show()
            any_visible = True
        else:
            self._meta_project_chip.hide()

        if sample:
            self._meta_sample_chip.setText(f"Sample: {sample}")
            self._meta_sample_chip.show()
            any_visible = True
        else:
            self._meta_sample_chip.hide()

        if author:
            self._meta_author_chip.setText(f"Author: {author}")
            self._meta_author_chip.show()
            any_visible = True
        else:
            self._meta_author_chip.hide()

        if str(getattr(self, "_detail_level", "overview")) == "overview":
            any_visible = False
        self._meta_chip_row.setVisible(any_visible)

    def _set_run_chips(self, labels: Sequence[str]) -> None:
        if isinstance(labels, str):
            labels = [labels]
        layout: FlowLayout = self._run_chip_row.layout()  # type: ignore[assignment]
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        self._run_chips = []
        for text in labels:
            chip = QLabel(text, self._run_chip_row)
            chip.setObjectName("RunChip")
            layout.addWidget(chip)
            self._run_chips.append(chip)
        # FlowLayout doesn't use stretch; wrapping handles spacing.
        visible = bool(labels)
        if str(getattr(self, "_detail_level", "overview")) == "overview":
            visible = False
        if bool(getattr(self, "_compact_mode", False)) and str(getattr(self, "_detail_level", "overview")) != "debug":
            visible = False
        self._run_chip_row.setVisible(visible)

    def _refresh_run_chips(self, data: OutcomeExplorerData | None) -> None:
        labels: list[str] = []
        if data is not None:
            if data.guide_id:
                labels.append(str(data.guide_id))
            if self._evs and isinstance(self._evs, dict):
                seq = self._evs.get("sequence", {}) if isinstance(self._evs.get("sequence"), dict) else {}
                locus = seq.get("referenceLocus", {}) if isinstance(seq, dict) else {}
                chrom = locus.get("chrom")
                start = locus.get("start")
                end = locus.get("end")
                if chrom is not None and start is not None and end is not None:
                    labels.append(f"{chrom}:{start}-{end}")
            labels.append(f"{len(data.rows)} outcomes")
            sim = self._evs.get("simulation", {}) if isinstance(self._evs, dict) else {}
            draws = None
            if isinstance(sim, dict):
                cfg = sim.get("config", {}) if isinstance(sim.get("config"), dict) else sim
                draws = cfg.get("draws") if isinstance(cfg, dict) else None
            if draws:
                labels.append(f"Draws: {draws}")
            backend = self._backend_name or self._backend_kind or (sim.get("engine") if isinstance(sim, dict) else None)
            if backend:
                labels.append(f"Backend: {backend}")
        self._set_run_chips(labels)

    def _update_pathway_mix_label(self, data: OutcomeExplorerData | None, *, run_kind: str) -> None:
        label = getattr(self, "_pathway_mix_label", None)
        if not isinstance(label, QLabel):
            return
        if data is None:
            label.setVisible(False)
            return
        if str(run_kind or "").lower() != "crispr":
            label.setVisible(False)
            return
        pathways = tuple(getattr(data, "repair_pathways", ()) or ())
        if len(pathways) <= 1:
            label.setVisible(False)
            return
        quantitative_allowed = bool(str(getattr(self, "_decision_mode", "filter_only")) == "decision_grade")
        items: list[str] = []
        for pid in PATHWAY_ORDER:
            p = next((pp for pp in pathways if str(getattr(pp, "pathway", "")) == pid), None)
            if p is None:
                continue
            try:
                mass = float(getattr(p, "probability_mass", 0.0) or 0.0)
            except Exception:
                mass = 0.0
            if mass <= 0.0:
                continue
            nm = str(PATHWAY_UI_LABEL.get(pid, pid))
            if quantitative_allowed:
                items.append(f"{nm} {mass*100:.1f}%")
            else:
                items.append(nm)
        if not items:
            label.setVisible(False)
            return
        suffix = "" if quantitative_allowed else " (mass suppressed)"
        label.setText("Repair pathway mixture (derived): " + " · ".join(items) + suffix)
        show = str(getattr(self, "_detail_level", "overview")) != "overview"
        label.setVisible(bool(show))

    def _is_prime_run(self) -> bool:
        if self._backend_kind and "prime" in str(self._backend_kind).lower():
            return True
        if self._backend_name and "prime" in str(self._backend_name).lower():
            return True
        try:
            mode = ""
            if isinstance(self._evs, dict):
                mode = str(self._evs.get("editPlan", {}).get("mode", "")).lower()
            return "prime" in mode
        except Exception:
            return False

    def set_data(self, data: OutcomeExplorerData) -> None:
        # baseline change detection -> clear caches/overlays
        if self._baseline_data is not None:
            prev_fp = getattr(self._baseline_data, "fingerprint", None)
            if data.fingerprint and prev_fp and data.fingerprint != prev_fp:
                self._perturbation_cache.clear()
                self._perturbation_cache_fp = None
                self._baseline_overlay = None
                self._current_shift = 0
                self._strand_flipped = False
                if hasattr(self.chart_pos, "set_overlay"):
                    self.chart_pos.set_overlay(None)
                if hasattr(self.chart_prob, "set_overlay"):
                    self.chart_prob.set_overlay(None)
                if getattr(self, "_overlay_toggle", None):
                    self._overlay_toggle.setChecked(False)

        self._data = data
        self._sync_exploratory_color_ack_for_data(data)
        self._apply_probability_mode()
        if self._baseline_data is None or self._current_shift == 0:
            self._baseline_data = data
        if self._baseline_data is not None:
            self._perturbation_cache_fp = getattr(self._baseline_data, "fingerprint", None)
        self._backend_name = data.backend_name
        self._backend_kind = data.backend_kind
        self._perf_simple = len(data.rows) > 400
        self._current_run_label = self._label_from_evs(self._evs)
        self._prime_meta = None
        # Propagate perf mode to charts to optionally skip animations/tooltips on huge runs.
        self.chart_pos._perf_simple = self._perf_simple
        if hasattr(self, "chart_prob"):
            self.chart_prob._perf_simple = self._perf_simple
        self._current_selection = None
        self._current_sequence_ctx = None
        self._delta_label.setText("")
        run_kind = "prime" if self._is_prime_run() else "crispr"
        for bar in data.bars:
            bar.run_kind = run_kind
            if "intended" in (bar.label or "").lower():
                bar.intended = True  # type: ignore[attr-defined]
        for row in data.rows:
            row.run_kind = run_kind
            if "intended" in (row.label or "").lower():
                row.intended = True
            if getattr(row, "pathway", None) is None:
                row.pathway = classify_repair_pathway(label=str(row.label), category=str(row.category))
        for bar in data.bars:
            if getattr(bar, "pathway", None) is None:
                bar.pathway = classify_repair_pathway(label=str(bar.label), category=str(bar.category))
        try:
            if run_kind == "crispr":
                self.filters.set_pathways([p.pathway for p in getattr(data, "repair_pathways", ())])
            else:
                self.filters.set_pathways([])
            ui_path = "all"
            try:
                ui_path = str(self.filters.pathway_combo.currentData() or "all")
            except Exception:
                ui_path = "all"
            self._last_filter = (self._last_filter[0], self._last_filter[1], self._last_filter[2], ui_path)
        except Exception:
            pass
        # refresh metadata chips in case no run model was provided
        self._update_metadata_chips()
        self._refresh_run_chips(data)
        try:
            self.filters.set_outcome_count(len(data.rows))
        except Exception:
            pass
        self._update_contract_badges()
        self._refresh_posterior_context_panel()
        try:
            self.chart_pos.set_context(_format_thermo_context(data.thermo_context), data.calibration_badge)
        except Exception:
            pass
        summary = data.summary
        top_label = summary.top_outcome or ""
        top_value = top_label
        try:
            top_prob = next((r.probability for r in data.rows if r.label == top_label), None)
            if top_prob is not None:
                top_value = f"{top_label} ({self._format_prob_value(float(top_prob), digits=1)})"
        except Exception:
            top_value = top_label

        # Summary Contract v2: control/risk/integrity first.
        contract = self._run_summary_v2() or {}
        # UI is a projection of artifact state: decision-grade requires the run artifact gate to be eligible.
        self._decision_mode = self._effective_decision_mode()
        self._update_provenance_strip()
        contract_control = contract.get("control") if isinstance(contract.get("control"), Mapping) else {}
        contract_risk = contract.get("risk") if isinstance(contract.get("risk"), Mapping) else {}
        contract_verdict = contract.get("verdict") if isinstance(contract.get("verdict"), Mapping) else {}
        contract_model_stack = contract.get("model_stack") if isinstance(contract.get("model_stack"), Mapping) else {}
        iteration = contract_control.get("iteration") if isinstance(contract_control.get("iteration"), Mapping) else None
        contract_repair_model = (
            contract_model_stack.get("repair_model")
            if isinstance(contract_model_stack.get("repair_model"), Mapping)
            else {}
        )

        dominance_val = float(
            contract_control.get("dominance_ratio", getattr(summary, "dominance_ratio", 0.0)) or 0.0
        )
        top_label_ui = top_outcome_ui_label(dominance_ratio=dominance_val)
        dominance_txt = "∞" if math.isinf(dominance_val) else f"{dominance_val:.2f}"
        entropy_bits = float(contract_control.get("entropy_bits", getattr(summary, "entropy_bits", 0.0)) or 0.0)
        entropy_txt = f"{entropy_bits:.2f} bits"
        if str(getattr(self, "_decision_mode", "filter_only")) != "decision_grade":
            dominance_txt = "suppressed"
            entropy_txt = "suppressed"
        intended_p = float(
            contract_control.get("intended_functional_p", getattr(summary, "intended_functional_p", 0.0)) or 0.0
        )
        intended_txt = self._format_prob_value(intended_p, digits=1)
        no_cut_p = float(contract_control.get("no_cut_p", getattr(summary, "no_cut_prob", 0.0)) or 0.0)
        no_cut_txt = self._format_prob_value(no_cut_p, digits=1)
        stability_value, stability_tooltip = self._format_stability_chip(contract_control)

        tail = contract_risk.get("tail") if isinstance(contract_risk.get("tail"), Mapping) else {}
        tail_p99 = tail.get("global_p99_del_bp", getattr(summary, "tail_p99_del_bp", None))
        tail_cvar99 = tail.get("global_cvar99_del_bp", getattr(summary, "tail_cvar99_del_bp", None))
        tail_p_ge_50 = tail.get("p_any_large_del_ge_50bp", getattr(summary, "tail_p_ge_50bp", None))
        if tail_p99 is None or tail_cvar99 is None:
            tail_txt = "p99 — · cvar99 —"
        else:
            if tail_p_ge_50 is None:
                tail_txt = f"p99 {float(tail_p99):.0f} bp · cvar99 {float(tail_cvar99):.0f} bp"
            else:
                tail_txt = f"cvar99 {float(tail_cvar99):.0f} bp · P≥50 {self._format_prob_value(float(tail_p_ge_50), digits=3)}"
        if str(getattr(self, "_decision_mode", "filter_only")) != "decision_grade":
            tail_txt = "suppressed"

        # Governance inputs used by the decision details panel.
        decision_mode = self._decision_mode
        decision_grade = bool(decision_mode == "decision_grade")
        validity = contract.get("validity") if isinstance(contract.get("validity"), Mapping) else {}
        uncertainty = contract.get("uncertainty") if isinstance(contract.get("uncertainty"), Mapping) else {}
        grade = str(contract_verdict.get("grade") or "").strip().upper()
        if grade not in {"A", "B", "C", "D", "F"}:
            grade = "C"

        iteration_chips, _ = self._build_iteration_chips(iteration)
        require_band = bool(intended_p < 0.8 or (decision_mode == "decision_grade" and grade not in {"A", "B"}))
        intended_edit_spec = contract.get("intended_edit_spec") if isinstance(contract.get("intended_edit_spec"), Mapping) else None
        intended_value = self._format_intended_with_context(
            intended_txt,
            intended_edit_spec,
            uncertainty,
            require_band=require_band,
        )
        intended_tip = self._format_intended_tooltip(
            intended_edit_spec,
            uncertainty,
            require_band=require_band,
        )

        noncompliance = (
            contract_verdict.get("noncompliance_reasons")
            if isinstance(contract_verdict.get("noncompliance_reasons"), list)
            else []
        )
        noncompliance = [str(r) for r in noncompliance if str(r).strip()]
        noncompliance_set = set(noncompliance)

        validity_status = str(validity.get("status") or "")
        validity_causes = validity.get("root_causes") if isinstance(validity.get("root_causes"), list) else []
        validity_causes = [str(c) for c in validity_causes if str(c).strip()]
        validity_tip = "\n".join([_label_from_root_cause(c) for c in validity_causes]).strip()

        policy_compliant = contract_verdict.get("compliant_with_policy")
        policy_tip = "\n".join([_label_from_root_cause(r) for r in noncompliance]).strip()

        unc_status = str(uncertainty.get("status") or "not_computed").strip().lower()
        unc_computed = bool(unc_status == "computed")
        unc_reason = str(uncertainty.get("reason") or "").strip()

        auditable, audit_reason = intended_functional_auditability(intended_edit_spec if isinstance(intended_edit_spec, Mapping) else None)
        spec_short, spec_tip = self._format_intended_edit_spec_short(intended_edit_spec if isinstance(intended_edit_spec, Mapping) else None)
        if decision_grade:
            intended_spec_value = ("Auditable · " if auditable else "Not auditable · ") + (audit_reason or spec_short)
        else:
            intended_spec_value = ("Declared · " + spec_short) if isinstance(intended_edit_spec, Mapping) else spec_short
        intended_spec_tip = spec_tip or ""

        claims = contract_control.get("claims") if isinstance(contract_control.get("claims"), Mapping) else None
        claims_required = bool(claims.get("required")) if isinstance(claims, Mapping) and "required" in claims else None
        claims_status = str(claims.get("status") or "not_computed") if isinstance(claims, Mapping) else "not_computed"
        claims_computed = bool(claims_status == "computed")
        claims_clean = claims.get("clean") if isinstance(claims, Mapping) else None
        claims_reason = str(claims.get("reason") or "").strip() if isinstance(claims, Mapping) else ""
        claims_blocks = bool(claims_required is True and (not claims_computed or claims_clean is False))
        if "claims_dirty" in noncompliance_set:
            claims_blocks = True
        claims_value = "Computed" if claims_computed else "Not computed"
        if claims_computed and isinstance(claims_clean, bool):
            claims_value = "Clean" if claims_clean else "Dirty"
        if claims_reason and not claims_computed:
            claims_value = claims_value + f" · {claims_reason}"

        if decision_mode != "decision_grade":
            is_demo = False
            try:
                run = getattr(self, "_current_run", None)
                meta = None
                if isinstance(run, Mapping):
                    meta_raw = run.get("metadata")
                    meta = meta_raw if isinstance(meta_raw, Mapping) else None
                elif run is not None:
                    meta_raw = getattr(run, "metadata", None)
                    meta = meta_raw if isinstance(meta_raw, Mapping) else None
                if isinstance(meta, Mapping) and str(meta.get("scenario") or "").strip().lower() == "demo":
                    is_demo = True
            except Exception:
                is_demo = False
            if not is_demo:
                evs = getattr(self, "_evs", None)
                if isinstance(evs, Mapping):
                    cfg = evs.get("config") if isinstance(evs.get("config"), Mapping) else {}
                    meta2 = cfg.get("metadata") if isinstance(cfg.get("metadata"), Mapping) else {}
                    preset_id = str(meta2.get("preset_id") or "").strip().lower()
                    if preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"):
                        is_demo = True
            if is_demo:
                claims_value = "Disabled (demo)"
                claims_reason = "Claims evaluation is disabled in demo mode (decision-grade only)."
                claims_blocks = False
                claims_computed = False

        iter_required = bool(iteration.get("required")) if isinstance(iteration, Mapping) and "required" in iteration else None
        iter_status = str(iteration.get("status") or "not_computed") if isinstance(iteration, Mapping) else "not_computed"
        iter_computed = bool(iter_status == "computed")
        iter_reason = str(iteration.get("reason") or "").strip() if isinstance(iteration, Mapping) else ""
        trans_required = bool(iteration.get("transition_required")) if isinstance(iteration, Mapping) and "transition_required" in iteration else False
        trans_model = str(iteration.get("transition_model") or "identity") if isinstance(iteration, Mapping) else "identity"
        iter_blocks = bool((iter_required is True and not iter_computed) or (trans_required and trans_model == "identity"))
        iter_value = "Computed" if iter_computed else "Not computed"
        if trans_required and trans_model == "identity":
            iter_value = "Unsupported (T=identity)"
        if iter_reason and not iter_computed:
            iter_value = iter_value + f" · {iter_reason}"

        species_block = contract.get("species_detection") if isinstance(contract.get("species_detection"), Mapping) else None
        species_required = bool(species_block.get("required")) if isinstance(species_block, Mapping) and "required" in species_block else None
        species_status = str(species_block.get("status") or "unknown") if isinstance(species_block, Mapping) else "unknown"
        species_resolved = bool(species_status == "resolved")
        species_value = "Resolved" if species_resolved else species_status.replace("_", " ").title()
        if isinstance(species_block, Mapping):
            taxon_name = str(species_block.get("taxon_name") or "").strip()
            if taxon_name:
                species_value = taxon_name if species_resolved else f"{species_value} · {taxon_name}"
        species_blocks = bool(species_required is True and not species_resolved)

        risk_offt = contract_risk.get("off_target") if isinstance(contract_risk.get("off_target"), Mapping) else None
        offt_status = str(risk_offt.get("status") or "not_computed") if isinstance(risk_offt, Mapping) else "not_computed"
        offt_computed = bool(offt_status == "computed")
        offt_required = True if "off_target_required_but_not_computed" in noncompliance_set else None
        offt_blocks = bool(offt_required is True and not offt_computed)

        risk_hazard = contract_risk.get("hazard") if isinstance(contract_risk.get("hazard"), Mapping) else None
        hazard_status = str(risk_hazard.get("status") or "not_computed") if isinstance(risk_hazard, Mapping) else "not_computed"
        hazard_computed = bool(hazard_status == "computed")
        splice_required = True if "splice_risk_required_but_not_computed" in noncompliance_set else None
        splice_blocks = bool(splice_required is True and not hazard_computed)
        reg_required = True if "regulatory_risk_required_but_not_computed" in noncompliance_set else None
        reg_blocks = bool(reg_required is True and not hazard_computed)

        required_rows: list[DecisionDetailRow] = [
            DecisionDetailRow(
                "Decision grade",
                "Enabled" if decision_mode == "decision_grade" else "Not decision grade",
                required=True,
                computed=bool(decision_mode == "decision_grade"),
                blocks=bool(decision_mode != "decision_grade"),
            ),
            DecisionDetailRow(
                "Run validity",
                "Valid" if validity_status != "invalid" else "Invalid",
                required=True,
                computed=True,
                blocks=bool(validity_status == "invalid"),
                tooltip=validity_tip or None,
            ),
            DecisionDetailRow(
                "Policy",
                "Compliant" if policy_compliant is True else ("Noncompliant" if policy_compliant is False else "—"),
                required=True if isinstance(policy_compliant, bool) else None,
                computed=isinstance(policy_compliant, bool),
                blocks=bool(policy_compliant is False),
                tooltip=policy_tip or None,
            ),
            DecisionDetailRow(
                "Uncertainty",
                "Computed" if unc_computed else ("Not computed" + (f" · {unc_reason}" if unc_reason else "")),
                required=True,
                computed=unc_computed,
                blocks=bool(decision_grade and not unc_computed),
            ),
            DecisionDetailRow(
                "Intended edit spec",
                intended_spec_value,
                required=True,
                computed=bool(auditable),
                blocks=bool(decision_grade and not auditable),
                tooltip=intended_spec_tip or None,
            ),
        ]
        if isinstance(species_block, Mapping):
            required_rows.append(
                DecisionDetailRow(
                    "Species",
                    species_value,
                    required=species_required,
                    computed=species_resolved,
                    blocks=species_blocks,
                )
            )
        if isinstance(claims, Mapping):
            required_rows.append(
                DecisionDetailRow(
                    "Claims",
                    claims_value,
                    required=claims_required,
                    computed=claims_computed,
                    blocks=claims_blocks,
                    tooltip=claims_reason or None,
                )
            )
        if isinstance(iteration, Mapping):
            required_rows.append(
                DecisionDetailRow(
                    "Iteration cap",
                    iter_value,
                    required=iter_required,
                    computed=iter_computed,
                    blocks=iter_blocks,
                    tooltip=iter_reason or None,
                )
            )
        required_rows.append(
            DecisionDetailRow(
                "Off-target risk",
                self._format_off_target_chip(contract_risk),
                required=offt_required,
                computed=offt_computed,
                blocks=offt_blocks,
            )
        )
        required_rows.append(
            DecisionDetailRow(
                "Splice risk",
                self._format_splice_risk_chip(contract_risk),
                required=splice_required,
                computed=hazard_computed,
                blocks=splice_blocks,
            )
        )
        required_rows.append(
            DecisionDetailRow(
                "Regulatory risk",
                self._format_regulatory_risk_chip(contract_risk),
                required=reg_required,
                computed=hazard_computed,
                blocks=reg_blocks,
            )
        )

        flags = contract_control.get("flags") if isinstance(contract_control.get("flags"), list) else []
        warn_plurality = any(str(f) == "plurality_regime" for f in flags)

        risk_rows: list[DecisionDetailRow] = [
            DecisionDetailRow(top_label_ui, top_value, computed=True),
            DecisionDetailRow(
                "Intended functional" if decision_mode == "decision_grade" else "Intended functional score",
                intended_value,
                tooltip=intended_tip or None,
            ),
            DecisionDetailRow("Tail risk", tail_txt),
            DecisionDetailRow("Off-target constraint", self._format_off_target_chip(contract_risk), computed=offt_computed),
            DecisionDetailRow("Splice risk", self._format_splice_risk_chip(contract_risk), computed=hazard_computed),
            DecisionDetailRow("Regulatory risk", self._format_regulatory_risk_chip(contract_risk), computed=hazard_computed),
            DecisionDetailRow("Escape risk", self._format_escape_risk_chip(contract_control)),
            DecisionDetailRow("Stability", stability_value, tooltip=stability_tooltip or None),
        ]
        if warn_plurality:
            risk_rows.insert(2, DecisionDetailRow("Warning", "Plurality regime", computed=True))

        rm_type = str(contract_repair_model.get("type") or "statistical")
        expl_rows: list[DecisionDetailRow] = [
            DecisionDetailRow("Repair model", repair_model_ui_label(model_type=rm_type).split(", ", 1)[-1], computed=True),
            DecisionDetailRow("Dominance", dominance_txt),
            DecisionDetailRow("Outcome entropy", entropy_txt),
            DecisionDetailRow("No cut", no_cut_txt),
        ]
        iter_computed_flag: bool | None = iter_computed if isinstance(iteration, Mapping) else None
        for spec in iteration_chips:
            lbl, val = spec[:2]
            expl_rows.append(DecisionDetailRow(str(lbl), str(val), computed=iter_computed_flag))

        # UI-only interaction diagnostics for CRISPR runs (window-local, proxy-only).
        if run_kind == "crispr":
            try:
                val, tip, computed = self._format_cas_dna_interaction_chip(
                    quantitative_allowed=decision_grade
                )
            except Exception:
                computed = False
            if computed:
                expl_rows.append(
                    DecisionDetailRow(
                        "Cas–DNA interaction (proxy)",
                        val,
                        computed=True,
                        tooltip=tip or None,
                    )
                )

        required_compact = [r for r in required_rows if r.blocks or r.required is True or r.computed is False]
        if not required_compact:
            required_compact = list(required_rows[:3])
        risk_compact = list(risk_rows[:5])
        expl_compact = list(expl_rows)

        self._summary_details_full = (required_rows, risk_rows, expl_rows)
        self._summary_details_compact = (required_compact, risk_compact, expl_compact)
        self._apply_summary_groups()
        try:
            self._refresh_decision_authority_banner(contract)
        except Exception:
            pass
        try:
            if hasattr(self, "_iteration_panel") and self._iteration_panel is not None:
                self._iteration_panel.set_trace(iteration)
        except Exception:
            pass
        self._refresh_export_block()
        self._update_viz_badge(data)
        self._update_rank_chip()
        try:
            self.outcome_legend.set_run_kind(run_kind)
        except Exception:
            pass
        try:
            self._update_pathway_mix_label(data, run_kind=run_kind)
        except Exception:
            pass
        self.chart_pos.set_run_kind(run_kind)
        self.chart_pos.set_data(data.bars, data.positions, data.heat_values)
        self.chart_prob.set_run_kind(run_kind)
        self.chart_prob.set_data(data.bars)
        try:
            self._timeline.set_prime_mode(run_kind == "prime")
        except Exception:
            pass
        self.table.set_rows(data.rows)
        self.details.set_selection(None, data.sequence, None, run_physics=data.summary)
        self.chart_pos.setSelected(None)
        self.chart_prob.setSelected(None)
        self.chart_pos.setHighlighted(None)
        self.chart_prob.setHighlighted(None)
        self.table.setHighlighted(None, lock=True)
        self._update_prob_mass(data.rows)
        self._apply_overlay()
        self._refresh_overlay_legend()
        self._update_prime_inspector()
        # reapply previous filters
        self._on_filters_changed(*self._last_filter)
        # Selection defaults:
        # - Summary: always land on the top outcome (narrative).
        # - Inspect: restore last user selection for this run, else fall back to top.
        inspect_mode = bool(getattr(self, "_inspect_mode", False))
        if inspect_mode:
            if data.run_id in self._last_selection_per_run:
                sel = self._last_selection_per_run[data.run_id]
                self._on_outcome_selected(sel.outcome_name, user=False)
            elif top_label:
                self._on_outcome_selected(top_label, user=False)
        else:
            if top_label:
                self._on_outcome_selected(top_label, user=False)
            elif data.run_id in self._last_selection_per_run:
                sel = self._last_selection_per_run[data.run_id]
                self._on_outcome_selected(sel.outcome_name, user=False)

        # Off-target heat track (if EVS layer present)
        try:
            if self._evs is not None and isinstance(self._evs, dict):
                layers = self._evs.get("visualization", {}).get("layers", [])
                for layer in layers:
                    if isinstance(layer, dict) and layer.get("kind", "").lower() == "track:offtargetheat":
                        heat = compute_offtarget_heat(self._evs)
                        # No rendering hook yet; placeholder to ensure computation works.
                        layer.setdefault("style", {})["computedHeatMax"] = float(heat.max()) if heat.size else 0.0
                        break
        except Exception:
            pass

    def _normalize_export_path(self, path_str: str, suffix: str) -> Path:
        path = Path(path_str)
        suffix = suffix if suffix.startswith(".") else f".{suffix}"
        if path.suffix.lower() != suffix.lower():
            path = path.with_suffix(suffix)
        return path

    def _suggest_export_path(self, filename: str, *, decision_mode_override: str | None = None) -> str:
        """
        Suggest a writable default file path for save dialogs.

        In some environments (e.g., WSL or containerized runs) the process CWD can be unwritable
        (often mounted under `/mnt/*`). Prefer the user's home directory when available.
        """
        candidates: list[Path] = []
        last_export = getattr(self, "_last_export_path", None)
        if last_export:
            try:
                candidates.append(Path(last_export).expanduser().resolve().parent)
            except Exception:
                pass

        # Prefer HOME over CWD for stability.
        try:
            candidates.append(Path.home())
        except Exception:
            pass
        try:
            candidates.append(Path.cwd())
        except Exception:
            pass

        tmpdir = os.environ.get("TMPDIR")
        if tmpdir:
            candidates.append(Path(tmpdir))
        candidates.append(Path("/tmp"))

        for base in candidates:
            try:
                if base.is_dir() and os.access(str(base), os.W_OK):
                    prefix = self._export_filename_prefix(decision_mode_override=decision_mode_override)
                    final = filename
                    if prefix and not final.startswith(prefix):
                        final = prefix + final
                    return str(base / final)
            except Exception:
                continue
        prefix = self._export_filename_prefix(decision_mode_override=decision_mode_override)
        if prefix and not filename.startswith(prefix):
            return prefix + filename
        return filename

    def _export_outcomes_csv(self) -> None:
        if self._data is None:
            return
        export_class = self._prompt_export_class("Export outcomes")
        if export_class is None:
            return
        mode_label = "DECISION_GRADE" if export_class == "decision_grade" else "EXPLORATORY"
        decision_mode_override = "filter_only" if export_class == "exploratory" else None
        path_str, _ = QFileDialog.getSaveFileName(
            self,
            f"Export outcomes as CSV — {mode_label}",
            self._suggest_export_path("helix_outcomes.csv", decision_mode_override=decision_mode_override),
            "CSV files (*.csv)",
        )
        if not path_str:
            return
        path = self._normalize_export_path(path_str, ".csv")

        try:
            stamp = limitations_stamp()
            decision_mode, interpretation, proof = self._governance_context_for_export(decision_mode_override=decision_mode_override)
            gov_prefix = governance_csv_prefix(
                decision_mode=decision_mode,
                interpretation=interpretation,
                decision_grade_proof=proof if isinstance(proof, Mapping) else None,
            )
            rows = self._data.rows
            quantitative_allowed = bool(decision_mode == "decision_grade")
            if quantitative_allowed:
                fieldnames = [
                    "name",
                    "category",
                    "pathway",
                    "prob",
                    "delta_bp",
                    "frameshift",
                    "peak_position",
                    "position_min",
                    "position_max",
                    "microhomology",
                    "pbs_dG",
                    "flap_ddG",
                    "E_pred",
                ]
            else:
                # DEMO/Exploratory: no probability-shaped outputs in exported data.
                fieldnames = [
                    "name",
                    "category",
                    "pathway",
                    "rank",
                    "tier",
                    "delta_bp",
                    "frameshift",
                    "position_min",
                    "position_max",
                    "microhomology",
                ]
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "w", newline="", encoding="utf8") as f:
                f.write(limitations_csv_prefix(stamp))
                f.write(gov_prefix)
                try:
                    f.write(self._cas_dna_interaction_csv_prefix(quantitative_allowed=quantitative_allowed))
                except Exception:
                    pass
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for idx, r in enumerate(rows):
                    if quantitative_allowed:
                        writer.writerow(
                            {
                                "name": r.label,
                                "category": r.category,
                                "pathway": r.pathway or "",
                                "prob": f"{r.probability:.6f}",
                                "delta_bp": r.delta_bp,
                                "frameshift": bool(r.frameshift),
                                "peak_position": r.peak_pos,
                                "position_min": r.start if r.start is not None else "",
                                "position_max": r.end if r.end is not None else "",
                                "microhomology": r.microhomology if r.microhomology is not None else "",
                                "pbs_dG": r.pbs_dg if r.pbs_dg is not None else "",
                                "flap_ddG": r.flap_ddg if r.flap_ddg is not None else "",
                                "E_pred": r.e_pred if r.e_pred is not None else "",
                            }
                        )
                    else:
                        rank = int(idx + 1)
                        writer.writerow(
                            {
                                "name": r.label,
                                "category": r.category,
                                "pathway": r.pathway or "",
                                "rank": rank,
                                "tier": tier_for_rank(rank).label,
                                "delta_bp": r.delta_bp,
                                "frameshift": bool(r.frameshift),
                                "position_min": r.start if r.start is not None else "",
                                "position_max": r.end if r.end is not None else "",
                                "microhomology": r.microhomology if r.microhomology is not None else "",
                            }
                        )
            self._write_export_provenance_sidecar(path, stamp, decision_mode_override=decision_mode_override)
        except Exception as exc:
            QMessageBox.critical(self, "Export outcomes", f"Failed to export outcomes: {exc}")
        else:
            # Keep UX quiet; no toast on success.
            self._last_export_path = str(path)

    def _write_export_provenance_sidecar(
        self,
        export_path: Path,
        stamp: Mapping[str, Any] | None,
        *,
        decision_mode_override: str | None = None,
    ) -> None:
        """
        Write a machine-readable provenance sidecar for exported text artifacts (CSV/HTML/etc).

        This keeps exports self-describing even when the primary format can't embed metadata.
        """
        sidecar = export_path.with_name(export_path.name + ".provenance.json")
        governance_json = self._governance_export_metadata_json(decision_mode_override=decision_mode_override)
        governance = None
        if governance_json:
            try:
                governance = json.loads(governance_json)
            except Exception:
                governance = None
        kind = export_path.suffix.lstrip(".").lower()
        export_kind = f"outcome_explorer_{kind}" if kind else "outcome_explorer_export"
        export_sha = None
        export_bytes = None
        try:
            raw = export_path.read_bytes()
            export_bytes = len(raw)
            export_sha = f"sha256:{hashlib.sha256(raw).hexdigest()}"
        except Exception:
            export_sha = None
            export_bytes = None
        payload = build_export_provenance_v1(
            export_kind=export_kind,
            export_path=export_path.name,
            export_sha256=export_sha,
            export_bytes=export_bytes,
            run_id=getattr(getattr(self, "_data", None), "run_id", None),
            governance=(governance if isinstance(governance, Mapping) else None),
            limitations_stamp=stamp,
        )
        try:
            decision_mode = ""
            if isinstance(governance, Mapping):
                decision_mode = str(governance.get("decision_mode") or "").strip().lower()
            quantitative_allowed = bool(decision_mode == "decision_grade")
            diagnostics = payload.setdefault("diagnostics", {})
            if isinstance(diagnostics, dict):
                diagnostics["cas_dna_interaction_proxy"] = self._exportable_cas_dna_interaction_proxy(
                    quantitative_allowed=quantitative_allowed
                )
        except Exception:
            pass
        sidecar.parent.mkdir(parents=True, exist_ok=True)
        with open(sidecar, "w", encoding="utf-8", newline="\n") as f:
            f.write(json.dumps(payload, indent=2, sort_keys=True))
            f.write("\n")

    def _pixmap_to_png_bytes(
        self,
        pix,
        stamp: Mapping[str, Any] | None = None,
        *,
        decision_mode_override: str | None = None,
    ) -> bytes:
        buffer = QBuffer()
        buffer.open(QIODevice.WriteOnly)
        if stamp:
            try:
                img = pix.toImage()
                img.setText("helix_limitations", json.dumps(stamp, sort_keys=True))
                wm_img = self._watermark_export_image(img, decision_mode_override=decision_mode_override)
                gov_json = self._governance_export_metadata_json(decision_mode_override=decision_mode_override)
                if gov_json:
                    wm_img.setText("helix_governance", gov_json)
                try:
                    gov = json.loads(gov_json) if gov_json else {}
                    decision_mode = str(gov.get("decision_mode") or "").strip().lower() if isinstance(gov, Mapping) else ""
                    proxy = self._exportable_cas_dna_interaction_proxy(
                        quantitative_allowed=bool(decision_mode == "decision_grade")
                    )
                    wm_img.setText("helix_cas_dna_interaction_proxy", json.dumps(proxy, sort_keys=True))
                except Exception:
                    pass
                wm_img.save(buffer, "PNG")
                return bytes(buffer.data())
            except Exception:
                pass
        buffer = QBuffer()
        buffer.open(QIODevice.WriteOnly)
        pix.save(buffer, "PNG")
        return bytes(buffer.data())

    def _export_report_html(self) -> None:
        if self._data is None:
            return
        export_class = self._prompt_export_class("Export report")
        if export_class is None:
            return
        mode_label = "DECISION_GRADE" if export_class == "decision_grade" else "EXPLORATORY"
        decision_mode_override = "filter_only" if export_class == "exploratory" else None
        path_str, _ = QFileDialog.getSaveFileName(
            self,
            f"Export guide report (HTML) — {mode_label}",
            self._suggest_export_path("helix_report.html", decision_mode_override=decision_mode_override),
            "HTML files (*.html)",
        )
        if not path_str:
            return
        path = self._normalize_export_path(path_str, ".html")

        try:
            stamp = limitations_stamp()
            decision_mode, interpretation, proof = self._governance_context_for_export(decision_mode_override=decision_mode_override)
            quantitative_allowed = bool(decision_mode == "decision_grade")
            gov_prefix = governance_csv_prefix(
                decision_mode=decision_mode,
                interpretation=interpretation,
                decision_grade_proof=proof if isinstance(proof, Mapping) else None,
            )
            chart_bytes = self._pixmap_to_png_bytes(self._current_chart().grab(), stamp, decision_mode_override=decision_mode_override)
            if quantitative_allowed:
                outcomes = [
                    {
                        "name": r.label,
                        "category": r.category,
                        "pathway": r.pathway,
                        "prob": r.probability,
                        "delta_bp": r.delta_bp,
                        "frameshift": r.frameshift,
                        "peak_position": r.peak_pos,
                        "position_min": r.start,
                        "position_max": r.end,
                        "microhomology": r.microhomology,
                        "pbs_dG": r.pbs_dg,
                        "flap_ddG": r.flap_ddg,
                        "E_pred": r.e_pred,
                    }
                    for r in self._data.rows
                ]
            else:
                outcomes = [
                    {
                        "name": r.label,
                        "category": r.category,
                        "pathway": r.pathway,
                        "rank": int(idx + 1),
                        "tier": tier_for_rank(int(idx + 1)).label,
                        "delta_bp": r.delta_bp,
                        "frameshift": bool(r.frameshift),
                        "position_min": r.start,
                        "position_max": r.end,
                        "microhomology": r.microhomology,
                    }
                    for idx, r in enumerate(self._data.rows)
                ]
            csv_text = None
            try:
                from io import StringIO

                buf = StringIO()
                writer = csv.writer(buf)
                writer.writerow(
                    (
                        [
                            "name",
                            "category",
                            "pathway",
                            "prob",
                            "delta_bp",
                            "frameshift",
                            "peak_position",
                            "position_min",
                            "position_max",
                            "microhomology",
                            "pbs_dG",
                            "flap_ddG",
                            "E_pred",
                        ]
                        if quantitative_allowed
                        else [
                            "name",
                            "category",
                            "pathway",
                            "rank",
                            "tier",
                            "delta_bp",
                            "frameshift",
                            "position_min",
                            "position_max",
                            "microhomology",
                        ]
                    )
                )
                for o in outcomes:
                    if quantitative_allowed:
                        writer.writerow(
                            [
                                o["name"],
                                o["category"],
                                o.get("pathway") or "",
                                o["prob"],
                                o["delta_bp"],
                                o["frameshift"],
                                o["peak_position"],
                                o["position_min"],
                                o["position_max"],
                                o["microhomology"],
                                o["pbs_dG"],
                                o["flap_ddG"],
                                o["E_pred"],
                            ]
                        )
                    else:
                        writer.writerow(
                            [
                                o["name"],
                                o["category"],
                                o.get("pathway") or "",
                                o["rank"],
                                o["tier"],
                                o["delta_bp"],
                                o["frameshift"],
                                o["position_min"],
                                o["position_max"],
                                o["microhomology"],
                            ]
                        )
                try:
                    csv_text = (
                        limitations_csv_prefix(stamp)
                        + gov_prefix
                        + self._cas_dna_interaction_csv_prefix(quantitative_allowed=quantitative_allowed)
                        + buf.getvalue()
                    )
                except Exception:
                    csv_text = limitations_csv_prefix(stamp) + gov_prefix + buf.getvalue()
            except Exception:
                csv_text = None

            guide_meta = {
                "guide_id": self._data.guide_id,
                "run_id": self._data.run_id,
                "cut_index": self._data.cut_index,
            }
            if self._current_run is not None:
                guide_meta.setdefault("target_locus", getattr(self._current_run, "target_locus", ""))
                guide_meta.setdefault("edit_type", getattr(self._current_run, "edit_type", ""))

            physics = {
                "engine_name": self._engine_info.name if self._engine_info else self._backend_name,
                "backend": self._engine_info.backend if self._engine_info else self._backend_kind,
                "crispr_scoring_version": self._engine_info.crispr_scoring_version if self._engine_info else None,
                "prime_scoring_version": self._engine_info.prime_scoring_version if self._engine_info else None,
            }
            if quantitative_allowed:
                physics.update(
                    {
                        "pbs_dG": self._data.summary.pbs_dg,
                        "flap_ddG": self._data.summary.flap_ddg,
                        "E_pred": self._data.summary.e_pred,
                        "cut_prob": self._data.summary.cut_prob,
                        "frameshift_prob": self._data.summary.frameshift_prob,
                    }
                )

            meta = {}
            if self._current_run is not None:
                try:
                    meta = dict(getattr(self._current_run, "metadata", {}) or {})
                except Exception:
                    meta = {}
            meta.setdefault("run_id", self._data.run_id)
            meta["limitations"] = stamp
            try:
                meta["cas_dna_interaction_proxy"] = self._exportable_cas_dna_interaction_proxy(
                    quantitative_allowed=quantitative_allowed
                )
            except Exception:
                pass

            save_session_report(
                path,
                guide_meta,
                physics,
                outcomes,
                chart_bytes,
                helix_flat_png=None,
                helix_helix_png=None,
                csv_text=csv_text,
                extra_metadata=meta,
                contract_v2=self._run_summary_v2(),
                limitations=stamp,
            )
        except Exception as exc:
            QMessageBox.critical(self, "Export report", f"Failed to export report: {exc}")
        else:
            # Keep UX quiet; no toast on success.
            self._last_export_path = str(path)

    def _on_filters_changed(self, min_prob: float, category: str, sort_key: str, pathway: str = "all") -> None:
        if self._data is None:
            return
        if str(getattr(self, "_decision_mode", "filter_only")) != "decision_grade":
            # Non-calibrated mode: suppress quantitative thresholds and enforce
            # stable rank ordering.
            min_prob = 0.0
            sort_key = "probability"
        pathway = str(pathway or "all").strip().lower() or "all"
        self._last_filter = (min_prob, category, sort_key, pathway)
        self.table.set_pinned_label(None)
        try:
            self.chart_pos.set_filters(min_prob, category, pathway)
        except TypeError:
            self.chart_pos.set_filters(min_prob, category)
        try:
            self.chart_prob.set_filters(min_prob, category, pathway)
        except TypeError:
            self.chart_prob.set_filters(min_prob, category)
        # Persist filter in EVS layer if present
        try:
            layer = self._outcomes_layer
            if layer is not None:
                style = layer.setdefault("style", {})
                style["filter"] = category
                style["sortBy"] = sort_key
                style["pathwayFilter"] = pathway
        except Exception:
            pass
        rows = [r for r in self._data.rows if r.probability >= min_prob]
        if category == "insertions":
            rows = [r for r in rows if "insertion" in r.category]
        elif category == "deletions":
            rows = [r for r in rows if "deletion" in r.category]
        elif category == "no_cut":
            rows = [r for r in rows if r.category == "no_cut"]
        elif category == "frameshift":
            rows = [r for r in rows if r.frameshift]
        if pathway != "all":
            rows = [
                r
                for r in rows
                if str(
                    getattr(r, "pathway", None)
                    or classify_repair_pathway(label=str(r.label), category=str(r.category))
                ).strip().lower()
                == pathway
            ]
        if sort_key == "frameshift":
            rows.sort(key=lambda r: (not r.frameshift, -r.probability))
        elif sort_key == "delta":
            rows.sort(key=lambda r: abs(r.delta_bp), reverse=True)
        else:
            rows.sort(key=lambda r: r.probability, reverse=True)
            if str(getattr(self, "_decision_mode", "filter_only")) == "decision_grade":
                intended = self._find_intended_label(rows)
                if intended:
                    rows = self._pin_row_first(rows, intended)
                    self.table.set_pinned_label(intended)
        self.table.set_rows(rows)
        if self._current_selection is not None:
            self.table.setHighlighted(self._current_selection.outcome_name, lock=True)
        self._update_prob_mass(rows)

    def _on_outcome_selected(self, outcome_id: str | None, *, user: bool = False) -> None:
        if self._data is None:
            return
        if not outcome_id:
            self._current_selection = None
            self.details.set_selection(None, self._data.sequence, None, run_physics=self._data.summary)
            self.details.set_physics_hints(None)
            self.chart_pos.setSelected(None)
            self.chart_prob.setSelected(None)
            self.table.setHighlighted(None, lock=True)
            self._current_sequence_ctx = None
            self._prime_meta = None
            self._sequence_context.set_context(None)
            return

        bar = next((b for b in self._data.bars if b.label == outcome_id), None)
        sel: OutcomeSelection | None = None
        if bar is not None:
            sel = OutcomeSelection(
                run_id=self._data.run_id,
                guide_id=self._data.guide_id,
                outcome_name=bar.label,
                probability=bar.probability if self._decision_mode_eligible else None,
                delta_bp=bar.delta_bp,
                position_range=(int(bar.pos_range[0]), int(bar.pos_range[1])),
                peak_position=int(round(bar.peak_pos)),
            )
            self._current_selection = sel
            if user and self._data.run_id is not None:
                self._last_selection_per_run[self._data.run_id] = sel

        self.details.set_selection(bar, self._data.sequence, sel, run_physics=self._data.summary)
        # Build sequence context before physics hints so prime overlays can reference it.
        self._update_sequence_context(bar)
        self.details.set_physics_hints(self._build_physics_hints(bar))
        self.chart_pos.setSelected(bar.label if bar else None)
        self.chart_prob.setSelected(bar.label if bar else None)
        self.chart_pos.setHighlighted(None)
        self.chart_prob.setHighlighted(None)
        self.chart_pos.update()
        self.chart_prob.update()
        if bar and "intended" in bar.label.lower() and hasattr(self, "_prime_inspector"):
            self._prime_inspector.show()
        try:
            vis = self._evs.setdefault("visualization", {}) if isinstance(self._evs, dict) else None
            if vis is not None:
                selection = vis.setdefault("selection", {})
                selection["selectedOutcomeLabel"] = bar.label if bar else None
        except Exception:
            pass
        self._update_offtarget_heat()

        self.table.setHighlighted(bar.label if bar else None, lock=True, ensure_visible=True)

        if sel is not None:
            self.outcomeSelected.emit(sel)

    def _current_bar_by_label(self, label: str | None) -> Optional[OutcomeBar]:
        if not label or self._data is None:
            return None
        return next((b for b in self._data.bars if b.label == label), None)

    def _refresh_sequence_context(self) -> None:
        bar = self._current_bar_by_label(getattr(self._current_selection, "outcome_name", None))
        self._update_sequence_context(bar)

    def _update_sequence_context(self, bar: OutcomeBar | None) -> None:
        ctx = self._build_sequence_context(bar) if bar else None
        self._current_sequence_ctx = ctx
        if not self._focus_mode:
            self._sequence_context.set_context(None)
            return
        self._sequence_context.set_mode(self._sequence_context_mode)
        self._sequence_context.set_context(ctx)

    def _update_mass_hover(self, outcome_label: str | None) -> None:
        if not hasattr(self, "_mass_meter"):
            return
        prob = 0.0
        if outcome_label and self._data is not None:
            match = next((b for b in self._data.bars if b.label == outcome_label), None)
            if match is not None:
                prob = max(0.0, min(1.0, match.probability))
        self._prob_mass_highlight = prob
        self._mass_meter.set_values(self._prob_mass_total, prob)

    def _build_perturbed_data(self, delta_bp: int) -> OutcomeExplorerData:
        """Heuristic cut-shift preview using cached outcomes (mass-conserving)."""
        base = self._baseline_data or self._data
        assert base is not None
        new_bars = _simulate_cut_shift(base.bars, delta_bp)
        # map for rows
        bar_by_label = {b.label: b for b in new_bars}
        new_rows: list[OutcomeRow] = []
        for r in base.rows:
            b = bar_by_label.get(r.label)
            if b is None:
                continue
            new_rows.append(
                replace(
                    r,
                    probability=b.probability,
                    peak_pos=b.peak_pos,
                    pos_range=b.pos_range,
                )
            )
        # recompute summary
        no_cut_prob = sum(r.probability for r in new_rows if r.category == "no_cut")
        frameshift_prob = sum(r.probability for r in new_rows if r.frameshift)
        cut_prob = max(0.0, 1.0 - no_cut_prob)
        deltas = [r.delta_bp for r in new_rows if r.category != "no_cut"]
        weights = [r.probability for r in new_rows if r.category != "no_cut"]
        expected_indel = sum(d * w for d, w in zip(deltas, weights)) / (sum(weights) or 1.0)
        median_indel = _median_weighted(deltas, weights)
        top_outcome = max(new_rows, key=lambda r: r.probability, default=None)
        summary = OutcomeSummary(
            cut_prob=cut_prob,
            no_cut_prob=no_cut_prob,
            frameshift_prob=frameshift_prob,
            median_indel=median_indel,
            expected_indel=expected_indel,
            top_outcome=top_outcome.label if top_outcome else "",
            e_pred=base.summary.e_pred,
            pbs_dg=base.summary.pbs_dg,
            flap_ddg=base.summary.flap_ddg,
        )
        repair_pathways = build_repair_pathway_mixture(
            [{"label": r.label, "category": r.category, "probability": r.probability} for r in new_rows]
        )
        stochastic_narrative = build_stochastic_narrative_v1(repair_pathways)
        positions = [p - delta_bp for p in base.positions]
        heat_values = list(base.heat_values)
        perturbed = OutcomeExplorerData(
            summary=summary,
            bars=new_bars,
            rows=new_rows,
            positions=positions,
            heat_values=heat_values,
            cut_index=base.cut_index + delta_bp,
            sequence=base.sequence,
            run_id=base.run_id,
            guide_id=base.guide_id,
            backend_name=base.backend_name,
            backend_kind=base.backend_kind,
            trust="viz_derived",
            provenance=[
                {
                    "source": "viz",
                    "op": "outcome_explorer.cut_shift",
                    "params": {"delta_bp": delta_bp, "strand_flip": bool(getattr(self, '_strand_flipped', False))},
                    "input_view_hash": base.view_hash or base.fingerprint,
                }
            ],
            policy_hash=base.policy_hash,
            semantic_hash=base.semantic_hash,
            determinism_class=base.determinism_class,
            thermo_context=base.thermo_context,
            calibration_badge=base.calibration_badge,
            repair_pathways=repair_pathways,
            stochastic_narrative=stochastic_narrative,
        )
        fp = hashlib.sha256()
        fp.update((base.view_hash or base.fingerprint or "").encode("utf-8"))
        fp.update(str(delta_bp).encode("utf-8"))
        fp.update(str(getattr(self, "_strand_flipped", False)).encode("utf-8"))
        for b in sorted(new_bars, key=lambda x: x.label):
            fp.update(b.label.encode("utf-8"))
            fp.update(str(round(b.probability, 6)).encode("utf-8"))
        perturbed.fingerprint = fp.hexdigest()
        perturbed.view_hash = perturbed.fingerprint
        return perturbed

    def _render_delta_summary(
        self, baseline: OutcomeExplorerData, perturbed: OutcomeExplorerData, delta_bp: int, mode_label: str
    ) -> None:
        """Compact delta readout for key masses."""
        if str(getattr(self, "_decision_mode", "filter_only")) != "decision_grade":
            self._delta_label.setText(f"{mode_label}: cut shift {delta_bp:+d} bp · quantitative deltas suppressed")
            return

        def _mass(rows, predicate):
            return sum(r.probability for r in rows if predicate(r))

        intended_base = _mass(baseline.rows, lambda r: r.intended or "intended" in r.label.lower())
        intended_new = _mass(perturbed.rows, lambda r: r.intended or "intended" in r.label.lower())
        frameshift_base = _mass(baseline.rows, lambda r: r.frameshift)
        frameshift_new = _mass(perturbed.rows, lambda r: r.frameshift)
        nocut_base = _mass(baseline.rows, lambda r: r.category == "no_cut")
        nocut_new = _mass(perturbed.rows, lambda r: r.category == "no_cut")

        def _fmt(label, old, new):
            delta = (new - old) * 100.0
            sign = "+" if delta >= 0 else ""
            return f"{label}: {sign}{delta:.1f}%"

        txt = (
            f"{mode_label} (global): cut shift {delta_bp:+d} bp · "
            f"{_fmt('Intended', intended_base, intended_new)} · "
            f"{_fmt('Frameshift', frameshift_base, frameshift_new)} · "
            f"{_fmt('No cut', nocut_base, nocut_new)}"
        )
        self._delta_label.setText(txt)

    def _emit_viz_transform(self, baseline: OutcomeExplorerData, perturbed: OutcomeExplorerData, delta_bp: int) -> None:
        """Write a viz_transform.json describing the cut-shift operation."""
        try:
            out_dir = Path(os.environ.get("HELIX_VIZ_TRANSFORM_DIR", Path.cwd() / "viz_transforms"))
            out_dir.mkdir(parents=True, exist_ok=True)
            payload = {
                "transformVersion": "1.0",
                "inputArtifactHash": baseline.view_hash or baseline.fingerprint,
                "policyHash": baseline.policy_hash,
                "semanticHash": baseline.semantic_hash,
                "determinismClass": baseline.determinism_class,
                "runId": baseline.run_id,
                "ops": [
                    {
                        "op": "cut_shift",
                        "delta_bp": delta_bp,
                        "strand_flip": bool(getattr(self, "_strand_flipped", False)),
                    }
                ],
                "outputViewHash": perturbed.view_hash or perturbed.fingerprint,
            }
            out_path = out_dir / f"viz_transform_{payload['outputViewHash'] or 'unknown'}.json"
            out_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
            perturbed.viz_transform_path = str(out_path)
        except Exception:
            # best-effort; viz transforms should not crash UI
            pass

    def _update_viz_badge(self, data: OutcomeExplorerData | None) -> None:
        derived = bool(data and getattr(data, "trust", "") == "viz_derived")
        if not derived:
            self._viz_badge.setVisible(False)
            self._set_export_enabled(True)
            return
        path = getattr(data, "viz_transform_path", None)
        view_hash = getattr(data, "view_hash", None) or getattr(data, "fingerprint", None)
        has_transform = path is not None and Path(path).exists()
        if has_transform:
            self._viz_badge.setText("Derived view")
            self._viz_badge.setToolTip(f"View hash: {view_hash or '<unknown>'}\nTransform: {path}")
            self._set_export_enabled(True)
        else:
            self._viz_badge.setText("Invalid derived view")
            self._viz_badge.setToolTip("Missing viz_transform.json; export disabled")
            self._set_export_enabled(False, "Missing viz_transform.json; export disabled")
        self._viz_badge.setVisible(True)

    def _on_viz_badge_clicked(self) -> None:
        text = self._viz_badge.text()
        if "Invalid" in text:
            return
        if str(getattr(self, "_decision_mode", "filter_only")) != "decision_grade":
            try:
                self._delta_detail_label.setText("Quantitative deltas suppressed")
            except Exception:
                pass
            return
        if self._data is None:
            return
        path = getattr(self._data, "viz_transform_path", None)
        if path and Path(path).exists():
            try:
                # copy path for convenience
                try:
                    from PySide6.QtWidgets import QApplication

                    QApplication.clipboard().setText(path)
                except Exception:
                    pass
                # open folder containing file
                QDesktopServices.openUrl(QUrl.fromLocalFile(Path(path).parent.as_posix()))
                return
            except Exception:
                pass
        # Detail: top gains/losses (3 each)
        diffs = []
        base_map = {r.label: r.probability for r in baseline.rows}
        for r in perturbed.rows:
            diffs.append((r.label, r.probability - base_map.get(r.label, 0.0)))
        gains = sorted([d for d in diffs if d[1] > 0], key=lambda x: x[1], reverse=True)[:3]
        losses = sorted([d for d in diffs if d[1] < 0], key=lambda x: x[1])[:3]
        parts: list[str] = []
        if gains:
            parts.append("Gains: " + ", ".join(f"{l} {d*100:+.1f}%" for l, d in gains))
        if losses:
            parts.append("Losses: " + ", ".join(f"{l} {d*100:+.1f}%" for l, d in losses))
        self._delta_detail_label.setText(" · ".join(parts))

    def _on_chart_hovered(self, outcome_id: object) -> None:
        outcome = outcome_id if isinstance(outcome_id, str) else None
        self.chart_prob.setHighlighted(outcome)
        self.chart_pos.setHighlighted(outcome)
        self.table.setHighlighted(outcome)
        self._update_mass_hover(outcome)

    def _on_table_hovered(self, outcome_id: object) -> None:
        outcome = outcome_id if isinstance(outcome_id, str) else None
        self.chart_prob.setHighlighted(outcome)
        self.chart_pos.setHighlighted(outcome)
        self._update_mass_hover(outcome)

    def _on_cut_shift_step(self, step: int, *, absolute: bool = False) -> None:
        """
        Apply cut shift. Buttons behave as relative steps (-1/+1) with clamp to [-1, 1].
        Reset uses absolute=True to jump to baseline (0).
        """
        if self._data is None or self._baseline_data is None:
            return
        # cache guard: clear if baseline fingerprint changed
        base_fp = getattr(self._baseline_data, "fingerprint", None)
        if base_fp and self._perturbation_cache_fp and base_fp != self._perturbation_cache_fp:
            self._perturbation_cache.clear()
            self._perturbation_cache_fp = base_fp
        if absolute:
            target = 0
        else:
            target = max(-1, min(1, self._current_shift + step))
        if target == 0 and not self._strand_flipped:
            self._current_shift = 0
            self._baseline_overlay = None
            self._perturbation_cache.clear()
            if hasattr(self.chart_pos, "set_overlay"):
                self.chart_pos.set_overlay(None)
            if hasattr(self.chart_prob, "set_overlay"):
                self.chart_prob.set_overlay(None)
            if getattr(self, "_overlay_toggle", None):
                self._overlay_toggle.setChecked(False)
            self.set_data(self._baseline_data)
            self._delta_label.setText("")
            if hasattr(self, "_delta_detail_label"):
                self._delta_detail_label.setText("")
            return
        if target == self._current_shift:
            return
        self._current_shift = target
        delta_bp = target

        mode_label = "Preview (heuristic)"
        target_id: str | None = None
        try:
            target_id = getattr(self._current_selection, "guide_id", None) or getattr(self._baseline_data, "guide_id", None)
        except Exception:
            target_id = getattr(self._baseline_data, "guide_id", None)
        cache_key = (delta_bp, self._strand_flipped, target_id)
        perturbed: OutcomeExplorerData | None = self._perturbation_cache.get(cache_key)
        if perturbed is None and callable(self._perturbation_provider):
            try:
                try:
                    perturbed = self._perturbation_provider(delta_bp, strand_flip=self._strand_flipped, target_id=target_id)
                except TypeError:
                    perturbed = self._perturbation_provider(delta_bp)
                if perturbed is None:
                    raise NotImplementedError("Provider returned None")
                mode_label = "Recomputed"
            except NotImplementedError:
                QMessageBox.information(
                    self,
                    "Strand flip unsupported",
                    "Recompute provider does not support strand flip yet." if self._strand_flipped else "Recompute provider returned no data.",
                )
                # revert flip flag
                self._strand_flipped = False
                return
            except Exception as exc:
                QMessageBox.warning(self, "Recompute failed", str(exc))
                perturbed = None
        if perturbed is None:
            perturbed = self._build_perturbed_data(delta_bp)
        self._perturbation_cache[cache_key] = perturbed

        overlay_map = {b.label: b.probability for b in self._baseline_data.bars}
        self.set_data(perturbed)
        self._emit_viz_transform(self._baseline_data, perturbed, delta_bp)
        if hasattr(self.chart_prob, "set_overlay"):
            self.chart_prob.set_overlay(overlay_map, "Baseline (0 bp)")
        self.chart_pos.set_overlay(overlay_map, "Baseline (0 bp)")
        flip_txt = " · strand flipped" if self._strand_flipped else ""
        self._render_delta_summary(self._baseline_data, perturbed, delta_bp, mode_label + flip_txt)

    def _on_strand_flip(self) -> None:
        if not callable(self._perturbation_provider):
            QMessageBox.information(
                self,
                "Strand flip unavailable",
                "Strand flip requires a recompute provider. Configure an engine hook first.",
            )
            return
        self._strand_flipped = not self._strand_flipped
        # Re-run current shift with flip flag
        target_id = getattr(self._current_selection, "guide_id", None) or getattr(self._baseline_data, "guide_id", None)
        self._perturbation_cache.pop((self._current_shift, self._strand_flipped, target_id), None)
        self._on_cut_shift_step(0 if self._current_shift == 0 else self._current_shift, absolute=False)

    def set_rank(self, rank: int | None, total: int | None) -> None:
        self._rank = rank
        self._rank_total = total
        self._update_rank_chip()

    def set_engine_info(self, engine: EngineInfo | None) -> None:
        self._engine_info = engine
        self._update_engine_chip()

    def set_perturbation_provider(self, provider) -> None:
        """Optional: set callable (delta_bp: int, strand_flip: bool = False, target_id: str | None = None) -> OutcomeExplorerData."""
        self._perturbation_provider = provider
        self._perturbation_cache.clear()
        if getattr(self, "_strand_flip_btn", None):
            self._strand_flip_btn.setEnabled(True)
            self._strand_flip_btn.setToolTip("Recomputes with strand flip via provider.")

    def _extract_posterior_payload(self, payload: Mapping[str, Any] | None) -> Mapping[str, Any] | None:
        if not isinstance(payload, Mapping):
            return None
        if isinstance(payload.get("posterior"), Mapping):
            return payload.get("posterior")  # type: ignore[return-value]
        state = payload.get("state") if isinstance(payload.get("state"), Mapping) else payload
        if not isinstance(state, Mapping):
            return None
        cfg = state.get("config", {}) if isinstance(state.get("config"), Mapping) else {}
        sim_payload = cfg.get("sim_payload") if isinstance(cfg.get("sim_payload"), Mapping) else {}
        if isinstance(sim_payload, Mapping) and isinstance(sim_payload.get("posterior"), Mapping):
            return sim_payload.get("posterior")  # type: ignore[return-value]
        return None

    def _refresh_posterior_context_panel(self) -> None:
        if not hasattr(self, "details"):
            return
        allow_planning = self._decision_mode == "decision_grade"
        try:
            if hasattr(self.details, "next_experiment_label"):
                self.details.next_experiment_label.setVisible(bool(allow_planning))
            if hasattr(self.details, "next_experiment_text"):
                self.details.next_experiment_text.setVisible(bool(allow_planning))
        except Exception:
            pass
        edit_spec = None
        context = None
        if isinstance(self._posterior_payload, Mapping):
            edit_spec = self._posterior_payload.get("edit_spec")
            context = self._posterior_payload.get("context")
        if edit_spec is None and isinstance(self._evs, Mapping):
            exp_spec = self._evs.get("experiment_spec") or self._evs.get("experimentSpec")
            plan = self._evs.get("edit_plan") or self._evs.get("editPlan")
            if exp_spec is not None or plan is not None:
                edit_spec = {
                    "experiment_spec": exp_spec,
                    "edit_plan": plan,
                }
        if context is None and isinstance(self._evs, Mapping):
            ctx = self._evs.get("context") or self._evs.get("reference_context")
            if isinstance(ctx, Mapping):
                context = ctx
        self.details.set_posterior_context(
            edit_spec if isinstance(edit_spec, Mapping) else None,
            context if isinstance(context, Mapping) else None,
        )
        if allow_planning and hasattr(self.details, "set_next_experiment"):
            rec_text = "Next data: not computed"
            rec_tooltip = ""
            if isinstance(self._posterior_payload, Mapping):
                try:
                    trace = self._posterior_payload.get("planner_trace")
                    if isinstance(trace, Mapping):
                        top = trace.get("top_choice") if isinstance(trace.get("top_choice"), Mapping) else None
                        if isinstance(top, Mapping):
                            kind = str(top.get("kind") or "measure_outcome_histogram")
                            assay = str(top.get("assay") or "unconfigured")
                            gain = float(top.get("expected_information_gain_bits") or 0.0)
                            rec_text = f"Next data: {kind} via {assay} (expected IG≈{gain:.2f} bits, proxy)"
                        lines = [str(trace.get("note") or "").strip()]
                        ranked = (
                            trace.get("ranked_candidates")
                            if isinstance(trace.get("ranked_candidates"), list)
                            else []
                        )
                        for cand in ranked:
                            if not isinstance(cand, Mapping):
                                continue
                            assay = str(cand.get("assay") or "").strip()
                            ig = cand.get("expected_information_gain_bits")
                            try:
                                igf = float(ig) if ig is not None else None
                            except (TypeError, ValueError):
                                igf = None
                            if assay and igf is not None:
                                lines.append(f"{assay}: IG≈{igf:.2f} bits")
                        rec_tooltip = "\n".join([line for line in lines if line])
                    else:
                        from helix.sim.experiment_planner import (
                            format_recommendation_short,
                            recommend_next_experiment_from_payload,
                        )

                        rec = recommend_next_experiment_from_payload(self._posterior_payload, trials=64, seed=0)
                        rec_text = format_recommendation_short(rec)
                        lines = [
                            "Proxy (in silico): entropy-based expected information gain. "
                            "Not calibrated and not a wet-lab protocol instruction."
                        ]
                        if rec.notes:
                            lines.append(str(rec.notes or "").strip())
                        for cand in rec.candidates:
                            lines.append(f"{cand.assay}: IG≈{cand.expected_information_gain_bits:.2f} bits")
                        rec_tooltip = "\n".join([line for line in lines if line])
                except Exception:
                    pass
            self.details.set_next_experiment(rec_text, tooltip=rec_tooltip)
        elif hasattr(self.details, "set_next_experiment"):
            try:
                self.details.set_next_experiment("", tooltip="")
            except Exception:
                pass
        self._update_domain_badge()

    def set_evs(self, evs: dict | None) -> None:
        # Reset any run-model derived state so an EVS-only activation can't
        # accidentally inherit decision-gating / metadata from a previous run.
        self._current_run = None
        self._decision_mode_eligible = False
        self._artifact_valid = None
        self._decision_mode_reasons = []
        self._decision_mode = "filter_only"
        self._probability_mode = "score"
        self._exploratory_color_ack = False
        self._exploratory_color_ack_key = None
        try:
            self.set_rank(None, None)
        except Exception:
            pass
        try:
            self._apply_probability_mode()
        except Exception:
            pass
        try:
            self._update_gate_banner()
        except Exception:
            pass

        self._evs = evs
        self._outcomes_layer = None
        self._heat_layer = None
        self._posterior_payload = self._extract_posterior_payload(evs)
        if evs is None:
            self._refresh_run_chips(None)
            self._refresh_posterior_context_panel()
            return
        # Build data rows/bars directly from EVS so charts are populated
        try:
            data = self._build_data_from_evs(evs)
            if data is not None:
                self.set_data(data)
        except Exception:
            pass
        # locate Track:Outcomes layer
        try:
            layers = evs.get("visualization", {}).get("layers", []) if isinstance(evs, dict) else []
            for layer in layers:
                if isinstance(layer, dict) and layer.get("kind", "").lower() == "track:outcomes":
                    self._outcomes_layer = layer
                if isinstance(layer, dict) and layer.get("kind", "").lower() == "track:offtargetheat":
                    self._heat_layer = layer
            if self._heat_layer is None:
                self.heat_toggle.setChecked(False)
                self.heat_toggle.setEnabled(False)
            else:
                vis_flag = self._heat_layer.get("visible", True)
                self.heat_toggle.blockSignals(True)
                self.heat_toggle.setChecked(bool(vis_flag))
                self.heat_toggle.setEnabled(True)
                self.heat_toggle.blockSignals(False)
            style = self._outcomes_layer.get("style", {}) if self._outcomes_layer else {}
            mode = style.get("chartMode", "probabilities")
            idx = 0 if mode == "probabilities" else 1
            self.chart_view.setCurrentIndex(idx)
            self._on_chart_view_changed(idx)

            preset = style.get("viewPreset", "balanced")
            mapping = {"balanced": 0, "chart_focus": 1, "details_focus": 2}
            if preset in mapping:
                self.view_mode.setCurrentIndex(mapping[preset])

            sort_by = style.get("sortBy", "probability")
            filt = style.get("filter", "all")
            pathway = style.get("pathwayFilter", "all")
            # Re-run filters with persisted sort/filter
            self._last_filter = (self._last_filter[0], filt, sort_by, str(pathway or "all"))
            self._on_filters_changed(*self._last_filter)

            selected = evs.get("visualization", {}).get("selection", {}).get("selectedOutcomeLabel")
            if selected:
                self._on_outcome_selected(str(selected), user=True)
            self._update_offtarget_heat()
        except Exception:
            pass
        self._refresh_posterior_context_panel()

    def _build_data_from_evs(self, evs: dict) -> OutcomeExplorerData | None:
        return build_outcome_explorer_data_from_evs(evs)

    def set_backend(self, name: str | None, kind: str | None = None) -> None:
        self._backend_name = name
        self._backend_kind = kind

    def _update_rank_chip(self) -> None:
        if self._decision_mode == "filter_only":
            self.rank_chip.setVisible(False)
            return
        if self._rank is None or self._rank_total is None or self._rank <= 0:
            self.rank_chip.setVisible(False)
            return
        self.rank_chip.setText(f"Rank: #{self._rank} of {self._rank_total}")
        self.rank_chip.setVisible(True)

    def _update_engine_chip(self) -> None:
        # Engine chip currently part of summary strip; nothing to do if not present.
        if self._engine_info is None:
            return

    def _find_intended_label(self, rows: list[OutcomeRow]) -> str | None:
        for r in rows:
            if "intended" in r.label.lower():
                return r.label
        return None

    def _pin_row_first(self, rows: list[OutcomeRow], label: str) -> list[OutcomeRow]:
        pinned = [r for r in rows if r.label == label]
        rest = [r for r in rows if r.label != label]
        return pinned + rest if pinned else rows

    # Layout helpers ---------------------------------------------------
    def _on_detail_level_changed(self, idx: int) -> None:
        mapping = {0: "overview", 1: "analysis", 2: "debug"}
        self._set_detail_level(mapping.get(int(idx), "overview"), persist=True)

    def _set_detail_level(self, level: str, *, persist: bool) -> None:
        raw = str(level or "").strip().lower()
        normalized = raw
        if normalized in {"overview", "summary"}:
            normalized = "overview"
        elif normalized in {"analysis", "inspect"}:
            normalized = "analysis"
        elif normalized in {"debug"}:
            normalized = "debug"
        else:
            normalized = "overview"

        self._detail_level = normalized
        try:
            idx = {"overview": 0, "analysis": 1, "debug": 2}[normalized]
            if hasattr(self, "detail_level") and self.detail_level.currentIndex() != idx:
                self.detail_level.blockSignals(True)
                self.detail_level.setCurrentIndex(idx)
                self.detail_level.blockSignals(False)
        except Exception:
            pass

        if persist:
            try:
                self._settings.setValue("outcomeExplorer/detailLevel", normalized)
            except Exception:
                pass

        want_inspect = bool(normalized != "overview")
        prev_inspect_raw = getattr(self, "_inspect_mode", None)
        prev_inspect = None if prev_inspect_raw is None else bool(prev_inspect_raw)
        try:
            summary_row = getattr(self, "_summary_row", None)
            if isinstance(summary_row, QWidget):
                summary_row.setVisible(want_inspect)
        except Exception:
            pass
        try:
            self._apply_decision_details_expand_policy()
        except Exception:
            pass

        if prev_inspect is None or want_inspect != prev_inspect:
            try:
                self._on_inspect_toggled(want_inspect)
            except Exception:
                pass
        else:
            try:
                self._apply_compact_header_state()
            except Exception:
                pass

        # Debug mode overrides some compact-mode hiding (by explicit user intent).
        try:
            self._refresh_run_chips(getattr(self, "_data", None))
        except Exception:
            pass
        try:
            self._update_metadata_chips()
        except Exception:
            pass
        try:
            data = getattr(self, "_data", None)
            run_kind = "prime" if self._is_prime_run() else "crispr"
            self._update_pathway_mix_label(data, run_kind=run_kind)
        except Exception:
            pass

    def set_compact_mode(self, enabled: bool) -> None:
        """
        Compact mode is for short/laptop viewports:
        - hide secondary header controls behind a chevron
        - keep the outcome chart dominant
        """
        enabled = bool(enabled)
        if self._compact_mode == enabled:
            return
        self._compact_mode = enabled

        if enabled:
            try:
                self._header_more_btn.setChecked(False)
                self._header_more_btn.show()
            except Exception:
                pass

            # Chart becomes the hero on compact screens.
            try:
                if self.view_mode.currentIndex() == 0:
                    self._compact_prev_view_mode = 0
                    self._compact_view_mode_auto = True
                    self.view_mode.setCurrentIndex(1)
            except Exception:
                pass
        else:
            try:
                self._header_more_btn.setChecked(False)
                self._header_more_btn.hide()
            except Exception:
                pass

            if self._compact_view_mode_auto and self._compact_prev_view_mode is not None:
                try:
                    if self.view_mode.currentIndex() == 1:
                        self.view_mode.setCurrentIndex(self._compact_prev_view_mode)
                except Exception:
                    pass
            self._compact_prev_view_mode = None
            self._compact_view_mode_auto = False

        # Compact mode trims non-decision chrome to preserve vertical space for the
        # boss-signal banner + required decision rows.
        try:
            divider = getattr(self, "_header_divider", None)
            if isinstance(divider, QWidget):
                show_divider = (not enabled) or (str(getattr(self, "_detail_level", "overview")) == "debug")
                divider.setVisible(bool(show_divider))
        except Exception:
            pass
        try:
            self._refresh_run_chips(getattr(self, "_data", None))
        except Exception:
            pass

        self._apply_compact_header_state()

    def _on_header_more_toggled(self, expanded: bool) -> None:
        try:
            self._header_more_btn.setText("▴" if expanded else "▾")
        except Exception:
            pass
        self._apply_compact_header_state()

    def _on_inspect_toggled(self, enabled: bool) -> None:
        self._inspect_mode = bool(enabled)
        try:
            self._settings.setValue("outcomeExplorer/inspectMode", bool(enabled))
        except Exception:
            pass
        # Header controls + summary chips.
        try:
            self._apply_compact_header_state()
        except Exception:
            pass

        # Chart-level controls are inspection-only by default (quiet Summary).
        try:
            self.chart_legend.setVisible(bool(enabled))
        except Exception:
            pass
        # Disclaimer is visual (grid + axis label); avoid redundant textual disclaimers.
        try:
            self.filters.setVisible(bool(enabled))
        except Exception:
            pass

        # Heat is considered an inspection overlay; hide it in Summary even if it was enabled.
        try:
            if not enabled:
                if self._inspect_prev_heat_enabled is None:
                    self._inspect_prev_heat_enabled = bool(self.heat_toggle.isChecked())
                self.heat_toggle.setChecked(False)
            else:
                if self._inspect_prev_heat_enabled is not None:
                    self.heat_toggle.setChecked(bool(self._inspect_prev_heat_enabled))
                self._inspect_prev_heat_enabled = None
        except Exception:
            pass

        # Propagate mode to charts (visual hierarchy changes live here).
        try:
            self.chart_prob.set_inspect_mode(bool(enabled))
        except Exception:
            pass
        try:
            self.chart_pos.set_inspect_mode(bool(enabled))
        except Exception:
            pass

        # Deterministic mode transitions:
        # - Summary is narrative: select top outcome (without overwriting stored user intent).
        # - Inspect is workbench: restore last user selection for this run when available.
        try:
            if self._data is not None:
                top = str(getattr(self._data.summary, "top_outcome", "") or "")
                if not enabled:
                    if top:
                        self._on_outcome_selected(top, user=False)
                else:
                    run_id = self._data.run_id
                    last_user = self._last_selection_per_run.get(run_id)
                    cur = getattr(self._current_selection, "outcome_name", None) if self._current_selection else None
                    if last_user is not None and last_user.outcome_name and last_user.outcome_name != cur:
                        self._on_outcome_selected(last_user.outcome_name, user=False)
        except Exception:
            pass

    def _apply_compact_header_state(self) -> None:
        primary = getattr(self, "_header_primary_controls", None)
        badges = getattr(self, "_header_badges", None)
        if primary is None and badges is None:
            return
        level = str(getattr(self, "_detail_level", "overview") or "overview")
        if level == "overview":
            try:
                self._header_more_btn.setVisible(False)
            except Exception:
                pass
            if primary is not None:
                primary.setVisible(False)
            if badges is not None:
                badges.setVisible(True)
        elif level == "debug":
            try:
                self._header_more_btn.setVisible(False)
            except Exception:
                pass
            if primary is not None:
                primary.setVisible(True)
            if badges is not None:
                badges.setVisible(True)
        else:
            try:
                self._header_more_btn.setVisible(bool(self._compact_mode))
            except Exception:
                pass
            if self._compact_mode:
                if primary is not None:
                    primary.setVisible(bool(self._header_more_btn.isChecked()))
                if badges is not None:
                    badges.setVisible(True)
            else:
                if primary is not None:
                    primary.setVisible(True)
                if badges is not None:
                    badges.setVisible(True)
        try:
            self._apply_summary_groups()
        except Exception:
            pass

    def _apply_summary_groups(self) -> None:
        full = getattr(self, "_summary_details_full", None)
        if not full:
            return
        inspect_mode = bool(getattr(self, "_inspect_mode", False))
        prev_inspect = getattr(self, "_summary_prev_inspect_mode", None)
        if prev_inspect != inspect_mode:
            self._summary_prev_inspect_mode = inspect_mode
            exploratory_visible: bool | None = bool(inspect_mode)
        else:
            exploratory_visible = None
        if not inspect_mode:
            details = getattr(self, "_summary_details_compact", None) or full
            required, risk, expl = details
            self.summary.set_details(required=required, risk=risk, exploratory=expl, exploratory_visible=False)
            return

        # Inspect mode is a workbench: show the full details, but don't fight the user's toggle
        # after the initial mode transition.
        required, risk, expl = full
        self.summary.set_details(required=required, risk=risk, exploratory=expl, exploratory_visible=exploratory_visible)

    def _on_view_mode_changed(self, idx: int) -> None:
        modes = {0: "balanced", 1: "chart", 2: "table"}
        self._apply_view_mode(modes.get(idx, "balanced"))
        try:
            layer = self._outcomes_layer
            if layer is not None:
                style = layer.setdefault("style", {})
                style["viewPreset"] = modes.get(idx, "balanced")
        except Exception:
            pass

    def _on_chart_view_changed(self, idx: int) -> None:
        self.chart_stack.setCurrentIndex(idx)
        if hasattr(self, "chart_legend"):
            self.chart_legend.setText(self._chart_legend_text(idx))
        # Re-apply filters to ensure the newly visible chart is up to date
        self._on_filters_changed(*self._last_filter)
        # keep selection highlight consistent
        sel = getattr(self, "_current_selection", None)
        if sel is not None:
            self.chart_pos.setSelected(sel.outcome_name)
            self.chart_prob.setSelected(sel.outcome_name)
        self.update()
        # persist chart mode in EVS layer
        try:
            layer = self._outcomes_layer
            if layer is not None:
                style = layer.setdefault("style", {})
                style["chartMode"] = "probabilities" if idx == 0 else "position"
        except Exception:
            pass
        self._update_offtarget_heat()

    def _apply_view_mode(self, mode: str) -> None:
        if not hasattr(self, "_vsplit") or self._vsplit is None:
            return
        total = max(self.height(), 800)
        seq_h = 0
        try:
            if getattr(self, "_sequence_context", None) is not None and self._sequence_context.isVisible():
                seq_h = int(total * 0.22)
        except Exception:
            seq_h = 0
        remaining = max(0, total - seq_h)
        if mode == "chart":
            chart_h = int(remaining * 0.8)
        elif mode == "table":
            chart_h = int(remaining * 0.35)
        else:
            chart_h = int(remaining * 0.7)
        details_h = max(0, remaining - chart_h)
        sizes = [chart_h, seq_h, details_h]
        try:
            self._vsplit.setSizes(sizes)
        except Exception:
            pass

    def apply_default_layout(self) -> None:
        if hasattr(self, "_vsplit") and self._vsplit is not None:
            total = max(self.height(), 900)
            seq_h = 0
            try:
                if getattr(self, "_sequence_context", None) is not None and self._sequence_context.isVisible():
                    seq_h = int(total * 0.22)
            except Exception:
                seq_h = 0
            remaining = max(0, total - seq_h)
            chart_h = int(remaining * 0.68)
            details_h = max(0, remaining - chart_h)
            self._vsplit.setSizes([chart_h, seq_h, details_h])
        if hasattr(self, "_details_split") and self._details_split is not None:
            width = max(self.width(), 1100)
            self._details_split.setSizes([int(width * 0.34), int(width * 0.66)])

    def _update_offtarget_heat(self) -> None:
        if not hasattr(self, "heat_widget"):
            return
        if self._evs is None or self._heat_layer is None:
            self.heat_widget.clear_heat()
            self.heat_widget.setVisible(False)
            self.heat_caption.setVisible(False)
            return
        if self._heat_layer.get("visible", True) is False:
            self.heat_widget.clear_heat()
            self.heat_widget.setVisible(False)
            self.heat_caption.setVisible(False)
            return

        try:
            heat = compute_offtarget_heat(self._evs)
        except Exception:
            heat = []
        if heat is None or len(heat) == 0:
            self.heat_widget.clear_heat()
            self.heat_widget.setVisible(False)
            self.heat_caption.setVisible(False)
            return

        style = self._heat_layer.setdefault("style", {})
        min_val = style.get("minValue")
        max_val = style.get("maxValue")
        if min_val is None or max_val is None:
            min_val = float(min(heat))
            max_val = float(max(heat)) if len(heat) else 1.0
            style["minValue"] = min_val
            style["maxValue"] = max_val

        height = self._heat_layer.get("height")
        if isinstance(height, int) and height > 0:
            self.heat_widget.setMinimumHeight(height)
            self.heat_widget.setMaximumHeight(height)

        self.heat_widget.set_heat(heat, min_val=min_val, max_val=max_val)
        if max_val - min_val < 1e-6:
            self.heat_widget.setVisible(False)
            caption = "No off-target signal in this window."
            tooltip = ""
            try:
                value, tip, computed = self._format_cas_dna_interaction_chip(
                    quantitative_allowed=str(getattr(self, "_decision_mode", "filter_only")) == "decision_grade"
                )
                if computed:
                    tooltip = tip or ""
                    params = self._window_local_offtarget_interaction_proxy().get("params", {})
                    if isinstance(params, Mapping):
                        pam = str(params.get("pam") or "")
                        mm = params.get("mismatch_max")
                        seed = params.get("seed_len")
                        if pam and mm is not None and seed is not None:
                            caption = f"{caption} · PAM {pam} · max_mm {mm} · seed {seed}"
            except Exception:
                pass
            self.heat_caption.setText(caption)
            self.heat_caption.setToolTip(tooltip)
            self.heat_caption.setVisible(True)
        else:
            self.heat_widget.setVisible(True)
            caption = "Off-target heat (window-only): brighter = higher predicted off-target risk at this locus."
            tooltip = ""
            try:
                diag = self._window_local_offtarget_interaction_proxy()
                params = diag.get("params") if isinstance(diag.get("params"), Mapping) else {}
                pam = str(params.get("pam") or "")
                mm = params.get("mismatch_max")
                seed = params.get("seed_len")
                if pam and mm is not None and seed is not None:
                    caption = f"Off-target heat (window-only): PAM {pam} · max_mm {mm} · seed {seed}"
                _value, tip, computed = self._format_cas_dna_interaction_chip(
                    quantitative_allowed=str(getattr(self, "_decision_mode", "filter_only")) == "decision_grade"
                )
                if computed:
                    tooltip = tip or ""
            except Exception:
                pass
            self.heat_caption.setText(caption)
            self.heat_caption.setToolTip(tooltip)
            self.heat_caption.setVisible(True)

    def _update_prob_mass(self, rows: list[OutcomeRow]) -> None:
        if not hasattr(self, "_mass_meter"):
            return
        total = sum(r.probability for r in rows)
        self._prob_mass_total = total
        self._mass_meter.set_values(total, self._prob_mass_highlight)

    def _grab_chart_image(self, target_width: int = 1920) -> QImage:
        """
        Grab the currently visible chart as an image.

        Falls back to manual render if QWidget.grab() returns a null pixmap
        (can happen on some GPU/Wayland stacks).
        """
        chart = self._current_chart()
        chart.repaint()
        pix: QPixmap = chart.grab()
        if not pix.isNull() and pix.width() > 0 and pix.height() > 0:
            if pix.width() < target_width:
                pix = pix.scaledToWidth(target_width, Qt.SmoothTransformation)
            return pix.toImage()

        # Fallback: render into an offscreen image to avoid null pixmaps.
        size = chart.size()
        if size.isEmpty():
            size = chart.sizeHint()
        if size.isEmpty():
            raise RuntimeError("chart has zero size")

        scale = max(1.0, target_width / float(max(size.width(), 1)))
        target_size = QSize(
            max(1, int(size.width() * scale)),
            max(1, int(size.height() * scale)),
        )
        img = QImage(target_size, QImage.Format_ARGB32_Premultiplied)
        img.fill(Qt.transparent)
        painter = QPainter(img)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.scale(scale, scale)
        chart.render(painter)
        painter.end()
        return img

    def _governance_context_for_export(
        self,
        *,
        decision_mode_override: str | None = None,
    ) -> tuple[str, str, Mapping[str, Any] | None]:
        if decision_mode_override is None:
            decision_mode = self._effective_decision_mode()
        else:
            raw = str(decision_mode_override or "").strip().lower()
            decision_mode = "decision_grade" if raw == "decision_grade" else "filter_only"
        interpretation = interpretation_for_mode(decision_mode)
        proof = None
        if decision_mode == "decision_grade":
            run = self._current_run
            meta = getattr(run, "metadata", None) if run is not None else None
            artifact = meta.get("run_artifact") if isinstance(meta, Mapping) else None
            proof = extract_decision_grade_proof_from_artifact(artifact if isinstance(artifact, Mapping) else None)
            if proof is None:
                proof = extract_decision_grade_proof_from_summary(self._run_summary_v2())
        return decision_mode, interpretation, proof

    def _governance_export_metadata_json(self, *, decision_mode_override: str | None = None) -> str | None:
        decision_mode, interpretation, proof = self._governance_context_for_export(decision_mode_override=decision_mode_override)
        is_demo = False
        try:
            is_demo = bool(self._is_demo_run())
        except Exception:
            is_demo = False
        payload = build_governance_provenance(
            decision_mode=decision_mode,
            is_demo=is_demo,
            interpretation=interpretation,
            decision_grade_proof=(dict(proof) if isinstance(proof, Mapping) else None),
        )
        try:
            return json.dumps(payload, sort_keys=True)
        except Exception:
            return None

    def _watermark_export_image(self, image: QImage, *, decision_mode_override: str | None = None) -> QImage:
        """Apply a governance watermark to exported images (visible, cropping-resistant)."""
        try:
            w = int(image.width())
            h = int(image.height())
        except Exception:
            return image
        if w <= 0 or h <= 0:
            return image

        decision_mode, interpretation, proof = self._governance_context_for_export(decision_mode_override=decision_mode_override)
        is_demo = False
        try:
            is_demo = bool(self._is_demo_run())
        except Exception:
            is_demo = False
        wm_text = export_watermark_label(decision_mode=decision_mode, is_demo=is_demo)
        wm_lines = governance_stamp_lines(
            decision_mode=decision_mode,
            interpretation=interpretation,
            decision_grade_proof=proof if isinstance(proof, Mapping) else None,
        )
        wm_lines = [str(line) for line in wm_lines if str(line).strip()]
        if not wm_text and not wm_lines:
            return image

        img = QImage(image)
        painter = QPainter(img)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.TextAntialiasing, True)
        try:
            painter.save()
            painter.setOpacity(0.08)
            font = QFont()
            font.setBold(True)
            font.setPixelSize(max(18, int(min(w, h) * 0.12)))
            painter.setFont(font)
            painter.setPen(QPen(Qt.white))
            painter.translate(w / 2.0, h / 2.0)
            painter.rotate(-30.0)
            painter.drawText(QRectF(-w, -h, w * 2.0, h * 2.0), Qt.AlignCenter, wm_text)
            painter.restore()
        except Exception:
            try:
                painter.restore()
            except Exception:
                pass

        if wm_lines:
            try:
                painter.save()
                painter.setOpacity(0.70)
                font = QFont()
                font.setPixelSize(max(10, int(min(w, h) * 0.022)))
                painter.setFont(font)
                painter.setPen(QPen(Qt.white))
                margin = max(8, int(min(w, h) * 0.02))
                painter.drawText(
                    QRect(margin, margin, max(1, w - 2 * margin), max(1, h - 2 * margin)),
                    Qt.AlignLeft | Qt.AlignBottom,
                    "\n".join(wm_lines),
                )
                painter.restore()
            except Exception:
                try:
                    painter.restore()
                except Exception:
                    pass

        painter.end()
        return img

    def _write_png(
        self,
        image: QImage,
        path_str: str,
        *,
        stamp: Mapping[str, Any] | None = None,
        decision_mode_override: str | None = None,
    ) -> Path:
        """
        Save QImage to disk with clearer error messages.
        """
        path = Path(path_str)
        if path.suffix.lower() not in {".png"}:
            path = path.with_suffix(".png")
        path.parent.mkdir(parents=True, exist_ok=True)

        writer = QImageWriter(str(path), b"png")
        writer.setCompression(9)
        writer.setQuality(100)
        out_image = self._watermark_export_image(image, decision_mode_override=decision_mode_override)
        if stamp:
            try:
                out_image.setText("helix_limitations", json.dumps(stamp, sort_keys=True))
            except Exception:
                pass
        gov_json = self._governance_export_metadata_json(decision_mode_override=decision_mode_override)
        gov_obj: Mapping[str, Any] | None = None
        decision_mode = ""
        if gov_json:
            try:
                out_image.setText("helix_governance", gov_json)
            except Exception:
                pass
            try:
                loaded = json.loads(gov_json)
                if isinstance(loaded, Mapping):
                    gov_obj = loaded
                    decision_mode = str(gov_obj.get("decision_mode") or "").strip().lower()
            except Exception:
                gov_obj = None
                decision_mode = ""
        proxy = None
        try:
            proxy = self._exportable_cas_dna_interaction_proxy(
                quantitative_allowed=bool(decision_mode == "decision_grade")
            )
            out_image.setText("helix_cas_dna_interaction_proxy", json.dumps(proxy, sort_keys=True))
        except Exception:
            proxy = None
        if not writer.write(out_image):
            msg = writer.errorString() or "save failed"
            raise RuntimeError(msg)

        # Always write a lightweight provenance sidecar for chain-of-custody.
        if write_image_provenance_sidecars_enabled(settings=getattr(self, "_settings", None)):
            try:
                run_id = None
                try:
                    run_id = getattr(self._data, "run_id", None) if getattr(self, "_data", None) is not None else None
                except Exception:
                    run_id = None
                if run_id is None:
                    try:
                        run_id = getattr(getattr(self, "_current_run", None), "run_id", None)
                    except Exception:
                        run_id = None
                payload = build_png_provenance_v1(
                    png_path=path,
                    artifact_surface="outcome_explorer",
                    run_id=run_id,
                    governance=gov_obj,
                    limitations_stamp=stamp,
                    embedded_png_text_chunks_present=True,
                )
                if proxy is not None:
                    diag = payload.setdefault("diagnostics", {})
                    if isinstance(diag, dict):
                        diag["cas_dna_interaction_proxy"] = proxy
                write_png_provenance_sidecar(path, payload)
            except Exception as exc:
                raise RuntimeError(f"failed to write provenance sidecar for {path.name}: {exc}") from exc
        return path

    def _export_chart_png(self) -> None:
        export_class = self._prompt_export_class("Export chart")
        if export_class is None:
            return
        mode_label = "DECISION_GRADE" if export_class == "decision_grade" else "EXPLORATORY"
        decision_mode_override = "filter_only" if export_class == "exploratory" else None
        path_str, _ = QFileDialog.getSaveFileName(
            self,
            f"Export outcome chart — {mode_label}",
            self._suggest_export_path("helix_outcome_chart.png", decision_mode_override=decision_mode_override),
            "PNG (*.png)",
        )
        if not path_str:
            return
        try:
            stamp = limitations_stamp()
            image = self._grab_chart_image()
            saved_path = self._write_png(image, path_str, stamp=stamp, decision_mode_override=decision_mode_override)
        except Exception as exc:
            QMessageBox.critical(self, "Export chart", f"Failed to export chart: {exc}")
        else:
            # Keep UX quiet; no toast on success.
            self._last_export_path = str(saved_path)

    def _export_focus_snapshot(self) -> None:
        """Export the current focus-mode view: PNG + JSON metadata."""
        if not getattr(self, "_focus_mode", False):
            QMessageBox.information(self, "Focus snapshot", "Enter Focus Mode to export a focus snapshot.")
            return
        export_class = self._prompt_export_class("Focus snapshot")
        if export_class is None:
            return
        mode_label = "DECISION_GRADE" if export_class == "decision_grade" else "EXPLORATORY"
        decision_mode_override = "filter_only" if export_class == "exploratory" else None
        path_str, _ = QFileDialog.getSaveFileName(
            self,
            f"Export focus snapshot — {mode_label}",
            self._suggest_export_path("helix_focus_snapshot.png", decision_mode_override=decision_mode_override),
            "PNG (*.png)",
        )
        if not path_str:
            return
        base = Path(path_str)
        stamp = limitations_stamp()
        try:
            image = self._grab_chart_image()
            base = self._write_png(image, str(base), stamp=stamp, decision_mode_override=decision_mode_override)
        except Exception as exc:
            QMessageBox.critical(self, "Focus snapshot", f"Failed to export PNG: {exc}")
            return
        meta = {
            "run_id": getattr(self._data, "run_id", None) if self._data else None,
            "baseline_label": self._baseline_label,
            "lens": getattr(self.chart_prob, "_lens", "all"),
            "physics_overlay": getattr(self, "_physics_overlay_enabled", False),
            "summary": {
                "frameshift_total": self._prob_mass.get("frameshift") if hasattr(self, "_prob_mass") else None,
            },
            "limitations": stamp,
        }
        try:
            decision_mode, interpretation, proof = self._governance_context_for_export(decision_mode_override=decision_mode_override)
            meta["governance"] = {
                "decision_mode": decision_mode,
                "interpretation": interpretation,
                "decision_grade_proof": (dict(proof) if isinstance(proof, Mapping) else None),
            }
            try:
                meta["cas_dna_interaction_proxy"] = self._exportable_cas_dna_interaction_proxy(
                    quantitative_allowed=bool(decision_mode == "decision_grade")
                )
            except Exception:
                pass
        except Exception:
            pass
        try:
            base.with_suffix(".json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
        except Exception as exc:
            QMessageBox.critical(self, "Focus snapshot", f"Failed to export metadata: {exc}")

    def _on_toggle_offtarget_heat(self, checked: bool) -> None:
        if self._heat_layer is None:
            return
        self._heat_layer["visible"] = bool(checked)
        self._update_offtarget_heat()

    def _current_chart(self) -> QWidget:
        return self.chart_prob if self.chart_stack.currentIndex() == 0 else self.chart_pos

    def set_baseline_overlay(self, evs: dict | None) -> None:
        """Provide a baseline EVS snapshot for overlay rendering."""
        try:
            self._baseline_overlay = self._build_data_from_evs(evs) if evs else None
        except Exception:
            self._baseline_overlay = None
        self._baseline_label = self._label_from_evs(evs)
        self._overlay_toggle.blockSignals(True)
        has_overlay = self._baseline_overlay is not None
        self._overlay_toggle.setVisible(has_overlay)
        if has_overlay:
            self._overlay_toggle.setChecked(True)
        else:
            self._overlay_toggle.setChecked(False)
        self._overlay_toggle.blockSignals(False)
        self._apply_overlay()
        self._refresh_overlay_legend()

    def _apply_overlay(self) -> None:
        if not getattr(self, "_overlay_toggle", None):
            return
        if not self._overlay_toggle.isChecked() or self._baseline_overlay is None or self._data is None:
            if hasattr(self.chart_pos, "set_overlay"):
                self.chart_pos.set_overlay(None)
            if hasattr(self.chart_prob, "set_overlay"):
                self.chart_prob.set_overlay(None)
            return
        if self._current_run_label and self._baseline_label and self._current_run_label == self._baseline_label:
            # Same run; hide overlay
            self.chart_pos.set_overlay(None)
            self.chart_prob.set_overlay(None)
            self._overlay_toggle.setChecked(False)
            self._overlay_legend.setVisible(False)
            return
        overlay_map = {b.label: b.probability for b in self._baseline_overlay.bars}
        if hasattr(self.chart_pos, "set_overlay"):
            self.chart_pos.set_overlay(overlay_map, self._baseline_label)
        if hasattr(self.chart_prob, "set_overlay"):
            self.chart_prob.set_overlay(overlay_map, self._baseline_label)
        self._refresh_overlay_legend()
        self._refresh_sequence_context()

    def _derive_prime_cfg_from_edit_plan(self, evs: dict) -> dict | None:
        edit_plan = evs.get("editPlan") if isinstance(evs.get("editPlan"), Mapping) else None
        if not isinstance(edit_plan, Mapping):
            return None
        mode = str(edit_plan.get("mode") or "").strip().lower()
        if mode != "prime":
            return None
        targets = edit_plan.get("targets") if isinstance(edit_plan.get("targets"), list) else []
        if not targets or not isinstance(targets[0], Mapping):
            return None
        target = targets[0]

        start = target.get("start")
        end = target.get("end")
        try:
            spacer_start = int(start) if start is not None else 0
        except Exception:
            spacer_start = 0
        try:
            spacer_end = int(end) if end is not None else spacer_start + 20
        except Exception:
            spacer_end = spacer_start + 20
        spacer_len = max(1, int(spacer_end) - int(spacer_start))

        grna = target.get("gRNA") if isinstance(target.get("gRNA"), Mapping) else {}
        pam = grna.get("pam")
        pam_text = str(pam).strip() if pam is not None else ""
        pam_len = len(pam_text) if pam_text else 3
        pam_start = spacer_start + spacer_len

        donor = target.get("donor") if isinstance(target.get("donor"), Mapping) else {}
        pbs = donor.get("pbs") if isinstance(donor.get("pbs"), Mapping) else {}
        pbs_len = pbs.get("length")
        if pbs_len is None and pbs.get("sequence"):
            pbs_len = len(str(pbs.get("sequence") or ""))
        try:
            pbs_len_int = int(pbs_len) if pbs_len is not None else None
        except Exception:
            pbs_len_int = None

        rt = donor.get("rt") if isinstance(donor.get("rt"), Mapping) else {}
        rtt_len = rt.get("length")
        if rtt_len is None and rt.get("sequence"):
            rtt_len = len(str(rt.get("sequence") or ""))
        try:
            rtt_len_int = int(rtt_len) if rtt_len is not None else None
        except Exception:
            rtt_len_int = None

        prime_cfg: dict[str, object] = {
            "spacer_start": spacer_start,
            "spacer_len": spacer_len,
            "pam_start": pam_start,
            "pam_len": pam_len,
            "pbs_len": pbs_len_int if pbs_len_int is not None else 13,
            "rtt_len": rtt_len_int if rtt_len_int is not None else 12,
        }
        try:
            strand = target.get("strand")
            if strand is not None:
                prime_cfg["strand"] = str(strand)
        except Exception:
            pass

        return prime_cfg

    def _update_prime_inspector(self) -> None:
        if not hasattr(self, "_prime_inspector"):
            return
        prime_cfg = None
        edit_spec = None
        if isinstance(self._evs, dict):
            cfg = self._evs.get("config", {}) if isinstance(self._evs.get("config"), dict) else {}
            prime_cfg = cfg.get("prime") or self._evs.get("prime")
            if prime_cfg is None:
                prime_cfg = self._derive_prime_cfg_from_edit_plan(self._evs)
            edit_spec = cfg.get("edit_spec") or self._evs.get("edit_spec")
        self._prime_inspector.set_context(
            prime_cfg if isinstance(prime_cfg, dict) else None,
            edit_spec if isinstance(edit_spec, dict) else None,
        )

    def _label_from_evs(self, evs: dict | None) -> str | None:
        if not isinstance(evs, dict):
            return None
        state = evs
        meta = state.get("config", {}).get("metadata", {}) if isinstance(state.get("config"), dict) else {}
        if isinstance(meta, dict) and meta.get("run_label"):
            return str(meta.get("run_label"))
        if state.get("run_label"):
            return str(state.get("run_label"))
        guide = state.get("config", {}).get("guide", {}) if isinstance(state.get("config"), dict) else {}
        if isinstance(guide, dict) and guide.get("id"):
            return str(guide.get("id"))
        return None

    def _refresh_overlay_legend(self) -> None:
        if not hasattr(self, "_overlay_legend"):
            return
        has_baseline = self._baseline_overlay is not None and self._baseline_label and self._current_run_label and self._current_run_label != self._baseline_label
        self._overlay_legend.setVisible(bool(has_baseline))
        if not has_baseline:
            return
        cand_label = self._current_run_label or "Candidate"
        base_label = self._baseline_label or "Baseline"
        cand_trim = cand_label if len(cand_label) <= 28 else cand_label[:25] + "…"
        base_trim = base_label if len(base_label) <= 28 else base_label[:25] + "…"
        cand_color = QColor(219, 234, 254).name()
        base_color = QColor(159, 181, 221).name()
        self._legend_candidate.setText(f"<span style='color:{cand_color}'>■</span> Candidate ({cand_trim})")
        self._legend_baseline.setText(f"<span style='color:{base_color}'>■</span> Baseline ({base_trim})")

    # basic keyboard navigation
    def keyPressEvent(self, event):  # type: ignore[override]
        if event.key() in (Qt.Key_Up, Qt.Key_Down):
            if not self.table._rows:
                return
            model = self.table.selectionModel()
            row = model.selectedRows()[0].row() if model.selectedRows() else 0
            if event.key() == Qt.Key_Up:
                row = max(0, row - 1)
            else:
                row = min(len(self.table._rows) - 1, row + 1)
            self.table.selectRow(row)
            self._on_outcome_selected(self.table._rows[row].label, user=True)
            return
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            model = self.table.selectionModel()
            if model.selectedRows():
                row = model.selectedRows()[0].row()
                if 0 <= row < len(self.table._rows):
                    self._on_outcome_selected(self.table._rows[row].label, user=True)
            return
        if event.key() in (Qt.Key_Return, Qt.Key_Enter):
            # Toggle chart mode
            current = self.chart_stack.currentIndex()
            new_idx = 1 - current
            self.chart_stack.setCurrentIndex(new_idx)
            self._on_chart_view_changed(new_idx)
            return
        super().keyPressEvent(event)
class PrimeOutcomeClass(Enum):
    DESIRED = auto()
    BYPRODUCT = auto()
    INDEL = auto()
    NO_CUT = auto()


def refresh_open_outcome_explorers() -> None:
    """Refresh preference-driven state on all open OutcomeExplorerWidget instances."""
    try:
        app = QApplication.instance()
    except Exception:
        return
    if app is None:
        return
    for w in app.allWidgets():
        if isinstance(w, OutcomeExplorerWidget):
            try:
                w.refresh_preferences()
            except Exception:
                continue
