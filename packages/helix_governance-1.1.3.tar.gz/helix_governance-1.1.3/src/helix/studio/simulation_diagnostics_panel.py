from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from helix.studio.models import RunModel
from helix.studio.outcome_explorer import FlowLayout
from helix.studio.semantic_schema import CalibrationBadge, ThermoContext, format_scalar
from helix.studio.session import ExperimentState, SessionModel
from helix.studio.simulation_diagnostics import SimulationDiagnostics, build_simulation_diagnostics
from helix.studio.ui_tokens import CAUTION, HX_DANGER, MARGIN_PANEL, SPACING_SMALL, SUCCESS, base_font, monospace_font


class SimulationDiagnosticsPanel(QWidget):
    """Shared diagnostics strip shown above center tabs for consistent run context."""

    def __init__(
        self,
        session: SessionModel | None,
        parent: QWidget | None = None,
        *,
        project_root: str | Path | None = None,
    ) -> None:
        super().__init__(parent)
        self.setFont(base_font())
        self._session = session
        self._project_root = Path(project_root) if project_root else None
        self._evs: Mapping[str, Any] | None = None
        self._run_model: RunModel | None = None
        self._state: ExperimentState | None = session.state if session is not None else None

        root = QVBoxLayout(self)
        root.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        root.setSpacing(SPACING_SMALL)

        header_row = QHBoxLayout()
        header_row.setContentsMargins(0, 0, 0, 0)
        header_row.setSpacing(SPACING_SMALL)

        title = QLabel("Simulation status", self)
        title.setObjectName("PanelTitle")
        header_row.addWidget(title)

        self._summary = QLabel("No run loaded.", self)
        self._summary.setWordWrap(False)
        self._summary.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._summary.setProperty("tone", "muted")
        self._summary.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        header_row.addWidget(self._summary, 1)

        self._toggle = QToolButton(self)
        self._toggle.setCheckable(True)
        self._toggle.setChecked(False)
        self._toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._toggle.clicked.connect(self._toggle_details)
        header_row.addWidget(self._toggle)
        root.addLayout(header_row)

        self._chip_row = QWidget(self)
        self._chip_layout = FlowLayout(self._chip_row, hspacing=8, vspacing=6)
        self._chips: list[QLabel] = []
        root.addWidget(self._chip_row)

        self._details_box = QFrame(self)
        self._details_box.setObjectName("DiagnosticsDetails")
        details_layout = QVBoxLayout(self._details_box)
        details_layout.setContentsMargins(0, 0, 0, 0)
        details_layout.setSpacing(SPACING_SMALL)

        self._explain = QLabel("", self._details_box)
        self._explain.setWordWrap(True)
        self._explain.setProperty("tone", "muted")
        self._explain.setTextInteractionFlags(Qt.TextSelectableByMouse)
        details_layout.addWidget(self._explain)

        self._raw_toggle = QToolButton(self._details_box)
        self._raw_toggle.setCheckable(True)
        self._raw_toggle.setChecked(False)
        self._raw_toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._raw_toggle.clicked.connect(self._toggle_raw)
        details_layout.addWidget(self._raw_toggle)

        self._raw_box = QFrame(self._details_box)
        self._raw_box.setObjectName("DiagnosticsRawBox")
        raw_layout = QVBoxLayout(self._raw_box)
        raw_layout.setContentsMargins(8, 8, 8, 8)
        raw_layout.setSpacing(SPACING_SMALL)
        raw_title = QLabel("Raw diagnostics (schema-level, not user-facing)", self._raw_box)
        raw_title.setProperty("tone", "muted")
        raw_layout.addWidget(raw_title)
        self._raw_text = QPlainTextEdit(self._raw_box)
        self._raw_text.setReadOnly(True)
        self._raw_text.setFont(monospace_font())
        self._raw_text.setLineWrapMode(QPlainTextEdit.NoWrap)
        self._raw_text.setFixedHeight(160)
        self._raw_text.setStyleSheet(
            "background-color: palette(base); border: 1px solid palette(mid); color: palette(window-text);"
        )
        raw_layout.addWidget(self._raw_text)
        self._raw_box.setStyleSheet("QFrame#DiagnosticsRawBox { border: 1px solid palette(mid); border-radius: 6px; }")
        details_layout.addWidget(self._raw_box)

        root.addWidget(self._details_box)
        self._toggle_details()

        if self._session is not None:
            try:
                self._session.stateChanged.connect(self._on_state_changed)
            except Exception:
                pass

        self._refresh()

    def set_evs(self, evs: Mapping[str, Any] | None) -> None:
        self._evs = evs
        if evs is not None:
            self._run_model = None
        self._refresh()

    def set_run_model(self, run: RunModel | None) -> None:
        self._run_model = run
        self._refresh()

    def _on_state_changed(self, state: ExperimentState) -> None:
        self._state = state
        self._refresh()

    def _toggle_details(self) -> None:
        expanded = bool(self._toggle.isChecked())
        self._details_box.setVisible(expanded)
        self._toggle.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self._toggle.setText("Details")

    def _refresh(self) -> None:
        run = self._run_model
        if run is not None and isinstance(self._evs, Mapping):
            evs_id = self._evs.get("id") or self._evs.get("run_id")
            if evs_id is not None and str(getattr(run, "run_id", "")) != str(evs_id):
                run = None
        if run is None and self._session is not None:
            run_id = None
            if isinstance(self._evs, Mapping):
                run_id = self._evs.get("id") or self._evs.get("run_id")
            if run_id is None and self._state is not None:
                run_id = self._state.run_id
            if run_id is not None:
                try:
                    run = self._session.get_run_by_id(str(run_id))
                except Exception:
                    run = None
        diag = build_simulation_diagnostics(
            evs=self._evs,
            state=self._state,
            run=run,
            project_root=self._project_root,
        )
        if diag is None:
            self._summary.setText("No run loaded.")
            self._summary.setToolTip("")
            self._explain.setText("")
            self._set_chip_specs([])
            self._raw_text.setPlainText("")
            self._raw_toggle.setVisible(False)
            self._raw_box.setVisible(False)
            return
        self._summary.setText(self._build_summary_line(diag))
        self._summary.setToolTip(self._build_summary_tooltip(diag))
        self._apply_details(diag)

    def _is_demo_context(self) -> bool:
        run = self._run_model
        if run is not None:
            meta = getattr(run, "metadata", None)
            if isinstance(meta, Mapping) and str(meta.get("scenario") or "").strip().lower() == "demo":
                return True
        for src in (self._evs, getattr(self._state, "config", None) if self._state is not None else None):
            if not isinstance(src, Mapping):
                continue
            candidates: list[Mapping[str, Any]] = []
            cfg = src.get("config") if isinstance(src.get("config"), Mapping) else None
            if isinstance(cfg, Mapping):
                candidates.append(cfg)
            candidates.append(src)
            sim = src.get("simulation") if isinstance(src.get("simulation"), Mapping) else None
            params = sim.get("params") if isinstance(sim, Mapping) and isinstance(sim.get("params"), Mapping) else None
            if isinstance(params, Mapping):
                candidates.append(params)

            for cand in candidates:
                meta = cand.get("metadata") if isinstance(cand.get("metadata"), Mapping) else {}
                scenario = str(meta.get("scenario") or "").strip().lower()
                if scenario == "demo":
                    return True
                preset_id = str(meta.get("preset_id") or "").strip().lower()
                if preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"):
                    return True
        return False

    def _build_summary_line(self, diag: SimulationDiagnostics) -> str:
        if self._is_demo_context():
            decision_tag = "DECISION-GRADE" if getattr(diag, "decision_mode", None) == "decision_grade" else "NOT DECISION-GRADE"
            parts: list[str] = [f"DEMO — {decision_tag}"]

            blockers = self._decision_blocker_count()
            if blockers:
                parts.append(f"Blockers: {blockers}")

            if diag.integrity_failures:
                parts.append(f"Integrity: FAIL ({len(diag.integrity_failures)})")
            elif diag.integrity_warnings:
                parts.append(f"Integrity: WARN ({len(diag.integrity_warnings)})")
            else:
                parts.append("Integrity: OK")

            if diag.evidence is None:
                parts.append("Evidence: --")
            elif diag.evidence.missing:
                parts.append(f"Evidence: missing {diag.evidence.missing}")
            else:
                parts.append("Evidence: OK")

            return " · ".join([p for p in parts if p]).strip()

        parts: list[str] = []
        if getattr(diag, "decision_mode", None) == "decision_grade":
            if diag.verdict_grade:
                parts.append(f"Grade {diag.verdict_grade}")
        else:
            parts.append("Not decision grade")
        if diag.verdict_headline:
            parts.append(str(diag.verdict_headline))
        dominant = self._dominant_issue(diag)
        if dominant:
            parts.append(dominant)
        return " | ".join(parts) if parts else "Diagnostics ready."

    def _extract_run_summary(self) -> Mapping[str, Any] | None:
        run = self._run_model
        if run is not None:
            meta = getattr(run, "metadata", None)
            if isinstance(meta, Mapping) and isinstance(meta.get("run_summary"), Mapping):
                return meta.get("run_summary")  # type: ignore[return-value]
        if isinstance(self._evs, Mapping):
            cfg = self._evs.get("config") if isinstance(self._evs.get("config"), Mapping) else {}
            meta = cfg.get("metadata") if isinstance(cfg.get("metadata"), Mapping) else {}
            if isinstance(meta.get("run_summary"), Mapping):
                return meta.get("run_summary")  # type: ignore[return-value]
            sim = self._evs.get("simulation") if isinstance(self._evs.get("simulation"), Mapping) else {}
            params = sim.get("params") if isinstance(sim.get("params"), Mapping) else {}
            meta2 = params.get("metadata") if isinstance(params.get("metadata"), Mapping) else {}
            if isinstance(meta2.get("run_summary"), Mapping):
                return meta2.get("run_summary")  # type: ignore[return-value]
        state = self._state
        if state is not None and isinstance(getattr(state, "config", None), Mapping):
            cfg = state.config
            meta = cfg.get("metadata") if isinstance(cfg.get("metadata"), Mapping) else {}
            if isinstance(meta.get("run_summary"), Mapping):
                return meta.get("run_summary")  # type: ignore[return-value]
        return None

    def _decision_blocker_count(self) -> int:
        summary = self._extract_run_summary()
        if not isinstance(summary, Mapping):
            return 0
        verdict = summary.get("verdict") if isinstance(summary.get("verdict"), Mapping) else {}
        notes = verdict.get("decision_notes") if isinstance(verdict.get("decision_notes"), list) else []
        return len([n for n in notes if isinstance(n, str) and n.strip()])

    def _build_summary_tooltip(self, diag: SimulationDiagnostics) -> str:
        parts: list[str] = []
        if diag.run_label or diag.run_id:
            run_text = diag.run_label or "--"
            if diag.run_id:
                run_text = f"{run_text} (id {diag.run_id})"
            parts.append(f"Run: {run_text}")
        if diag.run_kind:
            parts.append(f"Mode: {diag.run_kind}")
        if diag.engine or diag.backend:
            engine = diag.engine or "--"
            if diag.backend:
                engine = f"{engine} ({diag.backend})"
            parts.append(f"Engine: {engine}")
        if diag.calibration_badge and diag.calibration_badge != CalibrationBadge.UNKNOWN:
            parts.append(f"Calibration: {diag.calibration_badge.value}")
        if diag.thermo_context is not None:
            parts.append(f"Thermo: {self._format_thermo(diag.thermo_context)}")
        return "\n".join(parts)

    def _apply_details(self, diag: SimulationDiagnostics) -> None:
        explain = self._build_explain_line(diag)
        self._explain.setText(explain)
        self._explain.setVisible(bool(explain.strip()))
        self._set_chip_specs(self._build_chip_specs(diag))
        raw_text = self._build_raw_text(diag)
        self._raw_text.setPlainText(raw_text)
        has_raw = bool(raw_text.strip())
        self._raw_toggle.setVisible(has_raw)
        self._raw_toggle.setEnabled(has_raw)
        if not has_raw:
            self._raw_toggle.setChecked(False)
        self._toggle_raw()

    def _toggle_raw(self) -> None:
        expanded = bool(self._raw_toggle.isChecked())
        self._raw_box.setVisible(expanded)
        self._raw_toggle.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self._raw_toggle.setText("Hide raw diagnostics" if expanded else "Show raw diagnostics")

    def _dominant_issue(self, diag: SimulationDiagnostics) -> str | None:
        if diag.evidence and diag.evidence.missing:
            return f"Evidence missing {diag.evidence.missing}"
        if diag.integrity_failures:
            return f"Integrity failures {len(diag.integrity_failures)}"
        if diag.mass and diag.mass.violated:
            return "Mass violation"
        if diag.off_target_status:
            sev, label = self._status_severity(diag.off_target_status)
            if sev in ("warn", "danger"):
                return f"Off-target {label}"
        if diag.stability_status:
            sev, label = self._status_severity(diag.stability_status)
            if sev in ("warn", "danger"):
                return f"Stability {label}"
        if diag.schema_issues and diag.schema_issues.rows_with_issues:
            return f"Schema issues {diag.schema_issues.rows_with_issues}"
        return None

    def _build_explain_line(self, diag: SimulationDiagnostics) -> str:
        headline = diag.verdict_headline or "Diagnostics ready."
        details: list[str] = []
        if diag.noncompliance_reasons:
            details.append("Policy: " + ", ".join(diag.noncompliance_reasons))
        if diag.integrity_failures:
            details.append("Integrity failures: " + ", ".join(diag.integrity_failures))
        elif diag.integrity_warnings:
            details.append("Integrity warnings: " + ", ".join(diag.integrity_warnings))
        if diag.evidence and diag.evidence.missing:
            details.append(f"Evidence missing {diag.evidence.missing}.")
        if diag.mass and diag.mass.violated:
            details.append("Mass audit failed.")
        if diag.schema_issues and diag.schema_issues.rows_with_issues:
            details.append(f"Schema issues in {diag.schema_issues.rows_with_issues} rows.")
        if not details:
            return headline
        return f"{headline}  " + " ".join(details)

    def _build_chip_specs(self, diag: SimulationDiagnostics) -> list[tuple[str, str, str, str]]:
        specs: list[tuple[str, str, str, str]] = []
        # Integrity
        if diag.integrity_failures:
            specs.append(("Integrity", f"FAIL ({len(diag.integrity_failures)})", "danger", self._format_integrity(diag)))
        elif diag.integrity_warnings:
            specs.append(("Integrity", f"WARN ({len(diag.integrity_warnings)})", "warn", self._format_integrity(diag)))
        else:
            specs.append(("Integrity", "ok", "ok", self._format_integrity(diag)))

        # Stability
        sev, label = self._status_severity(diag.stability_status)
        specs.append(("Stability", label, sev, self._format_status(diag.stability_status, diag.stability_reason)))

        # Off-target
        sev, label = self._status_severity(diag.off_target_status)
        specs.append(("Off-target", label, sev, self._format_status(diag.off_target_status, diag.off_target_reason)))

        # Mass audit
        if diag.mass is None:
            specs.append(("Mass audit", "--", "muted", "unavailable"))
        else:
            status = "FAIL" if diag.mass.violated else "OK"
            sev = "danger" if diag.mass.violated else "ok"
            specs.append(("Mass audit", status, sev, self._format_mass(diag)))

        # Evidence
        if diag.evidence is None:
            specs.append(("Evidence", "--", "muted", "unavailable"))
        elif diag.evidence.missing:
            specs.append(
                ("Evidence", f"missing {diag.evidence.missing}", "danger", self._format_evidence(diag))
            )
        else:
            specs.append(("Evidence", "ok", "ok", self._format_evidence(diag)))

        return specs

    def _set_chip_specs(self, specs: list[tuple[str, str, str, str]]) -> None:
        for chip in self._chips:
            try:
                chip.hide()
            except Exception:
                pass
            chip.setParent(None)
            chip.deleteLater()
        self._chips.clear()
        for label, value, severity, tooltip in specs:
            chip = QLabel(f"{label}: {value}", self._chip_row)
            chip.setTextFormat(Qt.PlainText)
            chip.setToolTip(tooltip)
            self._apply_chip_style(chip, severity)
            self._chip_layout.addWidget(chip)
            self._chips.append(chip)
        self._chip_row.setVisible(bool(specs))

    def _apply_chip_style(self, chip: QLabel, severity: str) -> None:
        base = "padding:4px 10px; border-radius:10px; font-size:11px;"
        if severity == "muted":
            chip.setStyleSheet(
                base
                + "background-color: palette(base); border: 1px solid palette(mid); color: palette(mid);"
            )
            return
        color = {
            "ok": SUCCESS,
            "warn": CAUTION,
            "danger": HX_DANGER,
        }.get(severity, SUCCESS)
        tone = QColor(color)
        bg = QColor(tone)
        bg.setAlphaF(0.14)
        border = QColor(tone)
        border.setAlphaF(0.45)
        chip.setStyleSheet(
            base
            + f"background-color: {bg.name(QColor.HexArgb)}; border: 1px solid {border.name(QColor.HexArgb)}; "
            "color: palette(window-text);"
        )

    def _status_severity(self, status: str | None) -> tuple[str, str]:
        if not status:
            return "muted", "--"
        text = str(status).strip()
        lowered = text.lower()
        if lowered in {"ok", "pass", "stable", "good", "nominal"}:
            return "ok", text
        if lowered in {"unknown", "not reported", "n/a"}:
            return "muted", "--"
        if "warn" in lowered or "limit" in lowered or "partial" in lowered:
            return "warn", text
        return "danger", text

    def _build_raw_text(self, diag: SimulationDiagnostics) -> str:
        lines: list[str] = []
        lines.append(f"Run: {self._format_run(diag)}")
        lines.append(f"Engine: {self._format_engine(diag)}")
        policy = diag.policy_hash or "--"
        semantic = diag.semantic_hash or "--"
        determinism = diag.determinism_class or "--"
        lines.append(f"Contract: policy {policy} | semantic {semantic} | determinism {determinism}")
        lines.append(f"Verdict: {self._format_verdict(diag)}")
        lines.append(f"Integrity: {self._format_integrity(diag)}")
        lines.append(f"Stability: {self._format_status(diag.stability_status, diag.stability_reason)}")
        lines.append(f"Off-target: {self._format_status(diag.off_target_status, diag.off_target_reason)}")
        lines.append(f"Mass audit: {self._format_mass(diag)}")
        lines.append(f"Constraints: {self._format_constraints(diag)}")
        lines.append(f"Evidence: {self._format_evidence(diag)}")
        lines.append(f"Uncertainty: {self._format_uncertainty(diag)}")
        lines.append(f"Schema issues: {self._format_schema(diag)}")
        lines.append(f"Calibration: {diag.calibration_badge.value if diag.calibration_badge else 'unknown'}")
        lines.append(f"Thermo context: {self._format_thermo(diag.thermo_context)}")
        return "\n".join(lines)

    def _format_run(self, diag: SimulationDiagnostics) -> str:
        parts: list[str] = []
        if diag.run_label:
            parts.append(str(diag.run_label))
        if diag.run_id:
            parts.append(f"id {diag.run_id}")
        if diag.run_kind:
            parts.append(str(diag.run_kind))
        return " | ".join(parts) if parts else "--"

    def _format_engine(self, diag: SimulationDiagnostics) -> str:
        engine = diag.engine or "--"
        if diag.backend:
            engine = f"{engine} ({diag.backend})"
        return engine

    def _format_contract(self, diag: SimulationDiagnostics) -> tuple[str, str]:
        policy = self._short_hash(diag.policy_hash)
        semantic = self._short_hash(diag.semantic_hash)
        determinism = diag.determinism_class or "--"
        text = f"policy {policy} | semantic {semantic} | determinism {determinism}"
        tooltip = f"policy {diag.policy_hash or '--'}\nsemantic {diag.semantic_hash or '--'}\ndeterminism {determinism}"
        return text, tooltip

    def _format_verdict(self, diag: SimulationDiagnostics) -> str:
        grade = diag.verdict_grade or "--"
        headline = diag.verdict_headline or ""
        parts = [grade]
        if headline:
            parts.append(headline)
        if diag.policy_compliant is not None:
            parts.append("policy ok" if diag.policy_compliant else "policy noncompliant")
        if diag.noncompliance_reasons:
            parts.append("reasons: " + ", ".join(diag.noncompliance_reasons))
        return " | ".join([p for p in parts if p]) if parts else "--"

    def _format_integrity(self, diag: SimulationDiagnostics) -> str:
        failures = ", ".join(diag.integrity_failures) if diag.integrity_failures else "none"
        warnings = ", ".join(diag.integrity_warnings) if diag.integrity_warnings else "none"
        return f"failures: {failures} | warnings: {warnings}"

    def _format_status(self, status: str | None, reason: str | None) -> str:
        if not status:
            return "not reported"
        if reason:
            return f"{status} ({reason})"
        return status

    def _format_mass(self, diag: SimulationDiagnostics) -> str:
        mass = diag.mass
        if mass is None:
            return "unavailable"
        status = "FAIL" if mass.violated else "OK"
        return (
            f"root total {mass.root_total:.4f} | suppressed {mass.root_suppressed:.4f} | "
            f"unaccounted {mass.root_unaccounted:.4f} | eps {mass.epsilon:.3g} | "
            f"max dev {mass.max_violation:.4f} | {status}"
        )

    def _format_constraints(self, diag: SimulationDiagnostics) -> str:
        con = diag.constraints
        if con is None:
            return "unavailable"
        return (
            f"edges {con.edges_with_constraints} | exclusive {con.exclusive_edges} "
            f"({con.exclusive_refs}) | requires {con.requires_edges} ({con.requires_refs}) | "
            f"forbids {con.forbids_edges} ({con.forbids_refs})"
        )

    def _format_evidence(self, diag: SimulationDiagnostics) -> str:
        ev = diag.evidence
        if ev is None:
            return "unavailable"
        return f"support {ev.support} | conflict {ev.conflict} | missing {ev.missing}"

    def _format_uncertainty(self, diag: SimulationDiagnostics) -> str:
        unc = diag.uncertainty
        if unc is None:
            return "unavailable"
        return (
            f"aleatoric {unc.aleatoric} | epistemic {unc.epistemic} | measurement {unc.measurement} | "
            f"unknown {unc.unknown}"
        )

    def _format_schema(self, diag: SimulationDiagnostics) -> str:
        issues = diag.schema_issues
        if issues is None:
            return "unavailable"
        if not issues.unique_issues:
            return f"rows with issues {issues.rows_with_issues}"
        return f"rows with issues {issues.rows_with_issues} | unique {', '.join(issues.unique_issues)}"

    def _format_thermo(self, ctx: ThermoContext | None) -> str:
        if ctx is None:
            return "unknown"
        parts = [
            f"T={format_scalar(ctx.temperature)}",
            f"I={format_scalar(ctx.ionic_strength)}",
            f"Mg={format_scalar(ctx.magnesium)}",
            f"crowding={format_scalar(ctx.crowding)}",
            f"model={ctx.model}",
            f"salt={ctx.salt_model}",
            f"mismatch={ctx.mismatch_model}",
        ]
        return " | ".join(parts)

    def _short_hash(self, value: str | None) -> str:
        if not value:
            return "--"
        val = str(value)
        if len(val) <= 10:
            return val
        return val[:10] + "..."


__all__ = ["SimulationDiagnosticsPanel"]
