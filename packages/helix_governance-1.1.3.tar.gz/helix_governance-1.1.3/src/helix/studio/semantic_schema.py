from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Sequence

try:  # pragma: no cover - optional dependency
    from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

    PYDANTIC_AVAILABLE = True
except Exception:  # pragma: no cover - fallback path
    BaseModel = object  # type: ignore
    Field = lambda *args, **kwargs: None  # type: ignore
    ValidationError = Exception  # type: ignore
    PYDANTIC_AVAILABLE = False


class SemanticSchemaError(RuntimeError):
    pass


class Unit(str, Enum):
    KCAL_PER_MOL = "kcal/mol"
    PER_S = "1/s"
    BP = "bp"
    NT = "nt"
    KELVIN = "K"
    MOLARITY = "M"
    PROBABILITY = "probability"
    UNITLESS = "unitless"


class CalibrationBadge(str, Enum):
    MEASURED = "measured"
    COMPUTED = "computed"
    ESTIMATED = "estimated"
    UNKNOWN = "unknown"


class EvidenceType(str, Enum):
    READ_BASED = "read_based"
    BARCODE = "barcode"
    ENZYME_REPORTER = "enzyme_reporter"
    ORTHOGONAL_ASSAY = "orthogonal_assay"
    SIMULATION = "simulation"
    OTHER = "other"


class CausalRole(str, Enum):
    ROOT = "root"
    BASELINE = "baseline"
    BINDING = "binding"
    PAM_RECOGNITION = "pam_recognition"
    CONFORMATIONAL_CHANGE = "conformational_change"
    CUT = "cut"
    RESECTION = "resection"
    SYNTHESIS = "synthesis"
    LIGATION = "ligation"
    MISMATCH_REPAIR = "mismatch_repair"
    REPAIR = "repair"
    RESOLVE = "resolve"
    UNKNOWN = "unknown"


class TimeStage(str, Enum):
    PRE_CUT = "pre_cut"
    POST_CUT = "post_cut"
    REPAIR_IN_PROGRESS = "repair_in_progress"
    RESOLVED = "resolved"
    UNKNOWN = "unknown"


class UncertaintyType(str, Enum):
    ALEATORIC = "aleatoric"
    EPISTEMIC = "epistemic"
    MEASUREMENT = "measurement"
    UNKNOWN = "unknown"


class DistributionFamily(str, Enum):
    GAUSSIAN = "gaussian"
    LOG_NORMAL = "log_normal"
    BETA = "beta"
    DIRICHLET = "dirichlet"
    EMPIRICAL = "empirical"
    UNKNOWN = "unknown"


if PYDANTIC_AVAILABLE:

    class _BaseSchema(BaseModel):
        model_config = ConfigDict(extra="forbid", populate_by_name=True)

    class UnknownValue(_BaseSchema):
        reason: str

    class Provenance(_BaseSchema):
        source: str
        method: str
        version: str
        timestamp: str
        assumptions: list[str] = Field(default_factory=list)

        @field_validator("source", "method", "version", "timestamp")
        @classmethod
        def _non_empty(cls, value: str) -> str:
            if not value:
                raise ValueError("provenance fields must be non-empty")
            return value

    class ScalarValue(_BaseSchema):
        value: float
        unit: Unit
        provenance: Provenance

    class UncertaintySpec(_BaseSchema):
        type: UncertaintyType
        distribution_family: DistributionFamily
        params: dict[str, ScalarValue] = Field(default_factory=dict)
        correlation_id: str | None = None
        provenance: Provenance

    class PhysicalState(_BaseSchema):
        molecular_config: str | UnknownValue
        strand_polarity: str | UnknownValue
        base_pair_energy: ScalarValue | UnknownValue

    class TimeLocality(_BaseSchema):
        stage: TimeStage
        time_step: int
        provenance: Provenance

    class ThermoContext(_BaseSchema):
        temperature: ScalarValue | UnknownValue
        ionic_strength: ScalarValue | UnknownValue
        magnesium: ScalarValue | UnknownValue
        crowding: ScalarValue | UnknownValue
        model: str | UnknownValue
        salt_model: str | UnknownValue
        mismatch_model: str | UnknownValue
        provenance: Provenance

    class Evidence(_BaseSchema):
        evidence_type: EvidenceType
        detail: str
        provenance: Provenance

    class MassAudit(_BaseSchema):
        mass_out_total: ScalarValue
        mass_suppressed: ScalarValue
        mass_unaccounted: ScalarValue
        epsilon: float
        violated: bool

    class SemanticBinding(_BaseSchema):
        schema_version: str = Field(default="v1")
        physical_state: PhysicalState
        causal_role: CausalRole
        uncertainty: UncertaintySpec
        time_locality: TimeLocality
        invariant: str
        evidence: list[Evidence] = Field(default_factory=list)
        calibration: CalibrationBadge = Field(default=CalibrationBadge.UNKNOWN)
        provenance: Provenance
        conservation: MassAudit

    class EdgeConstraints(_BaseSchema):
        exclusive_with: list[str] = Field(default_factory=list)
        requires: list[str] = Field(default_factory=list)
        forbids: list[str] = Field(default_factory=list)
        provenance: Provenance

else:
    @dataclass(frozen=True)
    class UnknownValue:
        reason: str

    @dataclass(frozen=True)
    class Provenance:
        source: str
        method: str
        version: str
        timestamp: str
        assumptions: list[str] = field(default_factory=list)

    @dataclass(frozen=True)
    class ScalarValue:
        value: float
        unit: Unit
        provenance: Provenance

    @dataclass(frozen=True)
    class UncertaintySpec:
        type: UncertaintyType
        distribution_family: DistributionFamily
        params: dict[str, ScalarValue] = field(default_factory=dict)
        correlation_id: str | None = None
        provenance: Provenance | None = None

    @dataclass(frozen=True)
    class PhysicalState:
        molecular_config: str | UnknownValue
        strand_polarity: str | UnknownValue
        base_pair_energy: ScalarValue | UnknownValue

    @dataclass(frozen=True)
    class TimeLocality:
        stage: TimeStage
        time_step: int
        provenance: Provenance

    @dataclass(frozen=True)
    class ThermoContext:
        temperature: ScalarValue | UnknownValue
        ionic_strength: ScalarValue | UnknownValue
        magnesium: ScalarValue | UnknownValue
        crowding: ScalarValue | UnknownValue
        model: str | UnknownValue
        salt_model: str | UnknownValue
        mismatch_model: str | UnknownValue
        provenance: Provenance

    @dataclass(frozen=True)
    class Evidence:
        evidence_type: EvidenceType
        detail: str
        provenance: Provenance

    @dataclass(frozen=True)
    class MassAudit:
        mass_out_total: ScalarValue
        mass_suppressed: ScalarValue
        mass_unaccounted: ScalarValue
        epsilon: float
        violated: bool

    @dataclass(frozen=True)
    class SemanticBinding:
        schema_version: str = "v1"
        physical_state: PhysicalState = field(default_factory=lambda: PhysicalState(UnknownValue("missing"), UnknownValue("missing"), UnknownValue("missing")))
        causal_role: CausalRole = CausalRole.UNKNOWN
        uncertainty: UncertaintySpec = field(
            default_factory=lambda: UncertaintySpec(
                type=UncertaintyType.UNKNOWN,
                distribution_family=DistributionFamily.UNKNOWN,
                params={},
                correlation_id=None,
                provenance=Provenance("unknown", "unknown", "unknown", "unknown", ["no provenance"]),
            )
        )
        time_locality: TimeLocality = field(
            default_factory=lambda: TimeLocality(
                stage=TimeStage.UNKNOWN,
                time_step=0,
                provenance=Provenance("unknown", "unknown", "unknown", "unknown", ["no provenance"]),
            )
        )
        invariant: str = ""
        evidence: list[Evidence] = field(default_factory=list)
        calibration: CalibrationBadge = CalibrationBadge.UNKNOWN
        provenance: Provenance = field(default_factory=lambda: Provenance("unknown", "unknown", "unknown", "unknown", ["no provenance"]))
        conservation: MassAudit = field(
            default_factory=lambda: MassAudit(
                mass_out_total=ScalarValue(1.0, Unit.PROBABILITY, Provenance("unknown", "unknown", "unknown", "unknown")),
                mass_suppressed=ScalarValue(0.0, Unit.PROBABILITY, Provenance("unknown", "unknown", "unknown", "unknown")),
                mass_unaccounted=ScalarValue(0.0, Unit.PROBABILITY, Provenance("unknown", "unknown", "unknown", "unknown")),
                epsilon=0.0,
                violated=False,
            )
        )

    @dataclass(frozen=True)
    class EdgeConstraints:
        exclusive_with: list[str] = field(default_factory=list)
        requires: list[str] = field(default_factory=list)
        forbids: list[str] = field(default_factory=list)
        provenance: Provenance = field(default_factory=lambda: Provenance("unknown", "unknown", "unknown", "unknown", ["no provenance"]))


def unknown(reason: str) -> UnknownValue:
    return UnknownValue(reason=reason)


def is_unknown(value: object) -> bool:
    return isinstance(value, UnknownValue)


def scalar_value(value: ScalarValue | UnknownValue | None) -> float | None:
    if isinstance(value, ScalarValue):
        return float(value.value)
    return None


def format_scalar(value: ScalarValue | UnknownValue | None) -> str:
    if isinstance(value, ScalarValue):
        return f"{value.value:.4g} {value.unit}"
    if isinstance(value, UnknownValue):
        return f"unknown ({value.reason})"
    return "unknown"


def _ensure_non_empty(label: str, value: str, issues: list[str]) -> str:
    if not value:
        issues.append(f"{label} missing")
        return "unknown"
    return value


def build_provenance(raw: Mapping[str, Any] | None, *, default_source: str, default_method: str, issues: list[str]) -> Provenance:
    payload = dict(raw or {}) if isinstance(raw, Mapping) else {}
    source = _ensure_non_empty("provenance.source", str(payload.get("source") or default_source), issues)
    method = _ensure_non_empty("provenance.method", str(payload.get("method") or default_method), issues)
    version = _ensure_non_empty("provenance.version", str(payload.get("version") or "unknown"), issues)
    timestamp = _ensure_non_empty("provenance.timestamp", str(payload.get("timestamp") or "unknown"), issues)
    assumptions = payload.get("assumptions") if isinstance(payload.get("assumptions"), list) else []
    if not assumptions:
        assumptions = ["unspecified"]
        issues.append("provenance.assumptions missing")
    return Provenance(source=source, method=method, version=version, timestamp=timestamp, assumptions=list(assumptions))


def build_scalar(
    value: float | None,
    unit: Unit,
    provenance: Provenance | None,
    *,
    issues: list[str],
    field_label: str,
    missing_reason: str,
) -> ScalarValue | UnknownValue:
    if value is None:
        issues.append(f"{field_label} missing")
        return unknown(missing_reason)
    if provenance is None:
        issues.append(f"{field_label} provenance missing")
        return unknown(f"{missing_reason} (provenance missing)")
    try:
        return ScalarValue(value=float(value), unit=unit, provenance=provenance)
    except Exception as exc:  # pragma: no cover - defensive
        issues.append(f"{field_label} invalid: {exc}")
        return unknown(missing_reason)


def build_uncertainty(
    raw: Mapping[str, Any] | None,
    *,
    provenance: Provenance,
    issues: list[str],
) -> UncertaintySpec:
    payload = dict(raw or {}) if isinstance(raw, Mapping) else {}
    type_raw = str(payload.get("type") or "unknown").lower()
    family_raw = str(payload.get("distribution_family") or payload.get("family") or "unknown").lower()
    try:
        unc_type = UncertaintyType(type_raw)
    except Exception:
        issues.append(f"uncertainty.type unknown: {type_raw}")
        unc_type = UncertaintyType.UNKNOWN
    try:
        family = DistributionFamily(family_raw)
    except Exception:
        issues.append(f"uncertainty.distribution_family unknown: {family_raw}")
        family = DistributionFamily.UNKNOWN
    params_raw = payload.get("params") if isinstance(payload.get("params"), Mapping) else {}
    if not params_raw and "variance" in payload:
        params_raw = {"variance": payload.get("variance")}
    params: dict[str, ScalarValue] = {}
    if isinstance(params_raw, Mapping):
        for key, val in params_raw.items():
            try:
                params[str(key)] = ScalarValue(
                    value=float(val),
                    unit=Unit.UNITLESS,
                    provenance=provenance,
                )
            except Exception:
                issues.append(f"uncertainty.params.{key} invalid")
    correlation_id = payload.get("correlation_id") if isinstance(payload.get("correlation_id"), str) else None
    return UncertaintySpec(
        type=unc_type,
        distribution_family=family,
        params=params,
        correlation_id=correlation_id,
        provenance=provenance,
    )


def validate_semantic_binding(binding: SemanticBinding) -> list[str]:
    issues: list[str] = []
    if PYDANTIC_AVAILABLE:
        try:
            SemanticBinding.model_validate(binding.model_dump())
        except ValidationError as exc:
            issues.append(str(exc))
        return issues
    # Manual validation for fallback dataclasses.
    if not binding.invariant:
        issues.append("invariant missing")
    if not isinstance(binding.causal_role, CausalRole):
        issues.append("causal_role invalid")
    if not isinstance(binding.time_locality.stage, TimeStage):
        issues.append("time_locality.stage invalid")
    return issues


__all__ = [
    "CalibrationBadge",
    "CausalRole",
    "DistributionFamily",
    "EdgeConstraints",
    "Evidence",
    "EvidenceType",
    "MassAudit",
    "PhysicalState",
    "Provenance",
    "ScalarValue",
    "SemanticBinding",
    "SemanticSchemaError",
    "TimeLocality",
    "ThermoContext",
    "TimeStage",
    "UncertaintySpec",
    "UncertaintyType",
    "Unit",
    "UnknownValue",
    "build_provenance",
    "build_scalar",
    "build_uncertainty",
    "format_scalar",
    "is_unknown",
    "scalar_value",
    "unknown",
    "validate_semantic_binding",
    "PYDANTIC_AVAILABLE",
]
