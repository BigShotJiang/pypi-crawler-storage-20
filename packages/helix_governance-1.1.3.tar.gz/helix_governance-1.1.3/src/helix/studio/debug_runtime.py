from __future__ import annotations

import os
import sys
from typing import Any

from helix import clock

def _env_flag(name: str) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return False
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def log_pid(tag: str) -> None:
    """Emit a deterministic PID/time breadcrumb to stderr when enabled.

    Enable with `HELIX_STUDIO_DEBUG_PID=1`.
    """

    if not _env_flag("HELIX_STUDIO_DEBUG_PID"):
        return
    try:
        sys.stderr.write(f"[HelixPID] {tag} pid={os.getpid()} t={clock.unix_time_s():.6f}\n")
        sys.stderr.flush()
    except Exception:
        return


def install_window_tracker(app: Any) -> Any:
    """Log top-level window show/hide events when enabled.

    Enable with `HELIX_STUDIO_DEBUG_WINDOWS=1`.
    """

    if not _env_flag("HELIX_STUDIO_DEBUG_WINDOWS"):
        return None

    try:
        from PySide6.QtCore import QObject, QEvent, Qt
        from PySide6.QtWidgets import QWidget
    except Exception:
        return None

    log_all = _env_flag("HELIX_STUDIO_DEBUG_WINDOWS_ALL")

    class _Tracker(QObject):
        def eventFilter(self, obj, event) -> bool:  # type: ignore[override]
            try:
                if not isinstance(obj, QWidget) or not obj.isWindow():
                    return False
                if not log_all:
                    try:
                        wtype = obj.windowType()
                        if wtype in (Qt.WindowType.Popup, Qt.WindowType.ToolTip):
                            return False
                    except Exception:
                        pass
                et = event.type()
                if et not in (QEvent.Show, QEvent.Hide, QEvent.Close):
                    return False
                geo = obj.geometry()
                title = obj.windowTitle()
                name = obj.objectName()
                cls = type(obj).__name__
                parent = obj.parentWidget()
                parent_cls = type(parent).__name__ if parent is not None else None
                try:
                    wtype = obj.windowType()
                    wtype_int = int(wtype)
                except Exception:
                    wtype_int = -1
                sys.stderr.write(
                    "[HelixWindow] "
                    f"event={int(et)} "
                    f"class={cls} "
                    f"id=0x{id(obj):x} "
                    f"windowType={wtype_int} "
                    f"parent={parent_cls} "
                    f"title={title!r} "
                    f"objectName={name!r} "
                    f"geom=({geo.x()},{geo.y()},{geo.width()}x{geo.height()})\n"
                )
                sys.stderr.flush()
            except Exception:
                return False
            return False

    tracker = _Tracker(app)
    try:
        app.installEventFilter(tracker)
    except Exception:
        return None
    # Prevent GC in some embed paths.
    try:
        setattr(app, "_helix_window_tracker", tracker)
    except Exception:
        pass
    return tracker


__all__ = ["install_window_tracker", "log_pid"]
