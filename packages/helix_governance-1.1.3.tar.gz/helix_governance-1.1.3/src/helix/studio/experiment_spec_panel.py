from __future__ import annotations

import json
from typing import Any, Mapping, Sequence

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QSpinBox,
    QVBoxLayout,
    QWidget,
    QCheckBox,
)

from helix import clock
from .experiment_spec import experiment_spec_to_dict
from .session import SessionModel
from .experiment_intent_spec_panel import ExperimentIntentSpecEditor
from .suggestions import (
    CONF_HIGH,
    SOURCE_USER,
    SOURCE_USER_APPLIED,
    actionable,
    suggestions_enabled,
)
from .ui_tokens import (
    CAUTION,
    MARGIN_PANEL,
    SPACING_MEDIUM,
    SPACING_SMALL,
    base_font,
    monospace_font,
)


INTENT_CHOICES: list[tuple[str, str]] = [
    ("knockout", "Knockout"),
    ("precise_substitution", "Precise substitution"),
    ("tag_insertion", "Tag insertion"),
    ("promoter_edit", "Promoter edit"),
    ("prime_edit", "Prime edit"),
    ("multiplex", "Multiplex"),
]

EDIT_MODALITIES: list[tuple[str, str]] = [
    ("crispr_cut", "CRISPR cut"),
    ("prime", "Prime"),
    ("pcr", "PCR"),
]

BASE_EDITOR_CHOICES: list[tuple[str, str]] = [
    ("ABE", "ABE"),
    ("CBE", "CBE"),
]

DELIVERY_MODE_CHOICES: list[tuple[str, str]] = [
    ("", "Auto (default)"),
    ("RNP", "RNP"),
    ("mRNA", "mRNA"),
    ("plasmid", "plasmid"),
    ("viral", "viral"),
]

REPAIR_BIAS_PRESET_CHOICES: list[tuple[str, str]] = [
    ("", "Auto (neutral)"),
    ("neutral", "Neutral"),
    ("nhej_heavy", "NHEJ-heavy"),
    ("mmej_heavy", "MMEJ-heavy"),
    ("hdr_heavy", "HDR-heavy"),
]


def _default_base_window(editor_type: str) -> tuple[int, int]:
    if str(editor_type).upper() == "CBE":
        return 13, 17
    return 12, 16


def _normalize_editor_type(value: Any) -> str:
    text = str(value or "").strip().upper()
    if text in {"ABE", "CBE"}:
        return text
    if "CBE" in text:
        return "CBE"
    if "ABE" in text:
        return "ABE"
    return "ABE"


class ExperimentSpecEditor(QWidget):
    """Lightweight editor for ExperimentSpec intent + constraints."""

    def __init__(self, session: SessionModel, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._session = session
        self._updating = False
        self._pending_edit_intent: dict[str, Any] | None = None
        self._pending_constraints: dict[str, Any] = {}
        self._pending_assumptions: dict[str, Any] = {}
        self._edit_intent_valid = True
        self._constraints_valid = True
        self._assumptions_valid = True
        self._locus_valid = True
        self._base_valid = True
        self._base_dirty = False
        self._pending_base_edit: dict[str, Any] = {}
        self._cell_dirty = False
        self._current_input_digest: str | None = None
        self._active_locus_suggestion: Mapping[str, Any] | None = None
        self._active_genome_suggestion: Mapping[str, Any] | None = None
        self._locus_candidates: Sequence[Mapping[str, Any]] = []
        self._genome_candidates: Sequence[Mapping[str, Any]] = []

        self.setFont(base_font())
        root = QVBoxLayout(self)
        root.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        root.setSpacing(SPACING_MEDIUM)

        self._intent_editor = ExperimentIntentSpecEditor(self._session, self)
        root.addWidget(self._intent_editor)

        group = QGroupBox("Experiment intent & constraints", self)
        group_layout = QVBoxLayout(group)
        group_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        group_layout.setSpacing(SPACING_MEDIUM)

        form = QFormLayout()
        form.setHorizontalSpacing(SPACING_MEDIUM)
        form.setVerticalSpacing(SPACING_SMALL)

        self._experiment_id = QLineEdit(self)
        form.addRow("Experiment ID", self._experiment_id)

        self._genome_build = QLineEdit(self)
        form.addRow("Genome build", self._genome_build)
        self._genome_build_suggestion = QLabel("", self)
        self._genome_build_suggestion.setStyleSheet("color: palette(link); font-size: 11px;")
        self._genome_build_suggestion.setOpenExternalLinks(False)
        self._genome_build_suggestion.linkActivated.connect(self._on_apply_genome_suggestion)
        self._genome_build_suggestion.hide()
        group_layout.addWidget(self._genome_build_suggestion)

        self._contig = QLineEdit(self)
        form.addRow("Contig", self._contig)

        locus_row = QHBoxLayout()
        self._locus_chr = QLineEdit(self)
        self._locus_chr.setPlaceholderText("chr")
        self._locus_start = QSpinBox(self)
        self._locus_start.setRange(0, 2_000_000_000)
        self._locus_end = QSpinBox(self)
        self._locus_end.setRange(0, 2_000_000_000)
        self._locus_strand = QComboBox(self)
        self._locus_strand.addItems(["+", "-"])
        locus_row.addWidget(self._locus_chr)
        locus_row.addWidget(QLabel("Start", self))
        locus_row.addWidget(self._locus_start)
        locus_row.addWidget(QLabel("End", self))
        locus_row.addWidget(self._locus_end)
        locus_row.addWidget(QLabel("Strand", self))
        locus_row.addWidget(self._locus_strand)
        locus_widget = QWidget(self)
        locus_widget.setLayout(locus_row)
        form.addRow("Locus", locus_widget)
        self._locus_suggestion = QLabel("", self)
        self._locus_suggestion.setStyleSheet("color: palette(link); font-size: 11px;")
        self._locus_suggestion.setOpenExternalLinks(False)
        self._locus_suggestion.linkActivated.connect(self._on_apply_locus_suggestion)
        self._locus_suggestion.hide()
        group_layout.addWidget(self._locus_suggestion)

        self._intent = QComboBox(self)
        for value, label in INTENT_CHOICES:
            self._intent.addItem(label, value)
        form.addRow("Intent", self._intent)

        modality_row = QHBoxLayout()
        self._modality_checks: dict[str, QCheckBox] = {}
        for value, label in EDIT_MODALITIES:
            cb = QCheckBox(label, self)
            self._modality_checks[value] = cb
            modality_row.addWidget(cb)
        modality_row.addStretch(1)
        modality_widget = QWidget(self)
        modality_widget.setLayout(modality_row)
        form.addRow("Modalities", modality_widget)

        group_layout.addLayout(form)

        self._locus_warning = QLabel("", self)
        self._locus_warning.setStyleSheet(f"color: {CAUTION};")
        self._locus_warning.hide()
        group_layout.addWidget(self._locus_warning)

        edit_intent_label = QLabel("Advanced intent JSON (optional)", self)
        edit_intent_label.setStyleSheet("font-weight: 600;")
        group_layout.addWidget(edit_intent_label)
        self._edit_intent = QPlainTextEdit(self)
        self._edit_intent.setFont(monospace_font())
        self._edit_intent.setPlaceholderText(
            "{\n"
            "  \"version\": \"v1\",\n"
            "  \"goal\": \"knockout\",\n"
            "  \"target\": {\"kind\": \"cds\", \"transcriptId\": null},\n"
            "  \"success\": {\"metric\": \"frameshift\", \"threshold\": 0.95, \"strict\": true},\n"
            "  \"context\": {\"haplotypeId\": null, \"phaseSetId\": null}\n"
            "}"
        )
        self._edit_intent.setMinimumHeight(90)
        group_layout.addWidget(self._edit_intent)
        self._edit_intent_warning = QLabel("", self)
        self._edit_intent_warning.setStyleSheet(f"color: {CAUTION};")
        self._edit_intent_warning.hide()
        group_layout.addWidget(self._edit_intent_warning)

        constraints_label = QLabel("Constraints (JSON)", self)
        constraints_label.setStyleSheet("font-weight: 600;")
        group_layout.addWidget(constraints_label)
        self._constraints = QPlainTextEdit(self)
        self._constraints.setFont(monospace_font())
        self._constraints.setPlaceholderText("{\n  \"offTargetRiskThreshold\": 0.2,\n  \"maxIndelSize\": 25\n}")
        self._constraints.setMinimumHeight(90)
        group_layout.addWidget(self._constraints)
        self._constraints_warning = QLabel("", self)
        self._constraints_warning.setStyleSheet(f"color: {CAUTION};")
        self._constraints_warning.hide()
        group_layout.addWidget(self._constraints_warning)

        base_label = QLabel("Base editing assumptions", self)
        base_label.setStyleSheet("font-weight: 600;")
        group_layout.addWidget(base_label)
        base_form = QFormLayout()
        base_form.setHorizontalSpacing(SPACING_MEDIUM)
        base_form.setVerticalSpacing(SPACING_SMALL)

        self._base_editor = QComboBox(self)
        for value, label in BASE_EDITOR_CHOICES:
            self._base_editor.addItem(label, value)
        base_form.addRow("Editor type", self._base_editor)

        window_row = QHBoxLayout()
        self._base_window_start = QSpinBox(self)
        self._base_window_start.setRange(-30, 30)
        self._base_window_end = QSpinBox(self)
        self._base_window_end.setRange(-30, 30)
        window_row.addWidget(QLabel("Start", self))
        window_row.addWidget(self._base_window_start)
        window_row.addWidget(QLabel("End", self))
        window_row.addWidget(self._base_window_end)
        window_widget = QWidget(self)
        window_widget.setLayout(window_row)
        base_form.addRow("Window (PAM-relative)", window_widget)

        intended_row = QHBoxLayout()
        self._base_intended_enabled = QCheckBox("Use intended index", self)
        self._base_intended = QSpinBox(self)
        self._base_intended.setRange(-30, 30)
        self._base_intended.setEnabled(False)
        intended_row.addWidget(self._base_intended_enabled)
        intended_row.addWidget(self._base_intended)
        intended_row.addStretch(1)
        intended_widget = QWidget(self)
        intended_widget.setLayout(intended_row)
        base_form.addRow("Intended index", intended_widget)

        base_widget = QWidget(self)
        base_widget.setLayout(base_form)
        group_layout.addWidget(base_widget)

        self._base_warning = QLabel("", self)
        self._base_warning.setStyleSheet(f"color: {CAUTION};")
        self._base_warning.hide()
        group_layout.addWidget(self._base_warning)

        cell_label = QLabel("Cell context", self)
        cell_label.setStyleSheet("font-weight: 600;")
        group_layout.addWidget(cell_label)
        cell_form = QFormLayout()
        cell_form.setHorizontalSpacing(SPACING_MEDIUM)
        cell_form.setVerticalSpacing(SPACING_SMALL)

        self._cell_line = QLineEdit(self)
        self._cell_line.setPlaceholderText("e.g. K562")
        cell_form.addRow("Cell line", self._cell_line)

        self._delivery_mode = QComboBox(self)
        for value, label in DELIVERY_MODE_CHOICES:
            self._delivery_mode.addItem(label, value)
        cell_form.addRow("Delivery", self._delivery_mode)

        self._repair_bias_preset = QComboBox(self)
        for value, label in REPAIR_BIAS_PRESET_CHOICES:
            self._repair_bias_preset.addItem(label, value)
        cell_form.addRow("Repair bias", self._repair_bias_preset)

        accessibility_row = QHBoxLayout()
        self._accessibility_override = QCheckBox("Override", self)
        self._accessibility_scalar = QDoubleSpinBox(self)
        self._accessibility_scalar.setRange(0.0, 10.0)
        self._accessibility_scalar.setDecimals(3)
        self._accessibility_scalar.setSingleStep(0.05)
        self._accessibility_scalar.setValue(1.0)
        self._accessibility_scalar.setEnabled(False)
        accessibility_row.addWidget(self._accessibility_override)
        accessibility_row.addWidget(self._accessibility_scalar)
        accessibility_row.addStretch(1)
        accessibility_widget = QWidget(self)
        accessibility_widget.setLayout(accessibility_row)
        cell_form.addRow("Accessibility scalar", accessibility_widget)

        cell_widget = QWidget(self)
        cell_widget.setLayout(cell_form)
        group_layout.addWidget(cell_widget)

        assumptions_label = QLabel("Assumptions (JSON)", self)
        assumptions_label.setStyleSheet("font-weight: 600;")
        group_layout.addWidget(assumptions_label)
        self._assumptions = QPlainTextEdit(self)
        self._assumptions.setFont(monospace_font())
        self._assumptions.setPlaceholderText("{\n  \"cellType\": \"K562\",\n  \"deliveryMethod\": \"electroporation\"\n}")
        self._assumptions.setMinimumHeight(90)
        group_layout.addWidget(self._assumptions)
        self._assumptions_warning = QLabel("", self)
        self._assumptions_warning.setStyleSheet(f"color: {CAUTION};")
        self._assumptions_warning.hide()
        group_layout.addWidget(self._assumptions_warning)

        root.addWidget(group)

        try:
            self._session.stateChanged.connect(self._on_state_changed)
        except Exception:
            pass

        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(250)
        self._debounce.timeout.connect(self._commit_spec)

        self._wire_inputs()

    def _wire_inputs(self) -> None:
        self._experiment_id.textChanged.connect(self._schedule_commit)
        self._genome_build.textChanged.connect(self._schedule_commit)
        self._contig.textChanged.connect(self._schedule_commit)
        self._locus_chr.textChanged.connect(self._schedule_commit)
        self._locus_start.valueChanged.connect(self._schedule_commit)
        self._locus_end.valueChanged.connect(self._schedule_commit)
        self._locus_strand.currentIndexChanged.connect(self._schedule_commit)
        self._intent.currentIndexChanged.connect(self._schedule_commit)
        self._edit_intent.textChanged.connect(self._schedule_edit_intent)
        for cb in self._modality_checks.values():
            cb.stateChanged.connect(self._schedule_commit)
        self._constraints.textChanged.connect(self._schedule_constraints)
        self._assumptions.textChanged.connect(self._schedule_assumptions)
        self._base_editor.currentIndexChanged.connect(self._schedule_base_edit)
        self._base_window_start.valueChanged.connect(self._schedule_base_edit)
        self._base_window_end.valueChanged.connect(self._schedule_base_edit)
        self._base_intended_enabled.stateChanged.connect(self._on_intended_toggle)
        self._base_intended.valueChanged.connect(self._schedule_base_edit)
        self._cell_line.textChanged.connect(self._schedule_cell_context)
        self._delivery_mode.currentIndexChanged.connect(self._schedule_cell_context)
        self._repair_bias_preset.currentIndexChanged.connect(self._schedule_cell_context)
        self._accessibility_override.stateChanged.connect(self._on_accessibility_override_toggled)
        self._accessibility_scalar.valueChanged.connect(self._schedule_cell_context)

    def set_spec(self, spec: dict[str, Any]) -> None:
        self._updating = True
        payload = experiment_spec_to_dict(spec)
        self._experiment_id.setText(str(payload.get("experimentId") or ""))
        reference = payload.get("reference") if isinstance(payload.get("reference"), dict) else {}
        self._genome_build.setText(str(reference.get("genomeBuild") or ""))
        self._contig.setText(str(reference.get("contig") or ""))

        locus = payload.get("locus") if isinstance(payload.get("locus"), dict) else {}
        self._locus_chr.setText(str(locus.get("chr") or ""))
        self._locus_start.setValue(int(locus.get("start") or 0))
        self._locus_end.setValue(int(locus.get("end") or 0))
        strand = str(locus.get("strand") or "+")
        idx = self._locus_strand.findText(strand)
        self._locus_strand.setCurrentIndex(idx if idx >= 0 else 0)

        intent = str(payload.get("intent") or "knockout")
        intent_idx = self._intent.findData(intent)
        self._intent.setCurrentIndex(intent_idx if intent_idx >= 0 else 0)

        modalities = payload.get("editModalities") if isinstance(payload.get("editModalities"), list) else []
        for value, cb in self._modality_checks.items():
            cb.setChecked(value in modalities)

        edit_intent = payload.get("editIntent") if isinstance(payload.get("editIntent"), dict) else None
        self._pending_edit_intent = dict(edit_intent) if edit_intent is not None else None
        self._edit_intent_valid = True
        if edit_intent is None:
            self._edit_intent.setPlainText("")
        else:
            self._edit_intent.setPlainText(json.dumps(edit_intent, indent=2, sort_keys=True))

        constraints = payload.get("constraints") if isinstance(payload.get("constraints"), dict) else {}
        self._pending_constraints = dict(constraints)
        self._constraints_valid = True
        self._constraints.setPlainText(json.dumps(constraints, indent=2, sort_keys=True))

        assumptions = payload.get("assumptions") if isinstance(payload.get("assumptions"), dict) else {}
        self._pending_assumptions = dict(assumptions)
        self._assumptions_valid = True
        self._assumptions.setPlainText(json.dumps(assumptions, indent=2, sort_keys=True))
        self._sync_base_controls_from_assumptions(assumptions)
        self._sync_cell_controls_from_assumptions(assumptions)

        self._updating = False
        self._refresh_warnings()
        try:
            self._intent_editor.set_intent_spec(getattr(self._session.state, "experiment_intent_spec", None))
        except Exception:
            pass

    def _schedule_commit(self) -> None:
        if self._updating:
            return
        self._debounce.start()

    def _schedule_constraints(self) -> None:
        if self._updating:
            return
        ok = self._parse_constraints()
        if ok:
            self._debounce.start()

    def _schedule_edit_intent(self) -> None:
        if self._updating:
            return
        ok = self._parse_edit_intent()
        if ok:
            self._debounce.start()

    def _schedule_assumptions(self) -> None:
        if self._updating:
            return
        ok = self._parse_assumptions()
        if ok:
            self._debounce.start()

    def _parse_constraints(self) -> bool:
        text = self._constraints.toPlainText().strip()
        if not text:
            self._pending_constraints = {}
            self._constraints_warning.hide()
            self._constraints_valid = True
            return True
        try:
            data = json.loads(text)
        except Exception:
            self._constraints_warning.setText("Constraints JSON is invalid; changes not applied.")
            self._constraints_warning.show()
            self._constraints_valid = False
            return False
        if not isinstance(data, dict):
            self._constraints_warning.setText("Constraints must be a JSON object.")
            self._constraints_warning.show()
            self._constraints_valid = False
            return False
        self._pending_constraints = data
        self._constraints_warning.hide()
        self._constraints_valid = True
        return True

    def _parse_edit_intent(self) -> bool:
        text = self._edit_intent.toPlainText().strip()
        if not text:
            self._pending_edit_intent = None
            self._edit_intent_warning.hide()
            self._edit_intent_valid = True
            return True
        try:
            data = json.loads(text)
        except Exception:
            self._edit_intent_warning.setText("Advanced intent JSON is invalid; changes not applied.")
            self._edit_intent_warning.show()
            self._edit_intent_valid = False
            return False
        if data is None:
            self._pending_edit_intent = None
            self._edit_intent_warning.hide()
            self._edit_intent_valid = True
            return True
        if not isinstance(data, dict):
            self._edit_intent_warning.setText("Advanced intent must be a JSON object.")
            self._edit_intent_warning.show()
            self._edit_intent_valid = False
            return False
        self._pending_edit_intent = data
        self._edit_intent_warning.hide()
        self._edit_intent_valid = True
        return True

    def _parse_assumptions(self) -> bool:
        text = self._assumptions.toPlainText().strip()
        if not text:
            self._pending_assumptions = {}
            self._assumptions_warning.hide()
            self._assumptions_valid = True
            self._base_dirty = False
            self._sync_base_controls_from_assumptions({})
            return True
        try:
            data = json.loads(text)
        except Exception:
            self._assumptions_warning.setText("Assumptions JSON is invalid; changes not applied.")
            self._assumptions_warning.show()
            self._assumptions_valid = False
            return False
        if not isinstance(data, dict):
            self._assumptions_warning.setText("Assumptions must be a JSON object.")
            self._assumptions_warning.show()
            self._assumptions_valid = False
            return False
        self._pending_assumptions = data
        self._assumptions_warning.hide()
        self._assumptions_valid = True
        self._base_dirty = False
        self._cell_dirty = False
        self._sync_base_controls_from_assumptions(data)
        self._sync_cell_controls_from_assumptions(data)
        return True

    def _sync_base_controls_from_assumptions(self, assumptions: dict[str, Any]) -> None:
        base_cfg = {}
        if isinstance(assumptions.get("baseEdit"), dict):
            base_cfg = assumptions.get("baseEdit", {})
        elif isinstance(assumptions.get("base_edit"), dict):
            base_cfg = assumptions.get("base_edit", {})
        elif isinstance(assumptions.get("base"), dict):
            base_cfg = assumptions.get("base", {})
        editor_type = _normalize_editor_type(
            base_cfg.get("editorType")
            or base_cfg.get("editorKind")
            or base_cfg.get("editor")
            or base_cfg.get("kind")
        )
        window_start = base_cfg.get("windowStart")
        window_end = base_cfg.get("windowEnd")
        if window_start is None or window_end is None:
            default_start, default_end = _default_base_window(editor_type)
            window_start = default_start if window_start is None else window_start
            window_end = default_end if window_end is None else window_end
        intended = base_cfg.get("intendedIndex")
        was_updating = self._updating
        self._updating = True
        idx = self._base_editor.findData(editor_type)
        self._base_editor.setCurrentIndex(idx if idx >= 0 else 0)
        self._base_window_start.setValue(int(window_start))
        self._base_window_end.setValue(int(window_end))
        if intended is None:
            self._base_intended_enabled.setChecked(False)
            self._base_intended.setEnabled(False)
        else:
            self._base_intended_enabled.setChecked(True)
            self._base_intended.setEnabled(True)
            try:
                self._base_intended.setValue(int(intended))
            except Exception:
                self._base_intended.setValue(0)
        self._updating = was_updating
        self._validate_base_window()

    def _on_intended_toggle(self) -> None:
        if self._updating:
            return
        enabled = self._base_intended_enabled.isChecked()
        self._base_intended.setEnabled(enabled)
        self._schedule_base_edit()

    def _validate_base_window(self) -> bool:
        start = int(self._base_window_start.value())
        end = int(self._base_window_end.value())
        if start >= end:
            self._base_warning.setText("Base edit window start must be < end.")
            self._base_warning.show()
            self._base_valid = False
            return False
        self._base_warning.hide()
        self._base_valid = True
        return True

    def _schedule_base_edit(self) -> None:
        if self._updating:
            return
        self._base_dirty = True
        if not self._validate_base_window():
            return
        editor_type = _normalize_editor_type(self._base_editor.currentData() or self._base_editor.currentText())
        window_start = int(self._base_window_start.value())
        window_end = int(self._base_window_end.value())
        base_edit: dict[str, Any] = {
            "editorType": editor_type,
            "windowStart": window_start,
            "windowEnd": window_end,
        }
        if self._base_intended_enabled.isChecked():
            base_edit["intendedIndex"] = int(self._base_intended.value())

        self._pending_base_edit = dict(base_edit)
        assumptions = dict(self._pending_assumptions)
        assumptions["baseEdit"] = dict(base_edit)
        self._pending_assumptions = assumptions
        self._sync_assumptions_text()
        self._debounce.start()

    def _sync_cell_controls_from_assumptions(self, assumptions: dict[str, Any]) -> None:
        cell_line = str(assumptions.get("cellLine") or assumptions.get("cell_line") or "").strip()
        delivery = str(assumptions.get("delivery") or assumptions.get("deliveryMode") or assumptions.get("delivery_mode") or "").strip()
        repair_bias = str(
            assumptions.get("repairBiasPreset")
            or assumptions.get("repair_bias_preset")
            or assumptions.get("repairBias")
            or assumptions.get("repair_bias")
            or ""
        ).strip()
        acc = assumptions.get("accessibilityScalar")
        if acc is None:
            acc = assumptions.get("accessibility_scalar")

        was_updating = self._updating
        self._updating = True
        self._cell_line.setText(cell_line)

        delivery_idx = self._delivery_mode.findData(delivery)
        self._delivery_mode.setCurrentIndex(delivery_idx if delivery_idx >= 0 else 0)

        bias_idx = self._repair_bias_preset.findData(repair_bias)
        self._repair_bias_preset.setCurrentIndex(bias_idx if bias_idx >= 0 else 0)

        if acc is None:
            self._accessibility_override.setChecked(False)
            self._accessibility_scalar.setEnabled(False)
            self._accessibility_scalar.setValue(1.0)
        else:
            self._accessibility_override.setChecked(True)
            self._accessibility_scalar.setEnabled(True)
            try:
                self._accessibility_scalar.setValue(float(acc))
            except Exception:
                self._accessibility_scalar.setValue(1.0)
        self._updating = was_updating

    def _on_accessibility_override_toggled(self) -> None:
        if self._updating:
            return
        enabled = self._accessibility_override.isChecked()
        self._accessibility_scalar.setEnabled(enabled)
        self._schedule_cell_context()

    def _schedule_cell_context(self) -> None:
        if self._updating:
            return
        self._cell_dirty = True
        assumptions = dict(self._pending_assumptions)

        cell_line = self._cell_line.text().strip()
        if cell_line:
            assumptions["cellLine"] = cell_line
        else:
            assumptions.pop("cellLine", None)

        delivery = str(self._delivery_mode.currentData() or "").strip()
        if delivery:
            assumptions["delivery"] = delivery
        else:
            assumptions.pop("delivery", None)

        repair_bias = str(self._repair_bias_preset.currentData() or "").strip()
        if repair_bias:
            assumptions["repairBiasPreset"] = repair_bias
        else:
            assumptions.pop("repairBiasPreset", None)

        if self._accessibility_override.isChecked():
            assumptions["accessibilityScalar"] = float(self._accessibility_scalar.value())
        else:
            assumptions.pop("accessibilityScalar", None)

        self._pending_assumptions = assumptions
        self._sync_assumptions_text()
        self._debounce.start()

    def _sync_assumptions_text(self) -> None:
        was_updating = self._updating
        self._updating = True
        self._assumptions.setPlainText(json.dumps(self._pending_assumptions, indent=2, sort_keys=True))
        self._updating = was_updating

    def _refresh_warnings(self) -> None:
        locus_chr = self._locus_chr.text().strip()
        start = int(self._locus_start.value())
        end = int(self._locus_end.value())
        warnings: list[str] = []
        unset_locus = not locus_chr and start == 0 and end == 0
        if not unset_locus:
            if not locus_chr:
                warnings.append("Locus chr is required.")
            if start >= end:
                warnings.append("Locus start must be < end.")
        if warnings:
            self._locus_valid = False
            self._locus_warning.setText(" ".join(warnings))
            self._locus_warning.show()
        else:
            self._locus_valid = True
            self._locus_warning.hide()

        if self._constraints_valid:
            constraints_warnings: list[str] = []
            max_indel = self._pending_constraints.get("maxIndelSize")
            if max_indel is not None:
                try:
                    if float(max_indel) <= 0:
                        constraints_warnings.append("maxIndelSize must be > 0.")
                except Exception:
                    constraints_warnings.append("maxIndelSize must be numeric.")
            off_target = self._pending_constraints.get("offTargetRiskThreshold")
            if off_target is not None:
                try:
                    val = float(off_target)
                    if val < 0 or val > 1:
                        constraints_warnings.append("offTargetRiskThreshold must be between 0 and 1.")
                except Exception:
                    constraints_warnings.append("offTargetRiskThreshold must be numeric.")
            if constraints_warnings:
                self._constraints_warning.setText(" ".join(constraints_warnings))
                self._constraints_warning.show()
            else:
                self._constraints_warning.hide()
        self._validate_base_window()

    def _commit_spec(self) -> None:
        if self._updating:
            return
        self._refresh_warnings()
        if not (
            self._edit_intent_valid
            and self._constraints_valid
            and self._assumptions_valid
            and self._locus_valid
            and self._base_valid
        ):
            return
        spec = experiment_spec_to_dict(self._session.state.experiment_spec)
        prev_reference = spec.get("reference") if isinstance(spec.get("reference"), dict) else {}
        prev_genome_build = str(prev_reference.get("genomeBuild") or "")
        prev_locus = spec.get("locus") if isinstance(spec.get("locus"), dict) else {}
        prev_locus_tuple = (
            str(prev_locus.get("chr") or ""),
            int(prev_locus.get("start") or 0),
            int(prev_locus.get("end") or 0),
            str(prev_locus.get("strand") or "+"),
        )
        spec["experimentId"] = self._experiment_id.text().strip() or "unset"
        reference = spec.get("reference") if isinstance(spec.get("reference"), dict) else {}
        reference["genomeBuild"] = self._genome_build.text().strip()
        reference["contig"] = self._contig.text().strip()
        spec["reference"] = reference

        locus = spec.get("locus") if isinstance(spec.get("locus"), dict) else {}
        locus["chr"] = self._locus_chr.text().strip()
        locus["start"] = int(self._locus_start.value())
        locus["end"] = int(self._locus_end.value())
        locus["strand"] = self._locus_strand.currentText()
        spec["locus"] = locus

        spec["intent"] = self._intent.currentData() or "knockout"
        if self._pending_edit_intent is None:
            spec.pop("editIntent", None)
        else:
            spec["editIntent"] = dict(self._pending_edit_intent)

        modalities: list[str] = []
        for value, cb in self._modality_checks.items():
            if cb.isChecked():
                modalities.append(value)
        spec["editModalities"] = modalities
        spec["constraints"] = dict(self._pending_constraints)
        spec["assumptions"] = dict(self._pending_assumptions)

        now_ts = clock.utc_now_iso()
        new_genome_build = str(reference.get("genomeBuild") or "")
        if new_genome_build != prev_genome_build:
            reference["genomeBuild_source"] = SOURCE_USER
            reference["genomeBuild_inference_ref"] = None
            reference["genomeBuild_updatedAt"] = now_ts

        new_locus_tuple = (
            str(locus.get("chr") or ""),
            int(locus.get("start") or 0),
            int(locus.get("end") or 0),
            str(locus.get("strand") or "+"),
        )
        if new_locus_tuple != prev_locus_tuple:
            spec["locus_source"] = SOURCE_USER
            spec["locus_inference_ref"] = None
            spec["locus_updatedAt"] = now_ts

        try:
            self._session.update(experiment_spec=experiment_spec_to_dict(spec))
        except Exception:
            pass

    # --- suggestion handling -------------------------------------------------
    def _choose_candidate(self, candidates: Sequence[Mapping[str, Any]], title: str) -> Mapping[str, Any] | None:
        if not candidates:
            return None
        items: list[str] = []
        for cand in candidates:
            label = str(cand.get("label") or cand.get("genomeBuild") or "candidate")
            desc: list[str] = []
            try:
                score = float(cand.get("score", 0.0))
                desc.append(f"score {score:.2f}")
            except Exception:
                pass
            method = cand.get("method")
            if method:
                desc.append(str(method))
            conf = cand.get("confidence")
            if conf:
                desc.append(str(conf))
            suffix = f" ({'; '.join(desc)})" if desc else ""
            items.append(f"{label}{suffix}")
        choice, ok = QInputDialog.getItem(self, title, "Select inference:", items, 0, False)
        if not ok:
            return None
        try:
            idx = items.index(choice)
        except ValueError:
            return None
        return candidates[idx] if 0 <= idx < len(candidates) else None

    def _show_locus_suggestion(self, suggestion: Any) -> None:
        self._active_locus_suggestion = None
        self._locus_candidates = []
        if not (suggestions_enabled() and isinstance(suggestion, Mapping)):
            self._locus_suggestion.hide()
            return
        self._active_locus_suggestion = suggestion
        candidates = suggestion.get("candidates") if isinstance(suggestion.get("candidates"), Sequence) else []
        self._locus_candidates = [c for c in candidates if isinstance(c, Mapping)]
        best = suggestion.get("best") if isinstance(suggestion.get("best"), Mapping) else {}
        label = str(best.get("label") or "")
        conf = str(best.get("confidence") or "low")
        ambiguous = bool(suggestion.get("ambiguous"))
        stale = self._current_input_digest and suggestion.get("input_digest") != self._current_input_digest
        if stale:
            self._locus_suggestion.setText("Stale locus suggestion (input changed). Re-ingest to refresh.")
            self._locus_suggestion.show()
            return
        if ambiguous or conf != CONF_HIGH or not actionable(suggestion, self._current_input_digest):
            if self._locus_candidates:
                self._locus_suggestion.setText('<a href="choose_locus">Locus inference available (ambiguous/low) — choose…</a>')
                self._locus_suggestion.show()
            else:
                self._locus_suggestion.hide()
            return
        if label:
            self._locus_suggestion.setText(f'<a href="apply_locus">Inferred locus: {label} ({conf}) — apply</a>')
            self._locus_suggestion.show()
        else:
            self._locus_suggestion.hide()

    def _show_genome_suggestion(self, suggestion: Any) -> None:
        self._active_genome_suggestion = None
        self._genome_candidates = []
        if not (suggestions_enabled() and isinstance(suggestion, Mapping)):
            self._genome_build_suggestion.hide()
            return
        self._active_genome_suggestion = suggestion
        candidates = suggestion.get("candidates") if isinstance(suggestion.get("candidates"), Sequence) else []
        self._genome_candidates = [c for c in candidates if isinstance(c, Mapping)]
        best = suggestion.get("best") if isinstance(suggestion.get("best"), Mapping) else {}
        build = str(best.get("genomeBuild") or best.get("label") or "")
        conf = str(best.get("confidence") or "low")
        ambiguous = bool(suggestion.get("ambiguous"))
        stale = self._current_input_digest and suggestion.get("input_digest") != self._current_input_digest
        if stale:
            self._genome_build_suggestion.setText("Stale genome build suggestion (input changed). Re-ingest to refresh.")
            self._genome_build_suggestion.show()
            return
        if ambiguous or conf != CONF_HIGH or not actionable(suggestion, self._current_input_digest):
            if self._genome_candidates:
                self._genome_build_suggestion.setText(
                    '<a href="choose_genome">Genome build inference available (ambiguous/low) — choose…</a>'
                )
                self._genome_build_suggestion.show()
            else:
                self._genome_build_suggestion.hide()
            return
        if build:
            self._genome_build_suggestion.setText(
                f'<a href="apply_genome">Inferred build: {build} ({conf}) — apply</a>'
            )
            self._genome_build_suggestion.show()
        else:
            self._genome_build_suggestion.hide()

    def _on_state_changed(self, state) -> None:
        cfg = state.config if hasattr(state, "config") and isinstance(state.config, dict) else {}
        meta = cfg.get("metadata") if isinstance(cfg, dict) else {}
        self._current_input_digest = meta.get("input_digest") if suggestions_enabled() else None
        if suggestions_enabled():
            self._show_locus_suggestion(meta.get("locus_suggestion"))
            self._show_genome_suggestion(meta.get("genome_build_suggestion"))
        else:
            self._locus_suggestion.hide()
            self._genome_build_suggestion.hide()

    def _apply_locus_candidate(self, candidate: Mapping[str, Any], suggestion_id: str) -> None:
        label = str(candidate.get("label") or "")
        if not label:
            return
        chrom = label
        start = None
        end = None
        if ":" in label and "-" in label:
            try:
                chrom_part, coords = label.split(":", 1)
                start_str, end_str = coords.split("-", 1)
                chrom = chrom_part
                start = int(start_str.replace(",", ""))
                end = int(end_str.replace(",", ""))
            except Exception:
                pass
        spec = experiment_spec_to_dict(self._session.state.experiment_spec)
        locus = spec.get("locus") if isinstance(spec.get("locus"), dict) else {}
        locus["chr"] = chrom
        if start is not None and end is not None:
            locus["start"] = start
            locus["end"] = end
        spec["locus"] = locus
        spec["locus_source"] = SOURCE_USER_APPLIED
        spec["locus_inference_ref"] = suggestion_id or candidate.get("label")
        spec["locus_updatedAt"] = clock.utc_now_iso()
        self._updating = True
        try:
            self._locus_chr.setText(str(locus.get("chr") or ""))
            if start is not None and end is not None:
                self._locus_start.setValue(int(locus.get("start") or 0))
                self._locus_end.setValue(int(locus.get("end") or 0))
        finally:
            self._updating = False
        try:
            self._session.update(experiment_spec=experiment_spec_to_dict(spec))
            self._session.log(f"Applied inferred locus ({label}) with provenance {suggestion_id or 'unknown'}.")
        except Exception:
            QMessageBox.warning(self, "Apply failed", "Could not apply inferred locus.")

    def _apply_genome_candidate(self, candidate: Mapping[str, Any], suggestion_id: str) -> None:
        build = str(candidate.get("genomeBuild") or candidate.get("label") or "")
        if not build:
            QMessageBox.warning(self, "Apply failed", "Genome build candidate is missing a build identifier.")
            return
        spec = experiment_spec_to_dict(self._session.state.experiment_spec)
        reference = spec.get("reference") if isinstance(spec.get("reference"), dict) else {}
        reference["genomeBuild"] = build
        reference["genomeBuild_source"] = SOURCE_USER_APPLIED
        reference["genomeBuild_inference_ref"] = suggestion_id or candidate.get("label")
        reference["genomeBuild_index_id"] = candidate.get("index_id")
        reference["genomeBuild_index_checksum"] = candidate.get("index_checksum")
        reference["genomeBuild_updatedAt"] = clock.utc_now_iso()
        spec["reference"] = reference
        self._updating = True
        try:
            self._genome_build.setText(build)
        finally:
            self._updating = False
        try:
            self._session.update(experiment_spec=experiment_spec_to_dict(spec))
            self._session.log(f"Applied inferred genome build ({build}) with provenance {suggestion_id or 'unknown'}.")
        except Exception:
            QMessageBox.warning(self, "Apply failed", "Could not apply inferred genome build.")

    def _on_apply_locus_suggestion(self, link: str = "") -> None:
        suggestion = self._active_locus_suggestion
        if not (suggestions_enabled() and isinstance(suggestion, Mapping)):
            return
        if suggestion.get("input_digest") != self._current_input_digest:
            QMessageBox.information(self, "Stale suggestion", "Sequence changed; re-ingest to refresh inference.")
            return
        suggestion_id = str(suggestion.get("suggestion_id") or "")
        if link == "choose_locus" or not actionable(suggestion, self._current_input_digest):
            cand = self._choose_candidate(self._locus_candidates, "Choose locus suggestion")
            if cand:
                self._apply_locus_candidate(cand, suggestion_id)
            return
        if link == "apply_locus" and actionable(suggestion, self._current_input_digest):
            best = suggestion.get("best") if isinstance(suggestion.get("best"), Mapping) else None
            if best:
                self._apply_locus_candidate(best, suggestion_id)

    def _on_apply_genome_suggestion(self, link: str = "") -> None:
        suggestion = self._active_genome_suggestion
        if not (suggestions_enabled() and isinstance(suggestion, Mapping)):
            return
        if suggestion.get("input_digest") != self._current_input_digest:
            QMessageBox.information(self, "Stale suggestion", "Sequence changed; re-ingest to refresh inference.")
            return
        suggestion_id = str(suggestion.get("suggestion_id") or "")
        if link == "choose_genome" or not actionable(suggestion, self._current_input_digest):
            cand = self._choose_candidate(self._genome_candidates, "Choose genome build")
            if cand:
                self._apply_genome_candidate(cand, suggestion_id)
            return
        if link == "apply_genome" and actionable(suggestion, self._current_input_digest):
            best = suggestion.get("best") if isinstance(suggestion.get("best"), Mapping) else None
            if best:
                self._apply_genome_candidate(best, suggestion_id)


__all__ = ["ExperimentSpecEditor"]
