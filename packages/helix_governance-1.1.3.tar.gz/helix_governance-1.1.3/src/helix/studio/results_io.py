from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Mapping, Tuple

RESULTS_RECORD_SCHEMA_ID = "helix_results_record_v1"
RESULTS_RECORDS_CAP = 50

try:  # pragma: no cover - optional dependency
    from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

    PYDANTIC_AVAILABLE = True
except Exception:  # pragma: no cover - fallback path
    BaseModel = object  # type: ignore
    ValidationError = Exception  # type: ignore
    PYDANTIC_AVAILABLE = False


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n").encode(
        "utf-8"
    )


def sanitize_results_id(raw: str) -> str:
    token = str(raw or "").strip()
    if not token:
        return "results"
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", token)


if PYDANTIC_AVAILABLE:

    class ResultsRecordV1(BaseModel):
        model_config = ConfigDict(extra="allow", populate_by_name=True)

        schema_: str = Field(default=RESULTS_RECORD_SCHEMA_ID, alias="schema")
        results_id: str = Field(alias="resultsId")
        linked_experiment_id: str | None = Field(default=None, alias="linkedExperimentId")
        session_id: str | None = Field(default=None, alias="sessionId")
        modality: str
        conditions: dict[str, Any] = Field(default_factory=dict)
        primary_target: dict[str, Any] = Field(default_factory=dict, alias="primaryTarget")
        off_targets_observed: list[dict[str, Any]] = Field(default_factory=list, alias="offTargetsObserved")
        assay_metadata: dict[str, Any] = Field(default_factory=dict, alias="assayMetadata")
        notes: list[str] = Field(default_factory=list)

        @field_validator("modality", mode="before")
        @classmethod
        def _coerce_modality(cls, value: Any) -> Any:
            if isinstance(value, str):
                value = value.strip().lower()
            return value

        @field_validator("results_id", mode="before")
        @classmethod
        def _coerce_results_id(cls, value: Any) -> Any:
            if isinstance(value, str):
                return value.strip()
            return value

        @property
        def schema(self) -> str:
            return self.schema_


def results_record_to_dict(data: Any) -> dict[str, Any]:
    if PYDANTIC_AVAILABLE and isinstance(data, ResultsRecordV1):
        return data.model_dump(exclude_none=True, by_alias=True)
    if isinstance(data, Mapping):
        return dict(data)
    return {}


def results_record_json_bytes(data: Any) -> bytes:
    payload = results_record_to_dict(data)
    return _canonical_json_bytes(payload)


def results_record_sha256(data: Any) -> str:
    return hashlib.sha256(results_record_json_bytes(data)).hexdigest()


def _validate_required_fields(data: Mapping[str, Any]) -> Tuple[str, str]:
    schema = str(data.get("schema") or "")
    if schema != RESULTS_RECORD_SCHEMA_ID:
        raise ValueError(f"Unsupported results record schema: {schema!r}")
    results_id = str(data.get("resultsId") or "").strip()
    if not results_id:
        raise ValueError("resultsId is required")
    modality = str(data.get("modality") or "").strip().lower()
    if modality not in {"cut", "prime", "base"}:
        raise ValueError("modality must be 'cut', 'prime', or 'base'")
    return results_id, modality


def results_record_from_dict(data: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(data, Mapping):
        raise ValueError("Results record must be a JSON object")
    _validate_required_fields(data)
    if PYDANTIC_AVAILABLE:
        model = ResultsRecordV1.model_validate(data)
        return model.model_dump(exclude_none=True, by_alias=True)
    # Minimal normalization for non-pydantic usage.
    payload = dict(data)
    payload["modality"] = str(payload.get("modality") or "").strip().lower()
    return payload


def load_results_record(path: Path | str) -> dict[str, Any]:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    return results_record_from_dict(raw)


def attach_results_record(
    session: Any,
    record: Mapping[str, Any],
    *,
    cap: int = RESULTS_RECORDS_CAP,
) -> list[dict[str, Any]]:
    payload = results_record_from_dict(record)
    results_id = str(payload.get("resultsId") or "").strip()
    existing = getattr(session.state, "results_records", []) if session is not None else []
    records = list(existing) if isinstance(existing, list) else []
    records = [r for r in records if isinstance(r, Mapping) and str(r.get("resultsId") or "") != results_id]
    records.append(payload)
    if cap > 0 and len(records) > cap:
        records = records[-cap:]
    if session is not None:
        session.update(results_records=records)
    return records


__all__ = [
    "RESULTS_RECORD_SCHEMA_ID",
    "RESULTS_RECORDS_CAP",
    "ResultsRecordV1",
    "attach_results_record",
    "load_results_record",
    "results_record_from_dict",
    "results_record_json_bytes",
    "results_record_sha256",
    "results_record_to_dict",
    "sanitize_results_id",
]
