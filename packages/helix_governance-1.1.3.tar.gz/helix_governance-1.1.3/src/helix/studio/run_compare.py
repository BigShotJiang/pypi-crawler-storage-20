from __future__ import annotations

import traceback
from typing import Mapping

from PySide6.QtWidgets import QHBoxLayout, QLabel, QTextEdit, QVBoxLayout, QWidget

from .run_metrics import (
    classify_run_delta,
    compute_run_metrics,
    diff_summary_text,
    format_snapshot_text,
)
from .run_metrics import ensure_state_payload
from .workers import run_bg, CancelToken


class RunCompareWidget(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._token = CancelToken()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(6)
        header = QLabel("Select two runs in history and click Compare to see details.", self)
        layout.addWidget(header)
        self._selection_row = QHBoxLayout()
        self._selection_row.setSpacing(8)
        self._baseline_label = QLabel("Baseline: —", self)
        self._candidate_label = QLabel("Candidate: —", self)
        self._selection_row.addWidget(self._baseline_label)
        self._selection_row.addWidget(self._candidate_label)
        self._selection_row.addStretch(1)
        layout.addLayout(self._selection_row)
        self._verdict_label = QLabel("", self)
        self._verdict_label.setWordWrap(True)
        layout.addWidget(self._verdict_label)
        self._delta_strip = QLabel("", self)
        self._delta_strip.setWordWrap(True)
        layout.addWidget(self._delta_strip)

        body = QHBoxLayout()
        self._left = QTextEdit(self)
        self._left.setReadOnly(True)
        self._right = QTextEdit(self)
        self._right.setReadOnly(True)
        body.addWidget(self._left)
        body.addWidget(self._right)
        layout.addLayout(body)

        layout.addWidget(QLabel("Diff summary", self))
        self._diff = QTextEdit(self)
        self._diff.setReadOnly(True)
        layout.addWidget(self._diff)

    def set_runs(
        self,
        lhs: Mapping[str, object],
        lhs_label: str,
        _lhs_meta: object | None,
        _lhs_chip: object | None,
        rhs: Mapping[str, object],
        rhs_label: str,
        _rhs_meta: object | None,
        _rhs_chip: object | None,
    ) -> None:
        self._baseline_label.setText(f"Baseline: {lhs_label}")
        self._candidate_label.setText(f"Candidate: {rhs_label}")
        self.compare_snapshots(lhs, rhs)

    def compare_snapshots(self, lhs: Mapping[str, object], rhs: Mapping[str, object]) -> None:
        self._token.bump()
        self._verdict_label.setText("Computing…")
        self._diff.setPlainText("")
        self._left.setPlainText("")
        self._right.setPlainText("")
        self._delta_strip.setText("")

        def _work():
            lhs_metrics = compute_run_metrics(lhs)
            rhs_metrics = compute_run_metrics(rhs)
            return lhs_metrics, rhs_metrics

        def _ok(result) -> None:
            try:
                lhs_metrics, rhs_metrics = result
                try:
                    self._left.setPlainText(format_snapshot_text(lhs_metrics))
                except Exception:
                    self._left.setPlainText(str(lhs_metrics))
                try:
                    self._right.setPlainText(format_snapshot_text(rhs_metrics))
                except Exception:
                    self._right.setPlainText(str(rhs_metrics))

                verdict = classify_run_delta(lhs_metrics, rhs_metrics)
                origin_l = lhs.get("import_origin") or "native"
                origin_r = rhs.get("import_origin") or "native"
                self._verdict_label.setText(
                    f"Verdict: {verdict.label} – {verdict.details} | L:{origin_l} vs R:{origin_r}"
                )
                self._diff.setPlainText(diff_summary_text(lhs_metrics, rhs_metrics))
                try:
                    d_intended = (rhs_metrics.intended_mass - lhs_metrics.intended_mass) * 100
                    d_fs = (rhs_metrics.off_target_mass - lhs_metrics.off_target_mass) * 100
                    strip = f"Δ intended: {d_intended:+.1f}%   Δ frameshift: {d_fs:+.1f}%"

                    def _prime_perfect(snap):
                        state = ensure_state_payload(snap) or {}
                        outcomes = state.get("outcomes") or []
                        perfect = 0.0
                        for oc in outcomes:
                            try:
                                p = float(oc.get("probability", 0.0))
                            except Exception:
                                p = 0.0
                            label = str(oc.get("label", "")).lower()
                            frameshift = bool(oc.get("frameshift", False))
                            delta_bp = oc.get("delta_bp", 0)
                            if "intended" in label and not frameshift and delta_bp == 0:
                                perfect += p
                        return perfect

                    p_base = _prime_perfect(lhs)
                    p_cand = _prime_perfect(rhs)
                    if p_base or p_cand:
                        strip += f"   Δ perfect prime: {(p_cand - p_base)*100:+.1f}%"
                    self._delta_strip.setText(strip)
                except Exception:
                    self._delta_strip.setText("")
            except Exception:
                _err(traceback.format_exc())

        def _err(tb: str) -> None:
            try:
                self._verdict_label.setText("Compare failed; see logs")
                self._diff.setPlainText(tb)
            except Exception:
                pass

        run_bg(_work, _ok, _err, label="RunCompare.compare", token=self._token)
