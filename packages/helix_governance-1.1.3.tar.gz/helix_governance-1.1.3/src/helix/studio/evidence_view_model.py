from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from helix.studio.governance_stamp import interpretation_for_mode, normalize_decision_mode, ui_mode_subtext
from helix.studio.ordinal_bins import tier_for_rank


@dataclass(frozen=True, slots=True)
class DatasetRef:
    id: str
    checksum: str


@dataclass(frozen=True, slots=True)
class BackendRef:
    name: str
    version: str
    git_commit: str
    build_timestamp_utc: str


@dataclass(frozen=True, slots=True)
class ModelRef:
    model_id: str
    model_version: str
    model_hash: str


@dataclass(frozen=True, slots=True)
class ParamsRef:
    params_hash: str


@dataclass(frozen=True, slots=True)
class CalibrationBundleRef:
    id: str
    checksum: str
    created_at_utc: str
    evaluation_code_hash: str
    model_id: str
    model_version: str
    model_hash: str
    calibration_dataset: DatasetRef
    heldout_dataset: DatasetRef


@dataclass(frozen=True, slots=True)
class PriorsRef:
    id: str
    hash: str


@dataclass(frozen=True, slots=True)
class CalibrationMetrics:
    n: int | None
    grade_correlation: float | None
    rmse: float | None
    mae: float | None
    ece: float | None
    mce: float | None
    brier: float | None
    log_loss: float | None


@dataclass(frozen=True, slots=True)
class ReliabilityBin:
    bin_lo: float
    bin_hi: float
    n: int
    pred_mean: float | None
    obs_mean: float | None


@dataclass(frozen=True, slots=True)
class CalibrationSliceMetrics:
    n: int | None
    pearson_r: float | None
    rmse: float | None
    mae: float | None
    bias: float | None
    ece: float | None
    mce: float | None
    brier: float | None
    log_loss: float | None


@dataclass(frozen=True, slots=True)
class CalibrationSliceReport:
    slice_id: str
    bins: tuple[ReliabilityBin, ...]
    metrics: CalibrationSliceMetrics


@dataclass(frozen=True, slots=True)
class CalibrationBundleReport:
    bundle_id: str
    bundle_hash: str
    created_at_utc: str
    evaluation_code_hash: str
    bins_count: int | None
    slices: tuple[CalibrationSliceReport, ...]
    target: Mapping[str, Any] | None = None
    coverage: Mapping[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class EvidenceOverview:
    decision_mode_requested: str
    decision_mode: str
    interpretation: str
    validity_status: str
    uncertainty_status: str
    decision_notes: tuple[str, ...]
    backend: BackendRef
    model: ModelRef
    params: ParamsRef
    reference_genome: DatasetRef
    annotation_dataset: DatasetRef
    calibration_dataset: DatasetRef
    calibration_bundle: CalibrationBundleRef
    priors: PriorsRef


def _s(raw: Any, *, default: str = "") -> str:
    value = str(raw or "").strip()
    return value if value else default


def _mapping(raw: Any) -> Mapping[str, Any]:
    return raw if isinstance(raw, Mapping) else {}


def _dataset_ref(raw: Any, *, default_id: str = "unavailable") -> DatasetRef:
    data = _mapping(raw)
    return DatasetRef(
        id=_s(data.get("id"), default=default_id),
        checksum=_s(data.get("checksum"), default="sha256:unavailable"),
    )


def build_evidence_overview(summary: Mapping[str, Any]) -> EvidenceOverview:
    decision_mode_requested = normalize_decision_mode(summary.get("decision_mode_requested"))
    decision_mode = normalize_decision_mode(summary.get("decision_mode"))
    interpretation = interpretation_for_mode(decision_mode)

    validity = _mapping(summary.get("validity"))
    validity_status = _s(validity.get("status"), default="unknown")

    uncertainty = _mapping(summary.get("uncertainty"))
    uncertainty_status = _s(uncertainty.get("status"), default="unknown")

    verdict = _mapping(summary.get("verdict"))
    notes_raw = verdict.get("decision_notes")
    notes = tuple(_s(n) for n in notes_raw if _s(n)) if isinstance(notes_raw, list) else tuple()

    prov = _mapping(summary.get("provenance"))
    backend = _mapping(prov.get("backend"))
    model = _mapping(prov.get("model"))
    params = _mapping(prov.get("params"))
    data = _mapping(prov.get("data"))
    assumptions = _mapping(prov.get("assumptions"))
    priors = _mapping(assumptions.get("cut_repair_profile"))

    cal_bundle = _mapping(data.get("calibration_bundle"))
    cal_bundle_cal_ds = _dataset_ref(
        {"id": cal_bundle.get("calibration_dataset_id"), "checksum": cal_bundle.get("calibration_dataset_checksum")},
        default_id="unconfigured",
    )
    cal_bundle_held_ds = _dataset_ref(
        {"id": cal_bundle.get("heldout_dataset_id"), "checksum": cal_bundle.get("heldout_dataset_checksum")},
        default_id="unconfigured",
    )

    return EvidenceOverview(
        decision_mode_requested=decision_mode_requested,
        decision_mode=decision_mode,
        interpretation=interpretation,
        validity_status=validity_status,
        uncertainty_status=uncertainty_status,
        decision_notes=notes,
        backend=BackendRef(
            name=_s(backend.get("name"), default="backend"),
            version=_s(backend.get("version"), default="unavailable"),
            git_commit=_s(backend.get("git_commit"), default="unavailable"),
            build_timestamp_utc=_s(backend.get("build_timestamp_utc"), default="unavailable"),
        ),
        model=ModelRef(
            model_id=_s(model.get("model_id"), default="unconfigured"),
            model_version=_s(model.get("model_version"), default="unconfigured"),
            model_hash=_s(model.get("model_hash"), default="sha256:unavailable"),
        ),
        params=ParamsRef(params_hash=_s(params.get("params_hash"), default="sha256:unavailable")),
        reference_genome=_dataset_ref(data.get("reference_genome"), default_id="unconfigured"),
        annotation_dataset=_dataset_ref(data.get("annotation_dataset"), default_id="unconfigured"),
        calibration_dataset=_dataset_ref(data.get("calibration_dataset"), default_id="unconfigured"),
        calibration_bundle=CalibrationBundleRef(
            id=_s(cal_bundle.get("id"), default="unconfigured"),
            checksum=_s(cal_bundle.get("checksum"), default="sha256:unavailable"),
            created_at_utc=_s(cal_bundle.get("created_at_utc"), default="unavailable"),
            evaluation_code_hash=_s(cal_bundle.get("evaluation_code_hash"), default="sha256:unavailable"),
            model_id=_s(cal_bundle.get("model_id"), default="unconfigured"),
            model_version=_s(cal_bundle.get("model_version"), default="unconfigured"),
            model_hash=_s(cal_bundle.get("model_hash"), default="sha256:unavailable"),
            calibration_dataset=cal_bundle_cal_ds,
            heldout_dataset=cal_bundle_held_ds,
        ),
        priors=PriorsRef(
            id=_s(priors.get("id"), default="unavailable"),
            hash=_s(priors.get("hash"), default="sha256:unavailable"),
        ),
    )


def load_matching_calibration_metrics(overview: EvidenceOverview) -> CalibrationMetrics | None:
    """Best-effort: load evaluation metrics from HELIX_CALIBRATION_BUNDLE_{PATH,DIR}.

    This reads the same lookup path used by summary_contract_v2. If no bundle is found
    or parsing fails, returns None (UI should present "unavailable").
    """

    report = load_matching_calibration_bundle_report(overview)
    if report is None:
        return None
    overall = next((s for s in report.slices if s.slice_id == "overall"), None)
    if overall is None:
        return None
    # Maintain the existing "heldout_summary" semantics: use the slice's metrics
    # as the best available proxy for the heldout summary block.
    return CalibrationMetrics(
        n=overall.metrics.n,
        grade_correlation=overall.metrics.pearson_r,
        rmse=overall.metrics.rmse,
        mae=overall.metrics.mae,
        ece=overall.metrics.ece,
        mce=overall.metrics.mce,
        brier=overall.metrics.brier,
        log_loss=overall.metrics.log_loss,
    )


def load_matching_calibration_bundle_report(overview: EvidenceOverview) -> CalibrationBundleReport | None:
    """Load the matching calibration bundle (if any) and parse slice metrics + reliability curves."""

    try:
        from helix.calibration.bundle import find_calibration_bundle
    except Exception:
        return None

    requested_ds = overview.calibration_dataset.id
    calibration_dataset_id = None if requested_ds in {"", "unconfigured", "unavailable"} else requested_ds

    try:
        bundle = find_calibration_bundle(
            model_id=overview.model.model_id,
            model_version=overview.model.model_version,
            model_hash=overview.model.model_hash if overview.model.model_hash.startswith("sha256:") else None,
            calibration_dataset_id=calibration_dataset_id,
        )
    except Exception:
        return None

    if not isinstance(bundle, Mapping):
        return None

    prov = bundle.get("provenance") if isinstance(bundle.get("provenance"), Mapping) else {}
    eval_code_hash = _s(prov.get("evaluation_code_hash"), default="sha256:unavailable")

    eval_block = bundle.get("evaluation") if isinstance(bundle.get("evaluation"), Mapping) else {}
    bins_block = eval_block.get("bins") if isinstance(eval_block.get("bins"), Mapping) else {}
    bins_count = None
    try:
        bins_count = int(bins_block.get("count")) if bins_block.get("count") is not None else None
    except Exception:
        bins_count = None

    curves = eval_block.get("curves") if isinstance(eval_block.get("curves"), Mapping) else {}
    metrics = eval_block.get("metrics") if isinstance(eval_block.get("metrics"), Mapping) else {}

    def _float_or_none(x: Any) -> float | None:
        try:
            v = float(x)
        except Exception:
            return None
        return v if v == v else None

    def _int_or_none(x: Any) -> int | None:
        try:
            return int(x)
        except Exception:
            return None

    slice_ids = sorted({str(k) for k in list(curves.keys()) + list(metrics.keys()) if str(k).strip()})
    if "overall" in slice_ids:
        slice_ids = ["overall"] + [s for s in slice_ids if s != "overall"]

    slices: list[CalibrationSliceReport] = []
    for sid in slice_ids:
        curve_raw = curves.get(sid)
        bins: list[ReliabilityBin] = []
        if isinstance(curve_raw, list):
            for item in curve_raw:
                if not isinstance(item, Mapping):
                    continue
                try:
                    bins.append(
                        ReliabilityBin(
                            bin_lo=float(item.get("bin_lo") or 0.0),
                            bin_hi=float(item.get("bin_hi") or 0.0),
                            n=int(item.get("n") or 0),
                            pred_mean=_float_or_none(item.get("pred_mean")),
                            obs_mean=_float_or_none(item.get("obs_mean")),
                        )
                    )
                except Exception:
                    continue

        m_raw = metrics.get(sid) if isinstance(metrics.get(sid), Mapping) else {}
        m = CalibrationSliceMetrics(
            n=_int_or_none(m_raw.get("n")),
            pearson_r=_float_or_none(m_raw.get("pearson_r")),
            rmse=_float_or_none(m_raw.get("rmse")),
            mae=_float_or_none(m_raw.get("mae")),
            bias=_float_or_none(m_raw.get("bias")),
            ece=_float_or_none(m_raw.get("ece")),
            mce=_float_or_none(m_raw.get("mce")),
            brier=_float_or_none(m_raw.get("brier")),
            log_loss=_float_or_none(m_raw.get("log_loss")),
        )
        slices.append(CalibrationSliceReport(slice_id=sid, bins=tuple(bins), metrics=m))

    coverage = bundle.get("coverage") if isinstance(bundle.get("coverage"), Mapping) else None
    target = bundle.get("target") if isinstance(bundle.get("target"), Mapping) else None

    return CalibrationBundleReport(
        bundle_id=_s(bundle.get("bundle_id"), default="calibration_bundle"),
        bundle_hash=_s(bundle.get("bundle_hash"), default="sha256:unavailable"),
        created_at_utc=_s(bundle.get("created_at_utc"), default="unavailable"),
        evaluation_code_hash=eval_code_hash,
        bins_count=bins_count,
        slices=tuple(slices),
        target=target,
        coverage=coverage,
    )


def tier_mapping_ranges(*, max_rank: int = 64) -> list[tuple[int, int, str]]:
    """Return contiguous rank ranges mapped to an ordinal tier label.

    Uses `tier_for_rank` as the source of truth so help text stays in sync.
    """

    m = max(1, int(max_rank))
    spans: list[tuple[int, int, str]] = []
    start = 1
    prev_label = tier_for_rank(1).label
    for rank in range(2, m + 1):
        label = tier_for_rank(rank).label
        if label != prev_label:
            spans.append((start, rank - 1, prev_label))
            start = rank
            prev_label = label
    spans.append((start, m, prev_label))
    return spans


def tier_help_text(*, max_rank: int = 64) -> str:
    spans = tier_mapping_ranges(max_rank=max_rank)
    lines = [
        "Tiers are ordinal-only (rank buckets). They do not imply calibrated probabilities.",
        "Rank is computed from the within-run outcome ordering used by the UI when quantitative outputs are suppressed.",
        "Tiers are not comparable across runs or calibration bundles.",
        "",
        "Rank → Tier mapping:",
    ]
    for lo, hi, label in spans:
        if lo == hi:
            lines.append(f"- rank {lo}: {label}")
        else:
            lines.append(f"- ranks {lo}–{hi}: {label}")
    return "\n".join(lines).strip() + "\n"


def mode_help_text(*, decision_mode: str) -> str:
    mode = normalize_decision_mode(decision_mode)
    sub = ui_mode_subtext(decision_mode=mode)
    if mode == "decision_grade":
        return "DECISION-GRADE: calibrated + uncertainty computed; probabilities are permitted.\n"
    if sub:
        return f"UNCALIBRATED: {sub}\n"
    return "UNCALIBRATED: exploratory mode; quantitative outputs are suppressed.\n"


def format_evidence_overview(
    overview: EvidenceOverview,
    *,
    calibration_metrics: CalibrationMetrics | None = None,
) -> str:
    lines: list[str] = []
    lines.append(f"Decision mode: {overview.decision_mode.upper()} (requested: {overview.decision_mode_requested.upper()})")
    lines.append(f"Interpretation: {overview.interpretation}")
    lines.append(f"Validity: {overview.validity_status}")
    lines.append(f"Uncertainty: {overview.uncertainty_status}")
    lines.append("")
    lines.append("Backend")
    lines.append(f"- {overview.backend.name} {overview.backend.version} · {overview.backend.git_commit} · {overview.backend.build_timestamp_utc}")
    lines.append("")
    lines.append("Model")
    lines.append(f"- model_id: {overview.model.model_id}")
    lines.append(f"- model_version: {overview.model.model_version}")
    lines.append(f"- model_hash: {overview.model.model_hash}")
    lines.append(f"- params_hash: {overview.params.params_hash}")
    lines.append(f"- priors: {overview.priors.id} ({overview.priors.hash})")
    lines.append("")
    lines.append("Data")
    lines.append(f"- reference_genome: {overview.reference_genome.id} ({overview.reference_genome.checksum})")
    lines.append(f"- annotation_dataset: {overview.annotation_dataset.id} ({overview.annotation_dataset.checksum})")
    lines.append(f"- calibration_dataset: {overview.calibration_dataset.id} ({overview.calibration_dataset.checksum})")
    lines.append("")
    lines.append("Calibration bundle")
    lines.append(f"- id: {overview.calibration_bundle.id}")
    lines.append(f"- checksum: {overview.calibration_bundle.checksum}")
    lines.append(f"- created_at_utc: {overview.calibration_bundle.created_at_utc}")
    lines.append(f"- evaluation_code_hash: {overview.calibration_bundle.evaluation_code_hash}")
    lines.append(f"- model_id: {overview.calibration_bundle.model_id}")
    lines.append(f"- model_version: {overview.calibration_bundle.model_version}")
    lines.append(f"- model_hash: {overview.calibration_bundle.model_hash}")
    lines.append(
        f"- calibration_dataset: {overview.calibration_bundle.calibration_dataset.id} ({overview.calibration_bundle.calibration_dataset.checksum})"
    )
    lines.append(
        f"- heldout_dataset: {overview.calibration_bundle.heldout_dataset.id} ({overview.calibration_bundle.heldout_dataset.checksum})"
    )
    if calibration_metrics is not None:
        lines.append("")
        lines.append("Calibration metrics (heldout)")
        n = "unavailable" if calibration_metrics.n is None else str(calibration_metrics.n)
        lines.append(f"- n: {n}")
        lines.append(f"- grade_correlation: {calibration_metrics.grade_correlation if calibration_metrics.grade_correlation is not None else 'unavailable'}")
        lines.append(f"- rmse: {calibration_metrics.rmse if calibration_metrics.rmse is not None else 'unavailable'}")
        lines.append(f"- mae: {calibration_metrics.mae if calibration_metrics.mae is not None else 'unavailable'}")
        lines.append(f"- ece: {calibration_metrics.ece if calibration_metrics.ece is not None else 'unavailable'}")
        lines.append(f"- mce: {calibration_metrics.mce if calibration_metrics.mce is not None else 'unavailable'}")
        lines.append(f"- brier: {calibration_metrics.brier if calibration_metrics.brier is not None else 'unavailable'}")
        lines.append(f"- log_loss: {calibration_metrics.log_loss if calibration_metrics.log_loss is not None else 'unavailable'}")
    if overview.decision_notes:
        lines.append("")
        lines.append("Decision notes")
        for note in overview.decision_notes:
            lines.append(f"- {note}")
    return "\n".join(lines).strip() + "\n"


__all__ = [
    "BackendRef",
    "CalibrationBundleRef",
    "CalibrationMetrics",
    "CalibrationBundleReport",
    "CalibrationSliceMetrics",
    "CalibrationSliceReport",
    "DatasetRef",
    "EvidenceOverview",
    "ModelRef",
    "ParamsRef",
    "PriorsRef",
    "ReliabilityBin",
    "build_evidence_overview",
    "format_evidence_overview",
    "load_matching_calibration_bundle_report",
    "load_matching_calibration_metrics",
    "mode_help_text",
    "tier_help_text",
    "tier_mapping_ranges",
]
