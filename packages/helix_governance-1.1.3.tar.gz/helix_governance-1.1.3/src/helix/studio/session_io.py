from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import os

from helix.scientific_contract import current_contract_identity, _warn_env_fallback
from .cli_session_contract_stamp import CLI_SESSION_CONTRACT_HASH, CLI_SESSION_CONTRACT_ID
from .session import SessionModel
from .models import RunModel


def _ensure_contract_identity(payload: dict[str, Any]) -> dict[str, Any]:
    header = payload.setdefault("header", {})
    if not isinstance(header, dict):
        header = {}
        payload["header"] = header

    identity = current_contract_identity()
    missing_keys: list[str] = []

    def _env(name: str) -> str | None:
        val = os.getenv(name)
        return val.strip() if val else None

    if os.getenv("HELIX_DISALLOW_CONTRACT_ENV_FALLBACK") != "1":
        seed_needed = False
        if not identity.get("policy_hash") and not _env("HELIX_POLICY_HASH"):
            seed_needed = True
        if not identity.get("semantic_hash") and not _env("HELIX_SEMANTIC_HASH"):
            seed_needed = True
        if not identity.get("determinism_class") and not _env("HELIX_DETERMINISM_CLASS"):
            seed_needed = True
        if seed_needed:
            try:
                from helix.scientific_contract import load_model_semantics, load_policy

                load_policy()
                load_model_semantics()
                identity = current_contract_identity()
            except Exception:
                identity = current_contract_identity()

    def _fill(key: str, identity_key: str, env_var: str) -> None:
        if header.get(key):
            return
        val = identity.get(identity_key)
        if val:
            header[key] = val
            return
        env_val = _env(env_var)
        if env_val:
            header[key] = env_val
            missing_keys.append(key)
            return
        missing_keys.append(key)

    _fill("policyHash", "policy_hash", "HELIX_POLICY_HASH")
    _fill("semanticHash", "semantic_hash", "HELIX_SEMANTIC_HASH")
    _fill("determinismClass", "determinism_class", "HELIX_DETERMINISM_CLASS")

    header.setdefault("contractId", CLI_SESSION_CONTRACT_ID)
    header.setdefault("contractHash", CLI_SESSION_CONTRACT_HASH)

    if missing_keys:
        if os.getenv("HELIX_DISALLOW_CONTRACT_ENV_FALLBACK") == "1":
            raise RuntimeError(
                f"Contract identity missing and env fallback disallowed; missing keys={sorted(missing_keys)}"
            )
        _warn_env_fallback(missing_keys)
        prov = payload.setdefault("provenance", [])
        if isinstance(prov, list):
            prov.append(
                {
                    "source": "contract",
                    "op": "env_fallback",
                    "reason": "missing current_contract_identity",
                    "keys": sorted(missing_keys),
                }
            )
    return payload


def save_session(path: str | Path, session: SessionModel) -> Path:
    """Serialize the current SessionModel snapshot to a .helix JSON file."""
    out = Path(path)
    payload = session.to_payload(timestamp=True)
    payload = _ensure_contract_identity(payload)
    out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf8")
    return out


def load_session(path: str | Path) -> SessionModel:
    """Load a SessionModel snapshot from a .helix JSON file."""
    p = Path(path)
    raw = json.loads(p.read_text(encoding="utf8"))
    if isinstance(raw, dict):
        raw = _ensure_contract_identity(raw)
    sess = SessionModel()
    runs_raw = raw.get("runs") if isinstance(raw, dict) else None
    if isinstance(runs_raw, list):
        sess.runs = []
        for r in runs_raw:
            try:
                sess.runs.append(RunModel.from_dict(r))
            except Exception:
                continue
    sess.load_payload(raw)
    return sess
