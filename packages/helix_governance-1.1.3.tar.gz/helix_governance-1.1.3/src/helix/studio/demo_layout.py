from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from .ui_tokens import base_font


def seed_canonical_demo_state(window, ctx) -> None:
    """Put Helix Studio into a deterministic, screenshot-friendly state.

    Assumptions:
      - ``window`` is a HelixStudioMainWindow
      - ``ctx`` is a StudioContext already bound to the window/session
    """

    try:
        window.reset_layout_to_defaults()
    except Exception:
        pass

    try:
        window.setFont(base_font())
    except Exception:
        pass

    # Load demo content if available
    try:
        if hasattr(window, "_on_open_demo_session"):
            window._on_open_demo_session()
    except Exception:
        pass

    app = QApplication.instance()
    if app is not None:
        app.processEvents()

    # Left: select Runs tab if present
    left_tabs = getattr(window, "left_tabs", lambda: None)()
    if left_tabs is not None:
        for idx in range(left_tabs.count()):
            label = left_tabs.tabText(idx).lower()
            if "run" in label:
                left_tabs.setCurrentIndex(idx)
                break

    # Center: prefer the 2.5D / workflow tab for richer visuals
    center_tabs = getattr(window, "center_tabs", lambda: None)()
    if center_tabs is not None:
        target_idx = None
        for idx in range(center_tabs.count()):
            label = center_tabs.tabText(idx).lower()
            if "workflow" in label or "2.5d" in label:
                target_idx = idx
                break
        if target_idx is None and center_tabs.count() > 0:
            target_idx = 0
        if target_idx is not None:
            center_tabs.setCurrentIndex(target_idx)

    # Right: pick Guides tab if available, else Session
    right_tabs = getattr(window, "right_tabs", lambda: None)()
    if right_tabs is not None:
        target_idx = None
        for idx in range(right_tabs.count()):
            label = right_tabs.tabText(idx).lower()
            if "guide" in label:
                target_idx = idx
                break
        if target_idx is None:
            for idx in range(right_tabs.count()):
                if "session" in right_tabs.tabText(idx).lower():
                    target_idx = idx
                    break
        if target_idx is not None:
            right_tabs.setCurrentIndex(target_idx)

    # Keep log visible but compact (~20-25% height)
    console_dock = getattr(window, "console_dock", getattr(window, "log_dock", lambda: None))()
    if console_dock is not None:
        console_dock.show()
        try:
            window.resizeDocks([console_dock], [int(window.height() * 0.22)], Qt.Vertical)
        except Exception:
            pass

    try:
        window._apply_default_splitter_sizes()
    except Exception:
        pass

    if app is not None:
        app.processEvents()
