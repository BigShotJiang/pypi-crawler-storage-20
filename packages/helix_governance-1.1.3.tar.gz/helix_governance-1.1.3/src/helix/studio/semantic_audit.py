from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from helix.edit.dag import EditDAG
from helix.studio.semantic_schema import MassAudit, Provenance, ScalarValue, Unit


@dataclass(frozen=True)
class SuppressedNode:
    node_id: str
    prob: float
    parents: tuple[str, ...]


def _prob_scalar(value: float, provenance: Provenance) -> ScalarValue:
    return ScalarValue(value=float(value), unit=Unit.PROBABILITY, provenance=provenance)


def audit_mass_conservation(
    dag: EditDAG,
    node_prob_raw: Mapping[str, float],
    suppressed: Sequence[SuppressedNode],
    *,
    epsilon: float = 1e-3,
    provenance: Provenance | None = None,
) -> dict[str, MassAudit]:
    prov = provenance or Provenance(
        source="unknown",
        method="unknown",
        version="unknown",
        timestamp="unknown",
        assumptions=["no provenance"],
    )
    children: dict[str, list[str]] = {}
    for edge in dag.edges:
        children.setdefault(edge.source, []).append(edge.target)

    suppressed_by_parent: dict[str, float] = {}
    suppressed_set = {s.node_id for s in suppressed}
    for entry in suppressed:
        for parent in entry.parents:
            suppressed_by_parent[parent] = suppressed_by_parent.get(parent, 0.0) + float(entry.prob)

    audits: dict[str, MassAudit] = {}
    for node_id in dag.nodes:
        parent_mass = float(node_prob_raw.get(node_id, 0.0))
        node_children = children.get(node_id, [])
        if parent_mass <= 0.0:
            audits[node_id] = MassAudit(
                mass_out_total=_prob_scalar(0.0, prov),
                mass_suppressed=_prob_scalar(0.0, prov),
                mass_unaccounted=_prob_scalar(0.0, prov),
                epsilon=float(epsilon),
                violated=True,
            )
            continue
        if not node_children:
            audits[node_id] = MassAudit(
                mass_out_total=_prob_scalar(1.0, prov),
                mass_suppressed=_prob_scalar(0.0, prov),
                mass_unaccounted=_prob_scalar(0.0, prov),
                epsilon=float(epsilon),
                violated=False,
            )
            continue
        visible_mass = sum(float(node_prob_raw.get(child, 0.0)) for child in node_children if child not in suppressed_set)
        suppressed_mass = float(suppressed_by_parent.get(node_id, 0.0))
        mass_out_total = (visible_mass + suppressed_mass) / parent_mass
        mass_unaccounted = max(0.0, 1.0 - mass_out_total)
        violated = abs(1.0 - mass_out_total) > float(epsilon)
        audits[node_id] = MassAudit(
            mass_out_total=_prob_scalar(mass_out_total, prov),
            mass_suppressed=_prob_scalar(suppressed_mass / parent_mass, prov),
            mass_unaccounted=_prob_scalar(mass_unaccounted, prov),
            epsilon=float(epsilon),
            violated=bool(violated),
        )
    return audits


def max_mass_violation(audits: Mapping[str, MassAudit]) -> float:
    worst = 0.0
    for audit in audits.values():
        try:
            total = float(audit.mass_out_total.value)
        except Exception:
            total = 0.0
        worst = max(worst, abs(1.0 - total))
    return worst


__all__ = ["SuppressedNode", "audit_mass_conservation", "max_mass_violation"]
