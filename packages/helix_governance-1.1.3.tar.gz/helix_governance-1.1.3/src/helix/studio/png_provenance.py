from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Mapping

from helix import __version__ as helix_version
from helix import clock
from helix.studio.governance_stamp import interpretation_for_mode, normalize_decision_mode
from helix.studio.cli_session_contract_stamp import CLI_SESSION_CONTRACT_HASH, CLI_SESSION_CONTRACT_ID

PNG_PROVENANCE_SCHEMA_V1 = "helix_png_provenance_v1"


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


def _sha256_prefixed(data: bytes) -> str:
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


def _is_sha256_prefixed(value: object) -> bool:
    if not isinstance(value, str):
        return False
    token = value.strip()
    if not token:
        return False
    if token.startswith("sha256:"):
        token = token[len("sha256:") :]
    if len(token) != 64:
        return False
    return all(ch in "0123456789abcdef" for ch in token.lower())


def build_png_provenance_v1(
    *,
    png_path: str | Path,
    png_bytes: bytes | None = None,
    artifact_surface: str,
    run_id: str | int | None,
    governance: Mapping[str, Any] | None = None,
    limitations_stamp: Mapping[str, Any] | None = None,
    decision_support_requested: bool | None = None,
    denial_reason_code: str | None = None,
    supported_context_id: str | None = None,
    supported_context_hash: str | None = None,
    model_hash: str | None = None,
    params_bundle_hash: str | None = None,
    dataset_version_hash: str | None = None,
    baseline_id: str | None = None,
    baseline_hash: str | None = None,
    embedded_png_text_chunks_present: bool = True,
    embedded_chunks_sha256: str | None = None,
) -> dict[str, Any]:
    path = Path(png_path)
    raw = bytes(png_bytes) if png_bytes is not None else path.read_bytes()
    stamp = dict(limitations_stamp) if isinstance(limitations_stamp, Mapping) else {}
    gov = dict(governance) if isinstance(governance, Mapping) else {}

    timestamp_utc = str(stamp.get("timestamp_utc") or "").strip() or _utc_now_iso()

    decision_mode = normalize_decision_mode(gov.get("decision_mode"))
    interpretation = str(gov.get("interpretation") or "").strip() or interpretation_for_mode(decision_mode)
    is_demo = bool(gov.get("is_demo", False))
    decision_support_enabled = bool(decision_mode == "decision_grade")
    if decision_support_enabled:
        export_class = "decision_support"
    else:
        export_class = "demo" if is_demo else "exploratory"

    if decision_support_requested is None:
        decision_support_requested = bool(decision_support_enabled)
    if denial_reason_code is None and decision_support_requested and not decision_support_enabled:
        denial_reason_code = "DENY_DECISION_SUPPORT_DISABLED"

    payload: dict[str, Any] = {
        "schema_version": PNG_PROVENANCE_SCHEMA_V1,
        "artifact_type": "image_export",
        "artifact_surface": str(artifact_surface),
        "artifact_filename": path.name,
        "artifact_sha256": _sha256_prefixed(raw),
        "run_id": (str(run_id) if run_id is not None and str(run_id).strip() else None),
        "timestamp_utc": timestamp_utc,
        "contract_id": CLI_SESSION_CONTRACT_ID,
        "contract_hash": CLI_SESSION_CONTRACT_HASH,
        "governance": {
            "export_class": export_class,
            "decision_support_enabled": bool(decision_support_enabled),
            "decision_support_requested": bool(decision_support_requested),
            "governance_decision_mode": decision_mode,
            "governance_interpretation": interpretation,
            "denial_reason_code": (str(denial_reason_code) if denial_reason_code is not None else None),
        },
        "context": {
            "supported_context_id": (str(supported_context_id) if supported_context_id else None),
            "supported_context_hash": (str(supported_context_hash) if supported_context_hash else None),
        },
        "versions": {
            "app_version": str(helix_version),
            "model_hash": (str(model_hash) if model_hash else None),
            "params_bundle_hash": (str(params_bundle_hash) if params_bundle_hash else None),
            "dataset_version_hash": (str(dataset_version_hash) if dataset_version_hash else None),
            "baseline_id": (str(baseline_id) if baseline_id else None),
            "baseline_hash": (str(baseline_hash) if baseline_hash else None),
        },
        "linkage": {
            "embedded_png_text_chunks_present": bool(embedded_png_text_chunks_present),
            "embedded_chunks_sha256": (str(embedded_chunks_sha256) if embedded_chunks_sha256 else None),
        },
    }
    if stamp:
        payload["limitations_stamp"] = stamp
    if gov:
        payload["governance_payload"] = gov
    return payload


def png_provenance_c14n_bytes(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(dict(payload), sort_keys=True, separators=(",", ":")).encode("utf-8")


def png_provenance_sha256(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(png_provenance_c14n_bytes(payload)).hexdigest()


def validate_png_provenance_v1(payload: Mapping[str, Any]) -> None:
    if not isinstance(payload, Mapping):
        raise ValueError("png provenance must be a mapping")
    schema = payload.get("schema_version")
    if schema != PNG_PROVENANCE_SCHEMA_V1:
        raise ValueError(f"unexpected schema_version: {schema!r}")

    surface = payload.get("artifact_surface")
    if not isinstance(surface, str) or not surface.strip():
        raise ValueError("artifact_surface must be a non-empty string")
    fname = payload.get("artifact_filename")
    if not isinstance(fname, str) or not fname.strip():
        raise ValueError("artifact_filename must be a non-empty string")
    sha = payload.get("artifact_sha256")
    if not _is_sha256_prefixed(sha):
        raise ValueError("artifact_sha256 must be sha256:<64 hex>")
    ts = payload.get("timestamp_utc")
    if not isinstance(ts, str) or not ts.strip():
        raise ValueError("timestamp_utc must be a non-empty string")

    gov = payload.get("governance")
    if not isinstance(gov, Mapping):
        raise ValueError("governance must be an object")
    export_class = gov.get("export_class")
    if not isinstance(export_class, str) or not export_class.strip():
        raise ValueError("governance.export_class must be a non-empty string")
    if "decision_support_enabled" not in gov or not isinstance(gov.get("decision_support_enabled"), bool):
        raise ValueError("governance.decision_support_enabled must be a bool")
    if "decision_support_requested" not in gov or not isinstance(gov.get("decision_support_requested"), bool):
        raise ValueError("governance.decision_support_requested must be a bool")
    mode = gov.get("governance_decision_mode")
    if not isinstance(mode, str) or not mode.strip():
        raise ValueError("governance.governance_decision_mode must be a non-empty string")
    interp = gov.get("governance_interpretation")
    if not isinstance(interp, str) or not interp.strip():
        raise ValueError("governance.governance_interpretation must be a non-empty string")
    denial = gov.get("denial_reason_code")
    if denial is not None and (not isinstance(denial, str) or not denial.strip()):
        raise ValueError("governance.denial_reason_code must be a string or null")

    linkage = payload.get("linkage")
    if linkage is not None:
        if not isinstance(linkage, Mapping):
            raise ValueError("linkage must be an object")
        present = linkage.get("embedded_png_text_chunks_present")
        if not isinstance(present, bool):
            raise ValueError("linkage.embedded_png_text_chunks_present must be a bool")
        chunk_sha = linkage.get("embedded_chunks_sha256")
        if chunk_sha is not None and not _is_sha256_prefixed(chunk_sha):
            raise ValueError("linkage.embedded_chunks_sha256 must be sha256:<64 hex> or null")


def png_provenance_sidecar_path(png_path: str | Path) -> Path:
    p = Path(png_path)
    return p.with_name(p.name + ".provenance.json")


def write_png_provenance_sidecar(png_path: str | Path, payload: Mapping[str, Any]) -> Path:
    sidecar = png_provenance_sidecar_path(png_path)
    sidecar.write_text(json.dumps(dict(payload), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return sidecar


__all__ = [
    "PNG_PROVENANCE_SCHEMA_V1",
    "build_png_provenance_v1",
    "png_provenance_c14n_bytes",
    "png_provenance_sha256",
    "png_provenance_sidecar_path",
    "validate_png_provenance_v1",
    "write_png_provenance_sidecar",
]
