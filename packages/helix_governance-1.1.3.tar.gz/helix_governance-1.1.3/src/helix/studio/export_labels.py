from __future__ import annotations

from typing import Any, Mapping

from helix.studio.export_gate import ExportDecisionContext
from helix.studio.governance_stamp import export_watermark_label, interpretation_for_mode, normalize_decision_mode


def is_demo_from_metadata(meta: Mapping[str, Any] | None) -> bool:
    """
    Heuristic used across export surfaces to decide whether a run should be treated as demo.

    This must stay intentionally conservative: returning True only when the signal is explicit.
    """
    if not isinstance(meta, Mapping):
        return False
    scenario = str(meta.get("scenario") or "").strip().lower()
    if scenario == "demo":
        return True
    preset_id = str(meta.get("preset_id") or meta.get("presetId") or "").strip().lower()
    if preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"):
        return True
    return False


def is_demo_from_preset(preset: Mapping[str, Any] | None) -> bool:
    if not isinstance(preset, Mapping):
        return False
    preset_id = str(preset.get("id") or preset.get("preset_id") or preset.get("presetId") or "").strip().lower()
    if preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"):
        return True
    scenario = str(preset.get("scenario") or "").strip().lower()
    return bool(scenario == "demo")


def build_export_label(ctx: ExportDecisionContext) -> str:
    """
    Canonical, user-facing label for exports (watermarks, banners, etc.).

    Keep this stable and screenshot-safe: downstream humans and machines will search for it.
    """
    return export_watermark_label(decision_mode=ctx.decision_mode, is_demo=ctx.is_demo)


def build_governance_provenance(
    *,
    decision_mode: Any,
    is_demo: bool,
    interpretation: str | None = None,
    decision_grade_proof: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Canonical machine-readable governance payload embedded in exported artifacts.
    """
    mode = normalize_decision_mode(decision_mode)
    interp = interpretation_for_mode(mode) if interpretation is None else str(interpretation)
    return {
        "decision_mode": mode,
        "interpretation": interp,
        "decision_grade_proof": (dict(decision_grade_proof) if isinstance(decision_grade_proof, Mapping) else None),
        "is_demo": bool(is_demo),
        "watermark": export_watermark_label(decision_mode=mode, is_demo=is_demo),
    }


__all__ = [
    "is_demo_from_metadata",
    "is_demo_from_preset",
    "build_export_label",
    "build_governance_provenance",
]

