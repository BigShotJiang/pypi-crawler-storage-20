from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Mapping

from PySide6.QtCore import Qt, Signal, QTimer, QDateTime
from PySide6.QtWidgets import QTabWidget, QTextEdit
from helix.studio.qtconcurrent_compat import QFutureWatcher
from PySide6.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QPlainTextEdit,
    QVBoxLayout,
    QWidget,
)

from helix.studio.session import SessionModel, ExperimentState
from helix.studio.ui_tokens import monospace_font


_DIAG_EXECUTOR = None


class HelixSpecEditor(QWidget):
    """Lightweight HelixSpec buffer editor backed by SessionModel."""

    runRequested = Signal()
    openBundleRequested = Signal()

    def __init__(self, session: SessionModel, project_root: Path | None = None, parent=None) -> None:
        super().__init__(parent)
        self.session = session
        self._project_root = project_root
        self._applying = False
        self._current_path: str | None = session.state.helixspec_path
        self._diag_future = None
        self._diag_watcher = None
        self._last_run_text: str | None = None
        self._last_run_time: QDateTime | None = None
        self._last_wetlab_preflight: dict[str, Any] | None = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        controls = QHBoxLayout()
        controls.setContentsMargins(0, 0, 0, 0)
        controls.setSpacing(8)

        open_btn = QPushButton("Open .hxspec…", self)
        open_btn.clicked.connect(self._open_spec)
        self._save_btn = QPushButton("Save", self)
        self._save_btn.clicked.connect(lambda: self._save_spec(force_dialog=False))
        self._save_as_btn = QPushButton("Save As…", self)
        self._save_as_btn.clicked.connect(lambda: self._save_spec(force_dialog=True))
        self._run_btn = QPushButton("Run", self)
        self._run_btn.setObjectName("PrimaryButton")
        self._run_btn.clicked.connect(lambda: self.runRequested.emit())
        self._open_bundle_btn = QPushButton("Open Last Run", self)
        self._open_bundle_btn.setEnabled(False)
        self._open_bundle_btn.clicked.connect(lambda: self.openBundleRequested.emit())

        self._path_label = QLabel(self)
        self._path_label.setObjectName("HelixSpecPathLabel")
        self._path_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        try:
            self._path_label.setElideMode(Qt.ElideMiddle)
        except Exception:
            pass

        controls.addWidget(open_btn)
        controls.addWidget(self._save_btn)
        controls.addWidget(self._save_as_btn)
        controls.addWidget(self._run_btn)
        controls.addWidget(self._open_bundle_btn)
        controls.addStretch(1)
        controls.addWidget(self._path_label, 0, Qt.AlignRight)

        self._editor = QPlainTextEdit(self)
        self._editor.setLineWrapMode(QPlainTextEdit.NoWrap)
        self._editor.setFont(monospace_font())
        self._editor.textChanged.connect(self._on_text_changed)
        self._editor.setPlaceholderText(
            "version 1\n"
            "genome hg38\n"
            "locus DEMO = chr1:1-60(+)\n"
            "cut edit demo_cut {\n"
            '  nuclease Cas9 { pam: \"NGG\" }\n'
            '  guide g1 = \"GGGCCAGGAGCCTGAAGTCT\"\n'
            "  target t1 using g1 at DEMO\n"
            "}\n"
        )

        # Pipeline status + last run
        status_row = QHBoxLayout()
        status_row.setContentsMargins(0, 0, 0, 0)
        status_row.setSpacing(8)
        self._pipeline_label = QLabel("Run: idle", self)
        self._pipeline_label.setStyleSheet("color: palette(mid);")
        self._last_run_label = QLabel("Last run: —", self)
        self._last_run_label.setStyleSheet("color: palette(mid);")
        status_row.addWidget(self._pipeline_label)
        status_row.addStretch(1)
        status_row.addWidget(self._last_run_label)

        layout.addLayout(controls)
        layout.addLayout(status_row)
        layout.addWidget(self._editor, 1)

        # Tabs for diagnostics / IR / Plan / Diff
        self._tabs = QTabWidget(self)
        try:
            self._tabs.tabBar().setMovable(True)
        except Exception:
            pass

        # Diagnostics tab
        self._diag_label = QLabel("", self)
        self._diag_label.setStyleSheet("color: palette(mid);")
        diag_container = QWidget(self)
        diag_layout = QVBoxLayout(diag_container)
        diag_layout.setContentsMargins(8, 8, 8, 8)
        diag_layout.setSpacing(6)
        diag_layout.addWidget(self._diag_label)
        self._quickfix_container = QWidget(diag_container)
        self._quickfix_layout = QVBoxLayout(self._quickfix_container)
        self._quickfix_layout.setContentsMargins(0, 0, 0, 0)
        self._quickfix_layout.setSpacing(4)
        self._quickfix_container.setVisible(False)
        diag_layout.addWidget(self._quickfix_container)
        self._diagnostics_text = QTextEdit(self)
        self._diagnostics_text.setReadOnly(True)
        self._diagnostics_text.setPlaceholderText("Diagnostics will appear here after analysis")
        diag_layout.addWidget(self._diagnostics_text)
        self._tabs.addTab(diag_container, "Diagnostics")

        # IR tab
        self._ir_preview = QPlainTextEdit(self)
        self._ir_preview.setLineWrapMode(QPlainTextEdit.NoWrap)
        self._ir_preview.setFont(monospace_font())
        self._ir_preview.setReadOnly(True)
        self._ir_preview.setPlaceholderText("IR preview will appear here after successful compile")
        self._tabs.addTab(self._ir_preview, "IR")

        # Plan summary tab
        self._plan_summary = QTextEdit(self)
        self._plan_summary.setReadOnly(True)
        self._plan_summary.setPlaceholderText("Plan summary will appear after diagnostics")
        self._tabs.addTab(self._plan_summary, "Plan summary")

        # Diff tab
        self._diff_view = QTextEdit(self)
        self._diff_view.setReadOnly(True)
        self._diff_view.setPlaceholderText("Diff against last run will appear here after a successful run")
        self._tabs.addTab(self._diff_view, "Diff")

        layout.addWidget(self._tabs, 1)

        # Debounced diagnostics
        self._diag_timer = QTimer(self)
        self._diag_timer.setSingleShot(True)
        self._diag_timer.setInterval(400)
        self._diag_timer.timeout.connect(self._run_diagnostics)

        # Seed from session state.
        self._apply_from_state(session.state)
        try:
            self.session.stateChanged.connect(self._apply_from_state)
        except Exception:
            pass
        self._update_run_enabled()
        self._diag_timer.start()

    # --- event handlers -------------------------------------------------
    def _on_text_changed(self) -> None:
        if self._applying:
            return
        text = self._editor.toPlainText()
        self.session.set_helixspec(text, path=self._current_path)
        self._update_path_label()
        self._update_run_enabled()
        self._diag_timer.start()

    def _open_spec(self) -> None:
        start_dir = self._current_path or str(self._project_root or os.getcwd())
        path, _ = QFileDialog.getOpenFileName(self, "Open HelixSpec", start_dir, "HelixSpec (*.hxspec);;All files (*.*)")
        if not path:
            return
        try:
            text = Path(path).read_text(encoding="utf-8")
        except Exception as exc:
            self.session.error(f"Failed to open HelixSpec: {exc}")
            return
        self._current_path = path
        self._apply_text(text)
        self.session.set_helixspec(text, path=path)
        self._update_path_label()

    def _save_spec(self, *, force_dialog: bool) -> None:
        path = self._current_path
        if force_dialog or not path:
            start_dir = path or str(self._project_root or os.getcwd())
            path, _ = QFileDialog.getSaveFileName(
                self, "Save HelixSpec", start_dir, "HelixSpec (*.hxspec);;All files (*.*)"
            )
            if not path:
                return
            if not Path(path).suffix:
                path = f"{path}.hxspec"
        text = self._editor.toPlainText()
        try:
            Path(path).write_text(text, encoding="utf-8")
        except Exception as exc:
            self.session.error(f"Failed to save HelixSpec: {exc}")
            return
        self._current_path = path
        self.session.set_helixspec(text, path=path)
        self._update_path_label()

    # --- helpers --------------------------------------------------------
    def _apply_text(self, text: str) -> None:
        self._applying = True
        try:
            self._editor.setPlainText(text or "")
        finally:
            self._applying = False

    def _apply_from_state(self, state: ExperimentState) -> None:
        if self._applying:
            return
        if state is None:
            return
        if state.helixspec_text == self._editor.toPlainText() and state.helixspec_path == self._current_path:
            return
        self._current_path = state.helixspec_path
        self._apply_text(state.helixspec_text)
        self._update_path_label()
        self._update_run_enabled()
        self._diag_timer.start()

    def _update_path_label(self) -> None:
        path = self._current_path
        if path:
            self._path_label.setText(Path(path).name)
            self._path_label.setToolTip(path)
            self._save_btn.setText("Save")
        else:
            self._path_label.setText("(unsaved)")
            self._path_label.setToolTip("")
            self._save_btn.setText("Save As…")

    def _update_run_enabled(self) -> None:
        enabled = bool(self._editor.toPlainText().strip())
        try:
            self._run_btn.setEnabled(enabled)
        except Exception:
            pass

    def set_run_enabled(self, enabled: bool) -> None:
        try:
            self._run_btn.setEnabled(bool(enabled))
        except Exception:
            pass

    def set_last_bundle(self, path: str | Path | None) -> None:
        """Enable the open-bundle button if a bundle path is known."""
        enabled = bool(path)
        try:
            self._open_bundle_btn.setEnabled(enabled)
            if enabled:
                self._open_bundle_btn.setToolTip(str(path))
            else:
                self._open_bundle_btn.setToolTip("")
        except Exception:
            pass

    # --- diagnostics ----------------------------------------------------
    def _run_diagnostics(self) -> None:
        text = self._editor.toPlainText()
        policy = None
        try:
            cfg = getattr(self.session.state, "config", None)
            raw = cfg.get("helixspec_policy") if isinstance(cfg, dict) else None
            policy = raw if isinstance(raw, dict) else None
        except Exception:
            policy = None
        watcher = self._diag_watcher or QFutureWatcher(self)
        global _DIAG_EXECUTOR
        if _DIAG_EXECUTOR is None:
            from concurrent.futures import ThreadPoolExecutor

            _DIAG_EXECUTOR = ThreadPoolExecutor(max_workers=1)

        future = _DIAG_EXECUTOR.submit(diagnose_helixspec, text, policy=policy)
        self._diag_future = future

        def _on_done(fut):
            try:
                res = fut.result()
            except Exception:
                res = {"ok": False, "errors": [{"message": "Diagnostics failed", "span": None}], "ir_text": ""}
            # Marshal back to UI thread
            QTimer.singleShot(0, lambda r=res: self._apply_diagnostics(r))

        future.add_done_callback(_on_done)

    def _clear_quickfixes(self) -> None:
        self._last_wetlab_preflight = None
        try:
            while self._quickfix_layout.count():
                item = self._quickfix_layout.takeAt(0)
                w = item.widget()
                if w is not None:
                    w.deleteLater()
        except Exception:
            pass
        try:
            self._quickfix_container.setVisible(False)
        except Exception:
            pass

    def _apply_quickfix_patch(self, *, code: str, patch: Mapping[str, Any]) -> None:
        try:
            from helix.studio.policy_patches import apply_policy_patch

            cfg = dict(getattr(self.session.state, "config", {}) or {})
            raw_policy = cfg.get("helixspec_policy")
            if not isinstance(raw_policy, Mapping):
                self.session.error("Quick fix requires a helixspec_policy in session config.")
                return
            updated = apply_policy_patch(raw_policy, patch)
            cfg["helixspec_policy"] = updated
            self.session.update(config=cfg)
            self.session.log(f"Applied quick fix {code}")
        except Exception as exc:
            self.session.error(f"Failed to apply quick fix {code}: {exc}")
            return
        self._run_diagnostics()

    def _render_quickfixes(self, findings: list[Mapping[str, Any]]) -> None:
        from functools import partial

        items: list[tuple[str, str, Mapping[str, Any]]] = []
        for f in findings:
            code = str(f.get("code") or "").strip()
            severity = str(f.get("severity") or "").strip().lower()
            if not code or severity != "error":
                continue
            hints = f.get("auto_fix_hints")
            if not isinstance(hints, list) or not hints:
                continue
            hint = hints[0] if isinstance(hints[0], Mapping) else None
            if hint is None:
                continue
            patch = hint.get("patch")
            if not isinstance(patch, Mapping) or not patch:
                continue
            hint_id = str(hint.get("id") or "").strip() or "quick_fix"
            items.append((code, hint_id, patch))

        if not items:
            try:
                self._quickfix_container.setVisible(False)
            except Exception:
                pass
            return

        title = QLabel("Quick fixes", self._quickfix_container)
        title.setStyleSheet("color: palette(mid);")
        self._quickfix_layout.addWidget(title)
        for code, hint_id, patch in items:
            btn = QPushButton(f"{code}: {hint_id}", self._quickfix_container)
            btn.clicked.connect(partial(self._apply_quickfix_patch, code=code, patch=patch))
            self._quickfix_layout.addWidget(btn)
        self._quickfix_container.setVisible(True)

    def _apply_diagnostics(self, result: dict) -> None:
        self._clear_quickfixes()

        compile_ok = bool(result.get("ok"))
        errors = result.get("errors") or []
        ir_text = result.get("ir_text") or ""

        wetlab = result.get("wetlab_preflight")
        wetlab_report = wetlab if isinstance(wetlab, Mapping) else None
        if wetlab_report is not None:
            self._last_wetlab_preflight = dict(wetlab_report)

        if not compile_ok:
            msg = errors[0]["message"] if errors else "Unknown error"
            span = errors[0].get("span") if errors else None
            self._diag_label.setText(f"Error: {msg}")
            lines = [f"- {e.get('message')}" for e in errors]
            self._diagnostics_text.setPlainText("\n".join(lines))
            self._plan_summary.setPlainText(f"Compilation failed:\n{msg}")
            self._ir_preview.setPlainText("")
            if span:
                self._highlight_error_line(span.get("line"), span.get("column"))
            else:
                self._clear_error_highlight()
            return

        self._clear_error_highlight()
        self._ir_preview.setPlainText(ir_text)

        plan_lines = [
            "Compilation succeeded.",
            f"IR bytes: {len(ir_text.encode('utf-8'))}",
            "Errors: 0",
        ]
        diag_lines: list[str] = []

        if wetlab_report is None:
            self._diag_label.setText("OK: compiled")
            diag_lines.append("Wet lab preflight: (no report)")
        else:
            enabled = bool(wetlab_report.get("enabled"))
            lint_ok = bool(wetlab_report.get("ok"))
            verdict = str(wetlab_report.get("verdict") or "").strip() or ("pass" if lint_ok else "fail")
            fail_count = int(wetlab_report.get("fail_count") or 0)
            warn_count = int(wetlab_report.get("warn_count") or 0)
            findings = wetlab_report.get("findings") if isinstance(wetlab_report.get("findings"), list) else []

            if not enabled:
                self._diag_label.setText("OK: compiled")
                diag_lines.append("Wet lab preflight: disabled by policy.")
            else:
                status = "PASS" if lint_ok else "FAIL"
                self._diag_label.setText(f"Wet lab preflight: {status}")
                plan_lines.append(f"Wet lab preflight: {verdict} errors={fail_count} warnings={warn_count}")
                for f in findings:
                    if not isinstance(f, Mapping):
                        continue
                    code = str(f.get("code") or "").strip()
                    sev = str(f.get("severity") or "").strip().lower()
                    message = str(f.get("message") or "").strip()
                    path = str(f.get("path") or "").strip()
                    line = f"- {code} [{sev}]: {message}" if code else f"- [{sev}]: {message}"
                    if path:
                        line += f" ({path})"
                    diag_lines.append(line)
                if not lint_ok:
                    self._render_quickfixes([f for f in findings if isinstance(f, Mapping)])

        self._diagnostics_text.setPlainText("\n".join(diag_lines) if diag_lines else "No diagnostics.")
        self._plan_summary.setPlainText("\n".join(plan_lines))

    def _highlight_error_line(self, line: int | None, column: int | None) -> None:
        if line is None or line < 1:
            self._clear_error_highlight()
            return
        try:
            cursor = self._editor.textCursor()
            block = self._editor.document().findBlockByNumber(line - 1)
            cursor.setPosition(block.position())
            cursor.movePosition(cursor.EndOfBlock, cursor.KeepAnchor)
            extra = QTextEdit.ExtraSelection()
            extra.cursor = cursor
            extra.format.setBackground(Qt.yellow)
            self._editor.setExtraSelections([extra])
        except Exception:
            self._clear_error_highlight()

    def _clear_error_highlight(self) -> None:
        try:
            self._editor.setExtraSelections([])
        except Exception:
            pass

    # --- pipeline + run state -------------------------------------------
    def _theme_prop_qss(self, prop: str, fallback: str) -> str:
        try:
            from PySide6.QtWidgets import QApplication

            app = QApplication.instance()
            if app is not None:
                val = app.property(prop)
                if isinstance(val, str) and val.strip():
                    return val.strip()
        except Exception:
            pass
        return fallback

    def mark_run_started(self, stage: str = "parsing") -> None:
        """Indicate a run has started."""
        self._pipeline_label.setText(f"Run: {stage}")
        accent = self._theme_prop_qss("helixAccent", "palette(highlight)")
        self._pipeline_label.setStyleSheet(f"color: {accent};")

    def record_run_failure(self, message: str | None = None) -> None:
        """Indicate run failure."""
        msg = message or "failed"
        self._pipeline_label.setText(f"Run: {msg}")
        err = self._theme_prop_qss("helixError", "palette(windowText)")
        self._pipeline_label.setStyleSheet(f"color: {err};")

    def record_run_success(self, current_text: str, run_dir: str | Path | None = None) -> None:
        """Record run success, update last-run metadata, diff, and labels."""
        self._pipeline_label.setText("Run: success")
        ok = self._theme_prop_qss("helixSuccess", "palette(windowText)")
        self._pipeline_label.setStyleSheet(f"color: {ok};")
        previous_text = self._last_run_text
        self._update_diff_view(current_text, previous_text)
        self._last_run_text = current_text
        self._last_run_time = QDateTime.currentDateTime()
        if self._last_run_time:
            self._last_run_label.setText(f"Last run: {self._last_run_time.toString('yyyy-MM-dd hh:mm:ss')}")
        else:
            self._last_run_label.setText("Last run: just now")
        if run_dir:
            try:
                self._open_bundle_btn.setToolTip(str(run_dir))
            except Exception:
                pass

    def _update_diff_view(self, current_text: str, previous_text: str | None = None) -> None:
        """Compute diff against last successful run."""
        import difflib

        baseline = previous_text if previous_text is not None else self._last_run_text
        if baseline is None:
            self._diff_view.setPlainText("No previous run to diff against.")
            return
        before_lines = (baseline or "").splitlines(keepends=True)
        after_lines = (current_text or "").splitlines(keepends=True)
        diff = difflib.unified_diff(
            before_lines,
            after_lines,
            fromfile="last_run",
            tofile="current",
            lineterm="",
            n=3,
        )
        diff_text = "\n".join(diff)
        if not diff_text.strip():
            diff_text = "No changes since last run."
        self._diff_view.setPlainText(diff_text)


def diagnose_helixspec(text: str, *, policy: dict | None = None) -> dict:
    """Compile HelixSpec text to IR for diagnostics (no disk writes)."""
    from helixspec.ast import parse_spec
    from helixspec.typecheck import typecheck_spec
    from helixspec.ir_v1 import lower_to_ir
    from helixspec.canon import canonical_json_bytes, canonicalize_ir
    from helixspec.errors import HelixSpecError
    from helixspec.lower_engine import lower_ir_to_edit_plan, lower_ir_to_experiment_spec
    from helix.scientific_contract import load_policy
    from helix.wetlab.preflight_linter import lint_wetlab_preflight, wetlab_preflight_report_to_dict

    try:
        ast = parse_spec(text)
        typed = typecheck_spec(ast)
        ir_payload = canonicalize_ir(lower_to_ir(typed))
        ir_bytes = canonical_json_bytes(ir_payload)
        try:
            policy_payload, policy_hash, _det_class, _resolved = load_policy(
                policy if isinstance(policy, dict) and policy else None
            )
        except Exception as exc:
            return {
                "ok": False,
                "errors": [{"message": f"Invalid policy: {exc}", "span": None}],
                "ir_text": ir_bytes.decode("utf-8"),
            }
        edit_plan = lower_ir_to_edit_plan(ir_payload, policy_payload)
        experiment_spec = lower_ir_to_experiment_spec(ir_payload, policy_payload)
        report = lint_wetlab_preflight(
            experiment_spec=experiment_spec,
            edit_plan=edit_plan,
            policy=policy_payload,
            policy_id=str(policy_payload.get("policyId") or policy_payload.get("policy_id") or "").strip() or None,
            policy_hash=policy_hash,
        )
        return {
            "ok": True,
            "errors": [],
            "ir_text": ir_bytes.decode("utf-8"),
            "wetlab_preflight": wetlab_preflight_report_to_dict(report),
        }
    except HelixSpecError as exc:
        span = exc.span
        return {
            "ok": False,
            "errors": [
                {
                    "message": exc.message,
                    "span": {"line": span.line, "column": span.column} if span else None,
                }
            ],
            "ir_text": "",
        }
    except Exception as exc:
        return {"ok": False, "errors": [{"message": str(exc), "span": None}], "ir_text": ""}
