from __future__ import annotations

from typing import Callable, Mapping, Any

from .rail_state import RailStateStore


def commit_with_guards(
    store: RailStateStore,
    stage: str,
    *,
    inflight_id: str,
    chain_id: str | None,
    expected_upstream_hash: str | None,
    current_upstream_hash: str | None,
    expected_upstream_extra: Mapping[str, Any] | None = None,
    current_upstream_extra: Mapping[str, Any] | None = None,
    apply_fn: Callable[[], str | None],
) -> None:
    """
    Guarded commit wrapper: validates inflight + chain + upstream before applying results.

    apply_fn should return the new output hash (already computed from payload).
    """
    # Validate inflight matches; if not, drop.
    if store._inflight.get(stage) != inflight_id:  # type: ignore[attr-defined]
        store.drop_stale(stage, inflight_id, reason="inflight_mismatch")  # type: ignore[attr-defined]
        return
    if chain_id is not None:
        expected_chain = store.chain_id_for(stage)
        if expected_chain not in {None, chain_id}:
            store.drop_stale(stage, inflight_id, reason="chain_mismatch")  # type: ignore[attr-defined]
            return
    if expected_upstream_hash is not None and current_upstream_hash is not None and expected_upstream_hash != current_upstream_hash:
        store.drop_stale(stage, inflight_id, reason="upstream_changed")  # type: ignore[attr-defined]
        return

    new_hash = apply_fn()
    store.end_compute(
        stage,
        inflight_id,
        new_hash=new_hash,
        current_upstream_hash=current_upstream_hash,
        chain_id=chain_id,
    )
