"""Sketch for GPU off-target heat computation (GL compute).

Not yet wired; compute_offtarget_heat still uses the CPU path. This module
lays out the intended API and buffer layout for a future GPU backend.
"""

from __future__ import annotations

from typing import Any

import numpy as np


def compute_offtarget_heat_gpu(evs: dict[str, Any], gl_ctx) -> np.ndarray:
    """
    Placeholder GPU backend. Intended steps:
    1. Build SSBOs for sequence bases, PAM mask, and output heat buffer.
    2. Upload guide bases + params (mismatchMax, seedLen, offsets) as uniforms.
    3. Dispatch a compute shader (e.g., local_size_x=256) to fill heat[] on device.
    4. Read back the heat buffer into a 1D float array (v0), or bind directly as a texture in the viewer later.

    Returns a numpy array so it can drop-in replace the CPU path.
    """

    # TODO: implement GL compute shader pipeline. For now, fall back to CPU-like stub.
    return np.zeros(len(evs.get("sequence", {}).get("ref", "")) or 1, dtype=np.float32)


COMPUTE_SHADER_SRC = r"""
#version 430
layout(local_size_x = 256) in;

layout(std430, binding = 0) buffer SeqBuffer { uint seq[]; };
layout(std430, binding = 1) buffer PamMask { uint mask[]; };
layout(std430, binding = 2) buffer Heat { float heat[]; };

uniform int guideLen;
uniform int mismatchMax;
uniform int seedLen;
// guide bases packed as uints (A,C,G,T mapped to 0..3) in a small uniform array
uniform uint guideBases[64];

void main() {
    uint idx = gl_GlobalInvocationID.x;
    // Bounds checks and PAM mask check would go here
    // Compute mismatches between seq window and guideBases
    // Apply simple scoring and write to heat[idx]
}
"""
