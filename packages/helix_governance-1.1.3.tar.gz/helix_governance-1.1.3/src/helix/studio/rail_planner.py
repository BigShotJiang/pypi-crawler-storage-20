from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Mapping

from .rail_model import RailGraph


@dataclass(frozen=True)
class RecomputePlan:
    stages: List[str]
    invalidate: List[str]


class RecomputePlanner:
    """Encodes downstream recompute policy once, so UI + backend stay aligned."""

    # Dependency order is linear in current projection.
    _order = ("genome", "edit_plan", "perturbations", "outcome_model", "evidence", "claims")

    def __init__(self, graph: RailGraph | None) -> None:
        self.graph = graph

    def plan(self, root: str) -> RecomputePlan:
        stages = self._downstream_chain(root)
        invalidate = []
        if root == "outcome_model":
            invalidate = ["evidence", "claims"]
        elif root == "evidence":
            invalidate = ["claims"]
        return RecomputePlan(stages=stages, invalidate=invalidate)

    def _downstream_chain(self, root: str) -> List[str]:
        if self.graph is None:
            return [root]
        order = list(self.graph.order) if getattr(self.graph, "order", None) else list(self._order)
        try:
            start_idx = order.index(root)
        except ValueError:
            return [root]
        return order[start_idx:]
