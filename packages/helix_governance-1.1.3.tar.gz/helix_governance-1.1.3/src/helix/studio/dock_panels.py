from __future__ import annotations

import re
from dataclasses import dataclass

_PANEL_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_.-]{1,80}$")


class DockPanelRegistrationError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class HelixDockPanel:
    panel_id: str
    title: str
    owner: str = "core"


class DockPanelRegistry:
    def __init__(self) -> None:
        self._panels: dict[str, HelixDockPanel] = {}
        self._owners: dict[str, set[str]] = {}

    def register(
        self,
        panel_id: str,
        title: str,
        *,
        owner: str = "core",
        replace: bool = False,
    ) -> HelixDockPanel:
        pid = (panel_id or "").strip().lower()
        if not _PANEL_ID_RE.match(pid):
            raise DockPanelRegistrationError(
                f"invalid panel id '{panel_id}' "
                "(expected 2-81 chars: a-z0-9 plus ._-)"
            )
        if not isinstance(title, str) or not title.strip():
            raise DockPanelRegistrationError("title must be a non-empty string")

        if pid in self._panels and not replace:
            raise DockPanelRegistrationError(f"panel already registered: {pid}")
        if pid in self._panels and replace:
            existing = self._panels[pid]
            next_owner = (owner or "core").strip().lower() or "core"
            if existing.owner != next_owner:
                raise DockPanelRegistrationError(
                    f"panel id collision: {pid} already owned by '{existing.owner}'"
                )

        panel = HelixDockPanel(
            panel_id=pid,
            title=title.strip(),
            owner=(owner or "core").strip().lower() or "core",
        )
        self._panels[pid] = panel
        self._owners.setdefault(panel.owner, set()).add(pid)
        return panel

    def unregister(self, panel_id: str) -> bool:
        pid = (panel_id or "").strip().lower()
        panel = self._panels.pop(pid, None)
        if panel is None:
            return False
        owner_ids = self._owners.get(panel.owner)
        if owner_ids is not None:
            owner_ids.discard(pid)
            if not owner_ids:
                self._owners.pop(panel.owner, None)
        return True

    def unregister_owner(self, owner: str) -> int:
        key = (owner or "").strip().lower()
        ids = sorted(self._owners.get(key, set()))
        removed = 0
        for pid in ids:
            if self.unregister(pid):
                removed += 1
        return removed

    def get(self, panel_id: str) -> HelixDockPanel | None:
        return self._panels.get((panel_id or "").strip().lower())

    def list(self) -> list[HelixDockPanel]:
        return sorted(
            self._panels.values(),
            key=lambda p: (p.title.lower(), p.panel_id),
        )


__all__ = [
    "DockPanelRegistry",
    "DockPanelRegistrationError",
    "HelixDockPanel",
]

