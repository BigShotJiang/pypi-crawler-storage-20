from __future__ import annotations

import copy
import hashlib
import json
import math
import os
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
from PySide6.QtCore import Qt, QTimer, Signal, QRect, QRectF, QPoint
from PySide6.QtGui import QAction, QCursor, QFont, QImage, QPainter, QPen, QMouseEvent, QWheelEvent
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QMessageBox,
    QPushButton,
    QSlider,
    QSplitter,
    QStackedLayout,
    QToolButton,
    QToolTip,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from helix import clock
from helix import temp
from helix.lightcone import (
    build_selection_index,
    compiled_geometry_sha256,
    compile_lightcone_geometry,
    decode_id_u32_be,
    decode_id_u32_le,
    gpu_preflight,
    lightcone_gpu_shader_sha256,
    load_lightcone_document,
    render_lightcone_id_rgba,
    render_lightcone_rgba,
    render_settings_payload,
    sha256_hex,
)
from helix.lightcone.allele_ops import allele_ops_from_payload, canonicalize_allele_ops
from helix.lightcone.gpu_backend import LightconeGpuRenderer, _build_segments_tree_v1, lightcone_gpu_backend_receipts
from helix.lightcone.contract import BuilderProvenance, LightconeDocument, OffTarget, ReferenceWindow
from helix.studio.export_gate import build_export_context
from helix.studio.ui.export_gate import ensure_export_allowed
from helix.lightcone.geometry import CompiledGeometry, draw_compiled_geometry
from helix.lightcone.metadata import build_lightcone_png_text
from helix.lightcone.picking import IdBufferRGBA8
from helix.lightcone.png import encode_png_rgba8
from helix.lightcone.render import CanvasRGBA8
from helix.lightcone.snapshot import lightcone_document_to_payload
from helix.lightcone.builders.base_v0 import BaseOutcomeBuilderV0
from helix.lightcone.builders.crispr_v0 import CrisprOutcomeBuilderV0
from helix.lightcone.builders.prime_v0 import PrimeOutcomeBuilderV0
from helix.studio.models import RunModel
from helix.rng import Rng
from helix.studio.experiment_spec import (
    experiment_spec_json_bytes,
    experiment_spec_sha256,
    experiment_spec_to_dict,
)
from helix.studio.experiment_intent_spec import (
    experiment_intent_spec_json_bytes,
    experiment_intent_spec_sha256,
    experiment_intent_spec_to_dict,
)
from helix.studio.edit_plan import edit_plan_json_bytes, edit_plan_sha256, edit_plan_to_dict
from helix.studio.lightcone_audit_pack import build_audit_pack_zip_bytes, build_selection_dump_payload_v1, stable_json_bytes
from helix.studio.export_clip import detect_mp4_encoder, encode_gif_bytes, encode_mp4_bytes_ffmpeg
from helix.studio.outcomes.model import compute_outcomes_for_current_plan, outcome_report_json_bytes, outcome_report_to_dict
from helix.studio.outcomes.clone_yield import build_clone_plan, clone_plan_json_bytes, clone_plan_sha256
from helix.studio.assays.assay_chooser import build_assay_plan, assay_plan_json_bytes, assay_plan_sha256
from helix.studio.offtargets.model import compute_offtargets_for_session, offtarget_report_json_bytes
from helix.studio.offtargets.validation_plan import build_validation_plan, validation_plan_json_bytes, validation_plan_sha256
from helix.studio.assays.primer_design import build_primer_plan, primer_plan_json_bytes, primer_plan_sha256
from helix.studio.results_io import results_record_json_bytes, sanitize_results_id
from helix.studio.calibration import calibration_preview_json_bytes
from helix.studio.base_position_calibration import (
    base_position_calibration_preview_json_bytes,
    base_position_calibration_profile_json_bytes,
    base_position_calibration_eval_json_bytes,
    build_base_position_calibration_eval,
)
from helix.studio.suggested_priors import suggested_priors_json_bytes, suggested_priors_sha256
from helix.studio.governance_stamp import (
    extract_decision_grade_proof_from_artifact,
    extract_decision_grade_proof_from_summary,
    governance_stamp_lines,
    interpretation_for_mode,
    normalize_decision_mode,
    export_watermark_label,
)
from helix.studio.export_labels import build_governance_provenance
from helix.studio.limitations import limitations_stamp
from helix.studio.png_provenance import build_png_provenance_v1, write_png_provenance_sidecar
from helix.studio.export_image_settings import write_image_provenance_sidecars_enabled
from helix.studio.ordinal_bins import tier_for_rank


@dataclass(frozen=True, slots=True)
class LightconeSelection:
    selection_id: int
    kind: str
    outcome_ids: tuple[str, ...]
    probability_mass: float
    dominant_outcome_id: str | None
    mechanism_tags: tuple[str, ...]
    ghost_id: str | None = None


def _rgba_to_qimage(rgba: bytes, *, width: int, height: int) -> QImage:
    # QImage references the underlying buffer; copy to detach from the temporary bytes.
    img = QImage(rgba, int(width), int(height), QImage.Format_RGBA8888)
    return img.copy()


def _clamp01(x: float) -> float:
    return 0.0 if x < 0.0 else 1.0 if x > 1.0 else float(x)


def _scale_radius_px(r: int, zoom: float) -> int:
    if r <= 0:
        return 0
    return max(0, int(round(float(r) * float(zoom))))


def _bezier_points(p0: tuple[int, int], p1: tuple[int, int], p2: tuple[int, int], p3: tuple[int, int], *, steps: int) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    steps = max(2, int(steps))
    for i in range(steps + 1):
        t = i / steps
        u = 1.0 - t
        x = u * u * u * p0[0] + 3.0 * u * u * t * p1[0] + 3.0 * u * t * t * p2[0] + t * t * t * p3[0]
        y = u * u * u * p0[1] + 3.0 * u * u * t * p1[1] + 3.0 * u * t * t * p2[1] + t * t * t * p3[1]
        out.append((int(round(x)), int(round(y))))
    return out


def _default_phase_stages() -> tuple[tuple[str, float, float], ...]:
    return (
        ("bind", 0.0, 0.15),
        ("cut_or_nick", 0.15, 0.3),
        ("processing", 0.3, 0.55),
        ("synthesis", 0.55, 0.85),
        ("ligation", 0.85, 1.0),
    )


def _stage_color_rgba8(name: str) -> tuple[int, int, int, int]:
    return {
        "bind": (28, 38, 64, 90),
        "cut_or_nick": (42, 32, 72, 90),
        "processing": (30, 52, 62, 90),
        "synthesis": (52, 46, 26, 90),
        "ligation": (44, 44, 50, 90),
    }.get(str(name), (32, 32, 40, 80))


def _slug_token(value: str, *, max_len: int = 48) -> str:
    s = str(value)
    out: list[str] = []
    prev_us = False
    for ch in s:
        if ch.isalnum():
            out.append(ch)
            prev_us = False
            continue
        if ch in {"_", "-", "."}:
            if not prev_us:
                out.append("_")
                prev_us = True
            continue
        if not prev_us:
            out.append("_")
            prev_us = True
    tok = "".join(out).strip("_")
    if not tok:
        return "x"
    if len(tok) > int(max_len):
        tok = tok[: int(max_len)].rstrip("_")
    return tok or "x"


class LightconeViewport(QWidget):
    clicked = Signal(int, int)  # x,y in image pixel coordinates
    hovered = Signal(int, int)  # x,y in widget coords
    panRequested = Signal(float, float)  # dx, dy in pixels
    zoomRequested = Signal(float, float, float)  # factor, center_x, center_y
    focusRequested = Signal(int, int)  # x,y
    exitHover = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._img: QImage | None = None
        self._img_rect = None
        self._dragging = False
        self._last_pos: QPoint | None = None
        self._press_pos: QPoint | None = None
        self._dragged = False
        # Do not start panning until cursor moves past the threshold; preserves click reliability.
        self._drag_threshold_px = 7  # was effectively 2

        self.setMouseTracking(True)
        self.setMinimumSize(0, 0)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def set_image(self, img: QImage | None) -> None:
        self._img = img
        self.update()

    def image_draw_rect(self) -> QRect | None:
        return self._img_rect

    def image(self) -> QImage | None:
        return self._img

    def paintEvent(self, event) -> None:  # type: ignore[override]
        _ = event
        p = QPainter(self)
        p.fillRect(self.rect(), Qt.black)
        img = self._img
        if img is None or img.isNull():
            p.end()
            return
        target = self.rect()
        self._img_rect = target
        scaled = img.scaled(target.size(), Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
        p.drawImage(target, scaled)
        p.end()

    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        super().mousePressEvent(event)
        if event.button() != Qt.LeftButton:
            return
        self._dragging = True
        self._last_pos = event.position().toPoint()
        self._press_pos = self._last_pos
        self._dragged = False

    def mouseReleaseEvent(self, event) -> None:  # type: ignore[override]
        super().mouseReleaseEvent(event)
        if event.button() == Qt.LeftButton:
            if not self._dragged:
                img = self._img
                rect = self._img_rect or self.rect()
                if img is not None and rect is not None:
                    pos = event.position()
                    x = float(pos.x())
                    y = float(pos.y())
                    if rect.left() <= x <= rect.right() and rect.top() <= y <= rect.bottom():
                        u = (x - rect.left()) / max(1.0, float(rect.width()))
                        v = (y - rect.top()) / max(1.0, float(rect.height()))
                        px = int(u * img.width())
                        py = int(v * img.height())
                        px = 0 if px < 0 else img.width() - 1 if px >= img.width() else px
                        py = 0 if py < 0 else img.height() - 1 if py >= img.height() else py
                        self.clicked.emit(int(px), int(py))
            self._dragging = False
            self._last_pos = None
            self._press_pos = None
            self._dragged = False

    def mouseMoveEvent(self, event) -> None:  # type: ignore[override]
        super().mouseMoveEvent(event)
        if self._dragging and self._last_pos is not None:
            pos = event.position().toPoint()
            if self._press_pos is not None and not self._dragged:
                dxp = abs(pos.x() - self._press_pos.x())
                dyp = abs(pos.y() - self._press_pos.y())
                if dxp <= self._drag_threshold_px and dyp <= self._drag_threshold_px:
                    # Still treating as a click candidate, do not pan yet.
                    return
                self._dragged = True
                # Reset last_pos so the first pan delta is not huge.
                self._last_pos = pos
                return

            # Dragging for real
            dx = float(pos.x() - self._last_pos.x())
            dy = float(pos.y() - self._last_pos.y())
            self.panRequested.emit(dx, dy)
            self._last_pos = pos
        else:
            self.hovered.emit(int(event.position().x()), int(event.position().y()))

    def leaveEvent(self, _event) -> None:  # type: ignore[override]
        try:
            self.exitHover.emit()
        except Exception:
            pass

    def wheelEvent(self, event: QWheelEvent) -> None:  # type: ignore[override]
        angle = event.angleDelta().y()
        if angle == 0:
            return
        factor = 1.0 + (0.0015 * angle)
        factor = 0.5 if factor < 0.5 else 2.5 if factor > 2.5 else factor
        pos = event.position()
        self.zoomRequested.emit(float(factor), float(pos.x()), float(pos.y()))

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        if event.button() == Qt.LeftButton:
            self.focusRequested.emit(int(event.position().x()), int(event.position().y()))
        super().mouseDoubleClickEvent(event)


class AlleleInspector(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._quantitative_allowed = True
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)

        title = QLabel("Allele inspector")
        try:
            f = title.font()
            f.setWeight(QFont.DemiBold)
            title.setFont(f)
        except Exception:
            pass
        layout.addWidget(title)

        self._meta = QLabel("")
        self._meta.setWordWrap(True)
        self._meta.setProperty("role", "muted")
        layout.addWidget(self._meta)

        self._text = QLabel("")
        mono = QFont("Consolas")
        mono.setPointSize(9)
        self._text.setFont(mono)
        self._text.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self._text, stretch=1)

        layout.addStretch(1)

    def set_quantitative_allowed(self, allowed: bool) -> None:
        allowed = bool(allowed)
        self._quantitative_allowed = allowed

    def show_alignment(
        self,
        *,
        outcome_id: str,
        probability: float,
        tags: tuple[str, ...],
        ref_seq: str,
        allele_ops_payload: Sequence[Mapping[str, Any]],
        ref_window_start: int | None = None,
        ref_window_end: int | None = None,
    ) -> None:
        ops = canonicalize_allele_ops(allele_ops_from_payload(allele_ops_payload))
        ref_aln: list[str] = []
        alt_aln: list[str] = []

        ref_pos = 0
        ref = str(ref_seq).upper()

        from helix.lightcone.allele_ops import DelOp, InsOp, MatchOp, SubOp

        for op in ops:
            if isinstance(op, MatchOp):
                seg = ref[ref_pos : ref_pos + op.n]
                ref_aln.append(seg)
                alt_aln.append(seg)
                ref_pos += op.n
            elif isinstance(op, DelOp):
                seg = ref[ref_pos : ref_pos + op.n]
                ref_aln.append(seg)
                alt_aln.append("-" * len(seg))
                ref_pos += op.n
            elif isinstance(op, InsOp):
                seq = str(op.seq).upper()
                ref_aln.append("-" * len(seq))
                alt_aln.append(seq)
            elif isinstance(op, SubOp):
                seg = ref[ref_pos : ref_pos + len(op.ref)]
                ref_aln.append(seg)
                alt_aln.append(str(op.alt).upper())
                ref_pos += len(op.ref)

        ref_s = "".join(ref_aln)
        alt_s = "".join(alt_aln)
        marks = "".join(" " if a == b else "^" for a, b in zip(ref_s, alt_s))

        def wrap(s: str, n: int = 84) -> str:
            return "\n".join(s[i : i + n] for i in range(0, len(s), n))

        bounds = ""
        if ref_window_start is not None and ref_window_end is not None:
            bounds = f" · refWindow=[{int(ref_window_start)},{int(ref_window_end)}]"

        if self._quantitative_allowed:
            p_txt = f"{probability:.6f}"
        else:
            p_txt = "suppressed"
        self._meta.setText(
            f"Outcome: {outcome_id} · p={p_txt} · ops={len(ops)}{bounds} · tags={', '.join(tags) if tags else '—'}"
        )
        self._text.setText(
            "REF:\n"
            + wrap(ref_s)
            + "\n\nALT:\n"
            + wrap(alt_s)
            + "\n\nDIFF:\n"
            + wrap(marks)
        )


class _ExportToast(QFrame):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("LightconeExportToast")
        self.setAttribute(Qt.WA_StyledBackground, True)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        layout.setSpacing(10)

        self._label = QLabel("", self)
        self._label.setWordWrap(True)
        layout.addWidget(self._label, stretch=1)

        self._copy_btn = QPushButton("Copy path", self)
        self._copy_btn.setObjectName("SecondaryButton")
        self._copy_btn.clicked.connect(self._on_copy)
        layout.addWidget(self._copy_btn)

        close_btn = QPushButton("✕", self)
        close_btn.setFixedSize(22, 22)
        close_btn.setObjectName("SecondaryButton")
        close_btn.clicked.connect(self.hide)
        layout.addWidget(close_btn)

        self._path: str | None = None
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.hide)

        # Default (info) style.
        self._apply_kind("info")

    def _apply_kind(self, kind: str) -> None:
        self.setProperty("kind", str(kind))
        try:
            style = self.style()
            style.unpolish(self)
            style.polish(self)
            self.update()
        except Exception:
            pass

    def show_message(self, message: str, *, path: str | None, kind: str = "info", auto_hide_ms: int = 4500) -> None:
        self._apply_kind(str(kind))
        self._path = str(path) if path else None
        self._label.setText(str(message))
        self._copy_btn.setEnabled(bool(self._path))
        self.show()
        self.raise_()
        if auto_hide_ms > 0:
            try:
                self._timer.stop()
            except Exception:
                pass
            self._timer.start(int(auto_hide_ms))

    def _on_copy(self) -> None:
        if not self._path:
            return
        try:
            cb = QApplication.clipboard()
            cb.setText(str(self._path))
            self._label.setText(f"Copied: {self._path}")
            self._timer.start(2200)
        except Exception:
            pass


class _EmptyStateOverlay(QFrame):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("LightconeEmptyOverlay")
        self.setProperty("role", "card")
        self.setAttribute(Qt.WA_StyledBackground, True)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(8)

        self._title = QLabel("No outcomes")
        self._title.setObjectName("LightconeEmptyTitle")
        try:
            f = self._title.font()
            f.setWeight(QFont.Bold)
            self._title.setFont(f)
        except Exception:
            pass
        layout.addWidget(self._title)

        self._causes = QLabel("")
        self._causes.setProperty("role", "muted")
        self._causes.setWordWrap(True)
        layout.addWidget(self._causes)

        self._action_btn = QPushButton("Copy debug bundle")
        self._action_btn.setVisible(False)
        layout.addWidget(self._action_btn)

        layout.addStretch(1)
        self.hide()

    def show_message(self, title: str, causes: list[str], *, on_action=None, action_label: str | None = None) -> None:
        self._title.setText(title)
        bullets = "\n".join(f"• {c}" for c in causes) if causes else "• No details available"
        self._causes.setText(bullets)
        if on_action is not None and action_label:
            self._action_btn.setText(action_label)
            self._action_btn.setVisible(True)
            try:
                if self._action_btn.receivers(self._action_btn.clicked) > 0:
                    self._action_btn.clicked.disconnect()
            except Exception:
                pass
            self._action_btn.clicked.connect(on_action)
        else:
            self._action_btn.setVisible(False)
        self.show()

    def clear(self) -> None:
        self.hide()


class LightconeSession:
    def __init__(self) -> None:
        self.doc = None
        self.phase = 1.0
        self.backend = "cpu"
        self._is_live_doc: bool = False
        self._gpu_ok = False
        self._gpu_info: dict[str, str] | None = None
        self._gpu_reason: str | None = None
        self._gpu_renderer: LightconeGpuRenderer | None = None
        self._gpu_stage_bands = None
        self._camera_pan_px: tuple[float, float] | None = None
        self._camera_zoom: float | None = None
        self._view_mode: str = "2d"  # "2d" | "3d"
        self._camera_eye: tuple[float, float, float] = (0.0, 0.0, 1800.0)
        self._camera_center: tuple[float, float, float] = (0.0, 0.0, 0.0)
        self._camera_up: tuple[float, float, float] = (0.0, 1.0, 0.0)
        self._last_effective_mass_cutoff: float | None = None
        self._id_dirty: bool = True
        self._id_buffer: bytes | None = None
        self._id_size: tuple[int, int] | None = None
        self._id_is_gpu: bool = False
        self._id_last_used: float | None = None

        self._cached_geom = None
        self._cached_geom_sha = None
        self._geom_size: tuple[int, int] | None = None
        self._selection_index = None
        self._geom_dirty = True
        self._render_dirty = True
        self._geom_rebuild_count = 0
        self._geom_last_log_ts: float = 0.0

        info, reason = gpu_preflight()
        if info:
            self._gpu_info = info
        if reason is None:
            self.backend = "gpu"
            self._gpu_ok = True
        else:
            self._gpu_reason = str(reason)
            self.backend = "cpu"
            self._gpu_ok = False

    def close(self) -> None:
        if self._gpu_renderer is not None:
            try:
                self._gpu_renderer.close()
            except Exception:
                pass
            self._gpu_renderer = None
        self._gpu_stage_bands = None

    @property
    def gpu_info(self) -> Mapping[str, str] | None:
        return dict(self._gpu_info) if self._gpu_info is not None else None

    @property
    def gpu_reason(self) -> str | None:
        return self._gpu_reason

    def load_fixture(self, path: str | Path) -> None:
        doc = load_lightcone_document(path)
        self.load_document(doc, phase=float(doc.render_golden.phase) if doc.render_golden is not None else None)

    def load_document(self, doc: LightconeDocument, *, phase: float | None) -> None:
        if doc.render_golden is None:
            raise ValueError("Fixture missing renderGolden")
        if doc.render_golden.style.layout_mode != "tree_v1":
            raise ValueError("Studio lightcone panel currently requires style.layoutMode='tree_v1'")
        self.doc = doc
        if phase is None:
            self.phase = float(doc.render_golden.phase)
        else:
            self.phase = float(phase)
        try:
            self._camera_pan_px = tuple(doc.render_golden.camera.pan_px)
            self._camera_zoom = float(doc.render_golden.camera.zoom)
        except Exception:
            self._camera_pan_px = (0.0, 0.0)
            self._camera_zoom = 1.0
        self._geom_dirty = True
        self._rebuild_geometry()

    def set_phase(self, phase: float) -> None:
        self.phase = 0.0 if phase < 0.0 else 1.0 if phase > 1.0 else float(phase)
        self._render_dirty = True
        self._id_dirty = True

    def set_camera(self, *, pan_dx: float = 0.0, pan_dy: float = 0.0, zoom_factor: float | None = None) -> None:
        """Adjust camera pan/zoom for interactive navigation."""
        if self.doc is None or self.doc.render_golden is None:
            return
        pan_x, pan_y = self._camera_pan_px or (0.0, 0.0)
        pan_x += float(pan_dx)
        pan_y += float(pan_dy)
        zoom = self._camera_zoom if self._camera_zoom is not None else float(self.doc.render_golden.camera.zoom)
        if zoom_factor is not None:
            zoom = float(zoom * zoom_factor)
            zoom = 0.25 if zoom < 0.25 else 4.0 if zoom > 4.0 else zoom
        self._camera_pan_px = (pan_x, pan_y)
        self._camera_zoom = zoom
        try:
            self.doc.render_golden.camera.pan_px = (pan_x, pan_y)
            self.doc.render_golden.camera.zoom = zoom
        except Exception:
            pass
        # Intentionally defer geometry rebuild to avoid heavy work in mouse move; render path will call _ensure_geometry().
        self._geom_dirty = True
        self._id_dirty = True

    def set_view_mode(self, mode: str) -> None:
        mode = "3d" if str(mode).lower() == "3d" else "2d"
        if mode == self._view_mode:
            return
        self._view_mode = mode
        # 3D path placeholder: keep geometry stable, but record camera pose for receipts.
        if mode == "3d":
            # Reset to a gentle orbit-friendly pose (looking down -Y).
            self._camera_eye = (0.0, -800.0, 1400.0)
            self._camera_center = (0.0, 0.0, 0.0)
            self._camera_up = (0.0, 0.0, 1.0)
        else:
            # Return to current 2D camera pan/zoom; render path remains 2D canonical.
            pass
        self._geom_dirty = True
        self._id_dirty = True

    def set_bundling_enabled(self, enabled: bool) -> None:
        doc = self.doc
        if doc is None or doc.render_golden is None:
            return
        # RenderStyle contains mutable dicts (frozen dataclass, but deep fields are editable).
        try:
            doc.render_golden.style.bundling["enabled"] = bool(enabled)
        except Exception:
            pass
        self._geom_dirty = True
        self._render_dirty = True

    def _is_software_renderer(self) -> bool:
        renderer = str((self._gpu_info or {}).get("GL_RENDERER", "")).lower()
        reason = str(self._gpu_reason or "").lower()
        tokens = ("llvmpipe", "softpipe", "swrast", "software rasterizer")
        return any(tok in renderer for tok in tokens) or any(tok in reason for tok in tokens)

    def _theta_for_selection(self, selection_id: int) -> float:
        # Stable hash -> angle in radians [0, 2pi).
        h = hashlib.sha256(str(int(selection_id)).encode("ascii")).digest()
        u32 = int.from_bytes(h[:4], "big")
        return (u32 / float(2**32)) * math.tau

    def _project_point_cyl(self, x: float, y: float, *, width: int, depth_scale: float, theta: float) -> tuple[float, float]:
        cx = width * 0.5
        dx = x - cx
        r = abs(dx)
        z = r * math.sin(theta)
        x_cyl = r * math.cos(theta)
        x2 = cx + x_cyl
        persp = 1.0 / (1.0 + (z / max(1.0, depth_scale)))
        x_proj = x2 * persp
        y_proj = y  # keep vertical stable to preserve phase readability
        return x_proj, y_proj

    def _apply_view_transform(self, geom, segs):
        if getattr(self, "_view_mode", "2d") != "3d" or geom is None:
            return geom, segs
        try:
            width = int(getattr(geom, "width", 0) or 0)
        except Exception:
            width = 0
        if width <= 0:
            return geom, segs
        depth_scale = max(width, 1) * 0.75

        # Transform geometry edges.
        new_edges = []
        for e in getattr(geom, "edges", []):
            theta = self._theta_for_selection(int(e.selection_id))
            p0x, p0y = self._project_point_cyl(float(e.p0[0]), float(e.p0[1]), width=width, depth_scale=depth_scale, theta=theta)
            p1x, p1y = self._project_point_cyl(float(e.p1[0]), float(e.p1[1]), width=width, depth_scale=depth_scale, theta=theta)
            p2x, p2y = self._project_point_cyl(float(e.p2[0]), float(e.p2[1]), width=width, depth_scale=depth_scale, theta=theta)
            p3x, p3y = self._project_point_cyl(float(e.p3[0]), float(e.p3[1]), width=width, depth_scale=depth_scale, theta=theta)
            new_edges.append(
                replace(
                    e,
                    p0=(int(p0x), int(p0y)),
                    p1=(int(p1x), int(p1y)),
                    p2=(int(p2x), int(p2y)),
                    p3=(int(p3x), int(p3y)),
                )
            )
        if new_edges:
            geom = replace(geom, edges=tuple(new_edges))

        # Transform GPU segments if provided.
        if segs:
            segs2 = []
            for s in segs:
                theta = self._theta_for_selection(int(s.selection_id))
                p0x, p0y = self._project_point_cyl(float(s.p0[0]), float(s.p0[1]), width=width, depth_scale=depth_scale, theta=theta)
                p1x, p1y = self._project_point_cyl(float(s.p1[0]), float(s.p1[1]), width=width, depth_scale=depth_scale, theta=theta)
                segs2.append(replace(s, p0=(p0x, p0y), p1=(p1x, p1y)))
            segs = segs2
        return geom, segs

    def _effective_dimensions(self, doc: LightconeDocument) -> tuple[int, int]:
        """Downshift live renders when stuck on llvmpipe to keep UI responsive."""
        if doc.render_golden is None:
            return 0, 0
        width = int(doc.render_golden.width)
        height = int(doc.render_golden.height)
        is_live = bool(self._is_live_doc) or bool(getattr(doc, "_live_doc", False))
        # Only downshift interactive renders for live Studio runs; keep fixtures deterministic.
        scale_interactive = 0.55 if getattr(self, "_is_interacting", False) and is_live else 1.0
        if self._is_software_renderer() and is_live:
            scale = 0.75 if self.backend == "cpu" else 0.85
            width = max(320, int(width * scale))
            height = max(240, int(height * scale))
        width = int(width * scale_interactive)
        height = int(height * scale_interactive)
        return width, height

    def receipts_text(self) -> str:
        doc = self.doc
        if doc is None or doc.render_golden is None:
            return ""
        rg = doc.render_golden
        settings_payload = render_settings_payload(rg)
        settings_payload["phase"] = float(self.phase)
        settings_sha = sha256_hex(json.dumps(settings_payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))
        eff_w, eff_h = self._effective_dimensions(doc)
        scale = float(eff_w) / float(rg.width) if rg.width else 1.0
        parts = [
            f"backend={self.backend}",
            f"settingsSha256={settings_sha}",
            f"geometrySha256={self._cached_geom_sha or ''}",
            f"effectiveWidthPx={eff_w}",
            f"effectiveHeightPx={eff_h}",
            f"scaleFactor={scale:.3f}",
            f"viewMode={self._view_mode}",
        ]
        if getattr(self, "_is_interacting", False):
            parts.append("interaction=fast")
        if self._last_effective_mass_cutoff is not None:
            parts.append(f"effectiveMassCutoff={self._last_effective_mass_cutoff:.6f}")
        if self._id_last_used:
            parts.append("idPassUsed=1")
        if self._view_mode == "3d":
            eye = ",".join(f"{v:.2f}" for v in self._camera_eye)
            center = ",".join(f"{v:.2f}" for v in self._camera_center)
            up = ",".join(f"{v:.2f}" for v in self._camera_up)
            parts.append(f"cameraPose=eye[{eye}]|center[{center}]|up[{up}]")
        if self.backend == "gpu" and self._gpu_ok:
            parts.append(f"gpuShaderSha256={lightcone_gpu_shader_sha256()}")
            cfg = lightcone_gpu_backend_receipts()
            parts.append(f"gpuRasterMode={cfg.get('rasterMode')}")
            parts.append(f"gpuScissorMode={cfg.get('scissorMode')}")
            parts.append(f"gpuQuadPadPx={cfg.get('quadPadPx')}")
            if self._gpu_info is not None:
                parts.append(f"gpu={self._gpu_info.get('GL_RENDERER','')}")
                parts.append(f"gl={self._gpu_info.get('GL_VERSION','')}")
        return "\n".join(parts)

    def _render_compiled_rgba_cpu(
        self,
        doc: LightconeDocument,
        *,
        geom: CompiledGeometry,
        width: int,
        height: int,
        phase: float,
        background: tuple[int, int, int, int],
        camera_pan_px: tuple[float, float],
        camera_zoom: float,
    ) -> bytes:
        rg = doc.render_golden
        assert rg is not None
        style = rg.style
        phase = _clamp01(float(phase))
        camera_zoom = float(camera_zoom)
        canvas = CanvasRGBA8.create(int(width), int(height), bg=tuple(int(x) for x in background))

        # Stage bands (post-camera) so they track pan/zoom.
        cx = float(width) * 0.5
        pan_x, _pan_y = (float(camera_pan_px[0]), float(camera_pan_px[1]))
        x0_t = (0.0 - cx) * camera_zoom + cx + pan_x
        x1_t = (float(width) - cx) * camera_zoom + cx + pan_x
        x_min = int(round(min(x0_t, x1_t)))
        x_max = int(round(max(x0_t, x1_t)))

        stages = doc.phase_stages or ()
        if not stages:
            for name, start, end in _default_phase_stages():
                y0 = float(geom.y_bottom_px) - float(end) * float(geom.axis_h_px)
                y1 = float(geom.y_bottom_px) - float(start) * float(geom.axis_h_px)
                if y1 <= y0:
                    continue
                y_min = int(round(min(y0, y1)))
                y_max = int(round(max(y0, y1)))
                canvas.fill_rect(x_min, y_min, x_max - x_min, y_max - y_min, _stage_color_rgba8(name))
        else:
            for st in stages:
                y0 = float(geom.y_bottom_px) - float(getattr(st, "end", 0.0)) * float(geom.axis_h_px)
                y1 = float(geom.y_bottom_px) - float(getattr(st, "start", 0.0)) * float(geom.axis_h_px)
                if y1 <= y0:
                    continue
                y_min = int(round(min(y0, y1)))
                y_max = int(round(max(y0, y1)))
                canvas.fill_rect(x_min, y_min, x_max - x_min, y_max - y_min, _stage_color_rgba8(str(getattr(st, "name", ""))))

        # Trunk (up to current phase).
        x_center = int(width) // 2
        x_center_t = (float(x_center) - cx) * camera_zoom + cx + pan_x
        y0 = float(geom.y_bottom_px)
        y1 = float(geom.y_bottom_px) - phase * float(geom.axis_h_px)
        canvas.draw_line(
            int(round(x_center_t)),
            int(round(y0)),
            int(round(x_center_t)),
            int(round(y1)),
            color=tuple(int(c) for c in style.trunk_color),
            r=_scale_radius_px(int(style.trunk_radius_px), camera_zoom),
        )

        draw_compiled_geometry(
            canvas,
            geom,
            phase=float(phase),
            tip_radius_px=int(style.tip_radius_px),
            tip_alpha_boost=int(style.tip_alpha_boost),
        )
        return bytes(canvas.pixels)

    def _render_compiled_id_rgba_cpu(
        self,
        doc: LightconeDocument,
        *,
        geom: CompiledGeometry,
        width: int,
        height: int,
        phase: float,
    ) -> bytes:
        phase = _clamp01(float(phase))
        y_clip = float(geom.y_bottom_px) - float(phase) * float(geom.axis_h_px)

        idbuf = IdBufferRGBA8(width=int(width), height=int(height))
        sel_index = self._selection_index if self._selection_index is not None else build_selection_index(doc, geom)

        def is_intended(selection_id: int) -> bool:
            info = sel_index.get(int(selection_id))
            if info is None:
                return False
            return "intended" in {t.lower() for t in getattr(info, "mechanism_tags", ())}

        edges = list(getattr(geom, "edges", ()))
        edges.sort(key=lambda e: (is_intended(int(e.selection_id)), float(getattr(e, "probability_mass", 0.0)), int(e.selection_id)))

        for e in edges:
            if float(phase) <= float(getattr(e, "start_phase", 0.0)):
                continue
            pts = _bezier_points(e.p0, e.p1, e.p2, e.p3, steps=40)
            clipped: list[tuple[int, int]] = []
            for x, y in pts:
                if float(y) >= y_clip:
                    clipped.append((int(x), int(y)))
            if len(clipped) < 2:
                continue
            r = max(1, int(getattr(e, "radius_px", 1)))
            idbuf.draw_polyline(clipped, selection_id=int(e.selection_id), r=r)
            x_tip, y_tip = clipped[-1]
            idbuf.fill_disc(int(x_tip), int(y_tip), max(r, 2), int(e.selection_id))

        return bytes(idbuf.pixels)

    def render_rgba(self) -> tuple[bytes, int, int]:
        doc = self.doc
        if doc is None or doc.render_golden is None:
            raise ValueError("No lightcone loaded")
        rg = doc.render_golden
        self._ensure_geometry()
        self._last_effective_mass_cutoff = None
        width, height = self._effective_dimensions(doc)
        if width <= 0 or height <= 0:
            raise ValueError("Invalid render dimensions")
        if self.backend == "gpu" and self._gpu_ok:
            if self._gpu_renderer is None:
                self._gpu_renderer = LightconeGpuRenderer()
            assert self._cached_geom is not None and self._gpu_stage_bands is not None
            y_clip = float(self._cached_geom.y_bottom_px) - float(self.phase) * float(self._cached_geom.axis_h_px)
            try:
                rgba = self._gpu_renderer.render_color(
                    doc,
                    width=width,
                    height=height,
                    phase=float(self.phase),
                    background_rgba8=tuple(int(x) for x in rg.background),
                    y_clip=float(y_clip),
                    stage_bands=self._gpu_stage_bands,
                    readback=True,
                )
            except Exception as exc:
                self.backend = "cpu"
                self._gpu_ok = False
                self._gpu_reason = str(exc)
                return render_lightcone_rgba(
                    doc,
                    width=int(rg.width),
                    height=int(rg.height),
                    phase=float(self.phase),
                    background=rg.background,
                    camera_pan_px=self._camera_pan_px or rg.camera.pan_px,
                    camera_zoom=self._camera_zoom or rg.camera.zoom,
                ), int(rg.width), int(rg.height)
        else:
            if getattr(self, "_view_mode", "2d") == "3d":
                assert self._cached_geom is not None
                camera_pan_px = self._camera_pan_px or rg.camera.pan_px
                camera_zoom = self._camera_zoom or rg.camera.zoom
                rgba = self._render_compiled_rgba_cpu(
                    doc,
                    geom=self._cached_geom,
                    width=int(width),
                    height=int(height),
                    phase=float(self.phase),
                    background=tuple(int(x) for x in rg.background),
                    camera_pan_px=tuple(float(x) for x in camera_pan_px),
                    camera_zoom=float(camera_zoom),
                )
                return rgba, int(width), int(height)

            # CPU path (canonical). Apply zoom-scaled prune only for live viewport; keep exports/goldens intact.
            restore_cutoff = None
            if getattr(self, "_mode", "live") == "live" and hasattr(rg, "style") and hasattr(rg.style, "prune"):
                try:
                    base_cutoff = float(rg.style.prune.get("massCutoff", 0.0))
                    zoom = float(self._camera_zoom or rg.camera.zoom or 1.0)
                    zoom_factor = 1.0 / zoom if zoom > 1e-6 else 8.0
                    zoom_factor = max(1.0, min(8.0, zoom_factor))
                    eff_cutoff = base_cutoff * zoom_factor
                    restore_cutoff = rg.style.prune.get("massCutoff", None)
                    rg.style.prune["massCutoff"] = eff_cutoff
                    self._last_effective_mass_cutoff = eff_cutoff
                except Exception:
                    restore_cutoff = None
            rgba = render_lightcone_rgba(
                doc,
                width=width,
                height=height,
                phase=float(self.phase),
                background=rg.background,
                camera_pan_px=self._camera_pan_px or rg.camera.pan_px,
                camera_zoom=self._camera_zoom or rg.camera.zoom,
            )
            if restore_cutoff is not None:
                try:
                    rg.style.prune["massCutoff"] = restore_cutoff
                except Exception:
                    pass
        return rgba, width, height

    def pick(self, *, x: int, y: int) -> LightconeSelection | None:
        doc = self.doc
        if doc is None or doc.render_golden is None:
            return None
        rg = doc.render_golden
        self._ensure_geometry()
        width, height = self._effective_dimensions(doc)
        if width <= 0 or height <= 0:
            return None

        if self.backend == "gpu" and self._gpu_ok:
            if self._gpu_renderer is None:
                self._gpu_renderer = LightconeGpuRenderer()
            y_clip = float(self._cached_geom.y_bottom_px) - float(self.phase) * float(self._cached_geom.axis_h_px)
            u32 = self._gpu_renderer.render_id_u32(width=width, height=height, y_clip=float(y_clip), readback=True)
            sid = decode_id_u32_le(u32, x=int(x), y=int(y), width=width, height=height)
            geom = self._cached_geom
        else:
            if getattr(self, "_view_mode", "2d") == "3d":
                rgba_id = self._render_compiled_id_rgba_cpu(doc, geom=self._cached_geom, width=int(width), height=int(height), phase=float(self.phase))
                sid = decode_id_u32_be(rgba_id, x=int(x), y=int(y), width=width, height=height)
                geom = self._cached_geom
            else:
                rgba_id = render_lightcone_id_rgba(
                    doc,
                    width=width,
                    height=height,
                    phase=float(self.phase),
                    camera_pan_px=self._camera_pan_px or rg.camera.pan_px,
                    camera_zoom=self._camera_zoom or rg.camera.zoom,
                )
                sid = decode_id_u32_be(rgba_id, x=int(x), y=int(y), width=width, height=height)
                geom = compile_lightcone_geometry(
                    doc,
                    width=width,
                    height=height,
                    phase=1.0,
                    camera_pan_px=self._camera_pan_px or rg.camera.pan_px,
                    camera_zoom=self._camera_zoom or rg.camera.zoom,
                )

        sel_index = self._selection_index if self._selection_index is not None else build_selection_index(doc, geom)

        # Clicks in the viewport are mapped from widget space -> image pixels with integer rounding.
        # In headless/offscreen Qt (and after repeated window lifecycles), this mapping can miss thin edges
        # by a couple of pixels. Make picking robust by searching a small neighborhood for a nearby id.
        if sid == 0:
            best_sid: int = 0
            best_d2: int | None = None
            best_tie: tuple[int, float, int] | None = None

            def tie_key(selection_id: int) -> tuple[int, float, int]:
                info = sel_index.get(int(selection_id))
                if info is None:
                    return (0, 0.0, int(selection_id))
                tags = {str(t).lower() for t in getattr(info, "mechanism_tags", ())}
                intended = 1 if "intended" in tags else 0
                mass = float(getattr(info, "probability_mass", 0.0))
                return (intended, mass, int(selection_id))

            radius = 4  # pixels
            decode = decode_id_u32_le if (self.backend == "gpu" and self._gpu_ok) else decode_id_u32_be
            buf = u32 if (self.backend == "gpu" and self._gpu_ok) else rgba_id
            for dy in range(-radius, radius + 1):
                yy = int(y) + int(dy)
                if yy < 0 or yy >= int(height):
                    continue
                for dx in range(-radius, radius + 1):
                    xx = int(x) + int(dx)
                    if xx < 0 or xx >= int(width):
                        continue
                    if dx == 0 and dy == 0:
                        continue
                    try:
                        cand = int(decode(buf, x=xx, y=yy, width=int(width), height=int(height)))
                    except Exception:
                        continue
                    if cand == 0:
                        continue
                    if cand not in sel_index:
                        continue
                    d2 = int(dx * dx + dy * dy)
                    cand_tie = tie_key(cand)
                    if best_d2 is None or d2 < best_d2 or (d2 == best_d2 and best_tie is not None and cand_tie > best_tie):
                        best_sid = cand
                        best_d2 = d2
                        best_tie = cand_tie
            sid = int(best_sid)
            if sid == 0:
                return None

        info = sel_index.get(int(sid))
        if info is None:
            return None
        return LightconeSelection(
            selection_id=int(info.selection_id),
            kind=str(info.kind),
            outcome_ids=tuple(info.outcome_ids),
            probability_mass=float(info.probability_mass),
            dominant_outcome_id=(str(info.dominant_outcome_id) if info.dominant_outcome_id else None),
            mechanism_tags=tuple(str(t) for t in info.mechanism_tags),
            ghost_id=(str(info.ghost_id) if info.ghost_id else None),
        )

    def outcomes_for_selection(self, sel: LightconeSelection) -> list[tuple[str, float, tuple[str, ...]]]:
        doc = self.doc
        if doc is None:
            return []
        oc_by_id = {str(o.id): o for o in doc.outcomes}
        items: list[tuple[str, float, tuple[str, ...]]] = []
        for oid in sel.outcome_ids:
            oc = oc_by_id.get(str(oid))
            if oc is None:
                continue
            items.append((str(oc.id), float(oc.probability), tuple(str(t) for t in oc.mechanism_tags)))
        items.sort(key=lambda t: (-float(t[1]), str(t[0])))
        return items

    def outcome_payload(self, outcome_id: str) -> tuple[float, tuple[str, ...], Sequence[Mapping[str, Any]]] | None:
        doc = self.doc
        if doc is None:
            return None
        for oc in doc.outcomes:
            if str(oc.id) == str(outcome_id):
                return float(oc.probability), tuple(str(t) for t in oc.mechanism_tags), oc.allele_ops
        return None

    def reference_sequence(self) -> str | None:
        doc = self.doc
        if doc is None or doc.reference_window is None:
            return None
        return doc.reference_window.sequence

    def reference_window_bounds(self) -> tuple[int, int] | None:
        doc = self.doc
        if doc is None or doc.reference_window is None:
            return None
        return int(doc.reference_window.start), int(doc.reference_window.end)

    def _rebuild_geometry(self) -> None:
        doc = self.doc
        if doc is None or doc.render_golden is None:
            self._cached_geom = None
            self._cached_geom_sha = None
            self._geom_size = None
            self._selection_index = None
            self._gpu_stage_bands = None
            return
        start_ts = clock.monotonic()
        rg = doc.render_golden
        width, height = self._effective_dimensions(doc)
        if self.backend == "gpu" and self._gpu_ok:
            if self._gpu_renderer is None:
                self._gpu_renderer = LightconeGpuRenderer()
            segs, _y_clip, stage_bands, geom = _build_segments_tree_v1(
                doc,
                width=int(width),
                height=int(height),
                phase=1.0,
                pick_mode=True,
            )
            geom, segs = self._apply_view_transform(geom, segs)
            self._gpu_renderer.upload_segments(segs)
            self._gpu_stage_bands = stage_bands
        else:
            camera_pan_px = self._camera_pan_px or rg.camera.pan_px
            camera_zoom = self._camera_zoom or rg.camera.zoom
            geom = compile_lightcone_geometry(
                doc,
                width=int(width),
                height=int(height),
                phase=1.0,
                camera_pan_px=camera_pan_px,
                camera_zoom=float(camera_zoom),
            )
            geom, _ = self._apply_view_transform(geom, None)
        self._cached_geom = geom
        self._cached_geom_sha = compiled_geometry_sha256(geom)
        self._geom_size = (int(width), int(height))
        self._selection_index = build_selection_index(doc, geom)
        self._id_dirty = True
        self._geom_dirty = False
        self._geom_rebuild_count += 1
        if os.getenv("HELIX_LIGHTCONE_DEBUG_GEOM") == "1":
            now = clock.monotonic()
            if now - self._geom_last_log_ts >= 1.0:
                dur_ms = (clock.monotonic() - start_ts) * 1000.0
                print(f"[lightcone] geometry rebuilds={self._geom_rebuild_count} last_ms={dur_ms:.2f}", flush=True)
                self._geom_last_log_ts = now

    def _ensure_geometry(self) -> None:
        doc = self.doc
        if doc is None or doc.render_golden is None:
            return
        cur_w, cur_h = self._effective_dimensions(doc)
        if (
            self._geom_dirty
            or self._cached_geom is None
            or self._geom_size != (int(cur_w), int(cur_h))
            or (self.backend == "gpu" and (self._gpu_stage_bands is None or self._selection_index is None))
        ):
            self._rebuild_geometry()


class LightconePanelWidget(QWidget):
    locusContextChanged = Signal(object)  # payload dict (best-effort, stable keys)
    outcomeActivated = Signal(object)  # payload dict
    exportCompleted = Signal(str, str)  # kind, path

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._session = LightconeSession()
        self._session_model = getattr(parent, "session", None)
        self._last_sel: LightconeSelection | None = None
        self._quantitative_allowed = False
        self._nav_stack: list[tuple[LightconeDocument, float]] = []
        self._last_export_path: str | None = None
        self._export_prompt_suppressed_by_key: dict[str, bool] = {}
        self._active_ghost_id: str | None = None
        self._mode: str = "live"  # "live" | "fixture"
        self._active_doc_id: str | None = None
        self._live_refresh_timer = QTimer(self)
        self._live_refresh_timer.setSingleShot(True)
        self._live_refresh_timer.setInterval(150)
        self._live_refresh_timer.timeout.connect(lambda: self._refresh_live_document(reason="timer"))
        self._llvmpipe_warned = False
        self._is_interacting = False
        self._render_dirty = True
        self._interaction_end_timer = QTimer(self)
        self._interaction_end_timer.setSingleShot(True)
        self._interaction_end_timer.setInterval(160)
        self._interaction_end_timer.timeout.connect(self._end_interaction)
        self._hover_timer = QTimer(self)
        self._hover_timer.setSingleShot(True)
        self._hover_timer.setInterval(30)
        self._hover_timer.timeout.connect(self._dispatch_hover_pick)
        self._pending_hover: tuple[int, int] | None = None
        self._hover_sel: LightconeSelection | None = None
        self._hover_enabled = False
        self._render_min_dt_s = 1.0 / 60.0  # cap rendering at ~60 FPS
        self._last_render_ts = 0.0

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        toolbar = QFrame(self)
        toolbar.setObjectName("LightconeToolbar")
        tl = QHBoxLayout(toolbar)
        tl.setContentsMargins(8, 8, 8, 8)
        tl.setSpacing(10)

        # Source selector: Live (default) vs Fixture import.
        self._source_menu = QMenu(self)
        self._source_live = QAction("Live (session)", self._source_menu, checkable=True)
        self._source_fixture = QAction("Import fixture…", self._source_menu, checkable=True)
        self._source_live.setChecked(True)
        self._source_live.triggered.connect(lambda _: self._switch_mode("live"))
        self._source_fixture.triggered.connect(lambda _: self._switch_mode("fixture"))
        self._source_menu.addAction(self._source_live)
        self._source_menu.addAction(self._source_fixture)

        self._source_btn = QToolButton(toolbar)
        self._source_btn.setText("Live")
        self._source_btn.setPopupMode(QToolButton.InstantPopup)
        self._source_btn.setMenu(self._source_menu)
        self._source_btn.setToolButtonStyle(Qt.ToolButtonTextOnly)
        tl.addWidget(self._source_btn)

        self._status_chip = QLabel("Live · bound")
        self._status_chip.setObjectName("LightconeStatusChip")
        self._status_chip.setProperty("role", "chip")
        self._status_chip.setAttribute(Qt.WA_StyledBackground, True)
        tl.addWidget(self._status_chip)

        # View mode toggle (2D / 3D).
        self._view_mode_menu = QMenu(self)
        self._view_mode_2d = QAction("2D view", self._view_mode_menu, checkable=True)
        self._view_mode_3d = QAction("3D view", self._view_mode_menu, checkable=True)
        self._view_mode_2d.setChecked(True)
        self._view_mode_2d.triggered.connect(lambda _: self._set_view_mode("2d"))
        self._view_mode_3d.triggered.connect(lambda _: self._set_view_mode("3d"))
        self._view_mode_menu.addAction(self._view_mode_2d)
        self._view_mode_menu.addAction(self._view_mode_3d)
        self._view_mode_btn = QToolButton(toolbar)
        self._view_mode_btn.setText("2D")
        self._view_mode_btn.setPopupMode(QToolButton.InstantPopup)
        self._view_mode_btn.setMenu(self._view_mode_menu)
        self._view_mode_btn.setToolTip("Toggle Lightcone view: 2D (canonical) vs 3D (exploratory)")
        tl.addWidget(self._view_mode_btn)

        # Slice controls (3D only).
        self._slice_toggle = QToolButton(toolbar)
        self._slice_toggle.setText("Slice: off")
        self._slice_toggle.setCheckable(True)
        self._slice_toggle.setChecked(False)
        self._slice_toggle.clicked.connect(self._on_slice_toggled)
        tl.addWidget(self._slice_toggle)

        self._slice_slider = QSlider(Qt.Horizontal, toolbar)
        self._slice_slider.setRange(0, 1000)
        self._slice_slider.setValue(0)
        self._slice_slider.setEnabled(False)
        self._slice_slider.valueChanged.connect(self._on_slice_changed)
        self._slice_span = 0.15  # fraction of phase
        tl.addWidget(self._slice_slider, 1)

        self._hover_toggle = QToolButton(toolbar)
        self._hover_toggle.setText("Hover pick")
        self._hover_toggle.setCheckable(True)
        self._hover_toggle.setChecked(False)
        self._hover_toggle.clicked.connect(self._on_hover_toggle)
        tl.addWidget(self._hover_toggle)

        self._back_btn = QPushButton("Back", toolbar)
        self._back_btn.clicked.connect(self._on_back_clicked)
        self._back_btn.setVisible(False)
        tl.addWidget(self._back_btn)

        self._locus_label = QLabel("", toolbar)
        self._locus_label.setObjectName("LightconeLocusLabel")
        self._locus_label.setProperty("role", "muted")
        tl.addWidget(self._locus_label)

        tl.addWidget(QLabel("Phase", toolbar))
        self._phase_slider = QSlider(Qt.Horizontal, toolbar)
        self._phase_slider.setRange(0, 1000)
        self._phase_slider.setValue(1000)
        self._phase_slider.valueChanged.connect(self._on_phase_changed)
        tl.addWidget(self._phase_slider, stretch=1)

        self._bundling = QCheckBox("Bundling", toolbar)
        self._bundling.stateChanged.connect(lambda s: self._on_bundling_changed(bool(s)))
        tl.addWidget(self._bundling)

        self._backend_label = QLabel("", toolbar)
        self._backend_label.setProperty("role", "muted")
        tl.addWidget(self._backend_label)

        # Export split-button (primary: audit pack).
        self._export_menu = QMenu(self)

        self._export_audit_pack_action = QAction("Export audit pack…", self)
        self._export_audit_pack_action.triggered.connect(self._on_export_audit_pack)

        export_audit_pack_action2 = QAction("Export audit pack…", self._export_menu)
        export_audit_pack_action2.triggered.connect(self._on_export_audit_pack)

        export_png_screenshot_action = QAction("Export PNG screenshot…", self._export_menu)
        export_png_screenshot_action.triggered.connect(self._on_export_png_screenshot)

        export_png_cpu_action = QAction("Export canonical CPU render PNG…", self._export_menu)
        export_png_cpu_action.triggered.connect(self._on_export_png_cpu)

        export_fixture_action = QAction("Export fixture JSON snapshot…", self._export_menu)
        export_fixture_action.triggered.connect(self._on_export_fixture_snapshot)

        export_clip_action = QAction("Export clip (GIF or MP4)…", self._export_menu)
        export_clip_action.triggered.connect(self._on_export_clip)

        self._export_menu.addAction(export_audit_pack_action2)
        self._export_menu.addSeparator()
        self._export_menu.addAction(export_png_screenshot_action)
        self._export_menu.addAction(export_png_cpu_action)
        self._export_menu.addAction(export_fixture_action)
        self._export_menu.addAction(export_clip_action)
        self._export_menu.addSeparator()

        header = QAction("Audit pack options", self._export_menu)
        header.setEnabled(False)
        self._export_menu.addAction(header)

        self._audit_opt_include_gpu = QAction("Include GPU screenshot (render_gpu.png)", self._export_menu)
        self._audit_opt_include_gpu.setCheckable(True)
        self._audit_opt_include_gpu.setChecked(True)
        self._export_menu.addAction(self._audit_opt_include_gpu)

        self._audit_opt_include_perf = QAction("Include perf receipt (perf_receipt.json) if available", self._export_menu)
        self._audit_opt_include_perf.setCheckable(True)
        self._audit_opt_include_perf.setChecked(True)
        self._export_menu.addAction(self._audit_opt_include_perf)

        self._audit_opt_include_selection = QAction("Include selected branch outcome dump (selection_dump.json)", self._export_menu)
        self._audit_opt_include_selection.setCheckable(True)
        self._audit_opt_include_selection.setChecked(False)
        self._export_menu.addAction(self._audit_opt_include_selection)

        self._export_menu.addSeparator()
        self._export_menu.addAction(self._export_audit_pack_action)

        self._export_btn = QToolButton(toolbar)
        self._export_btn.setPopupMode(QToolButton.MenuButtonPopup)
        self._export_btn.setToolButtonStyle(Qt.ToolButtonTextOnly)
        self._export_btn.setMenu(self._export_menu)
        self._export_btn.setDefaultAction(self._export_audit_pack_action)
        tl.addWidget(self._export_btn)

        outer.addWidget(toolbar)

        self._export_toast = _ExportToast(self)
        self._export_toast.hide()
        outer.addWidget(self._export_toast)
        if self._session.gpu_reason and "llvmpipe" in str(self._session.gpu_reason).lower():
            self._toast_export_result(
                "Software OpenGL detected (llvmpipe). Live view will reduce quality. Install NVIDIA/AMD drivers for GPU rendering.",
                path=None,
                kind="warn",
            )
            self._llvmpipe_warned = True

        splitter = QSplitter(Qt.Horizontal, self)
        outer.addWidget(splitter, stretch=1)

        # Viewport + overlays
        self._viewport = LightconeViewport(splitter)
        self._viewport.clicked.connect(self._on_viewport_clicked)
        self._viewport.hovered.connect(self._on_viewport_hovered)
        self._viewport.exitHover.connect(self._on_viewport_hover_exit)
        self._viewport.panRequested.connect(self._on_pan_requested)
        self._viewport.zoomRequested.connect(self._on_zoom_requested)
        self._viewport.focusRequested.connect(self._on_focus_requested)
        self._empty_overlay = _EmptyStateOverlay()
        view_container = QWidget(splitter)
        view_stack = QStackedLayout(view_container)
        view_stack.setStackingMode(QStackedLayout.StackAll)
        view_stack.addWidget(self._viewport)
        view_stack.addWidget(self._empty_overlay)
        splitter.addWidget(view_container)

        side = QWidget(splitter)
        side_layout = QVBoxLayout(side)
        side_layout.setContentsMargins(8, 8, 8, 8)
        side_layout.setSpacing(10)

        # Receipts (collapsed by default) with copy
        receipts_header = QHBoxLayout()
        receipts_header.setContentsMargins(0, 0, 0, 0)
        self._receipts_toggle = QToolButton(side)
        self._receipts_toggle.setText("Receipts ▸")
        self._receipts_toggle.setCheckable(True)
        self._receipts_toggle.setChecked(False)
        self._receipts_toggle.clicked.connect(self._toggle_receipts)
        receipts_header.addWidget(self._receipts_toggle)
        self._receipts_copy = QToolButton(side)
        self._receipts_copy.setText("Copy")
        self._receipts_copy.setToolTip("Copy full receipts to clipboard")
        self._receipts_copy.clicked.connect(self._copy_receipts)
        receipts_header.addWidget(self._receipts_copy)
        receipts_header.addStretch(1)
        side_layout.addLayout(receipts_header)

        receipts_box = QGroupBox("", side)
        receipts_layout = QVBoxLayout(receipts_box)
        receipts_layout.setContentsMargins(8, 8, 8, 8)
        self._receipts = QLabel("")
        mono = QFont("Consolas")
        mono.setPointSize(8)
        self._receipts.setFont(mono)
        self._receipts.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._receipts.setProperty("role", "muted")
        receipts_layout.addWidget(self._receipts)
        side_layout.addWidget(receipts_box)
        receipts_box.setVisible(False)
        self._receipts_box = receipts_box

        audit_header = QHBoxLayout()
        audit_header.setContentsMargins(0, 0, 0, 0)
        self._audit_toggle = QToolButton(side)
        self._audit_toggle.setText("Audit ▸")
        self._audit_toggle.setCheckable(True)
        self._audit_toggle.setChecked(False)
        self._audit_toggle.clicked.connect(self._toggle_audit)
        audit_header.addWidget(self._audit_toggle)
        audit_header.addStretch(1)
        side_layout.addLayout(audit_header)

        audit_box = QGroupBox("", side)
        audit_layout = QVBoxLayout(audit_box)
        audit_layout.setContentsMargins(8, 8, 8, 8)
        self._audit = QLabel("—")
        mono2 = QFont("Consolas")
        mono2.setPointSize(8)
        self._audit.setFont(mono2)
        self._audit.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._audit.setProperty("role", "muted")
        audit_layout.addWidget(self._audit)
        side_layout.addWidget(audit_box)
        audit_box.setVisible(False)
        self._audit_box = audit_box

        sel_box = QGroupBox("Selection", side)
        sel_form = QFormLayout(sel_box)
        sel_form.setContentsMargins(8, 8, 8, 8)
        self._sel_label = QLabel("—")
        self._sel_label.setWordWrap(True)
        sel_form.addRow("Edge", self._sel_label)
        side_layout.addWidget(sel_box)

        # Filters row
        filters_row = QHBoxLayout()
        filters_row.setContentsMargins(0, 0, 0, 0)
        self._prob_slider = QSlider(Qt.Horizontal, side)
        self._prob_slider.setRange(0, 100)
        self._prob_slider.setValue(0)
        self._prob_slider.setToolTip("Minimum probability (%)")
        self._prob_slider.valueChanged.connect(lambda v: self._on_filter_changed())
        self._prob_label = QLabel("Min p%", side)
        filters_row.addWidget(self._prob_label)
        filters_row.addWidget(self._prob_slider, 1)
        self._tag_buttons: dict[str, QToolButton] = {}
        for tag in ["nhej", "mmej", "hdr", "prime", "bystander"]:
            btn = QToolButton(side)
            btn.setText(tag.upper())
            btn.setCheckable(True)
            btn.setChecked(False)
            btn.clicked.connect(lambda _=False, t=tag: self._on_filter_changed())
            btn.setToolTip(f"Filter tag {tag}")
            filters_row.addWidget(btn)
            self._tag_buttons[tag] = btn
        side_layout.addLayout(filters_row)

        self._outcomes_list = QListWidget(side)
        self._outcomes_list.itemActivated.connect(self._on_outcome_activated)
        self._outcomes_list.setMouseTracking(True)
        try:
            self._outcomes_list.itemEntered.connect(self._on_outcome_hovered)
        except Exception:
            pass
        side_layout.addWidget(self._outcomes_list, stretch=1)

        self._inspector = AlleleInspector(side)
        side_layout.addWidget(self._inspector, stretch=1)

        splitter.addWidget(side)
        splitter.setStretchFactor(0, 7)
        splitter.setStretchFactor(1, 3)

        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.timeout.connect(self._render_if_dirty)

        # Optional bootstrap (useful for UI smoke tests and dev workflows).
        path = os.environ.get("HELIX_STUDIO_LIGHTCONE_FIXTURE", "").strip()
        if path:
            try:
                self.load_fixture(path)
            except Exception:
                pass
        else:
            # Default to live session mode.
            if self._session_model is not None:
                try:
                    self._session_model.runRecordedModel.connect(self._on_session_run_recorded)
                    self._session_model.stateChanged.connect(self._on_session_state_changed)
                except Exception:
                    pass
            self._refresh_live_document(reason="init")

    def _emit_locus_context_changed(self) -> None:
        doc = self._session.doc
        if doc is None:
            return
        ref_seq = None
        ref_sha = None
        try:
            if doc.reference_window is not None:
                ref_seq = doc.reference_window.sequence
                ref_sha = doc.reference_window.checksum
                if ref_sha is None and ref_seq:
                    ref_sha = hashlib.sha256(str(ref_seq).encode("utf-8")).hexdigest()
        except Exception:
            ref_seq, ref_sha = None, None

        payload = {
            "docId": str(doc.id),
            "editType": str(doc.edit_type),
            "locus": {
                "contig": str(doc.locus.contig),
                "position": int(doc.locus.position),
                "strand": str(doc.locus.strand),
                "windowStart": int(doc.locus.window_start),
                "windowEnd": int(doc.locus.window_end),
            },
            "referenceWindow": {
                "start": int(doc.reference_window.start) if doc.reference_window is not None else None,
                "end": int(doc.reference_window.end) if doc.reference_window is not None else None,
                "sequence": str(ref_seq) if ref_seq is not None else None,
                "sha256": str(ref_sha) if ref_sha is not None else None,
            },
            "navDepth": int(len(self._nav_stack)),
            "activeGhostId": (str(self._active_ghost_id) if self._active_ghost_id is not None else None),
        }
        try:
            self.locusContextChanged.emit(payload)
        except Exception:
            pass

    def _is_headless_qt(self) -> bool:
        platform = os.environ.get("QT_QPA_PLATFORM", "").lower()
        return platform in {"offscreen", "minimal"} or os.environ.get("HELIX_STUDIO_HEADLESS", "0") == "1"

    def _notify_user(self, title: str, message: str, *, kind: str = "info") -> None:
        """Best-effort notification that doesn't deadlock headless/offscreen tests."""
        if self._is_headless_qt():
            # Avoid modal dialogs in offscreen tests; log to stdout instead.
            print(f"[LightconePanel] {title}: {message}", flush=True)
            return
        try:
            if kind == "warn":
                QMessageBox.warning(self, title, message)
            elif kind == "error":
                QMessageBox.critical(self, title, message)
            else:
                QMessageBox.information(self, title, message)
        except Exception:
            # As a last resort, don't crash the UI for a notification failure.
            print(f"[LightconePanel] {title}: {message}", flush=True)

    def _export_hint_for_exception(self, exc: BaseException) -> str:
        text = str(exc).lower()
        if "imageio" in text and "gif" in text:
            return "Next: install 'imageio' (Helix Studio realtime extras)."
        if "ffmpeg" in text or "mp4" in text:
            return "Next: install ffmpeg (or imageio-ffmpeg) and ensure it's on PATH."
        return ""

    def _toast_export_result(self, message: str, *, path: str | None, kind: str) -> None:
        # Always log in headless tests; show toast in interactive UI.
        if self._is_headless_qt():
            print(f"[LightconePanel] Export: {message}", flush=True)
            return
        try:
            self._export_toast.show_message(message, path=path, kind=kind)
        except Exception:
            pass

    def _require_document(self) -> LightconeDocument | None:
        doc = self._session.doc
        if doc is None or doc.render_golden is None:
            self._notify_user("Export", "No Lightcone fixture loaded. Load a fixture first.", kind="warn")
            return None
        return doc

    def _default_export_dir(self) -> str:
        last = self._last_export_path
        if last:
            try:
                return str(Path(last).expanduser().resolve().parent)
            except Exception:
                pass
        return str(Path.cwd())

    def _save_path(self, *, title: str, default_name: str, filter_text: str) -> str | None:
        default = str(Path(self._default_export_dir()) / str(default_name))
        path_str, _ = QFileDialog.getSaveFileName(self, title, default, filter_text)
        return path_str or None

    def _write_bytes(self, path: str | Path, data: bytes) -> None:
        out = Path(path).expanduser()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        self._last_export_path = str(out)
        try:
            self._update_audit_label()
        except Exception:
            pass

    def _is_demo_run(self) -> bool:
        # Prefer run metadata if available; fall back to session metadata.
        run = None
        try:
            runs = getattr(self._session_model, "runs", None)
            if isinstance(runs, list) and runs:
                run = runs[-1]
        except Exception:
            run = None

        meta = getattr(run, "metadata", None) if run is not None else None
        if isinstance(meta, Mapping) and str(meta.get("scenario") or "").strip().lower() == "demo":
            return True

        try:
            state = getattr(self._session_model, "state", None)
        except Exception:
            state = None
        cfg = getattr(state, "config", None)
        meta2 = cfg.get("metadata") if isinstance(cfg, Mapping) and isinstance(cfg.get("metadata"), Mapping) else {}
        preset_id = str(meta2.get("preset_id") or "").strip().lower()
        scenario = str(meta2.get("scenario") or "").strip().lower()
        return bool(scenario == "demo" or preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"))

    def _export_run_id(self) -> str | int | None:
        run = None
        try:
            runs = getattr(self._session_model, "runs", None)
            if isinstance(runs, list) and runs:
                run = runs[-1]
        except Exception:
            run = None
        run_id = getattr(run, "run_id", None) if run is not None else None
        if isinstance(run_id, (int, str)) and str(run_id).strip():
            return run_id
        try:
            state = getattr(self._session_model, "state", None)
            cand = getattr(state, "run_id", None)
            if isinstance(cand, (int, str)) and str(cand).strip():
                return cand
        except Exception:
            pass
        return None

    def _prompt_export_allowed(self, title: str) -> bool:
        # Fixture exports are internal/demo artifacts; do not hard-block on
        # experiment intent binding (which is run-scoped and absent in fixtures).
        if getattr(self, "_mode", "") == "fixture":
            return True
        decision_mode, _interpretation, _proof = self._governance_context_for_export()
        ctx = build_export_context(decision_mode=decision_mode, is_demo=self._is_demo_run(), run_id=self._export_run_id())
        intent_spec = getattr(getattr(self._session_model, "state", None), "experiment_intent_spec", None)
        exp_spec = getattr(getattr(self._session_model, "state", None), "experiment_spec", None)
        summary = None
        try:
            runs = getattr(self._session_model, "runs", None)
            run = runs[-1] if isinstance(runs, list) and runs else None
            meta = getattr(run, "metadata", None) if run is not None else None
            summary = meta.get("run_summary") if isinstance(meta, Mapping) else None
        except Exception:
            summary = None
        return ensure_export_allowed(
            self,
            action_title=title,
            ctx=ctx,
            session_acks=self._export_prompt_suppressed_by_key,
            run_summary_v2=summary if isinstance(summary, Mapping) else None,
            experiment_intent_spec=intent_spec if isinstance(intent_spec, Mapping) else None,
            experiment_spec=exp_spec if isinstance(exp_spec, Mapping) else None,
        )

    def _default_export_basename(self) -> str:
        doc = self._session.doc
        if doc is None:
            locus = "unknown"
        else:
            contig = _slug_token(str(doc.locus.contig))
            pos = _slug_token(str(doc.locus.position))
            locus = f"{contig}_{pos}".strip("_") or "locus"
        stamp = clock.utc_now_stamp()
        base = f"lightcone_{locus}_{stamp}"
        decision_mode, _interpretation, _proof = self._governance_context_for_export()
        if decision_mode != "decision_grade":
            prefix = "DEMO" if self._is_demo_run() else "EXPLORATORY"
            return f"{prefix}_{base}"
        return base

    def _update_audit_label(self) -> None:
        try:
            audit = getattr(self, "_audit", None)
        except Exception:
            audit = None
        if audit is None:
            return

        lines: list[str] = []
        if self._last_export_path:
            lines.append(f"lastExportPath={self._last_export_path}")
        else:
            lines.append("lastExportPath=—")

        doc = self._session.doc
        if doc is not None:
            lines.append(f"locus={self._format_locus(doc)}")
        audit.setText("\n".join(lines).strip() or "—")
        if getattr(self, "_audit_toggle", None):
            self._audit_toggle.setText("Audit ▾" if self._audit_box.isVisible() else "Audit ▸")

    def _short_receipts_text(self) -> str:
        full = self._session.receipts_text()
        short: list[str] = []
        for line in full.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                v_stripped = v.strip()
                is_hexish = len(v_stripped) > 16 and all(c in "0123456789abcdefABCDEF" for c in v_stripped)
                if is_hexish:
                    v = f"{v_stripped[:12]}…"
                short.append(f"{k}={v}")
            else:
                short.append(line)
        return "\n".join(short)

    def _update_receipts_label(self) -> None:
        try:
            target = getattr(self, "_receipts", None)
        except Exception:
            target = None
        if target is None:
            return
        target.setText(self._short_receipts_text())

    def _governance_context_for_export(self) -> tuple[str, str, Mapping[str, Any] | None]:
        requested = "filter_only"
        eligible = False
        effective = "filter_only"
        proof = None

        run = None
        try:
            runs = getattr(self._session_model, "runs", None)
            if isinstance(runs, list) and runs:
                run = runs[-1]
        except Exception:
            run = None

        meta = getattr(run, "metadata", None) if run is not None else None
        artifact = meta.get("run_artifact") if isinstance(meta, Mapping) else None
        summary = meta.get("run_summary") if isinstance(meta, Mapping) else None

        if isinstance(artifact, Mapping):
            requested = normalize_decision_mode(artifact.get("decision_mode"))
            eligible = bool(artifact.get("decision_mode_eligible"))
            effective = "decision_grade" if (requested == "decision_grade" and eligible) else "filter_only"
            proof = extract_decision_grade_proof_from_artifact(artifact)
            if proof is None:
                proof = extract_decision_grade_proof_from_summary(summary if isinstance(summary, Mapping) else None)
        elif isinstance(summary, Mapping):
            requested = normalize_decision_mode(summary.get("decision_mode_requested"))
            effective = normalize_decision_mode(summary.get("decision_mode"))
            eligible = bool(effective == "decision_grade")
            proof = extract_decision_grade_proof_from_summary(summary)

        decision_mode = effective
        interpretation = interpretation_for_mode(decision_mode)
        if decision_mode != "decision_grade":
            proof = None
        _ = requested, eligible  # kept for potential future receipts
        return decision_mode, interpretation, proof

    def _sync_quantitative_policy_ui(self) -> None:
        """
        Enforce "no quantitative outputs" in non-decision-grade mode.

        Lightcone retains internal floats for rendering, but UI strings/exports must not
        emit probability-shaped values unless decision grade is enabled.
        """

        decision_mode, _interpretation, _proof = self._governance_context_for_export()
        allowed = bool(decision_mode == "decision_grade")
        if allowed == bool(getattr(self, "_quantitative_allowed", False)):
            return
        self._quantitative_allowed = allowed
        try:
            if hasattr(self, "_prob_slider") and self._prob_slider is not None:
                self._prob_slider.setVisible(bool(allowed))
                if not allowed:
                    self._prob_slider.setValue(0)
        except Exception:
            pass
        try:
            if hasattr(self, "_prob_label") and self._prob_label is not None:
                self._prob_label.setVisible(bool(allowed))
        except Exception:
            pass
        try:
            if hasattr(self, "_inspector") and self._inspector is not None:
                self._inspector.set_quantitative_allowed(bool(allowed))
        except Exception:
            pass
        try:
            if self._last_sel is not None:
                self._apply_selection(self._last_sel)
        except Exception:
            pass

    def _governance_export_metadata_json(self) -> str | None:
        decision_mode, interpretation, proof = self._governance_context_for_export()
        is_demo = False
        try:
            is_demo = bool(self._is_demo_run())
        except Exception:
            is_demo = False
        payload = build_governance_provenance(
            decision_mode=decision_mode,
            is_demo=is_demo,
            interpretation=interpretation,
            decision_grade_proof=(dict(proof) if isinstance(proof, Mapping) else None),
        )
        try:
            return json.dumps(payload, sort_keys=True)
        except Exception:
            return None

    def _apply_watermark(self, image: QImage, *, wm_text: str, wm_lines: Sequence[str]) -> QImage:
        """Apply a visible watermark (used for governance stamping)."""
        try:
            w = int(image.width())
            h = int(image.height())
        except Exception:
            return image
        if w <= 0 or h <= 0:
            return image
        if not wm_text and not wm_lines:
            return image

        img = QImage(image)
        painter = QPainter(img)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.TextAntialiasing, True)
        try:
            painter.save()
            painter.setOpacity(0.08)
            font = QFont()
            font.setBold(True)
            font.setPixelSize(max(18, int(min(w, h) * 0.12)))
            painter.setFont(font)
            painter.setPen(QPen(Qt.white))
            painter.translate(w / 2.0, h / 2.0)
            painter.rotate(-30.0)
            painter.drawText(QRectF(-w, -h, w * 2.0, h * 2.0), Qt.AlignCenter, wm_text)
            painter.restore()
        except Exception:
            try:
                painter.restore()
            except Exception:
                pass

        wm_lines_list = [str(line) for line in wm_lines if str(line).strip()]
        if wm_lines_list:
            try:
                painter.save()
                painter.setOpacity(0.70)
                font = QFont()
                font.setPixelSize(max(10, int(min(w, h) * 0.022)))
                painter.setFont(font)
                painter.setPen(QPen(Qt.white))
                margin = max(8, int(min(w, h) * 0.02))
                painter.drawText(
                    QRect(margin, margin, max(1, w - 2 * margin), max(1, h - 2 * margin)),
                    Qt.AlignLeft | Qt.AlignBottom,
                    "\n".join(wm_lines_list),
                )
                painter.restore()
            except Exception:
                try:
                    painter.restore()
                except Exception:
                    pass

        painter.end()
        return img

    def _watermark_export_image(self, image: QImage) -> QImage:
        """Apply a governance watermark to exported images (visible, cropping-resistant)."""
        decision_mode, interpretation, proof = self._governance_context_for_export()
        wm_text = export_watermark_label(decision_mode=decision_mode, is_demo=self._is_demo_run())
        wm_lines = governance_stamp_lines(
            decision_mode=decision_mode,
            interpretation=interpretation,
            decision_grade_proof=proof if isinstance(proof, Mapping) else None,
        )
        return self._apply_watermark(image, wm_text=str(wm_text), wm_lines=[str(line) for line in wm_lines])

    def _rgba_bytes_from_qimage(self, image: QImage) -> bytes:
        img = image.convertToFormat(QImage.Format_RGBA8888)
        stride = int(img.bytesPerLine())
        w = int(img.width())
        h = int(img.height())
        want_stride = w * 4
        buf = img.bits()
        buf.setsize(int(stride * h))
        raw = bytes(buf)
        if stride == want_stride:
            return raw
        out = bytearray(want_stride * h)
        for y in range(h):
            start = y * stride
            out[y * want_stride : (y + 1) * want_stride] = raw[start : start + want_stride]
        return bytes(out)

    def _png_bytes_for_rgba(
        self,
        *,
        doc: LightconeDocument,
        rgba: bytes,
        width: int,
        height: int,
        phase: float,
        backend: str,
        geometry_sha256: str | None,
    ) -> bytes:
        rg = doc.render_golden
        assert rg is not None
        settings = render_settings_payload(rg)
        settings["phase"] = float(phase)
        settings_sha = sha256_hex(
            json.dumps(settings, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        )
        raw_rgba_sha = sha256_hex(rgba)
        rgba_img = _rgba_to_qimage(rgba, width=int(width), height=int(height))
        rgba_wm_img = self._watermark_export_image(rgba_img)
        rgba_wm = self._rgba_bytes_from_qimage(rgba_wm_img)
        rgba_sha = sha256_hex(rgba_wm)
        text = build_lightcone_png_text(
            doc,
            rg,
            rgba_sha256=rgba_sha,
            settings_sha256=settings_sha,
            geometry_sha256=geometry_sha256,
            settings=settings,
            extra={"backend": str(backend), "rawRgbaSha256": raw_rgba_sha, "watermarkApplied": True},
        )
        gov_json = self._governance_export_metadata_json()
        if gov_json:
            text = dict(text)
            text["helix_governance"] = gov_json
        return encode_png_rgba8(width=int(width), height=int(height), rgba=rgba_wm, text=text)

    def _toggle_receipts(self) -> None:
        box = getattr(self, "_receipts_box", None)
        if box is None:
            return
        box.setVisible(bool(self._receipts_toggle.isChecked()))
        self._receipts_toggle.setText("Receipts ▾" if box.isVisible() else "Receipts ▸")

    def _toggle_audit(self) -> None:
        box = getattr(self, "_audit_box", None)
        if box is None:
            return
        box.setVisible(bool(self._audit_toggle.isChecked()))
        self._audit_toggle.setText("Audit ▾" if box.isVisible() else "Audit ▸")

    def _copy_receipts(self) -> None:
        try:
            text = self._session.receipts_text()
        except Exception:
            text = ""
        if not text:
            return
        try:
            QApplication.clipboard().setText(text)
            QToolTip.showText(QCursor.pos(), "Receipts copied", self)
        except Exception:
            pass

    def _on_export_png_screenshot(self) -> None:
        doc = self._require_document()
        if doc is None:
            return
        if not self._prompt_export_allowed("Export Lightcone screenshot"):
            return
        base = self._default_export_basename()
        path = self._save_path(
            title="Export Lightcone screenshot",
            default_name=f"{base}.png",
            filter_text="PNG image (*.png)",
        )
        if not path:
            return
        try:
            rgba, w, h = self._session.render_rgba()
            png = self._png_bytes_for_rgba(
                doc=doc,
                rgba=rgba,
                width=w,
                height=h,
                phase=float(self._session.phase),
                backend=str(self._session.backend),
                geometry_sha256=getattr(self._session, "_cached_geom_sha", None),
            )
            self._write_bytes(path, png)
            if write_image_provenance_sidecars_enabled():
                try:
                    gov_obj = None
                    gov_json = self._governance_export_metadata_json()
                    if gov_json:
                        try:
                            gov_obj = json.loads(gov_json)
                        except Exception:
                            gov_obj = None
                    sidecar_payload = build_png_provenance_v1(
                        png_path=Path(path).expanduser(),
                        artifact_surface="lightcone",
                        run_id=self._export_run_id(),
                        governance=gov_obj,
                        limitations_stamp=limitations_stamp(),
                        embedded_png_text_chunks_present=True,
                    )
                    write_png_provenance_sidecar(Path(path).expanduser(), sidecar_payload)
                except Exception as exc:
                    raise RuntimeError(f"failed to write PNG provenance sidecar: {exc}") from exc
            try:
                self.exportCompleted.emit("png_screenshot", str(path))
            except Exception:
                pass
            self._toast_export_result(f"Exported screenshot to {path}", path=path, kind="info")
        except Exception as exc:
            hint = self._export_hint_for_exception(exc)
            msg = f"Screenshot export failed: {exc}"
            if hint:
                msg = f"{msg}\n{hint}"
            self._toast_export_result(msg, path=None, kind="error")

    def _on_export_png_cpu(self) -> None:
        doc = self._require_document()
        if doc is None:
            return
        if not self._prompt_export_allowed("Export canonical CPU render"):
            return
        rg = doc.render_golden
        assert rg is not None
        base = self._default_export_basename()
        path = self._save_path(
            title="Export canonical CPU render",
            default_name=f"{base}_cpu.png",
            filter_text="PNG image (*.png)",
        )
        if not path:
            return
        try:
            phase = float(self._session.phase)
            rgba = render_lightcone_rgba(
                doc,
                width=int(rg.width),
                height=int(rg.height),
                phase=float(phase),
                background=rg.background,
                camera_pan_px=self._session._camera_pan_px or rg.camera.pan_px,
                camera_zoom=self._session._camera_zoom or rg.camera.zoom,
            )
            png = self._png_bytes_for_rgba(
                doc=doc,
                rgba=rgba,
                width=int(rg.width),
                height=int(rg.height),
                phase=float(phase),
                backend="cpu",
                geometry_sha256=getattr(self._session, "_cached_geom_sha", None),
            )
            self._write_bytes(path, png)
            if write_image_provenance_sidecars_enabled():
                try:
                    gov_obj = None
                    gov_json = self._governance_export_metadata_json()
                    if gov_json:
                        try:
                            gov_obj = json.loads(gov_json)
                        except Exception:
                            gov_obj = None
                    sidecar_payload = build_png_provenance_v1(
                        png_path=Path(path).expanduser(),
                        artifact_surface="lightcone",
                        run_id=self._export_run_id(),
                        governance=gov_obj,
                        limitations_stamp=limitations_stamp(),
                        embedded_png_text_chunks_present=True,
                    )
                    write_png_provenance_sidecar(Path(path).expanduser(), sidecar_payload)
                except Exception as exc:
                    raise RuntimeError(f"failed to write PNG provenance sidecar: {exc}") from exc
            try:
                self.exportCompleted.emit("png_cpu", str(path))
            except Exception:
                pass
            self._toast_export_result(f"Exported canonical CPU render to {path}", path=path, kind="info")
        except Exception as exc:
            hint = self._export_hint_for_exception(exc)
            msg = f"CPU render export failed: {exc}"
            if hint:
                msg = f"{msg}\n{hint}"
            self._toast_export_result(msg, path=None, kind="error")

    def _on_export_fixture_snapshot(self) -> None:
        doc = self._require_document()
        if doc is None:
            return
        if not self._prompt_export_allowed("Export Lightcone fixture snapshot"):
            return
        base = self._default_export_basename()
        path = self._save_path(
            title="Export Lightcone fixture snapshot",
            default_name=f"{base}_fixture_snapshot.v0.1.json",
            filter_text="JSON (*.json)",
        )
        if not path:
            return
        try:
            rg = doc.render_golden
            assert rg is not None
            phase = float(self._session.phase)

            settings = render_settings_payload(rg)
            settings["phase"] = float(phase)
            settings_sha = sha256_hex(
                json.dumps(settings, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
            )
            geometry_sha = str(getattr(self._session, "_cached_geom_sha", "") or "")

            rgba_cpu = render_lightcone_rgba(
                doc,
                width=int(rg.width),
                height=int(rg.height),
                phase=float(phase),
                background=rg.background,
                camera_pan_px=self._session._camera_pan_px or rg.camera.pan_px,
                camera_zoom=self._session._camera_zoom or rg.camera.zoom,
            )
            rgba_cpu_sha = sha256_hex(rgba_cpu)

            rg_override: dict[str, Any] = dict(settings)
            rg_override["settingsSha256"] = str(settings_sha)
            rg_override["rgbaSha256"] = str(rgba_cpu_sha)
            if geometry_sha:
                rg_override["geometrySha256"] = str(geometry_sha)
            if rg.tolerance is not None:
                rg_override["tolerance"] = {
                    "maxAbsDiff": int(rg.tolerance.max_abs_diff),
                    "meanAbsDiff": float(rg.tolerance.mean_abs_diff),
                }

            payload = lightcone_document_to_payload(doc, render_golden_override=rg_override)
            self._write_bytes(path, stable_json_bytes(payload))
            try:
                self.exportCompleted.emit("fixture_snapshot", str(path))
            except Exception:
                pass
            self._toast_export_result(f"Exported fixture snapshot to {path}", path=path, kind="info")
        except Exception as exc:
            hint = self._export_hint_for_exception(exc)
            msg = f"Fixture snapshot export failed: {exc}"
            if hint:
                msg = f"{msg}\n{hint}"
            self._toast_export_result(msg, path=None, kind="error")

    def _on_export_audit_pack(self) -> None:
        doc = self._require_document()
        if doc is None:
            return
        if not self._prompt_export_allowed("Export Lightcone audit pack"):
            return
        rg = doc.render_golden
        assert rg is not None
        base = self._default_export_basename()
        path = self._save_path(
            title="Export Lightcone audit pack",
            default_name=f"{base}.zip",
            filter_text="Zip archive (*.zip)",
        )
        if not path:
            return

        include_gpu = bool(self._audit_opt_include_gpu.isChecked())
        include_perf = bool(self._audit_opt_include_perf.isChecked())
        include_selection = bool(self._audit_opt_include_selection.isChecked())

        files: dict[str, bytes] = {}
        receipts: dict[str, Any] = {}
        decision_mode, interpretation, proof = self._governance_context_for_export()
        gov_lines = governance_stamp_lines(
            decision_mode=decision_mode,
            interpretation=interpretation,
            decision_grade_proof=proof if isinstance(proof, Mapping) else None,
        )
        gov_payload = {
            "schema": "helix.governance.lightcone_audit_pack/v1",
            "decision_mode": decision_mode,
            "interpretation": interpretation,
            "decision_grade_proof": (dict(proof) if isinstance(proof, Mapping) else None),
            "stamp_lines": [str(line) for line in gov_lines],
        }
        png_gov_obj = None
        try:
            gov_json = self._governance_export_metadata_json()
            if gov_json:
                png_gov_obj = json.loads(gov_json)
        except Exception:
            png_gov_obj = None
        png_stamp = limitations_stamp()
        png_run_id = self._export_run_id()
        try:
            files["governance/governance.json"] = stable_json_bytes(gov_payload)
            txt = "Helix Lightcone audit pack governance stamp\n" + "\n".join([str(line) for line in gov_lines]) + "\n"
            files["governance/governance.txt"] = txt.encode("utf-8")
        except Exception:
            pass

        receipts["specVersion"] = str(doc.spec_version)
        receipts["fixtureId"] = str(doc.id)
        receipts["backend"] = str(self._session.backend)
        receipts["phase"] = float(self._session.phase)
        receipts["decisionMode"] = str(decision_mode)
        receipts["interpretation"] = str(interpretation)
        try:
            gpu_info = self._session.gpu_info
            if gpu_info:
                receipts["gpuPreflight"] = dict(gpu_info)
        except Exception:
            pass

        spec_payload: dict[str, Any] | None = None
        try:
            spec_payload = experiment_spec_to_dict(getattr(self._session.state, "experiment_spec", None))
            files["experiment_spec.v1.json"] = experiment_spec_json_bytes(spec_payload)
            receipts["experimentSpecSha256"] = experiment_spec_sha256(spec_payload)
        except Exception:
            pass

        try:
            intent_payload = experiment_intent_spec_to_dict(getattr(self._session.state, "experiment_intent_spec", None))
            files["experiment_intent_spec.v1.json"] = experiment_intent_spec_json_bytes(intent_payload)
            receipts["experimentIntentSpecSha256"] = experiment_intent_spec_sha256(intent_payload)
        except Exception:
            pass

        try:
            plan_payload = edit_plan_to_dict(getattr(self._session.state, "edit_plan", None))
            files["edit_plan.v1.json"] = edit_plan_json_bytes(plan_payload)
            receipts["editPlanSha256"] = edit_plan_sha256(plan_payload)
        except Exception:
            pass

        try:
            raw_results = getattr(self._session_model.state, "results_records", [])
            results_entries: list[dict[str, Any]] = []
            if isinstance(raw_results, list):
                for rec in raw_results:
                    if not isinstance(rec, Mapping):
                        continue
                    results_id = str(rec.get("resultsId") or "").strip()
                    if not results_id:
                        continue
                    safe_id = sanitize_results_id(results_id)
                    file_name = f"results_record.{safe_id}.json"
                    data = results_record_json_bytes(rec)
                    files[file_name] = data
                    results_entries.append(
                        {
                            "resultsId": results_id,
                            "sha256": sha256_hex(data),
                            "path": file_name,
                        }
                    )
            if results_entries:
                results_entries.sort(key=lambda r: str(r.get("resultsId") or ""))
                receipts["resultsRecordSha256"] = results_entries
        except Exception:
            pass

        try:
            raw_previews = getattr(self._session_model.state, "calibration_previews", [])
            preview = None
            if isinstance(raw_previews, list) and raw_previews:
                preview = raw_previews[-1]
            if isinstance(preview, Mapping):
                preview_bytes = calibration_preview_json_bytes(preview)
                files["calibration_preview.v1.json"] = preview_bytes
                receipts["calibrationPreviewSha256"] = sha256_hex(preview_bytes)
        except Exception:
            pass

        try:
            raw_previews = getattr(self._session_model.state, "base_position_calibration_previews", [])
            preview = None
            if isinstance(raw_previews, list) and raw_previews:
                preview = raw_previews[-1]
            if isinstance(preview, Mapping):
                preview_bytes = base_position_calibration_preview_json_bytes(preview)
                files["base_position_calibration_preview.v1.json"] = preview_bytes
                receipts["basePositionCalibrationPreviewSha256"] = sha256_hex(preview_bytes)
        except Exception:
            pass

        try:
            profile = None
            cfg = getattr(self._session_model.state, "config", {})
            base_cfg = cfg.get("base_position_calibration") if isinstance(cfg, Mapping) else {}
            profile_id = str(base_cfg.get("profileId") or "") if isinstance(base_cfg, Mapping) else ""
            raw_profiles = getattr(self._session_model.state, "base_position_calibration_profiles", [])
            if isinstance(raw_profiles, list) and raw_profiles:
                if profile_id:
                    for entry in raw_profiles:
                        if isinstance(entry, Mapping) and str(entry.get("profileId") or "") == profile_id:
                            profile = entry
                            break
                if profile is None:
                    profile = raw_profiles[-1]
            if isinstance(profile, Mapping):
                profile_bytes = base_position_calibration_profile_json_bytes(profile)
                files["base_position_calibration_profile.v1.json"] = profile_bytes
                receipts["basePositionCalibrationProfileSha256"] = sha256_hex(profile_bytes)
        except Exception:
            pass

        try:
            raw_previews = getattr(self._session_model.state, "base_position_calibration_previews", [])
            preview = None
            if isinstance(raw_previews, list) and raw_previews:
                preview = raw_previews[-1]
            if isinstance(preview, Mapping):
                results_records = getattr(self._session_model.state, "results_records", [])
                eval_payload = build_base_position_calibration_eval(
                    preview,
                    results_records=results_records if isinstance(results_records, list) else None,
                )
                eval_bytes = base_position_calibration_eval_json_bytes(eval_payload)
                files["base_position_calibration_eval.v1.json"] = eval_bytes
                receipts["basePositionCalibrationEvalSha256"] = sha256_hex(eval_bytes)
        except Exception:
            pass

        try:
            suggested = None
            cfg = getattr(self._session_model.state, "config", {})
            outcome_cfg = cfg.get("outcome_model") if isinstance(cfg, Mapping) else {}
            overrides = outcome_cfg.get("overrides") if isinstance(outcome_cfg, Mapping) else {}
            suggested_id = str(overrides.get("suggestedId") or "") if isinstance(overrides, Mapping) else ""
            if suggested_id:
                raw_history = getattr(self._session_model.state, "suggested_priors_history", [])
                if isinstance(raw_history, list):
                    for entry in raw_history:
                        if not isinstance(entry, Mapping):
                            continue
                        if str(entry.get("suggestedId") or "") != suggested_id:
                            continue
                        raw = entry.get("suggestedJson")
                        if isinstance(raw, str) and raw.strip():
                            try:
                                suggested = json.loads(raw)
                            except Exception:
                                suggested = None
                        break
                if suggested is None:
                    raw_suggested = getattr(self._session_model.state, "suggested_priors", [])
                    if isinstance(raw_suggested, list):
                        for entry in raw_suggested:
                            if isinstance(entry, Mapping) and str(entry.get("suggestedId") or "") == suggested_id:
                                suggested = entry
                                break
            if isinstance(suggested, Mapping):
                suggested_bytes = suggested_priors_json_bytes(suggested)
                files["suggested_priors.v1.json"] = suggested_bytes
                receipts["suggestedPriorsSha256"] = suggested_priors_sha256(suggested)
        except Exception:
            pass

        report_payload: dict[str, Any] | None = None
        clone_plan_payload: dict[str, Any] | None = None
        validation_plan_payload: dict[str, Any] | None = None
        primer_plan_payload: dict[str, Any] | None = None

        try:
            report = compute_outcomes_for_current_plan(self._session_model, edit_plan=None, reference_context=None)
            report_bytes = outcome_report_json_bytes(report)
            files["outcome_report.v1.json"] = report_bytes
            report_sha = sha256_hex(report_bytes)
            receipts["outcomeReportSha256"] = report_sha
            try:
                report_payload = outcome_report_to_dict(report)
                clone_plan = build_clone_plan(report_payload, outcome_report_sha256=report_sha)
                clone_bytes = clone_plan_json_bytes(clone_plan)
                files["clone_plan.v1.json"] = clone_bytes
                receipts["clonePlanSha256"] = clone_plan_sha256(clone_plan)
                clone_plan_payload = clone_plan
            except Exception:
                pass
        except Exception:
            pass

        try:
            off_report = compute_offtargets_for_session(self._session_model)
            off_bytes = offtarget_report_json_bytes(off_report)
            files["offtarget_report.v1.json"] = off_bytes
            receipts["offTargetReportSha256"] = sha256_hex(off_bytes)
            try:
                off_payload = json.loads(off_bytes.decode("utf-8"))
            except Exception:
                off_payload = {}
            try:
                params_payload = off_payload.get("params", {}) if isinstance(off_payload, Mapping) else {}
                pack_id = params_payload.get("rloks_pack_id") or params_payload.get("rloksPackId")
                pack_fp = params_payload.get("rloks_pack_fingerprint") or params_payload.get("rloksPackFingerprint")
                if isinstance(pack_id, str) and pack_id.strip():
                    receipts["offTargetPackId"] = str(pack_id)
                if isinstance(pack_fp, str) and pack_fp.strip():
                    receipts["offTargetPackFingerprint"] = str(pack_fp)
            except Exception:
                pass
            try:
                genome_sequences = getattr(self._session_model.state, "genome", None)
                genome_sequences = getattr(genome_sequences, "sequences", None)
            except Exception:
                genome_sequences = None
            guide = {}
            try:
                cfg = self._session_model.state.config
                if isinstance(cfg, Mapping):
                    guide = cfg.get("guide") or {}
            except Exception:
                guide = {}
            plan = build_validation_plan(
                off_payload,
                off_target_report_sha256=str(receipts.get("offTargetReportSha256") or ""),
                genome_sequences=genome_sequences if isinstance(genome_sequences, Mapping) else None,
                experiment_spec=spec_payload if isinstance(spec_payload, Mapping) else {},
                guide=guide,
                edit_plan=getattr(self._session_model.state, "edit_plan", {}) if self._session_model else None,
                outcome_report=report_payload if isinstance(report_payload, Mapping) else None,
            )
            plan_bytes = validation_plan_json_bytes(plan)
            files["validation_plan.v1.json"] = plan_bytes
            validation_sha = validation_plan_sha256(plan)
            receipts["validationPlanSha256"] = validation_sha
            validation_plan_payload = plan
            primer_plan = build_primer_plan(
                plan,
                genome_sequences=genome_sequences if isinstance(genome_sequences, Mapping) else None,
                validation_plan_sha256=validation_sha,
                experiment_spec=spec_payload if isinstance(spec_payload, Mapping) else {},
                guide=guide,
            )
            primer_bytes = primer_plan_json_bytes(primer_plan)
            files["primer_plan.v1.json"] = primer_bytes
            receipts["primerPlanSha256"] = primer_plan_sha256(primer_plan)
            primer_plan_payload = primer_plan

            try:
                if report_payload is not None and clone_plan_payload is not None:
                    assay_plan = build_assay_plan(
                        report_payload,
                        validation_plan_payload or {},
                        primer_plan_payload or {},
                        clone_plan_payload,
                        experiment_spec=spec_payload if isinstance(spec_payload, Mapping) else {},
                    )
                    assay_bytes = assay_plan_json_bytes(assay_plan)
                    files["assay_plan.v1.json"] = assay_bytes
                    receipts["assayPlanSha256"] = assay_plan_sha256(assay_plan)
            except Exception:
                pass
        except Exception:
            pass

        # Canonical CPU render at the current phase.
        phase = float(self._session.phase)
        settings = render_settings_payload(rg)
        settings["phase"] = float(phase)
        settings_sha = sha256_hex(json.dumps(settings, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))
        receipts["settingsSha256"] = str(settings_sha)
        receipts["geometrySha256"] = str(getattr(self._session, "_cached_geom_sha", "") or "")

        # Fixture snapshot for this export (phase + updated settings/geometry receipts).
        try:
            rg_override_pre: dict[str, Any] = dict(settings)
            rg_override_pre["settingsSha256"] = str(settings_sha)
            rg_override_pre["rgbaSha256"] = str(getattr(rg, "rgba_sha256", "") or "")
            if str(receipts["geometrySha256"]):
                rg_override_pre["geometrySha256"] = str(receipts["geometrySha256"])
            if rg.tolerance is not None:
                rg_override_pre["tolerance"] = {
                    "maxAbsDiff": int(rg.tolerance.max_abs_diff),
                    "meanAbsDiff": float(rg.tolerance.mean_abs_diff),
                }
            payload_pre = lightcone_document_to_payload(doc, render_golden_override=rg_override_pre)
            files["fixture_snapshot.v0.1.json"] = stable_json_bytes(payload_pre)
        except Exception:
            files["fixture_snapshot.v0.1.json"] = b"{}\n"

        try:
            rgba_cpu = render_lightcone_rgba(
                doc,
                width=int(rg.width),
                height=int(rg.height),
                phase=float(phase),
                background=rg.background,
                camera_pan_px=self._session._camera_pan_px or rg.camera.pan_px,
                camera_zoom=self._session._camera_zoom or rg.camera.zoom,
            )
            png_cpu = self._png_bytes_for_rgba(
                doc=doc,
                rgba=rgba_cpu,
                width=int(rg.width),
                height=int(rg.height),
                phase=float(phase),
                backend="cpu",
                geometry_sha256=str(receipts["geometrySha256"]) or None,
            )
            files["render_cpu.png"] = png_cpu
            if write_image_provenance_sidecars_enabled():
                cpu_sidecar = build_png_provenance_v1(
                    png_path="render_cpu.png",
                    png_bytes=png_cpu,
                    artifact_surface="lightcone",
                    run_id=png_run_id,
                    governance=png_gov_obj,
                    limitations_stamp=png_stamp,
                    embedded_png_text_chunks_present=True,
                )
                files["render_cpu.png.provenance.json"] = stable_json_bytes(cpu_sidecar)
            rgba_cpu_sha = sha256_hex(rgba_cpu)

            # Fixture snapshot for this export (phase + updated receipts).
            rg_override: dict[str, Any] = dict(settings)
            rg_override["settingsSha256"] = str(settings_sha)
            rg_override["rgbaSha256"] = str(rgba_cpu_sha)
            if str(receipts["geometrySha256"]):
                rg_override["geometrySha256"] = str(receipts["geometrySha256"])
            if rg.tolerance is not None:
                rg_override["tolerance"] = {
                    "maxAbsDiff": int(rg.tolerance.max_abs_diff),
                    "meanAbsDiff": float(rg.tolerance.mean_abs_diff),
                }
            payload = lightcone_document_to_payload(doc, render_golden_override=rg_override)
            files["fixture_snapshot.v0.1.json"] = stable_json_bytes(payload)
        except Exception:
            pass

        if include_gpu and self._session.backend == "gpu":
            try:
                rgba_gpu, w, h = self._session.render_rgba()
                png_gpu = self._png_bytes_for_rgba(
                    doc=doc,
                    rgba=rgba_gpu,
                    width=w,
                    height=h,
                    phase=float(phase),
                    backend="gpu",
                    geometry_sha256=str(receipts["geometrySha256"]) or None,
                )
                files["render_gpu.png"] = png_gpu
                if write_image_provenance_sidecars_enabled():
                    gpu_sidecar = build_png_provenance_v1(
                        png_path="render_gpu.png",
                        png_bytes=png_gpu,
                        artifact_surface="lightcone",
                        run_id=png_run_id,
                        governance=png_gov_obj,
                        limitations_stamp=png_stamp,
                        embedded_png_text_chunks_present=True,
                    )
                    files["render_gpu.png.provenance.json"] = stable_json_bytes(gpu_sidecar)
                receipts["gpuShaderSha256"] = str(lightcone_gpu_shader_sha256())
                receipts["gpuBackend"] = dict(lightcone_gpu_backend_receipts())
            except Exception:
                pass

        if include_perf:
            try:
                perf_path = Path("artifacts/lightcone/perf_receipt.json")
                if perf_path.exists():
                    files["perf_receipt.json"] = perf_path.read_bytes()
            except Exception:
                pass

        if include_selection and self._last_sel is not None:
            try:
                sel = self._last_sel
                decision_mode, _interp, _proof = self._governance_context_for_export()
                quantitative_allowed = bool(decision_mode == "decision_grade")

                # Locus context (match the v0.1 fixture contract keys).
                loc = doc.locus
                locus_payload = {
                    "contig": str(loc.contig),
                    "position": int(loc.position),
                    "strand": str(loc.strand),
                    "windowStart": int(loc.window_start),
                    "windowEnd": int(loc.window_end),
                }

                ref_sha = None
                try:
                    if doc.reference_window is not None:
                        if doc.reference_window.checksum:
                            ref_sha = str(doc.reference_window.checksum)
                        elif doc.reference_window.sequence:
                            ref_sha = hashlib.sha256(str(doc.reference_window.sequence).encode("utf-8")).hexdigest()
                except Exception:
                    ref_sha = None

                sel_payload = {
                    "selectionId": int(sel.selection_id),
                    "kind": str(sel.kind),
                    "ghostId": (str(sel.ghost_id) if sel.ghost_id is not None else None),
                    "probabilityMass": (float(sel.probability_mass) if quantitative_allowed else None),
                    "dominantOutcomeId": (str(sel.dominant_outcome_id) if sel.dominant_outcome_id is not None else None),
                    "mechanismTags": [str(t) for t in sel.mechanism_tags],
                }

                outcomes_payload: list[dict[str, Any]] = []
                for oid, p, tags in self._session.outcomes_for_selection(sel)[:256]:
                    allele_ops_payload = []
                    payload = self._session.outcome_payload(str(oid))
                    if payload is not None:
                        _prob, _tags2, ops = payload
                        allele_ops_payload = list(ops)
                    outcomes_payload.append(
                        {
                            "id": str(oid),
                            "probability": float(p),
                            "mechanismTags": list(tags),
                            "alleleOps": allele_ops_payload,
                        }
                    )

                dump = build_selection_dump_payload_v1(
                    spec_version=str(doc.spec_version),
                    fixture_id=str(doc.id),
                    locus=locus_payload,
                    reference_window_sha256=ref_sha,
                    selection=sel_payload,
                    outcomes=outcomes_payload,
                    quantitative_allowed=quantitative_allowed,
                )
                files["selection_dump.json"] = stable_json_bytes(dump)
            except Exception:
                pass

        try:
            pack_dirname = Path(path).stem or base
        except Exception:
            pack_dirname = base
        try:
            zip_bytes = build_audit_pack_zip_bytes(pack_dirname=pack_dirname, files=files, receipts=receipts)
            self._write_bytes(path, zip_bytes)
            try:
                self.exportCompleted.emit("audit_pack", str(path))
            except Exception:
                pass
            self._toast_export_result(f"Exported audit pack to {path}", path=path, kind="info")
        except Exception as exc:
            hint = self._export_hint_for_exception(exc)
            msg = f"Audit pack export failed: {exc}"
            if hint:
                msg = f"{msg}\n{hint}"
            self._toast_export_result(msg, path=None, kind="error")

    def _on_export_clip(self) -> None:
        doc = self._require_document()
        if doc is None:
            return
        if not self._prompt_export_allowed("Export Lightcone clip"):
            return
        rg = doc.render_golden
        assert rg is not None

        base = self._default_export_basename()
        default_name = f"{base}_clip.gif"
        path = self._save_path(
            title="Export Lightcone clip",
            default_name=default_name,
            filter_text="GIF animation (*.gif);;MP4 video (*.mp4)",
        )
        if not path:
            return
        out = Path(path).expanduser()

        fps = int(os.getenv("HELIX_LIGHTCONE_CLIP_FPS", "24"))
        fps = max(1, min(60, int(fps)))
        try:
            duration_s = float(os.getenv("HELIX_LIGHTCONE_CLIP_DURATION_S", "3.0"))
        except Exception:
            duration_s = 3.0
        duration_s = max(0.25, min(10.0, float(duration_s)))
        n_frames = max(2, int(round(duration_s * float(fps))) + 1)

        start_phase = 0.0
        end_phase = 1.0
        phases = [start_phase + (end_phase - start_phase) * (i / float(n_frames - 1)) for i in range(n_frames)]

        prev_phase = float(self._session.phase)

        decision_mode, interpretation, proof = self._governance_context_for_export()
        wm_text = export_watermark_label(decision_mode=decision_mode, is_demo=self._is_demo_run())
        wm_lines = governance_stamp_lines(
            decision_mode=decision_mode,
            interpretation=interpretation,
            decision_grade_proof=proof if isinstance(proof, Mapping) else None,
        )
        wm_lines_list = [str(line) for line in wm_lines if str(line).strip()]

        def _watermark_rgb_frame(frame: np.ndarray) -> np.ndarray:
            if frame.ndim != 3 or int(frame.shape[2]) != 3:
                return frame
            h, w = int(frame.shape[0]), int(frame.shape[1])
            if h <= 0 or w <= 0:
                return frame
            try:
                rgb_bytes = np.ascontiguousarray(frame).tobytes()
                img = QImage(rgb_bytes, w, h, w * 3, QImage.Format_RGB888).copy()
                wm_img = self._apply_watermark(img, wm_text=str(wm_text), wm_lines=wm_lines_list)
                out = wm_img.convertToFormat(QImage.Format_RGB888)
                stride = int(out.bytesPerLine())
                buf = out.bits()
                buf.setsize(int(stride * h))
                raw = bytes(buf)
                row_len = w * 3
                if stride != row_len:
                    tmp = bytearray(row_len * h)
                    for y in range(h):
                        tmp[y * row_len : (y + 1) * row_len] = raw[y * stride : y * stride + row_len]
                    raw = bytes(tmp)
                return np.frombuffer(raw, dtype=np.uint8).reshape((h, w, 3))
            except Exception:
                return frame

        def frames_rgb():
            for p in phases:
                self._session.set_phase(float(p))
                rgba, w, h = self._session.render_rgba()
                if len(rgba) != int(w) * int(h) * 4:
                    continue
                arr = np.frombuffer(rgba, dtype=np.uint8).reshape((int(h), int(w), 4))
                rgb = np.ascontiguousarray(arr[:, :, :3])
                yield _watermark_rgb_frame(rgb)

        try:
            out.parent.mkdir(parents=True, exist_ok=True)
            ext = out.suffix.lower()
            if ext == ".mp4":
                enc = detect_mp4_encoder()
                if enc is None:
                    raise RuntimeError("MP4 export requires ffmpeg (or imageio-ffmpeg).")
                mp4 = encode_mp4_bytes_ffmpeg(frames_rgb=frames_rgb(), fps=fps, encoder=enc)
                if not mp4:
                    raise RuntimeError("Failed to encode MP4 (no frames?)")
                out.write_bytes(mp4)
            else:
                gif = encode_gif_bytes(frames_rgb=frames_rgb(), fps=fps)
                out.write_bytes(gif)
            self._last_export_path = str(out)
            try:
                self.exportCompleted.emit("clip", str(out))
            except Exception:
                pass
            self._toast_export_result(f"Exported clip to {str(out)}", path=str(out), kind="info")
        except Exception as exc:
            hint = self._export_hint_for_exception(exc)
            msg = f"Clip export failed: {exc}"
            if hint:
                msg = f"{msg}\n{hint}"
            self._toast_export_result(msg, path=None, kind="error")
        finally:
            # Restore the UI phase and rerender.
            try:
                self._session.set_phase(float(prev_phase))
            except Exception:
                pass
            try:
                self._phase_slider.blockSignals(True)
                self._phase_slider.setValue(int(round(float(prev_phase) * 1000.0)))
                self._phase_slider.blockSignals(False)
            except Exception:
                pass
            try:
                self._render_timer.start(0)
            except Exception:
                pass

    def set_document(self, doc: LightconeDocument, *, phase: float | None = None, reset_navigation: bool = True) -> None:
        """Load an in-memory LightconeDocument (live Studio path).

        Fixtures remain an import path; Studio integration should prefer this method.
        """
        self._session.load_document(doc, phase=phase)
        self._session._is_live_doc = self._mode == "live"
        if reset_navigation:
            self._nav_stack.clear()
            self._active_ghost_id = None
            self._back_btn.setVisible(False)
        self._active_doc_id = str(doc.id)
        if self._mode == "live":
            try:
                setattr(doc, "_live_doc", True)
            except Exception:
                pass
        self._backend_label.setText(f"Backend: {self._session.backend}")
        self._bundling.setChecked(
            bool(self._session.doc and self._session.doc.render_golden and self._session.doc.render_golden.style.bundling.get("enabled", False))
        )
        self._phase_slider.blockSignals(True)
        self._phase_slider.setValue(int(round(self._session.phase * 1000.0)))
        self._phase_slider.blockSignals(False)
        self._update_locus_label()
        self._update_receipts_label()
        self._emit_locus_context_changed()
        self._render()
        self._session._id_dirty = True
        if doc.outcomes:
            self._clear_empty_state()
        else:
            self._show_empty_state("Run produced 0 outcomes", ["Outcome set is empty"], run=None)
        self._update_status_chip()

    def load_fixture(self, path: str | Path) -> None:
        self._mode = "fixture"
        self._source_live.setChecked(False)
        self._source_fixture.setChecked(True)
        self._source_btn.setText("Fixture")
        self._session.load_fixture(path)
        self._session._is_live_doc = False
        self._nav_stack.clear()
        self._active_ghost_id = None
        self._back_btn.setVisible(False)
        self._backend_label.setText(f"Backend: {self._session.backend}")
        self._bundling.setChecked(bool(self._session.doc and self._session.doc.render_golden and self._session.doc.render_golden.style.bundling.get("enabled", False)))
        self._phase_slider.blockSignals(True)
        self._phase_slider.setValue(int(round(self._session.phase * 1000.0)))
        self._phase_slider.blockSignals(False)
        self._update_locus_label()
        self._update_receipts_label()
        self._emit_locus_context_changed()
        self._render()
        self._session._id_dirty = True
        self._update_status_chip(extra="fixture loaded")

    def _on_load_clicked(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Load lightcone fixture", "", "Lightcone JSON (*.json)")
        if not path:
            return
        self.load_fixture(path)

    def _switch_mode(self, mode: str) -> None:
        mode = "live" if mode not in {"live", "fixture"} else mode
        if mode == self._mode and mode == "live":
            return
        self._mode = mode
        if mode == "live":
            self._source_btn.setText("Live")
            self._source_live.setChecked(True)
            self._source_fixture.setChecked(False)
            self._refresh_live_document(reason="mode-switch")
        else:
            self._source_btn.setText("Fixture")
            self._source_live.setChecked(False)
            self._source_fixture.setChecked(True)
            self._on_load_clicked()

    def _update_status_chip(self, extra: str | None = None) -> None:
        backend = self._session.backend
        state = "Live" if self._mode == "live" else "Fixture"
        if getattr(self, "_session", None) is not None and getattr(self._session, "_view_mode", "2d") == "3d":
            state = f"{state} · 3D"
        if extra:
            text = f"{state} · {extra}"
        elif self._mode == "live" and self._session_model is not None and self._session_model.runs:
            text = f"Live · run {self._session_model.runs[-1].run_id}"
        else:
            text = f"{state} · ready"
        self._status_chip.setText(text)
        if backend == "gpu":
            warn = " (software GL)" if self._session._is_software_renderer() else ""
            self._backend_label.setText(f"Backend: gpu{warn}")
        else:
            reason = self._session.gpu_reason or "cpu fallback"
            self._backend_label.setText(f"Backend: cpu ({reason})")
        try:
            self._sync_quantitative_policy_ui()
        except Exception:
            pass

    def _current_phase_clip(self) -> tuple[float, float]:
        if not self._slice_toggle.isChecked():
            return (0.0, 1.0)
        v = float(self._slice_slider.value()) / 1000.0
        span = float(getattr(self, "_slice_span", 0.15))
        lo = max(0.0, v - span * 0.5)
        hi = min(1.0, v + span * 0.5)
        return (lo, hi)

    def _active_filter_tags(self) -> set[str]:
        tags: set[str] = set()
        for k, btn in getattr(self, "_tag_buttons", {}).items():
            if btn.isChecked():
                tags.add(k.lower())
        return tags

    def _outcome_passes_filters(self, *, prob: float, tags: tuple[str, ...]) -> bool:
        if bool(getattr(self, "_quantitative_allowed", False)):
            min_p = float(getattr(self._prob_slider, "value", lambda: 0)()) / 100.0
            if prob < min_p:
                return False
        active_tags = self._active_filter_tags()
        if not active_tags:
            return True
        lower_tags = {t.lower() for t in tags}
        return any(t in lower_tags or any(t in lt for lt in lower_tags) for t in active_tags)

    def _selection_passes_filters(self, sel: LightconeSelection) -> bool:
        outcomes = self._session.outcomes_for_selection(sel)
        for _, p, tags in outcomes:
            if self._outcome_passes_filters(prob=p, tags=tags):
                return True
        return False

    def _on_filter_changed(self) -> None:
        # Re-apply filters to current selection and rerender overlays/list.
        if self._last_sel is not None and self._selection_passes_filters(self._last_sel):
            self._apply_selection(self._last_sel)
        else:
            self._outcomes_list.clear()
        self._mark_dirty()

    def _clear_empty_state(self) -> None:
        try:
            self._empty_overlay.clear()
        except Exception:
            pass

    def _show_empty_state(self, title: str, causes: list[str], *, run: RunModel | None = None) -> None:
        def _copy_bundle() -> None:
            bundle = {
                "title": title,
                "causes": causes,
                "timestamp": clock.unix_time_s(),
            }
            try:
                if run is not None:
                    bundle["run"] = {
                        "run_id": run.run_id,
                        "edit_type": run.edit_type,
                        "target_locus": run.target_locus,
                        "sequence_sha256": hashlib.sha256(run.sequence.encode("utf-8")).hexdigest() if run.sequence else None,
                        "pam_index": run.pam_index,
                        "cut_index": run.cut_index,
                    }
            except Exception:
                pass
            # Session-level hints (best-effort, non-fatal)
            try:
                cfg = getattr(self._session_model, "state", None)
                cfg = cfg.config if cfg is not None else {}
                outcome_cfg = cfg.get("outcome_model") if isinstance(cfg, Mapping) else {}
                guide_cfg = cfg.get("guide") if isinstance(cfg, Mapping) else {}
                bundle["debug"] = {
                    "whole_genome_search": outcome_cfg.get("search_mode"),
                    "fm_ready": outcome_cfg.get("fm_index_path") or outcome_cfg.get("fm_ready"),
                    "guide_len": len(str(guide_cfg.get("sequence") or "")) if isinstance(guide_cfg, Mapping) else None,
                    "pam_satisfied": guide_cfg.get("pam_satisfied") if isinstance(guide_cfg, Mapping) else None,
                    "window_start": run.cut_index if run is not None else None,
                    "window_end": run.cut_index + len(run.sequence) if run is not None and run.sequence else None,
                    "seed": outcome_cfg.get("seed"),
                    "priors_profile": outcome_cfg.get("priors_profile"),
                    "engine_warnings": getattr(self._session_model, "state", None).config.get("engine_warnings", []) if getattr(self._session_model, "state", None) else [],
                }
            except Exception:
                pass
            try:
                path = temp.gettempdir() / f"lightcone_debug_{int(clock.unix_time_s())}.json"
                path.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
                QApplication.clipboard().setText(str(path))
                self._toast_export_result(f"Copied debug bundle path: {path}", path=str(path), kind="info")
            except Exception as exc:
                self._toast_export_result(f"Failed to write debug bundle: {exc}", path=None, kind="error")

        try:
            self._empty_overlay.show_message(title, causes, on_action=_copy_bundle, action_label="Copy debug bundle")
        except Exception:
            pass

    def _diagnose_zero_outcomes(self, run: RunModel | None) -> list[str]:
        causes: list[str] = []
        if run is None:
            return ["No recorded run", "Run a simulation to populate Lightcone"]
        try:
            if self._dag_has_branch_mass():
                causes.append("Edit DAG shows non-zero branch mass but outcomes are empty")
        except Exception:
            pass
        if not run.sequence:
            causes.append("Sequence missing")
        if not run.target_locus:
            causes.append("Target locus unset")
        if run.cut_index is None and run.pam_index is None and run.edit_type != "prime_edit":
            causes.append("Cut/PAM index unavailable")
        # Whole genome off-target without FM index (best-effort based on metadata/config).
        try:
            cfg = getattr(self._session_model, "state", None)
            cfg = cfg.config if cfg is not None else {}
            search_mode = None
            fm_ready = None
            if isinstance(cfg, Mapping):
                outcome_cfg = cfg.get("outcome_model") or {}
                if isinstance(outcome_cfg, Mapping):
                    search_mode = outcome_cfg.get("search_mode")
                    fm_ready = outcome_cfg.get("fm_index_path") or outcome_cfg.get("fm_ready")
            if (search_mode == "whole") and not fm_ready:
                causes.append("Whole genome search requested but FM index is not built")
        except Exception:
            pass
        causes.append("Outcome model returned 0 outcomes")
        if not causes:
            causes.append("Unknown cause")
        return causes[:3]

    def _latest_run(self) -> RunModel | None:
        try:
            runs = getattr(self._session_model, "runs", None)
            if runs:
                return runs[-1]
        except Exception:
            return None
        return None

    def _dag_has_branch_mass(self) -> bool:
        state = getattr(self._session_model, "state", None)
        payload = getattr(state, "dag_from_runtime", None) if state is not None else None
        if payload is None:
            return False
        try:
            from helix.edit.dag import EditDAG, dag_from_payload
        except Exception:
            return False
        try:
            if isinstance(payload, EditDAG):
                dag = payload
            elif isinstance(payload, Mapping) and payload.get("nodes"):
                dag = dag_from_payload(dict(payload))
            else:
                return False
        except Exception:
            return False
        if not dag.nodes or len(dag.nodes) <= 1:
            return False
        root_id = dag.root_id
        root_log_p = float(dag.nodes[root_id].log_prob) if root_id in dag.nodes else 0.0
        for node_id, node in dag.nodes.items():
            if node_id == root_id:
                continue
            try:
                prob = math.exp(float(node.log_prob) - root_log_p)
            except Exception:
                continue
            if prob > 1e-12:
                return True
        return False
    
    def current_doc_id(self) -> str | None:
        return self._active_doc_id

    def _refresh_live_document(self, *, reason: str) -> None:
        if self._mode != "live":
            return
        run = self._latest_run()
        if run is None:
            self._show_empty_state("Live: no runs yet", ["Click Simulate to generate outcomes"])
            self._update_status_chip(extra="waiting for run")
            return
        try:
            from helix.studio.lightcone_live import build_lightcone_document_from_run

            doc = build_lightcone_document_from_run(run)
            if not doc.outcomes:
                causes = self._diagnose_zero_outcomes(run)
                self._show_empty_state("Run produced 0 outcomes", causes, run=run)
            else:
                self._clear_empty_state()
            self._active_doc_id = str(doc.id)
            self.set_document(doc, phase=1.0, reset_navigation=True)
            self._update_status_chip(extra=f"run {run.run_id}")
            self._mark_dirty()
            self._session._id_dirty = True
        except Exception as exc:
            self._show_empty_state("Live sync failed", [str(exc)])
            self._update_status_chip(extra="error")

    def _on_session_run_recorded(self, run: RunModel) -> None:
        if self._mode != "live":
            return
        self._live_refresh_timer.start()
        self._mark_dirty()

    def _on_session_state_changed(self, *_args) -> None:
        if self._mode != "live":
            return
        self._live_refresh_timer.start()
        self._mark_dirty()

    def _on_phase_changed(self, value: int) -> None:
        self._session.set_phase(float(value) / 1000.0)
        self._set_interacting(True)
        self._mark_dirty()
        self._schedule_interaction_end()

    def _on_bundling_changed(self, enabled: bool) -> None:
        self._session.set_bundling_enabled(bool(enabled))
        self._update_receipts_label()
        self._mark_dirty()

    def _render(self) -> None:
        try:
            rgba, w, h = self._session.render_rgba()
        except Exception as exc:
            self._viewport.set_image(None)
            self._receipts.setText(f"{self._session.receipts_text()}\n\nERROR: {exc}")
            return
        self._viewport.set_image(_rgba_to_qimage(rgba, width=w, height=h))
        self._update_locus_label()
        self._update_receipts_label()
        self._update_audit_label()
        self._clear_empty_state()
        self._auto_select_best_selection()
        self._render_dirty = False
        self._session._id_dirty = True

    def _mark_dirty(self) -> None:
        self._render_dirty = True
        self._session._id_dirty = True
        try:
            self._render_timer.start(0)
        except Exception:
            pass

    def _render_if_dirty(self) -> None:
        if not self._render_dirty:
            return
        now = clock.monotonic()
        elapsed = now - getattr(self, "_last_render_ts", 0.0)
        if elapsed < self._render_min_dt_s:
            # Coalesce renders to ~60 FPS; reschedule for the remaining budget.
            remaining_ms = max(1, int((self._render_min_dt_s - elapsed) * 1000))
            try:
                self._render_timer.start(remaining_ms)
            except Exception:
                pass
            return
        self._last_render_ts = now
        self._render()

    def _ensure_id_buffer(self) -> tuple[bytes | None, int, int, bool]:
        """Render ID buffer on-demand. Returns (buf, width, height, is_gpu)."""
        doc = self._session.doc
        if doc is None or doc.render_golden is None:
            return None, 0, 0, False
        width, height = self._session._effective_dimensions(doc)
        if width <= 0 or height <= 0:
            return None, 0, 0, False
        if (
            not self._session._id_dirty
            and self._session._id_buffer is not None
            and self._session._id_size == (int(width), int(height))
        ):
            return self._session._id_buffer, int(width), int(height), bool(self._session._id_is_gpu)

        if self._session.backend == "gpu" and self._session._gpu_ok:
            if self._session._gpu_renderer is None:
                self._session._gpu_renderer = LightconeGpuRenderer()
            if self._session._cached_geom is None or self._session._gpu_stage_bands is None or getattr(self._session, "_selection_index", None) is None:
                self._session._rebuild_geometry()
            if self._session._cached_geom is None:
                return None, 0, 0, False
            y_clip = float(self._session._cached_geom.y_bottom_px) - float(self._session.phase) * float(self._session._cached_geom.axis_h_px)
            buf = self._session._gpu_renderer.render_id_u32(width=int(width), height=int(height), y_clip=float(y_clip), readback=True)
            self._session._id_buffer = buf
            self._session._id_size = (int(width), int(height))
            self._session._id_is_gpu = True
        else:
            # CPU ID buffer
            buf = render_lightcone_id_rgba(
                doc,
                width=int(width),
                height=int(height),
                phase=float(self._session.phase),
                camera_pan_px=self._session._camera_pan_px or doc.render_golden.camera.pan_px,
                camera_zoom=self._session._camera_zoom or doc.render_golden.camera.zoom,
            )
            self._session._id_buffer = buf
            self._session._id_size = (int(width), int(height))
            self._session._id_is_gpu = False

        self._session._id_dirty = False
        self._session._id_last_used = clock.unix_time_s()
        return self._session._id_buffer, int(width), int(height), bool(self._session._id_is_gpu)

    def _on_viewport_clicked(self, x: int, y: int) -> None:
        sel = self._pick_at(x, y)
        if isinstance(sel, Exception):
            self._sel_label.setText(f"Pick failed: {sel}")
            return
        if sel is None:
            self._sel_label.setText("—")
            self._outcomes_list.clear()
            self._inspector._text.setText("")
            self._inspector._meta.setText("Click a filament to inspect")
            return
        if sel.kind == "ghost" and sel.ghost_id:
            self._enter_ghost(sel.ghost_id)
            return
        if not self._selection_passes_filters(sel):
            self._sel_label.setText("Filtered out by current thresholds")
            return
        try:
            self._apply_selection(sel)
        except Exception:
            # Qt slots swallow exceptions; keep the UI responsive and retry once after the click handler unwinds.
            try:
                QTimer.singleShot(0, lambda s=sel: self._apply_selection(s))
            except Exception:
                pass
            return

        # Offscreen Qt + repeated window lifecycles can occasionally drop list updates during the click handler.
        # If the selection is valid but produced an empty list, retry once on the next event loop tick.
        if sel.outcome_ids and self._outcomes_list.count() == 0:
            try:
                QTimer.singleShot(0, lambda s=sel: self._apply_selection(s))
            except Exception:
                pass

    def _pick_at(self, px: int, py: int) -> LightconeSelection | Exception | None:
        # CPU path: fall back to session.pick (renders ID once per click).
        if getattr(self._session, "backend", "cpu") != "gpu" or not getattr(self._session, "_gpu_ok", False):
            try:
                return self._session.pick(x=px, y=py)
            except Exception as exc:
                return exc

        # Ensure color frame exists
        if self._render_dirty:
            try:
                self._render()
            except Exception as exc:
                return exc
        # Render ID buffer lazily
        try:
            buf, w, h, is_gpu = self._ensure_id_buffer()
        except Exception as exc:
            return exc
        if buf is None or w <= 0 or h <= 0:
            try:
                return self._session.pick(x=px, y=py)
            except Exception as exc:
                return exc
        if px < 0 or py < 0 or px >= w or py >= h:
            return None
        try:
            if is_gpu:
                sid = decode_id_u32_le(buf, x=int(px), y=int(py), width=int(w), height=int(h))
            else:
                sid = decode_id_u32_be(buf, x=int(px), y=int(py), width=int(w), height=int(h))
        except Exception as exc:
            return exc
        if sid == 0:
            try:
                return self._session.pick(x=px, y=py)
            except Exception as exc:
                return exc
        sel_index = getattr(self._session, "_selection_index", None)
        if sel_index is None:
            try:
                return self._session.pick(x=px, y=py)
            except Exception as exc:
                return exc
        info = sel_index.get(int(sid))
        if info is None:
            try:
                return self._session.pick(x=px, y=py)
            except Exception as exc:
                return exc
        return LightconeSelection(
            selection_id=int(info.selection_id),
            kind=str(info.kind),
            outcome_ids=tuple(info.outcome_ids),
            probability_mass=float(info.probability_mass),
            dominant_outcome_id=(str(info.dominant_outcome_id) if info.dominant_outcome_id else None),
            mechanism_tags=tuple(str(t) for t in info.mechanism_tags),
            ghost_id=(str(info.ghost_id) if info.ghost_id else None),
        )

    def _set_view_mode(self, mode: str) -> None:
        mode = "3d" if str(mode).lower() == "3d" else "2d"
        self._session.set_view_mode(mode)
        try:
            self._view_mode_2d.setChecked(mode == "2d")
            self._view_mode_3d.setChecked(mode == "3d")
            self._view_mode_btn.setText("3D" if mode == "3d" else "2D")
        except Exception:
            pass
        self._mark_dirty()
        self._update_status_chip()
        self._slice_slider.setEnabled(mode == "3d" and self._slice_toggle.isChecked())

    def _widget_to_image_coords(self, x: int, y: int) -> tuple[int, int] | None:
        img = self._viewport.image()
        rect = self._viewport.image_draw_rect()
        if img is None or rect is None:
            return None
        if x < rect.left() or y < rect.top() or x >= rect.right() or y >= rect.bottom():
            return None
        u = (x - rect.left()) / max(1.0, float(rect.width()))
        v = (y - rect.top()) / max(1.0, float(rect.height()))
        px = int(u * img.width())
        py = int(v * img.height())
        px = 0 if px < 0 else img.width() - 1 if px >= img.width() else px
        py = 0 if py < 0 else img.height() - 1 if py >= img.height() else py
        return px, py

    def _dispatch_hover_pick(self) -> None:
        if self._pending_hover is None:
            return
        if not self._hover_enabled:
            return
        wx, wy = self._pending_hover
        coords = self._widget_to_image_coords(wx, wy)
        if coords is None:
            return
        px, py = coords
        sel = self._pick_at(px, py)
        if sel is None or not self._selection_passes_filters(sel):
            return
        self._hover_sel = sel
        tooltip = self._tooltip_for_selection(sel)
        try:
            QToolTip.showText(self._viewport.mapToGlobal(QPoint(wx, wy)), tooltip, self._viewport)
        except Exception:
            pass
        self._highlight_outcomes_for_selection(sel, transient=True)

    def _on_viewport_hovered(self, x: int, y: int) -> None:
        self._pending_hover = (x, y)
        try:
            self._hover_timer.start()
        except Exception:
            pass

    def _on_viewport_hover_exit(self) -> None:
        self._pending_hover = None
        self._hover_sel = None
        try:
            self._hover_timer.stop()
        except Exception:
            pass

    def _on_outcome_hovered(self, item: QListWidgetItem) -> None:
        oid = item.data(Qt.UserRole)
        if oid is None:
            return
        if not self._hover_enabled:
            return
        sel = self._find_selection_containing_outcome(str(oid))
        if sel:
            self._highlight_outcomes_for_selection(sel, transient=True)

    def _find_selection_containing_outcome(self, oid: str) -> LightconeSelection | None:
        index = getattr(self._session, "_selection_index", None)
        if not index:
            return None
        for sel in index.values():
            try:
                if str(oid) in {str(x) for x in sel.outcome_ids}:
                    return LightconeSelection(
                        selection_id=int(sel.selection_id),
                        kind=str(sel.kind),
                        outcome_ids=tuple(str(o) for o in sel.outcome_ids),
                        probability_mass=float(sel.probability_mass),
                        dominant_outcome_id=str(sel.dominant_outcome_id) if sel.dominant_outcome_id else None,
                        mechanism_tags=tuple(str(t) for t in sel.mechanism_tags),
                        ghost_id=str(sel.ghost_id) if getattr(sel, "ghost_id", None) else None,
                    )
            except Exception:
                continue
        return None

    def _highlight_outcomes_for_selection(self, sel: LightconeSelection, *, transient: bool = False) -> None:
        # Update outcomes list highlighting; do not mutate persistent selection when transient.
        self._outcomes_list.blockSignals(True)
        for i in range(self._outcomes_list.count()):
            item = self._outcomes_list.item(i)
            if item is None:
                continue
            oid = item.data(Qt.UserRole)
            if oid and str(oid) in {str(o) for o in sel.outcome_ids}:
                item.setSelected(True)
            else:
                item.setSelected(False)
        self._outcomes_list.blockSignals(False)
        if not transient:
            self._apply_selection(sel)

    def _tooltip_for_selection(self, sel: LightconeSelection) -> str:
        if bool(getattr(self, "_quantitative_allowed", False)):
            lines = [f"id {sel.selection_id} · mass {sel.probability_mass:.4f}"]
        else:
            lines = [f"id {sel.selection_id} · mass suppressed"]
        if sel.dominant_outcome_id:
            lines.append(f"dom {sel.dominant_outcome_id}")
        if sel.mechanism_tags:
            lines.append("tags " + ", ".join(sel.mechanism_tags))
        outcomes = self._session.outcomes_for_selection(sel)
        top3 = outcomes[:3]
        if top3:
            lines.append("top outcomes:")
            for idx, (oid, p, _tags) in enumerate(top3):
                if bool(getattr(self, "_quantitative_allowed", False)):
                    lines.append(f"  {p:.4f} {oid}")
                else:
                    lines.append(f"  #{idx + 1} {oid}")
        return "\n".join(lines)

    def _on_pan_requested(self, dx: float, dy: float) -> None:
        self._session.set_camera(pan_dx=dx, pan_dy=dy)
        self._set_interacting(True)
        self._mark_dirty()
        self._schedule_interaction_end()

    def _on_zoom_requested(self, factor: float, _cx: float, _cy: float) -> None:
        self._session.set_camera(zoom_factor=factor)
        self._set_interacting(True)
        self._mark_dirty()
        self._schedule_interaction_end()

    def _focus_on_selection(self, sel: LightconeSelection) -> None:
        geom = getattr(self._session, "_cached_geom", None)
        doc = self._session.doc
        if geom is None or doc is None or doc.render_golden is None:
            return
        edges = [e for e in getattr(geom, "edges", []) if int(getattr(e, "selection_id", -1)) == int(sel.selection_id)]
        if not edges:
            return
        xs = [float(p[0]) for e in edges for p in [e.p0, e.p1, e.p2, e.p3] if hasattr(e, "p0")]
        ys = [float(p[1]) for e in edges for p in [e.p0, e.p1, e.p2, e.p3] if hasattr(e, "p0")]
        if not xs or not ys:
            return
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        cx = 0.5 * (min_x + max_x)
        cy = 0.5 * (min_y + max_y)
        w = max_x - min_x
        h = max_y - min_y
        width, height = self._session._effective_dimensions(doc)
        cur_zoom = self._session._camera_zoom or doc.render_golden.camera.zoom
        target_zoom = cur_zoom
        if w > 1 and h > 1:
            target_zoom = min(width / (w * 1.4), height / (h * 1.4))
        zoom_factor = target_zoom / cur_zoom if cur_zoom else 1.0
        dx = (width * 0.5 - cx)
        dy = (height * 0.5 - cy)
        self._session.set_camera(pan_dx=dx, pan_dy=dy, zoom_factor=zoom_factor)
        self._mark_dirty()

    def _on_focus_requested(self, wx: int, wy: int) -> None:
        coords = self._widget_to_image_coords(wx, wy)
        if coords is None:
            return
        px, py = coords
        try:
            sel = self._session.pick(x=px, y=py)
        except Exception:
            sel = None
        if sel is None:
            return
        self._focus_on_selection(sel)
        self._set_interacting(False)

    def keyPressEvent(self, event) -> None:  # type: ignore[override]
        if event.key() == Qt.Key_F and self._last_sel is not None:
            self._focus_on_selection(self._last_sel)
            event.accept()
            return
        super().keyPressEvent(event)

    def _set_interacting(self, on: bool) -> None:
        if bool(self._is_interacting) == bool(on):
            return
        self._is_interacting = bool(on)
        try:
            self._session._is_interacting = bool(on)
        except Exception:
            pass
        self._mark_dirty()
        self._session._id_dirty = True

    def _schedule_interaction_end(self) -> None:
        try:
            self._interaction_end_timer.start()
        except Exception:
            pass

    def _end_interaction(self) -> None:
        self._set_interacting(False)

    def _on_slice_toggled(self) -> None:
        enabled = bool(self._slice_toggle.isChecked())
        self._slice_toggle.setText("Slice: on" if enabled else "Slice: off")
        self._slice_slider.setEnabled(enabled and getattr(self, "_session", None) and getattr(self._session, "_view_mode", "2d") == "3d")
        self._mark_dirty()

    def _on_slice_changed(self, value: int) -> None:
        _ = value
        self._mark_dirty()

    def _on_hover_toggle(self) -> None:
        self._hover_enabled = bool(self._hover_toggle.isChecked())

    def _apply_selection(self, sel: LightconeSelection) -> None:
        self._last_sel = sel
        if bool(getattr(self, "_quantitative_allowed", False)):
            mass_txt = f"{sel.probability_mass:.4f}"
        else:
            mass_txt = "suppressed"
        self._sel_label.setText(
            f"id={sel.selection_id} · mass={mass_txt} · "
            f"outcomes={len(sel.outcome_ids)} · dom={sel.dominant_outcome_id or '—'}"
        )
        self._outcomes_list.clear()
        outcomes = self._session.outcomes_for_selection(sel)
        shown_rank = 0
        for oid, p, tags in outcomes[:64]:
            if not self._outcome_passes_filters(prob=p, tags=tags):
                continue
            shown_rank += 1
            if bool(getattr(self, "_quantitative_allowed", False)):
                item = QListWidgetItem(f"{p:8.6f}  {oid}  {'/'.join(tags) if tags else ''}")
            else:
                tier = tier_for_rank(shown_rank).label
                item = QListWidgetItem(f"#{shown_rank:02d}  {tier}  {oid}  {'/'.join(tags) if tags else ''}")
            item.setData(Qt.UserRole, oid)
            self._outcomes_list.addItem(item)
        # Auto-open top outcome
        if self._outcomes_list.count() > 0:
            self._outcomes_list.setCurrentRow(0)
            self._on_outcome_activated(self._outcomes_list.currentItem())
        else:
            self._inspector._text.setText("")
            self._inspector._meta.setText("Click a filament to inspect")
        self._session._id_dirty = True  # selection/payload changes can invalidate desired id context

    def _auto_select_best_selection(self) -> None:
        try:
            index = getattr(self._session, "_selection_index", None)
        except Exception:
            index = None
        if not index:
            return
        # Prefer edge selections with highest probability mass.
        best = None
        best_mass = -1.0
        for sel in index.values():
            if getattr(sel, "kind", "") != "edge":
                continue
            mass = float(getattr(sel, "probability_mass", 0.0))
            if mass > best_mass and self._selection_passes_filters(
                LightconeSelection(
                    selection_id=int(sel.selection_id),
                    kind=str(sel.kind),
                    outcome_ids=tuple(sel.outcome_ids),
                    probability_mass=float(sel.probability_mass),
                    dominant_outcome_id=(str(sel.dominant_outcome_id) if sel.dominant_outcome_id is not None else None),
                    mechanism_tags=tuple(sel.mechanism_tags),
                    ghost_id=(str(sel.ghost_id) if getattr(sel, "ghost_id", None) is not None else None),
                )
            ):
                best = sel
                best_mass = mass
        if best is None:
            return
        lc_sel = LightconeSelection(
            selection_id=int(best.selection_id),
            kind=str(best.kind),
            outcome_ids=tuple(best.outcome_ids),
            probability_mass=float(best.probability_mass),
            dominant_outcome_id=(str(best.dominant_outcome_id) if best.dominant_outcome_id is not None else None),
            mechanism_tags=tuple(best.mechanism_tags),
            ghost_id=(str(best.ghost_id) if getattr(best, "ghost_id", None) is not None else None),
        )
        self._apply_selection(lc_sel)

    def _on_outcome_activated(self, item: QListWidgetItem) -> None:
        oid = item.data(Qt.UserRole)
        if not oid:
            return
        payload = self._session.outcome_payload(str(oid))
        ref = self._session.reference_sequence()
        bounds = self._session.reference_window_bounds()
        if payload is None or ref is None:
            return
        prob, tags, allele_ops = payload
        self._inspector.show_alignment(
            outcome_id=str(oid),
            probability=float(prob),
            tags=tags,
            ref_seq=ref,
            allele_ops_payload=allele_ops,
            ref_window_start=(bounds[0] if bounds else None),
            ref_window_end=(bounds[1] if bounds else None),
        )
        try:
            doc = self._session.doc
            sel = self._last_sel
            payload2 = {
                "docId": (str(doc.id) if doc is not None else ""),
                "outcomeId": str(oid),
                "probability": float(prob),
                "mechanismTags": [str(t) for t in tags],
                "alleleOps": list(allele_ops),
                "selectionId": (int(sel.selection_id) if sel is not None else None),
            }
            self.outcomeActivated.emit(payload2)
        except Exception:
            pass

    def _format_locus(self, doc: LightconeDocument) -> str:
        loc = doc.locus
        return f"{loc.contig}:{loc.position} ({loc.strand}) window=[{loc.window_start},{loc.window_end}]"

    def _update_locus_label(self) -> None:
        doc = self._session.doc
        if doc is None:
            self._locus_label.setText("")
            return
        self._locus_label.setText(self._format_locus(doc))

    def _on_back_clicked(self) -> None:
        if not self._nav_stack:
            self._back_btn.setVisible(False)
            return
        doc, phase = self._nav_stack.pop()
        self._session.load_document(doc, phase=float(phase))
        if not self._nav_stack:
            self._active_ghost_id = None
        self._bundling.setChecked(bool(self._session.doc and self._session.doc.render_golden and self._session.doc.render_golden.style.bundling.get("enabled", False)))
        self._phase_slider.blockSignals(True)
        self._phase_slider.setValue(int(round(self._session.phase * 1000.0)))
        self._phase_slider.blockSignals(False)
        self._back_btn.setVisible(bool(self._nav_stack))
        self._last_sel = None
        self._sel_label.setText("—")
        self._outcomes_list.clear()
        self._inspector._text.setText("")
        self._inspector._meta.setText("")
        self._update_locus_label()
        self._emit_locus_context_changed()
        self._mark_dirty()

    def _enter_ghost(self, ghost_id: str) -> None:
        doc = self._session.doc
        if doc is None:
            return
        ghost = next((g for g in doc.off_targets if str(g.id) == str(ghost_id)), None)
        if ghost is None:
            return
        self._nav_stack.append((doc, float(self._session.phase)))
        ghost_doc = _build_ghost_drilldown_document(doc, ghost)
        self._session.load_document(ghost_doc, phase=float(self._session.phase))
        self._active_ghost_id = str(ghost_id)
        self._bundling.setChecked(bool(self._session.doc and self._session.doc.render_golden and self._session.doc.render_golden.style.bundling.get("enabled", False)))
        self._back_btn.setVisible(True)
        self._last_sel = None
        self._sel_label.setText("—")
        self._outcomes_list.clear()
        self._inspector._text.setText("")
        self._inspector._meta.setText("")
        self._update_locus_label()
        self._emit_locus_context_changed()
        self._mark_dirty()

    def closeEvent(self, event) -> None:  # type: ignore[override]
        try:
            self._session.close()
        except Exception:
            pass
        try:
            self._live_refresh_timer.stop()
        except Exception:
            pass
        super().closeEvent(event)

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        if self._mode == "live":
            self._live_refresh_timer.start()

    def hideEvent(self, event) -> None:  # type: ignore[override]
        try:
            self._render_timer.stop()
            self._live_refresh_timer.stop()
        except Exception:
            pass
        super().hideEvent(event)


def _seed_u32(label: str) -> int:
    h = hashlib.sha256(str(label).encode("utf-8")).digest()
    return int.from_bytes(h[:4], "big") or 1


def _pseudo_reference_sequence(*, length: int, seed: int) -> str:
    rng = Rng(int(seed), stream_id=f"studio:lightcone_panel:pseudo_ref_v0:seed={int(seed)}")
    return "".join(rng.choice("ACGT") for _ in range(max(1, int(length))))


def _guess_base_editor_kind(primary: LightconeDocument) -> str:
    tags = {str(t).lower() for oc in primary.outcomes for t in oc.mechanism_tags}
    if "abe" in tags:
        return "ABE"
    if "cbe" in tags:
        return "CBE"
    return "CBE"


def _build_ghost_drilldown_document(primary: LightconeDocument, ghost: OffTarget) -> LightconeDocument:
    """Build a deterministic, self-contained drilldown document for an off-target locus.

    v0 behavior: synthesize a reference window and outcomes using the v0 builders, keyed by ghost id.
    """

    seed = _seed_u32(f"ghostdoc:{primary.id}:{ghost.id}")
    ref_len = 64
    if primary.reference_window is not None and primary.reference_window.sequence:
        ref_len = len(primary.reference_window.sequence)
    seq = _pseudo_reference_sequence(length=ref_len, seed=seed)
    ref_sha = hashlib.sha256(seq.encode("utf-8")).hexdigest()

    ref_window = ReferenceWindow(
        start=int(ghost.locus.window_start),
        end=int(ghost.locus.window_end),
        sequence=seq,
        checksum=ref_sha,
    )

    edit_type = str(primary.edit_type)
    outcomes = ()
    if edit_type == "crispr_cut":
        cut_index = int(ghost.locus.position) - int(ghost.locus.window_start)
        outcomes = CrisprOutcomeBuilderV0().build(seq, cut_index=cut_index, seed=seed)
    elif edit_type == "base_edit":
        kind = _guess_base_editor_kind(primary)
        center = max(0, min(ref_len - 1, ref_len // 2))
        w0 = max(0, center - 6)
        w1 = min(ref_len - 1, center + 6)
        outcomes = BaseOutcomeBuilderV0().build(seq, seed=seed, editor_kind=kind, edit_window=(w0, w1), intended_offset=center)
    elif edit_type == "prime_edit":
        rng = Rng(int(seed), stream_id=f"studio:lightcone_panel:ghost_rtt_v0:seed={int(seed)}")
        rtt = "".join(rng.choice("ACGT") for _ in range(9))
        nick_index = int(ghost.locus.position) - int(ghost.locus.window_start)
        outcomes = PrimeOutcomeBuilderV0().build(seq, nick_index=nick_index, rtt=rtt, seed=seed)
    else:
        cut_index = int(ref_len // 2)
        outcomes = CrisprOutcomeBuilderV0().build(seq, cut_index=cut_index, seed=seed)

    bp = BuilderProvenance(
        builder_id="helix.lightcone.ghost_drilldown_v0",
        builder_version="v0.1",
        seed=int(seed),
        params={
            "sourceDocId": str(primary.id),
            "ghostId": str(ghost.id),
            "editType": str(edit_type),
        },
        reference_window_sha256=ref_sha,
        notes="Synthetic outcomes for off-target drilldown (v0).",
    )

    rg = copy.deepcopy(primary.render_golden)
    return LightconeDocument(
        spec_version=str(primary.spec_version),
        id=f"{primary.id}::ghost::{ghost.id}",
        locus=ghost.locus,
        edit_type=str(edit_type),
        reference_window=ref_window,
        outcomes=tuple(outcomes),
        builder_provenance=bp,
        phase_stages=tuple(primary.phase_stages),
        off_targets=(),
        render_golden=rg,
        notes=f"Ghost drilldown for {ghost.id}",
    )
