from __future__ import annotations

import traceback
import threading
from dataclasses import dataclass
from typing import Any, Callable, Optional

from PySide6.QtCore import QObject, Signal


class _Dispatcher(QObject):
    dispatch = Signal(object)

    def __init__(self) -> None:
        super().__init__()
        self.dispatch.connect(self._on_dispatch)

    def _on_dispatch(self, fn: object) -> None:
        if not callable(fn):
            return
        try:
            fn()
        except Exception:
            pass


_dispatcher = _Dispatcher()


@dataclass
class CancelToken:
    current: int = 0

    def bump(self) -> int:
        self.current += 1
        return self.current


def run_bg(
    fn: Callable[[], Any],
    on_ok: Callable[[Any], None],
    on_err: Callable[[str], None],
    *,
    label: str,
    token: Optional[CancelToken] = None,
) -> None:
    local_version = token.bump() if token is not None else None

    def _post_ok(result: Any) -> None:
        if token is not None and local_version != token.current:
            return
        _dispatcher.dispatch.emit(lambda: on_ok(result))

    def _post_err(tb: str) -> None:
        if token is not None and local_version != token.current:
            return
        _dispatcher.dispatch.emit(lambda: on_err(f"{label} failed:\n{tb}"))

    def _worker() -> None:
        try:
            res = fn()
        except Exception:
            _post_err(traceback.format_exc())
            return
        _post_ok(res)

    t = threading.Thread(target=_worker, daemon=True)
    t.start()


def run_bg_stream(
    fn: Callable[[], Any],
    on_update: Callable[[Any], None],
    on_err: Callable[[str], None],
    *,
    label: str,
    token: Optional[CancelToken] = None,
) -> None:
    local_version = token.bump() if token is not None else None

    def _post_update(update: Any) -> None:
        if token is not None and local_version != token.current:
            return
        _dispatcher.dispatch.emit(lambda: on_update(update))

    def _post_err(tb: str) -> None:
        if token is not None and local_version != token.current:
            return
        _dispatcher.dispatch.emit(lambda: on_err(f"{label} failed:\n{tb}"))

    def _worker() -> None:
        try:
            for update in fn():
                _post_update(update)
        except Exception:
            _post_err(traceback.format_exc())

    t = threading.Thread(target=_worker, daemon=True)
    t.start()
