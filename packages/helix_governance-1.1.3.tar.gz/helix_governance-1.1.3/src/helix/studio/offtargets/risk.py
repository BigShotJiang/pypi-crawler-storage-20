from __future__ import annotations

from typing import Any


def seed_start_index(guide_len: int) -> int:
    """Return the inclusive start index for the PAM-proximal seed region."""
    # Convention: mismatch positions are zero-based along the guide alignment,
    # with index (guide_len - 1) closest to the PAM. Seed is the last 8 bases.
    return max(0, int(guide_len) - 8)


def score_offtarget_hit(
    *,
    total_mm: int,
    seed_mm: int,
    pam_class: str,
    pam_ok: bool,
    bulge_type: str = "NONE",
    bulge_pos: int | None = None,
    guide_len: int = 20,
) -> tuple[float, str, list[str]]:
    total_mm = int(total_mm)
    seed_mm = int(seed_mm)
    nonseed_mm = max(0, total_mm - seed_mm)
    seed_score = 0.6 * float(seed_mm)
    nonseed_score = 0.2 * float(nonseed_mm)

    seed_start = seed_start_index(guide_len)
    seed_bulge = False
    bulge_score = 0.0
    if str(bulge_type).upper() != "NONE":
        if bulge_pos is not None:
            try:
                bulge_pos_int = int(bulge_pos)
            except Exception:
                bulge_pos_int = None
            if bulge_pos_int is not None and seed_start <= bulge_pos_int < max(1, int(guide_len)):
                seed_bulge = True
        bulge_score = 0.8 if seed_bulge else 0.3

    score = seed_score + nonseed_score + bulge_score
    if pam_class == "NGG":
        score += 0.05
    elif str(pam_class).endswith("GG"):
        score += 0.03
    elif str(pam_class).endswith("AG"):
        score += 0.01
    if not pam_ok:
        score -= 0.05
    score = round(max(0.0, score), 4)

    if score >= 2.5:
        tier = "High"
    elif score >= 1.4:
        tier = "Medium"
    else:
        tier = "Low"

    notes = [
        f"total mismatches: {total_mm}",
        f"seed mismatches: {seed_mm}",
        f"seed bulge: {'yes' if seed_bulge else 'no'}",
        f"score components: seed {seed_score:.2f}, nonseed {nonseed_score:.2f}, bulge {bulge_score:.2f}",
        f"PAM class: {pam_class}",
        f"PAM match: {'yes' if pam_ok else 'no'}",
    ]
    return score, tier, notes


__all__ = ["score_offtarget_hit", "seed_start_index"]
