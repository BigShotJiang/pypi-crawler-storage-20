from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, List, Mapping


SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2, "unclassified": 3}
DOMINANT_CALLOUT_TEXT = (
    "Dominant is most likely, not safest. Check Tail Risk for severe long-tail outcomes."
)


@dataclass(frozen=True)
class TailRiskEntry:
    outcome_id: str
    label: str
    probability: float
    severity: str
    severity_rank: int
    score: float
    ci_low: float | None = None
    ci_high: float | None = None


def _severity_rank(severity: str) -> int:
    return SEVERITY_ORDER.get(severity.lower(), SEVERITY_ORDER["unclassified"])


def build_tail_risk_entries(
    outcomes: Iterable[Mapping[str, Any]],
    *,
    dominant_outcome_id: str | None = None,
    top_k: int = 5,
    severity_weight: Mapping[str, float] | None = None,
) -> List[TailRiskEntry]:
    """Build a ranked, deterministic tail-risk list from outcome payloads."""
    if severity_weight is None:
        severity_weight = {"high": 1.0, "medium": 0.5, "low": 0.1, "unclassified": 0.1}

    entries: List[TailRiskEntry] = []
    for outcome in outcomes:
        if not isinstance(outcome, Mapping):
            continue
        oid = str(outcome.get("id") or outcome.get("outcome_id") or "")
        if not oid:
            continue
        if dominant_outcome_id and oid == str(dominant_outcome_id):
            continue
        p = float(outcome.get("probability") or outcome.get("p") or outcome.get("prob") or 0.0)
        sev_raw = outcome.get("severity") or outcome.get("severity_class") or "unclassified"
        sev = str(sev_raw)
        rank = _severity_rank(sev)
        weight = float(severity_weight.get(sev.lower(), severity_weight.get("unclassified", 0.1)))

        ci = outcome.get("ci") or {}
        ci_low = None
        ci_high = None
        if isinstance(ci, Mapping):
            if ci.get("low") is not None:
                ci_low = float(ci.get("low"))
            if ci.get("high") is not None:
                ci_high = float(ci.get("high"))

        label = str(outcome.get("label") or outcome.get("name") or oid)
        score = p * weight
        entries.append(
            TailRiskEntry(
                outcome_id=oid,
                label=label,
                probability=p,
                severity=sev,
                severity_rank=rank,
                score=score,
                ci_low=ci_low,
                ci_high=ci_high,
            )
        )

    entries.sort(
        key=lambda e: (
            e.severity_rank,
            -e.score,
            -e.probability,
            e.outcome_id,
        )
    )
    return entries[:top_k]


def tail_risk_flag_from_config(config: Mapping[str, Any] | None) -> bool:
    """Return persisted tail-risk flag. Supports both dag.* and offtarget.* namespaces."""
    if not isinstance(config, Mapping):
        return False
    # Preferred: dag namespace
    dag_cfg = config.get("dag")
    if isinstance(dag_cfg, Mapping) and "tail_risk_view" in dag_cfg:
        return bool(dag_cfg.get("tail_risk_view"))
    # Backward/compat: offtarget namespace
    offtarget_cfg = config.get("offtarget")
    if isinstance(offtarget_cfg, Mapping):
        return bool(offtarget_cfg.get("tail_risk_view"))
    return False


def update_tail_risk_flag(config: Mapping[str, Any] | None, enabled: bool) -> dict[str, Any]:
    """Return a copy of config with dag.tail_risk_view set (leaves legacy offtarget keys untouched)."""
    cfg = dict(config or {})
    dag_cfg = dict(cfg.get("dag") or {})
    dag_cfg["tail_risk_view"] = bool(enabled)
    cfg["dag"] = dag_cfg
    return cfg


@dataclass(frozen=True)
class TailRiskPanelEntry:
    outcome_id: str
    node_id: str
    label: str
    probability: float
    severity: str
    ci_low: float | None
    ci_high: float | None


@dataclass(frozen=True)
class TailRiskPanelModel:
    visible: bool
    callout_text: str
    entries: list[TailRiskPanelEntry]


def build_tail_risk_panel_model(
    config: Mapping[str, Any] | None,
    outcomes: Iterable[Mapping[str, Any]] | None,
    *,
    dominant_outcome_id: str | None = None,
    top_k: int = 5,
) -> TailRiskPanelModel:
    visible = tail_risk_flag_from_config(config)
    if not visible:
        return TailRiskPanelModel(visible=False, callout_text=DOMINANT_CALLOUT_TEXT, entries=[])

    entries_raw = build_tail_risk_entries(
        outcomes or [],
        dominant_outcome_id=dominant_outcome_id,
        top_k=top_k,
    )
    entries = [
        TailRiskPanelEntry(
            outcome_id=e.outcome_id,
            node_id=e.outcome_id,  # outcome_id doubles as node id in DAG payloads
            label=e.label,
            probability=e.probability,
            severity=e.severity,
            ci_low=e.ci_low,
            ci_high=e.ci_high,
        )
        for e in entries_raw
    ]
    return TailRiskPanelModel(visible=True, callout_text=DOMINANT_CALLOUT_TEXT, entries=entries)


__all__ = [
    "DOMINANT_CALLOUT_TEXT",
    "SEVERITY_ORDER",
    "TailRiskEntry",
    "TailRiskPanelEntry",
    "TailRiskPanelModel",
    "build_tail_risk_entries",
    "build_tail_risk_panel_model",
    "tail_risk_flag_from_config",
    "update_tail_risk_flag",
]
