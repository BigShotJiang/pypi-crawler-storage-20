from __future__ import annotations

from .model import (
    OffTargetReportV1,
    OffTargetProvider,
    OffTargetProviderRegistry,
    compute_inputs_sha256,
    compute_offtargets_for_session,
    get_default_registry,
    offtarget_report_json_bytes,
    offtarget_report_to_dict,
)
from .mismatch_provider import MismatchOffTargetProvider
from .bulge_provider import BulgeOffTargetProvider
from .rloks_provider import RLoCKSOffTargetProvider
from .noop import NoopOffTargetProvider
from .validation_plan import build_validation_plan, validation_plan_json_bytes, validation_plan_sha256
from .reference_accessor import (
    ReferenceAccessor,
    OffTargetReferenceCache,
    build_reference_cache_from_config,
    get_default_reference_cache,
)

__all__ = [
    "OffTargetReportV1",
    "OffTargetProvider",
    "OffTargetProviderRegistry",
    "NoopOffTargetProvider",
    "MismatchOffTargetProvider",
    "BulgeOffTargetProvider",
    "RLoCKSOffTargetProvider",
    "compute_inputs_sha256",
    "compute_offtargets_for_session",
    "get_default_registry",
    "offtarget_report_json_bytes",
    "offtarget_report_to_dict",
    "build_validation_plan",
    "validation_plan_json_bytes",
    "validation_plan_sha256",
    "ReferenceAccessor",
    "OffTargetReferenceCache",
    "get_default_reference_cache",
    "build_reference_cache_from_config",
]
