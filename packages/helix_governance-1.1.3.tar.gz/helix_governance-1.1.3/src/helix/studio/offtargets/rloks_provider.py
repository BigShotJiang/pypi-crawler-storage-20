from __future__ import annotations

import hashlib
import json
from importlib import resources
from pathlib import Path
from typing import Any, Mapping

from helix import bioinformatics
from helix.crispr.pam import PAM, get_pam
from helix.crispr.score import enumerate_off_targets

from .model import (
    OffTargetReportV1,
    compute_inputs_sha256,
    _genome_digest,
    normalize_target_id,
    base_hit_key,
    namespace_hit_key,
    offtarget_report_json_bytes,
    offtarget_report_to_dict,
)
from .reference_accessor import ReferenceAccessor, get_default_reference_cache
from .risk import seed_start_index


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _pam_pattern(pam: Any) -> str | None:
    if isinstance(pam, str):
        try:
            pam_def = get_pam(pam)
            return pam_def.get("pattern")
        except Exception:
            return None
    if isinstance(pam, Mapping):
        return str(pam.get("pattern") or "") or None
    if isinstance(pam, PAM):
        return str(pam.as_dict().get("pattern") or "") or None
    return None


def _classify_pam(pam_seq: str, pam_pattern: str | None) -> str:
    if not pam_seq or not pam_pattern or len(pam_seq) != len(pam_pattern):
        return "Unknown"
    pattern = pam_pattern.upper()
    seq = pam_seq.upper()
    if any(ch not in "ACGTN" for ch in pattern) or any(ch not in "ACGT" for ch in seq):
        return "Unknown"
    class_chars = []
    for pat, base in zip(pattern, seq):
        class_chars.append("N" if pat == "N" else base)
    return "".join(class_chars) or "Unknown"


def _normalize_guide(
    guide: Mapping[str, Any] | None,
    genome_sequences: Mapping[str, Any] | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    if isinstance(guide, Mapping):
        payload.update({k: guide[k] for k in guide.keys()})

    seq = str(payload.get("sequence") or "").strip().upper()
    if seq:
        payload["sequence"] = seq
        payload.setdefault("start", 0)
        payload.setdefault("end", len(seq))
        payload.setdefault("strand", "+")
        return payload

    contig = str(payload.get("contig") or payload.get("chrom") or "")
    start = payload.get("start")
    end = payload.get("end")
    if contig and isinstance(genome_sequences, Mapping) and contig in genome_sequences:
        genome_seq = genome_sequences.get(contig)
        if isinstance(genome_seq, str) and start is not None and end is not None:
            s = _safe_int(start, 0)
            e = _safe_int(end, s)
            if e > s:
                slice_seq = genome_seq[s:e]
                strand = str(payload.get("strand") or "+")
                payload["sequence"] = (
                    bioinformatics.reverse_complement(slice_seq) if strand == "-" else slice_seq
                ).upper()
                return payload
    return payload


def _resolve_pack_dir(params: Mapping[str, Any] | None) -> Path:
    repo_root = Path(__file__).resolve().parents[4]
    if isinstance(params, Mapping):
        for key in ("rloks_pack_dir", "rloksPackDir", "pack_dir", "packDir"):
            value = params.get(key)
            if isinstance(value, str) and value.strip():
                candidate = Path(value).expanduser()
                if not candidate.is_absolute():
                    candidate = repo_root / candidate
                return candidate.resolve()
    return (repo_root / "models" / "rloks" / "packs").resolve()


def _resolve_pack_id(params: Mapping[str, Any] | None) -> str:
    """Return the user/config pack selector (not the canonical pack identity)."""
    if isinstance(params, Mapping):
        for key in ("rloks_pack_id", "rloksPackId", "pack_id", "packId"):
            value = params.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
    return "default"


def _load_rloks_pack_manifest(pack_dir: Path) -> tuple[dict[str, Any], dict[str, str]] | None:
    manifest_path = pack_dir / "manifest.json"
    if not manifest_path.exists():
        return None
    raw = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("RLoCKS pack manifest must be a JSON object")
    if raw.get("schema") != "rloks_pack_manifest_v1":
        raise ValueError(f"Unsupported RLoCKS pack manifest schema: {raw.get('schema')}")
    packs = raw.get("packs")
    aliases = raw.get("aliases", {})
    if not isinstance(packs, dict):
        raise ValueError("RLoCKS pack manifest 'packs' must be an object")
    if not isinstance(aliases, dict):
        raise ValueError("RLoCKS pack manifest 'aliases' must be an object")
    aliases_typed = {str(k): str(v) for k, v in aliases.items()}

    for alias, canonical_id in aliases_typed.items():
        if not alias:
            raise ValueError("RLoCKS pack manifest alias keys must be non-empty")
        if canonical_id not in packs:
            raise ValueError(f"RLoCKS pack manifest alias '{alias}' points to unknown pack id '{canonical_id}'")

    overlap = sorted(set(aliases_typed.keys()) & set(str(k) for k in packs.keys()))
    if overlap:
        raise ValueError(
            f"RLoCKS pack manifest has ambiguous keys (alias collides with pack id): {', '.join(overlap)}"
        )

    for pack_id, entry in packs.items():
        if not isinstance(entry, Mapping):
            raise ValueError(f"RLoCKS pack manifest pack '{pack_id}' must be an object")
        pack_file = entry.get("file")
        sha_file = entry.get("sha256_file")
        if not isinstance(pack_file, str) or not pack_file.strip():
            raise ValueError(f"RLoCKS pack manifest pack '{pack_id}' missing file")
        if not isinstance(sha_file, str) or not sha_file.strip():
            raise ValueError(f"RLoCKS pack manifest pack '{pack_id}' missing sha256_file")
        if Path(pack_file).is_absolute() or ".." in Path(pack_file).parts:
            raise ValueError(f"RLoCKS pack manifest pack '{pack_id}' file must be a safe relative path: {pack_file}")
        if Path(sha_file).is_absolute() or ".." in Path(sha_file).parts:
            raise ValueError(
                f"RLoCKS pack manifest pack '{pack_id}' sha256_file must be a safe relative path: {sha_file}"
            )

    return packs, aliases_typed


def _rloks_pack_manifest_schema_sha256(schema: str) -> str | None:
    if schema != "rloks_pack_manifest_v1":
        return None
    resource = resources.files("helix.schema").joinpath("rloks/rloks_pack_manifest_v1.json")
    return hashlib.sha256(resource.read_bytes()).hexdigest()


def _parse_sha256_text(text: str) -> str:
    parts = text.strip().split()
    if not parts:
        raise ValueError("sha256 file is empty")
    digest = parts[0].strip().lower()
    if len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest):
        raise ValueError("sha256 digest must be 64 hex characters")
    return digest


def _compute_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _verify_sha256(pack_path: Path, sha256_path: Path) -> str:
    if not sha256_path.exists():
        raise FileNotFoundError(f"Missing sha256 sidecar: {sha256_path}")
    expected = _parse_sha256_text(sha256_path.read_text(encoding="utf-8"))
    actual = _compute_sha256(pack_path)
    if expected != actual:
        raise ValueError(
            f"RLoCKS pack checksum mismatch for '{pack_path.name}': expected {expected} (from {sha256_path.name}), got {actual}"
        )
    return actual


def _format_known_packs(packs: dict[str, Any], aliases: dict[str, str], limit: int = 20) -> str:
    alias_list = sorted(set(str(k) for k in aliases.keys()))
    id_list = sorted(set(str(k) for k in packs.keys()))

    def _fmt(items: list[str]) -> str:
        if len(items) <= limit:
            return ", ".join(items)
        head = ", ".join(items[:limit])
        return f"{head} (+{len(items) - limit} more)"

    return f"Known selectors: {_fmt(alias_list)}; known canonical ids: {_fmt(id_list)}"


def _pack_path_for_report(pack_path: Path, pack_dir: Path) -> str:
    try:
        return pack_path.resolve().relative_to(pack_dir.resolve()).as_posix()
    except Exception:
        return pack_path.name


def _resolve_rloks_pack_files(pack_selector: str, pack_dir: Path) -> tuple[Path, Path]:
    selector = pack_selector.strip()
    if not selector:
        raise ValueError("RLoCKS pack id must be explicit")

    direct = Path(selector).expanduser()
    if direct.exists():
        pack_path = direct.resolve()
        sha_path = pack_path.with_suffix(pack_path.suffix + ".sha256")
        return pack_path, sha_path

    if selector.endswith(".json"):
        pack_path = (pack_dir / selector).resolve()
        if pack_path.exists():
            return pack_path, pack_path.with_suffix(pack_path.suffix + ".sha256")

    manifest = _load_rloks_pack_manifest(pack_dir)
    if manifest is not None:
        packs, aliases = manifest
        canonical_id = aliases.get(selector, selector)
        pack_entry = packs.get(canonical_id)
        if isinstance(pack_entry, Mapping):
            pack_file = pack_entry.get("file")
            sha_file = pack_entry.get("sha256_file")
            if isinstance(pack_file, str) and pack_file.strip():
                pack_path = (pack_dir / pack_file).resolve()
                if not pack_path.exists():
                    raise FileNotFoundError(f"Pack file missing for '{canonical_id}': {pack_path}")
                if isinstance(sha_file, str) and sha_file.strip():
                    sha_path = (pack_dir / sha_file).resolve()
                else:
                    sha_path = pack_path.with_suffix(pack_path.suffix + ".sha256")
                return pack_path, sha_path

    candidate = (pack_dir / f"{selector}.json").resolve()
    if candidate.exists():
        return candidate, candidate.with_suffix(candidate.suffix + ".sha256")

    # Convenience: allow canonical ids like "rloks:0.1.1" even without a manifest.
    if ":" in selector and "/" not in selector and "\\" not in selector:
        model, version = selector.split(":", 1)
        candidate = (pack_dir / f"{model}_v{version}.json").resolve()
        if candidate.exists():
            return candidate, candidate.with_suffix(candidate.suffix + ".sha256")

    if manifest is not None:
        packs, aliases = manifest
        raise FileNotFoundError(
            f"Unknown RLoCKS pack selector '{selector}' in '{pack_dir}'. {_format_known_packs(packs, aliases)}"
        )

    raise FileNotFoundError(f"Could not resolve RLoCKS pack '{selector}' in '{pack_dir}'")


def _resolve_rloks_pack_path(pack_selector: str, pack_dir: Path) -> Path:
    pack_path, _sha_path = _resolve_rloks_pack_files(pack_selector, pack_dir)
    return pack_path


def _enumerate_rloks_hits(
    guide_norm: Mapping[str, Any],
    guide_seq: str,
    guide_len: int,
    genome_sequences: Mapping[str, Any],
    pam: Any,
    pam_pattern: str | None,
    pam_len: int,
    max_mm: int,
    max_hits: int,
    reference_accessor: ReferenceAccessor | None,
) -> tuple[list[dict[str, Any]], bool]:
    hits_all: list[dict[str, Any]] = []
    truncated = False
    contigs = reference_accessor.contigs() if reference_accessor is not None else sorted(genome_sequences.keys())
    for contig in contigs:
        genome_seq = reference_accessor.get_window(
            contig,
            0,
            reference_accessor.contig_length(contig),
            strand="+",
        )
        if not genome_seq:
            continue
        pam_targets = []
        pam_target_map: dict[tuple[int, str], Mapping[str, Any]] = {}
        if pam_len > 0:
            pam_targets = reference_accessor.prefetch_pam_targets(
                contig,
                0,
                reference_accessor.contig_length(contig),
                pam,
                guide_len=guide_len,
                normalize=False,
                strand_policy="both",
            )
            for entry in pam_targets:
                if not isinstance(entry, Mapping):
                    continue
                pam_pos = entry.get("pam_pos")
                strand = str(entry.get("strand") or "")
                if pam_pos is None or not strand:
                    continue
                pam_target_map[(int(pam_pos), strand)] = entry
        hits = enumerate_off_targets(genome_seq, guide_norm, pam, max_mm=max_mm, max_gap=0)
        for hit in hits:
            hit = dict(hit)
            hit["contig"] = str(contig)
            pam_seq = ""
            pam_ok = bool(hit.get("pam_ok", True))
            strand = str(hit.get("strand") or "+")
            try:
                start = int(hit.get("start", 0))
                end = int(hit.get("end", start))
            except Exception:
                start = 0
                end = 0
            if pam_len > 0:
                if strand == "+":
                    pam_start = end
                    pam_end = end + pam_len
                    if pam_ok:
                        entry = pam_target_map.get((pam_start, "+"))
                        if isinstance(entry, Mapping):
                            pam_seq = str(entry.get("pam_seq") or "")
                    if not pam_seq and 0 <= pam_start < len(genome_seq) and pam_end <= len(genome_seq):
                        pam_seq = reference_accessor.get_window(contig, pam_start, pam_end, strand="+").upper()
                else:
                    pam_start = start - pam_len
                    pam_end = start
                    if pam_ok:
                        entry = pam_target_map.get((pam_start, "-"))
                        if isinstance(entry, Mapping):
                            pam_seq = str(entry.get("pam_seq") or "")
                    if not pam_seq and pam_start >= 0 and pam_end <= len(genome_seq):
                        pam_seq = reference_accessor.get_window(contig, pam_start, pam_end, strand="-").upper()
            hit["pamSequence"] = pam_seq
            hit["pamClass"] = _classify_pam(pam_seq, pam_pattern)

            target_seq = ""
            if contig and reference_accessor is not None:
                if end > start:
                    target_seq = reference_accessor.get_window(contig, start, end, strand=strand).upper()
            hit["alignedGuide"] = guide_seq
            hit["alignedTarget"] = target_seq

            hits_all.append(hit)
            if max_hits > 0 and len(hits_all) >= max_hits:
                truncated = True
                break
        if truncated:
            break

    return hits_all, truncated


def _prepare_candidates(
    hits_all: list[dict[str, Any]],
    guide_len: int,
    pam_len: int,
) -> tuple[list[tuple[str, str]], list[dict[str, Any]]]:
    candidates: list[tuple[str, str]] = []
    candidate_hits: list[dict[str, Any]] = []
    for hit in hits_all:
        target_seq = str(hit.get("alignedTarget") or "")
        pam_seq = str(hit.get("pamSequence") or "")
        if not target_seq or not pam_seq or len(target_seq) != guide_len:
            continue
        if pam_len > 0 and len(pam_seq) != pam_len:
            continue
        candidates.append((target_seq, pam_seq))
        candidate_hits.append(hit)
    return candidates, candidate_hits


def _resolve_on_target_index(candidate_hits: list[dict[str, Any]]) -> int:
    for idx, hit in enumerate(candidate_hits):
        mismatches = hit.get("mismatches") if isinstance(hit.get("mismatches"), list) else []
        if not mismatches:
            return idx
    return 0


def _apply_scored_fields(
    hit: dict[str, Any],
    scored: Mapping[str, Any],
    seed_start: int,
    target_id: str | None,
) -> tuple[dict[str, Any], str]:
    mismatches = hit.get("mismatches") if isinstance(hit.get("mismatches"), list) else []
    positions = []
    for mismatch in mismatches:
        if isinstance(mismatch, Mapping) and "position" in mismatch:
            try:
                positions.append(int(mismatch.get("position")))
            except Exception:
                continue
    positions = sorted(set(p for p in positions if p is not None))
    total_mm = len(positions)
    seed_mm = len([p for p in positions if p >= seed_start])

    p_cleave = float(scored.get("p_cleave") or 0.0)
    site_score = float(scored.get("site_score") or 0.0)

    if p_cleave >= 0.05:
        tier = "High"
    elif p_cleave >= 0.01:
        tier = "Medium"
    else:
        tier = "Low"

    hit["mismatchPositions"] = positions
    hit["totalMismatchCount"] = total_mm
    hit["seedMismatchCount"] = seed_mm
    hit["bulgeType"] = "NONE"
    hit["bulgePos"] = None
    hit["bulgeSize"] = 0
    hit["effectiveDistance"] = total_mm
    hit["riskScore"] = round(p_cleave, 12)
    hit["riskTier"] = tier
    hit["p_cleave"] = p_cleave
    hit["siteScore"] = site_score
    hit["packId"] = scored.get("pack_id")
    hit["packFingerprint"] = scored.get("pack_fingerprint")
    hit["explainSchemaVersion"] = scored.get("explain_schema_version")
    hit["explanation"] = scored.get("explanation")

    notes = [
        f"p_cleave: {p_cleave:.6g}",
        f"site_score: {site_score:.6g}",
        f"pack: {scored.get('pack_id')}",
    ]
    hit["notes"] = notes
    if target_id:
        hit["targetId"] = target_id
    hit_key = namespace_hit_key(base_hit_key(hit), target_id)
    hit["hitKey"] = hit_key
    return hit, tier


def _sort_scored_hits(scored_hits: list[dict[str, Any]]) -> None:
    scored_hits.sort(
        key=lambda h: (
            -float(h.get("riskScore") or 0.0),
            int(h.get("totalMismatchCount") or 0),
            str(h.get("contig") or ""),
            int(h.get("start") or 0),
        )
    )


def _finalize_rloks_report(
    *,
    provider_id: str,
    provider_version: str,
    inputs_sha: str,
    guide_norm: Mapping[str, Any],
    genome_sequences: Mapping[str, Any],
    resolved_params: dict[str, Any],
    scored_hits: list[dict[str, Any]],
    truncated: bool,
    max_hits: int,
    max_mm: int,
    pack_meta: Mapping[str, Any] | None,
) -> OffTargetReportV1:
    high_count = 0
    medium_count = 0
    low_count = 0
    for hit in scored_hits:
        tier = str(hit.get("riskTier") or "")
        if tier == "High":
            high_count += 1
        elif tier == "Medium":
            medium_count += 1
        else:
            low_count += 1

    summary = [
        f"RLoCKS scoring (≤{max_mm} mismatches) across {len(genome_sequences)} contig(s).",
        f"{len(scored_hits)} candidate site(s) scored.",
    ]
    if pack_meta:
        summary.append(f"Pack: {pack_meta.get('pack_id')} (schema {pack_meta.get('explain_schema_version')})")
        summary.append(f"Fingerprint: {pack_meta.get('pack_fingerprint')}")
    if truncated:
        summary.append(f"Truncated to top {max_hits} hits.")

    genome_meta = {"contigs": _genome_digest(genome_sequences)}
    if pack_meta:
        resolved_params["rloks_pack_fingerprint"] = pack_meta.get("pack_fingerprint")
        resolved_params["explain_schema_version"] = pack_meta.get("explain_schema_version")
        resolved_params["rloks_pack_canonical_id"] = pack_meta.get("pack_id")

    model_id = str(pack_meta.get("pack_id", provider_id)) if pack_meta else provider_id
    if ":" in model_id:
        model_id = model_id.split(":", 1)[0]
    model_version = str(pack_meta.get("model_version", provider_version)) if pack_meta else provider_version

    return OffTargetReportV1(
        model_id=model_id,
        model_version=model_version,
        inputs_sha256=inputs_sha,
        summary=summary,
        guide=dict(guide_norm),
        genome=genome_meta,
        params=resolved_params,
        hits=scored_hits,
        total_hits=len(scored_hits) if not truncated else None,
        hit_cap=max_hits,
        is_truncated=truncated,
        hits_returned=len(scored_hits),
        max_mismatches=max_mm,
        high_risk_count=high_count,
        medium_risk_count=medium_count,
        low_risk_count=low_count,
    )


class RLoCKSOffTargetProvider:
    provider_id = "offtarget_rloks_v1"
    provider_version = "v1"

    def can_handle(
        self,
        experiment_spec: Mapping[str, Any] | None,
        guide: Mapping[str, Any] | None,
        genome_sequences: Mapping[str, Any] | None,
        params: Mapping[str, Any] | None,
    ) -> bool:
        guide_norm = _normalize_guide(guide, genome_sequences)
        seq = str(guide_norm.get("sequence") or "")
        return bool(seq and isinstance(genome_sequences, Mapping) and genome_sequences)

    def run(
        self,
        experiment_spec: Mapping[str, Any] | None,
        guide: Mapping[str, Any] | None,
        genome_sequences: Mapping[str, Any] | None,
        params: Mapping[str, Any] | None,
        reference_accessor: ReferenceAccessor | None = None,
    ) -> OffTargetReportV1:
        guide_norm = _normalize_guide(guide, genome_sequences)
        guide_seq = str(guide_norm.get("sequence") or "")
        if not guide_seq or not isinstance(genome_sequences, Mapping) or not genome_sequences:
            inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, params)
            return OffTargetReportV1(
                model_id=self.provider_id,
                model_version=self.provider_version,
                inputs_sha256=inputs_sha,
                summary=["Inputs incomplete; off-target search not run."],
                guide=dict(guide_norm),
                genome={},
                params=dict(params or {}),
                hits=[],
                total_hits=0,
                hit_cap=None,
                is_truncated=False,
                hits_returned=0,
                max_mismatches=None,
            )

        params = dict(params or {})
        max_mm = _safe_int(params.get("max_mm", params.get("max_mismatch", 3)), 3)
        max_hits = _safe_int(params.get("max_hits", 200), 200)
        pam = params.get("pam") or guide_norm.get("pam") or params.get("pam_profile") or "NGG"
        pack_selector = _resolve_pack_id(params)
        pack_dir = _resolve_pack_dir(params)
        kon = _safe_float(params.get("kon", 1.0), 1.0)
        concentration = _safe_float(params.get("concentration", 1.0), 1.0)
        exposure_time = _safe_float(params.get("exposure_time", params.get("exposureTime", 1.0)), 1.0)
        resolved_params = {
            "max_mm": max_mm,
            "max_hits": max_hits,
            "pam": pam,
            "rloks_pack_id": pack_selector,
            "kon": kon,
            "concentration": concentration,
            "exposure_time": exposure_time,
        }

        if pack_selector.strip().lower() == "latest":
            inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, resolved_params)
            summary = ["RLoCKS pack id must be explicit; 'latest' is not allowed."]
            genome_meta = {"contigs": _genome_digest(genome_sequences)}
            return OffTargetReportV1(
                model_id=self.provider_id,
                model_version=self.provider_version,
                inputs_sha256=inputs_sha,
                summary=summary,
                guide=dict(guide_norm),
                genome=genome_meta,
                params=resolved_params,
                hits=[],
                total_hits=0,
                hit_cap=max_hits,
                is_truncated=False,
                hits_returned=0,
                max_mismatches=max_mm,
            )

        pack_path = None
        try:
            pack_path, sha_path = _resolve_rloks_pack_files(pack_selector, pack_dir)
            pack_sha256 = _verify_sha256(pack_path, sha_path)
            resolved_params["rloks_pack_path"] = _pack_path_for_report(pack_path, pack_dir)
            resolved_params["rloks_pack_sha256"] = pack_sha256
            if pack_path.is_relative_to(pack_dir) and (pack_dir / "manifest.json").exists():
                manifest_bytes = (pack_dir / "manifest.json").read_bytes()
                resolved_params["rloks_pack_manifest_sha256"] = hashlib.sha256(manifest_bytes).hexdigest()
                manifest = json.loads(manifest_bytes.decode("utf-8"))
                schema = str(manifest.get("schema") or "")
                if schema:
                    resolved_params["rloks_pack_manifest_schema"] = schema
                    schema_sha = _rloks_pack_manifest_schema_sha256(schema)
                    if schema_sha:
                        resolved_params["rloks_pack_manifest_schema_sha256"] = schema_sha
        except Exception as exc:
            inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, resolved_params)
            summary = [
                "RLoCKS pack load failed.",
                str(exc),
            ]
            genome_meta = {"contigs": _genome_digest(genome_sequences)}
            return OffTargetReportV1(
                model_id=self.provider_id,
                model_version=self.provider_version,
                inputs_sha256=inputs_sha,
                summary=summary,
                guide=dict(guide_norm),
                genome=genome_meta,
                params=resolved_params,
                hits=[],
                total_hits=0,
                hit_cap=max_hits,
                is_truncated=False,
                hits_returned=0,
                max_mismatches=max_mm,
            )

        inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, resolved_params)
        target_id = normalize_target_id(guide_norm)
        pam_pattern = _pam_pattern(pam)
        pam_len = len(pam_pattern or "")
        guide_len = len(guide_seq)
        seed_start = seed_start_index(guide_len)

        if reference_accessor is None:
            reference_accessor = get_default_reference_cache().accessor(genome_sequences)

        hits_all, truncated = _enumerate_rloks_hits(
            guide_norm=guide_norm,
            guide_seq=guide_seq,
            guide_len=guide_len,
            genome_sequences=genome_sequences,
            pam=pam,
            pam_pattern=pam_pattern,
            pam_len=pam_len,
            max_mm=max_mm,
            max_hits=max_hits,
            reference_accessor=reference_accessor,
        )

        candidates, candidate_hits = _prepare_candidates(hits_all, guide_len, pam_len)

        if not candidates:
            summary = ["RLoCKS scoring skipped; no valid PAM-aligned candidates."]
            genome_meta = {"contigs": _genome_digest(genome_sequences)}
            return OffTargetReportV1(
                model_id=self.provider_id,
                model_version=self.provider_version,
                inputs_sha256=inputs_sha,
                summary=summary,
                guide=dict(guide_norm),
                genome=genome_meta,
                params=resolved_params,
                hits=[],
                total_hits=0,
                hit_cap=max_hits,
                is_truncated=truncated,
                hits_returned=0,
                max_mismatches=max_mm,
            )

        try:
            from rloks import ScoreContext, score_offtargets_with_pack_id
        except Exception as exc:  # pragma: no cover - dependency missing
            summary = [
                "RLoCKS dependency unavailable during scoring.",
                str(exc),
            ]
            genome_meta = {"contigs": _genome_digest(genome_sequences)}
            return OffTargetReportV1(
                model_id=self.provider_id,
                model_version=self.provider_version,
                inputs_sha256=inputs_sha,
                summary=summary,
                guide=dict(guide_norm),
                genome=genome_meta,
                params=resolved_params,
                hits=[],
                total_hits=0,
                hit_cap=max_hits,
                is_truncated=False,
                hits_returned=0,
                max_mismatches=max_mm,
            )

        on_target_index = _resolve_on_target_index(candidate_hits)

        context = ScoreContext(
            kon=kon,
            concentration=concentration,
            exposure_time=exposure_time,
        )

        try:
            report = score_offtargets_with_pack_id(
                guide=guide_seq,
                candidates=candidates,
                pack_id=str(pack_path),
                context=context,
                pack_dir=str(pack_dir),
                on_target_index=on_target_index,
                explain=True,
            )
        except Exception as exc:
            summary = [
                "RLoCKS pack load failed.",
                str(exc),
            ]
            genome_meta = {"contigs": _genome_digest(genome_sequences)}
            return OffTargetReportV1(
                model_id=self.provider_id,
                model_version=self.provider_version,
                inputs_sha256=inputs_sha,
                summary=summary,
                guide=dict(guide_norm),
                genome=genome_meta,
                params=resolved_params,
                hits=[],
                total_hits=0,
                hit_cap=max_hits,
                is_truncated=False,
                hits_returned=0,
                max_mismatches=max_mm,
            )

        quantized = report.to_dict()
        results = quantized["results"] if isinstance(quantized.get("results"), list) else []
        pack_meta = results[0] if results else None

        scored_hits: list[dict[str, Any]] = []
        for hit, scored in zip(candidate_hits, results):
            scored_hit, _tier = _apply_scored_fields(dict(hit), scored, seed_start, target_id)
            scored_hits.append(scored_hit)

        _sort_scored_hits(scored_hits)

        return _finalize_rloks_report(
            provider_id=self.provider_id,
            provider_version=self.provider_version,
            inputs_sha=inputs_sha,
            guide_norm=guide_norm,
            genome_sequences=genome_sequences,
            resolved_params=resolved_params,
            scored_hits=scored_hits,
            truncated=truncated,
            max_hits=max_hits,
            max_mm=max_mm,
            pack_meta=pack_meta,
        )


def stream_rloks_report(
    experiment_spec: Mapping[str, Any] | None,
    guide: Mapping[str, Any] | None,
    genome_sequences: Mapping[str, Any] | None,
    params: Mapping[str, Any] | None,
    *,
    reference_accessor: ReferenceAccessor | None = None,
    batch_size: int = 512,
) -> Iterable[dict[str, Any]]:
    if batch_size <= 0:
        batch_size = 512
    guide_norm = _normalize_guide(guide, genome_sequences)
    guide_seq = str(guide_norm.get("sequence") or "")
    if not guide_seq or not isinstance(genome_sequences, Mapping) or not genome_sequences:
        inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, params)
        report = OffTargetReportV1(
            model_id=RLoCKSOffTargetProvider.provider_id,
            model_version=RLoCKSOffTargetProvider.provider_version,
            inputs_sha256=inputs_sha,
            summary=["Inputs incomplete; off-target search not run."],
            guide=dict(guide_norm),
            genome={},
            params=dict(params or {}),
            hits=[],
            total_hits=0,
            hit_cap=None,
            is_truncated=False,
            hits_returned=0,
            max_mismatches=None,
        )
        payload = offtarget_report_to_dict(report)
        yield {"payload": payload, "report_bytes": offtarget_report_json_bytes(report), "done": True}
        return

    params = dict(params or {})
    max_mm = _safe_int(params.get("max_mm", params.get("max_mismatch", 3)), 3)
    max_hits = _safe_int(params.get("max_hits", 200), 200)
    pam = params.get("pam") or guide_norm.get("pam") or params.get("pam_profile") or "NGG"
    pack_selector = _resolve_pack_id(params)
    pack_dir = _resolve_pack_dir(params)
    kon = _safe_float(params.get("kon", 1.0), 1.0)
    concentration = _safe_float(params.get("concentration", 1.0), 1.0)
    exposure_time = _safe_float(params.get("exposure_time", params.get("exposureTime", 1.0)), 1.0)
    resolved_params = {
        "max_mm": max_mm,
        "max_hits": max_hits,
        "pam": pam,
        "rloks_pack_id": pack_selector,
        "kon": kon,
        "concentration": concentration,
        "exposure_time": exposure_time,
    }

    if pack_selector.strip().lower() == "latest":
        inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, resolved_params)
        summary = ["RLoCKS pack id must be explicit; 'latest' is not allowed."]
        genome_meta = {"contigs": _genome_digest(genome_sequences)}
        report = OffTargetReportV1(
            model_id=RLoCKSOffTargetProvider.provider_id,
            model_version=RLoCKSOffTargetProvider.provider_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            guide=dict(guide_norm),
            genome=genome_meta,
            params=resolved_params,
            hits=[],
            total_hits=0,
            hit_cap=max_hits,
            is_truncated=False,
            hits_returned=0,
            max_mismatches=max_mm,
        )
        payload = offtarget_report_to_dict(report)
        yield {"payload": payload, "report_bytes": offtarget_report_json_bytes(report), "done": True}
        return

    pack_path = None
    try:
        pack_path, sha_path = _resolve_rloks_pack_files(pack_selector, pack_dir)
        pack_sha256 = _verify_sha256(pack_path, sha_path)
        resolved_params["rloks_pack_path"] = _pack_path_for_report(pack_path, pack_dir)
        resolved_params["rloks_pack_sha256"] = pack_sha256
        if pack_path.is_relative_to(pack_dir) and (pack_dir / "manifest.json").exists():
            manifest_bytes = (pack_dir / "manifest.json").read_bytes()
            resolved_params["rloks_pack_manifest_sha256"] = hashlib.sha256(manifest_bytes).hexdigest()
            manifest = json.loads(manifest_bytes.decode("utf-8"))
            schema = str(manifest.get("schema") or "")
            if schema:
                resolved_params["rloks_pack_manifest_schema"] = schema
                schema_sha = _rloks_pack_manifest_schema_sha256(schema)
                if schema_sha:
                    resolved_params["rloks_pack_manifest_schema_sha256"] = schema_sha
    except Exception as exc:
        inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, resolved_params)
        summary = [
            "RLoCKS pack load failed.",
            str(exc),
        ]
        genome_meta = {"contigs": _genome_digest(genome_sequences)}
        report = OffTargetReportV1(
            model_id=RLoCKSOffTargetProvider.provider_id,
            model_version=RLoCKSOffTargetProvider.provider_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            guide=dict(guide_norm),
            genome=genome_meta,
            params=resolved_params,
            hits=[],
            total_hits=0,
            hit_cap=max_hits,
            is_truncated=False,
            hits_returned=0,
            max_mismatches=max_mm,
        )
        payload = offtarget_report_to_dict(report)
        yield {"payload": payload, "report_bytes": offtarget_report_json_bytes(report), "done": True}
        return

    inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, resolved_params)
    target_id = normalize_target_id(guide_norm)
    pam_pattern = _pam_pattern(pam)
    pam_len = len(pam_pattern or "")
    guide_len = len(guide_seq)
    seed_start = seed_start_index(guide_len)

    if reference_accessor is None:
        reference_accessor = get_default_reference_cache().accessor(genome_sequences)

    hits_all, truncated = _enumerate_rloks_hits(
        guide_norm=guide_norm,
        guide_seq=guide_seq,
        guide_len=guide_len,
        genome_sequences=genome_sequences,
        pam=pam,
        pam_pattern=pam_pattern,
        pam_len=pam_len,
        max_mm=max_mm,
        max_hits=max_hits,
        reference_accessor=reference_accessor,
    )
    candidates, candidate_hits = _prepare_candidates(hits_all, guide_len, pam_len)

    if not candidates:
        summary = ["RLoCKS scoring skipped; no valid PAM-aligned candidates."]
        genome_meta = {"contigs": _genome_digest(genome_sequences)}
        report = OffTargetReportV1(
            model_id=RLoCKSOffTargetProvider.provider_id,
            model_version=RLoCKSOffTargetProvider.provider_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            guide=dict(guide_norm),
            genome=genome_meta,
            params=resolved_params,
            hits=[],
            total_hits=0,
            hit_cap=max_hits,
            is_truncated=truncated,
            hits_returned=0,
            max_mismatches=max_mm,
        )
        payload = offtarget_report_to_dict(report)
        yield {"payload": payload, "report_bytes": offtarget_report_json_bytes(report), "done": True}
        return

    try:
        from rloks import ScoreContext, score_offtargets_stream_with_pack_id
    except Exception as exc:  # pragma: no cover - dependency missing
        summary = [
            "RLoCKS dependency unavailable during scoring.",
            str(exc),
        ]
        genome_meta = {"contigs": _genome_digest(genome_sequences)}
        report = OffTargetReportV1(
            model_id=RLoCKSOffTargetProvider.provider_id,
            model_version=RLoCKSOffTargetProvider.provider_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            guide=dict(guide_norm),
            genome=genome_meta,
            params=resolved_params,
            hits=[],
            total_hits=0,
            hit_cap=max_hits,
            is_truncated=False,
            hits_returned=0,
            max_mismatches=max_mm,
        )
        payload = offtarget_report_to_dict(report)
        yield {"payload": payload, "report_bytes": offtarget_report_json_bytes(report), "done": True}
        return

    on_target_index = _resolve_on_target_index(candidate_hits)
    context = ScoreContext(
        kon=kon,
        concentration=concentration,
        exposure_time=exposure_time,
    )

    scored_hits_by_index: dict[int, dict[str, Any]] = {}
    scored_count = 0
    pack_meta: Mapping[str, Any] | None = None
    total = len(candidates)

    def _stream_payload(delta_hits: list[dict[str, Any]], scored: int) -> dict[str, Any]:
        summary = [
            f"RLoCKS scoring (≤{max_mm} mismatches) across {len(genome_sequences)} contig(s).",
            f"Scored {scored} of {total} candidate site(s).",
        ]
        if pack_meta:
            summary.append(f"Pack: {pack_meta.get('pack_id')} (schema {pack_meta.get('explain_schema_version')})")
            summary.append(f"Fingerprint: {pack_meta.get('pack_fingerprint')}")
        if truncated:
            summary.append(f"Truncated to top {max_hits} hits.")
        params_payload = dict(resolved_params)
        if pack_meta:
            params_payload["rloks_pack_fingerprint"] = pack_meta.get("pack_fingerprint")
            params_payload["explain_schema_version"] = pack_meta.get("explain_schema_version")
            params_payload["rloks_pack_canonical_id"] = pack_meta.get("pack_id")
        return {
            "summary": summary,
            "params": params_payload,
            "hits": delta_hits,
            "hitCap": max_hits,
            "isTruncated": truncated,
            "hitsReturned": scored,
            "maxMismatches": max_mm,
            "streaming": True,
            "streamDelta": True,
            "stream": {"scored": scored, "total": total},
        }

    yield {"payload": _stream_payload([], 0), "report_bytes": b"", "done": False, "reset": True}

    try:
        stream = score_offtargets_stream_with_pack_id(
            guide=guide_seq,
            candidates=candidates,
            pack_id=str(pack_path),
            context=context,
            pack_dir=str(pack_dir),
            on_target_index=on_target_index,
            batch_size=batch_size,
            explain=True,
        )
        for batch in stream:
            if batch.done:
                break
            delta: list[dict[str, Any]] = []
            for scored_result in batch.results:
                scored = scored_result.to_dict()
                if pack_meta is None:
                    pack_meta = scored
                hit = dict(candidate_hits[scored["index"]])
                hit["streamIndex"] = scored["index"]
                scored_hit, _tier = _apply_scored_fields(hit, scored, seed_start, target_id)
                delta.append(scored_hit)
                scored_hits_by_index[scored["index"]] = scored_hit
            scored_count += len(delta)
            if delta:
                yield {"payload": _stream_payload(delta, scored_count), "report_bytes": b"", "done": False}
    except Exception as exc:
        summary = [
            "RLoCKS pack load failed.",
            str(exc),
        ]
        genome_meta = {"contigs": _genome_digest(genome_sequences)}
        report = OffTargetReportV1(
            model_id=RLoCKSOffTargetProvider.provider_id,
            model_version=RLoCKSOffTargetProvider.provider_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            guide=dict(guide_norm),
            genome=genome_meta,
            params=resolved_params,
            hits=[],
            total_hits=0,
            hit_cap=max_hits,
            is_truncated=False,
            hits_returned=0,
            max_mismatches=max_mm,
        )
        payload = offtarget_report_to_dict(report)
        yield {"payload": payload, "report_bytes": offtarget_report_json_bytes(report), "done": True}
        return

    final_hits: list[dict[str, Any]] = []
    for idx in sorted(scored_hits_by_index.keys()):
        hit = dict(scored_hits_by_index[idx])
        hit.pop("streamIndex", None)
        final_hits.append(hit)
    _sort_scored_hits(final_hits)

    report = _finalize_rloks_report(
        provider_id=RLoCKSOffTargetProvider.provider_id,
        provider_version=RLoCKSOffTargetProvider.provider_version,
        inputs_sha=inputs_sha,
        guide_norm=guide_norm,
        genome_sequences=genome_sequences,
        resolved_params=resolved_params,
        scored_hits=final_hits,
        truncated=truncated,
        max_hits=max_hits,
        max_mm=max_mm,
        pack_meta=pack_meta,
    )
    payload = offtarget_report_to_dict(report)
    yield {"payload": payload, "report_bytes": offtarget_report_json_bytes(report), "done": True}


__all__ = ["RLoCKSOffTargetProvider", "stream_rloks_report"]
