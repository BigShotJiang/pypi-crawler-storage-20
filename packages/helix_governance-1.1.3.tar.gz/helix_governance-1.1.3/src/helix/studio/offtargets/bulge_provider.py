from __future__ import annotations

from typing import Any, Mapping

from helix import bioinformatics
from helix.crispr.pam import PAM, get_pam

from .model import (
    OffTargetReportV1,
    compute_inputs_sha256,
    _genome_digest,
    normalize_target_id,
    base_hit_key,
    namespace_hit_key,
)
from .reference_accessor import ReferenceAccessor, get_default_reference_cache
from .risk import score_offtarget_hit, seed_start_index


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _pam_pattern(pam: Any) -> str | None:
    if isinstance(pam, str):
        try:
            pam_def = get_pam(pam)
            return pam_def.get("pattern")
        except Exception:
            return None
    if isinstance(pam, Mapping):
        return str(pam.get("pattern") or "") or None
    if isinstance(pam, PAM):
        return str(pam.as_dict().get("pattern") or "") or None
    return None


def _classify_pam(pam_seq: str, pam_pattern: str | None) -> str:
    if not pam_seq or not pam_pattern or len(pam_seq) != len(pam_pattern):
        return "Unknown"
    pattern = pam_pattern.upper()
    seq = pam_seq.upper()
    if any(ch not in "ACGTN" for ch in pattern) or any(ch not in "ACGT" for ch in seq):
        return "Unknown"
    class_chars = []
    for pat, base in zip(pattern, seq):
        class_chars.append("N" if pat == "N" else base)
    return "".join(class_chars) or "Unknown"


def _normalize_guide(
    guide: Mapping[str, Any] | None,
    genome_sequences: Mapping[str, Any] | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    if isinstance(guide, Mapping):
        payload.update({k: guide[k] for k in guide.keys()})

    seq = str(payload.get("sequence") or "").strip().upper()
    if seq:
        payload["sequence"] = seq
        payload.setdefault("start", 0)
        payload.setdefault("end", len(seq))
        payload.setdefault("strand", "+")
        return payload

    contig = str(payload.get("contig") or payload.get("chrom") or "")
    start = payload.get("start")
    end = payload.get("end")
    if contig and isinstance(genome_sequences, Mapping) and contig in genome_sequences:
        genome_seq = genome_sequences.get(contig)
        if isinstance(genome_seq, str) and start is not None and end is not None:
            s = _safe_int(start, 0)
            e = _safe_int(end, s)
            if e > s:
                slice_seq = genome_seq[s:e]
                strand = str(payload.get("strand") or "+")
                payload["sequence"] = (
                    bioinformatics.reverse_complement(slice_seq) if strand == "-" else slice_seq
                ).upper()
                return payload
    return payload


def _mismatch_profile(guide_seq: str, target_seq: str) -> list[dict[str, Any]]:
    profile: list[dict[str, Any]] = []
    for idx, (g_base, t_base) in enumerate(zip(guide_seq, target_seq)):
        if g_base != t_base:
            profile.append({"position": idx, "guide": g_base, "target": t_base})
    return profile


def _best_dna_bulge(guide_seq: str, target_seq: str) -> tuple[int, int, list[dict[str, Any]]]:
    best_mm = None
    best_pos = 0
    best_mismatches: list[dict[str, Any]] = []
    for pos in range(len(target_seq)):
        trimmed = target_seq[:pos] + target_seq[pos + 1 :]
        mismatches = _mismatch_profile(guide_seq, trimmed)
        mm = len(mismatches)
        if best_mm is None or mm < best_mm:
            best_mm = mm
            best_pos = pos
            best_mismatches = mismatches
    return int(best_mm or 0), best_pos, best_mismatches


def _best_rna_bulge(guide_seq: str, target_seq: str) -> tuple[int, int, list[dict[str, Any]]]:
    best_mm = None
    best_pos = 0
    best_mismatches: list[dict[str, Any]] = []
    for pos in range(len(guide_seq)):
        trimmed_guide = guide_seq[:pos] + guide_seq[pos + 1 :]
        mismatches_raw = _mismatch_profile(trimmed_guide, target_seq)
        mismatches: list[dict[str, Any]] = []
        for entry in mismatches_raw:
            idx = _safe_int(entry.get("position"), 0)
            orig_pos = idx if idx < pos else idx + 1
            mismatches.append({"position": orig_pos, "guide": entry.get("guide"), "target": entry.get("target")})
        mm = len(mismatches)
        if best_mm is None or mm < best_mm:
            best_mm = mm
            best_pos = pos
            best_mismatches = mismatches
    return int(best_mm or 0), best_pos, best_mismatches


class BulgeOffTargetProvider:
    provider_id = "spcas9_ngg_bulge_v1"
    provider_version = "v1"

    def can_handle(
        self,
        experiment_spec: Mapping[str, Any] | None,
        guide: Mapping[str, Any] | None,
        genome_sequences: Mapping[str, Any] | None,
        params: Mapping[str, Any] | None,
    ) -> bool:
        guide_norm = _normalize_guide(guide, genome_sequences)
        seq = str(guide_norm.get("sequence") or "")
        if not seq or not isinstance(genome_sequences, Mapping) or not genome_sequences:
            return False
        params = params or {}
        provider_id = str(params.get("provider_id") or params.get("providerId") or params.get("provider") or "")
        if provider_id:
            return provider_id == self.provider_id
        return bool(params.get("allow_bulge") or params.get("bulge") or params.get("max_bulges"))

    def run(
        self,
        experiment_spec: Mapping[str, Any] | None,
        guide: Mapping[str, Any] | None,
        genome_sequences: Mapping[str, Any] | None,
        params: Mapping[str, Any] | None,
        reference_accessor: ReferenceAccessor | None = None,
    ) -> OffTargetReportV1:
        guide_norm = _normalize_guide(guide, genome_sequences)
        guide_seq = str(guide_norm.get("sequence") or "")
        if not guide_seq or not isinstance(genome_sequences, Mapping) or not genome_sequences:
            inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, params)
            return OffTargetReportV1(
                model_id=self.provider_id,
                model_version=self.provider_version,
                inputs_sha256=inputs_sha,
                summary=["Inputs incomplete; off-target search not run."],
                guide=dict(guide_norm),
                genome={},
                params=dict(params or {}),
                hits=[],
                total_hits=0,
                hit_cap=None,
                is_truncated=False,
                hits_returned=0,
                max_mismatches=None,
            )

        params = dict(params or {})
        use_prefetch = True
        if "prefetch_targets" in params:
            try:
                use_prefetch = bool(params.pop("prefetch_targets"))
            except Exception:
                use_prefetch = True
        max_mm = _safe_int(params.get("max_mm", params.get("max_mismatch", 3)), 3)
        max_hits = _safe_int(params.get("max_hits", 200), 200)
        max_bulges = _safe_int(params.get("max_bulges", params.get("maxBulges", 1)), 1)
        pam = params.get("pam") or guide_norm.get("pam") or params.get("pam_profile") or "NGG"
        resolved_params = {
            "max_mm": max_mm,
            "max_hits": max_hits,
            "max_bulges": max_bulges,
            "pam": pam,
        }
        inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, resolved_params)
        target_id = normalize_target_id(guide_norm)

        pam_pattern = _pam_pattern(pam)
        pam_len = len(pam_pattern or "")
        guide_len = len(guide_seq)
        seed_start = seed_start_index(guide_len)
        if not pam_pattern or pam_len == 0:
            return OffTargetReportV1(
                model_id=self.provider_id,
                model_version=self.provider_version,
                inputs_sha256=inputs_sha,
                summary=["PAM pattern unavailable; off-target search not run."],
                guide=dict(guide_norm),
                genome={"contigs": _genome_digest(genome_sequences)},
                params=resolved_params,
                hits=[],
                total_hits=0,
                hit_cap=max_hits,
                is_truncated=False,
                hits_returned=0,
                max_mismatches=max_mm,
            )

        if reference_accessor is None:
            reference_accessor = get_default_reference_cache().accessor(genome_sequences)

        hits_all: list[dict[str, Any]] = []
        truncated = False

        contigs = reference_accessor.contigs() if reference_accessor is not None else sorted(genome_sequences.keys())
        for contig in contigs:
            contig_len = reference_accessor.contig_length(contig)
            if contig_len <= 0:
                continue
            if use_prefetch:
                pam_targets = reference_accessor.prefetch_pam_targets(
                    contig,
                    0,
                    contig_len,
                    pam,
                    guide_len=guide_len,
                    normalize=True,
                    strand_policy="both",
                )
                for entry in pam_targets:
                    if not isinstance(entry, Mapping):
                        continue
                    hit = self._evaluate_prefetched_target(
                        contig=str(contig),
                        pam_pattern=pam_pattern,
                        guide_seq=guide_seq,
                        guide_len=guide_len,
                        seed_start=seed_start,
                        pam_len=pam_len,
                        entry=entry,
                        contig_len=contig_len,
                    )
                    if hit is not None:
                        hits_all.append(hit)
                    if max_hits > 0 and len(hits_all) >= max_hits:
                        truncated = True
                        break
            else:
                pam_sites = reference_accessor.iter_pam_sites(
                    contig,
                    0,
                    contig_len,
                    pam,
                    strand_policy="both",
                )
                for pam_start, strand in pam_sites:
                    hit = self._evaluate_hit(
                        contig=str(contig),
                        reference_accessor=reference_accessor,
                        guide_seq=guide_seq,
                        guide_len=guide_len,
                        strand=strand,
                        pam_start=int(pam_start),
                        pam_len=pam_len,
                        pam_pattern=pam_pattern,
                        seed_start=seed_start,
                    )
                    if hit is not None:
                        hits_all.append(hit)
                    if max_hits > 0 and len(hits_all) >= max_hits:
                        truncated = True
                        break
            if truncated:
                break

        filtered = []
        for hit in hits_all:
            if int(hit.get("totalMismatchCount") or 0) <= max_mm:
                filtered.append(hit)

        filtered.sort(
            key=lambda h: (
                int(h.get("effectiveDistance") or 0),
                int(h.get("totalMismatchCount") or 0),
                {"NONE": 0, "DNA": 1, "RNA": 2}.get(str(h.get("bulgeType") or "NONE").upper(), 3),
                str(h.get("contig") or ""),
                int(h.get("start") or 0),
            )
        )

        if max_hits > 0 and len(filtered) > max_hits:
            filtered = filtered[:max_hits]
            truncated = True

        high_count = 0
        medium_count = 0
        low_count = 0
        for hit in filtered:
            if target_id:
                hit["targetId"] = target_id
            hit_key = namespace_hit_key(base_hit_key(hit), target_id)
            hit["hitKey"] = hit_key
            tier = str(hit.get("riskTier") or "")
            if tier == "High":
                high_count += 1
            elif tier == "Medium":
                medium_count += 1
            else:
                low_count += 1

        summary = [
            f"Bulge search (≤{max_mm} mismatches, ≤{max_bulges} bulge) across {len(genome_sequences)} contig(s).",
            f"{len(filtered)} candidate site(s) scored.",
        ]
        if truncated:
            summary.append(f"Truncated to top {max_hits} hits.")

        genome_meta = {"contigs": _genome_digest(genome_sequences)}
        total_hits = len(filtered) if not truncated else None
        return OffTargetReportV1(
            model_id=self.provider_id,
            model_version=self.provider_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            guide=dict(guide_norm),
            genome=genome_meta,
            params=resolved_params,
            hits=filtered,
            total_hits=total_hits,
            hit_cap=max_hits,
            is_truncated=truncated,
            hits_returned=len(filtered),
            max_mismatches=max_mm,
            high_risk_count=high_count,
            medium_risk_count=medium_count,
            low_risk_count=low_count,
        )

    def _evaluate_hit(
        self,
        *,
        contig: str,
        reference_accessor: ReferenceAccessor,
        guide_seq: str,
        guide_len: int,
        strand: str,
        pam_start: int,
        pam_len: int,
        pam_pattern: str,
        seed_start: int,
    ) -> dict[str, Any] | None:
        if strand == "+":
            guide_end = pam_start
            guide_start = guide_end - guide_len
        else:
            guide_start = pam_start + pam_len
            guide_end = guide_start + guide_len
        contig_len = reference_accessor.contig_length(contig)
        if guide_start < 0 or guide_end > contig_len:
            return None

        target_base = reference_accessor.get_window(
            contig,
            guide_start,
            guide_end,
            strand=strand,
            normalize=True,
        )

        target_plus = None
        target_minus = None
        if strand == "+":
            if guide_start - 1 >= 0:
                target_plus = reference_accessor.get_window(
                    contig,
                    guide_start - 1,
                    guide_end,
                    strand=strand,
                    normalize=True,
                )
            if guide_start + 1 < guide_end:
                target_minus = reference_accessor.get_window(
                    contig,
                    guide_start + 1,
                    guide_end,
                    strand=strand,
                    normalize=True,
                )
        else:
            if guide_end + 1 <= contig_len:
                target_plus = reference_accessor.get_window(
                    contig,
                    guide_start,
                    guide_end + 1,
                    strand=strand,
                    normalize=True,
                )
            if guide_end - 1 > guide_start:
                target_minus = reference_accessor.get_window(
                    contig,
                    guide_start,
                    guide_end - 1,
                    strand=strand,
                    normalize=True,
                )

        candidates: list[dict[str, Any]] = []
        mismatches = _mismatch_profile(guide_seq, target_base)
        candidates.append(
            {
                "bulgeType": "NONE",
                "bulgePos": None,
                "bulgeSize": 0,
                "totalMismatchCount": len(mismatches),
                "mismatches": mismatches,
                "alignedGuide": guide_seq,
                "alignedTarget": target_base,
            }
        )

        if target_plus is not None and len(target_plus) == guide_len + 1:
            mm, pos, mismatches = _best_dna_bulge(guide_seq, target_plus)
            aligned_guide = guide_seq[:pos] + "-" + guide_seq[pos:]
            candidates.append(
                {
                    "bulgeType": "DNA",
                    "bulgePos": pos,
                    "bulgeSize": 1,
                    "totalMismatchCount": mm,
                    "mismatches": mismatches,
                    "alignedGuide": aligned_guide,
                    "alignedTarget": target_plus,
                }
            )

        if target_minus is not None and len(target_minus) == guide_len - 1:
            mm, pos, mismatches = _best_rna_bulge(guide_seq, target_minus)
            aligned_target = target_minus[:pos] + "-" + target_minus[pos:]
            candidates.append(
                {
                    "bulgeType": "RNA",
                    "bulgePos": pos,
                    "bulgeSize": 1,
                    "totalMismatchCount": mm,
                    "mismatches": mismatches,
                    "alignedGuide": guide_seq,
                    "alignedTarget": aligned_target,
                }
            )

        candidates.sort(
            key=lambda c: (
                int(c.get("totalMismatchCount") or 0),
                {"NONE": 0, "DNA": 1, "RNA": 2}.get(str(c.get("bulgeType") or "NONE").upper(), 3),
            )
        )
        chosen = candidates[0]

        positions = []
        for mismatch in chosen.get("mismatches", []):
            if isinstance(mismatch, Mapping) and "position" in mismatch:
                try:
                    positions.append(int(mismatch.get("position")))
                except Exception:
                    continue
        positions = sorted(set(p for p in positions if p is not None))
        total_mm = int(chosen.get("totalMismatchCount") or len(positions))
        seed_mm = len([p for p in positions if p >= seed_start])

        bulge_type = str(chosen.get("bulgeType") or "NONE").upper()
        bulge_pos = chosen.get("bulgePos")
        try:
            bulge_pos_int = int(bulge_pos) if bulge_pos is not None else None
        except Exception:
            bulge_pos_int = None
        effective_distance = total_mm + (1 if bulge_type != "NONE" else 0)

        pam_seq = reference_accessor.get_window(
            contig,
            pam_start,
            pam_start + pam_len,
            strand=strand,
            normalize=True,
        )
        pam_class = _classify_pam(pam_seq, pam_pattern)

        score, tier, notes = score_offtarget_hit(
            total_mm=total_mm,
            seed_mm=seed_mm,
            pam_class=pam_class,
            pam_ok=True,
            bulge_type=bulge_type,
            bulge_pos=bulge_pos_int,
            guide_len=guide_len,
        )

        hit = {
            "guide_id": None,
            "contig": contig,
            "strand": strand,
            "start": guide_start,
            "end": guide_end,
            "distance": total_mm,
            "pam_ok": True,
            "pamSequence": pam_seq,
            "pamClass": pam_class,
            "mismatches": chosen.get("mismatches", []),
            "mismatchPositions": positions,
            "totalMismatchCount": total_mm,
            "seedMismatchCount": seed_mm,
            "bulgeType": bulge_type,
            "bulgePos": bulge_pos_int,
            "bulgeSize": int(chosen.get("bulgeSize") or 0),
            "effectiveDistance": effective_distance,
            "riskScore": score,
            "riskTier": tier,
            "notes": notes,
            "alignedGuide": str(chosen.get("alignedGuide") or ""),
            "alignedTarget": str(chosen.get("alignedTarget") or ""),
        }
        return hit

    def _evaluate_prefetched_target(
        self,
        *,
        contig: str,
        pam_pattern: str,
        guide_seq: str,
        guide_len: int,
        seed_start: int,
        pam_len: int,
        entry: Mapping[str, Any],
        contig_len: int,
    ) -> dict[str, Any] | None:
        strand = str(entry.get("strand") or "+")
        pam_start = entry.get("pam_pos")
        if pam_start is None:
            return None
        pam_start = int(pam_start)
        if strand == "+":
            guide_end = pam_start
            guide_start = guide_end - guide_len
        else:
            guide_start = pam_start + pam_len
            guide_end = guide_start + guide_len
        if guide_start < 0 or guide_end > contig_len:
            return None

        target_base = str(entry.get("target20") or "")
        if len(target_base) != guide_len:
            return None
        target_plus = entry.get("target21")
        target_minus = entry.get("target19")

        candidates: list[dict[str, Any]] = []
        mismatches = _mismatch_profile(guide_seq, target_base)
        candidates.append(
            {
                "bulgeType": "NONE",
                "bulgePos": None,
                "bulgeSize": 0,
                "totalMismatchCount": len(mismatches),
                "mismatches": mismatches,
                "alignedGuide": guide_seq,
                "alignedTarget": target_base,
            }
        )

        if isinstance(target_plus, str) and len(target_plus) == guide_len + 1:
            mm, pos, mismatches = _best_dna_bulge(guide_seq, target_plus)
            aligned_guide = guide_seq[:pos] + "-" + guide_seq[pos:]
            candidates.append(
                {
                    "bulgeType": "DNA",
                    "bulgePos": pos,
                    "bulgeSize": 1,
                    "totalMismatchCount": mm,
                    "mismatches": mismatches,
                    "alignedGuide": aligned_guide,
                    "alignedTarget": target_plus,
                }
            )

        if isinstance(target_minus, str) and len(target_minus) == guide_len - 1:
            mm, pos, mismatches = _best_rna_bulge(guide_seq, target_minus)
            aligned_target = target_minus[:pos] + "-" + target_minus[pos:]
            candidates.append(
                {
                    "bulgeType": "RNA",
                    "bulgePos": pos,
                    "bulgeSize": 1,
                    "totalMismatchCount": mm,
                    "mismatches": mismatches,
                    "alignedGuide": guide_seq,
                    "alignedTarget": aligned_target,
                }
            )

        candidates.sort(
            key=lambda c: (
                int(c.get("totalMismatchCount") or 0),
                {"NONE": 0, "DNA": 1, "RNA": 2}.get(str(c.get("bulgeType") or "NONE").upper(), 3),
            )
        )
        chosen = candidates[0]

        positions = []
        for mismatch in chosen.get("mismatches", []):
            if isinstance(mismatch, Mapping) and "position" in mismatch:
                try:
                    positions.append(int(mismatch.get("position")))
                except Exception:
                    continue
        positions = sorted(set(p for p in positions if p is not None))
        total_mm = int(chosen.get("totalMismatchCount") or len(positions))
        seed_mm = len([p for p in positions if p >= seed_start])

        bulge_type = str(chosen.get("bulgeType") or "NONE").upper()
        bulge_pos = chosen.get("bulgePos")
        try:
            bulge_pos_int = int(bulge_pos) if bulge_pos is not None else None
        except Exception:
            bulge_pos_int = None
        effective_distance = total_mm + (1 if bulge_type != "NONE" else 0)

        pam_seq = str(entry.get("pam_seq") or "")
        pam_class = _classify_pam(pam_seq, pam_pattern)

        score, tier, notes = score_offtarget_hit(
            total_mm=total_mm,
            seed_mm=seed_mm,
            pam_class=pam_class,
            pam_ok=True,
            bulge_type=bulge_type,
            bulge_pos=bulge_pos_int,
            guide_len=guide_len,
        )

        return {
            "guide_id": None,
            "contig": contig,
            "strand": strand,
            "start": guide_start,
            "end": guide_end,
            "distance": total_mm,
            "pam_ok": True,
            "pamSequence": pam_seq,
            "pamClass": pam_class,
            "mismatches": chosen.get("mismatches", []),
            "mismatchPositions": positions,
            "totalMismatchCount": total_mm,
            "seedMismatchCount": seed_mm,
            "bulgeType": bulge_type,
            "bulgePos": bulge_pos_int,
            "bulgeSize": int(chosen.get("bulgeSize") or 0),
            "effectiveDistance": effective_distance,
            "riskScore": score,
            "riskTier": tier,
            "notes": notes,
            "alignedGuide": str(chosen.get("alignedGuide") or ""),
            "alignedTarget": str(chosen.get("alignedTarget") or ""),
        }


__all__ = ["BulgeOffTargetProvider"]
