from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Mapping, Protocol

from helix.studio.experiment_spec import experiment_spec_to_dict
from helix.studio.session import SessionModel
from helix.studio.run_artifact import artifact_is_valid, artifact_root_causes

RLOKS_PROVIDER_ID = "offtarget_rloks_v1"

try:  # pragma: no cover - optional dependency
    from pydantic import BaseModel, ConfigDict, Field

    PYDANTIC_AVAILABLE = True
except Exception:  # pragma: no cover - fallback path
    BaseModel = object  # type: ignore
    Field = lambda *args, **kwargs: None  # type: ignore
    PYDANTIC_AVAILABLE = False

LOGGER = logging.getLogger(__name__)


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n").encode(
        "utf-8"
    )


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def normalize_target_id(guide: Mapping[str, Any] | None) -> str | None:
    if not isinstance(guide, Mapping):
        return None
    for key in ("targetId", "target_id", "target"):
        value = guide.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def base_hit_key(hit: Mapping[str, Any]) -> str:
    key = hit.get("hitKey")
    if isinstance(key, str) and key.strip():
        return key.strip()
    contig = str(hit.get("contig") or "")
    strand = str(hit.get("strand") or "")
    try:
        start = int(hit.get("start", 0))
        end = int(hit.get("end", start + 1))
    except Exception:
        start = 0
        end = 0
    return f"{contig}:{start}-{end}:{strand}"


def namespace_hit_key(hit_key: str, target_id: str | None) -> str:
    if target_id:
        return f"{target_id}::{hit_key}"
    return hit_key


def _targets_from_edit_plan(edit_plan: Mapping[str, Any] | None) -> list[Mapping[str, Any]]:
    if not isinstance(edit_plan, Mapping):
        return []
    targets = edit_plan.get("targets")
    if isinstance(targets, list):
        return [t for t in targets if isinstance(t, Mapping)]
    return []


def _guide_from_target(target: Mapping[str, Any]) -> dict[str, Any]:
    guide: dict[str, Any] = {}
    grna = target.get("gRNA") if isinstance(target.get("gRNA"), Mapping) else None
    if grna is None and isinstance(target.get("guide"), Mapping):
        grna = target.get("guide")
    if isinstance(grna, Mapping):
        if "sequence" in grna:
            guide["sequence"] = grna.get("sequence")
        if "pam" in grna:
            guide["pam"] = grna.get("pam")
        if "pamClass" in grna:
            guide["pamClass"] = grna.get("pamClass")
    for key in ("contig", "chr", "chrom"):
        if key in target:
            guide["contig"] = target.get(key)
            break
    for key in ("start", "end", "strand"):
        if key in target:
            guide[key] = target.get(key)
    for key in ("cutIndex", "cut_index"):
        if key in target:
            guide[key] = target.get(key)
            break
    target_id = normalize_target_id(target)
    if target_id:
        guide["targetId"] = target_id
    return guide


def _guide_sort_key(entry: Mapping[str, Any]) -> tuple[str, str]:
    target_id = normalize_target_id(entry) or ""
    seq = str(entry.get("sequence") or "")
    return (target_id, seq)


def _genome_digest(genome_sequences: Mapping[str, Any] | None) -> list[dict[str, Any]]:
    if not isinstance(genome_sequences, Mapping):
        return []
    entries: list[dict[str, Any]] = []
    for contig in sorted(genome_sequences.keys()):
        seq = genome_sequences.get(contig)
        if not isinstance(seq, str):
            continue
        seq_bytes = seq.encode("utf-8")
        entries.append(
            {
                "contig": str(contig),
                "length": len(seq),
                "sha256": _sha256_hex(seq_bytes),
            }
        )
    return entries


def compute_inputs_sha256(
    experiment_spec: Mapping[str, Any] | None,
    guide: Mapping[str, Any] | None,
    genome_sequences: Mapping[str, Any] | None,
    params: Mapping[str, Any] | None,
) -> str:
    payload = {
        "experimentSpec": experiment_spec_to_dict(experiment_spec),
        "guide": dict(guide or {}),
        "genome": _genome_digest(genome_sequences),
        "params": dict(params or {}),
    }
    return _sha256_hex(_canonical_json_bytes(payload))


if PYDANTIC_AVAILABLE:

    class OffTargetReportV1(BaseModel):
        model_config = ConfigDict(extra="allow", populate_by_name=True)

        schema_: str = Field(default="helix_offtarget_report_v1", alias="schema")
        model_id: str = Field(alias="modelId")
        model_version: str = Field(alias="modelVersion")
        inputs_sha256: str = Field(alias="inputsSha256")
        summary: list[str] = Field(default_factory=list)
        guide: dict[str, Any] = Field(default_factory=dict)
        genome: dict[str, Any] = Field(default_factory=dict)
        params: dict[str, Any] = Field(default_factory=dict)
        hits: list[dict[str, Any]] = Field(default_factory=list)
        total_hits: int | None = Field(default=None, alias="totalHits")
        hit_cap: int | None = Field(default=None, alias="hitCap")
        is_truncated: bool | None = Field(default=None, alias="isTruncated")
        hits_returned: int | None = Field(default=None, alias="hitsReturned")
        max_mismatches: int | None = Field(default=None, alias="maxMismatches")
        high_risk_count: int | None = Field(default=None, alias="highRiskCount")
        medium_risk_count: int | None = Field(default=None, alias="mediumRiskCount")
        low_risk_count: int | None = Field(default=None, alias="lowRiskCount")

        @property
        def schema(self) -> str:
            return self.schema_
else:
    from dataclasses import dataclass, field

    @dataclass
    class OffTargetReportV1:
        schema: str = "helix_offtarget_report_v1"
        model_id: str = ""
        model_version: str = ""
        inputs_sha256: str = ""
        summary: list[str] = field(default_factory=list)
        guide: dict[str, Any] = field(default_factory=dict)
        genome: dict[str, Any] = field(default_factory=dict)
        params: dict[str, Any] = field(default_factory=dict)
        hits: list[dict[str, Any]] = field(default_factory=list)
        total_hits: int | None = None
        hit_cap: int | None = None
        is_truncated: bool | None = None
        hits_returned: int | None = None
        max_mismatches: int | None = None
        high_risk_count: int | None = None
        medium_risk_count: int | None = None
        low_risk_count: int | None = None


class OffTargetProvider(Protocol):
    provider_id: str
    provider_version: str

    def run(
        self,
        experiment_spec: Mapping[str, Any] | None,
        guide: Mapping[str, Any] | None,
        genome_sequences: Mapping[str, Any] | None,
        params: Mapping[str, Any] | None,
        reference_accessor: Any | None = None,
    ) -> OffTargetReportV1: ...


class OffTargetProviderRegistry:
    def __init__(self) -> None:
        self._providers: dict[str, OffTargetProvider] = {}
        self._default_id: str | None = None
        self._order: list[str] = []

    def register(self, provider: OffTargetProvider, *, default: bool = False) -> None:
        key = getattr(provider, "provider_id", "").strip() or provider.__class__.__name__
        self._providers[key] = provider
        if key not in self._order:
            self._order.append(key)
        if default or self._default_id is None:
            self._default_id = key

    def get(self, provider_id: str | None = None) -> OffTargetProvider:
        key = provider_id or self._default_id
        if not key or key not in self._providers:
            raise KeyError(f"Off-target provider not registered: {provider_id}")
        return self._providers[key]

    def set_default(self, provider_id: str) -> None:
        if provider_id not in self._providers:
            raise KeyError(f"Off-target provider not registered: {provider_id}")
        self._default_id = provider_id

    def list(self) -> list[str]:
        return sorted(self._providers.keys())

    def select(
        self,
        experiment_spec: Mapping[str, Any] | None,
        guide: Mapping[str, Any] | None,
        genome_sequences: Mapping[str, Any] | None,
        params: Mapping[str, Any] | None,
    ) -> OffTargetProvider:
        for key in self._order:
            provider = self._providers.get(key)
            if provider is None:
                continue
            can_handle = getattr(provider, "can_handle", None)
            if callable(can_handle):
                try:
                    if bool(can_handle(experiment_spec, guide, genome_sequences, params)):
                        return provider
                except Exception:
                    continue
        return self.get(self._default_id)


_DEFAULT_REGISTRY: OffTargetProviderRegistry | None = None


def get_default_registry() -> OffTargetProviderRegistry:
    global _DEFAULT_REGISTRY
    if _DEFAULT_REGISTRY is None:
        _DEFAULT_REGISTRY = OffTargetProviderRegistry()
        try:
            from .noop import NoopOffTargetProvider

            _DEFAULT_REGISTRY.register(NoopOffTargetProvider(), default=True)
        except Exception as exc:
            LOGGER.debug("Off-target registry could not register noop provider: %s", exc)
        try:
            from .mismatch_provider import MismatchOffTargetProvider

            _DEFAULT_REGISTRY.register(MismatchOffTargetProvider())
        except Exception as exc:
            LOGGER.debug("Off-target registry could not register mismatch provider: %s", exc)
        try:
            from .bulge_provider import BulgeOffTargetProvider

            _DEFAULT_REGISTRY.register(BulgeOffTargetProvider())
        except Exception as exc:
            LOGGER.debug("Off-target registry could not register bulge provider: %s", exc)
        try:
            from .rloks_provider import RLoCKSOffTargetProvider

            _DEFAULT_REGISTRY.register(RLoCKSOffTargetProvider())
        except Exception as exc:
            LOGGER.debug("Off-target registry could not register RLoCKS provider: %s", exc)
    return _DEFAULT_REGISTRY


def offtarget_report_to_dict(report: OffTargetReportV1) -> dict[str, Any]:
    if PYDANTIC_AVAILABLE and hasattr(report, "model_dump"):
        return report.model_dump(exclude_none=True, by_alias=True)
    if isinstance(report, dict):
        return dict(report)
    try:
        from dataclasses import asdict, is_dataclass

        if is_dataclass(report):
            raw = asdict(report)
            payload = {
                "schema": raw.get("schema", "helix_offtarget_report_v1"),
                "modelId": raw.get("model_id", ""),
                "modelVersion": raw.get("model_version", ""),
                "inputsSha256": raw.get("inputs_sha256", ""),
                "summary": raw.get("summary", []),
                "guide": raw.get("guide", {}),
                "genome": raw.get("genome", {}),
                "params": raw.get("params", {}),
                "hits": raw.get("hits", []),
            }
            if raw.get("total_hits") is not None:
                payload["totalHits"] = raw.get("total_hits")
            if raw.get("hit_cap") is not None:
                payload["hitCap"] = raw.get("hit_cap")
            if raw.get("is_truncated") is not None:
                payload["isTruncated"] = raw.get("is_truncated")
            if raw.get("hits_returned") is not None:
                payload["hitsReturned"] = raw.get("hits_returned")
            if raw.get("max_mismatches") is not None:
                payload["maxMismatches"] = raw.get("max_mismatches")
            if raw.get("high_risk_count") is not None:
                payload["highRiskCount"] = raw.get("high_risk_count")
            if raw.get("medium_risk_count") is not None:
                payload["mediumRiskCount"] = raw.get("medium_risk_count")
            if raw.get("low_risk_count") is not None:
                payload["lowRiskCount"] = raw.get("low_risk_count")
            return payload
    except Exception:
        pass
    return {}


def offtarget_report_json_bytes(report: OffTargetReportV1) -> bytes:
    return _canonical_json_bytes(offtarget_report_to_dict(report))


def compute_offtargets_for_session(
    session: SessionModel | None,
    *,
    guide: Mapping[str, Any] | None = None,
    genome_sequences: Mapping[str, Any] | None = None,
    params: Mapping[str, Any] | None = None,
    provider_id: str | None = None,
    edit_plan: Mapping[str, Any] | None = None,
) -> OffTargetReportV1:
    registry = get_default_registry()
    if session is not None:
        try:
            artifact = session.ensure_run_artifact()
        except Exception:
            artifact = None
        if artifact is not None and not artifact_is_valid(artifact):
            blocked = []
            validity = artifact.get("validity") if isinstance(artifact.get("validity"), Mapping) else {}
            if isinstance(validity, Mapping):
                blocked = validity.get("blocked_features") if isinstance(validity.get("blocked_features"), list) else []
            blocked = {str(b) for b in blocked if str(b)}
            # Only hard-block if the artifact explicitly blocks off-target work (e.g., missing FM index).
            if "off_target" in blocked:
                reasons = artifact_root_causes(artifact)
                summary = ["off-target computation blocked"] + [str(r) for r in reasons]
                return OffTargetReportV1(
                    model_id="blocked",
                    model_version="0",
                    inputs_sha256="",
                    summary=summary,
                    guide={},
                    genome={},
                    params={},
                    hits=[],
                    total_hits=0,
                )
    experiment_spec = session.state.experiment_spec if session is not None else {}
    if guide is None and session is not None:
        try:
            cfg = session.state.config
            if isinstance(cfg, Mapping):
                guide = cfg.get("guide")
        except Exception:
            guide = None
    if edit_plan is None and session is not None:
        try:
            candidate = session.state.edit_plan
            if isinstance(candidate, Mapping):
                edit_plan = candidate
        except Exception:
            edit_plan = None
    if params is None and session is not None:
        try:
            cfg = session.state.config
            if isinstance(cfg, Mapping):
                params = cfg.get("offtarget") or {}
        except Exception:
            params = None
    if provider_id is None and isinstance(params, Mapping):
        provider_id = (
            params.get("provider_id")
            or params.get("providerId")
            or params.get("provider")
            or params.get("offtargetProvider")
        )
    if provider_id is None and isinstance(params, Mapping):
        pack_id = params.get("rloks_pack_id") or params.get("rloksPackId")
        if isinstance(pack_id, str) and pack_id.strip():
            provider_id = RLOKS_PROVIDER_ID
    if genome_sequences is None and session is not None:
        try:
            genome = session.state.genome
            genome_sequences = getattr(genome, "sequences", None)
        except Exception:
            genome_sequences = None
    if provider_id:
        provider = registry.get(provider_id)
    else:
        provider = registry.select(experiment_spec, guide, genome_sequences, params)
    reference_accessor = None
    try:
        from .reference_accessor import build_reference_cache_from_config, get_default_reference_cache

        cache_cfg = None
        if session is not None:
            try:
                cfg = session.state.config
                if isinstance(cfg, Mapping):
                    cache_cfg = cfg.get("reference_cache") or cfg.get("referenceCache")
            except Exception:
                cache_cfg = None
        if isinstance(cache_cfg, Mapping):
            cache = build_reference_cache_from_config(cache_cfg)
        else:
            cache = get_default_reference_cache()
        reference_accessor = cache.accessor(genome_sequences)
    except Exception:
        reference_accessor = None
    targets = _targets_from_edit_plan(edit_plan)
    if len(targets) > 1:
        guides = [_guide_from_target(t) for t in targets]
        guides = [g for g in guides if isinstance(g, Mapping) and (g.get("sequence") or g.get("contig"))]
        if guides:
            guides.sort(key=_guide_sort_key)
            combined_hits: list[dict[str, Any]] = []
            truncated_any = False
            provider_id_local = None
            provider_version_local = None
            resolved_params = dict(params or {})
            max_mismatches = None
            for guide_entry in guides:
                local_provider = registry.select(experiment_spec, guide_entry, genome_sequences, params)
                local_report = local_provider.run(
                    experiment_spec,
                    guide_entry,
                    genome_sequences,
                    params,
                    reference_accessor=reference_accessor,
                )
                payload = offtarget_report_to_dict(local_report)
                if provider_id_local is None:
                    provider_id_local = payload.get("modelId") or getattr(local_provider, "provider_id", "")
                    provider_version_local = payload.get("modelVersion") or getattr(local_provider, "provider_version", "")
                local_hits = payload.get("hits") if isinstance(payload.get("hits"), list) else []
                for hit in local_hits:
                    if isinstance(hit, Mapping):
                        combined_hits.append(dict(hit))
                if bool(payload.get("isTruncated")):
                    truncated_any = True
                if max_mismatches is None:
                    max_mismatches = payload.get("maxMismatches")
                if payload.get("params") and isinstance(payload.get("params"), Mapping):
                    resolved_params = dict(payload.get("params") or {})

            combined_hits.sort(
                key=lambda h: (
                    int(h.get("effectiveDistance", h.get("distance", 0)) or 0),
                    int(h.get("totalMismatchCount", h.get("distance", 0)) or 0),
                    {"NONE": 0, "DNA": 1, "RNA": 2}.get(str(h.get("bulgeType") or "NONE").upper(), 3),
                    str(h.get("contig") or ""),
                    int(h.get("start") or 0),
                )
            )
            high_count = 0
            medium_count = 0
            low_count = 0
            for hit in combined_hits:
                tier = str(hit.get("riskTier") or "")
                if tier == "High":
                    high_count += 1
                elif tier == "Medium":
                    medium_count += 1
                else:
                    low_count += 1

            guide_payload = {
                "mode": "multiplex",
                "targets": [dict(g) for g in guides],
            }
            inputs_sha = compute_inputs_sha256(experiment_spec, guide_payload, genome_sequences, resolved_params)
            summary = [
                f"Multiplex off-target search across {len(guides)} target(s).",
                f"{len(combined_hits)} candidate site(s) scored.",
            ]
            if truncated_any:
                hit_cap = resolved_params.get("max_hits")
                if hit_cap is not None:
                    summary.append(f"Truncated to top {hit_cap} hits per target.")
            genome_meta = {"contigs": _genome_digest(genome_sequences)}
            return OffTargetReportV1(
                model_id=provider_id_local or provider.provider_id,
                model_version=provider_version_local or provider.provider_version,
                inputs_sha256=inputs_sha,
                summary=summary,
                guide=guide_payload,
                genome=genome_meta,
                params=resolved_params,
                hits=combined_hits,
                total_hits=None if truncated_any else len(combined_hits),
                hit_cap=resolved_params.get("max_hits"),
                is_truncated=truncated_any,
                hits_returned=len(combined_hits),
                max_mismatches=max_mismatches if max_mismatches is not None else resolved_params.get("max_mm"),
                high_risk_count=high_count,
                medium_risk_count=medium_count,
                low_risk_count=low_count,
            )

    return provider.run(experiment_spec, guide, genome_sequences, params, reference_accessor=reference_accessor)


__all__ = [
    "OffTargetReportV1",
    "OffTargetProvider",
    "OffTargetProviderRegistry",
    "compute_inputs_sha256",
    "compute_offtargets_for_session",
    "get_default_registry",
    "offtarget_report_json_bytes",
    "offtarget_report_to_dict",
]
