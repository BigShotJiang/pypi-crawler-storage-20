from __future__ import annotations

import hashlib
from collections import OrderedDict
from typing import Any, Iterable, Mapping, Sequence

from helix import bioinformatics
from helix.crispr.pam import PAM, get_pam, match_pam, reverse_complement_pattern


class LRUCache:
    def __init__(self, max_entries: int) -> None:
        self._max_entries = max(0, int(max_entries))
        self._data: OrderedDict[tuple[Any, ...], Any] = OrderedDict()

    def get(self, key: tuple[Any, ...]) -> Any | None:
        if self._max_entries <= 0:
            return None
        if key not in self._data:
            return None
        value = self._data.pop(key)
        self._data[key] = value
        return value

    def set(self, key: tuple[Any, ...], value: Any) -> None:
        if self._max_entries <= 0:
            return
        if key in self._data:
            self._data.pop(key)
        self._data[key] = value
        while len(self._data) > self._max_entries:
            self._data.popitem(last=False)


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _pam_pattern(pam: Any) -> str | None:
    if isinstance(pam, str):
        try:
            pam_def = get_pam(pam)
            return pam_def.get("pattern")
        except Exception:
            return None
    if isinstance(pam, Mapping):
        return str(pam.get("pattern") or "") or None
    if isinstance(pam, PAM):
        return str(pam.as_dict().get("pattern") or "") or None
    return None


def _pam_key(pam: Any) -> str:
    pattern = _pam_pattern(pam)
    if pattern:
        return pattern.upper()
    return str(pam or "").upper()


class ReferenceAccessor:
    def __init__(
        self,
        genome_sequences: Mapping[str, Any] | None,
        *,
        window_cache: LRUCache,
        pam_cache: LRUCache,
        target_cache: LRUCache,
    ) -> None:
        self._genome = genome_sequences if isinstance(genome_sequences, Mapping) else {}
        self._window_cache = window_cache
        self._pam_cache = pam_cache
        self._target_cache = target_cache
        self._contig_hash: dict[str, str] = {}
        self._contig_len: dict[str, int] = {}
        self._contigs: list[str] = []
        for contig in sorted(self._genome.keys()):
            seq = self._genome.get(contig)
            if not isinstance(seq, str):
                continue
            self._contigs.append(str(contig))
            self._contig_len[str(contig)] = len(seq)
            self._contig_hash[str(contig)] = _sha256_hex(seq.encode("utf-8"))

    def contigs(self) -> Sequence[str]:
        return self._contigs

    def contig_length(self, contig: str) -> int:
        return int(self._contig_len.get(str(contig), 0))

    def _contig_hash_value(self, contig: str) -> str:
        return self._contig_hash.get(str(contig), "")

    def get_window(
        self,
        contig: str,
        start: int,
        end: int,
        *,
        strand: str = "+",
        normalize: bool = False,
    ) -> str:
        contig = str(contig)
        seq = self._genome.get(contig)
        if not isinstance(seq, str):
            return ""
        try:
            start_int = int(start)
            end_int = int(end)
        except Exception:
            return ""
        expected_len = max(0, end_int - start_int)
        key = (contig, start_int, end_int, str(strand), bool(normalize), self._contig_hash_value(contig))
        cached = self._window_cache.get(key)
        if cached is not None:
            return cached
        window = seq[start_int:end_int]
        if len(window) != expected_len:
            raise ValueError(
                f"Reference window length mismatch for {contig}:{start_int}-{end_int} "
                f"(expected {expected_len}, got {len(window)})"
            )
        if normalize:
            window = bioinformatics.normalize_sequence(window).upper()
        if strand == "-":
            window = bioinformatics.reverse_complement(window)
        self._window_cache.set(key, window)
        return window

    def iter_pam_sites(
        self,
        contig: str,
        window_start: int,
        window_end: int,
        pam: Any,
        *,
        strand_policy: str = "both",
    ) -> list[tuple[int, str]]:
        contig = str(contig)
        seq = self._genome.get(contig)
        if not isinstance(seq, str):
            return []
        try:
            start_int = int(window_start)
            end_int = int(window_end)
        except Exception:
            return []
        if end_int <= start_int:
            return []
        pam_key = _pam_key(pam)
        strand_policy = str(strand_policy or "both").lower()
        cache_key = (contig, start_int, end_int, pam_key, strand_policy, self._contig_hash_value(contig))
        cached = self._pam_cache.get(cache_key)
        if cached is not None:
            return list(cached)

        pam_pattern = _pam_pattern(pam)
        if not pam_pattern:
            return []
        pam_len = len(pam_pattern)
        if pam_len <= 0:
            return []

        pam_def = get_pam(pam) if isinstance(pam, str) else pam
        rc_pattern = reverse_complement_pattern(pam_pattern)
        rc_pam_def = {"pattern": rc_pattern}

        window = seq[start_int:end_int]
        window_norm = bioinformatics.normalize_sequence(window).upper()
        if len(window) != max(0, end_int - start_int):
            raise ValueError(
                f"PAM window length mismatch for {contig}:{start_int}-{end_int} "
                f"(expected {max(0, end_int - start_int)}, got {len(window)})"
            )
        max_idx = len(window_norm) - pam_len
        if max_idx < 0:
            return []

        hits: list[tuple[int, str]] = []
        check_plus = strand_policy in {"both", "+", "plus", "forward"}
        check_minus = strand_policy in {"both", "-", "minus", "reverse"}
        for offset in range(0, max_idx + 1):
            if check_plus and match_pam(window_norm, pam_def, offset):
                hits.append((start_int + offset, "+"))
            if check_minus and match_pam(window_norm, rc_pam_def, offset):
                hits.append((start_int + offset, "-"))

        for pos, strand in hits:
            offset = int(pos) - start_int
            if strand == "+":
                if not match_pam(window_norm, pam_def, offset):
                    raise ValueError(f"PAM cache mismatch at {contig}:{pos} (+)")
            else:
                if not match_pam(window_norm, rc_pam_def, offset):
                    raise ValueError(f"PAM cache mismatch at {contig}:{pos} (-)")

        self._pam_cache.set(cache_key, tuple(hits))
        return hits

    def prefetch_pam_targets(
        self,
        contig: str,
        window_start: int,
        window_end: int,
        pam: Any,
        *,
        guide_len: int,
        normalize: bool = True,
        strand_policy: str = "both",
    ) -> list[dict[str, Any]]:
        contig = str(contig)
        seq = self._genome.get(contig)
        if not isinstance(seq, str):
            return []
        try:
            start_int = int(window_start)
            end_int = int(window_end)
            guide_len_int = int(guide_len)
        except Exception:
            return []
        if guide_len_int <= 0 or end_int <= start_int:
            return []
        pam_pattern = _pam_pattern(pam)
        if not pam_pattern:
            return []
        pam_len = len(pam_pattern)
        if pam_len <= 0:
            return []

        pam_key = _pam_key(pam)
        cache_key = (
            contig,
            start_int,
            end_int,
            pam_key,
            guide_len_int,
            bool(normalize),
            str(strand_policy),
            self._contig_hash_value(contig),
        )
        cached = self._target_cache.get(cache_key)
        if cached is not None:
            return list(cached)

        contig_len = self.contig_length(contig)
        pam_sites = self.iter_pam_sites(
            contig,
            start_int,
            end_int,
            pam,
            strand_policy=strand_policy,
        )
        targets: list[dict[str, Any]] = []
        for pam_pos, strand in pam_sites:
            if strand == "+":
                guide_end = int(pam_pos)
                guide_start = guide_end - guide_len_int
            else:
                guide_start = int(pam_pos) + pam_len
                guide_end = guide_start + guide_len_int
            if guide_start < 0 or guide_end > contig_len:
                continue
            target20 = self.get_window(
                contig,
                guide_start,
                guide_end,
                strand=strand,
                normalize=normalize,
            )
            if len(target20) != guide_len_int:
                continue
            target21 = None
            target19 = None
            if strand == "+":
                if guide_start - 1 >= 0:
                    target21 = self.get_window(
                        contig,
                        guide_start - 1,
                        guide_end,
                        strand=strand,
                        normalize=normalize,
                    )
                if guide_start + 1 < guide_end:
                    target19 = self.get_window(
                        contig,
                        guide_start + 1,
                        guide_end,
                        strand=strand,
                        normalize=normalize,
                    )
            else:
                if guide_end + 1 <= contig_len:
                    target21 = self.get_window(
                        contig,
                        guide_start,
                        guide_end + 1,
                        strand=strand,
                        normalize=normalize,
                    )
                if guide_end - 1 > guide_start:
                    target19 = self.get_window(
                        contig,
                        guide_start,
                        guide_end - 1,
                        strand=strand,
                        normalize=normalize,
                    )
            pam_seq = self.get_window(
                contig,
                int(pam_pos),
                int(pam_pos) + pam_len,
                strand=strand,
                normalize=normalize,
            )
            targets.append(
                {
                    "pam_pos": int(pam_pos),
                    "strand": strand,
                    "pam_seq": pam_seq,
                    "target20": target20,
                    "target21": target21,
                    "target19": target19,
                }
            )

        self._target_cache.set(cache_key, tuple(targets))
        return targets


class OffTargetReferenceCache:
    def __init__(
        self,
        *,
        window_cache_size: int = 128,
        pam_cache_size: int = 128,
        target_cache_size: int = 128,
    ) -> None:
        self._window_cache = LRUCache(window_cache_size)
        self._pam_cache = LRUCache(pam_cache_size)
        self._target_cache = LRUCache(target_cache_size)

    def accessor(self, genome_sequences: Mapping[str, Any] | None) -> ReferenceAccessor:
        return ReferenceAccessor(
            genome_sequences,
            window_cache=self._window_cache,
            pam_cache=self._pam_cache,
            target_cache=self._target_cache,
        )


_DEFAULT_CACHE: OffTargetReferenceCache | None = None


def get_default_reference_cache() -> OffTargetReferenceCache:
    global _DEFAULT_CACHE
    if _DEFAULT_CACHE is None:
        _DEFAULT_CACHE = OffTargetReferenceCache()
    return _DEFAULT_CACHE


def build_reference_cache_from_config(config: Mapping[str, Any] | None) -> OffTargetReferenceCache:
    cfg = config if isinstance(config, Mapping) else {}
    enabled = True
    if "enabled" in cfg:
        try:
            enabled = bool(cfg.get("enabled"))
        except Exception:
            enabled = True
    if not enabled:
        return OffTargetReferenceCache(window_cache_size=0, pam_cache_size=0, target_cache_size=0)

    def _read_int(*keys: str, default: int) -> int:
        for key in keys:
            if key in cfg:
                try:
                    return int(cfg.get(key))
                except Exception:
                    return default
        return default

    max_windows = _read_int("max_windows", "maxWindows", default=128)
    max_pam = _read_int("max_pam_scans", "maxPamScans", default=128)
    max_prefetch = _read_int("max_prefetch_targets", "maxPrefetchTargets", default=128)
    return OffTargetReferenceCache(
        window_cache_size=max_windows,
        pam_cache_size=max_pam,
        target_cache_size=max_prefetch,
    )


__all__ = [
    "LRUCache",
    "ReferenceAccessor",
    "OffTargetReferenceCache",
    "get_default_reference_cache",
    "build_reference_cache_from_config",
]
