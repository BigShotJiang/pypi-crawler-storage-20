from __future__ import annotations

from typing import Any, Mapping

from helix.studio.experiment_spec import experiment_spec_to_dict

from .model import OffTargetReportV1, compute_inputs_sha256


class NoopOffTargetProvider:
    provider_id = "offtarget_noop"
    provider_version = "v1"

    def run(
        self,
        experiment_spec: Mapping[str, Any] | None,
        guide: Mapping[str, Any] | None,
        genome_sequences: Mapping[str, Any] | None,
        params: Mapping[str, Any] | None,
        reference_accessor: Any | None = None,
    ) -> OffTargetReportV1:
        missing: list[str] = []
        spec = experiment_spec_to_dict(experiment_spec)
        if not spec:
            missing.append("experimentSpec")
        guide_seq = ""
        if isinstance(guide, Mapping):
            guide_seq = str(guide.get("sequence") or "")
        if not guide_seq:
            missing.append("guide.sequence")
        if not isinstance(genome_sequences, Mapping) or not genome_sequences:
            missing.append("genome.sequences")

        summary = [
            "Inputs incomplete; off-target search not run.",
        ]
        if missing:
            summary.append("Missing: " + ", ".join(missing))

        inputs_sha = compute_inputs_sha256(experiment_spec, guide, genome_sequences, params)
        max_hits = None
        max_mm = None
        if isinstance(params, Mapping):
            max_hits = params.get("max_hits")
            max_mm = params.get("max_mm") or params.get("max_mismatch")
        return OffTargetReportV1(
            model_id=self.provider_id,
            model_version=self.provider_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            guide=dict(guide or {}),
            genome={},
            params=dict(params or {}),
            hits=[],
            total_hits=0,
            hit_cap=int(max_hits) if max_hits is not None else None,
            is_truncated=False,
            hits_returned=0,
            max_mismatches=int(max_mm) if max_mm is not None else None,
        )


__all__ = ["NoopOffTargetProvider"]
