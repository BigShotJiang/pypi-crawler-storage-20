from __future__ import annotations

from collections.abc import Mapping
import hashlib
import json
from typing import Any

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QButtonGroup,
    QFrame,
    QHBoxLayout,
    QLabel,
    QComboBox,
    QLineEdit,
    QTableWidget,
    QTableWidgetItem,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
    QHeaderView,
)

from helix import bioinformatics
from helix.studio.experiment_spec import experiment_spec_to_dict
from helix.studio.offtargets.model import compute_offtargets_for_session, offtarget_report_json_bytes
from helix.studio.offtargets.rloks_provider import stream_rloks_report
from helix.studio.offtargets.rloks_ui_helpers import (
    RLOKS_PROVIDER_ID,
    build_top_risk_drivers,
    extract_rloks_pack_fields,
    get_tooltip,
    update_rloks_config,
)
from helix.studio.offtargets.validation_plan import build_validation_plan, validation_plan_sha256
from helix.studio.assays.primer_design import build_primer_plan
from helix.studio.assays.assay_chooser import build_assay_plan
from helix.studio.outcomes.model import compute_outcomes_for_current_plan, outcome_report_to_dict
from helix.studio.outcomes.clone_yield import build_clone_plan
from helix.studio.session import SessionModel, RunKind
from helix.studio.ui_tokens import MARGIN_PANEL, SPACING_MEDIUM, SPACING_SMALL, base_font
from helix.studio.workers import CancelToken, run_bg_stream


class OffTargetListPanel(QWidget):
    def __init__(self, session: SessionModel | None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._session = session
        self._hits: list[dict[str, Any]] = []
        self._stable_hits: list[dict[str, Any]] = []
        self._risk_hits: list[dict[str, Any]] = []
        self._visible_hits: list[dict[str, Any]] = []
        self._primer_by_key: dict[str, dict[str, Any]] = {}
        self._assay_by_key: dict[str, dict[str, Any]] = {}
        self._is_truncated = False
        self._syncing = False
        self._rloks_pack_dirty = False
        self._rloks_schema_version = ""
        self._stream_token = CancelToken()
        self._compare_token = CancelToken()
        self._compare_enabled = False
        self._compare_running = False
        self._compare_deltas_risk: dict[str, float] = {}
        self._compare_deltas_score: dict[str, float] = {}
        self._compare_pack_id = "rloks_v0.1.0"
        self._stream_hits_by_index: dict[int, dict[str, Any]] = {}
        self._compare_hits_by_index: dict[int, dict[str, Any]] = {}
        self._stream_total = 0
        self._streaming = False
        self._sort_mode = "stable"  # "stable" or "risk"

        self.setFont(base_font())
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(SPACING_MEDIUM)

        header = QHBoxLayout()
        header.setSpacing(SPACING_SMALL)
        self._toggle = QToolButton(self)
        self._toggle.setCheckable(True)
        self._toggle.setChecked(True)
        self._toggle.setArrowType(Qt.DownArrow)
        self._toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._toggle.setText("Off-targets")
        header.addWidget(self._toggle)
        header.addStretch(1)

        self._jump_button = QToolButton(self)
        self._jump_button.setText("Jump to locus")
        self._jump_button.setEnabled(False)
        header.addWidget(self._jump_button)

        root.addLayout(header)

        self._body = QFrame(self)
        body_layout = QVBoxLayout(self._body)
        body_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        body_layout.setSpacing(SPACING_MEDIUM)

        self._summary_label = QLabel("Awaiting off-target report.", self)
        self._summary_label.setWordWrap(True)
        body_layout.addWidget(self._summary_label)

        self._rloks_panel = QFrame(self)
        self._rloks_panel.setStyleSheet("background: #0f172a; border: 1px solid #1e293b; border-radius: 6px;")
        rloks_layout = QVBoxLayout(self._rloks_panel)
        rloks_layout.setContentsMargins(SPACING_SMALL, SPACING_SMALL, SPACING_SMALL, SPACING_SMALL)
        rloks_layout.setSpacing(SPACING_SMALL)

        self._rloks_title = QLabel("RLoCKS pack (audit-critical)", self)
        self._rloks_title.setStyleSheet("color: #e2e8f0; font-weight: 600;")
        rloks_layout.addWidget(self._rloks_title)

        rloks_row = QHBoxLayout()
        rloks_row.setSpacing(SPACING_SMALL)
        rloks_row.addWidget(QLabel("Pack ID", self))
        self._rloks_pack_edit = QLineEdit(self)
        self._rloks_pack_edit.setPlaceholderText("rloks_v0.1.0")
        self._rloks_pack_edit.setClearButtonEnabled(True)
        rloks_row.addWidget(self._rloks_pack_edit, 1)
        self._rloks_apply = QToolButton(self)
        self._rloks_apply.setText("Apply")
        self._rloks_apply.setEnabled(False)
        rloks_row.addWidget(self._rloks_apply)
        self._rloks_cancel = QToolButton(self)
        self._rloks_cancel.setText("Cancel")
        self._rloks_cancel.setEnabled(False)
        rloks_row.addWidget(self._rloks_cancel)
        self._compare_toggle = QToolButton(self)
        self._compare_toggle.setText("Compare to v0.1.0")
        self._compare_toggle.setCheckable(True)
        self._compare_toggle.setChecked(False)
        self._compare_toggle.setToolTip("Run a second pass with pack rloks_v0.1.0 and show deltas.")
        rloks_row.addWidget(self._compare_toggle)
        rloks_layout.addLayout(rloks_row)

        meta_row = QHBoxLayout()
        meta_row.setSpacing(SPACING_SMALL)
        self._rloks_fingerprint = QLabel("Fingerprint: —", self)
        self._rloks_fingerprint.setStyleSheet("color: #94a3b8;")
        self._rloks_schema = QLabel("Schema: —", self)
        self._rloks_schema.setStyleSheet("color: #94a3b8;")
        meta_row.addWidget(self._rloks_fingerprint)
        meta_row.addSpacing(SPACING_SMALL)
        meta_row.addWidget(self._rloks_schema)
        meta_row.addStretch(1)
        rloks_layout.addLayout(meta_row)

        self._rloks_error = QLabel("", self)
        self._rloks_error.setWordWrap(True)
        self._rloks_error.setStyleSheet("color: #fecaca;")
        self._rloks_error.hide()
        rloks_layout.addWidget(self._rloks_error)

        body_layout.addWidget(self._rloks_panel)

        self._risk_summary_label = QLabel("", self)
        self._risk_summary_label.setStyleSheet("color: #cbd5f5;")
        self._risk_summary_label.hide()
        body_layout.addWidget(self._risk_summary_label)

        filter_row = QHBoxLayout()
        filter_row.setSpacing(SPACING_SMALL)
        self._contig_filter = QComboBox(self)
        self._contig_filter.addItem("All contigs", None)
        self._target_filter = QComboBox(self)
        self._target_filter.addItem("All targets", None)
        self._mm_filter = QComboBox(self)
        self._mm_filter.addItem("All mismatches", None)
        self._bulge_filter = QComboBox(self)
        self._bulge_filter.addItem("Any bulge", None)
        self._bulge_filter.addItem("None only", "NONE")
        self._bulge_filter.addItem("Bulge only", "BULGE")
        filter_row.addWidget(self._contig_filter)
        filter_row.addWidget(self._target_filter)
        filter_row.addWidget(self._mm_filter)
        filter_row.addWidget(self._bulge_filter)

        self._sort_group = QButtonGroup(self)
        self._sort_group.setExclusive(True)
        self._sort_stable = QToolButton(self)
        self._sort_stable.setText("Stable order")
        self._sort_stable.setCheckable(True)
        self._sort_stable.setChecked(True)
        self._sort_stable.setToolTip("Show candidates in deterministic input order.")
        self._sort_group.addButton(self._sort_stable)
        filter_row.addWidget(self._sort_stable)

        self._sort_risk = QToolButton(self)
        self._sort_risk.setText("Sort by risk")
        self._sort_risk.setCheckable(True)
        self._sort_risk.setChecked(False)
        self._sort_risk.setToolTip("After scoring completes, sort by highest predicted risk.")
        self._sort_group.addButton(self._sort_risk)
        filter_row.addWidget(self._sort_risk)
        filter_row.addStretch(1)
        body_layout.addLayout(filter_row)

        self._truncate_label = QLabel("", self)
        self._truncate_label.setWordWrap(True)
        self._truncate_label.setStyleSheet("color: #fbbf24;")
        self._truncate_label.hide()
        body_layout.addWidget(self._truncate_label)

        self._table = QTableWidget(self)
        self._table.setColumnCount(12)
        self._table.setHorizontalHeaderLabels(
            [
                "Rank",
                "Target",
                "Tier",
                "Assay",
                "Locus",
                "Mismatches",
                "Bulge",
                "Score",
                "Primers",
                "Amplicon",
                "Δp_cleave",
                "ΔScore",
            ]
        )
        self._table.verticalHeader().setVisible(False)
        self._table.setSelectionBehavior(QTableWidget.SelectRows)
        self._table.setSelectionMode(QTableWidget.SingleSelection)
        self._table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._table.setShowGrid(True)
        try:
            header_widget = self._table.horizontalHeader()
            header_widget.setSectionResizeMode(0, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(1, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(2, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(3, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(4, QHeaderView.Stretch)
            header_widget.setSectionResizeMode(5, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(6, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(7, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(8, QHeaderView.Stretch)
            header_widget.setSectionResizeMode(9, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(10, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(11, QHeaderView.ResizeToContents)
        except Exception:
            pass
        body_layout.addWidget(self._table)

        self._empty_label = QLabel("No off-targets to display.", self)
        self._empty_label.hide()
        body_layout.addWidget(self._empty_label)

        self._detail_label = QLabel("", self)
        self._detail_label.setStyleSheet("color: #cbd5f5;")
        self._detail_label.setWordWrap(True)
        self._detail_label.hide()
        body_layout.addWidget(self._detail_label)

        self._explain_header = QLabel("Explanation", self)
        self._explain_header.setStyleSheet("color: #e2e8f0; font-weight: 600;")
        self._explain_header.hide()
        body_layout.addWidget(self._explain_header)

        self._explain_highlights = QLabel("", self)
        self._explain_highlights.setStyleSheet("color: #94a3b8;")
        self._explain_highlights.setWordWrap(True)
        self._explain_highlights.hide()
        body_layout.addWidget(self._explain_highlights)

        self._explain_tree = QTreeWidget(self)
        self._explain_tree.setColumnCount(2)
        self._explain_tree.setHeaderLabels(["Term", "Value"])
        self._explain_tree.header().setStretchLastSection(True)
        self._explain_tree.hide()
        body_layout.addWidget(self._explain_tree)

        root.addWidget(self._body)

        self._toggle.toggled.connect(self._on_toggle)
        self._jump_button.clicked.connect(self._on_jump_clicked)
        self._table.cellDoubleClicked.connect(self._on_row_activated)
        self._table.itemSelectionChanged.connect(self._on_selection_changed)
        self._contig_filter.currentIndexChanged.connect(self._on_filter_changed)
        self._target_filter.currentIndexChanged.connect(self._on_filter_changed)
        self._mm_filter.currentIndexChanged.connect(self._on_filter_changed)
        self._bulge_filter.currentIndexChanged.connect(self._on_filter_changed)
        self._rloks_apply.clicked.connect(self._apply_rloks_settings)
        self._rloks_cancel.clicked.connect(self._cancel_streaming)
        self._rloks_pack_edit.editingFinished.connect(self._apply_rloks_settings)
        self._rloks_pack_edit.textEdited.connect(self._on_rloks_pack_edited)
        self._compare_toggle.toggled.connect(self._on_compare_toggled)
        self._sort_stable.toggled.connect(self._on_sort_mode_changed)
        self._sort_risk.toggled.connect(self._on_sort_mode_changed)

        self._refresh_timer = QTimer(self)
        self._refresh_timer.setSingleShot(True)
        self._refresh_timer.timeout.connect(self._refresh_report)

        if self._session is not None:
            try:
                self._session.stateChanged.connect(self._on_state_changed)
            except Exception:
                pass
        self._refresh_report()

    def _on_toggle(self, checked: bool) -> None:
        try:
            self._body.setVisible(bool(checked))
        except Exception:
            pass
        try:
            self._toggle.setArrowType(Qt.DownArrow if checked else Qt.RightArrow)
        except Exception:
            pass

    def _on_state_changed(self, _state) -> None:
        self._refresh_timer.start(220)

    def _refresh_report(self) -> None:
        if self._syncing:
            return
        if self._should_stream_rloks():
            self._start_rloks_stream()
            return
        self._cancel_streaming(silent=True)
        report = compute_offtargets_for_session(self._session)
        report_bytes = offtarget_report_json_bytes(report)
        try:
            payload = json.loads(report_bytes.decode("utf-8"))
        except Exception:
            payload = {}
        self._render_payload(payload, report_bytes)

    def _should_stream_rloks(self) -> bool:
        if self._session is None:
            return False
        params = self._current_offtarget_params()
        provider_id = ""
        if isinstance(params, Mapping):
            provider_id = (
                str(params.get("provider_id") or "")
                or str(params.get("providerId") or "")
                or str(params.get("provider") or "")
                or str(params.get("offtargetProvider") or "")
            )
        if provider_id != RLOKS_PROVIDER_ID:
            return False
        edit_plan = getattr(self._session.state, "edit_plan", None)
        if isinstance(edit_plan, Mapping):
            targets = edit_plan.get("targets")
            if isinstance(targets, list) and len(targets) > 1:
                return False
        return True

    def _start_rloks_stream(self) -> None:
        if self._session is None:
            return
        self._cancel_streaming(silent=True)
        self._clear_compare_state(reset_toggle=False)
        self._stream_hits_by_index = {}
        self._stream_total = 0
        self._streaming = True
        self._rloks_cancel.setEnabled(True)
        self._set_compare_controls_enabled(False)
        self._set_sort_controls_enabled(False)

        experiment_spec = getattr(self._session.state, "experiment_spec", {}) or {}
        cfg = self._session.state.config if isinstance(self._session.state.config, Mapping) else {}
        guide = cfg.get("guide") if isinstance(cfg.get("guide"), Mapping) else cfg.get("guide")
        params = cfg.get("offtarget") if isinstance(cfg.get("offtarget"), Mapping) else {}
        genome_sequences = getattr(self._session.state.genome, "sequences", None)
        cache_cfg = None
        if isinstance(cfg, Mapping):
            cache_cfg = cfg.get("reference_cache") or cfg.get("referenceCache")
        batch_size = 512
        if isinstance(params, Mapping):
            try:
                batch_size = int(params.get("rloks_batch_size") or params.get("batch_size") or 512)
            except Exception:
                batch_size = 512
        if batch_size <= 0:
            batch_size = 512

        def _work():
            reference_accessor = None
            try:
                from helix.studio.offtargets.reference_accessor import (
                    build_reference_cache_from_config,
                    get_default_reference_cache,
                )

                if isinstance(cache_cfg, Mapping):
                    cache = build_reference_cache_from_config(cache_cfg)
                else:
                    cache = get_default_reference_cache()
                reference_accessor = cache.accessor(genome_sequences)
            except Exception:
                reference_accessor = None
            return stream_rloks_report(
                experiment_spec,
                guide,
                genome_sequences,
                params,
                reference_accessor=reference_accessor,
                batch_size=batch_size,
            )

        def _on_update(update: Any) -> None:
            payload = update.get("payload") if isinstance(update, Mapping) else {}
            report_bytes = update.get("report_bytes") or b""
            if update.get("reset"):
                self._stream_hits_by_index = {}
                self._primer_by_key = {}
                self._assay_by_key = {}
            self._render_payload(payload, report_bytes)
            if update.get("done"):
                self._streaming = False
                self._rloks_cancel.setEnabled(False)
                self._set_sort_controls_enabled(True)
                self._set_compare_controls_enabled(True)

        def _on_err(err: str) -> None:
            self._streaming = False
            self._rloks_cancel.setEnabled(False)
            self._summary_label.setText(err)

        run_bg_stream(_work, _on_update, _on_err, label="RLoCKS stream", token=self._stream_token)

    def _start_compare_stream(self) -> None:
        if self._session is None:
            return
        if self._compare_running:
            return
        self._compare_token.bump()
        self._compare_running = True
        self._compare_hits_by_index = {}
        self._compare_deltas_risk = {}
        self._compare_deltas_score = {}

        experiment_spec = getattr(self._session.state, "experiment_spec", {}) or {}
        cfg = self._session.state.config if isinstance(self._session.state.config, Mapping) else {}
        guide = cfg.get("guide") if isinstance(cfg.get("guide"), Mapping) else cfg.get("guide")
        params = cfg.get("offtarget") if isinstance(cfg.get("offtarget"), Mapping) else {}
        params = dict(params or {})
        params["rloks_pack_id"] = self._compare_pack_id
        genome_sequences = getattr(self._session.state, "genome", None)
        cache_cfg = None
        if isinstance(cfg, Mapping):
            cache_cfg = cfg.get("reference_cache") or cfg.get("referenceCache")
        batch_size = 512
        if isinstance(params, Mapping):
            try:
                batch_size = int(params.get("rloks_batch_size") or params.get("batch_size") or 512)
            except Exception:
                batch_size = 512
        if batch_size <= 0:
            batch_size = 512

        def _work():
            reference_accessor = None
            try:
                from helix.studio.offtargets.reference_accessor import (
                    build_reference_cache_from_config,
                    get_default_reference_cache,
                )

                if isinstance(cache_cfg, Mapping):
                    cache = build_reference_cache_from_config(cache_cfg)
                else:
                    cache = get_default_reference_cache()
                reference_accessor = cache.accessor(genome_sequences)
            except Exception:
                reference_accessor = None
            return stream_rloks_report(
                experiment_spec,
                guide,
                genome_sequences,
                params,
                reference_accessor=reference_accessor,
                batch_size=batch_size,
            )

        def _on_update(update: Any) -> None:
            payload = update.get("payload") if isinstance(update, Mapping) else {}
            if update.get("reset"):
                self._compare_hits_by_index = {}
            hits = payload.get("hits") if isinstance(payload.get("hits"), list) else []
            for entry in hits:
                if not isinstance(entry, Mapping):
                    continue
                idx = entry.get("streamIndex")
                if idx is None:
                    idx = entry.get("candidateIndex")
                try:
                    index_val = int(idx)
                except Exception:
                    index_val = len(self._compare_hits_by_index)
                self._compare_hits_by_index[index_val] = dict(entry)

            if update.get("done"):
                self._compare_running = False
                self._compute_compare_deltas()
                self._render_table(self._apply_filters(self._get_active_hits()))

        def _on_err(err: str) -> None:
            self._compare_running = False
            self._compare_toggle.setChecked(False)
            self._compare_deltas_risk = {}
            self._compare_deltas_score = {}
            self._summary_label.setText(f"Compare run failed: {err}")

        run_bg_stream(_work, _on_update, _on_err, label="RLoCKS compare", token=self._compare_token)

    def _compute_compare_deltas(self) -> None:
        base_hits = self._hits
        compare_hits = [self._compare_hits_by_index[k] for k in sorted(self._compare_hits_by_index.keys())]
        self._compare_deltas_risk = compute_risk_deltas(base_hits, compare_hits)
        score_deltas: dict[str, float] = {}
        compare_by_key = {str(h.get("hitKey") or ""): h for h in compare_hits}
        for hit in base_hits:
            key = str(hit.get("hitKey") or "")
            if not key or key not in compare_by_key:
                continue
            base_score = float(hit.get("siteScore") or hit.get("riskScore") or 0.0)
            compare_score = float(compare_by_key[key].get("siteScore") or compare_by_key[key].get("riskScore") or 0.0)
            score_deltas[key] = base_score - compare_score
        self._compare_deltas_score = score_deltas

    def _render_payload(self, payload: Mapping[str, Any], report_bytes: bytes) -> None:
        if bool(payload.get("streaming")):
            self._set_sort_controls_enabled(False)
            self._render_stream_payload(payload)
            return
        # New primary payload clears any stale compare data.
        self._clear_compare_state(reset_toggle=False)
        self._set_sort_controls_enabled(True)
        self._sync_rloks_panel(payload)
        summary_lines = payload.get("summary") if isinstance(payload.get("summary"), list) else []
        if summary_lines:
            text = "\n".join(f"• {str(line)}" for line in summary_lines)
        else:
            text = "No off-target report available."
        self._summary_label.setText(text)

        self._is_truncated = bool(payload.get("isTruncated") if "isTruncated" in payload else payload.get("truncated"))
        hit_cap = payload.get("hitCap")
        max_mm = payload.get("maxMismatches")
        if self._is_truncated and hit_cap is not None and max_mm is not None:
            self._truncate_label.setText(
                f"Results truncated to {int(hit_cap)} hits at {int(max_mm)} mismatches. Refine search."
            )
            self._truncate_label.show()
        else:
            self._truncate_label.hide()
            self._truncate_label.setText("")

        hits = payload.get("hits") if isinstance(payload.get("hits"), list) else []
        rows: list[dict[str, Any]] = []
        for entry in hits:
            if isinstance(entry, Mapping):
                rows.append(dict(entry))

        # Build validation + primer plans for UI display (deterministic, no persistence).
        self._primer_by_key = {}
        self._assay_by_key = {}
        try:
            off_sha = hashlib.sha256(report_bytes).hexdigest()
            genome_sequences = None
            if self._session is not None:
                genome_sequences = getattr(self._session.state.genome, "sequences", None)
            exp_spec = {}
            guide = {}
            if self._session is not None:
                try:
                    exp_spec = getattr(self._session.state, "experiment_spec", {}) or {}
                except Exception:
                    exp_spec = {}
                try:
                    cfg = self._session.state.config
                    if isinstance(cfg, Mapping):
                        guide = cfg.get("guide") or {}
                except Exception:
                    guide = {}
            plan = build_validation_plan(
                payload,
                off_target_report_sha256=off_sha,
                genome_sequences=genome_sequences if isinstance(genome_sequences, Mapping) else None,
                experiment_spec=exp_spec,
                guide=guide,
                edit_plan=getattr(self._session.state, "edit_plan", {}) if self._session else None,
            )
            validation_sha = validation_plan_sha256(plan)
            primer_plan = build_primer_plan(
                plan,
                genome_sequences=genome_sequences if isinstance(genome_sequences, Mapping) else None,
                validation_plan_sha256=validation_sha,
                experiment_spec=exp_spec,
                guide=guide,
            )
            for pair in primer_plan.get("primerPairs", []):
                if isinstance(pair, Mapping):
                    key = str(pair.get("hitKey") or pair.get("id") or "")
                    if key:
                        self._primer_by_key[key] = dict(pair)
            try:
                if self._session is not None:
                    outcome_report = compute_outcomes_for_current_plan(self._session)
                    outcome_payload = outcome_report_to_dict(outcome_report)
                else:
                    outcome_payload = {}
                clone_plan = build_clone_plan(outcome_payload)
                assay_plan = build_assay_plan(
                    outcome_payload,
                    plan,
                    primer_plan,
                    clone_plan,
                    experiment_spec=getattr(self._session.state, "experiment_spec", {}) if self._session else {},
                )
                for entry in assay_plan.get("offTargets", []):
                    if isinstance(entry, Mapping):
                        key = str(entry.get("hitKey") or "")
                        if key:
                            self._assay_by_key[key] = dict(entry)
            except Exception:
                self._assay_by_key = {}
        except Exception:
            self._primer_by_key = {}
            self._assay_by_key = {}

        self._set_hits(rows)
        self._update_filters(self._stable_hits)
        filtered = self._apply_filters(self._get_active_hits())
        self._render_risk_summary(filtered)
        self._render_table(filtered)
        self._jump_button.setEnabled(False)
        self._detail_label.hide()
        self._detail_label.setText("")
        self._explain_header.hide()
        self._explain_highlights.hide()
        self._explain_tree.hide()
        self._explain_tree.clear()
        self._set_compare_controls_enabled(False)
        self._set_compare_controls_enabled(True)

    def _render_stream_payload(self, payload: Mapping[str, Any]) -> None:
        self._sync_rloks_panel(payload)
        summary_lines = payload.get("summary") if isinstance(payload.get("summary"), list) else []
        if summary_lines:
            text = "\n".join(f"• {str(line)}" for line in summary_lines)
        else:
            stream = payload.get("stream") if isinstance(payload.get("stream"), Mapping) else {}
            scored = stream.get("scored")
            total = stream.get("total")
            if scored is not None and total is not None:
                text = f"Scored {int(scored)} of {int(total)} candidate site(s)."
            else:
                text = "Streaming off-target scoring..."
        self._summary_label.setText(text)

        self._is_truncated = bool(payload.get("isTruncated") if "isTruncated" in payload else payload.get("truncated"))
        hit_cap = payload.get("hitCap")
        max_mm = payload.get("maxMismatches")
        if self._is_truncated and hit_cap is not None and max_mm is not None:
            self._truncate_label.setText(
                f"Results truncated to {int(hit_cap)} hits at {int(max_mm)} mismatches. Refine search."
            )
            self._truncate_label.show()
        else:
            self._truncate_label.hide()
            self._truncate_label.setText("")

        hits = payload.get("hits") if isinstance(payload.get("hits"), list) else []
        if payload.get("streamDelta"):
            self._merge_stream_hits(hits)
        else:
            self._stream_hits_by_index = {}
        self._merge_stream_hits(hits)

        rows = [self._stream_hits_by_index[key] for key in sorted(self._stream_hits_by_index.keys())]
        self._set_hits(rows)
        self._update_filters(self._stable_hits)
        filtered = self._apply_filters(self._get_active_hits())
        self._render_risk_summary(filtered)
        self._render_table(filtered)
        self._jump_button.setEnabled(False)
        self._detail_label.hide()
        self._detail_label.setText("")
        self._explain_header.hide()
        self._explain_highlights.hide()
        self._explain_tree.hide()
        self._explain_tree.clear()
        if not self._streaming and self._compare_toggle.isChecked():
            self._start_compare_stream()
        if not self._streaming:
            self._set_compare_controls_enabled(True)
            if self._compare_toggle.isChecked():
                self._start_compare_stream()

    def _merge_stream_hits(self, hits: list[Any]) -> None:
        for entry in hits:
            if not isinstance(entry, Mapping):
                continue
            idx = entry.get("streamIndex")
            if idx is None:
                idx = entry.get("candidateIndex")
            try:
                index_val = int(idx)
            except Exception:
                index_val = len(self._stream_hits_by_index)
            self._stream_hits_by_index[index_val] = dict(entry)

    def _extract_target_id(self, hit: Mapping[str, Any]) -> str:
        target_id = str(hit.get("targetId") or "")
        if not target_id:
            hit_key = str(hit.get("hitKey") or "")
            if "::" in hit_key:
                target_id = hit_key.split("::", 1)[0]
        return target_id

    def _count_tiers(self, rows: list[dict[str, Any]]) -> tuple[int, int, int]:
        high = medium = low = 0
        for entry in rows:
            tier = str(entry.get("riskTier") or "").lower()
            if tier == "high":
                high += 1
            elif tier == "medium":
                medium += 1
            else:
                low += 1
        return high, medium, low

    def _render_risk_summary(self, rows: list[dict[str, Any]]) -> None:
        high, medium, low = self._count_tiers(rows)
        trunc_note = " • Truncated" if self._is_truncated else ""
        self._risk_summary_label.setText(f"High {high}, Medium {medium}, Low {low}{trunc_note}")
        self._risk_summary_label.setVisible(True)

    def _update_filters(self, rows: list[dict[str, Any]]) -> None:
        self._syncing = True
        contigs = sorted({str(row.get("contig") or "") for row in rows if row.get("contig")})
        target_ids = sorted(
            {self._extract_target_id(row) for row in rows if self._extract_target_id(row)}
        )
        mm_values = sorted({int(row.get("totalMismatchCount") or row.get("distance") or 0) for row in rows})

        current_contig = self._contig_filter.currentData()
        self._contig_filter.clear()
        self._contig_filter.addItem("All contigs", None)
        for contig in contigs:
            self._contig_filter.addItem(contig, contig)
        if current_contig in contigs:
            idx = self._contig_filter.findData(current_contig)
            if idx >= 0:
                self._contig_filter.setCurrentIndex(idx)

        current_target = self._target_filter.currentData()
        self._target_filter.clear()
        self._target_filter.addItem("All targets", None)
        for target_id in target_ids:
            self._target_filter.addItem(target_id, target_id)
        if current_target in target_ids:
            idx = self._target_filter.findData(current_target)
            if idx >= 0:
                self._target_filter.setCurrentIndex(idx)

        current_mm = self._mm_filter.currentData()
        self._mm_filter.clear()
        self._mm_filter.addItem("All mismatches", None)
        for mm in mm_values:
            if mm >= 3:
                continue
            self._mm_filter.addItem(str(mm), mm)
        if any(mm >= 3 for mm in mm_values):
            self._mm_filter.addItem("3+", "3+")
        if current_mm in [self._mm_filter.itemData(i) for i in range(self._mm_filter.count())]:
            idx = self._mm_filter.findData(current_mm)
            if idx >= 0:
                self._mm_filter.setCurrentIndex(idx)
        self._syncing = False

    def _apply_filters(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        contig_filter = self._contig_filter.currentData()
        target_filter = self._target_filter.currentData()
        mm_filter = self._mm_filter.currentData()
        bulge_filter = self._bulge_filter.currentData()
        filtered = []
        for hit in rows:
            contig = str(hit.get("contig") or "")
            if contig_filter and contig != contig_filter:
                continue
            target_id = self._extract_target_id(hit)
            if target_filter and target_id != target_filter:
                continue
            mm_count = int(hit.get("totalMismatchCount") or hit.get("distance") or 0)
            if mm_filter is None:
                pass
            elif mm_filter == "3+":
                if mm_count < 3:
                    continue
            elif isinstance(mm_filter, int):
                if mm_count != mm_filter:
                    continue
            bulge_type = str(hit.get("bulgeType") or "NONE").upper()
            if bulge_filter == "NONE" and bulge_type != "NONE":
                continue
            if bulge_filter == "BULGE" and bulge_type == "NONE":
                continue
            filtered.append(hit)
        return filtered

    def _render_table(self, rows: list[dict[str, Any]]) -> None:
        self._visible_hits = list(rows)
        self._table.setRowCount(len(rows))
        for idx, hit in enumerate(rows, start=1):
            contig = str(hit.get("contig") or "")
            start = hit.get("start")
            end = hit.get("end")
            strand = str(hit.get("strand") or "")
            locus = f"{contig}:{start}-{end} {strand}".strip()
            target_id = self._extract_target_id(hit)
            target_label = target_id or "primary"
            distance = int(hit.get("totalMismatchCount") or hit.get("distance") or 0)
            bulge_type = str(hit.get("bulgeType") or "NONE").upper()
            bulge_pos = hit.get("bulgePos")
            bulge_text = bulge_type
            if bulge_type != "NONE":
                try:
                    bulge_text = f"{bulge_type}@{int(bulge_pos)}"
                except Exception:
                    bulge_text = bulge_type
            score = float(hit.get("riskScore") or hit.get("score") or 0.0)
            tier = str(hit.get("riskTier") or "—")
            hit_key = str(hit.get("hitKey") or "")
            if not hit_key:
                base_key = f"{contig}:{start}-{end}:{strand}"
                hit_key = f"{target_id}::{base_key}" if target_id else base_key
            primer = self._primer_by_key.get(hit_key)
            assay_info = self._assay_by_key.get(hit_key, {})
            assay_text = str(assay_info.get("recommendedAssay") or "—")
            assay_rationale = assay_info.get("rationale") if isinstance(assay_info.get("rationale"), list) else []
            primer_text = "—"
            amplicon_text = "—"
            if isinstance(primer, Mapping):
                fwd = primer.get("forwardPrimer")
                rev = primer.get("reversePrimer")
                if fwd and rev:
                    primer_text = f"FWD {fwd}\nREV {rev}"
                amp_len = primer.get("ampliconLength")
                if amp_len is not None:
                    amplicon_text = f"{int(amp_len)} bp"
            cells = [
                str(idx),
                target_label,
                tier,
                assay_text,
                locus,
                str(distance),
                bulge_text,
                f"{score:.3f}",
                primer_text,
                amplicon_text,
                self._format_delta(self._compare_deltas_risk.get(hit_key)),
                self._format_delta(self._compare_deltas_score.get(hit_key)),
            ]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                if col == 3 and assay_rationale:
                    item.setToolTip("\n".join(str(r) for r in assay_rationale))
                if col == 4:
                    aligned_guide = str(hit.get("alignedGuide") or "")
                    aligned_target = str(hit.get("alignedTarget") or "")
                    if aligned_guide and aligned_target:
                        item.setToolTip(f"Guide:  {aligned_guide}\nTarget: {aligned_target}")
                self._table.setItem(idx - 1, col, item)

        self._empty_label.setVisible(len(rows) == 0)

    def _on_filter_changed(self) -> None:
        if self._syncing:
            return
        filtered = self._apply_filters(self._get_active_hits())
        self._render_risk_summary(filtered)
        self._render_table(filtered)
        self._jump_button.setEnabled(False)
        self._detail_label.hide()
        self._detail_label.setText("")

    def _on_selection_changed(self) -> None:
        rows = self._table.selectionModel().selectedRows() if self._table.selectionModel() else []
        self._jump_button.setEnabled(bool(rows))
        if not rows:
            self._detail_label.hide()
            self._detail_label.setText("")
            self._explain_header.hide()
            self._explain_highlights.hide()
            self._explain_tree.hide()
            self._explain_tree.clear()
            return
        row = rows[0].row()
        if not (0 <= row < len(self._visible_hits)):
            self._detail_label.hide()
            self._detail_label.setText("")
            self._explain_header.hide()
            self._explain_highlights.hide()
            self._explain_tree.hide()
            self._explain_tree.clear()
            return
        hit = self._visible_hits[row]
        hit_key = str(hit.get("hitKey") or "")
        target_id = self._extract_target_id(hit) or "primary"
        detail = f"Hit: {hit_key or '—'} • Target: {target_id}"
        self._detail_label.setText(detail)
        self._detail_label.show()
        explanation = hit.get("explanation") if isinstance(hit.get("explanation"), Mapping) else None
        if explanation:
            schema_version = str(hit.get("explainSchemaVersion") or self._rloks_schema_version or "")
            self._populate_explanation_tree(explanation, schema_version)
            self._explain_header.show()
            self._explain_tree.show()
            highlights = build_top_risk_drivers(explanation)
            if highlights:
                self._explain_highlights.setText(highlights)
                self._explain_highlights.show()
            else:
                self._explain_highlights.hide()
        else:
            self._explain_header.hide()
            self._explain_highlights.hide()
            self._explain_tree.hide()
            self._explain_tree.clear()

    def _on_row_activated(self, row: int, _column: int) -> None:
        if 0 <= row < len(self._visible_hits):
            self._jump_to_hit(self._visible_hits[row])

    def _on_jump_clicked(self) -> None:
        rows = self._table.selectionModel().selectedRows() if self._table.selectionModel() else []
        if not rows:
            return
        row = rows[0].row()
        if 0 <= row < len(self._visible_hits):
            self._jump_to_hit(self._visible_hits[row])

    def _jump_to_hit(self, hit: Mapping[str, Any]) -> None:
        if self._session is None:
            return
        genome = getattr(self._session.state, "genome", None)
        sequences = getattr(genome, "sequences", None)
        if not isinstance(sequences, Mapping):
            return
        contig = str(hit.get("contig") or "")
        if contig not in sequences:
            return
        seq = sequences.get(contig)
        if not isinstance(seq, str) or not seq:
            return
        try:
            start = int(hit.get("start", 0))
            end = int(hit.get("end", start + 1))
        except Exception:
            return
        if end <= start:
            return

        flank = 60
        window_start = max(0, start - flank)
        window_end = min(len(seq), end + flank)
        if window_end <= window_start:
            return
        window_seq = seq[window_start:window_end]

        guide_start = max(0, start - window_start)
        guide_end = max(guide_start + 1, end - window_start)
        guide_end = min(len(window_seq), guide_end)
        strand = str(hit.get("strand") or "+")
        guide_seq = window_seq[guide_start:guide_end]
        if strand == "-":
            guide_seq = bioinformatics.reverse_complement(guide_seq)

        locus = f"{contig}:{start}-{end}"
        guide_payload = {
            "id": f"offtarget_{contig}_{start}",
            "start": guide_start,
            "end": guide_end,
            "strand": strand,
            "sequence": guide_seq,
            "locus": locus,
            "pam": str(hit.get("pam") or ""),
        }
        sim_payload = {
            "site": {"sequence": window_seq},
            "guide": dict(guide_payload),
            "outcomes": [],
            "artifact": "helix.offtarget.jump.v1",
        }

        spec_payload = experiment_spec_to_dict(self._session.state.experiment_spec)
        if isinstance(spec_payload.get("locus"), Mapping):
            locus_payload = dict(spec_payload.get("locus") or {})
        else:
            locus_payload = {}
        locus_payload["chr"] = contig
        locus_payload["start"] = int(window_start)
        locus_payload["end"] = int(window_end)
        locus_payload["strand"] = strand or "+"
        spec_payload["locus"] = locus_payload

        cfg = dict(self._session.state.config or {})
        cfg["guide"] = guide_payload
        cfg["sim_payload"] = sim_payload
        cfg.setdefault("sim_type", "CRISPR")

        update_kwargs = {"config": cfg, "experiment_spec": spec_payload, "viz_dirty": True}
        if self._session.state.run_kind == RunKind.NONE:
            update_kwargs["run_kind"] = RunKind.CRISPR
        self._session.update(**update_kwargs)

    def _on_rloks_pack_edited(self, _text: str) -> None:
        self._rloks_pack_dirty = True
        self._update_rloks_apply_state()

    def _cancel_streaming(self, _checked: bool = False, *, silent: bool = False) -> None:
        self._stream_token.bump()
        self._streaming = False
        self._rloks_cancel.setEnabled(False)
        self._set_sort_controls_enabled(True)
        self._clear_compare_state()
        if not silent:
            self._summary_label.setText("Off-target scoring canceled.")

    def _cancel_compare(self) -> None:
        self._compare_token.bump()
        self._compare_running = False
        self._clear_compare_state(reset_toggle=False)
        self._render_table(self._apply_filters(self._get_active_hits()))

    def _apply_rloks_settings(self) -> None:
        if self._session is None:
            return
        pack_id = self._rloks_pack_edit.text().strip()
        if not pack_id:
            self._update_rloks_apply_state()
            return
        current_pack_id = str(self._current_offtarget_params().get("rloks_pack_id") or "")
        if pack_id == current_pack_id:
            self._rloks_pack_dirty = False
            self._update_rloks_apply_state()
            return
        self._cancel_streaming(silent=True)
        cfg = update_rloks_config(self._session.state.config or {}, pack_id, provider_id=RLOKS_PROVIDER_ID)
        self._rloks_pack_dirty = False
        self._session.update(config=cfg, viz_dirty=True)
        self._update_rloks_apply_state()

    def _risk_sort_key(self, hit: Mapping[str, Any]) -> tuple:
        return (
            -float(hit.get("riskScore") or hit.get("score") or 0.0),
            int(hit.get("totalMismatchCount") or hit.get("distance") or 0),
            str(hit.get("contig") or ""),
            int(hit.get("start") or 0),
            str(hit.get("strand") or ""),
            str(hit.get("hitKey") or ""),
        )

    def _set_hits(self, rows: list[dict[str, Any]]) -> None:
        self._stable_hits = list(rows)
        self._risk_hits = sorted(self._stable_hits, key=self._risk_sort_key)
        self._hits = self._stable_hits  # legacy attribute

    def _get_active_hits(self) -> list[dict[str, Any]]:
        return self._risk_hits if self._sort_mode == "risk" else self._stable_hits

    def _set_sort_controls_enabled(self, enabled: bool) -> None:
        self._sort_stable.setEnabled(True)
        self._sort_risk.setEnabled(bool(enabled))
        if not enabled:
            self._sort_mode = "stable"
            self._sort_stable.setChecked(True)
            self._sort_risk.setChecked(False)

    def _set_compare_controls_enabled(self, enabled: bool) -> None:
        self._compare_enabled = bool(enabled)
        self._compare_toggle.setEnabled(self._compare_enabled)
        if not self._compare_enabled:
            self._compare_running = False
            self._compare_toggle.setChecked(False)
            self._clear_compare_state(reset_toggle=False)

    def _clear_compare_state(self, reset_toggle: bool = True) -> None:
        self._compare_deltas_risk = {}
        self._compare_deltas_score = {}
        self._compare_hits_by_index = {}
        self._compare_running = False
        if reset_toggle:
            try:
                self._compare_toggle.setChecked(False)
            except Exception:
                pass

    def _update_rloks_apply_state(self) -> None:
        if self._session is None:
            self._rloks_apply.setEnabled(False)
            return
        pack_id = self._rloks_pack_edit.text().strip()
        current_pack_id = str(self._current_offtarget_params().get("rloks_pack_id") or "")
        enabled = bool(pack_id) and pack_id != current_pack_id
        self._rloks_apply.setEnabled(enabled)

    def _current_offtarget_params(self) -> Mapping[str, Any]:
        if self._session is None:
            return {}
        cfg = self._session.state.config
        if isinstance(cfg, Mapping):
            params = cfg.get("offtarget")
            if isinstance(params, Mapping):
                return params
        return {}

    def _sync_rloks_panel(self, payload: Mapping[str, Any]) -> None:
        cfg_params = self._current_offtarget_params()
        pack_fields = extract_rloks_pack_fields(payload, cfg_params)
        if not getattr(self, "_rloks_pack_dirty", False):
            if pack_fields.pack_id:
                self._rloks_pack_edit.setText(pack_fields.pack_id)
        if pack_fields.pack_fingerprint:
            self._rloks_fingerprint.setText(f"Fingerprint: {pack_fields.pack_fingerprint}")
        elif not pack_fields.error_message:
            self._rloks_fingerprint.setText("Fingerprint: —")
        if pack_fields.explain_schema_version:
            self._rloks_schema.setText(f"Schema: {pack_fields.explain_schema_version}")
            self._rloks_schema_version = pack_fields.explain_schema_version
        elif not pack_fields.error_message:
            self._rloks_schema.setText("Schema: —")
        if pack_fields.error_message:
            attempted = pack_fields.pack_id or self._rloks_pack_edit.text().strip()
            prefix = f"Attempted pack: {attempted or '—'}"
            self._rloks_error.setText(prefix + "\n" + pack_fields.error_message)
            self._rloks_error.show()
        else:
            self._rloks_error.hide()
            self._rloks_error.setText("")
        self._update_rloks_apply_state()

    def _populate_explanation_tree(self, explanation: Mapping[str, Any], schema_version: str) -> None:
        self._explain_tree.clear()

        def _add(parent: QTreeWidgetItem | None, key: str, value: Any, path: str) -> None:
            label = str(key)
            display = self._format_explain_value(value)
            item = QTreeWidgetItem([label, display])
            tooltip = get_tooltip(schema_version, path)
            if tooltip:
                item.setToolTip(0, tooltip)
            if parent is None:
                self._explain_tree.addTopLevelItem(item)
            else:
                parent.addChild(item)
            if isinstance(value, Mapping):
                for sub_key, sub_val in value.items():
                    sub_label = str(sub_key)
                    sub_path = f"{path}.{sub_label}" if path else sub_label
                    _add(item, sub_label, sub_val, sub_path)
            elif isinstance(value, list):
                for idx, entry in enumerate(value):
                    sub_key = f"[{idx}]"
                    sub_path = f"{path}{sub_key}"
                    _add(item, sub_key, entry, sub_path)

        for key, value in explanation.items():
            _add(None, key, value, str(key))
        self._explain_tree.expandToDepth(1)

    def _format_explain_value(self, value: Any) -> str:
        if isinstance(value, float):
            return f"{value:.6g}"
        return str(value)

    def _format_delta(self, value: float | None) -> str:
        if value is None:
            return "—"
        return f"{value:+.3f}"

    def _on_sort_mode_changed(self, checked: bool) -> None:
        if not checked:
            return
        if self._streaming:
            self._sort_mode = "stable"
            self._sort_stable.setChecked(True)
            self._sort_risk.setChecked(False)
            return
        self._sort_mode = "risk" if self._sort_risk.isChecked() else "stable"
        filtered = self._apply_filters(self._get_active_hits())
        self._render_risk_summary(filtered)
        self._render_table(filtered)

    def _on_compare_toggled(self, checked: bool) -> None:
        if not checked:
            self._clear_compare_state(reset_toggle=False)
            filtered = self._apply_filters(self._get_active_hits())
            self._render_table(filtered)
            return
        if self._streaming:
            # defer compare until primary streaming completes; keep toggle unchecked
            self._compare_toggle.setChecked(False)
            return
        self._start_compare_stream()


__all__ = ["OffTargetListPanel"]
