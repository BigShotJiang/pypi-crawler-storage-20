from __future__ import annotations

from typing import Any, Mapping

from helix import bioinformatics
from helix.crispr.pam import PAM, get_pam
from helix.crispr.score import DEFAULT_WEIGHTS, enumerate_off_targets, score_off_targets

from .model import (
    OffTargetReportV1,
    compute_inputs_sha256,
    _genome_digest,
    normalize_target_id,
    base_hit_key,
    namespace_hit_key,
)
from .reference_accessor import ReferenceAccessor, get_default_reference_cache
from .risk import score_offtarget_hit, seed_start_index


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _pam_pattern(pam: Any) -> str | None:
    if isinstance(pam, str):
        try:
            pam_def = get_pam(pam)
            return pam_def.get("pattern")
        except Exception:
            return None
    if isinstance(pam, Mapping):
        return str(pam.get("pattern") or "") or None
    if isinstance(pam, PAM):
        return str(pam.as_dict().get("pattern") or "") or None
    return None


def _classify_pam(pam_seq: str, pam_pattern: str | None) -> str:
    if not pam_seq or not pam_pattern or len(pam_seq) != len(pam_pattern):
        return "Unknown"
    pattern = pam_pattern.upper()
    seq = pam_seq.upper()
    if any(ch not in "ACGTN" for ch in pattern) or any(ch not in "ACGT" for ch in seq):
        return "Unknown"
    class_chars = []
    for pat, base in zip(pattern, seq):
        class_chars.append("N" if pat == "N" else base)
    return "".join(class_chars) or "Unknown"


def _normalize_guide(
    guide: Mapping[str, Any] | None,
    genome_sequences: Mapping[str, Any] | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    if isinstance(guide, Mapping):
        payload.update({k: guide[k] for k in guide.keys()})

    seq = str(payload.get("sequence") or "").strip().upper()
    if seq:
        payload["sequence"] = seq
        payload.setdefault("start", 0)
        payload.setdefault("end", len(seq))
        payload.setdefault("strand", "+")
        return payload

    contig = str(payload.get("contig") or payload.get("chrom") or "")
    start = payload.get("start")
    end = payload.get("end")
    if contig and isinstance(genome_sequences, Mapping) and contig in genome_sequences:
        genome_seq = genome_sequences.get(contig)
        if isinstance(genome_seq, str) and start is not None and end is not None:
            s = _safe_int(start, 0)
            e = _safe_int(end, s)
            if e > s:
                slice_seq = genome_seq[s:e]
                strand = str(payload.get("strand") or "+")
                payload["sequence"] = (
                    bioinformatics.reverse_complement(slice_seq) if strand == "-" else slice_seq
                ).upper()
                return payload
    return payload



class MismatchOffTargetProvider:
    provider_id = "offtarget_mismatch_v1"
    provider_version = "v1"

    def can_handle(
        self,
        experiment_spec: Mapping[str, Any] | None,
        guide: Mapping[str, Any] | None,
        genome_sequences: Mapping[str, Any] | None,
        params: Mapping[str, Any] | None,
    ) -> bool:
        guide_norm = _normalize_guide(guide, genome_sequences)
        seq = str(guide_norm.get("sequence") or "")
        return bool(seq and isinstance(genome_sequences, Mapping) and genome_sequences)

    def run(
        self,
        experiment_spec: Mapping[str, Any] | None,
        guide: Mapping[str, Any] | None,
        genome_sequences: Mapping[str, Any] | None,
        params: Mapping[str, Any] | None,
        reference_accessor: ReferenceAccessor | None = None,
    ) -> OffTargetReportV1:
        guide_norm = _normalize_guide(guide, genome_sequences)
        guide_seq = str(guide_norm.get("sequence") or "")
        if not guide_seq or not isinstance(genome_sequences, Mapping) or not genome_sequences:
            inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, params)
            return OffTargetReportV1(
                model_id=self.provider_id,
                model_version=self.provider_version,
                inputs_sha256=inputs_sha,
                summary=["Inputs incomplete; off-target search not run."],
                guide=dict(guide_norm),
                genome={},
                params=dict(params or {}),
                hits=[],
                total_hits=0,
                hit_cap=None,
                is_truncated=False,
                hits_returned=0,
                max_mismatches=None,
            )

        params = dict(params or {})
        use_prefetch = True
        if "prefetch_targets" in params:
            try:
                use_prefetch = bool(params.pop("prefetch_targets"))
            except Exception:
                use_prefetch = True
        max_mm = _safe_int(params.get("max_mm", params.get("max_mismatch", 3)), 3)
        max_hits = _safe_int(params.get("max_hits", 200), 200)
        pam = params.get("pam") or guide_norm.get("pam") or params.get("pam_profile") or "NGG"
        weights = params.get("weights") or DEFAULT_WEIGHTS.get("off_target", {})
        resolved_params = {"max_mm": max_mm, "max_hits": max_hits, "pam": pam, "weights": weights}
        inputs_sha = compute_inputs_sha256(experiment_spec, guide_norm, genome_sequences, resolved_params)
        target_id = normalize_target_id(guide_norm)
        pam_pattern = _pam_pattern(pam)
        pam_len = len(pam_pattern or "")
        guide_len = len(guide_seq)
        seed_start = seed_start_index(guide_len)

        if reference_accessor is None:
            reference_accessor = get_default_reference_cache().accessor(genome_sequences)

        hits_all: list[dict[str, Any]] = []
        truncated = False
        contigs = reference_accessor.contigs() if reference_accessor is not None else sorted(genome_sequences.keys())
        for contig in contigs:
            genome_seq = reference_accessor.get_window(
                contig,
                0,
                reference_accessor.contig_length(contig),
                strand="+",
            )
            if not genome_seq:
                continue
            pam_targets = []
            pam_target_map: dict[tuple[int, str], Mapping[str, Any]] = {}
            if use_prefetch and pam_len > 0:
                pam_targets = reference_accessor.prefetch_pam_targets(
                    contig,
                    0,
                    reference_accessor.contig_length(contig),
                    pam,
                    guide_len=guide_len,
                    normalize=False,
                    strand_policy="both",
                )
                for entry in pam_targets:
                    if not isinstance(entry, Mapping):
                        continue
                    pam_pos = entry.get("pam_pos")
                    strand = str(entry.get("strand") or "")
                    if pam_pos is None or not strand:
                        continue
                    pam_target_map[(int(pam_pos), strand)] = entry
            hits = enumerate_off_targets(genome_seq, guide_norm, pam, max_mm=max_mm, max_gap=0)
            for hit in hits:
                hit = dict(hit)
                hit["contig"] = str(contig)
                if pam_len > 0:
                    strand = str(hit.get("strand") or "+")
                    try:
                        start = int(hit.get("start", 0))
                        end = int(hit.get("end", start))
                    except Exception:
                        start = 0
                        end = 0
                    pam_seq = ""
                    pam_ok = bool(hit.get("pam_ok", True))
                    if strand == "+":
                        pam_start = end
                        pam_end = end + pam_len
                        if pam_ok and use_prefetch:
                            entry = pam_target_map.get((pam_start, "+"))
                            if isinstance(entry, Mapping):
                                pam_seq = str(entry.get("pam_seq") or "")
                        if not pam_seq and 0 <= pam_start < len(genome_seq) and pam_end <= len(genome_seq):
                            pam_seq = reference_accessor.get_window(contig, pam_start, pam_end, strand="+").upper()
                    else:
                        pam_start = start - pam_len
                        pam_end = start
                        if pam_ok and use_prefetch:
                            entry = pam_target_map.get((pam_start, "-"))
                            if isinstance(entry, Mapping):
                                pam_seq = str(entry.get("pam_seq") or "")
                        if not pam_seq and pam_start >= 0 and pam_end <= len(genome_seq):
                            pam_seq = reference_accessor.get_window(contig, pam_start, pam_end, strand="-").upper()
                    hit["pamSequence"] = pam_seq
                    hit["pamClass"] = _classify_pam(pam_seq, pam_pattern)
                else:
                    hit["pamSequence"] = ""
                    hit["pamClass"] = "Unknown"
                hits_all.append(hit)
                if max_hits > 0 and len(hits_all) >= max_hits:
                    truncated = True
                    break
            if truncated:
                break

        scored = score_off_targets(hits_all, weights)
        total_hits = len(scored) if not truncated else None

        scored.sort(
            key=lambda h: (
                _safe_int(h.get("effectiveDistance", h.get("distance", 0))),
                _safe_int(h.get("totalMismatchCount", h.get("distance", 0))),
                {"NONE": 0, "DNA": 1, "RNA": 2}.get(str(h.get("bulgeType") or "NONE").upper(), 3),
                str(h.get("contig", "")),
                _safe_int(h.get("start", 0)),
            )
        )

        if max_hits > 0 and len(scored) > max_hits:
            scored = scored[:max_hits]
            truncated = True

        high_count = 0
        medium_count = 0
        low_count = 0
        for hit in scored:
            mismatches = hit.get("mismatches") if isinstance(hit.get("mismatches"), list) else []
            positions = []
            for mismatch in mismatches:
                if isinstance(mismatch, Mapping) and "position" in mismatch:
                    try:
                        positions.append(int(mismatch.get("position")))
                    except Exception:
                        continue
            positions = sorted(set(p for p in positions if p is not None))
            total_mm = len(positions)
            seed_mm = len([p for p in positions if p >= seed_start])
            pam_class = str(hit.get("pamClass") or "Unknown")
            pam_ok = bool(hit.get("pam_ok", True))
            score, tier, notes = score_offtarget_hit(
                total_mm=total_mm,
                seed_mm=seed_mm,
                pam_class=pam_class,
                pam_ok=pam_ok,
                bulge_type="NONE",
                bulge_pos=None,
                guide_len=guide_len,
            )
            hit["mismatchPositions"] = positions
            hit["totalMismatchCount"] = total_mm
            hit["seedMismatchCount"] = seed_mm
            hit["bulgeType"] = "NONE"
            hit["bulgePos"] = None
            hit["bulgeSize"] = 0
            hit["effectiveDistance"] = total_mm
            hit["riskScore"] = score
            hit["riskTier"] = tier
            hit["notes"] = notes
            if target_id:
                hit["targetId"] = target_id
            hit_key = namespace_hit_key(base_hit_key(hit), target_id)
            hit["hitKey"] = hit_key
            contig = str(hit.get("contig") or "")
            target_seq = ""
            if contig and reference_accessor is not None:
                try:
                    start = int(hit.get("start", 0))
                    end = int(hit.get("end", start))
                except Exception:
                    start = 0
                    end = 0
                if end > start:
                    strand = str(hit.get("strand") or "+")
                    if use_prefetch and pam_len > 0:
                        if strand == "+":
                            pam_pos = end
                        else:
                            pam_pos = start - pam_len
                        entry = pam_target_map.get((pam_pos, strand))
                        if isinstance(entry, Mapping):
                            target_seq = str(entry.get("target20") or "")
                    if not target_seq:
                        target_seq = reference_accessor.get_window(contig, start, end, strand=strand).upper()
            hit["alignedGuide"] = guide_seq
            hit["alignedTarget"] = target_seq or str(hit.get("alignedTarget") or "")
            if tier == "High":
                high_count += 1
            elif tier == "Medium":
                medium_count += 1
            else:
                low_count += 1

        summary = [
            f"Mismatch search (≤{max_mm} mismatches) across {len(genome_sequences)} contig(s).",
            f"{total_hits if total_hits is not None else len(scored)} candidate site(s) scored.",
        ]
        if truncated:
            summary.append(f"Truncated to top {max_hits} hits.")

        genome_meta = {"contigs": _genome_digest(genome_sequences)}
        return OffTargetReportV1(
            model_id=self.provider_id,
            model_version=self.provider_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            guide=dict(guide_norm),
            genome=genome_meta,
            params=resolved_params,
            hits=scored,
            total_hits=total_hits,
            hit_cap=max_hits,
            is_truncated=truncated,
            hits_returned=len(scored),
            max_mismatches=max_mm,
            high_risk_count=high_count,
            medium_risk_count=medium_count,
            low_risk_count=low_count,
        )


__all__ = ["MismatchOffTargetProvider"]
