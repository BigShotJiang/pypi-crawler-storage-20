from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

from helix.studio.experiment_spec import experiment_spec_to_dict


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n").encode(
        "utf-8"
    )


def validation_plan_json_bytes(plan: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(plan))


def validation_plan_sha256(plan: Mapping[str, Any]) -> str:
    return hashlib.sha256(validation_plan_json_bytes(plan)).hexdigest()


def _contig_lengths(
    *,
    genome_sequences: Mapping[str, Any] | None,
    report_payload: Mapping[str, Any],
) -> dict[str, int]:
    lengths: dict[str, int] = {}
    if isinstance(genome_sequences, Mapping):
        for contig, seq in genome_sequences.items():
            if isinstance(seq, str):
                lengths[str(contig)] = len(seq)
    if lengths:
        return lengths
    genome_meta = report_payload.get("genome") if isinstance(report_payload.get("genome"), Mapping) else {}
    contigs = genome_meta.get("contigs") if isinstance(genome_meta.get("contigs"), list) else []
    for entry in contigs:
        if isinstance(entry, Mapping):
            contig = str(entry.get("contig") or "")
            length = entry.get("length")
            try:
                length_int = int(length)
            except Exception:
                continue
            if contig and length_int > 0:
                lengths[contig] = length_int
    return lengths


def _tier_rank(tier: str) -> int:
    tier = str(tier or "").lower()
    if tier == "high":
        return 0
    if tier == "medium":
        return 1
    if tier == "low":
        return 2
    return 3


def _assays_for_tier(tier: str, total_mm: int) -> list[str]:
    tier = str(tier or "").lower()
    if tier == "high":
        return ["amplicon_seq", "targeted_ngs"]
    if tier == "medium":
        return ["amplicon_seq"]
    if total_mm <= 1:
        return ["sanger"]
    return ["amplicon_seq"]


def _primary_target_entry(
    *,
    experiment_spec: Mapping[str, Any] | None,
    guide: Mapping[str, Any] | None,
    contig_lengths: Mapping[str, int],
    window_radius: int,
) -> dict[str, Any] | None:
    spec = experiment_spec_to_dict(experiment_spec)
    locus = spec.get("locus") if isinstance(spec.get("locus"), Mapping) else {}
    contig = str(locus.get("chr") or locus.get("contig") or "")
    if not contig:
        return None
    try:
        start = int(locus.get("start", 0))
        end = int(locus.get("end", start + 1))
    except Exception:
        return None
    if end <= start:
        return None
    center = (start + end) // 2
    if isinstance(guide, Mapping):
        if guide.get("cut_index") is not None or guide.get("cutIndex") is not None:
            cut_index = guide.get("cut_index") if "cut_index" in guide else guide.get("cutIndex")
            try:
                center = int(start + int(cut_index))
            except Exception:
                pass
        else:
            try:
                gstart = int(guide.get("start"))
                gend = int(guide.get("end", gstart + 1))
                if gend > gstart:
                    center = start + (gstart + gend) // 2
            except Exception:
                pass
    win_start = max(0, center - int(window_radius))
    win_end = center + int(window_radius)
    contig_len = contig_lengths.get(contig)
    if contig_len:
        win_end = min(int(contig_len), win_end)
    if win_end <= win_start:
        win_end = win_start + 1
    return {
        "hitKey": "primary_target",
        "contig": contig,
        "start": start,
        "end": end,
        "strand": str(locus.get("strand") or "+"),
        "recommendedAmpliconWindow": {"start": win_start, "end": win_end},
        "notes": ["Primary target locus from experiment spec."],
    }


def _primary_target_entry_for_target(
    *,
    target_id: str,
    target: Mapping[str, Any],
    contig_lengths: Mapping[str, int],
    window_radius: int,
) -> dict[str, Any] | None:
    contig = str(target.get("contig") or target.get("chr") or target.get("chrom") or "")
    if not contig:
        guide = target.get("guide") if isinstance(target.get("guide"), Mapping) else None
        if isinstance(guide, Mapping):
            contig = str(guide.get("contig") or guide.get("chr") or guide.get("chrom") or "")
    if not contig:
        return None
    start = target.get("start")
    end = target.get("end")
    if start is None or end is None:
        guide = target.get("guide") if isinstance(target.get("guide"), Mapping) else None
        if isinstance(guide, Mapping):
            if start is None and "start" in guide:
                start = guide.get("start")
            if end is None and "end" in guide:
                end = guide.get("end")
    if start is None or end is None:
        cut_index = target.get("cutIndex") if "cutIndex" in target else target.get("cut_index")
        if cut_index is None:
            cut_index = target.get("cutPosition") if "cutPosition" in target else target.get("cut_position")
        if cut_index is not None:
            try:
                cut_int = int(cut_index)
                start = cut_int
                end = cut_int + 1
            except Exception:
                start = None
                end = None
    try:
        start_int = int(start) if start is not None else None
        end_int = int(end) if end is not None else None
    except Exception:
        return None
    if start_int is None or end_int is None:
        return None
    if end_int <= start_int:
        end_int = start_int + 1
    center = (start_int + end_int) // 2
    win_start = max(0, center - int(window_radius))
    win_end = center + int(window_radius)
    contig_len = contig_lengths.get(contig)
    if contig_len:
        win_end = min(int(contig_len), win_end)
    if win_end <= win_start:
        win_end = win_start + 1
    return {
        "hitKey": f"{target_id}::primary_target",
        "contig": contig,
        "start": start_int,
        "end": end_int,
        "strand": str(target.get("strand") or "+"),
        "recommendedAmpliconWindow": {"start": win_start, "end": win_end},
        "notes": ["Primary target locus from edit plan target."],
    }


def _target_id_from_hit(hit: Mapping[str, Any]) -> str | None:
    raw = hit.get("targetId")
    if isinstance(raw, str) and raw.strip():
        return raw.strip()
    key = hit.get("hitKey")
    if isinstance(key, str) and "::" in key:
        return key.split("::", 1)[0]
    return None


def _union_sort_key(hit: Mapping[str, Any]) -> tuple[int, float, int, str]:
    tier = _tier_rank(hit.get("riskTier"))
    score = float(hit.get("riskScore") or 0.0)
    effective = int(hit.get("effectiveDistance") or hit.get("totalMismatchCount") or hit.get("distance") or 0)
    hit_key = str(hit.get("hitKey") or "")
    return (tier, -score, effective, hit_key)


def build_validation_plan(
    report_payload: Mapping[str, Any],
    *,
    off_target_report_sha256: str,
    genome_sequences: Mapping[str, Any] | None = None,
    experiment_spec: Mapping[str, Any] | None = None,
    guide: Mapping[str, Any] | None = None,
    edit_plan: Mapping[str, Any] | None = None,
    outcome_report: Mapping[str, Any] | None = None,
    max_hits: int = 50,
    window_radius: int = 120,
) -> dict[str, Any]:
    hits = report_payload.get("hits") if isinstance(report_payload.get("hits"), list) else []
    contig_lengths = _contig_lengths(genome_sequences=genome_sequences, report_payload=report_payload)

    target_hits: dict[str, list[dict[str, Any]]] = {}
    for hit in hits:
        if not isinstance(hit, Mapping):
            continue
        target_id = _target_id_from_hit(hit)
        if target_id:
            target_hits.setdefault(target_id, []).append(dict(hit))

    high = int(report_payload.get("highRiskCount") or 0)
    medium = int(report_payload.get("mediumRiskCount") or 0)
    low = int(report_payload.get("lowRiskCount") or 0)

    if not (high or medium or low):
        for entry in hits:
            if not isinstance(entry, Mapping):
                continue
            tier = str(entry.get("riskTier") or "").lower()
            if tier == "high":
                high += 1
            elif tier == "medium":
                medium += 1
            else:
                low += 1

    multiplex = len(target_hits) > 1

    def _filter_hits(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
        filtered: list[dict[str, Any]] = []
        for entry in entries:
            tier = str(entry.get("riskTier") or "")
            if tier.lower() not in {"high", "medium"}:
                continue
            filtered.append(entry)
        filtered.sort(key=_union_sort_key)
        if max_hits > 0 and len(filtered) > max_hits:
            filtered = filtered[:max_hits]
        return filtered

    def _to_validation_hit(hit: Mapping[str, Any], rank: int) -> dict[str, Any] | None:
        contig = str(hit.get("contig") or "")
        try:
            start = int(hit.get("start", 0))
            end = int(hit.get("end", start + 1))
        except Exception:
            return None
        if end <= start:
            return None
        center = (start + end) // 2
        win_start = max(0, center - int(window_radius))
        win_end = center + int(window_radius)
        contig_len = contig_lengths.get(contig)
        if contig_len:
            win_end = min(int(contig_len), win_end)
        if win_end <= win_start:
            win_end = win_start + 1

        total_mm = int(hit.get("totalMismatchCount") or hit.get("distance") or 0)
        seed_mm = int(hit.get("seedMismatchCount") or 0)
        tier = str(hit.get("riskTier") or "Unknown")
        score = float(hit.get("riskScore") or 0.0)
        pam_class = str(hit.get("pamClass") or "Unknown")
        hit_key = str(hit.get("hitKey") or "")
        if not hit_key:
            hit_key = f"{contig}:{start}-{end}:{str(hit.get('strand') or '')}"
        target_id = _target_id_from_hit(hit)
        if target_id and "::" not in hit_key:
            hit_key = f"{target_id}::{hit_key}"

        return {
            "rank": rank,
            "hitKey": hit_key,
            "contig": contig,
            "start": start,
            "end": end,
            "strand": str(hit.get("strand") or ""),
            "riskTier": tier,
            "riskScore": round(score, 4),
            "totalMismatchCount": total_mm,
            "seedMismatchCount": seed_mm,
            "pamClass": pam_class,
            "recommendedAmpliconWindow": {"start": win_start, "end": win_end},
            "recommendedAssays": _assays_for_tier(tier, total_mm),
            "notes": [
                f"riskTier: {tier}",
                f"riskScore: {score:.4f}",
                f"mismatches: {total_mm}",
                f"seed mismatches: {seed_mm}",
                f"PAM class: {pam_class}",
            ],
        }

    if not multiplex:
        ordered_hits = []
        for entry in hits:
            if not isinstance(entry, Mapping):
                continue
            tier = str(entry.get("riskTier") or "")
            if tier.lower() not in {"high", "medium", "low"}:
                continue
            ordered_hits.append(dict(entry))

        ordered_hits.sort(
            key=lambda h: (
                _tier_rank(h.get("riskTier")),
                -float(h.get("riskScore") or 0.0),
                str(h.get("contig") or ""),
                int(h.get("start") or 0),
                str(h.get("strand") or ""),
            )
        )

        selected: list[dict[str, Any]] = []
        for hit in ordered_hits:
            tier = str(hit.get("riskTier") or "")
            if tier.lower() not in {"high", "medium"}:
                continue
            selected.append(hit)
            if max_hits > 0 and len(selected) >= max_hits:
                break

        top_hits: list[dict[str, Any]] = []
        for idx, hit in enumerate(selected, start=1):
            entry = _to_validation_hit(hit, idx)
            if entry is not None:
                top_hits.append(entry)
    else:
        top_hits = []

    target_sections: list[dict[str, Any]] = []
    union_section: dict[str, Any] | None = None
    primary_target = None

    if multiplex:
        edit_targets: dict[str, Mapping[str, Any]] = {}
        if isinstance(edit_plan, Mapping):
            raw_targets = edit_plan.get("targets")
            if isinstance(raw_targets, list):
                for entry in raw_targets:
                    if not isinstance(entry, Mapping):
                        continue
                    tid = str(entry.get("targetId") or entry.get("id") or entry.get("label") or entry.get("name") or "")
                    if tid:
                        edit_targets[tid] = entry

        union_candidates: list[dict[str, Any]] = []
        for tid in sorted(target_hits.keys()):
            hits_for_target = target_hits.get(tid, [])
            filtered = _filter_hits(hits_for_target)
            union_candidates.extend(filtered)

            top_entries: list[dict[str, Any]] = []
            for idx, hit in enumerate(filtered, start=1):
                entry = _to_validation_hit(hit, idx)
                if entry is not None:
                    top_entries.append(entry)

            per_high = 0
            per_med = 0
            per_low = 0
            for hit in hits_for_target:
                tier = str(hit.get("riskTier") or "").lower()
                if tier == "high":
                    per_high += 1
                elif tier == "medium":
                    per_med += 1
                else:
                    per_low += 1

            primary = None
            target_meta = edit_targets.get(tid)
            if isinstance(target_meta, Mapping):
                primary = _primary_target_entry_for_target(
                    target_id=tid,
                    target=target_meta,
                    contig_lengths=contig_lengths,
                    window_radius=window_radius,
                )
            if primary is None and hits_for_target:
                first_hit = hits_for_target[0]
                primary = _primary_target_entry_for_target(
                    target_id=tid,
                    target={
                        "contig": first_hit.get("contig"),
                        "start": first_hit.get("start"),
                        "end": first_hit.get("end"),
                        "strand": first_hit.get("strand"),
                    },
                    contig_lengths=contig_lengths,
                    window_radius=window_radius,
                )

            target_sections.append(
                {
                    "targetId": tid,
                    "highRiskCount": per_high,
                    "mediumRiskCount": per_med,
                    "lowRiskCount": per_low,
                    "hitCap": max_hits,
                    "topHits": top_entries,
                    "primaryTarget": primary,
                }
            )

        union_candidates.sort(key=_union_sort_key)
        if max_hits > 0 and len(union_candidates) > max_hits:
            union_candidates = union_candidates[:max_hits]
        union_hits: list[dict[str, Any]] = []
        for idx, hit in enumerate(union_candidates, start=1):
            entry = _to_validation_hit(hit, idx)
            if entry is not None:
                union_hits.append(entry)
        top_hits = union_hits
        if target_sections:
            primary_target = target_sections[0].get("primaryTarget")
        union_section = {
            "highRiskCount": high,
            "mediumRiskCount": medium,
            "lowRiskCount": low,
            "hitCap": max_hits,
            "topHits": union_hits,
        }
    else:
        primary_target = _primary_target_entry(
            experiment_spec=experiment_spec,
            guide=guide,
            contig_lengths=contig_lengths,
            window_radius=window_radius,
        )

    summary = [
        f"High {high}, Medium {medium}, Low {low}.",
        f"Top hits capped at {max_hits}.",
    ]
    if isinstance(outcome_report, Mapping):
        sv_entries = outcome_report.get("structuralVariants") if isinstance(outcome_report.get("structuralVariants"), list) else []
        span_del = 0.0
        span_len = 0
        for entry in sv_entries:
            if not isinstance(entry, Mapping):
                continue
            if str(entry.get("kind") or "") != "spanDeletion":
                continue
            try:
                freq = float(entry.get("frequency") or 0.0)
            except Exception:
                freq = 0.0
            try:
                length = int(entry.get("length") or 0)
            except Exception:
                length = 0
            span_del = max(span_del, freq)
            span_len = max(span_len, length)
        if span_del > 0.02 or span_len > window_radius * 2:
            summary.append(
                f"Span deletion risk detected (max {span_del * 100:.2f}%, span {span_len} bp)."
            )
    guidance = [
        "High risk: validate with amplicon sequencing or targeted NGS.",
        "Medium risk: validate with amplicon sequencing.",
        "Low risk: Sanger sequencing is usually sufficient.",
    ]

    payload = {
        "schema": "helix_validation_plan_v1",
        "offTargetReportSha256": str(off_target_report_sha256),
        "summary": summary,
        "highRiskCount": high,
        "mediumRiskCount": medium,
        "lowRiskCount": low,
        "hitCap": max_hits,
        "windowRadius": window_radius,
        "topHits": top_hits,
        "primaryTarget": primary_target,
        "globalGuidance": guidance,
    }
    if multiplex:
        payload["targets"] = target_sections
        if union_section is not None:
            payload["union"] = union_section
    return payload


__all__ = [
    "build_validation_plan",
    "validation_plan_json_bytes",
    "validation_plan_sha256",
]
