from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping


RLOKS_PROVIDER_ID = "offtarget_rloks_v1"


@dataclass(frozen=True)
class RLoCKSPackFields:
    pack_id: str
    pack_fingerprint: str
    explain_schema_version: str
    error_message: str


TOOLTIPS_BY_SCHEMA: dict[str, dict[str, str]] = {
    "v1": {
        "p_cleave": "Cleavage probability over the exposure window. Higher means more risk.",
        "binding.r_bind": "Effective binding rate per site (1/s). Higher increases cleavage risk.",
        "binding.context.kon": "Association rate constant used for binding (1/(M·s)).",
        "binding.context.concentration": "Effective RNP concentration (M). Higher increases binding events.",
        "binding.context.exposure_time": "Exposure time in seconds. Longer increases cleavage probability.",
        "energy.dG_total": "Total binding free energy (kcal/mol). More negative favors binding.",
        "energy.dG_hybrid": "RNA:DNA hybridization free energy (kcal/mol). More negative is stronger pairing.",
        "energy.dG_open": "DNA opening penalty (kcal/mol). Higher makes R-loop formation harder.",
        "energy.dG_pam": "PAM contribution to binding free energy (kcal/mol). More negative is better PAM.",
        "energy.dG_fold": "Guide folding penalty (kcal/mol). Higher means less guide availability.",
        "energy.dG_mismatch": "Mismatch penalty added to binding energy (kcal/mol). Higher reduces binding.",
        "rloop.p_rloop": "Probability the R-loop reaches full length before dissociation. Higher increases risk.",
        "event.p_event": "Probability of a productive event once bound (0–1). Higher increases risk.",
        "lock.p_unlock": "Probability the HNH lock is released (0–1). Lower suppresses cleavage.",
        "lock.distal_uphill": "Distal instability inferred from the energy profile. Higher tends to lock the complex.",
        "lock.distal_barrier_spikes": "Distal mismatch barrier spikes. Higher tends to reduce unlocking.",
        "lock.fray_length": "Estimated distal fraying length (nt). Longer suggests more locking.",
        "lock.lock_energy": "Locking free energy (kcal/mol). Higher reduces unlocking.",
    }
}


def extract_rloks_pack_fields(
    payload: Mapping[str, Any] | None,
    config_params: Mapping[str, Any] | None = None,
) -> RLoCKSPackFields:
    params = {}
    if isinstance(payload, Mapping):
        params = payload.get("params") if isinstance(payload.get("params"), Mapping) else {}
    if not isinstance(params, Mapping):
        params = {}
    config_params = config_params if isinstance(config_params, Mapping) else {}
    pack_id = str(params.get("rloks_pack_id") or config_params.get("rloks_pack_id") or "")
    fingerprint = str(params.get("rloks_pack_fingerprint") or "")
    schema = str(params.get("explain_schema_version") or "")
    summary = []
    if isinstance(payload, Mapping):
        summary = payload.get("summary") if isinstance(payload.get("summary"), list) else []
    error_message = extract_rloks_error(summary)
    return RLoCKSPackFields(
        pack_id=pack_id,
        pack_fingerprint=fingerprint,
        explain_schema_version=schema,
        error_message=error_message,
    )


def extract_rloks_error(summary_lines: Iterable[Any] | None) -> str:
    lines = [str(line) for line in (summary_lines or []) if line]
    if not lines:
        return ""
    joined = "\n".join(lines)
    markers = (
        "RLoCKS pack load failed",
        "RLoCKS dependency unavailable",
        "RLoCKS pack id must be explicit",
    )
    if any(marker in joined for marker in markers):
        return joined
    return ""


def update_rloks_config(
    config: Mapping[str, Any] | None,
    pack_id: str,
    provider_id: str = RLOKS_PROVIDER_ID,
) -> dict[str, Any]:
    cfg = dict(config or {})
    params = dict(cfg.get("offtarget") or {})
    params["provider_id"] = provider_id
    params["rloks_pack_id"] = pack_id
    cfg["offtarget"] = params
    return cfg


def get_tooltip(schema_version: str, path: str) -> str | None:
    if not schema_version or not path:
        return None
    schema = TOOLTIPS_BY_SCHEMA.get(schema_version)
    if not schema:
        return None
    return schema.get(path)


def build_top_risk_drivers(explanation: Mapping[str, Any]) -> str:
    try:
        energy = explanation.get("energy", {})
        rloop = explanation.get("rloop", {})
        lock = explanation.get("lock", {})
        binding = explanation.get("binding", {})
        event = explanation.get("event", {})
        drivers: list[tuple[str, float]] = []
        if isinstance(energy, Mapping) and "dG_total" in energy:
            drivers.append(("ΔG_total", -float(energy.get("dG_total") or 0.0)))
        if isinstance(rloop, Mapping) and "p_rloop" in rloop:
            drivers.append(("p_rloop", float(rloop.get("p_rloop") or 0.0)))
        if isinstance(lock, Mapping) and "p_unlock" in lock:
            drivers.append(("p_unlock", float(lock.get("p_unlock") or 0.0)))
        if isinstance(event, Mapping) and "p_event" in event:
            drivers.append(("p_event", float(event.get("p_event") or 0.0)))
        if isinstance(binding, Mapping) and "r_bind" in binding:
            drivers.append(("r_bind", float(binding.get("r_bind") or 0.0)))
        if not drivers:
            return ""
        drivers.sort(key=lambda d: d[1], reverse=True)
        top = drivers[:3]
        parts = [f"{name}={value:.4g}" for name, value in top]
        return "Top risk drivers: " + ", ".join(parts)
    except Exception:
        return ""


def collect_explanation_paths(explanation: Mapping[str, Any]) -> list[str]:
    paths: list[str] = []

    def _walk(node: Any, prefix: str) -> None:
        if isinstance(node, Mapping):
            for key, value in node.items():
                label = str(key)
                path = f"{prefix}.{label}" if prefix else label
                paths.append(path)
                _walk(value, path)
        elif isinstance(node, list):
            for idx, entry in enumerate(node):
                path = f"{prefix}[{idx}]"
                paths.append(path)
                _walk(entry, path)

    _walk(explanation, "")
    return paths


def compute_risk_deltas(
    base_hits: Iterable[Mapping[str, Any]],
    compare_hits: Iterable[Mapping[str, Any]],
) -> dict[str, float]:
    """Compute riskScore deltas keyed by hitKey (base - compare)."""
    base = {
        str(h.get("hitKey") or ""): float(h.get("riskScore") or h.get("p_cleave") or 0.0)
        for h in base_hits
    }
    other = {
        str(h.get("hitKey") or ""): float(h.get("riskScore") or h.get("p_cleave") or 0.0)
        for h in compare_hits
    }
    deltas: dict[str, float] = {}
    for key, score in base.items():
        if key and key in other:
            deltas[key] = score - other[key]
    return deltas


__all__ = [
    "RLOKS_PROVIDER_ID",
    "RLoCKSPackFields",
    "build_top_risk_drivers",
    "collect_explanation_paths",
    "extract_rloks_error",
    "extract_rloks_pack_fields",
    "get_tooltip",
    "compute_risk_deltas",
    "TOOLTIPS_BY_SCHEMA",
    "update_rloks_config",
]
