from __future__ import annotations

import hashlib
import json
import math
import os
import platform
import re
import sys
from typing import Any, Mapping, Sequence, TYPE_CHECKING

from helix import __version__ as HELIX_VERSION
from helix import clock
from helix.provenance import current_git_sha
from helix.studio.experiment_intent_spec import (
    EXPERIMENT_INTENT_SPEC_SCHEMA_ID,
    experiment_intent_spec_sha256,
    experiment_intent_spec_to_dict,
    intent_spec_missing_required_fields,
)
from helix.studio.experiment_spec import experiment_spec_to_dict

try:
    from helix.edit.dag import dag_from_payload, EditDAG
except Exception:  # pragma: no cover - optional for non-DAG runs
    EditDAG = None  # type: ignore[assignment]
    dag_from_payload = None  # type: ignore[assignment]

if TYPE_CHECKING:  # pragma: no cover
    from helix.studio.models import RunModel, EngineInfo
    from helix.studio.session import ExperimentState


EPSILON = 1e-6
RESIDUAL_EPSILON = 1e-6
_CREATED_AT_UTC: str | None = None
SINK_IDS = ("sink.unmapped", "sink.deleted", "sink.other_rearrangement", "sink.death_arrest")

DECISION_GRADE_UNCERTAINTY_KEYS = (
    "control.intended_functional_p",
    "control.no_cut_p",
    "outcomes.top_p",
)

ROOT_CAUSE_TARGET_LOCUS = "TARGET_LOCUS_UNRESOLVED"
ROOT_CAUSE_PAM_INDEX = "PAM_INDEX_MISSING"
ROOT_CAUSE_NO_TERMINAL = "NO_TERMINAL_REACHABLE"
ROOT_CAUSE_TERMINAL_MASS = "TERMINAL_MASS_NOT_ONE"
ROOT_CAUSE_PRUNED_TERMINALS = "PRUNING_REMOVED_ALL_TERMINALS"
ROOT_CAUSE_CALIBRATION = "CALIBRATION_MISSING"
ROOT_CAUSE_CLAIMS = "CLAIMS_UNSUPPORTED"
ROOT_CAUSE_PROVENANCE = "PROVENANCE_INCOMPLETE"
ROOT_CAUSE_UNCERTAINTY = "UNCERTAINTY_INCOMPLETE"
ROOT_CAUSE_INTENDED_EDIT_SPEC = "INTENDED_EDIT_SPEC_INCOMPLETE"
ROOT_CAUSE_INTENT_SPEC_MISSING = "MISSING_INTENT_SPEC"
ROOT_CAUSE_INTENT_SPEC_INVALID = "INTENT_SPEC_INVALID_SCHEMA"
ROOT_CAUSE_INTENT_SPEC_INCOMPLETE = "INTENT_SPEC_INCOMPLETE_REQUIRED_FIELDS"
ROOT_CAUSE_INTENT_REF = "INTENT_REF_NOT_BOUND"
ROOT_CAUSE_GRAPH_CYCLE = "GRAPH_CYCLE_DETECTED"
ROOT_CAUSE_CUT_INDEX = "CUT_INDEX_UNAVAILABLE"
ROOT_CAUSE_SPECIES_UNRESOLVED = "SPECIES_UNRESOLVED"

_LOCUS_RE = re.compile(
    r"^\s*(?P<contig>[^:\s]+)\s*:\s*(?P<start>[\d,]+)\s*(?:[-–]\s*(?P<end>[\d,]+)\s*)?$"
)


def _canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n").encode("utf-8")


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _hash_payload(payload: Mapping[str, Any]) -> str:
    return _sha256_hex(_canonical_json_bytes(payload))


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


def _configured_sha(value: Any) -> bool:
    try:
        s = str(value or "").strip()
    except Exception:
        return False
    return bool(s.startswith("sha256:") and s != "sha256:unavailable")


def _provenance_decision_grade_ready(prov: Mapping[str, Any] | None) -> bool:
    if not isinstance(prov, Mapping):
        return False
    backend = prov.get("backend") if isinstance(prov.get("backend"), Mapping) else {}
    git_commit = str(backend.get("git_commit") or "").strip()
    build_ts = str(backend.get("build_timestamp_utc") or "").strip()
    if git_commit in {"", "unavailable"}:
        return False
    if build_ts in {"", "unavailable"}:
        return False

    model = prov.get("model") if isinstance(prov.get("model"), Mapping) else {}
    if not _configured_sha(model.get("model_hash")):
        return False

    params = prov.get("params") if isinstance(prov.get("params"), Mapping) else {}
    if not _configured_sha(params.get("params_hash")):
        return False

    assumptions = prov.get("assumptions") if isinstance(prov.get("assumptions"), Mapping) else {}
    cut_profile = (
        assumptions.get("cut_repair_profile")
        if isinstance(assumptions.get("cut_repair_profile"), Mapping)
        else {}
    )
    if str(cut_profile.get("id") or "").strip() in {"", "unavailable"}:
        return False
    if not _configured_sha(cut_profile.get("hash")):
        return False
    return True


def _license_decision_grade_ready(prov: Mapping[str, Any] | None) -> bool:
    if not isinstance(prov, Mapping):
        return False
    block = prov.get("license") if isinstance(prov.get("license"), Mapping) else {}
    status = str(block.get("status") or "").strip().lower()
    if status != "licensed":
        return False
    lic_id = str(block.get("license_id") or "").strip()
    lic_sha = str(block.get("license_sha256") or "").strip()
    org = str(block.get("org") or "").strip()
    edit_program_id = str(block.get("edit_program_id") or "").strip()
    if not lic_id:
        return False
    if not (lic_sha.startswith("sha256:") and lic_sha != "sha256:unavailable" and len(lic_sha) == len("sha256:") + 64):
        return False
    if not org or not edit_program_id:
        return False
    return True


def _uncertainty_decision_grade_ready(summary: Mapping[str, Any] | None) -> bool:
    if not isinstance(summary, Mapping):
        return False
    unc = summary.get("uncertainty") if isinstance(summary.get("uncertainty"), Mapping) else {}
    if str(unc.get("status") or "") != "computed":
        return False
    cis = unc.get("credible_intervals") if isinstance(unc.get("credible_intervals"), Mapping) else {}
    for key in DECISION_GRADE_UNCERTAINTY_KEYS:
        entry = cis.get(key)
        if not isinstance(entry, Mapping):
            return False
        lo = entry.get("lower")
        hi = entry.get("upper")
        if not isinstance(lo, (int, float)) or not isinstance(hi, (int, float)):
            return False
    return True


def _intended_edit_spec_decision_grade_ready(summary: Mapping[str, Any] | None) -> bool:
    if not isinstance(summary, Mapping):
        return False
    spec = summary.get("intended_edit_spec") if isinstance(summary.get("intended_edit_spec"), Mapping) else {}
    allele = spec.get("allele") if isinstance(spec.get("allele"), Mapping) else {}
    a_status = str(allele.get("status") or "").strip().lower()
    if a_status in {"", "not_specified", "absent"}:
        return False
    meas = spec.get("measurement") if isinstance(spec.get("measurement"), Mapping) else {}
    m_status = str(meas.get("status") or "").strip().lower()
    if m_status != "declared":
        return False
    if not (meas.get("assay_type") or meas.get("assay_definition_id")):
        return False
    return True


def _intent_spec_decision_grade_ready(state: "ExperimentState | None") -> tuple[bool, list[str]]:
    """
    Gate decision-grade eligibility on a complete ExperimentIntentSpec and a matching ExperimentSpec.intentRef.

    Keep this check local to the artifact: it is a chain-of-custody requirement, not a model quality claim.
    """
    if state is None:
        # Cannot evaluate without session state; do not hard-block.
        return True, []

    try:
        intent_payload = experiment_intent_spec_to_dict(getattr(state, "experiment_intent_spec", None))
        missing = intent_spec_missing_required_fields(intent_payload)
    except Exception:
        return False, [ROOT_CAUSE_INTENT_SPEC_INVALID]

    if not isinstance(getattr(state, "experiment_intent_spec", None), Mapping):
        return False, [ROOT_CAUSE_INTENT_SPEC_MISSING]
    if missing:
        return False, [ROOT_CAUSE_INTENT_SPEC_INCOMPLETE]

    try:
        exp_spec = experiment_spec_to_dict(getattr(state, "experiment_spec", None))
        ref = exp_spec.get("intentRef") if isinstance(exp_spec.get("intentRef"), Mapping) else None
        kind = str(ref.get("kind") or "") if isinstance(ref, Mapping) else ""
        sha = str(ref.get("sha256") or "") if isinstance(ref, Mapping) else ""
        expected_sha = experiment_intent_spec_sha256(intent_payload)
        if not isinstance(ref, Mapping):
            return False, [ROOT_CAUSE_INTENT_REF]
        if kind and kind != EXPERIMENT_INTENT_SPEC_SCHEMA_ID:
            return False, [ROOT_CAUSE_INTENT_REF]
        if not sha or sha != expected_sha:
            return False, [ROOT_CAUSE_INTENT_REF]
    except Exception:
        return False, [ROOT_CAUSE_INTENT_REF]

    return True, []


def _decision_grade_proof_block(
    *,
    summary: Mapping[str, Any] | None,
    provenance: Mapping[str, Any] | None,
    eligible: bool,
) -> dict[str, Any]:
    prov = provenance if isinstance(provenance, Mapping) else {}
    pdata = prov.get("data") if isinstance(prov.get("data"), Mapping) else {}

    cald = pdata.get("calibration_dataset") if isinstance(pdata.get("calibration_dataset"), Mapping) else {}
    calb = pdata.get("calibration_bundle") if isinstance(pdata.get("calibration_bundle"), Mapping) else {}

    unc = (
        summary.get("uncertainty")
        if isinstance(summary, Mapping) and isinstance(summary.get("uncertainty"), Mapping)
        else {}
    )
    unc_status = str(unc.get("status") or "not_computed")
    unc_kind = str(unc.get("kind") or "")

    return {
        "status": "present" if eligible else "absent",
        "calibration_dataset": {
            "id": str(cald.get("id") or "").strip() or None,
            "checksum": str(cald.get("checksum") or "").strip() or None,
        },
        "calibration_bundle": {
            "id": str(calb.get("id") or "").strip() or None,
            "checksum": str(calb.get("checksum") or "").strip() or None,
            "evaluation_code_hash": str(calb.get("evaluation_code_hash") or "").strip() or None,
            "model_id": str(calb.get("model_id") or "").strip() or None,
            "model_version": str(calb.get("model_version") or "").strip() or None,
            "model_hash": str(calb.get("model_hash") or "").strip() or None,
            "calibration_dataset_id": str(calb.get("calibration_dataset_id") or "").strip() or None,
            "calibration_dataset_checksum": str(calb.get("calibration_dataset_checksum") or "").strip() or None,
        },
        "uncertainty": {
            "status": unc_status,
            "kind": (unc_kind or None),
            "required_credible_interval_keys": list(DECISION_GRADE_UNCERTAINTY_KEYS),
        },
    }


def _normalize_locus(raw: str | None) -> tuple[str | None, dict[str, Any]]:
    text = str(raw or "").strip()
    if not text:
        return None, {"status": "unresolved", "reason_unresolved": "empty"}
    match = _LOCUS_RE.match(text)
    if not match:
        return None, {"status": "unresolved", "reason_unresolved": "unrecognized_format"}
    contig = str(match.group("contig"))
    start = int(match.group("start").replace(",", ""))
    end_raw = match.group("end")
    if not end_raw:
        end = start + 1
    else:
        end = int(str(end_raw).replace(",", ""))
        if end < start:
            start, end = end, start
    normalized = f"{contig}:{start}-{end}"
    return normalized, {"status": "resolved", "normalized": normalized, "contig": contig, "start": start, "end": end}


def _extract_target_locus(state: "ExperimentState | None", run: "RunModel | None") -> str:
    if run is not None and getattr(run, "target_locus", None):
        return str(run.target_locus)
    if state is None:
        return ""
    cfg = state.config if isinstance(state.config, Mapping) else {}
    guide = cfg.get("guide") if isinstance(cfg.get("guide"), Mapping) else {}
    locus = guide.get("locus")
    if isinstance(locus, str) and locus.strip():
        return locus
    plan = state.edit_plan if isinstance(state.edit_plan, Mapping) else {}
    targets = plan.get("targets") if isinstance(plan.get("targets"), list) else []
    if targets:
        first = targets[0]
        if isinstance(first, Mapping):
            locus = first.get("locus") or first.get("targetLocus")
            if isinstance(locus, str) and locus.strip():
                return locus
    return ""


def _extract_cut_index(state: "ExperimentState | None", run: "RunModel | None") -> int | None:
    if run is not None:
        if getattr(run, "cut_index", None) is not None:
            try:
                return int(run.cut_index)  # type: ignore[arg-type]
            except Exception:
                pass
    if state is None:
        return None
    cfg = state.config if isinstance(state.config, Mapping) else {}
    guide = cfg.get("guide") if isinstance(cfg.get("guide"), Mapping) else {}
    for key in ("cut_index", "cutIndex", "cut_position", "cutPosition"):
        if key in guide and guide.get(key) is not None:
            try:
                return int(guide.get(key))
            except Exception:
                return None
    return None


def _extract_pam_index(state: "ExperimentState | None", run: "RunModel | None") -> int | None:
    if run is not None and getattr(run, "pam_index", None) is not None:
        try:
            return int(run.pam_index)  # type: ignore[arg-type]
        except Exception:
            return None
    if state is None:
        return None
    cfg = state.config if isinstance(state.config, Mapping) else {}
    guide = cfg.get("guide") if isinstance(cfg.get("guide"), Mapping) else {}
    for key in ("pam_index", "pamIndex"):
        if key in guide and guide.get(key) is not None:
            try:
                return int(guide.get(key))
            except Exception:
                return None
    return None


def _extract_engine(run: "RunModel | None", state: "ExperimentState | None") -> dict[str, Any]:
    engine = None
    if run is not None:
        engine = getattr(run, "engine", None)
    if engine is None and state is not None:
        cfg = state.config if isinstance(state.config, Mapping) else {}
        engine = cfg.get("engine")
    if engine is not None and hasattr(engine, "to_dict"):
        try:
            return engine.to_dict()
        except Exception:
            pass
    if isinstance(engine, Mapping):
        return dict(engine)
    # Fallback engine skeleton
    payload = {"name": "helix", "backend": "", "crispr_scoring_version": None, "prime_scoring_version": None, "backend_reason": None}
    try:
        from helix.crispr.physics import get_last_crispr_backend_detail  # type: ignore

        backend, reason = get_last_crispr_backend_detail()
        if backend:
            payload["backend"] = backend
        if reason:
            payload["backend_reason"] = reason
    except Exception:
        pass
    return payload


def _extract_genome_build_id(state: "ExperimentState | None") -> str | None:
    if state is None:
        return None
    cfg = state.config if isinstance(state.config, Mapping) else {}
    genome = cfg.get("genome") if isinstance(cfg.get("genome"), Mapping) else {}
    for key in ("genome_id", "genomeId", "build", "build_id", "genomeBuild"):
        value = genome.get(key)
        if value:
            return str(value)
    spec = state.experiment_spec if isinstance(state.experiment_spec, Mapping) else {}
    ref = spec.get("reference") if isinstance(spec.get("reference"), Mapping) else {}
    build = ref.get("genomeBuild")
    return str(build) if build else None


def _extract_search_mode(state: "ExperimentState | None") -> str:
    if state is None:
        return ""
    cfg = state.config if isinstance(state.config, Mapping) else {}
    run_cfg = cfg.get("run_config") if isinstance(cfg.get("run_config"), Mapping) else {}
    for key in ("search_mode", "searchMode"):
        if key in run_cfg:
            return str(run_cfg.get(key) or "").lower()
    genome = cfg.get("genome") if isinstance(cfg.get("genome"), Mapping) else {}
    for key in ("search_mode", "searchMode"):
        if key in genome:
            return str(genome.get(key) or "").lower()
    outcome_cfg = cfg.get("outcome_model") if isinstance(cfg.get("outcome_model"), Mapping) else {}
    if "search_mode" in outcome_cfg:
        return str(outcome_cfg.get("search_mode") or "").lower()
    return ""


def _extract_fm_index_path(state: "ExperimentState | None") -> str | None:
    if state is None:
        return None
    cfg = state.config if isinstance(state.config, Mapping) else {}
    run_cfg = cfg.get("run_config") if isinstance(cfg.get("run_config"), Mapping) else {}
    for key in ("fm_index_path", "fmIndexPath"):
        value = run_cfg.get(key)
        if value:
            return str(value)
    genome = cfg.get("genome") if isinstance(cfg.get("genome"), Mapping) else {}
    for key in ("fm_index_path", "fmIndexPath"):
        value = genome.get(key)
        if value:
            return str(value)
    outcome_cfg = cfg.get("outcome_model") if isinstance(cfg.get("outcome_model"), Mapping) else {}
    value = outcome_cfg.get("fm_index_path") or outcome_cfg.get("fmIndexPath")
    return str(value) if value else None


def _build_fingerprint() -> dict[str, Any]:
    if os.getenv("HELIX_DETERMINISTIC"):
        return {
            "git_sha": current_git_sha(),
            "python": f"{sys.version_info.major}.{sys.version_info.minor}",
            "platform": "deterministic",
            "implementation": platform.python_implementation(),
            "cuda_driver": None,
            "cuda_visible_devices": None,
        }

    return {
        "git_sha": current_git_sha(),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "implementation": platform.python_implementation(),
        "cuda_driver": os.getenv("CUDA_DRIVER_VERSION") or os.getenv("NVIDIA_DRIVER_VERSION"),
        "cuda_visible_devices": os.getenv("CUDA_VISIBLE_DEVICES"),
    }


def _determinism_mode(state: "ExperimentState | None", run: "RunModel | None") -> str:
    if run is not None:
        meta = getattr(run, "metadata", None)
        if isinstance(meta, Mapping):
            mode = meta.get("determinism_mode")
            if isinstance(mode, str) and mode.strip():
                return mode
    if state is not None:
        cfg = state.config if isinstance(state.config, Mapping) else {}
        run_cfg = cfg.get("run_config") if isinstance(cfg.get("run_config"), Mapping) else {}
        mode = run_cfg.get("determinism_mode") or run_cfg.get("determinismMode")
        if isinstance(mode, str) and mode.strip():
            return mode
    return "tolerant"


def _float_policy() -> dict[str, Any]:
    return {
        "deterministic_kernels": bool(os.getenv("HELIX_DETERMINISTIC", "")),
        "tolerance": EPSILON,
    }


def _preflight(
    *,
    target_locus: str | None,
    search_mode: str,
    fm_index_path: str | None,
    cut_index: int | None,
    pam_index: int | None,
    run_kind: str | None,
) -> tuple[dict[str, Any], list[str], list[str]]:
    root_causes: list[str] = []
    blocked: list[str] = []
    normalized, locus_info = _normalize_locus(target_locus)
    if locus_info.get("status") != "resolved":
        root_causes.append(ROOT_CAUSE_TARGET_LOCUS)
        blocked.extend(["simulation", "probabilities", "export", "decision_mode"])
    mode = str(search_mode or "").lower()
    if mode in {"whole", "genome", "full"}:
        if not fm_index_path:
            root_causes.append(ROOT_CAUSE_PAM_INDEX)
            blocked.extend(["simulation", "probabilities", "export", "decision_mode", "off_target"])
        else:
            try:
                if not os.path.exists(str(fm_index_path)):
                    root_causes.append(ROOT_CAUSE_PAM_INDEX)
                    blocked.extend(["simulation", "probabilities", "export", "decision_mode", "off_target"])
            except Exception:
                root_causes.append(ROOT_CAUSE_PAM_INDEX)
                blocked.extend(["simulation", "probabilities", "export", "decision_mode", "off_target"])
    kind = str(run_kind or "").lower()
    requires_cut = bool(kind and "prime" not in kind)
    if requires_cut and cut_index is None and pam_index is None:
        root_causes.append(ROOT_CAUSE_CUT_INDEX)
        blocked.extend(["simulation", "probabilities", "export", "decision_mode"])
    validity = {
        "status": "valid" if not root_causes else "invalid",
        "root_causes": list(dict.fromkeys(root_causes)),
        "blocked_features": list(dict.fromkeys(blocked)),
    }
    return validity, root_causes, blocked, locus_info, normalized


def _graph_hash(payload: Mapping[str, Any]) -> str:
    nodes = payload.get("nodes") if isinstance(payload.get("nodes"), Mapping) else {}
    edges = payload.get("edges") if isinstance(payload.get("edges"), Sequence) else []
    ordered_nodes = [
        {
            "id": node_id,
            "log_prob": float(node_entry.get("log_prob", 0.0)) if isinstance(node_entry, Mapping) else 0.0,
            "parents": list(node_entry.get("parents") or node_entry.get("parent_ids") or [])
            if isinstance(node_entry, Mapping)
            else [],
        }
        for node_id, node_entry in sorted(nodes.items(), key=lambda kv: kv[0])
    ]
    ordered_edges = sorted(
        [
            {
                "source": e.get("source"),
                "target": e.get("target"),
                "rule": e.get("rule") or e.get("rule_name") or "",
            }
            for e in edges
            if isinstance(e, Mapping)
        ],
        key=lambda e: (str(e.get("source")), str(e.get("target")), str(e.get("rule") or "")),
    )
    canonical = {"root_id": payload.get("root_id"), "nodes": ordered_nodes, "edges": ordered_edges}
    return _hash_payload(canonical)


def _state_digest(node_payload: Mapping[str, Any]) -> str:
    meta = node_payload.get("metadata") if isinstance(node_payload.get("metadata"), Mapping) else {}
    seq_hashes = node_payload.get("seq_hashes") if isinstance(node_payload.get("seq_hashes"), Mapping) else {}
    diffs = node_payload.get("diffs") if isinstance(node_payload.get("diffs"), Sequence) else []
    payload = {
        "metadata": dict(meta),
        "seq_hashes": dict(seq_hashes),
        "diffs": list(diffs),
    }
    return _hash_payload(payload)


def _dag_to_graph(payload: Mapping[str, Any]) -> tuple[dict[str, Any], dict[str, float], list[str], list[str]]:
    if dag_from_payload is None:
        raise RuntimeError("DAG helpers unavailable")
    dag = dag_from_payload(dict(payload))
    root_id = str(dag.root_id)
    edges = list(dag.edges)
    nodes = dag.nodes
    outgoing: dict[str, list[Any]] = {}
    incoming: dict[str, list[Any]] = {}
    for edge in edges:
        outgoing.setdefault(str(edge.source), []).append(edge)
        incoming.setdefault(str(edge.target), []).append(edge)

    root_log_p = float(nodes[root_id].log_prob) if root_id in nodes else 0.0
    masses: dict[str, float] = {str(node_id): 0.0 for node_id in nodes}
    for node_id, node in nodes.items():
        nid = str(node_id)
        if nid == root_id:
            masses[nid] = 1.0
            continue
        try:
            masses[nid] = max(0.0, float(math.exp(float(node.log_prob) - root_log_p)))
        except Exception:
            masses[nid] = 0.0

    edge_probs: dict[tuple[str, str], float] = {}
    for source, edge_list in outgoing.items():
        parent_mass = float(masses.get(str(source), 0.0))
        if parent_mass <= 0.0:
            for edge in edge_list:
                edge_probs[(str(edge.source), str(edge.target))] = 0.0
            continue
        for edge in edge_list:
            child_mass = float(masses.get(str(edge.target), 0.0))
            edge_probs[(str(edge.source), str(edge.target))] = child_mass / parent_mass

    indegree: dict[str, int] = {str(node_id): 0 for node_id in nodes}
    for src, edges_list in outgoing.items():
        for edge in edges_list:
            tgt = str(edge.target)
            indegree[tgt] = indegree.get(tgt, 0) + 1
    queue = [nid for nid, deg in indegree.items() if deg == 0]
    queue.sort()
    ordered: list[str] = []
    while queue:
        nid = queue.pop(0)
        ordered.append(nid)
        for edge in outgoing.get(nid, []):
            tgt = str(edge.target)
            indegree[tgt] -= 1
            if indegree[tgt] == 0:
                queue.append(tgt)
                queue.sort()
    if len(ordered) != len(nodes):
        raise ValueError(ROOT_CAUSE_GRAPH_CYCLE)

    terminals = [nid for nid in nodes if nid not in outgoing]
    terminals.sort()
    terminal_sum = sum(masses.get(nid, 0.0) for nid in terminals)

    graph_nodes: list[dict[str, Any]] = []
    for node_id, node in nodes.items():
        nid = str(node_id)
        node_payload = payload.get("nodes", {}).get(node_id, {}) if isinstance(payload.get("nodes"), Mapping) else {}
        parent_ids = tuple(node.parents or ())
        p_edge_in = []
        for parent in parent_ids:
            prob = edge_probs.get((str(parent), nid), 0.0)
            p_edge_in.append({"parent_id": str(parent), "prob": float(prob)})
        role = "terminal" if nid in terminals else ("root" if nid == root_id else "internal")
        graph_nodes.append(
            {
                "id": nid,
                "type": role,
                "parents": list(parent_ids),
                "state_digest": _state_digest(node_payload) if isinstance(node_payload, Mapping) else None,
                "p_node": float(masses.get(nid, 0.0)),
                "p_edge_in": p_edge_in,
            }
        )

    graph_edges: list[dict[str, Any]] = []
    for edge in edges:
        src = str(edge.source)
        tgt = str(edge.target)
        graph_edges.append(
            {
                "source": src,
                "target": tgt,
                "rule": str(edge.rule_name or ""),
                "prob": float(edge_probs.get((src, tgt), 0.0)),
            }
        )

    graph = {
        "source": "dag",
        "root_id": root_id,
        "nodes": graph_nodes,
        "edges": graph_edges,
        "terminals": terminals,
        "node_count": len(graph_nodes),
        "edge_count": len(graph_edges),
        "terminal_sum": terminal_sum,
        "graph_hash": _graph_hash(payload),
    }
    return graph, masses, terminals, ordered


def _outcomes_to_graph(outcomes: Sequence[Mapping[str, Any]]) -> tuple[dict[str, Any], dict[str, float], list[str], list[str]]:
    root_id = "root"
    graph_nodes: list[dict[str, Any]] = [
        {
            "id": root_id,
            "type": "root",
            "parents": [],
            "state_digest": None,
            "p_node": 1.0,
            "p_edge_in": [],
        }
    ]
    graph_edges: list[dict[str, Any]] = []
    masses: dict[str, float] = {root_id: 1.0}
    terminals: list[str] = []
    ordered = [root_id]
    for idx, outcome in enumerate(outcomes):
        if not isinstance(outcome, Mapping):
            continue
        raw_id = outcome.get("outcome_id") or outcome.get("id") or outcome.get("label") or f"outcome_{idx+1}"
        node_id = str(raw_id)
        prob = float(outcome.get("probability", outcome.get("prob", 0.0)) or 0.0)
        graph_edges.append({"source": root_id, "target": node_id, "rule": "outcome", "prob": prob})
        graph_nodes.append(
            {
                "id": node_id,
                "type": "terminal",
                "parents": [root_id],
                "state_digest": _hash_payload(dict(outcome)),
                "p_node": prob,
                "p_edge_in": [{"parent_id": root_id, "prob": prob}],
            }
        )
        masses[node_id] = prob
        terminals.append(node_id)
        ordered.append(node_id)
    terminals.sort()
    terminal_sum = sum(masses.get(nid, 0.0) for nid in terminals)
    graph = {
        "source": "outcomes",
        "root_id": root_id,
        "nodes": graph_nodes,
        "edges": graph_edges,
        "terminals": terminals,
        "terminals_nice": [t for t in terminals if t not in SINK_IDS],
        "sinks": [],
        "node_count": len(graph_nodes),
        "edge_count": len(graph_edges),
        "terminal_sum": terminal_sum,
        "graph_hash": _hash_payload({"outcomes": [dict(o) for o in outcomes]}),
    }
    return graph, masses, terminals, ordered


def _reachable_to_terminals(
    nodes: Sequence[str],
    terminals: Sequence[str],
    edges: Sequence[Mapping[str, Any]],
) -> set[str]:
    parents: dict[str, list[str]] = {str(n): [] for n in nodes}
    for edge in edges:
        src = edge.get("source")
        tgt = edge.get("target")
        if src is None or tgt is None:
            continue
        parents.setdefault(str(tgt), []).append(str(src))
    reachable = set(str(t) for t in terminals)
    queue = list(reachable)
    while queue:
        cur = queue.pop()
        for parent in parents.get(cur, []):
            if parent not in reachable:
                reachable.add(parent)
                queue.append(parent)
    return reachable


def _add_leakage_sinks(
    *,
    graph: dict[str, Any],
    masses: dict[str, float],
    terminals: list[str],
    residual: float,
    root_id: str,
    breakdown: Mapping[str, float] | None = None,
) -> float:
    """Attach sink nodes/edges to the graph, return added mass."""
    if residual <= RESIDUAL_EPSILON:
        return 0.0
    breakdown = breakdown if isinstance(breakdown, Mapping) else {}
    # Use provided breakdown if available; otherwise allocate all to unmapped.
    sinks: list[tuple[str, float]] = []
    for sink_id in SINK_IDS:
        key = sink_id.split(".")[-1]
        mass = float(breakdown.get(key, 0.0))
        if mass > 0:
            sinks.append((sink_id, mass))
    if not sinks:
        sinks.append((SINK_IDS[0], residual))
        total = residual
    else:
        total = sum(m for _, m in sinks)
        # If breakdown doesn't sum, scale into residual proportionally.
        if total > 0:
            scale = residual / total
            sinks = [(sid, m * scale) for sid, m in sinks]
            total = residual

    for sink_id, mass in sinks:
        masses[sink_id] = mass
        terminals.append(sink_id)
        graph["nodes"].append(
            {
                "id": sink_id,
                "type": "sink",
                "is_sink": True,
                "label": sink_id,
                "parents": [root_id],
                "state_digest": None,
                "p_node": mass,
                "p_edge_in": [{"parent_id": root_id, "prob": mass}],
            }
        )
        graph["edges"].append({"source": root_id, "target": sink_id, "rule": "sink", "prob": mass})
    terminals.sort()
    graph["terminal_sum"] = float(graph.get("terminal_sum", 0.0)) + total
    graph["sinks"].extend([sid for sid, _ in sinks])
    graph["terminals_nice"] = [t for t in terminals if t not in SINK_IDS]
    graph["node_count"] = len(graph["nodes"])
    graph["edge_count"] = len(graph["edges"])
    return total


def _extract_calibration(state: "ExperimentState | None", run: "RunModel | None") -> dict[str, Any]:
    summary = None
    if run is not None:
        meta = getattr(run, "metadata", None)
        if isinstance(meta, Mapping):
            if isinstance(meta.get("run_summary"), Mapping):
                summary = meta.get("run_summary")
    if summary and isinstance(summary, Mapping):
        prov = summary.get("provenance") if isinstance(summary.get("provenance"), Mapping) else {}
        prov_data = prov.get("data") if isinstance(prov.get("data"), Mapping) else {}
        bundle = (
            prov_data.get("calibration_bundle")
            if isinstance(prov_data.get("calibration_bundle"), Mapping)
            else {}
        )
        bundle_id = str(bundle.get("id") or "").strip()
        bundle_hash = str(bundle.get("checksum") or "").strip()
        proof_ok = bool(bundle_id and bundle_id != "unconfigured" and bundle_hash.startswith("sha256:") and bundle_hash != "sha256:unavailable")
        if not proof_ok:
            return {"status": "missing", "regime_id": None, "metrics": None, "ood": None}

        model_stack = summary.get("model_stack") if isinstance(summary.get("model_stack"), Mapping) else {}
        repair = model_stack.get("repair_model") if isinstance(model_stack.get("repair_model"), Mapping) else {}
        cal = repair.get("calibration") if isinstance(repair.get("calibration"), Mapping) else {}
        dataset_id = str(cal.get("dataset_id") or "").strip()
        if dataset_id and dataset_id != "unconfigured":
            return {
                "status": "present",
                "regime_id": dataset_id,
                "metrics": cal.get("metrics"),
                "ood": cal.get("ood"),
            }
    if state is not None:
        profiles = getattr(state, "calibration_profiles", None)
        if isinstance(profiles, list) and profiles:
            return {"status": "present", "regime_id": None, "metrics": None, "ood": None}
    return {"status": "missing", "regime_id": None, "metrics": None, "ood": None}


def build_run_artifact_from_state(
    state: "ExperimentState",
    *,
    run: "RunModel | None" = None,
    ui_view_settings: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    dag_payload = state.dag_from_runtime if isinstance(state.dag_from_runtime, Mapping) else None
    outcomes = state.outcomes or []
    cfg = state.config if isinstance(state.config, Mapping) else {}
    sim_payload = cfg.get("sim_payload") if isinstance(cfg.get("sim_payload"), Mapping) else {}
    if not outcomes and isinstance(sim_payload.get("outcomes"), list):
        outcomes = sim_payload.get("outcomes") or []
    return build_run_artifact(
        run_id=str(getattr(state, "run_id", "") or getattr(run, "run_id", "run")),
        dag_payload=dag_payload,
        outcomes=outcomes if isinstance(outcomes, list) else [],
        state=state,
        run=run,
        ui_view_settings=ui_view_settings,
    )


def build_run_artifact_from_run_model(
    run: "RunModel",
    *,
    state: "ExperimentState | None" = None,
    config: Mapping[str, Any] | None = None,
    ui_view_settings: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    return build_run_artifact(
        run_id=str(run.run_id),
        dag_payload=None,
        outcomes=[o.to_dict() for o in run.outcomes],
        state=state,
        run=run,
        ui_view_settings=ui_view_settings,
        extra_config=config,
    )


def build_run_artifact(
    *,
    run_id: str,
    dag_payload: Mapping[str, Any] | None,
    outcomes: Sequence[Mapping[str, Any]] | None,
    state: "ExperimentState | None",
    run: "RunModel | None",
    ui_view_settings: Mapping[str, Any] | None = None,
    extra_config: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    target_locus = _extract_target_locus(state, run)
    cut_index = _extract_cut_index(state, run)
    pam_index = _extract_pam_index(state, run)
    search_mode = _extract_search_mode(state)
    fm_index_path = _extract_fm_index_path(state)
    genome_build_id = _extract_genome_build_id(state)
    run_kind = None
    if run is not None:
        run_kind = getattr(run, "edit_type", None)
    if run_kind is None and state is not None:
        run_kind = getattr(state, "run_kind", None)
    cfg = state.config if (state is not None and isinstance(state.config, Mapping)) else {}
    if extra_config and isinstance(extra_config, Mapping):
        cfg = dict(cfg)
        cfg.update(extra_config)
    dag_cfg = cfg.get("dag") if isinstance(cfg.get("dag"), Mapping) else {}
    leakage_sinks_enabled = bool(dag_cfg.get("leakage_sinks"))
    pruning_cfg: dict[str, Any] = {}
    outcome_cfg = cfg.get("outcome_model") if isinstance(cfg.get("outcome_model"), Mapping) else {}
    for key in ("top_k", "tail_sample", "min_p", "max_outcomes"):
        if key in outcome_cfg:
            pruning_cfg[key] = outcome_cfg.get(key)
    validity, _root_causes, _blocked, locus_info, _normalized = _preflight(
        target_locus=target_locus,
        search_mode=search_mode,
        fm_index_path=fm_index_path,
        cut_index=cut_index,
        pam_index=pam_index,
        run_kind=str(run_kind) if run_kind is not None else None,
    )
    inputs = {
        "genome_build_id": genome_build_id,
        "target_locus": locus_info,
        "cut_index": {"status": "present" if cut_index is not None else "missing", "value": cut_index},
        "pam_index": {
            "requested": bool(search_mode in {"whole", "genome", "full"}),
            "status": "present" if fm_index_path else "missing",
            "index_id": fm_index_path or genome_build_id,
        },
    }
    settings = {
        "pruning": pruning_cfg,
        "ui_view_settings": dict(ui_view_settings or {}),
    }
    engine = _extract_engine(run, state)
    global _CREATED_AT_UTC
    if _CREATED_AT_UTC is None:
        _CREATED_AT_UTC = _utc_now_iso()

    run_summary = None
    if run is not None:
        meta = getattr(run, "metadata", None)
        if isinstance(meta, Mapping) and isinstance(meta.get("run_summary"), Mapping):
            run_summary = meta.get("run_summary")
    summary_decision_mode = str(run_summary.get("decision_mode") or "filter_only") if isinstance(run_summary, Mapping) else "filter_only"
    summary_decision_mode_requested = (
        str(run_summary.get("decision_mode_requested") or "") if isinstance(run_summary, Mapping) else ""
    )
    summary_validity = run_summary.get("validity") if isinstance(run_summary, Mapping) else None
    if isinstance(run_summary, Mapping):
        cand = run_summary.get("species_detection")
        if isinstance(cand, Mapping):
            inputs["species_detection"] = dict(cand)
    inputs.setdefault("species_detection", None)

    artifact: dict[str, Any] = {
        "run_id": str(run_id),
        "artifact_hash": "",
        "engine": engine,
        "version": HELIX_VERSION,
        "build_fingerprint": _build_fingerprint(),
        "determinism_mode": _determinism_mode(state, run),
        "float_policy": _float_policy(),
        "inputs": inputs,
        "settings": settings,
        "validity": validity,
        "graph": {"nodes": [], "edges": [], "terminals": [], "source": None, "terminal_sum": 0.0},
        "mass": {
            "terminal_sum": 0.0,
            "displayed_mass": 0.0,
            "residual_mass": 0.0,
            "epsilon": EPSILON,
            "sinks_enabled": False,
            "renormalized": False,
            "renorm_reason": None,
        },
        "calibration": _extract_calibration(state, run),
        "claims": {"status": "unsupported", "provenance": {}, "checks_passed": []},
        "decision_mode": summary_decision_mode if summary_decision_mode in {"filter_only", "decision_grade"} else "filter_only",
        "decision_mode_requested": summary_decision_mode_requested or None,
        "provenance": (dict(run_summary.get("provenance") or {}) if isinstance(run_summary, Mapping) else {}),
        "decision_grade_proof": _decision_grade_proof_block(
            summary=run_summary if isinstance(run_summary, Mapping) else None,
            provenance=(run_summary.get("provenance") if isinstance(run_summary, Mapping) else None),
            eligible=False,
        ),
        "decision_mode_eligible": False,
        "created_at_utc": _CREATED_AT_UTC,
    }

    if isinstance(summary_validity, Mapping) and str(summary_validity.get("status") or "") == "invalid":
        causes = summary_validity.get("root_causes") if isinstance(summary_validity.get("root_causes"), list) else []
        causes = [str(c) for c in causes if str(c)]
        validity["status"] = "invalid"
        validity["root_causes"] = list(dict.fromkeys(list(validity.get("root_causes", [])) + causes))
        validity["blocked_features"] = list(
            dict.fromkeys(list(validity.get("blocked_features", [])) + ["decision_mode"])
        )
        artifact["decision_mode"] = "filter_only"

    if validity.get("status") != "valid":
        return _finalize_artifact(artifact)

    graph = None
    masses: dict[str, float] = {}
    terminals: list[str] = []
    ordered: list[str] = []
    try:
        if dag_payload is not None and dag_payload.get("nodes"):
            graph, masses, terminals, ordered = _dag_to_graph(dag_payload)
        elif outcomes:
            graph, masses, terminals, ordered = _outcomes_to_graph(outcomes)
    except Exception as exc:
        reason = ROOT_CAUSE_GRAPH_CYCLE if str(exc) == ROOT_CAUSE_GRAPH_CYCLE else ROOT_CAUSE_NO_TERMINAL
        validity["status"] = "invalid"
        validity["root_causes"] = list(dict.fromkeys(list(validity.get("root_causes", [])) + [reason]))
        validity["blocked_features"] = list(dict.fromkeys(list(validity.get("blocked_features", [])) + ["probabilities"]))
        return _finalize_artifact(artifact)

    if graph is None:
        validity["status"] = "invalid"
        validity["root_causes"] = list(dict.fromkeys(list(validity.get("root_causes", [])) + [ROOT_CAUSE_NO_TERMINAL]))
        validity["blocked_features"] = list(dict.fromkeys(list(validity.get("blocked_features", [])) + ["probabilities"]))
        return _finalize_artifact(artifact)

    terminal_sum = float(graph.get("terminal_sum", 0.0))
    displayed_mass = terminal_sum
    residual_mass = max(0.0, 1.0 - displayed_mass)
    if leakage_sinks_enabled and residual_mass > EPSILON:
        root_id = str(graph.get("root_id") or "root")
        residual_mass = _add_leakage_sinks(
            graph=graph,
            masses=masses,
            terminals=terminals,
            residual=residual_mass,
            root_id=root_id,
        )
        terminal_sum = float(graph.get("terminal_sum", displayed_mass + residual_mass))
    artifact["graph"] = graph
    artifact["mass"]["terminal_sum"] = terminal_sum
    artifact["mass"]["displayed_mass"] = displayed_mass
    artifact["mass"]["residual_mass"] = residual_mass
    artifact["mass"]["sinks_enabled"] = leakage_sinks_enabled

    if not terminals or terminal_sum <= 0.0:
        validity["status"] = "invalid"
        validity["root_causes"] = list(dict.fromkeys(list(validity.get("root_causes", [])) + [ROOT_CAUSE_NO_TERMINAL]))
        validity["blocked_features"] = list(dict.fromkeys(list(validity.get("blocked_features", [])) + ["probabilities"]))
        artifact["graph"] = {"nodes": [], "edges": [], "terminals": [], "source": graph.get("source"), "terminal_sum": terminal_sum}
        return _finalize_artifact(artifact)

    if abs(terminal_sum - 1.0) > EPSILON:
        validity["status"] = "invalid"
        validity["root_causes"] = list(
            dict.fromkeys(list(validity.get("root_causes", [])) + [ROOT_CAUSE_TERMINAL_MASS])
        )
        validity["blocked_features"] = list(dict.fromkeys(list(validity.get("blocked_features", [])) + ["probabilities"]))
        artifact["graph"] = {"nodes": [], "edges": [], "terminals": [], "source": graph.get("source"), "terminal_sum": terminal_sum}
        return _finalize_artifact(artifact)

    reachable = _reachable_to_terminals([n["id"] for n in graph["nodes"]], terminals, graph["edges"])
    for node in graph["nodes"]:
        if float(node.get("p_node", 0.0)) > 0.0 and node["id"] not in reachable:
            validity["status"] = "invalid"
            validity["root_causes"] = list(
                dict.fromkeys(list(validity.get("root_causes", [])) + [ROOT_CAUSE_NO_TERMINAL])
            )
            validity["blocked_features"] = list(
                dict.fromkeys(list(validity.get("blocked_features", [])) + ["probabilities"])
            )
            artifact["graph"] = {"nodes": [], "edges": [], "terminals": [], "source": graph.get("source"), "terminal_sum": terminal_sum}
            return _finalize_artifact(artifact)

    calibration = artifact.get("calibration", {})
    if isinstance(calibration, Mapping) and str(calibration.get("status") or "") != "present":
        validity["root_causes"] = list(
            dict.fromkeys(list(validity.get("root_causes", [])) + [ROOT_CAUSE_CALIBRATION])
        )

    claims_supported = bool(validity.get("status") == "valid") and str(calibration.get("status") or "") == "present"
    claims = {
        "status": "supported" if claims_supported else "unsupported",
        "provenance": {
            "model_hash": (run.metadata.get("model_hash") if run is not None and isinstance(getattr(run, "metadata", None), Mapping) else None),
            "data_regime_ids": (run.metadata.get("data_regime_ids") if run is not None and isinstance(getattr(run, "metadata", None), Mapping) else None),
            "config_hash": None,
        },
        "checks_passed": [] if claims_supported else [ROOT_CAUSE_CLAIMS],
    }
    artifact["claims"] = claims
    if not claims_supported:
        validity["root_causes"] = list(dict.fromkeys(list(validity.get("root_causes", [])) + [ROOT_CAUSE_CLAIMS]))

    uncertainty_ready = _uncertainty_decision_grade_ready(run_summary)
    if not uncertainty_ready:
        validity["root_causes"] = list(
            dict.fromkeys(list(validity.get("root_causes", [])) + [ROOT_CAUSE_UNCERTAINTY])
        )

    intended_ready = _intended_edit_spec_decision_grade_ready(run_summary)
    if not intended_ready:
        validity["root_causes"] = list(
            dict.fromkeys(list(validity.get("root_causes", [])) + [ROOT_CAUSE_INTENDED_EDIT_SPEC])
        )

    calibration_proof_ready = False
    try:
        prov = artifact.get("provenance") if isinstance(artifact.get("provenance"), Mapping) else {}
        prov_model = prov.get("model") if isinstance(prov.get("model"), Mapping) else {}
        model_id = str(prov_model.get("model_id") or "").strip()
        model_version = str(prov_model.get("model_version") or "").strip()
        model_hash = str(prov_model.get("model_hash") or "").strip()
        pdata = prov.get("data") if isinstance(prov.get("data"), Mapping) else {}
        bundle = pdata.get("calibration_bundle") if isinstance(pdata.get("calibration_bundle"), Mapping) else {}
        bid = str(bundle.get("id") or "").strip()
        bsha = str(bundle.get("checksum") or "").strip()
        bcode = str(bundle.get("evaluation_code_hash") or "").strip()
        bmid = str(bundle.get("model_id") or "").strip()
        bmver = str(bundle.get("model_version") or "").strip()
        bmhash = str(bundle.get("model_hash") or "").strip()
        bds_id = str(bundle.get("calibration_dataset_id") or "").strip()
        bds_sha = str(bundle.get("calibration_dataset_checksum") or "").strip()
        cald = pdata.get("calibration_dataset") if isinstance(pdata.get("calibration_dataset"), Mapping) else {}
        ds_id = str(cald.get("id") or "").strip()
        ds_sha = str(cald.get("checksum") or "").strip()
        calibration_proof_ready = bool(
            bid
            and bid != "unconfigured"
            and bsha.startswith("sha256:")
            and bsha != "sha256:unavailable"
            and bcode.startswith("sha256:")
            and bcode != "sha256:unavailable"
            and model_id
            and model_version
            and model_hash.startswith("sha256:")
            and model_hash != "sha256:unavailable"
            and bmid == model_id
            and bmver == model_version
            and bmhash == model_hash
            and bds_id == ds_id
            and bds_sha == ds_sha
            and ds_id
            and ds_id != "unconfigured"
            and ds_sha.startswith("sha256:")
            and ds_sha != "sha256:unavailable"
        )
    except Exception:
        calibration_proof_ready = False
    if not calibration_proof_ready:
        validity["root_causes"] = list(
            dict.fromkeys(list(validity.get("root_causes", [])) + [ROOT_CAUSE_CALIBRATION])
        )

    provenance_ready = _provenance_decision_grade_ready(artifact.get("provenance") if isinstance(artifact.get("provenance"), Mapping) else None)
    if not provenance_ready:
        validity["root_causes"] = list(
            dict.fromkeys(list(validity.get("root_causes", [])) + [ROOT_CAUSE_PROVENANCE])
        )

    license_ready = _license_decision_grade_ready(artifact.get("provenance") if isinstance(artifact.get("provenance"), Mapping) else None)

    intent_ready, intent_causes = _intent_spec_decision_grade_ready(state)
    if not intent_ready and intent_causes:
        validity["root_causes"] = list(dict.fromkeys(list(validity.get("root_causes", [])) + list(intent_causes)))

    decision_mode_eligible = (
        validity.get("status") == "valid"
        and str(artifact.get("decision_mode") or "") == "decision_grade"
        and str(calibration.get("status") or "") == "present"
        and claims_supported
        and uncertainty_ready
        and intended_ready
        and provenance_ready
        and license_ready
        and intent_ready
        and calibration_proof_ready
        and (not inputs["pam_index"]["requested"] or inputs["pam_index"]["status"] == "present")
        and inputs["target_locus"].get("status") == "resolved"
    )
    artifact["decision_mode_eligible"] = bool(decision_mode_eligible)
    artifact["decision_grade_proof"] = _decision_grade_proof_block(
        summary=run_summary if isinstance(run_summary, Mapping) else None,
        provenance=artifact.get("provenance") if isinstance(artifact.get("provenance"), Mapping) else None,
        eligible=bool(decision_mode_eligible),
    )
    return _finalize_artifact(artifact)


def _finalize_artifact(artifact: dict[str, Any]) -> dict[str, Any]:
    payload = dict(artifact)
    payload["artifact_hash"] = ""
    digest = _hash_payload(payload)
    artifact["artifact_hash"] = digest
    return artifact


def artifact_is_valid(artifact: Mapping[str, Any] | None) -> bool:
    if not isinstance(artifact, Mapping):
        return False
    validity = artifact.get("validity") if isinstance(artifact.get("validity"), Mapping) else {}
    return str(validity.get("status") or "") == "valid"


def artifact_root_causes(artifact: Mapping[str, Any] | None) -> list[str]:
    if not isinstance(artifact, Mapping):
        return []
    validity = artifact.get("validity") if isinstance(artifact.get("validity"), Mapping) else {}
    causes = validity.get("root_causes") if isinstance(validity.get("root_causes"), list) else []
    return [str(c) for c in causes]


def artifact_calibrated(artifact: Mapping[str, Any] | None) -> bool:
    if not isinstance(artifact, Mapping):
        return False
    calibration = artifact.get("calibration") if isinstance(artifact.get("calibration"), Mapping) else {}
    return str(calibration.get("status") or "") == "present"


def artifact_decision_mode_eligible(artifact: Mapping[str, Any] | None) -> bool:
    if not isinstance(artifact, Mapping):
        return False
    return bool(artifact.get("decision_mode_eligible"))


__all__ = [
    "EPSILON",
    "ROOT_CAUSE_TARGET_LOCUS",
    "ROOT_CAUSE_PAM_INDEX",
    "ROOT_CAUSE_NO_TERMINAL",
    "ROOT_CAUSE_TERMINAL_MASS",
    "ROOT_CAUSE_PRUNED_TERMINALS",
    "ROOT_CAUSE_CALIBRATION",
    "ROOT_CAUSE_CLAIMS",
    "ROOT_CAUSE_PROVENANCE",
    "ROOT_CAUSE_UNCERTAINTY",
    "ROOT_CAUSE_GRAPH_CYCLE",
    "ROOT_CAUSE_CUT_INDEX",
    "ROOT_CAUSE_SPECIES_UNRESOLVED",
    "build_run_artifact_from_state",
    "build_run_artifact_from_run_model",
    "build_run_artifact",
    "artifact_is_valid",
    "artifact_root_causes",
    "artifact_calibrated",
    "artifact_decision_mode_eligible",
]
