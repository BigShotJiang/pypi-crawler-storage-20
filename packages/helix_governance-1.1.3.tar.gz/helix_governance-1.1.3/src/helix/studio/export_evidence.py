from __future__ import annotations

import json
import hashlib
from pathlib import Path
from typing import Any, Mapping

from helix import __version__ as helix_version
from helix import clock
from helix.security.tokens import token_hex
from helix.studio.models import RunModel, EngineInfo, OutcomeModel
from helix.studio.run_artifact import (
    build_run_artifact_from_run_model,
    artifact_decision_mode_eligible,
)
from helix.studio.governance_stamp import (
    extract_decision_grade_proof_from_artifact,
    extract_decision_grade_proof_from_summary,
    governance_stamp_lines,
    interpretation_for_mode,
    normalize_decision_mode,
)
from helix.studio.export_labels import build_governance_provenance, is_demo_from_metadata, is_demo_from_preset
from helix.studio.limitations import limitations_stamp
from helix.studio.provenance_header import build_provenance_header_v1


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_json(obj: Any) -> str:
    return _sha256_bytes(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8"))


def _utc_now_iso() -> str:
    # Example: 2025-11-29T03:14:15Z
    return clock.utc_now_iso()


def _run_model_from_snapshot(snapshot: Mapping[str, Any]) -> RunModel:
    state = snapshot.get("state", snapshot)
    outcomes_raw = state.get("outcomes", []) or []
    outcomes = [
        OutcomeModel(
            name=o.get("label") or o.get("name") or o.get("category", ""),
            category=o.get("category", ""),
            prob=float(o.get("probability", o.get("prob", 0.0)) or 0.0),
            delta_bp=o.get("delta_bp"),
            peak_position=o.get("peak_position"),
            position_min=o.get("position_min"),
            position_max=o.get("position_max"),
            frameshift=o.get("frameshift"),
            microhomology=o.get("microhomology"),
        )
        for o in outcomes_raw
    ]
    engine = EngineInfo(
        name=str(state.get("run_kind", "cli")),
        backend=str(state.get("engine_backend", "cpu-reference")),
        crispr_scoring_version=state.get("crispr_scoring_version"),
        prime_scoring_version=state.get("prime_scoring_version"),
        backend_reason=state.get("engine_backend_reason"),
    )
    return RunModel(
        run_id=str(state.get("run_id", "run")),
        guide_id=str(state.get("config", {}).get("guide", {}).get("id", "guide")) if isinstance(state.get("config"), Mapping) else "guide",
        edit_type=str(state.get("run_kind", "crispr")),
        sequence=str(state.get("sequence", "")),
        target_locus=str(state.get("config", {}).get("guide", {}).get("locus", "")) if isinstance(state.get("config"), Mapping) else "",
        pam_index=state.get("config", {}).get("guide", {}).get("pam_index") if isinstance(state.get("config"), Mapping) else None,
        cut_index=state.get("config", {}).get("guide", {}).get("cut_index") if isinstance(state.get("config"), Mapping) else None,
        outcomes=outcomes,
        physics=state.get("physics") or state.get("config", {}).get("sim_payload", {}).get("physics_score", {}) if isinstance(state.get("config"), Mapping) else {},
        engine=engine,
        metadata=state.get("config", {}).get("metadata", {}) if isinstance(state.get("config"), Mapping) else {},
    )


def run_to_evidence(
    run_or_snapshot: RunModel | Mapping[str, Any],
    preset: Mapping[str, Any] | None = None,
    *,
    include_sequence: bool = False,
    snapshot: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Serialize a run into a portable evidence payload."""
    run = run_or_snapshot if isinstance(run_or_snapshot, RunModel) else _run_model_from_snapshot(run_or_snapshot)
    meta = run.metadata if isinstance(run.metadata, Mapping) else {}
    artifact = meta.get("run_artifact") if isinstance(meta, Mapping) else None
    if not isinstance(artifact, Mapping):
        artifact = build_run_artifact_from_run_model(run)
    run_summary_v2 = meta.get("run_summary") if isinstance(meta.get("run_summary"), Mapping) else None
    decision_mode_eligible = artifact_decision_mode_eligible(artifact) if isinstance(artifact, Mapping) else False
    decision_mode_requested = normalize_decision_mode(artifact.get("decision_mode") if isinstance(artifact, Mapping) else None)
    decision_mode = (
        "decision_grade"
        if (decision_mode_requested == "decision_grade" and decision_mode_eligible)
        else "filter_only"
    )
    outcome_value_label = "probability" if decision_mode == "decision_grade" else "score"
    interpretation = interpretation_for_mode(decision_mode)
    proof = None
    if decision_mode == "decision_grade":
        proof = extract_decision_grade_proof_from_artifact(artifact if isinstance(artifact, Mapping) else None)
        if proof is None:
            proof = extract_decision_grade_proof_from_summary(run_summary_v2 if isinstance(run_summary_v2, Mapping) else None)
    stamp_lines = governance_stamp_lines(
        decision_mode=decision_mode,
        interpretation=interpretation,
        decision_grade_proof=proof if isinstance(proof, Mapping) else None,
    )
    stamp = limitations_stamp()
    outcomes = [o.to_dict() for o in run.outcomes]
    sequence = run.sequence if include_sequence else None
    genome_entry = {
        "id": getattr(run, "genome_id", None) or run.target_locus or "target",
        "sequence": sequence,
        "sequence_hash": _sha256_bytes(run.sequence.encode("utf-8")) if run.sequence else None,
        "length": len(run.sequence) if run.sequence else None,
        "include_sequence": bool(include_sequence),
    }

    preset_block = preset or {}
    is_demo = bool(is_demo_from_metadata(meta) or is_demo_from_preset(preset_block))
    gov_prov = build_governance_provenance(
        decision_mode=decision_mode,
        is_demo=is_demo,
        interpretation=interpretation,
        decision_grade_proof=(dict(proof) if isinstance(proof, Mapping) else None),
    )
    prov_header, prov_block = build_provenance_header_v1(decision_mode=decision_mode, run_summary_v2=run_summary_v2)
    evidence = {
        "schema": "helix_run_evidence_v1",
        "evidence_id": f"helix-run-{token_hex(16)}",
        "helix_version": helix_version,
        "generated_at": _utc_now_iso(),
        "include_sequence": bool(include_sequence),
        "decision_mode_requested": decision_mode_requested,
        "decision_mode_eligible": bool(decision_mode_eligible),
        "decision_mode": decision_mode,
        "outcome_value_label": outcome_value_label,
        "interpretation": interpretation,
        "provenance_header": prov_header,
        "provenance_block": prov_block,
        "decision_grade_proof": (dict(proof) if isinstance(proof, Mapping) else None),
        "governance": {
            "is_demo": bool(is_demo),
            "watermark": str(gov_prov.get("watermark") or ""),
            "stamp_lines": list(stamp_lines),
            "decision_grade_proof": (dict(proof) if isinstance(proof, Mapping) else None),
        },
        "limitations": stamp,
        "run": {
            "run_id": run.run_id,
            "run_label": getattr(run, "run_label", None) or getattr(run, "guide_id", "run"),
            "kind": getattr(run, "edit_type", ""),
            "guide_id": getattr(run, "guide_id", None),
            "target_locus": getattr(run, "target_locus", None),
            "outcomes": len(outcomes),
            "preset_id": preset_block.get("id"),
            "backend": run.engine.backend if run.engine else None,
            "scoring_versions": {
                "crispr": getattr(run.engine, "crispr_scoring_version", None),
                "prime": getattr(run.engine, "prime_scoring_version", None),
            },
        },
        "genome": genome_entry,
        "outcomes": outcomes,
        "preset": preset_block if preset_block else None,
        "physics": run.physics,
        "run_artifact": artifact,
        "run_summary_v2": run_summary_v2,
    }
    checksums = {"payload_sha256": _sha256_json({k: v for k, v in evidence.items() if k != "checksums"})}
    snap_for_hash = snapshot if snapshot is not None else (run_or_snapshot if isinstance(run_or_snapshot, Mapping) else None)
    if snap_for_hash is not None:
        snap_hash = _sha256_json(snap_for_hash)
        checksums["snapshot_sha256"] = snap_hash
        evidence["snapshot_sha256"] = snap_hash
    evidence["checksums"] = checksums
    return evidence


def write_evidence_json(evidence: Mapping[str, Any], path: Path, *, governance_signing: bool = False) -> None:
    from helix.governance.gates import require_decision_grade_signing

    run_block = evidence.get("run") if isinstance(evidence.get("run"), Mapping) else {}
    require_decision_grade_signing(
        decision_mode=evidence.get("decision_mode"),
        governance_signing=bool(governance_signing),
        run_id=str(run_block.get("run_id") or ""),
        surface="run_evidence_json",
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(evidence, indent=2), encoding="utf-8")
