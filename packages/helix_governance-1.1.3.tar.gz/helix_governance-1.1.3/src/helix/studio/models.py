from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Mapping, Sequence
from copy import deepcopy


@dataclass
class EngineInfo:
    name: str  # e.g., "helix_cuda"
    backend: str  # "gpu" | "native-cpu" | "cpu-reference"
    crispr_scoring_version: str | None = None
    prime_scoring_version: str | None = None
    backend_reason: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "EngineInfo":
        return cls(
            name=raw.get("name", "helix_cuda"),
            backend=raw.get("backend", "gpu"),
            crispr_scoring_version=raw.get("crispr_scoring_version"),
            prime_scoring_version=raw.get("prime_scoring_version"),
            backend_reason=raw.get("backend_reason"),
        )


@dataclass
class OutcomeModel:
    name: str
    category: str
    prob: float
    delta_bp: int | None = None
    peak_position: int | None = None
    position_min: int | None = None
    position_max: int | None = None
    frameshift: bool | None = None
    microhomology: int | None = None
    physics: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "OutcomeModel":
        return cls(
            name=raw.get("name", raw.get("label", "")),
            category=raw.get("category", raw.get("diff", {}).get("kind", "")),
            prob=float(raw.get("prob", raw.get("probability", 0.0))),
            delta_bp=raw.get("delta_bp"),
            peak_position=raw.get("peak_position"),
            position_min=raw.get("position_min"),
            position_max=raw.get("position_max"),
            frameshift=raw.get("frameshift"),
            microhomology=raw.get("microhomology"),
            physics=dict(raw.get("physics", {}) or {}),
        )


@dataclass
class RunModel:
    run_id: str
    guide_id: str
    edit_type: str
    sequence: str
    target_locus: str
    pam_index: int | None
    cut_index: int | None
    outcomes: list[OutcomeModel]
    physics: dict[str, Any]
    engine: EngineInfo
    metadata: dict[str, Any] | None = None
    parent_run_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "guide_id": self.guide_id,
            "edit_type": self.edit_type,
            "sequence": self.sequence,
            "target_locus": self.target_locus,
            "pam_index": self.pam_index,
            "cut_index": self.cut_index,
            "outcomes": [o.to_dict() for o in self.outcomes],
            "physics": self.physics,
            "engine": self.engine.to_dict(),
            "metadata": self.metadata or {},
            "parent_run_id": self.parent_run_id,
        }

    def clone(self, new_run_id: str | None = None) -> "RunModel":
        """Shallow clone carrying metadata; caller can override run_id."""
        data = deepcopy(self.to_dict())
        if new_run_id is not None:
            data["run_id"] = new_run_id
        data["parent_run_id"] = self.run_id
        return RunModel.from_dict(data)

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "RunModel":
        engine_raw = raw.get("engine", {}) or {}
        engine = EngineInfo.from_dict(engine_raw)
        outcomes = [OutcomeModel.from_dict(o) for o in (raw.get("outcomes") or [])]
        return cls(
            run_id=str(raw.get("run_id", "")),
            guide_id=str(raw.get("guide_id", "")),
            edit_type=str(raw.get("edit_type", "")),
            sequence=str(raw.get("sequence", "")),
            target_locus=str(raw.get("target_locus", "")),
            pam_index=raw.get("pam_index"),
            cut_index=raw.get("cut_index"),
            outcomes=outcomes,
            physics=dict(raw.get("physics", {}) or {}),
            engine=engine,
            metadata=dict(raw.get("metadata", {}) or {}),
            parent_run_id=raw.get("parent_run_id"),
        )
