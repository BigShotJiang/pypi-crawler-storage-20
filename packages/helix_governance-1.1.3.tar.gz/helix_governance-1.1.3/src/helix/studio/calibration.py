from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping, Sequence

from helix.studio.outcomes.clone_yield import build_clone_plan
from helix.studio.outcomes.hotspots import allele_key_from_entry
from helix.studio.experiment_spec import experiment_spec_to_dict

CALIBRATION_PROFILE_SCHEMA_ID = "helix_calibration_profile_v1"
CALIBRATION_PREVIEW_SCHEMA_ID = "helix_calibration_preview_v1"
CALIBRATION_PROFILES_CAP = 20
CALIBRATION_PREVIEWS_CAP = 20

DEFAULT_SAMPLE_POLICY = {
    "defaultN": 50,
    "assayOverrides": {"AmpliconSeq": 200, "Sanger": 20},
    "caps": {"maxN": 1000},
}

PRIME_CATEGORIES = (
    "desired_edit",
    "partial_edit",
    "rt_template_truncation",
    "nick_indels",
    "pegRNA_failure",
)


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (
        json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n"
    ).encode("utf-8")


def calibration_profile_json_bytes(profile: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(profile))


def calibration_profile_sha256(profile: Mapping[str, Any]) -> str:
    return hashlib.sha256(calibration_profile_json_bytes(profile)).hexdigest()


def calibration_preview_json_bytes(preview: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(preview))


def calibration_preview_sha256(preview: Mapping[str, Any]) -> str:
    return hashlib.sha256(calibration_preview_json_bytes(preview)).hexdigest()


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _round_prob(value: float, *, digits: int = 6) -> float:
    return round(float(value), digits)


def _normalize_text(value: Any) -> str:
    return str(value or "").strip()


def _infer_modality(
    outcome_report: Mapping[str, Any] | None,
    experiment_spec: Mapping[str, Any] | None,
    results_records: Sequence[Mapping[str, Any]] | None,
) -> str:
    spec = experiment_spec_to_dict(experiment_spec)
    intent = str(spec.get("intent") or "").strip().lower()
    modalities = spec.get("editModalities") if isinstance(spec.get("editModalities"), list) else []
    modality = "prime" if intent == "prime_edit" or "prime" in str(modalities).lower() else "cut"
    if outcome_report and isinstance(outcome_report.get("primeOutcomes"), list):
        modality = "prime"
    if results_records:
        modes = {
            str(rec.get("modality") or "").strip().lower()
            for rec in results_records
            if isinstance(rec, Mapping)
        }
        modes.discard("")
        if len(modes) == 1:
            modality = modes.pop()
    if modality not in {"cut", "prime"}:
        modality = "cut"
    return modality


def _effective_sample_size(record: Mapping[str, Any], policy: Mapping[str, Any]) -> int:
    caps = policy.get("caps") if isinstance(policy.get("caps"), Mapping) else {}
    max_n = int(_safe_float(caps.get("maxN"), 1000)) if isinstance(caps, Mapping) else 1000
    if max_n <= 0:
        max_n = 1000

    assay_meta = record.get("assayMetadata") if isinstance(record.get("assayMetadata"), Mapping) else {}
    read_depth = assay_meta.get("readDepth") if isinstance(assay_meta, Mapping) else None
    if read_depth is not None:
        n = int(round(_safe_float(read_depth, 0.0)))
        n = max(1, min(n, max_n))
        return n

    assay_type = _normalize_text(assay_meta.get("assayType")) if isinstance(assay_meta, Mapping) else ""
    overrides = policy.get("assayOverrides") if isinstance(policy.get("assayOverrides"), Mapping) else {}
    if assay_type in overrides:
        n = int(round(_safe_float(overrides.get(assay_type), 0.0)))
    else:
        n = int(round(_safe_float(policy.get("defaultN"), 50.0)))
    if n <= 0:
        n = 1
    return max(1, min(n, max_n))


def _desired_frequency_from_report(report_payload: Mapping[str, Any]) -> float:
    try:
        clone_plan = build_clone_plan(report_payload)
        desired = _safe_float(clone_plan.get("desiredFrequency"), 0.0)
    except Exception:
        desired = 0.0
    if desired <= 0.0:
        prime_outcomes = report_payload.get("primeOutcomes") if isinstance(report_payload.get("primeOutcomes"), list) else []
        for entry in prime_outcomes:
            if not isinstance(entry, Mapping):
                continue
            if str(entry.get("category") or "") == "desired_edit":
                desired = _safe_float(entry.get("probability"), 0.0)
                break
    return max(0.0, min(1.0, desired))


def _prime_prior_map(report_payload: Mapping[str, Any]) -> dict[str, float]:
    prime_outcomes = report_payload.get("primeOutcomes") if isinstance(report_payload.get("primeOutcomes"), list) else []
    priors: dict[str, float] = {}
    for entry in prime_outcomes:
        if not isinstance(entry, Mapping):
            continue
        cat = str(entry.get("category") or "").strip()
        if not cat:
            continue
        priors[cat] = max(0.0, _safe_float(entry.get("probability"), 0.0))
    if not priors:
        priors = {cat: 1.0 for cat in PRIME_CATEGORIES}
    total = sum(priors.values())
    if total <= 0:
        total = 1.0
    return {cat: priors.get(cat, 0.0) / total for cat in PRIME_CATEGORIES}


def build_calibration_profile_and_preview(
    results_records: Sequence[Mapping[str, Any]] | None,
    outcome_report_payload: Mapping[str, Any] | None,
    experiment_spec: Mapping[str, Any] | None = None,
    *,
    sample_policy: Mapping[str, Any] | None = None,
    prior_strength: int = 20,
) -> tuple[dict[str, Any], dict[str, Any]]:
    policy = dict(sample_policy or DEFAULT_SAMPLE_POLICY)
    report_payload = dict(outcome_report_payload or {})
    modality = _infer_modality(report_payload, experiment_spec, results_records)
    p_pred = _desired_frequency_from_report(report_payload)

    included_ids: list[str] = []
    skipped: list[dict[str, str]] = []
    total_n = 0
    total_k = 0

    ordered_records: list[Mapping[str, Any]] = []
    if results_records:
        ordered_records = sorted(
            [r for r in results_records if isinstance(r, Mapping)],
            key=lambda r: str(r.get("resultsId") or ""),
        )

    for record in ordered_records:
        results_id = _normalize_text(record.get("resultsId"))
        if not results_id:
            skipped.append({"resultsId": "", "reason": "missing resultsId"})
            continue
        record_modality = _normalize_text(record.get("modality")).lower()
        if record_modality and record_modality != modality:
            skipped.append({"resultsId": results_id, "reason": "modality mismatch"})
            continue
        primary = record.get("primaryTarget") if isinstance(record.get("primaryTarget"), Mapping) else {}
        p_obs = primary.get("observedDesiredFrequency") if isinstance(primary, Mapping) else None
        if p_obs is None:
            skipped.append({"resultsId": results_id, "reason": "missing observedDesiredFrequency"})
            continue
        try:
            p_obs_val = float(p_obs)
        except Exception:
            skipped.append({"resultsId": results_id, "reason": "invalid observedDesiredFrequency"})
            continue
        p_obs_val = max(0.0, min(1.0, p_obs_val))
        n_eff = _effective_sample_size(record, policy)
        k = int(round(p_obs_val * n_eff))
        total_n += n_eff
        total_k += k
        included_ids.append(results_id)

    n0 = max(1, int(prior_strength))
    k0 = int(round(p_pred * n0))
    alpha0 = 1 + k0
    beta0 = 1 + (n0 - k0)

    alpha = alpha0 + total_k
    beta = beta0 + (total_n - total_k)

    p_obs_agg = (total_k / total_n) if total_n > 0 else None
    p_cal = alpha / (alpha + beta)

    parameters: dict[str, Any] = {}
    if modality == "prime":
        priors = _prime_prior_map(report_payload)
        alpha_map = {cat: 1.0 + priors.get(cat, 0.0) * n0 for cat in PRIME_CATEGORIES}
        if total_n > 0:
            desired_prior = priors.get("desired_edit", 0.0)
            denom = max(1e-9, 1.0 - desired_prior)
            remaining = total_n - total_k
            alpha_map["desired_edit"] += float(total_k)
            for cat in PRIME_CATEGORIES:
                if cat == "desired_edit":
                    continue
                share = priors.get(cat, 0.0) / denom
                alpha_map[cat] += remaining * share
        alpha_map = {k: _round_prob(v, digits=6) for k, v in alpha_map.items()}
        parameters["dirichletAlpha"] = alpha_map
    else:
        parameters["desiredPosteriorAlpha"] = int(alpha)
        parameters["desiredPosteriorBeta"] = int(beta)

    notes: list[str] = []
    notes.append(f"Used prior strength N0={n0}.")
    notes.append(f"Included {len(included_ids)} result record(s).")
    for entry in skipped:
        rid = entry.get("resultsId") or "(unknown)"
        notes.append(f"Skipped {rid}: {entry.get('reason')}")

    scope: dict[str, Any] = {"modality": modality}
    if included_ids:
        for key, field in (("cellLine", "cellLine"), ("delivery", "delivery"), ("nuclease", "nuclease")):
            values = {
                _normalize_text(rec.get("conditions", {}).get(field))
                for rec in ordered_records
                if isinstance(rec.get("conditions"), Mapping) and _normalize_text(rec.get("resultsId")) in included_ids
            }
            values.discard("")
            if len(values) == 1:
                scope[key] = values.pop()

    profile_payload = {
        "schema": CALIBRATION_PROFILE_SCHEMA_ID,
        "profileId": "",
        "scope": scope,
        "sourceResults": list(included_ids),
        "effectiveSampleSizePolicy": policy,
        "parameters": parameters,
        "notes": notes,
    }

    # Compute profileId from canonical bytes without the profileId field populated.
    profile_id = hashlib.sha256(_canonical_json_bytes(dict(profile_payload))).hexdigest()
    profile_payload["profileId"] = profile_id

    preview_payload = {
        "schema": CALIBRATION_PREVIEW_SCHEMA_ID,
        "profileId": profile_id,
        "modality": modality,
        "pPred": _round_prob(p_pred, digits=6),
        "pObs": _round_prob(p_obs_agg, digits=6) if p_obs_agg is not None else None,
        "pCal": _round_prob(p_cal, digits=6),
        "delta": _round_prob(p_cal - p_pred, digits=6),
        "includedResults": list(included_ids),
        "skippedResults": skipped,
    }

    return profile_payload, preview_payload


def attach_calibration_profile(
    session: Any,
    profile: Mapping[str, Any],
    preview: Mapping[str, Any] | None = None,
    *,
    cap: int = CALIBRATION_PROFILES_CAP,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    profiles = list(getattr(session.state, "calibration_profiles", []) or []) if session is not None else []
    previews = list(getattr(session.state, "calibration_previews", []) or []) if session is not None else []

    profile_id = str(profile.get("profileId") or "")
    profiles = [p for p in profiles if str(p.get("profileId") or "") != profile_id]
    profiles.append(dict(profile))
    if cap > 0 and len(profiles) > cap:
        profiles = profiles[-cap:]

    if preview is not None:
        previews = [p for p in previews if str(p.get("profileId") or "") != profile_id]
        previews.append(dict(preview))
        if cap > 0 and len(previews) > cap:
            previews = previews[-cap:]

    if session is not None:
        session.update(calibration_profiles=profiles, calibration_previews=previews)

    return profiles, previews


def apply_calibration_to_report(
    report_payload: Mapping[str, Any],
    profile: Mapping[str, Any],
) -> dict[str, Any]:
    payload = json.loads(json.dumps(report_payload))
    modality = str(profile.get("scope", {}).get("modality") or "cut").strip().lower()
    p_cal = None
    if modality == "prime":
        alpha_map = profile.get("parameters", {}).get("dirichletAlpha") if isinstance(profile.get("parameters"), Mapping) else None
        if isinstance(alpha_map, Mapping):
            total = sum(_safe_float(v, 0.0) for v in alpha_map.values())
            desired = _safe_float(alpha_map.get("desired_edit"), 0.0)
            if total > 0:
                p_cal = desired / total
    else:
        alpha = _safe_float(profile.get("parameters", {}).get("desiredPosteriorAlpha"), 0.0)
        beta = _safe_float(profile.get("parameters", {}).get("desiredPosteriorBeta"), 0.0)
        if alpha + beta > 0:
            p_cal = alpha / (alpha + beta)

    if p_cal is None:
        return payload

    p_cal = max(0.0, min(1.0, p_cal))

    allele_spectrum = payload.get("alleleSpectrum") if isinstance(payload.get("alleleSpectrum"), list) else []
    desired_key = None
    try:
        clone_plan = build_clone_plan(payload)
        desired_key = str(clone_plan.get("desiredAlleleKey") or "") or None
        p_pred = _safe_float(clone_plan.get("desiredFrequency"), 0.0)
    except Exception:
        p_pred = 0.0
        desired_key = None

    if allele_spectrum and desired_key is not None:
        entries = [e for e in allele_spectrum if isinstance(e, Mapping)]
        desired_idx = None
        for idx, entry in enumerate(entries):
            try:
                if allele_key_from_entry(entry) == desired_key:
                    desired_idx = idx
                    break
            except Exception:
                continue

        if desired_idx is not None:
            scale = 0.0
            if p_pred < 1.0:
                scale = (1.0 - p_cal) / max(1e-12, 1.0 - p_pred)
            new_entries: list[dict[str, Any]] = []
            for idx, entry in enumerate(entries):
                freq = _safe_float(entry.get("frequency"), 0.0)
                new_entry = dict(entry)
                if idx == desired_idx:
                    new_entry["frequency"] = _round_prob(p_cal, digits=8)
                else:
                    new_entry["frequency"] = _round_prob(freq * scale, digits=8)
                new_entries.append(new_entry)
            remainder = 1.0 - sum(_safe_float(e.get("frequency"), 0.0) for e in new_entries)
            if new_entries and remainder != 0.0:
                adjust_idx = len(new_entries) - 1
                if adjust_idx == desired_idx and len(new_entries) > 1:
                    adjust_idx -= 1
                new_entries[adjust_idx]["frequency"] = _round_prob(
                    _safe_float(new_entries[adjust_idx].get("frequency"), 0.0) + remainder, digits=8
                )
            payload["alleleSpectrum"] = new_entries

    prime_outcomes = payload.get("primeOutcomes") if isinstance(payload.get("primeOutcomes"), list) else None
    if isinstance(prime_outcomes, list) and prime_outcomes:
        desired_idx = None
        p_pred_prime = 0.0
        entries: list[dict[str, Any]] = []
        for idx, entry in enumerate(prime_outcomes):
            if not isinstance(entry, Mapping):
                continue
            entry_dict = dict(entry)
            if str(entry_dict.get("category") or "") == "desired_edit":
                desired_idx = idx
                p_pred_prime = _safe_float(entry_dict.get("probability"), 0.0)
            entries.append(entry_dict)

        if desired_idx is not None:
            scale = 0.0
            if p_pred_prime < 1.0:
                scale = (1.0 - p_cal) / max(1e-12, 1.0 - p_pred_prime)
            for idx, entry in enumerate(entries):
                prob = _safe_float(entry.get("probability"), 0.0)
                if idx == desired_idx:
                    entry["probability"] = _round_prob(p_cal, digits=6)
                else:
                    entry["probability"] = _round_prob(prob * scale, digits=6)
            remainder = 1.0 - sum(_safe_float(e.get("probability"), 0.0) for e in entries)
            if entries and remainder != 0.0:
                adjust_idx = len(entries) - 1
                if adjust_idx == desired_idx and len(entries) > 1:
                    adjust_idx -= 1
                entries[adjust_idx]["probability"] = _round_prob(
                    _safe_float(entries[adjust_idx].get("probability"), 0.0) + remainder, digits=6
                )
            payload["primeOutcomes"] = entries

    payload["calibrationApplied"] = True
    payload["calibrationProfileId"] = str(profile.get("profileId") or "")
    return payload


__all__ = [
    "CALIBRATION_PROFILE_SCHEMA_ID",
    "CALIBRATION_PREVIEW_SCHEMA_ID",
    "CALIBRATION_PROFILES_CAP",
    "CALIBRATION_PREVIEWS_CAP",
    "calibration_profile_json_bytes",
    "calibration_profile_sha256",
    "calibration_preview_json_bytes",
    "calibration_preview_sha256",
    "build_calibration_profile_and_preview",
    "attach_calibration_profile",
    "apply_calibration_to_report",
]
