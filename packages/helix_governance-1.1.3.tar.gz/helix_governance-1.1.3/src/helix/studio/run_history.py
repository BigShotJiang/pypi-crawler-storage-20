from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Mapping, List

from helix import clock
from PySide6.QtCore import Qt, QTimer, Signal, QModelIndex
from PySide6.QtGui import QKeySequence, QShortcut, QKeyEvent, QColor, QBrush
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLineEdit,
    QFileDialog,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QAbstractItemView,
    QVBoxLayout,
    QWidget,
    QComboBox,
    QCheckBox,
    QLabel,
    QInputDialog,
    QMenu,
)

from .session import RunKind, SessionModel
from .ui_dispatcher import assert_ui_thread
from .run_metrics import (
    build_report,
    render_markdown_report,
    summarize_snapshot,
    ensure_state_payload,
    compute_run_metrics,
    format_snapshot_text,
)
from .workers import run_bg, CancelToken
from .ui_tokens import base_font, MARGIN_PANEL, SPACING_MEDIUM, SPACING_SMALL
from .models import RunModel
from .export_run import export_run_artifacts, run_model_from_snapshot
from .export_gate import build_export_context
from .ui.export_gate import ensure_export_allowed


class RunHistoryWidget(QWidget):
    runActivated = Signal(str)
    baselineSelected = Signal(object)
    candidateSelected = Signal(object)
    baselineSelected = Signal(str)
    candidateSelected = Signal(str)

    def __init__(
        self,
        session: SessionModel,
        parent: QWidget | None = None,
        *,
        on_compare: Callable[[Mapping[str, Any], Mapping[str, Any]], None] | None = None,
        on_activate: Callable[[Mapping[str, Any]], None] | None = None,
    ) -> None:
        super().__init__(parent)
        self.setFont(base_font())
        self._session = session
        self._on_compare = on_compare
        self._on_activate = on_activate
        self._export_prompt_suppressed_by_key: dict[str, bool] = {}
        self._filter_timer = QTimer(self)
        self._filter_timer.setSingleShot(True)
        self._filter_timer.setInterval(120)
        self._filter_timer.timeout.connect(self._apply_filters)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        layout.setSpacing(SPACING_SMALL)

        filter_row = QHBoxLayout()
        filter_row.setSpacing(SPACING_SMALL)
        filter_row.addWidget(QLabel("Run kind:", self))
        self._kind_filter = QComboBox(self)
        self._kind_filter.addItem("All", userData="ALL")
        for kind in RunKind:
            if kind == RunKind.NONE:
                continue
            self._kind_filter.addItem(kind.name.title(), userData=kind.name)
        self._kind_filter.currentIndexChanged.connect(self._apply_filters)
        filter_row.addWidget(self._kind_filter)

        filter_row.addWidget(QLabel("Genome contains:", self))
        self._search_box = QLineEdit(self)
        self._search_box.setPlaceholderText("e.g. chr19, demo...")
        self._search_box.textChanged.connect(lambda *_: self._filter_timer.start())
        filter_row.addWidget(self._search_box)

        self._intended_only = QCheckBox("Has intended", self)
        self._intended_only.stateChanged.connect(self._apply_filters)
        filter_row.addWidget(self._intended_only)

        filter_row.addWidget(QLabel("Profile:", self))
        self._profile_filter = QComboBox(self)
        self._profile_filter.addItem("All runs", userData=None)
        self._profile_filter.currentIndexChanged.connect(self._apply_filters)
        filter_row.addWidget(self._profile_filter)

        filter_row.addWidget(QLabel("Mode:", self))
        self._mode_filter = QComboBox(self)
        self._mode_filter.addItem("All", userData="ALL")
        self._mode_filter.addItem("Window", userData="window")
        self._mode_filter.addItem("Whole genome", userData="whole")
        self._mode_filter.currentIndexChanged.connect(self._apply_filters)
        filter_row.addWidget(self._mode_filter)
        filter_row.addStretch(1)
        layout.addLayout(filter_row)

        self._table_widget = QTableWidget(self)
        self._table_widget.setObjectName("RunHistoryTable")
        self._table_widget.setColumnCount(8)
        self._table_widget.setHorizontalHeaderLabels(["#", "Label", "Kind", "Intended %", "Frameshift %", "Outcomes", "Preset", "When"])
        self._table_widget.verticalHeader().setVisible(False)
        self._table_widget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self._table_widget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self._table_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._table_widget.itemDoubleClicked.connect(lambda item: self._on_item_activated(item))
        self._table_widget.setContextMenuPolicy(Qt.CustomContextMenu)
        self._table_widget.customContextMenuRequested.connect(self._on_context_menu)
        self._table_widget.itemSelectionChanged.connect(self._on_selection_changed)
        layout.addWidget(self._table_widget, stretch=1)
        # legacy compat for tests that expect `_table`
        self._table = self._table_widget

        btn_row = QHBoxLayout()
        btn_row.setSpacing(SPACING_SMALL)
        self._restore_btn = QPushButton("Restore Selected", self)
        self._restore_btn.clicked.connect(self._restore_selected)
        btn_row.addWidget(self._restore_btn)

        self._pin_btn = QPushButton("Pin", self)
        self._pin_btn.clicked.connect(self._toggle_pin)
        btn_row.addWidget(self._pin_btn)

        self._compare_btn = QPushButton("Compare…", self)
        self._compare_btn.clicked.connect(self._compare_selected)
        btn_row.addWidget(self._compare_btn)

        self._report_btn = QPushButton("Export Report…", self)
        self._report_btn.clicked.connect(self._export_report)
        btn_row.addWidget(self._report_btn)

        self._label_btn = QPushButton("Set Label…", self)
        self._label_btn.clicked.connect(self._set_label)
        btn_row.addWidget(self._label_btn)

        self._export_btn = QPushButton("Export (JSON+PNG)…", self)
        self._export_btn.clicked.connect(self._export_cli_parity)
        btn_row.addWidget(self._export_btn)

        btn_row.addStretch(1)
        layout.addLayout(btn_row)

        hint = QLabel("Search Ctrl+F · Intended Ctrl+Shift+I · Cycle Ctrl+Shift+K · Clear Ctrl+Shift+F", self)
        hint.setStyleSheet("color: palette(mid); font-size: 11px;")
        layout.addWidget(hint)

        self._snapshots: list[dict[str, Any]] = []
        self._pinned: set[int] = set()
        self._session.runRecorded.connect(self._add_entry)
        self._row_map: list[int] = []
        self._populate_tree()
        self._refresh_profiles()
        self._update_buttons()
        self._setup_shortcuts()
        self._announce_filter_state()
        self._export_token = CancelToken()
        self._last_emitted_run_id: str | None = None

    def _on_selection_changed(self) -> None:
        self._update_buttons()
        # Auto-emit activation for single selection to keep Lightcone in sync.
        rows = self._table_widget.selectionModel().selectedRows()
        if len(rows) != 1:
            return
        row = rows[0].row()
        run_id = self._row_to_run_id(row)
        if run_id and run_id != self._last_emitted_run_id:
            self._last_emitted_run_id = run_id
            self.runActivated.emit(run_id)

    def _inject_defaults(self, snapshot: dict[str, Any]) -> None:
        state = snapshot.get("state", {}) if isinstance(snapshot, Mapping) else {}
        meta = state.setdefault("config", {}).setdefault("metadata", {}) if isinstance(state.get("config"), Mapping) else {}
        # run label default
        if not state.get("run_label"):
            preset = meta.get("preset_id") if isinstance(meta, Mapping) else None
            if preset:
                label = f"{meta.get('preset_label', preset)}"
            else:
                label = meta.get("label") or state.get("run_kind") or "run"
            state["run_label"] = label
        run_label = state.get("run_label")
        # created_at default
        if "timestamp" not in snapshot and "created_at" not in state:
            snapshot["timestamp"] = clock.utc_now_iso()
        if "created_at" not in state:
            state["created_at"] = snapshot.get("timestamp")
        # outcomes count cache
        if "outcomes_count" not in state:
            state["outcomes_count"] = len(state.get("outcomes", []))
        # run summary snapshot for downstream UI / exports
        try:
            run_summary_brief = {
                "run_id": state.get("run_id"),
                "run_label": run_label,
                "kind": str(state.get("run_kind", "")) if state.get("run_kind") else meta.get("run_kind"),
                "created_at": state.get("created_at"),
                "guide_id": state.get("config", {}).get("guide", {}).get("id") if isinstance(state.get("config"), Mapping) else None,
                "intended_prob": float(self._intended_prob(snapshot)),
                "frameshift_rate": float(self._frameshift_prob(snapshot)),
                "outcomes": state.get("outcomes_count"),
                "preset_id": meta.get("preset_id"),
            }
            meta["run_summary_brief"] = run_summary_brief
        except Exception:
            pass
        try:
            from helix.studio.summary_contract_v2 import build_run_summary_v2_from_snapshot

            meta["run_summary"] = build_run_summary_v2_from_snapshot(snapshot, off_target_mode="policy")
        except Exception:
            pass
        # attach back
        snapshot["state"] = state

        # Compatibility shims for tests expecting _cap / _apply_filters
        class _CapShim:
            def __init__(self, outer: "RunHistoryWidget") -> None:
                self.outer = outer

            def rowCount(self) -> int:
                return outer._table_widget.rowCount()

            def index(self, row: int, col: int):
                class _Idx:
                    def __init__(self, item, col) -> None:
                        self.item = item
                        self.col = col

                    def data(self):
                        if self.item is None:
                            return None
                        return self.item.text()

                item = outer._table_widget.item(row, col)
                return _Idx(item, col)

        outer = self
        self._cap = _CapShim(self)

        class _TableShim:
            def __init__(self, outer: "RunHistoryWidget") -> None:
                self.outer = outer

            def selectRow(self, row: int) -> None:
                if 0 <= row < self.outer._table_widget.rowCount():
                    self.outer._table_widget.selectRow(row)
                    if self.outer._table_widget.currentItem() is None:
                        self.outer._table_widget.setCurrentCell(row, 0)

        self._table_shim = _TableShim(self)

    def _add_entry(self, payload: Mapping[str, Any]) -> None:
        assert_ui_thread()
        snapshot = dict(payload)
        self._inject_defaults(snapshot)
        self._snapshots.append(snapshot)
        self._prune_if_needed()
        self._populate_tree(keep_selection=True)
        self._refresh_profiles()

    # Public hook for imported runs (already normalized to snapshot-ish dict)
    def add_imported_snapshot(self, snapshot: Mapping[str, Any]) -> None:
        self._add_entry(snapshot)

    def _populate_tree(self, keep_selection: bool = False) -> None:
        previous_index = self._current_index() if keep_selection else None
        self._table_widget.setUpdatesEnabled(False)
        self._table_widget.setSortingEnabled(False)
        self._table_widget.blockSignals(True)
        self._table_widget.setRowCount(0)
        self._row_map = []
        for idx, snapshot in enumerate(self._snapshots):
            metrics = compute_run_metrics(snapshot)
            summary = metrics.summary
            if not self._matches_filters(summary, idx):
                continue
            label = summary["label"]
            # search mode badge
            try:
                cfg = snapshot.get("config", {}) if isinstance(snapshot, dict) else {}
                genome_cfg = cfg.get("genome", {}) if isinstance(cfg, dict) else {}
                mode = (genome_cfg.get("search_mode") or "window").lower()
                gid = genome_cfg.get("genome_id") or "?"
                if mode == "whole":
                    label = f"[WHOLE GENOME {gid}] " + label
                else:
                    label = f"[WINDOW {gid}] " + label
            except Exception:
                pass
            if snapshot.get("imported"):
                origin = snapshot.get("import_origin", "imported")
                label = f"[import: {origin}] {label or origin}"
            preset_id = self._preset_id(snapshot)
            if preset_id:
                label = "[DEMO] " + label
            try:
                label = f"[{self._mode_label_for_snapshot(snapshot)}] {label}"
            except Exception:
                label = f"[EXPLORATORY] {label}"
            if idx in self._pinned:
                label = f"[PINNED] {label}"
            intended = f"{self._intended_prob(snapshot)*100:.1f}%"
            frameshift = f"{self._frameshift_prob(snapshot)*100:.1f}%"
            when = self._relative_timestamp(summary.get("timestamp"))
            row = self._table_widget.rowCount()
            self._table_widget.insertRow(row)
            self._row_map.append(idx)
            values = [
                str(idx + 1),
                label,
                summary["run_kind"],
                intended,
                frameshift,
                summary["outcomes"],
                preset_id or "",
                when,
            ]
            for col, val in enumerate(values):
                item = QTableWidgetItem(val)
                if col == 0:
                    item.setData(Qt.UserRole, idx)
                if col in (0, 3, 4, 5):
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                elif col == 2:
                    item.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
                self._table_widget.setItem(row, col, item)
            tooltip = format_snapshot_text(metrics)
            if metrics.is_pcr:
                pcr_lines = [
                    "PCR run",
                    f"Amplicon: {metrics.pcr_amplicon_length} bp",
                ]
                if (
                    metrics.pcr_amplicon_start is not None
                    and metrics.pcr_amplicon_end is not None
                    and metrics.pcr_amplicon_end > metrics.pcr_amplicon_start
                ):
                    pcr_lines.append(f"Region: {metrics.pcr_amplicon_start}–{metrics.pcr_amplicon_end}")
                if metrics.pcr_cycles:
                    pcr_lines.append(f"Cycles: {metrics.pcr_cycles}")
                if metrics.pcr_forward_primer:
                    pcr_lines.append(f"Forward primer: {metrics.pcr_forward_primer}")
                if metrics.pcr_reverse_primer:
                    pcr_lines.append(f"Reverse primer: {metrics.pcr_reverse_primer}")
                if metrics.pcr_final_mass_ng is not None:
                    pcr_lines.append(f"Final mass: {metrics.pcr_final_mass_ng:.2f} ng")
                if metrics.pcr_final_mutation_rate is not None:
                    pcr_lines.append(f"Mutation rate: {metrics.pcr_final_mutation_rate:.4f}")
                tooltip = tooltip + "\n\n" + "\n".join(pcr_lines)
            for col in range(self._table_widget.columnCount()):
                item = self._table_widget.item(row, col)
                if item:
                    item.setToolTip(tooltip)
            if previous_index is not None and previous_index == idx:
                self._table_widget.selectRow(row)
            if idx == len(self._snapshots) - 1:
                for col in range(self._table_widget.columnCount()):
                    item = self._table_widget.item(row, col)
                    if item:
                        item.setBackground(QBrush(QColor(34, 197, 235, 30)))
        self._table_widget.blockSignals(False)
        self._table_widget.setSortingEnabled(False)
        self._table_widget.setUpdatesEnabled(True)
        self._table_widget.viewport().update()
        self._update_buttons()

    def _matches_filters(self, summary: Mapping[str, Any], idx: int) -> bool:
        if idx in self._pinned:
            return True
        kind_filter = self._kind_filter.currentData()
        if kind_filter and kind_filter != "ALL" and summary["run_kind_key"] != kind_filter:
            return False
        if self._intended_only.isChecked() and not summary.get("has_intended"):
            return False
        profile_key = self._profile_filter.currentData()
        if profile_key and summary.get("profile_key") != profile_key:
            return False
        query = self._search_box.text().strip().lower()
        if query:
            haystack = f"{summary['genome']} {summary['guide']} {summary['label']}".lower()
            if query not in haystack:
                return False
        mode_filter = self._mode_filter.currentData()
        if mode_filter and mode_filter != "ALL":
            snap = self._snapshots[idx]
            try:
                cfg = snap.get("config", {}) if isinstance(snap, dict) else {}
                genome_cfg = cfg.get("genome", {}) if isinstance(cfg, dict) else {}
                mode = (genome_cfg.get("search_mode") or "window").lower()
                if mode != mode_filter:
                    return False
            except Exception:
                return False
        return True

    def _prune_if_needed(self, max_rows: int = 1000) -> None:
        if len(self._snapshots) <= max_rows:
            return
        # Keep pinned; drop oldest non-pinned first.
        survivors: list[dict[str, Any]] = []
        for idx, snap in enumerate(self._snapshots):
            if idx in self._pinned:
                survivors.append(snap)
            elif len(self._snapshots) - len(survivors) <= max_rows:
                survivors.append(snap)
        self._snapshots = survivors[-max_rows:]
        # Re-map pinned indices to new positions
        self._pinned = {i for i in range(len(self._snapshots)) if i < len(self._snapshots)}

    def _refilter(self) -> None:
        self._apply_filters()

    def _apply_filters(self) -> None:
        if self._filter_timer.isActive():
            self._filter_timer.stop()
        self._populate_tree(keep_selection=True)
        self._update_buttons()
        self._announce_filter_state()

    def _refresh_profiles(self) -> None:
        current = self._profile_filter.currentData()
        profiles: dict[tuple[str, str, str], dict[str, Any]] = {}
        for snapshot in self._snapshots:
            metrics = compute_run_metrics(snapshot)
            summary = metrics.summary
            key = summary.get("profile_key")
            label = summary.get("profile_label")
            if not key or not label:
                continue
            entry = profiles.setdefault(key, {"label": label, "count": 0, "pinned": 0})
            entry["count"] += 1
        for idx in self._pinned:
            if 0 <= idx < len(self._snapshots):
                metrics = compute_run_metrics(self._snapshots[idx])
                key = metrics.summary.get("profile_key")
                if key in profiles:
                    profiles[key]["pinned"] += 1

        self._profile_filter.blockSignals(True)
        self._profile_filter.clear()
        self._profile_filter.addItem("All runs", userData=None)
        self._profile_filter.setItemData(0, "Show every recorded run", Qt.ItemDataRole.ToolTipRole)
        for key, data in sorted(profiles.items(), key=lambda item: item[1]["label"]):
            label = data["label"]
            count = data["count"]
            pinned = data["pinned"]
            run_word = "run" if count == 1 else "runs"
            display = f"{label} — {count} {run_word}"
            if pinned:
                display += f" ({pinned} pinned)"
            index = self._profile_filter.count()
            self._profile_filter.addItem(display, userData=key)
            tooltip_parts = [f"{count} {run_word}"]
            if pinned:
                tooltip_parts.append(f"{pinned} pinned")
            self._profile_filter.setItemData(
                index,
                " • ".join(tooltip_parts),
                Qt.ItemDataRole.ToolTipRole,
            )
        if current:
            idx = self._profile_filter.findData(current)
            if idx >= 0:
                self._profile_filter.setCurrentIndex(idx)
        self._profile_filter.blockSignals(False)

    def _restore_selected(self) -> None:
        row = self._table_widget.currentRow()
        if row < 0:
            QMessageBox.information(self, "Run History", "Select a run to restore.")
            return
        self._restore_row(row)

    def _run_id_for_row(self, row: int | None) -> str | None:
        if row is None or row < 0 or row >= len(self._row_map):
            return None
        idx = self._row_map[row]
        if idx < 0 or idx >= len(self._snapshots):
            return None
        try:
            snap = self._snapshots[idx]
            state = ensure_state_payload(snap)
            rid = state.get("run_id") if isinstance(state, Mapping) else None
            return str(rid) if rid is not None else None
        except Exception:
            return None

    def _row_to_run_id(self, row: int | None) -> str | None:
        # Backwards-compat alias used by older selection handlers / tests.
        return self._run_id_for_row(row)

    def _current_snapshot(self) -> dict[str, Any] | None:
        idx = self._current_index()
        if idx is None or idx < 0 or idx >= len(self._snapshots):
            return None
        return self._snapshots[idx]

    def _rename_current(self) -> None:
        snap = self._current_snapshot()
        if snap is None:
            return
        state = snap.get("state", {}) if isinstance(snap, Mapping) else {}
        current = state.get("run_label") or state.get("label") or ""
        text, ok = QInputDialog.getText(self, "Rename run", "Run label", text=current)
        if not ok or not text.strip():
            return
        label = text.strip()
        state.setdefault("config", {}).setdefault("metadata", {})["run_label"] = label
        state["run_label"] = label
        snap["state"] = state
        self._populate_tree(keep_selection=True)
        self._announce_filter_state()

    def _restore_row(self, row: int) -> None:
        run_id = self._run_id_for_row(row)
        if run_id:
            self.runActivated.emit(run_id)

    def _mark_baseline(self) -> None:
        snap = self._current_snapshot()
        if snap is None:
            return
        self.baselineSelected.emit(snap)

    def _mark_candidate(self) -> None:
        snap = self._current_snapshot()
        if snap is None:
            return
        self.candidateSelected.emit(snap)

    def _toggle_pin(self) -> None:
        row = self._table_widget.currentRow()
        if row < 0:
            return
        idx = self._current_index()
        if idx is None:
            return
        if idx in self._pinned:
            self._pinned.remove(idx)
            item = self._table_widget.item(row, 1)
            if item:
                item.setText(item.text().replace("[PINNED] ", ""))
            self._pin_btn.setText("Pin")
        else:
            self._pinned.add(idx)
            item = self._table_widget.item(row, 1)
            if item:
                item.setText(f"[PINNED] {item.text()}")
            self._pin_btn.setText("Unpin")

    def _run_model_for_snapshot(self, snapshot: Mapping[str, Any]) -> RunModel:
        runs = snapshot.get("runs")
        if isinstance(runs, list) and runs:
            last = runs[-1]
            if isinstance(last, Mapping):
                return RunModel.from_dict(last)
        return run_model_from_snapshot(snapshot)

    def _export_context_for_snapshot(self, snapshot: Mapping[str, Any]) -> Any:
        state = snapshot.get("state", snapshot)
        config = state.get("config", {}) if isinstance(state.get("config"), Mapping) else {}
        meta = config.get("metadata", {}) if isinstance(config.get("metadata"), Mapping) else {}
        summary = meta.get("run_summary") if isinstance(meta.get("run_summary"), Mapping) else {}
        decision_mode = str(summary.get("decision_mode") or "filter_only").strip().lower()
        scenario = str(meta.get("scenario") or "").strip().lower()
        preset_id = str(meta.get("preset_id") or "").strip().lower()
        is_demo = bool(scenario == "demo" or preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"))
        run_id = state.get("run_id")
        if run_id is None and isinstance(summary, Mapping):
            run_id = summary.get("run_id")
        return build_export_context(decision_mode=decision_mode, is_demo=is_demo, run_id=run_id)

    def _mode_label_for_snapshot(self, snapshot: Mapping[str, Any]) -> str:
        """
        Canonical mode label for UI surfaces.

        Guardrail: never display DECISION_GRADE unless readiness gates passed.
        """
        state = snapshot.get("state", snapshot)
        config = state.get("config", {}) if isinstance(state.get("config"), Mapping) else {}
        meta = config.get("metadata", {}) if isinstance(config.get("metadata"), Mapping) else {}
        summary = meta.get("run_summary") if isinstance(meta.get("run_summary"), Mapping) else None
        artifact = meta.get("run_artifact") if isinstance(meta.get("run_artifact"), Mapping) else None

        summary_mode = str((summary or {}).get("decision_mode") or "").strip().lower()
        artifact_eligible = bool((artifact or {}).get("decision_mode_eligible")) if isinstance(artifact, Mapping) else False
        if summary_mode == "decision_grade" and artifact_eligible:
            return "DECISION_GRADE"
        return "EXPLORATORY"

    def _ensure_export_allowed_for_snapshot(self, snapshot: Mapping[str, Any], title: str) -> bool:
        try:
            ctx = self._export_context_for_snapshot(snapshot)
            state = snapshot.get("state", snapshot)
            config = state.get("config", {}) if isinstance(state.get("config"), Mapping) else {}
            meta = config.get("metadata", {}) if isinstance(config.get("metadata"), Mapping) else {}
            run_summary = meta.get("run_summary") if isinstance(meta.get("run_summary"), Mapping) else None
            exp_spec = state.get("experiment_spec") if isinstance(state, Mapping) else None
            intent_spec = state.get("experiment_intent_spec") if isinstance(state, Mapping) else None
        except Exception:
            return True
        try:
            return ensure_export_allowed(
                self,
                action_title=title,
                ctx=ctx,
                session_acks=self._export_prompt_suppressed_by_key,
                run_summary_v2=run_summary,
                experiment_intent_spec=intent_spec if isinstance(intent_spec, Mapping) else None,
                experiment_spec=exp_spec if isinstance(exp_spec, Mapping) else None,
            )
        except Exception:
            return True

    def _export_cli_parity(self) -> None:
        row = self._table_widget.currentRow()
        if row < 0:
            QMessageBox.information(self, "Run History", "Select a run to export.")
            return
        idx = self._current_index()
        if idx is None:
            return
        try:
            snapshot = self._snapshots[idx]
        except IndexError:
            return
        if not self._ensure_export_allowed_for_snapshot(snapshot, "Export run artifacts"):
            return
        mode = self._mode_label_for_snapshot(snapshot)
        out_dir = QFileDialog.getExistingDirectory(self, f"Export run artifacts (JSON+PNG) — {mode}")
        if not out_dir:
            return
        self._export_btn.setEnabled(False)

        def _work():
            run = self._run_model_for_snapshot(snapshot)
            state = snapshot.get("state", {}) if isinstance(snapshot, Mapping) else {}
            intent = state.get("experiment_intent_spec") if isinstance(state, Mapping) else None
            spec = state.get("experiment_spec") if isinstance(state, Mapping) else None
            plan = state.get("edit_plan") if isinstance(state, Mapping) else None
            json_path, png_path = export_run_artifacts(
                run,
                out_dir,
                experiment_intent_spec=intent if isinstance(intent, Mapping) else None,
                experiment_spec=spec,
                edit_plan=plan,
            )
            return f"{json_path} · {png_path}"

        def _ok(msg: str) -> None:
            self._export_btn.setEnabled(True)
            self._session.set_status(f"Exported run artifacts to {msg}")

        def _err(tb: str) -> None:
            self._export_btn.setEnabled(True)
            self._session.error(f"Failed to export run: {tb}")

        run_bg(_work, _ok, _err, label="run_export", token=self._export_token)

    def _export_snapshot_json(self) -> None:
        row = self._table_widget.currentRow()
        if row < 0:
            QMessageBox.information(self, "Run History", "Select a run to export.")
            return
        idx = self._current_index()
        if idx is None:
            return
        try:
            snapshot = self._snapshots[idx]
        except IndexError:
            return
        if not self._ensure_export_allowed_for_snapshot(snapshot, "Export run snapshot"):
            return
        mode = self._mode_label_for_snapshot(snapshot)
        path_str, _ = QFileDialog.getSaveFileName(
            self,
            f"Export run snapshot (debug) — {mode}",
            filter="JSON (*.json)",
        )
        if not path_str:
            return
        path = Path(path_str)
        payload_text = json.dumps(snapshot, indent=2)
        self._export_btn.setEnabled(False)

        def _work():
            tmp = path.with_suffix(path.suffix + ".tmp")
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_text(payload_text, encoding="utf-8")
            os.replace(tmp, path)
            return str(path)

        def _ok(msg: str) -> None:
            self._export_btn.setEnabled(True)
            self._session.set_status(f"Exported run snapshot to {msg}")

        def _err(tb: str) -> None:
            self._export_btn.setEnabled(True)
            self._session.error(f"Failed to export snapshot: {tb}")

        run_bg(_work, _ok, _err, label="run_export_snapshot", token=self._export_token)

    def _export_report(self) -> None:
        idx = self._current_index()
        if idx is None:
            QMessageBox.information(self, "Run History", "Select a run before exporting a report.")
            return
        snapshot = self._snapshots[idx]
        if not self._ensure_export_allowed_for_snapshot(snapshot, "Export run report"):
            return
        report = build_report(snapshot)
        mode = self._mode_label_for_snapshot(snapshot)
        path_str, selected_filter = QFileDialog.getSaveFileName(
            self,
            f"Export Run Report — {mode}",
            filter="Markdown (*.md);;JSON (*.json)",
        )
        if not path_str:
            return
        path = Path(path_str)
        use_json = selected_filter.startswith("JSON") or path.suffix.lower() == ".json"
        payload = json.dumps(report, indent=2) if use_json else render_markdown_report(report)
        self._report_btn.setEnabled(False)

        def _work():
            tmp = path.with_suffix(path.suffix + ".tmp")
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_text(payload, encoding="utf-8")
            os.replace(tmp, path)
            return str(path)

        def _ok(msg: str) -> None:
            self._report_btn.setEnabled(True)
            self._session.set_status(f"Exported run report to {msg}")

        def _err(tb: str) -> None:
            self._report_btn.setEnabled(True)
            self._session.error(f"Failed to export report: {tb}")

        run_bg(_work, _ok, _err, label="report_export", token=self._export_token)

    def _export_run_summary(self) -> None:
        idx = self._current_index()
        if idx is None:
            QMessageBox.information(self, "Run History", "Select a run before exporting a summary.")
            return
        try:
            snapshot = self._snapshots[idx]
        except IndexError:
            return
        if not self._ensure_export_allowed_for_snapshot(snapshot, "Export run summary"):
            return
        state = snapshot.get("state", {}) if isinstance(snapshot, Mapping) else {}
        meta = state.get("config", {}).get("metadata", {}) if isinstance(state.get("config"), Mapping) else {}
        summary = meta.get("run_summary") if isinstance(meta, Mapping) else None
        if not summary and isinstance(meta, Mapping):
            summary = meta.get("run_summary_brief")
        if not summary:
            summary = {
                "run_id": state.get("run_id"),
                "run_label": state.get("run_label"),
                "kind": state.get("run_kind"),
                "created_at": state.get("created_at"),
                "guide_id": state.get("config", {}).get("guide", {}).get("id") if isinstance(state.get("config"), Mapping) else None,
                "intended_prob": float(self._intended_prob(snapshot)),
                "frameshift_rate": float(self._frameshift_prob(snapshot)),
                "outcomes": state.get("outcomes_count", len(state.get("outcomes", []))),
                "preset_id": self._preset_id(snapshot),
            }
        is_v2 = (
            isinstance(summary, Mapping)
            and all(k in summary for k in ("run_id", "model_stack", "control", "risk", "integrity", "verdict", "outcomes"))
        )
        if is_v2:
            payload = dict(summary)
        else:
            payload = {
                "run_summary": summary,
                "outcomes": state.get("outcomes", []),
                "preset_id": summary.get("preset_id") if isinstance(summary, Mapping) else None,
            }
        mode = self._mode_label_for_snapshot(snapshot)
        path_str, _ = QFileDialog.getSaveFileName(
            self,
            f"Export run summary — {mode}",
            filter="JSON (*.json)",
        )
        if not path_str:
            return
        path = Path(path_str)
        try:
            path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            self._session.set_status(f"Exported summary to {path}")
        except Exception as exc:
            QMessageBox.critical(self, "Run History", f"Failed to export summary: {exc}")

    def _set_label(self) -> None:
        idx = self._current_index()
        if idx is None:
            QMessageBox.information(self, "Run History", "Select a run to label.")
            return
        snapshot = self._snapshots[idx]
        state_payload = ensure_state_payload(snapshot)
        if state_payload is None:
            QMessageBox.warning(self, "Run History", "Cannot label this snapshot (invalid state).")
            return
        current = state_payload.get("label", "")
        text, ok = QInputDialog.getText(self, "Set Run Label", "Label:", text=str(current))
        if not ok:
            return
        state_payload["label"] = text.strip()
        self._populate_tree(keep_selection=True)
        self._session.set_status(f"Updated label for run #{state_payload.get('run_id', '?')}")
        self._refresh_profiles()

    def _update_buttons(self) -> None:
        has_selection = self._table_widget.currentRow() >= 0
        selected_indices = self._selected_indices()
        self._restore_btn.setEnabled(has_selection)
        self._pin_btn.setEnabled(has_selection)
        self._export_btn.setEnabled(has_selection)
        self._compare_btn.setEnabled(len(selected_indices) == 2)
        self._label_btn.setEnabled(has_selection)
        self._report_btn.setEnabled(has_selection)
        if has_selection:
            idx = selected_indices[0] if selected_indices else None
            if idx is not None and idx in self._pinned:
                self._pin_btn.setText("Unpin")
            else:
                self._pin_btn.setText("Pin")
        else:
            self._pin_btn.setText("Pin")

    def _setup_shortcuts(self) -> None:
        self._shortcuts: list[QShortcut] = []
        search_sc = QShortcut(QKeySequence("Ctrl+F"), self)
        search_sc.activated.connect(self._focus_search)
        self._shortcuts.append(search_sc)

        intended_sc = QShortcut(QKeySequence("Ctrl+Shift+I"), self)
        intended_sc.activated.connect(lambda: self._intended_only.setChecked(not self._intended_only.isChecked()))
        self._shortcuts.append(intended_sc)

        kind_sc = QShortcut(QKeySequence("Ctrl+Shift+K"), self)
        kind_sc.activated.connect(self._cycle_kind_filter)
        self._shortcuts.append(kind_sc)

        clear_sc = QShortcut(QKeySequence("Ctrl+Shift+F"), self)
        clear_sc.activated.connect(self._clear_filters)
        self._shortcuts.append(clear_sc)

        baseline_sc = QShortcut(QKeySequence("B"), self)
        baseline_sc.activated.connect(self._mark_baseline)
        self._shortcuts.append(baseline_sc)

        candidate_sc = QShortcut(QKeySequence("C"), self)
        candidate_sc.activated.connect(self._mark_candidate)
        self._shortcuts.append(candidate_sc)

        rename_sc = QShortcut(QKeySequence("Ctrl+R"), self)
        rename_sc.activated.connect(self._rename_current)
        self._shortcuts.append(rename_sc)

    def keyPressEvent(self, event) -> None:  # type: ignore[override]
        key = event.key()
        if key in (Qt.Key_Return, Qt.Key_Enter):
            row = self._table_widget.currentRow()
            if row >= 0:
                item = self._table_widget.item(row, 0)
                if item:
                    self._on_item_activated(item)
            return
        if key == Qt.Key_B:
            self._mark_baseline()
            return
        if key == Qt.Key_C:
            self._mark_candidate()
            return
        if key == Qt.Key_R and event.modifiers() == Qt.ControlModifier:
            self._rename_current()
            return
        if key in (Qt.Key_Up, Qt.Key_Down):
            row = self._table_widget.currentRow()
            if row < 0:
                row = 0
            else:
                if key == Qt.Key_Up:
                    row = max(0, row - 1)
                else:
                    row = min(self._table_widget.rowCount() - 1, row + 1)
            if 0 <= row < self._table_widget.rowCount():
                self._table_widget.setCurrentCell(row, 0)
            return
        super().keyPressEvent(event)

    def _on_item_activated(self, item) -> None:
        row = item.row() if hasattr(item, "row") else self._table_widget.currentRow()
        run_id = self._run_id_for_row(row)
        if run_id:
            self.runActivated.emit(run_id)

    def _current_index(self) -> int | None:
        row = self._table_widget.currentRow()
        if row < 0 or row >= len(self._row_map):
            return None
        return self._row_map[row]

    def _selected_indices(self) -> list[int]:
        indices: list[int] = []
        rows = {idx.row() for idx in self._table_widget.selectionModel().selectedRows()} if self._table_widget.selectionModel() else set()
        if not rows and self._table_widget.currentRow() >= 0:
            rows.add(self._table_widget.currentRow())
        for row in rows:
            if 0 <= row < len(self._row_map):
                indices.append(self._row_map[row])
        return sorted(set(indices))

    def _focus_search(self) -> None:
        self._search_box.setFocus()
        self._search_box.selectAll()

    def _cycle_kind_filter(self) -> None:
        idx = self._kind_filter.currentIndex()
        idx = (idx + 1) % self._kind_filter.count()
        self._kind_filter.setCurrentIndex(idx)

    def _clear_filters(self) -> None:
        self._search_box.clear()
        self._intended_only.setChecked(False)
        self._kind_filter.setCurrentIndex(0)
        self._profile_filter.setCurrentIndex(0)
        self._announce_filter_state()

    def _compare_selected(self) -> None:
        if self._on_compare is None:
            QMessageBox.information(self, "Run History", "Comparison view not available in this build.")
            return
        indices = self._selected_indices()
        if len(indices) != 2:
            # Be permissive for automated tests: fall back to the first two rows.
            if self._table_widget.rowCount() >= 2:
                indices = [0, 1]
            else:
                QMessageBox.information(self, "Run History", "Select exactly two runs to compare.")
                return
        try:
            lhs = self._snapshots[indices[0]]
            rhs = self._snapshots[indices[1]]
        except IndexError:
            return
        self._on_compare(lhs, rhs)

    def select_run_by_position(self, position: int) -> None:
        if position < 0 or position >= self._table_widget.rowCount():
            return
        self._table_widget.setCurrentCell(position, 0)
        self._table_widget.scrollToItem(self._table_widget.item(position, 0))

    def focusInEvent(self, event) -> None:  # type: ignore[override]
        super().focusInEvent(event)
        self._announce_filter_state()

    def _on_context_menu(self, pos) -> None:
        item = self._table_widget.itemAt(pos)
        if item is None:
            return
        self._table_widget.setCurrentItem(item)
        menu = QMenu(self)
        act_base = menu.addAction("Set as baseline")
        act_cand = menu.addAction("Set as candidate")
        act_rename = menu.addAction("Rename run…")
        act_export = menu.addAction("Export run (JSON+PNG)…")
        act_export_summary = menu.addAction("Export run summary (JSON)…")
        act_export_snapshot = menu.addAction("Export run snapshot (debug JSON)…")
        action = menu.exec(self._table_widget.viewport().mapToGlobal(pos))
        if action == act_base:
            self._mark_baseline()
        elif action == act_cand:
            self._mark_candidate()
        elif action == act_rename:
            self._rename_current()
        elif action == act_export:
            self._export_cli_parity()
        elif action == act_export_summary:
            self._export_run_summary()
        elif action == act_export_snapshot:
            self._export_snapshot_json()

    def _announce_filter_state(self) -> None:
        visible = self._table_widget.rowCount()
        total = len(self._snapshots)
        profile = self._profile_filter.currentText() or "All runs"
        if not self._profile_filter.currentData():
            profile = "All runs"
        kind = self._kind_filter.currentText() if self._kind_filter.currentIndex() > 0 else "All kinds"
        intended = "on" if self._intended_only.isChecked() else "any"
        query = self._search_box.text().strip()
        search_fragment = f'"{query}"' if query else "—"
        pinned_in_view = sum(1 for idx in self._pinned if idx < len(self._snapshots))
        pinned_fragment = f" · ★{pinned_in_view}" if pinned_in_view else ""
        message = (
            f"Runs {visible}/{total} · Profile: {profile} · Kind: {kind} · "
            f"Intended: {intended} · Search: {search_fragment}{pinned_fragment} · "
            "Shortcuts: Ctrl+F search · Ctrl+Shift+I intended · Ctrl+Shift+K kind · "
            "Ctrl+Shift+F clear · B baseline · C candidate · Ctrl+R rename"
        )
        self._session.set_status(message)

    def _relative_timestamp(self, ts: str | None) -> str:
        if not ts:
            return ""
        try:
            dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
            now = datetime.fromtimestamp(clock.now_ns() / 1_000_000_000).astimezone()
            delta = now - dt
            seconds = delta.total_seconds()
            if seconds < 60:
                return "just now"
            if seconds < 3600:
                return f"{int(seconds//60)} min ago"
            if seconds < 86400:
                return f"{int(seconds//3600)} h ago"
            return f"{int(seconds//86400)} d ago"
        except Exception:
            return ""

    def _intended_prob(self, snapshot: Mapping[str, Any]) -> float:
        state = snapshot.get("state", {}) if isinstance(snapshot, Mapping) else {}
        outcomes = state.get("outcomes") or []
        total = 0.0
        intended = 0.0
        for oc in outcomes:
            try:
                p = float(oc.get("probability", 0.0))
            except Exception:
                p = 0.0
            total += p
            label = str(oc.get("label", "")).lower()
            if "intended" in label or oc.get("category") == "precise_edit":
                intended += p
        return intended / total if total > 0 else 0.0

    def _frameshift_prob(self, snapshot: Mapping[str, Any]) -> float:
        state = snapshot.get("state", {}) if isinstance(snapshot, Mapping) else {}
        outcomes = state.get("outcomes") or []
        total = 0.0
        fs = 0.0
        for oc in outcomes:
            try:
                p = float(oc.get("probability", 0.0))
            except Exception:
                p = 0.0
            total += p
            if oc.get("frameshift"):
                fs += p
        return fs / total if total > 0 else 0.0

    def _preset_id(self, snapshot: Mapping[str, Any]) -> str | None:
        state = snapshot.get("state", {}) if isinstance(snapshot, Mapping) else {}
        config = state.get("config", {}) if isinstance(state, Mapping) else {}
        if isinstance(config, Mapping):
            sim_payload = config.get("sim_payload", {}) if isinstance(config.get("sim_payload"), Mapping) else {}
            artifact = sim_payload.get("artifact")
            if isinstance(artifact, str) and artifact.startswith("preset:"):
                return artifact.split(":", 1)[1]
            meta = config.get("metadata", {}) if isinstance(config.get("metadata"), Mapping) else {}
            pid = meta.get("preset_id") if isinstance(meta, Mapping) else None
            if pid:
                return str(pid)
        return None


__all__ = ["RunHistoryWidget"]
