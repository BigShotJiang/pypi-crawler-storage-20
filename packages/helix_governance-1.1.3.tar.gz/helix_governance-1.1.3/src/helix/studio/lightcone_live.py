from __future__ import annotations

import hashlib
import re
from dataclasses import replace
from typing import Any, Mapping

from helix.lightcone import (
    LIGHTCONE_RENDERER_ID,
    LIGHTCONE_RENDERER_VERSION,
    BaseOutcomeBuilderV0,
    CrisprOutcomeBuilderV0,
    PrimeOutcomeBuilderV0,
    render_settings_sha256,
)
from helix.lightcone.contract import (
    BuilderProvenance,
    LightconeDocument,
    Locus,
    PhaseStage,
    ReferenceWindow,
    RenderGolden,
)
from helix.studio.models import RunModel
from helix.rng import Rng

_LOCUS_RE = re.compile(
    r"^\s*(?P<contig>[^:\s]+)\s*:\s*(?P<start>[\d,]+)\s*(?:[-–]\s*(?P<end>[\d,]+)\s*)?$"
)


def _sha256_hex_text(text: str) -> str:
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def _u32_seed(label: str) -> int:
    digest = hashlib.sha256(str(label).encode("utf-8")).digest()
    value = int.from_bytes(digest[:4], "big")
    return int(value) if value else 1


def parse_target_locus_range(target_locus: str, *, sequence_len: int | None = None) -> tuple[str, int, int]:
    """Parse a `chr:start-end` locus string into (contig, start, end_exclusive).

    Notes:
    - Accepts commas in coordinates: `chr19:55,200,021-55,200,097`
    - If `sequence_len` is provided, detects inclusive vs exclusive end when possible.
    """

    raw = str(target_locus or "").strip()
    m = _LOCUS_RE.match(raw)
    if not m:
        raise ValueError(f"Unrecognized target_locus format: {target_locus!r}")

    contig = str(m.group("contig"))
    start = int(m.group("start").replace(",", ""))
    end_raw = m.group("end")
    if not end_raw:
        if sequence_len is None:
            return contig, int(start), int(start + 1)
        return contig, int(start), int(start + int(sequence_len))

    end = int(str(end_raw).replace(",", ""))
    if end < start:
        start, end = end, start

    if sequence_len is not None:
        span = int(end) - int(start)
        if span == int(sequence_len):
            # Treat as exclusive end: [start, end)
            return contig, int(start), int(end)
        if span + 1 == int(sequence_len):
            # Treat as inclusive end: [start, end]
            return contig, int(start), int(end + 1)

    # Default: treat as inclusive end to match common genomics strings.
    return contig, int(start), int(end + 1)


_DEFAULT_PHASE_STAGES: tuple[PhaseStage, ...] = (
    PhaseStage(name="bind", start=0.0, end=0.15),
    PhaseStage(name="cut_or_nick", start=0.15, end=0.30),
    PhaseStage(name="processing", start=0.30, end=0.55),
    PhaseStage(name="synthesis", start=0.55, end=0.85),
    PhaseStage(name="ligation", start=0.85, end=1.0),
)


def _default_render_golden(*, width: int, height: int, seed: int) -> RenderGolden:
    payload: dict[str, Any] = {
        "renderer": {"id": LIGHTCONE_RENDERER_ID, "version": LIGHTCONE_RENDERER_VERSION},
        "width": int(width),
        "height": int(height),
        "phase": 1.0,
        "seed": int(seed),
        "background": [8, 10, 18, 255],
        "camera": {"kind": "lightcone2d", "panPx": [0.0, 0.0], "zoom": 1.0},
        "projection": {"kind": "pixel_ortho", "phaseDirection": "up"},
        "colorSpace": "srgb8",
        "alphaMode": "straight",
        "compositeSpace": "srgb",
        "style": {
            "version": "v0.1",
            "layoutMode": "tree_v1",
            "margins": {"left": 36, "right": 36, "top": 24, "bottom": 24},
            "trunkColor": [130, 140, 165, 255],
            "trunkRadiusPx": 2,
            "branchRadiusPx": 2,
            "tipRadiusPx": 2,
            "tipAlphaBoost": 36,
            "alphaBase": 12,
            "alphaScale": 210,
            "alphaMin": 10,
            "alphaMax": 240,
            "laneSpreadPx": 240.0,
            "laneSpreadFrac": 0.6,
            "baseEditLaneSpreadPx": 120.0,
            "baseEditLaneSpreadFrac": 0.25,
            "deltaBpScalePx": 6.0,
            "deltaBpClampPx": 90.0,
            "treeMaxSpreadPx": 320.0,
            "treeLeafJitterPx": 2.0,
            "bundling": {"enabled": False},
            "ghosts": {"enabled": True},
            "baseSheen": {"enabled": True},
            "defaultColorRgb": [143, 152, 180],
            "tagRules": [
                {"matchAny": ["intended"], "colorRgb": [58, 232, 200], "thicknessMul": 1.35},
                {"matchAny": ["fog"], "colorRgb": [138, 147, 168], "thicknessMul": 0.75},
                {"matchAny": ["braid"], "braid": True},
            ],
        },
        "settingsSha256": "0" * 64,
        "rgbaSha256": "0" * 64,
    }
    rg = RenderGolden.from_payload(payload)
    return replace(rg, settings_sha256=render_settings_sha256(rg), rgba_sha256="0" * 64)


def _normalize_edit_type(value: str) -> str:
    v = (value or "").strip().lower()
    if v in {"crispr", "crispr_cut", "crispr-cut", "cas9"}:
        return "crispr_cut"
    if v in {"prime", "prime_edit", "prime-edit"}:
        return "prime_edit"
    if v in {"base", "base_edit", "base-edit"}:
        return "base_edit"
    return "crispr_cut"


def _clamp_int(v: int, lo: int, hi: int) -> int:
    return int(lo) if v < lo else int(hi) if v > hi else int(v)


def build_lightcone_document_from_run(
    run: RunModel,
    *,
    width: int = 1024,
    height: int = 768,
    seed: int | None = None,
) -> LightconeDocument:
    """Best-effort conversion from a Studio `RunModel` to a live LightconeDocument.

    This is intentionally v0: it uses the v0 outcome builders for alleleOps-rich outcomes,
    rather than relying on the run's serialized outcomes (which are often lossy).
    """

    ref_seq = str(run.sequence or "").upper()
    if not ref_seq:
        raise ValueError("RunModel.sequence is required to build a Lightcone document")

    try:
        contig, window_start, _window_end = parse_target_locus_range(run.target_locus, sequence_len=len(ref_seq))
    except Exception:
        contig, window_start = "chrGui", 0
    window_end = int(window_start) + len(ref_seq)

    edit_type = _normalize_edit_type(str(run.edit_type))
    stable_seed = int(seed) if seed is not None else _u32_seed(f"run:{run.run_id}:{run.guide_id}:{edit_type}:{contig}:{window_start}")

    ref_sha = _sha256_hex_text(ref_seq)
    ref_window = ReferenceWindow(start=int(window_start), end=int(window_end), sequence=ref_seq, checksum=ref_sha)

    locus_position = int(window_start) + max(0, len(ref_seq) // 2)
    builder_params: dict[str, Any] = {}
    outcomes = ()
    builder_id = "helix.lightcone.builders.unknown"
    builder_version = "v0"
    builder_notes = "Studio live build (v0)."

    if edit_type == "prime_edit":
        nick_index = run.cut_index
        if nick_index is None and run.pam_index is not None:
            try:
                nick_index = int(run.pam_index) - 3
            except Exception:
                nick_index = None
        nick_index_i = _clamp_int(int(nick_index) if nick_index is not None else (len(ref_seq) // 2), 0, len(ref_seq))
        locus_position = int(window_start) + int(nick_index_i)

        rtt = ""
        meta = run.metadata or {}
        for key in ("rtt", "RTT", "prime_rtt"):
            val = meta.get(key) if isinstance(meta, Mapping) else None
            if isinstance(val, str) and val.strip():
                rtt = val.strip()
                break
        if not rtt:
            rng = Rng(int(stable_seed), stream_id=f"studio:lightcone_live:prime:rtt_v0:seed={int(stable_seed)}")
            rtt = "".join(rng.choice("ACGT") for _ in range(9))

        builder = PrimeOutcomeBuilderV0()
        outcomes = builder.build(ref_seq, nick_index=nick_index_i, rtt=rtt, seed=stable_seed)
        p = builder.params
        builder_params = {
            "nickIndex": int(nick_index_i),
            "rtt": str(rtt),
            "intendedWeight": float(p.intended_weight),
            "noEditWeight": float(p.no_edit_weight),
            "byproductBaseWeight": float(p.byproduct_base_weight),
            "indelWeight": float(p.indel_weight),
        }
        builder_id = "helix.lightcone.builders.prime_v0"
    elif edit_type == "base_edit":
        center = len(ref_seq) // 2
        w0 = max(0, center - 6)
        w1 = min(len(ref_seq) - 1, center + 6)
        intended = center
        locus_position = int(window_start) + int(intended)

        builder = BaseOutcomeBuilderV0()
        outcomes = builder.build(ref_seq, seed=stable_seed, editor_kind="CBE", edit_window=(w0, w1), intended_offset=intended)
        p = builder.params
        builder_params = {
            "editorKind": "CBE",
            "editWindow": [int(w0), int(w1)],
            "intendedOffset": int(intended),
            "baseRate": float(p.base_rate),
            "baseline": float(p.baseline),
            "falloff": float(p.falloff),
            "beamWidth": int(p.beam_width),
        }
        builder_id = "helix.lightcone.builders.base_v0"
    else:
        cut_index = run.cut_index
        if cut_index is None and run.pam_index is not None:
            try:
                cut_index = int(run.pam_index) - 3
            except Exception:
                cut_index = None
        cut_index_i = _clamp_int(int(cut_index) if cut_index is not None else (len(ref_seq) // 2), 0, len(ref_seq))
        locus_position = int(window_start) + int(cut_index_i)

        builder = CrisprOutcomeBuilderV0()
        outcomes = builder.build(ref_seq, cut_index=cut_index_i, seed=stable_seed)
        p = builder.params
        builder_params = {
            "cutIndex": int(cut_index_i),
            "maxDeletionBp": int(p.max_deletion_bp),
            "maxInsertionBp": int(p.max_insertion_bp),
            "delDecay": float(p.del_decay),
            "insDecay": float(p.ins_decay),
            "mmejThresholdBp": int(p.mmej_threshold_bp),
            "noEditWeight": float(p.no_edit_weight),
        }
        builder_id = "helix.lightcone.builders.crispr_v0"

    bp = BuilderProvenance(
        builder_id=str(builder_id),
        builder_version=str(builder_version),
        seed=int(stable_seed),
        params=dict(builder_params),
        reference_window_sha256=str(ref_sha),
        notes=str(builder_notes),
    )

    locus = Locus(
        contig=str(contig),
        position=int(locus_position),
        strand="+",
        window_start=int(window_start),
        window_end=int(window_end),
    )

    rg = _default_render_golden(width=int(width), height=int(height), seed=int(stable_seed))
    doc_id = f"studio_run::{run.run_id}"

    return LightconeDocument(
        spec_version="v0.1",
        id=str(doc_id),
        locus=locus,
        edit_type=str(edit_type),
        reference_window=ref_window,
        outcomes=tuple(outcomes),
        builder_provenance=bp,
        phase_stages=_DEFAULT_PHASE_STAGES,
        off_targets=(),
        render_golden=rg,
        notes=f"Studio live document for run_id={run.run_id} guide_id={run.guide_id}",
    )
