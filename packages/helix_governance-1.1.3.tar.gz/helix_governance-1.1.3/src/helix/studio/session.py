from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
from typing import Any, Mapping, Optional, List

from helix import clock
try:
    import numpy as np

    _HAS_NUMPY = True
except Exception:  # pragma: no cover - numpy is always available in normal runtime
    np = None  # type: ignore
    _HAS_NUMPY = False

try:  # Allow headless / non-GUI usage
    from PySide6.QtCore import QObject, Signal
    _HAS_QT = True
except Exception:  # pragma: no cover - headless fallback
    _HAS_QT = False

    class QObject:  # type: ignore[override]
        def __init__(self, *args, **kwargs) -> None:
            super().__init__()

    class Signal:  # type: ignore[override]
        def __init__(self, *args, **kwargs) -> None:
            pass

        def emit(self, *args, **kwargs) -> None:
            pass

        def connect(self, *args, **kwargs) -> None:
            pass

from helix.crispr.model import CasSystem, CasSystemType, DigitalGenome, PAMRule
from helix.prime.model import PegRNA, PrimeEditor
from helix.studio.models import RunModel
from helix.studio.experiment_spec import (
    default_experiment_spec,
    experiment_spec_from_dict,
    experiment_spec_from_dict_with_error,
    experiment_spec_to_dict,
)
from helix.studio.experiment_intent_spec import (
    EXPERIMENT_INTENT_SPEC_SCHEMA_ID,
    default_experiment_intent_spec,
    experiment_intent_spec_from_dict_with_error,
    experiment_intent_spec_sha256,
    experiment_intent_spec_to_dict,
)
from helix.studio.edit_plan import (
    default_edit_plan,
    derive_edit_plan_from_legacy_config,
    edit_plan_from_dict_with_error,
    edit_plan_to_dict,
)


class RunKind(Enum):
    NONE = auto()
    CRISPR = auto()
    PRIME = auto()
    PCR = auto()

SESSION_SNAPSHOT_VERSION = 2
APPLY_HISTORY_CAP = 100
RESULTS_RECORDS_CAP = 50
CALIBRATION_PROFILES_CAP = 20
CALIBRATION_PREVIEWS_CAP = 20
BASE_POSITION_CAL_PROFILES_CAP = 20
BASE_POSITION_CAL_PREVIEWS_CAP = 20
PRIME_MULTIPLEX_CAL_PROFILES_CAP = 20
PRIME_MULTIPLEX_CAL_PREVIEWS_CAP = 20
SUGGESTED_PRIORS_CAP = 20
SUGGESTED_PRIORS_HISTORY_CAP = 20
PRIME_MULTIPLEX_CAL_PROFILES_CAP = 20
PRIME_MULTIPLEX_CAL_PREVIEWS_CAP = 20


@dataclass
class ExperimentState:
    genome: Optional[DigitalGenome] = None
    peg: Optional[PegRNA] = None
    editor: Optional[PrimeEditor] = None
    genome_source: str = "inline"
    genome_uri: Optional[str] = None
    genome_hash: Optional[str] = None
    experiment_intent_spec: dict[str, Any] = field(default_factory=default_experiment_intent_spec)
    experiment_spec: dict[str, Any] = field(default_factory=default_experiment_spec)
    edit_plan: dict[str, Any] = field(default_factory=default_edit_plan)
    apply_history: list[dict[str, Any]] = field(default_factory=list)
    results_records: list[dict[str, Any]] = field(default_factory=list)
    calibration_profiles: list[dict[str, Any]] = field(default_factory=list)
    calibration_previews: list[dict[str, Any]] = field(default_factory=list)
    base_position_calibration_profiles: list[dict[str, Any]] = field(default_factory=list)
    base_position_calibration_previews: list[dict[str, Any]] = field(default_factory=list)
    prime_multiplex_calibration_profiles: list[dict[str, Any]] = field(default_factory=list)
    prime_multiplex_calibration_previews: list[dict[str, Any]] = field(default_factory=list)
    suggested_priors: list[dict[str, Any]] = field(default_factory=list)
    suggested_priors_history: list[dict[str, Any]] = field(default_factory=list)
    suggested_priors_seq: int = 0

    dag_from_runtime: Optional[Any] = None
    viz_spec_payload: Optional[dict[str, Any]] = None
    outcomes: list[dict[str, Any]] = field(default_factory=list)
    run_artifact: Optional[dict[str, Any]] = None
    run_artifact_hash: Optional[str] = None
    config: dict[str, Any] = field(default_factory=dict)
    pcr_config: Optional["PCRConfig"] = None
    pcr_result: Optional["PCRResult"] = None
    # HelixSpec source of truth buffer (raw .hxspec text), kept alongside legacy configs.
    helixspec_text: str = ""
    helixspec_path: Optional[str] = None

    run_kind: RunKind = RunKind.NONE
    viz_dirty: bool = True
    run_id: int = 0

    @property
    def dag(self) -> Optional[Any]:
        return self.dag_from_runtime


class SessionModel(QObject):
    stateChanged = Signal(ExperimentState)
    logMessage = Signal(str)
    statusChanged = Signal(str)
    errorOccurred = Signal(str)
    runRecorded = Signal(dict)
    runRecordedModel = Signal(object)

    def __init__(self, parent: Optional[QObject] = None) -> None:
        super().__init__(parent)
        self._state = ExperimentState()
        self._run_counter = 0
        self.runs: list[RunModel] = []

    def add_run(self, run: RunModel) -> None:
        if not run.outcomes:
            self.mark_run_invalid(run, reason="zero_outcomes", causes=["Outcome model returned 0 outcomes"])
        self.runs.append(run)
        try:
            from helix.studio.run_artifact import build_run_artifact_from_run_model, artifact_is_valid, artifact_root_causes

            artifact = build_run_artifact_from_run_model(run, state=self._state)
            meta = dict(run.metadata or {})
            meta["run_artifact"] = artifact
            meta["artifact_hash"] = artifact.get("artifact_hash")
            run.metadata = meta
            if not artifact_is_valid(artifact):
                causes = artifact_root_causes(artifact)
                self.mark_run_invalid(run, reason="run_artifact_invalid", causes=[str(c) for c in causes])
        except Exception:
            pass
        try:
            from helix.support.events import log_event

            backend = None
            try:
                backend = getattr(run.engine, "backend", None) if getattr(run, "engine", None) is not None else None
            except Exception:
                backend = None
            log_event(
                "run.recorded",
                run_id=str(getattr(run, "run_id", "")),
                edit_type=str(getattr(run, "edit_type", "")),
                backend=str(backend) if backend is not None else "",
            )
        except Exception:
            pass
        try:
            self.runRecordedModel.emit(run)
        except Exception:
            pass

    def mark_run_invalid(self, run: RunModel, *, reason: str, causes: list[str] | None = None) -> None:
        meta = dict(run.metadata or {})
        meta["invalid"] = True
        if reason:
            meta["invalid_reason"] = str(reason)
        meta["invalid_at_utc"] = clock.utc_now_iso()
        if causes:
            meta["invalid_causes"] = list(causes)
        meta.setdefault("claims_disabled", True)
        run.metadata = meta

    def ensure_run_artifact(self, *, ui_view_settings: Mapping[str, Any] | None = None) -> dict[str, Any] | None:
        """Return the cached run artifact, computing it once if missing."""
        if isinstance(self._state.run_artifact, Mapping) and self._state.run_artifact_hash:
            return self._state.run_artifact
        run = self.get_run_by_id(str(self._state.run_id)) if self._state.run_id else None
        if run is None and self.runs:
            run = self.runs[-1]
        try:
            from helix.studio.run_artifact import build_run_artifact_from_state

            artifact = build_run_artifact_from_state(self._state, run=run, ui_view_settings=ui_view_settings)
        except Exception:
            artifact = None
        if isinstance(artifact, Mapping):
            self._state.run_artifact = dict(artifact)
            self._state.run_artifact_hash = str(artifact.get("artifact_hash") or "")
        return self._state.run_artifact

    def get_run_by_id(self, run_id: str) -> RunModel | None:
        for r in self.runs:
            if str(r.run_id) == str(run_id):
                return r
        return None

    def clone_run_config(self, run_id: str) -> RunModel | None:
        run = self.get_run_by_id(run_id)
        if run is None:
            return None
        return run.clone()

    @property
    def state(self) -> ExperimentState:
        return self._state

    def update(self, *, record_snapshot: bool | None = None, **kwargs: Any) -> None:
        changed = False
        artifact_dirty = False
        viz_dirty_needed = False
        if record_snapshot is None:
            record_snapshot = bool(kwargs.get("viz_dirty"))
        target_kind = kwargs.get("run_kind")

        # Detach common mutable payloads so downstream UI cannot silently mutate
        # session state (a frequent source of “hydration” bugs when specs/config
        # update in place without emitting stateChanged).
        detach_keys = {"config", "viz_spec_payload", "outcomes", "dag_from_runtime"}
        viz_affecting_keys = {"dag_from_runtime", "outcomes", "config", "run_kind", "run_id", "viz_spec_payload"}

        for key, value in kwargs.items():
            if not hasattr(self._state, key):
                continue
            current = getattr(self._state, key)

            store_value = value
            if key in detach_keys and isinstance(value, (dict, list)):
                try:
                    store_value = deepcopy(value)
                except Exception:
                    store_value = value

            # If callers pass the same mutable object, assume it may have been mutated
            # in place. For detached keys we still want to emit and break the reference.
            if current is value:
                if key in detach_keys:
                    setattr(self._state, key, store_value)
                    changed = True
                    viz_dirty_needed = True
                    artifact_dirty = True
                continue

            try:
                if current == store_value:
                    continue
            except Exception:
                pass

            setattr(self._state, key, store_value)
            changed = True
            if key in viz_affecting_keys:
                viz_dirty_needed = True
                artifact_dirty = True

        # If visualization-relevant inputs changed but the caller didn't explicitly
        # toggle viz_dirty, do it here so viz panels reliably refresh.
        if viz_dirty_needed and "viz_dirty" not in kwargs:
            if not bool(getattr(self._state, "viz_dirty", False)):
                self._state.viz_dirty = True
                changed = True
        if isinstance(self._state.apply_history, list) and len(self._state.apply_history) > APPLY_HISTORY_CAP:
            self._state.apply_history = self._state.apply_history[-APPLY_HISTORY_CAP:]
        if isinstance(self._state.results_records, list) and len(self._state.results_records) > RESULTS_RECORDS_CAP:
            self._state.results_records = self._state.results_records[-RESULTS_RECORDS_CAP:]
        if isinstance(self._state.calibration_profiles, list) and len(self._state.calibration_profiles) > CALIBRATION_PROFILES_CAP:
            self._state.calibration_profiles = self._state.calibration_profiles[-CALIBRATION_PROFILES_CAP:]
        if isinstance(self._state.calibration_previews, list) and len(self._state.calibration_previews) > CALIBRATION_PREVIEWS_CAP:
            self._state.calibration_previews = self._state.calibration_previews[-CALIBRATION_PREVIEWS_CAP:]
        if isinstance(self._state.base_position_calibration_profiles, list) and len(self._state.base_position_calibration_profiles) > BASE_POSITION_CAL_PROFILES_CAP:
            self._state.base_position_calibration_profiles = (
                self._state.base_position_calibration_profiles[-BASE_POSITION_CAL_PROFILES_CAP:]
            )
        if (
            isinstance(self._state.prime_multiplex_calibration_profiles, list)
            and len(self._state.prime_multiplex_calibration_profiles) > PRIME_MULTIPLEX_CAL_PROFILES_CAP
        ):
            self._state.prime_multiplex_calibration_profiles = (
                self._state.prime_multiplex_calibration_profiles[-PRIME_MULTIPLEX_CAL_PROFILES_CAP:]
            )
        if isinstance(self._state.base_position_calibration_previews, list) and len(self._state.base_position_calibration_previews) > BASE_POSITION_CAL_PREVIEWS_CAP:
            self._state.base_position_calibration_previews = (
                self._state.base_position_calibration_previews[-BASE_POSITION_CAL_PREVIEWS_CAP:]
            )
        if (
            isinstance(self._state.prime_multiplex_calibration_previews, list)
            and len(self._state.prime_multiplex_calibration_previews) > PRIME_MULTIPLEX_CAL_PREVIEWS_CAP
        ):
            self._state.prime_multiplex_calibration_previews = (
                self._state.prime_multiplex_calibration_previews[-PRIME_MULTIPLEX_CAL_PREVIEWS_CAP:]
            )
        if artifact_dirty:
            self._state.run_artifact = None
            self._state.run_artifact_hash = None
        if isinstance(self._state.suggested_priors, list) and len(self._state.suggested_priors) > SUGGESTED_PRIORS_CAP:
            self._state.suggested_priors = self._state.suggested_priors[-SUGGESTED_PRIORS_CAP:]
        if isinstance(self._state.suggested_priors_history, list) and len(self._state.suggested_priors_history) > SUGGESTED_PRIORS_HISTORY_CAP:
            self._state.suggested_priors_history = self._state.suggested_priors_history[-SUGGESTED_PRIORS_HISTORY_CAP:]
        if changed:
            if record_snapshot:
                kind = target_kind or self._state.run_kind
                if kind and kind != RunKind.NONE:
                    self._run_counter += 1
                    self._state.run_id = self._run_counter
                    snapshot = self.to_payload(timestamp=True)
                    self.stateChanged.emit(self._state)
                    self.runRecorded.emit(snapshot)
                    return
            self.stateChanged.emit(self._state)

    def append_outcome(self, outcome: dict[str, Any]) -> None:
        self._state.outcomes.append(outcome)
        self._state.viz_dirty = True
        self.stateChanged.emit(self._state)

    def set_helixspec(self, text: str, *, path: str | None = None) -> None:
        """Replace the current HelixSpec buffer (optionally tracking its source path)."""
        text = text or ""
        if self._state.helixspec_text == text and self._state.helixspec_path == path:
            return
        self._state.helixspec_text = text
        self._state.helixspec_path = path
        self._state.viz_dirty = True
        self.stateChanged.emit(self._state)

    def set_experiment_intent_spec(self, payload: Mapping[str, Any] | None) -> None:
        """
        Set the top-level ExperimentIntentSpec and bind it into ExperimentSpec.intentRef.

        This keeps "why/decision rule/premortem" as a first-class, versioned object, while
        still providing a tight link from the evolving design spec to the intent hash.
        """
        spec, _err = experiment_intent_spec_from_dict_with_error(payload)
        sha = experiment_intent_spec_sha256(spec)
        exp_spec = experiment_spec_to_dict(self._state.experiment_spec)
        exp_spec["intentRef"] = {"kind": EXPERIMENT_INTENT_SPEC_SCHEMA_ID, "sha256": sha}
        self.update(experiment_intent_spec=spec, experiment_spec=exp_spec)

    def log(self, msg: str) -> None:
        self.logMessage.emit(str(msg))

    def mark_viz_clean(self) -> None:
        if self._state.viz_dirty:
            self._state.viz_dirty = False

    def set_status(self, message: str) -> None:
        self.statusChanged.emit(str(message))
        self.log(str(message))

    def error(self, message: str) -> None:
        self.errorOccurred.emit(str(message))
        self.log(str(message))

    def to_payload(self, *, timestamp: bool = False) -> dict[str, Any]:
        state_payload = {
            "run_kind": self._state.run_kind.name,
            "run_id": self._state.run_id,
            "viz_dirty": self._state.viz_dirty,
            "config": deepcopy(self._state.config),
            "helixspec_text": self._state.helixspec_text,
            "helixspec_path": self._state.helixspec_path,
            "experiment_intent_spec": experiment_intent_spec_to_dict(self._state.experiment_intent_spec),
            "experiment_spec": experiment_spec_to_dict(self._state.experiment_spec),
            "edit_plan": edit_plan_to_dict(self._state.edit_plan),
            "apply_history": deepcopy(self._state.apply_history),
            "results_records": deepcopy(self._state.results_records),
            "calibration_profiles": deepcopy(self._state.calibration_profiles),
            "calibration_previews": deepcopy(self._state.calibration_previews),
            "base_position_calibration_profiles": deepcopy(self._state.base_position_calibration_profiles),
            "base_position_calibration_previews": deepcopy(self._state.base_position_calibration_previews),
            "prime_multiplex_calibration_profiles": deepcopy(self._state.prime_multiplex_calibration_profiles),
            "prime_multiplex_calibration_previews": deepcopy(self._state.prime_multiplex_calibration_previews),
            "suggested_priors": deepcopy(self._state.suggested_priors),
            "suggested_priors_history": deepcopy(self._state.suggested_priors_history),
            "suggested_priors_seq": int(self._state.suggested_priors_seq),
            "outcomes": deepcopy(self._state.outcomes),
            "dag_from_runtime": deepcopy(self._state.dag_from_runtime),
            "viz_spec_payload": deepcopy(self._state.viz_spec_payload),
            "run_artifact": deepcopy(self._state.run_artifact),
            "run_artifact_hash": self._state.run_artifact_hash,
            "genome_source": self._state.genome_source,
            "genome_uri": self._state.genome_uri,
            "genome_hash": self._state.genome_hash,
        }
        snapshot_timestamp: Optional[str] = None
        if timestamp:
            snapshot_timestamp = clock.utc_now_iso_offset()
        if self._state.genome is not None:
            state_payload["genome"] = deepcopy(self._state.genome.sequences)
        if self._state.peg is not None:
            state_payload["peg"] = _serialize_peg(self._state.peg)
        if self._state.editor is not None:
            state_payload["editor"] = _serialize_editor(self._state.editor)
        if self._state.pcr_config is not None:
            state_payload["pcr_config"] = _serialize_pcr_config(self._state.pcr_config)
        if self._state.pcr_result is not None:
            state_payload["pcr_result"] = _serialize_pcr_result(self._state.pcr_result)
        payload = {
            "version": SESSION_SNAPSHOT_VERSION,
            "state": state_payload,
        }
        if self.runs:
            payload["runs"] = [r.to_dict() for r in self.runs]
        if snapshot_timestamp:
            payload["timestamp"] = snapshot_timestamp
        return _json_safe(payload)

    def load_payload(self, payload: Mapping[str, Any]) -> None:
        if "state" in payload:
            version = payload.get("version", 0)
            state_payload = payload.get("state", {})
        else:
            version = 0
            state_payload = payload
        runs_raw = payload.get("runs") if isinstance(payload, Mapping) else None
        self.runs = []
        if isinstance(runs_raw, list):
            for r in runs_raw:
                try:
                    self.runs.append(RunModel.from_dict(r))
                except Exception:
                    continue
        state = ExperimentState()
        state.run_kind = RunKind[state_payload.get("run_kind", "NONE")]
        state.run_id = int(state_payload.get("run_id", 0))
        state.viz_dirty = bool(state_payload.get("viz_dirty", True))
        state.config = deepcopy(state_payload.get("config", {}))
        state.helixspec_text = str(state_payload.get("helixspec_text", "") or "")
        raw_path = state_payload.get("helixspec_path")
        state.helixspec_path = str(raw_path) if raw_path is not None else None
        raw_history = state_payload.get("apply_history", [])
        state.apply_history = deepcopy(raw_history) if isinstance(raw_history, list) else []
        if len(state.apply_history) > APPLY_HISTORY_CAP:
            state.apply_history = state.apply_history[-APPLY_HISTORY_CAP:]
        raw_results = state_payload.get("results_records", [])
        state.results_records = deepcopy(raw_results) if isinstance(raw_results, list) else []
        if len(state.results_records) > RESULTS_RECORDS_CAP:
            state.results_records = state.results_records[-RESULTS_RECORDS_CAP:]
        raw_profiles = state_payload.get("calibration_profiles", [])
        state.calibration_profiles = deepcopy(raw_profiles) if isinstance(raw_profiles, list) else []
        if len(state.calibration_profiles) > CALIBRATION_PROFILES_CAP:
            state.calibration_profiles = state.calibration_profiles[-CALIBRATION_PROFILES_CAP:]
        raw_previews = state_payload.get("calibration_previews", [])
        state.calibration_previews = deepcopy(raw_previews) if isinstance(raw_previews, list) else []
        if len(state.calibration_previews) > CALIBRATION_PREVIEWS_CAP:
            state.calibration_previews = state.calibration_previews[-CALIBRATION_PREVIEWS_CAP:]
        raw_base_profiles = state_payload.get("base_position_calibration_profiles", [])
        state.base_position_calibration_profiles = deepcopy(raw_base_profiles) if isinstance(raw_base_profiles, list) else []
        if len(state.base_position_calibration_profiles) > BASE_POSITION_CAL_PROFILES_CAP:
            state.base_position_calibration_profiles = (
                state.base_position_calibration_profiles[-BASE_POSITION_CAL_PROFILES_CAP:]
            )
        raw_prime_mux_profiles = state_payload.get("prime_multiplex_calibration_profiles", [])
        state.prime_multiplex_calibration_profiles = (
            deepcopy(raw_prime_mux_profiles) if isinstance(raw_prime_mux_profiles, list) else []
        )
        if len(state.prime_multiplex_calibration_profiles) > PRIME_MULTIPLEX_CAL_PROFILES_CAP:
            state.prime_multiplex_calibration_profiles = (
                state.prime_multiplex_calibration_profiles[-PRIME_MULTIPLEX_CAL_PROFILES_CAP:]
            )
        raw_base_previews = state_payload.get("base_position_calibration_previews", [])
        state.base_position_calibration_previews = deepcopy(raw_base_previews) if isinstance(raw_base_previews, list) else []
        if len(state.base_position_calibration_previews) > BASE_POSITION_CAL_PREVIEWS_CAP:
            state.base_position_calibration_previews = (
                state.base_position_calibration_previews[-BASE_POSITION_CAL_PREVIEWS_CAP:]
            )
        raw_prime_mux_previews = state_payload.get("prime_multiplex_calibration_previews", [])
        state.prime_multiplex_calibration_previews = (
            deepcopy(raw_prime_mux_previews) if isinstance(raw_prime_mux_previews, list) else []
        )
        if len(state.prime_multiplex_calibration_previews) > PRIME_MULTIPLEX_CAL_PREVIEWS_CAP:
            state.prime_multiplex_calibration_previews = (
                state.prime_multiplex_calibration_previews[-PRIME_MULTIPLEX_CAL_PREVIEWS_CAP:]
            )
        raw_priors = state_payload.get("suggested_priors", [])
        state.suggested_priors = deepcopy(raw_priors) if isinstance(raw_priors, list) else []
        if len(state.suggested_priors) > SUGGESTED_PRIORS_CAP:
            state.suggested_priors = state.suggested_priors[-SUGGESTED_PRIORS_CAP:]
        raw_history = state_payload.get("suggested_priors_history", [])
        state.suggested_priors_history = deepcopy(raw_history) if isinstance(raw_history, list) else []
        if len(state.suggested_priors_history) > SUGGESTED_PRIORS_HISTORY_CAP:
            state.suggested_priors_history = state.suggested_priors_history[-SUGGESTED_PRIORS_HISTORY_CAP:]
        state.suggested_priors_seq = int(state_payload.get("suggested_priors_seq", 0))
        state.outcomes = deepcopy(state_payload.get("outcomes", []))
        state.dag_from_runtime = deepcopy(state_payload.get("dag_from_runtime"))
        state.viz_spec_payload = deepcopy(state_payload.get("viz_spec_payload"))
        state.run_artifact = deepcopy(state_payload.get("run_artifact"))
        state.run_artifact_hash = state_payload.get("run_artifact_hash")
        state.genome_source = str(state_payload.get("genome_source", "inline"))
        state.genome_uri = state_payload.get("genome_uri")
        state.genome_hash = state_payload.get("genome_hash")
        intent_payload = state_payload.get("experiment_intent_spec")
        intent, intent_err = experiment_intent_spec_from_dict_with_error(
            intent_payload if isinstance(intent_payload, Mapping) else None
        )
        state.experiment_intent_spec = intent
        spec_payload = state_payload.get("experiment_spec")
        spec, spec_err = experiment_spec_from_dict_with_error(spec_payload)
        state.experiment_spec = spec
        plan_payload = state_payload.get("edit_plan")
        plan, plan_err = edit_plan_from_dict_with_error(plan_payload)
        state.edit_plan = plan
        try:
            targets = plan.get("targets") if isinstance(plan, Mapping) else []
        except Exception:
            targets = []
        if not targets:
            derived = derive_edit_plan_from_legacy_config(state.config, experiment_spec=state.experiment_spec)
            if derived is not None:
                state.edit_plan = derived
        genome_data = state_payload.get("genome")
        if isinstance(genome_data, Mapping):
            state.genome = DigitalGenome(sequences=dict(genome_data))
        elif state.genome is None and self.runs:
            # Legacy session payloads may include runs (with sequences) but omit the
            # v2 state.genome mapping. Hydrate a minimal inline genome so downstream
            # panels (e.g., Sim Builder, off-targets, inspectors) have a sequence
            # surface to operate on.
            inferred: dict[str, str] = {}
            for idx, run in enumerate(self.runs):
                try:
                    seq = str(getattr(run, "sequence", "") or "").strip().upper()
                except Exception:
                    continue
                if not seq:
                    continue
                contig: str | None = None
                try:
                    meta = run.metadata or {}
                except Exception:
                    meta = {}
                if isinstance(meta, Mapping):
                    for key in ("contig", "chrom", "chr"):
                        val = meta.get(key)
                        if isinstance(val, str) and val.strip():
                            contig = val.strip()
                            break
                if not contig:
                    guide_id = str(getattr(run, "guide_id", "") or "").strip()
                    run_id = str(getattr(run, "run_id", "") or "").strip()
                    contig = guide_id or run_id
                if not contig:
                    contig = f"contig_{idx + 1}"
                base = contig
                suffix = 2
                while contig in inferred and inferred[contig] != seq:
                    contig = f"{base}_{suffix}"
                    suffix += 1
                inferred[contig] = seq
            if inferred:
                state.genome = DigitalGenome(sequences=inferred)

        if state.run_kind == RunKind.NONE and self.runs:
            try:
                last_kind = str(self.runs[-1].edit_type or "").strip().lower()
            except Exception:
                last_kind = ""
            if last_kind in {"crispr", "cut", "crispr_cut"}:
                state.run_kind = RunKind.CRISPR
            elif last_kind == "prime":
                state.run_kind = RunKind.PRIME
            elif last_kind == "pcr":
                state.run_kind = RunKind.PCR
        peg_data = state_payload.get("peg")
        if isinstance(peg_data, Mapping):
            state.peg = _deserialize_peg(peg_data)
        editor_data = state_payload.get("editor")
        if isinstance(editor_data, Mapping):
            state.editor = _deserialize_editor(editor_data)
        pcr_cfg_data = state_payload.get("pcr_config")
        if isinstance(pcr_cfg_data, Mapping):
            state.pcr_config = _deserialize_pcr_config(pcr_cfg_data)
        pcr_res_data = state_payload.get("pcr_result")
        if isinstance(pcr_res_data, Mapping):
            state.pcr_result = _deserialize_pcr_result(pcr_res_data)
        snapshot_timestamp = payload.get("timestamp")
        if version == 0 and "timestamp" in state_payload:
            snapshot_timestamp = state_payload["timestamp"]
        if snapshot_timestamp:
            state.config.setdefault("metadata", {})["timestamp"] = snapshot_timestamp
        self._state = state
        if spec_err:
            try:
                self.log(f"ExperimentSpec validation failed; loaded with defaults where needed. {spec_err}")
            except Exception:
                pass
        if plan_err:
            try:
                self.log(f"EditPlan validation failed; loaded with defaults where needed. {plan_err}")
            except Exception:
                pass
        self._run_counter = max(self._run_counter, state.run_id)
        self.stateChanged.emit(self._state)


def _serialize_peg(peg: PegRNA) -> dict[str, Any]:
    return {
        "spacer": peg.spacer,
        "pbs": peg.pbs,
        "rtt": peg.rtt,
        "name": peg.name,
        "metadata": dict(peg.metadata),
    }


def _deserialize_peg(data: Mapping[str, Any]) -> PegRNA:
    return PegRNA(
        spacer=str(data.get("spacer", "")),
        pbs=str(data.get("pbs", "")),
        rtt=str(data.get("rtt", "")),
        name=data.get("name"),
        metadata=dict(data.get("metadata", {})),
    )


def _serialize_editor(editor: PrimeEditor) -> dict[str, Any]:
    return {
        "name": editor.name,
        "nick_to_edit_offset": editor.nick_to_edit_offset,
        "efficiency_scale": editor.efficiency_scale,
        "indel_bias": editor.indel_bias,
        "mismatch_tolerance": editor.mismatch_tolerance,
        "flap_balance": editor.flap_balance,
        "reanneal_bias": editor.reanneal_bias,
        "metadata": dict(editor.metadata),
        "cas": _serialize_cas(editor.cas),
    }


def _deserialize_editor(data: Mapping[str, Any]) -> PrimeEditor:
    cas_data = data.get("cas") or {}
    cas = _deserialize_cas(cas_data) if isinstance(cas_data, Mapping) else CasSystem(
        name="Imported",
        system_type=CasSystemType.CAS9,
        pam_rules=[PAMRule(pattern="NGG")],
        cut_offset=3,
    )

    return PrimeEditor(
        name=str(data.get("name", "PrimeEditor")),
        cas=cas,
        nick_to_edit_offset=int(data.get("nick_to_edit_offset", 0)),
        efficiency_scale=float(data.get("efficiency_scale", 1.0)),
        indel_bias=float(data.get("indel_bias", 0.0)),
        mismatch_tolerance=int(data.get("mismatch_tolerance", 3)),
        flap_balance=float(data.get("flap_balance", 0.5)),
        reanneal_bias=float(data.get("reanneal_bias", 0.1)),
        metadata=dict(data.get("metadata", {})),
    )


@dataclass(frozen=True)
class PCRConfig:
    template_seq: str
    fwd_primer: str
    rev_primer: str
    cycles: int
    polymerase_name: str
    base_error_rate: float
    indel_fraction: float
    efficiency: float
    initial_copies: int = 1


@dataclass
class PCRCycleStats:
    cycle_index: int
    amplicon_copies: float
    amplicon_mass_ng: float
    cumulative_mutation_rate: float
    sub_rate: float
    indel_rate: float


@dataclass
class PCRResult:
    config: PCRConfig
    amplicon_length: int
    amplicon_start: int = 0
    amplicon_end: int = 0
    cycles: List[PCRCycleStats] = field(default_factory=list)
    final_mutation_rate: float = 0.0
    final_amplicon_copies: float = 0.0
    final_amplicon_mass_ng: float = 0.0


def _serialize_pcr_config(cfg: PCRConfig) -> dict[str, Any]:
    return asdict(cfg)


def _deserialize_pcr_config(data: Mapping[str, Any]) -> PCRConfig:
    return PCRConfig(
        template_seq=str(data.get("template_seq", "")),
        fwd_primer=str(data.get("fwd_primer", "")),
        rev_primer=str(data.get("rev_primer", "")),
        cycles=int(data.get("cycles", 0)),
        polymerase_name=str(data.get("polymerase_name", "")),
        base_error_rate=float(data.get("base_error_rate", 0.0)),
        indel_fraction=float(data.get("indel_fraction", 0.0)),
        efficiency=float(data.get("efficiency", 0.0)),
        initial_copies=int(data.get("initial_copies", 1)),
    )


def _serialize_pcr_cycle(stats: PCRCycleStats) -> dict[str, Any]:
    return asdict(stats)


def _deserialize_pcr_cycle(data: Mapping[str, Any]) -> PCRCycleStats:
    return PCRCycleStats(
        cycle_index=int(data.get("cycle_index", 0)),
        amplicon_copies=float(data.get("amplicon_copies", 0.0)),
        amplicon_mass_ng=float(data.get("amplicon_mass_ng", 0.0)),
        cumulative_mutation_rate=float(data.get("cumulative_mutation_rate", 0.0)),
        sub_rate=float(data.get("sub_rate", 0.0)),
        indel_rate=float(data.get("indel_rate", 0.0)),
    )


def _serialize_pcr_result(result: PCRResult) -> dict[str, Any]:
    return {
        "config": _serialize_pcr_config(result.config),
        "amplicon_length": result.amplicon_length,
        "amplicon_start": result.amplicon_start,
        "amplicon_end": result.amplicon_end,
        "cycles": [_serialize_pcr_cycle(cycle) for cycle in result.cycles],
        "final_mutation_rate": result.final_mutation_rate,
        "final_amplicon_copies": result.final_amplicon_copies,
        "final_amplicon_mass_ng": result.final_amplicon_mass_ng,
    }


def _deserialize_pcr_result(data: Mapping[str, Any]) -> PCRResult:
    cfg_data = data.get("config") or {}
    cfg = _deserialize_pcr_config(cfg_data) if isinstance(cfg_data, Mapping) else PCRConfig(
        template_seq="",
        fwd_primer="",
        rev_primer="",
        cycles=0,
        polymerase_name="",
        base_error_rate=0.0,
        indel_fraction=0.0,
        efficiency=0.0,
        initial_copies=1,
    )
    cycles_data = data.get("cycles") or []
    cycles: List[PCRCycleStats] = []
    if isinstance(cycles_data, list):
        cycles = [_deserialize_pcr_cycle(entry) for entry in cycles_data if isinstance(entry, Mapping)]
    return PCRResult(
        config=cfg,
        amplicon_length=int(data.get("amplicon_length", 0)),
        amplicon_start=int(data.get("amplicon_start", 0)),
        amplicon_end=int(data.get("amplicon_end", 0)),
        cycles=cycles,
        final_mutation_rate=float(data.get("final_mutation_rate", 0.0)),
        final_amplicon_copies=float(data.get("final_amplicon_copies", 0.0)),
        final_amplicon_mass_ng=float(data.get("final_amplicon_mass_ng", 0.0)),
    )


def _json_safe(obj: Any) -> Any:
    """Recursively convert arrays and numpy scalars to JSON-friendly types."""

    if _HAS_NUMPY:
        if isinstance(obj, np.ndarray):  # type: ignore[arg-type]
            return obj.tolist()
        if isinstance(obj, np.generic):  # type: ignore[arg-type]
            return obj.item()

    if isinstance(obj, Mapping):
        return {key: _json_safe(value) for key, value in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [_json_safe(value) for value in obj]
    return obj


def _serialize_cas(cas: CasSystem) -> dict[str, Any]:
    return {
        "name": cas.name,
        "system_type": cas.system_type.value,
        "pam_rules": [{"pattern": rule.pattern, "description": rule.description} for rule in cas.pam_rules],
        "cut_offset": cas.cut_offset,
        "max_mismatches": cas.max_mismatches,
        "weight_mismatch_penalty": cas.weight_mismatch_penalty,
        "weight_pam_penalty": cas.weight_pam_penalty,
    }


def _deserialize_cas(data: Mapping[str, Any]) -> CasSystem:
    rules = [
        PAMRule(pattern=str(entry.get("pattern", "")), description=str(entry.get("description", "")))
        for entry in data.get("pam_rules", [])
        if isinstance(entry, Mapping)
    ]
    system_type = data.get("system_type", CasSystemType.CAS9.value)
    return CasSystem(
        name=str(data.get("name", "CasSystem")),
        system_type=CasSystemType(system_type),
        pam_rules=rules or [PAMRule(pattern="NGG")],
        cut_offset=int(data.get("cut_offset", 3)),
        max_mismatches=int(data.get("max_mismatches", 3)),
        weight_mismatch_penalty=float(data.get("weight_mismatch_penalty", 1.0)),
        weight_pam_penalty=float(data.get("weight_pam_penalty", 2.0)),
    )
