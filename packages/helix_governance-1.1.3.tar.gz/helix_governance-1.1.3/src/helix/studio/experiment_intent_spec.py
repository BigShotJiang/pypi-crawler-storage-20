from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Mapping, Optional, Tuple

EXPERIMENT_INTENT_SPEC_SCHEMA_ID = "helix_experiment_intent_spec_v1"

LOGGER = logging.getLogger(__name__)

try:  # pragma: no cover - optional dependency
    from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

    PYDANTIC_AVAILABLE = True
except Exception:  # pragma: no cover - fallback path
    BaseModel = object  # type: ignore
    ValidationError = Exception  # type: ignore
    PYDANTIC_AVAILABLE = False


def _schema_path() -> Path:
    return Path(__file__).resolve().parents[3] / "schemas" / "intent" / "helix_experiment_intent_spec_v1.json"


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n").encode(
        "utf-8"
    )


def _default_snapshots() -> dict[str, Any]:
    return {
        "targetLocusResolution": None,
        "guideSet": None,
        "offTargetPolicyMode": None,
        "assumedCellContext": None,
        "analysisPlan": None,
    }


def _default_perturbation() -> dict[str, Any]:
    return {"modality": "", "target": "", "notes": ""}


def _default_readout() -> dict[str, Any]:
    return {"measurement": "", "notes": ""}


def _default_decision_rule() -> dict[str, Any]:
    return {"rule": "", "notes": "", "threshold": None, "pattern": None}


def _default_spec_dict() -> dict[str, Any]:
    return {
        "schema": EXPERIMENT_INTENT_SPEC_SCHEMA_ID,
        "intentId": "unset",
        "createdAt": None,
        "decisionQuestion": "",
        "hypothesis": "",
        "perturbation": _default_perturbation(),
        "readout": _default_readout(),
        "decisionRule": _default_decision_rule(),
        "premortem": [],
        "snapshots": _default_snapshots(),
    }


def _norm_text(value: Any) -> str:
    return str(value or "").strip()


def intent_spec_missing_required_fields(data: Mapping[str, Any] | None) -> list[str]:
    """Return required-field names that are missing or empty (decision hygiene gate)."""
    spec = experiment_intent_spec_to_dict(data)
    missing: list[str] = []

    if not _norm_text(spec.get("decisionQuestion")):
        missing.append("decisionQuestion")
    if not _norm_text(spec.get("hypothesis")):
        missing.append("hypothesis")

    perturbation = spec.get("perturbation") if isinstance(spec.get("perturbation"), Mapping) else {}
    if not _norm_text(perturbation.get("modality")):
        missing.append("perturbation.modality")
    if not _norm_text(perturbation.get("target")):
        missing.append("perturbation.target")

    readout = spec.get("readout") if isinstance(spec.get("readout"), Mapping) else {}
    if not _norm_text(readout.get("measurement")):
        missing.append("readout.measurement")

    rule = spec.get("decisionRule") if isinstance(spec.get("decisionRule"), Mapping) else {}
    if not _norm_text(rule.get("rule")):
        missing.append("decisionRule.rule")

    premortem = spec.get("premortem") if isinstance(spec.get("premortem"), list) else []
    if not premortem:
        missing.append("premortem")
    else:
        first = premortem[0] if premortem else None
        if isinstance(first, Mapping):
            if not _norm_text(first.get("failureMode")):
                missing.append("premortem[0].failureMode")
            if not _norm_text(first.get("dataSignature")):
                missing.append("premortem[0].dataSignature")

    return missing


if PYDANTIC_AVAILABLE:

    class _BaseIntentModel(BaseModel):
        model_config = ConfigDict(extra="allow", populate_by_name=True)


    class PerturbationV1(_BaseIntentModel):
        modality: str = ""
        target: str = ""
        notes: str = ""

        @field_validator("modality", "target", "notes", mode="before")
        @classmethod
        def _coerce_text(cls, value: Any) -> Any:
            if value is None:
                return ""
            return str(value)


    class ReadoutV1(_BaseIntentModel):
        measurement: str = ""
        notes: str = ""

        @field_validator("measurement", "notes", mode="before")
        @classmethod
        def _coerce_text(cls, value: Any) -> Any:
            if value is None:
                return ""
            return str(value)


    class DecisionRuleV1(_BaseIntentModel):
        rule: str = ""
        notes: str = ""
        threshold: float | None = None
        pattern: str | None = None

        @field_validator("rule", "notes", mode="before")
        @classmethod
        def _coerce_text(cls, value: Any) -> Any:
            if value is None:
                return ""
            return str(value)


    class PremortemEntryV1(_BaseIntentModel):
        failure_mode: str = Field(default="", alias="failureMode")
        data_signature: str = Field(default="", alias="dataSignature")
        mitigation: str | None = None

        @field_validator("failure_mode", "data_signature", mode="before")
        @classmethod
        def _coerce_text(cls, value: Any) -> Any:
            if value is None:
                return ""
            return str(value)


    class ExperimentIntentSpecV1(_BaseIntentModel):
        schema_: str = Field(default=EXPERIMENT_INTENT_SPEC_SCHEMA_ID, alias="schema")
        intent_id: str = Field(default="unset", alias="intentId")
        created_at: Optional[str] = Field(default=None, alias="createdAt")
        decision_question: str = Field(default="", alias="decisionQuestion")
        hypothesis: str = ""
        perturbation: PerturbationV1 = Field(default_factory=PerturbationV1)
        readout: ReadoutV1 = Field(default_factory=ReadoutV1)
        decision_rule: DecisionRuleV1 = Field(default_factory=DecisionRuleV1, alias="decisionRule")
        premortem: list[PremortemEntryV1] = Field(default_factory=list)
        snapshots: dict[str, Any] = Field(default_factory=_default_snapshots)

        @field_validator("decision_question", "hypothesis", mode="before")
        @classmethod
        def _coerce_text(cls, value: Any) -> Any:
            if value is None:
                return ""
            return str(value)

        @property
        def schema(self) -> str:  # compatibility with existing callers
            return self.schema_


def default_experiment_intent_spec() -> dict[str, Any]:
    if PYDANTIC_AVAILABLE:
        model = ExperimentIntentSpecV1()
        payload = model.model_dump(exclude_none=True, by_alias=True)
        payload.setdefault("snapshots", _default_snapshots())
        return payload
    return json.loads(json.dumps(_default_spec_dict()))


def experiment_intent_spec_from_dict_with_error(data: Mapping[str, Any] | None) -> Tuple[dict[str, Any], str | None]:
    if data is None or not isinstance(data, Mapping):
        return default_experiment_intent_spec(), None
    if PYDANTIC_AVAILABLE:
        try:
            model = ExperimentIntentSpecV1.model_validate(data)
            payload = model.model_dump(exclude_none=True, by_alias=True)
            payload.setdefault("snapshots", _default_snapshots())
            return payload, None
        except ValidationError as exc:
            LOGGER.warning("ExperimentIntentSpec validation failed, using best-effort merge: %s", exc)
            merged = _default_spec_dict()
            merged.update({k: v for k, v in data.items()})
            merged.setdefault("schema", EXPERIMENT_INTENT_SPEC_SCHEMA_ID)
            merged.setdefault("snapshots", _default_snapshots())
            return merged, str(exc)
    merged = _default_spec_dict()
    merged.update({k: v for k, v in data.items()})
    merged.setdefault("schema", EXPERIMENT_INTENT_SPEC_SCHEMA_ID)
    merged.setdefault("snapshots", _default_snapshots())
    return merged, None


def experiment_intent_spec_from_dict(data: Mapping[str, Any] | None) -> dict[str, Any]:
    spec, _err = experiment_intent_spec_from_dict_with_error(data)
    return spec


def experiment_intent_spec_to_dict(data: Any) -> dict[str, Any]:
    if PYDANTIC_AVAILABLE and isinstance(data, ExperimentIntentSpecV1):
        payload = data.model_dump(exclude_none=True, by_alias=True)
        payload.setdefault("snapshots", _default_snapshots())
        return payload
    if isinstance(data, Mapping):
        return experiment_intent_spec_from_dict(data)
    if data is None:
        return default_experiment_intent_spec()
    return experiment_intent_spec_from_dict({})


def experiment_intent_spec_json_bytes(data: Any) -> bytes:
    payload = experiment_intent_spec_to_dict(data)
    return _canonical_json_bytes(payload)


def experiment_intent_spec_sha256(data: Any) -> str:
    import hashlib

    return hashlib.sha256(experiment_intent_spec_json_bytes(data)).hexdigest()


def experiment_intent_spec_json_schema() -> dict[str, Any]:
    if PYDANTIC_AVAILABLE:
        return ExperimentIntentSpecV1.model_json_schema()
    try:
        from importlib import resources

        schema_text = resources.files("helix.schema").joinpath("intent/helix_experiment_intent_spec_v1.json").read_text(
            encoding="utf-8"
        )
        return json.loads(schema_text)
    except Exception:
        pass
    path = _schema_path()
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


__all__ = [
    "EXPERIMENT_INTENT_SPEC_SCHEMA_ID",
    "ExperimentIntentSpecV1",
    "default_experiment_intent_spec",
    "experiment_intent_spec_from_dict",
    "experiment_intent_spec_from_dict_with_error",
    "experiment_intent_spec_json_bytes",
    "experiment_intent_spec_json_schema",
    "experiment_intent_spec_sha256",
    "experiment_intent_spec_to_dict",
    "intent_spec_missing_required_fields",
]
