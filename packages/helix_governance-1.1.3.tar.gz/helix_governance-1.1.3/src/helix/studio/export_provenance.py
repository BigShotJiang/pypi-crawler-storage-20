from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

EXPORT_PROVENANCE_SCHEMA_V1 = "helix_export_provenance_v1"


def _limitations_items(stamp: Mapping[str, Any] | None) -> list[dict[str, str]]:
    if not isinstance(stamp, Mapping):
        return []
    items: list[dict[str, str]] = []
    banner = str(stamp.get("banner") or "").strip()
    if banner:
        items.append({"code": "LIMITATIONS_BANNER", "message": banner})
    doc_slug = str(stamp.get("doc_slug") or "").strip()
    doc_version = str(stamp.get("doc_version") or "").strip()
    if doc_slug or doc_version:
        items.append({"code": "LIMITATIONS_DOC", "message": f"{doc_slug or 'unknown'}@{doc_version or 'unknown'}"})
    doc_last_updated = str(stamp.get("doc_last_updated") or "").strip()
    if doc_last_updated:
        items.append({"code": "LIMITATIONS_DOC_LAST_UPDATED", "message": doc_last_updated})
    timestamp_utc = str(stamp.get("timestamp_utc") or "").strip()
    if timestamp_utc:
        items.append({"code": "LIMITATIONS_EXPORTED_AT_UTC", "message": timestamp_utc})
    doc_url = str(stamp.get("doc_url") or "").strip()
    if doc_url:
        items.append({"code": "LIMITATIONS_DOC_URL", "message": doc_url})
    return items


def build_export_provenance_v1(
    *,
    export_kind: str,
    export_path: str | None = None,
    export_sha256: str | None = None,
    export_bytes: int | None = None,
    run_id: str | int | None = None,
    governance: Mapping[str, Any] | None = None,
    limitations_stamp: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    gov = dict(governance) if isinstance(governance, Mapping) else None
    stamp = dict(limitations_stamp) if isinstance(limitations_stamp, Mapping) else None

    decision_mode = None
    is_demo = False
    watermark = None
    if isinstance(gov, dict):
        dm = str(gov.get("decision_mode") or "").strip().lower()
        decision_mode = dm if dm else None
        is_demo = bool(gov.get("is_demo", False))
        watermark = str(gov.get("watermark") or "").strip() or None

    if decision_mode == "decision_grade":
        mode_class = "decision_grade"
    else:
        mode_class = "demo" if is_demo else "exploratory"

    export_obj: dict[str, Any] = {"kind": str(export_kind), "path": (str(export_path) if export_path else None)}
    if isinstance(export_sha256, str) and export_sha256.strip():
        export_obj["sha256"] = str(export_sha256).strip()
    if export_bytes is not None:
        try:
            export_obj["bytes"] = int(export_bytes)
        except Exception:
            pass

    return {
        "schema": EXPORT_PROVENANCE_SCHEMA_V1,
        "export": export_obj,
        "run": {"run_id": (str(run_id) if run_id is not None else None)},
        "mode_class": mode_class,
        "decision_mode": decision_mode,
        "decision_grade": bool(decision_mode == "decision_grade"),
        "is_demo": bool(is_demo),
        "export_label": watermark,
        "governance": gov,
        "limitations_stamp": stamp,
        "limitations": _limitations_items(stamp),
    }


def export_provenance_c14n_bytes(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(dict(payload), sort_keys=True, separators=(",", ":")).encode("utf-8")


def export_provenance_sha256(payload: Mapping[str, Any]) -> str:
    return hashlib.sha256(export_provenance_c14n_bytes(payload)).hexdigest()


def validate_export_provenance_v1(payload: Mapping[str, Any]) -> None:
    if not isinstance(payload, Mapping):
        raise ValueError("export provenance must be a mapping")
    schema = payload.get("schema")
    if schema != EXPORT_PROVENANCE_SCHEMA_V1:
        raise ValueError(f"unexpected schema: {schema!r}")
    export = payload.get("export")
    if not isinstance(export, Mapping):
        raise ValueError("export must be a mapping")
    kind = export.get("kind")
    if not isinstance(kind, str) or not kind.strip():
        raise ValueError("export.kind must be a non-empty string")
    sha = export.get("sha256")
    if sha is not None:
        if not isinstance(sha, str) or not sha.strip():
            raise ValueError("export.sha256 must be a string")
        token = sha.strip()
        if token.startswith("sha256:"):
            token = token[len("sha256:") :]
        if len(token) != 64 or any(ch not in "0123456789abcdef" for ch in token.lower()):
            raise ValueError("export.sha256 must be sha256:<64 hex>")
    run = payload.get("run")
    if run is not None and not isinstance(run, Mapping):
        raise ValueError("run must be a mapping or null")
    limitations = payload.get("limitations")
    if limitations is not None:
        if not isinstance(limitations, list):
            raise ValueError("limitations must be a list")
        for item in limitations:
            if not isinstance(item, Mapping):
                raise ValueError("limitations[] must be objects")
            code = item.get("code")
            msg = item.get("message")
            if not isinstance(code, str) or not code.strip():
                raise ValueError("limitations[].code must be a string")
            if not isinstance(msg, str) or not msg.strip():
                raise ValueError("limitations[].message must be a string")


__all__ = [
    "EXPORT_PROVENANCE_SCHEMA_V1",
    "build_export_provenance_v1",
    "export_provenance_c14n_bytes",
    "export_provenance_sha256",
    "validate_export_provenance_v1",
]
