from __future__ import annotations

import os
from typing import Final

from PySide6.QtCore import QSettings, Qt
from PySide6.QtWidgets import QApplication

SETTINGS_ORG: Final = "Helix"
SETTINGS_APP: Final = "Studio"

# Preset registry
PRESET_KEYS: Final = {
    "analysis": "presets/analysis",
    "simulation": "presets/simulation",
    "reporting": "presets/reporting",
    "genome_ide": "presets/genome_ide",
}


def _settings() -> QSettings:
    return QSettings(SETTINGS_ORG, SETTINGS_APP)

def _snapshot_non_preset_settings() -> dict[str, object]:
    """Capture all settings keys except factory preset storage."""
    snapshot: dict[str, object] = {}
    s = _settings()
    try:
        keys = list(s.allKeys())
    except Exception:
        keys = []
    for key in keys:
        if not isinstance(key, str) or not key:
            continue
        if key.startswith("presets/"):
            continue
        try:
            snapshot[key] = s.value(key)
        except Exception:
            continue
    return snapshot


def preset_exists(name: str) -> bool:
    base = PRESET_KEYS.get(name)
    if not base:
        return False
    s = _settings()
    return (
        s.value(f"{base}/geometry", None) is not None
        and s.value(f"{base}/state", None) is not None
    )


def save_preset(window, name: str) -> None:
    base = PRESET_KEYS[name]
    s = _settings()
    s.setValue(f"{base}/geometry", window.saveGeometry())
    s.setValue(f"{base}/state", window.saveState())


def load_preset(window, name: str) -> bool:
    base = PRESET_KEYS.get(name)
    if not base:
        return False
    s = _settings()
    state = s.value(f"{base}/state", None)
    if state is None:
        return False
    # Preserve the user's current window size/position; only restore docks/tabs.
    window.restoreState(state)
    return True


def ensure_default_presets(window, ctx=None) -> None:
    """Seed factory presets once; restore caller state afterwards."""
    settings_snapshot = _snapshot_non_preset_settings()
    seeded_any = False
    # Cache current state/geometry to avoid visual churn.
    #
    # Note: On the offscreen/minimal QPA, `restoreGeometry()` clamps the restored size
    # to the virtual screen (often 800×800), which breaks deterministic window sizing
    # in tests. Preserve the original size explicitly in that mode.
    current_geom = window.saveGeometry()
    try:
        current_rect = window.geometry()
    except Exception:
        current_rect = None
    current_state = window.saveState()
    platform = (os.environ.get("QT_QPA_PLATFORM", "") or QApplication.platformName() or "").strip().lower()

    if not preset_exists("analysis"):
        seeded_any = True
        _build_analysis_default(window)
        save_preset(window, "analysis")

    if not preset_exists("simulation"):
        seeded_any = True
        _build_simulation_default(window)
        save_preset(window, "simulation")

    if not preset_exists("reporting"):
        seeded_any = True
        _build_reporting_default(window)
        save_preset(window, "reporting")

    if not preset_exists("genome_ide"):
        seeded_any = True
        _build_genome_ide_default(window)
        save_preset(window, "genome_ide")

    try:
        if platform in {"offscreen", "minimal"} and current_rect is not None:
            window.setGeometry(current_rect)
        else:
            window.restoreGeometry(current_geom)
        window.restoreState(current_state)
    except Exception:
        pass

    # Preset seeding uses `reset_layout_to_defaults()` which clears some non-preset
    # continuity keys (e.g., last active tab). Restore pre-existing settings so
    # first-run preset generation doesn't wipe caller state.
    if seeded_any and settings_snapshot:
        s = _settings()
        for key, value in settings_snapshot.items():
            try:
                s.setValue(key, value)
            except Exception:
                continue
        try:
            s.sync()
        except Exception:
            pass


# ---- Default builders -------------------------------------------------


def _build_analysis_default(window) -> None:
    try:
        window.reset_layout_to_defaults()
    except Exception:
        pass

    left = getattr(window, "left_tabs", lambda: None)()
    center = getattr(window, "center_tabs", lambda: None)()
    right = getattr(window, "right_tabs", lambda: None)()
    console_dock = getattr(window, "console_dock", getattr(window, "log_dock", lambda: None))()

    _select_tab_by_prefix(left, "Run")
    _select_tab_by_substring(center, "Workflow") or _select_first(center)
    _select_tab_by_substring(right, "Guide") or _select_tab_by_substring(right, "Session")

    _show_console_compact(window, console_dock)


def _build_simulation_default(window) -> None:
    try:
        window.reset_layout_to_defaults()
    except Exception:
        pass

    left = getattr(window, "left_tabs", lambda: None)()
    center = getattr(window, "center_tabs", lambda: None)()
    right = getattr(window, "right_tabs", lambda: None)()
    console_dock = getattr(window, "console_dock", getattr(window, "log_dock", lambda: None))()

    _select_tab_by_prefix(left, "Sim") or _select_first(left)
    _select_tab_by_substring(center, "2.5d") or _select_tab_by_substring(center, "Realtime") or _select_first(center)
    _select_tab_by_substring(right, "Session") or _select_first(right)

    _show_console_compact(window, console_dock)
    try:
        window._apply_split_ratio([4, 8, 3])
    except Exception:
        pass


def _build_reporting_default(window) -> None:
    try:
        window.reset_layout_to_defaults()
    except Exception:
        pass

    left = getattr(window, "left_tabs", lambda: None)()
    center = getattr(window, "center_tabs", lambda: None)()
    right = getattr(window, "right_tabs", lambda: None)()
    console_dock = getattr(window, "console_dock", getattr(window, "log_dock", lambda: None))()

    _select_tab_by_prefix(left, "Run") or _select_first(left)
    _select_tab_by_substring(center, "Workflow") or _select_tab_by_substring(center, "Realtime") or _select_first(center)
    _select_tab_by_substring(right, "Compare") or _select_tab_by_substring(right, "Run") or _select_first(right)

    _show_console_compact(window, console_dock)


def _build_genome_ide_default(window) -> None:
    try:
        window.reset_layout_to_defaults()
    except Exception:
        pass

    left = getattr(window, "left_tabs", lambda: None)()
    center = getattr(window, "center_tabs", lambda: None)()
    right = getattr(window, "right_tabs", lambda: None)()
    console_dock = getattr(window, "console_dock", getattr(window, "log_dock", lambda: None))()

    _select_tab_by_prefix(left, "Run") or _select_first(left)
    _select_tab_by_substring(center, "Workflow") or _select_first(center)
    _select_tab_by_substring(right, "Session") or _select_first(right)

    try:
        window._apply_split_ratio([4, 9, 4])
    except Exception:
        pass

    _show_console_compact(window, console_dock)

    explorer = getattr(window, "workflow_panel", None)
    explorer_widget = getattr(explorer, "_explorer", None)
    try:
        if explorer_widget is not None:
            explorer_widget.apply_default_layout()
    except Exception:
        pass


# ---- Tab helpers ------------------------------------------------------


def _select_tab_by_prefix(tabs, prefix: str) -> bool:
    if tabs is None:
        return False
    needle = prefix.lower()
    for idx in range(tabs.count()):
        if tabs.tabText(idx).lower().startswith(needle):
            tabs.setCurrentIndex(idx)
            return True
    return False


def _select_tab_by_substring(tabs, needle: str) -> bool:
    if tabs is None:
        return False
    n = needle.lower()
    for idx in range(tabs.count()):
        if n in tabs.tabText(idx).lower():
            tabs.setCurrentIndex(idx)
            return True
    return False


def _select_first(tabs) -> bool:
    if tabs is None or tabs.count() == 0:
        return False
    tabs.setCurrentIndex(0)
    return True


def _show_console_compact(window, console_dock) -> None:
    if console_dock is None:
        return
    try:
        console_dock.show()
        window.resizeDocks([console_dock], [int(window.height() * 0.22)], Qt.Vertical)
        window._apply_default_splitter_sizes()
    except Exception:
        pass
