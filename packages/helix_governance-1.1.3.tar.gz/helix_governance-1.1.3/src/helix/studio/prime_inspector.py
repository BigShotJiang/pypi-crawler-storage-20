from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Qt, QPointF
from PySide6.QtGui import QPainter, QPen, QColor, QFont
from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel

from .ui_tokens import base_font, SPACING_SMALL


class PrimeInspector(QFrame):
    """Lightweight 1D rail visual for prime editing context."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("PrimeInspector")
        self.setFont(base_font())
        self.setFrameShape(QFrame.NoFrame)
        self.setMinimumHeight(110)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(SPACING_SMALL)
        self._title = QLabel("Prime inspector", self)
        self._title.setStyleSheet("color: #e5e7eb; font-weight: 600;")
        self._subtitle = QLabel("Select an intended edit to inspect peg/pam/nick.", self)
        self._subtitle.setStyleSheet("color: #9ca3af; font-size: 11px;")
        layout.addWidget(self._title)
        layout.addWidget(self._subtitle)
        self._info = QLabel("", self)
        self._info.setStyleSheet("color: #cbd5e1; font-size: 11px;")
        layout.addWidget(self._info)
        layout.addStretch(1)
        self._prime: Optional[dict] = None
        self._edit: Optional[dict] = None

    def set_context(self, prime_cfg: Optional[dict], edit_spec: Optional[dict]) -> None:
        self._prime = prime_cfg or None
        self._edit = edit_spec or None
        if not self._prime:
            self.hide()
            return
        self.show()
        spacer_start = self._prime.get("spacer_start", 0)
        spacer_len = self._prime.get("spacer_len", 20)
        pam = self._prime.get("pam_start", 0)
        pam_len = self._prime.get("pam_len", 3)
        pbs_len = self._prime.get("pbs_len", 13)
        rtt_len = self._prime.get("rtt_len", 12)
        nick = (self._prime.get("nicking_guide", {}) or {}).get("offset")
        edit_pos = (self._edit or {}).get("pos")
        self._info.setText(
            f"Spacer {spacer_start}-{spacer_start+spacer_len} · PAM {pam}-{pam+pam_len} · PBS {pbs_len} nt · RTT {rtt_len} nt"
            + (f" · Nick {nick}" if nick is not None else "")
            + (f" · Edit @ {edit_pos}" if edit_pos is not None else "")
        )
        self.update()

    def paintEvent(self, event):  # type: ignore[override]
        super().paintEvent(event)
        if not self._prime:
            return
        p = QPainter(self)
        try:
            p.setRenderHint(QPainter.Antialiasing, True)
            rect = self.rect().adjusted(10, 50, -10, -10)
            if rect.width() <= 0:
                return

            spacer_start = self._prime.get("spacer_start", 0)
            spacer_len = self._prime.get("spacer_len", 20)
            pam_start = self._prime.get("pam_start", spacer_start + spacer_len)
            pam_len = self._prime.get("pam_len", 3)
            pbs_len = self._prime.get("pbs_len", 13)
            rtt_len = self._prime.get("rtt_len", 12)
            edit_pos = (self._edit or {}).get("pos", spacer_start + spacer_len + pbs_len + 1)
            nick = (self._prime.get("nicking_guide", {}) or {}).get("offset", edit_pos + rtt_len // 2)
            end = max(pam_start + pam_len, edit_pos + rtt_len, nick + 1, spacer_start + spacer_len + pbs_len + rtt_len)
            start = max(0, spacer_start - 10)
            span = max(1, end - start)

            def px(pos: int) -> float:
                return rect.left() + (pos - start) / span * rect.width()

            rail_pen = QPen(QColor(76, 86, 106), 2)
            p.setPen(rail_pen)
            p.drawLine(px(start), rect.center().y(), px(end), rect.center().y())

            def block(x0, x1, color: QColor, label: str):
                y0 = rect.center().y() - 12
                y1 = rect.center().y() + 12
                p.fillRect(int(x0), y0, int(x1 - x0), y1 - y0, color)
                p.setPen(QPen(color.darker(120), 1.5))
                p.drawRect(int(x0), y0, int(x1 - x0), y1 - y0)
                p.setPen(QPen(QColor("#e5e7eb")))
                p.setFont(QFont(self.font().family(), 9, QFont.Medium))
                p.drawText(int((x0 + x1) / 2) - 40, y0 - 6, 80, 14, Qt.AlignCenter, label)

            spacer_x0, spacer_x1 = px(spacer_start), px(spacer_start + spacer_len)
            block(spacer_x0, spacer_x1, QColor(59, 130, 246, 180), "Spacer")

            pam_x0, pam_x1 = px(pam_start), px(pam_start + pam_len)
            block(pam_x0, pam_x1, QColor(244, 114, 182, 180), "PAM")

            pbs_x0, pbs_x1 = spacer_x1, spacer_x1 + (px(spacer_start + spacer_len + pbs_len) - spacer_x1)
            block(pbs_x0, pbs_x1, QColor(94, 234, 212, 120), "PBS")

            rtt_x0, rtt_x1 = pbs_x1, pbs_x1 + (px(spacer_start + spacer_len + pbs_len + rtt_len) - pbs_x1)
            block(rtt_x0, rtt_x1, QColor(190, 242, 100, 120), "RTT")

            p.setPen(QPen(QColor("#fbbf24"), 2.2))
            p.drawLine(px(edit_pos), rect.top(), px(edit_pos), rect.bottom())
            p.drawText(int(px(edit_pos)) - 30, rect.top() - 6, 60, 14, Qt.AlignCenter, "Edit")

            if nick is not None:
                p.setPen(QPen(QColor("#a78bfa"), 2.0, Qt.DashLine))
                p.drawLine(px(nick), rect.top(), px(nick), rect.bottom())
                p.drawText(int(px(nick)) - 40, rect.bottom() + 6, 80, 14, Qt.AlignCenter, "Nick")
        finally:
            p.end()
