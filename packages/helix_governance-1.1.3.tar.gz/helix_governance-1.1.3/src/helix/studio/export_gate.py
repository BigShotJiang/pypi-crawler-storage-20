from __future__ import annotations

from dataclasses import dataclass
from typing import Any, MutableMapping

from helix.studio.governance_stamp import normalize_decision_mode


@dataclass(frozen=True)
class ExportDecisionContext:
    decision_mode: str  # "decision_grade" | "filter_only"
    is_demo: bool
    run_id: str | int | None = None

    @property
    def mode_class(self) -> str:
        if self.decision_mode == "decision_grade":
            return "decision_grade"
        return "demo" if bool(self.is_demo) else "exploratory"

    @property
    def ack_key(self) -> str:
        """
        Return the session-scoped suppression key for the export gate prompt.

        Format:
          - decision-grade: "decision_grade" (never prompts; included for completeness)
          - exploratory/demo: "{mode_class}:{scope_id}"

        Where:
          - mode_class is "exploratory" or "demo"
          - scope_id is the run_id when available, else the literal "session"

        This ensures demo/exploratory acknowledgements do not cross-contaminate, and run-specific
        acknowledgements do not silently suppress prompts for different runs.
        """
        mode = self.mode_class
        if mode == "decision_grade":
            return mode
        rid = str(self.run_id).strip() if self.run_id is not None else ""
        scope = rid if rid else "session"
        return f"{mode}:{scope}"


def build_export_context(*, decision_mode: Any, is_demo: bool, run_id: Any = None) -> ExportDecisionContext:
    mode = normalize_decision_mode(decision_mode)
    rid: str | int | None
    if isinstance(run_id, (int, str)) and str(run_id).strip():
        rid = run_id
    else:
        rid = None
    return ExportDecisionContext(decision_mode=mode, is_demo=bool(is_demo), run_id=rid)


def should_prompt_export(ctx: ExportDecisionContext, session_acks: MutableMapping[str, bool]) -> bool:
    if ctx.decision_mode == "decision_grade":
        return False
    return not bool(session_acks.get(ctx.ack_key, False))


def set_export_prompt_suppressed(ctx: ExportDecisionContext, session_acks: MutableMapping[str, bool]) -> None:
    if ctx.decision_mode != "decision_grade":
        session_acks[ctx.ack_key] = True


__all__ = [
    "ExportDecisionContext",
    "build_export_context",
    "should_prompt_export",
    "set_export_prompt_suppressed",
]
