from __future__ import annotations

from dataclasses import replace

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QButtonGroup,
    QComboBox,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QRadioButton,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from helix.studio.target_field import TargetToken


class TargetRefineDrawer(QFrame):
    applied = Signal(object)  # TargetToken
    cancelled = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._build = "hg38"
        self._token: TargetToken | None = None

        self.setFrameShape(QFrame.StyledPanel)
        self.setStyleSheet("QFrame { border: 1px solid palette(mid); border-radius: 8px; }")
        self.setMinimumWidth(360)
        self.setMaximumWidth(460)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(10)

        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(8)
        title = QLabel("Refine target", self)
        title.setStyleSheet("font-weight: 650; font-size: 13px; color: palette(window-text);")
        header.addWidget(title)
        header.addStretch(1)
        close_btn = QPushButton("Close", self)
        close_btn.setFlat(True)
        close_btn.setProperty("role", "link")
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.clicked.connect(self._on_cancel_clicked)
        header.addWidget(close_btn)
        root.addLayout(header)

        summary = QLabel("", self)
        summary.setWordWrap(True)
        summary.setStyleSheet("color: palette(mid); font-size: 12px;")
        self._summary = summary
        root.addWidget(summary)

        type_row = QHBoxLayout()
        type_row.setContentsMargins(0, 0, 0, 0)
        type_row.setSpacing(8)
        type_label = QLabel("Target type:", self)
        type_label.setStyleSheet("color: palette(window-text); font-size: 12px;")
        type_row.addWidget(type_label)

        group = QButtonGroup(self)
        self._type_group = group
        self._type_gene = QRadioButton("Gene", self)
        self._type_locus = QRadioButton("Locus", self)
        self._type_variant = QRadioButton("Variant", self)
        self._type_panel = QRadioButton("Panel", self)
        for idx, rb in enumerate((self._type_gene, self._type_locus, self._type_variant, self._type_panel)):
            group.addButton(rb, idx)
            type_row.addWidget(rb)
        type_row.addStretch(1)
        root.addLayout(type_row)

        stack = QStackedWidget(self)
        self._stack = stack
        self._stack.addWidget(self._build_gene_page())
        self._stack.addWidget(self._build_locus_page())
        self._stack.addWidget(self._build_variant_page())
        self._stack.addWidget(self._build_panel_page())
        root.addWidget(stack, stretch=1)

        implications = QLabel("", self)
        implications.setWordWrap(True)
        implications.setStyleSheet("color: palette(mid); font-size: 12px;")
        self._implications = implications
        root.addWidget(implications)

        warn = QLabel("", self)
        warn.setWordWrap(True)
        warn.setStyleSheet("color: palette(mid); font-size: 12px;")
        warn.hide()
        self._warning = warn
        root.addWidget(warn)

        actions = QHBoxLayout()
        actions.setContentsMargins(0, 0, 0, 0)
        actions.addStretch(1)
        cancel_btn = QPushButton("Cancel", self)
        cancel_btn.clicked.connect(self._on_cancel_clicked)
        actions.addWidget(cancel_btn)
        save_btn = QPushButton("Save", self)
        save_btn.setProperty("role", "btnPrimary")
        save_btn.clicked.connect(self._on_save_clicked)
        actions.addWidget(save_btn)
        root.addLayout(actions)

        group.idClicked.connect(self._on_type_changed)  # type: ignore[arg-type]

    def set_reference_build(self, build: str) -> None:
        self._build = str(build or "").strip() or "hg38"
        if self._token is not None:
            self._token = replace(self._token, build=self._build)
        self._update_summary()

    def set_token(self, token: TargetToken) -> None:
        self._token = replace(token, build=self._build)
        kind = str(self._token.kind or "").strip() or "freeform"
        if kind == "locus":
            self._type_locus.setChecked(True)
        elif kind == "variant":
            self._type_variant.setChecked(True)
        elif kind == "panel":
            self._type_panel.setChecked(True)
        else:
            self._type_gene.setChecked(True)

        self._populate_from_token(self._token)
        self._update_summary()
        self._update_implications()
        self._warning.hide()

    def focus_first(self) -> None:
        page = self._stack.currentWidget()
        if page is None:
            return
        for child in page.findChildren(QLineEdit):
            if child.isVisible():
                try:
                    child.setFocus(Qt.TabFocusReason)
                except Exception:
                    pass
                return

    # ---- Pages ----

    def _build_gene_page(self) -> QWidget:
        page = QWidget(self)
        form = QFormLayout(page)
        form.setContentsMargins(0, 0, 0, 0)
        form.setHorizontalSpacing(10)
        form.setVerticalSpacing(8)

        self._gene_symbol = QLineEdit(page)
        self._gene_symbol.setPlaceholderText("Gene symbol (e.g., TP53)")
        form.addRow("Gene", self._gene_symbol)

        self._transcript_mode = QComboBox(page)
        self._transcript_mode.addItem("Canonical (recommended)", "canonical")
        self._transcript_mode.addItem("Specify transcript ID…", "custom")
        form.addRow("Transcript", self._transcript_mode)

        self._transcript_id = QLineEdit(page)
        self._transcript_id.setPlaceholderText("ENST… (optional)")
        form.addRow("Transcript ID", self._transcript_id)

        self._window_mode = QComboBox(page)
        self._window_mode.addItem("No window (default)", "none")
        self._window_mode.addItem("Early constitutive exon (hint)", "early_constitutive_exon")
        self._window_mode.addItem("Custom window…", "custom")
        form.addRow("Target window", self._window_mode)

        self._window_coords = QLineEdit(page)
        self._window_coords.setPlaceholderText("chr:start-end (e.g., chr17:7,576,000-7,590,000)")
        form.addRow("Window", self._window_coords)

        self._transcript_mode.currentIndexChanged.connect(self._sync_gene_visibility)  # type: ignore[arg-type]
        self._window_mode.currentIndexChanged.connect(self._sync_gene_visibility)  # type: ignore[arg-type]
        self._sync_gene_visibility()
        return page

    def _build_locus_page(self) -> QWidget:
        page = QWidget(self)
        form = QFormLayout(page)
        form.setContentsMargins(0, 0, 0, 0)
        form.setHorizontalSpacing(10)
        form.setVerticalSpacing(8)

        self._locus_coords = QLineEdit(page)
        self._locus_coords.setPlaceholderText("chr:start-end (e.g., chr17:7,576,000-7,590,000)")
        form.addRow("Locus", self._locus_coords)
        return page

    def _build_variant_page(self) -> QWidget:
        page = QWidget(self)
        form = QFormLayout(page)
        form.setContentsMargins(0, 0, 0, 0)
        form.setHorizontalSpacing(10)
        form.setVerticalSpacing(8)

        self._variant_id = QLineEdit(page)
        self._variant_id.setPlaceholderText("rs123 (or HGVS if available)")
        form.addRow("Variant", self._variant_id)
        return page

    def _build_panel_page(self) -> QWidget:
        page = QWidget(self)
        form = QFormLayout(page)
        form.setContentsMargins(0, 0, 0, 0)
        form.setHorizontalSpacing(10)
        form.setVerticalSpacing(8)

        self._panel_text = QLineEdit(page)
        self._panel_text.setPlaceholderText("Comma-separated targets (e.g., TP53, BRCA1, chr17:...)")
        form.addRow("Panel", self._panel_text)
        return page

    def _sync_gene_visibility(self) -> None:
        mode = str(self._transcript_mode.currentData() or "canonical")
        self._transcript_id.setVisible(mode == "custom")
        wmode = str(self._window_mode.currentData() or "none")
        self._window_coords.setVisible(wmode == "custom")

    # ---- Actions ----

    def _on_type_changed(self, idx: int) -> None:
        self._stack.setCurrentIndex(int(idx))
        self._sync_gene_visibility()
        self._update_implications()
        self._warning.hide()

    def _on_cancel_clicked(self) -> None:
        self._warning.hide()
        self.cancelled.emit()

    def _on_save_clicked(self) -> None:
        token = self._build_token_from_ui()
        if token is None:
            return
        self.applied.emit(token)

    def _build_token_from_ui(self) -> TargetToken | None:
        self._warning.hide()
        build = self._build

        idx = int(self._type_group.checkedId())
        if idx == 0:  # Gene
            gene = str(self._gene_symbol.text() or "").strip().upper()
            if not gene:
                return self._fail("Gene symbol is required.")
            transcript = None
            if str(self._transcript_mode.currentData() or "canonical") == "custom":
                transcript = str(self._transcript_id.text() or "").strip().upper() or None

            window = None
            window_mode = None
            wmode = str(self._window_mode.currentData() or "none")
            if wmode == "early_constitutive_exon":
                window_mode = "early_constitutive_exon"
            elif wmode == "custom":
                window = str(self._window_coords.text() or "").strip()
                if not window:
                    return self._fail("Custom window requires coordinates.")

            return TargetToken(
                primary=gene,
                build=build,
                kind="gene",
                transcript=transcript,
                window=window,
                window_mode=window_mode,
            )

        if idx == 1:  # Locus
            raw = str(self._locus_coords.text() or "").strip()
            token = TargetToken.tokenize(raw, build=build)
            if token is None or token.kind != "locus":
                return self._fail("Locus must match chr:start-end.")
            return token

        if idx == 2:  # Variant
            raw = str(self._variant_id.text() or "").strip()
            token = TargetToken.tokenize(raw, build=build)
            if token is None or token.kind != "variant":
                return self._fail("Variant must be an rsID (e.g., rs123).")
            return token

        if idx == 3:  # Panel
            raw = str(self._panel_text.text() or "").strip()
            token = TargetToken.tokenize(raw, build=build)
            if token is None or token.kind != "panel":
                return self._fail("Panel should be a comma-separated list of targets.")
            return token

        return self._fail("Unsupported target type.")

    def _fail(self, message: str) -> None:
        try:
            self._warning.setText(str(message))
            self._warning.show()
        except Exception:
            pass
        return None

    # ---- Presentation ----

    def _populate_from_token(self, token: TargetToken) -> None:
        kind = str(token.kind or "").strip()
        if kind == "locus":
            self._stack.setCurrentIndex(1)
            self._locus_coords.setText(str(token.primary or "").strip())
        elif kind == "variant":
            self._stack.setCurrentIndex(2)
            self._variant_id.setText(str(token.primary or "").strip())
        elif kind == "panel":
            self._stack.setCurrentIndex(3)
            self._panel_text.setText(str(token.primary or "").strip())
        else:
            self._stack.setCurrentIndex(0)
            self._gene_symbol.setText(str(token.primary or "").strip())
            if token.transcript:
                self._transcript_mode.setCurrentIndex(max(0, self._transcript_mode.findData("custom")))
                self._transcript_id.setText(str(token.transcript or "").strip())
            else:
                self._transcript_mode.setCurrentIndex(max(0, self._transcript_mode.findData("canonical")))
                self._transcript_id.setText("")

            if token.window_mode == "early_constitutive_exon":
                self._window_mode.setCurrentIndex(max(0, self._window_mode.findData("early_constitutive_exon")))
                self._window_coords.setText("")
            elif token.window:
                self._window_mode.setCurrentIndex(max(0, self._window_mode.findData("custom")))
                self._window_coords.setText(str(token.window or "").strip())
            else:
                self._window_mode.setCurrentIndex(max(0, self._window_mode.findData("none")))
                self._window_coords.setText("")

        self._sync_gene_visibility()

    def _update_summary(self) -> None:
        token = self._token
        build = self._build
        if token is None:
            self._summary.setText(f"Build: {build}")
            return
        self._summary.setText(f"Target: {token.display_line()}")

    def _update_implications(self) -> None:
        idx = int(self._type_group.checkedId())
        affects_guides = True
        if idx == 1:  # locus
            affects_guides = True
        if idx == 2:  # variant
            affects_guides = True
        guide_line = "Affects guides: yes" if affects_guides else "Affects guides: no"
        self._implications.setText(f"{guide_line} (non-blocking preview)")


__all__ = ["TargetRefineDrawer"]
