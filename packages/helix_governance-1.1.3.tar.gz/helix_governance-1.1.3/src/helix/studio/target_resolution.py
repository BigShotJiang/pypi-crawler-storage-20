from __future__ import annotations

import re
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any, Literal


_LOCUS_RE = re.compile(r"^\s*(?P<contig>[^:\s]+)\s*:\s*(?P<start>[\d,]+)\s*(?:[-–]\s*(?P<end>[\d,]+)\s*)?$")


def _norm_int(value: str) -> int:
    return int(str(value).replace(",", ""))


def _canon_contig_for_ensembl(contig: str) -> str:
    c = str(contig or "").strip()
    if not c:
        return ""
    low = c.lower()
    if low.startswith("chr"):
        c = c[3:]
    if c in {"M", "m", "MT", "Mt", "mt"}:
        return "MT"
    return c


def species_for_reference_build(build: str) -> str | None:
    key = str(build or "").strip().lower()
    if key == "hg38":
        return "human"
    if key == "mm10":
        return "mouse"
    return None


@dataclass(frozen=True)
class RegionSpan:
    build: str
    contig: str
    start1: int
    end1: int

    @property
    def length_bp(self) -> int:
        return max(1, int(self.end1) - int(self.start1) + 1)

    def to_dict(self) -> dict[str, Any]:
        return {
            "build": self.build,
            "contig": self.contig,
            "start1": int(self.start1),
            "end1": int(self.end1),
            "lengthBp": int(self.length_bp),
            "coordinateSystem": "1-based-inclusive",
        }


def parse_locus_primary(primary: str, *, build: str) -> RegionSpan | None:
    m = _LOCUS_RE.match(str(primary or "").strip())
    if not m:
        return None
    contig = str(m.group("contig") or "").strip()
    start = _norm_int(m.group("start"))
    end_raw = m.group("end")
    end = _norm_int(end_raw) if end_raw else start
    if end < start:
        start, end = end, start
    return RegionSpan(build=str(build or "").strip(), contig=contig, start1=int(start), end1=int(end))


@dataclass(frozen=True)
class OverlapGene:
    gene_id: str
    symbol: str
    biotype: str | None
    start1: int | None
    end1: int | None
    strand: int | None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"geneId": self.gene_id, "symbol": self.symbol}
        if self.biotype:
            payload["biotype"] = self.biotype
        if self.start1 is not None:
            payload["start1"] = int(self.start1)
        if self.end1 is not None:
            payload["end1"] = int(self.end1)
        if self.strand is not None:
            payload["strand"] = int(self.strand)
        return payload


@dataclass(frozen=True)
class GeneExonSummary:
    gene_id: str
    symbol: str
    canonical_transcript: str | None
    overlapped_exon_indices: tuple[int, ...]
    constitutive_exon_indices: tuple[int, ...]

    @property
    def exon_range(self) -> str:
        if not self.overlapped_exon_indices:
            return ""
        lo = min(self.overlapped_exon_indices)
        hi = max(self.overlapped_exon_indices)
        return f"{lo}–{hi}" if lo != hi else f"{lo}"

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "geneId": self.gene_id,
            "symbol": self.symbol,
            "canonicalTranscript": self.canonical_transcript,
            "overlappedExonIndices": list(self.overlapped_exon_indices),
            "constitutiveExonIndices": list(self.constitutive_exon_indices),
        }
        if self.exon_range:
            payload["overlappedExonRange"] = self.exon_range
        return payload


ScopeMode = Literal["unset", "gene", "multi", "noncoding", "custom"]


@dataclass(frozen=True)
class ScopeSelection:
    mode: ScopeMode = "unset"
    gene_id: str | None = None
    gene_symbol: str | None = None
    custom_label: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"mode": self.mode}
        if self.gene_id:
            payload["geneId"] = self.gene_id
        if self.gene_symbol:
            payload["geneSymbol"] = self.gene_symbol
        if self.custom_label:
            payload["customLabel"] = self.custom_label
        return payload


Verdict = Literal["compatible", "ambiguous", "incompatible"]


def evaluate_target_compatibility(
    *,
    target_type: str,
    region: RegionSpan,
    overlaps: list[OverlapGene],
    scope: ScopeSelection,
    coding_sequence_present: bool | None,
    constitutive_exons_affected: bool | None,
) -> dict[str, Any]:
    intent = str(target_type or "").strip().lower()
    reasons: list[str] = []
    warnings: list[str] = []

    if region.length_bp > 250_000:
        warnings.append("region_large")

    if len(overlaps) > 1 and scope.mode not in {"multi"}:
        warnings.append("multiple_overlapping_genes")

    if intent != "knockout":
        verdict: Verdict = "compatible"
        if scope.mode == "unset":
            verdict = "ambiguous"
            reasons.append("scope_unset")
        return {"verdict": verdict, "reasons": reasons, "warnings": warnings}

    # Knockout intent: require a coding-scoped feature.
    if scope.mode == "unset":
        return {"verdict": "ambiguous", "reasons": ["scope_unset"], "warnings": warnings}
    if scope.mode == "noncoding":
        return {"verdict": "incompatible", "reasons": ["non_coding_scope"], "warnings": warnings}
    if scope.mode == "multi":
        return {"verdict": "ambiguous", "reasons": ["multi_target_scope"], "warnings": warnings}

    if coding_sequence_present is False:
        reasons.append("no_coding_exons_in_region")
    if constitutive_exons_affected is False:
        reasons.append("no_constitutive_exons_affected")

    if reasons:
        return {"verdict": "incompatible", "reasons": reasons, "warnings": warnings}

    if coding_sequence_present is None or constitutive_exons_affected is None:
        return {
            "verdict": "ambiguous",
            "reasons": ["annotation_unavailable_or_incomplete"],
            "warnings": warnings,
        }

    return {"verdict": "compatible", "reasons": [], "warnings": warnings}


@dataclass
class TargetLocusResolutionState:
    token_primary: str
    build: str
    status: Literal["pending", "resolved", "unavailable"] = "pending"
    region: RegionSpan | None = None
    overlaps: list[OverlapGene] = field(default_factory=list)
    annotation: dict[str, Any] | None = None
    scope: ScopeSelection = field(default_factory=ScopeSelection)
    gene_summary: GeneExonSummary | None = None
    coding_sequence_present: bool | None = None
    constitutive_exons_affected: bool | None = None
    error: str | None = None

    def snapshot(self, *, target_type: str) -> dict[str, Any]:
        region = self.region
        if region is None:
            region = parse_locus_primary(self.token_primary, build=self.build)
        region_dict = region.to_dict() if region else None

        overlaps_sorted = sorted(
            self.overlaps,
            key=lambda g: (
                str(g.symbol or "").upper(),
                str(g.gene_id or "").upper(),
                int(g.start1 or 0),
                int(g.end1 or 0),
            ),
        )
        compat = (
            evaluate_target_compatibility(
                target_type=target_type,
                region=region,
                overlaps=overlaps_sorted,
                scope=self.scope,
                coding_sequence_present=self.coding_sequence_present,
                constitutive_exons_affected=self.constitutive_exons_affected,
            )
            if region
            else {"verdict": "ambiguous", "reasons": ["region_parse_failed"], "warnings": []}
        )

        payload: dict[str, Any] = {
            "version": "v1",
            "status": self.status,
            "input": {"primary": self.token_primary, "build": self.build},
            "region": region_dict,
            "annotation": self.annotation,
            "overlaps": [g.to_dict() for g in overlaps_sorted],
            "scope": self.scope.to_dict(),
            "geneSummary": self.gene_summary.to_dict() if self.gene_summary else None,
            "codingSequencePresent": self.coding_sequence_present,
            "constitutiveExonsAffected": self.constitutive_exons_affected,
            "compatibility": {"targetType": str(target_type or "").strip(), **compat},
            "error": str(self.error or "").strip() or None,
        }
        # Keep snapshot deterministic and small.
        return {k: v for k, v in payload.items() if v is not None}


@lru_cache(maxsize=1)
def _ensembl_software_release() -> int | None:
    try:
        import requests

        resp = requests.get(
            "https://rest.ensembl.org/info/software",
            headers={"Accept": "application/json"},
            timeout=2,
        )
        if not resp.ok:
            return None
        data = resp.json()
        release = data.get("release")
        return int(release) if release is not None else None
    except Exception:
        return None


def fetch_ensembl_region_overlaps(region: RegionSpan) -> tuple[list[OverlapGene], dict[str, Any] | None, str | None]:
    """
    Best-effort overlap query for gene features.

    Returns (genes, annotation_meta, error_message).
    """
    species = species_for_reference_build(region.build)
    if not species:
        return [], None, "No annotation provider for this reference build."
    try:
        import requests

        contig = _canon_contig_for_ensembl(region.contig)
        if not contig:
            return [], None, "Invalid contig."
        region_expr = f"{contig}:{int(region.start1)}-{int(region.end1)}"
        resp = requests.get(
            f"https://rest.ensembl.org/overlap/region/{species}/{region_expr}",
            params={"feature": "gene"},
            headers={"Accept": "application/json"},
            timeout=2,
        )
        if not resp.ok:
            return [], {"source": "EnsemblREST", "host": "rest.ensembl.org"}, f"HTTP {resp.status_code}"
        data = resp.json()
        genes: list[OverlapGene] = []
        if isinstance(data, list):
            for row in data:
                if not isinstance(row, dict):
                    continue
                if str(row.get("feature_type") or "").strip() != "gene":
                    continue
                gene_id = str(row.get("id") or row.get("gene_id") or "").strip()
                symbol = str(row.get("external_name") or row.get("display_name") or gene_id).strip()
                if not gene_id:
                    continue
                genes.append(
                    OverlapGene(
                        gene_id=gene_id,
                        symbol=symbol,
                        biotype=str(row.get("biotype") or "").strip() or None,
                        start1=int(row.get("start")) if row.get("start") is not None else None,
                        end1=int(row.get("end")) if row.get("end") is not None else None,
                        strand=int(row.get("strand")) if row.get("strand") is not None else None,
                    )
                )
        ann: dict[str, Any] = {"source": "EnsemblREST", "host": "rest.ensembl.org"}
        try:
            release = _ensembl_software_release()
            if release is not None:
                ann["release"] = int(release)
        except Exception:
            pass
        return genes, ann, None
    except Exception as exc:
        return [], {"source": "EnsemblREST", "host": "rest.ensembl.org"}, str(exc)


def fetch_ensembl_gene_exon_summary(*, gene: OverlapGene, region: RegionSpan) -> tuple[GeneExonSummary | None, bool | None, bool | None, str | None]:
    """
    Resolve exon overlap and a conservative 'constitutive exon' signal for a selected gene.

    Returns (summary, coding_sequence_present, constitutive_exons_affected, error_message).
    """
    species = species_for_reference_build(region.build)
    if not species:
        return None, None, None, "No annotation provider for this reference build."
    try:
        import requests

        resp = requests.get(
            f"https://rest.ensembl.org/lookup/id/{gene.gene_id}",
            params={"expand": "1"},
            headers={"Accept": "application/json"},
            timeout=3,
        )
        if not resp.ok:
            return None, None, None, f"HTTP {resp.status_code}"
        data = resp.json()
        if not isinstance(data, dict):
            return None, None, None, "Unexpected response."

        canonical = str(data.get("canonical_transcript") or "").strip() or None
        txs = data.get("Transcript") if isinstance(data.get("Transcript"), list) else []
        gene_strand = int(data.get("strand") or gene.strand or 1)

        canonical_base = canonical.split(".", maxsplit=1)[0] if canonical else None
        canonical_tx = None
        for tx in txs:
            if not isinstance(tx, dict):
                continue
            tx_id = str(tx.get("id") or "").strip()
            if not tx_id:
                continue
            if canonical_base and (tx_id == canonical_base or tx_id.split(".", maxsplit=1)[0] == canonical_base):
                canonical_tx = tx
                break
            if bool(tx.get("is_canonical")):
                canonical_tx = tx
        if canonical_tx is None and txs:
            canonical_tx = txs[0] if isinstance(txs[0], dict) else None

        exons = canonical_tx.get("Exon") if isinstance(canonical_tx, dict) and isinstance(canonical_tx.get("Exon"), list) else []
        exon_intervals: list[tuple[int, int]] = []
        for exon in exons:
            if not isinstance(exon, dict):
                continue
            if exon.get("start") is None or exon.get("end") is None:
                continue
            a = int(exon.get("start"))
            b = int(exon.get("end"))
            exon_intervals.append((min(a, b), max(a, b)))

        exon_intervals_sorted = sorted(exon_intervals, key=lambda p: p[0], reverse=(gene_strand < 0))
        overlapped_indices: list[int] = []
        overlapped_intervals: set[tuple[int, int]] = set()
        for idx, (a, b) in enumerate(exon_intervals_sorted, start=1):
            if b < region.start1 or a > region.end1:
                continue
            overlapped_indices.append(idx)
            overlapped_intervals.add((a, b))

        pc_txs = [t for t in txs if isinstance(t, dict) and str(t.get("biotype") or "").strip() == "protein_coding"]
        exon_sets: list[set[tuple[int, int]]] = []
        for tx in pc_txs:
            exons_tx = tx.get("Exon") if isinstance(tx.get("Exon"), list) else []
            s: set[tuple[int, int]] = set()
            for exon in exons_tx:
                if not isinstance(exon, dict):
                    continue
                if exon.get("start") is None or exon.get("end") is None:
                    continue
                a = int(exon.get("start"))
                b = int(exon.get("end"))
                s.add((min(a, b), max(a, b)))
            if s:
                exon_sets.append(s)
        constitutive: set[tuple[int, int]] = set.intersection(*exon_sets) if exon_sets else set()

        constitutive_indices: list[int] = []
        for idx, interval in enumerate(exon_intervals_sorted, start=1):
            if interval in constitutive:
                constitutive_indices.append(idx)

        constitutive_affected = any(interval in constitutive for interval in overlapped_intervals) if constitutive else False
        coding_present = bool(str(gene.biotype or "").strip() == "protein_coding") and bool(overlapped_indices)

        summary = GeneExonSummary(
            gene_id=gene.gene_id,
            symbol=gene.symbol,
            canonical_transcript=(canonical.split(".", maxsplit=1)[0] if canonical else None),
            overlapped_exon_indices=tuple(overlapped_indices),
            constitutive_exon_indices=tuple(constitutive_indices),
        )
        return summary, bool(coding_present), bool(constitutive_affected), None
    except Exception as exc:
        return None, None, None, str(exc)

