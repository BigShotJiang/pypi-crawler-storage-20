"""Heuristics for inferring a target locus from FASTA-like filenames.

The goal is to be conservative: surface high-confidence coordinate matches
first, fall back to gene/contig tokens, and return ``kind="unknown"`` when
signals are weak. This keeps downstream UI panels consistent and prevents
conflicting counts or silently wrong inferences.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class LocusGuess:
    """Parsed locus guess from a filename.

    Attributes
    ----------
    kind:
        One of ``"coords"``, ``"gene"``, ``"contig"``, ``"unknown"``.
    chrom, start, end:
        Coordinate fields (1-based, inclusive) when ``kind == "coords"``.
    gene:
        Gene-like token when ``kind == "gene"``.
    contig:
        Accession/contig token when ``kind == "contig"``.
    strand:
        Optional strand hint (``"+"`` or ``"-"``) if present in the filename.
    score:
        Heuristic confidence (0–1). Higher means more confident.
    evidence:
        Short human-readable description of what pattern matched.
    """

    kind: str  # "coords" | "gene" | "contig" | "unknown"
    chrom: Optional[str] = None
    start: Optional[int] = None
    end: Optional[int] = None
    gene: Optional[str] = None
    contig: Optional[str] = None
    strand: Optional[str] = None  # "+" | "-" | None
    score: float = 0.0
    evidence: Optional[str] = None


_CHR = r"(?:chr)?(?:[0-9]{1,2}|X|Y|M|MT)"
_NUM = r"(?:\d{1,3}(?:,\d{3})*|\d+)"  # accepts 1,234,567 or 1234567

# Coordinate patterns (highest confidence first)
_COORD_PATTERNS = [
    re.compile(rf"(?P<chrom>{_CHR})\s*[:_ -]\s*(?P<start>{_NUM})\s*(?:\.{2}|[-_])\s*(?P<end>{_NUM})", re.IGNORECASE),
    re.compile(rf"(?P<chrom>{_CHR})\s*[:_ -]\s*(?P<pos>{_NUM})\b", re.IGNORECASE),  # single position
]

_STRAND_PATTERN = re.compile(r"(?:^|[_\.\s-])(plus|\+|minus|-|fwd|rev|forward|reverse)(?:$|[_\.\s-])", re.IGNORECASE)

_CONTIG_PATTERN = re.compile(
    r"\b(ENSG\d+|ENST\d+|ENSMUSG\d+|ENSMUST\d+|NC_\d+|NG_\d+|NT_\d+|NW_\d+|NZ_[A-Z0-9]+|KI\d+\.\d+|GL\d+\.\d+)\b",
    re.IGNORECASE,
)

_GENE_PATTERN = re.compile(r"\b([A-Z][A-Z0-9]{1,9})\b")

_STOPWORDS = {
    "FASTA",
    "FA",
    "FNA",
    "SEQ",
    "SEQS",
    "SEQUENCE",
    "TARGET",
    "LOCUS",
    "REGION",
    "GENOME",
    "HUMAN",
    "MOUSE",
    "GRCH",
    "HG",
    "MM",
    "BUILD",
    "REF",
    "REFERENCE",
    "EDIT",
    "GUIDE",
    "WT",
    "MUT",
    "ALT",
    "VAR",
    "SNP",
    "INDEL",
    "PRIME",
    "CRISPR",
    "PAM",
    "NGG",
    "CAS9",
}


def _norm_num(text: str) -> int:
    return int(text.replace(",", ""))


def _infer_strand(text: str) -> Optional[str]:
    m = _STRAND_PATTERN.search(text)
    if not m:
        return None
    token = m.group(1).lower()
    if token in {"+", "plus", "fwd", "forward"}:
        return "+"
    if token in {"-", "minus", "rev", "reverse"}:
        return "-"
    return None


def _normalize_chrom(token: str) -> str:
    cleaned = token.lower().replace("chr", "chr").replace("mt", "M").replace("m", "M")
    if not cleaned.startswith("chr"):
        cleaned = "chr" + cleaned
    return cleaned


def infer_target_locus_from_filename(path: str) -> LocusGuess:
    """Infer a target locus from a FASTA/sequence filename.

    Parameters
    ----------
    path:
        Full path or basename of the file.

    Returns
    -------
    LocusGuess
        Structured guess with confidence score and evidence string.
    """

    base = os.path.basename(path)
    name, _ext = os.path.splitext(base)

    text = name.replace("__", "_")
    strand = _infer_strand(text)

    # 1) Coordinates (highest confidence)
    for pat in _COORD_PATTERNS:
        match = pat.search(text)
        if not match:
            continue

        groups = match.groupdict()
        chrom = groups.get("chrom")
        if chrom:
            chrom = _normalize_chrom(chrom)

        if "start" in groups and "end" in groups and groups["start"] and groups["end"]:
            start = _norm_num(groups["start"])
            end = _norm_num(groups["end"])
            if start > end:
                start, end = end, start
            return LocusGuess(
                kind="coords",
                chrom=chrom,
                start=start,
                end=end,
                strand=strand,
                score=0.98,
                evidence=f"matched coords pattern: {match.group(0)}",
            )

        if "pos" in groups and chrom:
            pos = _norm_num(groups["pos"])
            return LocusGuess(
                kind="coords",
                chrom=chrom,
                start=pos,
                end=pos,
                strand=strand,
                score=0.90,
                evidence=f"matched single position: {match.group(0)}",
            )

    # 2) Contig/accession tokens
    contig_match = _CONTIG_PATTERN.search(text)
    if contig_match:
        token = contig_match.group(1)
        return LocusGuess(
            kind="contig",
            contig=token,
            strand=strand,
            score=0.75,
            evidence=f"matched contig token: {token}",
        )

    # 3) Gene-like token heuristic
    tokens = re.split(r"[^A-Za-z0-9]+", text)
    candidates: list[tuple[float, str]] = []
    for tok in tokens:
        if not tok:
            continue
        upper = tok.upper()
        if upper in _STOPWORDS:
            continue
        if re.fullmatch(r"[0-9]+", tok):
            continue
        if re.fullmatch(_CHR, upper, flags=re.IGNORECASE):
            continue
        if not _GENE_PATTERN.fullmatch(upper):
            continue
        # Heuristic score prefers shorter symbols but keeps space for things like BRCA1
        score = 0.55 + max(0, (10 - len(upper))) * 0.02
        candidates.append((score, upper))

    if candidates:
        candidates.sort(reverse=True)
        best_score, gene = candidates[0]
        return LocusGuess(
            kind="gene",
            gene=gene,
            strand=strand,
            score=min(0.85, best_score),
            evidence=f"best gene-like token from filename: {gene}",
        )

    return LocusGuess(kind="unknown", strand=strand, score=0.0, evidence="no recognizable locus tokens")


def canonical_coord_string(guess: LocusGuess) -> Optional[str]:
    """Return canonical ``chr:start-end`` string if coordinates are present."""

    if guess.kind != "coords" or not (guess.chrom and guess.start is not None and guess.end is not None):
        return None
    return f"{guess.chrom}:{guess.start}-{guess.end}"


__all__ = ["LocusGuess", "infer_target_locus_from_filename", "canonical_coord_string"]
