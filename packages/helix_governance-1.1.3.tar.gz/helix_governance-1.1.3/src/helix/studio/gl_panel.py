from __future__ import annotations

import io
import math
import time
from collections.abc import Mapping
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional, Callable, Sequence

import numpy as np

from helix import clock
from helix import temp
try:  # Make Qt optional for headless/test environments.
    from PySide6.QtCore import QEvent, QObject, QPoint, Qt, QTimer, Signal
    from PySide6.QtCore import QRect, QRectF
    from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPalette, QPen
    from PySide6.QtWidgets import (
        QApplication,
        QCheckBox,
        QComboBox,
        QFileDialog,
        QGraphicsOpacityEffect,
        QHBoxLayout,
        QLabel,
        QPushButton,
        QSlider,
        QStyle,
        QStyleOptionSlider,
        QStackedLayout,
        QToolTip,
        QTabWidget,
        QVBoxLayout,
        QWidget,
    )
    _HAS_QT = True
except Exception:  # pragma: no cover - exercised only in headless CI
    Qt = None  # type: ignore[assignment]
    QEvent = None  # type: ignore[assignment]
    QObject = None  # type: ignore[assignment]
    QTimer = None  # type: ignore[assignment]
    QPoint = None  # type: ignore[assignment]
    QRect = None  # type: ignore[assignment]
    QRectF = None  # type: ignore[assignment]
    QColor = QFont = QImage = QPainter = QPalette = QPen = None  # type: ignore[assignment]
    QStyle = QStyleOptionSlider = QToolTip = None  # type: ignore[assignment]
    Signal = lambda *args, **kwargs: None  # type: ignore[assignment]
    QApplication = object  # type: ignore[assignment]
    QGraphicsOpacityEffect = object  # type: ignore[assignment]
    QCheckBox = QComboBox = QFileDialog = QHBoxLayout = QLabel = QPushButton = QStackedLayout = QSlider = QVBoxLayout = QWidget = QTabWidget = object  # type: ignore[assignment]
    _HAS_QT = False

from helix.gui.modern.builders import (
    build_crispr_orbitals_3d_spec,
    build_crispr_rail_3d_spec,
    build_crispr_viz_spec,
    build_prime_scaffold_3d_spec,
    build_prime_viz_spec,
)
from helix.gui.modern.dag_adapters import crispr_dag_to_viz_spec, crispr_dag_to_workflow

if TYPE_CHECKING:  # pragma: no cover
    pass
from helix.gui.modern.spec import EditVisualizationSpec, load_viz_spec
from helix.gui.railbands.widget import RailBandWidget
from helix.studio.outcomes.hotspots import build_hotspot_segments
from helix.studio.outcomes.prime_overlay import build_prime_overlay
from helix.studio.outcomes.base_overlay import build_base_overlay
from helix.studio.outcomes.model import compute_outcomes_for_current_plan, outcome_report_json_bytes
from helix.studio.run_metrics import (
    RunMetrics,
    classify_run_quality,
    compute_run_metrics,
)
from helix.studio.export_clip import (
    build_capture_metadata,
    compute_clip_window,
    detect_mp4_encoder,
    frame_times_seconds,
    write_clip_zip,
)
from helix.studio.locus_fit import fit_time_window_to_event_cluster
from helix.studio.session import ExperimentState, RunKind, SessionModel
from helix.studio.export_gate import build_export_context
from helix.studio.governance_stamp import (
    extract_decision_grade_proof_from_artifact,
    governance_stamp_lines,
    interpretation_for_mode,
    normalize_decision_mode,
    export_watermark_label,
)


def _workflow_from_serializable(data: Mapping[str, Any]) -> dict[str, Any]:
    buffers: dict[str, Any] = {}
    scalar_keys = {
        "x_extent",
        "y_extent",
        "captured_mass",
        "total_mass",
        "cut_index",
        "guide_start",
        "guide_end",
        "heat_y",
        "heat_height",
        "slice_width",
    }
    for key, value in data.items():
        if key in scalar_keys:
            try:
                buffers[key] = float(value)
            except Exception:
                buffers[key] = 0.0
        elif isinstance(value, str):
            buffers[key] = str(value)
        else:
            buffers[key] = np.array(value, dtype="f4")
    return buffers


class EventMarkerSlider(QSlider):  # type: ignore[misc]  # QSlider is object when Qt unavailable
    """Horizontal slider with lightweight event tick markers + hover/click affordances."""

    markerClicked = Signal(int)
    viewWindowChanged = Signal(float, float)
    loopRangeChanged = Signal(float, float)
    loopCleared = Signal()

    _PREVIEW_COLOR = (120, 170, 255)

    def __init__(self, orientation, parent: QWidget | None = None) -> None:
        if not _HAS_QT:
            raise RuntimeError("Qt widgets backend is not available; EventMarkerSlider cannot be constructed.")
        super().__init__(orientation, parent)
        self._markers: list[tuple[float, str, list[tuple[int, int, int, int]]]] = []
        self._last_tooltip: str | None = None
        self._duration_s = 1.0
        self._view_start_s = 0.0
        self._view_end_s = 1.0
        self._loop_range_s: tuple[float, float] | None = None
        self._loop_enabled = False
        self._drag_mode: str | None = None
        self._drag_anchor_x = 0
        self._drag_anchor_view: tuple[float, float] = (0.0, 1.0)
        self._drag_loop_anchor_t: float | None = None
        self._space_down = False
        # Transient "Fit to Locus" preview band (purely visual/training).
        self._preview_range_s: tuple[float, float] | None = None
        self._preview_t0: float = 0.0
        self._preview_duration_s: float = 0.0
        self._preview_kind: str = "fit"
        self._preview_timer: QTimer | None = None
        self.setMouseTracking(True)
        try:
            self.setFocusPolicy(Qt.StrongFocus)
        except Exception:
            pass
        try:
            app = QApplication.instance()
            if app is not None:
                app.installEventFilter(self)
        except Exception:
            pass

    def eventFilter(self, obj: QObject, event) -> bool:  # type: ignore[override]
        """Track Space as a scrubber 'hand tool' without fighting the GL viewport."""
        try:
            typ = event.type()
        except Exception:
            return False
        if typ not in (QEvent.KeyPress, QEvent.KeyRelease):
            return False
        try:
            if event.isAutoRepeat():
                return False
        except Exception:
            pass
        try:
            key = event.key()
        except Exception:
            return False
        if key != Qt.Key_Space:
            return False

        # Only treat space as "hand" while the scrubber is under the cursor or
        # actively panning. Otherwise let the main viewport keep Space=play/pause.
        hovered = bool(self.underMouse())
        if typ == QEvent.KeyPress:
            if not hovered and self._drag_mode != "pan":
                return False
            self._space_down = True
            return True
        # Always catch the release if we latched Space to avoid getting stuck.
        if self._space_down:
            self._space_down = False
            return True
        return False

    def duration_seconds(self) -> float:
        return float(self._duration_s)

    def view_window_seconds(self) -> tuple[float, float]:
        return float(self._view_start_s), float(self._view_end_s)

    def set_duration_seconds(self, duration_s: float) -> None:
        try:
            d = float(duration_s)
        except Exception:
            return
        if not math.isfinite(d) or d <= 0.0:
            d = 1.0
        self._duration_s = d
        self._set_view_window_seconds(0.0, d, emit=True)

    def set_view_window_seconds(self, start_s: float, end_s: float) -> None:
        self._set_view_window_seconds(start_s, end_s, emit=True)

    def reset_view_window(self) -> None:
        self._set_view_window_seconds(0.0, float(self._duration_s), emit=True)

    def set_loop_range_seconds(self, start_s: float | None, end_s: float | None = None) -> None:
        if start_s is None or end_s is None:
            self._loop_range_s = None
            self.update()
            return
        try:
            a = float(start_s)
            b = float(end_s)
        except Exception:
            self._loop_range_s = None
            self.update()
            return
        if not math.isfinite(a) or not math.isfinite(b):
            self._loop_range_s = None
            self.update()
            return
        if b < a:
            a, b = b, a
        loop = float(self._duration_s)
        a = max(0.0, min(loop, a))
        b = max(0.0, min(loop, b))
        min_span = 1e-6
        if b - a < min_span:
            b = min(loop, a + min_span)
        if b - a < min_span:
            self._loop_range_s = None
        else:
            self._loop_range_s = (a, b)
        self.update()

    def set_loop_enabled(self, enabled: bool) -> None:
        self._loop_enabled = bool(enabled)
        self.update()

    def flash_preview_band(self, start_s: float, end_s: float, *, kind: str = "fit") -> None:
        """Flash a transient time range band on the scrubber groove.

        This is UI-only feedback used by Fit-to-Locus and its one-step undo.
        """
        try:
            a = float(start_s)
            b = float(end_s)
        except Exception:
            return
        if not math.isfinite(a) or not math.isfinite(b):
            return
        if b < a:
            a, b = b, a
        loop = float(self._duration_s)
        if loop <= 0.0:
            loop = 1.0
        a = max(0.0, min(loop, a))
        b = max(0.0, min(loop, b))
        if float(b) - float(a) <= 1e-9:
            return

        k = "undo" if str(kind).lower() == "undo" else "fit"
        # Fit spec: 250–350ms fade (no blink). Undo is a subtler, slightly quicker version.
        duration_s = 0.32 if k == "fit" else 0.26
        now = clock.monotonic()
        self._preview_range_s = (float(a), float(b))
        self._preview_t0 = float(now)
        self._preview_duration_s = float(duration_s)
        self._preview_kind = k

        if self._preview_timer is None:
            self._preview_timer = QTimer(self)
            self._preview_timer.setInterval(16)
            self._preview_timer.timeout.connect(self._on_preview_timer)
        try:
            self._preview_timer.start()
        except Exception:
            pass
        self.update()

    def _on_preview_timer(self) -> None:
        if self._preview_range_s is None or self._preview_duration_s <= 1e-9:
            try:
                if self._preview_timer is not None:
                    self._preview_timer.stop()
            except Exception:
                pass
            return
        now = clock.monotonic()
        if float(now) >= float(self._preview_t0) + float(self._preview_duration_s):
            self._preview_range_s = None
            self._preview_duration_s = 0.0
            try:
                if self._preview_timer is not None:
                    self._preview_timer.stop()
            except Exception:
                pass
        self.update()

    def loop_enabled(self) -> bool:
        return bool(self._loop_enabled)

    def loop_range_seconds(self) -> tuple[float, float] | None:
        if self._loop_range_s is None:
            return None
        return (float(self._loop_range_s[0]), float(self._loop_range_s[1]))

    def time_seconds_for_value(self, value: int) -> float:
        rng = max(1, int(self.maximum()) - int(self.minimum()))
        frac = (float(value) - float(self.minimum())) / float(rng)
        frac = max(0.0, min(1.0, frac))
        span = max(1e-9, float(self._view_end_s) - float(self._view_start_s))
        return float(self._view_start_s) + frac * span

    def value_for_time_seconds(self, t_s: float) -> int:
        rng = max(1, int(self.maximum()) - int(self.minimum()))
        span = max(1e-9, float(self._view_end_s) - float(self._view_start_s))
        frac = (float(t_s) - float(self._view_start_s)) / span
        frac = max(0.0, min(1.0, frac))
        return int(self.minimum()) + int(round(frac * float(rng)))

    def _set_view_window_seconds(self, start_s: float, end_s: float, *, emit: bool) -> None:
        loop = float(self._duration_s)
        if loop <= 0.0:
            loop = 1.0
        try:
            a = float(start_s)
            b = float(end_s)
        except Exception:
            return
        if not math.isfinite(a) or not math.isfinite(b):
            return
        if b < a:
            a, b = b, a
        min_span = max(1e-6, loop / 1000.0)
        span = max(min_span, min(loop, float(b) - float(a)))
        a = max(0.0, min(loop - span, a))
        b = a + span
        changed = abs(a - float(self._view_start_s)) > 1e-9 or abs(b - float(self._view_end_s)) > 1e-9
        self._view_start_s = a
        self._view_end_s = b
        if changed:
            self.update()
            if emit:
                try:
                    self.viewWindowChanged.emit(float(a), float(b))
                except Exception:
                    pass

    def set_markers(
        self,
        markers: list[
            tuple[float, str]
            | tuple[float, str, tuple[int, int, int, int]]
            | tuple[float, str, list[tuple[int, int, int, int]]]
        ]
        | None,
    ) -> None:
        """Markers are (fraction_0_1, label [, rgba])."""
        if not markers:
            self._markers = []
            self.update()
            return
        cleaned: list[tuple[float, str, list[tuple[int, int, int, int]]]] = []
        for entry in markers:
            if not isinstance(entry, (list, tuple)) or len(entry) < 2:
                continue
            frac = entry[0]
            label = entry[1]
            try:
                f = float(frac)
            except Exception:
                continue
            if not math.isfinite(f):
                continue
            f = max(0.0, min(1.0, f))
            colors: list[tuple[int, int, int, int]] = [(140, 190, 255, 200)]
            if len(entry) >= 3:
                raw = entry[2]
                # Accept either a single rgba tuple or a list of rgba tuples.
                rgba_list: list[tuple[int, int, int, int]] = []
                if isinstance(raw, (list, tuple)):
                    if len(raw) == 4 and all(isinstance(v, (int, float)) for v in raw):
                        rgba_list = [tuple(int(v) for v in raw)]  # type: ignore[misc]
                    elif raw and all(isinstance(v, (list, tuple)) for v in raw):
                        for rgba in raw:
                            if not isinstance(rgba, (list, tuple)) or len(rgba) not in {3, 4}:
                                continue
                            try:
                                r = int(rgba[0])
                                g = int(rgba[1])
                                b = int(rgba[2])
                                a = int(rgba[3]) if len(rgba) == 4 else 220
                            except Exception:
                                continue
                            rgba_list.append((r, g, b, a))
                if rgba_list:
                    normed: list[tuple[int, int, int, int]] = []
                    for r, g, b, a in rgba_list:
                        normed.append(
                            (
                                max(0, min(255, int(r))),
                                max(0, min(255, int(g))),
                                max(0, min(255, int(b))),
                                max(0, min(255, int(a))),
                            )
                        )
                    colors = normed[:6]

            cleaned.append((f, str(label), colors))
        cleaned.sort(key=lambda triple: triple[0])
        self._markers = cleaned
        self.update()

    def _groove_rect(self):
        opt = QStyleOptionSlider()
        try:
            self.initStyleOption(opt)
        except Exception:
            pass
        return self.style().subControlRect(QStyle.CC_Slider, opt, QStyle.SC_SliderGroove, self)

    def _marker_at_pos(self, pos: QPoint) -> tuple[int, str] | None:
        if not self._markers:
            return None
        groove = self._groove_rect()
        if groove.width() <= 1:
            return None
        x = int(pos.x())
        best_frac = 0.0
        best_label = ""
        best_dist = 1e9
        for frac, label, _colors in self._markers:
            mx = groove.left() + int(round(frac * float(groove.width() - 1)))
            dist = abs(mx - x)
            if dist < best_dist:
                best_dist = dist
                best_frac = frac
                best_label = label
        if best_dist > 9:
            return None
        rng = max(1, int(self.maximum()) - int(self.minimum()))
        value = int(self.minimum()) + int(round(best_frac * float(rng)))
        return value, best_label

    def _time_at_pos(self, pos: QPoint) -> float:
        groove = self._groove_rect()
        if groove.width() <= 1:
            return float(self._view_start_s)
        frac = (float(pos.x()) - float(groove.left())) / float(groove.width() - 1)
        frac = max(0.0, min(1.0, frac))
        span = max(1e-9, float(self._view_end_s) - float(self._view_start_s))
        return float(self._view_start_s) + frac * span

    def _loop_x_positions(self) -> tuple[int, int] | None:
        if self._loop_range_s is None:
            return None
        a, b = self._loop_range_s
        return self._range_x_positions(float(a), float(b))

    def _range_x_positions(self, start_s: float, end_s: float) -> tuple[int, int] | None:
        groove = self._groove_rect()
        if groove.width() <= 2:
            return None
        span = max(1e-9, float(self._view_end_s) - float(self._view_start_s))
        fa = (float(start_s) - float(self._view_start_s)) / span
        fb = (float(end_s) - float(self._view_start_s)) / span
        fa = max(0.0, min(1.0, fa))
        fb = max(0.0, min(1.0, fb))
        x0 = groove.left() + int(round(fa * float(groove.width() - 1)))
        x1 = groove.left() + int(round(fb * float(groove.width() - 1)))
        if x1 < x0:
            x0, x1 = x1, x0
        return x0, x1

    def _preview_alpha(self, now: float) -> int:
        if self._preview_range_s is None or self._preview_duration_s <= 1e-9:
            return 0
        u = (float(now) - float(self._preview_t0)) / max(1e-9, float(self._preview_duration_s))
        if u >= 1.0:
            return 0
        # Ease-out fade (no blink).
        ease = max(0.0, min(1.0, 1.0 - float(u)))
        ease = ease * ease
        base = 90 if self._preview_kind == "fit" else 55
        return int(max(0.0, min(255.0, float(base) * float(ease))))

    def _hit_loop_handle(self, pos: QPoint) -> str | None:
        xs = self._loop_x_positions()
        if xs is None:
            return None
        x0, x1 = xs
        groove = self._groove_rect()
        if not groove.adjusted(-6, -10, 6, 10).contains(pos):
            return None
        hit_radius = 7
        if abs(int(pos.x()) - int(x0)) <= hit_radius:
            return "a"
        if abs(int(pos.x()) - int(x1)) <= hit_radius:
            return "b"
        return None

    def _pos_in_loop_band(self, pos: QPoint) -> bool:
        xs = self._loop_x_positions()
        if xs is None:
            return False
        x0, x1 = xs
        groove = self._groove_rect()
        band_rect = groove.adjusted(0, -10, 0, 10)
        return bool(band_rect.contains(pos) and x0 <= int(pos.x()) <= x1)

    def paintEvent(self, event) -> None:  # type: ignore[override]
        super().paintEvent(event)
        groove = self._groove_rect()
        if groove.width() <= 2:
            return
        y0 = groove.center().y() - 6
        y1 = groove.center().y() + 6
        cy = groove.center().y()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)

        # A/B loop band + handles.
        if self._loop_range_s is not None:
            xs = self._loop_x_positions()
            if xs is not None:
                x0, x1 = xs
                fill = QColor(120, 170, 255, 70 if self._loop_enabled else 40)
                p.setPen(Qt.NoPen)
                p.setBrush(fill)
                top = groove.center().y() - 9
                height = 18
                p.drawRect(min(x0, x1), top, max(1, abs(x1 - x0)), height)

                handle_color = QColor(180, 205, 255, 200 if self._loop_enabled else 160)
                p.setPen(QPen(handle_color, 2))
                p.setBrush(Qt.NoBrush)
                p.drawLine(x0, top - 2, x0, top + height + 2)
                p.drawLine(x1, top - 2, x1, top + height + 2)

        # Transient preview flash band (Fit / Undo). Drawn above loop band, below markers.
        if self._preview_range_s is not None and self._preview_duration_s > 1e-9:
            now = clock.monotonic()
            alpha = self._preview_alpha(float(now))
            if alpha > 0:
                xs = self._range_x_positions(float(self._preview_range_s[0]), float(self._preview_range_s[1]))
                if xs is not None:
                    x0, x1 = xs
                    r, g, b = self._PREVIEW_COLOR
                    fill = QColor(int(r), int(g), int(b), int(alpha))
                    p.setPen(Qt.NoPen)
                    p.setBrush(fill)
                    top = groove.center().y() - 9
                    height = 18
                    p.drawRect(min(x0, x1), top, max(1, abs(x1 - x0)), height)

        if not self._markers:
            p.end()
            return
        for frac, _label, colors in self._markers:
            multi = len(colors) > 1
            if multi:
                p.setPen(QPen(QColor(160, 175, 210, 90), 1))
            else:
                r, g, b, a = colors[0]
                p.setPen(QPen(QColor(r, g, b, min(220, a)), 1))
            mx = groove.left() + int(round(frac * float(groove.width() - 1)))
            p.drawLine(mx, y0, mx, y1)
            p.setPen(Qt.NoPen)
            if not colors:
                continue
            if len(colors) == 1:
                r, g, b, a = colors[0]
                p.setBrush(QColor(r, g, b, min(255, a + 40)))
                p.drawEllipse(mx - 2, cy - 2, 4, 4)
            else:
                # Stacked dots to indicate multiple categories share this bin.
                dot_r = 2
                spacing = 4
                start = -((len(colors) - 1) * spacing) * 0.5
                for idx, (r, g, b, a) in enumerate(colors):
                    y = cy + int(round(start + idx * spacing))
                    p.setBrush(QColor(r, g, b, min(255, a + 40)))
                    p.drawEllipse(mx - dot_r, y - dot_r, dot_r * 2, dot_r * 2)
        p.end()

    def mouseMoveEvent(self, event) -> None:  # type: ignore[override]
        if self._drag_mode is not None:
            try:
                pos = event.position().toPoint()
            except Exception:
                pos = event.pos()
            if self._drag_mode == "pan":
                groove = self._groove_rect()
                span = max(1e-9, float(self._drag_anchor_view[1]) - float(self._drag_anchor_view[0]))
                if groove.width() > 1:
                    dx = float(pos.x()) - float(self._drag_anchor_x)
                    delta_t = (dx / float(groove.width() - 1)) * span
                    # Hand tool: drag right reveals earlier time (map semantics).
                    self._set_view_window_seconds(
                        float(self._drag_anchor_view[0]) - delta_t,
                        float(self._drag_anchor_view[1]) - delta_t,
                        emit=True,
                    )
                try:
                    event.accept()
                except Exception:
                    pass
                return
            if self._drag_mode in {"loop_set", "loop_handle_a", "loop_handle_b"}:
                t = self._time_at_pos(pos)
                if self._drag_mode == "loop_set" and self._drag_loop_anchor_t is not None:
                    self.set_loop_range_seconds(self._drag_loop_anchor_t, t)
                elif self._loop_range_s is not None:
                    a, b = self._loop_range_s
                    if self._drag_mode == "loop_handle_a":
                        self.set_loop_range_seconds(t, b)
                    else:
                        self.set_loop_range_seconds(a, t)
                if self._loop_range_s is not None:
                    try:
                        a, b = self._loop_range_s
                        self.loopRangeChanged.emit(float(a), float(b))
                    except Exception:
                        pass
                try:
                    event.accept()
                except Exception:
                    pass
                return
        try:
            pos = event.position().toPoint()
        except Exception:
            pos = event.pos()
        hit = self._marker_at_pos(pos)
        if hit is not None:
            _value, label = hit
            if label != self._last_tooltip:
                try:
                    QToolTip.showText(event.globalPosition().toPoint(), label, self)
                except Exception:
                    QToolTip.showText(event.globalPos(), label, self)
                self._last_tooltip = label
        else:
            if self._last_tooltip is not None:
                try:
                    QToolTip.hideText()
                except Exception:
                    pass
                self._last_tooltip = None
        super().mouseMoveEvent(event)

    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        try:
            button = event.button()
            mods = event.modifiers()
        except Exception:
            button = None
            mods = Qt.NoModifier

        try:
            pos = event.position().toPoint()
        except Exception:
            pos = event.pos()

        if button == Qt.RightButton:
            if self._pos_in_loop_band(pos):
                self._loop_range_s = None
                self.update()
                try:
                    self.loopCleared.emit()
                except Exception:
                    pass
                try:
                    event.accept()
                except Exception:
                    pass
                return

        if button == Qt.LeftButton:
            if bool(mods & Qt.ShiftModifier):
                self._drag_mode = "loop_set"
                self._drag_loop_anchor_t = self._time_at_pos(pos)
                self.set_loop_range_seconds(self._drag_loop_anchor_t, self._drag_loop_anchor_t)
                try:
                    a, b = self._loop_range_s or (self._drag_loop_anchor_t, self._drag_loop_anchor_t)
                    self.loopRangeChanged.emit(float(a), float(b))
                except Exception:
                    pass
                try:
                    event.accept()
                except Exception:
                    pass
                return
            if self._space_down:
                self._drag_mode = "pan"
                self._drag_anchor_x = int(pos.x())
                self._drag_anchor_view = (float(self._view_start_s), float(self._view_end_s))
                try:
                    event.accept()
                except Exception:
                    pass
                return
            handle = self._hit_loop_handle(pos)
            if handle is not None:
                self._drag_mode = "loop_handle_a" if handle == "a" else "loop_handle_b"
                try:
                    event.accept()
                except Exception:
                    pass
                return

        hit = self._marker_at_pos(pos)
        if hit is not None and not bool(mods & Qt.ShiftModifier):
            value, _label = hit
            try:
                self.markerClicked.emit(int(value))
            except Exception:
                pass
            try:
                event.accept()
            except Exception:
                pass
            return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # type: ignore[override]
        if self._drag_mode is not None:
            self._drag_mode = None
            self._drag_loop_anchor_t = None
            try:
                event.accept()
            except Exception:
                pass
            return
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:  # type: ignore[override]
        self.reset_view_window()
        try:
            event.accept()
        except Exception:
            pass

    def wheelEvent(self, event) -> None:  # type: ignore[override]
        try:
            delta_steps = float(event.angleDelta().y()) / 120.0
        except Exception:
            delta_steps = 0.0
        if abs(delta_steps) <= 1e-12:
            super().wheelEvent(event)
            return
        groove = self._groove_rect()
        if groove.width() <= 1:
            super().wheelEvent(event)
            return
        try:
            pos = event.position().toPoint()
        except Exception:
            pos = event.pos()
        anchor_t = self._time_at_pos(pos)
        frac = (float(pos.x()) - float(groove.left())) / float(groove.width() - 1)
        frac = max(0.0, min(1.0, frac))

        loop = max(1e-6, float(self._duration_s))
        span = max(1e-9, float(self._view_end_s) - float(self._view_start_s))
        # Wheel up = zoom in.
        zoom_factor = math.pow(0.82, delta_steps)
        new_span = max(loop / 1000.0, min(loop, span * zoom_factor))
        new_start = float(anchor_t) - frac * float(new_span)
        new_end = new_start + float(new_span)
        self._set_view_window_seconds(new_start, new_end, emit=True)
        try:
            event.accept()
        except Exception:
            pass


class GLViewport(QWidget):  # type: ignore[misc]  # QWidget is object when Qt unavailable
    def __init__(self, session: SessionModel, parent: QWidget | None = None) -> None:
        if not _HAS_QT:
            raise RuntimeError("Qt widgets backend is not available; GLViewport cannot be constructed.")
        super().__init__(parent)
        self._session = session
        self._last_error_run_id: Optional[int] = None
        self._pending_view_state: Mapping[str, Any] | None = None
        self._pending_scrubber_state: Mapping[str, Any] | None = None
        self._current_spec: EditVisualizationSpec | None = None
        self._time_bin_events: dict[int, list[float]] = {}
        self._time_bin_cycle: dict[int, int] = {}
        self._last_time_bin_clicked: int | None = None
        self._last_marker_refresh_at = 0.0
        self._last_follow_pan_at = 0.0
        self._follow_suspend_until = 0.0
        self._follow_pan_active = False
        self._follow_pan_dir = 0  # -1 left, +1 right
        self._follow_in_adjust = False
        self._is_playing = True
        self._fit_locus_undo: dict[str, Any] | None = None
        self._export_prompt_suppressed_by_key: dict[str, bool] = {}

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        # Local viewport controls (rail view + animation).
        controls = QWidget(self)
        controls_layout = QVBoxLayout(controls)
        controls_layout.setContentsMargins(8, 4, 8, 4)
        controls_layout.setSpacing(6)

        row1 = QHBoxLayout()
        row1.setContentsMargins(0, 0, 0, 0)
        row1.setSpacing(12)

        self._play_toggle = QCheckBox("Play", controls)
        self._play_toggle.setChecked(True)
        row1.addWidget(self._play_toggle)

        self._follow_toggle = QCheckBox("Follow", controls)
        self._follow_toggle.setChecked(True)
        try:
            self._follow_toggle.setToolTip("Auto-pan the time window during playback.")
        except Exception:
            pass
        row1.addWidget(self._follow_toggle)

        self._animate_toggle = QCheckBox("Shader motion", controls)
        self._animate_toggle.setChecked(True)
        row1.addWidget(self._animate_toggle)

        row1.addWidget(QLabel("Speed", controls))
        self._speed_combo = QComboBox(controls)
        self._speed_combo.addItem("0.25×", 0.25)
        self._speed_combo.addItem("0.5×", 0.5)
        self._speed_combo.addItem("1×", 1.0)
        self._speed_combo.addItem("2×", 2.0)
        self._speed_combo.addItem("4×", 4.0)
        self._speed_combo.setCurrentIndex(2)
        row1.addWidget(self._speed_combo)

        row1.addWidget(QLabel("Rail view", controls))
        self._rail_mode_combo = QComboBox(controls)
        self._rail_mode_combo.addItem("Flat rails", "flat")
        self._rail_mode_combo.addItem("3D helix", "helix")
        self._rail_mode_combo.setCurrentIndex(0)
        row1.addWidget(self._rail_mode_combo)

        self._export_clip_btn = QPushButton("Export clip", controls)
        try:
            self._export_clip_btn.setToolTip(
                "Export a short resolve clip as a zip (clip.gif + metadata.json; clip.mp4 when an encoder is available)."
            )
        except Exception:
            pass
        row1.addWidget(self._export_clip_btn)

        self._export_clip_include_spec = QCheckBox("spec.json", controls)
        self._export_clip_include_spec.setChecked(False)
        try:
            self._export_clip_include_spec.setToolTip("Include full spec.json in the zip (includes sequence).")
        except Exception:
            pass
        row1.addWidget(self._export_clip_include_spec)

        row1.addStretch(1)
        controls_layout.addLayout(row1)

        row2 = QHBoxLayout()
        row2.setContentsMargins(0, 0, 0, 0)
        row2.setSpacing(10)
        row2.addWidget(QLabel("Time", controls))
        self._time_slider = EventMarkerSlider(Qt.Horizontal, controls)
        self._time_slider.setRange(0, 1000)
        self._time_slider.setSingleStep(1)
        self._time_slider.setPageStep(10)
        row2.addWidget(self._time_slider, stretch=1)
        controls_layout.addLayout(row2)

        row3 = QHBoxLayout()
        row3.setContentsMargins(0, 0, 0, 0)
        row3.setSpacing(10)
        self._scrubber_help = QLabel(
            "Wheel zoom · double-click reset · Space+drag pan · Shift+drag loop · L loop · Ctrl+L fit locus · Ctrl+Shift+L undo · Z fit events · Shift+Z fit loop · \u2190/\u2192 jump events · ,/. step frames (Shift=10)",
            controls,
        )
        self._scrubber_help.setStyleSheet("color: palette(mid); font-size: 11px;")
        row3.addWidget(self._scrubber_help)

        self._follow_notice = QLabel("Follow paused", controls)
        self._follow_notice.setStyleSheet("color: palette(mid); font-size: 11px; font-style: italic;")
        self._follow_notice.setVisible(False)
        row3.addWidget(self._follow_notice)
        self._follow_notice_fx = None
        self._follow_notice_timer = None
        try:
            self._follow_notice_fx = QGraphicsOpacityEffect(self._follow_notice)
            self._follow_notice_fx.setOpacity(1.0)
            self._follow_notice.setGraphicsEffect(self._follow_notice_fx)
        except Exception:
            self._follow_notice_fx = None
        try:
            self._follow_notice_timer = QTimer(self)
            self._follow_notice_timer.setSingleShot(True)
            self._follow_notice_timer.timeout.connect(self._fade_follow_notice)
        except Exception:
            self._follow_notice_timer = None
        self._follow_notice_anim = None

        row3.addStretch(1)

        def _legend_item(label: str, color: QColor) -> QWidget:
            item = QWidget(controls)
            hl = QHBoxLayout(item)
            hl.setContentsMargins(0, 0, 0, 0)
            hl.setSpacing(4)

            dot = QLabel("\u25CF", item)
            dot_font = QFont()
            dot_font.setPixelSize(12)
            dot.setFont(dot_font)
            try:
                pal = dot.palette()
                pal.setColor(QPalette.WindowText, color)
                dot.setPalette(pal)
            except Exception:
                pass
            hl.addWidget(dot)

            name = QLabel(str(label), item)
            name.setStyleSheet("color: palette(mid); font-size: 11px;")
            hl.addWidget(name)
            return item

        self._tick_legend = QWidget(controls)
        legend_layout = QHBoxLayout(self._tick_legend)
        legend_layout.setContentsMargins(0, 0, 0, 0)
        legend_layout.setSpacing(10)
        legend_layout.addWidget(_legend_item("Recognition", QColor(140, 191, 255)))
        legend_layout.addWidget(_legend_item("Cut/Nick", QColor(255, 160, 90)))
        legend_layout.addWidget(_legend_item("Prime/RT", QColor(210, 124, 255)))
        legend_layout.addWidget(_legend_item("Repair", QColor(60, 220, 255)))
        row3.addWidget(self._tick_legend)
        controls_layout.addLayout(row3)

        self._block_time_slider = False
        self._resume_play_after_scrub = False

        self._stack_host = QWidget(self)
        self._stack = QStackedLayout(self._stack_host)
        self._stack.setStackingMode(QStackedLayout.StackAll)

        self._placeholder = QLabel(
            "Viewport\n\nNo simulation yet.\nRun a CRISPR or Prime simulation to populate DAG, rails, and workflow views.",
            self,
        )
        self._placeholder.setAlignment(Qt.AlignCenter)
        self._placeholder.setStyleSheet("color: palette(mid); font-size: 15px;")
        self._stack.addWidget(self._placeholder)

        try:
            from helix.gui.modern.qt import HelixModernWidget
        except Exception as exc:
            raise RuntimeError(
                "Helix GL viewport requires moderngl (install the 'realtime' extra) and a working Qt OpenGL stack."
            ) from exc

        self._hud_text_sink: Callable[[str, Sequence[str]], None] | None = None

        self._gl = HelixModernWidget(self)
        try:
            # Keep HUD text off the viewport; we'll route it to a dock panel.
            self._gl.set_hud_overlay_mode("panel")
        except Exception:
            pass
        # QWidget-composited GL viewport so overlay widgets (rails, banners, side panels)
        # respect normal Qt z-order and clipping.
        self._gl_container = self._gl
        self._stack.addWidget(self._gl_container)
        self._rail_widget = RailBandWidget(self)
        self._stack.addWidget(self._rail_widget)
        self._stack.setCurrentWidget(self._placeholder)

        self._overlay_layer = QWidget(self._stack_host)
        self._overlay_layer.setAttribute(Qt.WA_TransparentForMouseEvents)
        overlay_layout = QVBoxLayout(self._overlay_layer)
        overlay_layout.setContentsMargins(12, 12, 12, 12)
        overlay_layout.setSpacing(0)

        self._overlay = QLabel(self._overlay_layer)
        self._overlay.setObjectName("ViewportOverlay")
        self._overlay.setStyleSheet(
            "#ViewportOverlay { background-color: palette(base); color: palette(window-text); padding: 6px 10px; border-radius: 4px; font-size: 12px; }"
        )
        self._overlay.setAlignment(Qt.AlignLeft | Qt.AlignTop)
        self._overlay.setAttribute(Qt.WA_TransparentForMouseEvents)
        self._overlay.hide()
        overlay_layout.addWidget(self._overlay, alignment=Qt.AlignTop | Qt.AlignLeft)
        overlay_layout.addStretch(1)

        layout.addWidget(controls)
        layout.addWidget(self._stack_host)
        self._stack.addWidget(self._overlay_layer)

        # Wire controls once the GL widget exists.
        self._play_toggle.toggled.connect(self._on_play_toggled)
        self._animate_toggle.toggled.connect(self._on_animate_toggled)
        self._speed_combo.currentIndexChanged.connect(self._on_speed_changed)
        self._rail_mode_combo.currentIndexChanged.connect(self._on_rail_mode_changed)
        self._export_clip_btn.clicked.connect(self._export_resolve_clip)
        self._time_slider.valueChanged.connect(self._on_time_slider_changed)
        try:
            self._time_slider.markerClicked.connect(self._on_time_marker_clicked)  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            self._time_slider.viewWindowChanged.connect(self._on_time_view_window_changed)  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            self._time_slider.loopRangeChanged.connect(self._on_time_loop_range_changed)  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            self._time_slider.loopCleared.connect(self._on_time_loop_cleared)  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            self._time_slider.sliderPressed.connect(self._on_time_slider_pressed)
            self._time_slider.sliderReleased.connect(self._on_time_slider_released)
        except Exception:
            pass

        try:
            self._gl.timeUpdated.connect(self._on_gl_time_updated)  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            self._gl.playingChanged.connect(self._on_gl_playing_changed)  # type: ignore[attr-defined]
        except Exception:
            pass

        self._session.stateChanged.connect(self._on_state_changed)
        self._on_state_changed(self._session.state)

        try:
            from PySide6.QtGui import QKeySequence, QShortcut

            self._loop_shortcut = QShortcut(QKeySequence("L"), self)
            self._loop_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
            self._loop_shortcut.activated.connect(self._toggle_loop_enabled)

            self._follow_shortcut = QShortcut(QKeySequence("F"), self)
            self._follow_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
            self._follow_shortcut.activated.connect(self._toggle_follow_playhead)

            self._fit_events_shortcut = QShortcut(QKeySequence("Z"), self)
            self._fit_events_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
            self._fit_events_shortcut.activated.connect(self._fit_view_to_events)

            self._fit_loop_shortcut = QShortcut(QKeySequence("Shift+Z"), self)
            self._fit_loop_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
            self._fit_loop_shortcut.activated.connect(self._fit_view_to_loop_range)

            self._fit_locus_shortcut = QShortcut(QKeySequence("Ctrl+L"), self)
            self._fit_locus_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
            self._fit_locus_shortcut.activated.connect(self._fit_to_locus)

            self._undo_fit_locus_shortcut = QShortcut(QKeySequence("Ctrl+Shift+L"), self)
            self._undo_fit_locus_shortcut.setContext(Qt.WidgetWithChildrenShortcut)
            self._undo_fit_locus_shortcut.activated.connect(self._undo_fit_to_locus)
        except Exception:
            self._loop_shortcut = None
            self._follow_shortcut = None
            self._fit_events_shortcut = None
            self._fit_loop_shortcut = None
            self._fit_locus_shortcut = None
            self._undo_fit_locus_shortcut = None

    def highlight_outcome(self, sel: object) -> None:
        """Forward OutcomeSelection into the GL widget if present."""
        if hasattr(self, "_gl") and self._gl is not None:
            try:
                self._gl.highlight_outcome(sel)
            except Exception:
                pass

    def perf_hud_enabled(self) -> bool:
        if getattr(self, "_gl", None) is None:
            return False
        try:
            return bool(self._gl.perf_hud_enabled())
        except Exception:
            return False

    def set_perf_hud_enabled(self, enabled: bool) -> None:
        if getattr(self, "_gl", None) is None:
            return
        try:
            self._gl.set_perf_hud_enabled(bool(enabled))
        except Exception:
            pass

    def set_hud_text_sink(self, sink: Callable[[str, Sequence[str]], None] | None) -> None:
        """Forward realtime HUD text to an external sink (console tab, etc.)."""
        self._hud_text_sink = sink
        if getattr(self, "_gl", None) is None:
            return
        try:
            self._gl.set_hud_text_sink(sink)
            if sink is not None:
                self._gl.set_hud_overlay_mode("panel")
        except Exception:
            pass

    def get_view_state(self) -> dict[str, Any]:
        """Return a JSON-serializable viewer state for UI persistence."""
        state: dict[str, Any] = {}
        try:
            if getattr(self, "_gl", None) is not None:
                state = dict(self._gl.get_view_state())  # type: ignore[attr-defined]
        except Exception:
            state = {}
        try:
            state["animate"] = bool(self._animate_toggle.isChecked())
        except Exception:
            pass
        try:
            state["rail_mode"] = str(self._rail_mode_combo.currentData() or "flat")
        except Exception:
            pass
        try:
            state["playback_speed"] = float(self._speed_combo.currentData() or 1.0)
        except Exception:
            pass
        try:
            state["scrubber_follow"] = bool(self._follow_toggle.isChecked())
        except Exception:
            pass
        state["scrubber_state_v"] = 1
        try:
            loop = float(self._time_slider.duration_seconds())  # type: ignore[attr-defined]
            if loop > 1e-6:
                view_start, view_end = self._time_slider.view_window_seconds()  # type: ignore[attr-defined]
                state["scrubber_view_norm"] = [
                    max(0.0, min(1.0, float(view_start) / loop)),
                    max(0.0, min(1.0, float(view_end) / loop)),
                ]
        except Exception:
            pass
        try:
            loop = float(self._time_slider.duration_seconds())  # type: ignore[attr-defined]
            if loop > 1e-6:
                rng = getattr(self._time_slider, "loop_range_seconds", lambda: None)()  # type: ignore[attr-defined]
                if rng is not None:
                    a, b = rng
                    state["scrubber_loop_range_norm"] = [
                        max(0.0, min(1.0, float(a) / loop)),
                        max(0.0, min(1.0, float(b) / loop)),
                    ]
                enabled = getattr(self._time_slider, "loop_enabled", lambda: False)()  # type: ignore[attr-defined]
                state["scrubber_loop_enabled"] = bool(enabled)
        except Exception:
            pass
        return state

    def apply_view_state(self, state: Mapping[str, Any] | None) -> None:
        """Best-effort restore of persisted `get_view_state()` output."""
        if not isinstance(state, Mapping):
            return

        self._pending_view_state = dict(state)
        self._pending_scrubber_state = dict(state)

        # Sync UI toggles first so the controls match the underlying viewer.
        try:
            if "animate" in state:
                self._animate_toggle.setChecked(bool(state.get("animate")))
        except Exception:
            pass
        try:
            if "scrubber_follow" in state:
                self._follow_toggle.setChecked(bool(state.get("scrubber_follow")))
        except Exception:
            pass

        try:
            mode = state.get("rail_mode")
            if isinstance(mode, str):
                idx = self._rail_mode_combo.findData(mode)
                if idx >= 0:
                    self._rail_mode_combo.setCurrentIndex(idx)
        except Exception:
            pass
        try:
            speed = state.get("playback_speed") or state.get("speed")
            if speed is not None:
                target = float(speed)
                best_idx = 2
                best_dist = 1e9
                for idx in range(self._speed_combo.count()):
                    try:
                        val = float(self._speed_combo.itemData(idx))
                    except Exception:
                        continue
                    dist = abs(val - target)
                    if dist < best_dist:
                        best_dist = dist
                        best_idx = idx
                self._speed_combo.setCurrentIndex(best_idx)
        except Exception:
            pass

        # Apply immediately if the GL engine is already loaded; otherwise keep
        # it pending until the next spec load (set_spec resets camera).
        self._apply_pending_view_state()
        self._apply_pending_scrubber_state()

    def _apply_pending_view_state(self) -> None:
        if self._pending_view_state is None:
            return
        if getattr(self, "_gl", None) is None:
            return
        try:
            self._gl.apply_view_state(self._pending_view_state)  # type: ignore[attr-defined]
        except Exception:
            return

        # Only clear once a spec/engine exists; otherwise keep pending so the
        # restored camera survives the first set_spec() call.
        try:
            engine = getattr(self._gl, "engine", None)
            if engine is not None:
                self._pending_view_state = None
        except Exception:
            self._pending_view_state = None

    def _apply_pending_scrubber_state(self) -> None:
        state = self._pending_scrubber_state
        if not isinstance(state, Mapping):
            return

        engine = getattr(self._gl, "engine", None) if getattr(self, "_gl", None) is not None else None
        loop = float(getattr(engine, "loop_duration", 0.0)) if engine is not None else 0.0
        if loop <= 1e-6:
            return

        # Only clear once we have an engine/loop to apply against.
        self._pending_scrubber_state = None

        try:
            scrubber_v = int(state.get("scrubber_state_v") or 0)
        except Exception:
            scrubber_v = 0
        if scrubber_v > 1:
            # Unknown future scrubber state; ignore rather than misapplying.
            return

        # Restore view window (normalized fractions) if present.
        view_norm = state.get("scrubber_view_norm")
        if isinstance(view_norm, (list, tuple)) and len(view_norm) == 2:
            try:
                a = float(view_norm[0])
                b = float(view_norm[1])
            except Exception:
                a = b = 0.0
            if math.isfinite(a) and math.isfinite(b):
                a = max(0.0, min(1.0, a))
                b = max(0.0, min(1.0, b))
                if b < a:
                    a, b = b, a
                if b - a > 1e-6:
                    try:
                        self._time_slider.set_view_window_seconds(a * loop, b * loop)  # type: ignore[attr-defined]
                    except Exception:
                        pass

        # Restore loop range + enabled state if present.
        loop_norm = state.get("scrubber_loop_range_norm")
        if isinstance(loop_norm, (list, tuple)) and len(loop_norm) == 2:
            try:
                a = float(loop_norm[0])
                b = float(loop_norm[1])
            except Exception:
                a = b = 0.0
            if math.isfinite(a) and math.isfinite(b):
                a = max(0.0, min(1.0, a))
                b = max(0.0, min(1.0, b))
                if b < a:
                    a, b = b, a
                if b - a > 1e-6:
                    start_s = a * loop
                    end_s = b * loop
                    try:
                        self._time_slider.set_loop_range_seconds(start_s, end_s)  # type: ignore[attr-defined]
                    except Exception:
                        pass
                    try:
                        self._gl.set_loop_range_seconds(float(start_s), float(end_s))  # type: ignore[attr-defined]
                    except Exception:
                        pass

        enabled = state.get("scrubber_loop_enabled")
        if enabled is not None:
            try:
                self._time_slider.set_loop_enabled(bool(enabled))  # type: ignore[attr-defined]
            except Exception:
                pass
            try:
                self._gl.set_loop_enabled(bool(enabled))  # type: ignore[attr-defined]
            except Exception:
                pass

    def _suspend_follow_for(self, seconds: float) -> None:
        """Temporarily suspend follow-playhead after manual user actions."""
        try:
            delay = float(seconds)
        except Exception:
            return
        if delay <= 0.0:
            return
        try:
            now = clock.monotonic()
        except Exception:
            return
        until = now + delay
        self._follow_suspend_until = max(float(self._follow_suspend_until), float(until))
        self._show_follow_suspended_indicator()

    def _show_follow_suspended_indicator(self) -> None:
        try:
            if not bool(self._follow_toggle.isChecked()):
                return
        except Exception:
            return
        if not hasattr(self, "_follow_notice") or self._follow_notice is None:
            return
        try:
            remaining = max(0.0, float(self._follow_suspend_until) - clock.monotonic())
        except Exception:
            remaining = 0.0

        try:
            self._follow_notice.setText("Follow paused")
            self._follow_notice.setVisible(True)
        except Exception:
            return

        try:
            if self._follow_notice_fx is not None:
                self._follow_notice_fx.setOpacity(1.0)
        except Exception:
            pass
        try:
            if self._follow_notice_anim is not None:
                self._follow_notice_anim.stop()
        except Exception:
            pass

        if self._follow_notice_timer is None:
            try:
                QTimer.singleShot(int(max(0.0, remaining) * 1000.0), self._fade_follow_notice)  # type: ignore[attr-defined]
            except Exception:
                pass
            return
        try:
            self._follow_notice_timer.stop()
            self._follow_notice_timer.start(int(max(0.0, remaining) * 1000.0))
        except Exception:
            pass

    def _fade_follow_notice(self) -> None:
        if not hasattr(self, "_follow_notice") or self._follow_notice is None:
            return
        if self._follow_notice_fx is None:
            try:
                self._follow_notice.setVisible(False)
            except Exception:
                pass
            return
        # If follow is still suspended (timer can be stale), keep it visible.
        try:
            if clock.monotonic() < float(self._follow_suspend_until) - 1e-3:
                self._show_follow_suspended_indicator()
                return
        except Exception:
            pass

        try:
            from PySide6.QtCore import QEasingCurve, QPropertyAnimation
        except Exception:
            try:
                self._follow_notice.setVisible(False)
            except Exception:
                pass
            return

        try:
            anim = QPropertyAnimation(self._follow_notice_fx, b"opacity", self)
            anim.setDuration(220)
            anim.setEasingCurve(QEasingCurve.OutCubic)
            anim.setStartValue(float(self._follow_notice_fx.opacity()))
            anim.setEndValue(0.0)

            def _finish() -> None:
                try:
                    self._follow_notice.setVisible(False)
                    self._follow_notice_fx.setOpacity(1.0)
                except Exception:
                    pass

            anim.finished.connect(_finish)
            self._follow_notice_anim = anim
            anim.start()
        except Exception:
            try:
                self._follow_notice.setVisible(False)
            except Exception:
                pass

    def _on_state_changed(self, state: ExperimentState) -> None:
        if not state.viz_dirty:
            return
        spec = self._extract_spec(state)
        if spec is None and state.outcomes:
            spec = self._build_spec_from_state(state)
        config = state.config if isinstance(state.config, Mapping) else {}
        if spec is not None:
            settings = config.get("sim_settings") or {}
            viz_mode = str((settings.get("viz_mode") or "rail_3d")).lower()
            metadata = spec.metadata or {}
            workflow_meta = config.get("workflow_view") or metadata.get("workflow_view")

            # If we have a CRISPR edit DAG but no workflow metadata yet,
            # derive a 2.5D workflow view directly from the DAG.
            if workflow_meta is None and isinstance(state.dag_from_runtime, Mapping):
                try:
                    wf = crispr_dag_to_workflow(state.dag_from_runtime)
                except Exception:
                    wf = None
                if wf is not None:
                    workflow_meta = wf
                    config["workflow_view"] = wf

            if viz_mode == "rail_2d":
                self._current_spec = None
                rail_meta = metadata.get("rail_bands")
                if isinstance(rail_meta, Mapping) and rail_meta.get("bands"):
                    try:
                        show_hotspots = True
                        show_context = True
                        mode = "aggregate"
                        selected_key = None
                        edit_plan = None
                        reference_context = None
                        hotspot_cfg = config.get("outcome_hotspots") if isinstance(config, Mapping) else None
                        if isinstance(hotspot_cfg, Mapping):
                            if "enabled" in hotspot_cfg:
                                show_hotspots = bool(hotspot_cfg.get("enabled"))
                            if "show_context" in hotspot_cfg:
                                show_context = bool(hotspot_cfg.get("show_context"))
                            mode = str(hotspot_cfg.get("mode") or "aggregate")
                            selected_key = hotspot_cfg.get("selected_allele_key")
                        prime_overlay_enabled = True
                        prime_cfg = config.get("outcome_prime_overlay") if isinstance(config, Mapping) else None
                        if isinstance(prime_cfg, Mapping) and "enabled" in prime_cfg:
                            prime_overlay_enabled = bool(prime_cfg.get("enabled"))
                        try:
                            from .outcomes.prime_model import extract_prime_inputs_from_session

                            inferred = extract_prime_inputs_from_session(self._session)
                            if inferred is not None:
                                edit_plan, reference_context = inferred
                        except Exception:
                            pass
                        report = compute_outcomes_for_current_plan(
                            self._session,
                            edit_plan=edit_plan,
                            reference_context=reference_context,
                        )
                        report_bytes = outcome_report_json_bytes(report)
                        multiplex_target = None
                        try:
                            multiplex_target = getattr(self._session, "_multiplex_target_override", None)
                        except Exception:
                            multiplex_target = None
                        hotspots = build_hotspot_segments(
                            report_bytes,
                            sequence_len=len(spec.sequence),
                            mode=mode,
                            selected_allele_key=str(selected_key) if selected_key else None,
                            show_context=show_context,
                            multiplex_target_id=str(multiplex_target) if multiplex_target else None,
                        )
                        prime_overlay: Mapping[str, Any] | None = None
                        if prime_overlay_enabled:
                            prime_overlay = build_prime_overlay(
                                report_bytes,
                                sequence_len=len(spec.sequence),
                                edit_plan=edit_plan,
                                reference_context=reference_context,
                            )
                        base_overlay = build_base_overlay(
                            report_bytes,
                            sequence_len=len(spec.sequence),
                        )
                        if hotspots or prime_overlay or base_overlay:
                            rail_meta = dict(rail_meta)
                            if hotspots:
                                hotspots["show"] = bool(show_hotspots)
                                rail_meta["hotspots"] = hotspots
                            if prime_overlay:
                                overlay_payload = dict(prime_overlay)
                                overlay_payload["show"] = True
                                rail_meta["prime_overlay"] = overlay_payload
                            if base_overlay:
                                overlay_payload = dict(base_overlay)
                                overlay_payload["show"] = True
                                rail_meta["base_overlay"] = overlay_payload
                            spec.metadata = dict(spec.metadata or {})
                            spec.metadata["rail_bands"] = rail_meta
                    except Exception:
                        pass
                    self._rail_widget.set_spec(spec)
                    self._gl.set_workflow_view(None)
                    self._stack.setCurrentWidget(self._rail_widget)
                    self._overlay.hide()
                    try:
                        self._time_slider.set_markers([])  # type: ignore[attr-defined]
                    except Exception:
                        pass
                    self._time_bin_events = {}
                    self._time_bin_cycle = {}
                    self._last_time_bin_clicked = None
                    self._last_error_run_id = None
                    return

            try:
                self._stack.setCurrentWidget(self._gl_container)
            except RuntimeError:
                return
            self._gl.set_spec(spec)
            self._current_spec = spec
            try:
                engine = getattr(self._gl, "engine", None)
                loop = float(getattr(engine, "loop_duration", 0.0)) if engine is not None else 0.0
                if loop > 1e-6:
                    self._time_slider.set_duration_seconds(loop)  # type: ignore[attr-defined]
            except Exception:
                pass
            try:
                self._time_slider.set_loop_range_seconds(None)  # type: ignore[attr-defined]
                self._time_slider.set_loop_enabled(False)  # type: ignore[attr-defined]
            except Exception:
                pass
            self._apply_pending_scrubber_state()
            if viz_mode == "workflow_2p5d" and isinstance(workflow_meta, Mapping):
                self._gl.set_workflow_view(_workflow_from_serializable(workflow_meta))
            else:
                self._gl.set_workflow_view(None)
            try:
                self._refresh_time_markers(spec)
            except Exception:
                pass
            self._gl.update()
            metrics = None
            try:
                metrics = compute_run_metrics(self._session.to_payload())
            except Exception:
                metrics = None
            self._refresh_overlay(metrics)
            self._last_error_run_id = None
        else:
            self._gl.set_workflow_view(None)
            self._current_spec = None
            try:
                self._time_slider.set_markers([])  # type: ignore[attr-defined]
            except Exception:
                pass
            self._time_bin_events = {}
            self._time_bin_cycle = {}
            self._last_time_bin_clicked = None
            if state.dag_from_runtime:
                self._show_placeholder("Viewport\n\nDAG available – awaiting visualization.")
            else:
                self._show_placeholder(
                    "Viewport\n\nNo simulation yet.\nRun a CRISPR or Prime simulation to populate DAG, rails, and workflow views."
                )
            self._overlay.hide()
            if (state.viz_spec_payload or state.dag_from_runtime or state.outcomes) and (
                state.run_id != self._last_error_run_id
            ):
                self._session.error("Failed to build visualization spec from session; see logs.")
                self._last_error_run_id = state.run_id
        self._apply_pending_view_state()
        self._session.mark_viz_clean()

    def raise_surfaces(self) -> None:
        """Ensure embedded GL widgets stay on top after tab or screen moves."""
        try:
            # These are QWidget subclasses, so raise_ is safe even if hidden.
            self._stack_host.raise_()
            self._gl_container.raise_()
            self._overlay.raise_()
            self._rail_widget.raise_()
        except Exception:
            pass

    def _is_current_tab_selected(self) -> bool:
        """Return True if this widget is the active page in its parent tab widget."""
        parent = self.parent()
        while parent is not None:
            if isinstance(parent, QTabWidget):
                try:
                    return parent.currentWidget() is self
                except Exception:
                    return False
            try:
                parent = parent.parent()
            except Exception:
                break
        return False

    def showEvent(self, event) -> None:  # type: ignore[override]
        try:
            if self._gl is not None:
                self._gl.set_render_active(self._is_current_tab_selected())
        except Exception:
            pass
        super().showEvent(event)

    def hideEvent(self, event) -> None:  # type: ignore[override]
        try:
            if self._gl is not None:
                self._gl.set_render_active(False)
        except Exception:
            pass
        super().hideEvent(event)

    def set_render_active(self, active: bool) -> None:
        """Pause/resume ModernGL rendering when the tab is inactive."""
        gl = getattr(self, "_gl", None)
        if gl is None:
            return
        try:
            gl.set_render_active(active)  # type: ignore[attr-defined]
        except Exception:
            pass

    def set_dag(self, dag) -> None:
        # self._gl.set_dag(dag)
        pass

    def _extract_spec(self, state: ExperimentState) -> Optional[EditVisualizationSpec]:
        config = state.config if isinstance(state.config, Mapping) else {}
        candidate = state.viz_spec_payload or config.get("viz_spec_payload") or config.get("viz_spec")
        if candidate is not None:
            try:
                return load_viz_spec(candidate)
            except Exception:
                self._session.log("Failed to load viz spec from session config.")
        dag_payload = state.dag_from_runtime
        if isinstance(dag_payload, Mapping):
            try:
                return crispr_dag_to_viz_spec(dag_payload)
            except Exception:
                self._session.log("Failed to adapt DAG payload into visualization spec.")
        return None

    def _build_spec_from_state(self, state: ExperimentState) -> Optional[EditVisualizationSpec]:
        config = state.config if isinstance(state.config, Mapping) else {}
        payload = config.get("sim_payload")
        if not isinstance(payload, Mapping):
            return None
        viz_mode = str(((config.get("sim_settings") or {}).get("viz_mode") or "rail_3d")).lower()
        sim_type = state.run_kind.name if state.run_kind != RunKind.NONE else str(config.get("sim_type") or "").upper()
        if sim_type == "CRISPR":
            sequence = self._sequence_from_state(state) or self._sequence_from_payload(payload)
            guide = config.get("guide") or payload.get("guide")
            if not sequence or not isinstance(guide, Mapping):
                return None
            if viz_mode == "orbitals_3d":
                spec = build_crispr_orbitals_3d_spec(sequence, guide, payload)
            else:
                spec = build_crispr_rail_3d_spec(sequence, guide, payload)
            if spec is None:
                spec = build_crispr_viz_spec(sequence, guide, payload)
            return spec
        if sim_type == "PRIME":
            genome = state.genome
            peg = state.peg
            editor = state.editor
            if genome is None or peg is None or editor is None:
                return None
            if viz_mode == "prime_scaffold_3d":
                return build_prime_scaffold_3d_spec(genome, peg, editor, payload)
            return build_prime_viz_spec(genome, peg, editor, payload)
        return None

    def _sequence_from_state(self, state: ExperimentState) -> Optional[str]:
        genome = state.genome
        sequences = getattr(genome, "sequences", None) if genome is not None else None
        if isinstance(sequences, Mapping):
            for seq in sequences.values():
                if isinstance(seq, str) and seq:
                    return seq
        return None

    def _sequence_from_payload(self, payload: Mapping[str, Any]) -> Optional[str]:
        site = payload.get("site")
        if isinstance(site, Mapping):
            seq = site.get("sequence")
            if isinstance(seq, str):
                return seq
        seq = payload.get("sequence")
        if isinstance(seq, str):
            return seq
        return None

    def _show_placeholder(self, message: str) -> None:
        self._placeholder.setText(message)
        self._stack.setCurrentWidget(self._placeholder)
        self._overlay.hide()

    def _refresh_overlay(self, snapshot_metrics: RunMetrics | None) -> None:
        lines = build_overlay_lines(snapshot_metrics)
        if not lines:
            self._overlay.hide()
            return
        self._overlay.setText("\n".join(lines))
        self._overlay.show()
        try:
            self._overlay_layer.raise_()
            self._overlay.raise_()
        except Exception:
            pass

    def _on_animate_toggled(self, enabled: bool) -> None:
        if self._gl is not None:
            self._gl.set_animate(enabled)

    def _on_speed_changed(self, index: int) -> None:
        if self._gl is None:
            return
        try:
            speed = float(self._speed_combo.itemData(index) or 1.0)
        except Exception:
            speed = 1.0
        try:
            self._gl.set_playback_speed(speed)  # type: ignore[attr-defined]
        except Exception:
            pass

    def _on_play_toggled(self, enabled: bool) -> None:
        if self._gl is not None:
            try:
                self._gl.set_playing(bool(enabled))  # type: ignore[attr-defined]
            except Exception:
                pass

    def _on_rail_mode_changed(self, index: int) -> None:
        if self._gl is None:
            return
        mode = self._rail_mode_combo.itemData(index) or "flat"
        self._gl.set_rail_mode(str(mode))

    def _on_time_slider_pressed(self) -> None:
        if self._gl is None:
            return
        self._suspend_follow_for(0.9)
        self._resume_play_after_scrub = bool(self._play_toggle.isChecked())
        if self._resume_play_after_scrub:
            try:
                self._gl.set_playing(False)  # type: ignore[attr-defined]
            except Exception:
                pass

    def _on_time_slider_released(self) -> None:
        if self._gl is None:
            return
        self._suspend_follow_for(0.35)
        if self._resume_play_after_scrub:
            try:
                self._gl.set_playing(True)  # type: ignore[attr-defined]
            except Exception:
                pass
        self._resume_play_after_scrub = False

    def _on_time_slider_changed(self, value: int) -> None:
        if self._gl is None or self._block_time_slider:
            return
        engine = getattr(self._gl, "engine", None)
        if engine is None:
            return
        loop = float(getattr(engine, "loop_duration", 0.0))
        if loop <= 1e-6:
            return
        try:
            t_s = float(self._time_slider.time_seconds_for_value(int(value)))  # type: ignore[attr-defined]
            self._gl.set_time_norm(max(0.0, min(1.0, t_s / loop)))  # type: ignore[attr-defined]
        except Exception:
            pass

    def _on_time_view_window_changed(self, start_s: float, end_s: float) -> None:
        if self._gl is None:
            return
        engine = getattr(self._gl, "engine", None)
        if engine is None:
            return
        if not bool(self._follow_in_adjust):
            self._suspend_follow_for(0.8)
        try:
            now = float(getattr(getattr(engine, "state", None), "time", 0.0))
        except Exception:
            now = 0.0
        if not self._time_slider.isSliderDown():
            try:
                self._block_time_slider = True
                self._time_slider.setValue(int(self._time_slider.value_for_time_seconds(now)))  # type: ignore[attr-defined]
            finally:
                self._block_time_slider = False
        if self._current_spec is not None:
            try:
                # Throttle marker rebuilds while playing + following to keep
                # continuous panning from re-walking the entire event list at 60fps.
                if bool(self._is_playing) and bool(self._follow_toggle.isChecked()):
                    now_t = clock.monotonic()
                    if now_t - float(self._last_marker_refresh_at) < 0.10:
                        return
                    self._last_marker_refresh_at = now_t
                self._refresh_time_markers(self._current_spec)
            except Exception:
                pass

    def _on_time_loop_range_changed(self, start_s: float, end_s: float) -> None:
        if self._gl is None:
            return
        try:
            self._gl.set_loop_range_seconds(float(start_s), float(end_s))  # type: ignore[attr-defined]
        except Exception:
            pass

    def _on_time_loop_cleared(self) -> None:
        if self._gl is None:
            return
        try:
            self._gl.clear_loop_range()  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            self._gl.set_loop_enabled(False)  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            self._time_slider.set_loop_enabled(False)  # type: ignore[attr-defined]
        except Exception:
            pass

    def _toggle_loop_enabled(self) -> None:
        if self._gl is None:
            return
        engine = getattr(self._gl, "engine", None)
        if engine is None:
            return
        try:
            new_enabled = not bool(getattr(engine, "loop_enabled", False))
        except Exception:
            new_enabled = True
        try:
            self._gl.set_loop_enabled(bool(new_enabled))  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            self._time_slider.set_loop_enabled(bool(new_enabled))  # type: ignore[attr-defined]
        except Exception:
            pass

    def _toggle_follow_playhead(self) -> None:
        try:
            self._follow_toggle.setChecked(not bool(self._follow_toggle.isChecked()))
        except Exception:
            pass
        try:
            if not bool(self._follow_toggle.isChecked()):
                if self._follow_notice_timer is not None:
                    self._follow_notice_timer.stop()
                if self._follow_notice_anim is not None:
                    self._follow_notice_anim.stop()
                if getattr(self, "_follow_notice", None) is not None:
                    self._follow_notice.setVisible(False)
        except Exception:
            pass

    def _fit_view_to_loop_range(self) -> None:
        rng = None
        try:
            rng = self._time_slider.loop_range_seconds()  # type: ignore[attr-defined]
        except Exception:
            rng = None
        if rng is None:
            return
        a, b = rng
        span = max(1e-6, float(b) - float(a))
        pad = min(span * 0.12, span)
        try:
            self._time_slider.set_view_window_seconds(float(a) - pad, float(b) + pad)  # type: ignore[attr-defined]
        except Exception:
            pass

    def _fit_view_to_events(self) -> None:
        engine = getattr(self._gl, "engine", None) if getattr(self, "_gl", None) is not None else None
        if engine is None:
            return
        try:
            times = list(engine.event_times_seconds())
        except Exception:
            times = []
        if not times:
            try:
                self._time_slider.reset_view_window()  # type: ignore[attr-defined]
            except Exception:
                pass
            return
        loop = float(getattr(engine, "loop_duration", 0.0))
        if loop <= 1e-6:
            return
        t0 = float(min(times))
        t1 = float(max(times))
        span = max(loop / 1000.0, t1 - t0)
        pad = span * 0.18
        try:
            self._time_slider.set_view_window_seconds(t0 - pad, t1 + pad)  # type: ignore[attr-defined]
        except Exception:
            pass

    def _fit_to_locus(self) -> None:
        """Fit both time window (event cluster) and camera (locus context)."""
        if self._gl is None:
            return
        engine = getattr(self._gl, "engine", None)
        if engine is None:
            return
        try:
            if self._time_slider.isSliderDown():
                return
        except Exception:
            pass
        # Don't fight the user's hand while they are dragging the camera.
        try:
            if getattr(self._gl, "_drag_mode", None) is not None:
                return
        except Exception:
            pass

        loop = float(getattr(engine, "loop_duration", 0.0))
        if loop <= 1e-6:
            return
        try:
            now = float(getattr(getattr(engine, "state", None), "time", 0.0))
        except Exception:
            now = 0.0

        # One-step undo snapshot (time window + camera state) so users can "peek" and revert.
        try:
            prev_view = self._time_slider.view_window_seconds()  # type: ignore[attr-defined]
        except Exception:
            prev_view = None
        prev_gl_state = None
        try:
            prev_gl_state = dict(self._gl.get_view_state())  # type: ignore[attr-defined]
        except Exception:
            prev_gl_state = None
        if prev_view is not None and isinstance(prev_gl_state, dict):
            self._fit_locus_undo = {"time_view": [float(prev_view[0]), float(prev_view[1])], "gl_state": prev_gl_state}

        try:
            times = list(engine.event_times_seconds())
        except Exception:
            times = []

        loop_range = None
        try:
            if bool(getattr(engine, "loop_enabled", False)) and getattr(engine, "loop_range", None) is not None:
                a, b = getattr(engine, "loop_range")
                a = max(0.0, min(loop, float(a)))
                b = max(0.0, min(loop, float(b)))
                if b < a:
                    a, b = b, a
                if b - a > 1e-6:
                    loop_range = (float(a), float(b))
        except Exception:
            loop_range = None

        # If loop is enabled but state is outside range (shouldn't happen, but can in
        # legacy states), clamp playhead into the loop so fit doesn't "lie".
        if loop_range is not None:
            a, b = loop_range
            if float(now) < float(a) - 1e-6:
                try:
                    self._gl.set_time_norm(float(a) / float(loop))  # type: ignore[attr-defined]
                except Exception:
                    pass
                now = float(a)
            elif float(now) > float(b) + 1e-6:
                target = max(float(a), min(float(loop) - 1e-6, float(b) - 1e-6))
                try:
                    self._gl.set_time_norm(float(target) / float(loop))  # type: ignore[attr-defined]
                except Exception:
                    pass
                now = float(target)

        start_s, end_s = fit_time_window_to_event_cluster(
            t_s=float(now),
            event_times_s=times,
            duration_s=loop,
            loop_range_s=loop_range,
        )

        # Manual action: pause follow briefly so playback doesn't yank context away.
        self._suspend_follow_for(0.7)
        self._follow_pan_active = False
        self._follow_pan_dir = 0

        try:
            self._follow_in_adjust = True
            self._time_slider.set_view_window_seconds(float(start_s), float(end_s))  # type: ignore[attr-defined]
        except Exception:
            pass
        finally:
            self._follow_in_adjust = False

        # Preview feedback: briefly flash the fitted window on the scrubber.
        flash_a, flash_b = float(start_s), float(end_s)
        if loop_range is not None:
            la, lb = loop_range
            if abs(float(start_s) - float(la)) <= 1e-6 and abs(float(end_s) - float(lb)) <= 1e-6:
                flash_a, flash_b = float(la), float(lb)
        try:
            if hasattr(self._time_slider, "flash_preview_band"):
                self._time_slider.flash_preview_band(float(flash_a), float(flash_b), kind="fit")  # type: ignore[attr-defined]
        except Exception:
            pass

        # Fit the spatial camera around the active locus + story geometry.
        try:
            if hasattr(self._gl, "fit_to_locus"):
                self._gl.fit_to_locus()  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            if hasattr(self._gl, "pulse_locus"):
                self._gl.pulse_locus("fit")  # type: ignore[attr-defined]
        except Exception:
            pass

    def _undo_fit_to_locus(self) -> None:
        undo = getattr(self, "_fit_locus_undo", None)
        if not isinstance(undo, Mapping):
            return
        if self._gl is None:
            return
        try:
            if self._time_slider.isSliderDown():  # type: ignore[attr-defined]
                return
        except Exception:
            pass
        try:
            if getattr(self._gl, "_drag_mode", None) is not None:
                return
        except Exception:
            pass

        time_view = undo.get("time_view")
        gl_state = undo.get("gl_state")
        if not (isinstance(time_view, (list, tuple)) and len(time_view) == 2):
            return
        if not isinstance(gl_state, Mapping):
            return

        self._fit_locus_undo = None
        self._suspend_follow_for(0.7)
        self._follow_pan_active = False
        self._follow_pan_dir = 0

        try:
            self._follow_in_adjust = True
            self._time_slider.set_view_window_seconds(float(time_view[0]), float(time_view[1]))  # type: ignore[attr-defined]
        except Exception:
            pass
        finally:
            self._follow_in_adjust = False

        try:
            self._gl.apply_view_state(gl_state)  # type: ignore[attr-defined]
        except Exception:
            return
        try:
            if hasattr(self._time_slider, "flash_preview_band"):
                self._time_slider.flash_preview_band(float(time_view[0]), float(time_view[1]), kind="undo")  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            if hasattr(self._gl, "pulse_locus"):
                self._gl.pulse_locus("undo")  # type: ignore[attr-defined]
        except Exception:
            pass

    @staticmethod
    def _qimage_to_rgb_array(img: QImage) -> np.ndarray:
        """Convert a Qt framebuffer image into an RGB uint8 array."""
        qimg = img
        try:
            qimg = qimg.convertToFormat(QImage.Format_RGBA8888)
        except Exception:
            pass
        w = int(qimg.width())
        h = int(qimg.height())
        if w <= 0 or h <= 0:
            return np.zeros((0, 0, 3), dtype="u1")
        try:
            ptr = qimg.bits()
            ptr.setsize(int(qimg.sizeInBytes()))
            stride_px = int(qimg.bytesPerLine()) // 4
            rgba = np.frombuffer(ptr, dtype=np.uint8).reshape((h, stride_px, 4))
            rgb = np.ascontiguousarray(rgba[:, :w, :3])
            return rgb
        except Exception:
            return np.zeros((0, 0, 3), dtype="u1")

    def _prompt_export_allowed(self, *, title: str, decision_mode: str) -> bool:
        cfg = None
        try:
            state = getattr(self._session, "state", None)
            cfg = getattr(state, "config", None)
        except Exception:
            cfg = None
        meta = cfg.get("metadata") if isinstance(cfg, Mapping) and isinstance(cfg.get("metadata"), Mapping) else {}
        preset_id = str(meta.get("preset_id") or "").strip().lower()
        scenario = str(meta.get("scenario") or "").strip().lower()
        is_demo = bool(scenario == "demo" or preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"))

        run_id = None
        try:
            run_id = getattr(getattr(self._session, "state", None), "run_id", None)
        except Exception:
            run_id = None

        ctx = build_export_context(decision_mode=decision_mode, is_demo=is_demo, run_id=run_id)
        try:
            from helix.studio.ui.export_gate import ensure_export_allowed

            intent_spec = getattr(getattr(self._session, "state", None), "experiment_intent_spec", None)
            exp_spec = getattr(getattr(self._session, "state", None), "experiment_spec", None)
            summary = None
            try:
                runs = getattr(self._session, "runs", None)
                run = runs[-1] if isinstance(runs, list) and runs else None
                meta = getattr(run, "metadata", None) if run is not None else None
                summary = meta.get("run_summary") if isinstance(meta, Mapping) else None
            except Exception:
                summary = None
            return ensure_export_allowed(
                self,
                action_title=title,
                ctx=ctx,
                session_acks=self._export_prompt_suppressed_by_key,
                run_summary_v2=summary if isinstance(summary, Mapping) else None,
                experiment_intent_spec=intent_spec if isinstance(intent_spec, Mapping) else None,
                experiment_spec=exp_spec if isinstance(exp_spec, Mapping) else None,
            )
        except Exception:
            return True

    def _export_resolve_clip(self) -> None:
        """Export a short resolve clip as a zip (GIF + metadata, optional MP4)."""
        if self._gl is None:
            try:
                self._session.error("Export clip unavailable: viewport is not ready.")
            except Exception:
                pass
            return
        engine = getattr(self._gl, "engine", None)
        if engine is None:
            try:
                self._session.error("Export clip unavailable: no active render engine.")
            except Exception:
                pass
            return
        spec = self._current_spec or getattr(engine, "spec", None)
        if spec is None:
            try:
                self._session.error("Nothing to export yet: run a simulation to populate the Realtime (3D) view.")
            except Exception:
                pass
            return

        fps = 24
        try:
            loop = float(getattr(engine, "loop_duration", 0.0))
        except Exception:
            loop = 0.0
        if loop <= 1e-6:
            try:
                self._session.error("Nothing to export yet: simulation timeline is empty.")
            except Exception:
                pass
            return

        # Fail fast on missing dependencies before any interactive export gating or dialogs.
        try:
            import imageio.v2 as _iio  # noqa: F401
        except Exception as exc:
            try:
                self._session.error(f"Export clip requires 'imageio' (pip install imageio). ({exc})")
            except Exception:
                pass
            return

        try:
            now_s = float(getattr(getattr(engine, "state", None), "time", 0.0))
        except Exception:
            now_s = 0.0

        try:
            event_times_s = list(engine.event_times_seconds())
        except Exception:
            event_times_s = []

        loop_enabled = bool(getattr(engine, "loop_enabled", False))
        loop_range_s = None
        try:
            if loop_enabled and getattr(engine, "loop_range", None) is not None:
                a, b = getattr(engine, "loop_range")
                loop_range_s = (float(a), float(b))
        except Exception:
            loop_range_s = None

        include_full_spec = False
        try:
            include_full_spec = bool(self._export_clip_include_spec.isChecked())
        except Exception:
            include_full_spec = False

        # Governance stamping (burn into frames + include proof pointers in the zip).
        decision_mode = "filter_only"
        interpretation = "exploratory_uncalibrated"
        proof = None
        artifact = None
        try:
            artifact = self._session.ensure_run_artifact()
        except Exception:
            artifact = None
        if isinstance(artifact, Mapping):
            requested = normalize_decision_mode(artifact.get("decision_mode"))
            eligible = bool(artifact.get("decision_mode_eligible"))
            decision_mode = "decision_grade" if (requested == "decision_grade" and eligible) else "filter_only"
            interpretation = interpretation_for_mode(decision_mode)
            if decision_mode == "decision_grade":
                proof = extract_decision_grade_proof_from_artifact(artifact)

        gov_lines = governance_stamp_lines(
            decision_mode=decision_mode,
            interpretation=interpretation,
            decision_grade_proof=proof if isinstance(proof, Mapping) else None,
        )
        gov_payload = {
            "schema": "helix.governance.resolve_clip/v1",
            "decision_mode": decision_mode,
            "interpretation": interpretation,
            "decision_grade_proof": (dict(proof) if isinstance(proof, Mapping) else None),
            "stamp_lines": [str(line) for line in gov_lines],
        }

        is_demo = False
        try:
            cfg = getattr(getattr(self._session, "state", None), "config", None)
            meta = cfg.get("metadata") if isinstance(cfg, Mapping) and isinstance(cfg.get("metadata"), Mapping) else {}
            preset_id = str(meta.get("preset_id") or "").strip().lower()
            scenario = str(meta.get("scenario") or "").strip().lower()
            is_demo = bool(scenario == "demo" or preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"))
        except Exception:
            is_demo = False
        try:
            gov_payload["is_demo"] = bool(is_demo)
            gov_payload["watermark"] = export_watermark_label(decision_mode=decision_mode, is_demo=is_demo)
        except Exception:
            pass

        wm_text = export_watermark_label(decision_mode=decision_mode, is_demo=is_demo)
        wm_lines_list = [str(line) for line in gov_lines if str(line).strip()]

        if not self._prompt_export_allowed(title="Export resolve clip", decision_mode=decision_mode):
            return

        # Default output path.
        stamp = clock.local_now_stamp()
        try:
            run_id = getattr(getattr(self._session, "state", None), "run_id", None)
        except Exception:
            run_id = None
        run_token = f"run{int(run_id)}" if isinstance(run_id, int) else "run"
        default_dir = Path.home()
        try:
            from PySide6.QtCore import QStandardPaths  # type: ignore

            downloads = str(QStandardPaths.writableLocation(QStandardPaths.DownloadLocation) or "").strip()
            if downloads:
                default_dir = Path(downloads)
        except Exception:
            pass
        prefix = ""
        if str(decision_mode) != "decision_grade":
            prefix = "DEMO_" if is_demo else "EXPLORATORY_"
        default_name = str(default_dir / f"{prefix}helix_clip_{run_token}_{stamp}.zip")
        try:
            self.window().raise_()
            self.window().activateWindow()
        except Exception:
            pass
        path_str, _ = QFileDialog.getSaveFileName(
            self,
            "Export resolve clip",
            default_name,
            "Zip archive (*.zip)",
        )
        if not path_str:
            return

        mp4_encoder = detect_mp4_encoder()

        # Compute capture window (±2s around resolve, clamped/pinned inside loop).
        clip = compute_clip_window(
            now_s=now_s,
            loop_duration_s=loop,
            event_times_s=event_times_s,
            spec=spec,
            event_times_normalized=bool(getattr(engine, "event_times_normalized", False)),
            loop_enabled=loop_enabled,
            loop_range_s=loop_range_s,
            half_span_s=2.0,
            fps=fps,
        )
        # Avoid end-of-loop / end-of-range wrap at exact boundaries.
        cap_end = float(clip.end_s)
        eps = 1e-6
        if abs(cap_end - float(loop)) <= 1e-6 or cap_end >= float(loop) - eps:
            cap_end = float(loop) - eps
        if loop_enabled and loop_range_s is not None:
            try:
                _a, b = loop_range_s
                if abs(cap_end - float(b)) <= 1e-6 or cap_end >= float(b) - eps:
                    cap_end = float(b) - eps
            except Exception:
                pass
        if cap_end < float(clip.start_s) + 1e-9:
            cap_end = float(clip.start_s)
        clip = clip.__class__(
            start_s=float(clip.start_s),
            end_s=float(cap_end),
            anchor_time_s=float(clip.anchor_time_s),
            anchor_source=str(clip.anchor_source),
        )

        times = frame_times_seconds(start_s=float(clip.start_s), end_s=float(clip.end_s), fps=fps)
        if not times:
            try:
                self._session.error("Export clip failed: no frames to capture for the current timeline window.")
            except Exception:
                pass
            return

        # Snapshot view state + current time window for metadata.
        view_state = None
        try:
            view_state = dict(self._gl.get_view_state())  # type: ignore[attr-defined]
        except Exception:
            view_state = None
        time_view = None
        try:
            time_view = self._time_slider.view_window_seconds()  # type: ignore[attr-defined]
        except Exception:
            time_view = None

        # Build metadata (spec hash + redacted summary by default).
        metadata, spec_payload = build_capture_metadata(
            spec=spec,
            loop_duration_s=loop,
            now_s=now_s,
            event_times_s=event_times_s,
            event_times_normalized=bool(getattr(engine, "event_times_normalized", False)),
            event_time_units=str(getattr(engine, "event_time_units", "seconds")),
            event_time_units_source=str(getattr(engine, "event_time_units_source", "auto")),
            loop_enabled=loop_enabled,
            loop_range_s=loop_range_s,
            clip=clip,
            fps=fps,
            view_state=view_state,
            time_view_window_s=time_view,
            mp4_encoder=mp4_encoder,
            include_full_spec=include_full_spec,
        )
        try:
            perf = getattr(self._gl, "perf_stats", None)
            if callable(perf):
                snap = perf()
                if getattr(snap, "samples", 0) >= 2:
                    metadata["viewer_perf"] = {
                        "sample_count": int(getattr(snap, "samples", 0)),
                        "window_frames": int(getattr(snap, "window_frames", 0) or 0) or None,
                        "avg_fps": float(getattr(snap, "fps", 0.0)),
                        "avg_frame_ms": float(getattr(snap, "frame_ms", 0.0)),
                        "avg_cpu_submit_ms": float(getattr(snap, "cpu_ms", 0.0)),
                        "avg_wait_ms": float(getattr(snap, "wait_ms", 0.0)),
                        "avg_wait_raw_ms": float(getattr(snap, "wait_raw_ms", 0.0)),
                        "cpu_pct": float(getattr(snap, "cpu_pct", 0.0)),
                        "refresh_hz_used": (
                            float(getattr(snap, "refresh_hz_used")) if getattr(snap, "refresh_hz_used", None) is not None else None
                        ),
                        "refresh_hz_source": str(getattr(snap, "refresh_hz_source", "") or ""),
                        "label": str(getattr(snap, "bound", "") or ""),
                        "pacing_metric": "mad_sigma_ms",
                        "pacing_metric_ms": float(getattr(snap, "pacing_ms", 0.0)),
                    }
        except Exception:
            pass

        try:
            metadata["helix_governance"] = gov_payload
        except Exception:
            pass

        def _watermark_framebuffer(img: QImage) -> QImage:
            try:
                w = int(img.width())
                h = int(img.height())
            except Exception:
                return img
            if w <= 0 or h <= 0 or not wm_text:
                return img
            out_img = QImage(img)
            p = QPainter(out_img)
            p.setRenderHint(QPainter.Antialiasing, True)
            p.setRenderHint(QPainter.TextAntialiasing, True)
            try:
                p.save()
                p.setOpacity(0.08)
                font = QFont()
                font.setBold(True)
                font.setPixelSize(max(18, int(min(w, h) * 0.12)))
                p.setFont(font)
                p.setPen(QPen(Qt.white))
                p.translate(w / 2.0, h / 2.0)
                p.rotate(-30.0)
                p.drawText(QRectF(-w, -h, w * 2.0, h * 2.0), Qt.AlignCenter, str(wm_text))
                p.restore()
            except Exception:
                try:
                    p.restore()
                except Exception:
                    pass

            if wm_lines_list:
                try:
                    p.save()
                    p.setOpacity(0.70)
                    font = QFont()
                    font.setPixelSize(max(10, int(min(w, h) * 0.022)))
                    p.setFont(font)
                    p.setPen(QPen(Qt.white))
                    margin = max(8, int(min(w, h) * 0.02))
                    p.drawText(
                        QRect(margin, margin, max(1, w - 2 * margin), max(1, h - 2 * margin)),
                        Qt.AlignLeft | Qt.AlignBottom,
                        "\n".join(wm_lines_list),
                    )
                    p.restore()
                except Exception:
                    try:
                        p.restore()
                    except Exception:
                        pass
            p.end()
            return out_img

        # Pause playback during capture and restore after.
        prev_playing = False
        prev_time = float(now_s)
        try:
            prev_playing = bool(self._play_toggle.isChecked())
        except Exception:
            prev_playing = bool(getattr(self, "_is_playing", False))

        prev_overlay_visible = False
        prev_overlay_text = ""
        try:
            prev_overlay_visible = bool(self._overlay.isVisible())
            prev_overlay_text = str(self._overlay.text())
        except Exception:
            prev_overlay_visible = False
            prev_overlay_text = ""

        overlay_restore_scheduled = False

        def _restore_overlay() -> None:
            try:
                if prev_overlay_visible:
                    self._overlay.setText(prev_overlay_text)
                    self._overlay.show()
                else:
                    self._overlay.hide()
            except Exception:
                pass

        def _schedule_overlay_restore(delay_ms: int) -> None:
            nonlocal overlay_restore_scheduled
            overlay_restore_scheduled = True
            try:
                QTimer.singleShot(int(delay_ms), _restore_overlay)
            except Exception:
                pass

        try:
            try:
                self._session.set_status(f"Exporting resolve clip ({len(times)} frames)…")
            except Exception:
                pass
            # Show a lightweight progress overlay.
            try:
                self._overlay.setText("Exporting clip…")
                self._overlay.show()
                self._overlay_layer.raise_()
                self._overlay.raise_()
            except Exception:
                pass

            # Force pause (export should be deterministic).
            try:
                self._play_toggle.setChecked(False)
            except Exception:
                try:
                    self._gl.set_playing(False)  # type: ignore[attr-defined]
                except Exception:
                    pass

            import imageio.v2 as iio
            import shutil
            import subprocess
            from helix.support.subprocess import no_console_kwargs

            gif_buf = io.BytesIO()
            gif_writer = iio.get_writer(gif_buf, format="GIF", mode="I", duration=1.0 / float(fps))

            mp4_bytes = None
            mp4_proc = None
            mp4_tmp_dir = None
            mp4_path = None

            try:
                for idx, t_s in enumerate(times):
                    try:
                        self._gl.set_time_seconds(float(t_s), pause=True)  # type: ignore[attr-defined]
                    except Exception:
                        try:
                            self._gl.set_time_norm(float(t_s) / float(loop))  # type: ignore[attr-defined]
                        except Exception:
                            pass
                    try:
                        QApplication.processEvents()
                    except Exception:
                        pass
                    try:
                        img = self._gl.grabFramebuffer()  # type: ignore[attr-defined]
                    except Exception:
                        continue
                    try:
                        img = _watermark_framebuffer(img)
                    except Exception:
                        pass
                    frame = self._qimage_to_rgb_array(img)
                    if frame.size == 0:
                        continue

                    gif_writer.append_data(frame)

                    if mp4_encoder is not None:
                        if mp4_proc is None:
                            mp4_tmp_dir = temp.mkdtemp(prefix="helix_clip_")
                            mp4_path = mp4_tmp_dir / "clip.mp4"
                            h, w = int(frame.shape[0]), int(frame.shape[1])
                            cmd = [
                                str(mp4_encoder.exe),
                                "-hide_banner",
                                "-loglevel",
                                "error",
                                "-y",
                                "-f",
                                "rawvideo",
                                "-vcodec",
                                "rawvideo",
                                "-pix_fmt",
                                "rgb24",
                                "-s",
                                f"{w}x{h}",
                                "-r",
                                str(int(fps)),
                                "-i",
                                "pipe:0",
                                "-an",
                                "-vcodec",
                                str(mp4_encoder.codec),
                                "-pix_fmt",
                                "yuv420p",
                                "-movflags",
                                "+faststart",
                                str(mp4_path),
                            ]
                            try:
                                mp4_proc = subprocess.Popen(
                                    cmd,
                                    stdin=subprocess.PIPE,
                                    stdout=subprocess.DEVNULL,
                                    stderr=subprocess.PIPE,
                                    **no_console_kwargs(),
                                )
                            except Exception:
                                mp4_proc = None
                                mp4_tmp_dir = None
                                mp4_path = None

                        if mp4_proc is not None and mp4_proc.stdin is not None:
                            try:
                                mp4_proc.stdin.write(np.ascontiguousarray(frame).tobytes())
                            except Exception:
                                pass

                    if idx and idx % 12 == 0:
                        try:
                            self._overlay.setText(f"Exporting clip… {idx}/{len(times)}")
                        except Exception:
                            pass

                gif_writer.close()

                if mp4_proc is not None:
                    try:
                        if mp4_proc.stdin is not None:
                            mp4_proc.stdin.close()
                    except Exception:
                        pass
                    try:
                        _stdout, stderr = mp4_proc.communicate(timeout=20.0)
                    except Exception:
                        stderr = b""
                    if mp4_proc.returncode == 0 and mp4_path is not None and mp4_path.exists():
                        try:
                            mp4_bytes = mp4_path.read_bytes()
                        except Exception:
                            mp4_bytes = None
                    else:
                        _ = stderr  # keep best-effort (optional)
                        mp4_bytes = None

            finally:
                try:
                    gif_writer.close()
                except Exception:
                    pass
                try:
                    if mp4_proc is not None and mp4_proc.poll() is None:
                        mp4_proc.kill()
                except Exception:
                    pass
                try:
                    if mp4_tmp_dir is not None:
                        shutil.rmtree(mp4_tmp_dir, ignore_errors=True)
                except Exception:
                    pass

            gif_bytes = gif_buf.getvalue()
            try:
                metadata.setdefault("clip", {})["mp4_included"] = bool(mp4_bytes)
            except Exception:
                pass

            out = write_clip_zip(
                out_path=path_str,
                gif_bytes=gif_bytes,
                metadata=metadata,
                governance=gov_payload,
                mp4_bytes=mp4_bytes,
                spec_payload=spec_payload,
            )
            try:
                self._overlay.setText(f"Clip exported: {out}")
                self._overlay.show()
            except Exception:
                pass
            try:
                self._session.set_status(f"Exported resolve clip: {out}")
            except Exception:
                pass
            _schedule_overlay_restore(3500)
        except Exception as exc:
            try:
                self._overlay.setText(f"Export failed: {exc}")
                self._overlay.show()
            except Exception:
                pass
            try:
                self._session.error(f"Export clip failed: {exc}")
            except Exception:
                pass
            try:
                import traceback

                self._session.log(traceback.format_exc())
            except Exception:
                pass
            _schedule_overlay_restore(5000)
        finally:
            # Restore playhead + playback state.
            try:
                self._gl.set_time_seconds(float(prev_time), pause=True)  # type: ignore[attr-defined]
            except Exception:
                pass
            try:
                self._play_toggle.setChecked(bool(prev_playing))
            except Exception:
                try:
                    self._gl.set_playing(bool(prev_playing))  # type: ignore[attr-defined]
                except Exception:
                    pass
            if not overlay_restore_scheduled:
                _restore_overlay()

    def _follow_playhead_if_needed(self, t_s: float) -> bool:
        if self._gl is None:
            return False
        try:
            if not bool(self._follow_toggle.isChecked()):
                return False
        except Exception:
            return False
        if not bool(self._is_playing):
            return False
        now_t = clock.monotonic()
        if now_t < float(self._follow_suspend_until):
            return False
        engine = getattr(self._gl, "engine", None)
        if engine is None:
            return False
        loop = float(getattr(engine, "loop_duration", 0.0))
        if loop <= 1e-6:
            return False
        try:
            view_start, view_end = self._time_slider.view_window_seconds()  # type: ignore[attr-defined]
        except Exception:
            return False
        view_span = float(view_end) - float(view_start)
        if not (view_span > 1e-6) or view_span >= loop - 1e-6:
            return False

        loop_range: tuple[float, float] | None = None
        loop_a = 0.0
        loop_b = 0.0
        try:
            if bool(getattr(engine, "loop_enabled", False)) and getattr(engine, "loop_range", None) is not None:
                loop_a, loop_b = getattr(engine, "loop_range")
                loop_a = max(0.0, min(loop, float(loop_a)))
                loop_b = max(0.0, min(loop, float(loop_b)))
                if loop_b < loop_a:
                    loop_a, loop_b = loop_b, loop_a
                if loop_b - loop_a > 1e-6:
                    loop_range = (float(loop_a), float(loop_b))
        except Exception:
            loop_range = None

        # If looping a sub-range that's smaller than (or equal to) the current view,
        # pin the window to the loop and suppress follow panning until the user
        # zooms in enough to track within the loop span.
        if loop_range is not None:
            loop_a, loop_b = loop_range
            loop_span = float(loop_b) - float(loop_a)
            if float(view_span) >= loop_span - 1e-6:
                self._follow_pan_active = False
                self._follow_pan_dir = 0
                before = self._time_slider.view_window_seconds()  # type: ignore[attr-defined]
                self._follow_in_adjust = True
                try:
                    self._time_slider.set_view_window_seconds(loop_a, loop_b)  # type: ignore[attr-defined]
                    after = self._time_slider.view_window_seconds()  # type: ignore[attr-defined]
                    return any(abs(float(a) - float(b)) > 1e-9 for a, b in zip(before, after, strict=False))
                except Exception:
                    return False
                finally:
                    self._follow_in_adjust = False

        local_frac = (float(t_s) - float(view_start)) / float(view_span)
        start_margin = 0.12
        stop_margin = 0.20

        if not self._follow_pan_active:
            if local_frac > 1.0 - start_margin:
                self._follow_pan_active = True
                self._follow_pan_dir = +1
            elif local_frac < start_margin:
                self._follow_pan_active = True
                self._follow_pan_dir = -1
            else:
                return False
        else:
            if stop_margin < local_frac < (1.0 - stop_margin):
                self._follow_pan_active = False
                self._follow_pan_dir = 0
                return False

        prev_pan_at = float(self._last_follow_pan_at)
        if now_t - prev_pan_at < 0.05:
            return False
        self._last_follow_pan_at = now_t

        # Smoothly glide toward a target window position instead of teleporting.
        # Time-constant tuned so 1x playback feels responsive but not jittery.
        dt_pan = now_t - prev_pan_at if prev_pan_at > 1e-6 else 0.05
        # Clamp dt so long UI hitches don't turn easing into a teleport.
        dt_pan = max(0.0, min(0.08, float(dt_pan)))
        tau = 0.14
        alpha = 1.0 - math.exp(-max(0.0, dt_pan) / tau)
        alpha = max(0.18, min(0.75, float(alpha)))

        # Bias the playhead slightly off-center so forward playback shows more upcoming context.
        target_frac = 0.45 if self._follow_pan_dir > 0 else 0.55
        desired_target_start = float(t_s) - float(target_frac) * float(view_span)

        # If looping a sub-range, keep the view window within that range during follow.
        if loop_range is not None:
            clamp_min = float(loop_a)
            clamp_max = float(loop_b) - float(view_span)
            desired_target_start = max(clamp_min, min(clamp_max, float(desired_target_start)))

        desired_start = float(view_start) + (float(desired_target_start) - float(view_start)) * alpha
        # Clamp after easing as well (handles cases where view_start is out-of-range).
        if loop_range is not None:
            clamp_min = float(loop_a)
            clamp_max = float(loop_b) - float(view_span)
            desired_start = max(clamp_min, min(clamp_max, float(desired_start)))
        # Avoid tiny micro-adjustments when close to steady-state.
        if abs(float(desired_start) - float(view_start)) < float(view_span) * 0.01:
            return False
        desired_end = float(desired_start) + float(view_span)
        try:
            before = self._time_slider.view_window_seconds()  # type: ignore[attr-defined]
            self._follow_in_adjust = True
            self._time_slider.set_view_window_seconds(desired_start, desired_end)  # type: ignore[attr-defined]
            after = self._time_slider.view_window_seconds()  # type: ignore[attr-defined]
            return any(abs(float(a) - float(b)) > 1e-9 for a, b in zip(before, after, strict=False))
        except Exception:
            return False
        finally:
            self._follow_in_adjust = False

    def _on_time_marker_clicked(self, value: int) -> None:
        """Marker clicks jump to the nearest (or next) event within that bin."""
        if self._gl is None:
            return
        engine = getattr(self._gl, "engine", None)
        if engine is None:
            return
        loop = float(getattr(engine, "loop_duration", 0.0))
        if loop <= 1e-6:
            return
        bin_value = int(value)
        times = list(self._time_bin_events.get(bin_value) or [])
        if not times:
            return

        # Pause playback on interrogation clicks.
        try:
            self._gl.set_playing(False)  # type: ignore[attr-defined]
        except Exception:
            pass

        now = float(getattr(getattr(engine, "state", None), "time", 0.0))

        if self._last_time_bin_clicked != bin_value:
            idx = min(range(len(times)), key=lambda i: abs(float(times[i]) - now))
        else:
            idx = (int(self._time_bin_cycle.get(bin_value, -1)) + 1) % len(times)

        self._time_bin_cycle[bin_value] = idx
        self._last_time_bin_clicked = bin_value

        t_s = float(times[idx])
        frac = max(0.0, min(1.0, t_s / loop))
        try:
            self._block_time_slider = True
            self._time_slider.setValue(bin_value)
        finally:
            self._block_time_slider = False
        try:
            self._gl.set_time_norm(frac)  # type: ignore[attr-defined]
        except Exception:
            pass

    def _on_gl_time_updated(self, t: float) -> None:
        if self._gl is None:
            return
        if self._time_slider.isSliderDown():
            return
        if self._follow_playhead_if_needed(float(t)):
            return
        try:
            self._block_time_slider = True
            self._time_slider.setValue(int(self._time_slider.value_for_time_seconds(float(t))))  # type: ignore[attr-defined]
        finally:
            self._block_time_slider = False

    def _on_gl_playing_changed(self, playing: bool) -> None:
        self._is_playing = bool(playing)
        # While scrubbing, keep the Play checkbox stable so release-to-resume works
        # and the UI doesn't flicker between "playing" and "paused".
        if bool(playing) is False and bool(getattr(self, "_resume_play_after_scrub", False)) and self._time_slider.isSliderDown():
            return
        try:
            self._play_toggle.blockSignals(True)
            self._play_toggle.setChecked(bool(playing))
        except Exception:
            pass
        finally:
            try:
                self._play_toggle.blockSignals(False)
            except Exception:
                pass

    def _refresh_time_markers(self, spec: EditVisualizationSpec) -> None:
        """Show event ticks on the scrubber and enable click/hover affordances."""
        engine = getattr(self._gl, "engine", None)
        if engine is None:
            self._time_slider.set_markers([])  # type: ignore[attr-defined]
            self._time_bin_events = {}
            self._time_bin_cycle = {}
            self._last_time_bin_clicked = None
            return
        loop = float(getattr(engine, "loop_duration", 0.0))
        if loop <= 1e-6:
            self._time_slider.set_markers([])  # type: ignore[attr-defined]
            self._time_bin_events = {}
            self._time_bin_cycle = {}
            self._last_time_bin_clicked = None
            return
        normalized = bool(getattr(engine, "event_times_normalized", False))
        try:
            view_start, view_end = self._time_slider.view_window_seconds()  # type: ignore[attr-defined]
        except Exception:
            view_start, view_end = 0.0, loop
        view_start = max(0.0, min(loop, float(view_start)))
        view_end = max(0.0, min(loop, float(view_end)))
        if view_end <= view_start + 1e-9:
            view_start, view_end = 0.0, loop
        view_span = max(1e-9, float(view_end) - float(view_start))

        def _rgba_for_event(token: str) -> tuple[int, int, int, int]:
            t = str(token).strip().lower()
            if t in {"cut", "nick_primary", "nick_secondary"}:
                return (255, 160, 90, 220)
            if t in {"prime_init", "rt_synthesis"}:
                return (210, 124, 255, 220)
            if t in {"flap_resolution", "repair_complete"}:
                return (60, 220, 255, 220)
            if t in {"recognition"}:
                return (140, 191, 255, 210)
            return (170, 180, 205, 180)

        def _priority(token: str) -> int:
            t = str(token).strip().lower()
            if t in {"cut", "nick_primary", "nick_secondary"}:
                return 0
            if t in {"flap_resolution", "repair_complete"}:
                return 1
            if t in {"prime_init", "rt_synthesis"}:
                return 2
            if t in {"recognition"}:
                return 3
            return 5

        bins: dict[int, list[tuple[float, str, str, tuple[int, int, int, int]]]] = {}
        for ev in getattr(spec, "events", ()) or ():
            try:
                t_evt = float(getattr(ev, "t", 0.0))
            except Exception:
                continue
            if not math.isfinite(t_evt):
                continue
            t_s_raw = t_evt * loop if normalized else t_evt
            if abs(float(t_s_raw) - loop) <= 1e-6:
                t_s = loop - 1e-6
            else:
                t_mod = float(t_s_raw) % loop
                if abs(t_mod) <= 1e-12 and abs(float(t_s_raw)) > 1e-6:
                    t_s = loop - 1e-6
                else:
                    t_s = max(0.0, min(loop - 1e-6, t_mod))
            if not (view_start - 1e-9 <= t_s <= view_end + 1e-9):
                continue
            local_frac = (t_s - view_start) / view_span
            value = int(round(max(0.0, min(1.0, local_frac)) * 1000.0))

            typ = getattr(getattr(ev, "type", None), "value", None) or str(getattr(ev, "type", "event"))
            rgba = _rgba_for_event(typ)
            locus = getattr(ev, "index", None)
            if locus is None:
                locus = getattr(ev, "start", None)
            locus_label = f" @{int(locus)}" if locus is not None else ""
            bins.setdefault(value, []).append((float(t_s), typ, f"{typ}{locus_label}", rgba))

        self._time_bin_events = {}
        self._time_bin_cycle = {}
        self._last_time_bin_clicked = None

        markers: list[tuple[float, str, list[tuple[int, int, int, int]]]] = []
        for value, entries in sorted(bins.items(), key=lambda kv: kv[0]):
            frac = max(0.0, min(1.0, float(value) / 1000.0))
            entries_sorted = sorted(entries, key=lambda e: e[0])
            self._time_bin_events[int(value)] = [float(t) for (t, _typ, _label, _rgba) in entries_sorted]

            colors: list[tuple[int, int, int, int]] = []
            for _t_evt, typ, label, rgba in entries:
                if rgba not in colors:
                    colors.append(rgba)
            # Sort colors by the strongest semantic token in this bin.
            colors_sorted = sorted(colors, key=lambda rgba: min((_priority(t) for _t, t, _l, r in entries if r == rgba), default=9))
            colors_sorted = colors_sorted[:6]

            min_t = entries_sorted[0][0]
            max_t = entries_sorted[-1][0]
            pct_min = (float(min_t) / loop) * 100.0 if loop > 1e-6 else 0.0
            pct_max = (float(max_t) / loop) * 100.0 if loop > 1e-6 else 0.0
            lines: list[str] = []
            count = len(entries_sorted)
            if count == 1:
                lines.append(f"1 event @ {min_t:.3f}s ({pct_min:.1f}%)")
            else:
                lines.append(f"{count} events @ {min_t:.3f}–{max_t:.3f}s ({pct_min:.1f}–{pct_max:.1f}%)")
                lines.append("Click again to cycle within this bin.")
            max_show = 12
            for t_evt, _typ, label, _rgba in entries_sorted[:max_show]:
                lines.append(f"• {label} (t={t_evt:.3f}s)")
            if count > max_show:
                lines.append(f"… +{count - max_show} more")

            markers.append((frac, "\n".join(lines), colors_sorted))

        self._time_slider.set_markers(markers)  # type: ignore[attr-defined]

def build_overlay_lines(metrics: RunMetrics | None) -> list[str]:
    if metrics is None:
        return []
    summary = metrics.summary
    draw_label = summary.get("draws") or "—"
    run_label = f"Run #{summary.get('run_id', '—')} [{summary.get('run_kind', '—')}]"
    genome_label = summary.get("genome", "—")
    lines: list[str] = [f"{run_label} | Draws: {draw_label} | Genome: {genome_label}"]
    dag = metrics.dag_stats
    if any(dag.values()):
        lines.append(
            "DAG nodes: {nodes} · branches: {branches} · leaves: {leaves} · depth: {depth}".format(
                nodes=dag.get("nodes", 0),
                branches=dag.get("branch_nodes", 0),
                leaves=dag.get("leaves", 0),
                depth=dag.get("depth", 0),
            )
        )
    total_outcomes = metrics.intended_count + metrics.off_target_count + metrics.neutral_count
    lines.append(
        f"Outcomes: {total_outcomes} (Intended: {metrics.intended_count}, Off-target: {metrics.off_target_count}, Neutral: {metrics.neutral_count})"
    )
    lines.append(
        f"Prob mass → Intended: {metrics.intended_mass:.2f}  Off-target: {metrics.off_target_mass:.2f}  Neutral: {metrics.neutral_mass:.2f}"
    )
    perf_line = _build_perf_line(metrics.perf)
    if perf_line:
        lines.append(perf_line)
    if metrics.is_pcr:
        region = ""
        if (
            metrics.pcr_amplicon_start is not None
            and metrics.pcr_amplicon_end is not None
            and metrics.pcr_amplicon_end > metrics.pcr_amplicon_start
        ):
            region = f" ({metrics.pcr_amplicon_start}–{metrics.pcr_amplicon_end})"
        lines.append(
            "PCR: {length} bp{region} · {cycles} cycles · {mass:.2f} ng · mut {mut:.4f}".format(
                length=metrics.pcr_amplicon_length or 0,
                region=region,
                cycles=metrics.pcr_cycles or "?",
                mass=metrics.pcr_final_mass_ng or 0.0,
                mut=metrics.pcr_final_mutation_rate or 0.0,
            )
        )
    quality_line = _build_quality_line(metrics)
    if quality_line:
        lines.append(quality_line)
    return lines


def _build_perf_line(perf: Mapping[str, float]) -> str:
    if not perf:
        return ""
    parts: list[str] = []
    sim_ms = perf.get("sim_ms")
    if sim_ms is not None:
        parts.append(f"Sim {sim_ms:.0f} ms")
    viz_ms = perf.get("viz_ms")
    if viz_ms is not None:
        parts.append(f"Viz {viz_ms:.0f} ms")
    if not parts:
        return ""
    return "Perf: " + " | ".join(parts)


def _build_quality_line(metrics: RunMetrics) -> str:
    verdict = classify_run_quality(metrics)
    if not verdict.label:
        return ""
    return f"Quality: {verdict.label} – {verdict.details}"
