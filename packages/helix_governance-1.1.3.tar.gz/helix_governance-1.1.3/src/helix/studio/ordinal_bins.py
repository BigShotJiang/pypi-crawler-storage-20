from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class OrdinalTier:
    """
    Qualitative, ordinal-only tier used when quantitative outputs are suppressed.

    Intentionally avoids any numeric magnitude claims. A tier conveys ordering
    without implying calibrated probabilities or comparable scores.
    """

    level: int

    @property
    def label(self) -> str:
        lvl = max(1, int(self.level))
        return f"Tier {lvl}"


def tier_for_rank(rank: int) -> OrdinalTier:
    """
    Map a 1-indexed rank to a small set of stable ordinal tiers.

    The mapping is intentionally coarse and monotonic.
    """

    try:
        r = int(rank)
    except Exception:
        r = 10**9
    r = max(1, r)

    if r == 1:
        return OrdinalTier(level=1)
    if r <= 3:
        return OrdinalTier(level=2)
    if r <= 10:
        return OrdinalTier(level=3)
    return OrdinalTier(level=4)


def tier_fill_fraction(tier: OrdinalTier) -> float:
    """
    Return a discrete, non-metric fill fraction for UI glyphs.

    This is a presentation helper only; callers must not expose the numeric
    fraction to users in non-decision-grade modes.
    """

    lvl = max(1, int(tier.level))
    return {1: 1.0, 2: 0.78, 3: 0.56, 4: 0.36}.get(lvl, 0.36)


__all__ = ["OrdinalTier", "tier_for_rank", "tier_fill_fraction"]
