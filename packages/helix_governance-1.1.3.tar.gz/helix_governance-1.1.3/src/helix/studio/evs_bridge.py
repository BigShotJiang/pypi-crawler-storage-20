from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Optional


@dataclass
class GuideContext:
    guide_seq: str
    pam_pattern: str = "NGG"


def extract_guide_context(evs: Mapping[str, Any] | None) -> Optional[GuideContext]:
    """
    Extract a minimal guide/PAM context from an EVS document.

    This is intentionally tolerant; it looks in common EVS locations and
    returns None if it cannot find a usable guide.
    """
    if not isinstance(evs, Mapping):
        return None

    edit_plan = evs.get("editPlan") if isinstance(evs, Mapping) else None
    targets = edit_plan.get("targets") if isinstance(edit_plan, Mapping) else None
    if not isinstance(targets, list) or not targets:
        return None
    t0 = targets[0] if isinstance(targets[0], Mapping) else None
    if not t0:
        return None

    grna = t0.get("gRNA") if isinstance(t0, Mapping) else None
    guide_seq = ""
    pam = "NGG"
    if isinstance(grna, Mapping):
        guide_seq = str(grna.get("sequence") or "")
        pam = str(grna.get("pam") or pam)
    else:
        guide_seq = str(t0.get("sequence") or "")
        pam = str(t0.get("pam") or pam)

    guide_seq = guide_seq.strip().upper()
    if not guide_seq:
        return None
    return GuideContext(guide_seq=guide_seq, pam_pattern=pam.strip().upper() or "NGG")


# Prime editing helpers -----------------------------------------------------

@dataclass
class PrimeContext:
    rt_template: str
    nick_pos_bp: int
    pam_pattern: Optional[str] = None


def extract_prime_context(evs: Mapping[str, Any] | None) -> Optional[PrimeContext]:
    if not isinstance(evs, Mapping):
        return None
    prime = evs.get("prime")
    if not isinstance(prime, Mapping):
        return None
    rt = prime.get("rt_template")
    nick = prime.get("nick_pos_bp")
    if rt is None or nick is None:
        return None
    pam = prime.get("pam")
    try:
        nick_int = int(nick)
    except Exception:
        return None
    return PrimeContext(rt_template=str(rt), nick_pos_bp=nick_int, pam_pattern=str(pam) if pam else None)
