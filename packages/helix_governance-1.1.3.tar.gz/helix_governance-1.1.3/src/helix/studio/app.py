from __future__ import annotations

import argparse
import os
import platform
import signal
import sys
import importlib.util
from pathlib import Path
import time
import faulthandler
import logging
from pathlib import Path

from PySide6.QtCore import Qt, QCoreApplication, QTimer, QVersionNumber, qVersion, qInstallMessageHandler
from PySide6.QtWidgets import QApplication, QMainWindow
from PySide6.QtGui import QGuiApplication, QIcon, QFont, QScreen, QCursor

# Best-effort local load of helix_cuda_fields when running from source
def _ensure_cuda_fields() -> None:
    try:
        import helix_cuda_fields  # type: ignore  # noqa: F401
        return
    except ModuleNotFoundError:
        pass
    root = Path(__file__).resolve().parents[3]
    from helix import fs

    candidates = fs.glob_sorted(root, "helix_cuda_fields*.so")
    candidate = candidates[0] if candidates else None
    if candidate is None:
        return
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    spec = importlib.util.spec_from_file_location("helix_cuda_fields", candidate)
    if spec and spec.loader:
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)  # type: ignore[attr-defined]
        sys.modules["helix_cuda_fields"] = mod


_ensure_cuda_fields()


def _install_qt_warning_filter() -> None:
    """Suppress known-benign Qt warnings without hiding real issues."""

    if getattr(_install_qt_warning_filter, "_installed", False):
        return

    prev_handler = None

    def _handler(msg_type, context, message):  # type: ignore[override]
        debug = os.getenv("HELIX_STUDIO_DEBUG_QT_MESSAGES", "0") == "1"
        # PySide6 can emit this once when QtConcurrent registers conversions.
        if "Type conversion already registered from type QFuture<QString> to type QFuture<void>" in message:
            return
        if debug:
            try:
                origin = ""
                try:
                    ctx_file = getattr(context, "file", None)
                    ctx_line = getattr(context, "line", None)
                    ctx_func = getattr(context, "function", None)
                    if ctx_file or ctx_line or ctx_func:
                        origin = f" ({ctx_file}:{ctx_line} {ctx_func})"
                except Exception:
                    origin = ""
                sys.stderr.write(f"[Qt] {msg_type} {message}{origin}\n")
                sys.stderr.flush()
            except Exception:
                pass
        if prev_handler is not None:
            prev_handler(msg_type, context, message)

    prev_handler = qInstallMessageHandler(_handler)
    _install_qt_warning_filter._installed = True  # type: ignore[attr-defined]


_install_qt_warning_filter()

from helix.gui.opengl import configure_opengl_surface_format
from helix.gui.theme import apply_helix_theme
from helix import clock
from helix import temp
from helix.determinism import allow_nondeterminism
from .main_window import HelixStudioMainWindow, _default_project_root
from .ui_tokens import ui_scale_factor
from .session import SessionModel
from .project import ProjectModel
from .context import StudioContext
from .perf import install_exception_shield, PerfOverlay
from helix.config import HelixFeatures
from helix.ogn.manager import OgnManager
from helix.ogn.client import MockOGNClient
from helix.scientific_contract import load_policy, load_model_semantics

from .debug_runtime import install_window_tracker, log_pid

_ICON_CACHE: QIcon | None = None
_LOGGER = logging.getLogger(__name__)


def _try_enable_windows_per_monitor_dpi() -> None:
    """Best-effort opt-in to per-monitor DPI awareness on Windows.

    Some packaging/launcher paths can leave the process "DPI unaware", causing Windows
    to bitmap-scale the entire UI (blurry, wrong apparent resolution). Qt normally
    handles this, but this guardrail makes it explicit.
    """

    if os.name != "nt":
        return

    try:
        import ctypes

        user32 = ctypes.windll.user32
        # DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = (HANDLE)-4
        ctx = ctypes.c_void_p(-4)
        if hasattr(user32, "SetProcessDpiAwarenessContext"):
            user32.SetProcessDpiAwarenessContext(ctx)
            return
    except Exception:
        pass

    try:
        import ctypes

        shcore = ctypes.windll.shcore
        # PROCESS_PER_MONITOR_DPI_AWARE = 2
        if hasattr(shcore, "SetProcessDpiAwareness"):
            shcore.SetProcessDpiAwareness(2)
            return
    except Exception:
        pass

    try:
        import ctypes

        user32 = ctypes.windll.user32
        if hasattr(user32, "SetProcessDPIAware"):
            user32.SetProcessDPIAware()
    except Exception:
        pass


def _configure_terminal_ctrl_c() -> None:
    """Make Ctrl-C reliably terminate the process when launched from a terminal.

    With Qt/PySide, SIGINT can manifest as KeyboardInterrupt inside arbitrary Qt
    callbacks without unwinding `app.exec()`, leaving the UI running (or stuck)
    while printing "Error calling Python override ... KeyboardInterrupt".
    Restoring the default SIGINT action makes Ctrl-C always stop Helix Studio.
    """
    try:
        signal.signal(signal.SIGINT, signal.SIG_DFL)
    except Exception:
        # Best-effort; some platforms/embedders may not allow altering signals.
        return


def _configure_application(app: QApplication) -> None:
    """Apply global font after QApplication is created."""
    scale = ui_scale_factor()
    font = QFont("Inter")
    font.setPointSizeF(13.0 * scale)
    font.setHintingPreference(QFont.PreferFullHinting)
    font.setStyleStrategy(QFont.PreferAntialias)
    app.setFont(font)


def _load_app_icon() -> QIcon | None:
    """Best-effort load of the Helix Studio icon.

    Prefer the packaged resource image, but also fall back to legacy repo-root
    filenames for older dev checkouts.
    """
    global _ICON_CACHE
    if _ICON_CACHE is not None:
        return _ICON_CACHE
    studio_dir = Path(__file__).resolve().parent
    root = studio_dir.parents[3]

    candidates = [
        studio_dir / "resources" / "images" / "helix-studio-logo.png",
        studio_dir / "resources" / "images" / "helix-studio-logo.ico",
    ]
    candidates += [root / name for name in ("helix-studio-logo.png", "helix-studio-logo.ico", "logo.png", "icon.png")]

    for candidate in candidates:
        if candidate.exists():
            _ICON_CACHE = QIcon(str(candidate))
            break
    return _ICON_CACHE


def _detect_wsl() -> bool:
    rel = platform.release().lower()
    ver = platform.version().lower()
    return "microsoft" in rel or "wsl" in rel or "microsoft" in ver


def _choose_qt_platform(headless: bool) -> str | None:
    if headless:
        if os.name == "nt":
            return "minimal"
        return "offscreen"
    if _detect_wsl():
        forced = os.getenv("HELIX_WSL_QT_PLATFORM", "").strip()
        if forced:
            return forced
        # In WSL, default to XCB for stability in headless/CI; allow override via HELIX_WSL_QT_PLATFORM.
        return "xcb"
    return None


def _bootstrap_environment(headless: bool, softgl: bool, disable_gl: bool) -> None:
    _try_enable_windows_per_monitor_dpi()

    # Set platform and application attributes before QApplication is constructed.
    chosen = _choose_qt_platform(headless)
    if chosen:
        existing = (os.environ.get("QT_QPA_PLATFORM") or "").strip()
        # Under WSLg, XCB often reports/handles HiDPI poorly (esp. fractional scaling).
        # If the user explicitly set QT_QPA_PLATFORM, respect it.
        if not existing:
            os.environ["QT_QPA_PLATFORM"] = chosen

    qt_scale = os.getenv("HELIX_QT_SCALE_FACTOR", "").strip()
    if qt_scale and not os.environ.get("QT_SCALE_FACTOR"):
        os.environ["QT_SCALE_FACTOR"] = qt_scale

    if softgl:
        os.environ.setdefault("QT_OPENGL", "software")
        os.environ.setdefault("QSG_RHI_BACKEND", "opengl")

    if disable_gl:
        os.environ.setdefault("HELIX_STUDIO_NO_GL", "1")

    if headless and not os.environ.get("QT_QPA_PLATFORM"):
        os.environ["QT_QPA_PLATFORM"] = "offscreen"

    if not headless and sys.platform.startswith("linux"):
        if not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY"):
            # Fail fast with a clear error instead of letting Qt crash with double-free.
            sys.stderr.write(
                "Helix Studio: no DISPLAY/WAYLAND_DISPLAY detected. Run inside an X/Wayland session "
                "or start with --headless/--no-gl to bypass GPU widgets.\n"
            )
            sys.exit(1)

    # Prefer shared GL contexts for moderngl + Qt interop and ensure raster/software path
    QApplication.setAttribute(Qt.AA_ShareOpenGLContexts, True)
    if os.getenv("HELIX_FORCE_96DPI", "0") == "1":
        QApplication.setAttribute(Qt.AA_Use96Dpi, True)
    if softgl:
        QApplication.setAttribute(Qt.AA_ForceRasterWidgets, True)
        QApplication.setAttribute(Qt.AA_UseSoftwareOpenGL, True)

    _qt_version = QVersionNumber.fromString(qVersion())
    is_qt6_or_newer = QVersionNumber.compare(_qt_version, QVersionNumber(6, 0, 0)) >= 0

    if not is_qt6_or_newer:
        # Qt5 path: legacy attributes to enable HiDPI handling.
        QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    else:
        # Qt6+: deprecated attributes are no-ops and warn; use the modern policy instead.
        # Rounding policy applied after app creation via _configure_application
        pass

    # Compress bursts of UI events (mouse move, wheel) to keep the UI snappy.
    QCoreApplication.setAttribute(Qt.AA_CompressHighFrequencyEvents, True)


def launch(no_gl: bool = False, headless: bool | None = None):
    """Lightweight launcher used in tests and shake harness."""
    if headless is None:
        headless = os.getenv("QT_QPA_PLATFORM", "").lower() == "offscreen"
    _bootstrap_environment(headless=headless, softgl=False, disable_gl=no_gl)
    app = QApplication.instance() or QApplication([])
    _configure_application(app)
    icon = _load_app_icon()
    if icon is not None:
        app.setWindowIcon(icon)
    root = _default_project_root()
    ctx = StudioContext(project=ProjectModel(root_path=root, name=root.name), features=HelixFeatures())
    win = HelixStudioMainWindow(session=SessionModel(), ctx=ctx, enable_gl=not no_gl)
    if icon is not None:
        win.setWindowIcon(icon)
    apply_helix_theme(app)
    return win


def _parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Launch Helix Studio GUI")
    parser.add_argument("project", nargs="?", help="Path to a Helix project root")
    parser.add_argument("--headless", action="store_true", help="Force offscreen Qt platform (no display)")
    parser.add_argument("--softgl", action="store_true", help="Force software OpenGL for unstable drivers")
    parser.add_argument("--no-gl", action="store_true", help="Disable GL-heavy viewports (safe mode)")
    parser.add_argument("--safe", action="store_true", help="Enable a safe mode (softgl + no-gl)")
    parser.add_argument("--reset-layout", action="store_true", help="Ignore saved layout state and reset to defaults")
    parser.add_argument("--smoke", action="store_true", help="Launch and exit quickly (CI smoke check)")
    parser.add_argument("--smoke-welcome", action="store_true", help="Exercise Welcome dialog (CI smoke check)")
    parser.add_argument("--skip-welcome", action="store_true", help="Skip Welcome dialog on startup")
    parser.add_argument("--force-maximized", action="store_true", help="Force maximized window, ignoring saved geometry")
    parser.add_argument(
        "--screen",
        default=None,
        help="Force window to a screen: 'cursor', 'primary', or QScreen name",
    )
    return parser.parse_args(argv)


def _start_watchdog(app: QApplication) -> None:
    if os.getenv("HELIX_STUDIO_WATCHDOG", "0") != "1":
        return

    interval_ms = 100
    threshold_ms = 500
    last = clock.perf_counter()

    def _tick() -> None:
        nonlocal last
        now = clock.perf_counter()
        drift_ms = (now - last) * 1000.0 - interval_ms
        last = now
        if drift_ms > threshold_ms:
            msg = f"UI freeze detected: drift={drift_ms:.1f}ms"
            sys.stderr.write(msg + "\n")
            faulthandler.dump_traceback()
    timer = QTimer(app)
    timer.setInterval(interval_ms)
    timer.timeout.connect(_tick)
    timer.start()


def _format_screen(screen: QScreen | None) -> str:
    if screen is None:
        return "screen=None"
    geom = screen.geometry()
    avail = screen.availableGeometry()
    try:
        dpr = screen.devicePixelRatio()
    except Exception:
        dpr = 1.0
    try:
        logical = screen.logicalDotsPerInch()
    except Exception:
        logical = -1.0
    try:
        physical = screen.physicalDotsPerInch()
    except Exception:
        physical = -1.0
    return (
        f"name={screen.name()} "
        f"geom={geom.width()}x{geom.height()}+{geom.x()}+{geom.y()} "
        f"avail={avail.width()}x{avail.height()}+{avail.x()}+{avail.y()} "
        f"dpr={dpr:.2f} logicalDpi={logical:.1f} physicalDpi={physical:.1f}"
    )


def _log_scaling_debug(app: QApplication) -> None:
    if os.getenv("HELIX_SCALE_DEBUG", "0") != "1":
        return
    try:
        sys.stderr.write("[HelixScale] env:\n")
        for key in (
            "QT_QPA_PLATFORM",
            "XDG_SESSION_TYPE",
            "QT_AUTO_SCREEN_SCALE_FACTOR",
            "QT_SCALE_FACTOR",
            "QT_SCREEN_SCALE_FACTORS",
            "QT_SCALE_FACTOR_ROUNDING_POLICY",
            "QT_FONT_DPI",
            "HELIX_FORCE_96DPI",
        ):
            sys.stderr.write(f"  {key}={os.getenv(key, '')!r}\n")
        screens = app.screens()
        sys.stderr.write(f"[HelixScale] screens={len(screens)}\n")
        for screen in screens:
            sys.stderr.write(f"[HelixScale] {_format_screen(screen)}\n")
        sys.stderr.flush()
    except Exception:
        pass

    def _log_primary(screen: QScreen) -> None:
        try:
            sys.stderr.write(f"[HelixScale] primaryChanged {_format_screen(screen)}\n")
            sys.stderr.flush()
        except Exception:
            pass

    def _log_added(screen: QScreen) -> None:
        try:
            sys.stderr.write(f"[HelixScale] screenChanged {_format_screen(screen)}\n")
            sys.stderr.flush()
        except Exception:
            pass

    def _log_removed(screen: QScreen) -> None:
        try:
            sys.stderr.write(f"[HelixScale] screenRemoved {_format_screen(screen)}\n")
            sys.stderr.flush()
        except Exception:
            pass

    try:
        app.primaryScreenChanged.connect(_log_primary)
    except Exception:
        pass
    try:
        app.screenAdded.connect(_log_added)
        app.screenRemoved.connect(_log_removed)
    except Exception:
        pass

    for screen in app.screens():
        try:
            screen.geometryChanged.connect(lambda _=None, s=screen: _log_added(s))
            screen.logicalDotsPerInchChanged.connect(lambda _=None, s=screen: _log_added(s))
            screen.physicalDotsPerInchChanged.connect(lambda _=None, s=screen: _log_added(s))
            screen.availableGeometryChanged.connect(lambda _=None, s=screen: _log_added(s))
        except Exception:
            continue


def _log_window_metrics(window: QMainWindow) -> None:
    if os.getenv("HELIX_SCALE_DEBUG", "0") != "1":
        return
    try:
        screen = window.screen() if hasattr(window, "screen") else None
        geo = window.geometry()
        sys.stderr.write(
            "[HelixScale] window "
            f"geom={geo.width()}x{geo.height()}+{geo.x()}+{geo.y()} "
            f"{_format_screen(screen)}\n"
        )
        sys.stderr.flush()
    except Exception:
        pass


def _force_window_screen(window: QMainWindow, target: str) -> None:
    """Force window onto a target screen: 'cursor', 'primary', or a screen name."""

    def _pick_screen() -> QScreen | None:
        app = QGuiApplication.instance()
        if app is None:
            return None
        tgt = target.strip().lower()
        if tgt == "cursor":
            try:
                pos = QCursor.pos()
                screen = app.screenAt(pos)
                if screen is not None:
                    return screen
            except Exception:
                pass
        if tgt == "primary":
            return app.primaryScreen()
        for screen in app.screens():
            try:
                if screen.name().lower() == tgt:
                    return screen
            except Exception:
                continue
        return app.primaryScreen()

    def _apply() -> None:
        screen = _pick_screen()
        if screen is None:
            return
        geo = screen.availableGeometry()
        try:
            handle = window.windowHandle()
            if handle is not None:
                handle.setScreen(screen)
        except Exception:
            pass
        try:
            window.setGeometry(geo)
        except Exception:
            pass
        try:
            window.showMaximized()
        except Exception:
            try:
                window.setGeometry(geo)
            except Exception:
                pass
        _log_window_metrics(window)

    # Run after the window is shown so a windowHandle exists.
    QTimer.singleShot(0, _apply)


def _should_start_maximized() -> bool:
    if os.environ.get("HELIX_STUDIO_START_MAXIMIZED", "1") == "0":
        return False
    platform = os.environ.get("QT_QPA_PLATFORM", "").lower()
    session = os.environ.get("XDG_SESSION_TYPE", "").lower()
    if "wayland" in platform or session == "wayland":
        return False
    return True


def main(argv: list[str] | None = None) -> None:
    from helix.determinism.guard import enable_from_env

    enable_from_env()

    args = _parse_args(argv or sys.argv[1:])

    disable_gl = bool(os.getenv("HELIX_STUDIO_NO_GL") == "1" or args.no_gl or args.safe)
    softgl = bool(os.getenv("HELIX_STUDIO_SOFTGL") == "1" or args.softgl or args.safe)
    headless = bool(os.getenv("HELIX_STUDIO_HEADLESS") == "1" or args.headless)
    if args.reset_layout:
        os.environ["HELIX_STUDIO_RESET_LAYOUT"] = "1"
    if args.skip_welcome:
        os.environ["HELIX_STUDIO_SKIP_WELCOME"] = "1"
    if args.force_maximized:
        os.environ["HELIX_STUDIO_FORCE_MAXIMIZED"] = "1"
    if args.screen:
        os.environ["HELIX_STUDIO_FORCE_SCREEN"] = args.screen

    if not disable_gl:
        try:
            import moderngl  # noqa: F401
        except Exception:
            disable_gl = True
            os.environ.setdefault("HELIX_STUDIO_NO_GL", "1")

    try:
        from helix.support.events import log_event

        log_event(
            "studio.start",
            enable_gl=not disable_gl,
            softgl=softgl,
            headless=headless,
        )
    except Exception:
        pass

    # Seed contract identity so snapshots/reports carry policy/semantics hashes.
    try:
        load_policy()
        load_model_semantics()
    except Exception as exc:  # pragma: no cover - best-effort
        _LOGGER.warning("Failed to seed contract identity: %s", exc)

    _bootstrap_environment(headless=headless, softgl=softgl, disable_gl=disable_gl)
    _configure_terminal_ctrl_c()
    install_exception_shield()
    try:
        # Debug aid: enable faulthandler when requested (or when watchdog is enabled).
        if os.getenv("HELIX_STUDIO_FAULTHANDLER", "0") == "1" or os.getenv("HELIX_STUDIO_WATCHDOG", "0") == "1":
            faulthandler.enable()
            raw = os.getenv("HELIX_STUDIO_FAULTHANDLER_LATER_S", "").strip()
            if raw:
                try:
                    delay_s = float(raw)
                except Exception:
                    delay_s = 0.0
                if delay_s > 0:
                    faulthandler.dump_traceback_later(delay_s, repeat=True)
    except Exception:
        pass
    configure_opengl_surface_format()

    # Must be set before QApplication is constructed to avoid Qt warnings.
    try:
        QGuiApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    except AttributeError:
        pass

    app = QApplication(sys.argv[:1])
    _configure_application(app)
    _log_scaling_debug(app)
    log_pid("startup")
    install_window_tracker(app)
    try:
        QCoreApplication.setOrganizationName("Helix")
        QCoreApplication.setApplicationName("Studio")
    except Exception:
        pass
    icon = _load_app_icon()
    if icon is not None:
        app.setWindowIcon(icon)
    apply_helix_theme(app)

    with allow_nondeterminism(reason="ui"):
        _start_watchdog(app)

        if args.smoke_welcome:
            sys.exit(_run_welcome_smoke(app))

        session = SessionModel()
        default_root = Path(args.project).resolve() if args.project else _default_project_root()
        if (default_root / ".helix_project.json").exists():
            project = ProjectModel.load(default_root)
        else:
            project = ProjectModel(root_path=default_root, name=default_root.name)
        features = HelixFeatures()
        ogn_manager = OgnManager(MockOGNClient()) if features.enable_ogn else None
        ctx = StudioContext(project=project, features=features, ogn_manager=ogn_manager)

        window = HelixStudioMainWindow(session, ctx, enable_gl=not disable_gl)
        if icon is not None:
            window.setWindowIcon(icon)

        # Run welcome before showing any chrome; quit if dismissed.
        try:
            if not window._run_welcome_if_needed():  # type: ignore[attr-defined]
                sys.exit(0)
        except Exception:
            pass

        if os.getenv("HELIX_STUDIO_PERF_OVERLAY", "0") == "1":
            from PySide6.QtWidgets import QLabel

            overlay = PerfOverlay()
            label = QLabel(window)
            label.setObjectName("PerfOverlayLabel")
            label.setAttribute(Qt.WA_StyledBackground, True)
            label.setAttribute(Qt.WA_TransparentForMouseEvents)
            overlay.updated.connect(label.setText)
            label.setText(overlay.text())
            window.statusBar().addPermanentWidget(label)

        if args.smoke:
            window.show()
            QTimer.singleShot(250, app.quit)
            sys.exit(app.exec())

        # Start maximized to better use available screen space (WSLg/Windows snap can still resize later).
        force_screen = os.getenv("HELIX_STUDIO_FORCE_SCREEN", "")
        if force_screen:
            window.show()
            _force_window_screen(window, force_screen)
        else:
            if _should_start_maximized():
                window.showMaximized()
            else:
                window.show()
        QTimer.singleShot(0, lambda: _log_window_metrics(window))
        try:
            from .crash_dialog import maybe_show_crash_dialog

            maybe_show_crash_dialog(window)
        except Exception:
            pass
        sys.exit(app.exec())


def _run_welcome_smoke(app: QApplication) -> int:
    """Exercise Welcome recents cards and actions in a packaged build.

    Contract:
    - Opens Welcome
    - Ensures card stack exists
    - Opens ⋯ menu for a session card and triggers Copy path
    - Asserts copy handler runs (clipboard check best-effort)
    """
    try:
        from PySide6.QtWidgets import QToolButton

        from helix.studio.welcome import RecentSessionCard, WelcomeDialog
    except Exception as exc:
        sys.stderr.write(f"[smoke-welcome] imports failed: {exc}\n")
        return 2

    tmp_dir = temp.gettempdir() / f"helix_studio_smoke_{os.getpid()}"
    try:
        tmp_dir.mkdir(parents=True, exist_ok=True)
        session_path = tmp_dir / "smoke_session.helix.json"
        session_path.write_text("{}", encoding="utf-8")
    except Exception as exc:
        sys.stderr.write(f"[smoke-welcome] temp setup failed: {exc}\n")
        return 2

    dlg = WelcomeDialog(None, recent_sessions=[str(session_path)])
    dlg.set_recent_handler(lambda path: None)

    copied = {"value": None}
    original_copy = getattr(dlg, "_copy_to_clipboard", None)
    if callable(original_copy):

        def _copy_to_clipboard_smoke(text: str, *, global_pos=None) -> None:
            copied["value"] = text
            try:
                original_copy(text, global_pos=global_pos)
            except Exception:
                return

        setattr(dlg, "_copy_to_clipboard", _copy_to_clipboard_smoke)

    clipboard = QApplication.clipboard()
    before_clip = ""
    clipboard_supported = False
    if clipboard is not None:
        try:
            before_clip = clipboard.text()
        except Exception:
            before_clip = ""
        try:
            sentinel = f"helix-smoke-{os.getpid()}"
            clipboard.setText(sentinel)
            app.processEvents()
            clipboard_supported = clipboard.text() == sentinel
        except Exception:
            clipboard_supported = False

    result = 0
    try:
        dlg.show()
        app.processEvents()

        cards = [
            card
            for card in dlg.findChildren(RecentSessionCard)
            if card.property("variant") == "session"
        ]
        if not cards:
            sys.stderr.write("[smoke-welcome] no session cards found\n")
            return 1

        card = cards[0]
        menu_btn = card.findChild(QToolButton, "RecentCardMenu")
        if menu_btn is None:
            sys.stderr.write("[smoke-welcome] menu button not found\n")
            return 1

        menu_btn.setEnabled(True)

        triggered = {"ok": False}

        def _show_recent_actions_menu_smoke(payload: str, global_pos) -> None:
            menu = dlg._build_recent_actions_menu(payload, global_pos)

            def _trigger_copy() -> None:
                for action in menu.actions():
                    if action.text().strip().lower() == "copy path":
                        triggered["ok"] = True
                        action.trigger()
                        menu.close()
                        return
                menu.close()

            QTimer.singleShot(0, _trigger_copy)
            QTimer.singleShot(750, menu.close)
            menu.exec(global_pos)

        setattr(dlg, "_show_recent_actions_menu", _show_recent_actions_menu_smoke)

        menu_btn.click()
        app.processEvents()

        if not triggered["ok"]:
            sys.stderr.write("[smoke-welcome] failed to trigger copy action\n")
            return 1
        if copied["value"] != str(session_path):
            sys.stderr.write("[smoke-welcome] copy handler did not run\n")
            return 1

        if clipboard_supported and clipboard is not None:
            expected = str(session_path)
            after_clip = ""
            for _ in range(12):
                app.processEvents()
                try:
                    after_clip = clipboard.text()
                except Exception:
                    after_clip = ""
                    break
                if after_clip == expected:
                    break
                time.sleep(0.05)
            if after_clip != expected:
                sys.stderr.write(
                    f"[smoke-welcome] clipboard mismatch (supported): expected={expected} got={after_clip!r}\n"
                )
                return 1
        elif clipboard is not None:
            try:
                after_clip = clipboard.text()
                if after_clip != str(session_path):
                    sys.stderr.write("[smoke-welcome] clipboard unavailable or blocked; skipping check\n")
            except Exception:
                sys.stderr.write("[smoke-welcome] clipboard unavailable or blocked; skipping check\n")

        return 0
    except Exception as exc:
        sys.stderr.write(f"[smoke-welcome] exception: {exc}\n")
        result = 2
        return result
    finally:
        try:
            dlg.close()
            app.processEvents()
        except Exception:
            pass
        if clipboard is not None:
            try:
                clipboard.setText(before_clip)
            except Exception:
                pass


if __name__ == "__main__":
    main()
