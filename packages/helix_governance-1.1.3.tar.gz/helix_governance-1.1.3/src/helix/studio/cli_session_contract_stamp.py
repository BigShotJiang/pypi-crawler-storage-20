from __future__ import annotations

# Helix CLI Session Contract stamp (embedded into exported/session artifacts).
#
# NOTE: This is intentionally a constant, not computed at runtime. It is updated only via
# the CLI Session Contract bump workflow (vN -> vN+1).

CLI_SESSION_CONTRACT_ID = "cli_session_contract_v2"

# The contract hash is the stable tree hash emitted by `tools/run_cli_session_contract.py`
# for the corresponding `tests/e2e/test_cli_session_contract_v2.py`, after v2 normalization.
CLI_SESSION_CONTRACT_HASH = "518be1abd20a080a233c4dfae460aaebd13f3de88fe14ea5b038244750f1419a"
