from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Mapping

from helix.studio.experiment_spec import experiment_spec_to_dict

from helix import bioinformatics


@dataclass(frozen=True)
class PrimerDesignConfig:
    flank: int = 150
    primer_len_min: int = 18
    primer_len_max: int = 24
    gc_min: float = 0.35
    gc_max: float = 0.65
    tm_min: float = 55.0
    tm_max: float = 65.0
    tm_opt: float = 60.0
    gc_opt: float = 0.5
    max_homopolymer: int = 4
    min_amplicon_length: int = 100
    max_amplicon_length: int = 500


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n").encode(
        "utf-8"
    )


def _primary_target_entry(
    *,
    experiment_spec: Mapping[str, Any] | None,
    guide: Mapping[str, Any] | None,
    genome_sequences: Mapping[str, Any] | None,
    window_radius: int = 120,
) -> dict[str, Any] | None:
    spec = experiment_spec_to_dict(experiment_spec)
    locus = spec.get("locus") if isinstance(spec.get("locus"), Mapping) else {}
    contig = str(locus.get("chr") or locus.get("contig") or "")
    if not contig:
        return None
    try:
        start = int(locus.get("start", 0))
        end = int(locus.get("end", start + 1))
    except Exception:
        return None
    if end <= start:
        return None
    center = (start + end) // 2
    if isinstance(guide, Mapping):
        if guide.get("cut_index") is not None or guide.get("cutIndex") is not None:
            cut_index = guide.get("cut_index") if "cut_index" in guide else guide.get("cutIndex")
            try:
                center = int(start + int(cut_index))
            except Exception:
                pass
        else:
            try:
                gstart = int(guide.get("start"))
                gend = int(guide.get("end", gstart + 1))
                if gend > gstart:
                    center = start + (gstart + gend) // 2
            except Exception:
                pass
    win_start = max(0, center - int(window_radius))
    win_end = center + int(window_radius)
    seq_len = None
    if isinstance(genome_sequences, Mapping):
        seq = genome_sequences.get(contig)
        if isinstance(seq, str):
            seq_len = len(seq)
    if seq_len:
        win_end = min(int(seq_len), win_end)
    if win_end <= win_start:
        win_end = win_start + 1
    return {
        "hitKey": "primary_target",
        "contig": contig,
        "start": start,
        "end": end,
        "strand": str(locus.get("strand") or "+"),
        "recommendedAmpliconWindow": {"start": win_start, "end": win_end},
        "notes": ["Primary target locus from experiment spec."],
    }


def _is_primary_hit_key(value: Any) -> bool:
    key = str(value or "")
    return key == "primary_target" or key.endswith("::primary_target")


def _design_for_hit(
    hit: Mapping[str, Any],
    *,
    genome_sequences: Mapping[str, Any] | None,
    config: PrimerDesignConfig,
) -> dict[str, Any] | None:
    contig = str(hit.get("contig") or "")
    if not contig:
        return None
    if not isinstance(genome_sequences, Mapping):
        return {
            "id": str(hit.get("hitKey") or ""),
            "hitKey": str(hit.get("hitKey") or ""),
            "contig": contig,
            "targetStart": _safe_int(hit.get("start", 0), 0),
            "targetEnd": _safe_int(hit.get("end", 0), 0),
            "ampliconStart": None,
            "ampliconEnd": None,
            "ampliconLength": None,
            "forwardPrimer": None,
            "reversePrimer": None,
            "status": "failed",
            "notes": ["missing genome sequence"],
        }
    seq = genome_sequences.get(contig)
    if not isinstance(seq, str) or not seq:
        return {
            "id": str(hit.get("hitKey") or ""),
            "hitKey": str(hit.get("hitKey") or ""),
            "contig": contig,
            "targetStart": _safe_int(hit.get("start", 0), 0),
            "targetEnd": _safe_int(hit.get("end", 0), 0),
            "ampliconStart": None,
            "ampliconEnd": None,
            "ampliconLength": None,
            "forwardPrimer": None,
            "reversePrimer": None,
            "status": "failed",
            "notes": ["missing contig sequence"],
        }
    window = hit.get("recommendedAmpliconWindow") if isinstance(hit.get("recommendedAmpliconWindow"), Mapping) else {}
    try:
        amp_start = int(window.get("start", hit.get("start", 0)))
        amp_end = int(window.get("end", hit.get("end", 0)))
    except Exception:
        return None
    design = design_primer_pair(
        seq,
        amplicon_start=amp_start,
        amplicon_end=amp_end,
        config=config,
    )
    hit_key = str(hit.get("hitKey") or f"{contig}:{amp_start}-{amp_end}:{hit.get('strand') or ''}")
    forward = (design.get("forward") or {}).get("sequence") if isinstance(design.get("forward"), Mapping) else None
    reverse = (design.get("reverse") or {}).get("sequence") if isinstance(design.get("reverse"), Mapping) else None
    status = "ok" if forward and reverse else "failed"
    notes = list(design.get("notes") or [])
    if status == "failed" and not notes:
        notes.append("primer design failed")
    return {
        "id": hit_key,
        "hitKey": hit_key,
        "contig": contig,
        "targetStart": _safe_int(hit.get("start", amp_start), int(amp_start)),
        "targetEnd": _safe_int(hit.get("end", amp_end), int(amp_end)),
        "ampliconStart": design.get("amplicon_start"),
        "ampliconEnd": design.get("amplicon_end"),
        "ampliconLength": design.get("amplicon_length"),
        "forwardPrimer": forward,
        "reversePrimer": reverse,
        "status": status,
        "notes": notes,
    }


def primer_plan_json_bytes(plan: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(plan))


def primer_plan_sha256(plan: Mapping[str, Any]) -> str:
    return hashlib.sha256(primer_plan_json_bytes(plan)).hexdigest()


def _gc_fraction(seq: str) -> float:
    if not seq:
        return 0.0
    seq = seq.upper()
    gc = seq.count("G") + seq.count("C")
    return float(gc) / float(len(seq))


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _tm_wallace(seq: str) -> float:
    seq = seq.upper()
    a = seq.count("A")
    t = seq.count("T")
    g = seq.count("G")
    c = seq.count("C")
    return float(2 * (a + t) + 4 * (g + c))


def _has_homopolymer(seq: str, max_run: int) -> bool:
    if max_run <= 0:
        return False
    run = 1
    last = ""
    for base in seq.upper():
        if base == last:
            run += 1
            if run > max_run:
                return True
        else:
            run = 1
            last = base
    return False


def _score_primer(seq: str, config: PrimerDesignConfig) -> tuple[float, float, float]:
    gc = _gc_fraction(seq)
    tm = _tm_wallace(seq)
    score = 0.0
    score += abs(tm - config.tm_opt)
    score += abs(gc - config.gc_opt) * 10.0
    score += abs(len(seq) - ((config.primer_len_min + config.primer_len_max) / 2.0)) * 0.5
    return score, gc, tm


def _primer_candidates(
    sequence: str,
    region_start: int,
    region_end: int,
    *,
    config: PrimerDesignConfig,
    reverse: bool = False,
    relaxed: bool = False,
) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    seq = sequence.upper()
    region_start = max(0, region_start)
    region_end = min(len(seq), region_end)
    if region_end <= region_start:
        return candidates
    for length in range(config.primer_len_min, config.primer_len_max + 1):
        for start in range(region_start, max(region_start, region_end - length + 1)):
            end = start + length
            if end > region_end:
                continue
            primer_seq = seq[start:end]
            if reverse:
                primer_seq = bioinformatics.reverse_complement(primer_seq)
            if _has_homopolymer(primer_seq, config.max_homopolymer):
                continue
            gc = _gc_fraction(primer_seq)
            tm = _tm_wallace(primer_seq)
            if not relaxed:
                if not (config.gc_min <= gc <= config.gc_max):
                    continue
                if not (config.tm_min <= tm <= config.tm_max):
                    continue
            score, gc, tm = _score_primer(primer_seq, config)
            candidates.append(
                {
                    "start": start,
                    "end": end,
                    "sequence": primer_seq,
                    "gc": round(gc, 4),
                    "tm": round(tm, 2),
                    "score": round(score, 4),
                }
            )
    candidates.sort(key=lambda c: (c["score"], c["start"], c["end"], c["sequence"]))
    return candidates


def design_primer_pair(
    sequence: str,
    *,
    amplicon_start: int,
    amplicon_end: int,
    config: PrimerDesignConfig | None = None,
) -> dict[str, Any]:
    if config is None:
        config = PrimerDesignConfig()
    seq = bioinformatics.normalize_sequence(sequence)
    if not seq:
        return {
            "forward": None,
            "reverse": None,
            "amplicon_start": None,
            "amplicon_end": None,
            "amplicon_length": 0,
            "notes": ["empty sequence"],
        }

    amp_start = max(0, int(amplicon_start))
    amp_end = min(len(seq), int(amplicon_end))
    if amp_end <= amp_start:
        amp_end = min(len(seq), amp_start + 1)

    left_region_start = max(0, amp_start - config.flank)
    left_region_end = min(len(seq), amp_start)
    right_region_start = max(0, amp_end)
    right_region_end = min(len(seq), amp_end + config.flank)

    notes: list[str] = []

    fwd_candidates = _primer_candidates(seq, left_region_start, left_region_end, config=config, reverse=False)
    if not fwd_candidates:
        fallback_end = min(len(seq), amp_start + config.flank)
        if fallback_end > left_region_end:
            fwd_candidates = _primer_candidates(seq, left_region_start, fallback_end, config=config, reverse=False)
            if fwd_candidates:
                notes.append("forward primer placed within target window")
    if not fwd_candidates:
        fwd_candidates = _primer_candidates(
            seq,
            left_region_start,
            min(len(seq), amp_start + config.flank),
            config=config,
            reverse=False,
            relaxed=True,
        )
        if fwd_candidates:
            notes.append("forward primer constraints relaxed")

    rev_candidates = _primer_candidates(seq, right_region_start, right_region_end, config=config, reverse=True)
    if not rev_candidates:
        fallback_start = max(0, amp_end - config.flank)
        if fallback_start < right_region_start:
            rev_candidates = _primer_candidates(seq, fallback_start, right_region_end, config=config, reverse=True)
            if rev_candidates:
                notes.append("reverse primer placed within target window")
    if not rev_candidates:
        rev_candidates = _primer_candidates(
            seq,
            max(0, amp_end - config.flank),
            right_region_end,
            config=config,
            reverse=True,
            relaxed=True,
        )
        if rev_candidates:
            notes.append("reverse primer constraints relaxed")

    if not fwd_candidates:
        notes.append("no forward primer candidate within constraints")
    if not rev_candidates:
        notes.append("no reverse primer candidate within constraints")

    best_pair = None
    for fwd in fwd_candidates[:50]:
        for rev in rev_candidates[:50]:
            amplicon_len = int(rev["end"]) - int(fwd["start"])
            if amplicon_len <= 0:
                continue
            if config.min_amplicon_length <= amplicon_len <= config.max_amplicon_length:
                best_pair = (fwd, rev, amplicon_len)
                break
        if best_pair:
            break

    if best_pair is None and fwd_candidates and rev_candidates:
        fwd = fwd_candidates[0]
        rev = rev_candidates[0]
        amplicon_len = int(rev["end"]) - int(fwd["start"])
        best_pair = (fwd, rev, amplicon_len)
        if amplicon_len > 0:
            notes.append("amplicon length outside preferred range")

    if best_pair is None:
        return {
            "forward": None,
            "reverse": None,
            "amplicon_start": amp_start,
            "amplicon_end": amp_end,
            "amplicon_length": max(0, amp_end - amp_start),
            "notes": notes or ["no primer pair found"],
        }

    fwd, rev, amplicon_len = best_pair
    return {
        "forward": fwd,
        "reverse": rev,
        "amplicon_start": int(fwd["start"]),
        "amplicon_end": int(rev["end"]),
        "amplicon_length": int(amplicon_len),
        "notes": notes,
    }


def build_primer_plan(
    validation_plan: Mapping[str, Any],
    *,
    genome_sequences: Mapping[str, Any] | None = None,
    config: PrimerDesignConfig | None = None,
    validation_plan_sha256: str | None = None,
    experiment_spec: Mapping[str, Any] | None = None,
    guide: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    if config is None:
        config = PrimerDesignConfig()
    union_block = validation_plan.get("union") if isinstance(validation_plan.get("union"), Mapping) else None
    if isinstance(union_block, Mapping) and isinstance(union_block.get("topHits"), list):
        hits = union_block.get("topHits")
    else:
        hits = validation_plan.get("topHits") if isinstance(validation_plan.get("topHits"), list) else []
    pairs: list[dict[str, Any]] = []
    seen_keys: set[str] = set()

    primary_entries: list[Mapping[str, Any]] = []
    targets = validation_plan.get("targets") if isinstance(validation_plan.get("targets"), list) else []
    if isinstance(targets, list) and targets:
        for entry in targets:
            if not isinstance(entry, Mapping):
                continue
            primary = entry.get("primaryTarget") if isinstance(entry.get("primaryTarget"), Mapping) else None
            if isinstance(primary, Mapping):
                primary_entries.append(primary)
    else:
        primary = validation_plan.get("primaryTarget") if isinstance(validation_plan.get("primaryTarget"), Mapping) else None
        if primary is None:
            primary = _primary_target_entry(
                experiment_spec=experiment_spec,
                guide=guide,
                genome_sequences=genome_sequences,
            )
        if isinstance(primary, Mapping):
            primary_entries.append(primary)

    for primary in primary_entries:
        pair = _design_for_hit(primary, genome_sequences=genome_sequences, config=config)
        if pair:
            key = str(pair.get("hitKey") or "")
            if key and key not in seen_keys:
                seen_keys.add(key)
                pairs.append(pair)

    for hit in hits:
        if not isinstance(hit, Mapping):
            continue
        pair = _design_for_hit(hit, genome_sequences=genome_sequences, config=config)
        if pair:
            key = str(pair.get("hitKey") or "")
            if key and key not in seen_keys:
                seen_keys.add(key)
                pairs.append(pair)

    pairs.sort(
        key=lambda p: (
            0 if _is_primary_hit_key(p.get("hitKey")) else 1,
            p.get("hitKey") or "",
            p.get("contig") or "",
            p.get("targetStart") or 0,
        )
    )

    return {
        "schema": "helix_primer_plan_v1",
        "validationPlanSha256": str(validation_plan_sha256 or ""),
        "primerPairs": pairs,
    }


__all__ = [
    "PrimerDesignConfig",
    "design_primer_pair",
    "build_primer_plan",
    "primer_plan_json_bytes",
    "primer_plan_sha256",
]
