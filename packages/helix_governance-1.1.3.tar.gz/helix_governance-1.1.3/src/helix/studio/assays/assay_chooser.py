from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Mapping

from helix.studio.experiment_spec import experiment_spec_to_dict
from helix.studio.outcomes.hotspots import allele_key_from_entry


ASSAY_ORDER = ["AMPLICONSEQ", "SANGER", "LONGREAD"]


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (
        json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n"
    ).encode("utf-8")


def assay_plan_json_bytes(plan: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(plan))


def assay_plan_sha256(plan: Mapping[str, Any]) -> str:
    return hashlib.sha256(assay_plan_json_bytes(plan)).hexdigest()


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _safe_int(value: Any, default: int | None = None) -> int | None:
    try:
        return int(value)
    except Exception:
        return default


def _norm(value: Any) -> str:
    try:
        import enum

        if isinstance(value, enum.Enum):
            value = value.value
    except Exception:
        pass
    return str(value or "").strip().lower()


def _prime_warnings_flag(warnings: list[Any]) -> bool:
    for warning in warnings:
        text = _norm(warning)
        if "truncation" in text or "nick" in text:
            return True
    return False


def _desired_frequency(
    report: Mapping[str, Any],
    *,
    intent: str,
) -> float:
    allele_spectrum = report.get("alleleSpectrum") if isinstance(report.get("alleleSpectrum"), list) else []
    intent = _norm(intent)

    prime_outcomes = report.get("primeOutcomes") if isinstance(report.get("primeOutcomes"), list) else []
    if prime_outcomes:
        for entry in prime_outcomes:
            if not isinstance(entry, Mapping):
                continue
            if _norm(entry.get("category")) == "desired_edit":
                return max(0.0, min(1.0, _safe_float(entry.get("probability"), 0.0)))

    base_outcomes = report.get("baseOutcomes") if isinstance(report.get("baseOutcomes"), list) else []
    if base_outcomes:
        for entry in base_outcomes:
            if not isinstance(entry, Mapping):
                continue
            if _norm(entry.get("category")) == "desired_edit":
                return max(0.0, min(1.0, _safe_float(entry.get("probability"), 0.0)))

    if intent == "prime_edit":
        for entry in allele_spectrum:
            if not isinstance(entry, Mapping):
                continue
            delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
            if _norm(delta.get("label")) in {"desired_edit", "desired"} or _norm(delta.get("type")) == "prime_desired":
                return max(0.0, min(1.0, _safe_float(entry.get("frequency"), 0.0)))
        return 0.0

    if intent == "knockout":
        desired = 0.0
        for entry in allele_spectrum:
            if not isinstance(entry, Mapping):
                continue
            delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
            kind = _norm(delta.get("type"))
            if kind not in {"del", "ins"}:
                continue
            length = delta.get("length")
            if length is None and kind == "ins":
                length = len(str(delta.get("sequence") or ""))
            length_int = _safe_int(length, 0) or 0
            if length_int <= 0:
                continue
            if length_int % 3 != 0:
                desired += _safe_float(entry.get("frequency"), 0.0)
        return max(0.0, min(1.0, desired))

    if intent in {"substitution", "insertion", "promoter_edit"}:
        desired = 0.0
        for entry in allele_spectrum:
            if not isinstance(entry, Mapping):
                continue
            delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
            if _norm(delta.get("label")) in {"desired", "desired_edit"}:
                desired += _safe_float(entry.get("frequency"), 0.0)
        return max(0.0, min(1.0, desired))

    return 0.0


def _spectrum_entropy(report: Mapping[str, Any]) -> int:
    allele_spectrum = report.get("alleleSpectrum") if isinstance(report.get("alleleSpectrum"), list) else []
    count = 0
    for entry in allele_spectrum:
        if not isinstance(entry, Mapping):
            continue
        freq = _safe_float(entry.get("frequency"), 0.0)
        if freq < 0.02:
            continue
        delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
        kind = _norm(delta.get("type"))
        label = _norm(delta.get("label"))
        if kind == "other" or label in {"other", "failure"} or "failure" in kind:
            continue
        count += 1
    return count


def _truncated_spectrum(report: Mapping[str, Any]) -> tuple[bool, float]:
    allele_spectrum = report.get("alleleSpectrum") if isinstance(report.get("alleleSpectrum"), list) else []
    other_freq = 0.0
    for entry in allele_spectrum:
        if not isinstance(entry, Mapping):
            continue
        delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
        kind = _norm(delta.get("type"))
        label = _norm(delta.get("label"))
        if kind == "other" or label == "other":
            other_freq += _safe_float(entry.get("frequency"), 0.0)
    return (other_freq > 0.0) or (other_freq > 0.05), other_freq


def _high_risk_count(validation_plan: Mapping[str, Any]) -> int:
    high = validation_plan.get("highRiskCount")
    if high is not None:
        try:
            return int(high)
        except Exception:
            pass
    count = 0
    hits = validation_plan.get("topHits") if isinstance(validation_plan.get("topHits"), list) else []
    for hit in hits:
        if not isinstance(hit, Mapping):
            continue
        if _norm(hit.get("riskTier")) == "high":
            count += 1
    return count


def _primer_pairs(primer_plan: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    pairs = primer_plan.get("primerPairs") if isinstance(primer_plan.get("primerPairs"), list) else []
    return [p for p in pairs if isinstance(p, Mapping)]


def _primary_primer_pair(
    primer_plan: Mapping[str, Any],
    experiment_spec: Mapping[str, Any],
    *,
    target_id: str | None = None,
) -> Mapping[str, Any] | None:
    pairs = _primer_pairs(primer_plan)
    if target_id:
        target_key = f"{target_id}::primary_target"
        for pair in pairs:
            if _norm(pair.get("hitKey")) == _norm(target_key):
                status = _norm(pair.get("status"))
                if status and status != "ok":
                    return None
                return pair
    for pair in pairs:
        key = _norm(pair.get("hitKey"))
        if key in {"primary_target", "primary", "target"}:
            status = _norm(pair.get("status"))
            if status and status != "ok":
                return None
            return pair
    spec = experiment_spec_to_dict(experiment_spec)
    locus = spec.get("locus") if isinstance(spec.get("locus"), Mapping) else {}
    contig = str(locus.get("chr") or locus.get("contig") or "")
    if not contig:
        return None
    try:
        start = int(locus.get("start", 0))
        end = int(locus.get("end", start + 1))
    except Exception:
        return None
    for pair in pairs:
        if str(pair.get("contig") or "") != contig:
            continue
        try:
            target_start = int(pair.get("targetStart", 0))
            target_end = int(pair.get("targetEnd", target_start + 1))
        except Exception:
            continue
        if target_end <= target_start:
            continue
        if target_start < end and target_end > start:
            return pair
    return None


def _has_primers(pair: Mapping[str, Any] | None) -> bool:
    if not isinstance(pair, Mapping):
        return False
    status = _norm(pair.get("status"))
    if status and status != "ok":
        return False
    return bool(pair.get("forwardPrimer") and pair.get("reversePrimer"))


def _amplicon_length(pair: Mapping[str, Any] | None) -> int | None:
    if not isinstance(pair, Mapping):
        return None
    return _safe_int(pair.get("ampliconLength"), None)


def _amplicon_window(pair: Mapping[str, Any] | None) -> dict[str, int] | None:
    if not isinstance(pair, Mapping):
        return None
    start = _safe_int(pair.get("ampliconStart"), None)
    end = _safe_int(pair.get("ampliconEnd"), None)
    if start is None or end is None:
        return None
    if end <= start:
        return None
    return {"start": start, "end": end}


def _infer_insertion_length(spec: Mapping[str, Any]) -> int | None:
    spec = experiment_spec_to_dict(spec)
    for section in ("constraints", "assumptions"):
        data = spec.get(section)
        if not isinstance(data, Mapping):
            continue
        for key in ("insertLength", "insertionLength", "insert_len", "insert_size"):
            if key in data:
                return _safe_int(data.get(key), None)
    return None


def _compute_clones_needed(p_desired: float, target_confidence: float) -> int | None:
    if p_desired >= 1.0:
        return 1
    if p_desired <= 0.0:
        return None
    denom = math.log(max(1e-12, 1.0 - p_desired))
    if denom >= 0:
        return None
    return max(1, int(math.ceil(math.log(1.0 - target_confidence) / denom)))


def _priority_from_pdesired(p_desired: float) -> str:
    if p_desired < 0.10:
        return "High"
    if p_desired < 0.25:
        return "Medium"
    return "Low"


def _span_deletion_signal(
    report: Mapping[str, Any],
    *,
    target_id: str | None = None,
) -> tuple[float, int]:
    entries = report.get("structuralVariants") if isinstance(report.get("structuralVariants"), list) else []
    max_freq = 0.0
    max_len = 0
    for entry in entries:
        if not isinstance(entry, Mapping):
            continue
        if str(entry.get("kind") or "") != "spanDeletion":
            continue
        target_ids = entry.get("targetIds")
        if target_id and isinstance(target_ids, list):
            if target_id not in [str(t) for t in target_ids]:
                continue
        try:
            freq = float(entry.get("frequency") or 0.0)
        except Exception:
            freq = 0.0
        length = 0
        try:
            length = int(entry.get("length") or 0)
        except Exception:
            length = 0
        if freq > max_freq:
            max_freq = freq
        if length > max_len:
            max_len = length
    return max_freq, max_len


def _rationale_texts(codes: list[str]) -> list[str]:
    mapping = {
        "NO_PRIMERS": "No primers available, using long read validation.",
        "PRIME_EDIT": "Prime editing has multiple byproduct modes, prefer deep amplicon sequencing.",
        "LONG_AMPLICON": "Amplicon length is large, Sanger quality may be poor.",
        "SPECTRUM_COMPLEX": "Predicted allele spectrum is complex, prefer quantitative sequencing.",
        "SPECTRUM_TRUNCATED": "Many low frequency alleles expected, prefer quantitative sequencing.",
        "LOW_DESIRED_RATE": "Desired edit fraction is low at target confidence, prefer quantitative sequencing.",
        "HIGH_CLONE_BURDEN": "High clone screening burden, prefer quantitative sequencing.",
        "HIGH_RISK_OFFTARGETS": "High risk off target sites detected, prefer quantitative sequencing.",
        "BASE_BYSTANDER_HIGH": "High bystander edit risk, prefer quantitative amplicon sequencing.",
        "BASE_BYSTANDER_MED": "Moderate bystander edit risk, amplicon sequencing recommended.",
        "BASE_OFFTARGET_PROXY": "Off-target deamination proxy elevated, prefer quantitative sequencing.",
        "SPAN_DELETION_RISK": "Span deletion risk detected, prefer quantitative sequencing.",
    }
    order = [
        "NO_PRIMERS",
        "PRIME_EDIT",
        "BASE_BYSTANDER_HIGH",
        "BASE_BYSTANDER_MED",
        "BASE_OFFTARGET_PROXY",
        "SPAN_DELETION_RISK",
        "LONG_AMPLICON",
        "SPECTRUM_COMPLEX",
        "SPECTRUM_TRUNCATED",
        "LOW_DESIRED_RATE",
        "HIGH_CLONE_BURDEN",
        "HIGH_RISK_OFFTARGETS",
    ]
    texts = []
    for key in order:
        if key in codes:
            text = mapping.get(key)
            if text:
                texts.append(text)
    return texts


def _pick_assay(scores: Mapping[str, int], *, allowed: set[str]) -> str:
    best = None
    best_score = None
    for assay in ASSAY_ORDER:
        if assay not in allowed:
            continue
        score = scores.get(assay)
        if score is None:
            continue
        if best is None or score < best_score:  # type: ignore[operator]
            best = assay
            best_score = score
    return best or "AMPLICONSEQ"


def _primary_assay(
    *,
    report: Mapping[str, Any],
    validation_plan: Mapping[str, Any],
    primer_plan: Mapping[str, Any],
    clone_plan: Mapping[str, Any],
    experiment_spec: Mapping[str, Any],
    target_id: str | None = None,
) -> dict[str, Any]:
    spec = experiment_spec_to_dict(experiment_spec)
    intent = _norm(spec.get("intent"))
    p_desired = _desired_frequency(report, intent=intent)
    spectrum_entropy = _spectrum_entropy(report)
    truncated, _other_freq = _truncated_spectrum(report)
    high_risk_count = _high_risk_count(validation_plan)

    target_conf = _safe_float(clone_plan.get("targetConfidence"), 0.95)
    clones_needed = clone_plan.get("clonesNeededSingleCell")
    if clones_needed is None:
        clones_needed = _compute_clones_needed(p_desired, target_conf)

    prime_outcomes = report.get("primeOutcomes") if isinstance(report.get("primeOutcomes"), list) else []
    is_prime = intent == "prime_edit" or bool(prime_outcomes)
    prime_warnings = report.get("primeWarnings") if isinstance(report.get("primeWarnings"), list) else []
    base_outcomes = report.get("baseOutcomes") if isinstance(report.get("baseOutcomes"), list) else []
    is_base = intent in {"base_edit", "base", "base-edit"} or bool(base_outcomes)
    span_del_freq, span_del_length = _span_deletion_signal(report, target_id=target_id)

    base_desired = 0.0
    base_bystander = 0.0
    base_offtarget = 0.0
    if base_outcomes:
        for entry in base_outcomes:
            if not isinstance(entry, Mapping):
                continue
            cat = _norm(entry.get("category"))
            prob = _safe_float(entry.get("probability"), 0.0)
            if cat == "desired_edit":
                base_desired = prob
            elif cat == "bystander_edit":
                base_bystander = prob
            elif cat == "off_target_deamination":
                base_offtarget = prob

    primary_pair = _primary_primer_pair(primer_plan, spec, target_id=target_id)
    has_primers = _has_primers(primary_pair)
    amplicon_length = _amplicon_length(primary_pair)
    readout_window = _amplicon_window(primary_pair)

    scores = {"SANGER": 0, "AMPLICONSEQ": 0, "LONGREAD": 0}
    codes: list[str] = []

    if not has_primers:
        scores["SANGER"] = 999
        scores["AMPLICONSEQ"] = 999
        scores["LONGREAD"] = 0
        if "NO_PRIMERS" not in codes:
            codes.append("NO_PRIMERS")
        recommended = "LONGREAD"
        return {
            "hitKey": f"{target_id}::primary_target" if target_id else "primary_target",
            "recommendedAssay": recommended,
            "scores": scores,
            "pDesired": round(p_desired, 8),
            "clonesNeeded": clones_needed,
            "priority": _priority_from_pdesired(p_desired),
            "recommendedReadoutWindow": readout_window,
            "rationale": _rationale_texts(codes),
        }

    longread_trigger = False
    if amplicon_length is not None and amplicon_length > 2000:
        longread_trigger = True
    if intent == "insertion":
        insert_len = _infer_insertion_length(spec)
        if insert_len is not None and insert_len > 500:
            longread_trigger = True

    if not longread_trigger:
        scores["LONGREAD"] = 5

    if span_del_length > 2000:
        longread_trigger = True
        scores["LONGREAD"] = 0
        scores["SANGER"] += 6
        scores["AMPLICONSEQ"] += 2
        if "SPAN_DELETION_RISK" not in codes:
            codes.append("SPAN_DELETION_RISK")

    if amplicon_length is not None and amplicon_length > 600:
        scores["SANGER"] += 3
        scores["AMPLICONSEQ"] += 1
        if "LONG_AMPLICON" not in codes:
            codes.append("LONG_AMPLICON")

    if is_prime:
        scores["SANGER"] += 4
        if "PRIME_EDIT" not in codes:
            codes.append("PRIME_EDIT")

    if is_base:
        if base_bystander >= 0.10:
            scores["SANGER"] += 4
            if "BASE_BYSTANDER_HIGH" not in codes:
                codes.append("BASE_BYSTANDER_HIGH")
        elif base_bystander >= 0.03:
            scores["SANGER"] += 2
            if "BASE_BYSTANDER_MED" not in codes:
                codes.append("BASE_BYSTANDER_MED")
        if base_offtarget >= 0.05:
            scores["SANGER"] += 2
            if "BASE_OFFTARGET_PROXY" not in codes:
                codes.append("BASE_OFFTARGET_PROXY")

    if span_del_freq > 0.02 or (amplicon_length is not None and span_del_length > amplicon_length):
        scores["SANGER"] += 4
        if "SPAN_DELETION_RISK" not in codes:
            codes.append("SPAN_DELETION_RISK")

    if spectrum_entropy >= 8:
        scores["SANGER"] += 4
        scores["AMPLICONSEQ"] += 1
        if "SPECTRUM_COMPLEX" not in codes:
            codes.append("SPECTRUM_COMPLEX")
    elif spectrum_entropy >= 4:
        scores["SANGER"] += 2
        if "SPECTRUM_COMPLEX" not in codes:
            codes.append("SPECTRUM_COMPLEX")

    if truncated:
        scores["SANGER"] += 3
        scores["AMPLICONSEQ"] += 1
        if "SPECTRUM_TRUNCATED" not in codes:
            codes.append("SPECTRUM_TRUNCATED")

    if _prime_warnings_flag(prime_warnings):
        scores["SANGER"] += 2

    if p_desired >= 0.25:
        # High desired fraction: Sanger acceptable as a quick screen; bias away from amplicon.
        scores["AMPLICONSEQ"] += 1
    elif p_desired >= 0.10:
        scores["SANGER"] += 1
    elif p_desired >= 0.02:
        scores["SANGER"] += 3
        if "LOW_DESIRED_RATE" not in codes:
            codes.append("LOW_DESIRED_RATE")
    else:
        scores["SANGER"] += 6
        scores["AMPLICONSEQ"] += 1
        if "LOW_DESIRED_RATE" not in codes:
            codes.append("LOW_DESIRED_RATE")

    if clones_needed is not None and clones_needed > 384:
        scores["SANGER"] += 4
        scores["AMPLICONSEQ"] += 1
        if "HIGH_CLONE_BURDEN" not in codes:
            codes.append("HIGH_CLONE_BURDEN")
    elif clones_needed is not None and clones_needed > 96:
        scores["SANGER"] += 2
        if "HIGH_CLONE_BURDEN" not in codes:
            codes.append("HIGH_CLONE_BURDEN")

    if high_risk_count >= 3:
        scores["SANGER"] += 4
        scores["AMPLICONSEQ"] += 1
        if "HIGH_RISK_OFFTARGETS" not in codes:
            codes.append("HIGH_RISK_OFFTARGETS")
    elif high_risk_count >= 1:
        scores["SANGER"] += 2
        if "HIGH_RISK_OFFTARGETS" not in codes:
            codes.append("HIGH_RISK_OFFTARGETS")

    # Re-evaluate desired frequency in case earlier calculations mutated state.
    p_desired = _desired_frequency(report, intent=intent)

    recommended = _pick_assay(scores, allowed=set(scores.keys()))

    return {
        "hitKey": f"{target_id}::primary_target" if target_id else "primary_target",
        "recommendedAssay": recommended,
        "scores": scores,
        "pDesired": round(p_desired, 8),
        "clonesNeeded": clones_needed,
        "priority": _priority_from_pdesired(p_desired),
        "recommendedReadoutWindow": readout_window,
        "rationale": _rationale_texts(codes),
    }


def _offtarget_assay(
    hit: Mapping[str, Any],
    *,
    primer_plan: Mapping[str, Any],
) -> dict[str, Any]:
    risk = _norm(hit.get("riskTier"))
    hit_key = str(hit.get("hitKey") or "")
    primer_pair = None
    for pair in _primer_pairs(primer_plan):
        if str(pair.get("hitKey") or "") == hit_key:
            primer_pair = pair
            break
    has_primers = _has_primers(primer_pair)
    amplicon_length = _amplicon_length(primer_pair)
    readout_window = _amplicon_window(primer_pair)
    if readout_window is None:
        window = hit.get("recommendedAmpliconWindow") if isinstance(hit.get("recommendedAmpliconWindow"), Mapping) else None
        if isinstance(window, Mapping):
            start = _safe_int(window.get("start"), None)
            end = _safe_int(window.get("end"), None)
            if start is not None and end is not None and end > start:
                readout_window = {"start": int(start), "end": int(end)}

    if risk == "high":
        assay = "AMPLICONSEQ"
        rationale = ["Risk tier High requires quantitative sequencing."]
    elif risk == "medium":
        if has_primers:
            assay = "AMPLICONSEQ"
            rationale = ["Medium risk site, prefer quantitative sequencing."]
        else:
            assay = "LONGREAD"
            rationale = ["No primers available, using long read validation."]
    else:
        if has_primers and amplicon_length is not None and amplicon_length <= 600:
            assay = "SANGER"
            rationale = ["Low risk site, Sanger acceptable for presence check."]
        elif has_primers:
            assay = "AMPLICONSEQ"
            rationale = ["Low risk site, amplicon sequencing preferred for length."]
        else:
            assay = "LONGREAD"
            rationale = ["No primers available, using long read validation."]

    return {
        "hitKey": hit_key,
        "riskTier": str(hit.get("riskTier") or ""),
        "recommendedAssay": assay,
        "priority": (str(hit.get("riskTier") or "") or "Low").title(),
        "recommendedReadoutWindow": readout_window,
        "rationale": rationale,
    }


def build_assay_plan(
    outcome_report: Mapping[str, Any],
    validation_plan: Mapping[str, Any],
    primer_plan: Mapping[str, Any],
    clone_plan: Mapping[str, Any],
    experiment_spec: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    experiment_spec = experiment_spec or {}
    multiplex_targets = []
    multiplex = outcome_report.get("multiplex") if isinstance(outcome_report.get("multiplex"), Mapping) else None
    if isinstance(multiplex, Mapping):
        targets = multiplex.get("targets") if isinstance(multiplex.get("targets"), list) else []
        multiplex_targets = [t for t in targets if isinstance(t, Mapping)]

    target_entries: list[dict[str, Any]] = []
    if len(multiplex_targets) > 1:
        target_entries_raw = [t for t in multiplex_targets if isinstance(t, Mapping)]
        target_entries_raw.sort(key=lambda t: str(t.get("targetId") or ""))

        plan_targets = validation_plan.get("targets") if isinstance(validation_plan.get("targets"), list) else []
        target_plan_map = {}
        for entry in plan_targets:
            if isinstance(entry, Mapping):
                tid = str(entry.get("targetId") or "")
                if tid:
                    target_plan_map[tid] = entry

        for entry in target_entries_raw:
            tid = str(entry.get("targetId") or "")
            report_view = dict(outcome_report)
            report_view["alleleSpectrum"] = (
                entry.get("alleleSpectrum") if isinstance(entry.get("alleleSpectrum"), list) else []
            )
            validation_view = target_plan_map.get(tid) if tid else None
            if isinstance(validation_view, Mapping):
                validation_view = {
                    "highRiskCount": validation_view.get("highRiskCount"),
                    "mediumRiskCount": validation_view.get("mediumRiskCount"),
                    "lowRiskCount": validation_view.get("lowRiskCount"),
                    "topHits": validation_view.get("topHits") if isinstance(validation_view.get("topHits"), list) else [],
                }
            else:
                validation_view = validation_plan

            clone_view = dict(clone_plan)
            if tid and tid != str(target_entries_raw[0].get("targetId") or ""):
                clone_view["clonesNeededSingleCell"] = None
                clone_view["clonesNeededBulk"] = None

            primary_entry = _primary_assay(
                report=report_view,
                validation_plan=validation_view,
                primer_plan=primer_plan,
                clone_plan=clone_view,
                experiment_spec=experiment_spec,
                target_id=tid or None,
            )
            target_entries.append({"targetId": tid, "primary": primary_entry})

        primary = target_entries[0]["primary"] if target_entries else _primary_assay(
            report=outcome_report,
            validation_plan=validation_plan,
            primer_plan=primer_plan,
            clone_plan=clone_plan,
            experiment_spec=experiment_spec,
        )
    else:
        primary = _primary_assay(
            report=outcome_report,
            validation_plan=validation_plan,
            primer_plan=primer_plan,
            clone_plan=clone_plan,
            experiment_spec=experiment_spec,
        )

    base_outcomes = outcome_report.get("baseOutcomes") if isinstance(outcome_report.get("baseOutcomes"), list) else []
    spec = experiment_spec_to_dict(experiment_spec)
    intent = _norm(spec.get("intent"))
    base_mode = intent in {"base_edit", "base", "base-edit"} or bool(base_outcomes)
    base_offtarget_note = "Base editing off-target risk may be substitutions rather than indels."

    union_block = validation_plan.get("union") if isinstance(validation_plan.get("union"), Mapping) else None
    if isinstance(union_block, Mapping) and isinstance(union_block.get("topHits"), list):
        hits = union_block.get("topHits")
    else:
        hits = validation_plan.get("topHits") if isinstance(validation_plan.get("topHits"), list) else []
    off_targets = []
    for hit in hits:
        if not isinstance(hit, Mapping):
            continue
        entry = _offtarget_assay(hit, primer_plan=primer_plan)
        if base_mode:
            rationale = entry.get("rationale") if isinstance(entry.get("rationale"), list) else []
            if base_offtarget_note not in rationale:
                rationale = list(rationale)
                rationale.append(base_offtarget_note)
            entry["rationale"] = rationale
        off_targets.append(entry)

    tier_order = {"High": 0, "Medium": 1, "Low": 2}
    off_targets.sort(
        key=lambda h: (
            tier_order.get(str(h.get("priority") or ""), 3),
            str(h.get("hitKey") or ""),
        )
    )

    payload = {
        "schema": "helix_assay_plan_v1",
        "primary": primary,
        "offTargets": off_targets,
    }
    if target_entries:
        payload["targets"] = target_entries
    return payload


__all__ = [
    "build_assay_plan",
    "assay_plan_json_bytes",
    "assay_plan_sha256",
]
