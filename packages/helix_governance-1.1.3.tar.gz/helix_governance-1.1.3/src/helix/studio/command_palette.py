from __future__ import annotations

from typing import Iterable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from .commands import HelixCommand
from .ui_tokens import monospace_font


class CommandPaletteDialog(QDialog):
    def __init__(
        self,
        commands: Iterable[HelixCommand],
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Command Palette")
        self.setModal(True)
        self.setMinimumWidth(520)

        self._commands = list(commands)
        self._command_by_row: list[HelixCommand] = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)

        header = QHBoxLayout()
        title = QLabel("Command Palette", self)
        title.setStyleSheet("font-weight: 600;")
        header.addWidget(title, 1)
        close_btn = QPushButton("Esc", self)
        close_btn.setFocusPolicy(Qt.NoFocus)
        close_btn.clicked.connect(self.reject)
        close_btn.setFixedWidth(54)
        header.addWidget(close_btn, 0)
        layout.addLayout(header)

        self._query = QLineEdit(self)
        self._query.setPlaceholderText("Type a command…")
        layout.addWidget(self._query)

        self._list = QListWidget(self)
        self._list.setSelectionMode(QAbstractItemView.SingleSelection)
        self._list.setUniformItemSizes(True)
        layout.addWidget(self._list, 1)

        hint = QLabel("Enter to run • Esc to close", self)
        hint.setStyleSheet("color: rgba(203,213,225,0.75);")
        layout.addWidget(hint)

        self._query.textChanged.connect(self._rebuild)
        self._query.returnPressed.connect(self._run_selected)
        self._list.itemActivated.connect(lambda _item: self._run_selected())

        self._rebuild()
        self._query.setFocus(Qt.OtherFocusReason)

    def selected_command(self) -> HelixCommand | None:
        row = self._list.currentRow()
        if 0 <= row < len(self._command_by_row):
            return self._command_by_row[row]
        return None

    def _rebuild(self) -> None:
        query = (self._query.text() or "").strip().lower()
        self._list.clear()
        self._command_by_row = []

        matches: list[HelixCommand] = []
        for cmd in self._commands:
            hay = f"{cmd.title} {cmd.command_id} {cmd.category or ''}".lower()
            if not query or query in hay:
                matches.append(cmd)

        # Deterministic ordering: category -> title
        matches.sort(key=lambda c: (c.category or "", c.title.lower(), c.command_id))

        for cmd in matches[:250]:
            label = cmd.title
            if cmd.shortcut:
                label = f"{label}    {cmd.shortcut}"
            item = QListWidgetItem(label, self._list)
            item.setData(Qt.UserRole, cmd.command_id)
            if cmd.shortcut:
                item.setFont(monospace_font())
            self._command_by_row.append(cmd)

        if self._list.count() > 0:
            self._list.setCurrentRow(0)

    def _run_selected(self) -> None:
        cmd = self.selected_command()
        if cmd is None:
            return
        try:
            cmd.callback()
        finally:
            self.accept()


__all__ = ["CommandPaletteDialog"]
