from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QHeaderView,
    QTableWidget,
    QTableWidgetItem,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from helix.studio.outcomes.clone_yield import build_clone_plan
from helix.studio.outcomes.model import compute_outcomes_for_current_plan, outcome_report_to_dict
from helix.studio.results_io import attach_results_record, load_results_record
from helix.studio.results_adapters.batch_ingest import (
    BatchIngestResult,
    batch_ingest_folder,
    batch_summary_json,
    write_batch_bundle,
)
from helix.studio.prime_multiplex_calibration import prime_multiplex_calibration_profile_sha256
from helix.studio.results_adapters.crispresso2 import import_crispresso2_substitution_table
from helix.studio.results_adapters.csv_counts import import_csv_counts
from helix.studio.results_adapters.pileup import import_pileup_results
from helix.studio.base_position_calibration import (
    base_position_calibration_batch_eval_json_bytes,
    build_base_position_calibration_batch_eval,
    format_base_position_batch_eval_summary,
    base_position_batch_eval_markdown,
)
from helix.studio.calibration import attach_calibration_profile, build_calibration_profile_and_preview
from helix.studio.export_gate import build_export_context
from helix.studio.session import SessionModel
from helix.studio.ui.export_gate import ensure_export_allowed
from helix.studio.ui_tokens import MARGIN_PANEL, SPACING_MEDIUM, SPACING_SMALL, base_font


class ResultsPanel(QWidget):
    def __init__(self, session: SessionModel | None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._session = session
        self._export_prompt_suppressed_by_key: dict[str, bool] = {}
        self._records: list[dict[str, Any]] = []
        self._selected: dict[str, Any] | None = None
        self._batch_result: BatchIngestResult | None = None
        self._batch_root: Path | None = None
        self._batch_eval: dict[str, Any] | None = None
        self._selected_profile_id: str | None = None
        self._eval_sort_mode: str = "original"

        self.setFont(base_font())
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(SPACING_MEDIUM)

        header = QHBoxLayout()
        header.setSpacing(SPACING_SMALL)
        self._toggle = QToolButton(self)
        self._toggle.setCheckable(True)
        self._toggle.setChecked(True)
        self._toggle.setArrowType(Qt.DownArrow)
        self._toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._toggle.setText("Results")
        header.addWidget(self._toggle)
        header.addStretch(1)

        self._import_button = QToolButton(self)
        self._import_button.setText("Import results")
        header.addWidget(self._import_button)

        self._import_crispresso_button = QToolButton(self)
        self._import_crispresso_button.setText("Import CRISPResso2")
        header.addWidget(self._import_crispresso_button)

        self._import_pileup_button = QToolButton(self)
        self._import_pileup_button.setText("Import pileup")
        header.addWidget(self._import_pileup_button)

        self._import_csv_counts_button = QToolButton(self)
        self._import_csv_counts_button.setText("Import CSV counts")
        header.addWidget(self._import_csv_counts_button)

        self._import_folder_button = QToolButton(self)
        self._import_folder_button.setText("Import folder")
        header.addWidget(self._import_folder_button)

        self._calibration_button = QToolButton(self)
        self._calibration_button.setText("Build calibration profile")
        header.addWidget(self._calibration_button)

        self._export_summary_button = QToolButton(self)
        self._export_summary_button.setText("Export summary")
        self._export_summary_button.setEnabled(False)
        header.addWidget(self._export_summary_button)

        self._export_bundle_button = QToolButton(self)
        self._export_bundle_button.setText("Export bundle")
        self._export_bundle_button.setEnabled(False)
        header.addWidget(self._export_bundle_button)

        self._run_demo_button = QToolButton(self)
        self._run_demo_button.setText("Run demo")
        header.addWidget(self._run_demo_button)

        self._export_eval_button = QToolButton(self)
        self._export_eval_button.setText("Export eval")
        self._export_eval_button.setEnabled(False)
        header.addWidget(self._export_eval_button)

        self._export_eval_md_button = QToolButton(self)
        self._export_eval_md_button.setText("Export eval (md)")
        self._export_eval_md_button.setEnabled(False)
        header.addWidget(self._export_eval_md_button)

        self._copy_summary_button = QToolButton(self)
        self._copy_summary_button.setText("Copy summary")
        self._copy_summary_button.setEnabled(False)
        header.addWidget(self._copy_summary_button)

        self._evaluate_batch_button = QToolButton(self)
        self._evaluate_batch_button.setText("Evaluate calibration")
        self._evaluate_batch_button.setEnabled(False)
        header.addWidget(self._evaluate_batch_button)

        root.addLayout(header)

        self._body = QFrame(self)
        body_layout = QVBoxLayout(self._body)
        body_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        body_layout.setSpacing(SPACING_MEDIUM)

        self._status_label = QLabel("No results imported.", self)
        self._status_label.setWordWrap(True)
        body_layout.addWidget(self._status_label)

        self._table = QTableWidget(self)
        self._table.setColumnCount(3)
        self._table.setHorizontalHeaderLabels(["Results ID", "Modality", "Observed desired"])
        self._table.verticalHeader().setVisible(False)
        self._table.setSelectionBehavior(QTableWidget.SelectRows)
        self._table.setSelectionMode(QTableWidget.SingleSelection)
        self._table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._table.setShowGrid(True)
        try:
            header_widget = self._table.horizontalHeader()
            header_widget.setSectionResizeMode(0, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(1, QHeaderView.ResizeToContents)
            header_widget.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        except Exception:
            pass
        body_layout.addWidget(self._table)

        self._detail_label = QLabel("Select a result to view details.", self)
        self._detail_label.setWordWrap(True)
        self._detail_label.setStyleSheet("color: palette(mid);")
        body_layout.addWidget(self._detail_label)

        self._calibration_label = QLabel("Calibration preview: —", self)
        self._calibration_label.setWordWrap(True)
        self._calibration_label.setStyleSheet("color: palette(mid);")
        body_layout.addWidget(self._calibration_label)

        self._batch_status_label = QLabel("Batch import: —", self)
        self._batch_status_label.setWordWrap(True)
        self._batch_status_label.setStyleSheet("color: palette(mid);")
        body_layout.addWidget(self._batch_status_label)

        self._batch_table = QTableWidget(self)
        self._batch_table.setColumnCount(5)
        self._batch_table.setHorizontalHeaderLabels(["Status", "Kind", "Rel path", "Events", "Low"])
        self._batch_table.verticalHeader().setVisible(False)
        self._batch_table.setSelectionBehavior(QTableWidget.SelectRows)
        self._batch_table.setSelectionMode(QTableWidget.NoSelection)
        self._batch_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._batch_table.setShowGrid(True)
        try:
            header_widget = self._batch_table.horizontalHeader()
            for col in range(5):
                header_widget.setSectionResizeMode(col, QHeaderView.ResizeToContents)
        except Exception:
            pass
        body_layout.addWidget(self._batch_table)

        self._profile_row = QHBoxLayout()
        self._profile_row.setSpacing(SPACING_SMALL)
        self._profile_label = QLabel("Calibration profile:", self)
        self._profile_combo = QComboBox(self)
        self._profile_combo.currentIndexChanged.connect(self._on_profile_changed)
        self._profile_row.addWidget(self._profile_label)
        self._profile_row.addWidget(self._profile_combo, 1)
        body_layout.addLayout(self._profile_row)

        self._eval_sort_combo = QComboBox(self)
        self._eval_sort_combo.addItem("Original order", "original")
        self._eval_sort_combo.addItem("Most improved", "improved")
        self._eval_sort_combo.addItem("Most regressed", "regressed")
        self._eval_sort_combo.addItem("Regressions only", "regressions_only")
        self._eval_sort_combo.currentIndexChanged.connect(self._on_eval_sort_changed)
        body_layout.addWidget(self._eval_sort_combo)

        self._eval_table = QTableWidget(self)
        self._eval_table.setColumnCount(8)
        self._eval_table.setHorizontalHeaderLabels(
            ["Status", "Rel path", "Kind", "Events", "L1 before", "L1 after", "Δ", "Flags"]
        )
        self._eval_table.verticalHeader().setVisible(False)
        self._eval_table.setSelectionBehavior(QTableWidget.SelectRows)
        self._eval_table.setSelectionMode(QTableWidget.NoSelection)
        self._eval_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._eval_table.setShowGrid(True)
        try:
            header_widget = self._eval_table.horizontalHeader()
            for col in range(8):
                header_widget.setSectionResizeMode(col, QHeaderView.ResizeToContents)
        except Exception:
            pass
        body_layout.addWidget(self._eval_table)

        root.addWidget(self._body)

        self._toggle.toggled.connect(self._on_toggle)
        self._import_button.clicked.connect(self._on_import)
        self._import_crispresso_button.clicked.connect(self._on_import_crispresso2)
        self._import_pileup_button.clicked.connect(self._on_import_pileup)
        self._import_csv_counts_button.clicked.connect(self._on_import_csv_counts)
        self._import_folder_button.clicked.connect(self._on_import_folder)
        self._export_summary_button.clicked.connect(self._on_export_summary)
        self._export_bundle_button.clicked.connect(self._on_export_bundle)
        self._run_demo_button.clicked.connect(self._on_run_demo)
        self._export_eval_button.clicked.connect(self._on_export_eval)
        self._export_eval_md_button.clicked.connect(self._on_export_eval_md)
        self._copy_summary_button.clicked.connect(self._on_copy_eval_summary)
        self._evaluate_batch_button.clicked.connect(self._on_evaluate_batch)
        self._calibration_button.clicked.connect(self._on_build_calibration)
        self._table.itemSelectionChanged.connect(self._on_selection_changed)

        if self._session is not None:
            try:
                self._session.stateChanged.connect(self._on_state_changed)
            except Exception:
                pass

        self._refresh()

    def _on_toggle(self, checked: bool) -> None:
        try:
            self._body.setVisible(bool(checked))
        except Exception:
            pass
        try:
            self._toggle.setArrowType(Qt.DownArrow if checked else Qt.RightArrow)
        except Exception:
            pass

    def _on_import(self) -> None:
        path_str, _ = QFileDialog.getOpenFileName(self, "Import results record", filter="JSON (*.json)")
        if not path_str:
            return
        try:
            record = load_results_record(Path(path_str))
        except Exception as exc:
            self._status_label.setText(f"Import failed: {exc}")
            return
        if self._session is None:
            self._status_label.setText("No active session to attach results.")
            return
        attach_results_record(self._session, record)
        self._refresh()
        self._status_label.setText(f"Imported results {record.get('resultsId')}")

    def _on_import_crispresso2(self) -> None:
        if self._session is None:
            self._status_label.setText("No active session to attach results.")
            return
        path_str, _ = QFileDialog.getOpenFileName(
            self,
            "Import CRISPResso2 substitution table",
            filter="Text (*.txt);;All files (*)",
        )
        if not path_str:
            dir_str = QFileDialog.getExistingDirectory(self, "Import CRISPResso2 output folder")
            if not dir_str:
                return
            path_str = dir_str
        try:
            record, table_type = import_crispresso2_substitution_table(Path(path_str), self._session)
        except Exception as exc:
            self._status_label.setText(f"Import failed: {exc}")
            return
        attach_results_record(self._session, record)
        self._refresh()
        self._status_label.setText(
            f"Imported CRISPResso2 results {record.get('resultsId')} ({table_type} table)"
        )

    def _on_import_pileup(self) -> None:
        if self._session is None:
            self._status_label.setText("No active session to attach results.")
            return
        path_str, _ = QFileDialog.getOpenFileName(
            self,
            "Import pileup (samtools mpileup text)",
            filter="Text (*.txt);;All files (*)",
        )
        if not path_str:
            return
        try:
            record = import_pileup_results(Path(path_str), self._session)
        except Exception as exc:
            self._status_label.setText(f"Import failed: {exc}")
            return
        attach_results_record(self._session, record)
        self._refresh()
        source = record.get("conditions", {}).get("source", {}) if isinstance(record, dict) else {}
        cols = source.get("pileupColumns")
        mapq = source.get("minMapQ")
        min_depth = source.get("minDepth")
        self._status_label.setText(
            f"Imported pileup results {record.get('resultsId')} (cols={cols}, minMapQ={mapq}, minDepth={min_depth})"
        )

    def _on_import_csv_counts(self) -> None:
        if self._session is None:
            self._status_label.setText("No active session to attach results.")
            return
        path_str, _ = QFileDialog.getOpenFileName(
            self,
            "Import CSV counts",
            filter="CSV (*.csv *.tsv);;Text (*.txt);;All files (*)",
        )
        if not path_str:
            return
        try:
            record = import_csv_counts(Path(path_str), self._session)
        except Exception as exc:
            self._status_label.setText(f"Import failed: {exc}")
            return
        attach_results_record(self._session, record)
        self._refresh()
        src = record.get("conditions", {}).get("source", {}) if isinstance(record, dict) else {}
        total = record.get("primaryTarget", {}).get("observedTotalEvents")
        self._status_label.setText(
            f"Imported CSV counts {record.get('resultsId')} (events={total}, window {src.get('windowStart')}..{src.get('windowEnd')})"
        )

    def _on_import_folder(self) -> None:
        if self._session is None:
            self._status_label.setText("No active session to run batch import.")
            return
        folder_str = QFileDialog.getExistingDirectory(self, "Import folder of results")
        if not folder_str:
            return
        try:
            self._batch_root = Path(folder_str)
            self._batch_result = batch_ingest_folder(self._batch_root, self._session)
            self._status_label.setText(
                f"Batch import complete: {self._batch_result.counts['ok']} ok, "
                f"{self._batch_result.counts['error']} errors"
            )
        except Exception as exc:
            self._batch_result = None
            self._batch_root = None
            self._status_label.setText(f"Batch import failed: {exc}")
        self._render_batch_result()

    def _export_context(self) -> Any:
        session = self._session
        is_demo = False
        run_id = None
        if session is not None:
            try:
                cfg = getattr(getattr(session, "state", None), "config", None)
                meta = cfg.get("metadata") if isinstance(cfg, Mapping) and isinstance(cfg.get("metadata"), Mapping) else {}
                preset_id = str(meta.get("preset_id") or "").strip().lower()
                scenario = str(meta.get("scenario") or "").strip().lower()
                is_demo = bool(scenario == "demo" or preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"))
            except Exception:
                is_demo = False
            try:
                run_id = getattr(getattr(session, "state", None), "run_id", None)
            except Exception:
                run_id = None
        decision_mode = "filter_only"
        if session is not None:
            try:
                runs = getattr(session, "runs", None)
                run = runs[-1] if isinstance(runs, list) and runs else None
                meta = getattr(run, "metadata", None) if run is not None else None
                summary = meta.get("run_summary") if isinstance(meta, Mapping) and isinstance(meta.get("run_summary"), Mapping) else None
                dm = str(summary.get("decision_mode") or "").strip().lower() if isinstance(summary, Mapping) else ""
                if dm == "decision_grade":
                    decision_mode = "decision_grade"
            except Exception:
                pass
        return build_export_context(decision_mode=decision_mode, is_demo=is_demo, run_id=run_id)

    def _ensure_export_allowed(self, title: str) -> bool:
        try:
            ctx = self._export_context()
        except Exception:
            return True
        try:
            intent_spec = getattr(getattr(self._session, "state", None), "experiment_intent_spec", None)
            exp_spec = getattr(getattr(self._session, "state", None), "experiment_spec", None)
            summary = None
            try:
                runs = getattr(self._session, "runs", None)
                run = runs[-1] if isinstance(runs, list) and runs else None
                meta = getattr(run, "metadata", None) if run is not None else None
                summary = meta.get("run_summary") if isinstance(meta, Mapping) else None
            except Exception:
                summary = None
            return ensure_export_allowed(
                self,
                action_title=title,
                ctx=ctx,
                session_acks=self._export_prompt_suppressed_by_key,
                run_summary_v2=summary if isinstance(summary, Mapping) else None,
                experiment_intent_spec=intent_spec if isinstance(intent_spec, Mapping) else None,
                experiment_spec=exp_spec if isinstance(exp_spec, Mapping) else None,
            )
        except Exception:
            return True

    def _on_export_summary(self) -> None:
        if not self._batch_result:
            return
        if not self._ensure_export_allowed("Export batch summary"):
            return
        path_str, _ = QFileDialog.getSaveFileName(self, "Export batch summary", filter="JSON (*.json)")
        if not path_str:
            return
        data = batch_summary_json(self._batch_result, folder_root=self._batch_root)
        Path(path_str).write_bytes(data)
        self._status_label.setText(f"Exported batch summary to {path_str}")

    def _on_export_bundle(self) -> None:
        if not self._batch_result:
            return
        if not self._ensure_export_allowed("Export batch bundle"):
            return
        path_str, _ = QFileDialog.getSaveFileName(self, "Export batch bundle", filter="Zip (*.zip)")
        if not path_str:
            return
        extra: dict[str, bytes] = {}
        if self._batch_eval:
            extra["eval/base_position_batch_eval.json"] = base_position_calibration_batch_eval_json_bytes(self._batch_eval)
        # Include active prime multiplex calibration profile for audit completeness.
        try:
            cfg = self._session.state.config if isinstance(self._session.state.config, Mapping) else {}
            pm_cfg = cfg.get("prime_multiplex_calibration") if isinstance(cfg.get("prime_multiplex_calibration"), Mapping) else {}
            enabled = bool(pm_cfg.get("enabled")) if isinstance(pm_cfg, Mapping) else False
            profile_id = str(pm_cfg.get("profileId") or "") if isinstance(pm_cfg, Mapping) else ""
            profiles = getattr(self._session.state, "prime_multiplex_calibration_profiles", [])
            profile: Mapping[str, Any] | None = None
            if enabled and profile_id and isinstance(profiles, list):
                for entry in profiles:
                    if isinstance(entry, Mapping) and str(entry.get("profileId") or "") == profile_id:
                        profile = entry
                        break
            if enabled and isinstance(profile, Mapping):
                profile_bytes = (
                    json.dumps(profile, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n"
                ).encode("utf-8")
                extra["calibration/prime_multiplex_profile.json"] = profile_bytes
        except Exception:
            pass
        write_batch_bundle(self._batch_result, bundle_path=Path(path_str), folder_root=self._batch_root, extra_files=extra)
        self._status_label.setText(f"Exported batch bundle to {path_str}")

    def _on_export_eval(self) -> None:
        if not self._batch_eval:
            return
        if not self._ensure_export_allowed("Export batch eval"):
            return
        path_str, _ = QFileDialog.getSaveFileName(self, "Export batch eval", filter="JSON (*.json)")
        if not path_str:
            return
        Path(path_str).write_bytes(base_position_calibration_batch_eval_json_bytes(self._batch_eval))
        self._status_label.setText(f"Exported batch eval to {path_str}")

    def _on_export_eval_md(self) -> None:
        if not self._batch_eval:
            return
        if not self._ensure_export_allowed("Export batch eval markdown"):
            return
        path_str, _ = QFileDialog.getSaveFileName(self, "Export batch eval (markdown)", filter="Markdown (*.md)")
        if not path_str:
            return
        Path(path_str).write_text(base_position_batch_eval_markdown(self._batch_eval), encoding="utf-8")
        self._status_label.setText(f"Exported batch eval markdown to {path_str}")

    def _on_run_demo(self) -> None:
        """
        Offline demo: regenerate canonical bundles and compare against expected bytes.
        """
        try:
            import filecmp
            from helix import temp

            from tools.generate_demo_bundles import generate_demo

            demo_root = Path(__file__).resolve().parents[2] / "demo" / "canonical"
            expected = demo_root / "expected"
            if not expected.exists():
                self._status_label.setText("Demo assets missing.")
                return
            tmp_dir = temp.mkdtemp(prefix="helix_demo_")
            generate_demo(tmp_dir)
            files = [
                "base_bundle.zip",
                "base_leaderboard.json",
                "base_leaderboard.md",
                "prime_leaderboard.json",
                "prime_leaderboard.md",
            ]
            mismatches = []
            for fname in files:
                if not filecmp.cmp(tmp_dir / fname, expected / fname, shallow=False):
                    mismatches.append(fname)
            if mismatches:
                self._status_label.setText(f"Demo FAILED: mismatches {', '.join(mismatches)}")
            else:
                self._status_label.setText("Demo OK: outputs match canonical hashes.")
        except Exception as exc:
            self._status_label.setText(f"Demo failed: {exc}")

    def _on_copy_eval_summary(self) -> None:
        if not self._batch_eval:
            return
        summary = format_base_position_batch_eval_summary(self._batch_eval)
        try:
            QApplication.clipboard().setText(summary)
        except Exception:
            pass
        self._status_label.setText(summary)

    def _on_evaluate_batch(self) -> None:
        if not self._batch_result or not self._batch_result.items:
            return
        profile = self._get_selected_profile()
        if not profile:
            self._status_label.setText("No calibration profile selected.")
            return
        ok_items = [it for it in self._batch_result.items if it.status == "ok"]
        if not ok_items:
            self._status_label.setText("No OK batch items to evaluate.")
            return
        eval_payload = build_base_position_calibration_batch_eval(
            profile=profile,
            batch_items=[
                {
                    "record": it.record,
                    "relPath": it.relPath,
                    "kind": it.kind,
                    "tableKind": it.tableKind,
                    "sourceHash": it.sourceHash,
                    "notes": it.notes,
                }
                for it in ok_items
            ],
            results_records=[it.record for it in ok_items if it.record],
            window_start=profile.get("window", {}).get("start") if isinstance(profile.get("window"), Mapping) else None,
            window_end=profile.get("window", {}).get("end") if isinstance(profile.get("window"), Mapping) else None,
        )
        self._batch_eval = eval_payload
        self._status_label.setText(
            f"Batch eval complete: {eval_payload['counts']['ok']} ok, {eval_payload['counts'].get('skip', 0)} skipped"
        )
        self._render_eval_result()

    def _on_eval_sort_changed(self, _idx: int) -> None:
        mode = str(self._eval_sort_combo.currentData()) if self._eval_sort_combo.currentData() else "original"
        self._eval_sort_mode = mode
        self._render_eval_result()

    def _on_state_changed(self, _state) -> None:
        self._refresh()

    def _refresh(self) -> None:
        records = []
        if self._session is not None:
            raw = getattr(self._session.state, "results_records", [])
            if isinstance(raw, list):
                for entry in raw:
                    if isinstance(entry, Mapping):
                        records.append(dict(entry))
        self._records = records
        self._refresh_profiles()
        self._render_table()
        self._render_calibration_preview()
        self._render_batch_result()
        self._render_eval_result()

    def _refresh_profiles(self) -> None:
        profiles = []
        if self._session is not None:
            raw = getattr(self._session.state, "base_position_calibration_profiles", []) or []
            if isinstance(raw, list):
                profiles = [p for p in raw if isinstance(p, Mapping)]
        profiles = sorted(profiles, key=lambda p: str(p.get("profileId") or ""))
        current_id = self._selected_profile_id
        self._profile_combo.blockSignals(True)
        self._profile_combo.clear()
        for p in profiles:
            pid = str(p.get("profileId") or "")
            window = p.get("window") if isinstance(p.get("window"), Mapping) else {}
            w_start = window.get("start")
            w_end = window.get("end")
            editor = p.get("editorType") or "base"
            label = f"{pid} • {editor} [{w_start},{w_end}]"
            self._profile_combo.addItem(label, pid)
            if current_id and pid == current_id:
                self._profile_combo.setCurrentIndex(self._profile_combo.count() - 1)
        if self._profile_combo.count() == 0:
            self._selected_profile_id = None
        elif self._profile_combo.currentIndex() >= 0:
            self._selected_profile_id = str(self._profile_combo.currentData())
        self._profile_combo.blockSignals(False)

    def _render_calibration_preview(self) -> None:
        preview = None
        if self._session is not None:
            raw = getattr(self._session.state, "calibration_previews", [])
            if isinstance(raw, list) and raw:
                preview = raw[-1]
        if not isinstance(preview, Mapping):
            self._calibration_label.setText("Calibration preview: —")
            return
        p_pred = preview.get("pPred")
        p_obs = preview.get("pObs")
        p_cal = preview.get("pCal")
        parts = []
        if p_pred is not None:
            parts.append(f"Predicted {float(p_pred) * 100:.2f}%")
        if p_obs is not None:
            parts.append(f"Observed {float(p_obs) * 100:.2f}%")
        if p_cal is not None:
            parts.append(f"Calibrated {float(p_cal) * 100:.2f}%")
        if not parts:
            self._calibration_label.setText("Calibration preview: —")
            return
        self._calibration_label.setText("Calibration preview: " + " • ".join(parts))

    def _get_profiles(self) -> list[Mapping[str, Any]]:
        profiles = []
        if self._session is not None:
            raw = getattr(self._session.state, "base_position_calibration_profiles", []) or []
            if isinstance(raw, list):
                profiles = [p for p in raw if isinstance(p, Mapping)]
        return sorted(profiles, key=lambda p: str(p.get("profileId") or ""))

    def _get_selected_profile(self) -> Mapping[str, Any] | None:
        profiles = self._get_profiles()
        if not profiles:
            return None
        if self._selected_profile_id:
            for p in profiles:
                if str(p.get("profileId") or "") == self._selected_profile_id:
                    return p
        return profiles[-1] if profiles else None

    def _on_profile_changed(self, _idx: int) -> None:
        self._selected_profile_id = str(self._profile_combo.currentData()) if self._profile_combo.currentData() else None
        self._batch_eval = None
        self._render_eval_result()
        self._render_batch_result()

    def _render_batch_result(self) -> None:
        if not self._batch_result or not isinstance(self._batch_result, BatchIngestResult):
            self._batch_status_label.setText("Batch import: —")
            self._batch_table.setRowCount(0)
            self._export_summary_button.setEnabled(False)
            self._export_bundle_button.setEnabled(False)
            self._evaluate_batch_button.setEnabled(False)
            self._batch_eval = None
            self._render_eval_result()
            return
        counts = self._batch_result.counts
        self._batch_status_label.setText(
            f"Batch: {counts['ok']} ok, {counts['error']} errors, {counts['lowEvidence']} low evidence, total {counts['total']}"
        )
        items = list(self._batch_result.items)
        items.sort(key=lambda it: it.relPath)
        self._batch_table.setRowCount(len(items))
        for idx, it in enumerate(items):
            kind = it.kind
            if it.tableKind:
                kind = f"{kind} ({it.tableKind})"
            status = "OK" if it.status == "ok" else "ERR"
            events = "—" if it.totalEvents is None else str(it.totalEvents)
            low = "Low" if it.lowEvidence else "—"
            cells = [status, kind, it.relPath, events, low]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self._batch_table.setItem(idx, col, item)
        has_ok = any(it.status == "ok" for it in items)
        self._export_summary_button.setEnabled(has_ok)
        self._export_bundle_button.setEnabled(has_ok)
        self._evaluate_batch_button.setEnabled(has_ok and self._get_selected_profile() is not None)

    def _set_batch_result_for_test(self, result: BatchIngestResult, root: Path | None = None) -> None:
        self._batch_result = result
        self._batch_root = root
        self._render_batch_result()
        self._render_eval_result()

    def _render_eval_result(self) -> None:
        if not self._batch_eval or not isinstance(self._batch_eval, Mapping):
            self._eval_table.setRowCount(0)
            self._export_eval_button.setEnabled(False)
            self._export_eval_md_button.setEnabled(False)
            self._copy_summary_button.setEnabled(False)
            return
        items = self._batch_eval.get("items") if isinstance(self._batch_eval.get("items"), list) else []
        items_sorted = self._sort_eval_items(items)
        self._eval_table.setRowCount(len(items_sorted))

        def _fmt_ppm_ratio(value: Any) -> str:
            try:
                val = int(round(float(value) * 1_000_000))
            except Exception:
                return "—"
            sign = "-" if val < 0 else ""
            val = abs(val)
            whole = val // 1_000_000
            frac = val % 1_000_000
            return f"{sign}{whole}.{frac:06d}"

        for idx, entry in enumerate(items_sorted):
            status = str(entry.get("status") or "—").upper()
            rel_path = str(entry.get("relPath") or "—")
            kind = str(entry.get("kind") or "—")
            if entry.get("tableKind"):
                kind = f"{kind} ({entry.get('tableKind')})"
            events = entry.get("totalEvents")
            events_text = "—" if events is None else str(events)
            flags = []
            if entry.get("lowEvidence"):
                flags.append("Low")
            if entry.get("inferred"):
                flags.append("Inferred")
            if status == "SKIP":
                flags_text = str(entry.get("reason") or "skip")
                l1_before = l1_after = delta = "—"
            else:
                flags_text = ",".join(flags) if flags else "—"
                l1_before = _fmt_ppm_ratio(entry.get("l1Before"))
                l1_after = _fmt_ppm_ratio(entry.get("l1After"))
                delta = _fmt_ppm_ratio(entry.get("improvement"))
            cells = [status, rel_path, kind, events_text, l1_before, l1_after, delta, flags_text]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self._eval_table.setItem(idx, col, item)
        self._export_eval_button.setEnabled(True)
        self._export_eval_md_button.setEnabled(True)
        self._copy_summary_button.setEnabled(True)

    def _sort_eval_items(self, items: list[Mapping[str, Any]]) -> list[Mapping[str, Any]]:
        mode = getattr(self, "_eval_sort_mode", "original")
        if mode == "improved":
            return sorted(items, key=lambda e: (-float(e.get("improvement") or 0), str(e.get("relPath") or "")))
        if mode == "regressed":
            return sorted(items, key=lambda e: (float(e.get("improvement") or 0), str(e.get("relPath") or "")))
        if mode == "regressions_only":
            filtered = [e for e in items if float(e.get("improvement") or 0) < 0]
            return sorted(filtered, key=lambda e: (float(e.get("improvement") or 0), str(e.get("relPath") or "")))
        return list(items)

    def _render_table(self) -> None:
        self._table.setRowCount(len(self._records))
        for idx, rec in enumerate(self._records):
            results_id = str(rec.get("resultsId") or "—")
            modality = str(rec.get("modality") or "—")
            observed = "—"
            primary = rec.get("primaryTarget") if isinstance(rec.get("primaryTarget"), Mapping) else {}
            if isinstance(primary, Mapping) and primary.get("observedDesiredFrequency") is not None:
                observed = f"{float(primary.get('observedDesiredFrequency')) * 100:.2f}%"
            cells = [results_id, modality, observed]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self._table.setItem(idx, col, item)

        if not self._records:
            self._detail_label.setText("Select a result to view details.")
        self._selected = None
        self._render_calibration_preview()
        self._render_batch_result()

    def _on_selection_changed(self) -> None:
        rows = self._table.selectionModel().selectedRows() if self._table.selectionModel() else []
        if not rows:
            self._detail_label.setText("Select a result to view details.")
            self._selected = None
            return
        row = rows[0].row()
        if 0 <= row < len(self._records):
            self._selected = self._records[row]
            self._render_details(self._selected)

    def _render_details(self, record: Mapping[str, Any]) -> None:
        primary = record.get("primaryTarget") if isinstance(record.get("primaryTarget"), Mapping) else {}
        observed = primary.get("observedDesiredFrequency") if isinstance(primary, Mapping) else None

        predicted = None
        try:
            if self._session is not None:
                report = compute_outcomes_for_current_plan(self._session)
                payload = outcome_report_to_dict(report)
                clone_plan = build_clone_plan(payload)
                predicted = clone_plan.get("desiredFrequency")
        except Exception:
            predicted = None

        if observed is None or predicted is None:
            self._detail_label.setText("Observed or predicted desired frequency unavailable.")
            return

        obs = float(observed)
        pred = float(predicted)
        delta = (obs - pred) * 100.0
        obs_text = f"{obs * 100:.2f}%"
        pred_text = f"{pred * 100:.2f}%"
        delta_text = f"{delta:+.2f}%"
        self._detail_label.setText(
            f"Observed desired {obs_text} vs predicted {pred_text} (Δ {delta_text}). Consider calibrating priors."
        )

    def _on_build_calibration(self) -> None:
        if self._session is None:
            self._status_label.setText("No active session to build calibration.")
            return
        try:
            report = compute_outcomes_for_current_plan(
                self._session, apply_calibration=False, apply_priors_override=False
            )
            report_payload = outcome_report_to_dict(report)
            profile, preview = build_calibration_profile_and_preview(
                getattr(self._session.state, "results_records", []),
                report_payload,
                getattr(self._session.state, "experiment_spec", None),
            )
            attach_calibration_profile(self._session, profile, preview)
            self._status_label.setText(f"Calibration profile {profile.get('profileId', '')} created.")
            self._refresh()
        except Exception as exc:
            self._status_label.setText(f"Calibration build failed: {exc}")


__all__ = ["ResultsPanel"]
