from __future__ import annotations

import json
import logging
from enum import Enum
from pathlib import Path
from typing import Any, Mapping, Optional, Tuple

EXPERIMENT_SPEC_SCHEMA_ID = "helix_experiment_spec_v1"

INTENT_VALUES = (
    "knockout",
    "precise_substitution",
    "tag_insertion",
    "promoter_edit",
    "prime_edit",
    "multiplex",
)

EDIT_MODALITY_VALUES = (
    "crispr_cut",
    "prime",
    "pcr",
)

LOGGER = logging.getLogger(__name__)

try:  # pragma: no cover - optional dependency
    from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

    PYDANTIC_AVAILABLE = True
except Exception:  # pragma: no cover - fallback path
    BaseModel = object  # type: ignore
    ValidationError = Exception  # type: ignore
    PYDANTIC_AVAILABLE = False


def _schema_path() -> Path:
    return Path(__file__).resolve().parents[3] / "schemas" / "experiment" / "helix_experiment_spec_v1.json"


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n").encode(
        "utf-8"
    )


def _default_reference() -> dict[str, Any]:
    return {
        "genomeBuild": "",
        "contig": "",
        "contigSha256": None,
        "contigsSha256": None,
        "genomeSha256": None,
    }


def _default_locus() -> dict[str, Any]:
    return {
        "chr": "",
        "start": 0,
        "end": 0,
        "strand": "+",
    }


def _default_spec_dict() -> dict[str, Any]:
    return {
        "schema": EXPERIMENT_SPEC_SCHEMA_ID,
        "experimentId": "unset",
        "createdAt": None,
        "reference": _default_reference(),
        "locus": _default_locus(),
        "intent": "knockout",
        "editModalities": [],
        "constraints": {},
        "assumptions": {},
    }


if PYDANTIC_AVAILABLE:

    class Intent(str, Enum):
        KNOCKOUT = "knockout"
        PRECISE_SUBSTITUTION = "precise_substitution"
        TAG_INSERTION = "tag_insertion"
        PROMOTER_EDIT = "promoter_edit"
        PRIME_EDIT = "prime_edit"
        MULTIPLEX = "multiplex"


    class EditModality(str, Enum):
        CRISPR_CUT = "crispr_cut"
        PRIME = "prime"
        PCR = "pcr"


    class _BaseSpecModel(BaseModel):
        model_config = ConfigDict(extra="allow", populate_by_name=True)


    class LocusTarget(_BaseSpecModel):
        contig: str = Field(default="", alias="chr")
        start: int = 0
        end: int = 0
        strand: str = "+"


    class ReferenceContext(_BaseSpecModel):
        genome_build: str = Field(default="", alias="genomeBuild")
        contig: str = Field(default="")
        contig_sha256: Optional[str] = Field(default=None, alias="contigSha256")
        contigs_sha256: Optional[str] = Field(default=None, alias="contigsSha256")
        genome_sha256: Optional[str] = Field(default=None, alias="genomeSha256")


    class ExperimentSpecV1(_BaseSpecModel):
        schema_: str = Field(default=EXPERIMENT_SPEC_SCHEMA_ID, alias="schema")
        experiment_id: str = Field(default="unset", alias="experimentId")
        created_at: Optional[str] = Field(default=None, alias="createdAt")
        reference: ReferenceContext = Field(default_factory=ReferenceContext)
        locus: LocusTarget = Field(default_factory=LocusTarget)
        intent: Intent = Intent.KNOCKOUT
        intent_ref: dict[str, Any] | None = Field(default=None, alias="intentRef")
        edit_intent: dict[str, Any] | None = Field(default=None, alias="editIntent")
        guide_objectives: dict[str, Any] | None = Field(default=None, alias="guideObjectives")
        edit_modalities: list[EditModality] = Field(default_factory=list, alias="editModalities")
        constraints: dict[str, Any] = Field(default_factory=dict)
        assumptions: dict[str, Any] = Field(default_factory=dict)

        @field_validator("intent", mode="before")
        @classmethod
        def _coerce_intent(cls, value: Any) -> Any:
            if isinstance(value, str):
                return value.strip().lower().replace(" ", "_")
            return value

        @field_validator("edit_modalities", mode="before")
        @classmethod
        def _coerce_modalities(cls, value: Any) -> Any:
            if isinstance(value, str):
                value = [value]
            if isinstance(value, list):
                normalized: list[Any] = []
                for item in value:
                    if isinstance(item, Enum):
                        item = item.value
                    if isinstance(item, str):
                        text = item.strip().lower().replace(" ", "_")
                        if "." in text:
                            text = text.rsplit(".", maxsplit=1)[-1]
                        normalized.append(text)
                    else:
                        normalized.append(item)
                return normalized
            return value

        @property
        def schema(self) -> str:  # compatibility with existing callers
            return self.schema_


def default_experiment_spec() -> dict[str, Any]:
    if PYDANTIC_AVAILABLE:
        model = ExperimentSpecV1()
        return model.model_dump(exclude_none=True, by_alias=True)
    return json.loads(json.dumps(_default_spec_dict()))


def experiment_spec_from_dict_with_error(data: Mapping[str, Any] | None) -> Tuple[dict[str, Any], str | None]:
    if data is None or not isinstance(data, Mapping):
        return default_experiment_spec(), None
    if PYDANTIC_AVAILABLE:
        try:
            model = ExperimentSpecV1.model_validate(data)
            return model.model_dump(exclude_none=True, by_alias=True), None
        except ValidationError as exc:
            LOGGER.warning("ExperimentSpec validation failed, using best-effort merge: %s", exc)
            merged = _default_spec_dict()
            merged.update({k: v for k, v in data.items()})
            merged.setdefault("schema", EXPERIMENT_SPEC_SCHEMA_ID)
            return merged, str(exc)
    merged = _default_spec_dict()
    merged.update({k: v for k, v in data.items()})
    merged.setdefault("schema", EXPERIMENT_SPEC_SCHEMA_ID)
    return merged, None


def experiment_spec_from_dict(data: Mapping[str, Any] | None) -> dict[str, Any]:
    spec, _err = experiment_spec_from_dict_with_error(data)
    return spec


def experiment_spec_to_dict(data: Any) -> dict[str, Any]:
    if PYDANTIC_AVAILABLE and isinstance(data, ExperimentSpecV1):
        return data.model_dump(exclude_none=True, by_alias=True)
    if isinstance(data, Mapping):
        return experiment_spec_from_dict(data)
    if data is None:
        return default_experiment_spec()
    return experiment_spec_from_dict({})


def experiment_spec_json_bytes(data: Any) -> bytes:
    payload = experiment_spec_to_dict(data)
    return _canonical_json_bytes(payload)


def experiment_spec_sha256(data: Any) -> str:
    import hashlib

    return hashlib.sha256(experiment_spec_json_bytes(data)).hexdigest()


def experiment_spec_json_schema() -> dict[str, Any]:
    if PYDANTIC_AVAILABLE:
        return ExperimentSpecV1.model_json_schema()
    try:
        from importlib import resources

        schema_text = resources.files("helix.schema").joinpath("experiment/helix_experiment_spec_v1.json").read_text(
            encoding="utf-8"
        )
        return json.loads(schema_text)
    except Exception:
        pass
    path = _schema_path()
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}
