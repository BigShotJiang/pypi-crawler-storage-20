"""Helix Studio shared UI components.

This package can be imported in headless environments (e.g., CLI/CI) without
pulling in Qt bindings. Heavy Qt objects are lazily imported via ``__getattr__``.
"""

__all__ = ["ExperimentState", "RunKind", "SessionModel", "HelixStudioMainWindow", "ProjectModel"]


def __getattr__(name: str):  # pragma: no cover - import-time side effects avoided
    if name in {"ExperimentState", "RunKind", "SessionModel"}:
        from .session import ExperimentState, RunKind, SessionModel

        return {"ExperimentState": ExperimentState, "RunKind": RunKind, "SessionModel": SessionModel}[name]
    if name == "ProjectModel":
        from .project import ProjectModel

        return ProjectModel
    if name == "HelixStudioMainWindow":
        from .main_window import HelixStudioMainWindow

        return HelixStudioMainWindow
    raise AttributeError(name)
