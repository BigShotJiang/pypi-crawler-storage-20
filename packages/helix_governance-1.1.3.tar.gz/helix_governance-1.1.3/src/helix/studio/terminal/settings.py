"""Shell detection and environment helpers for the Studio terminal."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List, Iterable


@dataclass(frozen=True)
class TerminalPalette:
    """Lightweight palette for the embedded terminal.

    Only contains the four colors we actually render with. Kept separate from
    the global Qt palette so a future light theme can swap these independently.
    """

    background: str = "#02061A"
    foreground: str = "#E5E9F0"
    selection_background: str = "#204060"
    selection_foreground: str = "#FFFFFF"


def default_shell_cmd() -> List[str]:
    """Return the preferred shell command for the current platform."""

    if sys.platform.startswith("win"):
        # Prefer pwsh if available, fall back to powershell.
        return ["pwsh.exe"] if _has_executable("pwsh.exe") else ["powershell.exe"]

    shell = os.environ.get("SHELL")
    if shell:
        return [shell, "-l"]

    return ["/bin/bash", "-l"]


def default_env() -> Dict[str, str]:
    env: Dict[str, str] = {}
    env["HELIX_STUDIO"] = "1"
    return env


def helix_env_for_project(project_root: Path | None) -> Dict[str, str]:
    env = default_env()
    if project_root:
        env["HELIX_PROJECT_ROOT"] = str(project_root)
    return env


def add_tool_paths(env: Dict[str, str], paths: Iterable[Path]) -> Dict[str, str]:
    """Return a copy of *env* with PATH extended by the provided directories."""

    new_env = dict(env)
    path_parts = [str(p) for p in paths if p]
    if not path_parts:
        return new_env
    current = new_env.get("PATH", os.environ.get("PATH", ""))
    combined = os.pathsep.join(path_parts + ([current] if current else []))
    new_env["PATH"] = combined
    return new_env


def _has_executable(name: str) -> bool:
    paths = os.environ.get("PATH", "").split(os.pathsep)
    for path in paths:
        candidate = Path(path) / name
        if candidate.exists() and os.access(candidate, os.X_OK):
            return True
    return False


__all__ = [
    "TerminalPalette",
    "default_shell_cmd",
    "default_env",
    "helix_env_for_project",
    "add_tool_paths",
]
