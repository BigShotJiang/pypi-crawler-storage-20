"""Terminal backend that prefers a real PTY (for line editing, arrows, etc.)."""

from __future__ import annotations

import fcntl
import os
import pty
import signal
import subprocess
import struct
import termios
from typing import Mapping, Optional

from PySide6.QtCore import QObject, QProcess, QSocketNotifier, Signal


class TerminalProcessBackend(QObject):
    output_ready = Signal(str)
    finished = Signal(int, str)  # exit_code, status
    started = Signal()

    def __init__(
        self,
        shell_cmd: list[str],
        *,
        cwd: str | None = None,
        env: Mapping[str, str] | None = None,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)

        self._shell_cmd = shell_cmd or ["/bin/bash", "-l"]
        self._cwd = cwd
        self._env = {k: str(v) for k, v in (env or {}).items()}

        self._use_qprocess = os.name != "posix"
        self._proc: Optional[QProcess] = None
        self._notifier: Optional[QSocketNotifier] = None
        self._master_fd: Optional[int] = None
        self._slave_fd: Optional[int] = None
        self._pid: Optional[int] = None
        self._started = False

        if self._use_qprocess:
            self._init_qprocess()

    # ---- Startup ----------------------------------------------------
    def start(self) -> None:
        if self._use_qprocess:
            if self._proc:
                self._proc.start()
            return

        self._start_pty_process()

    # ---- POSIX PTY path ---------------------------------------------
    def _start_pty_process(self) -> None:
        try:
            master_fd, slave_fd = pty.openpty()
            self._master_fd = master_fd
            self._slave_fd = slave_fd
            # give the child a sane default size before exec
            self.set_winsize(rows=40, cols=120)

            env = os.environ.copy()
            env.update(self._env)
            env.setdefault("TERM", "xterm-256color")

            # Avoid `os.fork()` from the Qt GUI process (multi-threaded), which can deadlock
            # under CPython 3.12+ when locks are held by other threads at fork time.
            proc = subprocess.Popen(
                self._shell_cmd,
                stdin=slave_fd,
                stdout=slave_fd,
                stderr=slave_fd,
                cwd=self._cwd or None,
                env=env,
                start_new_session=True,
                close_fds=True,
            )

            self._pid = proc.pid
            fcntl.fcntl(master_fd, fcntl.F_SETFL, os.O_NONBLOCK)
            os.close(slave_fd)
            self._slave_fd = None

            self._notifier = QSocketNotifier(master_fd, QSocketNotifier.Read, self)
            self._notifier.activated.connect(self._on_readable)

            self._started = True
            self.started.emit()

        except Exception as exc:
            self.output_ready.emit(f"[helix] terminal failed: {exc}\n")
            self.finished.emit(1, "error")

    def _on_readable(self) -> None:
        if self._master_fd is None:
            return
        try:
            data = os.read(self._master_fd, 4096)
        except BlockingIOError:
            return
        except OSError as exc:
            self.output_ready.emit(f"[helix] terminal read error: {exc}\n")
            self._handle_pty_exit()
            return

        if not data:
            self._handle_pty_exit()
            return

        self.output_ready.emit(data.decode(errors="ignore"))

    def _handle_pty_exit(self) -> None:
        if self._notifier:
            try:
                self._notifier.setEnabled(False)
            finally:
                self._notifier.deleteLater()
            self._notifier = None

        if self._master_fd is not None:
            try:
                os.close(self._master_fd)
            except Exception:
                pass
            self._master_fd = None

        if self._slave_fd is not None:
            try:
                os.close(self._slave_fd)
            except Exception:
                pass
            self._slave_fd = None

        exit_code, status = 0, "exited"
        if self._pid:
            try:
                pid, wait_status = os.waitpid(self._pid, os.WNOHANG)
                if pid == 0:
                    os.kill(self._pid, signal.SIGTERM)
                    pid, wait_status = os.waitpid(self._pid, 0)

                if os.WIFEXITED(wait_status):
                    exit_code = os.WEXITSTATUS(wait_status)
                elif os.WIFSIGNALED(wait_status):
                    sig = os.WTERMSIG(wait_status)
                    exit_code = -sig
                    status = f"signaled {sig}"
            except ChildProcessError:
                pass
            except Exception as exc:
                self.output_ready.emit(f"[helix] waitpid error: {exc}\n")
            finally:
                self._pid = None

        self.finished.emit(exit_code, status)

    # ---- QProcess fallback (non-posix) ------------------------------
    def _init_qprocess(self) -> None:
        self._proc = QProcess(self)
        self._proc.setProcessChannelMode(QProcess.MergedChannels)

        if self._cwd:
            self._proc.setWorkingDirectory(self._cwd)

        if self._env:
            proc_env = self._proc.processEnvironment()
            for key, value in self._env.items():
                proc_env.insert(str(key), str(value))
            self._proc.setProcessEnvironment(proc_env)

        self._proc.setProgram(self._shell_cmd[0])
        self._proc.setArguments(self._shell_cmd[1:])

        self._proc.readyReadStandardOutput.connect(self._on_stdout_proc)
        self._proc.started.connect(self._on_started_proc)
        self._proc.finished.connect(self._on_finished_proc)
        self._proc.errorOccurred.connect(self._on_error_proc)

    def _on_started_proc(self) -> None:
        self._started = True
        self.started.emit()

    def _on_stdout_proc(self) -> None:
        if not self._proc:
            return
        data = bytes(self._proc.readAllStandardOutput()).decode(errors="ignore")
        self.output_ready.emit(data)

    def _on_finished_proc(self, code: int, status) -> None:  # status is QProcess.ExitStatus
        self.finished.emit(code, str(status))

    def _on_error_proc(self, error) -> None:
        self.output_ready.emit(f"[helix] terminal process error: {error}\n")

    # ---- Public API --------------------------------------------------
    def write(self, data: str | bytes) -> None:
        if not data:
            return

        payload = data.encode() if isinstance(data, str) else data

        if self._use_qprocess:
            if self._proc:
                self._proc.write(payload)
            return

        if self._master_fd is None:
            return
        try:
            os.write(self._master_fd, payload)
        except OSError:
            # Process likely exited; ignore.
            pass

    def kill(self) -> None:
        if self._use_qprocess:
            try:
                if self._proc:
                    self._proc.kill()
            except Exception:
                pass
            return

        if self._pid:
            try:
                os.kill(self._pid, signal.SIGTERM)
            except Exception:
                pass
            finally:
                self._handle_pty_exit()

    def set_winsize(self, rows: int, cols: int) -> None:
        if self._use_qprocess or self._master_fd is None:
            return

        rows = max(1, int(rows))
        cols = max(1, int(cols))
        winsize = struct.pack("HHHH", rows, cols, 0, 0)
        try:
            fcntl.ioctl(self._master_fd, termios.TIOCSWINSZ, winsize)
        except OSError:
            # Process might be exiting; ignore.
            pass
