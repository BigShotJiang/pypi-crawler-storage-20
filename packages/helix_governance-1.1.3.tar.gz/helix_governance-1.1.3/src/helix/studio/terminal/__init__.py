"""Lightweight in-app terminal for Helix Studio.

This module exposes the :class:`TerminalManager` entry point used by the
main window to embed a tabbed shell inside the bottom console area.
"""

__all__ = ["TerminalManager", "TerminalTask"]


def __getattr__(name: str):  # pragma: no cover - avoid importing Qt in headless contexts
    if name in {"TerminalManager", "TerminalTask"}:
        from .manager import TerminalManager, TerminalTask

        return {"TerminalManager": TerminalManager, "TerminalTask": TerminalTask}[name]
    raise AttributeError(name)
