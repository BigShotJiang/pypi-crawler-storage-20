"""Single terminal session widget (output + keystroke forwarding)."""

from __future__ import annotations

from collections import OrderedDict

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import (
    QColor,
    QFont,
    QFontDatabase,
    QKeyEvent,
    QTextCharFormat,
    QTextCursor,
    QTextOption,
)
from PySide6.QtWidgets import QApplication, QTextEdit

from .ansi_parser import (
    AnsiBackspace,
    AnsiCarriageReturn,
    AnsiClearEol,
    AnsiCursorLeft,
    AnsiCursorRight,
    AnsiNewline,
    AnsiText,
    OscStreamStripper,
    SgrStreamDecoder,
    TermStyle,
)
from .process_backend import TerminalProcessBackend
from .settings import TerminalPalette


class TerminalSessionWidget(QTextEdit):
    _FORMAT_CACHE_LIMIT = 2048
    _MAX_PENDING_BYTES = 256 * 1024
    _MAX_CHARS = 1_000_000

    def __init__(
        self,
        backend: TerminalProcessBackend,
        title: str,
        *,
        palette: TerminalPalette | None = None,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.backend = backend
        self.title = title
        self._started = False
        self._palette_override = palette
        self._osc_stripper = OscStreamStripper()
        self._ansi_decoder = SgrStreamDecoder()
        self._default_fg = QColor("#ffffff")
        self._default_bg = QColor("#000000")
        self._format_cache: OrderedDict[tuple, QTextCharFormat] = OrderedDict()
        self._pending_output: list[str] = []
        self._pending_output_bytes = 0
        self._render_timer = QTimer(self)
        self._render_timer.setSingleShot(True)
        self._render_timer.setInterval(33)  # ~30Hz flush under heavy output
        self._render_timer.timeout.connect(self._flush_pending_output)

        self.setReadOnly(True)
        self.setUndoRedoEnabled(False)
        self.setAcceptRichText(False)
        self.document().setMaximumBlockCount(5000)
        self.setLineWrapMode(QTextEdit.NoWrap)
        self.setWordWrapMode(QTextOption.NoWrap)
        self.setFocusPolicy(Qt.StrongFocus)
        mono = QFontDatabase.systemFont(QFontDatabase.FixedFont)
        mono.setPointSize(11)
        self.setFont(mono)
        # Show a lightweight caret so users can see the active line/column.
        self.setCursorWidth(2)
        self.setViewportMargins(4, 4, 4, 4)
        self.setTextInteractionFlags(
            Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard
        )
        self.selectionChanged.connect(self._copy_on_select)

        backend.output_ready.connect(self._append_text)
        backend.started.connect(self._on_started)
        backend.finished.connect(self._on_finished)

        backend.start()
        self.setFocus()
        self.apply_theme()

        app = QApplication.instance()
        if app is not None and hasattr(app, "paletteChanged"):
            try:
                app.paletteChanged.connect(self.apply_theme)
            except Exception:
                pass

    # ---- Backend hooks -------------------------------------------------
    def _append_text(self, text: str) -> None:
        """Queue output for rendering and schedule a batched flush."""

        if not text:
            return

        self._pending_output.append(text)
        self._pending_output_bytes += len(text)

        if self._pending_output_bytes >= self._MAX_PENDING_BYTES:
            self._flush_pending_output()
            return

        if not self._render_timer.isActive():
            self._render_timer.start()

    def _flush_pending_output(self) -> None:
        """Render any queued backend output.

        Important UX behavior:
        - auto-scroll only if the user is already at the bottom
        - don't yank the viewport while the user has a selection
        """

        if not self._pending_output:
            return

        raw = "".join(self._pending_output)
        self._pending_output.clear()
        self._pending_output_bytes = 0

        bar = self.verticalScrollBar()
        was_at_bottom = bar.value() >= bar.maximum() - 2
        has_selection = self.textCursor().hasSelection()
        should_autoscroll = was_at_bottom and not has_selection
        prev_scroll = bar.value()

        raw = self._osc_stripper.feed(raw)
        events = self._ansi_decoder.feed(raw)

        # Insert using a document cursor so we don't destroy the user's selection.
        cursor = QTextCursor(self.document())
        cursor.movePosition(QTextCursor.End)

        pending_style: TermStyle | None = None
        pending_chunks: list[str] = []

        def flush_pending() -> None:
            nonlocal pending_style
            if pending_style is None or not pending_chunks:
                pending_style = None
                pending_chunks.clear()
                return
            cursor.insertText(
                "".join(pending_chunks),
                self._format_for_style(pending_style),
            )
            pending_style = None
            pending_chunks.clear()

        cursor.beginEditBlock()
        try:
            for event in events:
                match event:
                    case AnsiText(text=chunk, style=style):
                        if pending_style is None:
                            pending_style = style
                            pending_chunks.append(chunk)
                        elif style == pending_style:
                            pending_chunks.append(chunk)
                        else:
                            flush_pending()
                            pending_style = style
                            pending_chunks.append(chunk)
                    case AnsiBackspace():
                        flush_pending()
                        if cursor.positionInBlock() > 0:
                            cursor.movePosition(QTextCursor.Left)
                    case AnsiCarriageReturn():
                        flush_pending()
                        cursor.movePosition(QTextCursor.StartOfBlock)
                    case AnsiNewline():
                        flush_pending()
                        cursor.movePosition(QTextCursor.EndOfBlock)
                        cursor.insertBlock()
                    case AnsiCursorRight(steps=steps):
                        flush_pending()
                        for _ in range(max(1, steps)):
                            cursor.movePosition(QTextCursor.Right)
                    case AnsiCursorLeft(steps=steps):
                        flush_pending()
                        for _ in range(max(1, steps)):
                            cursor.movePosition(QTextCursor.Left)
                    case AnsiClearEol(mode=mode):
                        flush_pending()
                        mode = int(mode)
                        if mode == 1:
                            cursor.movePosition(
                                QTextCursor.StartOfBlock,
                                QTextCursor.KeepAnchor,
                            )
                        elif mode == 2:
                            cursor.movePosition(QTextCursor.StartOfBlock)
                            cursor.movePosition(
                                QTextCursor.EndOfBlock,
                                QTextCursor.KeepAnchor,
                            )
                        else:
                            cursor.movePosition(
                                QTextCursor.EndOfBlock,
                                QTextCursor.KeepAnchor,
                            )
                        cursor.removeSelectedText()
                    case _:
                        continue
            flush_pending()
        finally:
            cursor.endEditBlock()

        self._trim_to_char_limit(force=should_autoscroll)

        if should_autoscroll:
            end_cursor = QTextCursor(self.document())
            end_cursor.movePosition(QTextCursor.End)
            self.setTextCursor(end_cursor)
            self.ensureCursorVisible()
        else:
            # Restore viewport: adding content at the end shouldn't yank the user.
            bar.setValue(min(prev_scroll, bar.maximum()))

    def _format_for_style(self, style: TermStyle) -> QTextCharFormat:
        key = (style.fg, style.bg, style.bold, style.underline, style.inverse)
        cached = self._format_cache.get(key)
        if cached is not None:
            self._format_cache.move_to_end(key)
            return cached

        fmt = QTextCharFormat()

        fg = style.fg
        bg = style.bg
        if style.inverse:
            default_fg = (
                self._default_fg.red(),
                self._default_fg.green(),
                self._default_fg.blue(),
            )
            default_bg = (
                self._default_bg.red(),
                self._default_bg.green(),
                self._default_bg.blue(),
            )
            base_fg = fg if fg is not None else default_fg
            base_bg = bg if bg is not None else default_bg
            fg, bg = base_bg, base_fg

        # Foreground is explicit so default spans don't depend on editor state.
        if fg is None:
            fmt.setForeground(self._default_fg)
        else:
            fmt.setForeground(QColor(*fg))

        if bg is not None:
            fmt.setBackground(QColor(*bg))

        fmt.setFontWeight(QFont.Weight.Bold if style.bold else QFont.Weight.Normal)
        fmt.setFontUnderline(bool(style.underline))

        self._format_cache[key] = fmt
        self._format_cache.move_to_end(key)
        if len(self._format_cache) > self._FORMAT_CACHE_LIMIT:
            self._format_cache.popitem(last=False)
        return fmt

    def _trim_to_char_limit(self, *, force: bool) -> None:
        doc = self.document()
        count = doc.characterCount()
        if count <= self._MAX_CHARS:
            return

        # If the user is reading older output, allow some slack before forcing a trim.
        if not force and count <= self._MAX_CHARS * 2:
            return

        over = count - self._MAX_CHARS
        extra = min(self._MAX_CHARS // 10, 50_000)
        remove = min(count - 1, over + extra)

        trim = QTextCursor(doc)
        trim.setPosition(0)
        trim.setPosition(int(remove), QTextCursor.KeepAnchor)
        trim.removeSelectedText()

    def _on_started(self) -> None:
        self._started = True
        self._append_text(f"[helix] terminal started: {self.title}\n")

    def _on_finished(self, code: int, status: str) -> None:
        if not self._started:
            self._append_text(f"helix: failed to start shell (exit code {code})\n")
        else:
            self._append_text(
                f"\n[helix] terminal exited with code {code}, status {status}\n"
            )

    # ---- Input handling -----------------------------------------------
    def keyPressEvent(self, event: QKeyEvent) -> None:  # type: ignore[override]
        # Never call super(); we only forward bytes to the PTY or handle GUI copy/paste.
        self._handle_key_event(event)

    def _handle_key_event(self, event: QKeyEvent) -> bool:
        key = event.key()
        mods = event.modifiers()

        if mods == (Qt.ControlModifier | Qt.ShiftModifier):
            if key == Qt.Key_C:
                self.copy()
                return True
            if key == Qt.Key_V:
                self._paste_raw()
                return True

        if mods == Qt.ControlModifier:
            if key == Qt.Key_C:
                self._send_bytes(b"\x03")  # SIGINT
                return True
            if key == Qt.Key_D:
                self._send_bytes(b"\x04")  # EOT
                return True
            if key == Qt.Key_L:
                self._send_bytes(b"\x0c")  # form feed / clear
                return True

        if key in (Qt.Key_Return, Qt.Key_Enter):
            self._send_bytes(b"\r")
            return True

        if key == Qt.Key_Backspace:
            self._send_bytes(b"\x7f")
            return True

        if key == Qt.Key_Tab:
            self._send_bytes(b"\t")
            return True

        if key == Qt.Key_Up:
            self._send_bytes(b"\x1b[A")
            return True
        if key == Qt.Key_Down:
            self._send_bytes(b"\x1b[B")
            return True
        if key == Qt.Key_Right:
            self._send_bytes(b"\x1b[C")
            return True
        if key == Qt.Key_Left:
            self._send_bytes(b"\x1b[D")
            return True
        if key == Qt.Key_Escape:
            self._send_bytes(b"\x1b")
            return True

        text = event.text()
        if text:
            self._send_bytes(text.encode("utf-8"))
            return True

        return True

    def _paste_raw(self) -> None:
        text = QApplication.clipboard().text()
        if not text:
            return
        data = text.replace("\r\n", "\n").replace("\r", "\n")
        self._send_bytes(data.encode("utf-8"))

    def _send_bytes(self, data: bytes) -> None:
        self.backend.write(data)

    def focus_input(self) -> None:
        self.setFocus()

    def apply_theme(self, *_args) -> None:
        palette = self._resolve_palette()
        self._default_fg = QColor(palette.foreground)
        self._default_bg = QColor(palette.background)
        self._format_cache.clear()
        self.setStyleSheet(
            f"""
            QTextEdit {{
                background-color: {palette.background};
                color: {palette.foreground};
                selection-background-color: {palette.selection_background};
                selection-color: {palette.selection_foreground};
                border: none;
                padding: 6px 8px;
                line-height: 150%;
            }}
            """
        )

    def _resolve_palette(self) -> TerminalPalette:
        if self._palette_override is not None:
            return self._palette_override

        app = QApplication.instance()
        if app is not None:
            qpal = app.palette()
            try:
                return TerminalPalette(
                    background=qpal.window().color().name(),
                    foreground=qpal.windowText().color().name(),
                    selection_background=qpal.highlight().color().name(),
                    selection_foreground=qpal.highlightedText().color().name(),
                )
            except Exception:
                pass

        return TerminalPalette()

    def clear_scrollback(self) -> None:
        """Clear the visible scrollback without sending anything to the shell."""
        self.clear()

    def resizeEvent(self, event):  # type: ignore[override]
        super().resizeEvent(event)
        fm = self.fontMetrics()
        char_w = max(fm.averageCharWidth(), 1)
        char_h = max(fm.height(), 1)
        cols = max(20, self.viewport().width() // char_w)
        rows = max(2, self.viewport().height() // char_h)
        try:
            self.backend.set_winsize(rows=rows, cols=cols)
        except Exception:
            pass

    def _copy_on_select(self) -> None:
        cursor = self.textCursor()
        if cursor.hasSelection():
            QApplication.clipboard().setText(cursor.selectedText())

    def _move_cursor_to_end(self) -> None:
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.setTextCursor(cursor)
        self.ensureCursorVisible()


__all__ = ["TerminalSessionWidget"]
