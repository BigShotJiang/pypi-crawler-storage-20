"""Tabbed terminal panel suitable for embedding inside the console dock."""

from __future__ import annotations

from typing import Optional

from pathlib import Path

from PySide6.QtCore import Qt, QPoint
from PySide6.QtWidgets import QInputDialog, QMenu, QTabWidget, QVBoxLayout, QWidget

from .process_backend import TerminalProcessBackend
from .session_widget import TerminalSessionWidget
from .settings import TerminalPalette, default_env, default_shell_cmd


class TerminalDock(QWidget):
    def __init__(
        self,
        *,
        cwd: str | None,
        env: dict | None,
        palette: TerminalPalette | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._env = env or default_env()
        self._cwd = cwd
        self._palette = palette

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.tabs = QTabWidget(self)
        self.tabs.setTabsClosable(True)
        try:
            self.tabs.setUsesScrollButtons(True)
            bar = self.tabs.tabBar()
            bar.setExpanding(False)
            bar.setElideMode(Qt.ElideNone)
            bar.setMovable(True)
        except Exception:
            pass
        self.tabs.tabCloseRequested.connect(self._close_tab)
        self.tabs.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tabs.customContextMenuRequested.connect(self._show_tab_menu)
        layout.addWidget(self.tabs)

        # start with a single shell
        self.new_terminal(label="Shell")

    # ---- Public API ---------------------------------------------------
    def new_terminal(self, *, cwd: Optional[str] = None, label: Optional[str] = None) -> None:
        shell_cmd = default_shell_cmd()
        working_dir = cwd or self._cwd or str(Path.cwd())
        backend = TerminalProcessBackend(shell_cmd, cwd=working_dir, env=self._env, parent=self)
        session = TerminalSessionWidget(backend, title=label or shell_cmd[0], palette=self._palette, parent=self)
        idx = self.tabs.addTab(session, label or "Shell")
        self.tabs.setCurrentIndex(idx)
        session.focus_input()

    # ---- Internal helpers --------------------------------------------
    def _close_tab(self, index: int) -> None:
        widget = self.tabs.widget(index)
        if widget is not None and hasattr(widget, "backend"):
            try:
                widget.backend.kill()
            except Exception:
                pass
            widget.deleteLater()
        self.tabs.removeTab(index)

    def _show_tab_menu(self, pos: QPoint) -> None:
        index = self.tabs.tabBar().tabAt(pos)
        if index < 0:
            return
        menu = QMenu(self)

        rename_action = menu.addAction("Rename tab…")
        close_others_action = menu.addAction("Close others")
        close_all_action = menu.addAction("Close all")

        action = menu.exec(self.tabs.tabBar().mapToGlobal(pos))
        if action is None:
            return

        if action == rename_action:
            text, ok = QInputDialog.getText(self, "Rename tab", "Title", text=self.tabs.tabText(index))
            if ok and text.strip():
                self.tabs.setTabText(index, text.strip())
        elif action == close_others_action:
            self._close_all_except(index)
        elif action == close_all_action:
            self._close_all_except(None)

    def _close_all_except(self, keep_index: Optional[int]) -> None:
        for i in reversed(range(self.tabs.count())):
            if keep_index is not None and i == keep_index:
                continue
            self._close_tab(i)

    def close_all(self) -> None:
        """Close all sessions and kill their processes."""
        self._close_all_except(None)

    def focus_current_session(self) -> None:
        widget = self.tabs.currentWidget()
        if widget is not None and hasattr(widget, "focus_input"):
            widget.focus_input()

    def focusInEvent(self, event):  # type: ignore[override]
        self.focus_current_session()
        super().focusInEvent(event)


__all__ = ["TerminalDock"]
