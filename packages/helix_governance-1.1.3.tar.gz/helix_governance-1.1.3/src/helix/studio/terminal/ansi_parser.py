"""Minimal escape sequence helpers for the Studio terminal.

The in-app terminal is not a full terminal emulator: it implements a tiny
subset of VT behavior (CR/LF/BS, a few CSI cursor movements) to keep shells and
readline-style prompts usable inside a ``QTextEdit``.

Anything outside that tiny subset should be stripped to avoid rendering
artifacts, most notably:

- CSI sequences (``ESC [ ...``) used for colors and cursor movement.
- OSC sequences (``ESC ] ...``) used by many shells to set window/tab titles
  (e.g., ``ESC ] 0 ; <title> BEL``).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import TypeAlias

_ANSI_CSI_RE = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")

ANSI16: list[tuple[int, int, int]] = [
    (0, 0, 0),  # 0 black
    (205, 49, 49),  # 1 red
    (13, 188, 121),  # 2 green
    (229, 229, 16),  # 3 yellow
    (36, 114, 200),  # 4 blue
    (188, 63, 188),  # 5 magenta
    (17, 168, 205),  # 6 cyan
    (229, 229, 229),  # 7 white
]

ANSI16_BRIGHT: list[tuple[int, int, int]] = [
    (102, 102, 102),
    (241, 76, 76),
    (35, 209, 139),
    (245, 245, 67),
    (59, 142, 234),
    (214, 112, 214),
    (41, 184, 219),
    (255, 255, 255),
]


@dataclass
class TermStyle:
    fg: tuple[int, int, int] | None = None
    bg: tuple[int, int, int] | None = None
    bold: bool = False
    underline: bool = False
    inverse: bool = False

    def snapshot(self) -> "TermStyle":
        return TermStyle(
            fg=self.fg,
            bg=self.bg,
            bold=self.bold,
            underline=self.underline,
            inverse=self.inverse,
        )


def _xterm256_color(index: int) -> tuple[int, int, int] | None:
    idx = int(index)
    if idx < 0 or idx > 255:
        return None
    if idx < 8:
        return ANSI16[idx]
    if idx < 16:
        return ANSI16_BRIGHT[idx - 8]
    if idx < 232:
        i = idx - 16
        r, g, b = (i // 36) % 6, (i // 6) % 6, i % 6
        levels = (0, 95, 135, 175, 215, 255)
        return (levels[r], levels[g], levels[b])
    gray = 8 + (idx - 232) * 10
    return (gray, gray, gray)


def apply_sgr(params: list[int | None], st: TermStyle) -> None:
    """Apply ANSI SGR parameters to *st* in place.

    Supports:
    - reset, bold, underline, inverse
    - 16-color fg/bg (30-37, 40-47) and bright variants (90-97, 100-107)
    - xterm 256-color + truecolor (38/48;5;n and 38/48;2;r;g;b)
    """

    if not params:
        params = [0]

    i = 0
    while i < len(params):
        p = params[i]
        p = 0 if p is None else int(p)

        if p == 0:
            st.fg = None
            st.bg = None
            st.bold = False
            st.underline = False
            st.inverse = False
        elif p == 1:
            st.bold = True
        elif p == 22:
            st.bold = False
        elif p == 4:
            st.underline = True
        elif p == 24:
            st.underline = False
        elif p == 7:
            st.inverse = True
        elif p == 27:
            st.inverse = False
        elif 30 <= p <= 37:
            st.fg = ANSI16[p - 30]
        elif 90 <= p <= 97:
            st.fg = ANSI16_BRIGHT[p - 90]
        elif 40 <= p <= 47:
            st.bg = ANSI16[p - 40]
        elif 100 <= p <= 107:
            st.bg = ANSI16_BRIGHT[p - 100]
        elif p == 39:
            st.fg = None
        elif p == 49:
            st.bg = None
        elif p in {38, 48}:
            is_fg = p == 38
            mode = params[i + 1] if i + 1 < len(params) else None
            mode = 0 if mode is None else int(mode)
            if mode == 5 and i + 2 < len(params):
                idx = params[i + 2]
                if idx is not None:
                    color = _xterm256_color(idx)
                    if color is not None:
                        if is_fg:
                            st.fg = color
                        else:
                            st.bg = color
                i += 2
            elif mode == 2 and i + 4 < len(params):
                r, g, b = params[i + 2], params[i + 3], params[i + 4]
                if r is not None and g is not None and b is not None:
                    color = (
                        max(0, min(255, int(r))),
                        max(0, min(255, int(g))),
                        max(0, min(255, int(b))),
                    )
                    if is_fg:
                        st.fg = color
                    else:
                        st.bg = color
                i += 4
            # else: ignore unknown/unsupported 38/48 modes

        i += 1


@dataclass(frozen=True)
class AnsiText:
    text: str
    style: TermStyle


@dataclass(frozen=True)
class AnsiCarriageReturn:
    pass


@dataclass(frozen=True)
class AnsiNewline:
    pass


@dataclass(frozen=True)
class AnsiBackspace:
    pass


@dataclass(frozen=True)
class AnsiCursorRight:
    steps: int = 1


@dataclass(frozen=True)
class AnsiCursorLeft:
    steps: int = 1


@dataclass(frozen=True)
class AnsiClearEol:
    mode: int = 0


AnsiEvent: TypeAlias = (
    AnsiText
    | AnsiCarriageReturn
    | AnsiNewline
    | AnsiBackspace
    | AnsiCursorRight
    | AnsiCursorLeft
    | AnsiClearEol
)


@dataclass
class SgrStreamDecoder:
    """Stateful ANSI decoder that interprets CSI SGR (colors) into styled spans.

    This decoder:
    - consumes CSI SGR (``ESC [ ... m``) and updates a current :class:`TermStyle`
    - emits :class:`AnsiText` spans with the active style
    - implements minimal terminal controls needed for readline-style prompts
      (CR/LF/BS and CSI C/D/K)
    - keeps bounded state across chunk boundaries
    """

    max_csi_bytes: int = 4096
    _style: TermStyle = field(default_factory=TermStyle)
    _esc_pending: bool = False
    _in_csi: bool = False
    _csi_buf: str = ""

    def reset(self) -> None:
        self._style = TermStyle()
        self._esc_pending = False
        self._in_csi = False
        self._csi_buf = ""

    def feed(self, text: str) -> list[AnsiEvent]:
        if not text:
            return []

        events: list[AnsiEvent] = []
        buf: list[str] = []

        def flush_text() -> None:
            if not buf:
                return
            events.append(AnsiText("".join(buf), self._style.snapshot()))
            buf.clear()

        def _parse_params(raw: str) -> list[int | None]:
            raw = raw[1:] if raw.startswith("?") else raw
            if not raw:
                return []
            out: list[int | None] = []
            for part in raw.split(";"):
                if part == "":
                    out.append(None)
                    continue
                try:
                    out.append(int(part))
                except ValueError:
                    out.append(None)
            return out

        for ch in text:
            if self._esc_pending:
                self._esc_pending = False
                if ch == "[":
                    self._in_csi = True
                    self._csi_buf = ""
                    continue
                # Ignore the ESC itself, but do not drop the following byte.

            if self._in_csi:
                # CSI terminator is any byte in 0x40-0x7E.
                if 0x40 <= ord(ch) <= 0x7E:
                    cmd = ch
                    raw_params = self._csi_buf
                    self._in_csi = False
                    self._csi_buf = ""

                    params = _parse_params(raw_params)
                    flush_text()

                    if cmd == "m":
                        apply_sgr(params, self._style)
                    elif cmd == "C":
                        steps = params[0] if params else None
                        steps = 1 if steps in {None, 0} else int(steps)
                        events.append(AnsiCursorRight(steps=max(1, steps)))
                    elif cmd == "D":
                        steps = params[0] if params else None
                        steps = 1 if steps in {None, 0} else int(steps)
                        events.append(AnsiCursorLeft(steps=max(1, steps)))
                    elif cmd == "K":
                        mode = params[0] if params else None
                        mode = 0 if mode is None else int(mode)
                        events.append(AnsiClearEol(mode=mode))
                    # any other CSI is ignored visually
                    continue

                self._csi_buf += ch
                if len(self._csi_buf) > self.max_csi_bytes:
                    # Corrupted stream: abort CSI rather than swallowing output forever.
                    self._in_csi = False
                    self._csi_buf = ""
                continue

            if ch == "\x1b":
                self._esc_pending = True
                continue

            if ch in ("\b", "\x7f"):
                flush_text()
                events.append(AnsiBackspace())
                continue

            if ch == "\r":
                flush_text()
                events.append(AnsiCarriageReturn())
                continue

            if ch == "\n":
                flush_text()
                events.append(AnsiNewline())
                continue

            if ch == "\x07":  # bell
                continue

            buf.append(ch)

        flush_text()
        return events


def strip_osc(text: str) -> tuple[str, str]:
    """Strip xterm OSC sequences from *text*.

    OSC sequences start with ``ESC ]`` and are terminated by either:

    - BEL (``\\x07``),
    - ST (``ESC \\``), or
    - the single-byte 8-bit ST (``\\x9c``).

    Returns a tuple ``(cleaned, pending)``.

    The *pending* value is a small prefix (at most 3 characters) that callers
    should prepend to the next chunk to handle chunk-split OSC sequences without
    buffering unbounded payloads.
    """

    if not text:
        return "", ""

    out: list[str] = []
    length = len(text)
    i = 0
    in_osc = False
    osc_esc = False

    while i < length:
        ch = text[i]

        if not in_osc:
            if ch != "\x1b":
                out.append(ch)
                i += 1
                continue

            if i + 1 >= length:
                return "".join(out), "\x1b"

            if text[i + 1] == "]":
                in_osc = True
                osc_esc = False
                i += 2
                continue

            # Not OSC (e.g., CSI); leave bytes untouched for downstream handling.
            out.append(ch)
            i += 1
            continue

        # --- inside OSC payload: drop until BEL or ST ---
        if osc_esc:
            # ST terminator is ESC \ . If it's not a backslash, treat ESC as payload.
            if ch == "\\":
                in_osc = False
                osc_esc = False
                i += 1
                continue
            osc_esc = False
            # Continue processing *ch* below as regular payload (dropped).

        if ch in {"\x07", "\x9c"}:  # BEL or 8-bit ST
            in_osc = False
            i += 1
            continue

        if ch == "\x1b":
            osc_esc = True
            i += 1
            continue

        i += 1

    if in_osc:
        return ("".join(out), "\x1b]\x1b" if osc_esc else "\x1b]")

    return "".join(out), ""


@dataclass
class OscStreamStripper:
    """Stateful OSC stripper for streaming terminal output.

    This keeps the tiny amount of state needed to handle chunk boundaries while
    preventing a corrupted stream from swallowing output forever.
    """

    max_osc_bytes: int = 65536
    _pending: str = ""
    _dropped: int = 0

    def feed(self, text: str) -> str:
        if not text and not self._pending:
            return ""

        if self._pending:
            text = self._pending + text
            self._pending = ""

        cleaned, pending = strip_osc(text)

        # If we are still inside an OSC sequence (unterminated), advance the drop
        # counter. If it exceeds a cap, force-exit OSC mode so output becomes
        # visible again rather than being swallowed forever.
        if pending in {"\x1b]", "\x1b]\x1b"}:
            self._dropped += len(text) - len(cleaned)
            if self._dropped > self.max_osc_bytes:
                pending = ""
                self._dropped = 0
        else:
            self._dropped = 0

        self._pending = pending
        return cleaned

    def reset(self) -> None:
        self._pending = ""
        self._dropped = 0


def strip_ansi(text: str) -> str:
    cleaned, _pending = strip_osc(text)
    return _ANSI_CSI_RE.sub("", cleaned)


__all__ = [
    "ANSI16",
    "ANSI16_BRIGHT",
    "AnsiBackspace",
    "AnsiCarriageReturn",
    "AnsiClearEol",
    "AnsiCursorLeft",
    "AnsiCursorRight",
    "AnsiEvent",
    "AnsiNewline",
    "AnsiText",
    "OscStreamStripper",
    "SgrStreamDecoder",
    "TermStyle",
    "apply_sgr",
    "strip_ansi",
    "strip_osc",
]
