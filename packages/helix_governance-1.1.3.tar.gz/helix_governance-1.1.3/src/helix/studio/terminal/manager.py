"""TerminalManager: integrates the tabbed terminal into the Studio UI."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QApplication

from .dock import TerminalDock
from .settings import TerminalPalette, helix_env_for_project


@dataclass
class TerminalTask:
    label: str
    command: str
    cwd: Optional[Path] = None
    close_on_success: bool = False


class TerminalManager(QObject):
    run_task_started = Signal(str, str)  # label, command

    def __init__(self, main_window, console_tabs, project_root: Optional[Path]) -> None:
        super().__init__(main_window)
        self.main_window = main_window
        self.console_tabs = console_tabs
        self.project_root = project_root
        self._palette = self._derive_palette()

        env = helix_env_for_project(project_root)
        cwd = str(project_root) if project_root else None
        self.panel = TerminalDock(cwd=cwd, env=env, palette=self._palette, parent=console_tabs)
        self._tab_index = console_tabs.addTab(self.panel, "Terminal")
        self.console_tabs.currentChanged.connect(self._on_tab_changed)

    # ---- Public API ---------------------------------------------------
    def show(self) -> None:
        self._ensure_visible()

    def new_shell(self, *, cwd: Optional[Path] = None, label: Optional[str] = None) -> None:
        self.panel.new_terminal(cwd=str(cwd) if cwd else None, label=label)
        self._ensure_visible()

    def new_shell_here(self, cwd: Path) -> None:
        self.panel.new_terminal(cwd=str(cwd), label=cwd.name or "Shell")
        self._ensure_visible()

    def run_command_in_new_tab(self, command: str, *, cwd: Optional[Path] = None, label: Optional[str] = None) -> None:
        self.new_shell(cwd=cwd, label=label)
        self.send_text(command + "\n")

    def send_text(self, text: str) -> None:
        session = self.panel.tabs.currentWidget()
        if session is not None and hasattr(session, "backend"):
            session.backend.write(text)
            self.panel.focus_current_session()

    def run_task(self, task: TerminalTask) -> None:
        self.run_task_started.emit(task.label, task.command)
        self.new_shell(cwd=task.cwd, label=task.label)
        self.send_text(task.command + "\n")
        # close_on_success hook can be added by listening to backend.finished

    def current_session_widget(self):
        return self.panel.tabs.currentWidget()

    def clear_scrollback(self) -> None:
        session = self.current_session_widget()
        if session is not None and hasattr(session, "clear_scrollback"):
            session.clear_scrollback()

    # ---- Helpers ------------------------------------------------------
    def _ensure_visible(self) -> None:
        try:
            if self.console_tabs is not None:
                self.console_tabs.setCurrentIndex(self._tab_index)
            dock = getattr(self.main_window, "console_dock", lambda: None)()
            if dock is not None:
                dock.show()
                dock.raise_()
            self.panel.focus_current_session()
            QApplication.processEvents()
        except Exception:
            pass

    def _on_tab_changed(self, index: int) -> None:
        if index == self._tab_index:
            self.panel.focus_current_session()

    def shutdown(self) -> None:
        """Kill all terminal processes and release UI resources."""
        try:
            self.console_tabs.currentChanged.disconnect(self._on_tab_changed)
        except Exception:
            pass
        try:
            self.panel.close_all()
        except Exception:
            pass

    def _derive_palette(self) -> TerminalPalette:
        try:
            app = QApplication.instance()
            if app is not None:
                qpal = app.palette()
                return TerminalPalette(
                    background=qpal.window().color().name(),
                    foreground=qpal.windowText().color().name(),
                    selection_background=qpal.highlight().color().name(),
                    selection_foreground=qpal.highlightedText().color().name(),
                )
        except Exception:
            pass

        return TerminalPalette()


__all__ = ["TerminalManager", "TerminalTask"]
