from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from helix.edit.dag import EditDAG, dag_from_payload
from helix.studio.models import RunModel
from helix.studio.outcome_explorer import (
    OutcomeExplorerData,
    build_outcome_explorer_data,
    build_outcome_explorer_data_from_evs,
    _contract_hashes_from_evs,
)
from helix.studio.semantic_audit import SuppressedNode, audit_mass_conservation, max_mass_violation
from helix.studio.semantic_schema import CalibrationBadge, ThermoContext, UncertaintyType
from helix.studio.session import ExperimentState


@dataclass(frozen=True)
class MassSummary:
    root_total: float | None
    root_suppressed: float | None
    root_unaccounted: float | None
    epsilon: float | None
    violated: bool | None
    max_violation: float | None
    suppressed_count: int = 0


@dataclass(frozen=True)
class ConstraintSummary:
    edges_with_constraints: int
    exclusive_edges: int
    requires_edges: int
    forbids_edges: int
    exclusive_refs: int
    requires_refs: int
    forbids_refs: int


@dataclass(frozen=True)
class EvidenceSummary:
    support: int
    conflict: int
    missing: int


@dataclass(frozen=True)
class UncertaintySummary:
    aleatoric: int
    epistemic: int
    measurement: int
    unknown: int


@dataclass(frozen=True)
class SchemaIssueSummary:
    rows_with_issues: int
    unique_issues: tuple[str, ...]


@dataclass(frozen=True)
class SimulationDiagnostics:
    run_id: str | None
    run_label: str | None
    run_kind: str | None
    engine: str | None
    backend: str | None
    policy_hash: str | None
    semantic_hash: str | None
    determinism_class: str | None
    decision_mode: str | None
    verdict_grade: str | None
    verdict_headline: str | None
    policy_compliant: bool | None
    noncompliance_reasons: tuple[str, ...]
    integrity_failures: tuple[str, ...]
    integrity_warnings: tuple[str, ...]
    stability_status: str | None
    stability_reason: str | None
    off_target_status: str | None
    off_target_reason: str | None
    calibration_badge: CalibrationBadge
    thermo_context: ThermoContext | None
    mass: MassSummary | None
    constraints: ConstraintSummary | None
    evidence: EvidenceSummary | None
    uncertainty: UncertaintySummary | None
    schema_issues: SchemaIssueSummary | None


def _coerce_payload(payload: object) -> Mapping[str, Any] | None:
    if payload is None:
        return None
    if isinstance(payload, (bytes, bytearray)):
        try:
            payload = payload.decode("utf-8")
        except Exception:
            return None
    if isinstance(payload, str):
        text = payload.strip()
        if not text:
            return None
        try:
            payload = json.loads(text)
        except Exception:
            return None
    if isinstance(payload, Mapping):
        if "nodes" in payload or "edges" in payload:
            return payload
        frames = payload.get("frames")
        if isinstance(frames, Sequence):
            merged = _frames_to_artifact_payload([f for f in frames if isinstance(f, Mapping)])
            return merged or None
        if "new_nodes" in payload or "new_edges" in payload or str(payload.get("kind", "")).startswith("helix.edit_dag.frame"):
            merged = _frames_to_artifact_payload([payload])
            return merged or None
        return None
    if isinstance(payload, Sequence):
        frames = [f for f in payload if isinstance(f, Mapping)]
        if frames:
            merged = _frames_to_artifact_payload(frames)
            return merged or None
    return None


def _frames_to_artifact_payload(frames: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    nodes: dict[str, Any] = {}
    edges: list[Any] = []
    root_id: str | None = None
    for frame in frames:
        if not isinstance(frame, Mapping):
            continue
        new_nodes = frame.get("new_nodes") or {}
        if isinstance(new_nodes, Mapping):
            for node_id, node in new_nodes.items():
                nodes[str(node_id)] = node
                if root_id is None:
                    root_id = str(node_id)
        new_edges = frame.get("new_edges") or []
        if isinstance(new_edges, Sequence):
            for edge in new_edges:
                edges.append(dict(edge) if isinstance(edge, Mapping) else edge)
    if not nodes:
        return {}
    return {
        "artifact": "helix.edit_dag.frame.v1",
        "root_id": root_id or next(iter(nodes)),
        "nodes": nodes,
        "edges": edges,
    }


def _coerce_dag(payload: object) -> EditDAG | None:
    if isinstance(payload, EditDAG):
        return payload
    normalized = _coerce_payload(payload)
    if normalized is None:
        return None
    if not normalized.get("nodes"):
        return None
    try:
        return dag_from_payload(dict(normalized))
    except Exception:
        return None


def _extract_sequence_from_state(state: ExperimentState) -> str:
    seq = ""
    config = state.config if isinstance(state.config, Mapping) else {}
    sim_payload = config.get("sim_payload") if isinstance(config, Mapping) else {}
    if isinstance(sim_payload, Mapping):
        site = sim_payload.get("site") if isinstance(sim_payload.get("site"), Mapping) else {}
        seq = site.get("sequence") or sim_payload.get("sequence") or seq
    if not seq and isinstance(state.viz_spec_payload, Mapping):
        seq = state.viz_spec_payload.get("sequence", "")
    if not seq and getattr(state, "genome", None) is not None:
        try:
            seqs = getattr(state.genome, "sequences", {})
            if isinstance(seqs, Mapping) and seqs:
                seq = next(iter(seqs.values()), "")
        except Exception:
            pass
    return str(seq or "")


def _extract_guide_from_state(state: ExperimentState) -> Mapping[str, Any]:
    config = state.config if isinstance(state.config, Mapping) else {}
    guide = config.get("guide") if isinstance(config.get("guide"), Mapping) else {}
    if guide:
        return guide
    plan = state.edit_plan if isinstance(state.edit_plan, Mapping) else {}
    targets = plan.get("targets") if isinstance(plan.get("targets"), list) else []
    if targets:
        first = targets[0]
        if isinstance(first, Mapping):
            return first
    return {}


def build_outcome_data_from_state(state: ExperimentState) -> OutcomeExplorerData | None:
    if state is None:
        return None
    sequence = _extract_sequence_from_state(state)
    if not sequence:
        return None
    config = state.config if isinstance(state.config, Mapping) else {}
    sim_payload = config.get("sim_payload") if isinstance(config, Mapping) else {}
    outcomes = state.outcomes or (sim_payload.get("outcomes") if isinstance(sim_payload, Mapping) else []) or []
    if not isinstance(outcomes, list) or not outcomes:
        return None
    guide = _extract_guide_from_state(state)
    physics_run = sim_payload.get("physics_score") if isinstance(sim_payload, Mapping) else None
    return build_outcome_explorer_data(
        sequence,
        guide,
        outcomes,
        run_id=state.run_id,
        physics_run=physics_run if isinstance(physics_run, Mapping) else None,
        backend_name=(sim_payload.get("engine") if isinstance(sim_payload, Mapping) else None),
    )


def _extract_dag_payload(
    evs: Mapping[str, Any] | None,
    state: ExperimentState | None,
    *,
    project_root: Path | None = None,
) -> Mapping[str, Any] | None:
    if isinstance(evs, Mapping):
        dag_payload = evs.get("dag_from_runtime")
        if isinstance(dag_payload, Mapping) and dag_payload:
            return dag_payload
        evs_state = evs.get("state")
        if isinstance(evs_state, Mapping):
            dag_payload = evs_state.get("dag_from_runtime")
            if isinstance(dag_payload, Mapping) and dag_payload:
                return dag_payload
        artifacts = evs.get("artifacts")
        if isinstance(artifacts, list):
            for art in artifacts:
                if not isinstance(art, Mapping):
                    continue
                kind = str(art.get("kind") or art.get("schema") or "")
                if "edit_dag" not in kind:
                    continue
                payload = art.get("payload")
                if isinstance(payload, Mapping) and payload:
                    return payload
                path = art.get("path") or art.get("file")
                if not path:
                    continue
                if project_root is None:
                    continue
                try:
                    candidate = (project_root / str(path)).resolve()
                    if candidate.exists():
                        loaded = json.loads(candidate.read_text(encoding="utf-8"))
                        if isinstance(loaded, Mapping):
                            return loaded
                except Exception:
                    continue
    if state is not None:
        dag_payload = getattr(state, "dag_from_runtime", None)
        if isinstance(dag_payload, Mapping) and dag_payload:
            return dag_payload
    return None


def _build_mass_summary(
    dag: EditDAG,
    *,
    collapse_threshold: float,
    epsilon: float,
) -> tuple[MassSummary | None, list[SuppressedNode]]:
    if dag is None:
        return None, []
    root_id = dag.root_id
    root_log_p = float(dag.nodes[root_id].log_prob) if root_id in dag.nodes else 0.0
    node_prob_raw: dict[str, float] = {}
    for node_id, node in dag.nodes.items():
        if node_id == root_id:
            prob = 1.0
        else:
            try:
                prob = math.exp(float(node.log_prob) - root_log_p)
            except Exception:
                prob = 0.0
        node_prob_raw[node_id] = max(0.0, float(prob))
    total = sum(node_prob_raw.values()) or 1.0
    node_prob_display = {nid: node_prob_raw[nid] / total for nid in node_prob_raw}

    suppressed: list[SuppressedNode] = []
    for nid, p in node_prob_display.items():
        if nid == root_id:
            continue
        if p >= collapse_threshold:
            continue
        parents = tuple(dag.nodes[nid].parents or ()) if nid in dag.nodes else ()
        suppressed.append(SuppressedNode(node_id=nid, prob=node_prob_raw.get(nid, 0.0), parents=parents))

    audits = audit_mass_conservation(dag, node_prob_raw, suppressed, epsilon=epsilon)
    root_audit = audits.get(root_id)
    if root_audit is None:
        return None, suppressed
    mass = MassSummary(
        root_total=float(root_audit.mass_out_total.value),
        root_suppressed=float(root_audit.mass_suppressed.value),
        root_unaccounted=float(root_audit.mass_unaccounted.value),
        epsilon=float(root_audit.epsilon),
        violated=bool(root_audit.violated),
        max_violation=float(max_mass_violation(audits)),
        suppressed_count=len(suppressed),
    )
    return mass, suppressed


def _build_constraint_summary(dag: EditDAG) -> ConstraintSummary | None:
    if dag is None:
        return None
    edges_with_constraints = 0
    exclusive_edges = 0
    requires_edges = 0
    forbids_edges = 0
    exclusive_refs = 0
    requires_refs = 0
    forbids_refs = 0
    for edge in dag.edges:
        meta = edge.metadata if isinstance(edge.metadata, Mapping) else {}
        constraints = meta.get("constraints") if isinstance(meta.get("constraints"), Mapping) else {}
        if not isinstance(constraints, Mapping):
            continue
        exclusive = constraints.get("exclusive_with") if isinstance(constraints.get("exclusive_with"), list) else []
        requires = constraints.get("requires") if isinstance(constraints.get("requires"), list) else []
        forbids = constraints.get("forbids") if isinstance(constraints.get("forbids"), list) else []
        if exclusive or requires or forbids:
            edges_with_constraints += 1
        if exclusive:
            exclusive_edges += 1
            exclusive_refs += len(exclusive)
        if requires:
            requires_edges += 1
            requires_refs += len(requires)
        if forbids:
            forbids_edges += 1
            forbids_refs += len(forbids)
    return ConstraintSummary(
        edges_with_constraints=edges_with_constraints,
        exclusive_edges=exclusive_edges,
        requires_edges=requires_edges,
        forbids_edges=forbids_edges,
        exclusive_refs=exclusive_refs,
        requires_refs=requires_refs,
        forbids_refs=forbids_refs,
    )


def _build_evidence_summary(data: OutcomeExplorerData | None) -> EvidenceSummary | None:
    if data is None:
        return None
    support = 0
    conflict = 0
    missing = 0
    for row in data.rows:
        if row.evidence:
            lowered = " ".join(str(e).lower() for e in row.evidence)
            if any("conflicting evidence" in issue for issue in row.schema_issues) or any(
                token in lowered for token in ("conflict", "contradict", "refute")
            ):
                conflict += 1
            else:
                support += 1
        else:
            missing += 1
    return EvidenceSummary(support=support, conflict=conflict, missing=missing)


def _build_uncertainty_summary(data: OutcomeExplorerData | None) -> UncertaintySummary | None:
    if data is None:
        return None
    counts = {
        UncertaintyType.ALEATORIC: 0,
        UncertaintyType.EPISTEMIC: 0,
        UncertaintyType.MEASUREMENT: 0,
        UncertaintyType.UNKNOWN: 0,
    }
    for row in data.rows:
        if row.uncertainty is None:
            counts[UncertaintyType.UNKNOWN] += 1
            continue
        utype = row.uncertainty.type if row.uncertainty is not None else UncertaintyType.UNKNOWN
        if utype not in counts:
            counts[UncertaintyType.UNKNOWN] += 1
        else:
            counts[utype] += 1
    return UncertaintySummary(
        aleatoric=counts[UncertaintyType.ALEATORIC],
        epistemic=counts[UncertaintyType.EPISTEMIC],
        measurement=counts[UncertaintyType.MEASUREMENT],
        unknown=counts[UncertaintyType.UNKNOWN],
    )


def _build_schema_issue_summary(data: OutcomeExplorerData | None) -> SchemaIssueSummary | None:
    if data is None:
        return None
    rows_with_issues = 0
    issues: set[str] = set()
    for row in data.rows:
        if row.schema_issues:
            rows_with_issues += 1
            issues.update(row.schema_issues)
    return SchemaIssueSummary(rows_with_issues=rows_with_issues, unique_issues=tuple(sorted(issues)))


def _run_summary_from_model(run: RunModel | None) -> Mapping[str, Any] | None:
    if run is None:
        return None
    meta = getattr(run, "metadata", None)
    if not isinstance(meta, Mapping):
        return None
    if meta.get("invalid") or meta.get("claims_disabled"):
        return None
    summary = meta.get("run_summary")
    return summary if isinstance(summary, Mapping) else None


def _fallback_verdict(data: OutcomeExplorerData | None) -> tuple[str | None, str | None]:
    if data is None:
        return None, None
    intended_p = float(getattr(data.summary, "intended_functional_p", 0.0) or 0.0)
    no_cut_p = float(getattr(data.summary, "no_cut_prob", 0.0) or 0.0)
    dominance = float(getattr(data.summary, "dominance_ratio", 0.0) or 0.0)
    grade = "C"
    if intended_p < 0.6 or no_cut_p > 0.1 or dominance < 1.5:
        grade = "F"
    headline_by_grade = {
        "A": "High control, low risk within modeled bounds.",
        "B": "Moderate control, review tail risk and off target.",
        "C": "Weak control or incomplete constraints, not deployment ready.",
        "D": "Plurality regime or tail risk dominates, high mosaic or escape risk.",
        "F": "Loss of control, do not treat as intended edit.",
    }
    return grade, headline_by_grade.get(grade, "")


def build_simulation_diagnostics(
    *,
    evs: Mapping[str, Any] | None = None,
    state: ExperimentState | None = None,
    run: RunModel | None = None,
    project_root: Path | None = None,
    collapse_threshold: float = 0.01,
    epsilon: float = 1e-3,
) -> SimulationDiagnostics | None:
    data = None
    if isinstance(evs, Mapping):
        try:
            data = build_outcome_explorer_data_from_evs(dict(evs))
        except Exception:
            data = None
    if data is None and state is not None:
        try:
            data = build_outcome_data_from_state(state)
        except Exception:
            data = None

    run_id = None
    if isinstance(evs, Mapping):
        run_id = evs.get("id") or evs.get("run_id")
    if run_id is None and data is not None:
        run_id = data.run_id
    if run_id is None and state is not None:
        run_id = state.run_id
    if run_id is None and run is not None:
        run_id = run.run_id
    run_id_str = str(run_id) if run_id is not None else None

    run_label = None
    if isinstance(evs, Mapping):
        run_label = evs.get("run_label")
        meta = evs.get("config", {}).get("metadata", {}) if isinstance(evs.get("config"), Mapping) else {}
        if run_label is None and isinstance(meta, Mapping):
            run_label = meta.get("run_label")
        if run_label is None:
            guide = evs.get("config", {}).get("guide", {}) if isinstance(evs.get("config"), Mapping) else {}
            if isinstance(guide, Mapping):
                run_label = guide.get("id") or guide.get("name")
    if run_label is None and run is not None:
        run_label = run.guide_id
    run_label_str = str(run_label) if run_label else None

    run_kind = None
    if isinstance(evs, Mapping):
        run_kind = evs.get("editPlan", {}).get("mode") if isinstance(evs.get("editPlan"), Mapping) else None
    if run_kind is None and state is not None:
        try:
            run_kind = state.run_kind.name
        except Exception:
            run_kind = None
    if run_kind is None and run is not None:
        run_kind = run.edit_type
    run_kind_str = str(run_kind) if run_kind else None

    engine = None
    backend = None
    if isinstance(evs, Mapping):
        sim = evs.get("simulation", {}) if isinstance(evs.get("simulation"), Mapping) else {}
        engine = sim.get("engine") if isinstance(sim, Mapping) else None
    if engine is None and run is not None:
        engine = run.engine.name if run.engine else None
    if run is not None and getattr(run, "engine", None) is not None:
        backend = run.engine.backend

    policy_hash = None
    semantic_hash = None
    determinism_class = None
    if isinstance(evs, Mapping):
        try:
            policy_hash, semantic_hash, determinism_class = _contract_hashes_from_evs(evs)
        except Exception:
            policy_hash = semantic_hash = determinism_class = None

    run_summary = _run_summary_from_model(run)
    decision_mode = None
    verdict_grade = None
    verdict_headline = None
    policy_compliant = None
    noncompliance_reasons: tuple[str, ...] = ()
    integrity_failures: tuple[str, ...] = ()
    integrity_warnings: tuple[str, ...] = ()
    stability_status = None
    stability_reason = None
    off_target_status = None
    off_target_reason = None

    if isinstance(run_summary, Mapping):
        dm = str(run_summary.get("decision_mode") or "").strip().lower()
        if dm in {"filter_only", "decision_grade"}:
            decision_mode = dm
        verdict = run_summary.get("verdict") if isinstance(run_summary.get("verdict"), Mapping) else {}
        verdict_grade = str(verdict.get("grade") or "").strip().upper() or None
        verdict_headline = str(verdict.get("headline") or "").strip() or None
        policy_compliant = verdict.get("compliant_with_policy") if "compliant_with_policy" in verdict else None
        reasons_raw = verdict.get("noncompliance_reasons") if isinstance(verdict.get("noncompliance_reasons"), list) else []
        noncompliance_reasons = tuple(str(r) for r in reasons_raw if r)
        integrity = run_summary.get("integrity") if isinstance(run_summary.get("integrity"), Mapping) else {}
        integrity_failures = tuple(str(r) for r in integrity.get("failures", []) if r)
        integrity_warnings = tuple(str(r) for r in integrity.get("warnings", []) if r)
        control = run_summary.get("control") if isinstance(run_summary.get("control"), Mapping) else {}
        stability = control.get("stability") if isinstance(control.get("stability"), Mapping) else {}
        stability_status = str(stability.get("status") or "").strip() or None
        stability_reason = str(stability.get("reason") or stability.get("severity") or "").strip() or None
        risk = run_summary.get("risk") if isinstance(run_summary.get("risk"), Mapping) else {}
        off_target = risk.get("off_target") if isinstance(risk.get("off_target"), Mapping) else {}
        off_target_status = str(off_target.get("status") or "").strip() or None
        off_target_reason = str(off_target.get("reason") or off_target.get("limitations") or "").strip() or None

    if verdict_grade is None or verdict_headline is None:
        fallback_grade, fallback_headline = _fallback_verdict(data)
        verdict_grade = verdict_grade or fallback_grade
        verdict_headline = verdict_headline or fallback_headline

    dag_payload = _extract_dag_payload(evs, state, project_root=project_root)
    dag = _coerce_dag(dag_payload)
    mass_summary, _ = _build_mass_summary(dag, collapse_threshold=collapse_threshold, epsilon=epsilon) if dag else (None, [])
    constraint_summary = _build_constraint_summary(dag) if dag else None

    evidence_summary = _build_evidence_summary(data)
    uncertainty_summary = _build_uncertainty_summary(data)
    schema_issue_summary = _build_schema_issue_summary(data)

    calibration_badge = data.calibration_badge if data is not None else CalibrationBadge.UNKNOWN
    thermo_context = data.thermo_context if data is not None else None

    if not (data or dag or run_summary or run_id_str or run_label_str):
        return None

    return SimulationDiagnostics(
        run_id=run_id_str,
        run_label=run_label_str,
        run_kind=run_kind_str,
        engine=str(engine) if engine else None,
        backend=str(backend) if backend else None,
        policy_hash=str(policy_hash) if policy_hash else None,
        semantic_hash=str(semantic_hash) if semantic_hash else None,
        determinism_class=str(determinism_class) if determinism_class else None,
        decision_mode=decision_mode,
        verdict_grade=verdict_grade,
        verdict_headline=verdict_headline,
        policy_compliant=policy_compliant if isinstance(policy_compliant, bool) else None,
        noncompliance_reasons=tuple(noncompliance_reasons or ()),
        integrity_failures=tuple(integrity_failures or ()),
        integrity_warnings=tuple(integrity_warnings or ()),
        stability_status=stability_status,
        stability_reason=stability_reason,
        off_target_status=off_target_status,
        off_target_reason=off_target_reason,
        calibration_badge=calibration_badge,
        thermo_context=thermo_context,
        mass=mass_summary,
        constraints=constraint_summary,
        evidence=evidence_summary,
        uncertainty=uncertainty_summary,
        schema_issues=schema_issue_summary,
    )


__all__ = [
    "MassSummary",
    "ConstraintSummary",
    "EvidenceSummary",
    "UncertaintySummary",
    "SchemaIssueSummary",
    "SimulationDiagnostics",
    "build_simulation_diagnostics",
    "build_outcome_data_from_state",
]
