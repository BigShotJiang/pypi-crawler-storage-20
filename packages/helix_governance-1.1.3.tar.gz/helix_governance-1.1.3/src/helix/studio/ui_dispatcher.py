from __future__ import annotations

from PySide6.QtCore import QObject, Signal, Qt, QThread
from PySide6.QtWidgets import QApplication


class UiDispatcher(QObject):
    _call = Signal(object)

    def __init__(self) -> None:
        super().__init__()
        self._call.connect(self._run, Qt.QueuedConnection)

    def post(self, fn) -> None:
        self._call.emit(fn)

    def assert_ui_thread(self) -> None:
        app = QApplication.instance()
        if app is None:
            return
        if QThread.currentThread() != app.thread():
            raise RuntimeError("UI mutation called off UI thread")

    def _run(self, fn) -> None:
        fn()


dispatcher = UiDispatcher()


def ui_post(fn) -> None:
    dispatcher.post(fn)


def assert_ui_thread() -> None:
    dispatcher.assert_ui_thread()


__all__ = ["dispatcher", "ui_post", "assert_ui_thread"]
