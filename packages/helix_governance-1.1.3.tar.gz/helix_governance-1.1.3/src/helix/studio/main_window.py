from __future__ import annotations

import json
import os
import sys
import traceback
import platform
from pathlib import Path
from copy import deepcopy

from typing import Any, Mapping, Callable, List, Sequence

from PySide6.QtCore import (
    Qt,
    QSettings,
    QByteArray,
    QUrl,
    QEvent,
    Signal,
    QObject,
    QSize,
    QPoint,
    QRect,
    QPropertyAnimation,
    QEasingCurve,
)
from PySide6.QtGui import QKeySequence, QShortcut, QDesktopServices, QAction, QGuiApplication, QCursor, QIcon
from PySide6.QtWidgets import (
    QDockWidget,
    QFileDialog,
    QDialog,
    QLabel,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QTableWidget,
    QTableWidgetItem,
    QScrollArea,
    QSplitter,
    QTabWidget,
    QAbstractSpinBox,
    QComboBox,
    QToolButton,
    QMenuBar,
    QStyle,
    QHBoxLayout,
    QStackedWidget,
    QWidget,
    QVBoxLayout,
    QFrame,
    QListWidgetItem,
    QSizePolicy,
)
from PySide6.QtGui import QTextCursor
from PySide6.QtCore import QTimer
from helix.studio.qtconcurrent_compat import qt_run, QFutureWatcher
from helix import clock
from helix import temp

from .gl_panel import GLViewport
from .session import SessionModel
from .session_inspector import SessionInspector
from .workflow_panel import Workflow2p5DPanel
from .edit_dag_panel import EditDAGPanel
from .run_history import RunHistoryWidget
from .guide_inspector import GuideRunSummary, GuideInspectorWidget
from .ui_tokens import (
    base_font,
    monospace_font,
    MARGIN_PANEL,
    SPACING_MEDIUM,
    SPACING_SMALL,
    scaled_px,
    ui_scale_factor,
)
from helix.studio.reports.session_report import save_session_report
from helix.studio.limitations import limitations_stamp
from helix.support.build_meta import is_enterprise_build
from helix.studio.export_image_settings import (
    set_write_image_provenance_sidecars_enabled,
    write_image_provenance_sidecars_enabled,
)
from helix.studio.outcome_explorer import OutcomeExplorerWidget, build_outcome_explorer_data
from helix.studio.export_gate import build_export_context
from helix.studio.ui.export_gate import ensure_export_allowed
from helix.studio.run_artifact import (
    build_run_artifact_from_run_model,
    artifact_is_valid,
    artifact_root_causes,
    artifact_decision_mode_eligible,
)
from helix.studio.ui.text_utils import enable_word_wrap
from helix.studio.demo_loader import (
    build_guide_summaries_from_demo,
    demo_guides_payload,
    build_guide_summaries_from_session,
    build_runmodels_from_demo,
    build_canonical_demo_snapshot,
)
from helix.studio.experiment_presets import (
    load_preset as load_experiment_preset,
    preset_to_snapshot,
    list_presets,
    save_user_preset,
)
from helix.studio.session_io import save_session, load_session, _ensure_contract_identity
from helix.studio.guide_compare import GuideCompareWidget
from helix.studio.models import RunModel, EngineInfo
from PySide6.QtWidgets import QApplication
from helix.studio.welcome import WelcomeDialog
from helix.studio.export_evidence import run_to_evidence, write_evidence_json


def _is_headless_platform() -> bool:
    """Return True when running in offscreen/headless Qt mode."""
    platform_env = os.environ.get("QT_QPA_PLATFORM", "").lower()
    headless_env = os.environ.get("HELIX_STUDIO_HEADLESS", "0") == "1"
    if platform_env == "offscreen" or headless_env:
        return True

    # Tests frequently create the QApplication while QT_QPA_PLATFORM is set and then
    # later unset the env var via monkeypatch teardown. Query the active Qt platform
    # name to keep welcome dialog behavior consistent (and avoid modal hangs in CI).
    try:
        platform_name = str(QApplication.platformName() or "").lower()
    except Exception:
        platform_name = ""
    return platform_name in {"offscreen", "minimal"}


def _is_wayland_platform() -> bool:
    platform = os.environ.get("QT_QPA_PLATFORM", "").lower()
    session = os.environ.get("XDG_SESSION_TYPE", "").lower()
    return "wayland" in platform or session == "wayland"


def _is_wsl() -> bool:
    try:
        if "microsoft" in platform.release().lower():
            return True
    except Exception:
        pass
    if os.getenv("WSL_DISTRO_NAME"):
        return True
    try:
        with open("/proc/sys/kernel/osrelease", "r", encoding="utf-8") as f:
            data = f.read().lower()
            if "microsoft" in data or "wsl" in data:
                return True
    except Exception:
        pass
    return False


def _global_pos_from_event(event) -> QPoint | None:
    try:
        return event.globalPosition().toPoint()
    except Exception:
        try:
            return event.globalPos()
        except Exception:
            try:
                return QCursor.pos()
            except Exception:
                return None


def _frameless_debug_enabled() -> bool:
    return os.getenv("HELIX_FRAMELESS_DEBUG", "0") == "1"


def _frameless_log(message: str) -> None:
    log_path = os.getenv("HELIX_FRAMELESS_LOG")
    if not _frameless_debug_enabled() and not log_path:
        return
    line = f"[HelixFrameless] {message}\n"
    if _frameless_debug_enabled():
        try:
            sys.stderr.write(line)
            sys.stderr.flush()
        except Exception:
            pass
    if log_path:
        try:
            Path(log_path).parent.mkdir(parents=True, exist_ok=True)
            with open(log_path, "a", encoding="utf-8") as handle:
                handle.write(line)
        except Exception:
            pass


def _frameless_resize_disabled() -> bool:
    return os.getenv("HELIX_FRAMELESS_DISABLE_RESIZE", "0") == "1"


def _edges_value(edges: Qt.Edges) -> int:
    try:
        return int(edges)
    except Exception:
        try:
            return int(getattr(edges, "value", 0))
        except Exception:
            return 0

def _make_history_widget(session, on_compare):
    import os
    if os.getenv("HELIX_STUDIO_RUN_HISTORY_MV", "0") == "1":
        try:
            from helix.studio.experimental.run_history_mv.run_history_model import RunHistoryTableModel
            from helix.studio.run_history import RunHistoryWidget as StableWidget
            # Placeholder: currently fallback to stable even when flag is on; experimental widget disabled due to stability.
            return StableWidget(session, on_compare=on_compare)
        except Exception:
            return RunHistoryWidget(session, on_compare=on_compare)
    return RunHistoryWidget(session, on_compare=on_compare)


def _can_create_under(path: Path) -> bool:
    """Return True if we can create files/dirs under `path` (or its nearest existing parent)."""

    try:
        candidate = Path(path).expanduser().resolve()
    except Exception:
        candidate = Path(path)

    # Find nearest existing parent.
    probe = candidate
    try:
        while not probe.exists():
            parent = probe.parent
            if parent == probe:
                break
            probe = parent
        if not probe.exists():
            return False
        # We need to create *within* probe (or within candidate itself if it exists).
        base = candidate if candidate.exists() else probe
        return bool(base.is_dir()) and os.access(str(base), os.W_OK)
    except Exception:
        return False


class _RightSidebarDrawerOverlay(QFrame):
    """
    In-window sidebar drawer overlay.

    Notes:
    - Treat the overlay as the focus scope while open (Tab should not escape).
    - Override QWidget.window() for testability: focus.window() should resolve to the overlay.
    """

    def window(self) -> QWidget:  # type: ignore[override]
        return self

    def keyPressEvent(self, event) -> None:  # type: ignore[override]
        try:
            key = int(getattr(event, "key", lambda: -1)())
        except Exception:
            key = -1
        if key in (int(Qt.Key_Tab), int(Qt.Key_Backtab)):
            try:
                event.accept()
            except Exception:
                pass
            try:
                self.setFocus(Qt.TabFocusReason)
            except Exception:
                pass
            return
        super().keyPressEvent(event)

    def focusNextPrevChild(self, _next: bool) -> bool:  # type: ignore[override]
        # Keep keyboard focus inside the overlay while it's open.
        try:
            self.setFocus(Qt.TabFocusReason)
        except Exception:
            pass
        return True


def _default_project_root() -> Path:
    """Pick a sane writable default project root when StudioContext isn't provided.

    Path.cwd() is fine when Studio is started from a repo/workdir, but it can be
    '/' (or another unwritable location) in containers/WSL shells.
    """

    env_root = os.getenv("HELIX_PROJECT_ROOT")
    if env_root:
        candidate = Path(env_root).expanduser()
        if _can_create_under(candidate):
            return candidate.resolve()

    cwd = Path.cwd()
    if _can_create_under(cwd):
        return cwd.resolve()

    # Dev fallback: if running from a source checkout, use repo root (pyproject + src/helix).
    try:
        here = Path(__file__).resolve()
        for parent in here.parents:
            if (parent / "pyproject.toml").exists() and (parent / "src" / "helix").exists():
                if _can_create_under(parent):
                    return parent.resolve()
    except Exception:
        pass

    try:
        home = Path.home()
        candidate = home / "helix_studio"
        if _can_create_under(candidate):
            return candidate
    except Exception:
        pass

    return Path("/tmp/helix_studio").resolve()
from .run_compare import RunCompareWidget
from .terminal import TerminalManager, TerminalTask
from helix.gui.simbuilder.app import create_simbuilder_widget
from helix.studio.project import ProjectModel
from helix.studio.context import StudioContext
from helix.snapshot_bundle import default_snapshot_dir, default_report_dir, pack_snapshot_bundle
from helix.config import HelixFeatures
from helix.studio.run_metrics import build_report
from helix.studio.center_panel import CenterPanel
from helix.studio.hint_banner import HintBanner
from helix.studio.importers.adapters import imported_run_to_snapshot, _now_iso
from helix.studio.project import ImportedRunRef
from helix.studio.importers.registry import get_importer
from helix.studio.importers import ImportFailed
from helix.studio.workers import run_bg, CancelToken
from helix.studio.perf import perf_section
from helix.evs.io import load_evs_for_run
from helix.studio.layout_presets import (
    ensure_default_presets,
    load_preset as load_layout_preset,
    save_preset as save_layout_preset,
)
from helix.studio.layout_state import LayoutState, CenterTabLayout
from helix.studio.evs_bridge import extract_guide_context, extract_prime_context
from helix.studio.ui.window_positioning import center_on_focused_window, ensure_on_screen
from helix.gui.qt_geometry import qt_move, qt_set_geometry
from helix.studio.backend_config import load_backend_config
from helix.studio.api_client import InstrumentRunsApiClient
from helix.studio.instrument_runs_view import InstrumentRunsWidget
from helix.gui.theme import apply_helix_theme, available_themes, current_theme_name, token_theme_names, _display_name
from helix.gui.icon_resources import ensure_icon_resources_loaded
from .commands import CommandRegistry
from .dock_panels import DockPanelRegistry
from .helixspec_editor import HelixSpecEditor
from .extension_host import ExtensionHostClient, ExtensionHostSupervisor
from .extension_host.protocol import (
    METHOD_EVENTS_EMIT as EXT_METHOD_EVENTS_EMIT,
    METHOD_INVOKE_COMMAND as EXT_METHOD_INVOKE_COMMAND,
    METHOD_LOAD_PLUGINS as EXT_METHOD_LOAD_PLUGINS,
    METHOD_UNLOAD_PLUGINS as EXT_METHOD_UNLOAD_PLUGINS,
    METHOD_WEB_PANEL_CALL as EXT_METHOD_WEB_PANEL_CALL,
    NOTIFY_COMMAND_REGISTER as EXT_NOTIFY_COMMAND_REGISTER,
    NOTIFY_COMMAND_PROGRESS as EXT_NOTIFY_COMMAND_PROGRESS,
    NOTIFY_LOG as EXT_NOTIFY_LOG,
    NOTIFY_SYSTEM_CLIPBOARD_SET as EXT_NOTIFY_SYSTEM_CLIPBOARD_SET,
    NOTIFY_SYSTEM_OPEN_URL as EXT_NOTIFY_SYSTEM_OPEN_URL,
    NOTIFY_WEB_PANEL_MESSAGE as EXT_NOTIFY_WEB_PANEL_MESSAGE,
    NOTIFY_WEB_PANEL_REGISTER as EXT_NOTIFY_WEB_PANEL_REGISTER,
    NOTIFY_WEB_PANEL_UNREGISTER as EXT_NOTIFY_WEB_PANEL_UNREGISTER,
)
from .plugins import HelixPluginManager, LoadedPlugin, default_plugin_search_paths
from .plugins.studio_host import StudioPluginHost
from .ui_dispatcher import ui_post
from .web_panels import WebPanelBridge, WebPanelSpec, build_web_panel_widget
from .rail_state import RailStateStore
from .rail_model import CacheState, RailSelection, StageKind, RecomputeResult, stable_hash


ensure_icon_resources_loaded()
from .rail_planner import RecomputePlanner
from .status_chip import StatusChip
from .backend_commit import commit_with_guards
from .run_status_panel import RunStatusPanel


def _random_token() -> str:
    from helix.security.tokens import token_hex

    return token_hex(8)


SETTINGS_ORG = "Helix"
SETTINGS_APP = "Studio"
SETTINGS_GEOMETRY_KEY = "main/geometry"
SETTINGS_STATE_KEY = "main/state"
SETTINGS_LAYOUT_JSON_KEY = "main/layout_json"
SETTINGS_CENTER_TAB_KEY = "main/center_tab"
SETTINGS_REALTIME_VIEW_KEY = "main/view_state/realtime"
SETTINGS_WORKFLOW_VIEW_KEY = "main/view_state/workflow_2p5d"
SETTINGS_DAG_VIEW_KEY = "main/view_state/edit_dag"
SETTINGS_VISUALS_BANNER_KEY = "banners/visuals_unavailable_seen"
SETTINGS_VIEWER_PERF_HUD_KEY = "main/viewer/perf_hud"
SETTINGS_VIEW_STATE_VERSION = 1

_TOPBAR_METRICS_CACHE: tuple[float, tuple[int, int, int, int, int]] | None = None


def _topbar_metrics(*, screen=None) -> tuple[int, int, int, int, int]:
    """Return (height, pad_left, pad_right, gap, btn_size) derived from tokens."""
    global _TOPBAR_METRICS_CACHE
    scale = ui_scale_factor(screen=screen)
    if _TOPBAR_METRICS_CACHE is not None:
        cached_scale, cached = _TOPBAR_METRICS_CACHE
        if abs(cached_scale - scale) < 0.01:
            return cached
    height = 40
    pad_left = 12
    pad_right = 8
    gap = 8
    btn_size = 40
    try:
        tokens_path = Path(__file__).resolve().parents[3] / "helix" / "theme" / "tokens.json"
        data = json.loads(tokens_path.read_text(encoding="utf-8"))
        spacing = data.get("spacing", {})
        height = int(spacing.get("xxl", 32) + spacing.get("sm", 8))
        pad_left = int(spacing.get("md", 12))
        pad_right = int(spacing.get("sm", 8))
        gap = int(spacing.get("sm", 8))
        btn_size = max(40, int(height))
    except Exception:
        pass
    height = max(28, int(round(height * scale)))
    pad_left = max(4, int(round(pad_left * scale)))
    pad_right = max(4, int(round(pad_right * scale)))
    gap = max(2, int(round(gap * scale)))
    btn_size = max(int(round(40 * scale)), height)
    metrics = (height, pad_left, pad_right, gap, btn_size)
    _TOPBAR_METRICS_CACHE = (scale, metrics)
    return metrics

# Responsive layout policy (3 tiers):
# - wide: persistent left+right panels
# - medium: right panel becomes overlay, left stays available
# - compact: progressively disclose everything; center-first
LAYOUT_WIDE_MIN_WIDTH = 1440
LAYOUT_WIDE_MIN_HEIGHT = 950
LAYOUT_MEDIUM_MIN_WIDTH = 1150
LAYOUT_MEDIUM_MIN_HEIGHT = 720
LAYOUT_COMPACT_MIN_CENTER_WIDTH = 640
LEFT_RAIL_WIDTH = 78
SIDEBAR_MAX_FRACTION = 0.38
SIDEBAR_MAX_PX = 960
SIDEBAR_DEFAULT_PX = 420


class _SplitterShrinkContainer(QWidget):
    """Splitter child wrapper that refuses to advertise a large minimum width.

    Qt's QSplitter enforces each child's smart minimum size which, by default,
    includes `minimumSizeHint()`. Some widgets (notably QTabWidget) can report a
    relatively large minimum hint that prevents adjacent panels from expanding,
    making the center pane feel "fixed width" on resize or drag.

    The center surface must be shrinkable so left/right rails can be resized.
    """

    def minimumSizeHint(self) -> QSize:  # type: ignore[override]
        try:
            base = super().minimumSizeHint()
        except Exception:
            return QSize(0, 0)
        return QSize(0, int(base.height()))


class _TopBar(QFrame):
    def __init__(self, window: QMainWindow) -> None:
        super().__init__(window)
        self._window = window
        self.setObjectName("HelixTopBar")
        self.setProperty("role", "panel")
        self.setFixedHeight(40)
        self.setMouseTracking(True)

    def _is_drag_allowed(self, pos: QPoint) -> bool:
        child = self.childAt(pos)
        if child is None:
            return True
        if child.property("dragDisabled"):
            return False
        return True

    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        if event.button() == Qt.LeftButton and self._is_drag_allowed(event.position().toPoint()):
            wh = self._window.windowHandle()
            if wh is not None:
                if self._window.isMaximized():
                    try:
                        self._window.showNormal()
                    except Exception:
                        pass
                _frameless_log("TopBar: startSystemMove")
                wh.startSystemMove()
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:  # type: ignore[override]
        if event.button() == Qt.LeftButton and self._is_drag_allowed(event.position().toPoint()):
            if self._window.isMaximized():
                _frameless_log("TopBar: double-click -> showNormal")
                self._window.showNormal()
            else:
                _frameless_log("TopBar: double-click -> showMaximized")
                self._window.showMaximized()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)


class HelixStudioMainWindow(QMainWindow):
    outcomeSelectedOnRail = Signal(object)

    def __init__(
        self,
        session: SessionModel | None = None,
        ctx: StudioContext | None = None,
        parent: QWidget | None = None,
        *,
        enable_gl: bool = True,
    ) -> None:
        super().__init__(parent)
        try:
            from .debug_runtime import log_pid

            log_pid("main_window.__init__")
            if str(os.environ.get("HELIX_STUDIO_DEBUG_WINDOWS") or "").strip().lower() in {"1", "true", "yes", "on"}:
                sys.stderr.write(
                    f"[HelixWindow] HelixStudioMainWindow created id=0x{id(self):x} pid={os.getpid()}\n"
                )
                sys.stderr.flush()
        except Exception:
            pass
        self.setFont(base_font())
        self._settings = QSettings("Helix", "Studio")
        self._export_prompt_suppressed_by_key: dict[str, bool] = {}
        self._command_registry = CommandRegistry()
        self._dock_panel_registry = DockPanelRegistry()
        self._plugin_manager: HelixPluginManager | None = None
        self._plugin_host: StudioPluginHost | None = None
        self._extension_hosts: ExtensionHostSupervisor | None = None
        self._remote_plugin_ids: set[str] = set()
        self._remote_web_panel_bridges: dict[str, WebPanelBridge] = {}
        self._remote_pending_requests: dict[tuple[str, int], dict[str, str]] = {}
        self._plugin_progress: dict[str, str] = {}
        self._plugin_policy_violations: dict[str, int] = {}
        self._extension_host_watchdog: QTimer | None = None
        self._extension_host_running: dict[str, bool] = {}
        self._extension_host_restart_info: dict[str, dict[str, Any]] = {}
        self._plugin_host_crashes: dict[str, int] = {}
        self._plugin_command_timeouts: dict[str, int] = {}
        self._plugins_loaded = False
        self._plugins_safe_mode = False
        self._core_commands_registered = False
        self._plugin_logs: dict[str, list[str]] = {}
        self._menu_import = None
        self._menu_view = None
        self._menu_tools = None
        self._menu_help = None
        self._menu_plugin_panels = None
        self._theme_actions: dict[str, QAction] = {}
        self._menu_bar: QMenuBar | None = None
        self._top_bar: _TopBar | None = None
        native_env = os.getenv("HELIX_NATIVE_CHROME")
        default_native = False
        if native_env is None:
            if _is_headless_platform():
                # Frameless chrome requires global event filtering + style quirks that are not
                # meaningful in offscreen/minimal QPA mode and can destabilize headless tests/CI.
                default_native = True
            elif _is_wayland_platform():
                default_native = True
            elif _is_wsl():
                default_native = True
            elif os.name == "nt":
                # Prefer native Windows chrome so resize cursors/buttons come from the OS.
                default_native = True
        self._native_chrome = (native_env or "1" if default_native else "0") == "1"
        _frameless_log(
            f"native_chrome={self._native_chrome} env={native_env!r} "
            f"wayland={_is_wayland_platform()} wsl={_is_wsl()}"
        )
        self._resize_margin_px = 6
        self._resize_active = False
        self._window_btn_max: QToolButton | None = None
        self._icon_window_min: QIcon | None = None
        self._icon_window_max: QIcon | None = None
        self._icon_window_restore: QIcon | None = None
        self._icon_window_close: QIcon | None = None
        self.session = session or SessionModel(self)
        if ctx is None:
            root_path = _default_project_root()
            name = root_path.name or "helix_project"
            default_project = None
            try:
                if (root_path / ".helix_project.json").exists():
                    default_project = ProjectModel.load(root_path)
            except Exception:
                default_project = None
            if default_project is None:
                default_project = ProjectModel(root_path=root_path, name=name)
            ctx = StudioContext(project=default_project, features=HelixFeatures())
        self.ctx = ctx
        self.project = self.ctx.project
        self.rail_store = RailStateStore(self.session, self)
        try:
            self.rail_store.selectionChanged.connect(self._on_rail_selection_changed)
            self.rail_store.graphChanged.connect(self._on_rail_graph_changed)
            self.rail_store.recomputeRequested.connect(self._on_recompute_requested)
            self.rail_store.recomputeDownstreamRequested.connect(self._on_recompute_downstream_requested)
            self.rail_store.recomputeResultChanged.connect(self._on_recompute_result_changed)
            self.rail_store.recomputeRejected.connect(self._on_recompute_rejected)
            self.rail_store.staleResultDropped.connect(self._on_stale_result_dropped)
        except Exception:
            pass
        self._enable_gl = enable_gl
        self._init_helixspec_buffer()
        backend_cfg = load_backend_config()
        self._instrument_runs_api = InstrumentRunsApiClient(backend_cfg.base_url)
        # Ensure GL attributes exist before any Qt events fire
        self.gl_view: GLViewport | None = None
        self._docks: list[QDockWidget] = []
        self._log_buffer: list[str] = []
        self.terminal_manager: TerminalManager | None = None
        self._layout_mode: str | None = None
        self._sidebar_overlay = None
        self._sidebar_overlay_body = None
        self._sidebar_overlay_anim: QPropertyAnimation | None = None
        self._sidebar_overlay_guard: QObject | None = None
        # User intent: when True, keep the right overlay open when returning to overlay modes.
        # Wide mode always uses the docked right column (if enabled); overlay visibility is a
        # separate preference so medium can stay center-first by default.
        self._right_overlay_pinned_open = False
        self._sidebar_button_bar = None
        self._sidebar_drawer_button: QToolButton | None = None
        self._compact_menu_button: QToolButton | None = None
        self._activity_bar: QWidget | None = None
        self._left_rail_collapsed = False
        self._left_rail_ultra_hidden = False
        self._left_rail_pinned_open = False
        self._left_rail_hover_timer: QTimer | None = None
        self._left_rail_hover_guard: QObject | None = None
        self._left_hidden = False
        self._right_hidden = False
        self._left_last_size = SIDEBAR_DEFAULT_PX
        self._right_last_size = SIDEBAR_DEFAULT_PX
        self._console_restore_visible = False
        self._last_status_message = "Ready"
        self._focus_mode = False
        self._welcome_rejected = False
        self._welcome_checked = False
        self._pending_welcome_action: tuple[str, str | None] | None = None
        self._pending_initial_rail_segment_id: str | None = None
        self._focus_saved_sizes: list[int] | None = None
        # Log pane created up-front so tests can emit before showEvent
        self.log_widget = QPlainTextEdit()
        self.log_widget.setReadOnly(True)
        self.log_widget.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.log_widget.setMaximumBlockCount(800)
        self.log_widget.setPlaceholderText("Logs...")
        self.log_widget.setUndoRedoEnabled(False)
        self._log_flush_timer = QTimer(self)
        self._log_flush_timer.setInterval(50)
        self._load_token = CancelToken()
        self.setWindowTitle(f"Helix Studio – {self.project.name}")
        self._active_evs: dict | None = None
        self._pending_snapshots: list[Mapping[str, object]] = []
        self._run_recorded_connected = False
        self._pending_focus_run_id: str | None = None
        self._recompute_inflight_id: str | None = None
        self._recompute_chain_id: str | None = None
        self._recompute_chain: List[str] = []
        self._recompute_chain_start: List[str] = []
        self._compare_baseline: Mapping[str, object] | None = None
        if not self._native_chrome:
            self._install_frameless_chrome()
        self._compare_candidate: Mapping[str, object] | None = None
        # Flag to request fullscreen after startup events settle.
        self._fullscreen_after_welcome = False
        # One-time restore of center tab + viewer continuity state.
        self._restored_continuity_state = False
        self._pending_layout_state_restore: LayoutState | None = None
        self._last_splitter_wide_sizes: list[int] | None = None
        self._last_splitter_overlay_sizes: list[int] | None = None
        self._center_tab_index_by_key: dict[str, int] = {}
        self._closed_center_tabs: set[str] = set()
        self._suspend_center_tab_persistence = True
        self._active_center_tab_key: str | None = None
        self._ui_built = False
        self._show_requested = False
        # Track explicit pre-show sizing so headless/offscreen tests can clamp only
        # when the caller did not request a specific geometry.
        self._user_sized_before_show = False
        self._ui_build_failed = False
        self._helixspec_run_watcher: QFutureWatcher | None = None
        self._last_helixspec_run_dir: Path | None = None
        self._restore_last_helixspec_bundle_from_config()

        # Lightcone integration wiring (single panel instance owned by main window).
        self._lightcone_wired = False
        self._pending_lightcone_run: RunModel | None = None
        self._selected_lightcone_run: RunModel | None = None
        self._lightcone_sync_timer = QTimer(self)
        self._lightcone_sync_timer.setSingleShot(True)
        self._lightcone_sync_timer.timeout.connect(self._apply_pending_lightcone_sync)
        self._lightcone_last_locus_context: dict | None = None
        self._lightcone_last_export: tuple[str, str] | None = None
        self._lightcone_last_outcome: dict | None = None

        # Ingest status widgets (permanent in status bar)
        self._ingest_status = QLabel("")
        self._ingest_cancel_btn = QToolButton(self)
        self._ingest_cancel_btn.setText("Cancel ingest")
        self._ingest_cancel_btn.hide()
        self._ingest_cancel_btn.clicked.connect(self._on_ingest_cancel_clicked)
        self._cancel_target_label = QLabel("")
        self._cancel_target_label.setProperty("role", "muted")
        self.statusBar().addPermanentWidget(self._ingest_status)
        self.statusBar().addPermanentWidget(self._cancel_target_label)
        self.statusBar().addPermanentWidget(self._ingest_cancel_btn)
        self._current_cancel: str | None = None

    def show(self) -> None:  # type: ignore[override]
        self._show_requested = True
        return super().show()

    def resize(self, *args) -> None:  # type: ignore[override]
        # Capture explicit programmatic sizing before the window is shown; offscreen/minimal
        # platforms can emit resize events during `show()` which should not opt-out of clamping.
        if not getattr(self, "_show_requested", False) and not getattr(self, "_ui_built", False):
            self._user_sized_before_show = True
        return super().resize(*args)

    def _init_helixspec_buffer(self) -> None:
        """Seed the HelixSpec buffer from project examples if empty."""
        if self.session.state.helixspec_text:
            return
        try:
            candidate = self.project.root_path / "examples" / "helixspec" / "demo.hxspec"
            if candidate.exists():
                self.session.set_helixspec(candidate.read_text(encoding="utf-8"), path=str(candidate))
                return
        except Exception:
            pass
        # Fallback to a minimal valid HelixSpec buffer.
        self.session.set_helixspec(
            "version 1\n"
            "genome hg38\n"
            "locus DEMO = chr1:1-60(+)\n"
            "cut edit demo_cut {\n"
            '  nuclease Cas9 { pam: "NGG" }\n'
            '  guide g1 = "GGGCCAGGAGCCTGAAGTCT"\n'
            "  target t1 using g1 at DEMO\n"
            "}\n",
            path=None,
        )

    def showEvent(self, event) -> None:  # type: ignore[override]
        super().showEvent(event)
        if self._ui_built:
            return
        self._ui_built = True
        try:
            center_on_focused_window(self)
        except Exception:
            pass
        try:
            self._create_menus()
            self._install_wheel_guard()
            self._install_sidebar_overlay_guard()
            self._restore_last_helixspec_bundle_menu_state()

            # Run welcome + (when starting a new session) the goal-first setup gate
            # before we build heavyweight editor panels.
            if not self._welcome_checked:
                if not self._run_welcome_if_needed():
                    app = QApplication.instance()
                    if app is not None:
                        app.quit()
                    return
                if self._pending_welcome_action:
                    action, payload = self._pending_welcome_action
                    if action == "new":
                        self._pending_welcome_action = None
                        if not self._run_experiment_setup_gate(start_mode=payload):
                            app = QApplication.instance()
                            if app is not None:
                                app.quit()
                            return

            # --- central: GL viewport + workflow tabs ---
            self._main_tabs = self._build_center_tabs()
            if getattr(self, "_welcome_rejected", False):
                return
            try:
                self._wire_lightcone_panel_once()
            except Exception:
                pass

            # Left/right columns and central splitter
            self._build_central_splitter()
            try:
                self._on_rail_graph_changed(getattr(self.rail_store, "graph", None))
            except Exception:
                pass

            # bottom console area (log text buffered to keep UI responsive)
            self._log_flush_timer.timeout.connect(self._flush_logs)

            self._build_console_dock()
            self._init_terminal_manager()
            self._attach_viewer_hud_tab()
            self._build_sidebar_button_bar()
            self._build_compact_menu_button()
            self._install_top_corner_widgets()

            self.session.logMessage.connect(self._enqueue_log)
            self.session.statusChanged.connect(self._on_status_changed)
            self.session.errorOccurred.connect(self._show_error)
            self.session.runRecorded.connect(self._on_run_recorded)
            try:
                self.session.stateChanged.connect(self._on_session_state_changed_for_sidebar)
            except Exception:
                pass
            self._run_recorded_connected = True
            self._flush_pending_snapshots()
            try:
                self._prefill_sim_builder(self.session.to_payload())
            except Exception:
                pass

            self._restore_layout_or_defaults()
            if _is_headless_platform():
                # Offscreen/minimal platforms often report a small virtual screen. Clamp only
                # when the caller did not explicitly size the window (tests frequently do).
                if not getattr(self, "_user_sized_before_show", False):
                    try:
                        ensure_on_screen(self)
                    except Exception:
                        pass
                    # Qt may still adjust the window size after showEvent; clamp once more
                    # on the next tick so the final frame ends up contained.
                    try:
                        QTimer.singleShot(0, lambda: ensure_on_screen(self))
                    except Exception:
                        pass
            else:
                try:
                    ensure_on_screen(self)
                except Exception:
                    pass
                # In some platforms, frame decorations are applied after restoreGeometry()
                # completes; clamp once more on the next tick so the *frame* ends up fully
                # contained.
                try:
                    QTimer.singleShot(0, lambda: ensure_on_screen(self))
                except Exception:
                    pass
            # Always honor startup maximize (env-gated) even when restoring geometry.
            self._request_fullscreen()
            QTimer.singleShot(0, lambda: self._update_layout_mode(force=True))
            self._refresh_run_timeline()
            ensure_default_presets(self)
            try:
                self.history_widget.runActivated.connect(self.on_run_activated)
            except Exception:
                pass
            self._on_status_changed("Ready")
            self._update_sidebar_drawer_button()
            self._setup_shortcuts()
            self._maybe_offer_plugin_safe_mode()
            self._load_plugins_once()
            self._restore_imported_runs()

            if not self._restored_continuity_state:
                self._restored_continuity_state = True
                QTimer.singleShot(0, self._restore_continuity_state_from_settings)

            # Apply any action the user chose in the welcome dialog after UI is ready.
            if self._pending_welcome_action:
                action, payload = self._pending_welcome_action
                self._pending_welcome_action = None
                try:
                    self._run_pending_welcome_action(action, payload)
                except Exception:
                    pass

            # Ensure embedded GL windows stay above after initial layout.
            self._raise_gl_surfaces()
        except Exception as exc:
            self._ui_build_failed = True
            try:
                sys.stderr.write(f"[HelixStudio] UI build failed: {type(exc).__name__}: {exc}\n")
                traceback.print_exc()
            except Exception:
                pass
            self._show_ui_build_failure(exc)

    def _run_helixspec_buffer(self, *, inflight_id: str | None = None) -> None:
        """Compile + execute the current HelixSpec buffer using the CLI pipeline (async)."""
        text = self.session.state.helixspec_text or ""
        if not text.strip():
            self.session.error("HelixSpec buffer is empty.")
            return

        try:
            self._helixspec_editor.mark_run_started("Parsing…")
        except Exception:
            pass

    def _menu_host(self) -> QMenuBar:
        return self._menu_bar if self._menu_bar is not None else self.menuBar()

    def _install_frameless_chrome(self) -> None:
        try:
            self.setWindowFlag(Qt.FramelessWindowHint, True)
        except Exception:
            pass
        _frameless_log("install_frameless_chrome")

        height, pad_left, pad_right, gap, btn_size = _topbar_metrics(screen=self.screen())

        top = _TopBar(self)
        top.setProperty("role", "topbar")
        top.setProperty("active", "1" if self.isActiveWindow() else "0")
        top.setFixedHeight(height)
        layout = QHBoxLayout(top)
        layout.setContentsMargins(pad_left, 0, pad_right, 0)
        layout.setSpacing(gap)

        title = QLabel("Helix Studio", top)
        title.setObjectName("HelixTopBarTitle")
        title.setFixedHeight(height)
        layout.addWidget(title)

        menu_bar = QMenuBar(top)
        menu_bar.setObjectName("HelixTopMenuBar")
        menu_bar.setProperty("role", "menubar")
        menu_bar.setProperty("dragDisabled", True)
        menu_bar.setAutoFillBackground(False)
        menu_bar.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        menu_bar.setFixedHeight(height)
        layout.addWidget(menu_bar, 1, Qt.AlignVCenter)

        spacer = QWidget(top)
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        spacer.setProperty("dragDisabled", True)
        spacer.setFixedHeight(height)
        layout.addWidget(spacer, 1, Qt.AlignVCenter)

        controls = QWidget(top)
        controls.setObjectName("HelixWindowControls")
        controls.setProperty("dragDisabled", True)
        controls.setFixedHeight(height)
        ctl_layout = QHBoxLayout(controls)
        ctl_layout.setContentsMargins(0, 0, 0, 0)
        ctl_layout.setSpacing(2)

        btn_min = QToolButton(controls)
        btn_min.setObjectName("WindowBtnMin")
        btn_min.setProperty("role", "windowbtn")
        btn_min.setProperty("kind", "min")
        btn_min.setProperty("dragDisabled", True)
        icon_min = QIcon(":/icons/window_min.svg")
        if icon_min.isNull():
            icon_min = self.style().standardIcon(QStyle.SP_TitleBarMinButton)
        self._icon_window_min = icon_min
        btn_min.setIcon(icon_min)
        btn_min.clicked.connect(self.showMinimized)
        btn_min.setFixedSize(btn_size, height)

        btn_max = QToolButton(controls)
        btn_max.setObjectName("WindowBtnMax")
        btn_max.setProperty("role", "windowbtn")
        btn_max.setProperty("kind", "max")
        btn_max.setProperty("dragDisabled", True)
        icon_max = QIcon(":/icons/window_max.svg")
        if icon_max.isNull():
            icon_max = self.style().standardIcon(QStyle.SP_TitleBarMaxButton)
        icon_restore = QIcon(":/icons/window_restore.svg")
        if icon_restore.isNull():
            icon_restore = self.style().standardIcon(QStyle.SP_TitleBarNormalButton)
        self._icon_window_max = icon_max
        self._icon_window_restore = icon_restore
        btn_max.setIcon(icon_max)
        btn_max.clicked.connect(self._toggle_max_restore)
        btn_max.setFixedSize(btn_size, height)

        btn_close = QToolButton(controls)
        btn_close.setObjectName("WindowBtnClose")
        btn_close.setProperty("role", "windowbtn")
        btn_close.setProperty("kind", "close")
        btn_close.setProperty("dragDisabled", True)
        icon_close = QIcon(":/icons/window_close.svg")
        if icon_close.isNull():
            icon_close = self.style().standardIcon(QStyle.SP_TitleBarCloseButton)
        self._icon_window_close = icon_close
        btn_close.setIcon(icon_close)
        btn_close.clicked.connect(self.close)
        btn_close.setFixedSize(btn_size, height)

        ctl_layout.addWidget(btn_min)
        ctl_layout.addWidget(btn_max)
        ctl_layout.addWidget(btn_close)
        layout.addWidget(controls, 0, Qt.AlignVCenter)

        self._window_btn_max = btn_max
        self._menu_bar = menu_bar
        self._top_bar = top
        self.setMenuWidget(top)

        app = QApplication.instance()
        if app is not None:
            app.installEventFilter(self)

    def _toggle_max_restore(self) -> None:
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()
        self._update_window_controls()

    def _update_window_controls(self) -> None:
        btn = self._window_btn_max
        if btn is None:
            return
        if self.isMaximized():
            icon = self._icon_window_restore or self.style().standardIcon(QStyle.SP_TitleBarNormalButton)
        else:
            icon = self._icon_window_max or self.style().standardIcon(QStyle.SP_TitleBarMaxButton)
        btn.setIcon(icon)

    def _set_topbar_active(self, active: bool) -> None:
        bar = getattr(self, "_top_bar", None)
        if bar is None:
            return
        bar.setProperty("active", "1" if active else "0")
        try:
            style = bar.style()
            style.unpolish(bar)
            style.polish(bar)
            bar.update()
        except Exception:
            pass

    def _resize_edges_for_pos(self, pos: QPoint) -> Qt.Edges:
        if self.isMaximized() or self.isFullScreen():
            return Qt.Edges()
        try:
            dpr = float(getattr(self, "devicePixelRatioF", lambda: 1.0)())
        except Exception:
            dpr = 1.0
        margin = max(self._resize_margin_px, int(round(self._resize_margin_px * dpr)))
        rect = self.rect()
        edges = Qt.Edges()
        if pos.x() <= margin:
            edges |= Qt.LeftEdge
        if pos.x() >= rect.width() - margin:
            edges |= Qt.RightEdge
        if pos.y() <= margin:
            edges |= Qt.TopEdge
        if pos.y() >= rect.height() - margin:
            edges |= Qt.BottomEdge
        return edges

    def _update_resize_cursor(self, edges: Qt.Edges) -> None:
        if edges in (Qt.LeftEdge, Qt.RightEdge):
            self.setCursor(Qt.SizeHorCursor)
        elif edges in (Qt.TopEdge, Qt.BottomEdge):
            self.setCursor(Qt.SizeVerCursor)
        elif edges in (Qt.TopEdge | Qt.LeftEdge, Qt.BottomEdge | Qt.RightEdge):
            self.setCursor(Qt.SizeFDiagCursor)
        elif edges in (Qt.TopEdge | Qt.RightEdge, Qt.BottomEdge | Qt.LeftEdge):
            self.setCursor(Qt.SizeBDiagCursor)
        else:
            self.unsetCursor()

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:  # type: ignore[override]
        # This window installs itself as an application-level event filter when using frameless chrome.
        # Under PySide, the Python wrapper can be recreated without running __init__ (e.g., if the C++
        # object outlives all Python references), so avoid relying on Python-only attributes.
        #
        # Also: avoid calling the Qt base implementation here. In some environments it can re-enter the
        # override (virtual dispatch), producing recursion inside the Qt event loop.
        if getattr(self, "_native_chrome", True):
            return False
        if not isinstance(obj, QWidget):
            return False
        try:
            if obj.window() is not self:
                return False
        except Exception:
            return False
        if _frameless_resize_disabled():
            return False
        if event.type() == QEvent.MouseMove:
            global_pos = _global_pos_from_event(event)
            if global_pos is None:
                return False
            pos = self.mapFromGlobal(global_pos)
            edges = self._resize_edges_for_pos(pos)
            if not self._resize_active:
                self._update_resize_cursor(edges)
                if edges:
                    _frameless_log(f"Resize hover edges={_edges_value(edges)} pos={pos.x()},{pos.y()}")
        elif event.type() == QEvent.MouseButtonPress:
            try:
                button = event.button()
            except Exception:
                button = None
            if button == Qt.LeftButton:
                global_pos = _global_pos_from_event(event)
                if global_pos is None:
                    return False
                pos = self.mapFromGlobal(global_pos)
                edges = self._resize_edges_for_pos(pos)
                _frameless_log(
                    f"MousePress obj={type(obj).__name__} name={obj.objectName()!r} "
                    f"pos={pos.x()},{pos.y()} edges={_edges_value(edges)}"
                )
                if edges:
                    wh = self.windowHandle()
                    if wh is not None:
                        self._resize_active = True
                        _frameless_log(
                            f"startSystemResize edges={_edges_value(edges)} pos={pos.x()},{pos.y()}"
                        )
                        wh.startSystemResize(edges)
                        return True
        elif event.type() == QEvent.MouseButtonRelease:
            if self._resize_active:
                self._resize_active = False
                self._update_resize_cursor(Qt.Edges())
                _frameless_log("resize release")
        return False
        # Disable run button while busy.
        try:
            self._helixspec_editor.set_run_enabled(False)
        except Exception:
            pass

        inflight = inflight_id or _random_token()
        self._recompute_inflight_id = inflight
        self.rail_store.begin_compute("outcome_model", inflight)
        self._set_rail_state("evidence", CacheState.DIRTY)

        # Prepare output paths and params.
        stamp = clock.local_now_stamp()
        base_dir = self.project.root_path / "out" / "helixspec_runs"
        base_dir.mkdir(parents=True, exist_ok=True)
        run_dir = temp.mkdtemp(prefix=f"run_{stamp}_", dir=base_dir)
        spec_path = run_dir / "session.hxspec"
        deterministic = bool(self.session.state.config.get("helixspec_deterministic", True))
        policy = self.session.state.config.get("helixspec_policy")
        if not isinstance(policy, dict) or not policy:
            policy = None
        expected_plan_hash = stable_hash(getattr(self.session.state, "edit_plan", None))

        self.session.set_status(f"Running HelixSpec → {run_dir}")

        def _work() -> Path:
            from helixspec.run import run_spec  # lazy import to avoid startup cost

            spec_path.write_text(text, encoding="utf-8")
            run_spec(spec_path, run_dir, deterministic=deterministic, policy=policy)
            return run_dir

        watcher = self._helixspec_run_watcher or QFutureWatcher(self)
        self._helixspec_run_watcher = watcher

        def _on_finished() -> None:
            try:
                run_dir_result = watcher.result()
                self.session.set_status(f"HelixSpec run complete: {run_dir_result}")
                # If the buffer had no path, point it at the generated spec for convenience.
                if not self.session.state.helixspec_path:
                    self.session.set_helixspec(text, path=str(spec_path))
                self._last_helixspec_run_dir = Path(run_dir_result)
                try:
                    self.session.state.config["helixspec_last_bundle"] = str(run_dir_result)
                except Exception:
                    pass
                try:
                    self.actionOpenHelixSpecBundle.setEnabled(True)
                except Exception:
                    pass
                try:
                    self._helixspec_editor.set_last_bundle(run_dir_result)
                except Exception:
                    pass
                try:
                    self._helixspec_editor.record_run_success(text, run_dir_result)
                except Exception:
                    pass
                def _apply_outcome() -> str:
                    # Apply artifacts to session via existing ingest helper.
                    self._ingest_helixspec_bundle(Path(run_dir_result))
                    return self._segment_hash("outcome_model") or ""

                current_plan_hash = stable_hash(getattr(self.session.state, "edit_plan", None))
                commit_with_guards(
                    self.rail_store,
                    "outcome_model",
                    inflight_id=inflight,
                    chain_id=self._recompute_chain_id,
                    expected_upstream_hash=expected_plan_hash,
                    current_upstream_hash=current_plan_hash,
                    apply_fn=_apply_outcome,
                )
                self._set_rail_state("evidence", CacheState.DIRTY)
                self._recompute_inflight_id = None
            except Exception as exc:
                try:
                    self.session.error(f"HelixSpec run failed: {exc}")
                except Exception:
                    pass
                try:
                    self._helixspec_editor.record_run_failure(str(exc))
                except Exception:
                    pass
                try:
                    self.rail_store.fail_compute("outcome_model", inflight)
                except Exception:
                    pass
                self._recompute_inflight_id = None
            finally:
                try:
                    self._helixspec_editor.set_run_enabled(bool(self.session.state.helixspec_text.strip()))
                except Exception:
                    pass
                watcher.deleteLater()
                self._helixspec_run_watcher = None

        future = qt_run(_work)
        watcher.finished.connect(_on_finished)
        watcher.setFuture(future)

    def _ingest_helixspec_bundle(self, run_dir: Path) -> None:
        """Load results from a helixspec run bundle into history/panels."""
        try:
            results_path = run_dir / "results.json"
            receipts_path = run_dir / "receipts.json"
            manifest_path = run_dir / "manifest.json"
            if not results_path.exists():
                raise FileNotFoundError(f"No results.json found in bundle {run_dir}")
            results = json.loads(results_path.read_text(encoding="utf-8"))
            receipts: dict = {}
            if receipts_path.exists():
                try:
                    receipts = json.loads(receipts_path.read_text(encoding="utf-8"))
                except Exception:
                    self.session.log(f"Warning: could not parse receipts.json in {run_dir}; proceeding without receipts.")
            else:
                self.session.log(f"Warning: receipts.json missing in {run_dir}; proceeding without receipts.")
            state = results.get("snapshot") or {}
            if not isinstance(state, dict):
                raise ValueError("results.json missing snapshot payload")
            results = json.loads(results_path.read_text(encoding="utf-8"))
            receipts = json.loads(receipts_path.read_text(encoding="utf-8")) if receipts_path.exists() else {}
            state = results.get("snapshot") or {}
            if not isinstance(state, dict):
                raise ValueError("results.json missing snapshot")
            state = dict(state)
            state.setdefault("run_kind", receipts.get("run_kind") or "CRISPR")
            state.setdefault("run_id", receipts.get("run_id") or run_dir.name)
            meta = state.setdefault("config", {}).setdefault("metadata", {})
            meta.setdefault("helixspec_bundle", str(run_dir))
            meta.setdefault("helixspec_manifest", str(manifest_path))
            meta.setdefault("helixspec_results", str(results_path))
            meta.setdefault("helixspec_receipts", str(receipts_path))
            snapshot = {
                "version": 1,
                "state": state,
                "timestamp": receipts.get("timestamp"),
            }
            self.session.runRecorded.emit(snapshot)
            self._open_snapshot_in_explorer(snapshot)
        except Exception as exc:
            self.session.error(f"Failed to ingest HelixSpec run: {exc}")

    def _show_ui_build_failure(self, exc: Exception) -> None:
        central = self.centralWidget()
        if central is not None:
            try:
                self.statusBar().showMessage(f"UI build failed: {type(exc).__name__}: {exc}", 12000)
            except Exception:
                pass
            return
        msg = QLabel(
            "Helix Studio failed to build its UI.\n\n"
            f"Reason: {type(exc).__name__}: {exc}\n\n"
            "Next:\n"
            "- Relaunch with --reset-layout to clear saved state.\n"
            "- Check stderr for the full traceback.\n"
            "- If this persists, share the traceback.",
            self,
        )
        try:
            msg.setWordWrap(True)
        except Exception:
            pass
        msg.setAlignment(Qt.AlignCenter)
        self.setCentralWidget(msg)

    def _build_center_tabs(self) -> QTabWidget:
        tab = QTabWidget()
        try:
            tab.setMinimumWidth(0)
            tab.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            tab.setObjectName("MainTabs")
            tab.setDocumentMode(True)
            tab.setUsesScrollButtons(True)
            bar = tab.tabBar()
            # Avoid "giant tab" syndrome on wide windows; tabs should be content-sized.
            bar.setExpanding(False)
            bar.setElideMode(Qt.ElideRight)
            bar.setMovable(True)
            try:
                bar.tabMoved.connect(lambda _from, _to: self._rebuild_center_tab_index_map())
            except Exception:
                pass
            try:
                bar.setContextMenuPolicy(Qt.CustomContextMenu)
                bar.customContextMenuRequested.connect(self._on_center_tab_context_menu)
            except Exception:
                pass
        except Exception:
            pass
        self._center_tab_index_by_key = {}

        def _add(widget: QWidget, label: str, key: str) -> int:
            # Hard guard: tab pages should never impose a large minimum width
            # (Qt will otherwise propagate minimumSizeHint through QTabWidget,
            # which can make the center feel "fixed width" on resize).
            try:
                widget.setMinimumWidth(0)
                widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            except Exception:
                pass
            if isinstance(widget, QLabel):
                try:
                    widget.setWordWrap(True)
                    widget.setMinimumWidth(0)
                except Exception:
                    pass
            idx = tab.addTab(widget, label)
            self._center_tab_index_by_key[key] = idx
            try:
                tab.tabBar().setTabData(idx, key)
            except Exception:
                pass
            return idx

        # Primary analysis surface (Outcome Explorer + hero).
        self._helixspec_editor = HelixSpecEditor(self.session, project_root=self.project.root_path, parent=self)
        try:
            self._helixspec_editor.runRequested.connect(self._run_helixspec_buffer)
            self._helixspec_editor.openBundleRequested.connect(self._open_last_helixspec_bundle)
        except Exception:
            pass
        _add(self._helixspec_editor, "HelixSpec", "helixspec")

        self._center_panel = CenterPanel(self.ctx, self)
        try:
            self._center_panel.bind_session(self.session)
        except Exception:
            pass
        try:
            self._center_panel.setMinimumWidth(0)
        except Exception:
            pass
        try:
            self._center_panel.set_compare_handler(self._on_focus_compare_requested)
        except Exception:
            pass
        _add(self._center_panel, "Analysis", "analysis")

        if self._enable_gl:
            gl_error: Exception | None = None
            try:
                self.gl_view = GLViewport(self.session)
            except Exception as exc:
                gl_error = exc
                self.gl_view = None
            if self.gl_view is not None:
                try:
                    act = getattr(self, "_viewer_perf_hud_action", None)
                    if act is not None:
                        self.gl_view.set_perf_hud_enabled(bool(act.isChecked()))
                except Exception:
                    pass
                _add(self.gl_view, "Realtime (3D)", "realtime_3d")
                self.workflow_panel = Workflow2p5DPanel(self.session, enable_viewer=True)
            else:
                self._enable_gl = False
                try:
                    act = getattr(self, "_viewer_perf_hud_action", None)
                    if act is not None:
                        act.setEnabled(False)
                except Exception:
                    pass
                reason = str(gl_error) if gl_error else "Unknown error"
                placeholder = QLabel(
                    "GL viewport unavailable.\n\n"
                    f"Reason: {reason}\n\n"
                    "Next:\n"
                    "- Install the realtime/GL extras (moderngl + Qt OpenGL).\n"
                    "- Ensure a working OpenGL stack.\n"
                    "- Or launch with --no-gl to suppress this panel.",
                    self,
                )
                try:
                    placeholder.setWordWrap(True)
                except Exception:
                    pass
                placeholder.setAlignment(Qt.AlignCenter)
                _add(placeholder, "Realtime (3D)", "realtime_3d")
                self.workflow_panel = Workflow2p5DPanel(self.session, enable_viewer=False)
        else:
            self.gl_view = None
            placeholder = QLabel(
                "GL viewport disabled (HELIX_STUDIO_NO_GL=1 or --no-gl)."
                "\nRun on a GPU-capable display or re-enable GL for full visuals.",
                self,
            )
            try:
                placeholder.setWordWrap(True)
            except Exception:
                pass
            placeholder.setAlignment(Qt.AlignCenter)
            _add(placeholder, "Realtime (3D)", "realtime_3d")
            self.workflow_panel = Workflow2p5DPanel(self.session, enable_viewer=False)
        _add(self.workflow_panel, "2.5D Workflow", "workflow_2p5d")

        self.dag_panel = EditDAGPanel(self.session, self)
        _add(self.dag_panel, "Edit DAG", "edit_dag")
        tab.currentChanged.connect(self._raise_gl_surfaces)
        tab.currentChanged.connect(self._on_center_tab_changed)

        # Keep the index map in sync once all initial tabs are present.
        self._rebuild_center_tab_index_map()
        self._active_center_tab_key = self._current_center_tab_key()
        self._update_render_activation(self._active_center_tab_key)

        # Compare tab placeholder (created on demand)
        self.guide_compare_widget = GuideCompareWidget(lambda: OutcomeExplorerWidget(self))
        self._guide_compare_tab_index: int | None = None
        # Instrument runs tab
        self.instrument_runs_widget = InstrumentRunsWidget(self._instrument_runs_api, self, on_view_analysis=self.open_outcome_for_analysis)
        _add(self.instrument_runs_widget, "Instrument Runs", "instrument_runs")

        # Lightcone (Milestone 3C): GPU-interactive outcome “lightcone” viewer.
        self.lightcone_panel = None
        lightcone_import_error: Exception | None = None
        try:
            from helix.studio.lightcone_panel import LightconePanelWidget

            self.lightcone_panel = LightconePanelWidget(self)
        except Exception as exc:
            lightcone_import_error = exc
            self.lightcone_panel = None
        if self.lightcone_panel is not None:
            _add(self.lightcone_panel, "Lightcone", "lightcone")
        else:
            placeholder = QLabel(
                "Lightcone\n\n"
                "This panel is unavailable in the current environment.\n\n"
                f"Reason: {lightcone_import_error}\n\n"
                "Next:\n"
                "- Ensure the Studio GUI stack is installed (PySide6).\n"
                "- For GPU interactivity, ensure a working OpenGL stack.\n"
                "- See docs/runbooks/lightcone_runbook.md for setup and validation.",
                self,
            )
            try:
                placeholder.setWordWrap(True)
            except Exception:
                pass
            placeholder.setAlignment(Qt.AlignCenter)
            _add(placeholder, "Lightcone", "lightcone")

        if not self._welcome_checked:
            if not self._run_welcome_if_needed():
                app = QApplication.instance()
                if app is not None:
                    app.quit()
                return None

        if self._enable_gl and self.gl_view is not None:
            self.workflow_panel.outcomeSelected.connect(self.outcomeSelectedOnRail.emit)
            self.outcomeSelectedOnRail.connect(self.gl_view.highlight_outcome)
            # Toasts
            try:
                self.workflow_panel._explorer.outcomeSelected.connect(self._on_outcome_selected_toast)
                self.workflow_panel._explorer.designPcrRequested.connect(self._on_design_pcr_requested)
            except Exception:
                pass
        return tab

    def _build_central_splitter(self) -> None:
        try:
            self.sim_panel = create_simbuilder_widget(self.session, enable_gl_viewer=False)
        except Exception as exc:
            self.sim_panel = QLabel(
                "Sim Builder failed to load.\n\n"
                f"Reason: {exc}\n\n"
                "Next:\n"
                "- Check the console for import errors.\n"
                "- Verify optional dependencies are installed.",
                self,
            )
            try:
                self.sim_panel.setWordWrap(True)
            except Exception:
                pass
            self.sim_panel.setAlignment(Qt.AlignCenter)
        self._wire_ingest_signals()
        self._wire_fm_signals()
        try:
            self.sim_panel.setMinimumWidth(0)
            # Avoid hard caps so the UI can scale on large screens / high DPI.
            self.sim_panel.setMaximumWidth(16777215)
            self.sim_panel.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        except Exception:
            pass
        self.history_widget = _make_history_widget(self.session, self._on_compare_runs)
        try:
            self.history_widget.runActivated.connect(self.on_run_activated)
            self.history_widget.baselineSelected.connect(self._on_baseline_selected)
            self.history_widget.candidateSelected.connect(self._on_candidate_selected)
        except Exception:
            pass

        self.guide_inspector = GuideInspectorWidget(self)
        try:
            self.guide_inspector.guideSelected.connect(self._on_guide_selected)
            self.guide_inspector.exportAllRequested.connect(self._on_export_all_guides)
            self.guide_inspector.compareGuidesRequested.connect(self._on_compare_guides)
        except Exception:
            pass

        self.run_compare_widget = RunCompareWidget(self)

        self._splitter = QSplitter(Qt.Horizontal, self)
        self._splitter.setObjectName("centralWidget")
        self._left_column = self._build_left_column()
        self._activity_sidebar = self._build_activity_sidebar(self._left_column)
        self._right_column = self._build_right_column()
        # Allow columns to shrink on narrow screens.
        self._activity_sidebar.setMinimumWidth(0)
        self._activity_sidebar.setMaximumWidth(16777215)
        self._right_column.setMinimumWidth(0)
        self._right_column.setMaximumWidth(16777215)
        try:
            # Let QSplitter shrink the right column below its minimumSizeHint width.
            self._right_column.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Expanding)
        except Exception:
            pass

        self._center_container = _SplitterShrinkContainer(self)
        try:
            self._center_container.setMinimumWidth(0)
            # Extra guardrail: ensure the splitter can shrink the center even if future
            # widgets inflate size hints.
            self._center_container.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Expanding)
        except Exception:
            pass
        center_layout = QVBoxLayout(self._center_container)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(0)
        self._visuals_banner = HintBanner("", self._center_container)
        self._visuals_banner.hide()
        try:
            self._visuals_banner.closed.connect(self._on_visuals_banner_closed)
        except Exception:
            pass
        center_layout.addWidget(self._visuals_banner)
        try:
            self._run_status_panel = RunStatusPanel(
                self.session,
                self.rail_store,
                self._center_container,
                project_root=getattr(self.project, "root_path", None),
            )
            center_layout.addWidget(self._run_status_panel)
        except Exception:
            self._run_status_panel = None
        center_layout.addWidget(self._main_tabs, stretch=1)

        self._splitter.addWidget(self._activity_sidebar)
        self._splitter.addWidget(self._center_container)
        self._splitter.addWidget(self._right_column)
        # center-first stretch factors; side panes collapse when needed
        self._splitter.setStretchFactor(0, 2)
        # Keep the center dominant, but don't starve side panels on desktop widths.
        self._splitter.setStretchFactor(1, 6)
        self._splitter.setStretchFactor(2, 2)
        self._splitter.setCollapsible(0, True)
        self._splitter.setCollapsible(2, True)
        try:
            self._splitter.splitterMoved.connect(self._on_splitter_moved)
        except Exception:
            pass
        try:
            # Wrap any labels inside the sidebar overlay so text stays readable in narrow drawers.
            enable_word_wrap(self._right_column)
            enable_word_wrap(self._activity_sidebar)
        except Exception:
            pass
        # Remember last sidebar and right widths for toggle/restore
        self._sidebar_last_size = SIDEBAR_DEFAULT_PX
        self._right_last_size = SIDEBAR_DEFAULT_PX
        self.setCentralWidget(self._splitter)
        self._maybe_show_visuals_unavailable_banner()

    def _wire_ingest_signals(self) -> None:
        panel = getattr(self, "sim_panel", None)
        if panel is None:
            return
        try:
            panel.ingestStarted.connect(self._on_ingest_started)
            panel.ingestProgress.connect(self._on_ingest_progress)
            panel.ingestFinished.connect(self._on_ingest_finished)
            panel.ingestCancelled.connect(self._on_ingest_cancelled)
            panel.ingestError.connect(self._on_ingest_error)
        except Exception:
            pass

    def _wire_fm_signals(self) -> None:
        panel = getattr(self, "sim_panel", None)
        if panel is None:
            return
        try:
            panel.fmBuildStarted.connect(self._on_fm_build_started)
            panel.fmBuildProgress.connect(self._on_fm_build_progress)
            panel.fmBuildFinished.connect(self._on_fm_build_finished)
            panel.fmBuildCancelled.connect(self._on_fm_build_cancelled)
            panel.fmBuildError.connect(self._on_fm_build_error)
        except Exception:
            pass

    def _on_fm_build_started(self, gid: str) -> None:
        self._current_cancel = "fm"
        self._ingest_cancel_btn.setText("Cancel index")
        self._ingest_status.setText(f"Building FM index: {gid}…")
        self._cancel_target_label.setText("Job: FM build")
        self._ingest_cancel_btn.show()

    def _on_fm_build_progress(self, gid: str, pct: int) -> None:
        self._ingest_status.setText(f"Building FM index: {gid} · {pct}%")
        self._ingest_cancel_btn.show()
        self._cancel_target_label.setText("Job: FM build")

    def _on_fm_build_finished(self, gid: str, path: str) -> None:
        self._ingest_status.setText(f"FM index ready: {gid}")
        self._ingest_cancel_btn.hide()
        self._current_cancel = None
        self._cancel_target_label.clear()
        QTimer.singleShot(3000, lambda: self._ingest_status.setText(""))

    def _on_fm_build_cancelled(self, gid: str) -> None:
        self._ingest_status.setText(f"FM index cancelled: {gid}")
        self._ingest_cancel_btn.hide()
        self._current_cancel = None
        self._cancel_target_label.clear()
        QTimer.singleShot(2000, lambda: self._ingest_status.setText(""))

    def _on_fm_build_error(self, gid: str, msg: str) -> None:
        self._ingest_status.setText(f"FM index failed: {gid} ({msg})")
        self._ingest_cancel_btn.hide()
        self._current_cancel = None
        self._cancel_target_label.clear()

    def _on_ingest_started(self, name: str) -> None:
        self._ingest_status.setText(f"Ingesting {name}…")
        self._current_cancel = "ingest"
        self._ingest_cancel_btn.setText("Cancel ingest")
        self._cancel_target_label.setText("Job: ingest")
        self._ingest_cancel_btn.show()
        self._set_rail_state("genome", CacheState.COMPUTING)

    def _on_ingest_progress(self, name: str, pct: int) -> None:
        self._ingest_status.setText(f"Ingesting {name} · {pct}%")
        self._ingest_cancel_btn.show()
        self._cancel_target_label.setText("Job: ingest")

    def _on_ingest_finished(self, ingest) -> None:
        try:
            label = getattr(ingest, "source_fasta", None)
            name = label.name if label else "genome"
        except Exception:
            name = "genome"
        self._ingest_status.setText(f"Genome ready: {name}")
        self._ingest_cancel_btn.hide()
        self._current_cancel = None
        self._cancel_target_label.clear()
        QTimer.singleShot(3000, lambda: self._ingest_status.setText(""))
        self._set_rail_state("genome", CacheState.CLEAN)

    def _on_ingest_cancelled(self, name: str) -> None:
        self._ingest_status.setText(f"Ingest cancelled: {name}")
        self._ingest_cancel_btn.hide()
        self._current_cancel = None
        self._cancel_target_label.clear()
        QTimer.singleShot(2000, lambda: self._ingest_status.setText(""))
        self._set_rail_state("genome", CacheState.DIRTY)

    def _on_ingest_error(self, message: str) -> None:
        self._ingest_status.setText(f"Ingest failed: {message}")
        self._ingest_cancel_btn.hide()
        self._current_cancel = None
        self._cancel_target_label.clear()
        self._set_rail_state("genome", CacheState.DIRTY)

    def _on_ingest_cancel_clicked(self) -> None:
        panel = getattr(self, "sim_panel", None)
        if self._current_cancel == "fm":
            if panel is not None and hasattr(panel, "_cancel_fm_build"):
                try:
                    panel._cancel_fm_build()
                except Exception:
                    pass
            self._ingest_status.setText("Cancelling index build…")
        else:
            if panel is not None and hasattr(panel, "cancel_ingest"):
                try:
                    panel.cancel_ingest()
                except Exception:
                    pass
            self._ingest_status.setText("Cancelling ingest…")

    def _set_rail_state(self, segment_id: str, state: CacheState) -> None:
        store = getattr(self, "rail_store", None)
        if store is None:
            return
        try:
            store.mark_segment_state(segment_id, state)
        except Exception:
            pass

    def _build_activity_sidebar(self, left_column: QWidget) -> QWidget:
        """
        Wrap the existing left column in a VS Code–style sidebar:
            [ activity bar ][ stacked sidebar pages ]
        Currently only the Sim Builder page exists, but more can be added.
        """
        container = QWidget(self)
        container.setObjectName("ActivitySidebar")
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Activity bar (thin vertical strip of buttons)
        bar = QWidget(container)
        bar.setObjectName("ActivityBar")
        bar_layout = QVBoxLayout(bar)
        bar_layout.setContentsMargins(4, 4, 4, 4)
        bar_layout.setSpacing(4)
        self._activity_bar = bar

        self._activity_buttons: dict[str, QToolButton] = {}

        def make_button(key: str, text: str, tooltip: str) -> QToolButton:
            btn = QToolButton(bar)
            btn.setText(text)
            btn.setToolTip(tooltip)
            btn.setCheckable(True)
            btn.setAutoExclusive(True)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            try:
                btn.setProperty("full_text", text)
                btn.setProperty("rail_text", "Build" if key == "sim_builder" else text)
            except Exception:
                pass
            # VS Code style: clicking toggles sidebar open/closed and activates page
            btn.clicked.connect(lambda checked, k=key: self._on_activity_button_clicked(k, checked))
            self._activity_buttons[key] = btn
            bar_layout.addWidget(btn)
            return btn

        make_button("sim_builder", "Builder", "Sim Builder")
        bar_layout.addStretch(1)

        # Keep the rail visible even with a single page; compact mode uses it as a
        # stable collapse handle and additional pages can be added later.
        bar_width = self._scaled_px(36)
        bar.setMinimumWidth(bar_width)
        bar.setMaximumWidth(bar_width)

        # Sidebar stack: full-height panels next to the activity bar
        stack = QStackedWidget(container)
        stack.setObjectName("SidebarStack")
        stack.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        stack.setMinimumWidth(self._min_sidebar_width_px())
        self._sidebar_stack = stack
        self._sidebar_pages: dict[str, int] = {}

        index = self._sidebar_stack.addWidget(left_column)
        self._sidebar_pages["sim_builder"] = index

        layout.addWidget(bar)
        layout.addWidget(self._sidebar_stack)

        # Default selection
        self._set_active_sidebar("sim_builder")
        try:
            self._install_left_rail_hover_guard(container)
        except Exception:
            pass

        return container

    # --- Rail spine -> UI scoping -----------------------------------------

    def _on_rail_graph_changed(self, graph) -> None:
        """Seed default selection when a graph arrives."""
        try:
            pending = getattr(self, "_pending_initial_rail_segment_id", None)
            if pending and graph is not None:
                seg = None
                try:
                    seg = graph.get(pending)
                except Exception:
                    seg = None
                if seg is not None:
                    self._pending_initial_rail_segment_id = None
                    self.rail_store.set_selection(RailSelection(branch_id="trunk", segment_id=pending))
                    return

            if self.rail_store.selection is None and graph is not None:
                first = graph.order[0] if getattr(graph, "order", None) else None
                if first:
                    self.rail_store.set_selection(RailSelection(branch_id="trunk", segment_id=first))
        except Exception:
            pass

    def _on_rail_selection_changed(self, selection: RailSelection | None) -> None:
        if selection is None:
            return
        graph = getattr(self.rail_store, "graph", None)
        seg = graph.get(selection.segment_id) if graph else None  # type: ignore[union-attr]
        kind = seg.kind if seg is not None else StageKind.UNKNOWN
        self._scope_center_to_stage(kind)
        self._scope_right_sidebar_to_stage(kind)
        if kind in (StageKind.GENOME_CONTEXT, StageKind.EDIT_PLAN, StageKind.PERTURBATIONS):
            try:
                self._set_active_sidebar("sim_builder")
                self._set_left_visible(True)
            except Exception:
                pass

    def _scope_right_sidebar_to_stage(self, kind: StageKind) -> None:
        target = "Session"
        if kind == StageKind.PERTURBATIONS:
            target = "Guides"
        elif kind in (StageKind.OUTCOME_MODEL, StageKind.EVIDENCE, StageKind.CLAIMS):
            target = "Compare"
        self._select_right_tab_by_text(target)

    def _scope_center_to_stage(self, kind: StageKind) -> None:
        key = "analysis" if kind in (StageKind.OUTCOME_MODEL, StageKind.EVIDENCE, StageKind.CLAIMS) else "helixspec"
        self._set_center_tab(key)

    def _select_right_tab_by_text(self, label: str) -> None:
        tabs = getattr(self, "_right_tabs", None)
        if tabs is None:
            return
        for i in range(tabs.count()):
            if tabs.tabText(i).lower() == label.lower():
                tabs.setCurrentIndex(i)
                return

    def _rebuild_center_tab_index_map(self) -> None:
        """Recompute tab-key → index mapping after user reorders tabs."""
        tabs = getattr(self, "_main_tabs", None)
        if tabs is None:
            return
        mapping: dict[str, int] = {}
        bar = None
        try:
            bar = tabs.tabBar()
        except Exception:
            bar = None
        for idx in range(tabs.count()):
            key = None
            if bar is not None:
                try:
                    data = bar.tabData(idx)
                    if isinstance(data, str) and data:
                        key = data
                except Exception:
                    key = None
            if key:
                mapping[key] = idx
        # Fall back to existing mapping if something was missing.
        if mapping:
            self._center_tab_index_by_key = mapping

    def _tab_key_for_index(self, tabs: QTabWidget, bar, idx: int) -> str | None:
        key = None
        if bar is not None:
            try:
                data = bar.tabData(idx)
                if isinstance(data, str) and data:
                    key = data
            except Exception:
                key = None
        if key:
            return key
        for candidate, tab_idx in self._center_tab_index_by_key.items():
            if tab_idx == idx:
                return candidate
        return None

    def _capture_center_tab_layout(self) -> CenterTabLayout:
        tabs = getattr(self, "_main_tabs", None)
        if tabs is None:
            return CenterTabLayout()
        try:
            bar = tabs.tabBar()
        except Exception:
            bar = None
        order: list[str] = []
        hidden: set[str] = set()
        for idx in range(tabs.count()):
            key = self._tab_key_for_index(tabs, bar, idx)
            if not key:
                continue
            order.append(key)
            if not self._is_center_tab_visible(idx):
                hidden.add(key)
        return CenterTabLayout(order=order, hidden=hidden, active=self._current_center_tab_key())

    def _is_center_tab_visible(self, idx: int) -> bool:
        tabs = getattr(self, "_main_tabs", None)
        if tabs is None or idx < 0 or idx >= tabs.count():
            return False
        try:
            return bool(tabs.isTabVisible(idx))
        except Exception:
            # Older Qt versions: assume visible to avoid hiding everything.
            return True

    def _visible_center_tab_count(self) -> int:
        tabs = getattr(self, "_main_tabs", None)
        if tabs is None:
            return 0
        return sum(1 for i in range(tabs.count()) if self._is_center_tab_visible(i))

    def _apply_center_tab_layout(self, layout: CenterTabLayout) -> None:
        tabs = getattr(self, "_main_tabs", None)
        if tabs is None or layout is None:
            return
        try:
            bar = tabs.tabBar()
        except Exception:
            bar = None

        desired_order = [key for key in getattr(layout, "order", []) if isinstance(key, str) and key]
        hidden = {key for key in getattr(layout, "hidden", set()) if isinstance(key, str) and key}

        guard = getattr(self, "_suspend_center_tab_persistence", False)
        self._suspend_center_tab_persistence = True
        try:
            # Reorder tabs to the desired sequence; keys missing in stored order retain their relative position.
            if bar is not None and desired_order:
                current_order = [self._tab_key_for_index(tabs, bar, i) for i in range(tabs.count())]
                current_order = [key for key in current_order if key]
                for target_idx, key in enumerate(desired_order):
                    if key not in current_order:
                        continue
                    src_idx = current_order.index(key)
                    if src_idx == target_idx:
                        continue
                    try:
                        bar.moveTab(src_idx, target_idx)
                    except Exception:
                        break
                    moved = current_order.pop(src_idx)
                    current_order.insert(target_idx, moved)
            self._rebuild_center_tab_index_map()

            # Apply visibility preferences.
            for idx in range(tabs.count()):
                key = self._tab_key_for_index(tabs, bar, idx)
                if not key:
                    continue
                try:
                    tabs.setTabVisible(idx, key not in hidden)
                except Exception:
                    continue

            # Ensure at least one tab stays visible.
            if self._visible_center_tab_count() == 0 and tabs.count() > 0:
                try:
                    tabs.setTabVisible(0, True)
                except Exception:
                    pass

            # Avoid a hidden current tab by selecting the first visible one.
            current_idx = tabs.currentIndex()
            if not self._is_center_tab_visible(current_idx):
                for idx in range(tabs.count()):
                    if self._is_center_tab_visible(idx):
                        try:
                            tabs.setCurrentIndex(idx)
                        except Exception:
                            pass
                        break

            # Honor the stored active tab if it is still present and visible.
            target_key = layout.active if isinstance(layout.active, str) and layout.active else None
            if target_key and target_key in self._center_tab_index_by_key:
                idx = self._center_tab_index_by_key[target_key]
                if self._is_center_tab_visible(idx):
                    try:
                        tabs.setCurrentIndex(idx)
                        self._active_center_tab_key = target_key
                    except Exception:
                        pass

            self._closed_center_tabs = set(hidden)
            self._rebuild_center_tab_index_map()
            self._active_center_tab_key = self._current_center_tab_key()
        finally:
            self._suspend_center_tab_persistence = guard

        self._update_render_activation(self._active_center_tab_key)

    def _close_center_tab(self, idx: int) -> None:
        tabs = getattr(self, "_main_tabs", None)
        if tabs is None or idx < 0 or idx >= tabs.count():
            return
        if self._visible_center_tab_count() <= 1:
            return
        key = None
        bar = None
        try:
            bar = tabs.tabBar()
        except Exception:
            bar = None
        if bar is not None:
            try:
                data = bar.tabData(idx)
                if isinstance(data, str) and data:
                    key = data
            except Exception:
                key = None
        try:
            tabs.setTabVisible(idx, False)
        except Exception:
            return
        if key:
            self._closed_center_tabs.add(str(key))
        if tabs.currentIndex() == idx:
            for i in range(tabs.count()):
                if self._is_center_tab_visible(i):
                    try:
                        tabs.setCurrentIndex(i)
                    except Exception:
                        pass
                    break
        self._rebuild_center_tab_index_map()

    def _on_center_tab_context_menu(self, pos: QPoint) -> None:
        tabs = getattr(self, "_main_tabs", None)
        if tabs is None:
            return
        try:
            bar = tabs.tabBar()
        except Exception:
            return
        idx = bar.tabAt(pos)
        if idx < 0:
            return
        label = bar.tabText(idx)
        menu = QMenu(self)
        act_close = QAction(f"Close '{label}' tab", self)
        act_close.setEnabled(self._visible_center_tab_count() > 1)
        act_close.triggered.connect(lambda _checked=False, i=idx: self._close_center_tab(i))
        menu.addAction(act_close)
        try:
            menu.exec_(bar.mapToGlobal(pos))
        except Exception:
            pass

    def _set_center_tab(self, key: str) -> None:
        # Tab order is user-adjustable; refresh mapping before selecting.
        self._rebuild_center_tab_index_map()
        tab = getattr(self, "_main_tabs", None)
        mapping = getattr(self, "_center_tab_index_by_key", {})
        if tab is None or not mapping:
            return
        idx = mapping.get(key)
        if idx is None:
            return
        try:
            tab.setCurrentIndex(idx)
        except Exception:
            pass

    # --- Rail recompute + cache-hit wiring ---------------------------

    def _on_recompute_requested(self, segment_id: str) -> None:
        """Respond to rail double-clicks by kicking off a recompute pipeline."""
        self._recompute_chain_id = _random_token()
        plan = self._recompute_plan()
        handler = plan.get(segment_id)
        if handler is None:
            try:
                self.session.set_status(f"Recompute for {segment_id} not wired yet.")
            except Exception:
                pass
            return
        handler()

    def _on_recompute_downstream_requested(self, segment_id: str) -> None:
        graph = getattr(self.rail_store, "graph", None)
        planner = RecomputePlanner(graph)
        plan = planner.plan(segment_id)
        self._invalidate_segments(plan.invalidate)
        chain = plan.stages
        self._recompute_chain_id = _random_token()
        # Reset chain to avoid stale downstream work.
        self._recompute_chain = [sid for sid in chain if sid in self._recompute_plan()]
        self._recompute_chain_start = list(self._recompute_chain)
        self._run_next_recompute_in_chain()

    def _recompute_plan(self) -> dict[str, Callable[[], None]]:
        return {
            "outcome_model": self._recompute_outcome_model,
            "evidence": self._recompute_evidence,
            "claims": self._recompute_claims,
        }

    def _run_next_recompute_in_chain(self) -> None:
        if not self._recompute_chain:
            return
        sid = self._recompute_chain.pop(0)
        handler = self._recompute_plan().get(sid)
        if handler:
            total = len(self._recompute_chain_start) if getattr(self, "_recompute_chain_start", None) else (len(self._recompute_chain) + 1)
            done = total - (len(self._recompute_chain) + 1) + 1
            try:
                self._chain_chip.show_progress(self._recompute_chain_id or "", done, total, sid)
                self.rail_store.chainProgressChanged.emit(self._recompute_chain_id or "", done, total, sid)
            except Exception:
                pass
            handler()

    def _on_recompute_result_changed(self, segment_id: str, result: RecomputeResult) -> None:
        if self._recompute_chain_id and self.rail_store.chain_id_for(segment_id) not in {None, self._recompute_chain_id}:
            return
        if result in (RecomputeResult.FAILED, RecomputeResult.DROPPED_STALE):
            self._recompute_chain.clear()
            self._recompute_chain_start = []
            try:
                self._chain_chip.reset()
            except Exception:
                pass
            try:
                self.rail_store.chainProgressChanged.emit("", 0, 0, "")
            except Exception:
                pass
            return
        if not self._recompute_chain:
            try:
                self._chain_chip.reset()
            except Exception:
                pass
            try:
                self.rail_store.chainProgressChanged.emit("", 0, 0, "")
            except Exception:
                pass
            self._recompute_chain_start = []
            return
        self._run_next_recompute_in_chain()

    def _on_recompute_rejected(self, segment_id: str, reason: str) -> None:
        if reason == "already_computing":
            try:
                self.session.set_status(f"{segment_id} already computing")
            except Exception:
                pass

    def _on_stale_result_dropped(self, segment_id: str, reason: str) -> None:
        try:
            self.session.set_status(f"Stale result dropped for {segment_id}: {reason}")
        except Exception:
            pass
    def _recompute_outcome_model(self) -> None:
        inflight_id = _random_token()
        self._recompute_inflight_id = inflight_id
        graph = getattr(self.rail_store, "graph", None)
        seg = graph.get("outcome_model") if graph else None  # type: ignore[union-attr]
        started = self.rail_store.begin_compute("outcome_model", inflight_id, chain_id=self._recompute_chain_id)
        if not started:
            return
        self._invalidate_segments(["evidence", "claims"])
        self._run_helixspec_buffer(inflight_id=inflight_id)

    def _recompute_evidence(self) -> None:
        inflight_id = _random_token()
        self._recompute_inflight_id = inflight_id
        try:
            expected_outcome = self._segment_hash("outcome_model")
            if not self.rail_store.begin_compute(
                "evidence",
                inflight_id,
                chain_id=self._recompute_chain_id,
                expected_upstream_hash=expected_outcome,
            ):
                return
            self._invalidate_segments(["claims"])
            target_run = None
            try:
                rid = getattr(self.session.state, "run_id", None)
                if rid is not None:
                    target_run = self.session.get_run_by_id(str(rid))
            except Exception:
                target_run = None
            if target_run is None:
                target_run = self.session.runs[-1] if getattr(self.session, "runs", None) else None
            run = target_run
            if run is None:
                raise RuntimeError("No runs available for evidence recompute.")
            evidence = run_to_evidence(run, preset=None, include_sequence=False)
            current_outcome = self._segment_hash("outcome_model")

            def _apply() -> str:
                try:
                    self.session.update(results_records=[evidence])
                except Exception:
                    pass
                return stable_hash(evidence)

            commit_with_guards(
                self.rail_store,
                "evidence",
                inflight_id=inflight_id,
                chain_id=self._recompute_chain_id,
                expected_upstream_hash=expected_outcome,
                current_upstream_hash=current_outcome,
                apply_fn=_apply,
            )
        except Exception:
            try:
                self.rail_store.fail_compute("evidence", inflight_id)
            except Exception:
                pass
        finally:
            self._recompute_inflight_id = None

    def _recompute_claims(self) -> None:
        inflight_id = _random_token()
        self._recompute_inflight_id = inflight_id
        expected_evidence = self._segment_hash("evidence")
        if not self.rail_store.begin_compute(
            "claims",
            inflight_id,
            chain_id=self._recompute_chain_id,
            expected_upstream_hash=expected_evidence,
        ):
            return
        try:
            evidence_hash = stable_hash(getattr(self.session.state, "results_records", None))
            claims_hash = stable_hash({"claims": evidence_hash})
            current_evidence = self._segment_hash("evidence")
            commit_with_guards(
                self.rail_store,
                "claims",
                inflight_id=inflight_id,
                chain_id=self._recompute_chain_id,
                expected_upstream_hash=expected_evidence,
                current_upstream_hash=current_evidence,
                apply_fn=lambda: claims_hash,
            )
        except Exception:
            self.rail_store.fail_compute("claims", inflight_id)
        finally:
            self._recompute_inflight_id = None

    def _segment_hash(self, segment_id: str) -> str | None:
        graph = getattr(self.rail_store, "graph", None)
        if graph is None:
            return None
        seg = graph.get(segment_id)
        return seg.output_hash if seg else None

    def _invalidate_segments(self, segment_ids: list[str]) -> None:
        for sid in segment_ids:
            self._set_rail_state(sid, CacheState.DIRTY)
            self.rail_store.mark_segment_state(sid, CacheState.DIRTY)

    def _finalize_recompute_cache_state(self, *, inflight_id: str | None) -> None:
        if not inflight_id or inflight_id != self._recompute_inflight_id:
            return
        graph = getattr(self.rail_store, "graph", None)
        seg = graph.get("outcome_model") if graph else None  # type: ignore[union-attr]
        if seg is None:
            return
        try:
            self.rail_store.end_compute("outcome_model", inflight_id, new_hash=seg.output_hash, current_upstream_hash=None)
        except Exception:
            pass
        self._recompute_inflight_id = None

    def _build_left_column(self) -> QWidget:
        container = QWidget(self)
        container.setObjectName("LeftColumn")
        layout = QVBoxLayout(container)
        # Slightly tighter padding to make the dock feel less inset
        compact_margin = max(2, MARGIN_PANEL // 2)
        layout.setContentsMargins(compact_margin, compact_margin, compact_margin, compact_margin)
        layout.setSpacing(SPACING_MEDIUM)

        # Left rail: Sim Builder. In Studio mode the Sim Builder handles its own scrolling
        # (tabbed rail with per-tab scroll areas) so the tab bar stays pinned.
        layout.addWidget(self.sim_panel, stretch=1)
        # Wrap labels inside the left column so narrow widths don't clip text.
        try:
            enable_word_wrap(container)
        except Exception:
            pass
        self._left_tabs = None
        try:
            tabs = self.sim_panel.findChild(QTabWidget, "StudioLeftTabs")
            if tabs is not None:
                self._left_tabs = tabs
                tabs.setUsesScrollButtons(False)
        except Exception:
            pass
        return container

    def _set_active_sidebar(self, key: str) -> None:
        """Switch the visible sidebar page and sync activity button state."""
        stack = getattr(self, "_sidebar_stack", None)
        pages = getattr(self, "_sidebar_pages", {})
        buttons = getattr(self, "_activity_buttons", {})
        if stack is None or key not in pages:
            return
        try:
            stack.setCurrentIndex(pages[key])
        except Exception:
            return
        btn = buttons.get(key)
        if btn is not None and not btn.isChecked():
            btn.setChecked(True)

    def _on_activity_button_clicked(self, key: str, checked: bool) -> None:
        """
        VS Code style behavior:
        - Clicking the active button toggles the whole sidebar open/closed.
        - When opening, restore the last nonzero width.
        """
        if not checked:
            return
        if self._focus_mode:
            # Ignore sidebar toggles in focus mode.
            return
        self._set_active_sidebar(key)
        if self._layout_mode == "compact":
            # Compact mode: treat the left sidebar as a rail that expands on demand.
            if self._left_hidden:
                self._set_left_visible(True)
            if self._left_rail_collapsed:
                self._left_rail_pinned_open = True
                self._set_left_rail_collapsed(False)
            else:
                # If this was a hover-open, clicking pins it; if pinned, clicking collapses.
                if self._left_rail_pinned_open:
                    self._left_rail_pinned_open = False
                    self._set_left_rail_collapsed(True)
                else:
                    self._left_rail_pinned_open = True
            return
        if not hasattr(self, "_splitter"):
            return
        sizes = self._splitter.sizes()
        if len(sizes) < 2:
            return
        if len(sizes) == 2:
            sidebar, center = sizes
            right = 0
        else:
            sidebar, center, right = sizes[:3]
        if sidebar > 0:
            # Collapse sidebar, remember width
            self._sidebar_last_size = max(self._sidebar_last_size, sidebar)
            if len(sizes) == 2:
                self._splitter.setSizes([0, center + sidebar])
            else:
                self._splitter.setSizes([0, center + sidebar, right])
            return
        # Expand sidebar using last saved width, without starving center
        min_sidebar = self._min_sidebar_width_px()
        min_center = self._scaled_px(200)
        desired = max(self._sidebar_last_size, min_sidebar)
        if len(sizes) == 2:
            total = sidebar + center
            sidebar_new = min(desired, max(self._scaled_px(240), total // 3))
            center_new = max(min_center, total - sidebar_new)
            self._splitter.setSizes([sidebar_new, center_new])
            return
        total = sidebar + center + right
        sidebar_new = min(desired, max(self._scaled_px(300), total // 3))
        center_new = max(min_center, total - sidebar_new - right)
        if center_new < min_center:
            center_new = min_center
        remaining = total - sidebar_new - center_new
        right_new = max(0, remaining)
        self._splitter.setSizes([sidebar_new, center_new, right_new])

    def _install_left_rail_hover_guard(self, container: QWidget) -> None:
        if getattr(self, "_left_rail_hover_guard", None) is not None:
            return

        host = self

        class _LeftRailHoverGuard(QObject):
            def eventFilter(self, obj, event):  # type: ignore[override]
                if event.type() == QEvent.Enter:
                    host._on_left_rail_hover_enter()
                elif event.type() == QEvent.Leave:
                    host._on_left_rail_hover_leave()
                return False

        guard = _LeftRailHoverGuard(container)
        container.installEventFilter(guard)
        self._left_rail_hover_guard = guard

    def _on_left_rail_hover_enter(self) -> None:
        if self._layout_mode != "compact":
            return
        if _is_headless_platform():
            return
        if self._focus_mode or self._left_hidden:
            return
        timer = getattr(self, "_left_rail_hover_timer", None)
        if timer is not None:
            timer.stop()
        if self._left_rail_collapsed and not self._left_rail_pinned_open:
            self._set_left_rail_collapsed(False)

    def _on_left_rail_hover_leave(self) -> None:
        if self._layout_mode != "compact":
            return
        if _is_headless_platform():
            return
        if self._focus_mode or self._left_hidden:
            return
        if self._left_rail_pinned_open:
            return
        if getattr(self, "_left_rail_hover_timer", None) is None:
            t = QTimer(self)
            t.setSingleShot(True)

            def _collapse() -> None:
                if self._layout_mode != "compact":
                    return
                if self._left_hidden or self._focus_mode or self._left_rail_pinned_open:
                    return
                self._set_left_rail_collapsed(True)

            t.timeout.connect(_collapse)
            self._left_rail_hover_timer = t
        self._left_rail_hover_timer.start(240)

    def _set_left_rail_enabled(self, enabled: bool, *, collapse_on_enable: bool = False) -> None:
        bar = getattr(self, "_activity_bar", None)
        stack = getattr(self, "_sidebar_stack", None)
        if bar is None or stack is None:
            return
        buttons = list(getattr(self, "_activity_buttons", {}).values())
        left_rail_width = self._left_rail_width_px()
        min_sidebar = self._min_sidebar_width_px()

        if not enabled or self._left_hidden:
            # Restore full sidebar, hide the rail when it's redundant.
            self._left_rail_pinned_open = False
            self._left_rail_collapsed = False
            for btn in buttons:
                try:
                    full = btn.property("full_text")
                    if isinstance(full, str) and full and btn.text() != full:
                        btn.setText(full)
                except Exception:
                    pass
            try:
                stack.show()
                stack.setMinimumWidth(min_sidebar)
                stack.setMaximumWidth(16777215)
            except Exception:
                pass
            if len(getattr(self, "_activity_buttons", {})) <= 1:
                try:
                    bar.setMinimumWidth(0)
                    bar.setMaximumWidth(0)
                    bar.hide()
                except Exception:
                    pass
            else:
                try:
                    bar.setMinimumWidth(left_rail_width)
                    bar.setMaximumWidth(left_rail_width)
                    bar.show()
                except Exception:
                    pass
            return

        # Enabled (compact): show the rail always.
        try:
            bar.setMinimumWidth(left_rail_width)
            bar.setMaximumWidth(left_rail_width)
            bar.show()
        except Exception:
            pass
        for btn in buttons:
            try:
                rail = btn.property("rail_text")
                if isinstance(rail, str) and rail and btn.text() != rail:
                    btn.setText(rail)
            except Exception:
                pass

        if collapse_on_enable:
            self._left_rail_pinned_open = False
            self._set_left_rail_collapsed(True)

    def _set_left_rail_collapsed(self, collapsed: bool) -> None:
        collapsed = bool(collapsed)
        if self._left_hidden or self._focus_mode:
            return
        bar = getattr(self, "_activity_bar", None)
        stack = getattr(self, "_sidebar_stack", None)
        if bar is None or stack is None or not hasattr(self, "_splitter"):
            return
        left_rail_width = self._left_rail_width_px()
        min_sidebar = self._min_sidebar_width_px()
        min_center = self._scaled_px(200)

        if collapsed == self._left_rail_collapsed:
            # Still ensure geometry matches in case splitter was manually resized.
            pass
        self._left_rail_collapsed = collapsed

        # Stop any pending hover-collapse timer on explicit toggles.
        timer = getattr(self, "_left_rail_hover_timer", None)
        if timer is not None and not collapsed:
            timer.stop()

        sizes = self._splitter.sizes()
        if sizes:
            try:
                if sizes[0] > left_rail_width + 8:
                    self._left_last_size = sizes[0]
                    self._sidebar_last_size = max(getattr(self, "_sidebar_last_size", 0), sizes[0])
            except Exception:
                pass

        if collapsed:
            try:
                stack.hide()
                stack.setMinimumWidth(0)
                stack.setMaximumWidth(0)
            except Exception:
                pass
            try:
                bar.setMinimumWidth(left_rail_width)
                bar.setMaximumWidth(left_rail_width)
                bar.show()
            except Exception:
                pass
            try:
                sizes = self._splitter.sizes()
                if not sizes:
                    return
                total = sum(sizes)
                if len(sizes) == 2:
                    left = max(0, min(left_rail_width, total - min_center))
                    self._splitter.setSizes([left, total - left])
                else:
                    right = sizes[2]
                    left = max(0, min(left_rail_width, total - right - min_center))
                    center = max(min_center, total - left - right)
                    self._splitter.setSizes([left, total - left - right, right])
            except Exception:
                pass
            return

        # Expanded
        try:
            stack.show()
            stack.setMaximumWidth(16777215)
            stack.setMinimumWidth(min_sidebar)
        except Exception:
            pass
        try:
            bar.setMinimumWidth(left_rail_width)
            bar.setMaximumWidth(left_rail_width)
            bar.show()
        except Exception:
            pass
        try:
            sizes = self._splitter.sizes()
            if not sizes:
                return
            total = sum(sizes)
            min_desired = left_rail_width + min_sidebar
            desired = max(getattr(self, "_left_last_size", 240), getattr(self, "_sidebar_last_size", 260), min_desired)
            desired = min(desired, max(min_desired, int(total * 0.45)))
            if len(sizes) == 2:
                left = max(0, min(desired, total - min_center))
                self._splitter.setSizes([left, total - left])
            else:
                right = sizes[2]
                left = max(0, min(desired, total - right - min_center))
                center = max(min_center, total - left - right)
                self._splitter.setSizes([left, total - left - right, right])
        except Exception:
            pass
        try:
            # Ensure the Builder opens in the "Input" tab for muscle-memory.
            panel = getattr(self, "sim_panel", None)
            if panel is not None:
                tabs = panel.findChild(QTabWidget, "StudioLeftTabs")
                if tabs is not None:
                    tabs.setCurrentIndex(0)
        except Exception:
            pass

    # --- Focus mode ---------------------------------------------------
    def _set_focus_mode(self, enabled: bool) -> None:
        self._focus_mode = bool(enabled)
        self._apply_focus_mode()

    def _apply_focus_mode(self) -> None:
        if not hasattr(self, "_splitter"):
            return
        if self._focus_mode:
            # Save current state
            self._focus_saved_sizes = self._splitter.sizes()
            self._focus_console_was_visible = getattr(self, "_console_dock", None) and self._console_dock.isVisible()
            self._focus_right_overlay_was_visible = getattr(self, "_sidebar_overlay", None) and self._sidebar_overlay.isVisible()
            # Collapse sidebars
            total = sum(self._focus_saved_sizes) if self._focus_saved_sizes else self.width()
            self._hide_sidebar_overlay()
            self._splitter.setSizes([0, total, 0])
            # Hide console
            self._hide_console_dock()
            # Tell center panel to enter focus layout
            try:
                if hasattr(self, "_center_panel"):
                    self._center_panel.set_focus_layout(True)
            except Exception:
                pass
        else:
            # Restore sizes/state
            if getattr(self, "_focus_saved_sizes", None):
                try:
                    self._splitter.setSizes(self._focus_saved_sizes)
                except Exception:
                    pass
            if getattr(self, "_focus_console_was_visible", False):
                self._show_console_dock(default_only=False)
            if getattr(self, "_focus_right_overlay_was_visible", False):
                try:
                    self._open_sidebar_overlay()
                except Exception:
                    pass
            try:
                if hasattr(self, "_center_panel"):
                    self._center_panel.set_focus_layout(False)
            except Exception:
                pass
        # Keep action state in sync
        if hasattr(self, "_focus_action") and self._focus_action is not None:
            if self._focus_action.isChecked() != self._focus_mode:
                self._focus_action.blockSignals(True)
                self._focus_action.setChecked(self._focus_mode)
                self._focus_action.blockSignals(False)

    def _refresh_run_timeline(self) -> None:
        try:
            runs = getattr(self.session, "runs", [])
            if hasattr(self, "_center_panel"):
                self._center_panel.set_run_list(runs)
        except Exception:
            pass

    def _on_focus_compare_requested(self, run_id: str) -> None:
        """Load EVS for the requested run and set as baseline overlay in focus mode."""
        try:
            evs = load_evs_for_run(self.project.root_path, run_id)
        except Exception:
            evs = None
        try:
            if evs is not None and hasattr(self, "_center_panel") and hasattr(self._center_panel, "_explorer"):
                self._center_panel._explorer.set_baseline_overlay(evs)
        except Exception:
            pass

    def _clone_current_run_to_builder(self) -> None:
        latest = None
        try:
            latest = self.session.runs[-1] if getattr(self.session, "runs", None) else None
        except Exception:
            latest = None
        if latest is None:
            self.statusBar().showMessage("No run to clone", 3000)
            return
        self._clone_run_to_builder(latest.run_id)

    def _clone_run_to_builder(self, run_id: str) -> None:
        """Clone the given run into Sim Builder and focus it."""
        cfg = None
        try:
            cfg = self.session.clone_run_config(run_id)
        except Exception:
            cfg = None
        if cfg is None:
            self.statusBar().showMessage(f"Could not clone run {run_id}", 4000)
            return
        try:
            if hasattr(self.sim_panel, "load_from_model"):
                self.sim_panel.load_from_model(cfg)
            elif hasattr(self.sim_panel, "load_from_config"):
                self.sim_panel.load_from_config(cfg)
            self._set_focus_mode(False)
            self._set_left_visible(True)
            self.statusBar().showMessage(f"Cloned run {run_id} into Builder", 4000)
        except Exception as exc:
            self.statusBar().showMessage(f"Clone failed: {exc}", 5000)

    def _build_right_column(self) -> QWidget:
        container = QWidget(self)
        container.setObjectName("RightColumn")
        layout = QVBoxLayout(container)
        layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        layout.setSpacing(SPACING_MEDIUM)

        tabs = QTabWidget(container)
        tabs.setObjectName("RightTabs")
        self.session_inspector = SessionInspector(self.session)
        tabs.addTab(self._wrap_scroll(self.session_inspector), "Session")
        if self.guide_inspector is not None:
            tabs.addTab(self._wrap_scroll(self.guide_inspector), "Guides")
        tabs.addTab(self._wrap_scroll(self.run_compare_widget), "Compare")
        try:
            tabs.setDocumentMode(True)
            tabs.setUsesScrollButtons(True)
            bar = tabs.tabBar()
            bar.setExpanding(False)
            bar.setElideMode(Qt.ElideNone)
            bar.setMovable(True)
        except Exception:
            pass
        try:
            tabs.setMinimumWidth(0)
            tabs.setMaximumWidth(16777215)
            tabs.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Expanding)
        except Exception:
            pass
        try:
            # Avoid clipped labels when the sidebar is narrow.
            enable_word_wrap(container)
        except Exception:
            pass
        layout.addWidget(tabs)
        self._right_tabs = tabs
        return container

    def _build_console_dock(self) -> None:
        """Build bottom console dock with Log + Run History tabs."""

        self.log_widget.setFont(monospace_font())
        self.log_widget.setObjectName("LogPanel")

        log_container = QWidget(self)
        log_layout = QVBoxLayout(log_container)
        log_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        log_layout.setSpacing(SPACING_SMALL)
        log_layout.addWidget(self.log_widget)

        self._console_tabs = QTabWidget(self)
        self._console_tabs.setObjectName("ConsoleTabs")
        try:
            self._console_tabs.setDocumentMode(True)
            self._console_tabs.setUsesScrollButtons(True)
            bar = self._console_tabs.tabBar()
            bar.setExpanding(False)
            bar.setElideMode(Qt.ElideNone)
            bar.setMovable(True)
        except Exception:
            pass
        self._console_tabs.addTab(log_container, "Log / Events")
        self._console_tabs.addTab(self.history_widget, "Run history")
        self._viz_hud_panel = QPlainTextEdit(self)
        try:
            self._viz_hud_panel.setReadOnly(True)
            self._viz_hud_panel.setLineWrapMode(QPlainTextEdit.NoWrap)
            self._viz_hud_panel.setFont(monospace_font())
        except Exception:
            pass
        self._console_tabs.addTab(self._viz_hud_panel, "Viz HUD")
        self._console_tabs.setCurrentIndex(0)

        dock = QDockWidget("Console", self)
        dock.setObjectName("console_dock")
        dock.setAllowedAreas(Qt.BottomDockWidgetArea)
        dock.setWidget(self._console_tabs)
        dock.setFeatures(QDockWidget.DockWidgetClosable | QDockWidget.DockWidgetMovable)
        self.addDockWidget(Qt.BottomDockWidgetArea, dock)
        self._register_dock(dock)
        # Preserve legacy accessor naming for presets/layout helpers.
        self._console_dock = dock
        self._log_dock = dock

        # Quick toggle in the status bar for constrained layouts.
        self._console_toggle = QToolButton(self)
        self._console_toggle.setText("Console")
        self._console_toggle.setCheckable(True)
        self._console_toggle.setChecked(False)
        self._console_toggle.setAutoRaise(True)
        try:
            self._console_toggle.setProperty("variant", "status_toggle")
            self._console_toggle.setCursor(Qt.PointingHandCursor)
        except Exception:
            pass
        self._console_toggle.clicked.connect(
            lambda checked: self._show_console_dock(default_only=False) if checked else self._hide_console_dock()
        )
        try:
            dock.visibilityChanged.connect(self._on_console_visibility_changed)
        except Exception:
            pass
        try:
            self.statusBar().addPermanentWidget(self._console_toggle)
        except Exception:
            pass
        # Default: collapsed (restored window state may override later).
        dock.hide()
        self._update_console_toggle_text()

    def _set_viz_hud_text(self, title: str, lines: Sequence[str]) -> None:
        """Update the bottom-dock Viz HUD tab with the latest overlay text."""
        panel = getattr(self, "_viz_hud_panel", None)
        tabs = getattr(self, "_console_tabs", None)
        if panel is None or tabs is None:
            return
        payload = "\n".join(lines or [])
        try:
            if panel.toPlainText() != payload:
                panel.setPlainText(payload)
        except Exception:
            try:
                panel.setPlainText(payload)
            except Exception:
                pass
        try:
            idx = tabs.indexOf(panel)
            if idx >= 0 and title:
                tabs.setTabText(idx, title)
        except Exception:
            pass

    def _attach_viewer_hud_tab(self) -> None:
        """Wire the GL viewport HUD text into the console dock tab, if present."""
        gl = getattr(self, "gl_view", None)
        panel = getattr(self, "_viz_hud_panel", None)
        if gl is None or panel is None:
            return
        try:
            gl.set_hud_text_sink(self._set_viz_hud_text)
        except Exception:
            pass

        # Additional toggles for side panels
        self._left_toggle = QToolButton(self)
        self._left_toggle.setText("Builder")
        self._left_toggle.setCheckable(True)
        self._left_toggle.setChecked(True)
        self._left_toggle.setAutoRaise(True)
        try:
            self._left_toggle.setProperty("variant", "status_toggle")
            self._left_toggle.setCursor(Qt.PointingHandCursor)
        except Exception:
            pass
        self._left_toggle.clicked.connect(lambda checked: self._set_left_visible(checked))

        self._right_toggle = QToolButton(self)
        self._right_toggle.setText("Sidebar")
        self._right_toggle.setCheckable(True)
        self._right_toggle.setChecked(True)
        self._right_toggle.setAutoRaise(True)
        try:
            self._right_toggle.setProperty("variant", "status_toggle")
            self._right_toggle.setCursor(Qt.PointingHandCursor)
        except Exception:
            pass
        self._right_toggle.clicked.connect(lambda checked: self._set_right_visible(checked))

        try:
            self.statusBar().addPermanentWidget(self._left_toggle)
            self.statusBar().addPermanentWidget(self._right_toggle)
            self._chain_chip = StatusChip(self)
            self.statusBar().addPermanentWidget(self._chain_chip)
        except Exception:
            pass

    def _init_terminal_manager(self) -> None:
        try:
            self.terminal_manager = TerminalManager(self, self._console_tabs, self.ctx.project_root)
        except Exception:
            self.terminal_manager = None

    def _ui_scale(self) -> float:
        try:
            return ui_scale_factor(screen=self.screen())
        except Exception:
            return 1.0

    def _scaled_px(self, value: float) -> int:
        try:
            return scaled_px(value, screen=self.screen())
        except Exception:
            return max(1, int(round(float(value))))

    def _left_rail_width_px(self) -> int:
        return max(48, self._scaled_px(LEFT_RAIL_WIDTH))

    def _min_sidebar_width_px(self) -> int:
        return self._scaled_px(220)

    def _compact_center_min_width_px(self) -> int:
        return self._scaled_px(LAYOUT_COMPACT_MIN_CENTER_WIDTH)

    def _apply_default_splitter_sizes(self) -> None:
        if not hasattr(self, "_splitter"):
            return
        if self._splitter.count() < 2:
            return

        width = int(self._splitter.width() or 0)
        if width <= 0:
            width = int(self.width() or 0)
        if width <= 0:
            width = 900
        sidebar = int(self._default_sidebar_width_px(window_width=width))

        if self._splitter.count() < 3:
            # In overlay modes, keep the builder usable by reserving a minimum center width.
            min_center = int(self._measured_center_min_width())
            left = min(sidebar, max(0, width - min_center))
            center = max(0, width - left)
            self._splitter.setSizes([int(left), int(center)])
            return

        left = int(sidebar)
        right = int(sidebar)
        center = max(0, width - left - right)
        # Wide layout: side panels should not collapse just because the center widget
        # advertises an enormous sizeHint (e.g., expanding tab bars). Only enforce a
        # small "center stays usable" floor.
        min_center = self._compact_center_min_width_px()
        min_sidebar = self._min_sidebar_width_px()
        if center < min_center:
            deficit = min_center - center
            left_room = max(0, left - min_sidebar)
            right_room = max(0, right - min_sidebar)
            shrink_total = min(int(deficit), int(left_room + right_room))
            shrink_left = min(int(left_room), int((shrink_total + 1) // 2))
            shrink_right = min(int(right_room), int(shrink_total - shrink_left))
            left = max(min_sidebar, left - shrink_left)
            right = max(min_sidebar, right - shrink_right)
            center = max(0, width - left - right)

        # Ensure total width used (splitter sizes must sum).
        right = max(0, width - left - center)
        self._splitter.setSizes([int(left), int(center), int(right)])

    def _apply_split_ratio(self, weights: list[int]) -> None:
        if not hasattr(self, "_splitter"):
            return
        total = max(1, sum(weights))
        width = int(self._splitter.width() or 0)
        if width <= 0:
            width = int(self.width() or 0)
        if width <= 0:
            width = 900
        sizes = [width * w // total for w in weights]
        # ensure total width used
        if sizes:
            sizes[-1] = width - sum(sizes[:-1])
        try:
            self._splitter.setSizes(sizes)
        except Exception:
            pass

    def latest_run_id(self) -> str | None:
        """Return the newest run id visible in history or session."""
        history = getattr(self, "history_widget", None)
        if history is not None:
            snaps = getattr(history, "_snapshots", None)
            if snaps:
                state = snaps[-1].get("state") if isinstance(snaps[-1], Mapping) else snaps[-1]
                if isinstance(state, Mapping):
                    rid = state.get("run_id")
                    if rid is not None:
                        return str(rid)
        runs = getattr(self.session, "runs", None)
        if runs:
            try:
                return str(runs[-1].run_id)
            except Exception:
                pass
        return None

    def _reset_docks_default(self) -> None:
        dock = getattr(self, "_console_dock", getattr(self, "_log_dock", None))
        if dock is not None:
            self.addDockWidget(Qt.BottomDockWidgetArea, dock)
            # Default: collapsed to reclaim vertical space; open on demand.
            dock.hide()
            try:
                self._console_tabs.setCurrentIndex(0)
            except Exception:
                pass
            try:
                self._update_console_toggle_text()
            except Exception:
                pass

    # --- Responsive layout helpers -------------------------------------
    def _layout_mode_for_size(self, width: int, height: int) -> str:
        layout_scale = max(1.0, float(self._ui_scale()))
        wide_w = int(round(LAYOUT_WIDE_MIN_WIDTH * layout_scale))
        wide_h = int(round(LAYOUT_WIDE_MIN_HEIGHT * layout_scale))
        medium_w = int(round(LAYOUT_MEDIUM_MIN_WIDTH * layout_scale))
        medium_h = int(round(LAYOUT_MEDIUM_MIN_HEIGHT * layout_scale))
        if width >= wide_w and height >= wide_h:
            return "wide"
        if width >= medium_w and height >= medium_h:
            return "medium"
        return "compact"

    def _clamped_sidebar_max_width(self, *, window_width: int | None = None) -> int:
        width = int(self.width() if window_width is None else window_width)
        width = max(0, width)
        frac = int(width * float(SIDEBAR_MAX_FRACTION))
        # Proportional clamp + absolute safety net to prevent ultra-wide sidebars.
        min_sidebar = self._min_sidebar_width_px()
        max_px = self._scaled_px(SIDEBAR_MAX_PX)
        return max(min_sidebar, min(frac, max_px))

    def _default_sidebar_width_px(self, *, window_width: int | None = None) -> int:
        """Default sidebar width in logical pixels (stable across ultra-wide screens)."""

        width = int(self.width() if window_width is None else window_width)
        width = max(0, width)
        max_w = self._clamped_sidebar_max_width(window_width=width)
        raw_override = os.getenv("HELIX_SIDEBAR_DEFAULT_WIDTH", "").strip()
        if raw_override:
            try:
                desired = int(raw_override)
            except Exception:
                desired = int(SIDEBAR_DEFAULT_PX)
        else:
            desired = self._scaled_px(SIDEBAR_DEFAULT_PX)
        min_sidebar = self._min_sidebar_width_px()
        desired = max(min_sidebar, desired)
        return max(0, min(int(desired), int(max_w)))

    def _clamped_overlay_width(self, *, window_width: int | None = None) -> int:
        width = int(self.width() if window_width is None else window_width)
        width = max(0, width)
        pad = self._scaled_px(24)
        max_w = min(self._clamped_sidebar_max_width(window_width=width), max(0, width - pad))
        if max_w <= 0:
            return 0
        # Keep the drawer comfortable on medium laptops, but never let it eat the world.
        desired = int(width * 0.32)
        min_w = min(self._scaled_px(360), max_w)
        return max(min_w, min(desired, max_w))

    def _sidebar_overlay_geometry(
        self,
        *,
        window_width: int | None = None,
        window_height: int | None = None,
        chrome_top: int | None = None,
        status_bar_height: int | None = None,
    ) -> QRect:
        """
        Compute the intended geometry for the right sidebar drawer overlay.

        This helper is intentionally pure-ish so tests can validate sizing without
        relying on platform-specific minimum window constraints.
        """

        w = int(self.width() if window_width is None else window_width)
        h = int(self.height() if window_height is None else window_height)
        top = int(self._chrome_top_inset() if chrome_top is None else chrome_top)
        status_h = int(self.statusBar().height() if status_bar_height is None else status_bar_height)
        overlay_w = int(self._clamped_overlay_width(window_width=w))
        overlay_h = max(0, h - top - status_h - 24)
        x = w - overlay_w - 12
        y = top + 8
        return QRect(int(x), int(y), int(overlay_w), int(overlay_h))

    def _measured_center_min_width(self) -> int:
        """Best-effort minimum width for the center surface (for compact safeguards)."""

        candidates: list[int] = [int(self._compact_center_min_width_px())]
        try:
            if hasattr(self, "_center_container") and self._center_container is not None:
                candidates.append(int(self._center_container.minimumWidth()))
                candidates.append(int(self._center_container.minimumSizeHint().width()))
        except Exception:
            pass
        try:
            tabs = getattr(self, "_main_tabs", None)
            if tabs is not None:
                candidates.append(int(tabs.minimumWidth()))
                candidates.append(int(tabs.minimumSizeHint().width()))
                current = tabs.currentWidget()
                if current is not None:
                    candidates.append(int(current.minimumWidth()))
                    candidates.append(int(current.minimumSizeHint().width()))
        except Exception:
            pass
        return max(candidates)

    def _apply_sidebar_width_clamps(self) -> None:
        """Apply proportional max widths so sidebars remain sane on ultra-wide/high DPI."""

        max_w = self._clamped_sidebar_max_width()
        try:
            if hasattr(self, "_activity_sidebar") and self._activity_sidebar is not None:
                self._activity_sidebar.setMaximumWidth(max_w)
        except Exception:
            pass
        try:
            if hasattr(self, "_right_column") and self._right_column is not None:
                self._right_column.setMaximumWidth(max_w)
        except Exception:
            pass

    def _apply_compact_ultra_narrow_layout(self) -> None:
        """In compact mode, collapse the left rail entirely when the window is too narrow."""

        if not hasattr(self, "_splitter"):
            return
        if self._left_hidden or self._focus_mode:
            return

        # Ultra-narrow is a window-width constraint; don't let dynamic sizeHints (which can
        # vary with viewport height/styles) flip this decision and unexpectedly hide the
        # left rail mid-session.
        min_center = int(self._compact_center_min_width_px())
        left_rail_width = self._left_rail_width_px()
        ultra_narrow = int(self.width() or 0) < (left_rail_width + min_center)

        if ultra_narrow:
            self._left_rail_ultra_hidden = True
            bar = getattr(self, "_activity_bar", None)
            stack = getattr(self, "_sidebar_stack", None)
            for widget in (bar, stack):
                if widget is None:
                    continue
                try:
                    widget.setMinimumWidth(0)
                    widget.setMaximumWidth(0)
                    widget.hide()
                except Exception:
                    pass
            sizes = self._splitter.sizes()
            if sizes and len(sizes) >= 2:
                total = int(sum(sizes))
                self._splitter.setSizes([0, max(0, total)])
            return

        if getattr(self, "_left_rail_ultra_hidden", False):
            self._left_rail_ultra_hidden = False
            # Restore the compact left rail state after leaving ultra-narrow mode.
            try:
                self._set_left_rail_collapsed(getattr(self, "_left_rail_collapsed", False))
            except Exception:
                pass

    def _update_layout_mode(self, force: bool = False) -> None:
        if self._focus_mode:
            return
        if os.getenv("HELIX_STUDIO_RESPONSIVE_DISABLED", "0") == "1":
            return
        # Avoid setting mode before the workspace widgets exist (e.g., early resize events).
        if not hasattr(self, "_splitter") or getattr(self, "_main_tabs", None) is None:
            return
        mode = self._layout_mode_for_size(self.width(), self.height())
        if not force and mode == self._layout_mode:
            # Mode unchanged, but some compact-only geometry (like the left rail) needs to
            # stay consistent across resizes.
            if mode == "compact" and getattr(self, "_left_rail_collapsed", False):
                try:
                    self._set_left_rail_collapsed(True)
                except Exception:
                    pass
            if mode == "compact":
                try:
                    self._apply_compact_ultra_narrow_layout()
                except Exception:
                    pass
            # Still update proportional caps that depend on the current window width.
            try:
                self._apply_sidebar_width_clamps()
            except Exception:
                pass
            return
        prev_mode = self._layout_mode
        self._layout_mode = mode
        try:
            if hasattr(self, "_center_panel") and self._center_panel is not None:
                self._center_panel.set_compact_mode(mode != "wide")
        except Exception:
            pass
        try:
            self._build_compact_menu_button()
            self._install_top_corner_widgets()
        except Exception:
            pass

        if mode == "wide":
            try:
                self._menu_host().setVisible(True)
            except Exception:
                pass
            try:
                if getattr(self, "_compact_menu_button", None) is not None:
                    self._compact_menu_button.hide()
            except Exception:
                pass
            self._move_right_column_to_splitter()
            self._hide_sidebar_overlay()
            self._toggle_sidebar_button_bar(False)
            self._apply_default_splitter_sizes()
            self._set_left_visible(not self._left_hidden, apply_sizes=False)
            self._set_left_rail_enabled(False)
            self._set_right_visible(not self._right_hidden, apply_sizes=False)
            if getattr(self, "_console_restore_visible", False):
                self._show_console_dock(default_only=False)
            self._console_restore_visible = False
        elif mode == "medium":
            show_menu = self.height() >= 820
            try:
                self._menu_host().setVisible(bool(show_menu))
            except Exception:
                pass
            try:
                if getattr(self, "_compact_menu_button", None) is not None:
                    if show_menu:
                        self._compact_menu_button.hide()
                    else:
                        self._compact_menu_button.show()
            except Exception:
                pass
            self._move_right_column_to_overlay()
            self._toggle_sidebar_button_bar(True)
            if self._right_overlay_pinned_open and not self._right_hidden:
                self._open_sidebar_overlay(getattr(getattr(self, "_right_tabs", None), "currentIndex", lambda: 0)())
            else:
                self._hide_sidebar_overlay()
            self._apply_default_splitter_sizes()  # left + center only; keep builder usable
            self._set_left_visible(not self._left_hidden, apply_sizes=False)
            self._set_left_rail_enabled(False)
            if prev_mode == "wide":
                dock = getattr(self, "_console_dock", None)
                self._console_restore_visible = bool(dock and dock.isVisible())
                self._hide_console_dock()
        else:  # compact
            try:
                self._menu_host().setVisible(False)
            except Exception:
                pass
            try:
                if getattr(self, "_compact_menu_button", None) is not None:
                    self._compact_menu_button.show()
            except Exception:
                pass
            self._move_right_column_to_overlay()
            self._toggle_sidebar_button_bar(True)
            if self._right_overlay_pinned_open and not self._right_hidden:
                self._open_sidebar_overlay(getattr(getattr(self, "_right_tabs", None), "currentIndex", lambda: 0)())
            else:
                self._hide_sidebar_overlay()
            self._apply_split_ratio([1, 9])  # left + center only; prioritize center
            self._set_left_visible(not self._left_hidden, apply_sizes=False)
            if prev_mode == "wide":
                dock = getattr(self, "_console_dock", None)
                self._console_restore_visible = bool(dock and dock.isVisible())
                self._hide_console_dock()
            self._set_left_rail_enabled(True, collapse_on_enable=prev_mode != "compact")
            if getattr(self, "_left_rail_collapsed", False):
                # When the rail is collapsed, keep it at the fixed rail width even
                # if the splitter was previously resized while expanded.
                try:
                    self._set_left_rail_collapsed(True)
                except Exception:
                    pass

            # Ultra-narrow compact windows: give the center enough width to stay usable.
            try:
                self._apply_compact_ultra_narrow_layout()
            except Exception:
                pass
            # Ensure the left rail keeps a sane minimum width in compact mode.
            try:
                window_width = int(self.width() or 0)
                left_rail_width = self._left_rail_width_px()
                compact_center = self._compact_center_min_width_px()
                if window_width >= (left_rail_width + compact_center):
                    sizes = self._splitter.sizes()
                    if sizes and len(sizes) >= 2 and sizes[0] < left_rail_width:
                        total = int(sum(sizes))
                        min_center_floor = self._scaled_px(200)
                        left = min(left_rail_width, max(left_rail_width, total - min_center_floor))
                        if len(sizes) == 2:
                            self._splitter.setSizes([left, max(0, total - left)])
                        else:
                            right = sizes[2]
                            center = max(0, total - left - right)
                            self._splitter.setSizes([left, center, right])
            except Exception:
                pass
        self._position_sidebar_button_bar()
        try:
            self._update_sidebar_drawer_button()
        except Exception:
            pass
        try:
            self._apply_sidebar_width_clamps()
        except Exception:
            pass
        self._apply_pending_layout_state_restore()

    def _hide_console_dock(self) -> None:
        dock = getattr(self, "_console_dock", None)
        if dock is not None:
            dock.hide()
        toggle = getattr(self, "_console_toggle", None)
        if toggle is not None:
            toggle.setChecked(bool(dock and dock.isVisible()))
        action = getattr(self, "_toggle_console_action", None)
        if isinstance(action, QAction):
            desired = bool(dock and dock.isVisible())
            if action.isChecked() != desired:
                action.blockSignals(True)
                action.setChecked(desired)
                action.blockSignals(False)
        try:
            self._update_console_toggle_text()
        except Exception:
            pass
        # When console is hidden, preserve sizes so restore feels natural.
        try:
            sizes = self.consoleSplitter.sizes() if hasattr(self, "consoleSplitter") else None
            if sizes and len(sizes) == 2:
                self._console_saved_size = sizes[1]
        except Exception:
            pass

    def _show_console_dock(self, default_only: bool = False) -> None:
        dock = getattr(self, "_console_dock", None)
        if dock is None:
            return
        # Only show automatically in wide layouts unless explicitly requested.
        if default_only and self._layout_mode != "wide":
            return
        dock.show()
        dock.raise_()
        toggle = getattr(self, "_console_toggle", None)
        if toggle is not None:
            toggle.setChecked(True)
        action = getattr(self, "_toggle_console_action", None)
        if isinstance(action, QAction) and not action.isChecked():
            action.blockSignals(True)
            action.setChecked(True)
            action.blockSignals(False)
        try:
            self._update_console_toggle_text()
        except Exception:
            pass
        try:
            self._console_tabs.setCurrentIndex(0)
        except Exception:
            pass
        # restore saved height if available
        try:
            if hasattr(self, "consoleSplitter") and getattr(self, "_console_saved_size", None):
                sizes = self.consoleSplitter.sizes()
                top = sizes[0]
                self.consoleSplitter.setSizes([top, self._console_saved_size])
        except Exception:
            pass

    def _ensure_sidebar_overlay(self) -> None:
        if getattr(self, "_sidebar_overlay", None) is not None:
            return
        # Drawer is implemented as an in-window overlay (not a separate window) so
        # interactive runs behave consistently across platforms and screenshot
        # semantics are stable.
        overlay = _RightSidebarDrawerOverlay(self)
        overlay.setObjectName("RightSidebarDrawer")
        try:
            overlay.setFocusPolicy(Qt.StrongFocus)
        except Exception:
            pass
        try:
            overlay.setFrameShape(QFrame.StyledPanel)
        except Exception:
            pass
        try:
            overlay.setAttribute(Qt.WA_StyledBackground, True)
        except Exception:
            pass
        overlay.hide()

        body = QWidget(overlay)
        layout = QVBoxLayout(body)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        overlay_layout = QVBoxLayout(overlay)
        overlay_layout.setContentsMargins(0, 0, 0, 0)
        overlay_layout.setSpacing(0)
        overlay_layout.addWidget(body)

        self._sidebar_overlay = overlay
        self._sidebar_overlay_body = body

    def _clear_layout(self, layout) -> None:
        if layout is None:
            return
        while layout.count():
            item = layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)

    def _move_right_column_to_overlay(self) -> None:
        if not hasattr(self, "_right_column"):
            return
        # Preserve the last wide-mode widths before removing the right widget from the splitter.
        try:
            splitter = getattr(self, "_splitter", None)
            if splitter is not None:
                self._record_splitter_sizes(list(splitter.sizes()))
        except Exception:
            pass
        if getattr(self, "_sidebar_overlay_body", None) is None:
            self._ensure_sidebar_overlay()
        if self._sidebar_overlay_body is None:
            return
        if self._right_column.parent() is self._sidebar_overlay_body:
            return
        try:
            idx = self._splitter.indexOf(self._right_column)
            if idx >= 0:
                self._splitter.widget(idx).setParent(None)
        except Exception:
            try:
                self._right_column.setParent(None)
            except Exception:
                pass
        self._clear_layout(self._sidebar_overlay_body.layout())
        self._sidebar_overlay_body.layout().addWidget(self._right_column)
        self._right_column.show()
        # When overlay mode is active, keep toggle in sync.
        if hasattr(self, "_right_toggle"):
            self._right_toggle.setChecked(True)

    def _move_right_column_to_splitter(self) -> None:
        if not hasattr(self, "_right_column"):
            return
        # Preserve the last overlay-mode widths before re-attaching the right widget.
        try:
            splitter = getattr(self, "_splitter", None)
            if splitter is not None:
                self._record_splitter_sizes(list(splitter.sizes()))
        except Exception:
            pass
        if self._right_column.parent() is self._splitter:
            return
        if getattr(self, "_sidebar_overlay_body", None) is not None:
            self._clear_layout(self._sidebar_overlay_body.layout())
        try:
            self._right_column.setParent(self._splitter)
            self._splitter.addWidget(self._right_column)
            self._splitter.setStretchFactor(2, 5)
            self._right_column.show()
            self._hide_sidebar_overlay()
        except Exception:
            pass
        if hasattr(self, "_right_toggle"):
            self._right_toggle.setChecked(not self._right_hidden)

    def _hide_sidebar_overlay(self) -> None:
        overlay = getattr(self, "_sidebar_overlay", None)
        if overlay is None:
            return
        if not overlay.isVisible():
            overlay.hide()
            return
        try:
            anim = getattr(self, "_sidebar_overlay_anim", None)
            if anim is not None:
                anim.stop()
        except Exception:
            pass
        try:
            start = overlay.geometry()
            end = QRect(start)
            end.moveLeft(start.left() + start.width() + 24)
            anim = QPropertyAnimation(overlay, b"geometry", self)
            anim.setDuration(160)
            anim.setStartValue(start)
            anim.setEndValue(end)
            anim.setEasingCurve(QEasingCurve.InCubic)
            anim.finished.connect(overlay.hide)
            anim.start()
            self._sidebar_overlay_anim = anim
        except Exception:
            overlay.hide()
        try:
            self._update_sidebar_drawer_button()
        except Exception:
            pass

    def _toggle_sidebar_overlay(self, tab_index: int = 0) -> None:
        overlay = getattr(self, "_sidebar_overlay", None)
        if overlay is not None and overlay.isVisible():
            self._right_overlay_pinned_open = False
            self._hide_sidebar_overlay()
        else:
            self._open_sidebar_overlay_user(tab_index)
        try:
            self._update_sidebar_drawer_button()
        except Exception:
            pass

    def _open_sidebar_overlay_user(self, tab_index: int = 0) -> None:
        # User intent: they explicitly opened the drawer, so keep it open across
        # medium<->wide transitions until they close it.
        self._right_overlay_pinned_open = True
        if self._right_hidden:
            self._right_hidden = False
            self._set_right_column_hidden(False)
            try:
                if hasattr(self, "_right_toggle"):
                    self._right_toggle.setChecked(True)
            except Exception:
                pass
        self._open_sidebar_overlay(tab_index)

    def _open_sidebar_overlay(self, tab_index: int = 0) -> None:
        if self._layout_mode == "wide":
            # Sidebar is visible already.
            try:
                if hasattr(self, "_right_tabs"):
                    self._right_tabs.setCurrentIndex(tab_index)
            except Exception:
                pass
            return
        self._move_right_column_to_overlay()
        self._ensure_sidebar_overlay()
        if self._sidebar_overlay is None or self._sidebar_overlay_body is None:
            return
        try:
            if hasattr(self, "_right_tabs"):
                self._right_tabs.setCurrentIndex(tab_index)
        except Exception:
            pass
        local_end = self._sidebar_overlay_geometry()
        overlay_is_window = bool(getattr(self._sidebar_overlay, "isWindow", lambda: False)())
        if overlay_is_window:
            origin = self.mapToGlobal(QPoint(0, 0))
            end = QRect(
                origin.x() + local_end.x(),
                origin.y() + local_end.y(),
                local_end.width(),
                local_end.height(),
            )
            start = QRect(
                origin.x() + self.width() + 12,
                origin.y() + local_end.y(),
                local_end.width(),
                local_end.height(),
            )
        else:
            end = QRect(local_end)
            start = QRect(self.width() + 12, local_end.y(), local_end.width(), local_end.height())
        self._sidebar_overlay.setGeometry(start)
        self._sidebar_overlay.show()
        self._sidebar_overlay.raise_()
        try:
            if overlay_is_window:
                self._sidebar_overlay.activateWindow()
        except Exception:
            pass
        try:
            anim = getattr(self, "_sidebar_overlay_anim", None)
            if anim is not None:
                anim.stop()
        except Exception:
            pass
        try:
            anim = QPropertyAnimation(self._sidebar_overlay, b"geometry", self)
            anim.setDuration(180)
            anim.setStartValue(start)
            anim.setEndValue(end)
            anim.setEasingCurve(QEasingCurve.OutCubic)
            anim.start()
            self._sidebar_overlay_anim = anim
        except Exception:
            qt_set_geometry(self._sidebar_overlay, end.x(), end.y(), end.width(), end.height())
        try:
            self._update_sidebar_drawer_button()
        except Exception:
            pass
        # Accessibility: shift keyboard focus into the drawer so Tab stays local.
        try:
            self._sidebar_overlay.setFocus(Qt.ActiveWindowFocusReason)
        except Exception:
            pass

    def _build_sidebar_button_bar(self) -> None:
        if getattr(self, "_sidebar_button_bar", None) is not None:
            return
        bar = QWidget(self)
        bar.setObjectName("SidebarButtonBar")
        layout = QHBoxLayout(bar)
        # Keep this chrome tight; it's installed into the mode-tab bar in compact layouts.
        layout.setContentsMargins(6, 2, 6, 2)
        layout.setSpacing(6)

        btn = QToolButton(bar)
        btn.setObjectName("SidebarDrawerButton")
        btn.setText("Session: NONE · 0 outcomes ▸")
        btn.setToolButtonStyle(Qt.ToolButtonTextOnly)
        btn.setAutoRaise(True)
        btn.setMinimumHeight(24)
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(lambda checked=False: self._toggle_sidebar_overlay(0))
        layout.addWidget(btn)
        self._sidebar_drawer_button = btn
        bar.hide()
        self._sidebar_button_bar = bar
        try:
            self._update_sidebar_drawer_button()
        except Exception:
            pass

    def _toggle_sidebar_button_bar(self, visible: bool) -> None:
        self._build_sidebar_button_bar()
        if self._sidebar_button_bar is None:
            return
        self._sidebar_button_bar.setVisible(visible)
        if visible:
            self._sidebar_button_bar.raise_()
        try:
            self._update_sidebar_drawer_button()
        except Exception:
            pass

    def _position_sidebar_button_bar(self) -> None:
        bar = getattr(self, "_sidebar_button_bar", None)
        if bar is None or not bar.isVisible():
            return
        # If installed as a tab-corner widget it is positioned by Qt.
        if bar.parent() is not self:
            return
        top = self._chrome_top_inset() + 12
        qt_move(bar, self.width() - bar.width() - 6, top)

    def _position_sidebar_overlay(self) -> None:
        overlay = getattr(self, "_sidebar_overlay", None)
        if overlay is None or not overlay.isVisible():
            return
        try:
            anim = getattr(self, "_sidebar_overlay_anim", None)
            if anim is not None:
                end = None
                try:
                    end = anim.endValue()
                except Exception:
                    end = None
                # Don't interfere with the closing animation: it is about to hide
                # the drawer, and stopping it can leave it stuck half-visible.
                if isinstance(end, QRect) and end.left() > self.width():
                    return
                anim.stop()
        except Exception:
            pass
        local_rect = self._sidebar_overlay_geometry()
        try:
            if overlay.isWindow():
                origin = self.mapToGlobal(QPoint(0, 0))
                qt_set_geometry(
                    overlay,
                    origin.x() + local_rect.x(),
                    origin.y() + local_rect.y(),
                    local_rect.width(),
                    local_rect.height(),
                )
            else:
                qt_set_geometry(
                    overlay,
                    local_rect.x(),
                    local_rect.y(),
                    local_rect.width(),
                    local_rect.height(),
                )
        except Exception:
            qt_set_geometry(
                overlay,
                local_rect.x(),
                local_rect.y(),
                local_rect.width(),
                local_rect.height(),
            )

    def _build_compact_menu_button(self) -> None:
        if getattr(self, "_compact_menu_button", None) is not None:
            return
        btn = QToolButton(self)
        btn.setObjectName("CompactMenuButton")
        btn.setText("≡")
        btn.setToolTip("Menu")
        btn.setToolButtonStyle(Qt.ToolButtonTextOnly)
        btn.setAutoRaise(True)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setMinimumHeight(24)
        btn.setPopupMode(QToolButton.InstantPopup)

        menu = QMenu(btn)
        try:
            for action in self._menu_host().actions():
                if action is None or action.menu() is None:
                    continue
                menu.addAction(action)
        except Exception:
            pass
        btn.setMenu(menu)
        btn.hide()
        self._compact_menu_button = btn

    def _install_top_corner_widgets(self) -> None:
        tabs = getattr(self, "_main_tabs", None)
        if tabs is None:
            return
        try:
            if getattr(self, "_compact_menu_button", None) is not None:
                tabs.setCornerWidget(self._compact_menu_button, Qt.TopLeftCorner)
        except Exception:
            pass
        try:
            if getattr(self, "_sidebar_button_bar", None) is not None:
                tabs.setCornerWidget(self._sidebar_button_bar, Qt.TopRightCorner)
        except Exception:
            pass

    def _chrome_top_inset(self) -> int:
        """
        Pixels from the window top to the *workspace* surface.

        Used for overlay positioning so the mode-tab bar remains clickable.
        """
        top = 0
        try:
            if getattr(self, "_top_bar", None) is not None and self._top_bar.isVisible():
                top += self._top_bar.height()
            elif self._menu_host().isVisible():
                top += self._menu_host().height()
        except Exception:
            pass
        try:
            tabs = getattr(self, "_main_tabs", None)
            if tabs is not None:
                top += tabs.tabBar().height()
        except Exception:
            pass
        return int(top)

    def _session_sidebar_summary(self) -> str:
        evs = getattr(self, "_active_evs", None)
        if isinstance(evs, Mapping):
            outcomes = None
            try:
                sim = evs.get("simulation") if isinstance(evs.get("simulation"), Mapping) else {}
                results = sim.get("results") if isinstance(sim.get("results"), Mapping) else {}
                alleles = results.get("alleles")
                if isinstance(alleles, list):
                    outcomes = len(alleles)
            except Exception:
                outcomes = None
            if outcomes is None:
                try:
                    outcomes_raw = evs.get("outcomes")
                    if isinstance(outcomes_raw, list):
                        outcomes = len(outcomes_raw)
                except Exception:
                    outcomes = None
            if outcomes is None:
                try:
                    outcomes = int(evs.get("outcomes_count") or 0)
                except Exception:
                    outcomes = 0

            run_kind = ""
            try:
                edit_plan = evs.get("editPlan") if isinstance(evs.get("editPlan"), Mapping) else {}
                run_kind = str(edit_plan.get("mode") or "").strip()
            except Exception:
                run_kind = ""
            if not run_kind:
                try:
                    run_kind = str(evs.get("run_kind") or "").strip()
                except Exception:
                    run_kind = ""

            label = run_kind.upper() if run_kind else "Run"
            outcome_word = "outcome" if int(outcomes or 0) == 1 else "outcomes"
            return f"Session: {label} · {int(outcomes or 0)} {outcome_word}"

        state = getattr(self.session, "state", None)
        if state is None:
            return "Session: NONE · 0 outcomes"
        try:
            outcomes = len(getattr(state, "outcomes", []) or [])
        except Exception:
            outcomes = 0
        try:
            run_kind = getattr(getattr(state, "run_kind", None), "name", "") or ""
        except Exception:
            run_kind = ""
        try:
            run_id = int(getattr(state, "run_id", 0) or 0)
        except Exception:
            run_id = 0

        label = "NONE"
        try:
            genome = getattr(state, "genome", None)
            has_genome = bool(genome is not None and getattr(genome, "sequences", None))
        except Exception:
            has_genome = False

        if run_kind and run_kind != "NONE":
            label = run_kind
        elif has_genome:
            label = "Genome loaded"
        elif run_id:
            label = f"Run #{run_id}"

        outcome_word = "outcome" if outcomes == 1 else "outcomes"
        return f"Session: {label} · {outcomes} {outcome_word}"

    def _update_sidebar_drawer_button(self) -> None:
        btn = getattr(self, "_sidebar_drawer_button", None)
        if btn is None:
            try:
                bar = getattr(self, "_sidebar_button_bar", None)
                btn = bar.findChild(QToolButton, "SidebarDrawerButton") if bar is not None else None
            except Exception:
                btn = None
        if btn is None:
            return

        base = self._session_sidebar_summary()
        overlay = getattr(self, "_sidebar_overlay", None)
        suffix = " ◂" if overlay is not None and overlay.isVisible() else " ▸"
        full = base + suffix
        btn.setToolTip(base)
        if len(full) > 42:
            full = full[:41] + "…"
        btn.setText(full)

    def _on_session_state_changed_for_sidebar(self, _state) -> None:
        try:
            self._update_sidebar_drawer_button()
        except Exception:
            pass

    # Panel visibility helpers ----------------------------------------
    def _set_left_visible(self, visible: bool, apply_sizes: bool = True) -> None:
        self._left_hidden = not visible
        if not hasattr(self, "_splitter") or self._splitter.count() < 2:
            return
        sizes = self._splitter.sizes()
        if visible:
            # restore previous size or give a modest width
            min_left = self._scaled_px(180)
            min_center = self._scaled_px(200)
            left = self._left_last_size or max(min_left, self.width() // 8)
            center = max(min_center, self.width() - left - (sizes[2] if len(sizes) > 2 else 0))
            if len(sizes) == 3:
                self._splitter.setSizes([left, center, sizes[2]])
            else:
                self._splitter.setSizes([left, center])
        else:
            # save current size then collapse
            if sizes:
                self._left_last_size = sizes[0]
            if len(sizes) == 3:
                self._splitter.setSizes([0, sizes[1] + sizes[0] // 2, sizes[2]])
            else:
                self._splitter.setSizes([0, self.width()])
        if apply_sizes:
            try:
                self._splitter.update()
            except Exception:
                pass
        if hasattr(self, "_left_toggle"):
            self._left_toggle.setChecked(visible)

    def _set_right_column_hidden(self, hidden: bool) -> None:
        column = getattr(self, "_right_column", None)
        if column is None:
            return
        try:
            column.setVisible(not hidden)
        except Exception:
            pass
        try:
            column.setMaximumWidth(0 if hidden else 16777215)
        except Exception:
            pass

    def _set_right_visible(self, visible: bool, apply_sizes: bool = True) -> None:
        self._right_hidden = not visible
        if self._layout_mode in ("compact", "medium"):
            if not visible:
                self._right_overlay_pinned_open = False
                self._hide_sidebar_overlay()
                self._set_right_column_hidden(True)
            else:
                self._right_overlay_pinned_open = True
                self._set_right_column_hidden(False)
                self._open_sidebar_overlay()
            if hasattr(self, "_right_toggle"):
                self._right_toggle.setChecked(visible)
            return
        if not hasattr(self, "_splitter") or self._splitter.count() < 3:
            return
        sizes = self._splitter.sizes()
        if visible:
            self._set_right_column_hidden(False)
            min_right = self._scaled_px(200)
            min_left = self._scaled_px(180)
            min_center = self._scaled_px(200)
            right = self._right_last_size or max(min_right, self.width() // 6)
            center = max(min_center, self.width() - right - (sizes[0] if sizes else 0))
            left = sizes[0] if sizes else max(min_left, self.width() // 8)
            self._splitter.setSizes([left, center, right])
        else:
            if sizes and len(sizes) >= 3:
                self._right_last_size = sizes[2]
            if len(sizes) >= 3:
                self._splitter.setSizes([sizes[0], sizes[1] + sizes[2], 0])
            self._set_right_column_hidden(True)
        if apply_sizes:
            try:
                self._splitter.update()
            except Exception:
                pass
        if hasattr(self, "_right_toggle"):
            self._right_toggle.setChecked(visible)

    def _install_sidebar_overlay_guard(self) -> None:
        """Dismiss the right overlay on Esc/click-outside, without interfering with scroll."""

        if getattr(self, "_sidebar_overlay_guard", None) is not None:
            return

        app = QApplication.instance()
        if app is None:
            return

        host = self

        class _SidebarOverlayGuard(QObject):
            def eventFilter(self, obj, event):  # type: ignore[override]
                overlay = getattr(host, "_sidebar_overlay", None)
                try:
                    if overlay is None or not overlay.isVisible():
                        return False
                except RuntimeError:
                    return False
                except Exception:
                    return False
                et = event.type()
                if et == QEvent.KeyPress:
                    try:
                        if event.key() == Qt.Key_Escape:
                            # If a popup (e.g. combobox dropdown) is open, let it
                            # consume Esc first; a second Esc closes the drawer.
                            if QApplication.activePopupWidget() is not None:
                                return False
                            host._right_overlay_pinned_open = False
                            host._hide_sidebar_overlay()
                            return True
                    except Exception:
                        return False
                if et == QEvent.MouseButtonPress:
                    # Don't treat clicks inside the overlay (or on the toggle button)
                    # as outside-dismissal, otherwise the toggle can double-flip.
                    try:
                        btn = getattr(host, "_sidebar_drawer_button", None)
                        if isinstance(obj, QWidget) and btn is not None and (obj is btn or btn.isAncestorOf(obj)):
                            return False

                        global_pos = None
                        try:
                            global_pos = event.globalPosition().toPoint()
                        except Exception:
                            try:
                                global_pos = QCursor.pos()
                            except Exception:
                                global_pos = None

                        if global_pos is not None:
                            try:
                                local = overlay.mapFromGlobal(global_pos)
                                if overlay.rect().contains(local):
                                    return False
                            except Exception:
                                try:
                                    if overlay.geometry().contains(global_pos):
                                        return False
                                except Exception:
                                    pass
                            popup = QApplication.activePopupWidget()
                            if popup is not None:
                                try:
                                    p_local = popup.mapFromGlobal(global_pos)
                                    if popup.rect().contains(p_local):
                                        return False
                                except Exception:
                                    try:
                                        if popup.geometry().contains(global_pos):
                                            return False
                                    except Exception:
                                        pass
                    except Exception:
                        pass
                    host._right_overlay_pinned_open = False
                    host._hide_sidebar_overlay()
                    return False
                return False

        guard = _SidebarOverlayGuard(app)
        app.installEventFilter(guard)
        self._sidebar_overlay_guard = guard

    def _install_wheel_guard(self) -> None:
        """Prevent accidental spinbox/combobox changes from scroll when unfocused."""

        app = QApplication.instance()
        if app is None:
            return

        class _WheelGuard(QObject):
            def eventFilter(self, obj, event):  # type: ignore[override]
                if event.type() == QEvent.Wheel:
                    try:
                        from PySide6.QtGui import QWheelEvent
                        from PySide6.QtWidgets import QAbstractScrollArea, QWidget
                        from PySide6.QtCore import QPointF
                    except Exception:
                        return super().eventFilter(obj, event)
                    if not isinstance(event, QWheelEvent) or not isinstance(obj, QWidget):
                        return super().eventFilter(obj, event)

                    # We want the mouse wheel to scroll containers, not accidentally mutate
                    # dropdowns/spinboxes while hovering them.
                    w: QWidget | None = obj
                    control: QWidget | None = None
                    while w is not None:
                        if isinstance(w, (QAbstractSpinBox, QComboBox)):
                            control = w
                            break
                        w = w.parentWidget()
                    if control is None:
                        return super().eventFilter(obj, event)

                    # Forward the wheel event to the nearest scroll area (if any) so the
                    # user can continue scrolling naturally.
                    receiver: QWidget | None = obj
                    scroll: QAbstractScrollArea | None = None
                    while receiver is not None:
                        if isinstance(receiver, QAbstractScrollArea):
                            scroll = receiver
                            break
                        receiver = receiver.parentWidget()
                    if scroll is not None:
                        target = scroll.viewport() or scroll
                        gp = event.globalPosition()
                        local_pt = target.mapFromGlobal(gp.toPoint())
                        forwarded = QWheelEvent(
                            QPointF(local_pt),
                            gp,
                            event.pixelDelta(),
                            event.angleDelta(),
                            event.buttons(),
                            event.modifiers(),
                            event.phase(),
                            bool(event.inverted()),
                            event.source(),
                            event.pointingDevice(),
                        )
                        QApplication.sendEvent(target, forwarded)
                    event.ignore()
                    return True
                return super().eventFilter(obj, event)

        guard = _WheelGuard(app)
        app.installEventFilter(guard)
        # keep a ref to avoid GC
        self._wheel_guard = guard

    def set_active_evs(self, evs: dict | None) -> None:
        self._active_evs = evs
        run_model = None
        try:
            run_id = None
            if isinstance(evs, Mapping):
                run_id = evs.get("id") or evs.get("run_id")
                if run_id is None and isinstance(evs.get("state"), Mapping):
                    run_id = evs.get("state", {}).get("run_id")
            if run_id is not None and getattr(self, "session", None) is not None:
                run_model = self.session.get_run_by_id(str(run_id))
        except Exception:
            run_model = None

        # Some views (GL/workflow) depend on session state. Apply any EVS-derived state
        # mutations *before* updating EVS-bound panels so their EVS display isn't
        # immediately overwritten by stateChanged handlers.
        try:
            dag_payload = self._extract_dag_from_evs(evs)
            if dag_payload is not None and getattr(self, "session", None) is not None:
                self.session.update(
                    dag_from_runtime=dag_payload,
                    viz_spec_payload=None,
                    viz_dirty=True,
                    record_snapshot=False,
                )
        except Exception:
            pass
        try:
            self._center_panel.set_evs(evs)
        except Exception:
            pass
        try:
            self._center_panel.explorer().set_run_model(run_model)
        except Exception:
            pass
        try:
            if hasattr(self, "_run_status_panel") and self._run_status_panel is not None:
                self._run_status_panel.set_evs(evs)
        except Exception:
            pass
        try:
            if hasattr(self, "session_inspector") and self.session_inspector is not None:
                self.session_inspector.set_evs(evs)
        except Exception:
            pass
        try:
            wf = getattr(self, "workflow_panel", None)
            if wf is not None and hasattr(wf, "_explorer"):
                explorer = getattr(wf, "_explorer", None)
                if explorer is not None:
                    explorer.set_evs(evs)
                    explorer.set_run_model(run_model)
                    explorer.show()
                status = getattr(wf, "_status", None)
                if status is not None:
                    status.setText("Outcome Explorer ready.")
        except Exception:
            pass
        try:
            self._update_sidebar_drawer_button()
        except Exception:
            pass

    def _extract_dag_from_evs(self, evs: Mapping[str, object] | None) -> Mapping[str, object] | None:
        """Best-effort extraction of an edit DAG payload from an EVS document."""
        if not isinstance(evs, Mapping):
            return None
        # Common locations: top-level dag_from_runtime, nested under state, or artifact payload/path.
        dag_payload = evs.get("dag_from_runtime")
        if isinstance(dag_payload, Mapping) and dag_payload:
            return dag_payload
        state = evs.get("state")
        if isinstance(state, Mapping):
            dag_payload = state.get("dag_from_runtime")
            if isinstance(dag_payload, Mapping) and dag_payload:
                return dag_payload

        artifacts = evs.get("artifacts")
        if isinstance(artifacts, list):
            for art in artifacts:
                if not isinstance(art, Mapping):
                    continue
                kind = str(art.get("kind") or art.get("schema") or "")
                if "edit_dag" not in kind:
                    continue
                payload = art.get("payload")
                if isinstance(payload, Mapping) and payload:
                    return payload
                path = art.get("path") or art.get("file")
                if not path:
                    continue
                try:
                    root = getattr(self, "project", None)
                    root_path = getattr(root, "root_path", None) if root else None
                    base = Path(root_path) if root_path else Path(".")
                    candidate = (base / str(path)).resolve()
                    if candidate.exists():
                        loaded = json.loads(candidate.read_text(encoding="utf-8"))
                        if isinstance(loaded, Mapping):
                            return loaded
                except Exception:
                    continue
        return None

    def _wrap_scroll(self, widget: QWidget) -> QScrollArea:
        area = QScrollArea(self)
        area.setWidget(widget)
        area.setWidgetResizable(True)
        area.setFrameShape(QFrame.NoFrame)
        area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        return area

    def reset_layout_to_defaults(self) -> None:
        settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
        settings.remove(SETTINGS_GEOMETRY_KEY)
        settings.remove(SETTINGS_STATE_KEY)
        settings.remove(SETTINGS_LAYOUT_JSON_KEY)
        settings.remove(SETTINGS_CENTER_TAB_KEY)
        settings.remove(SETTINGS_REALTIME_VIEW_KEY)
        settings.remove(SETTINGS_WORKFLOW_VIEW_KEY)
        settings.remove(SETTINGS_DAG_VIEW_KEY)
        self.resize(1400, 900)
        self._apply_default_splitter_sizes()
        self._reset_docks_default()
        tabs = getattr(self, "_main_tabs", None)
        if tabs is not None:
            guard = getattr(self, "_suspend_center_tab_persistence", False)
            self._suspend_center_tab_persistence = True
            try:
                for idx in range(tabs.count()):
                    try:
                        tabs.setTabVisible(idx, True)
                    except Exception:
                        pass
                self._closed_center_tabs.clear()
                self._rebuild_center_tab_index_map()
                if tabs.count() > 0:
                    try:
                        tabs.setCurrentIndex(0)
                    except Exception:
                        pass
                self._active_center_tab_key = self._current_center_tab_key()
            finally:
                self._suspend_center_tab_persistence = guard
            self._update_render_activation(self._active_center_tab_key)

    def _restore_layout_or_defaults(self) -> None:
        settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
        restore_source = "defaults"
        if os.environ.get("HELIX_STUDIO_RESET_LAYOUT", "0") == "1":
            self.reset_layout_to_defaults()
            try:
                ensure_on_screen(self)
            except Exception:
                pass
            self._log_layout_restore("layout restore: reset requested via env; using defaults")
            return
        if _is_headless_platform():
            # Offscreen/minimal Qt surfaces report a tiny virtual screen and restoring persisted
            # geometry can clamp/override explicit `resize()` calls in tests and CI.
            try:
                self._apply_default_splitter_sizes()
                self._reset_docks_default()
            except Exception:
                pass
            self._ensure_splitter_visible()
            self._restored_geometry = False
            self._log_layout_restore("layout restore: headless platform; skipping persisted layout")
            return
        force_maximized = os.environ.get("HELIX_STUDIO_FORCE_MAXIMIZED", "0") == "1"
        try:
            layout_state = LayoutState.from_raw(settings.value(SETTINGS_LAYOUT_JSON_KEY, None))
        except Exception:
            layout_state = None
        geometry = settings.value(SETTINGS_GEOMETRY_KEY, None)
        state = settings.value(SETTINGS_STATE_KEY, None)

        restored_geometry = False
        if layout_state is not None and layout_state.geometry is not None and not force_maximized:
            try:
                self.restoreGeometry(QByteArray(layout_state.geometry))
                self._restored_geometry = True
                restored_geometry = True
            except Exception:
                self._restored_geometry = False
        if not restored_geometry:
            if geometry is not None and not force_maximized:
                self.restoreGeometry(geometry)
                self._restored_geometry = True
                restore_source = "legacy_qsettings"
            else:
                self.resize(1400, 900)
                self._move_to_cursor_screen()
                self._restored_geometry = False
                # First-run experience: favor fullscreen unless headless.
                self._request_fullscreen()

        state_restored = False
        if layout_state is not None and layout_state.qt_state is not None:
            try:
                self.restoreState(QByteArray(layout_state.qt_state))
                state_restored = True
            except Exception:
                state_restored = False
        if not state_restored:
            if state is not None:
                self.restoreState(state)
                restore_source = "legacy_qsettings"
            else:
                self._apply_default_splitter_sizes()
                self._reset_docks_default()

        if layout_state is not None:
            self._apply_center_tab_layout(layout_state.center_tabs)
            # Persisted splitter/visibility state is applied after responsive layout mode
            # settles (so overlay vs docked columns are configured first).
            self._pending_layout_state_restore = layout_state
            if os.getenv("HELIX_STUDIO_RESPONSIVE_DISABLED", "0") == "1":
                self._apply_pending_layout_state_restore()
        if layout_state is not None and (restored_geometry or state_restored):
            restore_source = "layout_json"
        elif geometry is None and state is None:
            restore_source = "defaults"
        self._ensure_splitter_visible()
        try:
            ensure_on_screen(self)
        except Exception:
            pass
        self._log_layout_restore(f"layout restore: source={restore_source}, force_maximized={force_maximized}")

    def _ensure_splitter_visible(self) -> None:
        splitter = getattr(self, "_splitter", None)
        if splitter is None:
            return
        try:
            sizes = list(splitter.sizes())
        except Exception:
            sizes = []
        if not sizes:
            return
        total = sum(max(0, int(sz)) for sz in sizes)
        if total <= 0:
            self._apply_default_splitter_sizes()
            return
        center_idx = 1 if len(sizes) >= 2 else 0
        try:
            center = int(sizes[center_idx])
        except Exception:
            center = 0
        if center <= 10:
            self._apply_default_splitter_sizes()

    def _record_splitter_sizes(self, sizes: list[int]) -> None:
        if not sizes:
            return
        cleaned: list[int] = []
        for value in sizes:
            try:
                cleaned.append(max(0, int(value)))
            except Exception:
                return
        if len(cleaned) >= 3:
            self._last_splitter_wide_sizes = cleaned[:3]
            left = cleaned[0]
            right = cleaned[2]
            if left > 0:
                self._left_last_size = left
                self._sidebar_last_size = left
            if right > 0:
                self._right_last_size = right
        elif len(cleaned) == 2:
            self._last_splitter_overlay_sizes = cleaned[:2]
            left = cleaned[0]
            if left > 0:
                self._left_last_size = left
                self._sidebar_last_size = left

    def _on_splitter_moved(self, _pos: int, _index: int) -> None:
        splitter = getattr(self, "_splitter", None)
        if splitter is None:
            return
        try:
            sizes = list(splitter.sizes())
        except Exception:
            return
        self._record_splitter_sizes(sizes)

    def _normalize_splitter_sizes(self, sizes: list[int], *, width: int) -> list[int] | None:
        cleaned: list[int] = []
        for value in sizes:
            try:
                v = int(value)
            except Exception:
                return None
            cleaned.append(max(0, v))
        total = sum(cleaned)
        if total <= 0:
            return None
        if width <= 0:
            return cleaned
        scaled = [width * v // total for v in cleaned]
        remainder = int(width - sum(scaled))
        if remainder:
            center_idx = 1 if len(scaled) >= 2 else 0
            scaled[center_idx] = max(0, int(scaled[center_idx] + remainder))
        return scaled

    def _apply_splitter_sizes_from_layout_state(self, layout_state: LayoutState) -> None:
        splitter = getattr(self, "_splitter", None)
        if splitter is None:
            return
        try:
            count = int(splitter.count())
        except Exception:
            return
        if count < 2:
            return
        if getattr(self, "_layout_mode", None) == "compact" and getattr(self, "_left_rail_collapsed", False):
            # Compact mode uses a fixed-width left rail; avoid re-expanding it based on
            # persisted wide/medium splitter ratios.
            return

        target: list[int] | None = None
        if count >= 3:
            if layout_state.splitter_wide and len(layout_state.splitter_wide) >= 3:
                target = [int(v) for v in layout_state.splitter_wide[:3]]
            elif layout_state.splitter_overlay and len(layout_state.splitter_overlay) >= 2:
                left = int(layout_state.splitter_overlay[0])
                width = int(splitter.width() or self.width() or sum(layout_state.splitter_overlay))
                right_pref = layout_state.right_last_size
                if right_pref is None:
                    right_pref = getattr(self, "_right_last_size", None)
                if right_pref is None:
                    right_pref = self._default_sidebar_width_px(window_width=width)
                right = int(right_pref)
                center = max(0, width - left - right)
                target = [left, center, max(0, width - left - center)]
        elif count == 2:
            if layout_state.splitter_overlay and len(layout_state.splitter_overlay) >= 2:
                target = [int(v) for v in layout_state.splitter_overlay[:2]]
            elif (getattr(self, "_layout_mode", None) != "compact") and layout_state.splitter_wide and len(layout_state.splitter_wide) >= 3:
                target = [int(layout_state.splitter_wide[0]), int(layout_state.splitter_wide[1]) + int(layout_state.splitter_wide[2])]

        if not target:
            return

        if layout_state.left_hidden is True and len(target) >= 1:
            target[0] = 0
        if count >= 3 and layout_state.right_hidden is True and len(target) >= 3:
            target[2] = 0

        try:
            width = int(splitter.width() or 0)
        except Exception:
            width = 0
        if width <= 0:
            try:
                width = int(self.width() or 0)
            except Exception:
                width = 0
        normalized = self._normalize_splitter_sizes(target, width=width)
        if normalized is None:
            return
        try:
            splitter.setSizes(normalized)
        except Exception:
            pass

    def _apply_layout_state_for_current_mode(self, layout_state: LayoutState) -> None:
        if layout_state is None:
            return

        # Restore internal "last known widths" so toggle behavior feels consistent.
        if isinstance(layout_state.sidebar_last_size, int):
            self._sidebar_last_size = max(0, int(layout_state.sidebar_last_size))
        if isinstance(layout_state.left_last_size, int):
            self._left_last_size = max(0, int(layout_state.left_last_size))
        if isinstance(layout_state.right_last_size, int):
            self._right_last_size = max(0, int(layout_state.right_last_size))
        if isinstance(layout_state.right_overlay_pinned_open, bool):
            self._right_overlay_pinned_open = bool(layout_state.right_overlay_pinned_open)

        # Apply visibility state first (may toggle overlays); sizes are applied afterwards.
        if isinstance(layout_state.left_hidden, bool):
            try:
                self._set_left_visible(not bool(layout_state.left_hidden), apply_sizes=False)
            except Exception:
                pass
        if isinstance(layout_state.right_hidden, bool):
            mode = getattr(self, "_layout_mode", None) or "wide"
            if mode in ("medium", "compact"):
                if layout_state.right_hidden:
                    try:
                        self._set_right_visible(False, apply_sizes=False)
                    except Exception:
                        pass
                else:
                    self._right_hidden = False
                    try:
                        self._set_right_column_hidden(False)
                    except Exception:
                        pass
                    try:
                        if hasattr(self, "_right_toggle"):
                            self._right_toggle.setChecked(True)
                    except Exception:
                        pass
                    try:
                        if self._right_overlay_pinned_open:
                            current_idx = getattr(getattr(self, "_right_tabs", None), "currentIndex", lambda: 0)()
                            self._open_sidebar_overlay(int(current_idx))
                        else:
                            self._hide_sidebar_overlay()
                    except Exception:
                        pass
            else:
                try:
                    self._set_right_visible(not bool(layout_state.right_hidden), apply_sizes=False)
                except Exception:
                    pass

        self._apply_splitter_sizes_from_layout_state(layout_state)
        self._ensure_splitter_visible()

    def _apply_pending_layout_state_restore(self) -> None:
        layout_state = getattr(self, "_pending_layout_state_restore", None)
        if layout_state is None:
            return
        self._pending_layout_state_restore = None
        try:
            self._apply_layout_state_for_current_mode(layout_state)
        except Exception:
            pass

    def _request_fullscreen(self) -> None:
        """Schedule a fullscreen/maximize after startup settles."""
        if _is_headless_platform():
            return
        if _is_wayland_platform():
            return
        if os.environ.get("HELIX_STUDIO_START_MAXIMIZED", "1") == "0":
            return
        if self._fullscreen_after_welcome:
            return
        self._fullscreen_after_welcome = True
        def _maximize():
            try:
                self.showMaximized()
            except Exception:
                pass
        QTimer.singleShot(0, _maximize)

    def _clamp_oversized_maximized(self) -> None:
        if _is_headless_platform():
            return
        if getattr(self, "_suppress_maximize_clamp", False):
            return
        try:
            handle = self.windowHandle()
            screen = handle.screen() if handle is not None else QGuiApplication.primaryScreen()
            if screen is None:
                return
            geo = screen.availableGeometry()
            frame = self.frameGeometry()
            if frame.width() <= geo.width() and frame.height() <= geo.height():
                return
            self._suppress_maximize_clamp = True
            try:
                self.showNormal()
                self.setGeometry(geo)
            finally:
                self._suppress_maximize_clamp = False
        except Exception:
            self._suppress_maximize_clamp = False

    def _on_visuals_banner_closed(self) -> None:
        try:
            QSettings(SETTINGS_ORG, SETTINGS_APP).setValue(SETTINGS_VISUALS_BANNER_KEY, True)
        except Exception:
            pass

    def _maybe_show_visuals_unavailable_banner(self) -> None:
        if _is_headless_platform():
            return
        if getattr(self, "_enable_gl", False):
            return

        banner = getattr(self, "_visuals_banner", None)
        if banner is None:
            return

        settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
        try:
            seen = bool(settings.value(SETTINGS_VISUALS_BANNER_KEY, False))
        except Exception:
            seen = False
        if seen:
            return

        banner.set_text(
            "3D + 2.5D visuals are unavailable in this session (GL disabled or moderngl missing). "
            "Install the 'realtime' extra and restart to enable ModernGL viewports; "
            "Helix continues in deterministic fallback mode."
        )
        try:
            banner.show()
        except Exception:
            return
        try:
            settings.setValue(SETTINGS_VISUALS_BANNER_KEY, True)
        except Exception:
            pass

    def _move_to_cursor_screen(self) -> None:
        pos = QCursor.pos()
        screen = QGuiApplication.screenAt(pos)
        print(
            f"[MainWindow] cursor pos=({pos.x()}, {pos.y()}) screenAt={getattr(screen, 'name', lambda: '?')() if screen else 'None'}",
            flush=True,
        )
        if screen is None:
            app = QGuiApplication.instance()
            if app is not None:
                for s in app.screens():
                    try:
                        if s.geometry().contains(pos):
                            screen = s
                            print(f"[MainWindow] matched via geometry: {getattr(screen, 'name', lambda: '?')()}", flush=True)
                            break
                    except Exception:
                        continue
        if screen is None:
            screen = QGuiApplication.primaryScreen()
        if screen is None:
            return
        geo = screen.availableGeometry()
        print(
            f"[MainWindow] using screen={getattr(screen, 'name', lambda: '?')()} geo=({geo.x()}, {geo.y()}, {geo.width()}x{geo.height()})",
            flush=True,
        )
        frame = self.frameGeometry()
        frame.moveCenter(geo.center())
        qt_move(self, frame.topLeft())

    def apply_layout_preset(self, key: str) -> None:
        # Layout presets are stored in QSettings and can be corrupted or become
        # incompatible across Qt versions. Loading them should never block core
        # actions like opening a run.
        try:
            ok = load_layout_preset(self, key)
        except Exception:
            ok = False
        if ok:
            return
        try:
            ensure_default_presets(self)
        except Exception:
            return
        try:
            load_layout_preset(self, key)
        except Exception:
            pass

    def on_run_activated(self, run_id: str) -> None:
        evs = load_evs_for_run(self.project.root_path, run_id)
        if evs is None:
            self.statusBar().showMessage(f"No EVS snapshot found for run {run_id}", 4000)
            return
        self._activate_evs_payload(evs, run_id=run_id, status_message=f"Loaded run {run_id} from EVS")

    def _activate_evs_payload(
        self,
        evs: dict,
        *,
        run_id: str,
        status_message: str | None = None,
        apply_layout_preset: bool = True,
        focus_sidebars: bool = True,
        sync_lightcone: bool = True,
    ) -> None:
        """Activate an EVS payload in all relevant panels without reloading from disk."""

        # Forward guide/PAM into the GL viewport if available.
        try:
            guide_ctx = extract_guide_context(evs)
            prime_ctx = extract_prime_context(evs)
            gl_view = getattr(self, "gl_view", None)
            gl = getattr(gl_view, "_gl", None) if gl_view is not None else None
            if gl is not None:
                try:
                    if hasattr(gl, "set_guide_context"):
                        gl.set_guide_context(guide_ctx)  # type: ignore[attr-defined]
                except Exception:
                    pass
                try:
                    if hasattr(gl, "set_prime_context"):
                        gl.set_prime_context(prime_ctx)  # type: ignore[attr-defined]
                except Exception:
                    pass
                try:
                    if hasattr(gl, "update"):
                        gl.update()  # type: ignore[attr-defined]
                except Exception:
                    pass

            self._maybe_set_gl_tile_from_evs(evs)
        except Exception:
            pass

        if apply_layout_preset:
            # Applying layout presets should not force the console open. Respect the user's
            # current console visibility and keep it collapsed by default.
            dock = getattr(self, "_console_dock", None)
            console_was_visible = bool(dock and dock.isVisible())
            try:
                self.apply_layout_preset("simulation")
            except Exception:
                pass
            try:
                if console_was_visible:
                    self._show_console_dock(default_only=False)
                else:
                    self._hide_console_dock()
            except Exception:
                pass
        try:
            self.set_active_evs(evs)
        except Exception:
            pass
        if focus_sidebars:
            try:
                if getattr(self, "_left_tabs", None):
                    self._left_tabs.setCurrentIndex(0)
                tabs = getattr(self, "_right_tabs", None)
                if tabs is not None:
                    tabs.setCurrentIndex(0)
            except Exception:
                pass
        if sync_lightcone:
            try:
                run = self.session.get_run_by_id(run_id)
                if run is not None:
                    self._schedule_lightcone_sync_from_run(run)
            except Exception:
                pass
        if status_message:
            try:
                self.statusBar().showMessage(str(status_message), 3000)
            except Exception:
                pass

    def closeEvent(self, event) -> None:  # type: ignore[override]
        settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
        self._persist_layout_state(settings)
        try:
            save_layout_preset(self, "genome_ide")
        except Exception:
            pass
        # Uninstall global event filters to avoid leaking host references across tests/sessions.
        try:
            app = QApplication.instance()
        except Exception:
            app = None
        if app is not None:
            try:
                guard = getattr(self, "_sidebar_overlay_guard", None)
                if guard is not None:
                    app.removeEventFilter(guard)
                self._sidebar_overlay_guard = None
            except Exception:
                pass
            try:
                guard = getattr(self, "_wheel_guard", None)
                if guard is not None:
                    app.removeEventFilter(guard)
                self._wheel_guard = None
            except Exception:
                pass
            try:
                app.removeEventFilter(self)
            except Exception:
                pass
        try:
            if getattr(self, "terminal_manager", None) is not None:
                self.terminal_manager.shutdown()
        except Exception:
            pass
        try:
            panel = getattr(self, "lightcone_panel", None)
            if panel is not None:
                panel.close()
        except Exception:
            pass
        super().closeEvent(event)

    # Helper to derive a basic genome tile for the GL viewport from EVS
    def _maybe_set_gl_tile_from_evs(self, evs: dict) -> None:
        if not hasattr(self, "gl_view") or self.gl_view is None:
            return
        gl = getattr(self.gl_view, "_gl", None)
        if gl is None:
            return
        seq_block = evs.get("sequence", {}) if isinstance(evs, dict) else {}
        if not isinstance(seq_block, dict):
            return
        seq = seq_block.get("ref") or seq_block.get("sequence")
        if not isinstance(seq, str) or not seq:
            return
        locus = seq_block.get("referenceLocus") if isinstance(seq_block.get("referenceLocus"), dict) else {}
        chrom = locus.get("chrom", "chr0")
        try:
            start = int(locus.get("start", 0))
        except Exception:
            start = 0
        try:
            if hasattr(gl, "set_tile_context"):
                gl.set_tile_context(str(chrom), start, seq)  # type: ignore[attr-defined]
            if hasattr(gl, "update"):
                gl.update()  # type: ignore[attr-defined]
        except Exception:
            pass

    # Accessors used by demo/layout helpers ---------------------------------
    def left_tabs(self):
        return getattr(self, "_left_tabs", None)

    def center_tabs(self):
        return getattr(self, "_main_tabs", None)

    def open_center_tab(self, key: str) -> bool:
        tabs = getattr(self, "_main_tabs", None)
        if tabs is None:
            return False
        idx = self._center_tab_index_by_key.get(str(key))
        if idx is None:
            return False
        try:
            if hasattr(tabs, "isTabVisible") and hasattr(tabs, "setTabVisible"):
                if not tabs.isTabVisible(idx):
                    tabs.setTabVisible(idx, True)
                    self._closed_center_tabs.discard(str(key))
            tabs.setCurrentIndex(idx)
            return True
        except Exception:
            return False

    def _open_lightcone_view(self) -> None:
        if not self.open_center_tab("lightcone"):
            try:
                self.statusBar().showMessage("Lightcone panel unavailable (missing deps or failed import).", 5000)
            except Exception:
                pass
            return
        if getattr(self, "lightcone_panel", None) is None:
            try:
                self.statusBar().showMessage("Lightcone panel unavailable (see Lightcone tab for details).", 5000)
            except Exception:
                pass
            return
        try:
            run = getattr(self, "_selected_lightcone_run", None)
            if run is not None:
                self._schedule_lightcone_sync_from_run(run, debounce_ms=0)
        except Exception:
            pass

    def _on_theme_selected(self, theme_name: str) -> None:
        app = QApplication.instance()
        if app is None:
            return
        apply_helix_theme(app, theme_name=theme_name, persist=True)
        resolved = current_theme_name(app)
        for name, act in self._theme_actions.items():
            try:
                act.setChecked(name == resolved)
            except Exception:
                pass
        try:
            self.style().unpolish(self)
            self.style().polish(self)
            self.update()
        except Exception:
            pass

    def _wire_lightcone_panel_once(self) -> None:
        if getattr(self, "_lightcone_wired", False):
            return
        panel = getattr(self, "lightcone_panel", None)
        if panel is None:
            return
        try:
            panel.locusContextChanged.connect(self._on_lightcone_locus_context_changed)
            panel.outcomeActivated.connect(self._on_lightcone_outcome_activated)
            panel.exportCompleted.connect(self._on_lightcone_export_completed)
        except Exception:
            return
        self._lightcone_wired = True

    def _schedule_lightcone_sync_from_run(self, run: RunModel, *, debounce_ms: int = 120) -> None:
        panel = getattr(self, "lightcone_panel", None)
        if panel is None:
            return
        self._selected_lightcone_run = run
        self._pending_lightcone_run = run
        try:
            self._lightcone_sync_timer.start(max(0, int(debounce_ms)))
        except Exception:
            self._apply_pending_lightcone_sync()

    def _apply_pending_lightcone_sync(self) -> None:
        run = getattr(self, "_pending_lightcone_run", None)
        self._pending_lightcone_run = None
        panel = getattr(self, "lightcone_panel", None)
        if run is None or panel is None:
            return
        try:
            current_doc_id = panel.current_doc_id() if hasattr(panel, "current_doc_id") else None
            if current_doc_id and str(run.run_id) in str(current_doc_id):
                return
        except Exception:
            pass
        try:
            from helix.studio.lightcone_live import build_lightcone_document_from_run

            doc = build_lightcone_document_from_run(run)
        except Exception as exc:
            try:
                self.statusBar().showMessage(f"Lightcone sync failed: {exc}", 6000)
            except Exception:
                pass
            return
        try:
            panel.set_document(doc, phase=1.0, reset_navigation=True)
        except Exception as exc:
            try:
                self.statusBar().showMessage(f"Lightcone load failed: {exc}", 6000)
            except Exception:
                pass

    def _on_lightcone_locus_context_changed(self, payload: object) -> None:
        if not isinstance(payload, dict):
            return
        self._lightcone_last_locus_context = dict(payload)

        locus = payload.get("locus") if isinstance(payload.get("locus"), Mapping) else {}
        ref = payload.get("referenceWindow") if isinstance(payload.get("referenceWindow"), Mapping) else {}
        contig = str(locus.get("contig") or "")
        try:
            window_start = int(locus.get("windowStart") or 0)
        except Exception:
            window_start = 0
        seq = ref.get("sequence")

        # Best-effort: keep the GL viewport "locus context" in sync with Lightcone navigation.
        try:
            if contig and isinstance(seq, str) and seq and getattr(self, "gl_view", None) is not None:
                gl = getattr(self.gl_view, "_gl", None)  # GLViewport wraps HelixModernWidget as _gl
                if gl is not None and hasattr(gl, "set_tile_context"):
                    gl.set_tile_context(contig, window_start, seq)
        except Exception:
            pass

    def _on_lightcone_outcome_activated(self, payload: object) -> None:
        if not isinstance(payload, dict):
            return
        self._lightcone_last_outcome = dict(payload)

    def _on_lightcone_export_completed(self, kind: str, path: str) -> None:
        self._lightcone_last_export = (str(kind), str(path))
        try:
            self.session.set_status(f"Lightcone export ({kind}): {path}")
        except Exception:
            pass

    def _current_center_tab_key(self) -> str | None:
        tabs = getattr(self, "_main_tabs", None)
        if tabs is None:
            return None
        idx = tabs.currentIndex()
        if idx < 0:
            return None
        try:
            data = tabs.tabBar().tabData(idx)
            if isinstance(data, str) and data:
                return data
        except Exception:
            pass
        for key, tab_idx in self._center_tab_index_by_key.items():
            if tab_idx == idx:
                return key
        return None

    def _on_center_tab_changed(self, index: int) -> None:
        if getattr(self, "_suspend_center_tab_persistence", False):
            return
        key: str | None = None
        tabs = getattr(self, "_main_tabs", None)
        if tabs is not None:
            try:
                data = tabs.tabBar().tabData(index)
                if isinstance(data, str) and data:
                    key = data
            except Exception:
                key = None
        if not key:
            for candidate, idx in self._center_tab_index_by_key.items():
                if idx == index:
                    key = candidate
                    break
        if not key:
            return
        self._active_center_tab_key = key
        self._update_render_activation(key)
        try:
            self._settings.setValue(SETTINGS_CENTER_TAB_KEY, key)
        except Exception:
            pass

    def _update_render_activation(self, active_key: str | None) -> None:
        gl_active = active_key == "realtime_3d"
        wf_active = active_key == "workflow_2p5d"
        if getattr(self, "gl_view", None) is not None:
            try:
                self.gl_view.set_render_active(gl_active)
            except Exception:
                pass
        if getattr(self, "workflow_panel", None) is not None:
            try:
                self.workflow_panel.set_render_active(wf_active)
            except Exception:
                pass

    def _read_json_setting(self, settings: QSettings, key: str) -> dict[str, object] | None:
        raw = None
        try:
            raw = settings.value(key, None)
        except Exception:
            raw = None
        if raw is None:
            return None
        if isinstance(raw, (bytes, bytearray)):
            try:
                raw = raw.decode("utf-8")
            except Exception:
                return None
        if isinstance(raw, dict):
            return raw
        if not isinstance(raw, str):
            raw = str(raw)
        if not raw:
            return None
        try:
            value = json.loads(raw)
        except Exception:
            return None
        return value if isinstance(value, dict) else None

    def _pack_view_state(self, payload: Mapping[str, object], *, kind: str) -> str:
        envelope: dict[str, object] = {
            "v": SETTINGS_VIEW_STATE_VERSION,
            "kind": str(kind),
            "payload": dict(payload),
        }
        try:
            return json.dumps(envelope)
        except TypeError:
            # Best-effort serialization; only used for UI continuity.
            return json.dumps(envelope, default=str)

    def _unpack_view_state(
        self,
        raw: Mapping[str, object] | None,
        *,
        kind: str,
    ) -> dict[str, object] | None:
        if raw is None:
            return None

        # Legacy (v0): raw is the payload itself.
        if "payload" not in raw and "v" not in raw and "version" not in raw:
            return dict(raw)

        version = raw.get("v", raw.get("version"))
        v: int | None = None
        if isinstance(version, int):
            v = version
        elif isinstance(version, str) and version.strip().isdigit():
            try:
                v = int(version.strip())
            except Exception:
                v = None

        if v is not None and v > SETTINGS_VIEW_STATE_VERSION:
            # Unknown future version; ignore rather than misapplying.
            return None

        payload = raw.get("payload", raw.get("data"))
        if isinstance(payload, Mapping):
            return dict(payload)

        # Some older runs might store the payload under the top-level.
        return dict(raw)

    def _snapshot_layout_state(self) -> LayoutState:
        geometry: bytes | None = None
        state: bytes | None = None
        try:
            geometry = bytes(self.saveGeometry())
        except Exception:
            geometry = None
        try:
            state = bytes(self.saveState())
        except Exception:
            state = None
        splitter_wide: list[int] = []
        splitter_overlay: list[int] = []
        splitter = getattr(self, "_splitter", None)
        current_sizes: list[int] = []
        if splitter is not None:
            try:
                current_sizes = [max(0, int(v)) for v in list(splitter.sizes())]
            except Exception:
                current_sizes = []

        if current_sizes:
            if len(current_sizes) >= 3:
                splitter_wide = current_sizes[:3]
                stored_overlay = getattr(self, "_last_splitter_overlay_sizes", None)
                if isinstance(stored_overlay, list) and len(stored_overlay) >= 2:
                    try:
                        splitter_overlay = [max(0, int(v)) for v in stored_overlay[:2]]
                    except Exception:
                        splitter_overlay = []
                if not splitter_overlay:
                    splitter_overlay = [splitter_wide[0], max(0, splitter_wide[1] + splitter_wide[2])]
            elif len(current_sizes) == 2:
                splitter_overlay = current_sizes[:2]
                stored_wide = getattr(self, "_last_splitter_wide_sizes", None)
                if isinstance(stored_wide, list) and len(stored_wide) >= 3:
                    try:
                        splitter_wide = [max(0, int(v)) for v in stored_wide[:3]]
                    except Exception:
                        splitter_wide = []
                if not splitter_wide:
                    try:
                        left = splitter_overlay[0]
                        center_total = splitter_overlay[1]
                        right_pref = getattr(self, "_right_last_size", None)
                        if right_pref is None:
                            right_pref = self._default_sidebar_width_px(window_width=sum(splitter_overlay))
                        right = max(0, min(int(right_pref), max(0, center_total)))
                        center = max(0, center_total - right)
                        splitter_wide = [int(left), int(center), int(right)]
                    except Exception:
                        splitter_wide = []
        else:
            stored_wide = getattr(self, "_last_splitter_wide_sizes", None)
            if isinstance(stored_wide, list) and len(stored_wide) >= 3:
                try:
                    splitter_wide = [max(0, int(v)) for v in stored_wide[:3]]
                except Exception:
                    splitter_wide = []
            stored_overlay = getattr(self, "_last_splitter_overlay_sizes", None)
            if isinstance(stored_overlay, list) and len(stored_overlay) >= 2:
                try:
                    splitter_overlay = [max(0, int(v)) for v in stored_overlay[:2]]
                except Exception:
                    splitter_overlay = []

        view_states: dict[str, str] = {}
        dag_state = None
        try:
            dag_state = getattr(self, "dag_panel", None).get_view_state()  # type: ignore[union-attr]
        except Exception:
            dag_state = None
        if isinstance(dag_state, dict):
            try:
                view_states["edit_dag"] = self._pack_view_state(dag_state, kind="edit_dag")
            except Exception:
                pass

        workflow_state = None
        try:
            workflow_state = getattr(self, "workflow_panel", None).get_view_state()  # type: ignore[union-attr]
        except Exception:
            workflow_state = None
        if isinstance(workflow_state, dict):
            try:
                view_states["workflow_2p5d"] = self._pack_view_state(workflow_state, kind="workflow_2p5d")
            except Exception:
                pass

        realtime_state = None
        try:
            realtime_state = getattr(self, "gl_view", None).get_view_state()  # type: ignore[union-attr]
        except Exception:
            realtime_state = None
        if isinstance(realtime_state, dict):
            try:
                view_states["realtime_3d"] = self._pack_view_state(realtime_state, kind="realtime_3d")
            except Exception:
                pass

        return LayoutState(
            geometry=geometry,
            qt_state=state,
            center_tabs=self._capture_center_tab_layout(),
            splitter_wide=splitter_wide,
            splitter_overlay=splitter_overlay,
            left_hidden=getattr(self, "_left_hidden", False),
            right_hidden=getattr(self, "_right_hidden", False),
            right_overlay_pinned_open=getattr(self, "_right_overlay_pinned_open", False),
            sidebar_last_size=getattr(self, "_sidebar_last_size", None),
            left_last_size=getattr(self, "_left_last_size", None),
            right_last_size=getattr(self, "_right_last_size", None),
            view_states=view_states,
        )

    def _persist_layout_state(self, settings: QSettings) -> None:
        snapshot = self._snapshot_layout_state()
        try:
            settings.setValue(SETTINGS_LAYOUT_JSON_KEY, snapshot.to_json())
        except Exception:
            pass

        if snapshot.geometry is not None:
            try:
                settings.setValue(SETTINGS_GEOMETRY_KEY, QByteArray(snapshot.geometry))
            except Exception:
                pass
        else:
            try:
                settings.setValue(SETTINGS_GEOMETRY_KEY, self.saveGeometry())
            except Exception:
                pass

        if snapshot.qt_state is not None:
            try:
                settings.setValue(SETTINGS_STATE_KEY, QByteArray(snapshot.qt_state))
            except Exception:
                pass
        else:
            try:
                settings.setValue(SETTINGS_STATE_KEY, self.saveState())
            except Exception:
                pass

    def _log_layout_restore(self, message: str) -> None:
        try:
            sys.stderr.write(f"[HelixStudio] {message}\n")
            sys.stderr.flush()
        except Exception:
            pass

    def _restore_continuity_state_from_settings(self) -> None:
        settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
        try:
            layout_state = LayoutState.from_raw(settings.value(SETTINGS_LAYOUT_JSON_KEY, None))
        except Exception:
            layout_state = None

        active_center_tab = getattr(getattr(layout_state, "center_tabs", None), "active", None) if layout_state else None
        if not isinstance(active_center_tab, str) or not active_center_tab:
            try:
                key = settings.value(SETTINGS_CENTER_TAB_KEY, None)
            except Exception:
                key = None
            if isinstance(key, str) and key:
                try:
                    self.open_center_tab(key)
                except Exception:
                    pass

        def _parse_view_state(raw: object) -> dict[str, object] | None:
            if raw is None:
                return None
            if isinstance(raw, Mapping):
                return dict(raw)
            if isinstance(raw, (bytes, bytearray)):
                try:
                    raw = raw.decode("utf-8")
                except Exception:
                    return None
            if isinstance(raw, str) and raw:
                try:
                    parsed = json.loads(raw)
                except Exception:
                    return None
                return dict(parsed) if isinstance(parsed, Mapping) else None
            return None

        views = getattr(layout_state, "view_states", {}) if layout_state is not None else {}

        dag_state_raw = _parse_view_state(views.get("edit_dag")) if isinstance(views, Mapping) and views else None
        if dag_state_raw is None:
            dag_state_raw = self._read_json_setting(settings, SETTINGS_DAG_VIEW_KEY)
        dag_state = self._unpack_view_state(dag_state_raw, kind="edit_dag")
        if dag_state is not None and getattr(self, "dag_panel", None) is not None:
            try:
                self.dag_panel.apply_view_state(dag_state)
            except Exception:
                pass

        workflow_state_raw = _parse_view_state(views.get("workflow_2p5d")) if isinstance(views, Mapping) and views else None
        if workflow_state_raw is None:
            workflow_state_raw = self._read_json_setting(settings, SETTINGS_WORKFLOW_VIEW_KEY)
        workflow_state = self._unpack_view_state(workflow_state_raw, kind="workflow_2p5d")
        if workflow_state is not None and getattr(self, "workflow_panel", None) is not None:
            try:
                self.workflow_panel.apply_view_state(workflow_state)
            except Exception:
                pass

        realtime_state_raw = _parse_view_state(views.get("realtime_3d")) if isinstance(views, Mapping) and views else None
        if realtime_state_raw is None:
            realtime_state_raw = self._read_json_setting(settings, SETTINGS_REALTIME_VIEW_KEY)
        realtime_state = self._unpack_view_state(realtime_state_raw, kind="realtime_3d")
        if realtime_state is not None and getattr(self, "gl_view", None) is not None:
            try:
                self.gl_view.apply_view_state(realtime_state)
            except Exception:
                pass

        # Enable persistence after one-time restoration so defaults/layout
        # seeding doesn't overwrite the user's last active tab.
        self._suspend_center_tab_persistence = False
        self._active_center_tab_key = self._current_center_tab_key()
        self._update_render_activation(self._active_center_tab_key)

    def _save_continuity_state_to_settings(self, settings: QSettings) -> None:
        key = self._current_center_tab_key()
        if key:
            try:
                settings.setValue(SETTINGS_CENTER_TAB_KEY, key)
            except Exception:
                pass

        dag_state = None
        try:
            dag_state = getattr(self, "dag_panel", None).get_view_state()  # type: ignore[union-attr]
        except Exception:
            dag_state = None
        if isinstance(dag_state, dict):
            try:
                settings.setValue(
                    SETTINGS_DAG_VIEW_KEY,
                    self._pack_view_state(dag_state, kind="edit_dag"),
                )
            except Exception:
                pass

        workflow_state = None
        try:
            workflow_state = getattr(self, "workflow_panel", None).get_view_state()  # type: ignore[union-attr]
        except Exception:
            workflow_state = None
        if isinstance(workflow_state, dict):
            try:
                settings.setValue(
                    SETTINGS_WORKFLOW_VIEW_KEY,
                    self._pack_view_state(workflow_state, kind="workflow_2p5d"),
                )
            except Exception:
                pass

        realtime_state = None
        try:
            realtime_state = getattr(self, "gl_view", None).get_view_state()  # type: ignore[union-attr]
        except Exception:
            realtime_state = None
        if isinstance(realtime_state, dict):
            try:
                settings.setValue(
                    SETTINGS_REALTIME_VIEW_KEY,
                    self._pack_view_state(realtime_state, kind="realtime_3d"),
                )
            except Exception:
                pass

    def right_tabs(self):
        return getattr(self, "_right_tabs", None)

    def log_dock(self):
        """Legacy accessor for the bottom console dock."""
        return getattr(self, "_console_dock", getattr(self, "_log_dock", None))

    def console_dock(self):
        """Preferred accessor for the bottom console dock."""
        return getattr(self, "_console_dock", None)

    def _show_terminal(self) -> None:
        if self.terminal_manager is not None:
            self.terminal_manager.show()

    def _new_terminal(self) -> None:
        if self.terminal_manager is not None:
            self.terminal_manager.new_shell()

    def _clear_terminal_scrollback(self) -> None:
        if self.terminal_manager is not None:
            self.terminal_manager.clear_scrollback()

    # ---- Terminal helpers exposed to other UI components --------------
    def open_terminal_here(self, path: Path) -> None:
        """Open a terminal tab rooted at *path* (file -> parent directory)."""
        if self.terminal_manager is None:
            return
        target = path if path.is_dir() else path.parent
        self.terminal_manager.new_shell_here(target)

    def run_selection_in_terminal(self, text: str) -> None:
        if self.terminal_manager is None:
            return
        payload = text.strip("\n")
        if not payload:
            return
        self.terminal_manager.show()
        if self.terminal_manager.panel.tabs.count() == 0:
            self.terminal_manager.new_shell()
        self.terminal_manager.send_text(payload + "\n")

    def run_file_in_terminal(self, path: Path) -> None:
        if self.terminal_manager is None or not path.exists():
            return
        ext = path.suffix.lower()
        if ext == ".py":
            cmd = f"python \"{path}\""
        elif ext == ".sh":
            cmd = f"bash \"{path}\""
        else:
            return
        task = TerminalTask(label=path.name, command=cmd, cwd=self.ctx.project_root if hasattr(self.ctx, "project_root") else None)
        self.terminal_manager.run_task(task)

    def _register_dock(self, dock: QDockWidget) -> None:
        dock.setFeatures(QDockWidget.DockWidgetClosable | QDockWidget.DockWidgetMovable)
        dock.setFloating(False)
        self._docks.append(dock)

    def _on_status_changed(self, message: str) -> None:
        msg = (message or "").strip()
        self._last_status_message = msg or "Ready"
        try:
            self.statusBar().showMessage(message)
        except Exception:
            pass
        try:
            self._update_console_toggle_text()
        except Exception:
            pass

    def _update_console_toggle_text(self) -> None:
        toggle = getattr(self, "_console_toggle", None)
        if toggle is None:
            return
        dock = getattr(self, "_console_dock", None)
        if dock is not None and dock.isVisible():
            toggle.setText("Console")
            return
        status = (getattr(self, "_last_status_message", "") or "Ready").strip() or "Ready"
        if len(status) > 22:
            status = status[:21] + "…"
        toggle.setText(f"Console · {status}")

    def _on_console_visibility_changed(self, visible: bool) -> None:
        toggle = getattr(self, "_console_toggle", None)
        if toggle is not None and toggle.isChecked() != visible:
            toggle.setChecked(bool(visible))
        action = getattr(self, "_toggle_console_action", None)
        if isinstance(action, QAction) and action.isChecked() != visible:
            action.blockSignals(True)
            action.setChecked(bool(visible))
            action.blockSignals(False)
        try:
            self._update_console_toggle_text()
        except Exception:
            pass

    def _restack_docks(self) -> None:
        for dock in self._docks:
            if dock.isFloating():
                dock.setFloating(False)
            dock.raise_()

    def _enqueue_log(self, msg: str) -> None:
        self._log_buffer.append(msg)
        if not self._log_flush_timer.isActive():
            self._log_flush_timer.start()

    def _flush_logs(self) -> None:
        if not self._log_buffer:
            self._log_flush_timer.stop()
            return
        batch = "\n".join(self._log_buffer)
        self._log_buffer.clear()
        cursor = self.log_widget.textCursor()
        cursor.movePosition(QTextCursor.End)
        cursor.insertText(batch + "\n")
        self.log_widget.setTextCursor(cursor)
        self.log_widget.ensureCursorVisible()
        if not self._log_buffer:
            self._log_flush_timer.stop()

    def _flush_pending_snapshots(self) -> None:
        """Emit any queued demo snapshots once listeners are wired up."""
        if not self._pending_snapshots:
            return
        pending = list(self._pending_snapshots)
        self._pending_snapshots.clear()
        for snap in pending:
            try:
                self.session.runRecorded.emit(snap)
            except Exception:
                # Ignore individual failures to keep the UI responsive
                continue

    def _raise_gl_surfaces(self) -> None:
        if self.gl_view is not None:
            self.gl_view.raise_surfaces()
        if hasattr(self, "workflow_panel") and self.workflow_panel is not None:
            self.workflow_panel.raise_surfaces()

    def moveEvent(self, event) -> None:  # type: ignore[override]
        self._restack_docks()
        self._raise_gl_surfaces()
        self._position_sidebar_overlay()
        return super().moveEvent(event)

    def changeEvent(self, event) -> None:  # type: ignore[override]
        if event.type() in (QEvent.WindowStateChange, QEvent.ScreenChangeInternal):
            self._restack_docks()
            self._raise_gl_surfaces()
            self._position_sidebar_overlay()
            if event.type() == QEvent.WindowStateChange and self.isMaximized():
                self._clamp_oversized_maximized()
            if event.type() == QEvent.WindowStateChange:
                self._update_window_controls()
        if event.type() in (QEvent.WindowActivate, QEvent.WindowDeactivate):
            self._set_topbar_active(event.type() == QEvent.WindowActivate)
        if event.type() == QEvent.Show:
            self._set_topbar_active(self.isActiveWindow())
            # Restoring window geometry before the native frame is realized can
            # leave the *frame* size offscreen (client area fits, decorations
            # push it over). Clamp once after show so tests/offscreen platforms
            # restore to a recoverable window.
            try:
                if getattr(self, "_restored_geometry", False):
                    QTimer.singleShot(0, lambda: ensure_on_screen(self))
            except Exception:
                pass
        return super().changeEvent(event)

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        self._update_layout_mode()
        self._position_sidebar_button_bar()
        self._position_sidebar_overlay()
        return super().resizeEvent(event)

    def _create_menus(self) -> None:
        menu = self._menu_host().addMenu("&File")
        self.menuFile = menu

        import_menu = self._menu_host().addMenu("&Import")
        self._menu_import = import_menu
        self.actionImportCrispresso = QAction("CRISPResso…", self)
        self.actionImportAmpseq = QAction("AMP-seq…", self)
        self.actionImportBam = QAction("BAM…", self)
        import_menu.addAction(self.actionImportCrispresso)
        import_menu.addAction(self.actionImportAmpseq)
        import_menu.addAction(self.actionImportBam)

        self.actionOpenDemo = QAction("Open CRISPR demo", self)
        self.actionOpenDemo.triggered.connect(self._on_open_demo_session)
        menu.addAction(self.actionOpenDemo)

        self.actionOpenPrimeDemo = QAction("Open prime demo", self)
        self.actionOpenPrimeDemo.setShortcut(QKeySequence("Ctrl+Alt+P"))
        self.actionOpenPrimeDemo.triggered.connect(self._on_open_prime_demo_session)
        menu.addAction(self.actionOpenPrimeDemo)

        self.actionExportEvidence = QAction("Export VeriBiota evidence…", self)
        self.actionExportEvidence.triggered.connect(self._on_export_evidence)
        menu.addAction(self.actionExportEvidence)

        open_preset_act = QAction("Open experiment preset…", self)
        open_preset_act.setShortcut(QKeySequence("Ctrl+Shift+E"))
        open_preset_act.triggered.connect(self._open_preset_dialog)
        menu.addAction(open_preset_act)

        save_preset_act = QAction("Save experiment as preset…", self)
        save_preset_act.setShortcut(QKeySequence("Ctrl+Alt+S"))
        save_preset_act.triggered.connect(self._save_experiment_preset)
        menu.addAction(save_preset_act)

        self.actionSaveSession = QAction("Save session…", self)
        self.actionSaveSession.triggered.connect(self._on_save_session)
        menu.addAction(self.actionSaveSession)

        self.actionOpenSession = QAction("Open session…", self)
        self.actionOpenSession.triggered.connect(self._on_open_session)
        menu.addAction(self.actionOpenSession)

        self._recent_sessions_menu = menu.addMenu("Open Recent Session")
        self._rebuild_recent_sessions_menu()

        self.actionImportCrispresso.triggered.connect(self._import_crispresso)
        self.actionImportAmpseq.triggered.connect(self._import_ampseq)
        self.actionImportBam.triggered.connect(self._import_bam)

        new_proj = menu.addAction("New Project…")
        new_proj.triggered.connect(self._new_project)
        open_proj = menu.addAction("Open Project…")
        open_proj.triggered.connect(self._open_project)

        recent_menu = menu.addMenu("Open Recent")
        self._recent_menu = recent_menu
        self._rebuild_recent_menu()


        menu.addSeparator()

        save_action = menu.addAction("Save Session…")
        save_action.triggered.connect(self._save_session)
        save_action.setShortcut(QKeySequence("Ctrl+S"))
        save_as_action = menu.addAction("Save Session As…")
        save_as_action.triggered.connect(self._save_session)
        save_as_action.setShortcut(QKeySequence("Ctrl+Shift+S"))
        load_action = menu.addAction("Load Session…")
        load_action.triggered.connect(self._load_session)
        load_action.setShortcut(QKeySequence("Ctrl+O"))

        menu.addSeparator()
        self._make_open_folder_actions(menu)
        self._make_helixspec_actions(menu)

        view_menu = self._menu_host().addMenu("&View")
        self._menu_view = view_menu
        reset_action = QAction("Reset layout", self)
        reset_action.triggered.connect(self.reset_layout_to_defaults)
        view_menu.addAction(reset_action)

        theme_menu = view_menu.addMenu("Theme")
        self._theme_actions.clear()
        current_theme = current_theme_name(QApplication.instance())
        theme_names = token_theme_names() or [t.name for t in available_themes()]
        for name in theme_names:
            label = _display_name(name)
            act = QAction(label, self, checkable=True)
            act.setData(name)
            act.setChecked(name == current_theme)
            act.triggered.connect(lambda checked=False, n=name: self._on_theme_selected(n))
            theme_menu.addAction(act)
            self._theme_actions[name] = act

        genome_reset = QAction("Reset to Genome IDE default", self)
        genome_reset.triggered.connect(lambda: self.apply_layout_preset("genome_ide"))
        view_menu.addAction(genome_reset)

        # Panel toggles
        toggle_builder = QAction("Show Sim Builder", self, checkable=True)
        toggle_builder.setChecked(True)
        toggle_builder.toggled.connect(lambda checked: self._set_left_visible(checked))
        view_menu.addAction(toggle_builder)

        toggle_sidebar = QAction("Show Sidebar (Session/Guides/Compare)", self, checkable=True)
        toggle_sidebar.setChecked(True)
        toggle_sidebar.toggled.connect(lambda checked: self._set_right_visible(checked))
        view_menu.addAction(toggle_sidebar)

        toggle_console = QAction("Show Console", self, checkable=True)
        toggle_console.setChecked(False)
        toggle_console.toggled.connect(lambda checked: self._show_console_dock(default_only=False) if checked else self._hide_console_dock())
        view_menu.addAction(toggle_console)
        self._toggle_console_action = toggle_console

        view_menu.addSeparator()

        exports_menu = view_menu.addMenu("Exports")
        write_sidecars_act = QAction("Write image provenance sidecars (*.png.provenance.json)", self, checkable=True)
        write_sidecars_act.setChecked(write_image_provenance_sidecars_enabled(settings=self._settings))
        write_sidecars_act.toggled.connect(
            lambda checked: set_write_image_provenance_sidecars_enabled(bool(checked), settings=self._settings)
        )
        if is_enterprise_build():
            # Enterprise builds enforce audit-grade exports.
            set_write_image_provenance_sidecars_enabled(True, settings=self._settings)
            write_sidecars_act.setChecked(True)
            write_sidecars_act.setEnabled(False)
            write_sidecars_act.setToolTip("Enterprise builds always write image provenance sidecars.")
        exports_menu.addAction(write_sidecars_act)
        self._write_image_sidecars_action = write_sidecars_act

        plugin_panels_menu = view_menu.addMenu("Plugin Panels")
        self._menu_plugin_panels = plugin_panels_menu

        # Focus mode: hide sidebars/console and give full space to outcomes
        focus_action = QAction("Outcomes Focus Mode", self, checkable=True)
        focus_action.setShortcut("F11")
        focus_action.toggled.connect(self._set_focus_mode)
        view_menu.addAction(focus_action)
        # Register as a global action for shortcut handling even when menu not open
        self.addAction(focus_action)
        self._focus_action = focus_action

        clone_action = QAction("Clone run to Builder", self)
        clone_action.setShortcut("Ctrl+Shift+C")
        clone_action.triggered.connect(self._clone_current_run_to_builder)
        view_menu.addAction(clone_action)

        home_action = QAction("Start panel", self)
        home_action.setShortcut(QKeySequence("Ctrl+Shift+H"))
        home_action.triggered.connect(self._show_start_panel)
        view_menu.addAction(home_action)

        self.actionOpenLightcone = QAction("Lightcone", self)
        self.actionOpenLightcone.setShortcut(QKeySequence("Ctrl+Alt+L"))
        self.actionOpenLightcone.triggered.connect(self._open_lightcone_view)
        view_menu.addAction(self.actionOpenLightcone)
        # Ensure shortcut works even when menu bar is hidden (compact mode).
        self.addAction(self.actionOpenLightcone)

        presets_menu = view_menu.addMenu("Layout preset")
        for key, label in (("analysis", "Analysis"), ("simulation", "Simulation"), ("reporting", "Reporting"), ("genome_ide", "Genome IDE")):
            act = QAction(label, self)
            act.triggered.connect(lambda checked=False, k=key: self.apply_layout_preset(k))
            presets_menu.addAction(act)

        # Debug overlay: optional viewer perf HUD (FPS / frame time).
        self._viewer_perf_hud_action = QAction("Show Viewer Performance HUD", self, checkable=True)
        env_default = False
        env = os.getenv("HELIX_VIEWER_PERF_HUD")
        if env is not None:
            env_default = env.strip().lower() in {"1", "true", "yes", "on"}
        try:
            settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
            self._viewer_perf_hud_action.setChecked(bool(settings.value(SETTINGS_VIEWER_PERF_HUD_KEY, env_default)))
        except Exception:
            self._viewer_perf_hud_action.setChecked(env_default)
        self._viewer_perf_hud_action.setEnabled(bool(self._enable_gl))
        self._viewer_perf_hud_action.toggled.connect(self._on_toggle_viewer_perf_hud)
        view_menu.addAction(self._viewer_perf_hud_action)

        # Toggle for PAM seed lane
        self._pam_seed_action = QAction("Show PAM seed field", self, checkable=True)
        self._pam_seed_action.setChecked(True)
        self._pam_seed_action.toggled.connect(self._on_toggle_pam_seed)
        view_menu.addAction(self._pam_seed_action)

        self._indel_risk_action = QAction("Show Indel risk field", self, checkable=True)
        self._indel_risk_action.setChecked(False)
        self._indel_risk_action.toggled.connect(self._on_toggle_indel_risk)
        view_menu.addAction(self._indel_risk_action)

        self._offtarget_action = QAction("Show Off-target density field", self, checkable=True)
        self._offtarget_action.setChecked(False)
        self._offtarget_action.toggled.connect(self._on_toggle_offtarget)
        view_menu.addAction(self._offtarget_action)

        self._gc_action = QAction("Show GC / homopolymer field", self, checkable=True)
        self._gc_action.setChecked(False)
        self._gc_action.toggled.connect(self._on_toggle_gc)
        view_menu.addAction(self._gc_action)

        self._dcas_action = QAction("Show dCas9 occupancy field", self, checkable=True)
        self._dcas_action.setChecked(False)
        self._dcas_action.toggled.connect(self._on_toggle_dcas)
        view_menu.addAction(self._dcas_action)

        self._composite_action = QAction("Show Editability/Safety field", self, checkable=True)
        self._composite_action.setChecked(False)
        self._composite_action.toggled.connect(self._on_toggle_composite)
        view_menu.addAction(self._composite_action)

        # Toggle for Prime DP lane
        self._prime_dp_action = QAction("Show Prime DP field", self, checkable=True)
        self._prime_dp_action.setChecked(True)
        self._prime_dp_action.toggled.connect(self._on_toggle_prime_dp)
        view_menu.addAction(self._prime_dp_action)

        tools_menu = self._menu_host().addMenu("&Tools")
        self._menu_tools = tools_menu

        command_palette = QAction("Command Palette…", self)
        command_palette.setShortcut(QKeySequence("Ctrl+Shift+P"))
        command_palette.triggered.connect(self._open_command_palette)
        tools_menu.addAction(command_palette)
        # Ensure shortcut works even when menu bar is hidden (compact mode).
        self.addAction(command_palette)
        tools_menu.addSeparator()

        open_terminal = QAction("Terminal", self)
        open_terminal.setShortcut(QKeySequence("Ctrl+`"))
        open_terminal.triggered.connect(self._show_terminal)
        tools_menu.addAction(open_terminal)

        new_terminal = QAction("New Terminal Tab", self)
        new_terminal.setShortcut(QKeySequence("Ctrl+Shift+`"))
        new_terminal.triggered.connect(self._new_terminal)
        tools_menu.addAction(new_terminal)

        clear_terminal = QAction("Clear Terminal Scrollback", self)
        clear_terminal.setShortcut(QKeySequence("Ctrl+Shift+L"))
        clear_terminal.triggered.connect(self._clear_terminal_scrollback)
        tools_menu.addAction(clear_terminal)

        tools_menu.addSeparator()
        plugins_menu = tools_menu.addMenu("Plugins")
        manage_plugins = QAction("Plugins…", self)
        manage_plugins.triggered.connect(self._show_plugins_dialog)
        plugins_menu.addAction(manage_plugins)
        plugins_menu.addSeparator()

        reload_plugins = QAction("Reload plugins (soft)", self)
        reload_plugins.triggered.connect(self._reload_plugins)
        plugins_menu.addAction(reload_plugins)

        restart_plugins = QAction("Restart Studio (clean reload)", self)
        restart_plugins.triggered.connect(self._restart_studio_clean)
        plugins_menu.addAction(restart_plugins)

        plugins_menu.addSeparator()
        open_plugins_folder = QAction("Open plugins folder", self)
        open_plugins_folder.triggered.connect(self._open_plugins_folder)
        plugins_menu.addAction(open_plugins_folder)

        help_menu = self._menu_host().addMenu("&Help")
        self._menu_help = help_menu
        shortcuts_action = help_menu.addAction("Keyboard Shortcuts")
        shortcuts_action.triggered.connect(self._show_shortcuts_dialog)
        prime_demo_action = help_menu.addAction("Open Prime demo")
        prime_demo_action.triggered.connect(self._on_open_prime_demo_session)

        help_menu.addSeparator()
        doctor_action = help_menu.addAction("Run doctor…")
        doctor_action.triggered.connect(self._on_run_doctor)
        support_bundle_action = help_menu.addAction("Export support bundle…")
        support_bundle_action.triggered.connect(self._on_export_support_bundle)
        help_menu.addSeparator()
        about_action = help_menu.addAction("About Helix Studio…")
        about_action.triggered.connect(self._on_show_about)

        self._register_core_commands_once()

    def _on_toggle_pam_seed(self, enabled: bool) -> None:
        try:
            if hasattr(self, "gl_view") and self.gl_view is not None:
                self.gl_view.set_pam_seed_enabled(enabled)
        except Exception:
            pass

    def _on_toggle_viewer_perf_hud(self, enabled: bool) -> None:
        try:
            self._settings.setValue(SETTINGS_VIEWER_PERF_HUD_KEY, bool(enabled))
        except Exception:
            pass
        try:
            if hasattr(self, "gl_view") and self.gl_view is not None:
                self.gl_view.set_perf_hud_enabled(enabled)
        except Exception:
            pass

    def _on_toggle_prime_dp(self, enabled: bool) -> None:
        try:
            if hasattr(self, "gl_view") and self.gl_view is not None and hasattr(self.gl_view, "set_prime_dp_enabled"):
                self.gl_view.set_prime_dp_enabled(enabled)
        except Exception:
            pass

    def _on_toggle_indel_risk(self, enabled: bool) -> None:
        try:
            if hasattr(self, "gl_view") and self.gl_view is not None and hasattr(self.gl_view, "set_indel_risk_enabled"):
                self.gl_view.set_indel_risk_enabled(enabled)
        except Exception:
            pass

    def _on_toggle_offtarget(self, enabled: bool) -> None:
        try:
            if hasattr(self, "gl_view") and self.gl_view is not None and hasattr(self.gl_view, "set_offtarget_enabled"):
                self.gl_view.set_offtarget_enabled(enabled)
        except Exception:
            pass

    def _on_toggle_composite(self, enabled: bool) -> None:
        try:
            if hasattr(self, "gl_view") and self.gl_view is not None and hasattr(self.gl_view, "set_composite_enabled"):
                self.gl_view.set_composite_enabled(enabled)
        except Exception:
            pass

    def _on_toggle_gc(self, enabled: bool) -> None:
        try:
            if hasattr(self, "gl_view") and self.gl_view is not None and hasattr(self.gl_view, "set_gc_enabled"):
                self.gl_view.set_gc_enabled(enabled)
        except Exception:
            pass

    def _on_toggle_dcas(self, enabled: bool) -> None:
        try:
            if hasattr(self, "gl_view") and self.gl_view is not None and hasattr(self.gl_view, "set_dcas_enabled"):
                self.gl_view.set_dcas_enabled(enabled)
        except Exception:
            pass
    def _save_session(self) -> None:
        path_str, _ = QFileDialog.getSaveFileName(
            self,
            "Save Helix Session",
            filter="Helix Session (*.helix.json);;JSON (*.json)",
        )
        if not path_str:
            return
        path = Path(path_str)
        payload = self.session.to_payload()

        def _work():
            tmp = path.with_suffix(path.suffix + ".tmp")
            text = json.dumps(payload, indent=2)
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp.write_text(text, encoding="utf-8")
            os.replace(tmp, path)
            return str(path)

        def _ok(msg: str) -> None:
            self.session.set_status(f"Saved session to {msg}")

        def _err(tb: str) -> None:
            self._show_error(f"Failed to save session: {tb}")

        run_bg(_work, _ok, _err, label="save_session", token=self._load_token)

    def _load_session(self) -> None:
        path_str, _ = QFileDialog.getOpenFileName(
            self,
            "Load Helix Session",
            filter="Helix Session (*.helix.json);;JSON (*.json)",
        )
        if not path_str:
            return
        path = Path(path_str)
        self._load_token.bump()

        def _work():
            with perf_section("load_session.read", warn_ms=50, error_ms=200):
                return json.loads(path.read_text(encoding="utf-8"))

        def _ok(payload):
            try:
                payload["viz_dirty"] = True
                self.session.load_payload(payload)
            except Exception as exc:
                self._show_error(f"Failed to restore session: {exc}")
                return
            self.session.set_status(f"Loaded session from {path}")

        def _err(tb: str) -> None:
            self._show_error(f"Failed to load session: {tb}")

        run_bg(_work, _ok, _err, label="load_session", token=self._load_token)

    # -------- Snapshot handling --------
    def _on_run_recorded(self, snapshot: Mapping[str, object]) -> None:
        """Persist snapshots/reports under the project and register them."""

        state = snapshot.get("state") if isinstance(snapshot, Mapping) else None
        if not isinstance(state, Mapping):
            return
        run_id = str(state.get("run_id") or "run")
        run_kind = str(state.get("run_kind") or "run").lower()

        snap_dir = default_snapshot_dir(self.ctx.project_root)
        rep_dir = default_report_dir(self.ctx.project_root)
        try:
            snap_dir.mkdir(parents=True, exist_ok=True)
            rep_dir.mkdir(parents=True, exist_ok=True)
        except PermissionError as exc:
            self.session.log(f"PermissionError creating artifacts under {self.ctx.project_root}: {exc}")
            self._show_error(
                "Helix Studio cannot write project artifacts.\n\n"
                f"Project root: {self.ctx.project_root}\n"
                f"Attempted: {snap_dir.parent}\n\n"
                "Fix: choose a writable project directory via File → New Project or Open Project."
            )
            return
        except Exception as exc:  # pragma: no cover - unexpected IO failure
            self._show_error(f"Failed to create snapshot/report directories: {exc}")
            return

        snap_path = snap_dir / f"{run_kind}_{run_id}.json"
        report_path = rep_dir / f"{run_kind}_{run_id}_report.json"
        evs_path = snap_dir / f"{run_id}.v1.1.evs.json"
        self._pending_focus_run_id = str(run_id)

        # Snapshot/report generation can be expensive (large payloads, JSON encoding,
        # report computation). Keep the UI responsive by running IO on a worker thread.
        payload = dict(snapshot) if isinstance(snapshot, Mapping) else {}

        def _work() -> dict[str, object]:
            result: dict[str, object] = {
                "run_id": str(run_id),
                "run_kind": str(run_kind),
                "snap_path": str(snap_path),
                "report_path": str(report_path),
                "evs_path": str(evs_path),
                "evs_error": None,
            }
            normalized = _ensure_contract_identity(dict(payload))
            Path(snap_path).write_text(json.dumps(normalized, indent=2), encoding="utf-8")

            # Report is optional; failures should not block recording.
            try:
                report_payload = build_report(normalized)
                Path(report_path).write_text(json.dumps(report_payload, indent=2), encoding="utf-8")
            except Exception as exc:
                result["report_error"] = str(exc)

            evs_payload: dict[str, object] | None = None
            try:
                evs_payload = _snapshot_to_evs(normalized, run_id=str(run_id))
                evs_payload = _ensure_contract_identity(evs_payload)
                Path(evs_path).write_text(json.dumps(evs_payload, indent=2), encoding="utf-8")
                result["evs_payload"] = evs_payload
            except Exception as exc:
                result["evs_error"] = str(exc)
            return result

        def _ok(result: dict[str, object]) -> None:
            snap_path_res = Path(str(result.get("snap_path") or snap_path))
            report_path_res = Path(str(result.get("report_path") or report_path))
            evs_payload = result.get("evs_payload") if isinstance(result.get("evs_payload"), dict) else None
            report_error = result.get("report_error")
            if report_error:
                self.session.log(f"Warning: could not write report for run {run_id}: {report_error}")
            evs_error = result.get("evs_error")
            if evs_error:
                self.session.log(f"Warning: could not write EVS for run {run_id}: {evs_error}")
            self.project.register_snapshot(
                snapshot_id=run_id,
                path=snap_path_res,
                session_id=str(state.get("run_id") or run_id),
                run_kind=state.get("run_kind"),
            )
            self.project.save()
            self._update_project_status()
            try:
                self._set_rail_state("outcome_model", CacheState.CLEAN)
                self._set_rail_state("evidence", CacheState.CLEAN)
            except Exception:
                pass
            try:
                self._finalize_recompute_cache_state()
            except Exception:
                pass
            self._emit_plugin_event(
                "core.run.recorded",
                {
                    "run_id": str(run_id),
                    "run_kind": str(state.get("run_kind") or ""),
                    "snapshot_path": str(snap_path_res),
                    "report_path": str(report_path_res),
                    "project_root": str(self.ctx.project_root),
                },
            )

            # Focus the UI on the newest completed run (avoid out-of-order IO).
            try:
                if self._pending_focus_run_id == str(run_id):
                    if isinstance(evs_payload, dict):
                        # A newly recorded run should update panels in-place without
                        # forcing a full layout preset (which feels like an app reload).
                        self._activate_evs_payload(
                            evs_payload,
                            run_id=str(run_id),
                            apply_layout_preset=False,
                            focus_sidebars=False,
                        )
                    elif not evs_error:
                        evs_disk = load_evs_for_run(self.project.root_path, str(run_id))
                        if isinstance(evs_disk, dict):
                            self._activate_evs_payload(
                                evs_disk,
                                run_id=str(run_id),
                                apply_layout_preset=False,
                                focus_sidebars=False,
                            )
                        else:
                            self.on_run_activated(str(run_id))
            except Exception:
                pass
            try:
                self.statusBar().showMessage(f"Run {run_id} recorded. Press ↑/↓ to browse runs.", 5000)
            except Exception:
                pass
            self._refresh_run_timeline()

        def _err(tb: str) -> None:
            self._show_error(f"Failed to write snapshot artifacts for run {run_id}:\n\n{tb}")

        run_bg(_work, _ok, _err, label="run_record", token=None)

    # -------- Project management --------
    def _new_project(self) -> None:
        root_str = QFileDialog.getExistingDirectory(self, "Select Project Directory")
        if not root_str:
            return
        root = Path(root_str)
        project = ProjectModel(root_path=root, name=root.name)
        project.save()
        self._switch_project(project)

    def _open_project(self) -> None:
        root_str = QFileDialog.getExistingDirectory(self, "Open Project")
        if not root_str:
            return
        root = Path(root_str)
        meta = root / ".helix_project.json"
        if not meta.exists():
            self._show_error(f"No .helix_project.json found in {root}")
            return
        try:
            project = ProjectModel.load(root)
        except Exception as exc:
            self._show_error(f"Failed to load project: {exc}")
            return
        self._switch_project(project)

    def _switch_project(self, project: ProjectModel) -> None:
        self.project = project
        try:
            self.ctx.project = project
        except Exception:
            pass
        self.setWindowTitle(f"Helix Studio – {self.project.name}")
        self._update_project_status()
        self._remember_project(self.project.root_path)
        self._emit_plugin_event(
            "core.project.opened",
            {
                "name": self.project.name,
                "root": str(self.project.root_path),
            },
        )

    def _remember_project(self, path: Path) -> None:
        paths = self._settings.value("recentProjects", [])
        if not isinstance(paths, list):
            paths = []
        path_str = str(path)
        if path_str in paths:
            paths.remove(path_str)
        paths.insert(0, path_str)
        self._settings.setValue("recentProjects", paths[:10])
        self._rebuild_recent_menu()

    def _update_project_status(self) -> None:
        from helix.config import native_backend_available

        msg = f"Project: {self.project.name} — {self.project.root_path}"
        if any(ref.external for ref in self.project.snapshots.values()) or any(
            ref.external for ref in self.project.imported_runs.values()
        ):
            msg += "  [external artifacts present]"
        native_status = "native backend: available" if native_backend_available() else "native backend: missing"
        msg += f"  |  {native_status}"
        self.statusBar().showMessage(msg)

    # -------- Open folders --------
    def _make_open_folder_actions(self, menu) -> None:
        self.actionOpenArtifacts = menu.addAction("Open Artifacts Folder")
        self.actionOpenSnapshots = menu.addAction("Open Snapshots Folder")
        self.actionOpenReports = menu.addAction("Open Reports Folder")

        self.actionOpenArtifacts.triggered.connect(self._open_artifacts_folder)
        self.actionOpenSnapshots.triggered.connect(self._open_snapshots_folder)
        self.actionOpenReports.triggered.connect(self._open_reports_folder)

    def _open_folder(self, path: Path) -> None:
        path.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def _open_artifacts_folder(self) -> None:
        self._open_folder(self.ctx.project_root / "artifacts")

    def _open_snapshots_folder(self) -> None:
        self._open_folder(default_snapshot_dir(self.ctx.project_root))

    def _open_reports_folder(self) -> None:
        self._open_folder(default_report_dir(self.ctx.project_root))

    def _make_helixspec_actions(self, menu) -> None:
        self.actionOpenHelixSpecBundle = menu.addAction("Open HelixSpec Run Folder")
        self.actionOpenHelixSpecBundle.triggered.connect(self._open_last_helixspec_bundle)
        self.actionOpenHelixSpecBundle.setEnabled(False)

    def _open_last_helixspec_bundle(self) -> None:
        path = self._last_helixspec_run_dir
        if path is None:
            QMessageBox.information(self, "HelixSpec", "No HelixSpec run has been executed yet.")
            return
        self._open_folder(path)

    def _restore_last_helixspec_bundle_from_config(self) -> None:
        try:
            cfg = getattr(self.session.state, "config", {})
            path_str = cfg.get("helixspec_last_bundle")
            if path_str:
                p = Path(path_str)
                if p.exists():
                    self._last_helixspec_run_dir = p
        except Exception:
            pass

    def _restore_last_helixspec_bundle_menu_state(self) -> None:
        try:
            if self._last_helixspec_run_dir and self._last_helixspec_run_dir.exists():
                self.actionOpenHelixSpecBundle.setEnabled(True)
                try:
                    self._helixspec_editor.set_last_bundle(self._last_helixspec_run_dir)
                except Exception:
                    pass
        except Exception:
            pass

    # -------- Restore imported runs --------
    def _restore_imported_runs(self) -> None:
        project = self.project
        history = self.history_widget
        root = project.root_path
        for run_id, ref in project.imported_runs.items():
            try:
                importer = get_importer(ref.source)
            except Exception:
                history.add_imported_snapshot(
                    {
                        "version": 0,
                        "imported": True,
                        "import_origin": ref.source,
                        "state": {
                            "run_kind": ref.kind,
                            "run_kind_key": ref.kind,
                            "run_id": run_id,
                            "viz_dirty": False,
                            "config": {"import_origin": ref.source},
                            "outcomes": [],
                            "genome_source": "imported",
                            "genome": {},
                            "label": ref.name,
                        },
                        "timestamp": _now_iso(),
                        "import_metrics": {},
                        "raw_path": str(ref.rel_path),
                        "status": "missing_importer",
                    }
                )
                continue

            raw_path = root / ref.rel_path
            if ref.external:
                raw_path = Path(ref.rel_path)
            if not raw_path.exists():
                history.add_imported_snapshot(
                    {
                        "version": 0,
                        "imported": True,
                        "import_origin": ref.source,
                        "state": {
                            "run_kind": ref.kind,
                            "run_kind_key": ref.kind,
                            "run_id": run_id,
                            "viz_dirty": False,
                            "config": {"import_origin": ref.source},
                            "outcomes": [],
                            "genome_source": "imported",
                            "genome": {},
                            "label": ref.name,
                        },
                        "timestamp": _now_iso(),
                        "import_metrics": {},
                        "raw_path": str(raw_path),
                        "status": "missing",
                    }
                )
                continue
            try:
                imported = importer(raw_path)
                snapshot = imported_run_to_snapshot(imported, run_id=int(run_id))
                history.add_imported_snapshot(snapshot)
            except Exception:
                history.add_imported_snapshot(
                    {
                        "version": 0,
                        "imported": True,
                        "import_origin": ref.source,
                        "state": {
                            "run_kind": ref.kind,
                            "run_kind_key": ref.kind,
                            "run_id": run_id,
                            "viz_dirty": False,
                            "config": {"import_origin": ref.source},
                            "outcomes": [],
                            "genome_source": "imported",
                            "genome": {},
                            "label": ref.name,
                        },
                        "timestamp": _now_iso(),
                        "import_metrics": {},
                        "raw_path": str(raw_path),
                        "status": "import_error",
                    }
                )

    def open_outcome_for_analysis(self, analysis_id: str) -> None:
        try:
            explorer = getattr(self.workflow_panel, "_explorer", None)
            if explorer and hasattr(explorer, "load_analysis"):
                explorer.load_analysis(analysis_id)
                return
        except Exception:
            pass
        QMessageBox.information(self, "Analysis", f"Open analysis {analysis_id}")

    # -------- Importers --------
    def _import_crispresso(self) -> None:
        dir_path = QFileDialog.getExistingDirectory(self, "Select CRISPResso Run Directory")
        if not dir_path:
            return
        self._run_import("crispresso", Path(dir_path))

    def _import_ampseq(self) -> None:
        dir_path = QFileDialog.getExistingDirectory(self, "Select AMP-seq Run Directory")
        if not dir_path:
            return
        self._run_import("ampseq", Path(dir_path))

    def _import_bam(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(self, "Select BAM File", filter="BAM Files (*.bam)")
        if not file_path:
            return
        self._run_import("bam", Path(file_path))

    def _run_import(self, kind: str, path: Path) -> None:
        try:
            importer = get_importer(kind)
        except ImportFailed as exc:
            QMessageBox.critical(self, "Import error", str(exc))
            return

        try:
            imported = importer(path)
        except ImportFailed as exc:
            QMessageBox.warning(self, "Import failed", str(exc))
            return
        except Exception as exc:  # pragma: no cover - unexpected errors
            QMessageBox.critical(self, "Import error", f"Unexpected error: {exc}")
            return

        # Add to in-memory history and persist in project
        run_id = len(self.history_widget._snapshots) + 1  # re-use existing counter behavior
        snapshot = imported_run_to_snapshot(imported, run_id=run_id)
        self.history_widget.add_imported_snapshot(snapshot)
        
        self._register_import_in_project(str(run_id), imported)
        self.project.save()

        self._show_imported_run(imported)

    def _register_import_in_project(self, run_id: str, imported) -> None:
        project = self.ctx.project
        project.register_imported_run(
            run_id,
            kind=imported.kind.name,
            source=imported.source,
            raw_path=imported.raw_dir,
            name=imported.name,
        )

    def _show_imported_run(self, imported) -> None:
        from PySide6.QtWidgets import QDialog, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem

        dlg = QDialog(self)
        dlg.setWindowTitle(f"Imported run: {imported.name} [{imported.source}]")
        layout = QVBoxLayout(dlg)

        info = QLabel(f"Kind: {imported.kind.name}  |  Source: {imported.source}\nPath: {imported.raw_dir}")
        layout.addWidget(info)

        metrics = imported.metrics or {}
        table = QTableWidget(len(metrics), 2, dlg)
        table.setHorizontalHeaderLabels(["Metric", "Value"])
        for row, (key, value) in enumerate(metrics.items()):
            table.setItem(row, 0, QTableWidgetItem(str(key)))
            table.setItem(row, 1, QTableWidgetItem(f"{value}"))
        layout.addWidget(table)

        dlg.setLayout(layout)
        dlg.resize(500, 400)
        dlg.exec()

    def _rebuild_recent_menu(self) -> None:
        if not hasattr(self, "_recent_menu"):
            return
        self._recent_menu.clear()
        paths = self._settings.value("recentProjects", [])
        if not isinstance(paths, list):
            paths = []
        for path_str in paths:
            action = self._recent_menu.addAction(path_str)
            action.triggered.connect(lambda checked=False, p=path_str: self._open_recent(p))

    def _rebuild_recent_sessions_menu(self) -> None:
        if not hasattr(self, "_recent_sessions_menu"):
            return
        self._recent_sessions_menu.clear()
        paths = self._settings.value("recentSessions", [])
        if not isinstance(paths, list):
            paths = []
        for path_str in paths:
            action = self._recent_sessions_menu.addAction(path_str)
            action.triggered.connect(lambda checked=False, p=path_str: self._open_recent_session(p))

    def _remember_recent_session(self, path_str: str) -> None:
        paths = self._settings.value("recentSessions", [])
        if not isinstance(paths, list):
            paths = []
        # move to front, de-dup
        paths = [p for p in paths if p != path_str]
        paths.insert(0, path_str)
        paths = paths[:5]
        self._settings.setValue("recentSessions", paths)
        self._rebuild_recent_sessions_menu()

    def _forget_recent_session(self, path_str: str) -> None:
        paths = self._settings.value("recentSessions", [])
        if not isinstance(paths, list):
            paths = []
        paths = [p for p in paths if p != path_str]
        self._settings.setValue("recentSessions", paths)
        self._rebuild_recent_sessions_menu()

    def _open_recent_session(self, path_str: str) -> None:
        path = Path(path_str)
        if not path.exists():
            self.statusBar().showMessage(f"Recent session missing: {path}", 5000)
            self._forget_recent_session(path_str)
            return
        try:
            import json

            raw = json.loads(path.read_text(encoding="utf8"))
            self.session.load_payload(raw)
            try:
                self._prefill_sim_builder(self.session.to_payload())
            except Exception:
                pass
            self._remember_recent_session(str(path))
            rows = build_guide_summaries_from_session(self.session)
            if hasattr(self, "guide_inspector"):
                self.guide_inspector.set_guide_rows(rows)
                if rows:
                    self.guide_inspector.table.selectRow(0)
            self.statusBar().showMessage(f"Loaded session from {path}", 4000)
        except Exception as exc:
            self.statusBar().showMessage(f"Failed to load session from {path}: {exc}", 6000)

    def _open_recent(self, path_str: str) -> None:
        root = Path(path_str)
        meta = root / ".helix_project.json"
        if not meta.exists():
            self._show_error(f"Recent project missing: {root}")
            return
        try:
            project = ProjectModel.load(root)
        except Exception as exc:
            self._show_error(f"Failed to load project: {exc}")
            return
        self._switch_project(project)

    def _show_error(self, message: str) -> None:
        self._show_console_dock(default_only=False)
        QMessageBox.critical(self, "Helix Studio", message)

    def _setup_shortcuts(self) -> None:
        self._shortcuts: list[QShortcut] = []
        rerun = QShortcut(QKeySequence("Ctrl+R"), self)
        rerun.activated.connect(self._rerun_active_sim)
        self._shortcuts.append(rerun)
        for i in range(1, 10):
            shortcut = QShortcut(QKeySequence(f"Ctrl+{i}"), self)
            shortcut.activated.connect(lambda pos=i - 1: self._select_history_position(pos))
            self._shortcuts.append(shortcut)
        zero_shortcut = QShortcut(QKeySequence("Ctrl+0"), self)
        zero_shortcut.activated.connect(lambda: self._select_history_position(9))
        self._shortcuts.append(zero_shortcut)

        demo_shortcut = QShortcut(QKeySequence("Ctrl+D"), self)
        demo_shortcut.activated.connect(lambda: getattr(self, "_center_panel", None) and self._center_panel._on_open_demo_clicked())
        self._shortcuts.append(demo_shortcut)

        latest_shortcut = QShortcut(QKeySequence("Ctrl+L"), self)
        latest_shortcut.activated.connect(lambda: getattr(self, "_center_panel", None) and self._center_panel._on_open_latest_clicked())
        self._shortcuts.append(latest_shortcut)

    def _open_command_palette(self) -> None:
        try:
            from .command_palette import CommandPaletteDialog
        except Exception as exc:
            try:
                self.statusBar().showMessage(f"Command palette unavailable: {exc}", 5000)
            except Exception:
                pass
            return
        dlg = CommandPaletteDialog(self._command_registry.list(), self)
        dlg.exec()

    def _register_core_commands_once(self) -> None:
        if getattr(self, "_core_commands_registered", False):
            return
        self._core_commands_registered = True

        reg = self._command_registry

        def _trigger(action: QAction | None) -> None:
            if action is None:
                return
            try:
                action.trigger()
            except Exception:
                pass

        try:
            reg.register(
                "studio.open_demo",
                "Open CRISPR demo",
                lambda: _trigger(getattr(self, "actionOpenDemo", None)),
                category="File",
            )
            reg.register(
                "studio.open_prime_demo",
                "Open prime demo",
                lambda: _trigger(getattr(self, "actionOpenPrimeDemo", None)),
                category="File",
                shortcut="Ctrl+Alt+P",
            )
            reg.register(
                "studio.open_experiment_preset",
                "Open experiment preset…",
                self._open_preset_dialog,
                category="File",
                shortcut="Ctrl+Shift+E",
            )
            reg.register(
                "studio.save_experiment_preset",
                "Save experiment as preset…",
                self._save_experiment_preset,
                category="File",
                shortcut="Ctrl+Alt+S",
            )
            reg.register(
                "studio.export_evidence",
                "Export VeriBiota evidence…",
                self._on_export_evidence,
                category="File",
            )
        except Exception:
            pass

        try:
            reg.register("studio.layout.reset", "Reset layout", self.reset_layout_to_defaults, category="View")
        except Exception:
            pass
        try:
            reg.register(
                "studio.outcomes.focus_mode.toggle",
                "Toggle Outcomes Focus Mode",
                lambda: _trigger(getattr(self, "_focus_action", None)),
                category="View",
                shortcut="F11",
            )
        except Exception:
            pass
        try:
            reg.register(
                "studio.view.lightcone",
                "Lightcone",
                lambda: _trigger(getattr(self, "actionOpenLightcone", None)),
                category="View",
                shortcut="Ctrl+Alt+L",
            )
        except Exception:
            pass

        try:
            reg.register("studio.terminal.show", "Terminal", self._show_terminal, category="Tools", shortcut="Ctrl+`")
            reg.register("studio.terminal.new_tab", "New Terminal Tab", self._new_terminal, category="Tools", shortcut="Ctrl+Shift+`")
            reg.register(
                "studio.terminal.clear_scrollback",
                "Clear Terminal Scrollback",
                self._clear_terminal_scrollback,
                category="Tools",
                shortcut="Ctrl+Shift+L",
            )
            reg.register(
                "studio.plugins.reload",
                "Reload plugins",
                self._reload_plugins,
                category="Tools",
            )
        except Exception:
            pass

    def _settings_disabled_plugins(self) -> set[str]:
        raw = self._settings.value("plugins/disabled", [])
        values: list[str] = []
        if isinstance(raw, list):
            values = [str(x) for x in raw]
        elif isinstance(raw, str):
            values = [raw]
        return {v.strip().lower() for v in values if v and v.strip()}

    def _effective_disabled_plugins(self) -> set[str]:
        disabled = set(self._settings_disabled_plugins())
        disabled_raw = (os.environ.get("HELIX_STUDIO_DISABLED_PLUGINS") or "").strip()
        if disabled_raw:
            disabled |= {p.strip().lower() for p in disabled_raw.split(",") if p.strip()}
        return disabled

    def _maybe_offer_plugin_safe_mode(self) -> None:
        if os.environ.get("HELIX_STUDIO_PLUGINS", "1") == "0":
            return
        if os.environ.get("HELIX_STUDIO_SAFE_MODE", "0") == "1":
            self._plugins_safe_mode = True
            return
        if getattr(self, "_plugins_safe_mode", False):
            return
        try:
            last_state = str(self._settings.value("plugins/last_load_state", "") or "")
        except Exception:
            last_state = ""
        crashed_during_load = last_state == "loading"
        try:
            shift_held = bool(QGuiApplication.keyboardModifiers() & Qt.ShiftModifier)
        except Exception:
            shift_held = False
        if not crashed_during_load and not shift_held:
            return

        box = QMessageBox(self)
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle("Plugin Safe Mode")
        if crashed_during_load:
            box.setText(
                "The previous Helix Studio launch may have crashed while loading plugins.\n\n"
                "Start in Safe Mode to disable plugins for this session."
            )
        else:
            box.setText(
                "Shift was held during startup.\n\n"
                "Start in Safe Mode to disable plugins for this session."
            )
        safe_btn = box.addButton("Start in Safe Mode", QMessageBox.AcceptRole)
        box.addButton("Continue", QMessageBox.RejectRole)
        box.setDefaultButton(safe_btn)
        box.exec()
        if box.clickedButton() == safe_btn:
            self._plugins_safe_mode = True
            try:
                self._settings.setValue("plugins/last_load_state", "safe_mode")
            except Exception:
                pass

    def _set_plugin_enabled(self, plugin_id: str, enabled: bool) -> None:
        pid = (plugin_id or "").strip().lower()
        if not pid:
            return
        disabled = self._settings_disabled_plugins()
        if enabled:
            disabled.discard(pid)
            try:
                self._clear_plugin_quarantine(pid)
            except Exception:
                pass
            try:
                self._plugin_host_crashes.pop(pid, None)
                self._plugin_command_timeouts.pop(pid, None)
            except Exception:
                pass
        else:
            disabled.add(pid)
        self._settings.setValue("plugins/disabled", sorted(disabled))

    def _ensure_plugin_system(self) -> None:
        disabled = sorted(self._effective_disabled_plugins())
        if self._plugin_manager is not None and self._plugin_host is not None:
            try:
                self._plugin_manager.set_disabled(disabled)
            except Exception:
                pass
            return
        paths = default_plugin_search_paths(self.ctx.project_root)
        self._plugin_manager = HelixPluginManager(search_paths=paths, disabled=disabled)
        self._plugin_host = StudioPluginHost(
            self,
            self._command_registry,
            self._dock_panel_registry,
            log_fn=self._plugin_log,
        )

    def _plugin_log(self, plugin_id: str, message: str) -> None:
        pid = (plugin_id or "host").strip().lower() or "host"
        msg = (message or "").strip()
        if not msg:
            return
        buf = self._plugin_logs.setdefault(pid, [])
        buf.append(msg)
        if len(buf) > 200:
            del buf[:-200]
        line = f"[Plugin:{pid}] {msg}"
        emitted = False
        try:
            self.session.logMessage.emit(line)
            emitted = True
        except Exception:
            pass
        if not emitted:
            try:
                print(line, flush=True)
            except Exception:
                pass
        try:
            log_path = self._plugin_log_path(pid)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            try:
                if log_path.exists() and log_path.stat().st_size > 1024 * 1024:
                    rotated = log_path.with_suffix(".log.1")
                    try:
                        rotated.unlink()
                    except Exception:
                        pass
                    try:
                        log_path.rename(rotated)
                    except Exception:
                        pass
            except Exception:
                pass
            stamp = clock.utc_now_iso_offset()
            with log_path.open("a", encoding="utf-8") as f:
                f.write(f"{stamp} {msg}\n")
        except Exception:
            pass

    def _emit_plugin_event(
        self,
        topic: str,
        payload,
        *,
        forward_to_extension_host: bool = True,
    ) -> None:
        host = getattr(self, "_plugin_host", None)
        if host is not None:
            try:
                host.emit(topic, payload)
            except Exception:
                pass
        if not forward_to_extension_host:
            return
        sup = getattr(self, "_extension_hosts", None)
        if sup is None:
            return
        try:
            sup.notify_all(EXT_METHOD_EVENTS_EMIT, {"topic": topic, "payload": payload})
        except Exception:
            return

    def _ensure_extension_hosts(self) -> ExtensionHostSupervisor | None:
        if os.environ.get("HELIX_STUDIO_EXTENSION_HOST", "0") != "1":
            return None
        sup = self._extension_hosts
        if sup is not None:
            return sup

        mode = os.environ.get("HELIX_STUDIO_EXTENSION_HOST_MODE", "shared")
        src_path = self.ctx.project_root / "src"

        def _on_notification(host_key: str, method: str, params) -> None:
            ui_post(
                lambda hk=host_key, m=method, p=params: self._on_extension_host_notification(
                    hk, m, p
                )
            )

        def _on_stderr(host_key: str, line: str) -> None:
            msg = (line or "").strip()
            if msg:
                self._plugin_log("host", f"ext_host[{host_key}] stderr: {msg}")

        sup = ExtensionHostSupervisor(
            project_root=self.ctx.project_root,
            src_path=src_path,
            mode=mode,
            env=dict(os.environ),
            on_notification=_on_notification,
            on_stderr=_on_stderr,
        )
        self._extension_hosts = sup
        try:
            if self._extension_host_watchdog is None:
                t = QTimer(self)
                t.setInterval(2000)
                t.timeout.connect(self._extension_host_watchdog_tick)
                t.start()
                self._extension_host_watchdog = t
        except Exception:
            pass
        return sup

    def _extension_host_stats(self) -> dict[str, Any]:
        enabled = os.environ.get("HELIX_STUDIO_EXTENSION_HOST", "0") == "1"
        mode = os.environ.get("HELIX_STUDIO_EXTENSION_HOST_MODE", "shared")
        info: dict[str, Any] = {"enabled": enabled, "mode": mode}
        try:
            info["watchdog"] = self._extension_host_watchdog_config()
        except Exception:
            pass
        sup = getattr(self, "_extension_hosts", None)
        if sup is None:
            info["running"] = False
            return info
        try:
            info.update(sup.stats())
        except Exception:
            pass
        try:
            info["restart_info"] = dict(
                getattr(self, "_extension_host_restart_info", {})
            )
        except Exception:
            pass
        try:
            info["running"] = any(v.get("running") for v in info.get("hosts", {}).values())
        except Exception:
            pass
        try:
            pids = set()
            for pid in getattr(self, "_remote_plugin_ids", set()):
                if isinstance(pid, str) and pid:
                    pids.add(pid)
            for pid in getattr(self, "_plugin_host_crashes", {}).keys():
                if isinstance(pid, str) and pid:
                    pids.add(pid)
            for pid in getattr(self, "_plugin_command_timeouts", {}).keys():
                if isinstance(pid, str) and pid:
                    pids.add(pid)
            for pid in getattr(self, "_plugin_policy_violations", {}).keys():
                if isinstance(pid, str) and pid:
                    pids.add(pid)

            health: dict[str, Any] = {}
            for pid in sorted(pids):
                health[pid] = {
                    "host_crashes": int(self._plugin_host_crashes.get(pid, 0)),
                    "command_timeouts": int(self._plugin_command_timeouts.get(pid, 0)),
                    "policy_violations": int(self._plugin_policy_violations.get(pid, 0)),
                    "quarantine": self._plugin_quarantine_info(pid),
                }
            info["plugin_health"] = health
        except Exception:
            pass
        return info

    @staticmethod
    def _extension_host_watchdog_config() -> dict[str, Any]:
        def _int_env(name: str, default: int) -> int:
            try:
                return int(os.environ.get(name, str(default)))
            except Exception:
                return int(default)

        def _float_env(name: str, default: float) -> float:
            try:
                return float(os.environ.get(name, str(default)))
            except Exception:
                return float(default)

        return {
            "interval_ms": 2000,
            "heartbeat": {
                "interval_s": _float_env(
                    "HELIX_STUDIO_EXTENSION_HOST_HEARTBEAT_INTERVAL_S", 2.0
                ),
                "timeout_s": _float_env(
                    "HELIX_STUDIO_EXTENSION_HOST_HEARTBEAT_TIMEOUT_S", 5.0
                ),
                "misses_before_restart": _int_env(
                    "HELIX_STUDIO_EXTENSION_HOST_HEARTBEAT_MISSES_BEFORE_RESTART", 2
                ),
            },
            "max_rss_mb": _int_env("HELIX_STUDIO_EXTENSION_HOST_MAX_RSS_MB", 1024),
            "max_pending_requests": _int_env(
                "HELIX_STUDIO_EXTENSION_HOST_MAX_PENDING", 200
            ),
            "max_notifications_dropped_total": _int_env(
                "HELIX_STUDIO_EXTENSION_HOST_MAX_DROPPED_NOTIFICATIONS", 500
            ),
            "quarantine": {
                "policy_violations": _int_env(
                    "HELIX_STUDIO_PLUGIN_POLICY_VIOLATION_QUARANTINE", 25
                ),
                "command_timeouts": _int_env(
                    "HELIX_STUDIO_EXTENSION_HOST_TIMEOUT_QUARANTINE", 3
                ),
                "host_crashes": _int_env(
                    "HELIX_STUDIO_EXTENSION_HOST_CRASH_QUARANTINE", 3
                ),
            },
        }

    @staticmethod
    def _process_rss_bytes(pid: int) -> int | None:
        try:
            import psutil  # type: ignore[import-not-found]

            return int(psutil.Process(int(pid)).memory_info().rss)
        except Exception:
            return None

    def _plugin_quarantine_reason(self, plugin_id: str) -> str | None:
        pid = (plugin_id or "").strip().lower()
        if not pid:
            return None
        key = f"plugins/quarantine/{pid}/reason"
        try:
            value = str(self._settings.value(key, "") or "").strip()
        except Exception:
            value = ""
        return value or None

    def _plugin_quarantine_info(self, plugin_id: str) -> dict[str, str] | None:
        pid = (plugin_id or "").strip().lower()
        if not pid:
            return None
        reason = self._plugin_quarantine_reason(pid)
        if not reason:
            return None
        try:
            at = str(
                self._settings.value(f"plugins/quarantine/{pid}/at", "") or ""
            ).strip()
        except Exception:
            at = ""
        info: dict[str, str] = {"reason": reason}
        if at:
            info["at"] = at
        return info

    def _quarantined_plugins(self) -> dict[str, str]:
        manager = getattr(self, "_plugin_manager", None)
        if manager is None:
            return {}
        out: dict[str, str] = {}
        for pid in sorted(manager.discovered.keys()):
            reason = self._plugin_quarantine_reason(pid)
            if reason:
                out[pid] = reason
        return out

    def _set_plugin_quarantine_reason(self, plugin_id: str, reason: str) -> None:
        pid = (plugin_id or "").strip().lower()
        msg = (reason or "").strip()
        if not pid or not msg:
            return
        try:
            self._settings.setValue(f"plugins/quarantine/{pid}/reason", msg)
            self._settings.setValue(
                f"plugins/quarantine/{pid}/at",
                clock.utc_now_iso_offset(),
            )
        except Exception:
            pass

    def _clear_plugin_quarantine(self, plugin_id: str) -> None:
        pid = (plugin_id or "").strip().lower()
        if not pid:
            return
        try:
            self._settings.remove(f"plugins/quarantine/{pid}")
        except Exception:
            pass

    def _unload_remote_plugin(self, plugin_id: str) -> None:
        pid = (plugin_id or "").strip().lower()
        if not pid:
            return
        try:
            if self._plugin_host is not None:
                self._plugin_host.unregister_plugin(pid)
        except Exception:
            pass
        try:
            if self._plugin_manager is not None:
                self._plugin_manager.loaded.pop(pid, None)
        except Exception:
            pass
        self._remote_plugin_ids.discard(pid)
        self._plugin_progress.pop(pid, None)
        for key in list(self._remote_pending_requests.keys()):
            if key[0] == pid:
                self._remote_pending_requests.pop(key, None)
        for panel_key in list(self._remote_web_panel_bridges.keys()):
            if panel_key.startswith(f"{pid}."):
                self._remote_web_panel_bridges.pop(panel_key, None)

    def _apply_extension_host_load_response(self, resp) -> None:
        manager = getattr(self, "_plugin_manager", None)
        host = getattr(self, "_plugin_host", None)
        if manager is None or host is None:
            return
        if not isinstance(resp, dict):
            return
        from types import ModuleType

        for item in resp.get("loaded", []):
            if not isinstance(item, dict):
                continue
            pid = str(item.get("plugin_id") or "").strip().lower()
            if not pid or pid not in manager.discovered:
                continue
            if str(item.get("status") or "") != "loaded":
                continue
            desc = manager.discovered[pid]
            manager.loaded[pid] = LoadedPlugin(
                descriptor=desc,
                module=ModuleType(f"remote:{pid}"),
                deactivate=None,
                load_time_ms=float(item.get("load_time_ms") or 0.0),
            )
            self._remote_plugin_ids.add(pid)
            self._plugin_host_crashes.pop(pid, None)

        for err in resp.get("errors", []):
            if not isinstance(err, dict):
                continue
            pid = err.get("plugin_id")
            key = str(pid).strip().lower() if pid else ""
            key = key.strip().lower() or "extension_host"
            tb = str(err.get("traceback") or err.get("error") or "").strip()
            manager.errors[key] = tb or str(err)
            if key in manager.discovered:
                try:
                    host.unregister_plugin(key)
                except Exception:
                    pass

    def _recover_extension_host(self, host_key: str, affected: list[str]) -> None:
        sup = getattr(self, "_extension_hosts", None)
        manager = getattr(self, "_plugin_manager", None)
        if sup is None or manager is None:
            return

        plugin_ids: list[str] = []
        for pid in affected:
            p = (pid or "").strip().lower()
            if not p:
                continue
            if manager.is_disabled(p):
                continue
            desc = manager.discovered.get(p)
            if desc is None:
                continue
            if desc.manifest.isolation != "extension_host":
                continue
            if p in self._effective_disabled_plugins():
                continue
            if self._plugin_quarantine_reason(p):
                continue
            plugin_ids.append(p)

        if not plugin_ids:
            return

        for pid in plugin_ids:
            self._unload_remote_plugin(pid)

        from helix.studio.plugins.policy import policy_from_permissions

        if host_key == "shared":
            specs: list[dict[str, Any]] = []
            for pid in plugin_ids:
                desc = manager.discovered.get(pid)
                if desc is None:
                    continue
                specs.append(
                    {
                        "plugin_id": pid,
                        "root": str(desc.root),
                        "manifest_path": str(desc.manifest_path),
                        "entry": desc.manifest.entry,
                        "policy": policy_from_permissions(desc.manifest.permissions).as_dict(),
                    }
                )
            if not specs:
                return
            try:
                ext = sup.start_shared_host()
                resp = ext.call(
                    EXT_METHOD_LOAD_PLUGINS,
                    {"plugins": specs},
                    timeout_s=30.0,
                )
                self._apply_extension_host_load_response(resp)
            except Exception as exc:
                try:
                    manager.errors["extension_host"] = str(exc)
                except Exception:
                    pass
            return

        if host_key.startswith("plugin:"):
            for pid in plugin_ids:
                desc = manager.discovered.get(pid)
                if desc is None:
                    continue
                try:
                    ext = sup.start_plugin_host(pid, cwd=desc.root)
                    resp = ext.call(
                        EXT_METHOD_LOAD_PLUGINS,
                        {
                            "plugins": [
                                {
                                    "plugin_id": pid,
                                    "root": str(desc.root),
                                    "manifest_path": str(desc.manifest_path),
                                    "entry": desc.manifest.entry,
                                    "policy": policy_from_permissions(
                                        desc.manifest.permissions
                                    ).as_dict(),
                                }
                            ]
                        },
                        timeout_s=30.0,
                    )
                    self._apply_extension_host_load_response(resp)
                except Exception as exc:
                    try:
                        manager.errors[pid] = str(exc)
                    except Exception:
                        pass
            return

    def _quarantine_plugin(self, plugin_id: str, *, reason: str) -> None:
        pid = (plugin_id or "").strip().lower()
        msg = (reason or "").strip()
        if not pid or not msg:
            return
        if pid in self._effective_disabled_plugins():
            return
        self._set_plugin_quarantine_reason(pid, msg)
        self._plugin_log("host", f"quarantined plugin {pid}: {msg}")
        try:
            self._set_plugin_enabled(pid, False)
        except Exception:
            pass
        self._unload_remote_plugin(pid)

        sup = getattr(self, "_extension_hosts", None)
        if sup is not None:
            ext = None
            try:
                ext = sup.client_for_plugin(pid)
            except Exception:
                ext = None
            if ext is not None and ext.is_running():
                try:
                    ext.call(
                        EXT_METHOD_UNLOAD_PLUGINS,
                        {"plugin_ids": [pid]},
                        timeout_s=10.0,
                    )
                except Exception:
                    pass
            try:
                sup.stop_plugin_host(pid)
            except Exception:
                pass

    def _record_plugin_timeout(self, plugin_id: str, *, command_id: str) -> None:
        pid = (plugin_id or "").strip().lower()
        if not pid:
            return
        count = int(self._plugin_command_timeouts.get(pid, 0)) + 1
        self._plugin_command_timeouts[pid] = count
        try:
            threshold = int(
                os.environ.get("HELIX_STUDIO_EXTENSION_HOST_TIMEOUT_QUARANTINE", "3")
            )
        except Exception:
            threshold = 3
        if count >= threshold:
            self._quarantine_plugin(
                pid,
                reason=(
                    f"remote commands exceeded timeout threshold "
                    f"({count} >= {threshold}); last={command_id}"
                ),
            )

    def _extension_host_watchdog_tick(self) -> None:
        sup = getattr(self, "_extension_hosts", None)
        if sup is None:
            return

        # Heartbeat: detect "alive but wedged" hosts without blocking the UI thread.
        try:
            hb_interval_s = float(
                os.environ.get("HELIX_STUDIO_EXTENSION_HOST_HEARTBEAT_INTERVAL_S", "2.0")
            )
        except Exception:
            hb_interval_s = 2.0
        try:
            hb_timeout_s = float(
                os.environ.get("HELIX_STUDIO_EXTENSION_HOST_HEARTBEAT_TIMEOUT_S", "5.0")
            )
        except Exception:
            hb_timeout_s = 5.0
        try:
            hb_misses = int(
                os.environ.get(
                    "HELIX_STUDIO_EXTENSION_HOST_HEARTBEAT_MISSES_BEFORE_RESTART", "2"
                )
            )
        except Exception:
            hb_misses = 2
        if hb_interval_s > 0 and hb_timeout_s > 0 and hb_misses > 0:
            try:
                to_restart = sup.heartbeat_tick(
                    interval_s=hb_interval_s,
                    timeout_s=hb_timeout_s,
                    restart_after_misses=hb_misses,
                )
            except Exception:
                to_restart = []
            for host_key, misses in list(to_restart):
                self._plugin_log(
                    "host",
                    f"extension host heartbeat timeout ({misses} misses); restarting: {host_key}",
                )
                try:
                    self._extension_host_restart_info[host_key] = {
                        "at": clock.utc_now_iso_offset(),
                        "reason": "heartbeat_timeout",
                        "misses": int(misses),
                        "timeout_s": float(hb_timeout_s),
                        "interval_s": float(hb_interval_s),
                    }
                except Exception:
                    pass

                affected = sup.plugins_for_host_key(host_key)
                if host_key.startswith("plugin:") and not affected:
                    affected = [host_key.split(":", 1)[-1].strip().lower()]

                # Dedicated hosts: heartbeat timeouts are clear blame; treat like crashes.
                if host_key.startswith("plugin:"):
                    try:
                        crash_threshold = int(
                            os.environ.get(
                                "HELIX_STUDIO_EXTENSION_HOST_CRASH_QUARANTINE", "3"
                            )
                        )
                    except Exception:
                        crash_threshold = 3

                    for pid in affected:
                        self._plugin_host_crashes[pid] = int(
                            self._plugin_host_crashes.get(pid, 0)
                        ) + 1
                        crashes = self._plugin_host_crashes[pid]
                        if crashes >= crash_threshold:
                            self._quarantine_plugin(
                                pid,
                                reason=(
                                    f"extension host heartbeat timed out {crashes} times "
                                    f"(>= {crash_threshold})"
                                ),
                            )

                try:
                    sup.stop_host(host_key, timeout_s=0.2)
                except Exception:
                    pass
                self._extension_host_running[host_key] = False
                self._recover_extension_host(host_key, affected)

        # Quarantine on repeated policy violations (e.g., web panel sandbox).
        try:
            violation_threshold = int(
                os.environ.get("HELIX_STUDIO_PLUGIN_POLICY_VIOLATION_QUARANTINE", "25")
            )
        except Exception:
            violation_threshold = 25
        for pid, count in list(self._plugin_policy_violations.items()):
            try:
                c = int(count)
            except Exception:
                c = 0
            if c >= violation_threshold:
                self._quarantine_plugin(
                    pid,
                    reason=f"policy violations exceeded threshold ({c} >= {violation_threshold})",
                )

        try:
            rss_limit_mb = int(
                os.environ.get("HELIX_STUDIO_EXTENSION_HOST_MAX_RSS_MB", "1024")
            )
        except Exception:
            rss_limit_mb = 1024
        rss_limit_bytes = max(0, rss_limit_mb) * 1024 * 1024

        for host_key, client in sup.all_hosts():
            running = bool(client.is_running())
            prev = bool(self._extension_host_running.get(host_key, running))
            self._extension_host_running[host_key] = running
            if prev and not running:
                self._plugin_log("host", f"extension host exited: {host_key}")
                try:
                    self._extension_host_restart_info[host_key] = {
                        "at": clock.utc_now_iso_offset(),
                        "reason": "exited",
                    }
                except Exception:
                    pass
                affected = sup.plugins_for_host_key(host_key)
                if host_key.startswith("plugin:") and not affected:
                    affected = [host_key.split(":", 1)[-1].strip().lower()]

                try:
                    crash_threshold = int(
                        os.environ.get("HELIX_STUDIO_EXTENSION_HOST_CRASH_QUARANTINE", "3")
                    )
                except Exception:
                    crash_threshold = 3

                for pid in affected:
                    self._plugin_host_crashes[pid] = int(
                        self._plugin_host_crashes.get(pid, 0)
                    ) + 1
                    crashes = self._plugin_host_crashes[pid]
                    if crashes >= crash_threshold and host_key.startswith("plugin:"):
                        self._quarantine_plugin(
                            pid,
                            reason=(
                                f"extension host crashed {crashes} times "
                                f"(>= {crash_threshold})"
                            ),
                        )

                # Attempt recovery (restart + reload) for non-quarantined plugins.
                self._recover_extension_host(host_key, affected)

            # Budgets only make sense for dedicated hosts (clear blame).
            if not host_key.startswith("plugin:"):
                continue
            pid = host_key.split(":", 1)[-1].strip().lower()
            if not pid or pid in self._effective_disabled_plugins():
                continue
            if not running:
                continue

            try:
                stats = client.stats()
            except Exception:
                stats = {}
            try:
                pending = int(stats.get("pending_requests") or 0)
            except Exception:
                pending = 0
            try:
                dropped = int(stats.get("notifications_dropped_total") or 0)
            except Exception:
                dropped = 0

            try:
                max_pending = int(
                    os.environ.get("HELIX_STUDIO_EXTENSION_HOST_MAX_PENDING", "200")
                )
            except Exception:
                max_pending = 200
            try:
                max_dropped = int(
                    os.environ.get(
                        "HELIX_STUDIO_EXTENSION_HOST_MAX_DROPPED_NOTIFICATIONS", "500"
                    )
                )
            except Exception:
                max_dropped = 500

            if max_pending > 0 and pending >= max_pending:
                self._quarantine_plugin(
                    pid,
                    reason=(
                        "extension host exceeded pending request budget "
                        f"({pending} >= {max_pending})"
                    ),
                )
                continue

            if max_dropped > 0 and dropped >= max_dropped:
                self._quarantine_plugin(
                    pid,
                    reason=(
                        "extension host exceeded notification drop budget "
                        f"({dropped} >= {max_dropped})"
                    ),
                )
                continue

            if rss_limit_bytes > 0:
                proc_pid = client.pid()
                if proc_pid is not None:
                    rss = self._process_rss_bytes(proc_pid)
                    if rss is not None and rss > rss_limit_bytes:
                        rss_mb = rss / (1024 * 1024)
                        self._quarantine_plugin(
                            pid,
                            reason=(
                                "extension host exceeded memory budget "
                                f"({rss_mb:.0f}MB > {rss_limit_mb}MB)"
                            ),
                        )

    def _on_extension_host_notification(self, host_key: str, method: str, params) -> None:
        m = (method or "").strip()
        if not m:
            return

        if m == EXT_NOTIFY_LOG:
            if isinstance(params, dict):
                pid = str(params.get("plugin_id") or "host").strip().lower() or "host"
                msg = str(params.get("message") or "").strip()
                if msg:
                    self._plugin_log(pid, msg)
            return

        if m == EXT_NOTIFY_SYSTEM_OPEN_URL:
            if not isinstance(params, dict):
                return
            pid = str(params.get("plugin_id") or "").strip().lower()
            url = str(params.get("url") or "").strip()
            if not pid or not url:
                return
            try:
                from PySide6.QtCore import QUrl
                from PySide6.QtGui import QDesktopServices
            except Exception as exc:
                self._plugin_log(pid, f"open_url unavailable: {exc}")
                return
            try:
                parsed = QUrl(url)
                scheme = (parsed.scheme() or "").strip().lower()
                if scheme not in {"http", "https"}:
                    self._plugin_log(pid, f"blocked open_url scheme: {scheme or '(none)'}")
                    return
                QDesktopServices.openUrl(parsed)
            except Exception as exc:
                self._plugin_log(pid, f"open_url failed: {exc}")
            return

        if m == EXT_NOTIFY_SYSTEM_CLIPBOARD_SET:
            if not isinstance(params, dict):
                return
            pid = str(params.get("plugin_id") or "").strip().lower()
            text = params.get("text")
            if not pid:
                return
            try:
                from PySide6.QtGui import QGuiApplication
            except Exception as exc:
                self._plugin_log(pid, f"clipboard unavailable: {exc}")
                return
            try:
                cb = QGuiApplication.clipboard()
                cb.setText(str(text))
            except Exception as exc:
                self._plugin_log(pid, f"clipboard_set failed: {exc}")
            return

        if m == EXT_NOTIFY_COMMAND_REGISTER:
            if not isinstance(params, dict):
                return
            pid = str(params.get("plugin_id") or "").strip().lower()
            cid = str(params.get("command_id") or "").strip().lower()
            title = str(params.get("title") or "").strip()
            handler_id = params.get("handler_id")
            category = params.get("category")
            shortcut = params.get("shortcut")
            menu = params.get("menu")
            if not pid or not cid or not title:
                return
            try:
                hid = int(handler_id)
            except Exception:
                return
            self._register_remote_command(
                pid,
                cid,
                title,
                hid,
                category=str(category) if isinstance(category, str) else None,
                shortcut=str(shortcut) if isinstance(shortcut, str) else None,
                menu=str(menu) if isinstance(menu, str) else None,
            )
            return

        if m == EXT_NOTIFY_COMMAND_PROGRESS:
            if not isinstance(params, dict):
                return
            pid = str(params.get("plugin_id") or "").strip().lower()
            rid = params.get("request_id")
            pct = params.get("percent")
            stage = params.get("stage")
            msg = params.get("message")
            try:
                req_id = int(rid) if rid is not None else None
            except Exception:
                req_id = None
            percent: int | None
            try:
                percent = int(pct) if pct is not None else None
            except Exception:
                percent = None
            stage_s = str(stage).strip() if isinstance(stage, str) else ""
            msg_s = str(msg).strip() if isinstance(msg, str) else ""

            cmd = ""
            if req_id is not None:
                info = self._remote_pending_requests.get((pid, req_id))
                if isinstance(info, dict):
                    cmd = str(info.get("command_id") or "").strip().lower()

            label = cmd or pid or "plugin"
            parts: list[str] = [label]
            if percent is not None:
                parts.append(f"{percent}%")
            if stage_s:
                parts.append(stage_s)
            if msg_s:
                parts.append(msg_s)
            text = " · ".join(p for p in parts if p)
            if pid and text:
                self._plugin_progress[pid] = text
            try:
                self.statusBar().showMessage(text)
            except Exception:
                pass
            return

        if m == EXT_NOTIFY_WEB_PANEL_REGISTER:
            if not isinstance(params, dict):
                return
            pid = str(params.get("plugin_id") or "").strip().lower()
            panel_id = str(params.get("panel_id") or "").strip().lower()
            title = str(params.get("title") or "").strip()
            entry_html = str(params.get("entry_html") or "").strip()
            area = str(params.get("area") or "bottom").strip().lower() or "bottom"
            visible = bool(params.get("visible", False))
            menu = str(params.get("menu") or "View/Plugin Panels").strip() or "View/Plugin Panels"
            handler_id = params.get("handler_id")
            hid: int | None
            try:
                hid = int(handler_id) if handler_id is not None else None
            except Exception:
                hid = None
            if not pid or not panel_id or not title or not entry_html:
                return
            self._register_remote_web_panel(
                pid,
                panel_id,
                title,
                entry_html,
                area=area,
                visible=visible,
                menu=menu,
                handler_id=hid,
            )
            return

        if m == EXT_NOTIFY_WEB_PANEL_MESSAGE:
            if not isinstance(params, dict):
                return
            panel_id = str(params.get("panel_id") or "").strip().lower()
            payload = params.get("payload")
            bridge = self._remote_web_panel_bridges.get(panel_id)
            if bridge is not None:
                try:
                    bridge.deliver_message(payload)
                except Exception:
                    pass
            return

        if m == EXT_NOTIFY_WEB_PANEL_UNREGISTER:
            if not isinstance(params, dict):
                return
            pid = str(params.get("plugin_id") or "").strip().lower()
            if pid:
                try:
                    if self._plugin_host is not None:
                        self._plugin_host.unregister_plugin(pid)
                except Exception:
                    pass
                try:
                    if self._plugin_manager is not None:
                        self._plugin_manager.loaded.pop(pid, None)
                except Exception:
                    pass
                self._remote_plugin_ids.discard(pid)
                for panel_key in list(self._remote_web_panel_bridges.keys()):
                    if panel_key.startswith(f"{pid}."):
                        self._remote_web_panel_bridges.pop(panel_key, None)
            return

        if m == EXT_METHOD_EVENTS_EMIT:
            if not isinstance(params, dict):
                return
            topic = str(params.get("topic") or "").strip()
            payload = params.get("payload")
            if topic:
                self._emit_plugin_event(topic, payload, forward_to_extension_host=False)
            return

    def _register_remote_command(
        self,
        plugin_id: str,
        command_id: str,
        title: str,
        handler_id: int,
        *,
        category: str | None,
        shortcut: str | None,
        menu: str | None,
    ) -> None:
        self._ensure_plugin_system()
        host = self._plugin_host
        if host is None:
            return
        api = host.api(plugin_id)

        def _invoke() -> None:
            sup = getattr(self, "_extension_hosts", None)
            ext = sup.client_for_plugin(plugin_id) if sup is not None else None
            if ext is None or not ext.is_running():
                self._plugin_log(plugin_id, "extension host is not running")
                return

            try:
                fut = ext.call_async(
                    EXT_METHOD_INVOKE_COMMAND,
                    {"handler_id": handler_id},
                )
            except Exception as exc:
                self._plugin_log(plugin_id, f"failed to invoke remote command: {exc}")
                return

            rid = getattr(fut, "_ext_request_id", None)
            req_id = int(rid) if isinstance(rid, int) else None
            if req_id is not None:
                self._remote_pending_requests[(plugin_id, req_id)] = {"command_id": command_id}
                try:
                    self.statusBar().showMessage(f"Running {command_id}…")
                except Exception:
                    pass

                def _timeout(r: int = req_id) -> None:
                    if fut.done():
                        return
                    try:
                        ext.cancel(r)
                    except Exception:
                        pass
                    self._plugin_log(plugin_id, f"{command_id}: timed out; cancelling…")
                    try:
                        self._record_plugin_timeout(plugin_id, command_id=command_id)
                    except Exception:
                        pass

                try:
                    QTimer.singleShot(30_000, _timeout)
                except Exception:
                    pass

            def _done() -> None:
                if req_id is not None:
                    self._remote_pending_requests.pop((plugin_id, req_id), None)
                try:
                    result = fut.result()
                except Exception as exc:
                    self._plugin_log(plugin_id, str(exc))
                    return

                if isinstance(result, dict) and result.get("result") is not None:
                    self._plugin_log(
                        plugin_id,
                        f"{command_id} -> {result.get('result')!r}",
                    )
                else:
                    self._plugin_log(plugin_id, f"{command_id} -> {result!r}")

                try:
                    active_for_plugin = any(
                        pid == plugin_id for pid, _rid in self._remote_pending_requests.keys()
                    )
                    if not active_for_plugin:
                        self._plugin_progress.pop(plugin_id, None)
                except Exception:
                    pass

            fut.add_done_callback(lambda _f: ui_post(_done))

        try:
            api.commands.register(
                command_id,
                title,
                _invoke,
                category=category,
                shortcut=shortcut,
                menu=menu,
            )
        except Exception as exc:
            self._plugin_log("host", f"failed to register remote command {command_id}: {exc}")

    def _register_remote_web_panel(
        self,
        plugin_id: str,
        panel_id: str,
        title: str,
        entry_html: str,
        *,
        area: str,
        visible: bool,
        menu: str,
        handler_id: int | None,
    ) -> None:
        self._ensure_plugin_system()
        manager = self._plugin_manager
        host = self._plugin_host
        if manager is None or host is None:
            return
        desc = manager.discovered.get(plugin_id)
        if desc is None:
            self._plugin_log("host", f"web panel from unknown plugin: {plugin_id}")
            return

        root = desc.root
        try:
            html_path = (root / entry_html).resolve()
            root_resolved = root.resolve()
            if not html_path.is_relative_to(root_resolved):
                raise ValueError("entry_html escapes plugin root")
        except Exception as exc:
            self._plugin_log(
                "host",
                f"invalid web panel entry_html for {panel_id} ({desc.manifest_path}): {exc}",
            )
            return
        if not html_path.exists() or not html_path.is_file():
            self._plugin_log(
                "host",
                f"web panel entry_html not found for {panel_id}: {html_path}",
            )
            return

        from helix.studio.plugins.policy import policy_from_permissions

        plugin_policy = policy_from_permissions(desc.manifest.permissions)

        def _report_violation(message: str) -> None:
            msg = (message or "").strip()
            if not msg:
                return

            def _apply() -> None:
                self._plugin_policy_violations[plugin_id] = (
                    int(self._plugin_policy_violations.get(plugin_id, 0)) + 1
                )
                self._plugin_log(
                    plugin_id,
                    f"policy violation ({panel_id}): {msg}",
                )

            ui_post(_apply)

        spec = WebPanelSpec(
            plugin_id=plugin_id,
            panel_id=panel_id,
            title=title,
            entry_html=html_path,
            assets_root=html_path.parent,
            handler_id=handler_id,
            policy=plugin_policy.web_panels,
            report_violation=_report_violation,
        )

        def _widget_factory() -> QWidget:
            widget, bridge = build_web_panel_widget(
                spec,
                get_extension_host=lambda pid=plugin_id: (
                    self._extension_hosts.client_for_plugin(pid)
                    if self._extension_hosts is not None
                    else None
                ),
                rpc_method=EXT_METHOD_WEB_PANEL_CALL,
                parent=self,
            )
            if bridge is not None:
                self._remote_web_panel_bridges[panel_id] = bridge
            try:
                widget.destroyed.connect(
                    lambda: self._remote_web_panel_bridges.pop(panel_id, None)
                )
            except Exception:
                pass
            return widget

        api = host.api(plugin_id)
        try:
            api.ui.register_dock_panel(
                panel_id,
                title,
                _widget_factory,
                area=area,
                visible=visible,
                menu=menu,
            )
        except Exception as exc:
            self._plugin_log("host", f"failed to register remote web panel {panel_id}: {exc}")
            self._remote_web_panel_bridges.pop(panel_id, None)

    def _plugin_log_path(self, plugin_id: str) -> Path:
        pid = (plugin_id or "host").strip().lower() or "host"
        try:
            from PySide6.QtCore import QStandardPaths

            base = QStandardPaths.writableLocation(QStandardPaths.CacheLocation)
        except Exception:
            base = ""
        root = Path(base) if base else (Path.home() / ".helix" / "studio" / "cache")
        return root / "plugins" / pid / "plugin.log"

    def _load_plugins_once(self) -> None:
        if getattr(self, "_plugins_loaded", False):
            return
        if os.environ.get("HELIX_STUDIO_PLUGINS", "1") == "0":
            try:
                self._settings.setValue("plugins/last_load_state", "disabled_by_env")
            except Exception:
                pass
            self._plugins_loaded = True
            return
        if getattr(self, "_plugins_safe_mode", False):
            self._plugins_loaded = True
            self._plugin_log("host", "safe mode: plugins disabled for this session")
            try:
                self._settings.setValue("plugins/last_load_state", "safe_mode")
            except Exception:
                pass
            return
        try:
            self._settings.setValue("plugins/last_load_state", "loading")
            self._settings.setValue(
                "plugins/last_load_started_at",
                clock.utc_now_iso_offset(),
            )
        except Exception:
            pass
        self._ensure_plugin_system()
        manager = self._plugin_manager
        host = self._plugin_host
        if manager is None or host is None:
            self._plugins_loaded = True
            return

        manager.discover()
        sup: ExtensionHostSupervisor | None = None
        remote_specs_shared: list[dict[str, Any]] = []
        remote_specs_dedicated: list[tuple[str, Path, dict[str, Any]]] = []
        for plugin_id in sorted(manager.discovered.keys()):
            if manager.is_disabled(plugin_id):
                continue
            desc = manager.discovered.get(plugin_id)
            if desc is None:
                continue
            if desc.manifest.isolation == "extension_host":
                if os.environ.get("HELIX_STUDIO_EXTENSION_HOST", "0") != "1":
                    manager.errors[plugin_id] = (
                        f"{desc.manifest_path}: isolation='extension_host' requires "
                        "HELIX_STUDIO_EXTENSION_HOST=1"
                    )
                    continue
                if sup is None:
                    sup = self._ensure_extension_hosts()
                if sup is None:
                    manager.errors[plugin_id] = (
                        f"{desc.manifest_path}: extension host unavailable"
                    )
                    continue

                from helix.studio.plugins.isolation_rules import (
                    should_use_dedicated_extension_host,
                )
                from helix.studio.plugins.policy import policy_from_permissions

                plugin_policy = policy_from_permissions(desc.manifest.permissions)
                plugin_mode = desc.manifest.extension_host_mode
                if plugin_mode is None and should_use_dedicated_extension_host(
                    plugin_policy
                ):
                    plugin_mode = "dedicated"
                host_key = sup.resolve_host_key(plugin_id, plugin_mode=plugin_mode)
                policy = plugin_policy.as_dict()
                spec = {
                    "plugin_id": plugin_id,
                    "root": str(desc.root),
                    "manifest_path": str(desc.manifest_path),
                    "entry": desc.manifest.entry,
                    "policy": policy,
                }
                if host_key == "shared":
                    sup.map_plugin(plugin_id, "shared")
                    remote_specs_shared.append(spec)
                else:
                    sup.map_plugin(plugin_id, host_key)
                    remote_specs_dedicated.append((plugin_id, desc.root, spec))
                continue

            api = host.api(plugin_id)
            loaded = manager.load(plugin_id, api)
            if loaded is None:
                # Roll back partial registrations when activation fails.
                host.unregister_plugin(plugin_id)

        if remote_specs_shared or remote_specs_dedicated:
            try:
                if sup is None:
                    sup = self._ensure_extension_hosts()

                if sup is not None and remote_specs_shared:
                    ext = sup.start_shared_host()
                    resp = ext.call(
                        EXT_METHOD_LOAD_PLUGINS,
                        {"plugins": remote_specs_shared},
                        timeout_s=30.0,
                    )
                    self._apply_extension_host_load_response(resp)

                if sup is not None and remote_specs_dedicated:
                    for pid, root, spec in remote_specs_dedicated:
                        ext = sup.start_plugin_host(pid, cwd=root)
                        resp = ext.call(
                            EXT_METHOD_LOAD_PLUGINS,
                            {"plugins": [spec]},
                            timeout_s=30.0,
                        )
                        self._apply_extension_host_load_response(resp)
            except Exception as exc:
                manager.errors["extension_host"] = str(exc)

        self._plugins_loaded = True
        try:
            self._settings.setValue(
                "plugins/last_load_error_count",
                int(len(manager.errors)),
            )
            self._settings.setValue("plugins/last_load_state", "ok")
        except Exception:
            pass

        if manager.loaded:
            loaded_ids = ", ".join(sorted(manager.loaded.keys()))
            self._plugin_log("host", f"loaded {len(manager.loaded)} plugin(s): {loaded_ids}")
        if manager.errors:
            for pid, err in manager.errors.items():
                last = err.strip().splitlines()[-1] if err.strip() else "unknown error"
                self._plugin_log("host", f"{pid}: {last}")

    def _reload_plugins(self) -> None:
        sup = getattr(self, "_extension_hosts", None)
        if sup is not None:
            try:
                sup.stop_all()
            except Exception:
                pass
        t = getattr(self, "_extension_host_watchdog", None)
        if t is not None:
            try:
                t.stop()
                t.deleteLater()
            except Exception:
                pass
        self._extension_host_watchdog = None
        self._extension_host_running = {}
        self._extension_host_restart_info = {}
        self._plugin_host_crashes = {}
        self._plugin_command_timeouts = {}
        self._extension_hosts = None
        self._remote_plugin_ids = set()
        self._remote_web_panel_bridges = {}
        self._remote_pending_requests = {}
        self._plugin_progress = {}
        self._plugin_policy_violations = {}

        self._ensure_plugin_system()
        manager = self._plugin_manager
        host = self._plugin_host
        if manager is None or host is None:
            return

        # Soft reload semantics:
        # - Call deactivate hooks (best-effort).
        # - Unregister everything created through the host registries.
        # This does NOT guarantee fresh Python module code (see menu item to restart).
        prev_ids = set(manager.loaded.keys()) | set(manager.discovered.keys())
        for pid in list(manager.loaded.keys()):
            manager.unload(pid)
        for pid in sorted(prev_ids):
            host.unregister_plugin(pid)

        self._plugins_loaded = False
        self._load_plugins_once()
        try:
            self.statusBar().showMessage("Plugins reloaded (soft)", 2500)
        except Exception:
            pass

    def _open_plugins_folder(self) -> None:
        root = self.ctx.project_root / "plugins"
        try:
            root.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(root)))
        except Exception:
            pass

    def _show_plugins_dialog(self) -> None:
        self._ensure_plugin_system()
        manager = self._plugin_manager
        if manager is None:
            return
        try:
            from .plugins.plugins_dialog import PluginsDialog
        except Exception as exc:
            self._plugin_log("host", f"Plugins dialog unavailable: {exc}")
            return
        dlg = PluginsDialog(self, manager=manager)
        dlg.exec()

    def _restart_studio_clean(self) -> None:
        """Restart the process for a true reload (clears Python module state)."""
        try:
            import sys

            from PySide6.QtWidgets import QMessageBox
        except Exception:
            return

        res = QMessageBox.question(
            self,
            "Restart Helix Studio",
            "Restart Studio now?\n\n"
            "This performs a clean reload of plugins (full Python interpreter restart).",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if res != QMessageBox.Yes:
            return

        project_root = str(self.ctx.project_root)
        argv = list(sys.argv[1:])
        if not argv or argv[0].startswith("-"):
            argv = [project_root, *argv]
        else:
            argv[0] = project_root

        exe0 = sys.argv[0] if sys.argv else ""
        try:
            if exe0 and os.path.exists(exe0) and os.access(exe0, os.X_OK):
                os.execv(exe0, [exe0, *argv])
            os.execv(sys.executable, [sys.executable, "-m", "helix.studio.app", *argv])
        except Exception as exc:
            try:
                QMessageBox.critical(self, "Restart failed", f"Could not restart Studio: {exc}")
            except Exception:
                pass

    def _rerun_active_sim(self) -> None:
        if hasattr(self.sim_panel, "run_active_tab"):
            self.sim_panel.run_active_tab()

    def _select_history_position(self, position: int) -> None:
        if hasattr(self, "history_widget"):
            self.history_widget.select_run_by_position(position)

    def _recent_preset_ids(self) -> list[str]:
        settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
        ids = settings.value("presets/recent_ids", [])
        if isinstance(ids, list):
            return [str(x) for x in ids][:5]
        return []

    def _add_recent_preset(self, preset_id: str) -> None:
        settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
        ids = self._recent_preset_ids()
        if preset_id in ids:
            ids.remove(preset_id)
        ids.insert(0, preset_id)
        settings.setValue("presets/recent_ids", ids[:5])

    def _show_start_panel(self) -> None:
        try:
            self._center_panel.show_hero()
        except Exception:
            pass

    def _open_preset_dialog(self) -> None:
        from PySide6.QtWidgets import QDialogButtonBox

        presets = list_presets()
        dlg = QDialog(self)
        dlg.setWindowTitle("Open experiment preset")
        table = QTableWidget(len(presets), 3, dlg)
        table.setHorizontalHeaderLabels(["Label", "Kind", "ID"])
        table.verticalHeader().setVisible(False)
        table.setSelectionBehavior(QTableWidget.SelectRows)
        table.setSelectionMode(QTableWidget.SingleSelection)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        for row, p in enumerate(presets):
            table.setItem(row, 0, QTableWidgetItem(p.label))
            table.setItem(row, 1, QTableWidgetItem(p.kind))
            table.setItem(row, 2, QTableWidgetItem(p.id))
        table.resizeColumnsToContents()
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel, dlg)
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)
        layout = QVBoxLayout(dlg)
        layout.addWidget(table)
        layout.addWidget(buttons)
        dlg.resize(520, 360)
        if dlg.exec() == QDialog.Accepted:
            idxs = table.selectionModel().selectedRows()
            if idxs:
                preset_id = table.item(idxs[0].row(), 2).text()
                self._apply_preset_id(preset_id)

    def _save_experiment_preset(self) -> None:
        state = getattr(self.session, "state", None)
        if state is None:
            QMessageBox.information(self, "Preset", "No active session to save.")
            return
        label, ok = QInputDialog.getText(self, "Save preset", "Preset label:", text="My experiment")
        if not ok or not label:
            return
        preset_id, ok = QInputDialog.getText(self, "Preset ID", "Preset ID (slug):", text=label.lower().replace(" ", "_"))
        if not ok or not preset_id:
            return
        tags, _ = QInputDialog.getText(self, "Tags", "Tags (comma separated):", text="user")

        payload = self.session.to_payload()
        genome_seq = ""
        try:
            genome_seq = payload.get("state", {}).get("config", {}).get("sim_payload", {}).get("site", {}).get("sequence", "")
        except Exception:
            pass
        preset = {
            "schema": "helix_experiment_preset_v1",
            "id": preset_id,
            "label": label,
            "kind": str(getattr(state, "run_kind", "demo")).lower(),
            "created_at": _now_iso(),
            "helix_min_version": "0.4.1",
            "tags": [t.strip() for t in (tags or "").split(",") if t.strip()],
            "genome": {
                "id": payload.get("state", {}).get("genome_hash", "user_genome"),
                "description": "User preset",
                "sequence": genome_seq,
                "coords": {"reference": None, "contig": None, "start": None, "end": None},
            },
            "edit_spec": payload.get("state", {}).get("config", {}).get("edit_spec", {}),
            "crispr": payload.get("state", {}).get("config", {}).get("guide", {}),
            "prime": payload.get("state", {}).get("peg", None),
            "simulation": payload.get("state", {}).get("config", {}).get("run_config", {}),
            "outcomes": payload.get("state", {}).get("outcomes", []),
            "ui_defaults": {
                "layout_preset": "GenomeIDE",
                "run_label": label,
            },
        }
        try:
            save_user_preset(preset_id, preset)
            QMessageBox.information(self, "Preset", f"Saved preset to {preset_id}")
            self._add_recent_preset(preset_id)
        except Exception as exc:
            QMessageBox.critical(self, "Preset", f"Failed to save preset: {exc}")

    def _hydrate_crispr_demo_snapshot(self, snapshot: Mapping[str, object]) -> dict[str, object]:
        """Return a canonical demo snapshot (hg38 EMX1 slice) with workflow + contract metadata."""

        try:
            demo = build_canonical_demo_snapshot()
        except Exception:
            return deepcopy(snapshot) if isinstance(snapshot, Mapping) else {}
        if isinstance(demo, Mapping):
            return deepcopy(demo)
        return deepcopy(snapshot) if isinstance(snapshot, Mapping) else {}

    def _apply_preset_id(self, preset_id: str) -> bool:
        try:
            preset = load_experiment_preset(preset_id)
            snapshot = preset_to_snapshot(preset)
            if preset_id.lower() == "crispr_demo_emx1_v1":
                snapshot = self._hydrate_crispr_demo_snapshot(snapshot)
        except FileNotFoundError:
            QMessageBox.critical(self, "Preset", f"Preset '{preset_id}' not found")
            return False
        except Exception as exc:
            QMessageBox.critical(self, "Preset", f"Failed to load preset: {exc}")
            return False

        try:
            self.session.load_payload(snapshot)
        except Exception as exc:
            QMessageBox.critical(self, "Preset", f"Failed to apply preset: {exc}")
            return False
        try:
            self._prefill_sim_builder(self.session.to_payload())
        except Exception:
            pass

        if self._run_recorded_connected:
            try:
                self.session.runRecorded.emit(snapshot)
            except Exception:
                self._pending_snapshots.append(snapshot)
        else:
            self._pending_snapshots.append(snapshot)

        try:
            self._open_snapshot_in_explorer(snapshot)
        except Exception:
            pass

        rows = build_guide_summaries_from_session(self.session)
        if hasattr(self, "guide_inspector"):
            try:
                self.guide_inspector.set_guide_rows(rows)
            except Exception:
                pass
        self._add_recent_preset(preset_id)
        return True

    def _on_compare_runs(self, lhs: Mapping[str, object], rhs: Mapping[str, object]) -> None:
        self.run_compare_widget.compare_snapshots(lhs, rhs)
        self.session.set_status("Comparing selected runs")

    def _on_baseline_selected(self, snapshot: Mapping[str, object]) -> None:
        self._compare_baseline = snapshot
        self._maybe_update_compare()
        # Feed overlay into Outcome Explorer when available
        try:
            explorer = getattr(self, "workflow_panel", None)
            if explorer and hasattr(explorer, "_explorer"):
                state = snapshot.get("state") if isinstance(snapshot, Mapping) else None
                if isinstance(state, Mapping):
                    run_id = str(state.get("run_id") or snapshot.get("id") or "baseline")
                    evs_payload = _snapshot_to_evs(snapshot, run_id=run_id)
                    evs_payload = _ensure_contract_identity(evs_payload)
                    explorer._explorer.set_baseline_overlay(evs_payload)
        except Exception:
            pass

    def _on_candidate_selected(self, snapshot: Mapping[str, object]) -> None:
        self._compare_candidate = snapshot
        self._maybe_update_compare()
        # Auto-open candidate in EVS so overlay is visible
        self._open_snapshot_in_explorer(snapshot)

    def _open_snapshot_in_explorer(self, snapshot: Mapping[str, object] | None) -> None:
        if snapshot is None:
            return
        try:
            state = snapshot.get("state") if isinstance(snapshot, Mapping) else None
            if not isinstance(state, Mapping):
                return
            run_id = str(state.get("run_id") or snapshot.get("id") or "run")
            evs_payload = _snapshot_to_evs(snapshot, run_id=run_id)
            evs_payload = _ensure_contract_identity(evs_payload)
            self._activate_evs_payload(
                evs_payload,
                run_id=run_id,
                apply_layout_preset=False,
                focus_sidebars=False,
                sync_lightcone=False,
            )
        except Exception:
            pass

    def _maybe_update_compare(self) -> None:
        if self._compare_baseline is None or self._compare_candidate is None:
            return
        a = self._compare_baseline
        b = self._compare_candidate
        def _label(snap: Mapping[str, object], fallback: str) -> str:
            if not isinstance(snap, Mapping):
                return fallback
            state = snap.get("state", {})
            if isinstance(state, Mapping):
                if state.get("run_label"):
                    return str(state.get("run_label"))
                meta = state.get("config", {}).get("metadata", {}) if isinstance(state.get("config"), Mapping) else {}
                if isinstance(meta, Mapping) and meta.get("run_label"):
                    return str(meta.get("run_label"))
                guide = state.get("config", {}).get("guide", {}) if isinstance(state.get("config"), Mapping) else {}
                if isinstance(guide, Mapping) and guide.get("id"):
                    return str(guide.get("id"))
            return fallback

        label_a = _label(a, "baseline")
        label_b = _label(b, "candidate")
        self.run_compare_widget.set_runs(a, label_a, None, None, b, label_b, None, None)
        try:
            explorer = getattr(self, "workflow_panel", None)
            if explorer and hasattr(explorer, "_explorer"):
                baseline_state = a.get("state") if isinstance(a, Mapping) else None
                baseline_evs = None
                if isinstance(baseline_state, Mapping):
                    run_id_a = str(baseline_state.get("run_id") or a.get("id") or "baseline")
                    baseline_evs = _snapshot_to_evs(a, run_id=run_id_a)
                    baseline_evs = _ensure_contract_identity(baseline_evs)
                explorer._explorer.set_baseline_overlay(baseline_evs)

                candidate_state = b.get("state") if isinstance(b, Mapping) else None
                if isinstance(candidate_state, Mapping):
                    run_id_b = str(candidate_state.get("run_id") or b.get("id") or "candidate")
                    candidate_evs = _snapshot_to_evs(b, run_id=run_id_b)
                    candidate_evs = _ensure_contract_identity(candidate_evs)
                    # show candidate in EVS with overlay active
                    explorer._explorer.set_evs(candidate_evs)
        except Exception:
            pass
        # Keep compare in the right sidebar to avoid reparenting the widget.
        try:
            self._set_right_visible(True)
        except Exception:
            pass
        try:
            tabs = getattr(self, "_right_tabs", None)
            if tabs is not None:
                for idx in range(tabs.count()):
                    if "compare" in tabs.tabText(idx).lower():
                        tabs.setCurrentIndex(idx)
                        break
        except Exception:
            pass

    # Guide selection coming from GuideInspector (summary, rank, total)
    def _on_guide_selected(self, summary, rank: int | None = None, total: int | None = None) -> None:
        run: RunModel | None = getattr(summary, "payload_ref", None)
        if run is None:
            return
        showed_gate_message = False
        if hasattr(self, "workflow_panel") and hasattr(self.workflow_panel, "_explorer"):
            try:
                guide = {
                    "id": run.guide_id,
                    "locus": run.target_locus,
                    "pam_index": run.pam_index,
                    "cut_index": run.cut_index,
                }
                meta = run.metadata if isinstance(run.metadata, Mapping) else {}
                artifact = meta.get("run_artifact") if isinstance(meta, Mapping) else None
                if not isinstance(artifact, Mapping):
                    artifact = build_run_artifact_from_run_model(run)
                    if isinstance(meta, Mapping):
                        meta = dict(meta)
                        meta["run_artifact"] = artifact
                        meta["artifact_hash"] = artifact.get("artifact_hash") if isinstance(artifact, Mapping) else None
                        run.metadata = meta
                valid = artifact_is_valid(artifact) if isinstance(artifact, Mapping) else False
                decision_ok = artifact_decision_mode_eligible(artifact) if isinstance(artifact, Mapping) else False
                reasons = artifact_root_causes(artifact) if isinstance(artifact, Mapping) else []
                if isinstance(artifact, Mapping) and not valid:
                    data = build_outcome_explorer_data(
                        run.sequence,
                        guide,
                        [],
                        run_id=run.run_id,
                        physics_run=run.physics,
                        backend_name=run.engine.name,
                        backend_kind=run.engine.backend,
                    )
                    if reasons:
                        self.statusBar().showMessage(
                            f"Run blocked: {', '.join(reasons)}",
                            5000,
                        )
                        showed_gate_message = True
                else:
                    data = build_outcome_explorer_data(
                        run.sequence,
                        guide,
                        [o.to_dict() for o in run.outcomes],
                        run_id=run.run_id,
                        physics_run=run.physics,
                        backend_name=run.engine.name,
                        backend_kind=run.engine.backend,
                    )
                try:
                    self.workflow_panel._explorer.set_decision_mode_gate(
                        valid=valid,
                        decision_mode_eligible=decision_ok,
                        reasons=reasons,
                    )
                except Exception:
                    pass
                self.workflow_panel._explorer.set_run_model(run)
                self.workflow_panel._explorer.set_data(data)
                if decision_ok and rank is not None and total is not None:
                    self.workflow_panel._explorer.set_rank(rank, total)
                else:
                    self.workflow_panel._explorer.set_rank(None, None)
                self.workflow_panel._explorer.set_engine_info(run.engine)
            except Exception:
                pass
        try:
            if hasattr(self, "_run_status_panel") and self._run_status_panel is not None:
                self._run_status_panel.set_run_model(run)
        except Exception:
            pass
        # Update engine panel if present
        try:
            self.workflow_panel.panel.set_engine_info(run.engine)
        except Exception:
            pass
        try:
            gid = getattr(summary, "guide_id", "")
            if gid and not showed_gate_message:
                if decision_ok and rank is not None and total is not None:
                    self.statusBar().showMessage(f"Selected guide {gid} (rank #{rank} of {total})", 3000)
                else:
                    self.statusBar().showMessage(f"Selected guide {gid}", 3000)
        except Exception:
            pass
        try:
            self._schedule_lightcone_sync_from_run(run)
        except Exception:
            pass

    # Toast helpers wired from Outcome Explorer
    def _on_outcome_selected_toast(self, sel: object) -> None:
        name = getattr(sel, "outcome_name", "")
        prob = getattr(sel, "probability", None)
        peak = getattr(sel, "peak_position", None)
        parts = []
        if name:
            parts.append(name)
        if prob is not None:
            parts.append(f"{float(prob) * 100.0:.1f}%")
        if peak is not None:
            parts.append(f"@ {peak} bp")
        msg = "Selected " + " ".join(parts) if parts else "Selected outcome"
        self.statusBar().showMessage(msg, 3000)

    def _on_design_pcr_requested(self, ctx: object) -> None:
        if hasattr(self, "pcr_panel") and getattr(self, "pcr_panel") is not None:
            try:
                self.pcr_panel.prefill_for_outcome(ctx)  # type: ignore[attr-defined]
            except Exception:
                pass
            # Switch to PCR tab if part of main tabs
            try:
                if hasattr(self, "_main_tabs") and self._main_tabs is not None:
                    idx = self._main_tabs.indexOf(self.pcr_panel)  # type: ignore[arg-type]
                    if idx >= 0:
                        self._main_tabs.setCurrentIndex(idx)
            except Exception:
                pass
        name = getattr(ctx, "outcome_name", "")
        prob = getattr(ctx, "probability", None)
        peak = getattr(ctx, "peak_position", None)
        parts = []
        if name:
            parts.append(name)
        if prob is not None:
            parts.append(f"{float(prob) * 100.0:.1f}%")
        if peak is not None:
            parts.append(f"@ {peak} bp")
        msg = "Designing PCR assay for " + " ".join(parts) if parts else "Designing PCR assay"
        self.statusBar().showMessage(msg, 4000)

    def _should_show_welcome_dialog(self) -> tuple[bool, str]:
        """Decide whether to show the welcome dialog and return reason."""
        if os.environ.get("HELIX_STUDIO_SKIP_WELCOME", "0") == "1":
            return False, "HELIX_STUDIO_SKIP_WELCOME=1"
        if os.environ.get("HELIX_STUDIO_FORCE_WELCOME", "0") == "1":
            return True, "HELIX_STUDIO_FORCE_WELCOME=1"
        if _is_headless_platform():
            return False, f"headless platform ({os.environ.get('QT_QPA_PLATFORM', '').lower() or 'offscreen'})"
        if getattr(self.session, "runs", []):
            return False, "session already has runs"
        return True, "empty session"

    def _run_welcome_if_needed(self) -> bool:
        """Run welcome dialog if needed. Returns True to continue, False to exit."""
        if self._welcome_checked:
            return not self._welcome_rejected
        self._welcome_checked = True
        show_welcome, reason = self._should_show_welcome_dialog()
        if not show_welcome:
            print(f"[Welcome] Skipping welcome dialog ({reason})", flush=True)
            if not getattr(self, "_restored_geometry", False):
                self._request_fullscreen()
            return True
        return self._show_welcome_dialog()

    def _show_welcome_dialog(self) -> bool:
        """Display welcome dialog. Returns True if accepted, False if dismissed."""
        force = os.environ.get("HELIX_STUDIO_FORCE_WELCOME", "0") == "1"
        if _is_headless_platform() and not force:
            print("[Welcome] Suppressed in headless mode (set HELIX_STUDIO_FORCE_WELCOME=1 to override)", flush=True)
            return True
        try:
            recent_sessions = self._settings.value("recentSessions", [])
            if not isinstance(recent_sessions, list):
                recent_sessions = []
            # Parentless so window manager doesn't force it onto the main
            # window's screen; welcome dialog handles centering to cursor.
            dlg = WelcomeDialog(None, recent_sessions=recent_sessions)

            def _set_pending(kind: str, payload: str | None = None) -> None:
                self._pending_welcome_action = (kind, payload)
                dlg.accept()

            def _on_demo() -> None:
                _set_pending("demo", None)

            def _on_open() -> None:
                _set_pending("open", None)

            def _on_new(start_mode: str | None = None) -> None:
                _set_pending("new", start_mode)

            def _on_recent(path_str: str) -> None:
                _set_pending("recent", path_str)

            dlg.set_handlers(_on_demo, _on_open, _on_new)

            def _on_prime_demo() -> None:
                _set_pending("prime_demo", None)

            dlg.set_prime_demo_handler(_on_prime_demo)
            dlg.set_recent_handler(_on_recent)
            dlg.set_recent_remove_handler(self._forget_recent_session)
            result = dlg.exec()
            if result != QDialog.Accepted:
                self._welcome_rejected = True
                return False
            self._fullscreen_after_welcome = True
            return True
        except Exception as exc:
            print(f"[Welcome] Failed to show dialog: {exc}", flush=True)
            return False

    def _run_experiment_setup_gate(self, *, start_mode: str | None) -> bool:
        """
        Goal-first setup gate for brand-new sessions.

        Returns True if setup completed (or is unavailable), False if the user canceled.
        """
        try:
            from helix.studio.experiment_setup_dialog import ExperimentSetupDialog

            dlg = ExperimentSetupDialog(start_mode=start_mode, parent=None)
            if dlg.exec() != QDialog.Accepted:
                return False
            result = dlg.result_payload()
            if result is None:
                return False
        except Exception as exc:
            # Fail open if the dialog cannot be constructed (headless/partial installs).
            try:
                print(f"[ExperimentSetup] Setup gate unavailable: {exc}", flush=True)
            except Exception:
                pass
            return True

        cfg = {}
        try:
            raw = getattr(getattr(self.session, "state", None), "config", None)
            cfg = dict(raw) if isinstance(raw, Mapping) else {}
        except Exception:
            cfg = {}

        patch = dict(result.config_patch or {})
        meta_patch = patch.pop("metadata", None)
        if isinstance(meta_patch, Mapping):
            meta = cfg.get("metadata")
            if not isinstance(meta, dict):
                meta = {}
                cfg["metadata"] = meta
            meta.update({str(k): v for k, v in meta_patch.items() if v is not None})
        for k, v in patch.items():
            if v is None:
                continue
            cfg[str(k)] = v

        try:
            self.session.update(config=cfg, experiment_spec=result.experiment_spec)
            self.session.set_experiment_intent_spec(result.experiment_intent_spec)
        except Exception:
            return True

        try:
            self._pending_initial_rail_segment_id = str(result.initial_rail_segment_id or "").strip() or None
        except Exception:
            self._pending_initial_rail_segment_id = None

        try:
            detail: dict[str, Any] = {
                "start_mode": start_mode,
                "primary_goal": result.primary_goal,
                "output_class": result.output_class,
            }
            if result.preset_id:
                detail["intent_preset_id"] = result.preset_id
            self._stamp_session_provenance(
                session_class=result.session_class,
                origin="experiment_setup",
                detail=detail,
            )
        except Exception:
            pass
        return True

    def _run_pending_welcome_action(self, kind: str, payload: str | None) -> None:
        if kind == "demo":
            self._on_open_demo_session()
            self._stamp_session_provenance(
                session_class="demo",
                origin="welcome_screen",
                detail={"demo_kind": "crispr"},
            )
            return
        if kind == "prime_demo":
            self._on_open_prime_demo_session()
            self._stamp_session_provenance(
                session_class="demo",
                origin="welcome_screen",
                detail={"demo_kind": "prime"},
            )
            return
        if kind == "open":
            self._on_open_session()
            return
        if kind == "new":
            if not self._run_experiment_setup_gate(start_mode=payload):
                return
            try:
                self.statusBar().showMessage("Experiment created", 3000)
            except Exception:
                pass
            return
        if kind == "recent" and payload:
            self._open_recent_session(payload)

    def _stamp_session_provenance(
        self,
        *,
        session_class: str,
        origin: str,
        detail: Mapping[str, Any] | None = None,
    ) -> None:
        """Attach provenance metadata to the active session state (local-first)."""

        allowed = {"demo", "exploratory", "decision_candidate"}
        session_class_norm = str(session_class or "").strip().lower()
        if session_class_norm not in allowed:
            return

        state = getattr(self.session, "state", None)
        cfg = getattr(state, "config", None)
        if not isinstance(cfg, dict):
            cfg = {}
            try:
                setattr(state, "config", cfg)
            except Exception:
                return

        meta = cfg.get("metadata")
        if not isinstance(meta, dict):
            meta = {}
            cfg["metadata"] = meta

        existing = str(meta.get("session_class") or "").strip().lower()
        if existing == "demo" and session_class_norm != "demo":
            # Demo sessions cannot be upgraded silently.
            session_class_norm = "demo"
        meta["session_class"] = session_class_norm
        meta["origin"] = str(origin or "").strip() or "unknown"

        toolchain_hash = self._current_toolchain_hash()
        if toolchain_hash:
            meta["toolchain_hash"] = toolchain_hash

        if detail:
            for k, v in detail.items():
                if v is None:
                    continue
                meta[str(k)] = v

        try:
            from helix.support.events import log_event

            log_event(
                "studio.session_provenance_stamped",
                session_class=meta.get("session_class"),
                origin=meta.get("origin"),
            )
        except Exception:
            pass

    def _current_toolchain_hash(self) -> str | None:
        """Hash the active contract identity into a stable toolchain fingerprint."""

        try:
            from helix.scientific_contract import current_contract_identity, load_model_semantics, load_policy, sha256_prefixed

            ident = current_contract_identity()
            if not ident.get("policy_hash") or not ident.get("determinism_class"):
                try:
                    load_policy(None)
                except Exception:
                    pass
            if not ident.get("semantic_hash"):
                try:
                    load_model_semantics(None)
                except Exception:
                    pass
            ident = current_contract_identity()
            payload = {
                "policy_hash": ident.get("policy_hash"),
                "semantic_hash": ident.get("semantic_hash"),
                "determinism_class": ident.get("determinism_class"),
            }
            if not payload.get("policy_hash") and not payload.get("semantic_hash") and not payload.get("determinism_class"):
                return None
            return sha256_prefixed(payload)
        except Exception:
            return None

    def _on_compare_guides(self, a, b) -> None:
        gid_a = getattr(a, "guide_id", "")
        gid_b = getattr(b, "guide_id", "")
        payload_a: RunModel | None = getattr(a, "payload_ref", None)
        payload_b: RunModel | None = getattr(b, "payload_ref", None)
        if payload_a is None or payload_b is None:
            self.statusBar().showMessage("Cannot compare: missing run payload", 4000)
            return
        def _label(summary, run: RunModel):
            parts = [summary.guide_id]
            if run.engine and run.engine.backend:
                parts.append(run.engine.backend.upper())
            if summary.rank and summary.total:
                parts.append(f"#{summary.rank}/{summary.total}")
            return " · ".join(parts)

        self.guide_compare_widget.set_runs(
            payload_a,
            _label(a, payload_a),
            getattr(a, "rank", None),
            getattr(a, "total", None),
            payload_b,
            _label(b, payload_b),
            getattr(b, "rank", None),
            getattr(b, "total", None),
        )
        if self._guide_compare_tab_index is None:
            self._guide_compare_tab_index = self._main_tabs.addTab(self.guide_compare_widget, "Compare guides")
            self._center_tab_index_by_key["compare_guides"] = self._guide_compare_tab_index
            try:
                self._main_tabs.tabBar().setTabData(self._guide_compare_tab_index, "compare_guides")
            except Exception:
                pass
            self._rebuild_center_tab_index_map()
        self._main_tabs.setCurrentIndex(self._guide_compare_tab_index)
        self.statusBar().showMessage(f"Comparing guides {gid_a} and {gid_b}", 4000)

    def _on_export_all_guides(self, out_dir: str, rows: list) -> None:
        # Gate exports in demo/exploratory mode so outputs remain self-describing outside Studio.
        is_demo = False
        try:
            cfg = getattr(getattr(self.session, "state", None), "config", None)
            meta2 = cfg.get("metadata") if isinstance(cfg, Mapping) and isinstance(cfg.get("metadata"), Mapping) else {}
            preset_id = str(meta2.get("preset_id") or "").strip().lower()
            scenario = str(meta2.get("scenario") or "").strip().lower()
            is_demo = bool(scenario == "demo" or preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"))
        except Exception:
            is_demo = False

        decision_mode = "decision_grade"
        saw_run = False
        for summary in rows:
            run = getattr(summary, "payload_ref", None)
            if not isinstance(run, RunModel):
                continue
            saw_run = True
            meta_map = getattr(run, "metadata", None) or {}
            scenario = str(meta_map.get("scenario") or "").strip().lower() if isinstance(meta_map, Mapping) else ""
            if scenario == "demo":
                is_demo = True
            artifact = meta_map.get("run_artifact") if isinstance(meta_map, Mapping) else None
            if not isinstance(artifact, Mapping):
                artifact = build_run_artifact_from_run_model(run)
            requested = str(artifact.get("decision_mode") or "").strip().lower() if isinstance(artifact, Mapping) else ""
            eligible = False
            try:
                eligible = (
                    requested == "decision_grade"
                    and isinstance(artifact, Mapping)
                    and artifact_is_valid(artifact)
                    and artifact_decision_mode_eligible(artifact)
                )
            except Exception:
                eligible = False
            if not eligible:
                decision_mode = "filter_only"
                break
        if not saw_run:
            decision_mode = "filter_only"

        ctx = build_export_context(decision_mode=decision_mode, is_demo=is_demo, run_id=None)
        intent_spec = getattr(getattr(self.session, "state", None), "experiment_intent_spec", None)
        exp_spec = getattr(getattr(self.session, "state", None), "experiment_spec", None)
        plan = getattr(getattr(self.session, "state", None), "edit_plan", None)
        export_policy = None
        try:
            cfg = getattr(getattr(self.session, "state", None), "config", None)
            raw = cfg.get("helixspec_policy") if isinstance(cfg, Mapping) else None
            export_policy = raw if isinstance(raw, Mapping) else None
        except Exception:
            export_policy = None
        if not ensure_export_allowed(
            self,
            action_title="Export guide reports",
            ctx=ctx,
            session_acks=self._export_prompt_suppressed_by_key,
            experiment_intent_spec=intent_spec if isinstance(intent_spec, Mapping) else None,
            experiment_spec=exp_spec if isinstance(exp_spec, Mapping) else None,
            edit_plan=plan if isinstance(plan, Mapping) else None,
            require_wetlab_preflight=True,
            policy=export_policy,
        ):
            return
        exported = 0
        for summary in rows:
            run = getattr(summary, "payload_ref", None)
            if run is None:
                continue
            try:
                self._export_single_guide_report(run, out_dir)
                exported += 1
            except Exception as exc:
                print(f"[GuideInspector] Failed to export report for {getattr(summary, 'guide_id', '')}: {exc}", flush=True)
        self.statusBar().showMessage(f"Exported {exported} guide reports to {out_dir}", 5000)

    def _on_open_demo_session(self) -> None:
        if not self._apply_preset_id("crispr_demo_emx1_v1"):
            snapshot = build_canonical_demo_snapshot()
            try:
                self.session.load_payload(snapshot)
            except Exception:
                return
            try:
                self._prefill_sim_builder(self.session.to_payload())
            except Exception:
                pass
        try:
            from helix.support.events import log_event

            log_event("studio.demo_opened", demo="crispr")
        except Exception:
            pass
        self.statusBar().showMessage(
            "Demo session loaded. Use Guide Inspector to switch guides; Outcome Explorer and Helix update automatically.",
            8000,
        )

    def _on_open_prime_demo_session(self) -> None:
        if self._apply_preset_id("prime_demo_emx1_v1"):
            try:
                from helix.support.events import log_event

                log_event("studio.demo_opened", demo="prime")
            except Exception:
                pass
            self.statusBar().showMessage("Prime demo loaded", 6000)
            try:
                rid = self.latest_run_id()
                if rid:
                    self.on_run_activated(rid)
            except Exception:
                pass

    def _on_export_evidence(self) -> None:
        # Export latest run in session as evidence payload.
        run = self.session.runs[-1] if getattr(self.session, "runs", None) else None
        if run is None:
            QMessageBox.information(self, "Evidence export", "No runs available to export.")
            return
        meta = getattr(run, "metadata", None)
        scenario = str(meta.get("scenario") or "").strip().lower() if isinstance(meta, Mapping) else ""
        cfg = getattr(getattr(self.session, "state", None), "config", None)
        meta2 = cfg.get("metadata") if isinstance(cfg, Mapping) and isinstance(cfg.get("metadata"), Mapping) else {}
        preset_id = str(meta2.get("preset_id") or "").strip().lower()
        is_demo = bool(scenario == "demo" or preset_id.startswith("crispr_demo_") or preset_id.startswith("prime_demo_"))

        artifact = meta.get("run_artifact") if isinstance(meta, Mapping) else None
        if not isinstance(artifact, Mapping):
            artifact = build_run_artifact_from_run_model(run)
        decision_mode = "filter_only"
        try:
            if (
                isinstance(artifact, Mapping)
                and str(artifact.get("decision_mode") or "").strip().lower() == "decision_grade"
                and artifact_is_valid(artifact)
                and artifact_decision_mode_eligible(artifact)
            ):
                decision_mode = "decision_grade"
        except Exception:
            decision_mode = "filter_only"

        ctx = build_export_context(decision_mode=decision_mode, is_demo=is_demo, run_id=getattr(run, "run_id", None))
        intent_spec = getattr(getattr(self.session, "state", None), "experiment_intent_spec", None)
        exp_spec = getattr(getattr(self.session, "state", None), "experiment_spec", None)
        plan = getattr(getattr(self.session, "state", None), "edit_plan", None)
        export_policy = None
        try:
            cfg3 = getattr(getattr(self.session, "state", None), "config", None)
            raw = cfg3.get("helixspec_policy") if isinstance(cfg3, Mapping) else None
            export_policy = raw if isinstance(raw, Mapping) else None
        except Exception:
            export_policy = None
        summary = meta.get("run_summary") if isinstance(meta, Mapping) else None
        if not ensure_export_allowed(
            self,
            action_title="Export evidence",
            ctx=ctx,
            session_acks=self._export_prompt_suppressed_by_key,
            run_summary_v2=summary if isinstance(summary, Mapping) else None,
            experiment_intent_spec=intent_spec if isinstance(intent_spec, Mapping) else None,
            experiment_spec=exp_spec if isinstance(exp_spec, Mapping) else None,
            edit_plan=plan if isinstance(plan, Mapping) else None,
            require_wetlab_preflight=True,
            policy=export_policy,
        ):
            return
        path_str, _ = QFileDialog.getSaveFileName(self, "Export VeriBiota evidence", filter="JSON (*.json)")
        if not path_str:
            return
        try:
            preset_id = getattr(self, "_last_preset_id", None)
            preset = load_experiment_preset(preset_id) if preset_id else None
        except Exception:
            preset = None
        evidence = run_to_evidence(run, preset=preset, include_sequence=False)
        try:
            write_evidence_json(evidence, Path(path_str))
            self.statusBar().showMessage(f"Evidence saved to {path_str}", 5000)
        except Exception as exc:
            QMessageBox.critical(self, "Evidence export", f"Failed to save evidence: {exc}")

    def _on_export_support_bundle(self) -> None:
        from helix.support.bundle import write_support_bundle

        stamp = clock.local_now_stamp()
        default_name = str(Path.cwd() / f"helix_support_bundle_{stamp}.zip")
        path_str, _ = QFileDialog.getSaveFileName(self, "Export support bundle", default_name, "Zip archive (*.zip)")
        if not path_str:
            return

        session_payload = None
        try:
            session_payload = self.session.to_payload(timestamp=True)
        except Exception:
            session_payload = None

        log_tail = ""
        try:
            text = self.log_widget.toPlainText()
            lines = text.splitlines()
            log_tail = "\n".join(lines[-400:]) + ("\n" if lines else "")
        except Exception:
            log_tail = ""

        try:
            out = write_support_bundle(path_str, session_payload=session_payload, extra_logs=log_tail, redact=True)
            self.statusBar().showMessage(f"Support bundle saved to {out}", 8000)
        except Exception as exc:
            QMessageBox.critical(self, "Support bundle", f"Failed to write support bundle: {exc}")

    def _on_run_doctor(self) -> None:
        try:
            from helix.studio.doctor_dialog import DoctorDialog

            DoctorDialog(self).exec()
        except Exception as exc:
            QMessageBox.critical(self, "Doctor", f"Failed to render doctor output: {exc}")

    def _on_show_about(self) -> None:
        try:
            from helix.studio.about_dialog import AboutDialog

            AboutDialog(self).exec()
        except Exception as exc:
            QMessageBox.critical(self, "About", f"Failed to show About dialog: {exc}")

    def _prefill_sim_builder(self, snapshot: Mapping[str, Any]) -> None:
        """Sync the Sim Builder UI from a session snapshot."""
        sim_panel = getattr(self, "sim_panel", None)
        if sim_panel is None:
            return
        state = snapshot.get("state") if isinstance(snapshot, Mapping) else {}
        if not isinstance(state, Mapping):
            return
        config = state.get("config") if isinstance(state, Mapping) else {}
        genome = state.get("genome") if isinstance(state, Mapping) else {}
        seq = ""
        if isinstance(config, Mapping):
            sim_payload = config.get("sim_payload")
            if isinstance(sim_payload, Mapping):
                site = sim_payload.get("site")
                if isinstance(site, Mapping):
                    candidate = site.get("sequence")
                    if isinstance(candidate, str) and candidate:
                        seq = candidate
        if not seq:
            try:
                candidate = state.get("viz_spec_payload", {}).get("sequence", "")
                if isinstance(candidate, str):
                    seq = candidate
            except Exception:
                seq = ""
        if not seq and isinstance(genome, Mapping):
            for val in genome.values():
                if isinstance(val, str) and val:
                    seq = val
                    break
        if seq:
            try:
                sim_panel.sequence_input.set_sequence(seq)
            except Exception:
                pass

        sim_settings = config.get("sim_settings") if isinstance(config, Mapping) else {}
        if isinstance(sim_settings, Mapping):
            try:
                sim_panel.sim_settings.apply_dict(sim_settings)
            except Exception:
                pass
        guide = config.get("guide") if isinstance(config, Mapping) else {}
        if guide and hasattr(sim_panel, "crispr_tab"):
            try:
                tab = sim_panel.crispr_tab
                tab._guide_list.clear()
                label = f"{guide.get('id', 'guide')} – {guide.get('start', '?')}-{guide.get('end', '?')} ({guide.get('strand', '+')})"
                item = QListWidgetItem(label)
                item.setData(Qt.UserRole, guide)
                tab._guide_list.addItem(item)
                tab._guide_list.setCurrentItem(item)
                tab._guides = [guide]
            except Exception:
                pass

    def _on_save_session(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Helix session",
            "helix_session.helix",
            "Helix session (*.helix);;All files (*.*)",
        )
        if not path:
            return
        save_session(path, self.session)
        try:
            self._remember_recent_session(path)
        except Exception:
            pass
        self.statusBar().showMessage(f"Saved session to {path}", 4000)

    def _on_open_session(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Open Helix session",
            "",
            "Helix session (*.helix);;All files (*.*)",
        )
        if not path:
            return
        # Reuse existing session model to keep signal wiring
        try:
            import json

            raw = json.loads(Path(path).read_text(encoding="utf8"))
            self.session.load_payload(raw)
            try:
                self._prefill_sim_builder(self.session.to_payload())
            except Exception:
                pass
        except Exception:
            self.statusBar().showMessage(f"Failed to load session from {path}", 5000)
            return

        rows = build_guide_summaries_from_session(self.session)
        if hasattr(self, "guide_inspector"):
            try:
                self.guide_inspector.set_guide_rows(rows)
                if rows:
                    self.guide_inspector.table.selectRow(0)
            except Exception:
                pass
        try:
            self._remember_recent_session(path)
        except Exception:
            pass
        self.statusBar().showMessage(f"Loaded session from {path}", 4000)

    def _export_single_guide_report(self, run: object, out_dir: str) -> None:
        if not isinstance(run, RunModel):
            return
        meta_map = run.metadata or {}
        if isinstance(meta_map, Mapping) and meta_map.get("invalid"):
            QMessageBox.warning(self, "Export report", "Export disabled: run marked invalid.")
            return
        artifact = meta_map.get("run_artifact") if isinstance(meta_map, Mapping) else None
        if not isinstance(artifact, Mapping):
            artifact = build_run_artifact_from_run_model(run)
        if isinstance(artifact, Mapping) and not artifact_is_valid(artifact):
            reasons = ", ".join(artifact_root_causes(artifact)) or "artifact invalid"
            QMessageBox.warning(self, "Export report", f"Export disabled: {reasons}")
            return
        guide = {
            "id": run.guide_id,
            "locus": run.target_locus,
            "pam_index": run.pam_index,
            "cut_index": run.cut_index,
        }
        outcomes = [o.to_dict() for o in run.outcomes]
        data = build_outcome_explorer_data(
            run.sequence,
            guide,
            outcomes,
            run_id=run.run_id,
            physics_run=run.physics,
            backend_name=run.engine.name,
            backend_kind=run.engine.backend,
        )
        decision_ok = artifact_decision_mode_eligible(artifact) if isinstance(artifact, Mapping) else False
        reasons = artifact_root_causes(artifact) if isinstance(artifact, Mapping) else []
        try:
            self.workflow_panel._explorer.set_decision_mode_gate(
                valid=True,
                decision_mode_eligible=decision_ok,
                reasons=reasons,
            )
        except Exception:
            pass
        self.workflow_panel._explorer.set_run_model(run)
        self.workflow_panel._explorer.set_data(data)
        self.workflow_panel._explorer.set_engine_info(run.engine)
        try:
            if hasattr(self, "_run_status_panel") and self._run_status_panel is not None:
                self._run_status_panel.set_run_model(run)
        except Exception:
            pass
        stamp = limitations_stamp()
        chart_bytes = self.workflow_panel._explorer._pixmap_to_png_bytes(
            self.workflow_panel._explorer.chart.grab(), stamp
        )
        guide_meta = {
            "guide_id": run.guide_id,
            "target_locus": run.target_locus,
            "run_id": run.run_id,
            "edit_type": run.edit_type,
        }
        outcomes_serializable = [
            {
                "name": r.label,
                "category": r.category,
                "prob": r.probability,
                "delta_bp": r.delta_bp,
                "frameshift": r.frameshift,
                "peak_position": r.peak_pos,
                "position_min": r.start,
                "position_max": r.end,
                "microhomology": r.microhomology,
                "pbs_dG": r.pbs_dg,
                "flap_ddG": r.flap_ddg,
                "E_pred": r.e_pred,
            }
            for r in data.rows
        ]
        physics_payload = dict(run.physics or {})
        physics_payload.setdefault("engine_name", run.engine.name)
        physics_payload.setdefault("backend", run.engine.backend)
        physics_payload.setdefault("crispr_scoring_version", run.engine.crispr_scoring_version)
        physics_payload.setdefault("prime_scoring_version", run.engine.prime_scoring_version)

        contract_v2 = None
        try:
            if isinstance(meta_map, Mapping):
                cand = meta_map.get("run_summary")
                contract_v2 = cand if isinstance(cand, Mapping) else None
        except Exception:
            contract_v2 = None

        fname = f"helix_report_{guide_meta['guide_id']}_{guide_meta['run_id']}.html"
        save_session_report(
            Path(out_dir) / fname,
            guide_meta,
            physics_payload,
            outcomes_serializable,
            chart_bytes,
            helix_flat_png=None,
            helix_helix_png=None,
            csv_text=None,
            extra_metadata={(run.metadata or {}) | {"run_id": run.run_id, "limitations": stamp}},
            contract_v2=contract_v2,
            limitations=stamp,
        )

    def _show_shortcuts_dialog(self) -> None:
        shortcuts = [
            ("Hero", "Ctrl+D", "Open CRISPR demo"),
            ("Hero", "Ctrl+L", "Open latest run"),
            ("Hero", "Ctrl+Shift+H", "Show start panel"),
            ("Global", "Ctrl+Shift+P", "Command palette"),
            ("Global", "Ctrl+Alt+P", "Open prime demo"),
            ("Global", "Ctrl+R", "Re-run active SimBuilder tab"),
            ("Global", "Ctrl+S / Ctrl+Shift+S", "Save session / Save as"),
            ("Global", "Ctrl+O", "Load session"),
            ("Global", "Ctrl+Shift+E", "Open experiment preset"),
            ("Global", "Ctrl+Alt+S", "Save experiment as preset"),
            ("Terminal", "Ctrl+` / Ctrl+Shift+`", "Show terminal / New tab"),
            ("Run History", "Ctrl+F", "Focus search"),
            ("Run History", "Ctrl+Shift+I", "Toggle intended filter"),
            ("Run History", "Ctrl+Shift+K", "Cycle run kinds"),
            ("Run History", "Ctrl+Shift+F", "Clear filters"),
            ("Run History", "B", "Set selected as baseline"),
            ("Run History", "C", "Set selected as candidate"),
            ("Run History", "Ctrl+1..0", "Jump to run rows"),
        ]

        dlg = QDialog(self)
        dlg.setWindowTitle("Keyboard Shortcuts")
        dlg.setObjectName("ShortcutDialog")
        table = QTableWidget(len(shortcuts), 3, dlg)
        table.setHorizontalHeaderLabels(["Scope", "Shortcut", "Action"])
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.setSelectionMode(QTableWidget.NoSelection)
        table.setFocusPolicy(Qt.NoFocus)
        for row, (scope, keys, action) in enumerate(shortcuts):
            table.setItem(row, 0, QTableWidgetItem(scope))
            table.setItem(row, 1, QTableWidgetItem(keys))
            table.setItem(row, 2, QTableWidgetItem(action))
        table.resizeColumnsToContents()
        layout = QVBoxLayout(dlg)
        layout.addWidget(table)
        dlg.resize(520, 360)
        dlg.exec()


def _snapshot_to_evs(snapshot: Mapping[str, object], run_id: str) -> dict[str, object]:
    """Build a minimal EVS v1.1 document from a legacy snapshot payload."""

    state = snapshot.get("state") if isinstance(snapshot, Mapping) else {}
    config = state.get("config") if isinstance(state, Mapping) else {}
    outcomes = state.get("outcomes") if isinstance(state, Mapping) else []
    viz_spec = state.get("viz_spec_payload") if isinstance(state, Mapping) else {}
    site = {}
    guide_meta = {}
    if isinstance(viz_spec, Mapping):
        site = viz_spec.get("site") or {}
        guide_meta = viz_spec.get("guide") or {}

    seq = ""
    chrom = "chrGui"
    start = 0
    end = 0
    if isinstance(site, Mapping):
        seq = str(site.get("sequence") or "")
        end = site.get("length") or len(seq)
        chrom = site.get("chrom") or chrom

    g_seq = ""
    g_label = None
    if isinstance(guide_meta, Mapping):
        g_seq = str(guide_meta.get("sequence") or "")
        g_label = guide_meta.get("id") or guide_meta.get("name")

    alleles: list[dict[str, object]] = []
    if isinstance(outcomes, list):
        def _delta_bp(diff: Mapping[str, object] | None) -> int:
            if not diff:
                return 0
            edit = str(diff.get("edit") or diff.get("kind") or "").lower()
            start = diff.get("start")
            end = diff.get("end")
            repl = diff.get("replacement")

            if repl is not None and start is not None and end is not None:
                try:
                    return len(str(repl)) - (int(end) - int(start))
                except Exception:
                    return 0

            if repl is None and start is not None and end is not None:
                try:
                    span = int(end) - int(start)
                    if span > 0:
                        return -span
                except Exception:
                    return 0

            if edit.startswith("del"):
                try:
                    mag = int("".join(ch for ch in edit if ch.isdigit()) or "0")
                    return -mag
                except Exception:
                    return 0
            if edit.startswith("ins"):
                try:
                    mag = int("".join(ch for ch in edit if ch.isdigit()) or "0")
                    return mag
                except Exception:
                    return 0
            return 0

        for out in outcomes:
            if not isinstance(out, Mapping):
                continue
            diff = out.get("diff") if isinstance(out.get("diff"), Mapping) else None
            delta_bp = out.get("delta_bp")
            if delta_bp is None:
                try:
                    delta_bp = _delta_bp(diff)
                except Exception:
                    delta_bp = None
            alleles.append(
                {
                    "label": out.get("label") or "outcome",
                    "frequency": float(out.get("probability") or out.get("count") or 0),
                    "count": out.get("count"),
                    "sequence": out.get("sequence"),
                    "deltaBp": delta_bp,
                    "diff": diff,
                }
            )

    return {
        "specVersion": "1.1",
        "id": str(run_id),
        "createdAt": snapshot.get("created_at") or snapshot.get("timestamp"),
        "sequence": {
            "ref": seq,
            "referenceLocus": {"chrom": chrom, "start": start, "end": end},
        },
        "editPlan": {
            "mode": str(state.get("run_kind") or "crispr").lower(),
            "targets": [
                {
                    "label": g_label or "guide",
                    "gRNA": {"sequence": g_seq, "pam": config.get("pam_profile")},
                }
            ],
        },
        "simulation": {
            "engine": "helix-gui",
            "params": config,
            "results": {"alleles": alleles},
        },
        "visualization": {
            "layers": [
                {
                    "kind": "Track:Outcomes",
                    "visible": True,
                    "style": {
                        "chartMode": "probabilities",
                        "viewPreset": "balanced",
                        "sortBy": "probability",
                        "filter": "all",
                    },
                }
            ],
            "selection": {
                "selectedOutcomeLabel": alleles[0]["label"] if alleles else None,
            },
        },
        "provenance": {"app": "Helix Studio"},
    }
