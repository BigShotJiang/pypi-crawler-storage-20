"""Lightweight project/workspace model for Helix Studio.

The goal is to give Studio a persistent home for sessions, datasets, and
snapshot bundles without forcing GUI dependencies. Paths are stored relative to
the project root so projects remain portable.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, Mapping

from helix import clock

def _utc_now_iso() -> str:
    return clock.utc_now_iso_offset()


def _relpath(root: Path, target: Path) -> str:
    root = root.resolve()
    target = target.resolve()
    try:
        return str(target.relative_to(root))
    except ValueError:
        return str(target)


def _to_path(root: Path, raw: str) -> Path:
    p = Path(raw)
    if not p.is_absolute():
        return (root / p).resolve()
    return p


@dataclass
class DatasetRef:
    name: str
    kind: str
    path: Path

    def to_dict(self, root: Path) -> Dict[str, Any]:
        return {"name": self.name, "kind": self.kind, "path": _relpath(root, self.path)}

    @classmethod
    def from_dict(cls, root: Path, payload: Mapping[str, Any]) -> "DatasetRef":
        return cls(
            name=str(payload["name"]),
            kind=str(payload["kind"]),
            path=_to_path(root, str(payload["path"])),
        )


@dataclass
class SessionRef:
    session_id: str
    path: Path

    def to_dict(self, root: Path) -> Dict[str, Any]:
        return {"session_id": self.session_id, "path": _relpath(root, self.path)}

    @classmethod
    def from_dict(cls, root: Path, payload: Mapping[str, Any]) -> "SessionRef":
        return cls(
            session_id=str(payload["session_id"]),
            path=_to_path(root, str(payload["path"])),
        )


@dataclass
class SnapshotBundleRef:
    snapshot_id: str
    path: Path
    created_at: str | None = None
    session_id: str | None = None
    run_kind: str | None = None
    external: bool = False

    def to_dict(self, root: Path) -> Dict[str, Any]:
        rel = _relpath(root, self.path)
        external = self.external or rel.startswith("..")
        return {
            "snapshot_id": self.snapshot_id,
            "path": rel,
            "created_at": self.created_at,
            "session_id": self.session_id,
            "run_kind": self.run_kind,
            "external": external,
        }

    @classmethod
    def from_dict(cls, root: Path, payload: Mapping[str, Any]) -> "SnapshotBundleRef":
        path = _to_path(root, str(payload["path"]))
        rel_external = bool(payload.get("external", False))
        return cls(
            snapshot_id=str(payload["snapshot_id"]),
            path=path,
            created_at=str(payload.get("created_at") or ""),
            session_id=payload.get("session_id"),
            run_kind=payload.get("run_kind"),
            external=rel_external or not path.is_relative_to(root),
        )


@dataclass
class ImportedRunRef:
    id: str
    kind: str
    source: str
    rel_path: str
    name: str
    external: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "kind": self.kind,
            "source": self.source,
            "rel_path": self.rel_path,
            "name": self.name,
            "external": self.external,
        }

    @classmethod
    def from_dict(cls, root: Path, payload: Mapping[str, Any]) -> "ImportedRunRef":
        rel_path = str(payload.get("rel_path") or "")
        external = bool(payload.get("external", False))
        try:
            candidate = (root / rel_path).resolve()
            external = external or not candidate.is_relative_to(root.resolve())
        except Exception:
            pass
        return cls(
            id=str(payload["id"]),
            kind=str(payload.get("kind") or ""),
            source=str(payload.get("source") or ""),
            rel_path=rel_path,
            name=str(payload.get("name") or str(payload.get("id"))),
            external=external,
        )


@dataclass
class ProjectModel:
    root_path: Path
    name: str
    created_at: str = field(default_factory=_utc_now_iso)
    engine_config: Dict[str, Any] = field(default_factory=dict)
    datasets: Dict[str, DatasetRef] = field(default_factory=dict)
    sessions: Dict[str, SessionRef] = field(default_factory=dict)
    snapshots: Dict[str, SnapshotBundleRef] = field(default_factory=dict)
    imported_runs: Dict[str, ImportedRunRef] = field(default_factory=dict)

    # ---------- Persistence ----------
    @property
    def metadata_path(self) -> Path:
        return (self.root_path / ".helix_project.json").resolve()

    def save(self) -> None:
        self.root_path.mkdir(parents=True, exist_ok=True)
        payload = {
            "name": self.name,
            "created_at": self.created_at,
            "engine_config": self.engine_config,
            "datasets": {k: v.to_dict(self.root_path) for k, v in self.datasets.items()},
            "sessions": {k: v.to_dict(self.root_path) for k, v in self.sessions.items()},
            "snapshots": {k: v.to_dict(self.root_path) for k, v in self.snapshots.items()},
            "imported_runs": {k: v.to_dict() for k, v in self.imported_runs.items()},
        }
        self.metadata_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, root_path: Path) -> "ProjectModel":
        root_path = Path(root_path).resolve()
        meta_path = root_path / ".helix_project.json"
        data = json.loads(meta_path.read_text(encoding="utf-8"))
        project = cls(
            root_path=root_path,
            name=str(data["name"]),
            created_at=str(data.get("created_at") or _utc_now_iso()),
            engine_config=dict(data.get("engine_config") or {}),
        )
        for key, payload in (data.get("datasets") or {}).items():
            project.datasets[key] = DatasetRef.from_dict(root_path, payload)
        for key, payload in (data.get("sessions") or {}).items():
            project.sessions[key] = SessionRef.from_dict(root_path, payload)
        for key, payload in (data.get("snapshots") or {}).items():
            project.snapshots[key] = SnapshotBundleRef.from_dict(root_path, payload)
        for key, payload in (data.get("imported_runs") or {}).items():
            project.imported_runs[key] = ImportedRunRef.from_dict(root_path, payload)
        return project

    # ---------- Helpers ----------
    def register_dataset(self, name: str, kind: str, path: Path) -> DatasetRef:
        ref = DatasetRef(name=name, kind=kind, path=Path(path).resolve())
        self.datasets[name] = ref
        return ref

    def register_session(self, session_id: str, path: Path) -> SessionRef:
        ref = SessionRef(session_id=session_id, path=Path(path).resolve())
        self.sessions[session_id] = ref
        return ref

    def register_snapshot(self, snapshot_id: str, path: Path, *, created_at: str | None = None, session_id: str | None = None, run_kind: str | None = None) -> SnapshotBundleRef:
        ref = SnapshotBundleRef(
            snapshot_id=snapshot_id,
            path=Path(path).resolve(),
            created_at=created_at or _utc_now_iso(),
            session_id=session_id,
            run_kind=run_kind,
            external=not Path(path).resolve().is_relative_to(self.root_path.resolve()),
        )
        self.snapshots[snapshot_id] = ref
        return ref

    def register_imported_run(self, run_id: str, *, kind: str, source: str, raw_path: Path, name: str) -> ImportedRunRef:
        root = self.root_path.resolve()
        raw_path = Path(raw_path).resolve()
        try:
            rel_path = raw_path.relative_to(root)
            external = False
        except Exception:
            rel_path = raw_path
            external = True
        ref = ImportedRunRef(
            id=run_id,
            kind=kind,
            source=source,
            rel_path=str(rel_path),
            name=name,
            external=external,
        )
        self.imported_runs[run_id] = ref
        return ref


__all__ = [
    "ProjectModel",
    "DatasetRef",
    "SessionRef",
    "SnapshotBundleRef",
    "ImportedRunRef",
]
