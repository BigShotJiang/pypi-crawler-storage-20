from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class CellContext:
    cell_line: str | None = None
    delivery_mode: str | None = None
    repair_bias_preset: str | None = None
    accessibility_scalar: float | None = None


def _safe_text(value: Any) -> str:
    return str(value or "").strip()


def _safe_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        parsed = float(value)
    except Exception:
        return None
    if not math.isfinite(parsed):
        return None
    return float(parsed)


def normalize_delivery_mode(value: Any) -> str | None:
    token = _safe_text(value)
    if not token:
        return None
    normalized = token.lower()
    if normalized == "rnp":
        return "RNP"
    if normalized in {"mrna", "m-rna"}:
        return "mRNA"
    if normalized == "plasmid":
        return "plasmid"
    if normalized == "viral":
        return "viral"
    return None


def normalize_repair_bias_preset(value: Any) -> str | None:
    token = _safe_text(value)
    if not token:
        return None
    normalized = token.lower()
    if normalized in {"neutral", "nhej_heavy", "mmej_heavy", "hdr_heavy"}:
        return normalized
    return None


def parse_cell_context(assumptions: Mapping[str, Any] | None) -> tuple[CellContext, list[str]]:
    warnings: list[str] = []
    src = assumptions if isinstance(assumptions, Mapping) else {}

    cell_line = _safe_text(src.get("cellLine") or src.get("cell_line")) or None

    raw_delivery = src.get("delivery") if "delivery" in src else src.get("deliveryMode") or src.get("delivery_mode")
    delivery = normalize_delivery_mode(raw_delivery)
    if raw_delivery is not None and _safe_text(raw_delivery) and delivery is None:
        warnings.append(f"Unknown delivery mode: {raw_delivery!r} (expected RNP, mRNA, plasmid, viral).")

    raw_bias = (
        src.get("repairBiasPreset")
        if "repairBiasPreset" in src
        else src.get("repair_bias_preset") or src.get("repairBias") or src.get("repair_bias")
    )
    repair_bias = normalize_repair_bias_preset(raw_bias)
    if raw_bias is not None and _safe_text(raw_bias) and repair_bias is None:
        warnings.append(
            "Unknown repairBiasPreset: "
            f"{raw_bias!r} (expected neutral, nhej_heavy, mmej_heavy, hdr_heavy)."
        )

    raw_access = src.get("accessibilityScalar") if "accessibilityScalar" in src else src.get("accessibility_scalar")
    accessibility = _safe_float(raw_access)
    if raw_access is not None and accessibility is None:
        warnings.append(f"Invalid accessibilityScalar: {raw_access!r} (expected a finite number).")
    if accessibility is not None and accessibility < 0.0:
        warnings.append(f"Invalid accessibilityScalar: {raw_access!r} (expected >= 0).")
        accessibility = None

    return (
        CellContext(
            cell_line=cell_line,
            delivery_mode=delivery,
            repair_bias_preset=repair_bias,
            accessibility_scalar=accessibility,
        ),
        warnings,
    )


def cell_context_breadcrumb(ctx: CellContext) -> str:
    cell_line = ctx.cell_line or "—"
    delivery = ctx.delivery_mode or "RNP"
    repair_bias = ctx.repair_bias_preset or "neutral"
    parts = [f"cellLine={cell_line}", f"delivery={delivery}", f"repairBias={repair_bias}"]
    if ctx.accessibility_scalar is not None:
        parts.append(f"accessibilityScalar={ctx.accessibility_scalar:g}")
    return "Cell context: " + " • ".join(parts)


def dynamic_indel_overrides_for_repair_preset(preset: str | None) -> dict[str, float]:
    preset = normalize_repair_bias_preset(preset) or "neutral"
    if preset == "neutral":
        return {}
    if preset == "nhej_heavy":
        return {
            "p_precise_repair": 0.07,
            "small_insertion_weight": 0.22,
            "small_deletion_weight": 0.20,
            "large_deletion_weight": 0.08,
            "large_del_weight_boost": 0.6,
        }
    if preset == "mmej_heavy":
        return {
            "p_precise_repair": 0.06,
            "small_insertion_weight": 0.12,
            "small_deletion_weight": 0.20,
            "large_deletion_weight": 0.18,
            "large_del_weight_boost": 1.8,
        }
    if preset == "hdr_heavy":
        return {
            "p_precise_repair": 0.30,
            "small_insertion_weight": 0.14,
            "small_deletion_weight": 0.12,
            "large_deletion_weight": 0.06,
            "large_del_weight_boost": 0.5,
        }
    return {}


@dataclass(frozen=True)
class CutModelRepairShapeBias:
    insertion_weight_mult: float = 1.0
    deletion_weight_mult: float = 1.0
    microhomology_mult: float = 1.0


def cut_model_bias_for_repair_preset(preset: str | None) -> CutModelRepairShapeBias:
    preset = normalize_repair_bias_preset(preset) or "neutral"
    if preset == "nhej_heavy":
        return CutModelRepairShapeBias(insertion_weight_mult=1.35, deletion_weight_mult=0.9, microhomology_mult=0.75)
    if preset == "mmej_heavy":
        return CutModelRepairShapeBias(insertion_weight_mult=0.75, deletion_weight_mult=1.15, microhomology_mult=1.35)
    return CutModelRepairShapeBias()


__all__ = [
    "CellContext",
    "CutModelRepairShapeBias",
    "cell_context_breadcrumb",
    "cut_model_bias_for_repair_preset",
    "dynamic_indel_overrides_for_repair_preset",
    "normalize_delivery_mode",
    "normalize_repair_bias_preset",
    "parse_cell_context",
]

