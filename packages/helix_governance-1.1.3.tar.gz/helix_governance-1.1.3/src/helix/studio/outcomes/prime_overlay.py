from __future__ import annotations

import json
from typing import Any, Mapping


def _extract_prime_config(edit_plan: Mapping[str, Any] | None) -> Mapping[str, Any]:
    if not isinstance(edit_plan, Mapping):
        return {}
    prime_cfg = edit_plan.get("prime") or edit_plan.get("pegRNA") or edit_plan.get("peg") or {}
    return prime_cfg if isinstance(prime_cfg, Mapping) else {}


def _extract_nick_pos(prime_cfg: Mapping[str, Any]) -> int | None:
    for key in ("nick_pos_bp", "nick_pos", "nickPos", "nick"):
        if key in prime_cfg:
            try:
                return int(prime_cfg.get(key))
            except Exception:
                continue
    nick = prime_cfg.get("nicking_guide") if isinstance(prime_cfg.get("nicking_guide"), Mapping) else None
    if isinstance(nick, Mapping):
        for key in ("offset", "offset_bp", "offsetBp"):
            if key in nick:
                try:
                    return int(nick.get(key))
                except Exception:
                    continue
    return None


def _normalize_pos(pos: int | None, *, window_start: int | None, seq_len: int) -> int | None:
    if pos is None:
        return None
    try:
        pos_int = int(pos)
    except Exception:
        return None
    if 0 <= pos_int < seq_len:
        return pos_int
    if window_start is not None:
        rel = pos_int - window_start
        if 0 <= rel < seq_len:
            return rel
    return None


def _segments_for_kind(
    allele_spectrum: list[Any],
    *,
    kind: str,
    seq_len: int,
) -> list[dict[str, int]]:
    segments: list[dict[str, int]] = []
    kind = str(kind or "").lower().strip()
    if not kind:
        return segments
    for entry in allele_spectrum:
        if not isinstance(entry, Mapping):
            continue
        delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
        delta_kind = str(delta.get("type") or "").lower().strip()
        if delta_kind != kind:
            continue
        try:
            start = int(delta.get("start"))
        except Exception:
            continue
        end_val = delta.get("end")
        length_val = delta.get("length")
        end = None
        if end_val is not None:
            try:
                end = int(end_val)
            except Exception:
                end = None
        if end is None and length_val is not None:
            try:
                end = start + max(1, int(length_val))
            except Exception:
                end = None
        if end is None:
            end = start + 1
        if end <= start:
            continue
        start = max(0, start)
        end = min(seq_len, end)
        if end <= start:
            continue
        segments.append({"start": start, "end": end})
    segments.sort(key=lambda seg: (seg["start"], seg["end"]))
    return segments


def build_prime_overlay(
    report_bytes: bytes,
    *,
    sequence_len: int,
    edit_plan: Mapping[str, Any] | None = None,
    reference_context: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    try:
        payload = json.loads(report_bytes.decode("utf-8"))
    except Exception:
        return {}
    if not isinstance(payload.get("primeOutcomes"), list):
        return {}
    allele_spectrum = payload.get("alleleSpectrum")
    if not isinstance(allele_spectrum, list) or sequence_len <= 0:
        return {}

    desired = _segments_for_kind(allele_spectrum, kind="prime_desired", seq_len=sequence_len)
    partial = _segments_for_kind(allele_spectrum, kind="prime_partial", seq_len=sequence_len)

    window_start = None
    if isinstance(reference_context, Mapping):
        for key in ("windowStart", "window_start", "start"):
            if key in reference_context:
                try:
                    window_start = int(reference_context.get(key))
                except Exception:
                    window_start = None
                break

    prime_cfg = _extract_prime_config(edit_plan)
    nick_pos = _extract_nick_pos(prime_cfg)
    nick_index = _normalize_pos(nick_pos, window_start=window_start, seq_len=sequence_len)

    if not desired and not partial and nick_index is None:
        return {}

    overlay: dict[str, Any] = {
        "desired": desired,
        "partial": partial,
    }
    if nick_index is not None:
        overlay["nick_index"] = nick_index
    return overlay


__all__ = ["build_prime_overlay"]
