from __future__ import annotations

from typing import Any, Mapping

from helix.studio.experiment_spec import experiment_spec_to_dict

from .model import OutcomeReportV1, compute_inputs_sha256


class NoopOutcomeModel:
    model_id = "noop"
    model_version = "v1"

    def run(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
    ) -> OutcomeReportV1:
        inputs_sha = compute_inputs_sha256(experiment_spec, edit_plan, reference_context)
        missing: list[str] = []
        spec = experiment_spec_to_dict(experiment_spec)
        if not experiment_spec:
            missing.append("experimentSpec")
        else:
            if not spec.get("intent"):
                missing.append("experimentSpec.intent")
            ref = spec.get("reference") if isinstance(spec.get("reference"), dict) else {}
            if not ref or not ref.get("genomeBuild"):
                missing.append("experimentSpec.reference.genomeBuild")
            locus = spec.get("locus") if isinstance(spec.get("locus"), dict) else {}
            if not locus or not locus.get("chr"):
                missing.append("experimentSpec.locus.chr")
            try:
                start = int(locus.get("start", 0))
                end = int(locus.get("end", 0))
            except Exception:
                start = 0
                end = 0
            if start >= end:
                missing.append("experimentSpec.locus.range")
        if not edit_plan:
            missing.append("editPlan")
        if not reference_context:
            missing.append("referenceContext")

        summary = ["Noop outcome model; no predictions generated."]
        if missing:
            summary.append(f"Inputs incomplete: {', '.join(missing)}")
        return OutcomeReportV1(
            model_id=self.model_id,
            model_version=self.model_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            allele_spectrum=[],
            uncertainty_summary=[],
            uncertainty={},
        )


__all__ = ["NoopOutcomeModel"]
