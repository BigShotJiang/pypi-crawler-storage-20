from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Mapping

from helix.studio.experiment_spec import experiment_spec_to_dict

from .cell_context import (
    CutModelRepairShapeBias,
    cell_context_breadcrumb,
    cut_model_bias_for_repair_preset,
    parse_cell_context,
)
from .intent_eval import evaluate_intent, parse_intent
from .model import OutcomeModel, OutcomeReportV1, compute_inputs_sha256
from .noop import NoopOutcomeModel


@dataclass(frozen=True)
class CutPlan:
    contig: str
    window_start: int
    window_end: int
    cut_index: int
    strand: str
    sequence: str


def _safe_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _normalize_base(base: str) -> str:
    base = (base or "").upper()
    return base if base in {"A", "C", "G", "T"} else "A"


def _microhomology_len(seq: str, left_end: int, right_start: int, max_k: int = 6) -> int:
    max_k = max(0, int(max_k))
    best = 0
    for k in range(1, max_k + 1):
        if left_end - k < 0 or right_start + k > len(seq):
            continue
        left = seq[left_end - k : left_end]
        right = seq[right_start : right_start + k]
        if any(base not in {"A", "C", "G", "T"} for base in left + right):
            continue
        if left == right:
            best = k
    return best


def _span_sv_rate(distance: int, mh_len: int) -> float:
    base_rate = 0.03
    distance_term = math.exp(-float(distance) / 500.0)
    mh_term = max(0.0, min(1.0, float(mh_len) / 6.0))
    rate = base_rate + 0.15 * distance_term + 0.05 * mh_term
    return max(0.0, min(0.35, rate))


def _gc_fraction(seq: str) -> float:
    if not seq:
        return 0.0
    gc = sum(1 for ch in seq.upper() if ch in {"G", "C"})
    return float(gc) / float(len(seq))


def _extract_cut_index(edit_plan: Mapping[str, Any], window_start: int, sequence_len: int) -> int | None:
    for key in ("cutIndex", "cut_index"):
        if key in edit_plan:
            idx = _safe_int(edit_plan.get(key), -1)
            if 0 <= idx < sequence_len:
                return idx
            if window_start >= 0:
                rel = idx - window_start
                if 0 <= rel < sequence_len:
                    return rel
    for key in ("cutPosition", "cut_position"):
        if key in edit_plan:
            pos = _safe_int(edit_plan.get(key), -1)
            if window_start >= 0:
                rel = pos - window_start
                if 0 <= rel < sequence_len:
                    return rel
            if 0 <= pos < sequence_len:
                return pos
    guide = edit_plan.get("guide")
    if isinstance(guide, Mapping):
        start = _safe_int(guide.get("start"), -1)
        end = _safe_int(guide.get("end"), -1)
        pam_index = guide.get("pam_index")
        if pam_index is not None:
            idx = _safe_int(pam_index, -1) - 3
            if 0 <= idx < sequence_len:
                return idx
            if window_start >= 0:
                rel = idx - window_start
                if 0 <= rel < sequence_len:
                    return rel
        if start >= 0 and end > start:
            mid = start + (end - start) // 2
            if 0 <= mid < sequence_len:
                return mid
            if window_start >= 0:
                rel = mid - window_start
                if 0 <= rel < sequence_len:
                    return rel
    return None


def _desired_frequency_from_spectrum(allele_spectrum: list[Mapping[str, Any]], intent: str) -> float:
    intent = str(intent or "").strip().lower()
    if intent != "knockout":
        return 0.0
    desired = 0.0
    for entry in allele_spectrum:
        if not isinstance(entry, Mapping):
            continue
        delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
        kind = str(delta.get("type") or "").strip().lower()
        if kind not in {"del", "ins"}:
            continue
        length = delta.get("length")
        if length is None and kind == "ins":
            length = len(str(delta.get("sequence") or ""))
        try:
            length_int = int(length or 0)
        except Exception:
            length_int = 0
        if length_int <= 0:
            continue
        if length_int % 3 != 0:
            try:
                desired += float(entry.get("frequency") or 0.0)
            except Exception:
                continue
    return max(0.0, min(1.0, desired))


def _target_id(target: Mapping[str, Any], idx: int) -> str:
    for key in ("targetId", "id", "label", "name"):
        value = target.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return f"target_{idx + 1}"


def _build_target_edit_plan(target: Mapping[str, Any], edit_plan: Mapping[str, Any]) -> dict[str, Any]:
    plan: dict[str, Any] = {}
    for key in ("contig", "strand", "cutIndex", "cut_index", "cutPosition", "cut_position"):
        if key in target:
            plan[key] = target.get(key)
        elif key in edit_plan:
            plan[key] = edit_plan.get(key)

    guide: dict[str, Any] = {}
    grna = target.get("gRNA") if isinstance(target.get("gRNA"), Mapping) else None
    if grna is None:
        grna = target.get("guide") if isinstance(target.get("guide"), Mapping) else None
    if isinstance(grna, Mapping):
        if "sequence" in grna:
            guide["sequence"] = grna.get("sequence")
        if "pam" in grna:
            guide["pam"] = grna.get("pam")
        if "pamClass" in grna:
            guide["pamClass"] = grna.get("pamClass")

    for key in ("start", "end", "guideStart", "guideEnd"):
        if key in target:
            if key == "guideStart":
                guide["start"] = target.get(key)
            elif key == "guideEnd":
                guide["end"] = target.get(key)
            else:
                guide[key] = target.get(key)

    if "pamIndex" in target:
        guide["pam_index"] = target.get("pamIndex")
    if "pam_index" in target:
        guide["pam_index"] = target.get("pam_index")

    if guide:
        plan["guide"] = guide
    if "strand" in target:
        guide.setdefault("strand", target.get("strand"))
    return plan


def _targets_from_edit_plan(edit_plan: Mapping[str, Any] | None) -> list[Mapping[str, Any]]:
    if not isinstance(edit_plan, Mapping):
        return []
    targets = edit_plan.get("targets")
    if isinstance(targets, list):
        return [t for t in targets if isinstance(t, Mapping)]
    return []


def extract_cut_plan(
    experiment_spec: Mapping[str, Any] | None,
    edit_plan: Mapping[str, Any] | None,
    reference_context: Mapping[str, Any] | None,
) -> CutPlan | None:
    spec = experiment_spec_to_dict(experiment_spec)
    locus = spec.get("locus") if isinstance(spec.get("locus"), dict) else {}
    contig = (
        str((edit_plan or {}).get("contig") or "")
        or str((reference_context or {}).get("contig") or "")
        or str(locus.get("chr") or "")
    )
    if not contig:
        return None
    window_start = _safe_int((reference_context or {}).get("windowStart"), _safe_int(locus.get("start"), 0))
    window_end = _safe_int((reference_context or {}).get("windowEnd"), _safe_int(locus.get("end"), 0))
    sequence = (reference_context or {}).get("sequence") or (reference_context or {}).get("windowSequence")
    if not isinstance(sequence, str) or not sequence:
        return None
    sequence = sequence.upper()
    if window_end <= window_start:
        window_start = max(0, window_start)
        window_end = window_start + len(sequence)
    strand = str((edit_plan or {}).get("strand") or locus.get("strand") or "+")
    cut_index = _extract_cut_index(edit_plan or {}, window_start, len(sequence))
    if cut_index is None:
        return None
    if not (0 <= cut_index < len(sequence)):
        return None
    return CutPlan(
        contig=contig,
        window_start=window_start,
        window_end=window_end,
        cut_index=cut_index,
        strand=strand if strand in {"+", "-"} else "+",
        sequence=sequence,
    )


def extract_cut_inputs_from_session(session) -> tuple[dict[str, Any], dict[str, Any]] | None:
    try:
        spec = experiment_spec_to_dict(session.state.experiment_spec)
    except Exception:
        return None
    locus = spec.get("locus") if isinstance(spec.get("locus"), dict) else {}
    contig = str(locus.get("chr") or "")
    if not contig:
        return None
    try:
        genome = session.state.genome
        sequences = getattr(genome, "sequences", {}) if genome is not None else {}
    except Exception:
        sequences = {}
    sequence = sequences.get(contig)
    if not isinstance(sequence, str) or not sequence:
        return None
    window_start = _safe_int(locus.get("start"), 0)
    window_end = _safe_int(locus.get("end"), 0)
    if window_end <= window_start:
        window_start = 0
        window_end = len(sequence)
    window_start = max(0, min(window_start, len(sequence)))
    window_end = max(window_start, min(window_end, len(sequence)))
    window_seq = sequence[window_start:window_end]

    guide = {}
    try:
        cfg = session.state.config
        if isinstance(cfg, Mapping):
            guide = cfg.get("guide") or {}
    except Exception:
        guide = {}
    edit_plan = {"contig": contig, "guide": dict(guide) if isinstance(guide, Mapping) else {}}
    if isinstance(guide, Mapping):
        if "cut_index" in guide:
            edit_plan["cutIndex"] = guide.get("cut_index")
        if "pam_index" in guide:
            edit_plan["pamIndex"] = guide.get("pam_index")
        if "start" in guide:
            edit_plan["guide"] = {**edit_plan["guide"], "start": guide.get("start"), "end": guide.get("end")}

    reference_context = {
        "contig": contig,
        "windowStart": window_start,
        "windowEnd": window_end,
        "sequence": window_seq,
    }
    return edit_plan, reference_context


class CutOutcomeModel:
    model_id = "cut_model"
    model_version = "v1"

    def __init__(self, *, max_alleles: int = 50, min_frequency: float = 0.0) -> None:
        self.max_alleles = max(1, int(max_alleles))
        try:
            self.min_frequency = max(0.0, float(min_frequency))
        except Exception:
            self.min_frequency = 0.0

    def can_handle(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
    ) -> bool:
        if extract_cut_plan(experiment_spec, edit_plan, reference_context) is not None:
            return True
        targets = _targets_from_edit_plan(edit_plan)
        if targets:
            for target in targets:
                plan = extract_cut_plan(experiment_spec, _build_target_edit_plan(target, edit_plan or {}), reference_context)
                if plan is not None:
                    return True
        return False

    def run(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
    ) -> OutcomeReportV1:
        targets = _targets_from_edit_plan(edit_plan)
        if len(targets) > 1:
            return self._run_multiplex(experiment_spec, edit_plan, reference_context, targets)

        plan = extract_cut_plan(experiment_spec, edit_plan, reference_context)
        if plan is None:
            return NoopOutcomeModel().run(experiment_spec, edit_plan, reference_context)

        spec = experiment_spec_to_dict(experiment_spec)
        intent = parse_intent(spec)
        assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
        transcript_context = (
            assumptions.get("transcriptContext") if isinstance(assumptions.get("transcriptContext"), Mapping) else None
        )

        cell_ctx, _ = parse_cell_context(assumptions)
        context_line = cell_context_breadcrumb(cell_ctx)
        bias = cut_model_bias_for_repair_preset(cell_ctx.repair_bias_preset)

        spectrum = _build_cut_spectrum(
            plan,
            max_alleles=self.max_alleles,
            min_frequency=self.min_frequency,
            bias=bias,
        )
        if not spectrum:
            return NoopOutcomeModel().run(experiment_spec, edit_plan, reference_context)

        summary = [
            "Baseline cut outcome model; microhomology-weighted deletions + short insertions.",
            context_line,
            f"Window={plan.contig}:{plan.window_start}-{plan.window_end} cutIndex={plan.cut_index}",
        ]
        intent_eval = evaluate_intent(
            spectrum or [],
            plan.cut_index,
            {
                "contig": plan.contig,
                "windowStart": plan.window_start,
                "windowEnd": plan.window_end,
                "sequence": plan.sequence,
            },
            transcript_context,
            intent=intent,
            assumptions=assumptions,
        )
        inputs_sha = compute_inputs_sha256(experiment_spec, edit_plan, reference_context)
        return OutcomeReportV1(
            model_id=self.model_id,
            model_version=self.model_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            allele_spectrum=spectrum,
            uncertainty_summary=[],
            uncertainty={},
            edit_intent=dict(intent),
            intent_evaluation=intent_eval,
        )

    def _run_multiplex(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
        targets: list[Mapping[str, Any]],
    ) -> OutcomeReportV1:
        spec = experiment_spec_to_dict(experiment_spec)
        intent = parse_intent(spec)
        assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
        transcript_context = (
            assumptions.get("transcriptContext") if isinstance(assumptions.get("transcriptContext"), Mapping) else None
        )

        cell_ctx, _ = parse_cell_context(assumptions)
        context_line = cell_context_breadcrumb(cell_ctx)
        bias = cut_model_bias_for_repair_preset(cell_ctx.repair_bias_preset)

        keyed_targets = [(_target_id(t, idx), t, idx) for idx, t in enumerate(targets)]
        keyed_targets.sort(key=lambda item: (item[0], item[2]))
        multiplex_targets: list[dict[str, Any]] = []
        target_meta: list[dict[str, Any]] = []
        warnings: list[str] = ["Multiplex v1 assumes independence between targets."]
        any_spectrum = False

        for tid, target, _idx in keyed_targets:
            target_plan = _build_target_edit_plan(target, edit_plan or {})
            plan = extract_cut_plan(experiment_spec, target_plan, reference_context)
            if plan is None:
                multiplex_targets.append(
                    {
                        "targetId": tid,
                        "desiredFrequency": 0.0,
                        "alleleSpectrum": [],
                        "summary": [f"Target {tid}: missing cut plan; no spectrum generated."],
                    }
                )
                warnings.append(f"Target {tid}: missing cut plan.")
                continue

            spectrum = _build_cut_spectrum(
                plan,
                max_alleles=self.max_alleles,
                min_frequency=self.min_frequency,
                bias=bias,
            )
            if spectrum:
                any_spectrum = True
            intent_eval = evaluate_intent(
                spectrum or [],
                plan.cut_index,
                {
                    "contig": plan.contig,
                    "windowStart": plan.window_start,
                    "windowEnd": plan.window_end,
                    "sequence": plan.sequence,
                },
                transcript_context,
                intent=intent,
                assumptions=assumptions,
            )
            desired = intent_eval.get("successProbability")
            goal = str(intent.get("goal") or "")
            if desired is None:
                warnings.append(f"Target {tid}: desired frequency not computed (goal={goal or 'unknown'}).")
            elif goal and goal != "knockout" and float(desired) <= 0.0:
                metric = str((intent.get('success') or {}).get('metric') or "")
                warnings.append(
                    f"Target {tid}: desired frequency unavailable for intent goal={goal or 'unknown'} metric={metric or 'unknown'}."
                )
            summary = [
                "Baseline cut outcome model; microhomology-weighted deletions + short insertions.",
                context_line,
                f"Window={plan.contig}:{plan.window_start}-{plan.window_end} cutIndex={plan.cut_index}",
            ]
            multiplex_targets.append(
                {
                    "targetId": tid,
                    "desiredFrequency": round(float(desired), 8) if desired is not None else None,
                    "alleleSpectrum": list(spectrum or []),
                    "summary": summary,
                    "intentEvaluation": intent_eval,
                }
            )
            target_meta.append(
                {
                    "targetId": tid,
                    "contig": plan.contig,
                    "windowStart": plan.window_start,
                    "sequence": plan.sequence,
                    "cutIndex": plan.cut_index,
                    "cutPosition": plan.window_start + plan.cut_index,
                    "desiredFrequency": float(desired) if desired is not None else 0.0,
                }
            )

        if not any_spectrum:
            return NoopOutcomeModel().run(experiment_spec, edit_plan, reference_context)

        def _target_sort_key(entry: Mapping[str, Any]) -> str:
            return str(entry.get("targetId") or "")

        multiplex_targets.sort(key=_target_sort_key)

        desireds = [float(entry.get("desiredFrequency") or 0.0) for entry in multiplex_targets]
        prod_all = 1.0
        prod_none = 1.0
        for p in desireds:
            p = max(0.0, min(1.0, float(p)))
            prod_all *= p
            prod_none *= (1.0 - p)

        combined = {
            "independenceAssumed": True,
            "expectedAllTargetsEdited": round(max(0.0, min(1.0, prod_all)), 8),
            "expectedAnyEdited": round(max(0.0, min(1.0, 1.0 - prod_none)), 8),
        }

        structural_variants: list[dict[str, Any]] = []
        if len(target_meta) > 1:
            contig_map: dict[str, list[dict[str, Any]]] = {}
            for entry in target_meta:
                contig = str(entry.get("contig") or "")
                if not contig:
                    continue
                contig_map.setdefault(contig, []).append(entry)

            for contig, entries in contig_map.items():
                entries.sort(key=lambda e: (str(e.get("targetId") or ""), int(e.get("cutPosition") or 0)))
                for i in range(len(entries)):
                    for j in range(i + 1, len(entries)):
                        left = entries[i]
                        right = entries[j]
                        pos1 = int(left.get("cutPosition") or 0)
                        pos2 = int(right.get("cutPosition") or 0)
                        if pos1 == pos2:
                            continue
                        start = min(pos1, pos2)
                        end = max(pos1, pos2)
                        length = max(0, end - start)
                        window_start = int(left.get("windowStart") or 0)
                        seq = str(left.get("sequence") or "")
                        left_idx = start - window_start
                        right_idx = end - window_start
                        mh_len = 0
                        if 0 <= left_idx < len(seq) and 0 <= right_idx <= len(seq) and left_idx < right_idx:
                            mh_len = _microhomology_len(seq, left_idx, right_idx, max_k=6)
                        p1 = max(0.0, min(1.0, float(left.get("desiredFrequency") or 0.0)))
                        p2 = max(0.0, min(1.0, float(right.get("desiredFrequency") or 0.0)))
                        p_both = p1 * p2
                        rate = _span_sv_rate(end - start, mh_len)
                        span_del = p_both * rate
                        span_inv = span_del * 0.15
                        target_ids = sorted({str(left.get("targetId") or ""), str(right.get("targetId") or "")})
                        notes = [
                            "Multiplex v1 assumes independence and uses heuristic span SV rates.",
                            f"distance={end - start}",
                            f"microhomology={mh_len}",
                        ]
                        if span_del >= 0.0:
                            structural_variants.append(
                                {
                                    "kind": "spanDeletion",
                                    "targetIds": target_ids,
                                    "contig": contig,
                                    "start": start,
                                    "end": end,
                                    "length": length,
                                    "frequency": round(float(span_del), 8),
                                    "notes": notes,
                                }
                            )
                        if span_inv >= 0.0:
                            structural_variants.append(
                                {
                                    "kind": "spanInversion",
                                    "targetIds": target_ids,
                                    "contig": contig,
                                    "start": start,
                                    "end": end,
                                    "length": length,
                                    "frequency": round(float(span_inv), 8),
                                    "notes": notes,
                                }
                            )

        if structural_variants:
            warnings.append("Multiplex v1 assumes independence and uses heuristic span SV rates.")
            def _sv_sort(entry: Mapping[str, Any]) -> tuple[str, str, int, int, str]:
                kind = str(entry.get("kind") or "")
                contig = str(entry.get("contig") or "")
                start = int(entry.get("start") or 0)
                end = int(entry.get("end") or 0)
                targets = ",".join(sorted(entry.get("targetIds") or []))
                return (kind, contig, start, end, targets)

            structural_variants.sort(key=_sv_sort)

        multiplex_payload = {
            "targets": multiplex_targets,
            "combined": combined,
            "warnings": warnings,
        }

        primary = multiplex_targets[0]
        spectrum = primary.get("alleleSpectrum") if isinstance(primary.get("alleleSpectrum"), list) else []
        primary_id = str(primary.get("targetId") or "")
        primary_eval = primary.get("intentEvaluation") if isinstance(primary.get("intentEvaluation"), Mapping) else None

        summary = [
            "Baseline cut outcome model; microhomology-weighted deletions + short insertions.",
            f"Multiplex cut outcomes ({len(multiplex_targets)} targets); primary={primary_id}.",
            context_line,
        ]
        inputs_sha = compute_inputs_sha256(experiment_spec, edit_plan, reference_context)
        return OutcomeReportV1(
            model_id=self.model_id,
            model_version=self.model_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            allele_spectrum=list(spectrum),
            uncertainty_summary=[],
            uncertainty={},
            multiplex=multiplex_payload,
            structural_variants=structural_variants or None,
            edit_intent=dict(intent),
            intent_evaluation=dict(primary_eval) if isinstance(primary_eval, Mapping) else None,
        )


def _build_cut_spectrum(
    plan: CutPlan,
    *,
    max_alleles: int,
    min_frequency: float,
    bias: CutModelRepairShapeBias | None = None,
) -> list[dict[str, Any]] | None:
    seq = plan.sequence
    cut = plan.cut_index
    gc = _gc_fraction(seq[max(0, cut - 10) : min(len(seq), cut + 10)])
    gc_factor = 1.0 + (gc - 0.5) * 0.2

    if bias is None:
        bias = CutModelRepairShapeBias()
    ins_mult = max(0.0, float(bias.insertion_weight_mult))
    del_mult = max(0.0, float(bias.deletion_weight_mult))
    mh_mult = max(0.0, float(bias.microhomology_mult))

    candidates: list[dict[str, Any]] = []
    max_del = 30
    max_ins = 3
    max_shift = 4

    for del_len in range(1, max_del + 1):
        base_prior = math.exp(-float(del_len) / 8.0)
        for shift in range(0, min(max_shift, del_len) + 1):
            start = cut - shift
            end = start + del_len
            if start < 0 or end > len(seq):
                continue
            mh = _microhomology_len(seq, start, end, max_k=6)
            weight = base_prior * (1.0 + 0.15 * float(mh) * mh_mult) * gc_factor * (1.0 - 0.04 * shift)
            weight *= del_mult
            candidates.append(
                {
                    "sequenceDelta": {
                        "type": "del",
                        "start": int(start),
                        "end": int(end),
                        "length": int(del_len),
                        "microhomology": int(mh),
                    },
                    "weight": float(weight),
                }
            )

    ins_base = _normalize_base(seq[cut - 1] if cut > 0 else "A")
    for ins_len in range(1, max_ins + 1):
        weight = math.exp(-float(ins_len) / 2.0) * 0.6 * gc_factor
        weight *= ins_mult
        candidates.append(
            {
                "sequenceDelta": {
                    "type": "ins",
                    "start": int(cut),
                    "sequence": ins_base * ins_len,
                    "length": int(ins_len),
                },
                "weight": float(weight),
            }
        )

    if not candidates:
        return None

    total = sum(c["weight"] for c in candidates)
    if total <= 0.0:
        return None

    max_weight = max(c["weight"] for c in candidates)

    def _delta_key(delta: Mapping[str, Any]) -> str:
        kind = str(delta.get("type") or "")
        if kind == "del":
            return f"del:{delta.get('start')}:{delta.get('end')}:{delta.get('length')}:{delta.get('microhomology')}"
        if kind == "ins":
            return f"ins:{delta.get('start')}:{delta.get('length')}:{delta.get('sequence')}"
        return str(kind)

    enriched: list[dict[str, Any]] = []
    for entry in candidates:
        weight = float(entry.get("weight") or 0.0)
        freq = weight / total
        delta = entry["sequenceDelta"]
        conf = 0.2 + 0.6 * (weight / max_weight)
        enriched.append(
            {
                "sequenceDelta": delta,
                "frequency": float(freq),
                "confidence": round(conf, 4),
                "_delta_key": _delta_key(delta),
            }
        )

    enriched.sort(key=lambda d: (-float(d["frequency"]), d["_delta_key"]))

    kept: list[dict[str, Any]] = []
    remainder = 0.0
    truncated = False
    for entry in enriched:
        if min_frequency > 0.0 and entry["frequency"] < min_frequency:
            remainder += entry["frequency"]
            truncated = True
            continue
        if len(kept) < max_alleles:
            kept.append(entry)
        else:
            remainder += entry["frequency"]
            truncated = True

    spectrum: list[dict[str, Any]] = []
    for entry in kept:
        spectrum.append(
            {
                "sequenceDelta": entry["sequenceDelta"],
                "frequency": float(entry["frequency"]),
                "confidence": float(entry["confidence"]),
                "_delta_key": entry["_delta_key"],
            }
        )

    if truncated and remainder > 0.0:
        spectrum.append(
            {
                "sequenceDelta": {"type": "other", "length": 0, "label": "OTHER"},
                "frequency": float(remainder),
                "confidence": 0.0,
                "_delta_key": "OTHER",
            }
        )

    if not spectrum:
        return None

    running = 0.0
    for idx, entry in enumerate(spectrum):
        if idx < len(spectrum) - 1:
            freq = round(float(entry["frequency"]), 8)
            running += freq
        else:
            freq = round(max(0.0, 1.0 - running), 8)
        entry["frequency"] = float(freq)
        entry.pop("_delta_key", None)

    total_freq = sum(float(entry.get("frequency") or 0.0) for entry in spectrum)
    if abs(total_freq - 1.0) > 1e-6 and spectrum:
        last = spectrum[-1]
        corrected = max(0.0, float(last.get("frequency") or 0.0) + (1.0 - total_freq))
        last["frequency"] = round(corrected, 8)

    return spectrum


def estimate_frameshift_fraction(sequence: str, cut_index: int, *, max_alleles: int = 50) -> float | None:
    """Return an exploratory frameshift fraction estimate from the cut outcome model.

    Notes:
    - This is a local, sequence-context-only proxy (microhomology-weighted indels).
    - It is *conditional on an indel occurring*; there is no explicit no-cut term.
    - Intended for ranking/triage, not decision-grade guidance.
    """

    if not isinstance(sequence, str):
        return None
    seq = sequence.strip().upper()
    if not seq:
        return None
    try:
        cut = int(cut_index)
    except Exception:
        return None
    if not (0 <= cut < len(seq)):
        return None

    plan = CutPlan(
        contig="chr",
        window_start=0,
        window_end=len(seq),
        cut_index=cut,
        strand="+",
        sequence=seq,
    )
    spectrum = _build_cut_spectrum(plan, max_alleles=max(1, int(max_alleles)), min_frequency=0.0)
    if not spectrum:
        return None

    frameshift = 0.0
    for entry in spectrum:
        if not isinstance(entry, Mapping):
            continue
        delta = entry.get("sequenceDelta")
        if not isinstance(delta, Mapping):
            continue
        kind = str(delta.get("type") or "").strip().lower()
        if kind not in {"del", "ins"}:
            continue

        length = delta.get("length")
        if length is None and kind == "ins":
            length = len(str(delta.get("sequence") or ""))
        try:
            length_int = int(length or 0)
        except Exception:
            length_int = 0
        if length_int <= 0:
            continue
        if length_int % 3 != 0:
            try:
                frameshift += float(entry.get("frequency") or 0.0)
            except Exception:
                continue

    return max(0.0, min(1.0, frameshift))


__all__ = ["CutOutcomeModel", "estimate_frameshift_fraction", "extract_cut_plan", "extract_cut_inputs_from_session"]
