from __future__ import annotations

import json
from typing import Any, Mapping, Sequence


def _segments_for_kind(
    allele_spectrum: list[Any],
    *,
    kind: str,
    seq_len: int,
) -> list[dict[str, int]]:
    segments: list[dict[str, int]] = []
    kind = str(kind or "").lower().strip()
    if not kind:
        return segments
    for entry in allele_spectrum:
        if not isinstance(entry, Mapping):
            continue
        delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
        delta_kind = str(delta.get("type") or "").lower().strip()
        if delta_kind != kind:
            continue
        try:
            start = int(delta.get("start"))
        except Exception:
            continue
        end_val = delta.get("end")
        length_val = delta.get("length")
        end = None
        if end_val is not None:
            try:
                end = int(end_val)
            except Exception:
                end = None
        if end is None and length_val is not None:
            try:
                end = start + max(1, int(length_val))
            except Exception:
                end = None
        if end is None:
            end = start + 1
        if end <= start:
            continue
        start = max(0, start)
        end = min(seq_len, end)
        if end <= start:
            continue
        segments.append({"start": start, "end": end})
    segments.sort(key=lambda seg: (seg["start"], seg["end"]))
    return segments


def _ticks_from_substitutions(
    allele_spectrum: Sequence[Any],
    *,
    sequence_len: int,
    levels: int = 4,
) -> list[dict[str, Any]]:
    ticks: dict[int, dict[str, Any]] = {}
    entries: list[tuple[int, int, str]] = []
    scale = 1_000_000

    for entry in allele_spectrum:
        if not isinstance(entry, Mapping):
            continue
        delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
        delta_kind = str(delta.get("type") or "").lower().strip()
        if delta_kind != "base_substitution":
            continue
        try:
            start = int(delta.get("start"))
        except Exception:
            continue
        if start < 0 or start >= sequence_len:
            continue
        freq = entry.get("frequency") or 0.0
        try:
            freq_val = float(freq)
        except Exception:
            continue
        if freq_val <= 0.0:
            continue
        role_raw = str(delta.get("role") or delta.get("label") or "").lower()
        role = "desired" if "desired" in role_raw else "bystander"
        entries.append((start, int(round(freq_val * scale)), role))

    if not entries:
        return []
    p_max = max(val for _pos, val, _role in entries)
    if p_max <= 0:
        return []
    levels = max(1, int(levels))
    for pos, p_int, role in entries:
        level = (p_int * (levels - 1) + (p_max - 1)) // p_max if p_max > 0 else 0
        level = max(0, min(levels - 1, int(level)))
        existing = ticks.get(pos)
        if existing is None:
            ticks[pos] = {"pos": pos, "level": level, "role": role}
        else:
            if level > int(existing.get("level", 0)):
                ticks[pos] = {"pos": pos, "level": level, "role": role}
            elif level == int(existing.get("level", 0)) and role == "desired" and existing.get("role") != "desired":
                ticks[pos] = {"pos": pos, "level": level, "role": role}

    ordered = list(ticks.values())
    ordered.sort(key=lambda item: (item["pos"], item.get("role", "")))
    return ordered


def build_base_overlay(
    report_bytes: bytes,
    *,
    sequence_len: int,
) -> dict[str, Any]:
    try:
        payload = json.loads(report_bytes.decode("utf-8"))
    except Exception:
        return {}
    if not isinstance(payload.get("baseOutcomes"), list):
        return {}
    allele_spectrum = payload.get("alleleSpectrum")
    if not isinstance(allele_spectrum, list) or sequence_len <= 0:
        return {}

    desired = _segments_for_kind(allele_spectrum, kind="base_desired", seq_len=sequence_len)
    bystander = _segments_for_kind(allele_spectrum, kind="base_bystander", seq_len=sequence_len)

    if not desired and not bystander:
        for entry in allele_spectrum:
            if not isinstance(entry, Mapping):
                continue
            delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
            delta_kind = str(delta.get("type") or "").lower().strip()
            if delta_kind != "base_substitution":
                continue
            role = str(delta.get("role") or delta.get("label") or "").lower()
            try:
                start = int(delta.get("start"))
            except Exception:
                continue
            end = start + 1
            if 0 <= start < sequence_len:
                end = min(sequence_len, end)
                segment = {"start": start, "end": end}
                if "desired" in role:
                    desired.append(segment)
                else:
                    bystander.append(segment)
        desired.sort(key=lambda seg: (seg["start"], seg["end"]))
        bystander.sort(key=lambda seg: (seg["start"], seg["end"]))

    if not desired and not bystander:
        return {}
    overlay: dict[str, Any] = {"desired": desired, "bystander": bystander}
    ticks = _ticks_from_substitutions(allele_spectrum, sequence_len=sequence_len, levels=4)
    if ticks:
        overlay["ticks"] = ticks
        overlay["tick_levels"] = 4
    return overlay


__all__ = ["build_base_overlay"]
