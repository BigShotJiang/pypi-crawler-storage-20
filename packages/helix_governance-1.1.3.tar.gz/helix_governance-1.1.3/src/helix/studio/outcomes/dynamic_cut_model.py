from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from helix.crispr.dynamic import CrisprDynamicSimConfig, simulate_crispr_dynamic
from helix.studio.experiment_spec import experiment_spec_to_dict

from .cell_context import (
    cell_context_breadcrumb,
    dynamic_indel_overrides_for_repair_preset,
    parse_cell_context,
)
from .cut_model import (
    _build_target_edit_plan,
    _target_id,
    _targets_from_edit_plan,
    extract_cut_plan,
)
from .intent_eval import evaluate_intent, parse_intent
from .model import OutcomeReportV1, compute_inputs_sha256
from .noop import NoopOutcomeModel


def _safe_float(value: Any, default: float) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _stable_seed(inputs_sha256: str) -> int:
    token = str(inputs_sha256 or "")
    if len(token) < 8:
        return 0
    try:
        return int(token[:8], 16)
    except Exception:
        return 0


@dataclass(frozen=True)
class _TargetPlan:
    target_id: str
    contig: str
    window_start: int
    window_end: int
    cut_index: int
    sequence: str
    grna_sequence: str | None
    accessibility: float

    @property
    def cut_pos(self) -> int:
        return int(self.window_start + self.cut_index)


def _extract_target_plans(
    experiment_spec: Mapping[str, Any] | None,
    edit_plan: Mapping[str, Any] | None,
    reference_context: Mapping[str, Any] | None,
) -> list[_TargetPlan]:
    targets = _targets_from_edit_plan(edit_plan)
    extracted: list[_TargetPlan] = []

    if not targets:
        plan = extract_cut_plan(experiment_spec, edit_plan, reference_context)
        if plan is None:
            return []
        extracted.append(
            _TargetPlan(
                target_id="primary",
                contig=plan.contig,
                window_start=plan.window_start,
                window_end=plan.window_end,
                cut_index=plan.cut_index,
                sequence=plan.sequence,
                grna_sequence=(edit_plan or {}).get("guide", {}).get("sequence") if isinstance((edit_plan or {}).get("guide"), Mapping) else None,
                accessibility=1.0,
            )
        )
        return extracted

    keyed_targets = [(_target_id(t, idx), t, idx) for idx, t in enumerate(targets)]
    keyed_targets.sort(key=lambda item: (item[0], item[2]))
    for tid, target, _idx in keyed_targets:
        target_plan = _build_target_edit_plan(target, edit_plan or {})
        plan = extract_cut_plan(experiment_spec, target_plan, reference_context)
        if plan is None:
            continue
        grna = None
        if isinstance(target.get("gRNA"), Mapping):
            grna = target.get("gRNA", {}).get("sequence")
        if grna is None and isinstance(target.get("guide"), Mapping):
            grna = target.get("guide", {}).get("sequence")
        if grna is None and isinstance(target_plan.get("guide"), Mapping):
            grna = target_plan.get("guide", {}).get("sequence")
        accessibility = _safe_float(target.get("accessibility"), 1.0)
        extracted.append(
            _TargetPlan(
                target_id=str(tid),
                contig=plan.contig,
                window_start=plan.window_start,
                window_end=plan.window_end,
                cut_index=plan.cut_index,
                sequence=plan.sequence,
                grna_sequence=str(grna) if isinstance(grna, str) and grna else None,
                accessibility=max(0.0, min(1.0, float(accessibility))),
            )
        )
    return extracted


def _delta_key(delta: Mapping[str, Any]) -> str:
    kind = str(delta.get("type") or "")
    if kind == "del":
        return f"del:{delta.get('start')}:{delta.get('end')}:{delta.get('length')}:{delta.get('microhomology')}"
    if kind == "ins":
        return f"ins:{delta.get('start')}:{delta.get('length')}:{delta.get('sequence')}"
    return f"other:{delta.get('label')}"


def _allele_spectrum_for_target(
    *,
    target: _TargetPlan,
    cells: list[Any],
    max_alleles: int,
    min_frequency: float,
) -> list[dict[str, Any]] | None:
    max_alleles = max(1, int(max_alleles))
    min_frequency = max(0.0, float(min_frequency))
    window_start = int(target.window_start)

    total = 0
    other = 0
    counts: dict[str, int] = {}
    deltas: dict[str, dict[str, Any]] = {}

    for cell in cells:
        if not getattr(cell, "alive", False):
            continue
        labels = getattr(cell, "allele_labels", {}).get(target.target_id) or []
        if not isinstance(labels, list):
            continue
        indel_map = {}
        for indel in getattr(cell, "indels", []) or []:
            if getattr(indel, "locus_id", None) != target.target_id:
                continue
            key = (getattr(indel, "locus_id", None), getattr(indel, "allele_id", None))
            indel_map[key] = indel
        for allele_id, label in enumerate(labels):
            total += 1
            if label != "INDEL":
                other += 1
                continue
            indel = indel_map.get((target.target_id, allele_id))
            if indel is None:
                other += 1
                continue
            kind = str(getattr(indel, "kind", "") or "")
            length = int(getattr(indel, "length_bp", 0) or 0)
            start_abs = int(getattr(indel, "start", 0) or 0)
            end_abs = int(getattr(indel, "end", start_abs) or start_abs)
            if kind == "del":
                delta = {
                    "type": "del",
                    "start": int(start_abs - window_start),
                    "end": int(end_abs - window_start),
                    "length": int(length),
                    "microhomology": 0,
                }
            elif kind == "ins":
                delta = {
                    "type": "ins",
                    "start": int(start_abs - window_start),
                    "length": int(length),
                    "sequence": "N" * max(0, length),
                }
            else:
                other += 1
                continue
            key = _delta_key(delta)
            counts[key] = counts.get(key, 0) + 1
            deltas[key] = delta

    if total <= 0:
        return None

    items: list[dict[str, Any]] = []
    for key, count in counts.items():
        freq = float(count) / float(total)
        if min_frequency > 0.0 and freq < min_frequency:
            other += count
            continue
        items.append(
            {
                "sequenceDelta": deltas[key],
                "frequency": float(freq),
                "confidence": 0.5,
                "_delta_key": key,
            }
        )

    items.sort(key=lambda d: (-float(d.get("frequency") or 0.0), str(d.get("_delta_key") or "")))

    remainder = float(other) / float(total)
    truncated = False
    if len(items) > max_alleles:
        for entry in items[max_alleles:]:
            remainder += float(entry.get("frequency") or 0.0)
        items = items[:max_alleles]
        truncated = True

    if truncated or remainder > 0.0:
        items.append(
            {
                "sequenceDelta": {"type": "other", "length": 0, "label": "OTHER"},
                "frequency": float(remainder),
                "confidence": 0.0,
                "_delta_key": "OTHER",
            }
        )

    if not items:
        return None

    running = 0.0
    for idx, entry in enumerate(items):
        if idx < len(items) - 1:
            freq = round(float(entry.get("frequency") or 0.0), 8)
            running += freq
        else:
            freq = round(max(0.0, 1.0 - running), 8)
        entry["frequency"] = float(freq)
        entry.pop("_delta_key", None)

    total_freq = sum(float(entry.get("frequency") or 0.0) for entry in items)
    if abs(total_freq - 1.0) > 1e-6:
        last = items[-1]
        corrected = max(0.0, float(last.get("frequency") or 0.0) + (1.0 - total_freq))
        last["frequency"] = round(corrected, 8)

    return items


class DynamicCutOutcomeModel:
    model_id = "dynamic_cut_model"
    model_version = "v1"

    def __init__(
        self,
        *,
        max_alleles: int = 50,
        min_frequency: float = 0.0,
        n_cells: int = 250,
        dt_h: float = 0.25,
        t_end_h: float = 24.0,
    ) -> None:
        self.max_alleles = max(1, int(max_alleles))
        self.min_frequency = max(0.0, float(min_frequency))
        self.n_cells = max(10, int(n_cells))
        self.dt_h = max(1e-6, float(dt_h))
        self.t_end_h = max(0.0, float(t_end_h))

    def can_handle(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
    ) -> bool:
        if extract_cut_plan(experiment_spec, edit_plan, reference_context) is not None:
            return True
        targets = _targets_from_edit_plan(edit_plan)
        if targets:
            for target in targets:
                plan = extract_cut_plan(experiment_spec, _build_target_edit_plan(target, edit_plan or {}), reference_context)
                if plan is not None:
                    return True
        return False

    def run(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
    ) -> OutcomeReportV1:
        spec = experiment_spec_to_dict(experiment_spec)
        intent = parse_intent(spec)
        assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
        transcript_context = (
            assumptions.get("transcriptContext") if isinstance(assumptions.get("transcriptContext"), Mapping) else None
        )

        cell_ctx, ctx_warnings = parse_cell_context(assumptions)
        context_line = cell_context_breadcrumb(cell_ctx)

        target_plans = _extract_target_plans(experiment_spec, edit_plan, reference_context)
        if not target_plans:
            return NoopOutcomeModel().run(experiment_spec, edit_plan, reference_context)

        inputs_sha = compute_inputs_sha256(experiment_spec, edit_plan, reference_context)
        seed = _stable_seed(inputs_sha)

        # Build a minimal dynamic sim config from the cut plans. We intentionally keep this
        # import-light and rely on CrisprDynamicSimConfig defaults for most knobs.
        guide_ids: dict[str, str] = {}
        guide_list: list[dict[str, Any]] = []
        next_gid = 1
        for t in target_plans:
            token = t.grna_sequence or t.target_id
            if token not in guide_ids:
                gid = f"g{next_gid}"
                next_gid += 1
                guide_ids[token] = gid
                guide_list.append({"id": gid, "abundance": 1.0, "load_efficiency": 1.0})

        targets_cfg: list[dict[str, Any]] = []
        accessibility_scalar = float(cell_ctx.accessibility_scalar) if cell_ctx.accessibility_scalar is not None else 1.0
        for t in target_plans:
            token = t.grna_sequence or t.target_id
            eff_access = float(t.accessibility) * accessibility_scalar
            eff_access = max(0.0, min(1.0, eff_access))
            targets_cfg.append(
                {
                    "id": t.target_id,
                    "grna_id": guide_ids.get(token, token),
                    "chr": t.contig,
                    "pos": int(t.cut_pos),
                    "accessibility": float(eff_access),
                }
            )

        delivery_cfg: dict[str, Any] = {"mode": cell_ctx.delivery_mode or "RNP"}
        delivery_params = assumptions.get("deliveryParams") if isinstance(assumptions.get("deliveryParams"), Mapping) else None
        if isinstance(delivery_params, Mapping):
            delivery_cfg["params"] = dict(delivery_params)
        delivery_hetero = (
            assumptions.get("deliveryHeterogeneity")
            if isinstance(assumptions.get("deliveryHeterogeneity"), Mapping)
            else assumptions.get("delivery_heterogeneity")
            if isinstance(assumptions.get("delivery_heterogeneity"), Mapping)
            else None
        )
        if isinstance(delivery_hetero, Mapping):
            delivery_cfg["heterogeneity"] = dict(delivery_hetero)

        repair_cfg: dict[str, Any] = {}
        indel_overrides = dynamic_indel_overrides_for_repair_preset(cell_ctx.repair_bias_preset)
        if indel_overrides:
            repair_cfg["indel"] = dict(indel_overrides)

        cfg = CrisprDynamicSimConfig.from_dict(
            {
                "time": {"dt_h": float(self.dt_h), "t_end_h": float(self.t_end_h)},
                "population": {"n_cells": int(self.n_cells), "seed": int(seed)},
                "delivery": delivery_cfg,
                "repair": repair_cfg,
                "fate": {"dsb_toxicity": {"enabled": False}},
                "measurement": {"amplicons": [], "dropout": {"dropout_prob": 0.0}},
                "grnas": guide_list,
                "targets": targets_cfg,
            }
        )

        result = simulate_crispr_dynamic(cfg)
        alive_cells = [c for c in result.cells if c.alive]
        if not alive_cells:
            summary = [
                "Dynamic cut model (ODE + stochastic): delivery-shaped Cas(t), multiplex competition, repair saturation + SVs.",
                context_line,
                "No surviving cells in simulation (all died); returning noop report.",
            ]
            return OutcomeReportV1(
                model_id=self.model_id,
                model_version=self.model_version,
                inputs_sha256=inputs_sha,
                summary=summary,
                allele_spectrum=[],
                uncertainty_summary=["dynamic:all_cells_dead"],
                uncertainty={"nCells": int(cfg.population.n_cells), "seed": int(cfg.population.seed)},
                edit_intent=dict(intent),
                intent_evaluation=None,
            )

        multiplex_targets: list[dict[str, Any]] = []
        any_spectrum = False
        warnings: list[str] = [
            "Dynamic model includes uncut alleles in OTHER (frequency is over all surviving alleles).",
            f"Sim seeded deterministically from inputsSha256 (seed={seed}).",
        ]
        warnings.extend(ctx_warnings)
        for t in target_plans:
            spectrum = _allele_spectrum_for_target(
                target=t,
                cells=alive_cells,
                max_alleles=self.max_alleles,
                min_frequency=self.min_frequency,
            )
            if spectrum:
                any_spectrum = True
            intent_eval = evaluate_intent(
                spectrum or [],
                t.cut_index,
                {
                    "contig": t.contig,
                    "windowStart": t.window_start,
                    "windowEnd": t.window_end,
                    "sequence": t.sequence,
                },
                transcript_context,
                intent=intent,
                assumptions=assumptions,
            )
            desired = intent_eval.get("successProbability")
            goal = str(intent.get("goal") or "")
            if desired is None:
                warnings.append(f"Target {t.target_id}: desired frequency not computed (goal={goal or 'unknown'}).")
            elif goal and goal != "knockout" and float(desired) <= 0.0:
                metric = str((intent.get('success') or {}).get('metric') or "")
                warnings.append(
                    f"Target {t.target_id}: desired frequency unavailable for intent goal={goal or 'unknown'} metric={metric or 'unknown'}."
                )
            summary_lines = [
                "Dynamic cut model (ODE + stochastic): delivery-shaped Cas(t), multiplex competition, repair saturation + SVs.",
                context_line,
                f"Window={t.contig}:{t.window_start}-{t.window_end} cutIndex={t.cut_index}",
                f"Sim: n_cells={cfg.population.n_cells} dt_h={cfg.time.dt_h} t_end_h={cfg.time.t_end_h}",
            ]
            multiplex_targets.append(
                {
                    "targetId": t.target_id,
                    "desiredFrequency": round(float(desired), 8) if desired is not None else None,
                    "alleleSpectrum": list(spectrum or []),
                    "summary": summary_lines,
                    "intentEvaluation": intent_eval,
                }
            )

        if not any_spectrum:
            return NoopOutcomeModel().run(experiment_spec, edit_plan, reference_context)

        multiplex_targets.sort(key=lambda e: str(e.get("targetId") or ""))

        n_alive = float(len(alive_cells))
        any_edited = 0
        all_edited = 0
        target_ids = [t.target_id for t in target_plans]
        for cell in alive_cells:
            edited_flags = []
            for tid in target_ids:
                labels = cell.allele_labels.get(tid) or []
                edited_flags.append(any(lbl != "WT" for lbl in labels))
            if any(edited_flags):
                any_edited += 1
            if edited_flags and all(edited_flags):
                all_edited += 1

        combined = {
            "independenceAssumed": False,
            "expectedAnyEdited": round(any_edited / n_alive, 8) if n_alive else 0.0,
            "expectedAllTargetsEdited": round(all_edited / n_alive, 8) if n_alive else 0.0,
        }

        structural_variants: dict[tuple[str, str, int, int, str], int] = {}
        for cell in alive_cells:
            seen: set[tuple[str, str, int, int, str]] = set()
            for sv in cell.svs:
                if getattr(sv, "kind", None) == "translocation":
                    continue
                if getattr(sv, "chrom_a", None) != getattr(sv, "chrom_b", None):
                    continue
                kind = str(getattr(sv, "kind", "") or "")
                out_kind = "spanDeletion" if kind == "deletion" else "spanInversion" if kind == "inversion" else ""
                if not out_kind:
                    continue
                contig = str(getattr(sv, "chrom_a", "") or "")
                start = min(int(getattr(sv, "pos_a", 0) or 0), int(getattr(sv, "pos_b", 0) or 0))
                end = max(int(getattr(sv, "pos_a", 0) or 0), int(getattr(sv, "pos_b", 0) or 0))
                target_pair = ",".join(sorted({str(getattr(sv, "locus_a", "") or ""), str(getattr(sv, "locus_b", "") or "")}))
                key = (out_kind, contig, start, end, target_pair)
                seen.add(key)
            for key in seen:
                structural_variants[key] = structural_variants.get(key, 0) + 1

        sv_payload: list[dict[str, Any]] = []
        for (kind, contig, start, end, target_pair), count in structural_variants.items():
            target_ids_sv = [t for t in target_pair.split(",") if t]
            length = max(0, int(end - start))
            freq = float(count) / n_alive if n_alive else 0.0
            sv_payload.append(
                {
                    "kind": kind,
                    "targetIds": target_ids_sv,
                    "contig": contig,
                    "start": int(start),
                    "end": int(end),
                    "length": int(length),
                    "frequency": round(float(freq), 8),
                    "notes": ["Dynamic simulator: distance-weighted end-joining; frequency is per surviving cell."],
                }
            )

        def _sv_sort(entry: Mapping[str, Any]) -> tuple[str, str, int, int, str]:
            return (
                str(entry.get("kind") or ""),
                str(entry.get("contig") or ""),
                int(entry.get("start") or 0),
                int(entry.get("end") or 0),
                ",".join(sorted(entry.get("targetIds") or [])),
            )

        sv_payload.sort(key=_sv_sort)

        multiplex_payload = {"targets": multiplex_targets, "combined": combined, "warnings": warnings}

        primary = multiplex_targets[0]
        spectrum = primary.get("alleleSpectrum") if isinstance(primary.get("alleleSpectrum"), list) else []
        primary_id = str(primary.get("targetId") or "")
        primary_eval = primary.get("intentEvaluation") if isinstance(primary.get("intentEvaluation"), Mapping) else None

        summary: list[str] = [
            "Dynamic cut model (ODE + stochastic): delivery-shaped Cas(t), multiplex competition, repair saturation + SVs.",
            context_line,
            f"Sim: n_cells={cfg.population.n_cells} dt_h={cfg.time.dt_h} t_end_h={cfg.time.t_end_h}",
        ]
        if len(multiplex_targets) > 1:
            summary.insert(1, f"Multiplex cut outcomes ({len(multiplex_targets)} targets); primary={primary_id}.")
        else:
            summary.insert(1, f"Cut outcomes; target={primary_id}.")

        uncertainty = {
            "sim": {
                "nCells": int(cfg.population.n_cells),
                "nAlive": int(len(alive_cells)),
                "seed": int(cfg.population.seed),
                "dtHours": float(cfg.time.dt_h),
                "tEndHours": float(cfg.time.t_end_h),
            }
        }
        return OutcomeReportV1(
            model_id=self.model_id,
            model_version=self.model_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            allele_spectrum=list(spectrum),
            uncertainty_summary=[],
            uncertainty=uncertainty,
            multiplex=multiplex_payload if len(multiplex_targets) > 1 else None,
            structural_variants=sv_payload or None,
            edit_intent=dict(intent),
            intent_evaluation=dict(primary_eval) if isinstance(primary_eval, Mapping) else None,
        )


__all__ = ["DynamicCutOutcomeModel"]
