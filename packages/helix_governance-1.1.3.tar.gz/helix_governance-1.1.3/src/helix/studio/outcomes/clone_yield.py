from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Mapping

from .hotspots import allele_key_from_entry


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (
        json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n"
    ).encode("utf-8")


def clone_plan_json_bytes(plan: Mapping[str, Any]) -> bytes:
    return _canonical_json_bytes(dict(plan))


def clone_plan_sha256(plan: Mapping[str, Any]) -> str:
    return hashlib.sha256(clone_plan_json_bytes(plan)).hexdigest()


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _normalize_label(value: Any) -> str:
    return str(value or "").strip().lower()


def _select_desired_entry(
    allele_spectrum: list[Any],
    *,
    desired_allele_key: str | None = None,
) -> tuple[Mapping[str, Any] | None, str | None]:
    if desired_allele_key:
        desired_key = str(desired_allele_key)
        for entry in allele_spectrum:
            if not isinstance(entry, Mapping):
                continue
            try:
                if allele_key_from_entry(entry) == desired_key:
                    return entry, desired_key
            except Exception:
                continue

    desired_candidates: list[tuple[float, str, Mapping[str, Any]]] = []
    fallback_candidates: list[tuple[float, str, Mapping[str, Any]]] = []
    for entry in allele_spectrum:
        if not isinstance(entry, Mapping):
            continue
        delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
        kind = _normalize_label(delta.get("type"))
        label = _normalize_label(delta.get("label"))
        if kind == "other":
            continue
        freq = _safe_float(entry.get("frequency"), 0.0)
        try:
            key = allele_key_from_entry(entry)
        except Exception:
            key = ""
        if label in {"desired_edit", "desired"} or kind == "prime_desired":
            desired_candidates.append((freq, key, entry))
        else:
            if "failure" in kind or label == "failure":
                continue
            fallback_candidates.append((freq, key, entry))

    def _pick(candidates: list[tuple[float, str, Mapping[str, Any]]]) -> tuple[Mapping[str, Any] | None, str | None]:
        if not candidates:
            return None, None
        candidates.sort(key=lambda item: (-item[0], item[1]))
        _, key, entry = candidates[0]
        return entry, key or None

    entry, key = _pick(desired_candidates)
    if entry is not None:
        return entry, key
    return _pick(fallback_candidates)


def build_clone_plan(
    report_payload: Mapping[str, Any],
    *,
    desired_allele_key: str | None = None,
    target_confidence: float = 0.95,
    outcome_report_sha256: str | None = None,
) -> dict[str, Any]:
    allele_spectrum = report_payload.get("alleleSpectrum") if isinstance(report_payload.get("alleleSpectrum"), list) else []
    entry, key = _select_desired_entry(allele_spectrum, desired_allele_key=desired_allele_key)

    desired_freq = 0.0
    if entry is not None:
        desired_freq = _safe_float(entry.get("frequency"), 0.0)
    desired_freq = max(0.0, min(1.0, desired_freq))

    confidence = _safe_float(target_confidence, 0.95)
    if confidence <= 0.0:
        confidence = 0.95
    if confidence >= 1.0:
        confidence = 0.99

    clones_needed = None
    if desired_freq >= 1.0:
        clones_needed = 1
    elif desired_freq > 0.0:
        denom = math.log(max(1e-12, 1.0 - desired_freq))
        if denom < 0:
            clones_needed = int(math.ceil(math.log(1.0 - confidence) / denom))
            clones_needed = max(1, clones_needed)

    assumptions = [
        "Binomial model with independent clones.",
        "Desired frequency derived from outcome report allele spectrum.",
        f"Target confidence {confidence:.2f}.",
    ]
    if desired_freq <= 0.0:
        if entry is None:
            assumptions.append("Desired allele not found; frequency assumed 0.")
        assumptions.append("Desired frequency is 0; clones required undefined.")

    return {
        "schema": "helix_clone_plan_v1",
        "outcomeReportSha256": str(outcome_report_sha256 or ""),
        "desiredAlleleKey": str(key or ""),
        "desiredFrequency": round(desired_freq, 8),
        "targetConfidence": round(confidence, 4),
        "expectedPositiveRate": round(desired_freq, 8),
        "clonesNeededBulk": clones_needed,
        "clonesNeededSingleCell": clones_needed,
        "assumptions": assumptions,
    }


__all__ = [
    "build_clone_plan",
    "clone_plan_json_bytes",
    "clone_plan_sha256",
]
