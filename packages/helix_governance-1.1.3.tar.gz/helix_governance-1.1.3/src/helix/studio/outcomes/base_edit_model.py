from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from helix import bioinformatics
from helix.studio.experiment_spec import experiment_spec_to_dict

from .model import OutcomeReportV1, compute_inputs_sha256
from .noop import NoopOutcomeModel


@dataclass(frozen=True)
class BaseEditPlan:
    contig: str
    window_start: int
    window_end: int
    guide_start: int
    guide_end: int
    strand: str
    sequence: str
    guide_seq: str
    editor_kind: str
    window_start_index: int
    window_end_index: int
    target_base: str
    intended_index: int | None


def _safe_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _normalize_editor_kind(value: Any) -> str:
    kind = str(value or "").strip().upper()
    if kind in {"ABE", "CBE"}:
        return kind
    if "CBE" in kind:
        return "CBE"
    if "ABE" in kind:
        return "ABE"
    return "ABE"


def _default_window_range(editor_kind: str) -> tuple[int, int]:
    if editor_kind == "CBE":
        return 13, 17
    return 12, 16


def _first_int(mapping: Mapping[str, Any], keys: tuple[str, ...]) -> int | None:
    for key in keys:
        if key not in mapping:
            continue
        value = mapping.get(key)
        try:
            return int(value)
        except Exception:
            continue
    return None


def _resolve_window_range(guide_len: int, editor_kind: str, base_cfg: Mapping[str, Any]) -> tuple[int, int]:
    guide_len = max(1, int(guide_len))
    default_start, default_end = _default_window_range(editor_kind)
    default_span = default_end - default_start
    start = _first_int(base_cfg, ("windowStart", "window_start", "editWindowStart", "edit_window_start"))
    end = _first_int(base_cfg, ("windowEnd", "window_end", "editWindowEnd", "edit_window_end"))
    window_cfg = base_cfg.get("window") if isinstance(base_cfg.get("window"), Mapping) else None
    if window_cfg is not None:
        if start is None:
            start = _first_int(window_cfg, ("start", "windowStart"))
        if end is None:
            end = _first_int(window_cfg, ("end", "windowEnd"))
    if start is None and end is None:
        start, end = default_start, default_end
    elif start is None:
        end = end if end is not None else default_end
        start = end - default_span
    elif end is None:
        start = start if start is not None else default_start
        end = start + default_span
    if start is None or end is None:
        start, end = default_start, default_end
    start = max(0, min(int(start), guide_len - 1))
    end = max(0, min(int(end), guide_len - 1))
    if end < start:
        start, end = end, start
    return start, end


def _resolve_intended_index(
    guide_len: int,
    base_cfg: Mapping[str, Any],
    *,
    window_start: int,
    window_end: int,
) -> int | None:
    intended = _first_int(
        base_cfg,
        ("intendedIndex", "intended_index", "targetIndex", "target_index", "desiredIndex", "desired_index"),
    )
    if intended is None:
        intended = (window_start + window_end) // 2
    if intended is None:
        return None
    intended = max(0, min(int(intended), guide_len - 1))
    return intended


def _resolve_guide_span(
    guide: Mapping[str, Any],
    *,
    window_start: int,
    sequence_len: int,
) -> tuple[int | None, int | None]:
    start = guide.get("start", guide.get("guideStart"))
    end = guide.get("end", guide.get("guideEnd"))
    if start is None or end is None:
        return None, None
    start_int = _safe_int(start, -1)
    end_int = _safe_int(end, -1)
    if 0 <= start_int < sequence_len and 0 < end_int <= sequence_len and end_int > start_int:
        return start_int, end_int
    if start_int >= window_start and end_int > start_int:
        rel_start = start_int - window_start
        rel_end = end_int - window_start
        if 0 <= rel_start < sequence_len and rel_end > rel_start:
            return rel_start, min(rel_end, sequence_len)
    return None, None


def _extract_base_cfg(edit_plan: Mapping[str, Any] | None, spec: Mapping[str, Any]) -> Mapping[str, Any]:
    base_cfg: Mapping[str, Any] | None = None
    if isinstance(edit_plan, Mapping):
        base_cfg = (
            edit_plan.get("base")
            or edit_plan.get("base_edit")
            or edit_plan.get("baseEdit")
            or edit_plan.get("baseEditConfig")
        )
        if not isinstance(base_cfg, Mapping):
            targets = edit_plan.get("targets")
            if isinstance(targets, list):
                for target in targets:
                    if not isinstance(target, Mapping):
                        continue
                    candidate = (
                        target.get("base")
                        or target.get("base_edit")
                        or target.get("baseEdit")
                        or target.get("baseEditConfig")
                    )
                    if isinstance(candidate, Mapping):
                        base_cfg = candidate
                        break
    if not isinstance(base_cfg, Mapping):
        base_cfg = {}
    base_cfg = dict(base_cfg)
    assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
    if isinstance(assumptions, Mapping):
        nested = (
            assumptions.get("base")
            or assumptions.get("base_edit")
            or assumptions.get("baseEdit")
            or assumptions.get("baseEditConfig")
        )
        if isinstance(nested, Mapping):
            for key, value in nested.items():
                base_cfg.setdefault(key, value)
        for key in (
            "editorType",
            "editorKind",
            "editor",
            "kind",
            "windowStart",
            "windowEnd",
            "editWindowStart",
            "editWindowEnd",
            "intendedIndex",
            "targetIndex",
            "desiredIndex",
        ):
            if key in assumptions and key not in base_cfg:
                base_cfg[key] = assumptions.get(key)
    return base_cfg


def _extract_editor_kind(base_cfg: Mapping[str, Any], spec: Mapping[str, Any]) -> str:
    kind = (
        base_cfg.get("editorType")
        or base_cfg.get("editorKind")
        or base_cfg.get("editor")
        or base_cfg.get("kind")
    )
    if not kind:
        assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
        kind = (
            assumptions.get("editorType")
            or assumptions.get("baseEditor")
            or assumptions.get("editorKind")
            or assumptions.get("editor")
        )
    return _normalize_editor_kind(kind)


def _has_multiplex_targets(edit_plan: Mapping[str, Any] | None) -> bool:
    if not isinstance(edit_plan, Mapping):
        return False
    targets = edit_plan.get("targets")
    return isinstance(targets, list) and len([t for t in targets if isinstance(t, Mapping)]) > 1


def extract_base_plan(
    experiment_spec: Mapping[str, Any] | None,
    edit_plan: Mapping[str, Any] | None,
    reference_context: Mapping[str, Any] | None,
) -> BaseEditPlan | None:
    spec = experiment_spec_to_dict(experiment_spec)
    locus = spec.get("locus") if isinstance(spec.get("locus"), dict) else {}
    contig = (
        str((edit_plan or {}).get("contig") or "")
        or str((reference_context or {}).get("contig") or "")
        or str(locus.get("chr") or "")
    )
    if not contig:
        return None
    window_start = _safe_int((reference_context or {}).get("windowStart"), _safe_int(locus.get("start"), 0))
    window_end = _safe_int((reference_context or {}).get("windowEnd"), _safe_int(locus.get("end"), 0))
    sequence = (reference_context or {}).get("sequence") or (reference_context or {}).get("windowSequence")
    if not isinstance(sequence, str) or not sequence:
        return None
    sequence = sequence.upper()
    if window_end <= window_start:
        window_start = max(0, window_start)
        window_end = window_start + len(sequence)
    guide: Mapping[str, Any] = {}
    if isinstance(edit_plan, Mapping):
        raw_guide = edit_plan.get("guide")
        if isinstance(raw_guide, Mapping):
            guide = raw_guide
        else:
            targets = edit_plan.get("targets")
            if isinstance(targets, list):
                for target in targets:
                    if isinstance(target, Mapping):
                        guide = target
                        break
    if not isinstance(guide, Mapping):
        return None
    strand = str(guide.get("strand") or (edit_plan or {}).get("strand") or locus.get("strand") or "+")
    guide_start, guide_end = _resolve_guide_span(guide, window_start=window_start, sequence_len=len(sequence))
    if guide_start is None or guide_end is None:
        return None
    if not (0 <= guide_start < guide_end <= len(sequence)):
        return None
    guide_seq = str(guide.get("sequence") or guide.get("guideSequence") or guide.get("guide_seq") or "")
    if not guide_seq:
        guide_seq = sequence[guide_start:guide_end]
        if strand == "-":
            guide_seq = bioinformatics.reverse_complement(guide_seq)
    guide_seq = guide_seq.upper()
    if not guide_seq:
        return None
    base_cfg = _extract_base_cfg(edit_plan, spec)
    editor_kind = _extract_editor_kind(base_cfg, spec)
    window_start_index, window_end_index = _resolve_window_range(len(guide_seq), editor_kind, base_cfg)
    target_base = "A" if editor_kind == "ABE" else "C"
    intended_index = _resolve_intended_index(
        len(guide_seq),
        base_cfg,
        window_start=window_start_index,
        window_end=window_end_index,
    )
    return BaseEditPlan(
        contig=contig,
        window_start=window_start,
        window_end=window_end,
        guide_start=guide_start,
        guide_end=guide_end,
        strand=strand if strand in {"+", "-"} else "+",
        sequence=sequence,
        guide_seq=guide_seq,
        editor_kind=editor_kind,
        window_start_index=window_start_index,
        window_end_index=window_end_index,
        target_base=target_base,
        intended_index=intended_index,
    )


def extract_base_inputs_from_session(session) -> tuple[dict[str, Any], dict[str, Any]] | None:
    try:
        spec = experiment_spec_to_dict(session.state.experiment_spec)
    except Exception:
        return None
    locus = spec.get("locus") if isinstance(spec.get("locus"), dict) else {}
    contig = str(locus.get("chr") or "")
    if not contig:
        return None
    try:
        genome = session.state.genome
        sequences = getattr(genome, "sequences", {}) if genome is not None else {}
    except Exception:
        sequences = {}
    sequence = sequences.get(contig)
    if not isinstance(sequence, str) or not sequence:
        return None
    window_start = _safe_int(locus.get("start"), 0)
    window_end = _safe_int(locus.get("end"), 0)
    if window_end <= window_start:
        window_start = 0
        window_end = len(sequence)
    window_start = max(0, min(window_start, len(sequence)))
    window_end = max(window_start, min(window_end, len(sequence)))
    window_seq = sequence[window_start:window_end]

    cfg = session.state.config if isinstance(session.state.config, Mapping) else {}
    guide = cfg.get("guide") if isinstance(cfg.get("guide"), Mapping) else {}
    base_cfg = cfg.get("base") or cfg.get("base_edit") or cfg.get("baseEdit") or {}

    sim_type = str(cfg.get("sim_type") or "").lower()
    if not base_cfg and sim_type not in {"base", "base_edit", "base-edit"}:
        return None

    edit_plan = {
        "contig": contig,
        "guide": dict(guide) if isinstance(guide, Mapping) else {},
        "base": dict(base_cfg) if isinstance(base_cfg, Mapping) else {},
    }
    reference_context = {
        "contig": contig,
        "windowStart": window_start,
        "windowEnd": window_end,
        "sequence": window_seq,
    }
    return edit_plan, reference_context


class BaseEditOutcomeModel:
    model_id = "base_edit_model"
    model_version = "v1"

    def can_handle(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
    ) -> bool:
        spec = experiment_spec_to_dict(experiment_spec)
        intent = str(spec.get("intent") or "").lower()
        modalities = spec.get("editModalities") if isinstance(spec.get("editModalities"), list) else []
        if intent in {"base_edit", "base", "base-edit"}:
            return True
        if any("base" in str(m).lower() for m in modalities):
            return True
        if isinstance(edit_plan, Mapping):
            if "base" in edit_plan or "base_edit" in edit_plan or "baseEdit" in edit_plan:
                return True
        return False

    def run(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
    ) -> OutcomeReportV1:
        plan = extract_base_plan(experiment_spec, edit_plan, reference_context)
        if plan is None:
            return NoopOutcomeModel().run(experiment_spec, edit_plan, reference_context)

        guide_len = len(plan.guide_seq)
        window_start = plan.window_start_index
        window_end = plan.window_end_index
        window_indices = list(range(window_start, window_end + 1))
        window_len = len(window_indices)
        target_base = plan.target_base
        editable_positions = [
            idx for idx in window_indices if 0 <= idx < guide_len and plan.guide_seq[idx] == target_base
        ]
        editable = len(editable_positions)
        intended_index = plan.intended_index
        warnings: list[str] = []
        has_intended = (
            intended_index is not None
            and intended_index in window_indices
            and 0 <= intended_index < guide_len
            and plan.guide_seq[intended_index] == target_base
        )

        desired = 0.0
        if editable > 0:
            if has_intended:
                desired = min(0.55, 0.2 + 0.05 * editable)
            else:
                desired = min(0.15, 0.02 * editable)
        bystander = min(0.4, 0.04 * max(0, editable - (1 if has_intended else 0)))
        off_target = min(0.3, 0.04 + 0.005 * window_len + 0.015 * editable)
        total = desired + bystander + off_target
        if total > 1.0:
            scale = 1.0 / total
            desired *= scale
            bystander *= scale
            off_target *= scale
            total = 1.0
        if editable > 0 and not has_intended and desired > 0.0:
            warnings.append("Intended index not editable in window; desired probability set to 0.")
            desired = 0.0
            total = desired + bystander + off_target
            if total > 1.0:
                scale = 1.0 / total
                desired *= scale
                bystander *= scale
                off_target *= scale
                total = 1.0
        failure = max(0.0, 1.0 - total)

        base_outcomes = [
            {"category": "desired_edit", "probability": round(desired, 6)},
            {"category": "bystander_edit", "probability": round(bystander, 6)},
            {"category": "off_target_deamination", "probability": round(off_target, 6)},
            {"category": "failure", "probability": round(failure, 6)},
        ]

        def _append_allele(
            kind: str,
            prob: float,
            *,
            start: int | None,
            end: int | None,
            label: str,
            ref_base: str | None = None,
            alt_base: str | None = None,
            role: str | None = None,
            pos: int | None = None,
        ) -> None:
            delta: dict[str, Any] = {"type": kind, "label": label}
            if start is not None and end is not None:
                delta["start"] = int(start)
                delta["end"] = int(end)
                delta["length"] = int(max(0, end - start))
            if ref_base:
                delta["refBase"] = ref_base
            if alt_base:
                delta["altBase"] = alt_base
            if role:
                delta["role"] = role
            if pos is not None:
                delta["pos"] = int(pos)
            allele_spectrum.append(
                {
                    "sequenceDelta": delta,
                    "frequency": round(float(prob), 8),
                }
            )

        allele_spectrum: list[dict[str, Any]] = []
        position_probs: list[dict[str, Any]] = []

        pos_rel_anchor = guide_len - 1 if guide_len > 0 else 0

        def _guide_index_to_genome(idx: int) -> int:
            if plan.strand == "+":
                return plan.guide_start + idx
            return plan.guide_end - 1 - idx

        desired_total = round(desired, 6)
        bystander_total = round(bystander, 6)
        desired_pos = intended_index if has_intended else None
        bystander_positions = [pos for pos in editable_positions if pos != desired_pos]

        anchor = desired_pos if desired_pos is not None else (window_start + window_end) // 2
        window_width = window_end - window_start + 1
        scale = max(2, int(round(window_width / 4)))
        floor = 1

        weights: dict[int, int] = {}
        for pos in bystander_positions:
            d = abs(pos - anchor)
            raw = max(0, scale - d)
            weights[pos] = raw + floor
        weight_total = sum(weights.values())

        bystander_probs: dict[int, float] = {}
        if weight_total > 0 and bystander_total > 0:
            for pos, weight in weights.items():
                bystander_probs[pos] = bystander_total * (weight / weight_total)

            rounded = {pos: round(prob, 6) for pos, prob in bystander_probs.items()}
            residual = round(bystander_total - sum(rounded.values()), 6)
            if abs(residual) > 1e-6 and rounded:
                pos_adjust = sorted(rounded.items(), key=lambda item: (-item[1], item[0]))[0][0]
                rounded[pos_adjust] = round(max(0.0, rounded[pos_adjust] + residual), 6)
            bystander_probs = rounded

        desired_prob = desired_total if desired_pos is not None and desired_total > 0 else 0.0

        positions_sorted = sorted(
            [pos for pos in editable_positions if pos in bystander_probs or pos == desired_pos]
        )
        alt_base = "G" if target_base == "A" else "T"
        for pos in positions_sorted:
            role = "desired" if pos == desired_pos else "bystander"
            prob = desired_prob if role == "desired" else bystander_probs.get(pos, 0.0)
            if prob <= 0.0:
                continue
            pos_rel = pos - pos_rel_anchor
            position_probs.append(
                {
                    "pos": int(pos_rel),
                    "base": target_base,
                    "prob": round(prob, 6),
                    "role": role,
                }
            )
            genome_pos = _guide_index_to_genome(pos)
            _append_allele(
                "base_substitution",
                prob,
                start=genome_pos,
                end=genome_pos + 1,
                label="desired_edit" if role == "desired" else "bystander_edit",
                ref_base=target_base,
                alt_base=alt_base,
                role=role,
                pos=pos_rel,
            )

        if off_target > 0.0:
            _append_allele("base_offtarget", off_target, start=None, end=None, label="off_target_deamination")
        _append_allele("base_failure", failure, start=None, end=None, label="FAILURE")

        editable_note = (
            "none"
            if not editable_positions
            else ", ".join(str(idx) for idx in editable_positions)
        )
        summary = [
            f"Baseline base edit model ({plan.editor_kind}).",
            f"Edit window indices {window_indices[0]}-{window_indices[-1]} (guide length {guide_len}).",
            f"Editable positions ({target_base}): {editable_note} (count {editable}).",
        ]
        if warnings:
            summary.append("Warnings: " + "; ".join(warnings))
        if _has_multiplex_targets(edit_plan):
            summary.insert(0, "Multiplex v1 supports only primary target for base editing.")

        return OutcomeReportV1(
            model_id=self.model_id,
            model_version=self.model_version,
            inputs_sha256=compute_inputs_sha256(experiment_spec, edit_plan, reference_context),
            summary=summary,
            allele_spectrum=allele_spectrum,
            uncertainty_summary=[],
            uncertainty={},
            base_outcomes=base_outcomes,
            base_editor={
                "editorType": plan.editor_kind,
                "targetBase": target_base,
                "windowStart": window_start,
                "windowEnd": window_end,
                "windowLength": window_len,
                "intendedIndex": intended_index,
                "editablePositions": editable_positions,
                "editableCount": editable,
            },
            base_position_probs={"positions": position_probs},
        )


__all__ = ["BaseEditOutcomeModel", "extract_base_inputs_from_session"]
