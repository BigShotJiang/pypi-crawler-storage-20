from __future__ import annotations

import itertools
from typing import Any, Mapping

from helix.studio.experiment_spec import experiment_spec_to_dict

from .model import OutcomeReportV1, compute_inputs_sha256


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _extract_prime_lengths(edit_plan: Mapping[str, Any] | None) -> tuple[int | None, int | None]:
    if not isinstance(edit_plan, Mapping):
        return None, None
    peg = edit_plan.get("pegRNA") or edit_plan.get("peg") or edit_plan.get("prime") or {}
    if not isinstance(peg, Mapping):
        peg = {}
    rtt = peg.get("rtt") or peg.get("rttSequence")
    pbs = peg.get("pbs") or peg.get("pbsSequence")
    rtt_len = peg.get("rtt_len") or peg.get("rttLength")
    pbs_len = peg.get("pbs_len") or peg.get("pbsLength")
    if rtt_len is None and isinstance(rtt, str):
        rtt_len = len(rtt)
    if pbs_len is None and isinstance(pbs, str):
        pbs_len = len(pbs)
    if rtt_len is None:
        return None, None
    return _safe_int(rtt_len, 0), _safe_int(pbs_len, 0) if pbs_len is not None else None


def _extract_prime_config(edit_plan: Mapping[str, Any] | None) -> Mapping[str, Any]:
    if not isinstance(edit_plan, Mapping):
        return {}
    prime_cfg = edit_plan.get("prime") or edit_plan.get("pegRNA") or edit_plan.get("peg") or {}
    if isinstance(prime_cfg, Mapping):
        return prime_cfg
    return {}


def _extract_prime_sequences(edit_plan: Mapping[str, Any] | None) -> tuple[str | None, str | None]:
    if not isinstance(edit_plan, Mapping):
        return None, None
    peg = edit_plan.get("pegRNA") or edit_plan.get("peg") or edit_plan.get("prime") or {}
    if not isinstance(peg, Mapping):
        peg = {}
    rtt = peg.get("rtt") or peg.get("rttSequence") or peg.get("rtt_seq")
    pbs = peg.get("pbs") or peg.get("pbsSequence") or peg.get("pbs_seq")
    rtt_seq = str(rtt).strip().upper() if isinstance(rtt, str) and rtt.strip() else None
    pbs_seq = str(pbs).strip().upper() if isinstance(pbs, str) and pbs.strip() else None
    return rtt_seq, pbs_seq


def _extract_anchor_pos(prime_cfg: Mapping[str, Any]) -> int | None:
    for key in ("edit_anchor_pos", "edit_anchor", "edit_pos", "editPos", "editAnchorPos"):
        if key in prime_cfg:
            try:
                return int(prime_cfg.get(key))
            except Exception:
                continue
    return None


def _extract_nick_pos(prime_cfg: Mapping[str, Any]) -> int | None:
    for key in ("nick_pos_bp", "nick_pos", "nickPos", "nick"):
        if key in prime_cfg:
            try:
                return int(prime_cfg.get(key))
            except Exception:
                continue
    nick = prime_cfg.get("nicking_guide") if isinstance(prime_cfg.get("nicking_guide"), Mapping) else None
    if isinstance(nick, Mapping):
        for key in ("offset", "offset_bp", "offsetBp"):
            if key in nick:
                try:
                    return int(nick.get(key))
                except Exception:
                    continue
    return None


def _has_multiplex_targets(edit_plan: Mapping[str, Any] | None) -> bool:
    if not isinstance(edit_plan, Mapping):
        return False
    targets = edit_plan.get("targets")
    return isinstance(targets, list) and len([t for t in targets if isinstance(t, Mapping)]) > 1


def _extract_target_pos(target: Mapping[str, Any]) -> int | None:
    for key in ("editAnchorPos", "anchor", "cutIndex", "pos", "position"):
        if key in target:
            try:
                return int(target.get(key))
            except Exception:
                continue
    return None


def _compute_prime_multiplex(edit_plan: Mapping[str, Any] | None, desired_prob: float) -> dict[str, Any] | None:
    if not _has_multiplex_targets(edit_plan):
        return None
    targets = [t for t in edit_plan.get("targets", []) if isinstance(t, Mapping)]
    target_ids = []
    target_positions = []
    target_entries = []
    for t in targets:
        tid = t.get("targetId") or t.get("id") or "t"
        target_ids.append(tid)
        pos = _extract_target_pos(t)
        target_positions.append(pos)
        target_entries.append({"targetId": tid, "desired": desired_prob, "pos": pos})
    combined_independent = desired_prob ** len(target_entries) if target_entries else 0.0

    # Interaction penalty heuristic: distance-based dampening when targets are close on same contig.
    penalty = 1.0
    distances: list[int] = []
    positions = [_extract_target_pos(t) for t in targets]
    for (a, pos_a), (b, pos_b) in itertools.combinations(zip(target_entries, positions), 2):
        if pos_a is None or pos_b is None:
            continue
        d = abs(pos_a - pos_b)
        distances.append(d)
        if d <= 100:
            penalty *= 0.9
        elif d <= 200:
            penalty *= 0.95
    penalty = max(0.5, min(1.0, penalty))
    combined_adjusted = combined_independent * penalty
    warnings = ["Prime multiplex v1 applies a distance-based interaction penalty."] if target_entries else []
    return {
        "targets": target_entries,
        "combinedDesiredIndependent": round(combined_independent, 6),
        "interactionPenalty": round(penalty, 6),
        "combinedDesired": round(combined_adjusted, 6),
        "distances": distances,
        "warnings": warnings,
        "params": {
            "penaltyRule": "distance_product",
            "distanceBucketA": 100,
            "distanceBucketB": 200,
            "penaltyA": 0.9,
            "penaltyB": 0.95,
            "combineRule": "product",
        },
        "targetIds": target_ids,
        "targetPositions": target_positions,
    }


def _resolve_window(spec: Mapping[str, Any], reference_context: Mapping[str, Any] | None) -> tuple[int, int, int]:
    locus = spec.get("locus") if isinstance(spec.get("locus"), Mapping) else {}
    window_start = _safe_int((reference_context or {}).get("windowStart"), _safe_int(locus.get("start"), 0))
    window_end = _safe_int((reference_context or {}).get("windowEnd"), _safe_int(locus.get("end"), 0))
    seq = (reference_context or {}).get("sequence")
    seq_len = len(seq) if isinstance(seq, str) else 0
    if seq_len and window_end <= window_start:
        window_end = window_start + seq_len
    if not seq_len and window_end > window_start:
        seq_len = window_end - window_start
    return window_start, window_end, max(0, seq_len)


def _anchor_to_window(anchor: int, window_start: int, seq_len: int) -> int:
    if seq_len <= 0:
        return max(0, anchor)
    if anchor >= window_start and anchor - window_start < seq_len:
        return anchor - window_start
    if 0 <= anchor < seq_len:
        return anchor
    return max(0, min(anchor, seq_len - 1))


def extract_prime_inputs_from_session(session) -> tuple[dict[str, Any], dict[str, Any]] | None:
    try:
        peg = session.state.peg
    except Exception:
        peg = None
    if peg is None:
        return None
    peg_payload = {}
    try:
        peg_payload = {"rtt": getattr(peg, "rtt", None), "pbs": getattr(peg, "pbs", None)}
    except Exception:
        peg_payload = {}
    prime_cfg = {}
    try:
        cfg = session.state.config
        if isinstance(cfg, Mapping):
            prime_cfg = cfg.get("prime") or {}
    except Exception:
        prime_cfg = {}
    edit_plan = {"prime": {**prime_cfg, "pegRNA": peg_payload}, "pegRNA": peg_payload}
    reference_context: dict[str, Any] = {}
    return edit_plan, reference_context


class PrimeOutcomeModel:
    model_id = "prime_model"
    model_version = "v1"

    def can_handle(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
    ) -> bool:
        spec = experiment_spec_to_dict(experiment_spec)
        intent = str(spec.get("intent") or "").lower()
        modalities = spec.get("editModalities") if isinstance(spec.get("editModalities"), list) else []
        if intent == "prime_edit" or "prime" in modalities:
            return True
        if isinstance(edit_plan, Mapping):
            if "prime" in edit_plan or "pegRNA" in edit_plan or "peg" in edit_plan:
                return True
        return False

    def run(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
    ) -> OutcomeReportV1:
        inputs_sha = compute_inputs_sha256(experiment_spec, edit_plan, reference_context)
        rtt_len, pbs_len = _extract_prime_lengths(edit_plan)
        spec = experiment_spec_to_dict(experiment_spec)
        prime_cfg = _extract_prime_config(edit_plan)
        rtt_seq, pbs_seq = _extract_prime_sequences(edit_plan)
        window_start, _window_end, seq_len = _resolve_window(spec, reference_context)
        anchor_pos = _extract_anchor_pos(prime_cfg)

        desired = 0.30
        partial = 0.15
        trunc = 0.10
        nick_indel = 0.20
        failure = 0.25
        warnings: list[str] = []

        if rtt_len is None and rtt_seq is None:
            warnings.append("RT template length missing; using default priors.")
        else:
            if rtt_len > 25:
                desired -= 0.05
                trunc += 0.05
            elif rtt_len < 10:
                desired -= 0.05
                partial += 0.05

        if pbs_len is None and pbs_seq is None:
            warnings.append("PBS length missing; using default priors.")
        else:
            if pbs_len < 8:
                desired -= 0.05
                failure += 0.05
            elif pbs_len > 13:
                desired += 0.03
                failure -= 0.03

        priors = [desired, partial, trunc, nick_indel, failure]
        priors = [max(0.01, _safe_float(p)) for p in priors]
        total = sum(priors)
        priors = [p / total for p in priors]

        categories = [
            {"category": "desired_edit", "probability": round(priors[0], 6)},
            {"category": "partial_edit", "probability": round(priors[1], 6)},
            {"category": "rt_template_truncation", "probability": round(priors[2], 6)},
            {"category": "nick_indels", "probability": round(priors[3], 6)},
            {"category": "pegRNA_failure", "probability": round(priors[4], 6)},
        ]

        allele_spectrum: list[dict[str, Any]] = []
        if rtt_seq:
            edit_len = len(rtt_seq)
        else:
            edit_len = max(1, _safe_int(rtt_len, 12))
        if anchor_pos is None:
            if seq_len > 0:
                anchor_pos = window_start + seq_len // 2
            else:
                anchor_pos = window_start
        anchor_idx = _anchor_to_window(anchor_pos, window_start, seq_len)
        edit_start = None
        edit_end = None
        if seq_len > 0:
            edit_start = max(0, anchor_idx - edit_len // 2)
            edit_end = min(seq_len, edit_start + edit_len)

        nick_pos = _extract_nick_pos(prime_cfg)
        nick_idx = None
        if nick_pos is not None and seq_len > 0:
            nick_idx = _anchor_to_window(nick_pos, window_start, seq_len)

        def _append_allele(
            kind: str,
            prob: float,
            *,
            start: int | None,
            end: int | None,
            label: str,
            sequence: str | None = None,
        ) -> None:
            delta: dict[str, Any] = {"type": kind, "label": label}
            if start is not None and end is not None:
                delta["start"] = int(start)
                delta["end"] = int(end)
                delta["length"] = int(max(0, end - start))
            if sequence:
                delta["sequence"] = sequence
            allele_spectrum.append(
                {
                    "sequenceDelta": delta,
                    "frequency": round(float(prob), 8),
                }
            )

        desired_seq = rtt_seq
        if not desired_seq and edit_len > 0:
            desired_seq = None

        partial_seq = None
        trunc_seq = None
        partial_end = edit_end
        trunc_end = edit_end
        if desired_seq:
            if pbs_len is not None and pbs_len > 0:
                partial_len = max(1, min(len(desired_seq), int(pbs_len)))
            else:
                partial_len = max(1, int(round(len(desired_seq) * 0.6)))
            trunc_len = max(1, int(round(len(desired_seq) * 0.3)))
            partial_seq = desired_seq[:partial_len]
            trunc_seq = desired_seq[:trunc_len]
            if edit_start is not None:
                partial_end = min(seq_len, edit_start + partial_len) if seq_len > 0 else edit_start + partial_len
                trunc_end = min(seq_len, edit_start + trunc_len) if seq_len > 0 else edit_start + trunc_len

        for entry in categories:
            cat = str(entry.get("category") or "")
            prob = float(entry.get("probability") or 0.0)
            if cat == "desired_edit":
                _append_allele(
                    "prime_desired",
                    prob,
                    start=edit_start,
                    end=edit_end,
                    label=cat,
                    sequence=desired_seq,
                )
            elif cat == "partial_edit":
                _append_allele(
                    "prime_partial",
                    prob,
                    start=edit_start,
                    end=partial_end,
                    label=cat,
                    sequence=partial_seq,
                )
            elif cat == "rt_template_truncation":
                _append_allele(
                    "prime_truncation",
                    prob,
                    start=edit_start,
                    end=trunc_end,
                    label=cat,
                    sequence=trunc_seq,
                )
            elif cat == "nick_indels":
                if nick_idx is not None:
                    nick_start = max(0, nick_idx - 1)
                    nick_end = min(seq_len, nick_idx + 2)
                else:
                    nick_start = None
                    nick_end = None
                _append_allele("prime_nick_indel", prob, start=nick_start, end=nick_end, label=cat)
            elif cat == "pegRNA_failure":
                _append_allele("prime_failure", prob, start=None, end=None, label="FAILURE")

        summary = [
            "Baseline prime outcome model; categorical priors only.",
            "Desired edit, partial edit, RT truncation, nick indels, pegRNA failure.",
        ]
        if warnings:
            summary.append("Warnings: " + "; ".join(warnings))

        report = OutcomeReportV1(
            model_id=self.model_id,
            model_version=self.model_version,
            inputs_sha256=inputs_sha,
            summary=summary,
            allele_spectrum=allele_spectrum,
            uncertainty_summary=[],
            uncertainty={},
            prime_outcomes=categories,
            prime_warnings=warnings or None,
        )
        multiplex_block = _compute_prime_multiplex(edit_plan, desired)
        if multiplex_block:
            report.multiplex = (report.multiplex or {}) | {"prime": multiplex_block}
            if "warnings" in multiplex_block and multiplex_block["warnings"]:
                warnings.extend([w for w in multiplex_block["warnings"] if w not in warnings])
            report.prime_warnings = warnings or None
        return report


__all__ = ["PrimeOutcomeModel", "extract_prime_inputs_from_session"]
