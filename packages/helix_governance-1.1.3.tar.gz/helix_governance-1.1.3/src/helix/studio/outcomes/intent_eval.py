from __future__ import annotations

from typing import Any, Mapping


_GOAL_VALUES = {"knockout", "precise", "tag", "promoter", "prime"}
_TARGET_KIND_VALUES = {"cds", "exon", "region"}
_SUCCESS_METRIC_VALUES = {"frameshift", "inframe", "precise_edit", "disrupt_motif"}


def _norm(value: Any) -> str:
    return str(value or "").strip().lower()


def _safe_int(value: Any) -> int | None:
    try:
        return int(value)
    except Exception:
        return None


def _safe_float(value: Any) -> float | None:
    try:
        return float(value)
    except Exception:
        return None


def _clamp01(value: float) -> float:
    if value < 0.0:
        return 0.0
    if value > 1.0:
        return 1.0
    return value


def parse_intent(spec: Mapping[str, Any] | None) -> dict[str, Any]:
    """
    Return a normalized, structured edit intent for a given ExperimentSpec payload.

    Backwards compatibility:
    - If spec.editIntent exists, it is normalized and used.
    - Otherwise, legacy spec.intent is mapped into a minimal v1 intent.
    """
    spec = spec if isinstance(spec, Mapping) else {}

    # Accept either a full ExperimentSpec mapping or an intent-shaped mapping.
    edit_intent = spec.get("editIntent") if isinstance(spec.get("editIntent"), Mapping) else None
    if edit_intent is None and any(key in spec for key in ("goal", "target", "success", "context", "version")):
        edit_intent = spec

    legacy_intent = _norm(spec.get("intent") or "knockout")

    if edit_intent is None:
        goal = {
            "knockout": "knockout",
            "ko": "knockout",
            "precise_substitution": "precise",
            "precise": "precise",
            "tag_insertion": "tag",
            "tag": "tag",
            "promoter_edit": "promoter",
            "promoter": "promoter",
            "prime_edit": "prime",
            "prime": "prime",
            "multiplex": "knockout",
        }.get(legacy_intent, "knockout")
        return {
            "version": "v1",
            "goal": goal,
            "target": {
                "kind": "cds",
                "transcriptId": None,
                "exonIndex": None,
                "regionStartAbs": None,
                "regionEndAbs": None,
            },
            "success": {"metric": "frameshift", "threshold": 0.0, "strict": False},
            "context": {"haplotypeId": None, "phaseSetId": None},
        }

    version = _norm(edit_intent.get("version") or "v1")
    if version != "v1":
        version = "v1"

    goal = _norm(edit_intent.get("goal") or "")
    if goal not in _GOAL_VALUES:
        goal = {
            "knockout": "knockout",
            "ko": "knockout",
            "precise_substitution": "precise",
            "precise": "precise",
            "tag_insertion": "tag",
            "tag": "tag",
            "promoter_edit": "promoter",
            "promoter": "promoter",
            "prime_edit": "prime",
            "prime": "prime",
        }.get(goal, None) or {
            "knockout": "knockout",
            "precise_substitution": "precise",
            "tag_insertion": "tag",
            "promoter_edit": "promoter",
            "prime_edit": "prime",
            "multiplex": "knockout",
        }.get(legacy_intent, "knockout")

    target = edit_intent.get("target") if isinstance(edit_intent.get("target"), Mapping) else {}
    kind = _norm(target.get("kind") or "cds")
    if kind not in _TARGET_KIND_VALUES:
        kind = "cds"

    transcript_id = target.get("transcriptId")
    transcript_id = str(transcript_id).strip() if isinstance(transcript_id, str) and transcript_id.strip() else None

    exon_index = _safe_int(target.get("exonIndex"))
    if exon_index is not None and exon_index < 0:
        exon_index = None

    region_start_abs = _safe_int(target.get("regionStartAbs"))
    region_end_abs = _safe_int(target.get("regionEndAbs"))

    success = edit_intent.get("success") if isinstance(edit_intent.get("success"), Mapping) else {}
    metric = _norm(success.get("metric") or "frameshift")
    if metric not in _SUCCESS_METRIC_VALUES:
        metric = "frameshift"
    threshold = _safe_float(success.get("threshold"))
    if threshold is None:
        threshold = 0.0
    threshold = _clamp01(float(threshold))
    strict = bool(success.get("strict"))

    context = edit_intent.get("context") if isinstance(edit_intent.get("context"), Mapping) else {}
    haplotype_id = context.get("haplotypeId")
    haplotype_id = str(haplotype_id).strip() if isinstance(haplotype_id, str) and haplotype_id.strip() else None
    phase_set_id = context.get("phaseSetId")
    phase_set_id = str(phase_set_id).strip() if isinstance(phase_set_id, str) and phase_set_id.strip() else None

    return {
        "version": version,
        "goal": goal,
        "target": {
            "kind": kind,
            "transcriptId": transcript_id,
            "exonIndex": exon_index,
            "regionStartAbs": region_start_abs,
            "regionEndAbs": region_end_abs,
        },
        "success": {"metric": metric, "threshold": float(threshold), "strict": strict},
        "context": {"haplotypeId": haplotype_id, "phaseSetId": phase_set_id},
    }


def evaluate_intent(
    allele_spectrum: list[Mapping[str, Any]] | None,
    cut_index: int | None,
    reference_context: Mapping[str, Any] | None,
    transcript_context: Mapping[str, Any] | None,
    *,
    intent: Mapping[str, Any] | None = None,
    assumptions: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Evaluate how well an allele spectrum satisfies an edit intent.

    Returns a JSON-ready payload:
      - successProbability: float | None
      - metricBreakdown: {frameshiftProb, inframeProb, otherProb}
      - reasons: list[str]

    Strict mode: if intent.success.strict is true and required transcript context is
    missing, successProbability is set to None with an explanatory reason.
    """
    allele_spectrum = allele_spectrum if isinstance(allele_spectrum, list) else []
    reference_context = reference_context if isinstance(reference_context, Mapping) else {}
    transcript_context = transcript_context if isinstance(transcript_context, Mapping) else None
    assumptions = assumptions if isinstance(assumptions, Mapping) else {}

    norm_intent = parse_intent(intent) if isinstance(intent, Mapping) else parse_intent({})
    success = norm_intent.get("success") if isinstance(norm_intent.get("success"), Mapping) else {}
    target = norm_intent.get("target") if isinstance(norm_intent.get("target"), Mapping) else {}
    context = norm_intent.get("context") if isinstance(norm_intent.get("context"), Mapping) else {}

    metric = _norm(success.get("metric") or "frameshift")
    threshold = _safe_float(success.get("threshold"))
    threshold = _clamp01(float(threshold if threshold is not None else 0.0))
    strict = bool(success.get("strict"))

    target_kind = _norm(target.get("kind") or "cds")
    intent_transcript_id = (
        str(target.get("transcriptId")).strip()
        if isinstance(target.get("transcriptId"), str) and str(target.get("transcriptId")).strip()
        else None
    )

    reasons: list[str] = []

    window_start = _safe_int(reference_context.get("windowStart"))
    if window_start is None:
        window_start = 0

    eval_region_abs: tuple[int, int] | None = None
    region_source = "unknown"

    if target_kind == "region":
        start_abs = _safe_int(target.get("regionStartAbs"))
        end_abs = _safe_int(target.get("regionEndAbs"))
        if start_abs is None or end_abs is None:
            reasons.append("target_region_missing_bounds")
        else:
            eval_region_abs = (min(start_abs, end_abs), max(start_abs, end_abs))
            region_source = "intent.region"
    elif target_kind == "cds":
        if transcript_context is None:
            reasons.append("transcript_context_missing")
        else:
            cds_start = _safe_int(transcript_context.get("cdsStartAbs"))
            cds_end = _safe_int(transcript_context.get("cdsEndAbs"))
            if cds_start is None or cds_end is None:
                reasons.append("transcript_context_missing_cds_bounds")
            else:
                eval_region_abs = (min(cds_start, cds_end), max(cds_start, cds_end))
                region_source = "assumptions.transcriptContext.cds"
    elif target_kind == "exon":
        reasons.append("exon_target_unsupported")
        if transcript_context is None:
            reasons.append("transcript_context_missing")
        else:
            cds_start = _safe_int(transcript_context.get("cdsStartAbs"))
            cds_end = _safe_int(transcript_context.get("cdsEndAbs"))
            if cds_start is not None and cds_end is not None:
                eval_region_abs = (min(cds_start, cds_end), max(cds_start, cds_end))
                region_source = "assumptions.transcriptContext.cds_fallback"

    transcript_id_ctx = None
    if transcript_context is not None:
        if isinstance(transcript_context.get("transcriptId"), str):
            transcript_id_ctx = transcript_context.get("transcriptId")

    if intent_transcript_id:
        if transcript_context is None:
            reasons.append("transcript_context_missing_for_transcript_id")
        elif transcript_id_ctx and transcript_id_ctx != intent_transcript_id:
            reasons.append("transcript_id_mismatch")

    def _delta_interval_abs(delta: Mapping[str, Any]) -> tuple[int, int] | None:
        kind = _norm(delta.get("type"))
        if kind == "del":
            start = _safe_int(delta.get("start"))
            end = _safe_int(delta.get("end"))
            if start is None:
                return None
            if end is None:
                length = _safe_int(delta.get("length")) or 0
                end = start + max(0, length)
            a = window_start + int(start)
            b = window_start + int(end)
            return (min(a, b), max(a, b))
        if kind == "ins":
            start = _safe_int(delta.get("start"))
            if start is None:
                return None
            pos = window_start + int(start)
            # Treat insertion as a point interval at its locus.
            return (pos, pos + 1)
        return None

    def _overlaps_region(delta: Mapping[str, Any]) -> bool:
        if eval_region_abs is None:
            return True
        interval = _delta_interval_abs(delta)
        if interval is None:
            return False
        a0, a1 = interval
        b0, b1 = eval_region_abs
        return (a0 < b1) and (b0 < a1)

    frameshift_prob = 0.0
    inframe_prob = 0.0
    other_prob = 0.0

    precise_prob = 0.0

    for entry in allele_spectrum:
        if not isinstance(entry, Mapping):
            continue
        freq = _safe_float(entry.get("frequency"))
        if freq is None:
            continue
        freq = _clamp01(float(freq))
        delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
        kind = _norm(delta.get("type"))

        if metric == "precise_edit":
            label = _norm(delta.get("label"))
            if label in {"desired", "desired_edit"} or kind == "prime_desired":
                precise_prob += freq

        if kind not in {"del", "ins"}:
            other_prob += freq
            continue

        if not _overlaps_region(delta):
            other_prob += freq
            continue

        length = _safe_int(delta.get("length"))
        if length is None and kind == "ins":
            length = len(str(delta.get("sequence") or ""))
        if length is None:
            other_prob += freq
            continue
        length = int(length)
        if length <= 0:
            other_prob += freq
            continue

        if length % 3 == 0:
            inframe_prob += freq
        else:
            frameshift_prob += freq

    frameshift_prob = _clamp01(frameshift_prob)
    inframe_prob = _clamp01(inframe_prob)
    other_prob = _clamp01(other_prob)
    precise_prob = _clamp01(precise_prob)

    success_probability: float | None = None
    if metric == "frameshift":
        success_probability = frameshift_prob
    elif metric == "inframe":
        success_probability = inframe_prob
    elif metric == "precise_edit":
        success_probability = precise_prob
    elif metric == "disrupt_motif":
        reasons.append("metric_disrupt_motif_unsupported")
        success_probability = None
    else:
        reasons.append("metric_unsupported")
        success_probability = None

    # Strict mode: refuse to emit successProbability when transcript context is required but missing.
    if strict and metric in {"frameshift", "inframe"}:
        if target_kind in {"cds", "exon"}:
            missing_ctx = transcript_context is None or eval_region_abs is None
            if missing_ctx:
                success_probability = None
                reasons.append("strict_transcript_context_required")
        if intent_transcript_id and (transcript_context is None or transcript_id_ctx != intent_transcript_id):
            success_probability = None
            reasons.append("strict_transcript_id_required")

    meets_threshold: bool | None = None
    if success_probability is not None:
        meets_threshold = bool(float(success_probability) >= float(threshold))

    # Carry identifiers through for downstream reporting/audit packs.
    transcript_meta = {}
    if transcript_context is not None:
        for key in ("transcriptId", "cdsStartAbs", "cdsEndAbs", "strand", "frameAtCdsStart"):
            if key in transcript_context:
                transcript_meta[key] = transcript_context.get(key)
    haplotype_meta = {}
    haplotype_block = assumptions.get("haplotype") if isinstance(assumptions.get("haplotype"), Mapping) else {}
    for key in ("haplotypeId", "alleleLabel", "phaseSetId", "variants"):
        if key in haplotype_block:
            haplotype_meta[key] = haplotype_block.get(key)

    out_context = {
        "cutIndex": int(cut_index) if cut_index is not None else None,
        "windowStart": int(window_start),
        "regionSource": region_source,
        "regionAbs": list(eval_region_abs) if eval_region_abs is not None else None,
        "intentContext": dict(context),
        "transcriptContext": transcript_meta or None,
        "haplotype": haplotype_meta or None,
    }

    return {
        "successProbability": success_probability,
        "meetsThreshold": meets_threshold,
        "metricBreakdown": {
            "frameshiftProb": round(frameshift_prob, 8),
            "inframeProb": round(inframe_prob, 8),
            "otherProb": round(other_prob, 8),
        },
        "metric": metric,
        "threshold": round(float(threshold), 6),
        "strict": strict,
        "reasons": reasons,
        "evaluationContext": out_context,
    }


__all__ = ["parse_intent", "evaluate_intent"]
