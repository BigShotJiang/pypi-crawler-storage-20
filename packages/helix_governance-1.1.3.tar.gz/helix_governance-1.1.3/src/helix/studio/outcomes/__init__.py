from __future__ import annotations

from importlib import import_module
from typing import Any

_EXPORTS: dict[str, str] = {
    # model.py
    "OutcomeModel": "helix.studio.outcomes.model",
    "OutcomeModelRegistry": "helix.studio.outcomes.model",
    "OutcomeReportV1": "helix.studio.outcomes.model",
    "compute_inputs_sha256": "helix.studio.outcomes.model",
    "compute_outcomes_for_current_plan": "helix.studio.outcomes.model",
    "get_default_registry": "helix.studio.outcomes.model",
    "outcome_report_json_bytes": "helix.studio.outcomes.model",
    "outcome_report_to_dict": "helix.studio.outcomes.model",
    # lightweight helpers
    "allele_key_from_entry": "helix.studio.outcomes.hotspots",
    "build_hotspot_segments": "helix.studio.outcomes.hotspots",
    # outcome models (may transitively import optional deps; keep lazy)
    "NoopOutcomeModel": "helix.studio.outcomes.noop",
    "CutOutcomeModel": "helix.studio.outcomes.cut_model",
    "DynamicCutOutcomeModel": "helix.studio.outcomes.dynamic_cut_model",
    "BaseEditOutcomeModel": "helix.studio.outcomes.base_edit_model",
    "PrimeOutcomeModel": "helix.studio.outcomes.prime_model",
    # overlays (may transitively import optional deps; keep lazy)
    "build_base_overlay": "helix.studio.outcomes.base_overlay",
    "build_prime_overlay": "helix.studio.outcomes.prime_overlay",
}

__all__ = sorted(_EXPORTS.keys())


def __getattr__(name: str) -> Any:
    if name not in _EXPORTS:
        raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
    module = import_module(_EXPORTS[name])
    value = getattr(module, name)
    globals()[name] = value
    return value

