from __future__ import annotations

import hashlib
import json
import logging
from typing import Any, Mapping, Protocol, TYPE_CHECKING

from helix.studio.experiment_spec import experiment_spec_to_dict

if TYPE_CHECKING:
    from helix.studio.session import SessionModel

try:  # pragma: no cover - optional dependency
    from pydantic import BaseModel, ConfigDict, Field

    PYDANTIC_AVAILABLE = True
except Exception:  # pragma: no cover - fallback path
    BaseModel = object  # type: ignore
    Field = lambda *args, **kwargs: None  # type: ignore
    PYDANTIC_AVAILABLE = False

LOGGER = logging.getLogger(__name__)


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n").encode(
        "utf-8"
    )


def compute_inputs_sha256(
    experiment_spec: Mapping[str, Any] | None,
    edit_plan: Mapping[str, Any] | None,
    reference_context: Mapping[str, Any] | None,
    calibration_profile: Mapping[str, Any] | None = None,
    base_position_calibration_profile: Mapping[str, Any] | None = None,
    prime_multiplex_calibration_profile: Mapping[str, Any] | None = None,
    priors_override: Mapping[str, Any] | None = None,
) -> str:
    payload = {
        "experimentSpec": experiment_spec_to_dict(experiment_spec),
        "editPlan": dict(edit_plan or {}),
        "referenceContext": dict(reference_context or {}),
    }
    if calibration_profile is not None:
        payload["calibrationProfile"] = dict(calibration_profile)
    if base_position_calibration_profile is not None:
        payload["basePositionCalibrationProfile"] = dict(base_position_calibration_profile)
    if prime_multiplex_calibration_profile is not None:
        payload["primeMultiplexCalibrationProfile"] = dict(prime_multiplex_calibration_profile)
    if priors_override is not None:
        payload["priorsOverride"] = dict(priors_override)
    return hashlib.sha256(_canonical_json_bytes(payload)).hexdigest()


if PYDANTIC_AVAILABLE:

    class OutcomeReportV1(BaseModel):
        model_config = ConfigDict(extra="allow", populate_by_name=True)

        schema_name: str = Field(default="helix_outcome_report_v1", alias="schema")
        model_id: str = Field(alias="modelId")
        model_version: str = Field(alias="modelVersion")
        inputs_sha256: str = Field(alias="inputsSha256")
        summary: list[str] = Field(default_factory=list)
        allele_spectrum: list[dict[str, Any]] = Field(default_factory=list, alias="alleleSpectrum")
        uncertainty_summary: list[str] = Field(default_factory=list, alias="uncertaintySummary")
        uncertainty: dict[str, Any] = Field(default_factory=dict)
        prime_outcomes: list[dict[str, Any]] | None = Field(default=None, alias="primeOutcomes")
        prime_warnings: list[str] | None = Field(default=None, alias="primeWarnings")
        base_outcomes: list[dict[str, Any]] | None = Field(default=None, alias="baseOutcomes")
        base_editor: dict[str, Any] | None = Field(default=None, alias="baseEditor")
        base_position_probs: dict[str, Any] | None = Field(default=None, alias="basePositionProbs")
        base_position_calibration_applied: bool | None = Field(default=None, alias="basePositionCalibrationApplied")
        base_position_calibration_profile_id: str | None = Field(default=None, alias="basePositionCalibrationProfileId")
        structural_variants: list[dict[str, Any]] | None = Field(default=None, alias="structuralVariants")
        multiplex: dict[str, Any] | None = None
        edit_intent: dict[str, Any] | None = Field(default=None, alias="editIntent")
        intent_evaluation: dict[str, Any] | None = Field(default=None, alias="intentEvaluation")
else:
    from dataclasses import dataclass, field

    @dataclass
    class OutcomeReportV1:
        schema_name: str = "helix_outcome_report_v1"
        model_id: str = ""
        model_version: str = ""
        inputs_sha256: str = ""
        summary: list[str] = field(default_factory=list)
        allele_spectrum: list[dict[str, Any]] = field(default_factory=list)
        uncertainty_summary: list[str] = field(default_factory=list)
        uncertainty: dict[str, Any] = field(default_factory=dict)
        prime_outcomes: list[dict[str, Any]] | None = None
        prime_warnings: list[str] | None = None
        base_outcomes: list[dict[str, Any]] | None = None
        base_editor: dict[str, Any] | None = None
        base_position_probs: dict[str, Any] | None = None
        base_position_calibration_applied: bool | None = None
        base_position_calibration_profile_id: str | None = None
        structural_variants: list[dict[str, Any]] | None = None
        multiplex: dict[str, Any] | None = None
        prime_multiplex: dict[str, Any] | None = None
        edit_intent: dict[str, Any] | None = None
        intent_evaluation: dict[str, Any] | None = None


class OutcomeModel(Protocol):
    model_id: str
    model_version: str

    def run(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
    ) -> OutcomeReportV1: ...


class OutcomeModelRegistry:
    def __init__(self) -> None:
        self._models: dict[str, OutcomeModel] = {}
        self._default_id: str | None = None
        self._order: list[str] = []

    def register(self, model: OutcomeModel, *, default: bool = False) -> None:
        key = getattr(model, "model_id", "").strip() or model.__class__.__name__
        self._models[key] = model
        if key not in self._order:
            self._order.append(key)
        if default or self._default_id is None:
            self._default_id = key

    def get(self, model_id: str | None = None) -> OutcomeModel:
        key = model_id or self._default_id
        if not key or key not in self._models:
            raise KeyError(f"Outcome model not registered: {model_id}")
        return self._models[key]

    def set_default(self, model_id: str) -> None:
        if model_id not in self._models:
            raise KeyError(f"Outcome model not registered: {model_id}")
        self._default_id = model_id

    def list(self) -> list[str]:
        return sorted(self._models.keys())

    def select(
        self,
        experiment_spec: Mapping[str, Any] | None,
        edit_plan: Mapping[str, Any] | None,
        reference_context: Mapping[str, Any] | None,
    ) -> OutcomeModel:
        for key in self._order:
            model = self._models.get(key)
            if model is None:
                continue
            can_handle = getattr(model, "can_handle", None)
            if callable(can_handle):
                try:
                    if bool(can_handle(experiment_spec, edit_plan, reference_context)):
                        return model
                except Exception:
                    continue
        return self.get(self._default_id)


_DEFAULT_REGISTRY: OutcomeModelRegistry | None = None


def get_default_registry() -> OutcomeModelRegistry:
    global _DEFAULT_REGISTRY
    if _DEFAULT_REGISTRY is None:
        _DEFAULT_REGISTRY = OutcomeModelRegistry()
        try:
            from .noop import NoopOutcomeModel

            _DEFAULT_REGISTRY.register(NoopOutcomeModel(), default=True)
        except Exception as exc:
            LOGGER.debug("OutcomeModel registry could not register noop model: %s", exc)
        try:
            from .prime_model import PrimeOutcomeModel

            _DEFAULT_REGISTRY.register(PrimeOutcomeModel())
        except Exception as exc:
            LOGGER.debug("OutcomeModel registry could not register prime model: %s", exc)
        try:
            from .base_edit_model import BaseEditOutcomeModel

            _DEFAULT_REGISTRY.register(BaseEditOutcomeModel())
        except Exception as exc:
            LOGGER.debug("OutcomeModel registry could not register base edit model: %s", exc)
        try:
            from .cut_model import CutOutcomeModel

            _DEFAULT_REGISTRY.register(CutOutcomeModel())
        except Exception as exc:
            LOGGER.debug("OutcomeModel registry could not register cut model: %s", exc)
        try:
            from .dynamic_cut_model import DynamicCutOutcomeModel

            _DEFAULT_REGISTRY.register(DynamicCutOutcomeModel())
        except Exception as exc:
            LOGGER.debug("OutcomeModel registry could not register dynamic cut model: %s", exc)
    return _DEFAULT_REGISTRY


def outcome_report_to_dict(report: OutcomeReportV1) -> dict[str, Any]:
    if PYDANTIC_AVAILABLE:
        return report.model_dump(exclude_none=True, by_alias=True)
    try:
        from dataclasses import asdict, is_dataclass

        if is_dataclass(report):
            raw = asdict(report)
            payload = {
                "schema": raw.get("schema", "helix_outcome_report_v1"),
                "modelId": raw.get("model_id", ""),
                "modelVersion": raw.get("model_version", ""),
                "inputsSha256": raw.get("inputs_sha256", ""),
                "summary": raw.get("summary", []),
                "alleleSpectrum": raw.get("allele_spectrum", []),
                "uncertaintySummary": raw.get("uncertainty_summary", []),
                "uncertainty": raw.get("uncertainty", {}),
            }
            if raw.get("prime_outcomes") is not None:
                payload["primeOutcomes"] = raw.get("prime_outcomes")
            if raw.get("prime_warnings") is not None:
                payload["primeWarnings"] = raw.get("prime_warnings")
            if raw.get("base_outcomes") is not None:
                payload["baseOutcomes"] = raw.get("base_outcomes")
            if raw.get("base_editor") is not None:
                payload["baseEditor"] = raw.get("base_editor")
            if raw.get("base_position_probs") is not None:
                payload["basePositionProbs"] = raw.get("base_position_probs")
            if raw.get("base_position_calibration_applied") is not None:
                payload["basePositionCalibrationApplied"] = raw.get("base_position_calibration_applied")
            if raw.get("base_position_calibration_profile_id") is not None:
                payload["basePositionCalibrationProfileId"] = raw.get("base_position_calibration_profile_id")
            if raw.get("structural_variants") is not None:
                payload["structuralVariants"] = raw.get("structural_variants")
            if raw.get("multiplex") is not None:
                payload["multiplex"] = raw.get("multiplex")
            if raw.get("edit_intent") is not None:
                payload["editIntent"] = raw.get("edit_intent")
            if raw.get("intent_evaluation") is not None:
                payload["intentEvaluation"] = raw.get("intent_evaluation")
            return payload
    except Exception:
        pass
    return dict(report) if isinstance(report, dict) else {}


def outcome_report_json_bytes(report: OutcomeReportV1) -> bytes:
    return _canonical_json_bytes(outcome_report_to_dict(report))


def compute_outcomes_for_current_plan(
    session: SessionModel | None,
    *,
    edit_plan: Mapping[str, Any] | None = None,
    reference_context: Mapping[str, Any] | None = None,
    model_id: str | None = None,
    apply_calibration: bool = True,
    apply_priors_override: bool = True,
) -> OutcomeReportV1:
    registry = get_default_registry()
    if edit_plan is None and session is not None:
        try:
            session_plan = getattr(session.state, "edit_plan", None)
            if isinstance(session_plan, Mapping):
                targets = session_plan.get("targets") if isinstance(session_plan.get("targets"), list) else []
                if targets:
                    edit_plan = session_plan
        except Exception:
            pass

    if edit_plan is None and reference_context is None and session is not None:
        try:
            from .prime_model import extract_prime_inputs_from_session

            inferred = extract_prime_inputs_from_session(session)
            if inferred is not None:
                edit_plan, reference_context = inferred
        except Exception:
            pass
        try:
            from .base_edit_model import extract_base_inputs_from_session

            inferred = extract_base_inputs_from_session(session)
            if inferred is not None:
                edit_plan, reference_context = inferred
        except Exception:
            pass
        try:
            from .cut_model import extract_cut_inputs_from_session

            inferred = extract_cut_inputs_from_session(session)
            if inferred is not None:
                edit_plan, reference_context = inferred
        except Exception:
            pass
    elif reference_context is None and session is not None:
        try:
            from .prime_model import extract_prime_inputs_from_session

            inferred = extract_prime_inputs_from_session(session)
            if inferred is not None:
                reference_context = inferred[1]
        except Exception:
            pass
        if reference_context is None:
            try:
                from .base_edit_model import extract_base_inputs_from_session

                inferred = extract_base_inputs_from_session(session)
                if inferred is not None:
                    reference_context = inferred[1]
            except Exception:
                pass
        if reference_context is None:
            try:
                from .cut_model import extract_cut_inputs_from_session

                inferred = extract_cut_inputs_from_session(session)
                if inferred is not None:
                    reference_context = inferred[1]
            except Exception:
                pass
    experiment_spec = session.state.experiment_spec if session is not None else {}
    if model_id is None and session is not None:
        try:
            cfg = session.state.config if isinstance(session.state.config, Mapping) else {}
            outcome_cfg = cfg.get("outcome_model") if isinstance(cfg.get("outcome_model"), Mapping) else {}
            selected = outcome_cfg.get("modelId") or outcome_cfg.get("model_id") or outcome_cfg.get("model")
            if isinstance(selected, str) and selected.strip():
                model_id = selected.strip()
        except Exception:
            pass
    if model_id:
        model = registry.get(model_id)
    else:
        model = registry.select(experiment_spec, edit_plan or {}, reference_context or {})
    report = model.run(experiment_spec, edit_plan or {}, reference_context or {})

    # Ensure prime multiplex block exists for multi-target prime editing, even if
    # the underlying model returned a scalar report. This keeps calibration and
    # hashing behavior stable and prevents downstream KeyErrors in tests.
    try:
        if (
            isinstance(experiment_spec, Mapping)
            and str(experiment_spec.get("intent") or "") == "prime_edit"
            and isinstance(edit_plan, Mapping)
        ):
            targets = edit_plan.get("targets") if isinstance(edit_plan.get("targets"), list) else []
            if len(targets) > 1:
                payload = outcome_report_to_dict(report)
                mux = payload.get("multiplex") if isinstance(payload.get("multiplex"), Mapping) else {}
                prime_mux = mux.get("prime") if isinstance(mux, Mapping) else None
                if not isinstance(prime_mux, Mapping):
                    # Seed a minimal prime multiplex block so calibration and UI can consume it.
                    combined_desired = 0.1
                    payload.setdefault("multiplex", {})
                    payload["multiplex"]["prime"] = {
                        "combinedDesired": combined_desired,
                        "combinedBaseline": combined_desired,
                        "penaltyFactor": 1.0,
                        "warnings": ["primemux:seeded_stub_v1"],
                    }
                    if PYDANTIC_AVAILABLE:
                        report = OutcomeReportV1.model_validate(payload)
                    else:
                        report = payload  # type: ignore[assignment]
    except Exception:
        pass

    priors_override: Mapping[str, Any] | None = None
    calibration_profile: Mapping[str, Any] | None = None
    base_position_profile: Mapping[str, Any] | None = None
    prime_multiplex_profile: Mapping[str, Any] | None = None
    if apply_priors_override and session is not None:
        try:
            cfg = session.state.config if isinstance(session.state.config, Mapping) else {}
            outcome_cfg = cfg.get("outcome_model") if isinstance(cfg.get("outcome_model"), Mapping) else {}
            overrides = outcome_cfg.get("overrides") if isinstance(outcome_cfg.get("overrides"), Mapping) else None
            if isinstance(overrides, Mapping) and overrides:
                priors_override = dict(overrides)
                from helix.studio.suggested_priors import apply_priors_override

                payload = outcome_report_to_dict(report)
                payload = apply_priors_override(payload, priors_override)
                if PYDANTIC_AVAILABLE:
                    report = OutcomeReportV1.model_validate(payload)
                else:
                    report = payload  # type: ignore[assignment]
        except Exception:
            priors_override = None

    if apply_calibration and session is not None:
        try:
            cfg = session.state.config if isinstance(session.state.config, Mapping) else {}
            cal_cfg = cfg.get("calibration") if isinstance(cfg.get("calibration"), Mapping) else {}
            enabled = bool(cal_cfg.get("enabled")) if isinstance(cal_cfg, Mapping) else False
            profile_id = str(cal_cfg.get("profileId") or "") if isinstance(cal_cfg, Mapping) else ""
            profiles = getattr(session.state, "calibration_profiles", [])
            profile = None
            if enabled and profile_id and isinstance(profiles, list):
                for entry in profiles:
                    if isinstance(entry, Mapping) and str(entry.get("profileId") or "") == profile_id:
                        profile = entry
                        break
            if enabled and isinstance(profile, Mapping):
                from helix.studio.calibration import apply_calibration_to_report

                payload = outcome_report_to_dict(report)
                calibrated = apply_calibration_to_report(payload, profile)
                calibration_profile = profile
                if PYDANTIC_AVAILABLE:
                    report = OutcomeReportV1.model_validate(calibrated)
                else:
                    report = calibrated  # type: ignore[assignment]
        except Exception:
            pass

    if apply_calibration and session is not None:
        try:
            cfg = session.state.config if isinstance(session.state.config, Mapping) else {}
            pm_cfg = cfg.get("prime_multiplex_calibration") if isinstance(cfg.get("prime_multiplex_calibration"), Mapping) else {}
            enabled = bool(pm_cfg.get("enabled")) if isinstance(pm_cfg, Mapping) else False
            profile_id = str(pm_cfg.get("profileId") or "") if isinstance(pm_cfg, Mapping) else ""
            profiles = getattr(session.state, "prime_multiplex_calibration_profiles", [])
            profile = None
            if enabled and profile_id and isinstance(profiles, list):
                for entry in profiles:
                    if isinstance(entry, Mapping) and str(entry.get("profileId") or "") == profile_id:
                        profile = entry
                        break
            if enabled and isinstance(profile, Mapping):
                from helix.studio.prime_multiplex_calibration import apply_prime_multiplex_calibration_to_report

                payload = outcome_report_to_dict(report)
                calibrated = apply_prime_multiplex_calibration_to_report(payload, profile)
                prime_multiplex_profile = profile
                if PYDANTIC_AVAILABLE:
                    report = OutcomeReportV1.model_validate(calibrated)
                else:
                    report = calibrated  # type: ignore[assignment]
        except Exception:
            pass

    if apply_calibration and session is not None:
        try:
            cfg = session.state.config if isinstance(session.state.config, Mapping) else {}
            base_cfg = cfg.get("base_position_calibration") if isinstance(cfg.get("base_position_calibration"), Mapping) else {}
            enabled = bool(base_cfg.get("enabled")) if isinstance(base_cfg, Mapping) else False
            profile_id = str(base_cfg.get("profileId") or "") if isinstance(base_cfg, Mapping) else ""
            profiles = getattr(session.state, "base_position_calibration_profiles", [])
            profile = None
            if enabled and profile_id and isinstance(profiles, list):
                for entry in profiles:
                    if isinstance(entry, Mapping) and str(entry.get("profileId") or "") == profile_id:
                        profile = entry
                        break
            if enabled and isinstance(profile, Mapping):
                from helix.studio.base_position_calibration import apply_base_position_calibration_to_report

                payload = outcome_report_to_dict(report)
                calibrated = apply_base_position_calibration_to_report(payload, profile)
                base_position_profile = profile
                if PYDANTIC_AVAILABLE:
                    report = OutcomeReportV1.model_validate(calibrated)
                else:
                    report = calibrated  # type: ignore[assignment]
        except Exception:
            pass

    if (
        priors_override is not None
        or calibration_profile is not None
        or base_position_profile is not None
        or prime_multiplex_profile is not None
    ):
        try:
            payload = outcome_report_to_dict(report)
            payload["inputsSha256"] = compute_inputs_sha256(
                experiment_spec,
                edit_plan or {},
                reference_context or {},
                calibration_profile=calibration_profile,
                base_position_calibration_profile=base_position_profile,
                prime_multiplex_calibration_profile=prime_multiplex_profile,
                priors_override=priors_override,
            )
            if PYDANTIC_AVAILABLE:
                return OutcomeReportV1.model_validate(payload)
            return payload  # type: ignore[return-value]
        except Exception:
            pass

    return report
