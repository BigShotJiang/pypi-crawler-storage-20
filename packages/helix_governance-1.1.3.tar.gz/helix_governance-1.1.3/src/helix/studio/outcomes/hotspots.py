from __future__ import annotations

import json
from typing import Any, Mapping


def allele_key_from_entry(entry: Mapping[str, Any], *, freq_precision: int = 8) -> str:
    delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
    kind = str(delta.get("type") or "")
    payload: dict[str, Any] = {"kind": kind}
    if kind == "del":
        payload.update(
            {
                "start": delta.get("start"),
                "end": delta.get("end"),
                "length": delta.get("length"),
                "microhomology": delta.get("microhomology"),
            }
        )
    elif kind == "ins":
        payload.update(
            {
                "start": delta.get("start"),
                "length": delta.get("length"),
                "sequence": delta.get("sequence"),
            }
        )
    else:
        payload.update(
            {
                "start": delta.get("start"),
                "end": delta.get("end"),
                "length": delta.get("length"),
                "sequence": delta.get("sequence"),
                "label": delta.get("label"),
            }
        )
    try:
        freq = float(entry.get("frequency") or 0.0)
    except Exception:
        freq = 0.0
    payload["frequency"] = round(freq, int(freq_precision))
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def _hotness_map(
    allele_spectrum: list[Any],
    *,
    sequence_len: int,
    mode: str,
    selected_allele_key: str | None,
    scale: int,
) -> tuple[dict[int, int], bool]:
    hotness: dict[int, int] = {}
    found_selected = False
    selected = str(selected_allele_key or "")

    def span_from_delta(delta: Mapping[str, Any]) -> tuple[int, int] | None:
        if delta.get("start") is None:
            return None
        try:
            start = int(delta.get("start", 0))
        except Exception:
            return None
        end_val = delta.get("end")
        length_val = delta.get("length")
        end = None
        if end_val is not None:
            try:
                end = int(end_val)
            except Exception:
                end = None
        if end is None and length_val is not None:
            try:
                length = int(length_val)
                end = start + max(1, length)
            except Exception:
                end = None
        if end is None:
            end = start + 1
        if end <= start:
            end = start + 1
        return start, end

    for entry in allele_spectrum:
        if not isinstance(entry, Mapping):
            continue
        delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
        kind = str(delta.get("type") or "").lower().strip()
        if kind == "other":
            continue
        if mode == "allele":
            if not selected or allele_key_from_entry(entry) != selected:
                continue
            found_selected = True
        freq = entry.get("frequency") or 0.0
        try:
            freq_int = int(round(float(freq) * scale))
        except Exception:
            continue
        if freq_int <= 0:
            continue

        if kind == "del":
            try:
                start = int(delta.get("start", 0))
                end = int(delta.get("end", start))
            except Exception:
                continue
            if end <= start:
                continue
            for pos in range(start, end):
                if 0 <= pos < sequence_len:
                    hotness[pos] = hotness.get(pos, 0) + freq_int
        elif kind == "ins":
            try:
                pos = int(delta.get("start", 0))
            except Exception:
                continue
            if 0 <= pos < sequence_len:
                hotness[pos] = hotness.get(pos, 0) + freq_int
        else:
            span = span_from_delta(delta)
            if span is None:
                continue
            start, end = span
            for pos in range(start, end):
                if 0 <= pos < sequence_len:
                    hotness[pos] = hotness.get(pos, 0) + freq_int

    return hotness, found_selected


def _segments_from_hotness(hotness: dict[int, int], *, levels: int) -> list[dict[str, Any]]:
    if not hotness:
        return []
    max_hot = max(hotness.values())
    if max_hot <= 0:
        return []
    positions = sorted(hotness.keys())
    segments: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None

    for pos in positions:
        level = (hotness[pos] * levels + max_hot - 1) // max_hot
        level = max(1, min(levels, int(level)))
        if current and current["level"] == level and pos == current["end"]:
            current["end"] = pos + 1
            continue
        if current:
            segments.append(current)
        current = {"start": pos, "end": pos + 1, "level": level}

    if current:
        segments.append(current)
    return segments


def _segments_from_positions(positions: list[int], *, level: int) -> list[dict[str, Any]]:
    if not positions:
        return []
    segments: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    for pos in sorted(positions):
        if current and pos == current["end"]:
            current["end"] = pos + 1
            continue
        if current:
            segments.append(current)
        current = {"start": pos, "end": pos + 1, "level": level}
    if current:
        segments.append(current)
    return segments


def build_hotspot_segments(
    report_bytes: bytes,
    *,
    sequence_len: int,
    levels: int = 5,
    mode: str = "aggregate",
    selected_allele_key: str | None = None,
    show_context: bool = True,
    multiplex_target_id: str | None = None,
) -> dict[str, Any]:
    try:
        payload = json.loads(report_bytes.decode("utf-8"))
    except Exception:
        return {}

    allele_spectrum = payload.get("alleleSpectrum")
    multiplex_override = str(multiplex_target_id or "")
    if multiplex_override:
        multiplex = payload.get("multiplex") if isinstance(payload.get("multiplex"), Mapping) else None
        if isinstance(multiplex, Mapping):
            targets = multiplex.get("targets") if isinstance(multiplex.get("targets"), list) else []
            if multiplex_override == "__combined__":
                return {}
            for idx, target in enumerate(targets):
                if not isinstance(target, Mapping):
                    continue
                target_id = str(target.get("targetId") or "").strip() or f"target_{idx + 1}"
                if target_id == multiplex_override:
                    allele_spectrum = target.get("alleleSpectrum")
                    break
    if not isinstance(allele_spectrum, list) or sequence_len <= 0:
        return {}

    scale = 10**8
    mode = str(mode or "aggregate").lower()
    levels = max(1, int(levels))

    hotness, found_selected = _hotness_map(
        allele_spectrum,
        sequence_len=sequence_len,
        mode=mode,
        selected_allele_key=selected_allele_key,
        scale=scale,
    )

    if mode == "allele" and not found_selected:
        return build_hotspot_segments(
            report_bytes,
            sequence_len=sequence_len,
            levels=levels,
            mode="aggregate",
            selected_allele_key=None,
            show_context=show_context,
            multiplex_target_id=multiplex_target_id,
        )

    if not hotness:
        return {}

    if mode == "aggregate":
        segments = _segments_from_hotness(hotness, levels=levels)
        return {"levels": levels, "segments": segments}

    selected_positions = sorted(hotness.keys())
    selected_segments = _segments_from_positions(selected_positions, level=levels)
    context_segments: list[dict[str, Any]] = []
    if show_context:
        context_payload = build_hotspot_segments(
            report_bytes,
            sequence_len=sequence_len,
            levels=levels,
            mode="aggregate",
            selected_allele_key=None,
            show_context=False,
            multiplex_target_id=multiplex_target_id,
        )
        context_segments = list(context_payload.get("segments") or [])

    combined = list(context_segments) + list(selected_segments)
    return {
        "levels": levels,
        "segments": combined,
        "context_segments": context_segments,
        "selected_segments": selected_segments,
    }


__all__ = ["build_hotspot_segments", "allele_key_from_entry"]
