from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Mapping

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QTableWidget,
    QTableWidgetItem,
    QToolButton,
    QVBoxLayout,
    QWidget,
    QHeaderView,
)

from helix.studio.outcomes.hotspots import allele_key_from_entry
from helix.studio.outcomes.clone_yield import build_clone_plan
from helix.studio.offtargets.model import compute_offtargets_for_session, offtarget_report_json_bytes
from helix.studio.offtargets.validation_plan import build_validation_plan, validation_plan_sha256
from helix.studio.assays.primer_design import build_primer_plan
from helix.studio.assays.assay_chooser import build_assay_plan
from helix.studio.experiment_spec import experiment_spec_to_dict
from helix.studio.outcomes.model import compute_outcomes_for_current_plan, outcome_report_to_dict
from helix.studio.base_position_calibration import (
    attach_base_position_calibration_profile,
    build_base_position_calibration_eval,
    build_base_position_calibration_profile_and_preview,
    check_base_position_calibration_compatibility,
)
from helix.studio.suggested_priors import (
    attach_suggested_priors,
    build_suggested_priors,
    check_suggested_priors_compatibility,
)
from helix.studio.session import SessionModel
from helix.studio.ui_tokens import MARGIN_PANEL, SPACING_MEDIUM, SPACING_SMALL, base_font

from .cell_context import parse_cell_context


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _round(value: float, digits: int = 6) -> float:
    return round(float(value), digits)


def _delta_to_display(delta: Mapping[str, Any]) -> tuple[str, str, str, bool]:
    kind_raw = str(delta.get("type") or "").lower().strip()
    kind = kind_raw if kind_raw else "unknown"
    if kind == "other":
        return "Other", "", "OTHER", True
    label_map = {
        "prime_desired": "DESIRED",
        "prime_partial": "PARTIAL",
        "prime_truncation": "TRUNC",
        "prime_nick_indel": "NICK",
        "prime_failure": "FAILURE",
        "base_desired": "DESIRED",
        "base_bystander": "BYSTANDER",
        "base_offtarget": "OFFTARGET",
        "base_failure": "FAILURE",
    }
    label = "DEL" if kind == "del" else "INS" if kind == "ins" else label_map.get(kind, kind.upper())

    length = delta.get("length")
    seq = str(delta.get("sequence") or "")
    if length is None and (kind == "ins" or seq):
        length = len(seq) if seq else 0
    try:
        length_int = int(length) if length is not None else 0
    except Exception:
        length_int = 0
    size = str(length_int) if length_int > 0 else "—"

    start = delta.get("start")
    end = delta.get("end")
    seq = str(delta.get("sequence") or "")
    seq_short = seq.upper()
    if seq_short and len(seq_short) > 12:
        seq_short = f"{seq_short[:12]}..."

    if kind == "base_substitution":
        role = str(delta.get("role") or delta.get("label") or "").lower()
        if "desired" in role:
            label = "DESIRED"
        elif "bystander" in role:
            label = "BYSTANDER"
        else:
            label = label_map.get(kind, kind.upper())
        ref_base = str(delta.get("refBase") or "").upper()
        alt_base = str(delta.get("altBase") or "").upper()
        pos_val = delta.get("pos")
        pos_str = ""
        if pos_val is not None:
            try:
                pos_int = int(pos_val)
                pos_str = str(pos_int)
            except Exception:
                pos_str = ""
        if ref_base and alt_base:
            if pos_str:
                delta_str = f"{ref_base}{pos_str}->{alt_base}"
            else:
                delta_str = f"{ref_base}->{alt_base}"
        else:
            delta_str = label
    elif kind == "del":
        if start is not None and end is not None:
            delta_str = f"del {length_int} @ {int(start)}-{int(end)}"
        else:
            delta_str = f"del {length_int}"
    elif kind == "ins":
        seq_short = seq.upper()
        if seq_short and len(seq_short) <= 8:
            delta_str = f"ins {length_int} +{seq_short}"
        elif start is not None:
            delta_str = f"ins {length_int} @ {int(start)}"
        else:
            delta_str = f"ins {length_int}"
    else:
        if seq_short:
            if start is not None and end is not None:
                delta_str = f"{seq_short} @ {int(start)}-{int(end)}"
            else:
                delta_str = seq_short
        else:
            if start is not None and end is not None:
                delta_str = f"{label} @ {int(start)}-{int(end)}"
            else:
                delta_str = label

    return label, size, delta_str, False


_COMBINED_TOKEN = "__combined__"


def _multiplex_target_id(entry: Mapping[str, Any], idx: int) -> str:
    value = entry.get("targetId")
    if isinstance(value, str) and value.strip():
        return value.strip()
    return f"target_{idx + 1}"


def _extract_multiplex(payload: Mapping[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any], list[str]]:
    multiplex = payload.get("multiplex") if isinstance(payload.get("multiplex"), Mapping) else {}
    targets = multiplex.get("targets") if isinstance(multiplex.get("targets"), list) else []
    combined = multiplex.get("combined") if isinstance(multiplex.get("combined"), Mapping) else {}
    warnings = multiplex.get("warnings") if isinstance(multiplex.get("warnings"), list) else []
    clean_targets = [dict(t) for t in targets if isinstance(t, Mapping)]
    clean_warnings = [str(w) for w in warnings]
    return clean_targets, dict(combined), clean_warnings


def _default_target_id(target_entries: list[tuple[str, Mapping[str, Any]]]) -> str:
    for tid, entry in target_entries:
        role = entry.get("role")
        if str(tid).lower() == "primary" or str(role or "").lower() == "primary":
            return tid
    return target_entries[0][0] if target_entries else ""


def _estimate_clones(desired_freq: float, confidence: float) -> int | None:
    desired_freq = max(0.0, min(1.0, float(desired_freq)))
    confidence = max(0.0, min(0.99, float(confidence)))
    if desired_freq >= 1.0:
        return 1
    if desired_freq <= 0.0:
        return None
    denom = math.log(max(1e-12, 1.0 - desired_freq))
    if denom >= 0.0:
        return None
    return max(1, int(math.ceil(math.log(1.0 - confidence) / denom)))


class OutcomeSpectrumPanel(QWidget):
    def __init__(self, session: SessionModel | None, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._session = session
        self._max_rows = 12
        self._histogram_data: dict[str, Any] = {"buckets": [], "other": 0.0}
        self._syncing = False
        self._row_keys: list[str | None] = []
        self._selected_key: str | None = None
        self._mode_override: str | None = None
        self._current_mode: str = "cut"
        self._last_payload: dict[str, Any] = {}
        self._suggested_payload: dict[str, Any] | None = None
        self._compat_status: str = "unknown"
        self._compat_reasons: list[str] = []
        self._base_calibration_status: str = "unknown"
        self._base_calibration_reasons: list[str] = []
        self._base_calibration_profiles: list[dict[str, Any]] = []
        self._base_calibration_previews: list[dict[str, Any]] = []
        self._selected_base_calibration_id: str | None = None
        self._base_calibration_preview: dict[str, Any] | None = None
        self._suggested_history: list[dict[str, Any]] = []
        self._selected_suggested_id: str | None = None
        self._target_override: str | None = None
        self._multiplex_targets: list[dict[str, Any]] = []
        self._multiplex_combined: dict[str, Any] = {}
        self._multiplex_warnings: list[str] = []
        self._combined_selected: bool = False
        self._last_multiplex_override: str | None = None
        self._prime_multiplex_label = QLabel("Prime multiplex: —", self)
        self._prime_multiplex_label.setWordWrap(True)
        try:
            self._prime_multiplex_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        except Exception:
            pass
        self._prime_multiplex_label.setStyleSheet("color: #94a3b8;")
        self._prime_multiplex_label = QLabel("Prime multiplex: —", self)
        self._prime_multiplex_label.setWordWrap(True)
        try:
            self._prime_multiplex_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        except Exception:
            pass
        self._prime_multiplex_label.setStyleSheet("color: #94a3b8;")

        self.setFont(base_font())
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(SPACING_MEDIUM)

        header = QHBoxLayout()
        header.setSpacing(SPACING_SMALL)
        self._toggle = QToolButton(self)
        self._toggle.setCheckable(True)
        self._toggle.setChecked(True)
        self._toggle.setArrowType(Qt.DownArrow)
        self._toggle.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self._toggle.setText("Outcome spectrum")
        header.addWidget(self._toggle)
        self._mode_selector = QComboBox(self)
        self._mode_selector.addItem("Cut outcomes", "cut")
        self._mode_selector.addItem("Prime outcomes", "prime")
        self._mode_selector.addItem("Base outcomes", "base")
        header.addWidget(self._mode_selector)
        self._target_label = QLabel("Target", self)
        self._target_label.setStyleSheet("color: #94a3b8;")
        self._target_label.hide()
        header.addWidget(self._target_label)
        self._target_selector = QComboBox(self)
        self._target_selector.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        self._target_selector.hide()
        header.addWidget(self._target_selector)
        header.addStretch(1)

        root.addLayout(header)

        self._body = QFrame(self)
        body_layout = QVBoxLayout(self._body)
        body_layout.setContentsMargins(MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL, MARGIN_PANEL)
        body_layout.setSpacing(SPACING_MEDIUM)

        info_row = QHBoxLayout()
        info_row.setSpacing(SPACING_SMALL)
        self._model_label = QLabel("Model: —", self)
        self._inputs_label = QLabel("Inputs: —", self)
        info_row.addWidget(self._model_label)
        self._calibration_badge = QLabel("Calibrated", self)
        self._calibration_badge.setStyleSheet(
            "padding:2px 6px; border-radius:6px; background: rgba(34,197,94,0.2); color:#86efac;"
        )
        self._calibration_badge.hide()
        info_row.addWidget(self._calibration_badge)
        self._base_calibration_badge = QLabel("Calibrated (Base positions)", self)
        self._base_calibration_badge.setStyleSheet(
            "padding:2px 6px; border-radius:6px; background: rgba(56,189,248,0.2); color:#7dd3fc;"
        )
        self._base_calibration_badge.hide()
        info_row.addWidget(self._base_calibration_badge)
        info_row.addStretch(1)
        info_row.addWidget(self._inputs_label)
        body_layout.addLayout(info_row)

        self._cell_context_label = QLabel("CellLine: — • Delivery: — • RepairBias: —", self)
        self._cell_context_label.setWordWrap(True)
        self._cell_context_label.setStyleSheet("color: #94a3b8;")
        body_layout.addWidget(self._cell_context_label)

        self._cut_engine_row = QFrame(self)
        cut_engine_layout = QHBoxLayout(self._cut_engine_row)
        cut_engine_layout.setContentsMargins(0, 0, 0, 0)
        cut_engine_layout.setSpacing(SPACING_SMALL)
        self._cut_engine_label = QLabel("Cut engine", self)
        self._cut_engine_label.setStyleSheet("color: #94a3b8;")
        cut_engine_layout.addWidget(self._cut_engine_label)
        self._cut_engine_selector = QComboBox(self)
        self._cut_engine_selector.addItem("Auto", userData="")
        self._cut_engine_selector.addItem("Baseline (static)", userData="cut_model")
        self._cut_engine_selector.addItem("Dynamic (resource-aware)", userData="dynamic_cut_model")
        self._cut_engine_selector.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        cut_engine_layout.addWidget(self._cut_engine_selector)
        cut_engine_layout.addStretch(1)
        self._cut_engine_row.setVisible(True)
        body_layout.addWidget(self._cut_engine_row)

        self._base_calibration_eval_label = QLabel("", self)
        self._base_calibration_eval_label.setWordWrap(True)
        self._base_calibration_eval_label.setStyleSheet("color: #94a3b8;")
        self._base_calibration_eval_label.hide()
        body_layout.addWidget(self._base_calibration_eval_label)

        calibration_row = QHBoxLayout()
        calibration_row.setSpacing(SPACING_SMALL)
        self._calibration_toggle = QCheckBox("Apply calibration", self)
        calibration_row.addWidget(self._calibration_toggle)
        self._calibration_selector = QComboBox(self)
        self._calibration_selector.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        calibration_row.addWidget(self._calibration_selector)
        calibration_row.addStretch(1)
        body_layout.addLayout(calibration_row)

        suggested_row = QHBoxLayout()
        suggested_row.setSpacing(SPACING_SMALL)
        self._suggested_button = QToolButton(self)
        self._suggested_button.setText("Generate suggested priors")
        suggested_row.addWidget(self._suggested_button)
        self._suggested_selector = QComboBox(self)
        self._suggested_selector.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        suggested_row.addWidget(self._suggested_selector)
        self._apply_suggested_button = QToolButton(self)
        self._apply_suggested_button.setText("Apply suggested priors")
        suggested_row.addWidget(self._apply_suggested_button)
        suggested_row.addStretch(1)
        body_layout.addLayout(suggested_row)

        self._compat_label = QLabel("Compatibility: —", self)
        self._compat_label.setWordWrap(True)
        self._compat_label.setStyleSheet("color: #94a3b8;")
        body_layout.addWidget(self._compat_label)
        self._compat_confirm = QCheckBox("I understand compatibility is unknown", self)
        self._compat_confirm.hide()
        body_layout.addWidget(self._compat_confirm)

        self._suggested_label = QLabel("Suggested priors: —", self)
        self._suggested_label.setWordWrap(True)
        self._suggested_label.setStyleSheet("color: #94a3b8;")
        body_layout.addWidget(self._suggested_label)

        self._summary_label = QLabel("Awaiting outcome report.", self)
        self._summary_label.setWordWrap(True)
        body_layout.addWidget(self._summary_label)

        self._screening_container = QFrame(self)
        screening_layout = QVBoxLayout(self._screening_container)
        screening_layout.setContentsMargins(0, 0, 0, 0)
        screening_layout.setSpacing(SPACING_SMALL)
        self._screening_title = QLabel("Screening estimate", self)
        self._screening_title.setStyleSheet("font-weight: 600;")
        screening_layout.addWidget(self._screening_title)
        self._screening_value = QLabel("Desired frequency: — • Clones needed for 95%: —", self)
        self._screening_value.setStyleSheet("color: #94a3b8;")
        screening_layout.addWidget(self._screening_value)
        self._assay_label = QLabel("Recommended assay: —", self)
        self._assay_label.setStyleSheet("color: #e2e8f0;")
        screening_layout.addWidget(self._assay_label)
        self._assay_rationale = QLabel("", self)
        self._assay_rationale.setWordWrap(True)
        self._assay_rationale.setStyleSheet("color: #94a3b8;")
        screening_layout.addWidget(self._assay_rationale)
        self._primary_primer_label = QLabel("Primary primers: —", self)
        self._primary_primer_label.setStyleSheet("color: #94a3b8;")
        screening_layout.addWidget(self._primary_primer_label)
        self._prime_multiplex_label.setStyleSheet("color: #94a3b8;")
        screening_layout.addWidget(self._prime_multiplex_label)
        body_layout.addWidget(self._screening_container)

        self._cut_container = QFrame(self)
        cut_layout = QVBoxLayout(self._cut_container)
        cut_layout.setContentsMargins(0, 0, 0, 0)
        cut_layout.setSpacing(SPACING_MEDIUM)

        self._coverage_container = QFrame(self)
        coverage_row = QHBoxLayout(self._coverage_container)
        coverage_row.setContentsMargins(0, 0, 0, 0)
        coverage_row.setSpacing(SPACING_SMALL)
        self._coverage_label = QLabel("Top 0 alleles shown, OTHER is 0.00%", self)
        self._coverage_label.setStyleSheet("color: #94a3b8;")
        coverage_row.addWidget(self._coverage_label)
        coverage_row.addStretch(1)
        self._hotspot_toggle = QCheckBox("Show hotspots on locus", self)
        self._hotspot_toggle.setChecked(True)
        coverage_row.addWidget(self._hotspot_toggle)
        self._context_toggle = QCheckBox("Show context", self)
        self._context_toggle.setChecked(True)
        coverage_row.addWidget(self._context_toggle)
        cut_layout.addWidget(self._coverage_container)

        self._selection_label = QLabel("", self)
        self._selection_label.setStyleSheet("color: #94a3b8;")
        self._selection_label.hide()
        cut_layout.addWidget(self._selection_label)

        self._multiplex_container = QFrame(self)
        multiplex_layout = QVBoxLayout(self._multiplex_container)
        multiplex_layout.setContentsMargins(0, 0, 0, 0)
        multiplex_layout.setSpacing(SPACING_SMALL)
        self._multiplex_summary = QLabel("", self)
        self._multiplex_summary.setWordWrap(True)
        self._multiplex_summary.setStyleSheet("color: #e2e8f0;")
        multiplex_layout.addWidget(self._multiplex_summary)
        self._multiplex_warning_label = QLabel("", self)
        self._multiplex_warning_label.setWordWrap(True)
        self._multiplex_warning_label.setStyleSheet("color: #94a3b8;")
        multiplex_layout.addWidget(self._multiplex_warning_label)
        self._multiplex_container.hide()
        cut_layout.addWidget(self._multiplex_container)

        self._legend_container = QFrame(self)
        legend_layout = QVBoxLayout(self._legend_container)
        legend_layout.setContentsMargins(0, 0, 0, 0)
        legend_layout.setSpacing(SPACING_SMALL)

        self._legend_level_labels: list[QLabel] = []
        level_row = QHBoxLayout()
        level_row.setSpacing(SPACING_SMALL)
        level_row.addWidget(QLabel("Aggregate intensity:", self))
        for idx, alpha in enumerate([20, 35, 50, 70, 90], start=1):
            level_row.addWidget(_legend_swatch("#f97316", alpha))
            label = QLabel(f"Level {idx}", self)
            self._legend_level_labels.append(label)
            level_row.addWidget(label)
            if idx < 5:
                level_row.addSpacing(SPACING_SMALL)
        level_row.addStretch(1)
        legend_layout.addLayout(level_row)

        selected_row = QHBoxLayout()
        selected_row.setSpacing(SPACING_SMALL)
        selected_row.addWidget(QLabel("Selected allele:", self))
        selected_row.addWidget(_legend_swatch("#f97316", 220))
        self._legend_selected_label = QLabel("Selected", self)
        selected_row.addWidget(self._legend_selected_label)
        selected_row.addStretch(1)
        legend_layout.addLayout(selected_row)

        cut_layout.addWidget(self._legend_container)

        self._histogram = OutcomeSpectrumHistogram(self)
        self._histogram.setMinimumHeight(120)
        cut_layout.addWidget(self._histogram)

        self._histogram_legend = QFrame(self)
        histo_legend = QHBoxLayout(self._histogram_legend)
        histo_legend.setContentsMargins(0, 0, 0, 0)
        histo_legend.setSpacing(SPACING_SMALL)
        histo_legend.addWidget(_legend_swatch("#ef4444", 255))
        self._histogram_label_del = QLabel("Deletions", self)
        histo_legend.addWidget(self._histogram_label_del)
        histo_legend.addSpacing(SPACING_MEDIUM)
        histo_legend.addWidget(_legend_swatch("#3b82f6", 255))
        self._histogram_label_ins = QLabel("Insertions", self)
        histo_legend.addWidget(self._histogram_label_ins)
        histo_legend.addSpacing(SPACING_MEDIUM)
        histo_legend.addWidget(_legend_swatch("#94a3b8", 255))
        self._histogram_label_other = QLabel("Other", self)
        histo_legend.addWidget(self._histogram_label_other)
        histo_legend.addStretch(1)
        cut_layout.addWidget(self._histogram_legend)

        self._table = QTableWidget(self)
        self._table.setColumnCount(5)
        self._table.setHorizontalHeaderLabels(["Rank", "Type", "Size", "Frequency", "Delta"])
        self._table.verticalHeader().setVisible(False)
        self._table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._table.setSelectionMode(QTableWidget.SingleSelection)
        self._table.setShowGrid(True)
        try:
            header_widget = self._table.horizontalHeader()
            header_widget.setStretchLastSection(True)
            for idx in range(4):
                header_widget.setSectionResizeMode(idx, QHeaderView.ResizeMode.ResizeToContents)
        except Exception:
            pass
        cut_layout.addWidget(self._table)

        self._empty_label = QLabel("No predicted alleles yet.", self)
        self._empty_label.setStyleSheet("color: #94a3b8;")
        cut_layout.addWidget(self._empty_label)

        body_layout.addWidget(self._cut_container)

        self._prime_container = QFrame(self)
        prime_layout = QVBoxLayout(self._prime_container)
        prime_layout.setContentsMargins(0, 0, 0, 0)
        prime_layout.setSpacing(SPACING_MEDIUM)

        self._prime_warning_label = QLabel("", self)
        self._prime_warning_label.setWordWrap(True)
        self._prime_warning_label.hide()
        prime_layout.addWidget(self._prime_warning_label)

        self._prime_table = QTableWidget(self)
        self._prime_table.setColumnCount(3)
        self._prime_table.setHorizontalHeaderLabels(["Category", "Probability", "Description"])
        self._prime_table.verticalHeader().setVisible(False)
        self._prime_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._prime_table.setSelectionMode(QTableWidget.NoSelection)
        self._prime_table.setShowGrid(True)
        try:
            header_widget = self._prime_table.horizontalHeader()
            header_widget.setStretchLastSection(True)
            header_widget.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
            header_widget.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        except Exception:
            pass
        prime_layout.addWidget(self._prime_table)

        self._prime_interpretation = QLabel("", self)
        self._prime_interpretation.setStyleSheet("color: #94a3b8;")
        prime_layout.addWidget(self._prime_interpretation)

        body_layout.addWidget(self._prime_container)

        self._base_container = QFrame(self)
        base_layout = QVBoxLayout(self._base_container)
        base_layout.setContentsMargins(0, 0, 0, 0)
        base_layout.setSpacing(SPACING_MEDIUM)

        self._base_warning_label = QLabel("", self)
        self._base_warning_label.setWordWrap(True)
        self._base_warning_label.hide()
        base_layout.addWidget(self._base_warning_label)

        self._base_table = QTableWidget(self)
        self._base_table.setColumnCount(3)
        self._base_table.setHorizontalHeaderLabels(["Category", "Probability", "Description"])
        self._base_table.verticalHeader().setVisible(False)
        self._base_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._base_table.setSelectionMode(QTableWidget.NoSelection)
        self._base_table.setShowGrid(True)
        try:
            header_widget = self._base_table.horizontalHeader()
            header_widget.setStretchLastSection(True)
            header_widget.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
            header_widget.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        except Exception:
            pass
        base_layout.addWidget(self._base_table)

        self._base_interpretation = QLabel("", self)
        self._base_interpretation.setStyleSheet("color: #94a3b8;")
        base_layout.addWidget(self._base_interpretation)

        self._base_calibration_container = QFrame(self)
        base_cal_layout = QVBoxLayout(self._base_calibration_container)
        base_cal_layout.setContentsMargins(0, 0, 0, 0)
        base_cal_layout.setSpacing(SPACING_SMALL)

        base_cal_row = QHBoxLayout()
        base_cal_row.setSpacing(SPACING_SMALL)
        self._base_calibration_button = QToolButton(self)
        self._base_calibration_button.setText("Build base position calibration")
        base_cal_row.addWidget(self._base_calibration_button)
        base_cal_row.addStretch(1)
        base_cal_layout.addLayout(base_cal_row)

        base_apply_row = QHBoxLayout()
        base_apply_row.setSpacing(SPACING_SMALL)
        self._base_calibration_toggle = QCheckBox("Apply base calibration", self)
        base_apply_row.addWidget(self._base_calibration_toggle)
        self._base_calibration_selector = QComboBox(self)
        self._base_calibration_selector.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        base_apply_row.addWidget(self._base_calibration_selector)
        base_apply_row.addStretch(1)
        base_cal_layout.addLayout(base_apply_row)

        self._base_calibration_status_label = QLabel("Base calibration: —", self)
        self._base_calibration_status_label.setWordWrap(True)
        self._base_calibration_status_label.setStyleSheet("color: #94a3b8;")
        base_cal_layout.addWidget(self._base_calibration_status_label)
        self._base_calibration_confirm = QCheckBox("I understand compatibility is unknown", self)
        self._base_calibration_confirm.hide()
        base_cal_layout.addWidget(self._base_calibration_confirm)

        self._base_calibration_preview_label = QLabel("Calibration preview", self)
        self._base_calibration_preview_label.setStyleSheet("font-weight: 600;")
        base_cal_layout.addWidget(self._base_calibration_preview_label)
        self._base_calibration_evidence_label = QLabel("", self)
        self._base_calibration_evidence_label.setWordWrap(True)
        self._base_calibration_evidence_label.setStyleSheet("color: #facc15;")
        self._base_calibration_evidence_label.hide()
        base_cal_layout.addWidget(self._base_calibration_evidence_label)
        self._base_calibration_preview_table = QTableWidget(self)
        self._base_calibration_preview_table.setColumnCount(6)
        self._base_calibration_preview_table.setHorizontalHeaderLabels(
            ["Pos", "Role", "Pred", "Obs", "Cal", "Scale"]
        )
        self._base_calibration_preview_table.verticalHeader().setVisible(False)
        self._base_calibration_preview_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._base_calibration_preview_table.setSelectionMode(QTableWidget.NoSelection)
        self._base_calibration_preview_table.setShowGrid(True)
        try:
            header_widget = self._base_calibration_preview_table.horizontalHeader()
            header_widget.setStretchLastSection(True)
            for idx in range(6):
                header_widget.setSectionResizeMode(idx, QHeaderView.ResizeMode.ResizeToContents)
        except Exception:
            pass
        base_cal_layout.addWidget(self._base_calibration_preview_table)

        base_layout.addWidget(self._base_calibration_container)

        body_layout.addWidget(self._base_container)

        root.addWidget(self._body)

        self._toggle.toggled.connect(self._on_toggled)
        self._calibration_toggle.toggled.connect(self._on_calibration_toggled)
        self._calibration_selector.currentIndexChanged.connect(self._on_calibration_selected)
        self._suggested_button.clicked.connect(self._on_generate_suggested)
        self._suggested_selector.currentIndexChanged.connect(self._on_suggested_selected)
        self._apply_suggested_button.clicked.connect(self._on_apply_suggested)
        self._compat_confirm.toggled.connect(self._refresh_suggested_display)
        self._base_calibration_button.clicked.connect(self._on_generate_base_calibration)
        self._base_calibration_toggle.toggled.connect(self._on_base_calibration_toggled)
        self._base_calibration_selector.currentIndexChanged.connect(self._on_base_calibration_selected)
        self._base_calibration_confirm.toggled.connect(self._refresh_base_calibration_display)
        self._hotspot_toggle.toggled.connect(self._on_hotspot_toggled)
        self._context_toggle.toggled.connect(self._on_context_toggled)
        self._table.cellClicked.connect(self._on_table_clicked)
        self._mode_selector.currentIndexChanged.connect(self._on_mode_changed)
        self._target_selector.currentIndexChanged.connect(self._on_target_changed)
        self._cut_engine_selector.currentIndexChanged.connect(self._on_cut_engine_changed)

        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(250)
        self._debounce.timeout.connect(self._refresh_report)

        if self._session is not None:
            try:
                self._session.stateChanged.connect(self._on_state_changed)
            except Exception:
                pass

        self._set_mode("cut")
        self._on_state_changed(None)

    def _on_toggled(self, checked: bool) -> None:
        self._body.setVisible(bool(checked))
        self._toggle.setArrowType(Qt.DownArrow if checked else Qt.RightArrow)

    def _on_state_changed(self, _state: Any) -> None:
        if self._session is not None:
            try:
                cfg = self._session.state.config if self._session is not None else {}
                enabled = True
                mode = "aggregate"
                selected = None
                show_context = True
                cal_enabled = False
                cal_profile_id = ""
                profiles = []
                base_cal_enabled = False
                base_cal_profile_id = ""
                base_profiles: list[dict[str, Any]] = []
                base_previews: list[dict[str, Any]] = []
                cut_model_id = ""
                if isinstance(cfg, Mapping):
                    hotspot_cfg = cfg.get("outcome_hotspots")
                    if isinstance(hotspot_cfg, Mapping):
                        if "enabled" in hotspot_cfg:
                            enabled = bool(hotspot_cfg.get("enabled"))
                        if "show_context" in hotspot_cfg:
                            show_context = bool(hotspot_cfg.get("show_context"))
                        mode = str(hotspot_cfg.get("mode") or "aggregate")
                        selected = hotspot_cfg.get("selected_allele_key")
                    cal_cfg = cfg.get("calibration")
                    if isinstance(cal_cfg, Mapping):
                        cal_enabled = bool(cal_cfg.get("enabled"))
                        cal_profile_id = str(cal_cfg.get("profileId") or "")
                    base_cfg = cfg.get("base_position_calibration")
                    if isinstance(base_cfg, Mapping):
                        base_cal_enabled = bool(base_cfg.get("enabled"))
                        base_cal_profile_id = str(base_cfg.get("profileId") or "")
                    outcome_cfg = cfg.get("outcome_model")
                    if isinstance(outcome_cfg, Mapping):
                        cut_model_id = str(outcome_cfg.get("modelId") or "")

                spec = experiment_spec_to_dict(getattr(self._session.state, "experiment_spec", {}) or {})
                assumptions = spec.get("assumptions") if isinstance(spec.get("assumptions"), Mapping) else {}
                cell_ctx, _ = parse_cell_context(assumptions)
                cell_line = cell_ctx.cell_line or "—"
                delivery = cell_ctx.delivery_mode or "RNP"
                repair_bias = cell_ctx.repair_bias_preset or "neutral"
                if cell_ctx.delivery_mode is None:
                    delivery = f"{delivery} (default)"
                if cell_ctx.repair_bias_preset is None:
                    repair_bias = f"{repair_bias} (default)"
                self._cell_context_label.setText(
                    f"CellLine: {cell_line} • Delivery: {delivery} • RepairBias: {repair_bias}"
                )
                raw_profiles = getattr(self._session.state, "calibration_profiles", [])
                if isinstance(raw_profiles, list):
                    profiles = [p for p in raw_profiles if isinstance(p, Mapping)]
                raw_base_profiles = getattr(self._session.state, "base_position_calibration_profiles", [])
                if isinstance(raw_base_profiles, list):
                    base_profiles = [p for p in raw_base_profiles if isinstance(p, Mapping)]
                raw_base_previews = getattr(self._session.state, "base_position_calibration_previews", [])
                if isinstance(raw_base_previews, list):
                    base_previews = [p for p in raw_base_previews if isinstance(p, Mapping)]
                if self._hotspot_toggle.isChecked() != enabled:
                    self._syncing = True
                    self._hotspot_toggle.setChecked(enabled)
                    self._syncing = False
                if self._context_toggle.isChecked() != show_context:
                    self._syncing = True
                    self._context_toggle.setChecked(show_context)
                    self._syncing = False
                self._context_toggle.setEnabled(bool(enabled))
                self._legend_container.setVisible(bool(enabled) and self._current_mode in {"cut", "prime", "base"})
                if mode != "allele":
                    self._selected_key = None
                else:
                    self._selected_key = str(selected) if selected else None

                # Sync calibration controls.
                profiles = sorted(profiles, key=lambda p: str(p.get("profileId") or ""))
                self._syncing = True
                self._calibration_selector.clear()
                for profile in profiles:
                    pid = str(profile.get("profileId") or "")
                    scope = profile.get("scope") if isinstance(profile.get("scope"), Mapping) else {}
                    modality = str(scope.get("modality") or "")
                    label = pid[:8] + (f" • {modality}" if modality else "")
                    self._calibration_selector.addItem(label if label else pid, userData=pid)
                has_profiles = bool(profiles)
                self._calibration_toggle.setEnabled(has_profiles)
                self._calibration_selector.setEnabled(has_profiles and bool(cal_enabled))
                if has_profiles and cal_profile_id:
                    idx = self._calibration_selector.findData(cal_profile_id)
                    if idx >= 0:
                        self._calibration_selector.setCurrentIndex(idx)
                if self._calibration_toggle.isChecked() != bool(cal_enabled):
                    self._calibration_toggle.setChecked(bool(cal_enabled))

                # Sync base position calibration controls.
                base_profiles = sorted(base_profiles, key=lambda p: str(p.get("profileId") or ""))
                self._base_calibration_profiles = base_profiles
                self._base_calibration_previews = base_previews
                self._base_calibration_selector.clear()
                for profile in base_profiles:
                    pid = str(profile.get("profileId") or "")
                    scope = profile.get("scope") if isinstance(profile.get("scope"), Mapping) else {}
                    editor_type = str(scope.get("editorType") or "")
                    label = pid[:8] + (f" • {editor_type}" if editor_type else "")
                    self._base_calibration_selector.addItem(label if label else pid, userData=pid)
                has_base_profiles = bool(base_profiles)
                self._base_calibration_toggle.setEnabled(has_base_profiles)
                self._base_calibration_selector.setEnabled(has_base_profiles and bool(base_cal_enabled))
                if has_base_profiles and base_cal_profile_id:
                    idx = self._base_calibration_selector.findData(base_cal_profile_id)
                    if idx >= 0:
                        self._base_calibration_selector.setCurrentIndex(idx)
                if self._base_calibration_toggle.isChecked() != bool(base_cal_enabled):
                    self._base_calibration_toggle.setChecked(bool(base_cal_enabled))

                idx = self._cut_engine_selector.findData(cut_model_id)
                if idx < 0:
                    idx = self._cut_engine_selector.findData("")
                if idx >= 0 and self._cut_engine_selector.currentIndex() != idx:
                    self._cut_engine_selector.setCurrentIndex(idx)
                self._syncing = False
            except Exception:
                pass
            try:
                raw_history = getattr(self._session.state, "suggested_priors_history", [])
                history: list[dict[str, Any]] = []
                if isinstance(raw_history, list):
                    for entry in raw_history:
                        if isinstance(entry, Mapping):
                            history.append(dict(entry))
                history.sort(key=lambda h: int(_safe_float(h.get("sequence"), 0.0)), reverse=True)
                self._suggested_history = history[:10]

                self._syncing = True
                self._suggested_selector.clear()
                for entry in self._suggested_history:
                    suggested_id = str(entry.get("suggestedId") or "")
                    scope_summary = str(entry.get("scopeSummary") or "")
                    model_id = str(entry.get("modelId") or "")
                    parts = [p.strip() for p in scope_summary.split("•")]
                    modality = parts[0] if parts else "any"
                    cell_line = parts[1] if len(parts) > 1 else "any"
                    label = f"{suggested_id[:8]} · {modality or 'any'} · {cell_line or 'any'} · {model_id or '—'}"
                    self._suggested_selector.addItem(label, userData=suggested_id)
                if self._selected_suggested_id:
                    idx = self._suggested_selector.findData(self._selected_suggested_id)
                    if idx >= 0:
                        self._suggested_selector.setCurrentIndex(idx)
                elif self._suggested_history:
                    self._suggested_selector.setCurrentIndex(0)
                self._syncing = False

                self._selected_suggested_id = str(self._suggested_selector.currentData() or "") or None
                self._suggested_payload = self._payload_from_history(self._selected_suggested_id)
            except Exception:
                self._suggested_payload = None
                self._suggested_history = []
            self._refresh_suggested_display()
            self._base_calibration_preview = self._preview_for_base_calibration(
                str(self._base_calibration_selector.currentData() or "")
            )
            self._refresh_base_calibration_display()
        if not self._debounce.isActive():
            self._debounce.start()

    def _on_hotspot_toggled(self, checked: bool) -> None:
        if self._syncing or self._session is None:
            return
        try:
            self._context_toggle.setEnabled(bool(checked))
            self._legend_container.setVisible(bool(checked) and self._current_mode in {"cut", "prime", "base"})
        except Exception:
            pass
        cfg = {}
        try:
            cfg = dict(self._session.state.config) if isinstance(self._session.state.config, Mapping) else {}
        except Exception:
            cfg = {}
        hotspot_cfg = cfg.get("outcome_hotspots")
        if not isinstance(hotspot_cfg, Mapping):
            hotspot_cfg = {}
        hotspot_cfg = dict(hotspot_cfg)
        hotspot_cfg["enabled"] = bool(checked)
        cfg["outcome_hotspots"] = hotspot_cfg
        try:
            self._session.update(config=cfg)
        except Exception:
            pass

    def _on_calibration_toggled(self, checked: bool) -> None:
        if self._syncing or self._session is None:
            return
        cfg = {}
        try:
            cfg = dict(self._session.state.config) if isinstance(self._session.state.config, Mapping) else {}
        except Exception:
            cfg = {}
        cal_cfg = cfg.get("calibration")
        if not isinstance(cal_cfg, Mapping):
            cal_cfg = {}
        cal_cfg = dict(cal_cfg)
        cal_cfg["enabled"] = bool(checked)
        cal_cfg["profileId"] = str(self._calibration_selector.currentData() or "")
        cfg["calibration"] = cal_cfg
        try:
            self._session.update(config=cfg)
        except Exception:
            pass

    def _on_calibration_selected(self) -> None:
        if self._syncing or self._session is None:
            return
        cfg = {}
        try:
            cfg = dict(self._session.state.config) if isinstance(self._session.state.config, Mapping) else {}
        except Exception:
            cfg = {}
        cal_cfg = cfg.get("calibration")
        if not isinstance(cal_cfg, Mapping):
            cal_cfg = {}
        cal_cfg = dict(cal_cfg)
        cal_cfg["profileId"] = str(self._calibration_selector.currentData() or "")
        if "enabled" not in cal_cfg:
            cal_cfg["enabled"] = bool(self._calibration_toggle.isChecked())
        cfg["calibration"] = cal_cfg
        try:
            self._session.update(config=cfg)
        except Exception:
            pass

    def _on_generate_suggested(self) -> None:
        if self._session is None:
            return
        try:
            profiles = getattr(self._session.state, "calibration_profiles", [])
            profile = None
            if isinstance(profiles, list) and profiles:
                selected_id = str(self._calibration_selector.currentData() or "")
                if selected_id:
                    for entry in profiles:
                        if isinstance(entry, Mapping) and str(entry.get("profileId") or "") == selected_id:
                            profile = entry
                            break
                if profile is None:
                    profile = profiles[-1]
            if not isinstance(profile, Mapping):
                return
            report = compute_outcomes_for_current_plan(
                self._session, apply_calibration=False, apply_priors_override=False
            )
            report_payload = outcome_report_to_dict(report)
            suggested = build_suggested_priors(
                profile,
                results_records=getattr(self._session.state, "results_records", []),
                outcome_report_payload=report_payload,
            )
            attach_suggested_priors(self._session, suggested)
            self._selected_suggested_id = str(suggested.get("suggestedId") or "")
            self._suggested_payload = dict(suggested)
            self._refresh_suggested_display()
        except Exception:
            return

    def _on_suggested_selected(self) -> None:
        if self._syncing:
            return
        self._selected_suggested_id = str(self._suggested_selector.currentData() or "") or None
        self._suggested_payload = self._payload_from_history(self._selected_suggested_id)
        self._refresh_suggested_display()

    def _on_apply_suggested(self) -> None:
        if self._session is None or not isinstance(self._suggested_payload, Mapping):
            return
        if self._compat_status == "incompatible":
            return
        if self._compat_status == "unknown" and not self._compat_confirm.isChecked():
            return
        priors = self._suggested_payload.get("priors") if isinstance(self._suggested_payload.get("priors"), Mapping) else {}
        overrides: dict[str, Any] = {}
        cut = priors.get("cut") if isinstance(priors.get("cut"), Mapping) else None
        if isinstance(cut, Mapping):
            overrides["cutPriorAlpha0"] = int(_safe_float(cut.get("desiredAlpha0"), 0.0))
            overrides["cutPriorBeta0"] = int(_safe_float(cut.get("desiredBeta0"), 0.0))
            overrides["cutPriorStrength"] = int(_safe_float(cut.get("defaultBetaPriorStrength"), 0.0))
        prime = priors.get("prime") if isinstance(priors.get("prime"), Mapping) else None
        if isinstance(prime, Mapping):
            overrides["primeDirichletStrength"] = int(_safe_float(prime.get("defaultDirichletStrength"), 0.0))
            alpha_map = prime.get("alphaByCategory") if isinstance(prime.get("alphaByCategory"), Mapping) else {}
            overrides["primeDirichletAlpha"] = dict(alpha_map) if isinstance(alpha_map, Mapping) else {}

        cfg = {}
        try:
            cfg = dict(self._session.state.config) if isinstance(self._session.state.config, Mapping) else {}
        except Exception:
            cfg = {}
        outcome_cfg = cfg.get("outcome_model")
        if not isinstance(outcome_cfg, Mapping):
            outcome_cfg = {}
        outcome_cfg = dict(outcome_cfg)
        current_overrides = outcome_cfg.get("overrides")
        if not isinstance(current_overrides, Mapping):
            current_overrides = {}
        current_overrides = dict(current_overrides)
        current_overrides.update({k: v for k, v in overrides.items() if v is not None})
        current_overrides["suggestedId"] = str(self._suggested_payload.get("suggestedId") or "")
        outcome_cfg["overrides"] = current_overrides
        cfg["outcome_model"] = outcome_cfg
        try:
            self._session.update(config=cfg)
        except Exception:
            pass

    def _preview_for_base_calibration(self, profile_id: str) -> dict[str, Any] | None:
        if not profile_id:
            return None
        for entry in self._base_calibration_previews:
            if not isinstance(entry, Mapping):
                continue
            if str(entry.get("profileId") or "") == profile_id:
                return dict(entry)
        return None

    def _on_generate_base_calibration(self) -> None:
        if self._session is None:
            return
        try:
            report = compute_outcomes_for_current_plan(
                self._session, apply_calibration=False, apply_priors_override=False
            )
            report_payload = outcome_report_to_dict(report)
            profile, preview = build_base_position_calibration_profile_and_preview(
                getattr(self._session.state, "results_records", []),
                report_payload,
                experiment_spec=getattr(self._session.state, "experiment_spec", {}) if self._session else {},
            )
            attach_base_position_calibration_profile(self._session, profile, preview)
            self._selected_base_calibration_id = str(profile.get("profileId") or "") or None
            self._base_calibration_preview = dict(preview)
            self._refresh_base_calibration_display()
        except Exception:
            return

    def _on_base_calibration_toggled(self, checked: bool) -> None:
        if self._syncing or self._session is None:
            return
        if self._base_calibration_status == "incompatible":
            self._syncing = True
            self._base_calibration_toggle.setChecked(False)
            self._syncing = False
            return
        if self._base_calibration_status == "unknown" and not self._base_calibration_confirm.isChecked():
            self._syncing = True
            self._base_calibration_toggle.setChecked(False)
            self._syncing = False
            return
        cfg = {}
        try:
            cfg = dict(self._session.state.config) if isinstance(self._session.state.config, Mapping) else {}
        except Exception:
            cfg = {}
        base_cfg = cfg.get("base_position_calibration")
        if not isinstance(base_cfg, Mapping):
            base_cfg = {}
        base_cfg = dict(base_cfg)
        base_cfg["enabled"] = bool(checked)
        base_cfg["profileId"] = str(self._base_calibration_selector.currentData() or "")
        cfg["base_position_calibration"] = base_cfg
        try:
            self._session.update(config=cfg)
        except Exception:
            pass

    def _on_base_calibration_selected(self) -> None:
        if self._syncing or self._session is None:
            return
        cfg = {}
        try:
            cfg = dict(self._session.state.config) if isinstance(self._session.state.config, Mapping) else {}
        except Exception:
            cfg = {}
        base_cfg = cfg.get("base_position_calibration")
        if not isinstance(base_cfg, Mapping):
            base_cfg = {}
        base_cfg = dict(base_cfg)
        base_cfg["profileId"] = str(self._base_calibration_selector.currentData() or "")
        if "enabled" not in base_cfg:
            base_cfg["enabled"] = bool(self._base_calibration_toggle.isChecked())
        cfg["base_position_calibration"] = base_cfg
        try:
            self._session.update(config=cfg)
        except Exception:
            pass
        self._base_calibration_preview = self._preview_for_base_calibration(base_cfg.get("profileId") or "")
        self._refresh_base_calibration_display()

    def _refresh_base_calibration_display(self) -> None:
        profile = None
        profile_id = str(self._base_calibration_selector.currentData() or "")
        for entry in self._base_calibration_profiles:
            if str(entry.get("profileId") or "") == profile_id:
                profile = entry
                break
        preview = self._base_calibration_preview or self._preview_for_base_calibration(profile_id)
        self._base_calibration_preview = preview

        status = "unknown"
        reasons: list[str] = []
        if isinstance(profile, Mapping):
            compat = check_base_position_calibration_compatibility(self._last_payload, profile)
            status = str(compat.get("status") or "unknown")
            reasons = [str(r) for r in compat.get("reasons") or []]
        else:
            reasons = ["no profile selected"]
        self._base_calibration_status = status
        self._base_calibration_reasons = reasons

        if status == "compatible":
            self._base_calibration_status_label.setText("Base calibration: compatible")
            self._base_calibration_status_label.setStyleSheet("color: #86efac;")
            self._base_calibration_confirm.hide()
        elif status == "incompatible":
            reason_text = ", ".join(reasons) if reasons else "incompatible"
            self._base_calibration_status_label.setText(f"Base calibration: incompatible ({reason_text})")
            self._base_calibration_status_label.setStyleSheet("color: #fca5a5;")
            self._base_calibration_confirm.hide()
        else:
            reason_text = ", ".join(reasons) if reasons else "unknown compatibility"
            self._base_calibration_status_label.setText(f"Base calibration: unknown ({reason_text})")
            self._base_calibration_status_label.setStyleSheet("color: #facc15;")
            self._base_calibration_confirm.show()

        has_profile = isinstance(profile, Mapping)
        toggle_enabled = has_profile and status != "incompatible"
        self._base_calibration_toggle.setEnabled(toggle_enabled)
        self._base_calibration_selector.setEnabled(has_profile and bool(self._base_calibration_toggle.isChecked()))

        if self._session is not None and self._base_calibration_toggle.isChecked():
            if status == "incompatible" or (status == "unknown" and not self._base_calibration_confirm.isChecked()):
                self._syncing = True
                self._base_calibration_toggle.setChecked(False)
                self._syncing = False
                try:
                    cfg = dict(self._session.state.config) if isinstance(self._session.state.config, Mapping) else {}
                except Exception:
                    cfg = {}
                base_cfg = cfg.get("base_position_calibration")
                if not isinstance(base_cfg, Mapping):
                    base_cfg = {}
                base_cfg = dict(base_cfg)
                base_cfg["enabled"] = False
                base_cfg["profileId"] = profile_id
                cfg["base_position_calibration"] = base_cfg
                try:
                    self._session.update(config=cfg)
                except Exception:
                    pass

        positions = []
        if isinstance(preview, Mapping):
            positions = preview.get("positions") if isinstance(preview.get("positions"), list) else []
        rows = [p for p in positions if isinstance(p, Mapping)]
        rows.sort(key=lambda r: int(_safe_float(r.get("pos"), 0.0)))
        self._base_calibration_preview_table.setRowCount(len(rows))
        for idx, entry in enumerate(rows):
            pos = str(int(_safe_float(entry.get("pos"), 0.0)))
            role = str(entry.get("role") or "")
            pred = entry.get("predicted")
            obs = entry.get("observed")
            cal = entry.get("calibrated")
            scale = entry.get("scale")
            pred_text = f"{_safe_float(pred, 0.0):.6f}" if pred is not None else "—"
            obs_text = f"{_safe_float(obs, 0.0):.6f}" if obs is not None else "—"
            cal_text = f"{_safe_float(cal, 0.0):.6f}" if cal is not None else "—"
            scale_text = f"{_safe_float(scale, 0.0):.3f}" if scale is not None else "—"
            cells = [pos, role, pred_text, obs_text, cal_text, scale_text]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self._base_calibration_preview_table.setItem(idx, col, item)

        evidence_note = ""
        if isinstance(preview, Mapping):
            evidence_note = str(preview.get("lowEvidenceNote") or "").strip()
        if evidence_note:
            self._base_calibration_evidence_label.setText(evidence_note)
            self._base_calibration_evidence_label.show()
        else:
            self._base_calibration_evidence_label.setText("")
            self._base_calibration_evidence_label.hide()

        eval_text = ""
        warning_note = ""
        if isinstance(preview, Mapping):
            results_records = []
            if self._session is not None:
                raw = getattr(self._session.state, "results_records", [])
                if isinstance(raw, list):
                    results_records = raw
            try:
                eval_payload = build_base_position_calibration_eval(
                    preview,
                    results_records=results_records,
                )
                l1_before = _safe_float(eval_payload.get("l1Before"), 0.0)
                l1_after = _safe_float(eval_payload.get("l1After"), 0.0)
                evidence_n = int(_safe_float(eval_payload.get("evidenceN"), 0.0))
                warning_note = str(eval_payload.get("warningNote") or "").strip()
                if warning_note:
                    eval_text = f"L1 worsened {l1_before:.3f} → {l1_after:.3f}, evidence {evidence_n} reads"
                else:
                    eval_text = f"L1 improved {l1_before:.3f} → {l1_after:.3f}, evidence {evidence_n} reads"
            except Exception:
                eval_text = ""
                warning_note = ""

        show_eval = bool(self._last_payload.get("basePositionCalibrationApplied"))
        if show_eval and eval_text:
            self._base_calibration_eval_label.setText(eval_text)
            self._base_calibration_eval_label.show()
        else:
            self._base_calibration_eval_label.setText("")
            self._base_calibration_eval_label.hide()

        if warning_note:
            self._base_calibration_evidence_label.setText(warning_note)
            self._base_calibration_evidence_label.show()

    def _payload_from_history(self, suggested_id: str | None) -> dict[str, Any] | None:
        if not suggested_id:
            return None
        for entry in self._suggested_history:
            if str(entry.get("suggestedId") or "") != suggested_id:
                continue
            if entry.get("storedExternally") and self._session is not None:
                try:
                    stored = getattr(self._session.state, "suggested_priors", [])
                    if isinstance(stored, list):
                        for payload in stored:
                            if str(payload.get("suggestedId") or "") == suggested_id:
                                return dict(payload)
                except Exception:
                    pass
            raw = entry.get("suggestedJson")
            if isinstance(raw, str) and raw.strip():
                try:
                    return json.loads(raw)
                except Exception:
                    pass
        return None

    def _refresh_suggested_display(self) -> None:
        cfg = {}
        try:
            cfg = dict(self._session.state.config) if self._session and isinstance(self._session.state.config, Mapping) else {}
        except Exception:
            cfg = {}
        overrides = {}
        outcome_cfg = cfg.get("outcome_model") if isinstance(cfg.get("outcome_model"), Mapping) else {}
        if isinstance(outcome_cfg, Mapping):
            overrides = outcome_cfg.get("overrides") if isinstance(outcome_cfg.get("overrides"), Mapping) else {}

        def _fmt_cut(source: Mapping[str, Any] | None) -> str:
            if not isinstance(source, Mapping):
                return "cut —"
            alpha0 = source.get("desiredAlpha0") if "desiredAlpha0" in source else source.get("cutPriorAlpha0")
            beta0 = source.get("desiredBeta0") if "desiredBeta0" in source else source.get("cutPriorBeta0")
            strength = source.get("defaultBetaPriorStrength") if "defaultBetaPriorStrength" in source else source.get("cutPriorStrength")
            if alpha0 is None or beta0 is None:
                return "cut —"
            parts = [f"α0={int(_safe_float(alpha0, 0.0))}", f"β0={int(_safe_float(beta0, 0.0))}"]
            if strength is not None:
                parts.append(f"S={int(_safe_float(strength, 0.0))}")
            return "cut " + " ".join(parts)

        def _fmt_prime(source: Mapping[str, Any] | None) -> str:
            if not isinstance(source, Mapping):
                return "prime —"
            strength = source.get("defaultDirichletStrength") if "defaultDirichletStrength" in source else source.get("primeDirichletStrength")
            alpha_map = source.get("alphaByCategory") if "alphaByCategory" in source else source.get("primeDirichletAlpha")
            if not isinstance(alpha_map, Mapping) and strength is None:
                return "prime —"
            parts = []
            if strength is not None:
                parts.append(f"S={int(_safe_float(strength, 0.0))}")
            if isinstance(alpha_map, Mapping):
                ordered = [
                    ("desired_edit", alpha_map.get("desired_edit")),
                    ("partial_edit", alpha_map.get("partial_edit")),
                    ("rt_template_truncation", alpha_map.get("rt_template_truncation")),
                    ("nick_indels", alpha_map.get("nick_indels")),
                    ("pegRNA_failure", alpha_map.get("pegRNA_failure")),
                ]
                parts.append(
                    "α{" + ", ".join(f"{k}={_round(_safe_float(v, 0.0), 4)}" for k, v in ordered) + "}"
                )
            return "prime " + " ".join(parts)

        current_cut = _fmt_cut(overrides if isinstance(overrides, Mapping) else None)
        current_prime = _fmt_prime(overrides if isinstance(overrides, Mapping) else None)

        suggested_cut = "cut —"
        suggested_prime = "prime —"
        if isinstance(self._suggested_payload, Mapping):
            priors = self._suggested_payload.get("priors") if isinstance(self._suggested_payload.get("priors"), Mapping) else {}
            if isinstance(priors, Mapping):
                suggested_cut = _fmt_cut(priors.get("cut") if isinstance(priors.get("cut"), Mapping) else None)
                suggested_prime = _fmt_prime(priors.get("prime") if isinstance(priors.get("prime"), Mapping) else None)

        if not isinstance(self._suggested_payload, Mapping):
            self._compat_status = "unknown"
            self._compat_reasons = []
            self._compat_label.setText("Compatibility: —")
            self._compat_label.setStyleSheet("color: #94a3b8;")
            self._compat_confirm.hide()
            self._apply_suggested_button.setToolTip("")
            self._apply_suggested_button.setEnabled(False)
        else:
            compat = check_suggested_priors_compatibility(
                self._suggested_payload,
                experiment_spec=getattr(self._session.state, "experiment_spec", {}) if self._session else {},
                outcome_report_payload=self._last_payload or {},
            )
            self._compat_status = str(compat.get("status") or "unknown")
            self._compat_reasons = [str(r) for r in (compat.get("reasons") or [])]
            reasons_text = ", ".join(self._compat_reasons)
            if self._compat_status == "compatible":
                self._compat_label.setText("Compatible")
                self._compat_label.setStyleSheet("color: #86efac;")
                self._compat_confirm.hide()
                allow_apply = True
            elif self._compat_status == "incompatible":
                self._compat_label.setText(f"Incompatible: {reasons_text}" if reasons_text else "Incompatible")
                self._compat_label.setStyleSheet("color: #f87171;")
                self._compat_confirm.hide()
                allow_apply = False
            else:
                self._compat_label.setText(
                    f"Compatibility unknown: {reasons_text}" if reasons_text else "Compatibility unknown"
                )
                self._compat_label.setStyleSheet("color: #fbbf24;")
                self._compat_confirm.show()
                allow_apply = bool(self._compat_confirm.isChecked())

            if self._compat_status == "incompatible" and reasons_text:
                self._apply_suggested_button.setToolTip(reasons_text)
            else:
                self._apply_suggested_button.setToolTip("")

            self._apply_suggested_button.setEnabled(bool(self._suggested_payload) and allow_apply)
        self._suggested_label.setText(
            f"Current priors: {current_cut} • {current_prime}\nSuggested priors: {suggested_cut} • {suggested_prime}"
        )

    def _on_context_toggled(self, checked: bool) -> None:
        if self._syncing or self._session is None:
            return
        cfg = {}
        try:
            cfg = dict(self._session.state.config) if isinstance(self._session.state.config, Mapping) else {}
        except Exception:
            cfg = {}
        hotspot_cfg = cfg.get("outcome_hotspots")
        if not isinstance(hotspot_cfg, Mapping):
            hotspot_cfg = {}
        hotspot_cfg = dict(hotspot_cfg)
        hotspot_cfg["show_context"] = bool(checked)
        cfg["outcome_hotspots"] = hotspot_cfg
        try:
            self._session.update(config=cfg)
        except Exception:
            pass

    def _on_mode_changed(self) -> None:
        if self._syncing:
            return
        mode = str(self._mode_selector.currentData() or "cut")
        self._mode_override = mode
        self._set_mode(mode)
        if self._last_payload:
            self._render_prime_outcomes(self._last_payload)
            self._render_base_outcomes(self._last_payload)
            self._apply_selection_status()

    def _on_cut_engine_changed(self) -> None:
        if self._syncing or self._session is None:
            return
        selected = str(self._cut_engine_selector.currentData() or "")
        cfg = {}
        try:
            cfg = dict(self._session.state.config) if isinstance(self._session.state.config, Mapping) else {}
        except Exception:
            cfg = {}
        outcome_cfg = cfg.get("outcome_model")
        if not isinstance(outcome_cfg, Mapping):
            outcome_cfg = {}
        outcome_cfg = dict(outcome_cfg)
        if selected:
            outcome_cfg["modelId"] = selected
        else:
            outcome_cfg.pop("modelId", None)
        cfg["outcome_model"] = outcome_cfg
        try:
            self._session.update(config=cfg)
        except Exception:
            pass

    def _on_target_changed(self) -> None:
        if self._syncing:
            return
        selected = self._target_selector.currentData()
        token = str(selected or "")
        if token == _COMBINED_TOKEN:
            self._combined_selected = True
        else:
            self._combined_selected = False
            self._target_override = token or None
        self._set_multiplex_override(token if token else None, combined=self._combined_selected)
        if self._last_payload:
            self._render_payload(self._last_payload)

    def _set_multiplex_override(self, target_id: str | None, *, combined: bool) -> None:
        if self._session is None:
            return
        override = _COMBINED_TOKEN if combined else (str(target_id) if target_id else None)
        if override == self._last_multiplex_override:
            return
        self._last_multiplex_override = override
        try:
            setattr(self._session, "_multiplex_target_override", override)
        except Exception:
            return
        try:
            if not getattr(self._session.state, "viz_dirty", False):
                self._session.update(viz_dirty=True)
            else:
                self._session.stateChanged.emit(self._session.state)
        except Exception:
            pass

    def _on_table_clicked(self, row: int, _column: int) -> None:
        if self._current_mode not in {"cut", "prime", "base"}:
            return
        if self._session is None or row < 0 or row >= len(self._row_keys):
            return
        key = self._row_keys[row]
        if key is None:
            return
        if self._selected_key == key:
            self._set_selection(None)
        else:
            self._set_selection(key)

    def _set_selection(self, key: str | None) -> None:
        if self._session is None:
            return
        cfg = {}
        try:
            cfg = dict(self._session.state.config) if isinstance(self._session.state.config, Mapping) else {}
        except Exception:
            cfg = {}
        hotspot_cfg = cfg.get("outcome_hotspots")
        if not isinstance(hotspot_cfg, Mapping):
            hotspot_cfg = {}
        hotspot_cfg = dict(hotspot_cfg)
        if key:
            hotspot_cfg["mode"] = "allele"
            hotspot_cfg["selected_allele_key"] = key
        else:
            hotspot_cfg["mode"] = "aggregate"
            hotspot_cfg.pop("selected_allele_key", None)
        cfg["outcome_hotspots"] = hotspot_cfg
        try:
            self._session.update(config=cfg)
        except Exception:
            pass

    def _refresh_report(self) -> None:
        if self._session is None:
            self._render_payload({})
            return
        try:
            report = compute_outcomes_for_current_plan(self._session)
            payload = outcome_report_to_dict(report)
        except Exception:
            payload = {}
        self._render_payload(payload)

    def _render_payload(self, payload: Mapping[str, Any]) -> None:
        self._last_payload = dict(payload)
        self._sync_mode_from_payload(payload)
        self._render_prime_outcomes(payload)
        self._render_base_outcomes(payload)

        model_id = str(payload.get("modelId") or "—")
        model_version = str(payload.get("modelVersion") or "")
        model_suffix = f" {model_version}" if model_version else ""
        self._model_label.setText(f"Model: {model_id}{model_suffix}")

        inputs_sha = str(payload.get("inputsSha256") or "")
        short_sha = inputs_sha[:8] if inputs_sha else "—"
        self._inputs_label.setText(f"Inputs: {short_sha}")
        self._calibration_badge.setVisible(bool(payload.get("calibrationApplied")))
        self._base_calibration_badge.setVisible(bool(payload.get("basePositionCalibrationApplied")))

        summary_lines = payload.get("summary") if isinstance(payload.get("summary"), list) else []
        if summary_lines:
            text = "\n".join(f"• {str(line)}" for line in summary_lines)
        else:
            text = "No summary available."
        self._summary_label.setText(text)

        multiplex_targets, multiplex_combined, multiplex_warnings = _extract_multiplex(payload)
        self._multiplex_targets = multiplex_targets
        self._multiplex_combined = multiplex_combined
        self._multiplex_warnings = multiplex_warnings

        active_alleles = payload.get("alleleSpectrum") if isinstance(payload.get("alleleSpectrum"), list) else []
        desired_override = None
        combined_selected = False
        has_multiplex = self._current_mode == "cut" and len(multiplex_targets) > 1
        target_ids: list[str] = []
        target_map: dict[str, dict[str, Any]] = {}
        if has_multiplex:
            target_entries = [(_multiplex_target_id(entry, idx), entry) for idx, entry in enumerate(multiplex_targets)]
            target_entries.sort(key=lambda item: item[0])
            target_ids = [tid for tid, _entry in target_entries]
            target_map = {tid: entry for tid, entry in target_entries}
            if target_ids:
                default_target = _default_target_id(target_entries)
                if not self._target_override or self._target_override not in target_map:
                    self._target_override = default_target
                combined_selected = bool(self._combined_selected)
                selected_token = _COMBINED_TOKEN if combined_selected else (self._target_override or default_target)
                self._syncing = True
                self._target_selector.clear()
                for tid in target_ids:
                    self._target_selector.addItem(tid, userData=tid)
                self._target_selector.addItem("Combined", userData=_COMBINED_TOKEN)
                idx = self._target_selector.findData(selected_token)
                if idx >= 0:
                    self._target_selector.setCurrentIndex(idx)
                self._syncing = False
                self._target_label.show()
                self._target_selector.show()
                self._combined_selected = combined_selected
                if combined_selected:
                    active_alleles = []
                else:
                    entry = target_map.get(self._target_override or default_target, {})
                    active_alleles = (
                        entry.get("alleleSpectrum") if isinstance(entry.get("alleleSpectrum"), list) else []
                    )
                    desired_override = entry.get("desiredFrequency")
            else:
                has_multiplex = False
        if not has_multiplex:
            self._combined_selected = False
            self._target_label.hide()
            self._target_selector.hide()
            self._multiplex_container.hide()
            self._prime_multiplex_label.setText("Prime multiplex: —")

        if self._combined_selected and has_multiplex:
            expected_any = float(multiplex_combined.get("expectedAnyEdited") or 0.0)
            expected_all = float(multiplex_combined.get("expectedAllTargetsEdited") or 0.0)
            combined_lines = [
                f"Expected any edited: {expected_any * 100:.2f}%",
                f"Expected all targets edited: {expected_all * 100:.2f}%",
            ]
            sv_entries = payload.get("structuralVariants") if isinstance(payload.get("structuralVariants"), list) else []
            span_del = 0.0
            span_inv = 0.0
            for entry in sv_entries:
                if not isinstance(entry, Mapping):
                    continue
                kind = str(entry.get("kind") or "")
                freq = 0.0
                try:
                    freq = float(entry.get("frequency") or 0.0)
                except Exception:
                    freq = 0.0
                if kind == "spanDeletion":
                    span_del += freq
                elif kind == "spanInversion":
                    span_inv += freq
            if span_del > 0.0:
                combined_lines.append(f"Expected span deletion: {span_del * 100:.2f}%")
            if span_inv > 0.0:
                combined_lines.append(f"Expected span inversion: {span_inv * 100:.2f}%")
            combined_text = "\n".join(combined_lines)
            self._multiplex_summary.setText(combined_text)
            if multiplex_warnings:
                warn_text = "\n".join(f"• {w}" for w in multiplex_warnings)
                self._multiplex_warning_label.setText(warn_text)
                self._multiplex_warning_label.show()
            else:
                self._multiplex_warning_label.hide()
                self._multiplex_warning_label.setText("")
            self._multiplex_container.show()
            self._screening_container.hide()
        else:
            self._multiplex_container.hide()
            self._screening_container.show()
            # Prime multiplex summary (read-only)
            prime_mux = None
            if isinstance(payload.get("prime_multiplex"), Mapping):
                prime_mux = payload.get("prime_multiplex")
            elif isinstance(payload.get("multiplex"), Mapping):
                prime_mux = payload.get("multiplex", {}).get("prime")
            if isinstance(prime_mux, Mapping):
                combined = float(prime_mux.get("combinedDesired") or 0.0)
                baseline = float(prime_mux.get("combinedDesiredIndependent") or 0.0)
                penalty = float(prime_mux.get("interactionPenalty") or 0.0)
                targets = prime_mux.get("targets") if isinstance(prime_mux.get("targets"), list) else []
                target_bits = []
                for t in targets:
                    if not isinstance(t, Mapping):
                        continue
                    tid = str(t.get("targetId") or "t")
                    dprob = float(t.get("desired") or 0.0)
                    pos = t.get("pos")
                    pos_str = f"{pos}" if pos is not None else "pos ?"
                    target_bits.append(f"{tid} {dprob:.2f} ({pos_str})")
                tgt_str = "; ".join(target_bits) if target_bits else "—"
                multiplier_ppm = prime_mux.get("multiplierAppliedPpm") or prime_mux.get("multiplierPpm")
                multiplier_str = ""
                try:
                    if multiplier_ppm and float(multiplier_ppm) != 1_000_000:
                        multiplier_str = f", calibrated x{float(multiplier_ppm)/1_000_000:.2f}"
                except Exception:
                    multiplier_str = ""
                self._prime_multiplex_label.setText(
                    f"Prime multiplex: combined {combined*100:.2f}%, baseline {baseline*100:.2f}%, penalty {penalty:.2f}{multiplier_str}, targets {tgt_str}"
                )
                params = prime_mux.get("params") if isinstance(prime_mux.get("params"), Mapping) else {}
                tip_parts = []
                if params:
                    tip_parts.append(f"params: {json.dumps(params, sort_keys=True)}")
                distances = prime_mux.get("distances") if isinstance(prime_mux.get("distances"), list) else []
                if distances:
                    tip_parts.append(f"distances: {distances}")
                warnings = prime_mux.get("warnings") if isinstance(prime_mux.get("warnings"), list) else []
                if warnings:
                    tip_parts.append(f"warnings: {warnings}")
                if multiplier_ppm:
                    tip_parts.append(f"multiplier_ppm: {multiplier_ppm}")
                if prime_mux.get("calibrationProfileId"):
                    tip_parts.append(f"profile: {prime_mux.get('calibrationProfileId')}")
                if prime_mux.get("calibrationProfileHash"):
                    tip_parts.append(f"profile_hash: {prime_mux.get('calibrationProfileHash')}")
                if isinstance(prime_mux.get("calibrationClamp"), Mapping):
                    tip_parts.append(f"clamp: {prime_mux.get('calibrationClamp')}")
                try:
                    self._prime_multiplex_label.setToolTip("\n".join(tip_parts))
                except Exception:
                    pass
            else:
                self._prime_multiplex_label.setText("Prime multiplex: —")

            clone_payload = dict(payload)
            clone_payload["alleleSpectrum"] = active_alleles
            clone_plan = build_clone_plan(clone_payload)
            intent_payload = payload.get("editIntent") if isinstance(payload.get("editIntent"), Mapping) else {}
            goal = str(intent_payload.get("goal") or "")
            eval_payload: Mapping[str, Any] | None = None
            if has_multiplex and not self._combined_selected:
                selected_target = target_map.get(self._target_override or "", {}) if target_map else {}
                if isinstance(selected_target.get("intentEvaluation"), Mapping):
                    eval_payload = selected_target.get("intentEvaluation")
            if eval_payload is None and isinstance(payload.get("intentEvaluation"), Mapping):
                eval_payload = payload.get("intentEvaluation")

            has_eval = isinstance(eval_payload, Mapping) and any(
                key in eval_payload for key in ("successProbability", "metric", "reasons")
            )
            if not has_eval:
                if desired_override is not None:
                    desired_freq = float(desired_override)
                    target_conf = float(clone_plan.get("targetConfidence") or 0.95)
                    clones_needed = _estimate_clones(desired_freq, target_conf)
                else:
                    desired_freq = float(clone_plan.get("desiredFrequency") or 0.0)
                    target_conf = float(clone_plan.get("targetConfidence") or 0.95)
                    clones_needed = clone_plan.get("clonesNeededSingleCell")
                desired_text = f"{desired_freq * 100:.2f}%"
                target_pct = f"{target_conf * 100:.0f}%"
                clones_text = "N/A (p=0)" if clones_needed is None else str(int(clones_needed))
                self._screening_value.setText(
                    f"Desired frequency: {desired_text} • Estimated clones to screen ({target_pct} confidence): {clones_text}"
                )
            else:
                metric = str(eval_payload.get("metric") or "") if isinstance(eval_payload, Mapping) else ""
                threshold = eval_payload.get("threshold") if isinstance(eval_payload, Mapping) else None
                try:
                    threshold_f = float(threshold) if threshold is not None else 0.0
                except Exception:
                    threshold_f = 0.0

                success_prob = None
                if isinstance(eval_payload, Mapping):
                    success_prob = eval_payload.get("successProbability")
                if success_prob is None and desired_override is not None:
                    success_prob = desired_override

                target_conf = float(clone_plan.get("targetConfidence") or 0.95)
                target_pct = f"{target_conf * 100:.0f}%"

                reasons = []
                if isinstance(eval_payload, Mapping) and isinstance(eval_payload.get("reasons"), list):
                    reasons = [str(r) for r in eval_payload.get("reasons") if r is not None]

                if success_prob is None:
                    reason_text = f" ({'; '.join(reasons)})" if reasons else ""
                    intent_text = (
                        f"Intent: {goal or 'unknown'} • Success: {metric or 'unknown'}≥{threshold_f:.2f} → Not computed{reason_text}"
                    )
                    self._screening_value.setText(
                        f"{intent_text} • Estimated clones to screen ({target_pct} confidence): N/A (not computed)"
                    )
                else:
                    desired_freq = float(success_prob)
                    desired_text = f"{desired_freq * 100:.2f}%"
                    clones_needed = _estimate_clones(desired_freq, target_conf)
                    clones_text = "N/A (p=0)" if clones_needed is None else str(int(clones_needed))
                    intent_text = f"Intent: {goal or 'unknown'} • Success: {metric or 'unknown'}≥{threshold_f:.2f} → {desired_text}"
                    self._screening_value.setText(
                        f"{intent_text} • Estimated clones to screen ({target_pct} confidence): {clones_text}"
                    )

        assay_label = "Recommended assay: —"
        rationale_text = ""
        primer_label = "Primary primers: —"
        if self._session is not None and not (self._combined_selected and has_multiplex):
            try:
                off_report = compute_offtargets_for_session(self._session)
                off_bytes = offtarget_report_json_bytes(off_report)
                off_payload = json.loads(off_bytes.decode("utf-8"))
                genome_sequences = None
                try:
                    genome_sequences = getattr(self._session.state.genome, "sequences", None)
                except Exception:
                    genome_sequences = None
                guide = {}
                try:
                    cfg = self._session.state.config
                    if isinstance(cfg, Mapping):
                        guide = cfg.get("guide") or {}
                except Exception:
                    guide = {}
                validation_plan = build_validation_plan(
                    off_payload,
                    off_target_report_sha256=hashlib.sha256(off_bytes).hexdigest(),
                    genome_sequences=genome_sequences if isinstance(genome_sequences, Mapping) else None,
                    experiment_spec=getattr(self._session.state, "experiment_spec", {}) if self._session else {},
                    guide=guide if isinstance(guide, Mapping) else None,
                    edit_plan=getattr(self._session.state, "edit_plan", {}) if self._session else None,
                    outcome_report=payload,
                )
                validation_sha = validation_plan_sha256(validation_plan)
                primer_plan = build_primer_plan(
                    validation_plan,
                    genome_sequences=genome_sequences if isinstance(genome_sequences, Mapping) else None,
                    validation_plan_sha256=validation_sha,
                    experiment_spec=getattr(self._session.state, "experiment_spec", {}) if self._session else {},
                    guide=guide if isinstance(guide, Mapping) else None,
                )
                for pair in primer_plan.get("primerPairs", []):
                    if not isinstance(pair, Mapping):
                        continue
                    if str(pair.get("hitKey") or "") != "primary_target":
                        continue
                    status = str(pair.get("status") or "")
                    fwd = pair.get("forwardPrimer")
                    rev = pair.get("reversePrimer")
                    amp_len = pair.get("ampliconLength")
                    if status and status != "ok":
                        notes = pair.get("notes") if isinstance(pair.get("notes"), list) else []
                        note_text = str(notes[0]) if notes else "design failed"
                        primer_label = f"Primary primers: failed — {note_text}"
                    elif fwd and rev:
                        amp_text = f"{int(amp_len)} bp" if amp_len is not None else "—"
                        primer_label = f"Primary primers: FWD {fwd} • REV {rev} • {amp_text}"
                    break
                assay_plan = build_assay_plan(
                    payload,
                    validation_plan,
                    primer_plan,
                    clone_plan,
                    experiment_spec=getattr(self._session.state, "experiment_spec", {}) or {},
                )
                primary = assay_plan.get("primary") if isinstance(assay_plan.get("primary"), Mapping) else {}
                assay = str(primary.get("recommendedAssay") or "—")
                assay_label = f"Recommended assay: {assay}"
                rationale = primary.get("rationale") if isinstance(primary.get("rationale"), list) else []
                if rationale:
                    rationale_text = "\n".join(f"• {line}" for line in rationale)
            except Exception:
                pass

        self._assay_label.setText(assay_label)
        if rationale_text:
            self._assay_rationale.setText(rationale_text)
            self._assay_rationale.show()
        else:
            self._assay_rationale.setText("")
            self._assay_rationale.hide()
        self._primary_primer_label.setText(primer_label)

        alleles = active_alleles if isinstance(active_alleles, list) else []
        rows: list[tuple[float, str, str, str, str, str | None]] = []
        other_row: tuple[float, str, str, str, str, None] | None = None
        for entry in alleles:
            if not isinstance(entry, Mapping):
                continue
            freq = entry.get("frequency") or 0.0
            try:
                freq_val = float(freq)
            except Exception:
                freq_val = 0.0
            delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
            kind_label, size, delta_str, is_other = _delta_to_display(delta)
            freq_str = f"{freq_val * 100:.2f}%"
            if is_other:
                other_row = (freq_val, delta_str, kind_label, size, freq_str, None)
            else:
                rows.append((freq_val, delta_str, kind_label, size, freq_str, allele_key_from_entry(entry)))

        rows.sort(key=lambda item: (-item[0], item[1]))
        if other_row is not None:
            if self._max_rows <= 1:
                rows = [other_row]
            else:
                rows = rows[: self._max_rows - 1] + [other_row]
        else:
            rows = rows[: self._max_rows]

        top_n = len(rows) - (1 if other_row is not None else 0)
        other_pct = (other_row[0] * 100.0) if other_row is not None else 0.0
        self._coverage_label.setText(f"Top {top_n} alleles shown, OTHER is {other_pct:.2f}%")

        self._row_keys = [row[5] for row in rows]
        self._table.setRowCount(len(rows))
        for idx, (_, delta_str, kind_label, size, freq_str, _key) in enumerate(rows, start=1):
            cells = [
                str(idx),
                kind_label,
                size,
                freq_str,
                delta_str,
            ]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self._table.setItem(idx - 1, col, item)

        show_cut_details = not (self._combined_selected and has_multiplex)
        if self._current_mode == "base":
            self._histogram_label_del.setText("Desired")
            self._histogram_label_ins.setText("Bystander")
            self._histogram_label_other.setText("Other")
        else:
            self._histogram_label_del.setText("Deletions")
            self._histogram_label_ins.setText("Insertions")
            self._histogram_label_other.setText("Other")
        self._coverage_container.setVisible(show_cut_details)
        self._table.setVisible(show_cut_details)
        self._histogram.setVisible(show_cut_details)
        self._histogram_legend.setVisible(show_cut_details)
        try:
            self._legend_container.setVisible(
                bool(show_cut_details)
                and self._hotspot_toggle.isChecked()
                and self._current_mode in {"cut", "prime", "base"}
            )
        except Exception:
            pass

        if show_cut_details:
            self._empty_label.setVisible(len(rows) == 0)
            self._apply_selection_status()
            buckets, other_freq = _build_histogram_data(alleles, mode=self._current_mode)
            self._histogram_data = {"buckets": buckets, "other": other_freq}
            self._histogram.set_data(buckets, other_freq)
        else:
            self._row_keys = []
            self._table.clearSelection()
            self._empty_label.hide()
            self._selection_label.hide()
            self._histogram_data = {"buckets": [], "other": 0.0}
            self._histogram.set_data([], 0.0)

        self._refresh_base_calibration_display()

    def _sync_mode_from_payload(self, payload: Mapping[str, Any]) -> None:
        prime_outcomes = payload.get("primeOutcomes") if isinstance(payload.get("primeOutcomes"), list) else []
        has_prime = bool(prime_outcomes)
        base_outcomes = payload.get("baseOutcomes") if isinstance(payload.get("baseOutcomes"), list) else []
        has_base = bool(base_outcomes)
        mode = self._mode_override
        if mode is None:
            if has_base:
                mode = "base"
            elif has_prime:
                mode = "prime"
            else:
                mode = "cut"
        if mode == "base" and not has_base:
            mode = "prime" if has_prime else "cut"
            self._mode_override = None
        if mode == "prime" and not has_prime:
            mode = "base" if has_base else "cut"
            self._mode_override = None
        self._set_mode(mode)
        idx = self._mode_selector.findData(mode)
        if idx >= 0 and self._mode_selector.currentIndex() != idx:
            self._syncing = True
            self._mode_selector.setCurrentIndex(idx)
            self._syncing = False

    def _set_mode(self, mode: str) -> None:
        mode_raw = str(mode)
        if mode_raw not in {"cut", "prime", "base"}:
            mode_raw = "cut"
        mode = mode_raw
        self._current_mode = mode
        self._cut_container.setVisible(mode in {"cut", "prime", "base"})
        self._prime_container.setVisible(mode == "prime")
        self._base_container.setVisible(mode == "base")
        try:
            self._cut_engine_row.setVisible(mode == "cut")
        except Exception:
            pass
        if mode != "cut":
            self._target_label.hide()
            self._target_selector.hide()
            self._multiplex_container.hide()
        try:
            self._legend_container.setVisible(self._hotspot_toggle.isChecked() and mode in {"cut", "prime", "base"})
        except Exception:
            pass

    def _render_prime_outcomes(self, payload: Mapping[str, Any]) -> None:
        prime_outcomes = payload.get("primeOutcomes") if isinstance(payload.get("primeOutcomes"), list) else []
        warnings = payload.get("primeWarnings") if isinstance(payload.get("primeWarnings"), list) else []
        if warnings:
            text = "\n".join(f"• {str(w)}" for w in warnings)
            self._prime_warning_label.setText(text)
            self._prime_warning_label.show()
        else:
            self._prime_warning_label.hide()
            self._prime_warning_label.setText("")

        category_map = {
            "desired_edit": ("Desired", "Desired edit incorporated"),
            "partial_edit": ("Partial", "Partial incorporation"),
            "rt_template_truncation": ("RT truncation", "RT template truncation"),
            "nick_indels": ("Nick indels", "Indels at nick site"),
            "pegRNA_failure": ("pegRNA failure", "pegRNA-related failure modes"),
        }
        order = {key: idx for idx, key in enumerate(category_map.keys())}

        rows: list[tuple[float, str, str, str]] = []
        desired_prob = 0.0
        total_prob = 0.0
        for entry in prime_outcomes:
            if not isinstance(entry, Mapping):
                continue
            category = str(entry.get("category") or "")
            prob = 0.0
            try:
                prob = float(entry.get("probability") or 0.0)
            except Exception:
                prob = 0.0
            label, desc = category_map.get(category, (category or "Unknown", ""))
            rows.append((prob, category, label, desc))
            if category == "desired_edit":
                desired_prob = prob
            total_prob += prob

        rows.sort(key=lambda r: (-r[0], order.get(r[1], 999), r[2]))
        self._prime_table.setRowCount(len(rows))
        for idx, (prob, _category, label, desc) in enumerate(rows):
            cells = [label, f"{prob * 100:.2f}%", desc]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self._prime_table.setItem(idx, col, item)

        byproducts = max(0.0, total_prob - desired_prob)
        self._prime_interpretation.setText(
            f"Predicted desired incorporation {desired_prob * 100:.2f}% • "
            f"Byproducts {byproducts * 100:.2f}%"
        )

    def _render_base_outcomes(self, payload: Mapping[str, Any]) -> None:
        base_outcomes = payload.get("baseOutcomes") if isinstance(payload.get("baseOutcomes"), list) else []
        warnings = payload.get("baseWarnings") if isinstance(payload.get("baseWarnings"), list) else []
        if warnings:
            text = "\n".join(f"• {str(w)}" for w in warnings)
            self._base_warning_label.setText(text)
            self._base_warning_label.show()
        else:
            self._base_warning_label.hide()
            self._base_warning_label.setText("")

        category_map = {
            "desired_edit": ("Desired", "Desired edit incorporated"),
            "bystander_edit": ("Bystander", "Bystander edits in window"),
            "off_target_deamination": ("Off target", "Off-target deamination proxy"),
            "failure": ("Failure", "No edit detected"),
        }
        rows: list[tuple[float, str, str, str]] = []
        desired_prob = 0.0
        bystander_prob = 0.0
        for entry in base_outcomes:
            if not isinstance(entry, Mapping):
                continue
            category = str(entry.get("category") or "")
            prob = 0.0
            try:
                prob = float(entry.get("probability") or 0.0)
            except Exception:
                prob = 0.0
            label, desc = category_map.get(category, (category or "Unknown", ""))
            rows.append((prob, category, label, desc))
            if category == "desired_edit":
                desired_prob = prob
            if category == "bystander_edit":
                bystander_prob = prob

        rows.sort(key=lambda r: (-r[0], r[1]))
        self._base_table.setRowCount(len(rows))
        for idx, (prob, _category, label, desc) in enumerate(rows):
            cells = [label, f"{prob * 100:.2f}%", desc]
            for col, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                self._base_table.setItem(idx, col, item)

        lines: list[str] = []
        base_editor = payload.get("baseEditor") if isinstance(payload.get("baseEditor"), Mapping) else {}
        editor_type = str(base_editor.get("editorType") or "").strip()
        try:
            window_start = int(base_editor.get("windowStart"))
        except Exception:
            window_start = None
        try:
            window_end = int(base_editor.get("windowEnd"))
        except Exception:
            window_end = None
        target_base = str(base_editor.get("targetBase") or "").strip()
        if editor_type and window_start is not None and window_end is not None:
            if target_base:
                lines.append(f"Editor {editor_type} window {window_start}-{window_end} (target {target_base})")
            else:
                lines.append(f"Editor {editor_type} window {window_start}-{window_end}")
        elif editor_type:
            lines.append(f"Editor {editor_type}")
        editable_count = base_editor.get("editableCount")
        if editable_count is not None:
            try:
                editable_count = int(editable_count)
            except Exception:
                pass
            lines.append(f"Editable positions: {editable_count} (per-position probabilities shown)")
        lines.append(f"Predicted desired edit: {desired_prob * 100:.2f}%")
        lines.append(f"Predicted bystander edits: {bystander_prob * 100:.2f}%")
        self._base_interpretation.setText("\n".join(lines))

    def _apply_selection_status(self) -> None:
        if self._current_mode not in {"cut", "prime", "base"}:
            self._table.clearSelection()
            self._selection_label.hide()
            return
        if self._combined_selected:
            self._table.clearSelection()
            self._selection_label.hide()
            return
        if not self._row_keys:
            self._table.clearSelection()
            self._selection_label.hide()
            return
        if self._selected_key and self._selected_key in self._row_keys:
            row = self._row_keys.index(self._selected_key)
            self._table.selectRow(row)
            self._selection_label.setText(
                f"Highlighting allele rank {row + 1}, click again to clear"
            )
            self._selection_label.show()
        elif self._selected_key:
            self._table.clearSelection()
            self._selection_label.setText("Highlighting selected allele, click again to clear")
            self._selection_label.show()
        else:
            self._table.clearSelection()
            self._selection_label.hide()


def _legend_swatch(color: str, alpha: int = 255) -> QWidget:
    swatch = QFrame()
    swatch.setFixedSize(10, 10)
    try:
        alpha = max(0, min(255, int(alpha)))
    except Exception:
        alpha = 255
    if alpha >= 255:
        style = f"background:{color}; border-radius:2px;"
    else:
        rgb = color.lstrip("#")
        try:
            r = int(rgb[0:2], 16)
            g = int(rgb[2:4], 16)
            b = int(rgb[4:6], 16)
            style = f"background: rgba({r}, {g}, {b}, {alpha}); border-radius:2px;"
        except Exception:
            style = f"background:{color}; border-radius:2px;"
    swatch.setStyleSheet(style)
    return swatch


def _build_histogram_data(alleles: list[Any], *, mode: str = "cut") -> tuple[list[dict[str, Any]], float]:
    buckets: dict[int, dict[str, Any]] = {}
    other_freq = 0.0
    mode = str(mode or "cut").lower()
    for entry in alleles:
        if not isinstance(entry, Mapping):
            continue
        freq = entry.get("frequency") or 0.0
        try:
            freq_val = float(freq)
        except Exception:
            continue
        delta = entry.get("sequenceDelta") if isinstance(entry.get("sequenceDelta"), Mapping) else {}
        kind = str(delta.get("type") or "").lower().strip()
        if kind == "other":
            other_freq += freq_val
            continue
        if mode == "base":
            if kind != "base_substitution":
                other_freq += freq_val
                continue
            pos_val = delta.get("pos")
            size = None
            if pos_val is not None:
                try:
                    size = int(pos_val)
                except Exception:
                    size = None
            if size is None:
                start_val = delta.get("start")
                try:
                    size = int(start_val)
                except Exception:
                    size = None
            if size is None:
                other_freq += freq_val
                continue
            bucket = buckets.setdefault(size, {"size": size, "del": 0.0, "ins": 0.0})
            role = str(delta.get("role") or delta.get("label") or "").lower()
            key = "del" if "desired" in role else "ins"
            bucket[key] += freq_val
            continue
        if kind not in {"del", "ins"}:
            other_freq += freq_val
            continue
        length = delta.get("length")
        if length is None and kind == "ins":
            seq = str(delta.get("sequence") or "")
            length = len(seq)
        try:
            length_int = int(length)
        except Exception:
            continue
        if length_int <= 0:
            continue
        bucket = buckets.setdefault(length_int, {"size": length_int, "del": 0.0, "ins": 0.0})
        key = "del" if kind == "del" else "ins"
        bucket[key] += freq_val
    ordered = [buckets[k] for k in sorted(buckets.keys())]
    return ordered, other_freq


class OutcomeSpectrumHistogram(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._buckets: list[dict[str, Any]] = []
        self._other_freq = 0.0

    def set_data(self, buckets: list[dict[str, Any]], other_freq: float) -> None:
        self._buckets = list(buckets)
        self._other_freq = float(other_freq)
        self.update()

    def paintEvent(self, event) -> None:  # type: ignore[override]
        from PySide6.QtGui import QColor, QPainter, QPen

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, False)

        rect = self.rect()
        painter.fillRect(rect, QColor("#0b1220"))

        margin_x = 8
        margin_top = 6
        margin_bottom = 18
        axis_y = rect.bottom() - margin_bottom
        plot_height = max(1, axis_y - rect.top() - margin_top)
        left = rect.left() + margin_x
        right = rect.right() - margin_x
        available = max(1, right - left)

        buckets = self._buckets
        has_other = self._other_freq > 0.0
        total_groups = len(buckets) + (1 if has_other else 0)
        if total_groups <= 0:
            return

        max_freq = 0.0
        for b in buckets:
            max_freq = max(max_freq, float(b.get("del") or 0.0), float(b.get("ins") or 0.0))
        if has_other:
            max_freq = max(max_freq, float(self._other_freq))
        if max_freq <= 0.0:
            return

        base = available // total_groups
        extra = available % total_groups
        group_widths = [base + (1 if i < extra else 0) for i in range(total_groups)]

        del_color = QColor("#ef4444")
        ins_color = QColor("#3b82f6")
        other_color = QColor("#94a3b8")

        painter.setPen(QPen(QColor("#1f2937")))
        painter.drawLine(left, axis_y, right, axis_y)

        x = left
        for idx in range(total_groups):
            width = group_widths[idx]
            group_left = x
            group_right = x + width
            x = group_right

            is_other = has_other and idx == total_groups - 1
            if is_other:
                bar_width = max(1, width // 2)
                bar_x = group_left + (width - bar_width) // 2
                bar_h = int(round((self._other_freq / max_freq) * plot_height))
                bar_y = axis_y - bar_h
                painter.fillRect(bar_x, bar_y, bar_width, bar_h, other_color)
                painter.setPen(QColor("#9ca3af"))
                painter.drawText(bar_x, rect.bottom() - 2, "OTHER")
                continue

            bucket = buckets[idx]
            gap = max(1, width // 10)
            bar_width = max(1, (width - gap) // 2)
            total_bar_width = bar_width * 2 + gap
            bar_left = group_left + (width - total_bar_width) // 2

            del_freq = float(bucket.get("del") or 0.0)
            ins_freq = float(bucket.get("ins") or 0.0)
            del_h = int(round((del_freq / max_freq) * plot_height))
            ins_h = int(round((ins_freq / max_freq) * plot_height))
            if del_h > 0:
                painter.fillRect(bar_left, axis_y - del_h, bar_width, del_h, del_color)
            if ins_h > 0:
                painter.fillRect(bar_left + bar_width + gap, axis_y - ins_h, bar_width, ins_h, ins_color)

            label = str(bucket.get("size"))
            painter.setPen(QColor("#9ca3af"))
            painter.drawText(group_left + 2, rect.bottom() - 2, label)



__all__ = ["OutcomeSpectrumPanel"]
