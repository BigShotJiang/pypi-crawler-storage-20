from __future__ import annotations

import json
import logging
from enum import Enum
from pathlib import Path
from typing import Any, Mapping, Optional, Tuple

EDIT_PLAN_SCHEMA_ID = "helix_edit_plan_v1"

MODE_VALUES = (
    "cut",
    "prime",
    "base",
    "multiplex",
)

LOGGER = logging.getLogger(__name__)

try:  # pragma: no cover - optional dependency
    from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

    PYDANTIC_AVAILABLE = True
except Exception:  # pragma: no cover - fallback path
    BaseModel = object  # type: ignore
    ValidationError = Exception  # type: ignore
    PYDANTIC_AVAILABLE = False


def _schema_path() -> Path:
    return Path(__file__).resolve().parents[3] / "schemas" / "edit_plan" / "helix_edit_plan_v1.json"


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (json.dumps(payload, sort_keys=True, indent=2, separators=(",", ": "), ensure_ascii=False) + "\n").encode(
        "utf-8"
    )


def _default_plan_dict() -> dict[str, Any]:
    return {
        "schema": EDIT_PLAN_SCHEMA_ID,
        "mode": "cut",
        "targets": [],
        "notes": [],
    }


if PYDANTIC_AVAILABLE:

    class Mode(str, Enum):
        CUT = "cut"
        PRIME = "prime"
        BASE = "base"
        MULTIPLEX = "multiplex"


    class _BasePlanModel(BaseModel):
        model_config = ConfigDict(extra="allow", populate_by_name=True)


    class GuideRNA(_BasePlanModel):
        sequence: str = ""
        pam: str = ""
        pam_class: Optional[str] = Field(default=None, alias="pamClass")


    class EditTarget(_BasePlanModel):
        target_id: Optional[str] = Field(default=None, alias="targetId")
        label: Optional[str] = None
        role: Optional[str] = None
        strand: str = "+"
        cut_index: Optional[int] = Field(default=None, alias="cutIndex")
        pam_class: Optional[str] = Field(default=None, alias="pamClass")
        grna: GuideRNA = Field(default_factory=GuideRNA, alias="gRNA")

        @field_validator("strand", mode="before")
        @classmethod
        def _coerce_strand(cls, value: Any) -> Any:
            if isinstance(value, str):
                value = value.strip()
                if value in {"+", "-"}:
                    return value
            return value


    class EditPlanV1(_BasePlanModel):
        schema_: str = Field(default=EDIT_PLAN_SCHEMA_ID, alias="schema")
        mode: Mode | str = Mode.CUT
        targets: list[EditTarget] = Field(default_factory=list)
        notes: list[str] = Field(default_factory=list)

        @field_validator("mode", mode="before")
        @classmethod
        def _coerce_mode(cls, value: Any) -> Any:
            if isinstance(value, str):
                return value.strip().lower()
            return value

        @field_validator("targets", mode="before")
        @classmethod
        def _coerce_targets(cls, value: Any) -> Any:
            if value is None:
                return []
            return value

        @property
        def schema(self) -> str:
            return self.schema_


def default_edit_plan() -> dict[str, Any]:
    if PYDANTIC_AVAILABLE:
        model = EditPlanV1()
        return model.model_dump(exclude_none=True, by_alias=True)
    return json.loads(json.dumps(_default_plan_dict()))


def edit_plan_from_dict_with_error(data: Mapping[str, Any] | None) -> Tuple[dict[str, Any], str | None]:
    if data is None or not isinstance(data, Mapping):
        return default_edit_plan(), None
    if PYDANTIC_AVAILABLE:
        try:
            model = EditPlanV1.model_validate(data)
            return model.model_dump(exclude_none=True, by_alias=True), None
        except ValidationError as exc:
            LOGGER.warning("EditPlan validation failed, using best-effort merge: %s", exc)
            merged = _default_plan_dict()
            merged.update({k: v for k, v in data.items()})
            merged.setdefault("schema", EDIT_PLAN_SCHEMA_ID)
            return merged, str(exc)
    merged = _default_plan_dict()
    merged.update({k: v for k, v in data.items()})
    merged.setdefault("schema", EDIT_PLAN_SCHEMA_ID)
    return merged, None


def edit_plan_from_dict(data: Mapping[str, Any] | None) -> dict[str, Any]:
    plan, _err = edit_plan_from_dict_with_error(data)
    return plan


def edit_plan_to_dict(data: Any) -> dict[str, Any]:
    if PYDANTIC_AVAILABLE and isinstance(data, EditPlanV1):
        return data.model_dump(exclude_none=True, by_alias=True)
    if isinstance(data, Mapping):
        return edit_plan_from_dict(data)
    if data is None:
        return default_edit_plan()
    return edit_plan_from_dict({})


def edit_plan_json_bytes(data: Any) -> bytes:
    payload = edit_plan_to_dict(data)
    return _canonical_json_bytes(payload)


def edit_plan_sha256(data: Any) -> str:
    import hashlib

    return hashlib.sha256(edit_plan_json_bytes(data)).hexdigest()


def edit_plan_json_schema() -> dict[str, Any]:
    if PYDANTIC_AVAILABLE:
        return EditPlanV1.model_json_schema()
    try:
        from importlib import resources

        schema_text = resources.files("helix.schema").joinpath("edit_plan/helix_edit_plan_v1.json").read_text(
            encoding="utf-8"
        )
        return json.loads(schema_text)
    except Exception:
        pass
    path = _schema_path()
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return {}


def derive_edit_plan_from_legacy_config(
    config: Mapping[str, Any] | None,
    *,
    experiment_spec: Mapping[str, Any] | None = None,
) -> dict[str, Any] | None:
    if not isinstance(config, Mapping):
        return None
    guide = config.get("guide")
    if not isinstance(guide, Mapping):
        guide = {}

    fields_used: set[str] = set()

    def _pick(mapping: Mapping[str, Any], key: str) -> Any:
        if key in mapping:
            val = mapping.get(key)
            if val is not None and (not isinstance(val, str) or val.strip() != ""):
                fields_used.add(f"config.guide.{key}")
                return val
        return None

    def _pick_config(key: str) -> Any:
        if key in config:
            val = config.get(key)
            if val is not None and (not isinstance(val, str) or val.strip() != ""):
                fields_used.add(f"config.{key}")
                return val
        return None

    guide_seq = _pick(guide, "sequence")
    if guide_seq is None:
        guide_seq = _pick(guide, "guideSequence")
    guide_seq = str(guide_seq or "").strip()

    pam_pattern = _pick(guide, "pam")
    if pam_pattern is None:
        pam_pattern = _pick(guide, "pam_pattern")
    if pam_pattern is None:
        pam_pattern = _pick_config("pam_profile") or _pick_config("pamProfile")
    pam_pattern = str(pam_pattern or "").strip()

    pam_class = (
        _pick(guide, "pamClass")
        or _pick(guide, "pam_class")
        or _pick_config("pamClass")
        or _pick_config("pam_class")
        or _pick_config("pam_profile")
        or _pick_config("pamProfile")
    )
    pam_class = str(pam_class or "").strip() or "SpCas9-NGG"

    cut_index = _pick(guide, "cut_index")
    if cut_index is None:
        cut_index = _pick(guide, "cutIndex")
    if cut_index is None:
        pam_index = _pick(guide, "pam_index")
        if pam_index is None:
            pam_index = _pick(guide, "pamIndex")
        if pam_index is not None:
            try:
                cut_index = int(pam_index) - 3
            except Exception:
                cut_index = None
    try:
        cut_index = int(cut_index) if cut_index is not None else None
    except Exception:
        cut_index = None

    contig = _pick(guide, "contig") or _pick(guide, "chr") or _pick(guide, "chrom")
    contig = str(contig or "").strip()
    start = _pick(guide, "start")
    end = _pick(guide, "end")

    locus = _pick(guide, "locus")
    if (not contig or start is None or end is None) and locus:
        try:
            from helix.studio.lightcone_live import parse_target_locus_range

            loc_contig, loc_start, loc_end = parse_target_locus_range(str(locus))
            contig = contig or loc_contig
            if start is None:
                start = loc_start
            if end is None:
                end = loc_end
        except Exception:
            pass

    try:
        start = int(start) if start is not None else None
    except Exception:
        start = None
    try:
        end = int(end) if end is not None else None
    except Exception:
        end = None

    strand = _pick(guide, "strand")
    strand = str(strand or "").strip()
    if strand not in {"+", "-"}:
        strand = "+"

    label = _pick(guide, "name") or _pick(guide, "id")
    label = str(label or "").strip() or "primary"

    if not fields_used:
        return None

    mode = _infer_mode(config, experiment_spec)

    target: dict[str, Any] = {
        "targetId": "primary",
        "label": label,
        "role": "primary",
        "strand": strand,
        "cutIndex": cut_index,
        "pamClass": pam_class,
        "gRNA": {
            "sequence": guide_seq,
            "pam": pam_pattern,
        },
    }
    if contig:
        target["contig"] = contig
    if start is not None:
        target["start"] = int(start)
    if end is not None:
        target["end"] = int(end)

    plan = {
        "schema": EDIT_PLAN_SCHEMA_ID,
        "mode": mode,
        "targets": [target],
        "notes": [],
        "meta": {
            "source": "legacy_config_bridge_v1",
            "fieldsUsed": sorted(fields_used),
        },
    }
    return edit_plan_to_dict(plan)


def _infer_mode(config: Mapping[str, Any], experiment_spec: Mapping[str, Any] | None) -> str:
    sim_type = str(config.get("sim_type") or "").strip().lower()
    if "prime" in sim_type:
        return "prime"
    if "base" in sim_type:
        return "base"
    if "multiplex" in sim_type:
        return "multiplex"
    if "crispr" in sim_type or "cut" in sim_type:
        return "cut"

    if isinstance(config.get("prime"), Mapping):
        return "prime"
    if any(k in config for k in ("base", "base_edit", "baseEdit")):
        return "base"

    spec = experiment_spec if isinstance(experiment_spec, Mapping) else {}
    intent = str(spec.get("intent") or "").strip().lower()
    if intent == "prime_edit":
        return "prime"
    if intent in {"base_edit", "base", "base-edit"}:
        return "base"
    if intent == "multiplex":
        return "multiplex"
    modalities = spec.get("editModalities") if isinstance(spec.get("editModalities"), list) else []
    for modality in modalities:
        mod = str(modality or "").lower()
        if "prime" in mod:
            return "prime"
        if "base" in mod:
            return "base"
        if "multiplex" in mod:
            return "multiplex"
    return "cut"


__all__ = [
    "EDIT_PLAN_SCHEMA_ID",
    "EditPlanV1",
    "default_edit_plan",
    "derive_edit_plan_from_legacy_config",
    "edit_plan_from_dict",
    "edit_plan_from_dict_with_error",
    "edit_plan_json_bytes",
    "edit_plan_json_schema",
    "edit_plan_sha256",
    "edit_plan_to_dict",
]
