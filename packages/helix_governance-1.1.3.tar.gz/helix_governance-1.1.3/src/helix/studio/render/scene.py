"""
GenomeScene: lightweight render owner for field-based lanes (e.g., PAM+seed heat).

This module is intentionally isolated and optional; importing it requires moderngl.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional, Tuple

import numpy as np

try:
    import moderngl
except Exception:  # pragma: no cover - optional dependency
    moderngl = None  # type: ignore

from helix.gpu.fields import (
    FieldRegistry,
    PamSeedFieldOp,
    PrimeDpFieldOp,
    IndelRiskFieldOp,
    OfftargetDensityFieldOp,
    CompositeEditabilityFieldOp,
    GcHomopolymerFieldOp,
    Dcas9OccupancyFieldOp,
)
from helix.gpu.fields.base import TileSpec
from helix.studio.evs_bridge import GuideContext, PrimeContext


class GenomeScene:
    """
    Owns a FieldRegistry and renders lanes into a supplied moderngl.Context.
    """

    def __init__(self, ctx: "moderngl.Context", shader_root: Path) -> None:
        if moderngl is None:
            raise RuntimeError("moderngl is required for GenomeScene")
        self.ctx = ctx
        self.shader_root = Path(shader_root)

        self.fields = FieldRegistry(ctx=self.ctx)
        heatmap_dir = self.shader_root / "heatmap"
        self.fields.register(
            PamSeedFieldOp(
                ctx=self.ctx,
                shader_dir=str(heatmap_dir),
            )
        )
        self.fields.register(
            PrimeDpFieldOp(
                ctx=self.ctx,
                shader_dir=str(heatmap_dir),
            )
        )
        self.fields.register(
            IndelRiskFieldOp(
                ctx=self.ctx,
                shader_dir=str(heatmap_dir),
            )
        )
        self.fields.register(
            OfftargetDensityFieldOp(
                ctx=self.ctx,
                shader_dir=str(heatmap_dir),
            )
        )
        self.fields.register(
            CompositeEditabilityFieldOp(
                ctx=self.ctx,
                shader_dir=str(heatmap_dir),
            )
        )
        self.fields.register(
            GcHomopolymerFieldOp(
                ctx=self.ctx,
                shader_dir=str(heatmap_dir),
            )
        )
        self.fields.register(
            Dcas9OccupancyFieldOp(
                ctx=self.ctx,
                shader_dir=str(heatmap_dir),
            )
        )

        self._current_tile: Optional[TileSpec] = None
        self._current_seq_slice: Optional[str] = None
        self._current_guide_ctx: Optional[GuideContext] = None
        self._current_prime_ctx: Optional[PrimeContext] = None
        self._pam_scores = None
        self._prime_scores = None
        self._indel_scores = None
        self._offtarget_scores = None
        self._gc_scores = None
        self._dcas_scores = None
        self._pam_seed_enabled: bool = True
        self._prime_dp_enabled: bool = True
        self._indel_risk_enabled: bool = False  # off by default until tuned
        self._offtarget_enabled: bool = False
        self._composite_enabled: bool = False  # summary lane, opt-in for now
        self._gc_enabled: bool = False  # GC/homopolymer stress
        self._dcas_enabled: bool = False

    def set_pam_seed_enabled(self, enabled: bool) -> None:
        self._pam_seed_enabled = bool(enabled)

    def pam_seed_enabled(self) -> bool:
        return self._pam_seed_enabled

    def set_prime_dp_enabled(self, enabled: bool) -> None:
        self._prime_dp_enabled = bool(enabled)

    def set_indel_risk_enabled(self, enabled: bool) -> None:
        self._indel_risk_enabled = bool(enabled)

    def set_offtarget_enabled(self, enabled: bool) -> None:
        self._offtarget_enabled = bool(enabled)

    def set_composite_enabled(self, enabled: bool) -> None:
        self._composite_enabled = bool(enabled)

    def set_gc_enabled(self, enabled: bool) -> None:
        self._gc_enabled = bool(enabled)

    def set_dcas_enabled(self, enabled: bool) -> None:
        self._dcas_enabled = bool(enabled)

    def update_pam_seed_field(
        self,
        chrom: str,
        tile_start_bp: int,
        tile_seq: str,
        guide_seq: str,
        pam_pattern: str = "NGG",
    ) -> None:
        if not self._pam_seed_enabled:
            return
        tile = TileSpec(chrom=chrom, tile_start_bp=tile_start_bp, tile_len_bp=len(tile_seq))
        params = {
            "guide": guide_seq,
            "pam_pattern": pam_pattern,
            "mismatch_penalty": 1.0,
            "pam_bonus": 3.0,
            "score_scale": 1.0,
        }
        self._pam_scores = self.fields.compute_field("pam_seed", tile, tile_seq, params)
        self._current_tile = tile
        self._current_seq_slice = tile_seq
        self._current_guide_ctx = GuideContext(guide_seq=guide_seq, pam_pattern=pam_pattern)

    def update_prime_dp_field(
        self,
        chrom: str,
        tile_start_bp: int,
        tile_seq: str,
        prime_ctx: PrimeContext,
    ) -> None:
        if not self._prime_dp_enabled:
            return
        tile = TileSpec(chrom=chrom, tile_start_bp=tile_start_bp, tile_len_bp=len(tile_seq))
        params = {
            "rt_template": prime_ctx.rt_template,
            "nick_pos_bp": prime_ctx.nick_pos_bp,
            "mismatch_penalty": 1.0,
            "gap_penalty": 1.0,
            "extension_bonus": 1.0,
            "max_extension": len(prime_ctx.rt_template),
        }
        self._prime_scores = self.fields.compute_field("prime_dp", tile, tile_seq, params)
        self._current_prime_ctx = prime_ctx
        self._current_tile = tile
        self._current_seq_slice = tile_seq

    def update_indel_risk_field(
        self,
        chrom: str,
        tile_start_bp: int,
        tile_seq: str,
    ) -> None:
        if not self._indel_risk_enabled:
            return
        tile = TileSpec(chrom=chrom, tile_start_bp=tile_start_bp, tile_len_bp=len(tile_seq))
        params = {
            "repeat_penalty": 0.2,
            "microhomology_bonus": 0.5,
            "max_window": 12,
        }
        self._indel_scores = self.fields.compute_field("indel_risk", tile, tile_seq, params)
        self._current_tile = tile
        self._current_seq_slice = tile_seq

    def update_offtarget_field(
        self,
        chrom: str,
        tile_start_bp: int,
        tile_seq: str,
        guide_seq: str,
        pam_pattern: str = "NGG",
    ) -> None:
        if not self._offtarget_enabled:
            return
        tile = TileSpec(chrom=chrom, tile_start_bp=tile_start_bp, tile_len_bp=len(tile_seq))
        params = {
            "guide": guide_seq,
            "pam_pattern": pam_pattern,
            "mismatch_penalty": 1.0,
            "score_scale": 1.0,
        }
        self._offtarget_scores = self.fields.compute_field("offtarget_density", tile, tile_seq, params)
        self._current_tile = tile
        self._current_seq_slice = tile_seq

    def update_gc_field(
        self,
        chrom: str,
        tile_start_bp: int,
        tile_seq: str,
    ) -> None:
        if not self._gc_enabled:
            return
        tile = TileSpec(chrom=chrom, tile_start_bp=tile_start_bp, tile_len_bp=len(tile_seq))
        params = {
            "window": 25,
            "gc_weight": 1.0,
            "hp_weight": 1.0,
            "normalize": False,
        }
        self._gc_scores = self.fields.compute_field("gc_homopolymer", tile, tile_seq, params)
        self._current_tile = tile
        self._current_seq_slice = tile_seq

    def update_dcas_field(
        self,
        chrom: str,
        tile_start_bp: int,
        tile_seq: str,
        guide_seq: str,
        pam_pattern: str = "NGG",
    ) -> None:
        if not self._dcas_enabled:
            return
        tile = TileSpec(chrom=chrom, tile_start_bp=tile_start_bp, tile_len_bp=len(tile_seq))
        params = {
            "guide": guide_seq,
            "pam_pattern": pam_pattern,
            "mismatch_penalty": 1.0,
            "pam_penalty": 1.0,
            "pam_bonus": 3.0,
            "score_scale": 1.0,
        }
        self._dcas_scores = self.fields.compute_field("dcas9_occupancy", tile, tile_seq, params)
        self._current_tile = tile
        self._current_seq_slice = tile_seq

    def update_composite_field(
        self,
        chrom: str,
        tile_start_bp: int,
        tile_seq: str,
    ) -> None:
        if not self._composite_enabled:
            return
        tile = TileSpec(chrom=chrom, tile_start_bp=tile_start_bp, tile_len_bp=len(tile_seq))
        n = tile.tile_len_bp

        def _nz(arr):
            if arr is None:
                return None
            return arr

        pam = _nz(self._pam_scores)
        prime = _nz(self._prime_scores)
        indel = _nz(self._indel_scores)
        off = _nz(self._offtarget_scores)

        def _fit(arr):
            if arr is None:
                return None
            if arr.shape[0] == n:
                return arr
            out = np.zeros(n, dtype=np.float32)
            m = min(n, arr.shape[0])
            out[:m] = arr[:m]
            return out

        pam = _fit(pam) if pam is not None else np.zeros(n, dtype=np.float32)
        prime = _fit(prime) if prime is not None else np.zeros(n, dtype=np.float32)
        indel = _fit(indel) if indel is not None else np.zeros(n, dtype=np.float32)
        off = _fit(off) if off is not None else np.zeros(n, dtype=np.float32)

        params = {
            "pam": pam,
            "prime": prime,
            "indel": indel,
            "off": off,
            "pam_weight": 1.0,
            "prime_weight": 1.0,
            "indel_weight": 1.0,
            "off_weight": 1.0,
            "normalize": False,
        }
        self.fields.compute_field("composite_editability", tile, tile_seq, params)
        self._current_tile = tile
        self._current_seq_slice = tile_seq

    def render(self, width: int, height: int) -> None:
        if not (
            self._pam_seed_enabled
            or self._prime_dp_enabled
            or self._indel_risk_enabled
            or self._offtarget_enabled
            or self._composite_enabled
            or self._gc_enabled
            or self._dcas_enabled
        ):
            return

        # Simple layout: bottom lanes with fixed height fraction
        lane_height = max(32, int(height * 0.08))

        lanes_drawn = 0

        # Indel risk lane (topmost if enabled)
        if self._indel_risk_enabled:
            indel_vp: Tuple[int, int, int, int] = (0, lane_height * lanes_drawn, width, lane_height)
            try:
                self.fields.render_field("indel_risk", indel_vp)
                lanes_drawn += 1
            except Exception:
                pass

        # Off-target density lane
        if self._offtarget_enabled:
            ot_vp: Tuple[int, int, int, int] = (0, lane_height * lanes_drawn, width, lane_height)
            try:
                self.fields.render_field("offtarget_density", ot_vp)
                lanes_drawn += 1
            except Exception:
                pass

        # Composite editability lane
        if self._composite_enabled:
            comp_vp: Tuple[int, int, int, int] = (0, lane_height * lanes_drawn, width, lane_height)
            try:
                self.fields.render_field("composite_editability", comp_vp)
                lanes_drawn += 1
            except Exception:
                pass

        # GC/homopolymer lane
        if self._gc_enabled:
            gc_vp: Tuple[int, int, int, int] = (0, lane_height * lanes_drawn, width, lane_height)
            try:
                self.fields.render_field("gc_homopolymer", gc_vp)
                lanes_drawn += 1
            except Exception:
                pass

        # dCas9 occupancy lane
        if self._dcas_enabled:
            dcas_vp: Tuple[int, int, int, int] = (0, lane_height * lanes_drawn, width, lane_height)
            try:
                self.fields.render_field("dcas9_occupancy", dcas_vp)
                lanes_drawn += 1
            except Exception:
                pass

        # Prime DP lane
        if self._prime_dp_enabled:
            prime_vp: Tuple[int, int, int, int] = (0, lane_height * lanes_drawn, width, lane_height)
            try:
                self.fields.render_field("prime_dp", prime_vp)
                lanes_drawn += 1
            except Exception:
                pass

        # PAM lane at the bottom of the stack
        if self._pam_seed_enabled:
            pam_vp: Tuple[int, int, int, int] = (0, lane_height * lanes_drawn, width, lane_height)
            try:
                self.fields.render_field("pam_seed", pam_vp)
            except Exception:
                pass
