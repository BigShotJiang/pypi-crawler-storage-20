from __future__ import annotations

import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import urljoin

from helix import clock
DOCS_BASE_URL_ENV = "DOCS_BASE_URL"
DOCS_BASE_URL_ENV_FALLBACK = "HELIX_DOCS_BASE_URL"

LIMITATIONS_DOC_SLUG = "crispr_edit_dag_limitations"
LIMITATIONS_DOC_VERSION = "1.0"
LIMITATIONS_DOC_LAST_UPDATED = "2025-12-26"
LIMITATIONS_DOC_PATH = "model_limitations/crispr_edit_dag_limitations/"

LIMITATIONS_BANNER = (
    "Limitations apply: CRISPR Edit DAG model is not validated for kinetic or safety-critical prediction."
)

LIMITATIONS_SUMMARY: tuple[str, ...] = (
    "DSBs are modeled as instantaneous transitions; kinetics and latent repairable states are not represented.",
    "Probability mass is conserved within modeled outcomes; cell death and large-scale genome instability are out-of-scope.",
    "No Edit collapses multiple failure modes; do not interpret as a single mechanism.",
    "PAM softness is an abstract knob; not delta G or kinetics; not validated for prediction.",
    "Dominant-path highlighting is a convenience; tail risks are not visualized.",
)

_SITE_URL_RE = re.compile(r"^site_url\s*:\s*(.+)$")


def _utc_now_iso() -> str:
    return clock.utc_now_iso()


def _normalize_base_url(raw: str | None) -> str | None:
    if not raw:
        return None
    value = raw.strip()
    if not value:
        return None
    if not value.endswith("/"):
        value = value + "/"
    return value


def _find_repo_root() -> Path | None:
    for parent in Path(__file__).resolve().parents:
        if (parent / "mkdocs.yml").exists():
            return parent
    return None


def _read_site_url(mkdocs_path: Path) -> str | None:
    try:
        text = mkdocs_path.read_text(encoding="utf-8")
    except Exception:
        return None
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        match = _SITE_URL_RE.match(stripped)
        if not match:
            continue
        value = match.group(1).strip().strip("\"").strip("'")
        return value or None
    return None


def resolve_docs_base_url() -> str | None:
    for key in (DOCS_BASE_URL_ENV, DOCS_BASE_URL_ENV_FALLBACK):
        env_val = _normalize_base_url(os.getenv(key, ""))
        if env_val:
            return env_val
    root = _find_repo_root()
    if root is None:
        return None
    site_url = _read_site_url(root / "mkdocs.yml")
    return _normalize_base_url(site_url)


def limitations_doc_url() -> str | None:
    base = resolve_docs_base_url()
    if not base:
        return None
    return urljoin(base, LIMITATIONS_DOC_PATH)


def limitations_stamp(now: datetime | None = None) -> dict[str, Any]:
    timestamp = now.isoformat().replace("+00:00", "Z") if now is not None else clock.utc_now_iso()
    stamp: dict[str, Any] = {
        "doc_slug": LIMITATIONS_DOC_SLUG,
        "doc_version": LIMITATIONS_DOC_VERSION,
        "doc_last_updated": LIMITATIONS_DOC_LAST_UPDATED,
        "timestamp_utc": timestamp,
        "banner": LIMITATIONS_BANNER,
    }
    url = limitations_doc_url()
    if url:
        stamp["doc_url"] = url
    return stamp


def limitations_stamp_lines(stamp: Mapping[str, Any]) -> list[str]:
    lines = [
        f"limitations_banner: {stamp.get('banner', '')}",
        f"limitations_doc: {stamp.get('doc_slug', '')}@{stamp.get('doc_version', '')}",
        f"limitations_last_updated: {stamp.get('doc_last_updated', '')}",
        f"limitations_timestamp_utc: {stamp.get('timestamp_utc', '')}",
    ]
    url = stamp.get("doc_url")
    if url:
        lines.append(f"limitations_url: {url}")
    return lines


def limitations_csv_prefix(stamp: Mapping[str, Any]) -> str:
    lines = [f"# {line}" for line in limitations_stamp_lines(stamp)]
    return "\n".join(lines) + "\n"


def limitations_copy_text() -> str:
    url = limitations_doc_url()
    if url:
        return url
    root = _find_repo_root()
    if root is not None:
        local = root / "docs" / "model_limitations" / "crispr_edit_dag_limitations.md"
        if local.exists():
            return str(local)
    return f"Set {DOCS_BASE_URL_ENV} to publish documentation links."


def open_limitations(parent=None) -> None:
    url = limitations_doc_url()
    if url:
        try:
            from PySide6.QtCore import QUrl
            from PySide6.QtGui import QDesktopServices

            QDesktopServices.openUrl(QUrl(url))
            return
        except Exception:
            pass
    try:
        from helix.studio.ui.limitations_dialog import LimitationsDialog

        dialog = LimitationsDialog(
            summary_lines=LIMITATIONS_SUMMARY,
            banner=LIMITATIONS_BANNER,
            link_url=url,
            copy_text=limitations_copy_text(),
            parent=parent,
        )
        dialog.exec()
    except Exception:
        return


__all__ = [
    "DOCS_BASE_URL_ENV",
    "LIMITATIONS_DOC_SLUG",
    "LIMITATIONS_DOC_VERSION",
    "LIMITATIONS_DOC_LAST_UPDATED",
    "LIMITATIONS_DOC_PATH",
    "LIMITATIONS_BANNER",
    "LIMITATIONS_SUMMARY",
    "resolve_docs_base_url",
    "limitations_doc_url",
    "limitations_stamp",
    "limitations_stamp_lines",
    "limitations_csv_prefix",
    "limitations_copy_text",
    "open_limitations",
]
