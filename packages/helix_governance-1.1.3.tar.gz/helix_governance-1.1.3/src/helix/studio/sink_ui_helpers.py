from __future__ import annotations

from typing import Mapping

SINK_TOOLTIP = "Residual probability mass not mapped to explicit outcomes"


def sink_badge_and_tooltip(node: Mapping[str, object]) -> tuple[str | None, str | None]:
    """Return (badge, tooltip) for a node dict if it is a sink."""
    if not isinstance(node, Mapping):
        return None, None
    node_type = str(node.get("type") or node.get("stage") or "")
    is_sink = bool(node.get("is_sink")) or node_type.lower() == "sink" or str(node.get("id") or "").startswith("sink.")
    if not is_sink:
        return None, None
    return "SINK", SINK_TOOLTIP


def format_mass_audit_line(mass: Mapping[str, object] | None) -> str | None:
    """Format a deterministic mass audit line if sinks are enabled."""
    if not isinstance(mass, Mapping):
        return None
    if not mass.get("sinks_enabled"):
        return None
    try:
        displayed = float(mass.get("displayed_mass", 0.0))
        residual = float(mass.get("residual_mass", 0.0))
        epsilon = float(mass.get("epsilon", 0.0))
    except Exception:
        return None
    return f"Displayed mass: {displayed:.6f} Residual: {residual:.6f} ε: {epsilon:g}"


__all__ = ["SINK_TOOLTIP", "sink_badge_and_tooltip", "format_mass_audit_line"]
