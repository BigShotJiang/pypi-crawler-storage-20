from __future__ import annotations

from pathlib import Path
from typing import Optional

from . import ImportedRun, ImportFailed
from helix.studio.session import RunKind

try:  # optional dependency
    import pysam  # type: ignore
except Exception:  # pragma: no cover - handled via ImportFailed
    pysam = None


def import_bam(bam_path: Path, name: Optional[str] = None) -> ImportedRun:
    """Import a BAM file and summarize basic read stats.

    Metrics recorded:
    - reads_total
    - reads_mapped
    - reads_unmapped
    - frac_mapped (derived)

    Extra metadata includes pairing and properly paired counts.
    """

    if pysam is None:
        raise ImportFailed("pysam not available")

    bam_path = Path(bam_path).resolve()
    if name is None:
        name = bam_path.stem

    if not bam_path.exists():
        raise ImportFailed(f"BAM not found: {bam_path}")

    reads_total = 0
    reads_mapped = 0
    reads_unmapped = 0
    reads_properly_paired = 0
    is_paired = False

    with pysam.AlignmentFile(str(bam_path), "rb") as bam:
        for read in bam.fetch(until_eof=True):
            reads_total += 1
            if read.is_paired:
                is_paired = True
            if read.is_unmapped:
                reads_unmapped += 1
            else:
                reads_mapped += 1
            if read.is_proper_pair:
                reads_properly_paired += 1

    metrics = {
        "reads_total": reads_total,
        "reads_mapped": reads_mapped,
        "reads_unmapped": reads_unmapped,
    }
    metrics["frac_mapped"] = (reads_mapped / reads_total) if reads_total else 0.0

    extra = {
        "is_paired": is_paired,
        "raw_counts": {
            "reads_properly_paired": reads_properly_paired,
        },
    }

    return ImportedRun(
        name=name,
        kind=RunKind.PCR,
        source="bam",
        raw_dir=bam_path,
        metrics=metrics,
        extra=extra,
    )


__all__ = ["import_bam"]
