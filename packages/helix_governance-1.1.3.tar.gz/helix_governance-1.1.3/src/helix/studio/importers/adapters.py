from __future__ import annotations

from typing import Dict, Any

from helix import clock
from . import ImportedRun


def _now_iso() -> str:
    return clock.utc_now_iso_offset()


def imported_run_to_snapshot(imported: ImportedRun, run_id: int) -> Dict[str, Any]:
    """Produce a minimal snapshot-like dict so RunHistory can render imports."""

    state = {
        "run_kind": imported.kind.name,
        "run_kind_key": imported.kind.name,
        "run_id": run_id,
        "viz_dirty": False,
        "config": {
            "import_origin": imported.source,
            "import_metrics": imported.metrics,
        },
        "outcomes": [],
        "genome_source": "imported",
        "genome": {},
        "label": imported.name,
        "guide": imported.name,
        "draws": "n/a",
    }
    snapshot = {
        "version": 0,
        "state": state,
        "timestamp": _now_iso(),
        "imported": True,
        "import_origin": imported.source,
        "import_metrics": imported.metrics,
        "raw_path": str(imported.raw_dir),
        "source": "imported",
        "status": "imported",
    }
    return snapshot


__all__ = ["imported_run_to_snapshot", "_now_iso"]
