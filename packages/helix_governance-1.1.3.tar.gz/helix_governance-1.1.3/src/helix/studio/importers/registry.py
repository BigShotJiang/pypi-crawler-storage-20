from __future__ import annotations

from typing import Callable, Dict, List

from . import ImportedRun, ImportFailed
from .crispresso import import_crispresso
from .ampseq import import_ampseq
from .bam import import_bam


_REGISTRY: Dict[str, Callable[..., ImportedRun]] = {
    "crispresso": import_crispresso,
    "ampseq": import_ampseq,
    "bam": import_bam,
}


def get_importer(kind: str) -> Callable[..., ImportedRun]:
    try:
        return _REGISTRY[kind.lower()]
    except KeyError as exc:
        raise ImportFailed(f"Unknown importer kind: {kind}") from exc


def supported_import_kinds() -> List[str]:
    return sorted(_REGISTRY.keys())


__all__ = ["get_importer", "supported_import_kinds"]
