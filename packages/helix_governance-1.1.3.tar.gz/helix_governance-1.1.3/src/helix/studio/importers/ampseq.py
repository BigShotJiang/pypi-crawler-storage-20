from __future__ import annotations

import csv
from pathlib import Path
from typing import Optional

from . import ImportedRun, ImportFailed
from helix.studio.session import RunKind


def _parse_int(row: dict, key: str, default: int = 0) -> int:
    raw = row.get(key)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except Exception as exc:  # pragma: no cover - unexpected type
        raise ImportFailed(f"Invalid integer for {key}: {raw}") from exc


def import_ampseq(run_dir: Path, name: Optional[str] = None) -> ImportedRun:
    """Import a minimal AMP-seq summary and normalize metrics."""

    run_dir = Path(run_dir).resolve()
    if name is None:
        name = run_dir.name

    summary_path = run_dir / "ampseq_summary.tsv"
    if not summary_path.exists():
        raise ImportFailed(f"Missing AMP-seq summary: {summary_path}")

    with summary_path.open(encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        rows = list(reader)

    if not rows:
        raise ImportFailed(f"Empty AMP-seq summary: {summary_path}")

    row = rows[0]

    reads_total = _parse_int(row, "reads_total")
    reads_on_target = _parse_int(row, "reads_on_target")
    reads_edited = _parse_int(row, "reads_edited")
    reads_reference = _parse_int(row, "reads_reference")

    metrics = {
        "reads_total": reads_total,
        "reads_on_target": reads_on_target,
        "reads_edited": reads_edited,
        "reads_reference": reads_reference,
    }

    if reads_total > 0:
        metrics["frac_on_target"] = reads_on_target / reads_total
        metrics["frac_edited"] = reads_edited / reads_total
        metrics["frac_reference"] = reads_reference / reads_total
    else:
        metrics["frac_on_target"] = 0.0
        metrics["frac_edited"] = 0.0
        metrics["frac_reference"] = 0.0

    extra = {"raw_summary": row}

    return ImportedRun(
        name=name,
        kind=RunKind.CRISPR,
        source="ampseq",
        raw_dir=run_dir,
        metrics=metrics,
        extra=extra,
    )


__all__ = ["import_ampseq"]
