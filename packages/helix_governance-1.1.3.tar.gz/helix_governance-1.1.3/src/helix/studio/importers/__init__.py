"""Importer interfaces for bringing external experiment outputs into Studio."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

from helix.studio.session import RunKind


class ImportFailed(Exception):
    """Raised when an importer cannot parse the provided payload."""


@dataclass
class ImportedRun:
    name: str
    kind: RunKind
    source: str
    raw_dir: Path
    metrics: Dict[str, Any]
    extra: Dict[str, Any]


__all__ = ["ImportedRun", "ImportFailed"]
