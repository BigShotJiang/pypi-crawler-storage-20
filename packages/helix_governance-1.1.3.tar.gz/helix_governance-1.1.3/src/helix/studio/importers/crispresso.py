from __future__ import annotations

import csv
from pathlib import Path
from typing import Optional

from . import ImportedRun, ImportFailed
from helix.studio.session import RunKind


def _parse_int(row: dict, key: str, default: int = 0) -> int:
    raw = row.get(key)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except Exception as exc:  # pragma: no cover - unexpected field type
        raise ImportFailed(f"Invalid integer for {key}: {raw}") from exc


def import_crispresso(run_dir: Path, name: Optional[str] = None) -> ImportedRun:
    """Import a CRISPResso run directory and normalize key metrics.

    Expected file (fixture-driven for now): ``crispresso_summary.tsv`` with columns:
    - reads_total
    - reads_unmodified
    - reads_modified
    - reads_nhej
    - reads_hdr
    """

    run_dir = Path(run_dir).resolve()
    if name is None:
        name = run_dir.name

    summary_path = run_dir / "crispresso_summary.tsv"
    if not summary_path.exists():
        raise ImportFailed(f"Missing CRISPResso summary: {summary_path}")

    with summary_path.open(encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        rows = list(reader)

    if not rows:
        raise ImportFailed(f"Empty CRISPResso summary: {summary_path}")

    row = rows[0]

    reads_total = _parse_int(row, "reads_total")
    reads_unmodified = _parse_int(row, "reads_unmodified")
    reads_modified = _parse_int(row, "reads_modified")
    reads_nhej = _parse_int(row, "reads_nhej")
    reads_hdr = _parse_int(row, "reads_hdr")

    metrics = {
        "reads_total": reads_total,
        "reads_unmodified": reads_unmodified,
        "reads_modified": reads_modified,
        "reads_nhej": reads_nhej,
        "reads_hdr": reads_hdr,
    }

    if reads_total > 0:
        metrics["frac_unmodified"] = reads_unmodified / reads_total
        metrics["frac_modified"] = reads_modified / reads_total
        metrics["frac_nhej"] = reads_nhej / reads_total
        metrics["frac_hdr"] = reads_hdr / reads_total
    else:
        metrics.update(
            {
                "frac_unmodified": 0.0,
                "frac_modified": 0.0,
                "frac_nhej": 0.0,
                "frac_hdr": 0.0,
            }
        )

    extra = {"raw_summary": row}

    return ImportedRun(
        name=name,
        kind=RunKind.CRISPR,
        source="crispresso",
        raw_dir=run_dir,
        metrics=metrics,
        extra=extra,
    )


__all__ = ["import_crispresso"]
