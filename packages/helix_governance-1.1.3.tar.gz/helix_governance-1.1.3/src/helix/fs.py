from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Callable, Iterator, TypeVar

_T = TypeVar("_T")


def _name_sort_key(name: str) -> tuple[str, str]:
    token = str(name or "")
    folded = token.casefold()
    return folded, token


def _stable_path_key(path: Path, *, base: Path | None = None) -> tuple[str, str]:
    p = Path(path)
    try:
        rel = p.relative_to(base) if base is not None else p
    except Exception:
        rel = p
    token = rel.as_posix()
    folded = token.casefold()
    return folded, token


def iterdir_sorted(path: str | Path, *, key: Callable[[Path], Any] | None = None) -> list[Path]:
    root = Path(path)
    entries = list(root.iterdir())
    if key is None:
        entries.sort(key=lambda p: _name_sort_key(p.name))
        return entries
    entries.sort(key=lambda p: (key(p), _name_sort_key(p.name)))
    return entries


def glob_sorted(path: str | Path, pattern: str, *, key: Callable[[Path], Any] | None = None) -> list[Path]:
    root = Path(path)
    entries = list(root.glob(pattern))
    if key is None:
        entries.sort(key=lambda p: _stable_path_key(p, base=root))
        return entries
    entries.sort(key=lambda p: (key(p), _stable_path_key(p, base=root)))
    return entries


def rglob_sorted(path: str | Path, pattern: str, *, key: Callable[[Path], Any] | None = None) -> list[Path]:
    root = Path(path)
    entries = list(root.rglob(pattern))
    if key is None:
        entries.sort(key=lambda p: _stable_path_key(p, base=root))
        return entries
    entries.sort(key=lambda p: (key(p), _stable_path_key(p, base=root)))
    return entries


def dir_has_any(path: str | Path) -> bool:
    root = Path(path)
    try:
        next(iter(root.iterdir()))
    except StopIteration:
        return False
    except FileNotFoundError:
        return False
    return True


def walk_sorted(
    path: str | Path,
    *,
    topdown: bool = True,
    followlinks: bool = False,
    name_key: Callable[[str], Any] | None = None,
) -> Iterator[tuple[Path, list[str], list[str]]]:
    root = Path(path)
    key = name_key or _name_sort_key
    for base, dirs, files in os.walk(root, topdown=topdown, followlinks=followlinks):
        dirs.sort(key=key)
        files.sort(key=key)
        yield Path(base), dirs, files


__all__ = [
    "dir_has_any",
    "glob_sorted",
    "iterdir_sorted",
    "rglob_sorted",
    "walk_sorted",
]

