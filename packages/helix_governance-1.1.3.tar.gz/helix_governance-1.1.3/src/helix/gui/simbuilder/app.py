"""Interactive PyQt Sim Builder for CRISPR/prime editing workflows."""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, fields
import os
from functools import partial
from pathlib import Path
from typing import Any, Callable, Mapping, Optional, TYPE_CHECKING

import numpy as np
from PySide6.QtCore import QByteArray, QObject, QPoint, QRect, QSize, QSettings, Qt, Signal, QThread, QTimer, Slot
from PySide6.QtGui import QCloseEvent, QSurfaceFormat
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLayout,
    QLayoutItem,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QPlainTextEdit,
    QSizePolicy,
    QSpinBox,
    QSplitter,
    QStackedLayout,
    QTabWidget,
    QVBoxLayout,
    QWidget,
    QWidgetItem,
    QComboBox,
    QDoubleSpinBox,
    QCompleter,
    QScrollArea,
    QGroupBox,
    QProgressBar,
    QCheckBox,
    QSlider,
    QStyle,
    QToolButton,
    QFrame,
)

from helix import bioinformatics
from helix import clock
from helix.determinism import allow_nondeterminism
from helix.crispr.coords import anchor_midpoint_index
from helix.crispr import guide as guide_module
from helix.crispr import score as crispr_score
from helix.crispr.guide_export import write_guides_csv
from helix.crispr.model import CasSystem, CasSystemType, DigitalGenome, PAMRule, GuideRNA
from helix.crispr.pam import build_crispr_pam_mask, build_prime_pam_mask
from helix.crispr.simulate import resolve_crispr_priors, simulate_cut_repair
from helix.crispr.dag_api import build_crispr_edit_dag
from helix.gui.modern.builders import (
    build_crispr_viz_spec,
    build_prime_viz_spec,
    build_crispr_rail_3d_spec,
    build_crispr_orbitals_3d_spec,
    build_prime_scaffold_3d_spec,
)
from helix.gui.modern.dag_adapters import crispr_dag_to_viz_spec
from helix.gui.modern.builders_2p5d import build_workflow2p5d_crispr, build_workflow2p5d_prime
from helix.gui.railbands.widget import RailBandWidget
from helix.gui.modern.spec import EditVisualizationSpec
from helix.gui.opengl import configure_opengl_surface_format
from helix.gui.theme import apply_helix_theme
from helix.studio.session import RunKind, SessionModel, PCRConfig, PCRResult
from helix.studio.models import RunModel, OutcomeModel, EngineInfo
from helix.studio.limitations import open_limitations, limitations_doc_url
from helix.crispr.physics import CRISPR_SCORING_VERSION
from helix.prime.physics import PRIME_SCORING_VERSION
from helix.studio.pcr_engine import simulate_pcr, find_amplicon, AmpliconInfo
from helix.studio.pcr_workflow import build_pcr_workflow_meta

LOGGER = logging.getLogger(__name__)
from helix.prime.model import PegRNA, PrimeEditor
from helix.prime.priors import resolve_prime_priors
from helix.prime.simulator import simulate_prime_edit
from helix.genome.ingest import ingest_fasta_to_2bit, GenomeIngestResult
from helix.studio.suggestions import (
    SuggestionCandidate,
    build_index_anchored_genome_suggestion,
    build_locus_suggestion,
    compute_input_digest,
    suggestions_enabled,
)
from helix.studio.locus_guess import (
    LocusGuess,
    canonical_coord_string,
    infer_target_locus_from_filename,
)
from helix.genome.window_store import GenomeWindowStore, GenomeWindow
from helix.genome.fm_registry import (
    register_ingest_result,
    resolve_fm_index,
    build_fm_index_with_progress,
    set_fm_index,
)


class FlowLayout(QLayout):
    """Simple flow layout that wraps widgets when space is tight."""

    def __init__(self, parent: QWidget | None = None, *, hspacing: int = 8, vspacing: int = 6) -> None:
        super().__init__(parent)
        self._items: list[QLayoutItem] = []
        self._hspacing = hspacing
        self._vspacing = vspacing
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item: QLayoutItem) -> None:  # type: ignore[override]
        self._items.append(item)

    def addWidget(self, widget: QWidget) -> None:
        self.addItem(QWidgetItem(widget))

    def count(self) -> int:  # type: ignore[override]
        return len(self._items)

    def itemAt(self, index: int) -> QLayoutItem | None:  # type: ignore[override]
        if 0 <= index < len(self._items):
            return self._items[index]
        return None

    def takeAt(self, index: int) -> QLayoutItem | None:  # type: ignore[override]
        if 0 <= index < len(self._items):
            return self._items.pop(index)
        return None

    def expandingDirections(self) -> Qt.Orientations:  # type: ignore[override]
        return Qt.Orientations(Qt.Orientation(0))

    def hasHeightForWidth(self) -> bool:  # type: ignore[override]
        return True

    def heightForWidth(self, width: int) -> int:  # type: ignore[override]
        width = max(0, width)
        return self._do_layout(QRect(0, 0, width, 0), test_only=True)

    def setGeometry(self, rect: QRect) -> None:  # type: ignore[override]
        super().setGeometry(rect)
        self._do_layout(rect, test_only=False)

    def sizeHint(self) -> QSize:  # type: ignore[override]
        return self.minimumSize()

    def minimumSize(self) -> QSize:  # type: ignore[override]
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        margins = self.contentsMargins()
        size += QSize(margins.left() + margins.right(), margins.top() + margins.bottom())
        return size

    def _do_layout(self, rect: QRect, *, test_only: bool) -> int:
        margins = self.contentsMargins()
        x = rect.x() + margins.left()
        y = rect.y() + margins.top()
        line_height = 0
        max_x = rect.x() + rect.width() - margins.right()

        for item in self._items:
            hint = item.sizeHint()
            next_x = x + hint.width()
            if x > rect.x() + margins.left() and next_x > max_x:
                x = rect.x() + margins.left()
                y += line_height + self._vspacing
                next_x = x + hint.width()
                line_height = 0
            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x = next_x + self._hspacing
            line_height = max(line_height, hint.height())

        return y + line_height + margins.bottom()

if TYPE_CHECKING:  # pragma: no cover
    from helix.gui.modern.qt import HelixModernWidget


def _read_fasta(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    sequence_lines = [line for line in lines if not line.startswith(">")]
    return "".join(sequence_lines)


def _workflow_to_serializable(data: dict[str, Any]) -> dict[str, Any]:
    serializable: dict[str, Any] = {}
    for key, value in data.items():
        if isinstance(value, np.ndarray):
            serializable[key] = value.tolist()
        else:
            serializable[key] = value
    return serializable


def _workflow_from_serializable(data: dict[str, Any]) -> dict[str, np.ndarray | float]:
    buffers: dict[str, np.ndarray | float] = {}
    for key, value in data.items():
        if key in ("x_extent", "y_extent", "captured_mass", "total_mass", "cut_index", "heat_y", "heat_height", "slice_width"):
            buffers[key] = float(value)
        else:
            buffers[key] = np.array(value, dtype="f4")
    return buffers


def _parse_env_flag(name: str) -> bool | None:
    raw = os.environ.get(name)
    if raw is None:
        return None
    text = str(raw).strip().lower()
    if not text:
        return None
    if text in {"1", "true", "yes", "on"}:
        return True
    if text in {"0", "false", "no", "off"}:
        return False
    return None


def _augment_payload_audit(payload: dict[str, Any], *, kind: str, run_config: Mapping[str, Any] | None = None) -> None:
    """Attach explicit model/probability metadata for domain-shift auditing.

    This is intentionally best-effort and non-gating: the GUI should remain usable even
    when provenance inputs are missing.
    """

    try:
        from helix.support.build_meta import build_info

        info = build_info()
        helix_version = str(info.get("helix_version") or "")
        git_sha = str(info.get("git_sha") or "")
        build_date_utc = str(info.get("build_date_utc") or "")
    except Exception:
        helix_version = ""
        git_sha = ""
        build_date_utc = ""

    try:
        from helix.provenance import current_git_sha

        if not git_sha:
            git_sha = str(current_git_sha() or "")
    except Exception:
        pass

    import hashlib

    def _sha256_prefixed(obj: Any) -> str:
        try:
            material = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n"
            return "sha256:" + hashlib.sha256(material.encode("utf-8")).hexdigest()
        except Exception:
            return "sha256:unavailable"

    # Determine primary model identity (edit outcomes).
    model_id = "unconfigured"
    model_version = "unconfigured"
    model_hash = "sha256:unavailable"
    calibration_status = "unknown"
    if isinstance(payload.get("posterior"), Mapping):
        post = payload.get("posterior") if isinstance(payload.get("posterior"), Mapping) else {}
        model = post.get("model") if isinstance(post.get("model"), Mapping) else {}
        model_id = str(model.get("id") or model.get("model_id") or model_id)
        model_version = str(model.get("version") or model.get("model_version") or model_version)
        model_hash = _sha256_prefixed({"model_id": model_id, "model_version": model_version})
        cal = post.get("calibration") if isinstance(post.get("calibration"), Mapping) else {}
        calibration_status = str(cal.get("status") or calibration_status)
    elif isinstance(payload.get("artifact"), str):
        artifact = str(payload.get("artifact") or "")
        if "edit_dag" in artifact:
            model_id = "crispr_edit_dag"
            if ".v" in artifact:
                model_version = artifact.split(".v", 1)[-1]
            model_hash = _sha256_prefixed({"artifact": artifact, "git_commit": git_sha})
            calibration_status = "not_applicable"

    model_ref = f"{model_id}@{model_version}+git:{git_sha[:8] or 'unavailable'}"

    # Minimal multi-model scaffold (matches Studio report structure).
    payload.setdefault("models", {})
    payload["models"] = {
        "edit_outcome": {"name": model_id, "version": model_version, "hash": model_hash, "calibration": calibration_status},
        "kinetics": None,
        "off_target": None,
    }
    payload.setdefault("probabilities", {})
    payload["probabilities"] = {
        "edit_outcome": {
            "semantics": "point_estimate",
            "calibrated": calibration_status == "calibrated",
        }
    }
    payload.setdefault("assumptions", {})
    payload["assumptions"] = {
        "global": [
            "bulk cell population (assumed unless specified elsewhere)",
            "steady-state outcomes (no kinetics model)",
        ],
        "edit_outcome_model": [
            "chromatin ignored",
            "cell-cycle averaged/ignored",
        ],
    }
    payload.setdefault("validation", {})
    payload["validation"] = {
        "recommended_assays": ["amplicon_seq"],
        "future_assays": ["timecourse_seq", "GUIDE_seq"],
        "expected_reads_for_plusminus_5pct": {"reads": 500, "confidence_level": 0.95, "absolute_error": 0.05},
    }
    payload.setdefault("decision", {})
    payload["decision"] = {
        "confidence": "low",
        "recommended_use": "exploration",
        "hard_stop_flags": ["do_not_use_for_therapeutic_decisions"],
    }

    # Lightweight provenance summary for copy/paste auditing.
    payload.setdefault("provenance", {})
    payload["provenance"] = {
        "backend": {
            "name": "helix",
            "version": helix_version or "unavailable",
            "git_commit": git_sha or "unavailable",
            "build_timestamp_utc": build_date_utc or "unavailable",
        },
        "model_ref": model_ref,
        "scoring_versions": {"crispr": CRISPR_SCORING_VERSION, "prime": PRIME_SCORING_VERSION},
        "run_config": dict(run_config or {}),
    }


class SequenceInput(QWidget):
    """Shared sequence editor with load-from-file support."""

    sequenceChanged = Signal(str)
    genomeIngested = Signal(object)
    ingestStarted = Signal(str)
    ingestProgress = Signal(str, int)
    ingestFinished = Signal(object)
    ingestCancelled = Signal(str)
    ingestError = Signal(str)
    ingestStarted = Signal(str)
    ingestProgress = Signal(str, int)
    ingestFinished = Signal(object)
    ingestCancelled = Signal(str)
    ingestError = Signal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._source_kind = "inline"
        self._source_uri: Optional[str] = None
        self._sequence_hash: Optional[str] = None
        self._cached_sequence: Optional[str] = None
        self._genome_ingest: Optional[GenomeIngestResult] = None
        self._ingest_thread: Optional[QThread] = None
        self._ingest_worker: Optional[QObject] = None
        self._ingest_path: Optional[Path] = None
        self._locus_guess: Optional[LocusGuess] = None
        self._locus_candidates: list[dict[str, Any]] = []
        self._input_digest: Optional[str] = None
        layout = QVBoxLayout(self)
        controls = FlowLayout(hspacing=6, vspacing=4)
        self._load_btn = QPushButton("Load FASTA…", self)
        self._clear_btn = QPushButton("Clear", self)
        controls.addWidget(self._load_btn)
        controls.addWidget(self._clear_btn)
        layout.addLayout(controls)
        self._file_notice = QLabel("", self)
        self._file_notice.setObjectName("SequenceFileNotice")
        self._file_notice.setVisible(False)
        layout.addWidget(self._file_notice)
        self._ingest_progress = QProgressBar(self)
        self._ingest_progress.setRange(0, 100)
        self._ingest_progress.setVisible(False)
        layout.addWidget(self._ingest_progress)
        self._text = QPlainTextEdit(self)
        self._text.setPlaceholderText("Paste sequence or FASTA content here…")
        layout.addWidget(self._text)
        self._length_label = QLabel("Length: 0 bp", self)
        layout.addWidget(self._length_label)

        self._load_btn.clicked.connect(self._load_from_file)
        self._clear_btn.clicked.connect(self.clear)
        self._text.textChanged.connect(self._on_text_changed)

    def sequence(self) -> str:
        if self._source_kind == "file" and self._source_uri:
            if self._cached_sequence is None:
                seq = _read_fasta(Path(self._source_uri))
                self._cached_sequence = bioinformatics.normalize_sequence(seq)
                self._sequence_hash = self._hash_sequence(self._cached_sequence)
                self._length_label.setText(f"Length: {len(self._cached_sequence)} bp")
            return self._cached_sequence or ""

        raw = self._text.toPlainText().strip()
        if not raw:
            return ""
        lines = [line.strip() for line in raw.splitlines() if line.strip()]
        seq = "".join(line for line in lines if not line.startswith(">"))
        return bioinformatics.normalize_sequence(seq)

    def current_sequence(self) -> str:
        """Expose a naming-convention-friendly accessor for consumers."""
        return self.sequence()

    def genome_ingest(self) -> Optional[GenomeIngestResult]:
        return self._genome_ingest

    def set_sequence(self, text: str) -> None:
        self._text.setPlainText(text)
        self._source_kind = "inline"
        self._source_uri = None
        self._sequence_hash = self._hash_sequence(text)
        self._cached_sequence = text
        self._file_notice.setVisible(False)
        self._text.setVisible(True)
        self._genome_ingest = None

    def clear(self) -> None:
        self._text.clear()
        self._source_kind = "inline"
        self._source_uri = None
        self._sequence_hash = None
        self._cached_sequence = None
        self._file_notice.setVisible(False)
        self._text.setVisible(True)
        self._genome_ingest = None
        self._locus_guess = None
        self._locus_candidates = []
        self._input_digest = None

    def _on_text_changed(self) -> None:
        seq = self.sequence()
        self._length_label.setText(f"Length: {len(seq)} bp")
        self.sequenceChanged.emit(seq)
        self._source_kind = "inline"
        self._source_uri = None
        self._sequence_hash = self._hash_sequence(seq)
        self._cached_sequence = seq
        self._genome_ingest = None
        self._locus_guess = None
        self._locus_candidates = []
        raw_text = self._text.toPlainText()
        self._input_digest = self._compute_digest(raw_text) if suggestions_enabled() else None

    def _load_from_file(self) -> None:
        path_str, _ = QFileDialog.getOpenFileName(self, "Select FASTA", filter="FASTA (*.fa *.fasta *.fna);;All files (*.*)")
        if not path_str:
            return
        path = Path(path_str)
        if suggestions_enabled():
            try:
                self._locus_guess = infer_target_locus_from_filename(str(path))
                label = self.locus_label()
                self._locus_candidates = []
                if label:
                    self._locus_candidates.append(
                        {
                            "label": label,
                            "kind": self._locus_guess.kind,
                            "score": float(self._locus_guess.score),
                            "confidence": self._confidence_for_score(self._locus_guess.score),
                            "method": "filename_inference",
                            "source": "inferred",
                            "details": self._locus_guess.evidence or "",
                        }
                    )
            except Exception:
                self._locus_guess = None
                self._locus_candidates = []
            try:
                raw_text = path.read_text(encoding="utf-8", errors="ignore")
                self._input_digest = self._compute_digest(raw_text)
            except Exception:
                self._input_digest = None
        try:
            length = self._fast_length(path)
        except Exception as exc:  # pragma: no cover - QFileDialog path errors are UI-bound
            QMessageBox.critical(self, "Failed to load FASTA", str(exc))
            return
        self._start_ingest_async(path, length)

    def _start_ingest_async(self, path: Path, length: Optional[int]) -> None:
        if self._ingest_thread is not None:
            return  # avoid double-start; caller should wait

        class _IngestWorker(QObject):
            progress = Signal(int)
            finished = Signal(object)
            error = Signal(str)
            cancelled = Signal()

            def __init__(self, fasta_path: Path) -> None:
                super().__init__()
                self._path = fasta_path
                self._cancelled = False

            @Slot()
            def cancel(self) -> None:
                self._cancelled = True

            @Slot()
            def run(self) -> None:
                try:
                    meta = ingest_fasta_to_2bit(
                        self._path,
                        progress_cb=self.progress.emit,
                        cancel_cb=lambda: self._cancelled,
                    )
                    if self._cancelled:
                        self.cancelled.emit()
                        return
                    self.finished.emit(meta)
                except Exception as exc:  # pragma: no cover - UI surface
                    if self._cancelled or "cancelled" in str(exc).lower():
                        self.cancelled.emit()
                    else:
                        self.error.emit(str(exc))

        self._ingest_thread = QThread(self)
        worker = _IngestWorker(path)
        self._ingest_worker = worker
        worker.moveToThread(self._ingest_thread)
        self._ingest_thread.started.connect(worker.run)
        worker.progress.connect(self._on_ingest_progress)
        worker.finished.connect(lambda meta: self._on_ingest_finished(meta, length, path))
        worker.cancelled.connect(lambda: self._on_ingest_cancelled(path))
        worker.error.connect(self._on_ingest_error)
        worker.finished.connect(self._cleanup_ingest_thread)
        worker.cancelled.connect(self._cleanup_ingest_thread)
        worker.error.connect(self._cleanup_ingest_thread)
        self._ingest_thread.start()
        self._ingest_progress.setValue(0)
        self._ingest_progress.setVisible(True)
        self._load_btn.setEnabled(False)
        self._clear_btn.setEnabled(False)
        self._ingest_path = path
        self.ingestStarted.emit(path.name)

    def _on_ingest_progress(self, percent: int) -> None:
        self._ingest_progress.setValue(max(0, min(100, percent)))
        if self._ingest_path:
            self.ingestProgress.emit(self._ingest_path.name, int(percent))

    def _on_ingest_finished(self, ingest: GenomeIngestResult, length: Optional[int], path: Path) -> None:
        register_ingest_result(ingest)
        self._genome_ingest = ingest
        self.genomeIngested.emit(ingest)
        self.ingestFinished.emit(ingest)
        self._cached_sequence = None
        self._source_kind = "file"
        self._source_uri = str(path)
        self._sequence_hash = None
        self._text.clear()
        self._text.setVisible(False)
        self._file_notice.setText(
            f"Loaded FASTA → 2bit: {path.name} ({length if length is not None else 'unknown'} bp)"
            f" · cached as {ingest.two_bit_path.name}"
        )
        self._file_notice.setVisible(True)
        self._length_label.setText(f"Length: {length if length is not None else 'unknown'} bp (lazy load)")
        self._ingest_progress.setVisible(False)
        self._load_btn.setEnabled(True)
        self._clear_btn.setEnabled(True)
        if suggestions_enabled() and self._locus_guess is None:
            try:
                self._locus_guess = infer_target_locus_from_filename(str(path))
            except Exception:
                self._locus_guess = None

    def _on_ingest_error(self, message: str) -> None:
        self._ingest_progress.setVisible(False)
        self._load_btn.setEnabled(True)
        self._clear_btn.setEnabled(True)
        QMessageBox.critical(self, "Failed to ingest FASTA", message)
        self.ingestError.emit(message)

    def _on_ingest_cancelled(self, path: Path) -> None:
        self._ingest_progress.setVisible(False)
        self._load_btn.setEnabled(True)
        self._clear_btn.setEnabled(True)
        self.ingestCancelled.emit(path.name)

    def _cleanup_ingest_thread(self) -> None:
        if self._ingest_thread is None:
            return
        self._ingest_thread.quit()
        self._ingest_thread.wait()
        self._ingest_thread = None
        self._ingest_worker = None
        self._ingest_path = None

    def cancel_ingest(self) -> None:
        worker = self._ingest_worker
        if worker is not None and hasattr(worker, "cancel"):
            try:
                worker.cancel()  # type: ignore[attr-defined]
            except Exception:
                pass

    @staticmethod
    def _confidence_for_score(score: float) -> str:
        if score >= 0.9:
            return "high"
        if score >= 0.7:
            return "med"
        return "low"

    def _compute_digest(self, sequence: str) -> Optional[str]:
        if not sequence:
            return None
        try:
            return compute_input_digest(sequence, params={})
        except Exception:
            return None

    def sequence_metadata(self) -> dict[str, Optional[str]]:
        meta = {
            "source": self._source_kind,
            "uri": self._source_uri,
            "hash": self._sequence_hash,
        }
        if self._genome_ingest is not None:
            meta["two_bit_path"] = str(self._genome_ingest.two_bit_path)
            meta["genome_id"] = self._genome_ingest.genome_id
        if not suggestions_enabled():
            return meta
        seq = self.sequence()
        if seq and not self._input_digest:
            raw_text = self._raw_sequence_text()
            self._input_digest = self._compute_digest(raw_text or seq)
        meta["input_digest"] = self._input_digest
        now = clock.utc_now_iso()
        label = self.locus_label()
        if label:
            meta["target_locus"] = label
        if self._locus_guess is not None:
            try:
                from dataclasses import asdict

                meta["locus_guess"] = asdict(self._locus_guess)
            except Exception:
                meta["locus_guess"] = None
        if self._locus_candidates and self._input_digest:
            meta["locus_suggestion"] = build_locus_suggestion(
                input_digest=self._input_digest,
                candidates=[SuggestionCandidate(**c) for c in self._locus_candidates],
                created_at=now,
            )
        return meta

    def locus_label(self) -> str:
        guess = self._locus_guess
        if guess is None:
            return ""
        if guess.kind == "coords":
            return canonical_coord_string(guess) or ""
        if guess.kind == "gene":
            return guess.gene or ""
        if guess.kind == "contig":
            return guess.contig or ""
        return ""

    def _hash_sequence(self, sequence: str) -> Optional[str]:
        if not sequence:
            return None
        import hashlib

        return hashlib.sha256(sequence.encode("utf-8")).hexdigest()

    def _raw_sequence_text(self) -> str:
        if self._source_kind == "file" and self._source_uri:
            try:
                return Path(self._source_uri).read_text(encoding="utf-8", errors="ignore")
            except Exception:
                return ""
        return self._text.toPlainText()

    def _fast_length(self, path: Path) -> Optional[int]:
        try:
            total = 0
            with path.open("r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if not line or line.startswith(">"):
                        continue
                    total += len(line.strip())
            return total
        except Exception:
            return None


class ViewerPlaceholder(QWidget):
    """Simple fallback canvas shown when OpenGL hasn't rendered yet."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setAutoFillBackground(True)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addStretch(1)
        self._label = QLabel("Viewer initializing…", self)
        self._label.setAlignment(Qt.AlignCenter)
        self._label.setStyleSheet("color: palette(mid); font-size: 16px;")
        layout.addWidget(self._label)
        layout.addStretch(1)

    def set_message(self, message: str) -> None:
        self._label.setText(message)


@dataclass
class SimSettings:
    """Shared simulation configuration passed across tabs."""

    pam_profile: str = "SpCas9_NGG"
    pam_softness: float = 0.0
    draws: int = 1000
    seed: Optional[int] = None
    priors_profile: str = "default_indel"
    viz_mode: str = "rail_3d"
    dag_mode: bool = True


class SimSettingsModel(QObject):
    """Wraps SimSettings with change notifications."""

    changed = Signal()

    def __init__(self, initial: SimSettings | None = None, parent: QObject | None = None) -> None:
        super().__init__(parent)
        if initial is None:
            env_dag = _parse_env_flag("HELIX_DAG_MODE")
            initial = SimSettings(dag_mode=bool(env_dag)) if env_dag is not None else SimSettings()
        self._settings = initial

    @property
    def value(self) -> SimSettings:
        return self._settings

    def update(self, **kwargs: Any) -> None:
        updated = False
        field_names = {field.name for field in fields(SimSettings)}
        for key, val in kwargs.items():
            if key in field_names:
                current = getattr(self._settings, key)
                if current != val:
                    setattr(self._settings, key, val)
                    updated = True
        if updated:
            self.changed.emit()

    def apply_dict(self, data: dict[str, Any]) -> None:
        filtered = {k: v for k, v in data.items() if hasattr(self._settings, k)}
        if filtered:
            self.update(**filtered)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self._settings)


PAM_PROFILE_PRESETS: dict[str, dict[str, str]] = {
    "SpCas9_NGG": {"pam": "SpCas9-NGG"},
    "SpG_NGN": {"pattern": "NGN", "orientation": "3prime", "notes": "SpG relaxed SpCas9"},
    "SpRY_NNN": {"pam": "SpRY-NNN"},
    "SaCas9_NNGRRT": {"pam": "SaCas9-NNGRRT"},
    "Cas12a_TTTN": {"pattern": "TTTN", "orientation": "5prime", "notes": "Cas12a/Cpf1"},
}
DEFAULT_PAM_PROFILES: tuple[str, ...] = tuple(PAM_PROFILE_PRESETS)
PRIOR_PROFILE_CHOICES: tuple[str, ...] = ("default_indel", "scarless", "indel_heavy", "hdr_only")
VIZ_MODE_CHOICES: tuple[str, ...] = ("rail_3d", "rail_2d", "orbitals_3d", "prime_scaffold_3d", "workflow_2p5d")
VIZ_MODE_LABELS: dict[str, str] = {
    "rail_3d": "Rail 3D (linear genome)",
    "rail_2d": "Rail 2D (bands)",
    "orbitals_3d": "Orbitals 3D (looped)",
    "prime_scaffold_3d": "Prime scaffold 3D",
    "workflow_2p5d": "Workflow 2.5D (timeline)",
}

GUIDE_VIABILITY_GC_MIN = 0.20
GUIDE_VIABILITY_GC_MAX = 0.80
GUIDE_VIABILITY_POLY_T_RUN = 4


class PamConfigPanel(QWidget):
    """Shared configuration form that feeds the SimSettingsModel."""

    settingsChanged = Signal(dict)

    def __init__(self, settings_model: SimSettingsModel, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._settings_model = settings_model
        self._syncing = False

        layout = QFormLayout(self)

        self.pam_profile_combo = HelixComboBox(self, searchable=True)
        self.pam_profile_combo.setEditable(True)
        for key in DEFAULT_PAM_PROFILES:
            preset = PAM_PROFILE_PRESETS.get(key, {})
            self.pam_profile_combo.addItem(key)
            notes = preset.get("notes")
            if notes:
                idx = self.pam_profile_combo.count() - 1
                self.pam_profile_combo.setItemData(idx, notes, Qt.ToolTipRole)
        self._configure_combo(self.pam_profile_combo)
        layout.addRow("PAM profile:", self.pam_profile_combo)

        self.pam_softness_spin = QDoubleSpinBox(self)
        self.pam_softness_spin.setRange(0.0, 1.0)
        self.pam_softness_spin.setSingleStep(0.1)
        doc_url = limitations_doc_url()
        pam_tooltip = (
            "Penalizes simulations when the expected PAM is missing at a site.\n"
            "0.0 = strict (PAM required). 1.0 = ignore PAM (treat non-canonical PAMs like NAG as allowed).\n"
            "Guide discovery uses the PAM profile only; softness does not change which guides are enumerated.\n\n"
            "Limitations: abstract parameter (not ΔG/kinetics; not validated for prediction)."
        )
        if doc_url:
            pam_tooltip += f"\nSee: {doc_url}"
        else:
            pam_tooltip += "\nSee Model limitations & invalid use cases."
        self.pam_softness_spin.setToolTip(pam_tooltip)
        layout.addRow("PAM softness:", self.pam_softness_spin)

        self._pam_softness_notice_shown = False
        self._pam_softness_callout = self._build_inline_callout(
            "Limitations apply: PAM softness is an abstract knob, not delta G/kinetics. "
            "Do not interpret as prediction. <a href=\"open\">Limitations</a>"
        )
        self._pam_softness_callout.setVisible(False)
        layout.addRow("", self._pam_softness_callout)

        self.draws_spin = QSpinBox(self)
        self.draws_spin.setRange(1, 1_000_000)
        layout.addRow("Draws:", self.draws_spin)

        self.seed_spin = QSpinBox(self)
        self.seed_spin.setRange(-1, 2**31 - 1)
        self.seed_spin.setSpecialValueText("Random each run")
        self.seed_spin.setToolTip("Use -1 for random seed per run.")
        layout.addRow("Seed:", self.seed_spin)

        self.priors_combo = HelixComboBox(self, searchable=False)
        self.priors_combo.addItems(PRIOR_PROFILE_CHOICES)
        self._configure_combo(self.priors_combo)
        layout.addRow("Priors profile:", self.priors_combo)

        self.viz_mode_combo = HelixComboBox(self, searchable=False)
        for key in VIZ_MODE_CHOICES:
            label = VIZ_MODE_LABELS.get(key, key)
            self.viz_mode_combo.addItem(label, userData=key)
        self._configure_combo(self.viz_mode_combo)
        layout.addRow("Viz mode:", self.viz_mode_combo)

        self.dag_mode_check = QCheckBox("Enable DAG mode (CRISPR only)", self)
        self.dag_mode_check.setToolTip("Populate the Edit DAG tab by running CRISPR in DAG-first mode.")
        env_dag_mode = _parse_env_flag("HELIX_DAG_MODE")
        if env_dag_mode is not None:
            self.dag_mode_check.setEnabled(False)
            self.dag_mode_check.setToolTip(
                "HELIX_DAG_MODE is set in the environment; clear it to change DAG mode in the UI."
            )
        layout.addRow("Edit DAG:", self.dag_mode_check)

        self._settings_model.changed.connect(self._load_from_model)
        self.pam_profile_combo.currentTextChanged.connect(self._on_changed)
        self.pam_softness_spin.valueChanged.connect(self._on_changed)
        self.pam_softness_spin.valueChanged.connect(self._on_pam_softness_changed)
        self.draws_spin.valueChanged.connect(self._on_changed)
        self.seed_spin.valueChanged.connect(self._on_changed)
        self.priors_combo.currentTextChanged.connect(self._on_changed)
        self.viz_mode_combo.currentIndexChanged.connect(self._on_changed)
        self.dag_mode_check.toggled.connect(self._on_changed)

        self._load_from_model()

    def _load_from_model(self) -> None:
        self._syncing = True
        try:
            settings = self._settings_model.value
            self._ensure_combo_text(self.pam_profile_combo, settings.pam_profile or "SpCas9_NGG")
            self.pam_softness_spin.setValue(settings.pam_softness)
            self.draws_spin.setValue(max(1, settings.draws))
            self.seed_spin.setValue(-1 if settings.seed is None else settings.seed)
            self._ensure_combo_text(self.priors_combo, settings.priors_profile or PRIOR_PROFILE_CHOICES[0])
            self._set_combo_by_data(self.viz_mode_combo, settings.viz_mode or "rail_3d")
            self.dag_mode_check.setChecked(bool(settings.dag_mode))
        finally:
            self._syncing = False

    # Prefill from a RunModel (used by Focus Mode cloning)
    def load_from_run_model(self, run) -> None:
        try:
            seq = getattr(run, "sequence", "") or ""
            if seq and hasattr(self, "sequence_input"):
                self.sequence_input.set_sequence(seq)
        except Exception:
            pass
        try:
            gid = getattr(run, "guide_id", "")
            if gid and hasattr(self, "crispr_tab") and hasattr(self.crispr_tab, "_guide_list"):
                self.crispr_tab._guide_list.clear()
                item = QListWidgetItem(gid)
                item.setData(Qt.UserRole, {"sequence": seq})
                self.crispr_tab._guide_list.addItem(item)
                self.crispr_tab._guide_list.setCurrentItem(item)
        except Exception:
            pass
        try:
            locus = getattr(run, "target_locus", "")
            if locus and hasattr(self, "target_field"):
                self.target_field.setText(str(locus))
                # If locus looks like chr:start-end, center camera there
                try:
                    chrom_part, coords = str(locus).split(":", 1)
                    pos_part = coords.split("-")[0]
                    pos = int(pos_part.replace(",", ""))
                    view_len = self.window_len.value() if hasattr(self, "window_len") else 1000
                    half = view_len // 2
                    start = max(0, pos - half)
                    if hasattr(self, "_set_active_window"):
                        self._set_active_window(chrom_part, start, view_len)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            pam_idx = getattr(run, "pam_index", None)
            if pam_idx is not None and hasattr(self, "pam_config") and hasattr(self.pam_config, "set_profile_index"):
                self.pam_config.set_profile_index(max(0, int(pam_idx)))  # type: ignore[attr-defined]
        except Exception:
            pass
        try:
            if hasattr(self, "sim_settings"):
                # stash parent linkage for downstream tagging
                self._cloned_parent_run_id = getattr(run, "parent_run_id", None)
        except Exception:
            pass

    def _ensure_combo_text(self, combo: QComboBox, text: str) -> None:
        if combo.findText(text) < 0:
            combo.addItem(text)
        combo.setCurrentText(text)

    def _set_combo_by_data(self, combo: QComboBox, value: str) -> None:
        idx = combo.findData(value)
        if idx >= 0:
            combo.setCurrentIndex(idx)

    def _configure_combo(self, combo: QComboBox) -> None:
        # Allow the Sim Builder sidebar to shrink on smaller screens.
        # Keep a reasonable minimum but avoid forcing a wide rail.
        combo.setMinimumWidth(140)
        combo.setMinimumContentsLength(12)
        combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
        view = combo.view()
        if view is not None:
            view.setMinimumWidth(180)
        combo.setMaxVisibleItems(16)
        combo.setInsertPolicy(QComboBox.NoInsert)

    def _build_inline_callout(self, message: str) -> QWidget:
        callout = QFrame(self)
        callout.setObjectName("PamSoftnessCallout")
        callout.setStyleSheet(
            "QFrame#PamSoftnessCallout {"
            " background: palette(alternate-base);"
            " border: 1px solid palette(mid);"
            " border-radius: 8px;"
            " }"
            "QLabel { color: palette(window-text); font-size: 11px; }"
            "QToolButton { color: palette(link); font-size: 11px; }"
        )
        layout = QHBoxLayout(callout)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(8)

        label = QLabel(message, callout)
        label.setTextFormat(Qt.RichText)
        label.setWordWrap(True)
        label.setTextInteractionFlags(Qt.TextBrowserInteraction)
        label.linkActivated.connect(lambda _=None: open_limitations(self))
        layout.addWidget(label, stretch=1)

        dismiss = QToolButton(callout)
        dismiss.setText("Dismiss")
        dismiss.clicked.connect(callout.hide)
        layout.addWidget(dismiss)
        return callout

    def _on_pam_softness_changed(self, value: float) -> None:
        if self._syncing or self._pam_softness_notice_shown:
            return
        if abs(float(value) - 0.0) < 1e-6:
            return
        self._pam_softness_notice_shown = True
        self._pam_softness_callout.setVisible(True)

    def _on_changed(self, *_args: object) -> None:
        if self._syncing:
            return
        payload = {
            "pam_profile": self.pam_profile_combo.currentText().strip(),
            "pam_softness": float(self.pam_softness_spin.value()),
            "draws": int(self.draws_spin.value()),
            "seed": None if self.seed_spin.value() < 0 else int(self.seed_spin.value()),
            "priors_profile": self.priors_combo.currentText().strip(),
            "viz_mode": str(self.viz_mode_combo.currentData() or self.viz_mode_combo.currentText().strip()),
            "dag_mode": bool(self.dag_mode_check.isChecked()),
        }
        self._settings_model.update(**payload)
        self.settingsChanged.emit(payload)


class LogPanel(QPlainTextEdit):
    """Simple log viewer."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setReadOnly(True)

    def log(self, message: str) -> None:
        self.appendPlainText(message)


class SimJobWorker(QObject):
    """Background worker that executes simulations off the UI thread."""

    finished = Signal(object, object)  # payload, spec
    failed = Signal(str)

    def __init__(self, task: Callable[[], tuple[dict, Optional[EditVisualizationSpec]]], parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._task = task

    def run(self) -> None:
        try:
            payload, spec = self._task()
            if spec is None:
                raise ValueError("Simulation succeeded but no visualization spec was generated.")
            self.finished.emit(payload, spec)
        except Exception as exc:  # pragma: no cover - errors reported via UI
            self.failed.emit(str(exc))


class PCRWorker(QObject):
    """Worker that runs PCR simulations off the UI thread."""

    finished = Signal(object)  # PCRResult
    failed = Signal(str)

    def __init__(self, config: PCRConfig, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._config = config

    def run(self) -> None:
        try:
            result = simulate_pcr(self._config)
            self.finished.emit(result)
        except Exception as exc:  # pragma: no cover - surfaced via UI/logs
            self.failed.emit(str(exc))


class SequenceWindowViewer(QWidget):
    """Minimal viewer that displays the active genome window."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        self._label = QLabel("No window selected", self)
        self._label.setWordWrap(True)
        self._label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        layout.addWidget(self._label)

    def set_window(self, chrom: str, start: int, sequence: str) -> None:
        preview = sequence[:120] + ("…" if len(sequence) > 120 else "")
        self._label.setText(f"{chrom}:{start} (+{len(sequence)} bp)\n{preview}")


class GLWindowAdapter:
    """Thin adapter to feed genome windows into a GL widget if it supports it."""

    def __init__(self, gl_window: object) -> None:
        self.gl_window = gl_window
        self.last_window = None

    def set_window(self, chrom: str, start: int, sequence_bytes: bytes) -> None:
        self.last_window = (chrom, start, sequence_bytes)
        # If the GL widget exposes a compatible API, call it; otherwise no-op.
        if hasattr(self.gl_window, "set_window"):
            try:
                self.gl_window.set_window(chrom, start, sequence_bytes)
                return
            except Exception:
                pass
        if hasattr(self.gl_window, "set_sequence"):
            try:
                self.gl_window.set_sequence(sequence_bytes, offset=start)
            except Exception:
                pass

    def set_window_camera(self, zoom_bp: float, center_bp: float) -> None:
        if hasattr(self.gl_window, "set_window_camera"):
            try:
                self.gl_window.set_window_camera(zoom_bp, center_bp)
            except Exception:
                pass

    def set_overlays(self, rel_indices: np.ndarray, kinds: np.ndarray, values: np.ndarray, labels=None, counts=None) -> None:
        if hasattr(self.gl_window, "set_overlays"):
            try:
                self.gl_window.set_overlays(
                    rel_indices,
                    kinds,
                    values,
                    int(rel_indices.size if rel_indices.size else 0),
                    labels or [],
                    counts,
                )
            except Exception:
                pass

    def set_search_mode(self, mode: str) -> None:
        if hasattr(self.gl_window, "set_search_mode"):
            try:
                self.gl_window.set_search_mode(mode)
            except Exception:
                pass


class CrisprTab(QWidget):
    """CRISPR simulation form."""

    specReady = Signal(object)
    simPayloadReady = Signal(object)
    logMessage = Signal(str)
    runCompleted = Signal(str, object, object)  # kind, payload, spec
    runStarted = Signal(str)
    runFailed = Signal(str, str)
    guidesUpdated = Signal(int, int)  # viable, rejected
    guideFocusChanged = Signal(object)

    def __init__(
        self,
        sequence_input: SequenceInput,
        sim_settings: SimSettingsModel,
        parent: QWidget | None = None,
        *,
        window_provider=None,
    ) -> None:
        super().__init__(parent)
        self._sequence_input = sequence_input
        self._sim_settings = sim_settings
        self._window_provider = window_provider
        self._guides_all: list[dict[str, Any]] = []
        self._guides_rejected: list[dict[str, Any]] = []
        self._guides: list[dict[str, Any]] = []
        self._apply_viability_filters = True
        self._show_rejected_guides = False
        self._guide_sort_mode = "position"  # position | pareto | frameshift | offtarget
        self._last_payload: Optional[dict] = None
        self._last_spec: Optional[EditVisualizationSpec] = None
        self._active_thread: QThread | None = None
        self._active_worker: SimJobWorker | None = None
        self._last_genome: Optional[DigitalGenome] = None
        self._last_run_config: dict[str, Any] = {}
        self._last_guide: Optional[dict[str, Any]] = None
        self._run_start: float | None = None
        self._last_run_ms: float | None = None

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self._guide_len = QSpinBox(self)
        self._guide_len.setRange(10, 40)
        self._guide_len.setValue(20)
        form.addRow("Guide length", self._guide_len)
        layout.addLayout(form)

        self._find_btn = QPushButton("Find Guides", self)
        layout.addWidget(self._find_btn)
        self._guide_list = QListWidget(self)
        layout.addWidget(self._guide_list)

        # Off-target search mode + FM index state
        fm_layout = QVBoxLayout()
        self.fm_status = QLabel("FM index: not built", self)
        self.offtarget_mode_combo = QComboBox(self)
        self.offtarget_mode_combo.addItem("Sequence-only (no off-targets)", userData="none")
        self.offtarget_mode_combo.addItem("Local off-target (within loaded sequence)", userData="window")
        self.offtarget_mode_combo.addItem("Whole-genome off-target (FM index)", userData="whole")
        self.offtarget_mode_combo.setCurrentIndex(1)
        self.offtarget_mode_combo.setToolTip(
            "Off-target evaluation mode:\n"
            "  - Sequence-only: no off-target computation.\n"
            "  - Local: enumerate near-matches within the loaded sequence/window.\n"
            "  - Whole-genome: requires a built FM index for the ingested genome."
        )
        self.fm_build_btn = QPushButton("Build index", self)
        self.fm_build_btn.clicked.connect(self._request_fm_build)
        fm_layout.addWidget(self.fm_status)
        fm_layout.addWidget(self.offtarget_mode_combo)
        fm_layout.addWidget(self.fm_build_btn)
        layout.addLayout(fm_layout)

        btn_row = FlowLayout(hspacing=8, vspacing=6)
        self._simulate_btn = QPushButton("Simulate CRISPR", self)
        self._save_sim_btn = QPushButton("Save .sim…", self)
        self._save_spec_btn = QPushButton("Save Viz Spec…", self)
        self._save_sim_btn.setEnabled(False)
        self._save_spec_btn.setEnabled(False)
        btn_row.addWidget(self._simulate_btn)
        btn_row.addWidget(self._save_sim_btn)
        btn_row.addWidget(self._save_spec_btn)
        layout.addLayout(btn_row)
        layout.addStretch(1)

        self._find_btn.clicked.connect(self._find_guides)
        self._simulate_btn.clicked.connect(self._simulate)
        self._save_sim_btn.clicked.connect(partial(self._export_json, "crispr.sim json", lambda: self._last_payload))
        self._save_spec_btn.clicked.connect(partial(self._export_spec, lambda: self._last_spec))
        self._guide_list.currentItemChanged.connect(lambda *_: self._on_guide_changed())
        try:
            self.offtarget_mode_combo.currentIndexChanged.connect(lambda *_: self._refresh_guide_proxies())
        except Exception:
            pass

    def set_apply_viability_filters(self, enabled: bool) -> None:
        self._apply_viability_filters = bool(enabled)
        self._recompute_viability()
        self._update_guide_list()

    def set_show_rejected_guides(self, show: bool) -> None:
        self._show_rejected_guides = bool(show)
        self._update_guide_list()

    def set_guide_sort_mode(self, mode: str) -> None:
        mode = str(mode or "").strip().lower()
        if mode not in {"position", "pareto", "frameshift", "offtarget"}:
            mode = "position"
        if self._guide_sort_mode == mode:
            return
        self._guide_sort_mode = mode
        self._update_guide_list()

    def guide_counts(self) -> tuple[int, int]:
        return (len(self._guides), len(self._guides_rejected))

    @staticmethod
    def _offtarget_rank(worst_score: float | None, hit_count: int) -> str:
        """Coarse risk bucket for window-local off-target proxy scores."""

        try:
            n = int(hit_count)
        except Exception:
            n = 0
        if n <= 0:
            return "low"
        try:
            worst = float(worst_score or 0.0)
        except Exception:
            worst = 0.0
        if worst >= 0.5:
            return "high"
        if worst >= 0.25:
            return "med"
        return "low"

    def _mark_recommended_guide(self) -> None:
        for guide in self._guides_all:
            guide.pop("recommended_exploratory", None)

        candidates: list[dict[str, Any]] = []
        for guide in self._guides:
            fs = guide.get("frameshift_fraction")
            if isinstance(fs, (int, float)):
                candidates.append(guide)
        if not candidates:
            return

        def _key(g: Mapping[str, Any]) -> tuple[float, float, float, int, str]:
            fs = float(g.get("frameshift_fraction") or -1.0)
            try:
                worst = float(g.get("offtarget_worst_score"))  # smaller is better
            except Exception:
                worst = float("inf")
            try:
                gc = float(g.get("gc_content") or 0.0)
            except Exception:
                gc = 0.0
            try:
                start = int(g.get("start") or 0)
            except Exception:
                start = 0
            strand = str(g.get("strand") or "+")
            # Sort: highest frameshift, then lowest off-target worst score, then GC closer to 0.5.
            return (-fs, worst, abs(gc - 0.5), start, strand)

        best = sorted(candidates, key=_key)[0]
        best["recommended_exploratory"] = True

    def _rejection_reasons(self, guide: Mapping[str, Any]) -> list[str]:
        reasons: list[str] = []
        guide_seq = str(guide.get("sequence") or "").upper()
        if guide_seq and any(base not in {"A", "C", "G", "T"} for base in guide_seq):
            reasons.append("ambiguous_base")
        try:
            gc = float(guide.get("gc_content") or 0.0)
        except Exception:
            gc = 0.0
        if gc < GUIDE_VIABILITY_GC_MIN or gc > GUIDE_VIABILITY_GC_MAX:
            reasons.append("GC_out_of_range")
        if "T" * GUIDE_VIABILITY_POLY_T_RUN in guide_seq:
            reasons.append("homopolymer_run")
        return reasons

    def _recompute_viability(self) -> None:
        self._guides = []
        self._guides_rejected = []
        for guide in self._guides_all:
            if self._apply_viability_filters:
                reasons = self._rejection_reasons(guide)
            else:
                reasons = []
            guide["reject_reasons"] = list(reasons)
            guide["viable"] = not reasons
            if reasons:
                self._guides_rejected.append(guide)
            else:
                self._guides.append(guide)

        self._mark_recommended_guide()
        self._compute_pareto_fronts()

    def _annotate_guides_with_proxies(self, sequence: str, *, pam_profile: str) -> None:
        """Attach lightweight, exploratory decision-support metrics to each guide.

        These are intended for *relative ranking* within the current window:
        - Frameshift fraction (indels only) via the deterministic cut model.
        - Window-local off-target proxy via mismatch + PAM penalties.
        """

        seq = str(sequence or "")
        if not seq:
            return

        # Outcome proxy: local microhomology-weighted spectrum (deterministic).
        try:
            from helix.studio.outcomes.cut_model import estimate_frameshift_fraction
        except Exception:
            estimate_frameshift_fraction = None  # type: ignore[assignment]

        # Off-target proxy: only compute for reasonably sized sequences.
        compute_offtargets = str(self.offtarget_mode_combo.currentData() or "window") != "none"
        if len(seq) > 200_000:
            compute_offtargets = False

        for guide in self._guides_all:
            cut_idx = guide.get("cut_index")
            fs = None
            if estimate_frameshift_fraction is not None and cut_idx is not None:
                try:
                    fs = estimate_frameshift_fraction(seq, int(cut_idx))
                except Exception:
                    fs = None
            guide["frameshift_fraction"] = fs

            if not compute_offtargets:
                guide["offtarget_hits"] = 0
                guide["offtarget_worst_score"] = None
                guide["offtarget_burden"] = None
                guide["offtarget_rank"] = "n/a" if str(self.offtarget_mode_combo.currentData() or "window") == "none" else "skipped"
                continue

            try:
                hits = crispr_score.enumerate_off_targets(seq, guide, pam_profile, max_mm=3)
                scored = crispr_score.score_off_targets(hits, crispr_score.DEFAULT_WEIGHTS["off_target"])
                candidates = [h for h in scored if int(h.get("distance") or 0) > 0]
                scores = [float(h.get("score") or 0.0) for h in candidates]
                worst = max(scores) if scores else 0.0
                burden = float(sum(scores))
                guide["offtarget_hits"] = int(len(candidates))
                guide["offtarget_worst_score"] = round(float(worst), 6)
                guide["offtarget_burden"] = round(float(burden), 6)
                guide["offtarget_rank"] = self._offtarget_rank(worst, len(candidates))
            except Exception:
                guide["offtarget_hits"] = 0
                guide["offtarget_worst_score"] = None
                guide["offtarget_burden"] = None
                guide["offtarget_rank"] = "n/a"

        try:
            from helix.crispr.guide_objectives import annotate_guides_with_metrics

            annotate_guides_with_metrics(
                self._guides_all,
                target_index_abs=getattr(self, "_guide_target_abs_index", None),
            )
        except Exception:
            pass

    def _compute_pareto_fronts(self) -> None:
        for guide in self._guides_all:
            guide.pop("pareto_front", None)
            guide.pop("is_pareto", None)
        try:
            from helix.crispr.guide_objectives import DEFAULT_GUIDE_OBJECTIVES_V1, pareto_front_ranks

            vectors = []
            ranked = []
            for guide in self._guides:
                metrics = guide.get("metrics") if isinstance(guide.get("metrics"), Mapping) else {}
                vectors.append(metrics)
                ranked.append(guide)
            ranks = pareto_front_ranks(vectors, DEFAULT_GUIDE_OBJECTIVES_V1)
            for guide, rank in zip(ranked, ranks):
                guide["pareto_front"] = rank
                guide["is_pareto"] = rank == 0
        except Exception:
            return

    def _format_rejection_reason(self, reason: str) -> str:
        reason = str(reason or "").strip()
        if reason == "ambiguous_base":
            return "ambiguous_base (contains N)"
        if reason == "GC_out_of_range":
            return f"GC_out_of_range ({GUIDE_VIABILITY_GC_MIN:.2f}–{GUIDE_VIABILITY_GC_MAX:.2f})"
        if reason == "homopolymer_run":
            return f"homopolymer_run (poly-T≥{GUIDE_VIABILITY_POLY_T_RUN})"
        return reason or "unknown"

    def _update_guide_list(self) -> None:
        self._guide_list.clear()
        show_rejected = self._show_rejected_guides and bool(self._guides_rejected)
        guides_to_show: list[dict[str, Any]] = list(self._guides)
        if show_rejected:
            guides_to_show.extend(self._guides_rejected)

        sort_mode = str(getattr(self, "_guide_sort_mode", "position") or "position").strip().lower()
        if sort_mode == "pareto":
            guides_to_show.sort(
                key=lambda g: (
                    not bool(g.get("viable", True)),
                    int(g.get("pareto_front")) if g.get("pareto_front") is not None else 9999,
                    int(g.get("start") or 0),
                    str(g.get("strand") or "+"),
                )
            )
        elif sort_mode == "frameshift":
            guides_to_show.sort(
                key=lambda g: (
                    not bool(g.get("viable", True)),
                    -float(g.get("frameshift_fraction") or -1.0),
                    float(g.get("offtarget_worst_score") or 0.0),
                    int(g.get("start") or 0),
                    str(g.get("strand") or "+"),
                )
            )
        elif sort_mode == "offtarget":
            guides_to_show.sort(
                key=lambda g: (
                    not bool(g.get("viable", True)),
                    float(g.get("offtarget_worst_score") if g.get("offtarget_worst_score") is not None else float("inf")),
                    -float(g.get("frameshift_fraction") or -1.0),
                    int(g.get("start") or 0),
                    str(g.get("strand") or "+"),
                )
            )

        for guide in guides_to_show:
            pam_seq = str(guide.get("pam_seq") or "?")
            viable = bool(guide.get("viable", True))
            prefix = "" if viable else "Rejected · "
            pareto_front = guide.get("pareto_front")
            pareto_tag = f"F{int(pareto_front)} · " if viable and isinstance(pareto_front, int) else ""
            star = "⭐ " if bool(guide.get("recommended_exploratory")) and viable else ""
            try:
                gc_txt = f"{float(guide.get('gc_content') or 0.0):.2f}"
            except Exception:
                gc_txt = "—"

            fs = guide.get("frameshift_fraction")
            if isinstance(fs, (int, float)):
                fs_txt = f"FS≈{float(fs) * 100.0:.0f}%"
            else:
                fs_txt = "FS —"

            ot_rank = str(guide.get("offtarget_rank") or "n/a")
            if ot_rank in {"n/a", "skipped"}:
                ot_txt = "OT —" if ot_rank == "n/a" else "OT (skipped)"
            else:
                ot_txt = f"OT {ot_rank}"
            label = (
                f"{star}{prefix}{pareto_tag}{guide.get('id')} · {guide.get('start')}-{guide.get('end')} ({guide.get('strand')}) "
                f"· PAM {pam_seq} · {fs_txt} · {ot_txt} · GC {gc_txt}"
            )
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, guide)
            try:
                tooltip = [
                    f"Status: {'viable' if viable else 'rejected'}",
                    f"Guide: {guide.get('sequence')}",
                    f"PAM: {pam_seq} ({self._sim_settings.value.pam_profile or 'SpCas9_NGG'})",
                    f"Strand: {guide.get('strand')}",
                    f"GC: {guide.get('gc_content')}",
                ]
                if bool(guide.get("recommended_exploratory")) and viable:
                    tooltip.append("Recommended (exploratory): highest frameshift proxy among viable guides (tie-broken by off-target proxy).")

                metrics = guide.get("metrics") if isinstance(guide.get("metrics"), Mapping) else {}
                if viable and isinstance(pareto_front, int):
                    tooltip.append(
                        "Pareto: "
                        f"front {int(pareto_front)} (0 = non-dominated under proxy tradeoffs: "
                        "frameshift↑, off-target↓, GC deviation↓, distance↓, RNA hairpin↓)."
                    )
                elif viable:
                    tooltip.append("Pareto: n/a (missing required proxy metrics).")
                try:
                    dist = metrics.get("distance_to_target")
                    if dist is not None:
                        tooltip.append(f"Distance-to-target (proxy): {int(dist)} bp (target = window midpoint).")
                except Exception:
                    pass
                try:
                    stem = metrics.get("rna_hairpin_max_stem")
                    if stem is not None:
                        tooltip.append(f"RNA hairpin proxy: max stem {int(stem)} bp (lower is better).")
                except Exception:
                    pass
                try:
                    skew = metrics.get("rna_end_gc_skew")
                    if skew is not None:
                        tooltip.append(f"RNA end GC skew proxy: {float(skew):.3f} (lower is better).")
                except Exception:
                    pass

                fs = guide.get("frameshift_fraction")
                if isinstance(fs, (int, float)):
                    tooltip.append(
                        "Frameshift (proxy, indels only): "
                        f"{float(fs) * 100.0:.1f}% (exploratory; uncalibrated)."
                    )
                else:
                    tooltip.append("Frameshift (proxy, indels only): n/a (requires cut index).")

                ot_rank = str(guide.get("offtarget_rank") or "n/a")
                if ot_rank not in {"n/a", "skipped"}:
                    try:
                        hits = int(guide.get("offtarget_hits") or 0)
                    except Exception:
                        hits = 0
                    try:
                        worst = float(guide.get("offtarget_worst_score") or 0.0)
                    except Exception:
                        worst = 0.0
                    try:
                        burden = float(guide.get("offtarget_burden") or 0.0)
                    except Exception:
                        burden = 0.0
                    tooltip.append(
                        "Off-target (window-local proxy): "
                        f"{hits} hit(s) (≤3 mismatches), worst_score={worst:.3f}, burden≈{burden:.3f}."
                    )
                    tooltip.append("Off-target proxy scope: loaded sequence/window only (not genome-wide).")
                elif ot_rank == "skipped":
                    tooltip.append("Off-target (window-local proxy): skipped (sequence too large; use a smaller window).")
                else:
                    tooltip.append("Off-target (proxy): n/a (off-target mode disabled).")
                cut_idx = guide.get("cut_index")
                anchor_idx = guide.get("anchor_index")
                if cut_idx is not None:
                    tooltip.append(f"Cut index: {int(cut_idx)}")
                elif anchor_idx is not None:
                    tooltip.append("Cut index: n/a (non-3' PAM profile)")
                if anchor_idx is not None:
                    suffix = " (used for view centering)" if cut_idx is None else ""
                    tooltip.append(f"Anchor index: {int(anchor_idx)}{suffix}")
                if viable:
                    if self._apply_viability_filters:
                        tooltip.append(
                            "Passed filters: PAM match; no N; "
                            f"GC {GUIDE_VIABILITY_GC_MIN:.2f}–{GUIDE_VIABILITY_GC_MAX:.2f}; "
                            f"no poly-T≥{GUIDE_VIABILITY_POLY_T_RUN}."
                        )
                    else:
                        tooltip.append("Viability filters: disabled (enumerating all PAM-matching guides).")
                else:
                    reasons = guide.get("reject_reasons") if isinstance(guide.get("reject_reasons"), list) else []
                    pretty = [self._format_rejection_reason(r) for r in reasons]
                    tooltip.append("Rejected reasons: " + ", ".join(pretty) if pretty else "Rejected reasons: (unknown)")
                item.setToolTip("\n".join(tooltip))
            except Exception:
                pass
            self._guide_list.addItem(item)

        viable_count = len(self._guides)
        rejected_count = len(self._guides_rejected) if self._apply_viability_filters else 0
        self.guidesUpdated.emit(int(viable_count), int(rejected_count))

    def _sequence_or_warn(self) -> Optional[str]:
        if self._window_provider:
            try:
                window = self._window_provider()
            except Exception:
                window = None
            if window and window.sequence:
                seq = window.sequence.decode("ascii") if isinstance(window.sequence, (bytes, bytearray)) else str(window.sequence)
                return seq
        sequence = self._sequence_input.current_sequence()
        if not sequence:
            self.logMessage.emit("Provide a sequence (paste or load FASTA) before running CRISPR sims.")
            return None
        return sequence

    def _request_fm_build(self) -> None:
        parent = self.parent()
        if parent is not None and hasattr(parent, "_start_fm_build"):
            try:
                parent._start_fm_build()
            except Exception as exc:
                self.logMessage.emit(f"FM build failed to start: {exc}")

    def refresh_fm_state(self, available_path: Optional[Path], building: bool) -> None:
        if building:
            self.fm_status.setText("FM index: building…")
            self.fm_build_btn.setEnabled(False)
            self.offtarget_mode_combo.setEnabled(False)
            return
        if available_path and Path(available_path).exists():
            self.fm_status.setText(f"FM index ready: {available_path.name}")
            self.fm_build_btn.setText("Rebuild index")
            self.fm_build_btn.setEnabled(True)
            self.offtarget_mode_combo.setEnabled(True)
            try:
                idx = self.offtarget_mode_combo.findData("whole")
                model = self.offtarget_mode_combo.model()
                if idx >= 0 and model is not None and hasattr(model, "item"):
                    item = model.item(idx)
                    if item is not None:
                        item.setEnabled(True)
            except Exception:
                pass
        else:
            self.fm_status.setText("FM index: not built")
            self.fm_build_btn.setText("Build index")
            self.fm_build_btn.setEnabled(True)
            self.offtarget_mode_combo.setEnabled(True)
            try:
                idx = self.offtarget_mode_combo.findData("whole")
                model = self.offtarget_mode_combo.model()
                if idx >= 0 and model is not None and hasattr(model, "item"):
                    item = model.item(idx)
                    if item is not None:
                        item.setEnabled(False)
                if str(self.offtarget_mode_combo.currentData() or "") == "whole":
                    fallback = self.offtarget_mode_combo.findData("window")
                    if fallback >= 0:
                        self.offtarget_mode_combo.setCurrentIndex(fallback)
            except Exception:
                pass

    def _find_guides(self) -> None:
        sequence = self._sequence_or_warn()
        if not sequence:
            return
        pam_profile = self._sim_settings.value.pam_profile or "SpCas9_NGG"
        pam = self._pam_from_profile(pam_profile)
        pam_orientation = str(pam.get("orientation") or "3prime").lower() if isinstance(pam, Mapping) else "3prime"
        norm_seq = bioinformatics.normalize_sequence(sequence)

        window_chrom = "chrGui"
        window_start = 0
        window_end = len(norm_seq)
        if self._window_provider:
            try:
                window = self._window_provider()
            except Exception:
                window = None
            if window is not None:
                try:
                    window_chrom = str(getattr(window, "chrom", "") or window_chrom)
                except Exception:
                    window_chrom = window_chrom
                try:
                    window_start = int(getattr(window, "start", 0) or 0)
                    window_end = int(getattr(window, "end", window_end) or window_end)
                except Exception:
                    window_start = 0
                    window_end = len(norm_seq)
        try:
            self._guide_target_abs_index = int(window_start) + max(0, int(window_end - window_start)) // 2
        except Exception:
            self._guide_target_abs_index = None

        guides = guide_module.find_guides(norm_seq, pam, self._guide_len.value(), strand="both")
        self._guides_all = [dict(g) for g in guides if isinstance(g, Mapping)]
        for guide in self._guides_all:
            guide.setdefault("chrom", window_chrom)
            try:
                pam_site = guide.get("pam_site") if isinstance(guide.get("pam_site"), Mapping) else None
                if pam_site is not None:
                    ps = int(pam_site.get("start", 0))
                    pe = int(pam_site.get("end", ps))
                    if 0 <= ps <= pe <= len(norm_seq):
                        guide["pam_seq"] = norm_seq[ps:pe].upper()
            except Exception:
                pass
            try:
                start = int(guide.get("start", 0))
                end = int(guide.get("end", start))
                strand = str(guide.get("strand", "+"))
                guide["abs_start"] = int(window_start) + start
                guide["abs_end"] = int(window_start) + end
                guide["anchor_index"] = int(anchor_midpoint_index(start, end))
                guide["abs_anchor_index"] = int(window_start) + int(guide["anchor_index"])
                if pam_orientation == "3prime":
                    cut_idx = max(start, end - 3) if strand == "+" else min(end, start + 3)
                    guide["cut_index"] = int(cut_idx)
                    guide["abs_cut_index"] = int(window_start) + int(cut_idx)
            except Exception:
                pass

        self._annotate_guides_with_proxies(norm_seq, pam_profile=pam_profile)
        self._recompute_viability()
        self._update_guide_list()

        # Causal continuity: auto-focus to the first returned guide.
        try:
            if self._guide_list.count() > 0:
                self._guide_list.setCurrentRow(0)
                first = self._guide_list.item(0)
                if first is not None:
                    self._guide_list.scrollToItem(first)
        except Exception:
            pass

        viable_count, rejected_count = self.guide_counts()
        if viable_count == 0 and (not self._apply_viability_filters or rejected_count == 0):
            self.logMessage.emit("No guides found with the current parameters.")
        else:
            parts = [f"PAM {pam_profile}", f"viable {viable_count}"]
            if self._apply_viability_filters and rejected_count:
                parts.append(f"rejected {rejected_count}")
            self.logMessage.emit(
                "Located guides (" + ", ".join(parts) + "). "
                "Select one, then run the simulation step."
            )

    def _refresh_guide_proxies(self) -> None:
        if not self._guides_all:
            return
        sequence = self._sequence_or_warn()
        if not sequence:
            return
        pam_profile = self._sim_settings.value.pam_profile or "SpCas9_NGG"
        norm_seq = bioinformatics.normalize_sequence(sequence)
        self._annotate_guides_with_proxies(norm_seq, pam_profile=pam_profile)
        self._recompute_viability()
        self._update_guide_list()

    def _selected_guide(self) -> Optional[dict]:
        item = self._guide_list.currentItem()
        if not item:
            return None
        return item.data(Qt.UserRole)

    def _on_guide_changed(self) -> None:
        guide = self._selected_guide()
        if guide is None:
            return
        try:
            self.guideFocusChanged.emit(guide)
        except Exception:
            pass
        try:
            chrom = guide.get("chrom") or guide.get("chromosome") or guide.get("chr") or "chr"
            if guide.get("cut_index") is not None:
                cut = int(guide.get("cut_index") or 0)
            elif guide.get("anchor_index") is not None:
                cut = int(guide.get("anchor_index") or 0)
            elif guide.get("cut") is not None:
                cut = int(guide.get("cut") or 0)
            elif guide.get("pam_index") is not None:
                cut = int(guide.get("pam_index") or 0)
            else:
                cut = int(guide.get("start") or 0)
            if hasattr(self.parent(), "window_len"):
                view_len = max(50, int(self.parent().window_len.value()))
            else:
                view_len = 1000
            half = view_len // 2
            start = max(0, cut - half)
            if hasattr(self.parent(), "_set_active_window"):
                self.parent()._set_active_window(chrom, start, view_len)
        except Exception:
            return

    def _simulate(self) -> None:
        try:
            from helix.studio.debug_runtime import log_pid

            log_pid("run_clicked.crispr")
        except Exception:
            pass
        sequence = self._sequence_or_warn()
        if not sequence:
            self.runFailed.emit("CRISPR", "No sequence provided.")
            return

        guide = self._selected_guide()
        if not guide:
            self.logMessage.emit("Select a guide before running the simulation.")
            self.runFailed.emit("CRISPR", "No guide selected.")
            return

        shared = self._sim_settings.value
        draws = max(1, shared.draws)
        seed = shared.seed
        pam_profile = shared.pam_profile or "SpCas9_NGG"
        pam_softness = shared.pam_softness
        priors_profile = shared.priors_profile or "default_indel"
        seed_label = "auto" if seed is None else str(seed)
        env_dag_mode = _parse_env_flag("HELIX_DAG_MODE")
        use_dag_mode = env_dag_mode if env_dag_mode is not None else bool(shared.dag_mode)
        mode_label = "DAG" if use_dag_mode else "legacy"
        mode_source = "env" if env_dag_mode is not None else "ui"
        self.logMessage.emit(
            f"Running CRISPR simulation [{mode_label} mode/{mode_source}] "
            f"(draws={draws}, seed={seed_label}, pam={pam_profile}, softness={pam_softness}, priors={priors_profile})…"
        )

        norm_seq = bioinformatics.normalize_sequence(sequence)
        self._last_genome = DigitalGenome(sequences={"chrGui": norm_seq})
        search_mode = str(self.offtarget_mode_combo.currentData() or "window")
        self._last_run_config = {
            "mode": "dag" if use_dag_mode else "legacy",
            "dag_mode": bool(use_dag_mode),
            "dag_mode_source": mode_source,
            "draws": draws,
            "seed": seed,
            "pam_profile": pam_profile,
            "pam_softness": pam_softness,
            "priors_profile": priors_profile,
            "search_mode": search_mode,
        }
        self._last_guide = guide
        if search_mode == "whole":
            meta = self._sequence_input.sequence_metadata()
            gid = meta.get("genome_id") if isinstance(meta, dict) else None
            if gid:
                fm_path = resolve_fm_index(str(gid))
                if fm_path and Path(fm_path).exists():
                    self._last_run_config["fm_index_path"] = str(fm_path)
                else:
                    self.logMessage.emit("Whole-genome off-target requested but FM index is missing; falling back to local.")
                    search_mode = "window"
                    self._last_run_config["search_mode"] = search_mode
                    try:
                        idx = self.offtarget_mode_combo.findData(search_mode)
                        if idx >= 0:
                            self.offtarget_mode_combo.setCurrentIndex(idx)
                    except Exception:
                        pass

        # Capture only primitives and immutable data into the closure.
        def task():
            if use_dag_mode:
                # DAG-first path: build a CRISPR edit DAG and adapt it to a viz spec.
                genome = self._last_genome or DigitalGenome(sequences={"chrGui": norm_seq})
                pam_cfg = guide_module.get_pam(pam_profile) if pam_profile else {"pattern": "NGG"}
                pattern = pam_cfg.get("pattern") or "NGG"
                cas = CasSystem(
                    name=f"GUI-{pam_profile}",
                    system_type=CasSystemType.CAS9,
                    pam_rules=[PAMRule(pattern=pattern)],
                    cut_offset=3,
                    max_mismatches=3,
                    weight_mismatch_penalty=1.0,
                    weight_pam_penalty=2.0,
                )
                guide_seq = guide.get("sequence") or norm_seq
                guide_obj = GuideRNA(
                    sequence=bioinformatics.normalize_sequence(str(guide_seq)),
                    pam=pattern,
                    name=str(guide.get("id") or guide.get("name") or "guide"),
                    metadata={"strand": str(guide.get("strand", "+"))},
                )
                dag = build_crispr_edit_dag(
                    genome,
                    cas,
                    guide_obj,
                    rng_seed=seed or 0,
                    max_depth=2,
                    min_prob=1e-4,
                    max_sites=50,
                    use_gpu=False,
                    frame_consumer=None,
                )
                # Reuse CLI payload shape for adapters and downstream tooling.
                from helix.cli import _edit_dag_to_payload  # local import to avoid cycles

                dag_payload = _edit_dag_to_payload(
                    dag,
                    artifact="helix.crispr.edit_dag.v1.1",
                    metadata={
                        "source": "gui.crispr_dag_mode",
                        "guide": guide,
                        "site_sequence": norm_seq,
                    },
                )
                try:
                    _augment_payload_audit(dag_payload, kind="CRISPR", run_config=self._last_run_config)
                except Exception:
                    pass
                # Provide a crispr.sim-like `outcomes` list for Studio panels that
                # expect it (Outcome Explorer, run metrics). This is derived from
                # DAG leaf nodes and is intentionally a best-effort adapter.
                try:
                    from helix.gui.modern.dag_adapters import crispr_dag_to_sim_payload

                    sim_like = crispr_dag_to_sim_payload(dag_payload)
                    raw_outcomes = sim_like.get("outcomes") if isinstance(sim_like, Mapping) else None
                    if isinstance(raw_outcomes, list) and raw_outcomes:
                        dag_payload["outcomes"] = [dict(o) for o in raw_outcomes if isinstance(o, Mapping)]
                except Exception:
                    pass
                spec = crispr_dag_to_viz_spec(dag_payload)
                if spec is None:
                    raise ValueError("Failed to build CRISPR visualization spec from DAG.")
                # Ensure the Studio workflow/analytics panels can light up immediately
                # (they rely on workflow_view being present at state-change time).
                try:
                    from helix.gui.modern.dag_adapters import crispr_dag_to_workflow

                    wf = crispr_dag_to_workflow(dag_payload)
                    if isinstance(wf, Mapping):
                        meta = spec.metadata or {}
                        meta["workflow_view"] = _workflow_to_serializable(dict(wf))
                        spec.metadata = meta
                except Exception:
                    pass
                return dag_payload, spec

            # Legacy sim-payload path (default).
            priors = resolve_crispr_priors(priors_profile)
            pam_mask = build_crispr_pam_mask(sequence, guide, pam_profile, pam_softness)
            payload = simulate_cut_repair(
                site_seq=sequence,
                guide=guide,
                priors=priors,
                draws=draws,
                seed=seed,
                emit_sequence=True,
                pam_mask=pam_mask,
                pam_profile=str(pam_profile) if pam_profile is not None else None,
                off_target_mode=search_mode,
            )

            viz_mode = (shared.viz_mode or "rail_3d").lower()
            if viz_mode == "orbitals_3d":
                spec = build_crispr_orbitals_3d_spec(sequence, guide, payload)
            else:
                spec = build_crispr_rail_3d_spec(sequence, guide, payload)
            if spec is None:
                spec = build_crispr_viz_spec(sequence, guide, payload)
            if spec is None:
                raise ValueError("Failed to build CRISPR visualization spec.")

            meta = spec.metadata or {}
            workflow = build_workflow2p5d_crispr(sequence, guide, payload)
            meta["workflow_view"] = _workflow_to_serializable(workflow)
            spec.metadata = meta

            return payload, spec

        self.runStarted.emit("CRISPR")
        self._start_worker(task)

    def trigger_simulation(self) -> None:
        self._simulate()

    def _start_worker(self, task: Callable[[], tuple[dict, Optional[EditVisualizationSpec]]]) -> None:
        if self._active_thread is not None:
            self.logMessage.emit("Simulation already running. Please wait for it to finish.")
            return

        self._simulate_btn.setEnabled(False)

        worker = SimJobWorker(task)
        thread = QThread(self)

        # Keep references so Python can't collect them early.
        self._active_thread = thread
        self._active_worker = worker

        worker.moveToThread(thread)

        # Success/failure handling
        worker.finished.connect(self._on_worker_success, Qt.QueuedConnection)
        worker.failed.connect(self._on_worker_failure, Qt.QueuedConnection)

        # Clean up worker + thread
        worker.finished.connect(worker.deleteLater)
        worker.failed.connect(worker.deleteLater)

        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)

        thread.finished.connect(self._on_thread_finished)
        thread.finished.connect(thread.deleteLater)

        thread.started.connect(worker.run)

        self._mark_run_start()
        thread.start()

    def _mark_run_start(self) -> None:
        self._run_start = clock.perf_counter()
        self._last_run_ms = None

    def _mark_run_end(self) -> float | None:
        if self._run_start is None:
            return None
        elapsed = max(0.0, (clock.perf_counter() - self._run_start) * 1000.0)
        self._run_start = None
        self._last_run_ms = elapsed
        return elapsed

    def _on_thread_finished(self) -> None:
        self._active_thread = None
        self._active_worker = None
        self._simulate_btn.setEnabled(True)
        self.logMessage.emit("Simulation finished.")

    def _on_worker_success(self, payload: dict, spec: EditVisualizationSpec) -> None:
        try:
            _augment_payload_audit(payload, kind="CRISPR", run_config=getattr(self, "_last_run_config", None))
        except Exception:
            pass
        self._last_payload = payload
        self._last_spec = spec
        self._save_sim_btn.setEnabled(True)
        self._save_spec_btn.setEnabled(True)
        self.simPayloadReady.emit(payload)
        self.specReady.emit(spec)
        self.runCompleted.emit("CRISPR", payload, spec)
        duration_ms = self._mark_run_end()
        if duration_ms is not None:
            self.logMessage.emit(f"CRISPR simulation complete ({duration_ms:.0f} ms).")
        else:
            self.logMessage.emit("CRISPR simulation complete.")
        try:
            hits = (
                payload.get("offtarget_hits")
                or payload.get("off_targets")
                or payload.get("offtargets")
                or []
            )
            if isinstance(hits, list) and hits:
                scores = []
                for h in hits:
                    if not isinstance(h, Mapping):
                        continue
                    try:
                        scores.append(float(h.get("score", 0.0)))
                    except Exception:
                        continue
                worst = max(scores) if scores else 0.0
                self.logMessage.emit(f"Off-targets: {len(hits)} hit(s) (worst score {worst:.3f}).")
        except Exception:
            pass
        outcomes = payload.get("outcomes") or []
        top = outcomes[0] if outcomes else None
        LOGGER.debug("CRISPR top outcome: %r", top)
        LOGGER.debug("CRISPR priors (keys): %r", list(payload.get("priors", {}).keys()))
        LOGGER.debug("CRISPR spec.edit_type: %s", getattr(spec, "edit_type", "<none>"))

    def _on_worker_failure(self, message: str) -> None:
        self._mark_run_end()
        QMessageBox.critical(self, "CRISPR simulation failed", message)
        self.logMessage.emit(f"CRISPR simulation failed: {message}")
        self.runFailed.emit("CRISPR", message)

    def shutdown(self) -> None:
        if self._active_thread is not None:
            self._active_thread.quit()
            self._active_thread.wait()
            self._active_thread = None
        self._simulate_btn.setEnabled(True)

    def _export_json(self, title: str, payload_getter: Callable[[], Optional[dict]]) -> None:
        payload = payload_getter()
        if not payload:
            self.logMessage.emit(f"No {title} available yet.")
            return
        path_str, _ = QFileDialog.getSaveFileName(self, f"Save {title}", filter="JSON (*.json)")
        if not path_str:
            return
        Path(path_str).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        self.logMessage.emit(f"Saved {title} to {path_str}.")

    def _export_spec(self, spec_getter: Callable[[], Optional[EditVisualizationSpec]]) -> None:
        spec = spec_getter()
        if not spec:
            self.logMessage.emit("No viz spec available yet.")
            return
        payload = spec.to_payload()
        path_str, _ = QFileDialog.getSaveFileName(self, "Save Viz Spec", filter="JSON (*.json)")
        if not path_str:
            return
        Path(path_str).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        self.logMessage.emit(f"Saved viz spec to {path_str}.")

    @property
    def last_genome(self) -> Optional[DigitalGenome]:
        return self._last_genome

    @property
    def last_peg(self) -> Optional[PegRNA]:
        return self._last_peg

    @property
    def last_editor(self) -> Optional[PrimeEditor]:
        return self._last_editor

    @property
    def last_run_config(self) -> dict[str, Any]:
        return dict(self._last_run_config)

    def save_state(self, settings: QSettings) -> None:
        settings.setValue("crispr/guide_len", self._guide_len.value())

    def load_state(self, settings: QSettings) -> None:
        guide_len = settings.value("crispr/guide_len")
        if guide_len is not None:
            self._guide_len.setValue(int(float(guide_len)))

    def _pam_from_profile(self, profile: str) -> dict[str, str]:
        profile = profile or "SpCas9_NGG"
        preset = PAM_PROFILE_PRESETS.get(profile)
        if preset:
            pam_name = preset.get("pam")
            if pam_name:
                try:
                    return guide_module.get_pam(pam_name)
                except Exception:  # pragma: no cover - fallback to literal definitions
                    LOGGER.warning("Unknown PAM preset '%s'. Falling back to literal pattern.", pam_name)
            pattern = preset.get("pattern")
            if pattern:
                return {"pattern": pattern, "orientation": preset.get("orientation", "3prime")}
        normalized = profile.replace("_", "-")
        for token in (profile, normalized):
            if token:
                try:
                    return guide_module.get_pam(token)
                except Exception:
                    continue
        pattern = profile.replace("-", "").replace("_", "")
        if not pattern:
            pattern = "NGG"
        LOGGER.info("Treating PAM profile '%s' as literal pattern '%s'.", profile, pattern)
        return {"pattern": pattern.upper(), "orientation": "3prime"}

    @property
    def last_genome(self) -> Optional[DigitalGenome]:
        return self._last_genome

    @property
    def last_run_config(self) -> dict[str, Any]:
        return dict(self._last_run_config)

    @property
    def last_guide(self) -> Optional[dict[str, Any]]:
        return self._last_guide

    @property
    def last_run_duration_ms(self) -> Optional[float]:
        return self._last_run_ms


class RunHistoryPanel(QWidget):
    """Displays completed simulations with preview/export helpers."""

    previewRequested = Signal(object)
    logMessage = Signal(str)
    _VIZ_SUFFIXES = (
        "rail_3d",
        "rail_2d",
        "orbitals_3d",
        "orbitals",
        "prime_scaffold_3d",
        "scaffold_3d",
        "workflow_2p5d",
    )

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        header = QLabel("Run History", self)
        header.setStyleSheet("font-weight: 600;")
        layout.addWidget(header)
        self._list = QListWidget(self)
        layout.addWidget(self._list)
        btn_row = FlowLayout(hspacing=8, vspacing=6)
        self._preview_btn = QPushButton("Preview", self)
        self._save_sim_btn = QPushButton("Save .sim…", self)
        self._save_spec_btn = QPushButton("Save Viz Spec…", self)
        self._save_dag_btn = QPushButton("Save DAG…", self)
        self._save_dag_btn.setEnabled(False)
        btn_row.addWidget(self._preview_btn)
        btn_row.addWidget(self._save_sim_btn)
        btn_row.addWidget(self._save_spec_btn)
        btn_row.addWidget(self._save_dag_btn)
        layout.addLayout(btn_row)

        self._preview_btn.clicked.connect(self._preview_selected)
        self._save_sim_btn.clicked.connect(self._save_sim)
        self._save_spec_btn.clicked.connect(self._save_spec)
        self._save_dag_btn.clicked.connect(self._save_dag)
        self._list.itemDoubleClicked.connect(lambda _: self._preview_selected())
        self._list.currentItemChanged.connect(lambda _current, _previous: self._update_save_buttons())

    def add_entry(self, kind: str, spec: EditVisualizationSpec, payload: dict, viz_mode: str | None = None) -> None:
        meta = spec.metadata or {}
        label_text = meta.get("label") or meta.get("name") or spec.edit_type
        display_label = self._format_label(kind, label_text, viz_mode)
        item = QListWidgetItem(display_label)
        is_dag = isinstance(payload, dict) and isinstance(payload.get("artifact"), str)
        item.setData(Qt.UserRole, {"spec": spec, "payload": payload, "kind": kind, "is_dag": is_dag})
        self._list.addItem(item)
        self._list.setCurrentItem(item)
        self._update_save_buttons()

    def _format_label(self, kind: str, label: str, viz_mode: str | None) -> str:
        if viz_mode:
            base = self._strip_viz_suffix(label)
            return f"[{kind}] {base} ({viz_mode})"
        return f"[{kind}] {label}"

    @classmethod
    def _strip_viz_suffix(cls, label: str) -> str:
        lower = label.lower()
        for suffix in cls._VIZ_SUFFIXES:
            token = f" ({suffix})"
            if lower.endswith(token):
                return label[: -len(token)]
        return label

    def _current_entry(self) -> Optional[dict]:
        item = self._list.currentItem()
        if not item:
            return None
        return item.data(Qt.UserRole)

    def _preview_selected(self) -> None:
        entry = self._current_entry()
        if not entry:
            self.logMessage.emit("Select a run from the history to preview.")
            return
        spec: EditVisualizationSpec = entry["spec"]
        self.previewRequested.emit(spec)

    def _update_save_buttons(self) -> None:
        entry = self._current_entry()
        is_dag = bool(entry and entry.get("is_dag"))
        self._save_dag_btn.setEnabled(is_dag)

    def _save_sim(self) -> None:
        entry = self._current_entry()
        if not entry:
            self.logMessage.emit("Select a run before saving a simulation payload.")
            return
        payload = entry["payload"]
        path_str, _ = QFileDialog.getSaveFileName(self, "Save Simulation JSON", filter="JSON (*.json)")
        if not path_str:
            return
        Path(path_str).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        self.logMessage.emit(f"Saved simulation payload to {path_str}.")

    def _save_spec(self) -> None:
        entry = self._current_entry()
        if not entry:
            self.logMessage.emit("Select a run before saving a viz spec.")
            return
        spec: EditVisualizationSpec = entry["spec"]
        path_str, _ = QFileDialog.getSaveFileName(self, "Save Viz Spec", filter="JSON (*.json)")
        if not path_str:
            return
        Path(path_str).write_text(json.dumps(spec.to_payload(), indent=2) + "\n", encoding="utf-8")
        self.logMessage.emit(f"Saved viz spec to {path_str}.")

    def _save_dag(self) -> None:
        entry = self._current_entry()
        if not entry:
            self.logMessage.emit("Select a run before saving an edit DAG payload.")
            return
        payload = entry["payload"]
        if not isinstance(payload, dict) or "artifact" not in payload:
            self.logMessage.emit("Selected run does not contain an edit DAG payload.")
            return
        path_str, _ = QFileDialog.getSaveFileName(
            self,
            "Save Edit DAG",
            filter="Edit DAG (*.edit_dag.json);;JSON (*.json)",
        )
        if not path_str:
            return
        Path(path_str).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        self.logMessage.emit(f"Saved edit DAG payload to {path_str}.")


class PrimeTab(QWidget):
    """Prime editing form."""

    specReady = Signal(object)
    simPayloadReady = Signal(object)
    logMessage = Signal(str)
    runCompleted = Signal(str, object, object)
    runStarted = Signal(str)
    runFailed = Signal(str, str)

    def __init__(
        self,
        sequence_input: SequenceInput,
        sim_settings: SimSettingsModel,
        parent: QWidget | None = None,
        *,
        window_provider=None,
    ) -> None:
        super().__init__(parent)
        self._sequence_input = sequence_input
        self._sim_settings = sim_settings
        self._window_provider = window_provider
        self._last_payload: Optional[dict] = None
        self._last_spec: Optional[EditVisualizationSpec] = None
        self._active_thread: QThread | None = None
        self._active_worker: SimJobWorker | None = None
        self._last_genome: Optional[DigitalGenome] = None
        self._last_peg: Optional[PegRNA] = None
        self._last_editor: Optional[PrimeEditor] = None
        self._last_run_config: dict[str, Any] = {}
        self._run_start: float | None = None
        self._last_run_ms: float | None = None

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self._peg_name = QLineEdit("peg-demo", self)
        self._spacer = QLineEdit(self)
        self._pbs = QLineEdit(self)
        self._rtt = QLineEdit(self)
        form.addRow("pegRNA name", self._peg_name)
        form.addRow("Spacer", self._spacer)
        form.addRow("PBS", self._pbs)
        form.addRow("RTT", self._rtt)
        layout.addLayout(form)

        editor_form = QFormLayout()
        self._editor_name = QLineEdit("PrimeEditor", self)
        self._nick_offset = QSpinBox(self)
        self._nick_offset.setRange(-50, 50)
        self._nick_offset.setValue(0)
        self._efficiency = QDoubleSpinBox(self)
        self._efficiency.setRange(0.0, 2.0)
        self._efficiency.setSingleStep(0.1)
        self._efficiency.setValue(0.8)
        self._indel_bias = QDoubleSpinBox(self)
        self._indel_bias.setRange(0.0, 1.0)
        self._indel_bias.setSingleStep(0.05)
        self._indel_bias.setValue(0.2)
        self._mismatch_tol = QSpinBox(self)
        self._mismatch_tol.setRange(0, 20)
        self._mismatch_tol.setValue(3)
        self._max_outcomes = QSpinBox(self)
        self._max_outcomes.setRange(1, 64)
        self._max_outcomes.setValue(8)

        editor_form.addRow("Editor name", self._editor_name)
        editor_form.addRow("Nick offset", self._nick_offset)
        editor_form.addRow("Efficiency scale", self._efficiency)
        editor_form.addRow("Indel bias", self._indel_bias)
        editor_form.addRow("Mismatch tolerance", self._mismatch_tol)
        editor_form.addRow("Max outcomes", self._max_outcomes)
        layout.addLayout(editor_form)

        btn_row = FlowLayout(hspacing=8, vspacing=6)
        self._simulate_btn = QPushButton("Simulate Prime Edit", self)
        self._save_sim_btn = QPushButton("Save prime.edit_sim…", self)
        self._save_spec_btn = QPushButton("Save Viz Spec…", self)
        self._save_sim_btn.setEnabled(False)
        self._save_spec_btn.setEnabled(False)
        btn_row.addWidget(self._simulate_btn)
        btn_row.addWidget(self._save_sim_btn)
        btn_row.addWidget(self._save_spec_btn)
        layout.addLayout(btn_row)
        layout.addStretch(1)

        fm_layout = QVBoxLayout()
        self.fm_status = QLabel("FM index: not built", self)
        self.offtarget_mode_combo = QComboBox(self)
        self.offtarget_mode_combo.addItem("Sequence-only (no off-targets)", userData="none")
        self.offtarget_mode_combo.addItem("Local off-target (within loaded sequence)", userData="window")
        self.offtarget_mode_combo.addItem("Whole-genome off-target (FM index)", userData="whole")
        self.offtarget_mode_combo.setCurrentIndex(1)
        self.offtarget_mode_combo.setToolTip(
            "Off-target evaluation mode:\n"
            "  - Sequence-only: no off-target computation.\n"
            "  - Local: enumerate near-matches within the loaded sequence/window.\n"
            "  - Whole-genome: requires a built FM index for the ingested genome."
        )
        self.fm_build_btn = QPushButton("Build index", self)
        self.fm_build_btn.clicked.connect(self._request_fm_build)
        fm_layout.addWidget(self.fm_status)
        fm_layout.addWidget(self.offtarget_mode_combo)
        fm_layout.addWidget(self.fm_build_btn)
        layout.addLayout(fm_layout)

        self._simulate_btn.clicked.connect(self._simulate)
        self._save_sim_btn.clicked.connect(partial(self._export_json, "prime.edit_sim json", lambda: self._last_payload))
        self._save_spec_btn.clicked.connect(partial(self._export_spec, lambda: self._last_spec))

    def _request_fm_build(self) -> None:
        """Ask parent widget to start/queue an FM index build."""
        parent = self.parent()
        if parent is not None and hasattr(parent, "_start_fm_build"):
            try:
                parent._start_fm_build()
            except Exception as exc:  # pragma: no cover - UI safety
                self.logMessage.emit(f"FM build failed to start: {exc}")

    def refresh_fm_state(self, available_path: Optional[Path], building: bool) -> None:
        """Update FM index controls based on availability and build state."""
        if building:
            self.fm_status.setText("FM index: building…")
            self.fm_build_btn.setEnabled(False)
            self.offtarget_mode_combo.setEnabled(False)
            return
        if available_path and Path(available_path).exists():
            self.fm_status.setText(f"FM index ready: {Path(available_path).name}")
            self.fm_build_btn.setText("Rebuild index")
            self.fm_build_btn.setEnabled(True)
            self.offtarget_mode_combo.setEnabled(True)
            try:
                idx = self.offtarget_mode_combo.findData("whole")
                model = self.offtarget_mode_combo.model()
                if idx >= 0 and model is not None and hasattr(model, "item"):
                    item = model.item(idx)
                    if item is not None:
                        item.setEnabled(True)
            except Exception:
                pass
        else:
            self.fm_status.setText("FM index: not built")
            self.fm_build_btn.setText("Build index")
            self.fm_build_btn.setEnabled(True)
            self.offtarget_mode_combo.setEnabled(True)
            try:
                idx = self.offtarget_mode_combo.findData("whole")
                model = self.offtarget_mode_combo.model()
                if idx >= 0 and model is not None and hasattr(model, "item"):
                    item = model.item(idx)
                    if item is not None:
                        item.setEnabled(False)
                if str(self.offtarget_mode_combo.currentData() or "") == "whole":
                    fallback = self.offtarget_mode_combo.findData("window")
                    if fallback >= 0:
                        self.offtarget_mode_combo.setCurrentIndex(fallback)
            except Exception:
                pass

    def _sequence_or_warn(self) -> Optional[str]:
        if self._window_provider:
            try:
                window = self._window_provider()
            except Exception:
                window = None
            if window and window.sequence:
                seq = window.sequence.decode("ascii") if isinstance(window.sequence, (bytes, bytearray)) else str(window.sequence)
                return seq
        sequence = self._sequence_input.current_sequence()
        if not sequence:
            self.logMessage.emit("Provide a sequence before running prime simulations.")
            self.runFailed.emit("PRIME", "No sequence provided.")
            return None
        return sequence

    def _simulate(self) -> None:
        try:
            from helix.studio.debug_runtime import log_pid

            log_pid("run_clicked.prime")
        except Exception:
            pass
        sequence = self._sequence_or_warn()
        if not sequence:
            return
        spacer = self._spacer.text().strip()
        pbs = self._pbs.text().strip()
        rtt = self._rtt.text().strip()
        if not spacer or not pbs or not rtt:
            self.logMessage.emit("Spacer, PBS, and RTT fields are required for prime simulations.")
            self.runFailed.emit("PRIME", "pegRNA fields missing.")
            return

        peg = PegRNA(spacer=spacer, pbs=pbs, rtt=rtt, name=self._peg_name.text().strip() or None)
        cas = CasSystem(
            name="SimBuilder-Cas9",
            system_type=CasSystemType.CAS9,
            pam_rules=[PAMRule(pattern="NGG", description="SpCas9")],
            cut_offset=3,
        )
        editor = PrimeEditor(
            name=self._editor_name.text().strip() or "PrimeEditor",
            cas=cas,
            nick_to_edit_offset=self._nick_offset.value(),
            efficiency_scale=self._efficiency.value(),
            indel_bias=self._indel_bias.value(),
            mismatch_tolerance=self._mismatch_tol.value(),
        )
        chrom_name = "chr"
        if self._window_provider:
            try:
                w = self._window_provider()
                if w and w.chrom:
                    chrom_name = w.chrom
            except Exception:
                pass
        genome = DigitalGenome({chrom_name: sequence})
        shared = self._sim_settings.value
        draws = max(1, shared.draws)
        seed = shared.seed
        pam_profile = shared.pam_profile or "SpCas9_NGG"
        pam_softness = shared.pam_softness
        priors_profile = shared.priors_profile or "default_indel"
        seed_label = "auto" if seed is None else str(seed)
        self.logMessage.emit(
            "Running prime editing simulation "
            f"(draws={draws}, seed={seed_label}, priors={priors_profile}, PAM={pam_profile})…"
        )
        self._last_genome = genome
        self._last_peg = peg
        self._last_editor = editor
        search_mode = str(self.offtarget_mode_combo.currentData() or "window")
        self._last_run_config = {
            "draws": draws,
            "seed": seed,
            "pam_profile": pam_profile,
            "pam_softness": pam_softness,
            "priors_profile": priors_profile,
            "search_mode": search_mode,
        }
        if search_mode == "whole":
            meta = self._sequence_input.sequence_metadata()
            gid = meta.get("genome_id") if isinstance(meta, dict) else None
            if gid:
                fm_path = resolve_fm_index(str(gid))
                if fm_path and Path(fm_path).exists():
                    self._last_run_config["fm_index_path"] = str(fm_path)
                else:
                    self.logMessage.emit("Whole-genome off-target requested but FM index is missing; falling back to local.")
                    search_mode = "window"
                    self._last_run_config["search_mode"] = search_mode
                    try:
                        idx = self.offtarget_mode_combo.findData(search_mode)
                        if idx >= 0:
                            self.offtarget_mode_combo.setCurrentIndex(idx)
                    except Exception:
                        pass

        def task() -> tuple[dict, Optional[EditVisualizationSpec]]:
            priors = resolve_prime_priors(priors_profile)
            pam_mask = build_prime_pam_mask(sequence, peg, pam_profile, pam_softness)
            payload = simulate_prime_edit(
                site_seq=sequence,
                peg=peg,
                priors=priors,
                draws=draws,
                seed=seed,
                emit_sequence=True,
                pam_mask=pam_mask,
            )
            viz_mode = (shared.viz_mode or "").lower()
            if viz_mode == "prime_scaffold_3d":
                spec = build_prime_scaffold_3d_spec(genome, peg, editor, payload)
            else:
                spec = build_prime_viz_spec(genome, peg, editor, payload)
            if spec is None:
                raise ValueError("Failed to build prime viz spec.")

            workflow = build_workflow2p5d_prime(sequence, payload)
            meta = spec.metadata or {}
            meta["workflow_view"] = _workflow_to_serializable(workflow)
            spec.metadata = meta

            return payload, spec

        self.runStarted.emit("PRIME")
        self._start_worker(task)

    def trigger_simulation(self) -> None:
        self._simulate()

    def _start_worker(self, task: Callable[[], tuple[dict, Optional[EditVisualizationSpec]]]) -> None:
        if self._active_thread is not None:
            self.logMessage.emit("Simulation already running. Please wait for it to finish.")
            return
        self._simulate_btn.setEnabled(False)
        def safe_task():
            try:
                return task()
            except Exception as exc:
                LOGGER.exception("Prime simulation failed:")
                raise

        worker = SimJobWorker(safe_task)
        thread = QThread(self)
        self._active_thread = thread
        self._active_worker = worker

        worker.moveToThread(thread)
        worker.finished.connect(self._on_worker_success, Qt.QueuedConnection)
        worker.failed.connect(self._on_worker_failure, Qt.QueuedConnection)
        worker.finished.connect(worker.deleteLater)
        worker.failed.connect(worker.deleteLater)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(self._on_thread_finished)
        thread.finished.connect(thread.deleteLater)
        thread.started.connect(worker.run)
        self._mark_run_start()
        thread.start()

    def _mark_run_start(self) -> None:
        self._run_start = clock.perf_counter()
        self._last_run_ms = None

    def _mark_run_end(self) -> float | None:
        if self._run_start is None:
            return None
        elapsed = max(0.0, (clock.perf_counter() - self._run_start) * 1000.0)
        self._run_start = None
        self._last_run_ms = elapsed
        return elapsed

    def _on_thread_finished(self) -> None:
        self._active_thread = None
        self._active_worker = None
        self._simulate_btn.setEnabled(True)

    def _on_worker_success(self, payload: dict, spec: EditVisualizationSpec) -> None:
        try:
            _augment_payload_audit(payload, kind="PRIME", run_config=getattr(self, "_last_run_config", None))
        except Exception:
            pass
        self._last_payload = payload
        self._last_spec = spec
        self._save_sim_btn.setEnabled(True)
        self._save_spec_btn.setEnabled(True)
        self.simPayloadReady.emit(payload)
        self.specReady.emit(spec)
        self.runCompleted.emit("PRIME", payload, spec)
        duration_ms = self._mark_run_end()
        if duration_ms is not None:
            self.logMessage.emit(f"Prime simulation complete ({duration_ms:.0f} ms).")
        else:
            self.logMessage.emit("Prime simulation complete.")
        top = payload.get("outcomes", [{}])
        top_label = top[0].get("label") if top and isinstance(top[0], dict) else None
        LOGGER.debug(
            "Prime sim outcome: top=%s priors=%s",
            top_label,
            list(payload.get("priors", {}).keys()),
        )

    def _on_worker_failure(self, message: str) -> None:
        self._mark_run_end()
        QMessageBox.critical(self, "Prime simulation failed", message)
        self.logMessage.emit(f"Prime simulation failed: {message}")
        self.runFailed.emit("PRIME", message)

    def shutdown(self) -> None:
        if self._active_thread is not None:
            self._active_thread.quit()
            self._active_thread.wait()
            self._active_thread = None
        self._simulate_btn.setEnabled(True)

    def _export_json(self, title: str, payload_getter: Callable[[], Optional[dict]]) -> None:
        payload = payload_getter()
        if not payload:
            self.logMessage.emit(f"No {title} available yet.")
            return
        path_str, _ = QFileDialog.getSaveFileName(self, f"Save {title}", filter="JSON (*.json)")
        if not path_str:
            return
        Path(path_str).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        self.logMessage.emit(f"Saved {title} to {path_str}.")

    def _export_spec(self, spec_getter: Callable[[], Optional[EditVisualizationSpec]]) -> None:
        spec = spec_getter()
        if not spec:
            self.logMessage.emit("No viz spec available yet.")
            return
        payload = spec.to_payload()
        path_str, _ = QFileDialog.getSaveFileName(self, "Save Viz Spec", filter="JSON (*.json)")
        if not path_str:
            return
        Path(path_str).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        self.logMessage.emit(f"Saved viz spec to {path_str}.")

    def save_state(self, settings: QSettings) -> None:
        settings.setValue("prime/peg_name", self._peg_name.text())
        settings.setValue("prime/spacer", self._spacer.text())
        settings.setValue("prime/pbs", self._pbs.text())
        settings.setValue("prime/rtt", self._rtt.text())
        settings.setValue("prime/editor_name", self._editor_name.text())
        settings.setValue("prime/nick_offset", self._nick_offset.value())
        settings.setValue("prime/efficiency", self._efficiency.value())
        settings.setValue("prime/indel_bias", self._indel_bias.value())
        settings.setValue("prime/mismatch_tol", self._mismatch_tol.value())
        settings.setValue("prime/max_outcomes", self._max_outcomes.value())

    def load_state(self, settings: QSettings) -> None:
        peg_name = settings.value("prime/peg_name")
        if peg_name is not None:
            self._peg_name.setText(str(peg_name))
        spacer = settings.value("prime/spacer")
        if spacer is not None:
            self._spacer.setText(str(spacer))
        pbs = settings.value("prime/pbs")
        if pbs is not None:
            self._pbs.setText(str(pbs))
        rtt = settings.value("prime/rtt")
        if rtt is not None:
            self._rtt.setText(str(rtt))
        editor_name = settings.value("prime/editor_name")
        if editor_name is not None:
            self._editor_name.setText(str(editor_name))
        nick = settings.value("prime/nick_offset")
        if nick is not None:
            self._nick_offset.setValue(int(float(nick)))
        efficiency = settings.value("prime/efficiency")
        if efficiency is not None:
            self._efficiency.setValue(float(efficiency))
        indel = settings.value("prime/indel_bias")
        if indel is not None:
            self._indel_bias.setValue(float(indel))
        mismatch = settings.value("prime/mismatch_tol")
        if mismatch is not None:
            self._mismatch_tol.setValue(int(float(mismatch)))
        max_outcomes = settings.value("prime/max_outcomes")
        if max_outcomes is not None:
            self._max_outcomes.setValue(int(float(max_outcomes)))


class PCRTab(QWidget):
    """PCR simulation form."""

    logMessage = Signal(str)
    runStarted = Signal(str)
    runFailed = Signal(str, str)
    runCompleted = Signal(PCRConfig, PCRResult)

    def __init__(self, sequence_input: SequenceInput, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._sequence_input = sequence_input
        self._active_thread: QThread | None = None
        self._active_worker: PCRWorker | None = None
        self._pending_config: PCRConfig | None = None
        self._last_result: PCRResult | None = None
        self._current_roi: tuple[int, int] | None = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        form = QFormLayout()

        self._template_override = QPlainTextEdit(self)
        self._template_override.setPlaceholderText("Optional override – leave blank to use the main sequence.")
        self._template_override.setMaximumHeight(70)
        form.addRow("Template override", self._template_override)

        self._fwd_edit = QLineEdit(self)
        self._fwd_edit.setPlaceholderText("5'→3' forward primer")
        form.addRow("Forward primer", self._fwd_edit)

        self._rev_edit = QLineEdit(self)
        self._rev_edit.setPlaceholderText("5'→3' reverse primer")
        form.addRow("Reverse primer", self._rev_edit)

        self._cycles_spin = QSpinBox(self)
        self._cycles_spin.setRange(1, 60)
        self._cycles_spin.setValue(30)
        form.addRow("Cycles", self._cycles_spin)

        self._polymerase_combo = QComboBox(self)
        self._polymerase_combo.addItems(["Taq standard", "High-fidelity", "Low-fidelity test"])
        form.addRow("Polymerase", self._polymerase_combo)

        self._error_rate_spin = QDoubleSpinBox(self)
        self._error_rate_spin.setDecimals(8)
        self._error_rate_spin.setRange(0.0, 1.0)
        self._error_rate_spin.setSingleStep(1e-6)
        self._error_rate_spin.setValue(1e-5)
        form.addRow("Base error rate", self._error_rate_spin)

        self._indel_fraction_spin = QDoubleSpinBox(self)
        self._indel_fraction_spin.setDecimals(3)
        self._indel_fraction_spin.setRange(0.0, 1.0)
        self._indel_fraction_spin.setSingleStep(0.05)
        self._indel_fraction_spin.setValue(0.1)
        form.addRow("Indel fraction", self._indel_fraction_spin)

        self._efficiency_spin = QDoubleSpinBox(self)
        self._efficiency_spin.setDecimals(3)
        self._efficiency_spin.setRange(0.0, 1.0)
        self._efficiency_spin.setSingleStep(0.05)
        self._efficiency_spin.setValue(0.8)
        form.addRow("Efficiency", self._efficiency_spin)

        self._initial_copies_spin = QSpinBox(self)
        self._initial_copies_spin.setRange(1, 10000000)
        self._initial_copies_spin.setValue(1)
        form.addRow("Initial copies", self._initial_copies_spin)

        layout.addLayout(form)

        self._run_btn = QPushButton("Simulate PCR", self)
        self._run_btn.clicked.connect(self.trigger_simulation)
        layout.addWidget(self._run_btn)
        self._check_btn = QPushButton("Check amplicon", self)
        self._check_btn.clicked.connect(self._check_amplicon)
        layout.addWidget(self._check_btn)
        layout.addStretch(1)

        self._polymerase_combo.currentTextChanged.connect(self._apply_polymerase_profile)
        self._apply_polymerase_profile(self._polymerase_combo.currentText())

    def _apply_polymerase_profile(self, name: str) -> None:
        profile = name.lower()
        if "high" in profile:
            self._error_rate_spin.setValue(1e-6)
            self._efficiency_spin.setValue(0.85)
        elif "low" in profile:
            self._error_rate_spin.setValue(5e-5)
            self._efficiency_spin.setValue(0.9)
        else:
            self._error_rate_spin.setValue(1e-5)
            self._efficiency_spin.setValue(0.88)

    def trigger_simulation(self) -> None:
        config = self._build_config()
        if not config:
            return
        try:
            from helix.studio.debug_runtime import log_pid

            log_pid("run_clicked.pcr")
        except Exception:
            pass
        self.logMessage.emit("Starting PCR simulation…")
        self._start_worker(config)

    def _build_config(self) -> Optional[PCRConfig]:
        template = self._resolve_template()
        fwd = bioinformatics.normalize_sequence(self._fwd_edit.text().strip())
        rev = bioinformatics.normalize_sequence(self._rev_edit.text().strip())
        if not template:
            QMessageBox.warning(self, "PCR", "Provide a template sequence (either override or main sequence).")
            return None
        if len(fwd) < 10 or len(rev) < 10:
            QMessageBox.warning(self, "PCR", "Primers must be at least 10 bases long.")
            return None
        return PCRConfig(
            template_seq=template,
            fwd_primer=fwd,
            rev_primer=rev,
            cycles=int(self._cycles_spin.value()),
            polymerase_name=self._polymerase_combo.currentText(),
            base_error_rate=float(self._error_rate_spin.value()),
            indel_fraction=float(self._indel_fraction_spin.value()),
            efficiency=float(self._efficiency_spin.value()),
            initial_copies=int(self._initial_copies_spin.value()),
        )

    def _resolve_template(self) -> str:
        template_override = self._template_override.toPlainText().strip()
        base_template = self._sequence_input.current_sequence()
        template = template_override or base_template
        return bioinformatics.normalize_sequence(template)

    def _start_worker(self, config: PCRConfig) -> None:
        if self._active_thread is not None:
            self.logMessage.emit("PCR simulation already running.")
            return
        self._pending_config = config
        worker = PCRWorker(config)
        thread = QThread(self)
        self._active_thread = thread
        self._active_worker = worker
        self._run_btn.setEnabled(False)
        self._check_btn.setEnabled(False)

        worker.moveToThread(thread)
        worker.finished.connect(self._on_worker_success, Qt.QueuedConnection)
        worker.failed.connect(self._on_worker_failure, Qt.QueuedConnection)
        worker.finished.connect(worker.deleteLater)
        worker.failed.connect(worker.deleteLater)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(self._on_thread_finished)
        thread.finished.connect(thread.deleteLater)

        thread.started.connect(worker.run)
        self.runStarted.emit("PCR")
        thread.start()

    def _on_worker_success(self, result: PCRResult) -> None:
        self._last_result = result
        config = self._pending_config or result.config
        self.runCompleted.emit(config, result)
        self.logMessage.emit("PCR simulation complete.")

    def _on_worker_failure(self, message: str) -> None:
        self.runFailed.emit("PCR", message)
        QMessageBox.critical(self, "PCR simulation failed", message)
        self.logMessage.emit(f"PCR simulation failed: {message}")

    def _on_thread_finished(self) -> None:
        self._active_thread = None
        self._active_worker = None
        self._pending_config = None
        self._run_btn.setEnabled(True)
        self._check_btn.setEnabled(True)

    def shutdown(self) -> None:
        if self._active_thread is not None:
            self._active_thread.quit()
            self._active_thread.wait()
            self._active_thread = None
            self._active_worker = None
        self._run_btn.setEnabled(True)
        self._check_btn.setEnabled(True)

    # ------------------------------------------------------------------
    # External prefill from Outcome Explorer
    # ------------------------------------------------------------------
    def prefill_for_outcome(self, ctx: object) -> None:
        """Naive v0 prefill: drop a ±150 bp window around the cut into the template override."""
        seq = getattr(ctx, "ref_sequence", "") or ""
        if not seq:
            return
        cut_idx = int(getattr(ctx, "cut_index", 0) or 0)
        peak_rel = int(getattr(ctx, "peak_position", 0) or 0)

        half_window = 150
        start = max(0, cut_idx - half_window)
        end = min(len(seq), cut_idx + half_window)
        if end <= start:
            return
        window_seq = seq[start:end]
        self._template_override.setPlainText(window_seq)

        roi_center = cut_idx + peak_rel
        roi_center = max(start, min(end - 1, roi_center))
        roi_start = max(start, roi_center - 10)
        roi_end = min(end, roi_center + 10)
        self._current_roi = (roi_start - start, roi_end - start)

        # Simple hint
        msg = f"Prefilled template ±150 bp around cut. ROI: {roi_start - cut_idx}..{roi_end - cut_idx} bp rel to cut."
        self.logMessage.emit(msg)

    def save_state(self, settings: QSettings) -> None:
        settings.setValue("pcr/template_override", self._template_override.toPlainText())
        settings.setValue("pcr/fwd_primer", self._fwd_edit.text())
        settings.setValue("pcr/rev_primer", self._rev_edit.text())
        settings.setValue("pcr/cycles", self._cycles_spin.value())
        settings.setValue("pcr/polymerase", self._polymerase_combo.currentText())
        settings.setValue("pcr/error_rate", self._error_rate_spin.value())
        settings.setValue("pcr/indel_fraction", self._indel_fraction_spin.value())
        settings.setValue("pcr/efficiency", self._efficiency_spin.value())
        settings.setValue("pcr/initial_copies", self._initial_copies_spin.value())

    def load_state(self, settings: QSettings) -> None:
        template_override = settings.value("pcr/template_override")
        if template_override is not None:
            self._template_override.setPlainText(str(template_override))
        fwd = settings.value("pcr/fwd_primer")
        if fwd is not None:
            self._fwd_edit.setText(str(fwd))
        rev = settings.value("pcr/rev_primer")
        if rev is not None:
            self._rev_edit.setText(str(rev))
        cycles = settings.value("pcr/cycles")
        if cycles is not None:
            self._cycles_spin.setValue(int(float(cycles)))
        polymerase = settings.value("pcr/polymerase")
        if polymerase is not None:
            idx = self._polymerase_combo.findText(str(polymerase))
            if idx >= 0:
                self._polymerase_combo.setCurrentIndex(idx)
        error_rate = settings.value("pcr/error_rate")
        if error_rate is not None:
            self._error_rate_spin.setValue(float(error_rate))
        indel_frac = settings.value("pcr/indel_fraction")
        if indel_frac is not None:
            self._indel_fraction_spin.setValue(float(indel_frac))
        efficiency = settings.value("pcr/efficiency")
        if efficiency is not None:
            self._efficiency_spin.setValue(float(efficiency))
        initial = settings.value("pcr/initial_copies")
        if initial is not None:
            self._initial_copies_spin.setValue(int(float(initial)))

    def _check_amplicon(self) -> None:
        template = self._resolve_template()
        fwd = bioinformatics.normalize_sequence(self._fwd_edit.text().strip())
        rev = bioinformatics.normalize_sequence(self._rev_edit.text().strip())
        if not template:
            QMessageBox.warning(self, "PCR", "Provide a template sequence before checking primers.")
            return
        if len(fwd) < 10 or len(rev) < 10:
            QMessageBox.warning(self, "PCR", "Primers must be at least 10 bases long.")
            return
        try:
            info = find_amplicon(template, fwd, rev)
        except Exception as exc:
            QMessageBox.warning(self, "PCR", f"No valid amplicon detected: {exc}")
            return
        msg = (
            f"Amplicon detected.\n\n"
            f"Length: {info.length} bp\n"
            f"Template positions: {info.start}–{info.end}"
        )
        QMessageBox.information(self, "PCR amplicon", msg)
        self.logMessage.emit(f"Amplicon: {info.length} bp ({info.start}–{info.end})")
    @property
    def last_genome(self) -> Optional[DigitalGenome]:
        return self._last_genome

    @property
    def last_peg(self) -> Optional[PegRNA]:
        return self._last_peg

    @property
    def last_editor(self) -> Optional[PrimeEditor]:
        return self._last_editor

    @property
    def last_run_config(self) -> dict[str, Any]:
        return dict(self._last_run_config)

    @property
    def last_run_duration_ms(self) -> Optional[float]:
        return self._last_run_ms


class SimBuilderWidget(QWidget):
    """Embeddable Sim Builder panel that hosts sequence + viz controls."""

    ingestStarted = Signal(str)
    ingestProgress = Signal(str, int)
    ingestFinished = Signal(object)
    ingestCancelled = Signal(str)
    ingestError = Signal(str)
    fmBuildStarted = Signal(str)
    fmBuildProgress = Signal(str, int)
    fmBuildFinished = Signal(str, str)
    fmBuildCancelled = Signal(str)
    fmBuildError = Signal(str, str)

    def __init__(
        self,
        session: Optional[SessionModel] = None,
        parent: Optional[QWidget] = None,
        *,
        enable_gl_viewer: bool = True,
    ) -> None:
        super().__init__(parent)
        self._session = session
        # Allow callers (e.g., Helix Studio embedding) to disable the GL viewport
        self._enable_gl_viewer = bool(enable_gl_viewer)
        self._studio_redirect_logged = False
        self._cloned_parent_run_id: str | None = None
        self.genome_store: Optional[GenomeWindowStore] = None
        self.active_window: Optional[GenomeWindow] = None
        self._window_changing = False
        self._fm_thread: QThread | None = None
        self._fm_worker: QObject | None = None
        self._fm_building = False
        self._last_offtargets: list[dict[str, Any]] = []
        self._offtarget_overlay_cap = 128
        root_layout = QHBoxLayout(self)
        self.sim_settings = SimSettingsModel(parent=self)
        self.main_splitter: QSplitter | None = None

        left = QWidget(self)
        try:
            left.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        except Exception:
            pass
        left_layout = QVBoxLayout(left)
        # Keep the top of the left rail from feeling "jammed into chrome" across DPI/styles.
        # Split the effective top gap into:
        #   - a small rail-level gap (always before any banners),
        #   - a section-level gap (before the first section header).
        # Clamp constants are intentionally local: this is a layout contract, not a theme token.
        MIN_PX = 8
        MIN_FONT_RATIO = 0.55
        MAX_FONT_RATIO = 3.0

        style_gap = int(self.style().pixelMetric(QStyle.PM_LayoutTopMargin))
        # Font-derived values track DPI scaling reliably (Qt uses logical pixels here).
        font_unit_px = max(1, int(self.fontMetrics().lineSpacing()))
        # Prefer platform spacing, but guard against pathological styles/fonts.
        base_gap = max(style_gap, int(font_unit_px * MIN_FONT_RATIO), MIN_PX)
        base_gap = min(base_gap, int(font_unit_px * MAX_FONT_RATIO))
        rail_top_gap = base_gap // 2
        first_section_gap = base_gap - rail_top_gap
        left_layout.setContentsMargins(0, 0, 0, 0)
        # Slightly more breathing room between pipeline stages (power-tool, not a form).
        left_layout.setSpacing(10)
        if rail_top_gap > 0:
            left_layout.addSpacing(rail_top_gap)
        hero_text = "Helix Studio · Experiment Control"
        if not self._enable_gl_viewer:
            hero_text = "Experiment Control"
        hero_label = QLabel(hero_text, self)
        hero_label.setObjectName("StudioHero")
        if not self._enable_gl_viewer:
            hero_label.setProperty("variant", "sidebar")
        try:
            hero_label.setWordWrap(True)
            hero_label.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        except Exception:
            pass

        input_box = QGroupBox("Input sequence", self)
        input_layout = QVBoxLayout(input_box)
        input_layout.setContentsMargins(8, 8, 8, 8)
        input_layout.setSpacing(6)
        input_layout.addWidget(hero_label)
        self.sequence_input = SequenceInput(self)
        input_layout.addWidget(self.sequence_input)
        self.sequence_input.genomeIngested.connect(self._on_genome_ingested)
        self.sequence_input.ingestStarted.connect(self.ingestStarted.emit)
        self.sequence_input.ingestProgress.connect(self.ingestProgress.emit)
        self.sequence_input.ingestFinished.connect(self.ingestFinished.emit)
        self.sequence_input.ingestCancelled.connect(self.ingestCancelled.emit)
        self.sequence_input.ingestError.connect(self.ingestError.emit)

        crispr_box = QGroupBox("CRISPR / Prime settings", self)
        crispr_layout = QVBoxLayout(crispr_box)
        crispr_layout.setContentsMargins(8, 8, 8, 8)
        crispr_layout.setSpacing(6)
        self.pam_config = PamConfigPanel(self.sim_settings, self)
        crispr_layout.addWidget(self.pam_config)

        self.tabs = QTabWidget(self)
        try:
            self.tabs.setUsesScrollButtons(True)
            self.tabs.tabBar().setExpanding(False)
        except Exception:
            pass
        self.crispr_tab = CrisprTab(
            self.sequence_input,
            self.sim_settings,
            self,
            window_provider=lambda: self.active_window,
        )
        self.prime_tab = PrimeTab(
            self.sequence_input,
            self.sim_settings,
            self,
            window_provider=lambda: self.active_window,
        )
        self.pcr_tab = PCRTab(self.sequence_input, self)
        self.tabs.addTab(self.crispr_tab, "CRISPR Sim")
        self.tabs.addTab(self.prime_tab, "Prime Sim")
        self.tabs.addTab(self.pcr_tab, "PCR Sim")
        crispr_layout.addWidget(self.tabs)

        outcome_explorer_box = QGroupBox("Outcome Explorer", self)
        outcome_explorer_layout = QVBoxLayout(outcome_explorer_box)
        outcome_explorer_layout.setContentsMargins(8, 8, 8, 8)
        outcome_explorer_layout.setSpacing(6)
        studio_settings = QSettings("Helix", "Studio")
        self._always_show_exploratory_color = QCheckBox("Always show exploratory color", outcome_explorer_box)
        self._always_show_exploratory_color.setToolTip(
            "When decision grade is disabled (exploratory mode), show saturated category colors by default.\n"
            "Values remain uncalibrated and non-comparable; this is a visual preference only."
        )
        try:
            self._always_show_exploratory_color.setChecked(
                bool(studio_settings.value("outcomeExplorer/alwaysShowExploratoryColor", False))
            )
        except Exception:
            self._always_show_exploratory_color.setChecked(False)

        def _on_always_show_exploratory_toggled(enabled: bool) -> None:
            try:
                studio_settings.setValue("outcomeExplorer/alwaysShowExploratoryColor", bool(enabled))
            except Exception:
                pass
            try:
                from helix.studio.outcome_explorer import refresh_open_outcome_explorers

                refresh_open_outcome_explorers()
            except Exception:
                pass

        self._always_show_exploratory_color.toggled.connect(_on_always_show_exploratory_toggled)
        outcome_explorer_layout.addWidget(self._always_show_exploratory_color)

        guides_box = QGroupBox("Guide discovery", self)
        guides_layout = QVBoxLayout(guides_box)
        guides_layout.setContentsMargins(8, 8, 8, 8)
        guides_layout.setSpacing(6)

        # Default (collapsed) view: keep the primary flow obvious.
        guides_layout.addWidget(self.crispr_tab._find_btn)
        self._guide_focus_label = QLabel("Current focus: —", guides_box)
        self._guide_focus_label.setWordWrap(True)
        self._guide_focus_label.setStyleSheet("color: palette(window-text); font-size: 11px; font-weight: 600;")
        guides_layout.addWidget(self._guide_focus_label)

        def _make_disclosure(title: str) -> tuple[QToolButton, QWidget, QVBoxLayout]:
            toggle = QToolButton(guides_box)
            toggle.setCheckable(True)
            toggle.setChecked(False)
            toggle.setAutoRaise(True)
            toggle.setToolButtonStyle(Qt.ToolButtonTextOnly)
            toggle.setStyleSheet(
                "QToolButton { padding: 0px; color: palette(window-text); font-size: 11px; font-weight: 650; }"
            )
            container = QWidget(guides_box)
            container.setVisible(False)
            container_layout = QVBoxLayout(container)
            container_layout.setContentsMargins(12, 0, 0, 0)
            container_layout.setSpacing(6)

            def _sync() -> None:
                arrow = "▾" if toggle.isChecked() else "▸"
                toggle.setText(f"{arrow} {title}")
                container.setVisible(bool(toggle.isChecked()))

            toggle.toggled.connect(lambda *_: _sync())
            _sync()

            guides_layout.addWidget(toggle)
            guides_layout.addWidget(container)
            return toggle, container, container_layout

        # Guide results (collapsed by default)
        self._guide_results_auto_opened = False
        self._guide_results_toggle, results_container, results_layout = _make_disclosure("Guide results")
        results_layout.addWidget(self.crispr_tab._guide_list)

        # Advanced guide discovery (collapsed by default)
        _adv_toggle, adv_container, adv_layout = _make_disclosure("Advanced guide discovery")
        adv_layout.addWidget(QLabel("Guide length", adv_container))
        adv_layout.addWidget(self.crispr_tab._guide_len)
        self._guide_len_hint = QLabel("", adv_container)
        self._guide_len_hint.setWordWrap(True)
        self._guide_len_hint.setVisible(False)
        adv_layout.addWidget(self._guide_len_hint)
        self._guide_discovery_hint = QLabel(
            "Discovery enumerates PAM-matching guides and shows exploratory proxies (frameshift + local off-target). "
            "Run simulation to inspect full outcome distributions.",
            adv_container,
        )
        self._guide_discovery_hint.setWordWrap(True)
        adv_layout.addWidget(self._guide_discovery_hint)

        sort_row = QHBoxLayout()
        sort_row.setContentsMargins(0, 0, 0, 0)
        sort_row.setSpacing(6)
        sort_row.addWidget(QLabel("Sort guides by:", adv_container))
        self._guide_sort_combo = QComboBox(adv_container)
        self._guide_sort_combo.addItem("Position (default)", userData="position")
        self._guide_sort_combo.addItem("Pareto front (tradeoffs)", userData="pareto")
        self._guide_sort_combo.addItem("Frameshift (exploratory)", userData="frameshift")
        self._guide_sort_combo.addItem("Off-target risk (exploratory)", userData="offtarget")
        self._guide_sort_combo.setCurrentIndex(0)
        sort_row.addWidget(self._guide_sort_combo)
        sort_row.addStretch(1)
        adv_layout.addLayout(sort_row)

        guides_actions = QHBoxLayout()
        guides_actions.setContentsMargins(0, 0, 0, 0)
        guides_actions.setSpacing(6)
        self._export_guides_btn = QPushButton("Export guides CSV…", adv_container)
        self._export_guides_btn.clicked.connect(self._export_guides_csv)
        guides_actions.addWidget(self._export_guides_btn)
        guides_actions.addStretch(1)
        adv_layout.addLayout(guides_actions)

        # Viability filters (collapsed by default)
        _vf_toggle, vf_container, vf_layout = _make_disclosure("Viability filters")
        guides_filter_row = QHBoxLayout()
        guides_filter_row.setContentsMargins(0, 0, 0, 0)
        guides_filter_row.setSpacing(6)
        self._apply_viability_filters_check = QCheckBox("Apply viability filters", vf_container)
        self._apply_viability_filters_check.setChecked(True)
        self._apply_viability_filters_check.setToolTip(
            "Viability filters (MVP):\n"
            "  - reject ambiguous bases (N)\n"
            "  - reject GC outside 0.20–0.80\n"
            "  - reject poly-T runs (>=4)\n"
            "\nToggle off to enumerate all PAM-matching guides."
        )
        guides_filter_row.addWidget(self._apply_viability_filters_check)
        guides_filter_row.addStretch(1)
        self._show_rejected_guides_check = QCheckBox("Show rejected", vf_container)
        self._show_rejected_guides_check.setChecked(False)
        self._show_rejected_guides_check.setEnabled(False)
        guides_filter_row.addWidget(self._show_rejected_guides_check)
        self._guide_counts_label = QLabel("", vf_container)
        self._guide_counts_label.setVisible(False)
        guides_filter_row.addWidget(self._guide_counts_label)
        vf_layout.addLayout(guides_filter_row)
        self._viability_contract_label = QLabel(
            "Viability (MVP): no N · GC 0.20–0.80 · no poly-T≥4.",
            vf_container,
        )
        self._viability_contract_label.setWordWrap(True)
        self._viability_contract_label.setVisible(True)
        vf_layout.addWidget(self._viability_contract_label)

        # Off-target settings (collapsed by default)
        _ot_toggle, ot_container, ot_layout = _make_disclosure("Off target settings")
        self._offtarget_badge_label = QLabel("", ot_container)
        self._offtarget_badge_label.setWordWrap(True)
        ot_layout.addWidget(self._offtarget_badge_label)

        # FM index controls + logs (advanced)
        fm_status_row = QHBoxLayout()
        fm_status_row.setContentsMargins(0, 0, 0, 0)
        fm_status_row.setSpacing(6)
        self.fm_status = QLabel("FM index: not built", ot_container)
        self.fm_ready_chip = QLabel("FM: none", ot_container)
        self.fm_ready_chip.setStyleSheet("color: palette(mid); font-size: 11px;")
        fm_status_row.addWidget(self.fm_status)
        fm_status_row.addStretch(1)
        fm_status_row.addWidget(self.fm_ready_chip)
        self.fm_progress = QProgressBar(ot_container)
        self.fm_progress.setRange(0, 100)
        self.fm_progress.setVisible(False)
        self.fm_build_btn = QPushButton("Build genome index", ot_container)
        self.fm_cancel_btn = QPushButton("Cancel build", ot_container)
        self.fm_cancel_btn.setVisible(False)
        self.fm_build_btn.clicked.connect(self._start_fm_build)
        self.fm_cancel_btn.clicked.connect(self._cancel_fm_build)
        ot_layout.addLayout(fm_status_row)
        ot_layout.addWidget(self.fm_progress)
        ot_layout.addWidget(self.fm_build_btn)
        ot_layout.addWidget(self.fm_cancel_btn)
        self.log_panel = LogPanel(ot_container)
        self.log_panel.setObjectName("LogPanel")
        self.log_panel.setMaximumHeight(150)
        ot_layout.addWidget(self.log_panel)

        self.crispr_tab.guidesUpdated.connect(self._on_guides_updated)
        try:
            self.crispr_tab.offtarget_mode_combo.currentIndexChanged.connect(lambda *_: self._update_offtarget_badge())
        except Exception:
            pass
        try:
            self._guide_sort_combo.currentIndexChanged.connect(
                lambda *_: self.crispr_tab.set_guide_sort_mode(str(self._guide_sort_combo.currentData() or "position"))
            )
        except Exception:
            pass
        self._apply_viability_filters_check.toggled.connect(self._on_viability_filters_toggled)
        self._show_rejected_guides_check.toggled.connect(self.crispr_tab.set_show_rejected_guides)
        self._on_viability_filters_toggled(self._apply_viability_filters_check.isChecked())
        self._update_offtarget_badge()

        # Window controls (chrom/position/length)
        window_box = QGroupBox("Window", self)
        window_layout = FlowLayout(hspacing=10, vspacing=6)
        window_box.setLayout(window_layout)

        def _labeled_field(label_text: str, widget: QWidget) -> QWidget:
            row = QWidget(window_box)
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(4)
            row_label = QLabel(label_text, row)
            row_layout.addWidget(row_label)
            row_layout.addWidget(widget)
            row_layout.addStretch(1)
            return row

        self.window_chrom = QComboBox(self)
        self.window_pos = QSpinBox(self)
        # QSpinBox max is a 32-bit signed int; cap below that to avoid overflow warnings.
        self.window_pos.setRange(0, 2_000_000_000)
        self.window_len = QSpinBox(self)
        self.window_len.setRange(50, 100_000)
        self.window_len.setValue(1000)

        window_layout.addWidget(_labeled_field("Chrom", self.window_chrom))
        window_layout.addWidget(_labeled_field("Pos", self.window_pos))
        window_layout.addWidget(_labeled_field("Len", self.window_len))

        # Zoom slider (affects GL viewer camera; optional)
        zoom_box = QHBoxLayout()
        zoom_box.setContentsMargins(8, 0, 8, 0)
        zoom_box.setSpacing(6)
        zoom_box.addWidget(QLabel("Zoom", self))
        self.window_zoom = QSlider(Qt.Horizontal, self)
        self.window_zoom.setRange(50, 5000)  # bp span
        self.window_zoom.setValue(self.window_len.value())
        zoom_box.addWidget(self.window_zoom)
        zoom_widget = QWidget(self)
        zoom_widget.setLayout(zoom_box)

        self.window_chrom.currentTextChanged.connect(self._on_window_controls_changed)
        self.window_pos.valueChanged.connect(lambda _v: self._on_window_controls_changed())
        self.window_len.valueChanged.connect(lambda _v: self._on_window_controls_changed())
        self.window_zoom.valueChanged.connect(self._on_zoom_changed)

        self._wire_navigation_sources()
        self._guide_len_programmatic = False
        self._guide_len_user_override = False
        self._guide_len_profile_last = ""
        try:
            self.crispr_tab._guide_len.valueChanged.connect(self._on_guide_len_changed)
        except Exception:
            pass
        self.sim_settings.changed.connect(self._update_guide_len_recommendation)
        self._update_guide_len_recommendation()
        self._refresh_fm_status()

        if not self._enable_gl_viewer:
            # Studio embedding: tab the left rail so only one vertical stack competes for height.
            self._studio_tabs = QTabWidget(self)
            self._studio_tabs.setObjectName("StudioLeftTabs")
            try:
                self._studio_tabs.setUsesScrollButtons(True)
                bar = self._studio_tabs.tabBar()
                bar.setExpanding(False)
                bar.setElideMode(Qt.ElideNone)
                bar.setMovable(True)
            except Exception:
                pass

            def _make_scroll_tab(widgets: list[QWidget]) -> QScrollArea:
                page = QWidget(self._studio_tabs)
                page_layout = QVBoxLayout(page)
                page_layout.setContentsMargins(0, 0, 0, 0)
                page_layout.setSpacing(10)
                if first_section_gap > 0:
                    page_layout.addSpacing(first_section_gap)
                for w in widgets:
                    page_layout.addWidget(w)
                page_layout.addStretch(1)

                area = QScrollArea(self._studio_tabs)
                area.setWidget(page)
                area.setWidgetResizable(True)
                area.setFrameShape(QScrollArea.NoFrame)
                area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
                area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
                return area

            viewer_disabled_hint = QLabel(
                "Sim Builder viewer disabled; see Helix Studio viewport for visuals.",
                self._studio_tabs,
            )
            viewer_disabled_hint.setObjectName("SimBuilderViewerDisabledHint")
            viewer_disabled_hint.setWordWrap(True)
            viewer_disabled_hint.setStyleSheet(
                "QLabel#SimBuilderViewerDisabledHint {"
                "padding: 6px 10px; border-radius: 8px; "
                "background-color: palette(base); border: 1px solid palette(midlight); "
                "color: palette(windowText); font-size: 11px;"
                "}"
            )

            self._studio_tabs.addTab(_make_scroll_tab([input_box, guides_box]), "Input")
            self._studio_tabs.addTab(
                _make_scroll_tab([viewer_disabled_hint, window_box, zoom_widget]),
                "View",
            )
            self._studio_tabs.addTab(_make_scroll_tab([crispr_box, outcome_explorer_box]), "Settings")
            left_layout.addWidget(self._studio_tabs, stretch=1)
        else:
            if first_section_gap > 0:
                left_layout.addSpacing(first_section_gap)
            left_layout.addWidget(input_box)
            left_layout.addWidget(window_box)
            left_layout.addWidget(zoom_widget)
            left_layout.addWidget(crispr_box)
            left_layout.addWidget(guides_box)
            left_layout.addStretch(1)

        self.gl_window: HelixModernWidget | None = None
        self.viewer: QWidget | None = None
        self.rail_widget: RailBandWidget | None = None

        self.viewer_placeholder = ViewerPlaceholder(self)
        self.viewer_placeholder.setObjectName("ViewerPlaceholder")
        self.viewer_container = QWidget(self)
        self.viewer_container.setAutoFillBackground(False)
        self.viewer_stack = QStackedLayout(self.viewer_container)
        self.viewer_stack.addWidget(self.viewer_placeholder)
        self._active_view_widget: QWidget = self.viewer_placeholder
        self.sequence_viewer = SequenceWindowViewer(self)
        self.viewer_stack.addWidget(self.sequence_viewer)
        self._gl_window_adapter: Optional[GLWindowAdapter] = None

        if self._enable_gl_viewer:
            try:
                from helix.gui.modern.qt import HelixModernWidget
            except Exception:
                self.viewer_placeholder.set_message(
                    "GL viewer unavailable (install the 'realtime' extra)."
                    "\nYou can still export results via the Session history.",
                )
            else:
                self.gl_window = HelixModernWidget(self)
                # Allow the viewer to fully collapse with the sidebar; keep only a tiny floor.
                self.gl_window.setMinimumWidth(0)
                self.gl_window.setMinimumHeight(0)
                self.gl_window.setSizePolicy(QSizePolicy.MinimumExpanding, QSizePolicy.MinimumExpanding)
                self.viewer = self.gl_window
                self.gl_window.frameDrawn.connect(self._on_viewer_frame)

                self.rail_widget = RailBandWidget(self)
                self.viewer_stack.addWidget(self.rail_widget)
                self.viewer_stack.addWidget(self.viewer)
                self.viewer_stack.setCurrentWidget(self.sequence_viewer)
                self._gl_window_adapter = GLWindowAdapter(self.gl_window)
        else:
            self.viewer_placeholder.set_message("Viewer output is available in the Helix Studio viewport.")

        right = QWidget(self)
        right_layout = QVBoxLayout(right)
        self._viewer_focus_label = QLabel("Focus: —", right)
        self._viewer_focus_label.setWordWrap(True)
        self._viewer_focus_label.setStyleSheet("color: palette(mid); font-size: 11px;")
        right_layout.addWidget(self._viewer_focus_label)
        self.right_splitter = QSplitter(Qt.Vertical, right)
        self.right_splitter.addWidget(self.viewer_container)
        self.history_panel = RunHistoryPanel(self)
        self.right_splitter.addWidget(self.history_panel)
        self.right_splitter.setStretchFactor(0, 3)
        self.right_splitter.setStretchFactor(1, 2)
        self.right_splitter.setCollapsible(0, False)
        right_layout.addWidget(self.right_splitter)
        controls = QHBoxLayout()
        controls.addStretch(1)
        self.viewer_reset_btn = QPushButton("Reset Camera", self)
        self.viewer_reset_btn.setToolTip("Return the 3D view to its default orbit.")
        self.viewer_reset_btn.clicked.connect(self._reset_viewer_camera)
        controls.addWidget(self.viewer_reset_btn)
        controls.addStretch(1)
        right_layout.addLayout(controls)

        if self._enable_gl_viewer:
            scroll_left = QScrollArea(self)
            scroll_left.setWidget(left)
            scroll_left.setWidgetResizable(True)
            scroll_left.setFrameShape(QScrollArea.NoFrame)
            self.main_splitter = QSplitter(Qt.Horizontal, self)
            self.main_splitter.addWidget(scroll_left)
            self.main_splitter.addWidget(right)
            self.main_splitter.setStretchFactor(0, 1)
            self.main_splitter.setStretchFactor(1, 2)
            self.main_splitter.setCollapsible(0, False)
            self.main_splitter.setCollapsible(1, False)
            root_layout.addWidget(self.main_splitter)
        else:
            # Studio embedding: keep our own tab bar pinned; each tab scrolls internally.
            # Ensure the unused viewer/history pane does not paint over the left rail.
            try:
                right.hide()
            except Exception:
                pass
            root_layout.addWidget(left, stretch=1)

        self.crispr_tab.specReady.connect(self._display_spec)
        self.prime_tab.specReady.connect(self._display_spec)
        self.history_panel.previewRequested.connect(self._display_spec)
        self.crispr_tab.logMessage.connect(self._log)
        self.prime_tab.logMessage.connect(self._log)
        self.pcr_tab.logMessage.connect(self._log)
        self.history_panel.logMessage.connect(self._log)
        self.crispr_tab.guideFocusChanged.connect(self._on_guide_focus_changed)
        self.crispr_tab.runCompleted.connect(self._record_run)
        self.prime_tab.runCompleted.connect(self._record_run)
        self.crispr_tab.runCompleted.connect(self._sync_session_state)
        self.prime_tab.runCompleted.connect(self._sync_session_state)
        self.crispr_tab.runStarted.connect(self._on_run_started)
        self.prime_tab.runStarted.connect(self._on_run_started)
        self.crispr_tab.runFailed.connect(self._on_run_failed)
        self.prime_tab.runFailed.connect(self._on_run_failed)
        self.pcr_tab.runStarted.connect(self._on_run_started)
        self.pcr_tab.runFailed.connect(self._on_run_failed)
        self.pcr_tab.runCompleted.connect(self._on_pcr_completed)
        if self._enable_gl_viewer:
            self._show_viewer_canvas(False, "Viewer initializing…")
        else:
            self.viewer_placeholder.set_message("Sim Builder viewer disabled; see Helix Studio viewport for visuals.")

        # DEBUG bootstrap: load a trivial CRISPR spec so the viewer renders something on startup.
        if self._enable_gl_viewer:
            try:
                fake_payload = {
                    "schema": {"kind": "crispr.sim", "spec_version": "1.0"},
                    "meta": {},
                    "site": {"length": 40, "sequence": "ACGT" * 10},
                    "guide": {"id": "debug", "start": 10, "end": 30, "strand": "+", "gc_content": 0.5},
                    "priors": {},
                    "draws": 1,
                    "outcomes": [
                        {
                            "label": "fake_del",
                            "count": 1,
                            "probability": 1.0,
                            "diff": {
                                "kind": "deletion",
                                "start": 15,
                                "end": 18,
                            },
                        }
                    ],
                }
                mode = (self.sim_settings.value.viz_mode or "rail_3d").lower()
                seq = fake_payload["site"]["sequence"]
                guide = fake_payload["guide"]
                if mode == "orbitals_3d":
                    fake_spec = build_crispr_orbitals_3d_spec(seq, guide, fake_payload)
                else:
                    fake_spec = build_crispr_rail_3d_spec(seq, guide, fake_payload)
                if fake_spec is None:
                    fake_spec = build_crispr_viz_spec(seq, guide, fake_payload)
                if fake_spec and mode == "workflow_2p5d":
                    workflow = build_workflow2p5d_crispr(seq, guide, fake_payload)
                    meta = fake_spec.metadata or {}
                    meta["workflow_view"] = _workflow_to_serializable(workflow)
                    fake_spec.metadata = meta

                def _load_debug_spec(spec=fake_spec) -> None:
                    self._display_spec(spec)
                    self._log("Loaded DEBUG visualization: " + spec.edit_type)

                QTimer.singleShot(0, _load_debug_spec)
            except Exception as exc:
                self._show_viewer_canvas(False, f"Failed to load debug viz: {exc}")
                self._log(f"Failed to load debug spec: {exc}")

    def _display_spec(self, spec: EditVisualizationSpec) -> None:
        if spec is None:
            self._show_viewer_canvas(False, "No visualization available for this run.")
            return
        if not self._enable_gl_viewer or self.gl_window is None or self.viewer is None:
            self.viewer_placeholder.set_message("Visualization ready – view in the Helix Studio viewport.")
            self._log(f"Visualization ready: {spec.edit_type} (Studio viewport)")
            if self._session is not None and not self._studio_redirect_logged:
                self._session.log("SimBuilder in Studio mode: visualization redirected to Helix Studio viewport.")
                self._studio_redirect_logged = True
            return
        metadata = spec.metadata or {}
        viz_mode = (self.sim_settings.value.viz_mode or "rail_3d").lower()
        workflow_meta = metadata.get("workflow_view")
        rail_meta = metadata.get("rail_bands")

        # Always load the spec into the GL widget so mode switches stay in sync.
        self.gl_window.set_spec(spec)

        if viz_mode == "rail_2d":
            if self.rail_widget is not None and rail_meta and rail_meta.get("bands"):
                self.rail_widget.set_spec(spec)
                self.gl_window.set_workflow_view(None)
                self._show_viewer_canvas(True, widget=self.rail_widget)
                self._log(f"Loaded visualization: {spec.edit_type} (rail 2D)")
                return
            else:
                self._log("Rail 2D view unavailable for this spec. Falling back to 3D.")

        workflow_buffers = None
        if viz_mode == "workflow_2p5d":
            if workflow_meta:
                workflow_buffers = _workflow_from_serializable(workflow_meta)
            else:
                self._log("Workflow view unavailable for this spec. Showing 3D view instead.")

        self.gl_window.set_workflow_view(workflow_buffers)  # type: ignore[arg-type]
        self._show_viewer_canvas(True, widget=self.viewer)
        self.gl_window.update()
        self._log(f"Loaded visualization: {spec.edit_type}")

    def _record_run(self, kind: str, payload: dict, spec: EditVisualizationSpec) -> None:
        viz_mode = (self.sim_settings.value.viz_mode or "rail_3d").lower()
        self.history_panel.add_entry(kind, spec, payload, viz_mode=viz_mode)
        self._log(f"Recorded {kind} run: {spec.edit_type}")
        if kind.upper() == "CRISPR":
            try:
                hits = (
                    payload.get("offtarget_hits")
                    or payload.get("off_targets")
                    or payload.get("offtargets")
                    or []
                )
                hit_list = hits if isinstance(hits, list) else []
                adjusted: list[dict[str, Any]] = []
                window = self.active_window
                offset = int(window.start) if window is not None else 0
                win_len = int(window.end - window.start) if window is not None else None
                chrom = str(window.chrom) if window is not None else ""
                for h in hit_list:
                    if not isinstance(h, Mapping):
                        continue
                    entry = dict(h)
                    if window is not None and chrom and not any(k in entry for k in ("chrom", "chr", "contig")):
                        entry["chrom"] = chrom
                    shift = 0
                    if window is not None and offset:
                        start_val = entry.get("start")
                        try:
                            start_int = int(start_val) if start_val is not None else None
                        except Exception:
                            start_int = None
                        if start_int is not None and start_int >= 0 and (win_len is None or start_int < win_len):
                            shift = offset
                    for key in ("start", "end", "cut_index", "pos", "position"):
                        if key not in entry or entry.get(key) is None:
                            continue
                        try:
                            entry[key] = int(entry[key]) + int(shift)
                        except Exception:
                            continue
                    adjusted.append(entry)

                self._last_offtargets = adjusted
                if adjusted:
                    payload["offtarget_hits"] = adjusted
            except Exception:
                self._last_offtargets = []
            try:
                self._update_offtarget_badge()
            except Exception:
                pass
        try:
            run_model = self._run_model_from_payload(kind, payload)
            if run_model is not None and isinstance(self._session, SessionModel):
                # carry lineage from clone
                if self._cloned_parent_run_id:
                    run_model.parent_run_id = self._cloned_parent_run_id
                self._cloned_parent_run_id = None
                self._session.add_run(run_model)
        except Exception:
            pass

    def _on_run_started(self, kind: str) -> None:
        if self._session is not None:
            self._session.set_status(f"Running {kind.title()} simulation…")

    def _on_run_failed(self, kind: str, message: str) -> None:
        if self._session is not None:
            self._session.error(f"{kind.title()} simulation failed: {message}")

    def _on_pcr_completed(self, config: PCRConfig, result: PCRResult) -> None:
        if self._session is None:
            return
        workflow_meta = build_pcr_workflow_meta(result)
        config_summary = {
            "sim_type": "PCR",
            "run_config": {
                "polymerase": config.polymerase_name,
                "cycles": config.cycles,
                "base_error_rate": config.base_error_rate,
                "indel_fraction": config.indel_fraction,
                "efficiency": config.efficiency,
                "initial_copies": config.initial_copies,
            },
            "workflow_view": workflow_meta,
        }
        self._session.update(
            pcr_config=config,
            pcr_result=result,
            config=config_summary,
            run_kind=RunKind.PCR,
            dag_from_runtime=None,
            viz_spec_payload=None,
            outcomes=[],
            viz_dirty=True,
        )
        self._session.log(
            "PCR run synced to session: "
            f"{result.amplicon_length} bp, "
            f"{result.final_amplicon_mass_ng:.2f} ng mass."
        )
        region = ""
        if result.amplicon_end > result.amplicon_start:
            region = f" ({result.amplicon_start}–{result.amplicon_end})"
        self._session.set_status(
            f"PCR run #{self._session.state.run_id} finished: "
            f"{result.amplicon_length} bp{region} · {config.cycles} cycles · "
            f"{result.final_amplicon_mass_ng:.2f} ng · "
            f"mutation {result.final_mutation_rate:.4f}"
        )

    def _on_genome_ingested(self, ingest: GenomeIngestResult) -> None:
        try:
            self.genome_store = GenomeWindowStore(ingest.two_bit_path, ingest.genome_id)
            self._log(f"Genome cached: {ingest.two_bit_path.name} ({ingest.total_bp} bp)")
            # Default active window: first chromosome, first 1kb (or full length if shorter)
            chrom_sizes = self.genome_store.chrom_sizes()
            if chrom_sizes:
                first_chrom = next(iter(chrom_sizes))
                default_len = min(1000, chrom_sizes[first_chrom])
                self._window_changing = True
                self.window_chrom.clear()
                self.window_chrom.addItems(list(chrom_sizes.keys()))
                self.window_chrom.setCurrentText(first_chrom)
                self.window_pos.setValue(default_len // 2)
                self.window_len.setValue(default_len)
                self._window_changing = False
                self._set_active_window(first_chrom, 0, default_len)
            self._refresh_fm_status(ingest)
        except Exception as exc:
            self._log(f"Failed to open genome store: {exc}")
            self.genome_store = None

    # --- Public window navigation helpers ---------------------------------
    def jump_to_locus(self, chrom: str, pos: int, length: Optional[int] = None) -> None:
        """Center the active window at chrom:pos with given length."""
        if length is None:
            length = int(self.window_len.value()) if hasattr(self, "window_len") else 1000
        half = length // 2
        start = max(0, pos - half)
        self._set_active_window(chrom, start, length)

    def jump_to_gene(self, chrom: str, tx_start: int, tx_end: int, length: Optional[int] = None) -> None:
        center = (tx_start + tx_end) // 2
        self.jump_to_locus(chrom, center, length)

    # Public handlers that other UI components (gene picker, bookmarks, go-to dialog) can call
    def on_gene_selected(self, gene) -> None:
        try:
            chrom = getattr(gene, "chrom", None) or gene.get("chrom")
            tx_start = int(getattr(gene, "tx_start", gene.get("tx_start")))
            tx_end = int(getattr(gene, "tx_end", gene.get("tx_end")))
            self.jump_to_gene(chrom, tx_start, tx_end)
        except Exception:
            return

    def on_bookmark_clicked(self, bookmark) -> None:
        try:
            locus = getattr(bookmark, "locus", None) or bookmark.get("locus") or str(bookmark)
            self.jump_to_locus_str(str(locus))
        except Exception:
            return

    def on_go_to_confirm(self, text: str) -> None:
        self.jump_to_locus_str(text)

    def jump_to_locus_str(self, locus: str, length: Optional[int] = None) -> None:
        try:
            chrom_part, coords = locus.split(":", 1)
            # Support chrom:pos-start or chrom:pos or chrom:pos:length
            if "-" in coords:
                pos_part = coords.split("-")[0]
                pos = int(pos_part.replace(",", ""))
            elif ":" in coords:
                pos_part, span_part = coords.split(":", 1)
                pos = int(pos_part.replace(",", ""))
                length = int(span_part)
            else:
                pos = int(coords.replace(",", ""))
            self.jump_to_locus(chrom_part, pos, length)
        except Exception:
            return

    def _set_active_window(self, chrom: str, start: int, length: int) -> None:
        if self.genome_store is None:
            return
        try:
            window = self.genome_store.get_window(chrom=chrom, start=start, length=length, packed=False)
        except Exception as exc:
            self._log(f"Window fetch failed: {exc}")
            return
        self.active_window = window
        self._update_viewer_from_window(window)
        self._last_window_meta = {
            "chrom": window.chrom,
            "start": int(window.start),
            "end": int(window.end),
        }
        # Sync controls without triggering recursion
        self._window_changing = True
        try:
            if self.window_chrom.findText(window.chrom) >= 0:
                self.window_chrom.setCurrentText(window.chrom)
            self.window_pos.setValue(int(window.start + (window.end - window.start) // 2))
            self.window_len.setValue(int(window.end - window.start))
        finally:
            self._window_changing = False

    def _update_viewer_from_window(self, window: GenomeWindow) -> None:
        seq_bytes = window.sequence
        seq_str = seq_bytes.decode("ascii") if isinstance(seq_bytes, (bytes, bytearray)) else str(seq_bytes)
        if self.sequence_viewer is not None:
            self.sequence_viewer.set_window(window.chrom, window.start, seq_str)
            self.viewer_stack.setCurrentWidget(self.sequence_viewer)
        elif self.viewer_placeholder is not None and not self._enable_gl_viewer:
            msg = f"{window.chrom}:{window.start}-{window.end} (len {window.end - window.start} bp)"
            self.viewer_placeholder.set_message(msg)
            self.viewer_stack.setCurrentWidget(self.viewer_placeholder)
        # TODO: push to GL rail/3D viewer when its window API is ready.
        if self._gl_window_adapter is not None:
            self._gl_window_adapter.set_window(window.chrom, window.start, seq_bytes)
            self._gl_window_adapter.set_window_camera(window.end - window.start, (window.start + window.end) * 0.5)
            rel, kinds, vals, labels, counts = self._build_overlays_for_window(window)
            if rel.size > 0:
                self._gl_window_adapter.set_overlays(rel, kinds, vals, labels, counts)
            mode = "window"
            try:
                mode = (self.crispr_tab._last_run_config.get("search_mode") or "window") if hasattr(self.crispr_tab, "_last_run_config") else "window"
            except Exception:
                mode = "window"
            self._gl_window_adapter.set_search_mode(mode)

    def make_gpu_window_payload(self) -> Optional[dict]:
        if self.genome_store is None or self.active_window is None:
            return None
        gw = self.active_window
        packed = self.genome_store.get_window(
            chrom=gw.chrom,
            start=gw.start,
            length=gw.end - gw.start,
            packed=True,
        )
        buf = np.frombuffer(packed.sequence, dtype=np.uint8)
        return {
            "chrom": packed.chrom,
            "start": int(packed.start),
            "end": int(packed.end),
            "packed_bases": buf,
        }

    def _build_overlays_for_window(self, window: GenomeWindow) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[str], np.ndarray | None]:
        # Simple overlays: center edit site tick
        rel = []
        kinds = []
        vals = []
        labels: list[str] = []
        counts: list[float] = []
        # Primary edit marker at window center
        rel.append((window.end - window.start) / 2.0)
        kinds.append(0)
        vals.append(1.0)
        labels.append(f"Edit center {window.chrom}:{window.start + (window.end - window.start)//2}")
        counts.append(1.0)
        # Guide ticks if present
        try:
            guides = getattr(self.crispr_tab, "_guides", []) or []
            for g in guides:
                chrom = g.get("chrom") or window.chrom
                pos = g.get("cut_index")
                pos_kind = "cut"
                if pos is None:
                    pos = g.get("anchor_index")
                    pos_kind = "anchor"
                if pos is None:
                    pos = g.get("start")
                    pos_kind = "start"
                if pos is None:
                    pos = g.get("pam_index")
                    pos_kind = "pam"
                if pos is None or chrom != window.chrom:
                    continue
                idx = float(pos) - float(window.start)
                if 0 <= idx < (window.end - window.start):
                    rel.append(idx)
                    kinds.append(1)
                    vals.append(float(g.get("score", 1.0)))
                    labels.append(f"Guide {pos_kind} {chrom}:{int(pos)} score {g.get('score', 'n/a')}")
                    counts.append(1.0)
        except Exception:
            pass
        # Off-target overlay when off-target evaluation is active
        try:
            search_mode = (self.crispr_tab._last_run_config.get("search_mode") or "window") if hasattr(self.crispr_tab, "_last_run_config") else "window"
            if search_mode in {"window", "whole"} and self._last_offtargets:
                win_len = window.end - window.start
                hits = [h for h in self._last_offtargets if isinstance(h, Mapping)]
                # Sort by score desc and cap to avoid overcrowding
                hits_sorted = sorted(hits, key=lambda h: float(h.get("score", 0.0)), reverse=True)
                hits_sorted = hits_sorted[: self._offtarget_overlay_cap]
                # Aggregate by position for stacking
                pos_map: dict[float, dict[str, float]] = {}
                scores = [float(h.get("score", 0.0)) for h in hits_sorted]
                max_score = max(scores) if scores else 1.0
                for h in hits_sorted:
                    if not isinstance(h, Mapping):
                        continue
                    chrom = h.get("chrom") or h.get("chr") or window.chrom
                    pos = h.get("pos") or h.get("position") or h.get("cut_index")
                    if pos is None or chrom != window.chrom:
                        continue
                    rel_idx = float(pos) - float(window.start)
                    if 0 <= rel_idx < win_len:
                        entry = pos_map.setdefault(rel_idx, {"max": 0.0, "count": 0.0, "label": None, "min": None})
                        score = float(h.get("score", 0.0))
                        entry["max"] = max(entry["max"], score)
                        entry["count"] += 1.0
                        entry["min"] = score if entry.get("min") is None else min(entry.get("min"), score)
                        if entry.get("label") is None:
                            pam = h.get("pam") or h.get("pam_seq") or "PAM?"
                            entry["label"] = f"Off-target {chrom}:{int(pos)} score {score:.3f} pam {pam}"
                for rel_idx, agg in pos_map.items():
                    rel.append(rel_idx)
                    kinds.append(2)
                    norm_score = (agg["max"] / max_score) if max_score else 0.0
                    # encode count lightly into value to allow shader to vary height/opacity if desired
                    vals.append(min(1.0, norm_score + 0.1 * min(5.0, agg["count"])) )
                    if agg.get("count", 0) > 1 and agg.get("min") is not None:
                        labels.append(
                            f"{int(agg['count'])} off-targets here\nworst {agg['max']:.3f} best {agg['min']:.3f}"
                        )
                    else:
                        labels.append(agg.get("label") or "Off-target")
                    counts.append(agg.get("count", 1.0))
        except Exception:
            pass
        if not rel:
            return np.array([], dtype="f4"), np.array([], dtype="u1"), np.array([], dtype="f4"), [], None
        return (
            np.array(rel, dtype="f4"),
            np.array(kinds, dtype="u1"),
            np.array(vals, dtype="f4"),
            labels,
            np.array(counts, dtype="f4") if counts else None,
        )

    def _on_window_controls_changed(self) -> None:
        if self._window_changing:
            return
        chrom = self.window_chrom.currentText().strip()
        if not chrom:
            return
        pos = int(self.window_pos.value())
        length = int(self.window_len.value())
        half = length // 2
        start = max(0, pos - half)
        self._set_active_window(chrom, start, length)

    def _on_zoom_changed(self, value: int) -> None:
        # Adjust window length via zoom slider and recenter current pos
        self.window_len.setValue(max(50, int(value)))
        self._on_window_controls_changed()

    # --- Ingest control ----------------------------------------------------
    def cancel_ingest(self) -> None:
        try:
            self.sequence_input.cancel_ingest()
        except Exception:
            pass

    # --- FM index build ----------------------------------------------------
    def _refresh_fm_status(self, ingest: GenomeIngestResult | None = None) -> None:
        meta = self.sequence_input.sequence_metadata()
        gid = meta.get("genome_id") if isinstance(meta, dict) else None
        if not gid:
            self.fm_status.setText("FM index: inline sequence")
            self.fm_build_btn.setEnabled(False)
            self.fm_progress.setVisible(False)
            self.fm_cancel_btn.setVisible(False)
            try:
                if hasattr(self.crispr_tab, "refresh_fm_state"):
                    self.crispr_tab.refresh_fm_state(None, False)
                if hasattr(self.prime_tab, "refresh_fm_state"):
                    self.prime_tab.refresh_fm_state(None, False)
            except Exception:
                pass
            try:
                self._update_offtarget_badge()
            except Exception:
                pass
            return
        fm_path = None
        builder = None
        try:
            fm_path = resolve_fm_index(str(gid))
            from helix.genome.fm_registry import load_registry

            entry = load_registry().get(str(gid))
            if entry and entry.params:
                builder = entry.params.get("builder") or entry.params.get("cmd")
        except Exception:
            fm_path = None
        if self._fm_building:
            self.fm_status.setText("FM index: building…")
            self.fm_build_btn.setEnabled(False)
            self.fm_progress.setVisible(True)
            self.fm_cancel_btn.setVisible(True)
            self.fm_ready_chip.setText("FM: building…")
            self.fm_ready_chip.setStyleSheet("color: palette(link); font-size: 11px;")
            try:
                if hasattr(self.crispr_tab, "refresh_fm_state"):
                    self.crispr_tab.refresh_fm_state(Path(fm_path) if fm_path else None, True)
                if hasattr(self.prime_tab, "refresh_fm_state"):
                    self.prime_tab.refresh_fm_state(Path(fm_path) if fm_path else None, True)
            except Exception:
                pass
            try:
                self._update_offtarget_badge()
            except Exception:
                pass
            return
        if fm_path and Path(fm_path).exists():
            self.fm_status.setText(f"FM index ready: {Path(fm_path).name}")
            self.fm_status.setStyleSheet("color: palette(highlight);")
            self.fm_build_btn.setText("Rebuild genome index")
            self.fm_build_btn.setEnabled(True)
            self.fm_progress.setVisible(False)
            self.fm_cancel_btn.setVisible(False)
            self.fm_ready_chip.setText("FM: ready")
            self.fm_ready_chip.setStyleSheet("color: palette(highlight); font-weight: 600; font-size: 11px;")
            builder_tip = f"\nBuilder: {builder}" if builder else ""
            chip_tip = (
                f"Genome {meta.get('genome_id', '?') if isinstance(meta, dict) else ''}\n"
                f"Index: {Path(fm_path).name}{builder_tip}"
            )
            self.fm_ready_chip.setToolTip(chip_tip)
        else:
            self.fm_status.setText("FM index: not built")
            self.fm_status.setStyleSheet("")
            self.fm_build_btn.setText("Build genome index")
            self.fm_build_btn.setEnabled(True)
            self.fm_progress.setVisible(False)
            self.fm_cancel_btn.setVisible(False)
            self.fm_ready_chip.setText("FM: none")
            self.fm_ready_chip.setStyleSheet("color: palette(mid); font-size: 11px;")
            self.fm_ready_chip.setToolTip("No FM index available for this genome")

        try:
            if hasattr(self.crispr_tab, "refresh_fm_state"):
                self.crispr_tab.refresh_fm_state(Path(fm_path) if fm_path else None, False)
            if hasattr(self.prime_tab, "refresh_fm_state"):
                self.prime_tab.refresh_fm_state(Path(fm_path) if fm_path else None, False)
        except Exception:
            pass
        try:
            self._update_offtarget_badge()
        except Exception:
            pass

    def _start_fm_build(self) -> None:
        if self._fm_building:
            return
        ingest = self.sequence_input.genome_ingest()
        if ingest is None:
            self._log("Ingest a genome before building an index.")
            return

        class _FmBuildWorker(QObject):
            progress = Signal(int)
            finished = Signal(str)
            error = Signal(str)

            def __init__(self, gid: str, two_bit: Path) -> None:
                super().__init__()
                self._gid = gid
                self._two_bit = two_bit
                self._cancelled = False

            @Slot()
            def cancel(self) -> None:
                self._cancelled = True

            @Slot()
            def run(self) -> None:
                try:
                    path = build_fm_index_with_progress(
                        self._gid,
                        self._two_bit,
                        progress_cb=self.progress.emit,
                        cancel_cb=lambda: self._cancelled,
                    )
                    if self._cancelled:
                        self.error.emit("cancelled")
                        return
                    self.finished.emit(str(path))
                except Exception as exc:
                    self.error.emit(str(exc))

        self._fm_building = True
        self.fm_build_btn.setEnabled(False)
        self.fm_progress.setValue(0)
        self.fm_progress.setVisible(True)
        self.fm_status.setText("FM index: building…")
        self.fm_cancel_btn.setVisible(True)
        self.fm_cancel_btn.setEnabled(True)

        self._fm_thread = QThread(self)
        worker = _FmBuildWorker(ingest.genome_id, ingest.two_bit_path)
        self._fm_worker = worker
        worker.moveToThread(self._fm_thread)
        self._fm_thread.started.connect(worker.run)
        worker.progress.connect(self._on_fm_progress)
        worker.finished.connect(lambda p: self._on_fm_finished(p, ingest.genome_id))
        worker.error.connect(self._on_fm_error)
        worker.finished.connect(self._cleanup_fm_build_thread)
        worker.error.connect(self._cleanup_fm_build_thread)
        self._fm_thread.start()
        self._refresh_fm_status()
        self.fmBuildStarted.emit(ingest.genome_id)

    def _cancel_fm_build(self) -> None:
        self._fm_building = False
        if self._fm_worker is not None and hasattr(self._fm_worker, "cancel"):
            try:
                self._fm_worker.cancel()  # type: ignore[attr-defined]
            except Exception:
                pass
        self.fm_status.setText("FM index: cancelling…")
        self.fm_cancel_btn.setEnabled(False)

    def _on_fm_progress(self, pct: int) -> None:
        self.fm_progress.setValue(max(0, min(100, pct)))
        self.fm_status.setText(f"FM index: building… {pct}%")
        ingest = self.sequence_input.genome_ingest()
        if ingest:
            self.fmBuildProgress.emit(ingest.genome_id, int(pct))

    def _on_fm_finished(self, path_str: str, genome_id: str) -> None:
        try:
            fm_path = Path(path_str)
            set_fm_index(genome_id, fm_path, mode="whole_genome")
            self._log(f"FM index built: {fm_path}")
            self.fmBuildFinished.emit(genome_id, str(fm_path))
        except Exception as exc:
            self._log(f"Failed to record FM index: {exc}")
        self._fm_building = False
        self.fm_cancel_btn.setVisible(False)
        self.fm_progress.setVisible(False)
        self._refresh_fm_status()

    def _on_fm_error(self, message: str) -> None:
        self._fm_building = False
        self.fm_status.setText(f"FM index build failed: {message}")
        self.fm_progress.setVisible(False)
        self.fm_build_btn.setEnabled(True)
        self.fm_cancel_btn.setVisible(False)
        ingest = self.sequence_input.genome_ingest()
        if ingest:
            self.fmBuildError.emit(ingest.genome_id, message)
        self._refresh_fm_status()

    def _cleanup_fm_build_thread(self) -> None:
        if self._fm_thread is None:
            return
        self._fm_thread.quit()
        self._fm_thread.wait()
        self._fm_thread = None
        self._fm_worker = None
        self._fm_building = False
        self.fm_cancel_btn.setVisible(False)
        self._refresh_fm_status()
        ingest = self.sequence_input.genome_ingest()
        if ingest and self.fm_progress.value() < 100:
            self.fmBuildCancelled.emit(ingest.genome_id)

    # --- Navigation glue ---------------------------------------------------
    def _wire_navigation_sources(self) -> None:
        # Gene picker (expects items carrying gene dicts or objects with chrom/tx_start/tx_end)
        gene_list = getattr(self, "gene_list", None)
        if gene_list is not None and hasattr(gene_list, "itemActivated"):
            def _on_gene_item(item):
                gene = item.data(Qt.UserRole) if hasattr(item, "data") else item
                self.on_gene_selected(gene)
            gene_list.itemActivated.connect(_on_gene_item)

        # Bookmark list (items with locus string in data or text)
        bookmark_list = getattr(self, "bookmark_list", None)
        if bookmark_list is not None and hasattr(bookmark_list, "itemActivated"):
            def _on_bookmark_item(item):
                locus = item.data(Qt.UserRole) if hasattr(item, "data") else (item.text() if hasattr(item, "text") else str(item))
                self.on_bookmark_clicked(locus)
            bookmark_list.itemActivated.connect(_on_bookmark_item)

        # Go-to dialog with a line edit
        go_to_dialog = getattr(self, "go_to_dialog", None)
        go_to_line = getattr(self, "go_to_line_edit", None)
        if go_to_dialog is not None and go_to_line is not None and hasattr(go_to_dialog, "accepted"):
            go_to_dialog.accepted.connect(lambda: self.on_go_to_confirm(str(go_to_line.text())))

    def _on_viability_filters_toggled(self, enabled: bool) -> None:
        self._viability_contract_label.setVisible(bool(enabled))
        if not enabled:
            try:
                self._show_rejected_guides_check.setChecked(False)
            except Exception:
                pass
            self._show_rejected_guides_check.setEnabled(False)
        try:
            self.crispr_tab.set_apply_viability_filters(bool(enabled))
        except Exception:
            return

    def _on_guides_updated(self, viable_count: int, rejected_count: int) -> None:
        filters_enabled = bool(self._apply_viability_filters_check.isChecked())
        total = int(viable_count) + (int(rejected_count) if filters_enabled else 0)
        if total <= 0:
            self._guide_counts_label.setVisible(False)
            self._show_rejected_guides_check.setEnabled(False)
            self._export_guides_btn.setEnabled(False)
            return

        if filters_enabled:
            self._guide_counts_label.setText(f"Viable {int(viable_count)} · Rejected {int(rejected_count)}")
        else:
            self._guide_counts_label.setText(f"Guides {int(viable_count)}")
        self._guide_counts_label.setVisible(True)
        self._export_guides_btn.setEnabled(True)

        if filters_enabled and int(rejected_count) > 0:
            self._show_rejected_guides_check.setEnabled(True)
        else:
            self._show_rejected_guides_check.setEnabled(False)
            try:
                self._show_rejected_guides_check.setChecked(False)
            except Exception:
                pass

        toggle = getattr(self, "_guide_results_toggle", None)
        if (
            toggle is not None
            and not getattr(self, "_guide_results_auto_opened", False)
            and int(total) > 0
        ):
            try:
                toggle.setChecked(True)
                self._guide_results_auto_opened = True
            except Exception:
                pass

    def _on_guide_focus_changed(self, guide_obj: object) -> None:
        guide = guide_obj if isinstance(guide_obj, Mapping) else {}
        gid = str(guide.get("id") or guide.get("name") or "guide")
        start = guide.get("start")
        end = guide.get("end")
        strand = str(guide.get("strand") or "").strip()
        pam = str(guide.get("pam_seq") or "").strip()
        viable = guide.get("viable")
        status = ""
        if viable is True:
            status = "viable"
        elif viable is False:
            status = "rejected"
        span = f"{start}-{end}" if isinstance(start, int) and isinstance(end, int) else "pos?"
        strand_txt = f" ({strand})" if strand else ""
        pam_txt = f" · PAM {pam}" if pam else ""
        fs_txt = ""
        fs = guide.get("frameshift_fraction")
        if isinstance(fs, (int, float)):
            fs_txt = f" · FS≈{float(fs) * 100.0:.0f}%"
        ot_txt = ""
        ot = str(guide.get("offtarget_rank") or "")
        if ot and ot not in {"n/a", "skipped"}:
            ot_txt = f" · OT {ot}"
        status_txt = f" · {status}" if status else ""
        focus_txt = f"Current focus: {gid} · {span}{strand_txt}{pam_txt}{fs_txt}{ot_txt}{status_txt}"
        try:
            self._guide_focus_label.setText(focus_txt)
        except Exception:
            pass
        try:
            self._viewer_focus_label.setText(f"Showing visualization for {gid} · {span}{strand_txt}")
        except Exception:
            pass

    def _update_offtarget_badge(self) -> None:
        try:
            mode = str(self.crispr_tab.offtarget_mode_combo.currentData() or "window")
        except Exception:
            mode = "window"

        index_ready = False
        try:
            meta = self.sequence_input.sequence_metadata()
            gid = meta.get("genome_id") if isinstance(meta, dict) else None
            if gid:
                fm = resolve_fm_index(str(gid))
                index_ready = bool(fm and Path(fm).exists())
        except Exception:
            index_ready = False

        if mode == "none":
            text = "Off-target: none (no evaluation)"
        elif mode == "whole":
            suffix = "FM index ready" if index_ready else "FM index required"
            text = f"Off-target: whole-genome ({suffix})"
        else:
            text = "Off-target: local (loaded sequence/window)"

        try:
            hits = [h for h in self._last_offtargets if isinstance(h, Mapping)]
            if hits and mode != "none":
                scores = []
                for h in hits:
                    try:
                        scores.append(float(h.get("score", 0.0)))
                    except Exception:
                        continue
                worst = max(scores) if scores else 0.0
                text += f" · last run: {len(hits)} hit(s), worst {worst:.3f}"
        except Exception:
            pass

        self._offtarget_badge_label.setText(text)

    def _guide_len_recommendation(self, pam_profile: str) -> tuple[int | None, tuple[int, int] | None]:
        profile = str(pam_profile or "").strip() or "SpCas9_NGG"
        preset = PAM_PROFILE_PRESETS.get(profile, {})
        orientation = str(preset.get("orientation") or "3prime").lower()
        if profile.startswith("Cas12a") or orientation == "5prime":
            return 23, (23, 24)
        if profile.startswith("SaCas9"):
            return 21, (21, 21)
        if profile.startswith(("SpCas9", "SpG", "SpRY", "Sp")):
            return 20, (20, 20)
        return None, None

    def _update_guide_len_recommendation(self) -> None:
        profile = str(self.sim_settings.value.pam_profile or "SpCas9_NGG")
        if profile != getattr(self, "_guide_len_profile_last", ""):
            self._guide_len_user_override = False
            self._guide_len_profile_last = profile

        recommended_default, recommended_range = self._guide_len_recommendation(profile)
        if recommended_default is not None and not getattr(self, "_guide_len_user_override", False):
            try:
                current = int(self.crispr_tab._guide_len.value())
            except Exception:
                current = None
            if current is None or current != int(recommended_default):
                self._guide_len_programmatic = True
                try:
                    self.crispr_tab._guide_len.setValue(int(recommended_default))
                finally:
                    self._guide_len_programmatic = False

        # Update hint text
        hint = getattr(self, "_guide_len_hint", None)
        if hint is None:
            return
        if recommended_range is None:
            hint.setVisible(False)
            return
        lo, hi = recommended_range
        recommended_str = f"{lo} nt" if lo == hi else f"{lo}–{hi} nt"
        try:
            current = int(self.crispr_tab._guide_len.value())
        except Exception:
            current = 0
        if lo <= current <= hi:
            hint.setText(f"Recommended for {profile}: {recommended_str}.")
        else:
            hint.setText(f"⚠ Nonstandard for {profile}: {current} nt (recommended {recommended_str}).")
        hint.setVisible(True)

    def _on_guide_len_changed(self, _value: int) -> None:
        if getattr(self, "_guide_len_programmatic", False):
            return
        self._guide_len_user_override = True
        self._update_guide_len_recommendation()

    def _export_guides_csv(self) -> None:
        guides: list[Mapping[str, Any]] = []
        try:
            guide_list = self.crispr_tab._guide_list
            for idx in range(int(guide_list.count())):
                item = guide_list.item(idx)
                if item is None:
                    continue
                guide = item.data(Qt.UserRole)
                if isinstance(guide, Mapping):
                    guides.append(guide)
        except Exception:
            guides = []
        if not guides:
            self._log("No guides to export yet. Click 'Find Guides' first.")
            return
        path_str, _ = QFileDialog.getSaveFileName(self, "Export guides", filter="CSV (*.csv)")
        if not path_str:
            return

        profile = str(self.sim_settings.value.pam_profile or "SpCas9_NGG")
        try:
            with open(path_str, "w", newline="", encoding="utf-8") as handle:
                write_guides_csv(handle, guides, pam_profile=profile)
        except Exception as exc:
            self._log(f"Failed to export guides: {exc}")
            return
        self._log(f"Exported {len(guides)} guide(s) to {path_str}.")

    def _sync_session_state(self, kind: str, payload: dict, spec: EditVisualizationSpec) -> None:
        if self._session is None:
            return
        spec_payload = spec.to_payload()
        config: dict[str, Any] = {
            "sim_type": kind,
            "sim_settings": self.sim_settings.to_dict(),
        }
        perf: dict[str, float] = {}
        workflow_meta = (spec.metadata or {}).get("workflow_view")
        if workflow_meta:
            config["workflow_view"] = workflow_meta
        if isinstance(payload, Mapping):
            config["sim_payload"] = dict(payload)
        genome: Optional[DigitalGenome] = None
        peg: Optional[PegRNA] = None
        editor: Optional[PrimeEditor] = None
        dag_payload: Optional[Any] = None
        outcomes: list[dict[str, Any]] = []
        if isinstance(payload, Mapping):
            raw_outcomes = payload.get("outcomes")
            if isinstance(raw_outcomes, list):
                outcomes = [dict(outcome) for outcome in raw_outcomes if isinstance(outcome, Mapping)]

        run_kind = RunKind.NONE
        normalized_kind = kind.upper()
        if normalized_kind == "CRISPR":
            genome = self.crispr_tab.last_genome
            config["run_config"] = self.crispr_tab.last_run_config
            guide = self.crispr_tab.last_guide
            if guide:
                config["guide"] = dict(guide)
            if isinstance(payload, Mapping) and isinstance(payload.get("artifact"), str):
                dag_payload = dict(payload)
            run_kind = RunKind.CRISPR
            duration = self.crispr_tab.last_run_duration_ms
            if duration is not None:
                perf["sim_ms"] = duration
        elif normalized_kind == "PRIME":
            genome = self.prime_tab.last_genome
            peg = self.prime_tab.last_peg
            editor = self.prime_tab.last_editor
            config["run_config"] = self.prime_tab.last_run_config
            run_kind = RunKind.PRIME
            duration = self.prime_tab.last_run_duration_ms
            if duration is not None:
                perf["sim_ms"] = duration

        seq_meta = self.sequence_input.sequence_metadata()
        gpu_window = self.make_gpu_window_payload() if self.sequence_input.genome_ingest() else None
        fm_index_path = None
        fm_builder = None
        try:
            gid = seq_meta.get("genome_id") if isinstance(seq_meta, dict) else None
            if gid:
                fm = resolve_fm_index(str(gid))
                fm_index_path = str(fm) if fm else None
                from helix.genome.fm_registry import load_registry

                entry = load_registry().get(str(gid))
                if entry and entry.params:
                    fm_builder = entry.params.get("builder") or entry.params.get("cmd")
        except Exception:
            fm_index_path = None

        if gpu_window is not None and self.active_window is not None:
            window = self.active_window
            config["genome"] = {
                "genome_id": seq_meta.get("genome_id"),
                "two_bit_path": seq_meta.get("two_bit_path"),
                "chrom": window.chrom,
                "window_start": int(window.start),
                "window_end": int(window.end),
                "packed_bases": gpu_window.get("packed_bases"),
            }
            if fm_index_path:
                config["genome"]["fm_index_path"] = fm_index_path
            if fm_builder:
                config["genome"]["fm_builder"] = fm_builder
        if perf:
            config["perf"] = perf

        if suggestions_enabled():
            try:
                meta = config.setdefault("metadata", {})
                seq_meta_map = seq_meta if isinstance(seq_meta, Mapping) else {}
                digest = seq_meta_map.get("input_digest")
                if digest:
                    meta["input_digest"] = digest
                loc_sug = seq_meta_map.get("locus_suggestion")
                if loc_sug:
                    meta["locus_suggestion"] = loc_sug
                # genome build suggestion only if anchored to FM index metadata
                if fm_index_path and digest and seq_meta_map.get("genome_id"):
                    try:
                        from helix.genome.fm_registry import load_registry

                        entry = load_registry().get(str(seq_meta_map.get("genome_id")))
                        checksum = getattr(entry, "checksum", None) if entry else None
                        build_id = None
                        if entry and getattr(entry, "params", None):
                            build_id = entry.params.get("build") or entry.params.get("genomeBuild")
                    except Exception:
                        entry = None
                        checksum = None
                        build_id = None
                    suggestion = build_index_anchored_genome_suggestion(
                        input_digest=digest,
                        genome_build=str(build_id) if build_id else None,
                        index_id=str(seq_meta_map.get("genome_id")) if seq_meta_map.get("genome_id") else None,
                        index_checksum=str(checksum) if checksum else None,
                        created_at=clock.utc_now_iso(),
                    )
                    if suggestion:
                        meta["genome_build_suggestion"] = suggestion
            except Exception:
                pass

        self._session.update(
            genome=genome,
            peg=peg,
            editor=editor,
            dag_from_runtime=dag_payload,
            viz_spec_payload=spec_payload,
            config=config,
            run_kind=run_kind,
            genome_source=seq_meta.get("source", "inline"),
            genome_uri=seq_meta.get("uri"),
            genome_hash=seq_meta.get("hash"),
            outcomes=outcomes,
            viz_dirty=True,
        )
        if outcomes:
            self._session.log(f"{kind.title()} run synced to session ({len(outcomes)} outcomes).")
        else:
            self._session.log(f"{kind.title()} run synced to session.")
        if self._session is not None:
            self._session.set_status(
                f"{kind.title()} run #{self._session.state.run_id} finished with {len(outcomes)} outcomes."
            )

    def run_active_tab(self) -> None:
        active = self.tabs.currentWidget()
        trigger = getattr(active, "trigger_simulation", None)
        if callable(trigger):
            trigger()
        else:
            self._log("Active tab cannot be triggered automatically.")

    def _log(self, message: str) -> None:
        self.log_panel.log(message)
        _console_log(message)

    def _show_viewer_canvas(self, ready: bool, message: str | None = None, widget: QWidget | None = None) -> None:
        if not self._enable_gl_viewer or self.viewer is None:
            if message:
                self.viewer_placeholder.set_message(message)
            return
        if ready:
            target = widget or self.viewer
            self.viewer_stack.setCurrentWidget(target)
            self._active_view_widget = target
        else:
            if message:
                self.viewer_placeholder.set_message(message)
            self.viewer_stack.setCurrentWidget(self.viewer_placeholder)
            self._active_view_widget = self.viewer_placeholder

    def _on_viewer_frame(self) -> None:
        if not self._enable_gl_viewer or self.gl_window is None:
            return
        if not hasattr(self, "_gl_logged"):
            self._gl_logged = True
            try:
                ctx = self.gl_window.context()
                if ctx is not None:
                    fmt = ctx.format()
                    profile_map = {
                        QSurfaceFormat.NoProfile: "none",
                        QSurfaceFormat.CoreProfile: "core",
                        QSurfaceFormat.CompatibilityProfile: "compat",
                    }
                    profile_name = profile_map.get(fmt.profile(), str(fmt.profile()))
                    self._log(
                        "GL context: "
                        f"{fmt.majorVersion()}.{fmt.minorVersion()} "
                        f"profile={profile_name} "
                        f"samples={fmt.samples()} "
                        f"depth={fmt.depthBufferSize()} "
                        f"swap={fmt.swapBehavior()}"
                    )
                else:
                    self._log("GL context unavailable (no QOpenGLContext).")
            except Exception as exc:
                self._log(f"GL context query failed: {exc}")
        if getattr(self, "_active_view_widget", None) is self.viewer:
            self._show_viewer_canvas(True, widget=self.viewer)

    def _reset_viewer_camera(self) -> None:
        if not self._enable_gl_viewer or self.gl_window is None:
            return
        self.gl_window.reset_camera()
        self._log("Viewer camera reset.")

    def load_state(self, settings: QSettings) -> None:
        if self.main_splitter is not None:
            splitter_state = settings.value("main_splitter_state", type=QByteArray)
            if not splitter_state or not isinstance(splitter_state, QByteArray) or not self.main_splitter.restoreState(splitter_state):
                self.main_splitter.setSizes([450, 950])
        right_splitter_state = settings.value("right_splitter_state", type=QByteArray)
        if not right_splitter_state or not isinstance(right_splitter_state, QByteArray) or not self.right_splitter.restoreState(right_splitter_state):
            self.right_splitter.setSizes([600, 300])
        sizes = self.right_splitter.sizes()
        if not sizes or len(sizes) < 2 or sizes[0] < 100:
            self.right_splitter.setSizes([600, 300])
        if self.main_splitter is not None:
            main_sizes = self.main_splitter.sizes()
            if not main_sizes or len(main_sizes) < 2 or main_sizes[0] < 200:
                self.main_splitter.setSizes([450, 950])
        sim_settings_blob = settings.value("sim_settings")
        if sim_settings_blob:
            try:
                if isinstance(sim_settings_blob, (bytes, bytearray)):
                    raw = bytes(sim_settings_blob).decode("utf-8")
                else:
                    raw = str(sim_settings_blob)
                payload = json.loads(raw)
            except Exception as exc:
                LOGGER.warning("Failed to restore sim settings: %s", exc)
            else:
                if isinstance(payload, dict):
                    self.sim_settings.apply_dict(payload)
        sequence_text = settings.value("sequence_text")
        if sequence_text:
            self.sequence_input.set_sequence(str(sequence_text))
        self.crispr_tab.load_state(settings)
        self.prime_tab.load_state(settings)
        self.pcr_tab.load_state(settings)

    def save_state(self, settings: QSettings) -> None:
        if self.main_splitter is not None:
            settings.setValue("main_splitter_state", self.main_splitter.saveState())
        settings.setValue("right_splitter_state", self.right_splitter.saveState())
        settings.setValue("sequence_text", self.sequence_input.sequence())
        settings.setValue("sim_settings", json.dumps(self.sim_settings.to_dict()))
        self.crispr_tab.save_state(settings)
        self.prime_tab.save_state(settings)
        self.pcr_tab.save_state(settings)

    def shutdown(self) -> None:
        self.crispr_tab.shutdown()
        self.prime_tab.shutdown()
        self.pcr_tab.shutdown()

    def on_simulation_finished(self, genome, dag, config, outcomes: list[dict[str, Any]]) -> None:
        if self._session is not None:
            self._session.update(genome=genome, dag=dag, config=config)
            for outcome in outcomes:
                self._session.append_outcome(outcome)

    def _run_model_from_payload(self, kind: str, payload: dict) -> RunModel | None:
        try:
            seq = payload.get("site", {}).get("sequence") or payload.get("sequence") or ""
            guide = payload.get("guide") or {}
            outcomes_raw = payload.get("outcomes") or []
            physics = payload.get("physics_score") or payload.get("physics") or {}
            cut_index = payload.get("cut_index") or guide.get("cut_index")
            if cut_index is None:
                cut_index = guide.get("anchor_index")
            if cut_index is None:
                try:
                    start = int(guide.get("start", 0))
                    end = int(guide.get("end", start))
                    strand = guide.get("strand", "+")
                    cut_index = max(start, end - 3) if strand == "+" else min(end, start + 3)
                except Exception:
                    cut_index = None
            backend_kind = payload.get("backend") or "gpu"
            engine_name = payload.get("engine") or "helix_cuda"
            meta = payload.get("meta") if isinstance(payload.get("meta"), Mapping) else {}
            seed = meta.get("seed") if isinstance(meta, Mapping) else None
            draws = payload.get("draws")
            from helix.provenance import current_git_sha
            from helix import __version__ as HELIX_VERSION

            git_sha = current_git_sha()
            engine = EngineInfo(
                name=str(engine_name),
                backend=str(backend_kind),
                crispr_scoring_version=CRISPR_SCORING_VERSION,
                prime_scoring_version=PRIME_SCORING_VERSION,
            )
            outcomes = [
                OutcomeModel(
                    name=o.get("label") or o.get("name") or o.get("category", ""),
                    category=o.get("category") or (o.get("diff", {}) or {}).get("kind", ""),
                    prob=float(o.get("probability", o.get("prob", 0.0))),
                    delta_bp=o.get("delta_bp"),
                    peak_position=o.get("peak_position"),
                    position_min=o.get("position_min"),
                    position_max=o.get("position_max"),
                    frameshift=o.get("frameshift"),
                    microhomology=o.get("microhomology"),
                )
                for o in outcomes_raw
            ]

            target_locus = str(guide.get("locus", ""))
            if not target_locus:
                try:
                    target_locus = self.sequence_input.locus_label()
                except Exception:
                    target_locus = ""

            return RunModel(
                run_id=str(payload.get("run_id", payload.get("id", "run"))),
                guide_id=str(guide.get("id") or guide.get("name") or "guide"),
                edit_type=kind.lower(),
                sequence=seq,
                target_locus=target_locus,
                pam_index=guide.get("pam_index"),
                cut_index=cut_index,
                outcomes=outcomes,
                physics=dict(physics),
                engine=engine,
                metadata={
                    "source": "sim_builder",
                    "seed": seed,
                    "draws": draws,
                    "git_sha": git_sha,
                    "helix_version": HELIX_VERSION,
                },
            )
        except Exception:
            return None


class SimBuilderWindow(QMainWindow):
    """Standalone window wrapper for the Sim Builder widget."""

    def __init__(self, session: Optional[SessionModel] = None) -> None:
        super().__init__()
        self.setWindowTitle("Helix Sim Builder")
        self._settings = QSettings("Helix", "SimBuilder")
        self._widget = SimBuilderWidget(session=session, parent=self)
        self.setCentralWidget(self._widget)
        self._restore_window_state()
        self._widget.load_state(self._settings)

    def _restore_window_state(self) -> None:
        geometry = self._settings.value("geometry", type=QByteArray)
        if geometry and isinstance(geometry, QByteArray):
            self.restoreGeometry(geometry)
        else:
            self.resize(1400, 900)
        window_state = self._settings.value("windowState", type=QByteArray)
        if window_state and isinstance(window_state, QByteArray):
            self.restoreState(window_state)

    def _save_window_state(self) -> None:
        self._settings.setValue("geometry", self.saveGeometry())
        self._settings.setValue("windowState", self.saveState())

    def closeEvent(self, event: QCloseEvent) -> None:
        self._widget.shutdown()
        self._widget.save_state(self._settings)
        self._save_window_state()
        self._settings.sync()
        super().closeEvent(event)


def create_simbuilder_widget(
    session: Optional[SessionModel] = None,
    parent: Optional[QWidget] = None,
    *,
    enable_gl_viewer: bool = True,
) -> SimBuilderWidget:
    return SimBuilderWidget(session=session, parent=parent, enable_gl_viewer=enable_gl_viewer)


def run_sim_builder() -> None:
    """Launch the Sim Builder UI."""

    app = QApplication.instance()
    owns_app = False
    if app is None:
        app = QApplication([])
        owns_app = True
    configure_opengl_surface_format()
    apply_helix_theme(app)
    session = SessionModel()
    window = SimBuilderWindow(session=session)
    window.show()
    if owns_app:
        with allow_nondeterminism(reason="ui"):
            app.exec()


def main() -> None:
    """Standalone entry point exposed via console script."""
    import sys

    app = QApplication(sys.argv)
    configure_opengl_surface_format()
    apply_helix_theme(app)
    session = SessionModel()
    window = SimBuilderWindow(session=session)
    window.show()
    with allow_nondeterminism(reason="ui"):
        sys.exit(app.exec())


def _console_log(message: str) -> None:
    print(f"[SimBuilder] {message}", flush=True)


class HelixComboBox(QComboBox):
    """ComboBox tuned for Sim Builder interactions."""

    def __init__(self, parent: QWidget | None = None, *, searchable: bool = True) -> None:
        super().__init__(parent)
        self._searchable = searchable
        if self._searchable:
            self.setEditable(True)
        self._init_completer()

    def _init_completer(self) -> None:
        if not self._searchable:
            return
        completer = QCompleter(self.model(), self)
        completer.setCompletionMode(QCompleter.PopupCompletion)
        completer.setFilterMode(Qt.MatchContains)
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        self.setCompleter(completer)

    def wheelEvent(self, event) -> None:  # type: ignore[override]
        view = self.view()
        if view is not None and view.isVisible():
            super().wheelEvent(event)
        else:
            event.ignore()

    def showPopup(self) -> None:  # type: ignore[override]
        super().showPopup()
        view = self.view()
        if view is not None:
            width = max(self.width(), view.sizeHintForColumn(0) + 40)
            view.setMinimumWidth(width)
