from __future__ import annotations

try:
    from PySide6.QtGui import QSurfaceFormat
except Exception:  # pragma: no cover - exercised when GUI stack unavailable
    QSurfaceFormat = None  # type: ignore[assignment]


def configure_opengl_surface_format() -> None:
    """Configure a consistent OpenGL surface format for Helix GL widgets."""

    if QSurfaceFormat is None:
        raise RuntimeError("PySide6 is required for OpenGL configuration (install the 'gui' extra).")

    fmt = QSurfaceFormat()
    fmt.setRenderableType(QSurfaceFormat.OpenGL)
    fmt.setProfile(QSurfaceFormat.CoreProfile)
    fmt.setVersion(3, 3)
    fmt.setSwapBehavior(QSurfaceFormat.DoubleBuffer)
    fmt.setDepthBufferSize(24)
    fmt.setStencilBufferSize(8)
    QSurfaceFormat.setDefaultFormat(fmt)


__all__ = ["configure_opengl_surface_format"]
