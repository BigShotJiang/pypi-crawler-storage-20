"""Pure Python core of the PyQt + ModernGL helix visualizer."""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, Iterable, List, Mapping

import numpy as np

from .spec import EditEvent, EditEventType, EditVisualizationSpec


@dataclass(slots=True)
class HelixGeometry:
    """Vertex bundles describing the primary helix rails."""

    rail_vertices: np.ndarray  # (N, 3) float32 positions
    rail_ids: np.ndarray  # (N,) float32 0 for strand A, 1 for strand B
    param_coords: np.ndarray  # (N,) float32 [0, 1] along helix
    base_centers: np.ndarray  # (B, 3) float32
    base_indices: np.ndarray  # (B,) int32 indexes into sequence


@dataclass(slots=True)
class RepairArcGeometry:
    """A packed vertex buffer representing independent repair arcs."""

    vertices: np.ndarray  # (M, 3) float32
    offsets: np.ndarray  # (A + 1,) int32 prefix sums for arc segments
    event_types: list[EditEventType]
    event_times: list[float]
    weights: np.ndarray | None = None
    kinds: np.ndarray | None = None


class AnimationPhase(str, Enum):
    """Named beats aligned with the user's storyboard."""

    APPROACH = "approach"
    RECOGNITION = "recognition"
    CUT = "cut"
    PRIME = "prime"
    REPAIR = "repair"
    RESOLVE = "resolve"


@dataclass(slots=True)
class AnimationState:
    """Mutable animation context shared by the Qt shell and shader uniforms."""

    time: float = 0.0
    phase: AnimationPhase = AnimationPhase.APPROACH
    loop_duration: float = 12.0


class HelixVizEngine:
    """Constructs helix/base/arc geometry and tracks the animation timeline."""

    def __init__(
        self,
        spec: EditVisualizationSpec,
        *,
        bases_per_turn: float = 10.0,
        segments_per_base: int = 5,
        radius: float = 0.38,
        pitch: float = 0.08,
    ) -> None:
        self.spec = spec
        self.bases_per_turn = bases_per_turn
        self.segments_per_base = max(1, segments_per_base)
        self.radius = radius
        self.pitch = pitch
        # Loop duration controls how long ribbons and phase beats stay
        # visible in realtime. Keep a reasonably long loop so edits
        # linger, with a small tail after the last event.
        self.loop_duration = max(12.0, spec.duration + 2.0)
        self.state = AnimationState(
            time=0.0,
            phase=AnimationPhase.APPROACH,
            loop_duration=self.loop_duration,
        )
        self.event_time_units, self.event_time_units_source = self._resolve_event_time_units(spec)
        self.event_times_normalized = self.event_time_units == "normalized"
        self.loop_range: tuple[float, float] | None = None
        self.loop_enabled = False
        self._base_positions: Dict[int, np.ndarray] = {}
        custom_geom = (
            (spec.metadata or {}).get("custom_geometry") if spec.metadata else None
        )
        if isinstance(custom_geom, Mapping):
            self.helix_geometry = self._geometry_from_custom(custom_geom)
            self.repair_geometry = self._repair_geometry_from_custom(custom_geom)
        else:
            self.helix_geometry = self._build_helix_geometry()
            self.repair_geometry = self._build_repair_geometry()
        self._phase_thresholds = self._build_phase_thresholds()

    @staticmethod
    def _resolve_event_time_units(spec: EditVisualizationSpec) -> tuple[str, str]:
        """Return (units, source) where units is 'seconds' or 'normalized'."""

        token: object | None = getattr(spec, "time_units", None)
        source = "explicit" if token is not None else "auto"

        if token is None and getattr(spec, "metadata", None):
            meta = spec.metadata or {}
            token = meta.get("time_units") or meta.get("event_time_units")
            if token is not None:
                source = "explicit"

        normalized: str | None = None
        if token is not None:
            t = str(token).strip().lower()
            if t in {"seconds", "second", "sec", "secs", "s"}:
                normalized = "seconds"
            elif t in {"normalized", "normalised", "norm", "fraction"}:
                normalized = "normalized"
            else:
                # Keep UI resilient when metadata contains unexpected values.
                normalized = None
                source = "auto"

        if normalized is None:
            # Back-compat heuristic: legacy specs used fractional event times.
            normalized = "normalized" if (bool(spec.events) and spec.duration <= 1.0) else "seconds"
            source = "auto"

        # Validate explicit normalized specs so we don't silently mis-gate shaders.
        if source == "explicit" and normalized == "normalized" and spec.events:
            times: list[float] = []
            for ev in spec.events:
                try:
                    t = float(ev.t)
                except Exception as exc:
                    raise ValueError(f"Event time must be a float (got {ev.t!r}).") from exc
                if not math.isfinite(t):
                    raise ValueError("Event times must be finite when time_units is explicit.")
                times.append(t)
            max_t = max(times)
            min_t = min(times)
            if min_t < -1e-6 or max_t > 1.0 + 1e-6:
                raise ValueError(
                    f"Normalized event times must be within [0, 1] (got range {min_t:.3f}..{max_t:.3f})."
                )

        return normalized, source

    def event_times_seconds(self) -> list[float]:
        """Return sorted, deduplicated event times in seconds within the loop."""

        loop = float(self.loop_duration)
        if loop <= 1e-6:
            return []

        normalized = bool(self.event_times_normalized)
        times: list[float] = []
        for ev in getattr(self.spec, "events", ()) or ():
            try:
                t_evt = float(getattr(ev, "t", 0.0))
            except Exception:
                continue
            if not math.isfinite(t_evt):
                continue
            t_s_raw = t_evt * loop if normalized else t_evt
            # Keep within the loop and avoid wrap-to-zero at exact boundaries.
            if abs(float(t_s_raw) - loop) <= 1e-6:
                t_s = loop - 1e-6
            else:
                t_s = float(t_s_raw) % loop
                if abs(t_s) <= 1e-12 and abs(float(t_s_raw)) > 1e-6:
                    # Values like `t=loop` or `t=2*loop` modulo to 0; treat as end-of-loop.
                    t_s = loop - 1e-6
                else:
                    t_s = max(0.0, min(loop - 1e-6, t_s))
            times.append(t_s)

        times.sort()
        deduped: list[float] = []
        for t_s in times:
            if not deduped or abs(t_s - deduped[-1]) > 1e-6:
                deduped.append(t_s)
        return deduped

    def set_loop_range(self, start: float, end: float) -> None:
        """Define an A/B loop range in seconds within [0, loop_duration]."""
        loop = float(self.loop_duration)
        if loop <= 1e-6:
            self.loop_range = None
            return
        try:
            a = float(start)
            b = float(end)
        except Exception:
            self.loop_range = None
            return
        if not math.isfinite(a) or not math.isfinite(b):
            self.loop_range = None
            return
        if b < a:
            a, b = b, a
        a = max(0.0, min(loop, a))
        b = max(0.0, min(loop, b))
        min_span = 1e-6
        if b - a < min_span:
            b = min(loop, a + min_span)
            if b - a < min_span:
                self.loop_range = None
                return
        self.loop_range = (a, b)

    def clear_loop_range(self) -> None:
        self.loop_range = None

    def set_loop_enabled(self, enabled: bool) -> None:
        self.loop_enabled = bool(enabled)

    # ------------------------------------------------------------------
    # Geometry builders
    def _build_helix_geometry(self) -> HelixGeometry:
        sequence = self.spec.sequence
        base_count = len(sequence)
        theta_step = 2.0 * math.pi / self.bases_per_turn
        total_samples = base_count * self.segments_per_base
        # Parameter along helix from 0..1 to keep consistent camera scale.
        samples = np.linspace(0.0, base_count - 1, total_samples, dtype=np.float32)
        thetas = samples * theta_step
        z = (samples / max(1, base_count - 1)) * 2.0 - 1.0

        def _rail_vertices(phase_offset: float) -> np.ndarray:
            theta = thetas + phase_offset
            x = self.radius * np.cos(theta)
            y = self.radius * np.sin(theta)
            return np.stack([x, y, z], axis=1).astype("f4")

        rail_a = _rail_vertices(0.0)
        rail_b = _rail_vertices(math.pi)
        rail_vertices = np.concatenate([rail_a, rail_b], axis=0)
        rail_ids = np.concatenate([
            np.zeros(len(rail_a), dtype="f4"),
            np.ones(len(rail_b), dtype="f4"),
        ])
        param_coords = np.concatenate([samples, samples], axis=0)
        if param_coords.size > 0:
            span = float(np.ptp(param_coords))
            param_coords = (param_coords - param_coords.min()) / max(1e-6, span)

        # Cache per-base centers for arc anchoring.
        base_centers = []
        base_indices = []
        for idx in range(base_count):
            theta = theta_step * idx
            x = self.radius * math.cos(theta)
            y = self.radius * math.sin(theta)
            zc = float(idx) / max(1, base_count - 1) * 2.0 - 1.0
            pos = np.array([x, y, zc], dtype="f4")
            self._base_positions[idx] = pos
            base_centers.append(pos)
            base_indices.append(idx)
        base_centers_arr = np.stack(base_centers, axis=0) if base_centers else np.zeros((0, 3), dtype="f4")
        base_idx_arr = np.array(base_indices, dtype="i4") if base_indices else np.zeros((0,), dtype="i4")
        return HelixGeometry(
            rail_vertices=rail_vertices,
            rail_ids=rail_ids,
            param_coords=param_coords.astype("f4"),
            base_centers=base_centers_arr,
            base_indices=base_idx_arr,
        )

    def _build_repair_geometry(self) -> RepairArcGeometry:
        arc_vertices: List[np.ndarray] = []
        offsets: List[int] = [0]
        event_types: List[EditEventType] = []
        event_times: List[float] = []
        for event in self.spec.events:
            try:
                if not math.isfinite(float(event.t)):
                    continue
            except Exception:
                continue
            anchor_idx = event.index
            if anchor_idx is None:
                anchor_idx = event.start
            if anchor_idx is None:
                continue
            if anchor_idx not in self._base_positions:
                continue
            if event.type not in {
                EditEventType.RECOGNITION,
                EditEventType.RT_SYNTHESIS,
                EditEventType.FLAP_RESOLUTION,
                EditEventType.REPAIR_COMPLETE,
            }:
                continue
            arc = self._arc_for_base(anchor_idx, event)
            arc_vertices.append(arc)
            offsets.append(offsets[-1] + len(arc))
            event_types.append(event.type)
            event_times.append(event.t)
        if arc_vertices:
            vertex_blob = np.vstack(arc_vertices).astype("f4")
        else:
            vertex_blob = np.zeros((0, 3), dtype="f4")
        return RepairArcGeometry(
            vertices=vertex_blob,
            offsets=np.array(offsets, dtype="i4"),
            event_types=event_types,
            event_times=event_times,
        )

    def _arc_for_base(self, base_idx: int, event: EditEvent) -> np.ndarray:
        base_pos = self._base_positions[base_idx]
        radial = base_pos.copy()
        radial[2] = 0.0
        norm = np.linalg.norm(radial)
        if norm < 1e-6:
            radial = np.array([1.0, 0.0, 0.0], dtype="f4")
        else:
            radial /= norm
        arc_height = 0.25 + 0.05 * (event.length or 1)
        control = base_pos + radial * arc_height + np.array([0.0, 0.0, 0.15], dtype="f4")
        samples = np.linspace(0.0, 1.0, 32, dtype="f4")
        curve = ((1 - samples)[:, None] ** 2) * base_pos + 2 * ((1 - samples)[:, None]) * (samples[:, None]) * control + (samples[:, None] ** 2) * base_pos
        return curve.astype("f4")

    def _geometry_from_custom(self, payload: Mapping[str, Any]) -> HelixGeometry:
        rv_data = payload.get("rail_vertices")
        rv = np.array(rv_data if rv_data is not None else [], dtype="f4")
        if rv.ndim == 1:
            rv = rv.reshape((-1, 3))
        rail_ids_data = payload.get("rail_ids")
        rail_ids = np.array(rail_ids_data if rail_ids_data is not None else [], dtype="f4")
        if rail_ids.size != rv.shape[0]:
            rail_ids = np.resize(rail_ids, (rv.shape[0],))
        param_data = payload.get("param_coords")
        param = np.array(param_data if param_data is not None else [], dtype="f4")
        if param.size > 0:
            span = float(np.ptp(param))
            param = (param - param.min()) / max(1e-6, span)
        else:
            param = np.zeros((rv.shape[0],), dtype="f4")
        if param.size != rv.shape[0]:
            param = np.resize(param, (rv.shape[0],))

        base_centers_raw = payload.get("base_centers")
        base_centers = np.array(base_centers_raw if base_centers_raw is not None else [], dtype="f4")
        if base_centers.ndim == 1:
            base_centers = base_centers.reshape((-1, 3))

        base_indices_raw = payload.get("base_indices")
        base_indices = np.array(base_indices_raw if base_indices_raw is not None else [], dtype="i4")

        # Many "custom_geometry" payloads describe rails/arcs but omit per-base indices.
        # Derive them from the spec sequence length so downstream viewers can place base
        # overlays and cut markers deterministically (instead of sampling rail vertices).
        seq_len = int(len(getattr(self.spec, "sequence", "") or ""))
        if seq_len > 0:
            if base_indices.size == 0:
                base_indices = np.arange(seq_len, dtype="i4")

            if base_centers.size == 0:
                # Best-effort: pick strand A (rail_id ~ 0) positions as base centers.
                try:
                    strand_mask = rail_ids < 0.5
                    strand = rv[strand_mask, :3] if rv.size else np.zeros((0, 3), dtype="f4")
                except Exception:
                    strand = rv[:, :3] if rv.size else np.zeros((0, 3), dtype="f4")

                if strand.shape[0] == seq_len:
                    base_centers = strand.astype("f4")
                elif strand.shape[0] > 0:
                    if seq_len == 1:
                        base_centers = strand[:1].astype("f4")
                    else:
                        idx = np.linspace(0.0, float(strand.shape[0] - 1), seq_len, dtype="f4")
                        pick = np.clip(np.round(idx).astype("i4"), 0, strand.shape[0] - 1)
                        base_centers = strand[pick, :3].astype("f4")
                else:
                    base_centers = np.zeros((0, 3), dtype="f4")

        # Normalize shapes/dtypes.
        if base_centers.ndim != 2 or base_centers.shape[1] != 3:
            base_centers = np.zeros((0, 3), dtype="f4")
        if base_indices.ndim != 1:
            base_indices = base_indices.reshape((-1,)).astype("i4")
        if base_indices.size != seq_len and seq_len > 0:
            base_indices = np.arange(seq_len, dtype="i4")
        return HelixGeometry(
            rail_vertices=rv,
            rail_ids=rail_ids,
            param_coords=param,
            base_centers=base_centers,
            base_indices=base_indices,
        )

    def _repair_geometry_from_custom(self, payload: Mapping[str, Any]) -> RepairArcGeometry:
        vert_data = payload.get("arc_vertices")
        vertices = np.array(vert_data if vert_data is not None else [], dtype="f4")
        if vertices.ndim == 1:
            vertices = vertices.reshape((-1, 3))
        offsets_data = payload.get("arc_offsets")
        if offsets_data is None:
            offsets_arr = np.array([0], dtype="i4")
        else:
            offsets_arr = np.array(offsets_data, dtype="i4")
        weights_data = payload.get("arc_weights")
        kinds_data = payload.get("arc_kinds")
        weights = np.array(weights_data if weights_data is not None else [], dtype="f4")
        kinds = np.array(kinds_data if kinds_data is not None else [], dtype="f4")
        return RepairArcGeometry(
            vertices=vertices,
            offsets=offsets_arr,
            event_types=[],
            event_times=[],
            weights=weights if weights.size else None,
            kinds=kinds if kinds.size else None,
        )

    # ------------------------------------------------------------------
    # Animation timeline helpers
    def _build_phase_thresholds(self) -> List[tuple[float, AnimationPhase]]:
        thresholds: List[tuple[float, AnimationPhase]] = [(0.0, AnimationPhase.APPROACH)]
        def _record(first_event: EditEvent | None, phase: AnimationPhase) -> None:
            if first_event:
                thresholds.append((first_event.t, phase))

        events = self.spec.events
        def _first_of(types: Iterable[EditEventType]) -> EditEvent | None:
            type_set = set(types)
            for ev in events:
                try:
                    if not math.isfinite(float(ev.t)):
                        continue
                except Exception:
                    continue
                if ev.type in type_set:
                    return ev
            return None

        _record(_first_of([EditEventType.RECOGNITION]), AnimationPhase.RECOGNITION)
        _record(_first_of([EditEventType.NICK_PRIMARY, EditEventType.CUT]), AnimationPhase.CUT)
        _record(_first_of([EditEventType.PRIME_INIT, EditEventType.RT_SYNTHESIS]), AnimationPhase.PRIME)
        _record(_first_of([EditEventType.FLAP_RESOLUTION]), AnimationPhase.REPAIR)
        last_event = None
        for ev in reversed(events or []):
            try:
                if not math.isfinite(float(ev.t)):
                    continue
            except Exception:
                continue
            last_event = ev
            break
        if last_event:
            thresholds.append((last_event.t, AnimationPhase.RESOLVE))
        thresholds = sorted({pair for pair in thresholds}, key=lambda x: x[0])
        if thresholds[-1][1] != AnimationPhase.RESOLVE:
            thresholds.append((self.loop_duration, AnimationPhase.RESOLVE))
        return thresholds

    def phase_for_time(self, t: float) -> AnimationPhase:
        loop_t = t % self.loop_duration
        if self.event_times_normalized and self.loop_duration > 1e-6:
            loop_t = loop_t / self.loop_duration
        current = AnimationPhase.APPROACH
        for time_marker, phase in self._phase_thresholds:
            if loop_t >= time_marker:
                current = phase
            else:
                break
        return current

    def set_time(self, t: float) -> AnimationState:
        loop = float(self.loop_duration)
        if loop <= 1e-6:
            self.state.time = 0.0
        else:
            try:
                t0 = float(t)
            except Exception:
                t0 = 0.0
            if not math.isfinite(t0):
                t0 = 0.0
            # Base timeline always lives within the loop duration.
            t0 = t0 % loop
            if self.loop_enabled and self.loop_range is not None:
                a, b = self.loop_range
                span = max(1e-6, float(b) - float(a))
                if t0 < a:
                    t0 = a
                elif t0 >= b:
                    t0 = float(a) + (t0 - float(a)) % span
                    if t0 >= b:
                        t0 = float(b) - 1e-6
            self.state.time = t0
        self.state.phase = self.phase_for_time(self.state.time)
        return self.state

    def advance(self, dt: float) -> AnimationState:
        return self.set_time(self.state.time + dt)

    # ------------------------------------------------------------------
    # Export helpers
    def active_events_within(self, t: float, window: float = 0.3) -> list[EditEvent]:
        loop_t = t % self.loop_duration
        if self.event_times_normalized:
            if self.loop_duration > 1e-6:
                loop_t = loop_t / self.loop_duration
                window = window / self.loop_duration
            start = max(0.0, loop_t - window)
            end = min(1.0, loop_t + window)
            hits = [ev for ev in self.spec.events if start <= ev.t <= end]
            if hits:
                return hits
            if loop_t + window > 1.0:
                wrap_hits = [ev for ev in self.spec.events if 0.0 <= ev.t <= (loop_t + window - 1.0)]
                return wrap_hits
            return []

        start = max(0.0, loop_t - window)
        end = min(self.loop_duration, loop_t + window)
        hits = [ev for ev in self.spec.events if start <= ev.t <= end]
        if hits:
            return hits
        if loop_t + window > self.loop_duration:
            wrap_hits = [ev for ev in self.spec.events if 0.0 <= ev.t <= (loop_t + window - self.loop_duration)]
            return wrap_hits
        return []

    def buffer_payload(self) -> Dict[str, np.ndarray]:
        """Return ModernGL-friendly ndarray bundles for the Qt shell."""

        return {
            "rail_vertices": self.helix_geometry.rail_vertices,
            "rail_ids": self.helix_geometry.rail_ids,
            "param_coords": self.helix_geometry.param_coords,
            "base_centers": self.helix_geometry.base_centers,
            "base_indices": self.helix_geometry.base_indices,
            "arc_vertices": self.repair_geometry.vertices,
            "arc_offsets": self.repair_geometry.offsets,
            "arc_weights": self.repair_geometry.weights if self.repair_geometry.weights is not None else np.zeros((0,), dtype="f4"),
            "arc_kinds": self.repair_geometry.kinds if self.repair_geometry.kinds is not None else np.zeros((0,), dtype="f4"),
        }

    def export_timeline(self) -> dict[str, Any]:
        """Structured dict that Unity (or other DCC tools) can ingest."""

        def _t_seconds(value: float) -> float:
            if self.event_times_normalized:
                return float(value) * float(self.loop_duration)
            return float(value)

        return {
            "duration": self.loop_duration,
            "phase_markers": [
                {"time": _t_seconds(t), "phase": phase.value}
                for t, phase in self._phase_thresholds
            ],
            "events": [
                {
                    "time": _t_seconds(event.t),
                    "type": event.type.value,
                    "index": event.index,
                    "start": event.start,
                    "length": event.length,
                    "metadata": dict(event.metadata),
                }
                for event in self.spec.events
            ],
        }
