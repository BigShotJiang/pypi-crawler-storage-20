from __future__ import annotations

import math
from collections.abc import Iterable, Sequence

import numpy as np


def fit_ortho_camera_distance(
    *,
    center_xy: tuple[float, float],
    points_xy: Sequence[tuple[float, float]],
    margin: float = 1.2,
    min_distance: float = 0.15,
) -> float:
    """Return a scalar distance used as 2D zoom (larger = zoom out).

    In HelixModernWidget's flat rail mode the MVP applies a uniform scale of
    `1 / cam_distance` to X and Y. With the camera centered at `center_xy`,
    a point is visible if `abs(dx) <= cam_distance` and `abs(dy) <= cam_distance`.
    """
    cx, cy = float(center_xy[0]), float(center_xy[1])
    max_off = 0.0
    for x, y in points_xy:
        dx = abs(float(x) - cx)
        dy = abs(float(y) - cy)
        max_off = max(max_off, dx, dy)
    m = max(1.0, float(margin))
    return max(float(min_distance), float(max_off) * m)


def radius_from_points(
    *,
    center: np.ndarray,
    points: Iterable[np.ndarray],
) -> float:
    """Max distance from center across points (3D)."""
    c = np.asarray(center, dtype="f4").reshape((3,))
    r = 0.0
    for p in points:
        v = np.asarray(p, dtype="f4").reshape((3,))
        r = max(r, float(np.linalg.norm(v - c)))
    return float(r)


def fit_perspective_orbit_distance(
    *,
    radius: float,
    fov_y_deg: float,
    aspect: float,
    margin: float = 1.2,
    min_distance: float = 0.5,
) -> float:
    """Return target cam_distance to fit a sphere of `radius` in view.

    Uses the smaller of horizontal/vertical half-FOV to remain conservative.
    """
    r = max(0.0, float(radius))
    if r <= 1e-9:
        return float(min_distance)

    half_y = math.radians(float(fov_y_deg)) * 0.5
    half_y = max(math.radians(1.0), min(math.radians(89.0), half_y))
    try:
        a = float(aspect)
    except Exception:
        a = 1.0
    a = max(1e-6, a)
    half_x = math.atan(math.tan(half_y) * a)
    half = min(half_y, half_x)
    denom = max(1e-6, math.sin(half))
    d = r / denom
    m = max(1.0, float(margin))
    return max(float(min_distance), d * m)

