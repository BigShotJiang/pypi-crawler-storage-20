"""PyQt shell that wraps the ModernGL helix core."""

from __future__ import annotations

import json
import math
import os
import statistics
import sys
from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

import numpy as np

from helix import clock
from helix.determinism import allow_nondeterminism
from .camera_fit import (
    fit_ortho_camera_distance,
    fit_perspective_orbit_distance,
    radius_from_points,
)
from .selection_utils import compute_selection_payload, event_confidence, infer_model_layer

try:  # Allow import in headless environments without moderngl installed
    import moderngl

    _HAS_MODERNGL = True
except Exception:  # pragma: no cover - CI/headless environments
    moderngl = None  # type: ignore[assignment]
    _HAS_MODERNGL = False

try:  # Allow import in headless environments without PyOpenGL
    from OpenGL import GL  # type: ignore[import]
    _HAS_GL = True
except Exception:  # pragma: no cover - exercised only in headless CI
    GL = None  # type: ignore[assignment]
    _HAS_GL = False

try:  # Allow import in headless environments without Qt / libEGL
    from PySide6.QtCore import (
        QByteArray,
        QEvent,
        QPoint,
        QPointF,
        QRect,
        QSettings,
        QSize,
        Qt,
        QThread,
        QTimer,
        Signal,
    )
    from PySide6.QtGui import QColor, QFont, QPainter, QPen, QPolygonF, QSurfaceFormat
    from PySide6.QtOpenGLWidgets import QOpenGLWidget
    from PySide6.QtWidgets import (
        QApplication,
        QCheckBox,
        QComboBox,
        QFormLayout,
        QFrame,
        QGroupBox,
        QHBoxLayout,
        QLabel,
        QMainWindow,
        QPushButton,
        QSpinBox,
        QDoubleSpinBox,
        QSlider,
        QSplitter,
        QTabWidget,
        QTextBrowser,
        QVBoxLayout,
        QWidget,
        QPlainTextEdit,
    )
    _HAS_QT = True
except Exception:  # pragma: no cover - exercised only in headless CI
    class _DummyQtBase:
        def __init__(self, *args, **kwargs) -> None:  # pragma: no cover - lightweight stub
            pass

    class _DummySignal:
        def __init__(self, *args, **kwargs) -> None:  # pragma: no cover
            pass

        def emit(self, *args, **kwargs) -> None:  # pragma: no cover
            pass

        def connect(self, *args, **kwargs) -> None:  # pragma: no cover
            pass

    Qt = QTimer = QPointF = QThread = QSize = QEvent = QPoint = QRect = QSettings = QByteArray = _DummyQtBase  # type: ignore[assignment]
    Signal = _DummySignal  # type: ignore[assignment]
    QSurfaceFormat = QOpenGLWidget = _DummyQtBase  # type: ignore[assignment]
    QFont = QColor = QPainter = QPen = QPolygonF = _DummyQtBase  # type: ignore[assignment]
    QApplication = (
        QCheckBox
    ) = QComboBox = QFormLayout = QGroupBox = QHBoxLayout = QVBoxLayout = QFrame = QLabel = QMainWindow = QPushButton = QTextBrowser = QSlider = QWidget = _DummyQtBase  # type: ignore[assignment]
    QSplitter = QTabWidget = QPlainTextEdit = _DummyQtBase  # type: ignore[assignment]
    _HAS_QT = False

if _HAS_QT:
    try:
        from ..theme import apply_helix_theme
    except Exception:  # pragma: no cover - theme needs QtGui/libEGL
        apply_helix_theme = lambda app: None  # type: ignore[assignment]
        _HAS_QT = False
    from helix.studio.evs_bridge import GuideContext, PrimeContext
    from helix.studio.render.scene import GenomeScene

    from ...config import native_backend_available, resolve_crispr_backend
    from .engine import AnimationPhase, HelixVizEngine
    from .spec import (
        EditEvent,
        EditEventType,
        EditVisualizationSpec,
        load_viz_spec,
        load_viz_specs,
    )
if not _HAS_QT:  # pragma: no cover - headless / no-Qt fallback
    def apply_helix_theme(app):
        return None


def _resolve_shader_root() -> Path:
    candidates: list[Path] = []
    if getattr(sys, "frozen", False):
        base = Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent))
        candidates.append(base / "shaders")
        candidates.append(base / "helix" / "shaders")

    module_root = Path(__file__).resolve().parents[2]
    candidates.append(module_root / "shaders")

    repo_root = Path(__file__).resolve().parents[4]
    candidates.append(repo_root / "shaders")
    candidates.append(Path.cwd() / "shaders")

    for cand in candidates:
        try:
            if (cand / "heatmap").is_dir():
                return cand
        except Exception:
            continue
    return candidates[0]

    native_backend_available = resolve_crispr_backend = lambda *args, **kwargs: None  # type: ignore[assignment]
    AnimationPhase = HelixVizEngine = EditVisualizationSpec = EditEventType = EditEvent = load_viz_spec = load_viz_specs = object  # type: ignore[assignment]


class RailViewMode(str, Enum):
    FLAT = "flat"
    HELIX = "helix"


class HudDisplayState(str, Enum):
    EXPANDED = "expanded"
    COLLAPSING = "collapsing"
    COLLAPSED = "collapsed"
    HIDDEN = "hidden"


class LegendToastState(str, Enum):
    INACTIVE = "inactive"
    ACTIVE = "active"


@dataclass(frozen=True, slots=True)
class ModernVizStyle:
    version: str = "modern-v2"
    flat_rail_spacing: float = 0.525
    flat_rail_thickness_px: int = 3
    flat_rail_marker_radius_px: int = 6
    flat_rail_label_font_px: int = 13
    flat_rail_label_offset_px: int = 8
    flat_ribbon_arrow_len: float = 0.05
    flat_ribbon_arrow_width: float = 0.025
    helix_strand_radius_px: int = 6
    helix_strand_thickness_px: int = 2
    event_marker_radius_px: int = 6
    dim_alpha_out_of_window: float = 0.22
    hud_collapse_delay_ms: int = 1000
    hud_collapsed_opacity: float = 0.35
    legend_toast_total_s: float = 2.4
    legend_toast_fade_fraction: float = 0.4


# Canonical style. Keep this as the single source of truth; overrides should
# be explicit and local (e.g. tests passing `style=...`).
MODERN_STYLE = ModernVizStyle()

# Geometric smoothing for helix rails
HELIX_SAMPLES_PER_BP = 4
MAX_HELIX_SAMPLES = 20000

_COMMON_REFRESH_HZ: tuple[float, ...] = (59.94, 60.0, 119.88, 120.0)


def _round_half_up(value: float) -> int:
    """Round halves away from zero (Qt-style), returning an int."""

    try:
        v = float(value)
    except Exception:
        return 0
    if not math.isfinite(v):
        return 0
    if v >= 0.0:
        return int(math.floor(v + 0.5))
    return -int(math.floor(abs(v) + 0.5))


def _logical_to_physical_px(logical_px: float, dpr: float) -> int:
    """Convert logical pixels to physical pixels with Qt-style rounding."""

    try:
        scale = float(dpr)
    except Exception:
        scale = 1.0
    if not (scale > 1e-6) or not math.isfinite(scale):
        scale = 1.0
    px = _round_half_up(float(logical_px) * scale)
    return max(1, int(px))


def _logical_to_physical_pos_px(logical_px: float, dpr: float, *, limit_px: int) -> int:
    """Convert a logical pixel coordinate into a physical pixel index.

    This is intended for things like ID-buffer picking. It uses the same half-up
    rounding as framebuffer sizing, then clamps into [0, limit_px-1].
    """

    try:
        limit = int(limit_px)
    except Exception:
        limit = 0
    if limit <= 0:
        return 0

    try:
        scale = float(dpr)
    except Exception:
        scale = 1.0
    if not (scale > 1e-6) or not math.isfinite(scale):
        scale = 1.0

    px = _round_half_up(float(logical_px) * scale)
    return max(0, min(limit - 1, int(px)))


def _framebuffer_size_px(*, logical_w: int, logical_h: int, dpr: float) -> tuple[int, int]:
    """Return (width_px, height_px) for a logical size + devicePixelRatio."""

    w = _logical_to_physical_px(max(1, int(logical_w)), dpr)
    h = _logical_to_physical_px(max(1, int(logical_h)), dpr)
    return w, h


def _draw_helix_reference_frame(
    painter: QPainter,
    *,
    project: Callable[[float, float, float], tuple[float, float] | None],
    bounds: tuple[float, float, float],
    now_frac: float,
    pulse: float = 0.0,
) -> None:
    """Draw a faint 'now' reference plane and a vertical axis spine in helix view.

    This is intentionally UI-only (QPainter overlay) so it remains deterministic and testable.
    """

    try:
        z_min, z_max, xy_radius = bounds
    except Exception:
        return

    z0 = float(z_min)
    z1 = float(z_max)
    if z1 < z0:
        z0, z1 = z1, z0

    frac = float(now_frac)
    if not math.isfinite(frac):
        frac = 0.0
    frac = max(0.0, min(1.0, frac))
    z_now = z0 + (z1 - z0) * frac

    r = float(xy_radius) if math.isfinite(float(xy_radius)) else 1.0
    r = max(1e-3, r)

    plane_half = r + 0.85
    corners = (
        (-plane_half, -plane_half, z_now),
        (plane_half, -plane_half, z_now),
        (plane_half, plane_half, z_now),
        (-plane_half, plane_half, z_now),
    )
    pts: list[QPointF] = []
    for x, y, z in corners:
        pt = project(float(x), float(y), float(z))
        if pt is None:
            pts = []
            break
        sx, sy = pt
        pts.append(QPointF(float(sx), float(sy)))

    if len(pts) == 4:
        try:
            alpha = 16 + int(8 * float(pulse))
        except Exception:
            alpha = 16
        alpha = max(0, min(60, int(alpha)))
        try:
            painter.setPen(Qt.NoPen)
            painter.setBrush(QColor(120, 185, 255, alpha))
            painter.drawPolygon(QPolygonF(pts))
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor(120, 185, 255, 70), 1))
            painter.drawPolygon(QPolygonF(pts))
        except Exception:
            pass

    axis_x = -(r + 1.25)
    axis_y = 0.0
    a0 = project(axis_x, axis_y, z0)
    a1 = project(axis_x, axis_y, z1)
    if a0 is None or a1 is None:
        return

    try:
        painter.setPen(QPen(QColor(160, 175, 210, 90), 1))
        painter.drawLine(int(a0[0]), int(a0[1]), int(a1[0]), int(a1[1]))
    except Exception:
        pass

    tick_len_world = 0.30
    tick_count = 5
    for i in range(tick_count):
        t = i / max(1, tick_count - 1)
        zt = z0 + (z1 - z0) * float(t)
        ta = project(axis_x, axis_y, zt)
        tb = project(axis_x + tick_len_world, axis_y, zt)
        if ta is None or tb is None:
            continue
        try:
            painter.setPen(QPen(QColor(160, 175, 210, 90), 1))
            painter.drawLine(int(ta[0]), int(ta[1]), int(tb[0]), int(tb[1]))
        except Exception:
            pass

    # Current time marker on the spine.
    ta = project(axis_x, axis_y, z_now)
    tb = project(axis_x + tick_len_world * 1.4, axis_y, z_now)
    if ta is None or tb is None:
        return
    try:
        painter.setPen(QPen(QColor(210, 232, 255, 210), 2))
        painter.drawLine(int(ta[0]), int(ta[1]), int(tb[0]), int(tb[1]))
        painter.setPen(QColor(210, 232, 255, 210))
        prev_font = None
        try:
            prev_font = painter.font()
            font = QFont(prev_font)
            # Keep this deterministic across the suite even if other code tweaks the app font.
            font.setFamily("Inter")
            font.setPixelSize(12)
            painter.setFont(font)
        except Exception:
            prev_font = None
        painter.drawText(int(tb[0]) + 6, int(tb[1]) + 4, "now")
        if prev_font is not None:
            try:
                painter.setFont(prev_font)
            except Exception:
                pass
    except Exception:
        pass


def _snap_common_refresh_hz(hz: float) -> float:
    if hz <= 1e-6:
        return float(hz)
    base_period = 1000.0 / float(hz)
    best = float(hz)
    best_err = float("inf")
    for canonical in _COMMON_REFRESH_HZ:
        period = 1000.0 / float(canonical)
        err = abs(base_period - period)
        if err < best_err:
            best = float(canonical)
            best_err = float(err)
    # Snap if the implied interval is extremely close (e.g. 59.94 vs 60).
    if best_err <= 0.25:
        return float(best)
    return float(hz)


_TYPICAL_REFRESH_HZ_PREFERENCE: tuple[float, ...] = (
    59.94,
    60.0,
    119.88,
    120.0,
    144.0,
    165.0,
    180.0,
    240.0,
    90.0,
    100.0,
    75.0,
    72.0,
    50.0,
    48.0,
    40.0,
    30.0,
)


def _typical_refresh_rank(hz: float) -> tuple[float, int]:
    hz = float(hz)
    if hz <= 1e-6 or not math.isfinite(hz):
        return float("inf"), len(_TYPICAL_REFRESH_HZ_PREFERENCE)
    best_rel = float("inf")
    best_rank = len(_TYPICAL_REFRESH_HZ_PREFERENCE)
    for rank, typical in enumerate(_TYPICAL_REFRESH_HZ_PREFERENCE):
        rel = abs(hz - typical) / typical
        if rel < best_rel - 1e-12 or (abs(rel - best_rel) <= 1e-12 and rank < best_rank):
            best_rel = float(rel)
            best_rank = int(rank)
    return float(best_rel), int(best_rank)


@dataclass
class HudState:
    label: str = "Helix"
    run_kind: str = "CRISPR"
    guide: str = "-"
    seq_len: int = 0
    view_mode: str = "Flat rails"
    time_s: float = 0.0
    time_norm: float = 0.0
    phase: str = "approach"
    selected: str = ""
    strand_a: str = "Orange"
    strand_b: str = "Cyan"


@dataclass(frozen=True, slots=True)
class CutSemantics:
    flat_rail_spacing: float = float(MODERN_STYLE.flat_rail_spacing)
    flat_template_rail_id: int = 1
    flat_opposite_rail_id: int = 0
    glyph_cut: str = "■"
    glyph_repair: str = "◆"

    cut_index: int | None = None
    cut_time_s: float | None = None
    cut_event_order: int | None = None

    nick_primary_index: int | None = None
    nick_primary_time_s: float | None = None
    nick_primary_event_order: int | None = None

    nick_secondary_index: int | None = None
    nick_secondary_time_s: float | None = None
    nick_secondary_event_order: int | None = None

    cursor_site: str | None = None
    cursor_label: str | None = None
    cursor_index: int | None = None
    cursor_time_s: float | None = None
    cursor_event_order: int | None = None
    cursor_param: float | None = None
    cursor_flat_x: float | None = None
    cursor_flat_rail_id: int | None = None
    cursor_flat_y: float | None = None

    resolved_event_time_s: float | None = None
    resolved_event_order: int | None = None
    resolved_phase: str | None = None
    label_to_site: tuple[tuple[str, str], ...] = ()

    @classmethod
    def from_spec(cls, spec: Any) -> "CutSemantics":
        seq = ""
        try:
            seq = str(getattr(spec, "sequence", "") or "")
        except Exception:
            seq = ""
        seq_len = int(len(seq))
        denom = max(1, seq_len - 1)

        meta_cut_index: int | None = None
        try:
            meta = getattr(spec, "metadata", None) or {}
            rail_bands = meta.get("rail_bands") if isinstance(meta, Mapping) else None
            if isinstance(rail_bands, Mapping) and rail_bands.get("cut_index") is not None:
                meta_cut_index = int(rail_bands.get("cut_index"))
        except Exception:
            meta_cut_index = None

        try:
            events = getattr(spec, "events", None) or []
        except Exception:
            events = []

        def _int_or_none(value: object | None) -> int | None:
            if value is None:
                return None
            try:
                return int(value)
            except Exception:
                return None

        def _float_or_none(value: object | None) -> float | None:
            if value is None:
                return None
            try:
                return float(value)
            except Exception:
                return None

        def _idx_key(idx: int | None) -> int:
            return -1 if idx is None else int(idx)

        def _float_key(t: float | None) -> float:
            return float("inf") if t is None else float(t)

        rows: list[dict[str, object]] = []
        for ev in events:
            typ = getattr(ev, "type", None)
            token = str(getattr(typ, "value", typ)).strip().lower()
            idx_val = _int_or_none(getattr(ev, "index", None))
            start_val = _int_or_none(getattr(ev, "start", None))
            length_val = _int_or_none(getattr(ev, "length", None))
            t_val = _float_or_none(getattr(ev, "t", None))
            key = (
                _float_key(t_val),
                token,
                _idx_key(idx_val),
                _idx_key(start_val),
                _idx_key(length_val),
            )
            rows.append(
                {
                    "token": token,
                    "idx": idx_val if idx_val is not None else start_val,
                    "idx_val": idx_val,
                    "start_val": start_val,
                    "length_val": length_val,
                    "t_val": t_val,
                    "key": key,
                }
            )

        key_rank: dict[tuple[float, str, int, int, int], int] = {
            key: rank for rank, key in enumerate(sorted({row["key"] for row in rows}))  # type: ignore[misc]
        }

        def _pick_first(*, token: str, require_index: bool) -> dict[str, object] | None:
            candidates = []
            for row in rows:
                if row["token"] != token:
                    continue
                idx = row["idx"]
                if require_index and idx is None:
                    continue
                candidates.append(row)
            if not candidates:
                return None
            return min(candidates, key=lambda r: r["key"])  # type: ignore[arg-type]

        cut_row = _pick_first(token="cut", require_index=True)
        nick_primary_row = _pick_first(token="nick_primary", require_index=True)
        nick_secondary_row = _pick_first(token="nick_secondary", require_index=True)
        repair_row = _pick_first(token="repair_complete", require_index=False)

        def _row_int(row: dict[str, object] | None, key: str) -> int | None:
            if row is None:
                return None
            val = row.get(key)
            return val if isinstance(val, int) else None

        def _row_float(row: dict[str, object] | None, key: str) -> float | None:
            if row is None:
                return None
            val = row.get(key)
            return val if isinstance(val, float) else None

        def _row_rank(row: dict[str, object] | None) -> int | None:
            if row is None:
                return None
            key = row.get("key")
            if not isinstance(key, tuple):
                return None
            return int(key_rank.get(key, 0))

        cut_index = _row_int(cut_row, "idx")
        cut_time_s = _row_float(cut_row, "t_val")
        cut_event_order = _row_rank(cut_row)

        nick_primary_index = _row_int(nick_primary_row, "idx")
        nick_primary_time_s = _row_float(nick_primary_row, "t_val")
        nick_primary_event_order = _row_rank(nick_primary_row)

        nick_secondary_index = _row_int(nick_secondary_row, "idx")
        nick_secondary_time_s = _row_float(nick_secondary_row, "t_val")
        nick_secondary_event_order = _row_rank(nick_secondary_row)

        resolved_event_time_s = _row_float(repair_row, "t_val")
        resolved_event_order = _row_rank(repair_row)

        cursor_site: str | None = None
        cursor_label: str | None = None
        cursor_index: int | None = None
        cursor_time_s: float | None = None
        cursor_event_order: int | None = None

        cursor_candidates = [row for row in rows if row.get("token") in {"nick_primary", "cut"} and row.get("idx") is not None]
        if cursor_candidates:
            priority = {"nick_primary": 0, "cut": 1}

            def _cursor_key(r: dict[str, object]) -> tuple[float, int, int, int]:
                token = str(r.get("token") or "")
                t_val = r.get("t_val")
                t_sort = float(t_val) if isinstance(t_val, float) else float("inf")
                idx = int(r.get("idx")) if isinstance(r.get("idx"), int) else -1
                rank = _row_rank(r) or 0
                return (t_sort, int(priority.get(token, 99)), idx, int(rank))

            best = min(cursor_candidates, key=_cursor_key)
            cursor_site = str(best.get("token") or "")
            cursor_label = "cut"
            cursor_index = int(best.get("idx")) if isinstance(best.get("idx"), int) else None
            cursor_time_s = float(best.get("t_val")) if isinstance(best.get("t_val"), float) else None
            cursor_event_order = _row_rank(best)
        elif meta_cut_index is not None:
            cursor_site = "metadata_cut"
            cursor_label = "cut"
            cursor_index = meta_cut_index
            cursor_time_s = None
            cursor_event_order = None

        def _clamp_idx(idx: int | None) -> int | None:
            if idx is None:
                return None
            if seq_len <= 0:
                return int(idx)
            return max(0, min(seq_len - 1, int(idx)))

        cut_index = _clamp_idx(cut_index)
        nick_primary_index = _clamp_idx(nick_primary_index)
        nick_secondary_index = _clamp_idx(nick_secondary_index)
        cursor_index = _clamp_idx(cursor_index)

        cursor_param: float | None = None
        cursor_flat_x: float | None = None
        cursor_flat_rail_id: int | None = None
        cursor_flat_y: float | None = None
        if cursor_index is not None and seq_len > 1:
            t_pos = float(cursor_index) / float(denom)
            cursor_param = float(t_pos)
            cursor_flat_x = (t_pos * 2.0 - 1.0) * 0.9
            cursor_flat_rail_id = 1
            cursor_flat_y = float(MODERN_STYLE.flat_rail_spacing)

        resolved_phase = "resolve" if resolved_event_time_s is not None else None

        label_to_site: list[tuple[str, str]] = []
        if cursor_label is not None and cursor_site is not None:
            label_to_site.append((cursor_label, cursor_site))

        return cls(
            cut_index=cut_index,
            cut_time_s=cut_time_s,
            cut_event_order=cut_event_order,
            nick_primary_index=nick_primary_index,
            nick_primary_time_s=nick_primary_time_s,
            nick_primary_event_order=nick_primary_event_order,
            nick_secondary_index=nick_secondary_index,
            nick_secondary_time_s=nick_secondary_time_s,
            nick_secondary_event_order=nick_secondary_event_order,
            cursor_site=cursor_site,
            cursor_label=cursor_label,
            cursor_index=cursor_index,
            cursor_time_s=cursor_time_s,
            cursor_event_order=cursor_event_order,
            cursor_param=cursor_param,
            cursor_flat_x=cursor_flat_x,
            cursor_flat_rail_id=cursor_flat_rail_id,
            cursor_flat_y=cursor_flat_y,
            resolved_event_time_s=resolved_event_time_s,
            resolved_event_order=resolved_event_order,
            resolved_phase=resolved_phase,
            label_to_site=tuple(label_to_site),
        )


@dataclass
class ViewerPerfStats:
    fps: float
    frame_ms: float
    cpu_ms: float
    cpu_pct: float
    bound: str
    samples: int
    wait_ms: float = 0.0
    wait_raw_ms: float = 0.0
    refresh_hz_used: float | None = None
    refresh_hz_source: str = ""
    pacing_ms: float = 0.0
    window_frames: int = 0


def _env_flag(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return int(default)
    try:
        return int(raw.strip())
    except Exception:
        return int(default)


@dataclass(slots=True)
class _ResizeAllocationState:
    """Tracks resize-driven allocation state with a critical vs heavy split.

    - desired_fb_px: the latest physical framebuffer size observed.
    - active_pick_px: the *critical* pick buffer size actually used for mapping/sampling.
    - heavy_*: debounced allocations for expensive, non-interaction-critical buffers.
    """

    debounce_s: float
    desired_fb_px: tuple[int, int] | None = None
    active_pick_px: tuple[int, int] | None = None
    heavy_pending_px: tuple[int, int] | None = None
    heavy_committed_px: tuple[int, int] | None = None
    heavy_last_change_s: float | None = None

    def note_desired(self, fb_w: int, fb_h: int, *, now_s: float) -> bool:
        size = (int(fb_w), int(fb_h))
        if size == self.desired_fb_px:
            return False
        self.desired_fb_px = size
        self.heavy_pending_px = size
        self.heavy_last_change_s = float(now_s)
        return True

    def pop_heavy_commit(self, *, now_s: float) -> tuple[int, int] | None:
        pending = self.heavy_pending_px
        if pending is None:
            return None
        if pending == self.heavy_committed_px:
            return None
        debounce_s = float(self.debounce_s)
        last_change = self.heavy_last_change_s
        if debounce_s <= 1e-6 or last_change is None:
            self.heavy_committed_px = pending
            return pending
        if float(now_s) - float(last_change) >= debounce_s:
            self.heavy_committed_px = pending
            return pending
        return None


@dataclass(slots=True)
class _PickIdBufferResources:
    """GPU resources for ID-buffer picking (single-sample, integer color)."""

    size_px: tuple[int, int]
    color_tex: object
    depth: object
    fbo: object


@dataclass(slots=True)
class _HeavyRenderResources:
    """Debounced (non-picking) render targets (MSAA, postprocess, etc)."""

    size_px: tuple[int, int]


def _try_release_mgl(obj: object | None) -> None:
    if obj is None:
        return
    try:
        obj.release()  # type: ignore[attr-defined]
    except Exception:
        pass


def _alloc_pick_id_buffer_resources(
    *,
    ctx: object,
    size_px: tuple[int, int],
    prev: _PickIdBufferResources | None,
) -> _PickIdBufferResources:
    """Allocate a single-sample integer ID buffer + matching depth attachment.

    GPU ID picking spec (do not improvise later):
    - Color attachment: R32UI (ModernGL: `components=1, dtype='u4'`)
    - Clear value 0 means "no hit"
    - Fragment shader writes uint id directly (no normalization)
    - Readback uses GL_RED_INTEGER / GL_UNSIGNED_INT (ModernGL dtype 'u4')
    - Depth attachment must exist and match dimensions
    - No MSAA in the pick path, ever (avoid resolve semantics / wrong ids)
    """

    w, h = int(size_px[0]), int(size_px[1])
    if w <= 0 or h <= 0:
        raise ValueError(f"Invalid pick buffer size: {size_px}")
    if prev is not None and tuple(prev.size_px) == (w, h):
        return prev

    # Allocate new targets first, validate, then swap+release old.
    color_tex = ctx.texture((w, h), components=1, dtype="u4")  # type: ignore[attr-defined]
    depth = ctx.depth_renderbuffer((w, h))  # type: ignore[attr-defined]
    fbo = ctx.framebuffer(color_attachments=[color_tex], depth_attachment=depth)  # type: ignore[attr-defined]

    complete = getattr(fbo, "is_complete", None)
    if callable(complete):
        try:
            is_ok = bool(complete())
        except Exception:
            is_ok = True
    elif complete is not None:
        is_ok = bool(complete)
    else:
        is_ok = True
    if not is_ok:
        _try_release_mgl(fbo)
        _try_release_mgl(color_tex)
        _try_release_mgl(depth)
        raise RuntimeError(f"Pick ID framebuffer is incomplete for size {w}x{h}")

    out = _PickIdBufferResources(size_px=(w, h), color_tex=color_tex, depth=depth, fbo=fbo)

    if prev is not None:
        _try_release_mgl(getattr(prev, "fbo", None))
        _try_release_mgl(getattr(prev, "color_tex", None))
        _try_release_mgl(getattr(prev, "depth", None))

    return out


def _alloc_heavy_render_resources(
    *,
    ctx: object,
    size_px: tuple[int, int],
    prev: _HeavyRenderResources | None,
) -> _HeavyRenderResources:
    """Allocate debounced heavy render targets (strictly non-picking)."""

    _ = ctx
    w, h = int(size_px[0]), int(size_px[1])
    if w <= 0 or h <= 0:
        raise ValueError(f"Invalid heavy buffer size: {size_px}")
    if prev is not None and tuple(prev.size_px) == (w, h):
        return prev
    return _HeavyRenderResources(size_px=(w, h))


@contextmanager
def _bool_state_guard(
    *,
    current: Callable[[], bool | None],
    set_state: Callable[[bool], None],
    default: bool,
    desired: bool,
):
    """Guard a boolean state flip and restore it on exit.

    This is used for GL enable/disable toggles where long-tail bugs come from
    state leakage across draw passes.
    """

    prev = current()
    if prev is None:
        prev = bool(default)
    prev = bool(prev)
    desired = bool(desired)
    if desired != prev:
        set_state(desired)
    try:
        yield
    finally:
        cur = current()
        if cur is None:
            cur = prev
        if bool(cur) != prev:
            set_state(prev)


_PHASE_BLURBS: dict[str, str] = {
    "approach": "Complex approaches the target locus.",
    "recognition": "Guide binding and PAM check.",
    "cut": "A cut or nick is made at the target index.",
    "prime": "RT synthesis extends from the pegRNA.",
    "repair": "Flaps resolve; repair pathways compete.",
    "resolve": "Repair completes; outcome is finalized.",
}


def _css_rgb(r: int, g: int, b: int) -> str:
    fn = "rgb"
    return f"{fn}({int(r)}, {int(g)}, {int(b)})"


def _css_rgba(r: int, g: int, b: int, a: float | int) -> str:
    fn = "rgba"
    if isinstance(a, float):
        if not math.isfinite(a):
            a = 0.0
        # Qt accepts both alpha-fraction and 0..255. Keep fractions as-is and
        # clamp integers into the 0..255 range.
        if 0.0 <= a <= 1.0:
            alpha = f"{max(0.0, min(1.0, float(a))):g}"
        else:
            alpha = str(max(0, min(255, int(round(float(a))))))
    else:
        alpha = str(max(0, min(255, int(a))))
    return f"{fn}({int(r)}, {int(g)}, {int(b)}, {alpha})"


class HudOverlay(QFrame):
    """A small HUD drawn on top of the OpenGL viewport (mouse transparent)."""

    def __init__(self, parent: QWidget | None = None, *, style: ModernVizStyle | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("HelixHudOverlay")
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAutoFillBackground(False)
        self._style = style or MODERN_STYLE

        hud_bg = _css_rgba(10, 14, 24, 155)
        hud_border = _css_rgba(120, 160, 255, 60)
        hud_text = _css_rgba(245, 248, 255, 235)
        self.setStyleSheet(
            """
            QFrame#HelixHudOverlay {
                background: %s;
                border: 1px solid %s;
                border-radius: 12px;
            }
            QLabel {
                color: %s;
            }
            """
            % (hud_bg, hud_border, hud_text)
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(4)

        self._title = QLabel("HELIX · Realtime Viz", self)
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(10)
        self._title.setFont(title_font)

        self._line1 = QLabel("", self)
        self._line2 = QLabel("", self)
        self._line3 = QLabel("", self)
        self._line4 = QLabel("", self)
        self._legend = QLabel("", self)
        self._hotkeys = QLabel("", self)
        self._selected = QLabel("", self)

        mono = QFont("Consolas")
        mono.setPointSize(9)
        for lab in (
            self._line1,
            self._line2,
            self._line3,
            self._line4,
            self._legend,
            self._hotkeys,
            self._selected,
        ):
            lab.setFont(mono)
            lab.setTextInteractionFlags(Qt.TextSelectableByMouse)

        self._selected.setStyleSheet(f"color: {_css_rgba(255, 236, 160, 235)};")
        self._hotkeys.setStyleSheet(f"color: {_css_rgba(200, 220, 255, 180)};")

        layout.addWidget(self._title)
        layout.addWidget(self._line1)
        layout.addWidget(self._line2)
        layout.addWidget(self._line3)
        layout.addWidget(self._selected)
        layout.addWidget(self._legend)
        layout.addWidget(self._hotkeys)
        layout.addWidget(self._line4)

        self._state = HudState()
        self._present_event_kinds: set[str] = set()
        self._controls_hint = "Hotkeys: Space play/pause · R reset · ←/→ jump events · ,/. step frames · H hide HUD · L legend help"

        self._hud_state = HudDisplayState.EXPANDED
        self._hud_prev_nonhidden = HudDisplayState.EXPANDED
        self._collapse_deadline_s: float | None = None
        self._collapse_timer = QTimer(self)
        self._collapse_timer.setSingleShot(True)
        self._collapse_timer.timeout.connect(self._on_collapse_timeout)

        self._refresh()
        self._apply_hud_state()

        self.setMinimumWidth(360)

    def sizeHint(self) -> QSize:  # type: ignore[override]
        if self._hud_state is HudDisplayState.COLLAPSED:
            return QSize(380, 92)
        return QSize(420, 170)

    def hud_state(self) -> HudDisplayState:
        return self._hud_state

    def note_interaction(self) -> None:
        if self._hud_state is not HudDisplayState.EXPANDED:
            return
        self._set_hud_state(HudDisplayState.COLLAPSING)
        delay_s = max(0.0, float(self._style.hud_collapse_delay_ms) / 1000.0)
        now = clock.monotonic()
        self._collapse_deadline_s = now + delay_s
        self._arm_collapse_timer(delay_s)

    def toggle_hidden(self) -> None:
        self.set_hidden(self._hud_state is not HudDisplayState.HIDDEN)

    def set_hidden(self, hidden: bool) -> None:
        hidden = bool(hidden)
        if hidden:
            if self._hud_state is HudDisplayState.HIDDEN:
                return
            self._hud_prev_nonhidden = self._hud_state
            self._stop_collapse_timer()
            self._set_hud_state(HudDisplayState.HIDDEN)
            self.hide()
            return

        if self._hud_state is not HudDisplayState.HIDDEN:
            return

        restored = self._hud_prev_nonhidden
        if restored is HudDisplayState.COLLAPSING and self._collapse_deadline_s is not None:
            now = clock.monotonic()
            remaining = float(self._collapse_deadline_s) - float(now)
            if remaining <= 0.0:
                restored = HudDisplayState.COLLAPSED
            else:
                self._arm_collapse_timer(remaining)
        self._set_hud_state(restored)
        self.show()
        self.adjustSize()
        self.update()

    def _arm_collapse_timer(self, delay_s: float) -> None:
        if delay_s <= 1e-6:
            self._on_collapse_timeout()
            return
        try:
            self._collapse_timer.start(int(math.ceil(delay_s * 1000.0)))
        except Exception:
            pass

    def _stop_collapse_timer(self) -> None:
        try:
            self._collapse_timer.stop()
        except Exception:
            pass

    def _on_collapse_timeout(self) -> None:
        if self._hud_state is HudDisplayState.COLLAPSING:
            self._set_hud_state(HudDisplayState.COLLAPSED)

    def _set_hud_state(self, state: HudDisplayState) -> None:
        self._hud_state = state
        if state is not HudDisplayState.HIDDEN:
            self._hud_prev_nonhidden = state
        self._apply_hud_state()

    def set_spec_meta(self, spec: Any) -> None:
        label = "Helix"
        guide = "-"
        run_kind = str(getattr(spec, "edit_type", "CRISPR")).upper()
        seq_len = 0
        try:
            seq = getattr(spec, "sequence", "") or ""
            seq_len = int(len(seq))
        except Exception:
            seq_len = 0

        meta = getattr(spec, "metadata", None) or {}
        if isinstance(meta, Mapping):
            label = str(meta.get("label") or meta.get("name") or label)
            guide = str(meta.get("guide") or meta.get("guide_name") or meta.get("guide_id") or guide)

        present: set[str] = set()
        try:
            for ev in getattr(spec, "events", []) or []:
                typ = getattr(ev, "type", None)
                if typ is None:
                    continue
                if typ in (EditEventType.RECOGNITION,):
                    present.add("recognition")
                elif typ in (EditEventType.CUT, EditEventType.NICK_PRIMARY, EditEventType.NICK_SECONDARY):
                    present.add("cut")
                elif typ in (EditEventType.PRIME_INIT, EditEventType.RT_SYNTHESIS):
                    present.add("prime")
                elif typ in (EditEventType.FLAP_RESOLUTION, EditEventType.REPAIR_COMPLETE):
                    present.add("repair")
        except Exception:
            present = set()
        self._present_event_kinds = present

        self._state.label = label
        self._state.run_kind = run_kind
        self._state.guide = guide
        self._state.seq_len = seq_len
        self._refresh()

        # Abstraction badge in HUD mirrors side panel badge.
        try:
            layer_label, layer_detail = infer_model_layer(getattr(spec, "metadata", None))
            self._line4.setText(f"Layer: {layer_label}")
            if layer_detail:
                self._line4.setText(self._line4.text() + f" · {layer_detail}")
        except Exception:
            pass

    def set_view_mode(self, mode: str) -> None:
        m = (mode or "").strip().lower()
        if m in ("flat", "flat rails", "linear", "2d"):
            self._state.view_mode = "Flat rails"
        elif m in ("helix", "3d helix", "3d"):
            self._state.view_mode = "3D helix"
        else:
            self._state.view_mode = mode
        self._refresh()

    def set_phase(self, phase: str) -> None:
        self._state.phase = (phase or "approach").strip()
        self._refresh()

    def set_time(self, time_s: float, loop_duration: float | None) -> None:
        self._state.time_s = float(time_s)
        if loop_duration and loop_duration > 1e-6:
            self._state.time_norm = max(0.0, min(1.0, float(time_s) / float(loop_duration)))
        else:
            self._state.time_norm = 0.0
        self._refresh()

    def set_selected_event(self, ev: Any | None) -> None:
        if ev is None:
            self._state.selected = ""
            self._refresh()
            return

        typ = getattr(ev, "type", None)
        type_name = getattr(typ, "name", None) or (str(typ) if typ is not None else "EVENT")
        idx = getattr(ev, "index", None)
        if idx is None:
            idx = getattr(ev, "start", None)
        t = getattr(ev, "t", None)

        parts = [type_name]
        if idx is not None:
            parts.append(f"@ {int(idx)}")
        if t is not None:
            parts.append(f"(t={float(t):.2f})")

        self._state.selected = "Selected: " + " ".join(parts)
        self._refresh()

    def _refresh(self) -> None:
        s = self._state
        phase_key = (s.phase or "approach").strip().lower()
        blurb = _PHASE_BLURBS.get(phase_key, "Animation phase in progress.")

        self._line1.setText(f"{s.run_kind} · Guide {s.guide} · {s.seq_len} bp · View: {s.view_mode}")
        self._line2.setText(f"Time: {s.time_s:.2f}s ({int(round(s.time_norm * 100.0))}%) · Phase: {s.phase}")
        self._line3.setText(f"{s.phase.upper()}: {blurb}")
        self._selected.setText(s.selected)
        self._selected.setVisible(bool(s.selected))

        def _legend_item(kind: str, glyph: str, label: str, rgb: tuple[int, int, int]) -> str:
            alpha = 230 if kind in self._present_event_kinds else 90
            r, g, b = rgb
            rgba = _css_rgba(r, g, b, alpha)
            return f'<span style="color: {rgba};">{glyph} {label}</span>'

        legend_html = " · ".join(
            [
                _legend_item("recognition", "●", "Recognition", (120, 220, 180)),
                _legend_item("cut", "■", "Cut/Nick", (255, 176, 96)),
                _legend_item("prime", "▲", "Prime/RT", (235, 85, 210)),
                _legend_item("repair", "◆", "Repair", (60, 220, 255)),
            ]
        )
        self._legend.setText(legend_html)
        self._hotkeys.setText(self._controls_hint)

        if s.view_mode.lower().startswith("flat"):
            self._line4.setText(
                "Rails: top=template · bottom=opposite · Orange=Cut/Nick · Cyan=Repair"
            )
        else:
            self._line4.setText("Helix view: rails wrapped in 3D · Highlight band = selected window")

    def _apply_hud_state(self) -> None:
        collapsed = self._hud_state is HudDisplayState.COLLAPSED
        hidden = self._hud_state is HudDisplayState.HIDDEN

        for w in (self._line3, self._line4, self._legend):
            w.setVisible(not collapsed and not hidden)

        self._hotkeys.setVisible(not hidden)
        self._line1.setVisible(not hidden)
        self._line2.setVisible(not hidden)
        self._selected.setVisible(bool(self._state.selected) and not hidden and not collapsed)

        try:
            if hidden:
                self.setWindowOpacity(0.0)
            elif collapsed:
                self.setWindowOpacity(float(self._style.hud_collapsed_opacity))
            else:
                self.setWindowOpacity(1.0)
        except Exception:
            pass


class FloatingHud(HudOverlay):
    """Top-level tool window HUD (legacy workaround for native child window stacking)."""

    def __init__(self, parent: QWidget | None = None) -> None:
        # Use no parent so the WM treats it as an independent top-level.
        super().__init__(parent=None)
        self.setWindowFlags(
            Qt.FramelessWindowHint
            | Qt.WindowStaysOnTopHint
            | Qt.Tool
            | Qt.NoDropShadowWindowHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_AlwaysStackOnTop, True)
        self.setFocusPolicy(Qt.NoFocus)
        # Ensure the top-level window has a reasonable initial size
        self.resize(self.sizeHint())


class HudTabPanel(QWidget):
    """Bottom tab that mirrors the realtime viz HUD without overlaying the viewport."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 8)
        layout.setSpacing(6)

        self._title = QLabel("HELIX · Realtime Viz", self)
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(10)
        self._title.setFont(title_font)

        self._body = QPlainTextEdit(self)
        self._body.setReadOnly(True)
        self._body.setLineWrapMode(QPlainTextEdit.NoWrap)
        mono = QFont("Consolas")
        mono.setPointSize(9)
        self._body.setFont(mono)

        layout.addWidget(self._title)
        layout.addWidget(self._body, stretch=1)

        self._last_payload: str = ""
        self._last_title: str = "HELIX · Realtime Viz"

    def set_content(self, title: str, lines: Sequence[str]) -> None:
        new_title = title or "HELIX · Realtime Viz"
        payload = "\n".join(lines or [])
        if payload == self._last_payload and new_title == self._last_title:
            return
        self._title.setText(new_title)
        self._body.setPlainText(payload)
        self._last_payload = payload
        self._last_title = new_title


class LegendToastOverlay(QFrame):
    """One-shot legend help toast (mouse transparent, auto-fades)."""

    def __init__(self, parent: QWidget | None = None, *, style: ModernVizStyle | None = None) -> None:
        super().__init__(parent=None)
        self._style = style or MODERN_STYLE
        self.setObjectName("HelixLegendToastOverlay")
        self.setWindowFlags(
            Qt.FramelessWindowHint
            | Qt.WindowStaysOnTopHint
            | Qt.Tool
            | Qt.NoDropShadowWindowHint
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_AlwaysStackOnTop, True)
        self.setFocusPolicy(Qt.NoFocus)

        toast_bg = _css_rgba(10, 14, 24, 190)
        toast_border = _css_rgba(120, 160, 255, 55)
        toast_text = _css_rgba(245, 248, 255, 235)
        self.setStyleSheet(
            """
            QFrame#HelixLegendToastOverlay {
                background: %s;
                border: 1px solid %s;
                border-radius: 12px;
            }
            QLabel {
                color: %s;
            }
            """
            % (toast_bg, toast_border, toast_text)
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(6)

        title = QLabel("Glyph legend (L)", self)
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(9)
        title.setFont(title_font)

        self._body = QLabel("", self)
        self._body.setWordWrap(True)
        mono = QFont("Consolas")
        mono.setPointSize(9)
        self._body.setFont(mono)

        self._body.setText(
            "● Recognition   ■ Cut/Nick   ▲ Prime/RT   ◆ Repair\n"
            "Tip: this toast is time-limited; press L again after it fades."
        )

        layout.addWidget(title)
        layout.addWidget(self._body)

        self._toast_state = LegendToastState.INACTIVE
        self._toast_deadline_s: float | None = None
        self._toast_timer = QTimer(self)
        self._toast_timer.setInterval(50)
        self._toast_timer.timeout.connect(self._on_toast_tick)
        self.hide()

    def toast_state(self) -> LegendToastState:
        return self._toast_state

    def arm(self) -> None:
        if self._toast_state is LegendToastState.ACTIVE:
            # Deterministic choice: do not retrigger or extend a live toast.
            return
        total = float(self._style.legend_toast_total_s)
        if total <= 1e-6:
            return
        self._toast_state = LegendToastState.ACTIVE
        now = clock.monotonic()
        self._toast_deadline_s = now + total
        try:
            self.setWindowOpacity(1.0)
        except Exception:
            pass
        self.show()
        self.raise_()
        try:
            self._toast_timer.start()
        except Exception:
            pass

    def force_show_for_test(self) -> None:
        """Force-show the toast without timers (used by golden tests)."""
        self._toast_state = LegendToastState.ACTIVE
        self._toast_deadline_s = None
        try:
            self.setWindowOpacity(1.0)
        except Exception:
            pass
        self.show()

    def _on_toast_tick(self) -> None:
        if self._toast_state is not LegendToastState.ACTIVE:
            try:
                self._toast_timer.stop()
            except Exception:
                pass
            self.hide()
            return

        deadline = self._toast_deadline_s
        if deadline is None:
            return

        now = clock.monotonic()
        remaining = float(deadline) - float(now)
        if remaining <= 0.0:
            self._toast_state = LegendToastState.INACTIVE
            try:
                self._toast_timer.stop()
            except Exception:
                pass
            self.hide()
            return

        total = max(1e-6, float(self._style.legend_toast_total_s))
        fade_s = max(1e-6, total * max(0.0, min(1.0, float(self._style.legend_toast_fade_fraction))))
        opacity = 1.0
        if remaining <= fade_s:
            opacity = max(0.0, min(1.0, remaining / fade_s))
        try:
            self.setWindowOpacity(opacity)
        except Exception:
            pass


class HudAnchor(QFrame):
    """Keeps a floating overlay anchored to a target widget."""

    def __init__(
        self,
        container: QWidget,
        overlay: QWidget,
        *,
        corner: str = "top-left",
        margin: QPoint | None = None,
        should_show: Callable[[], bool] | None = None,
    ) -> None:
        super().__init__(container)
        self.container = container
        self.overlay = overlay
        self.corner = corner
        self.margin = margin or QPoint(16, 16)
        self.should_show = should_show
        self._window_filter_installed = False
        container.installEventFilter(self)
        if container.window():
            container.window().installEventFilter(self)
            self._window_filter_installed = True
        QTimer.singleShot(0, self._reposition)

    def eventFilter(self, obj, event):  # type: ignore[override]
        t = event.type()
        if not self._window_filter_installed and self.container.window():
            self.container.window().installEventFilter(self)
            self._window_filter_installed = True
        if t in (QEvent.Move, QEvent.Resize, QEvent.Show, QEvent.Hide, QEvent.WindowStateChange):
            self._reposition()
        return False

    def _reposition(self) -> None:
        w = self.container.window()
        if w is None:
            QTimer.singleShot(16, self._reposition)
            return

        # Retry until both the container and window are visible and not minimized
        if (not self.container.isVisible()) or (not w.isVisible()) or w.isMinimized():
            self.overlay.hide()
            QTimer.singleShot(16, self._reposition)
            return

        try:
            if self.should_show is not None and not bool(self.should_show()):
                self.overlay.hide()
                return
        except Exception:
            pass

        # Refresh size before placing
        self.overlay.adjustSize()
        if self.overlay.width() < 50 or self.overlay.height() < 20:
            self.overlay.resize(self.overlay.sizeHint())

        try:
            if self.should_show is None and hasattr(self.overlay, "hud_state") and self.overlay.hud_state() == HudDisplayState.HIDDEN:
                self.overlay.hide()
                return
        except Exception:
            pass

        top_left = self.container.mapToGlobal(QPoint(0, 0))
        if self.corner == "bottom-left":
            x = int(top_left.x() + self.margin.x())
            y = int(top_left.y() + self.container.height() - self.overlay.height() - self.margin.y())
            self.overlay.move(QPoint(x, y))
        else:
            self.overlay.move(top_left + self.margin)
        self.overlay.show()
        self.overlay.raise_()
        self.overlay.update()


class BenchmarkWorker(QThread):
    completed = Signal(dict)
    failed = Signal(str)

    def __init__(self, config_args: Mapping[str, object], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._config_args = dict(config_args)

    def run(self) -> None:
        try:
            from ...engine_benchmark import BenchmarkConfig, run_benchmark

            payload = run_benchmark(BenchmarkConfig(**self._config_args))
        except Exception as exc:  # pragma: no cover - UI helper
            self.failed.emit(str(exc))
            return
        self.completed.emit(payload)


class HelixModernWidget(QOpenGLWidget):
    """QOpenGLWidget that pushes geometry buffers into ModernGL programs."""

    timeUpdated = Signal(float)
    phaseChanged = Signal(str)
    playingChanged = Signal(bool)
    frameDrawn = Signal()
    eventPicked = Signal(object)
    userInteracted = Signal()
    hudToggleRequested = Signal()
    legendToastRequested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        if not _HAS_QT:
            raise RuntimeError("Qt GUI stack not available; HelixModernWidget cannot be constructed.")
        if not _HAS_MODERNGL:
            raise RuntimeError(
                "ModernGL viewports are unavailable (missing 'moderngl'). Install with `pip install -e '.[gui,realtime]'` "
                "(or add `moderngl` + `glfw` to your environment) and restart; without this, realtime GL rendering, "
                "workflow lanes, and GPU-backed picking are disabled."
            )
        super().__init__(parent=parent)
        fmt = QSurfaceFormat()
        fmt.setRenderableType(QSurfaceFormat.OpenGL)
        fmt.setVersion(3, 3)
        fmt.setProfile(QSurfaceFormat.CoreProfile)
        fmt.setDepthBufferSize(24)
        fmt.setStencilBufferSize(8)
        fmt.setSwapBehavior(QSurfaceFormat.DoubleBuffer)
        fmt.setSamples(4)
        fmt.setSwapInterval(1)
        self.setFormat(fmt)

        # HiDPI / mixed-monitor bookkeeping (devicePixelRatio can change when
        # dragging the window between screens without a logical resize).
        self._last_dpr = 1.0
        self._last_fb_size_px: tuple[int, int] | None = None
        self._last_dpr = self._device_pixel_ratio()

        # Core state
        self.engine: HelixVizEngine | None = None
        self.ctx: moderngl.Context | None = None
        self._pick_id_buffer_enabled = _env_flag("HELIX_VIEWER_PICK_ID_BUFFER", False)
        self._gl_depth_test_enabled: bool | None = None
        self._gl_blend_enabled: bool | None = None
        self._gl_error: str | None = None
        self._show_ribbons = True
        # Rail + arc programs / buffers
        self._rail_program: moderngl.Program | None = None
        self._arc_program: moderngl.Program | None = None
        self._rail_vbo: moderngl.Buffer | None = None
        self._rail_vertex_count: int = 0
        self._vao: moderngl.VertexArray | None = None
        self._arc_weights_normalized: bool | None = None
        self._arc_weight_min: float | None = None
        self._arc_weight_max: float | None = None
        self._arc_vbo: moderngl.Buffer | None = None
        self._arc_vao: moderngl.VertexArray | None = None
        self._arc_heads_vbo: moderngl.Buffer | None = None
        self._arc_heads_vao: moderngl.VertexArray | None = None
        self._arc_heads_count: int = 0
        self._arc_ranges: list[tuple[int, int]] = []
        self._arc_firsts: np.ndarray = np.zeros((0,), dtype="i4")
        self._arc_counts: np.ndarray = np.zeros((0,), dtype="i4")
        self._arc_cpu: np.ndarray | None = None
        self._arc_events: list[EditEvent] = []
        self._arc_confidence: list[float] = []
        self._selected_kind: float | None = None
        self._world_rail_vertices: np.ndarray | None = None
        self._bp_positions: np.ndarray | None = None
        self._bp_positions_template: np.ndarray | None = None
        self._num_bp: int = 0
        self._helix_reference_bounds: tuple[float, float, float] | None = None
        self._highlight_range: tuple[int, int] | None = None
        self._highlight_param: tuple[float, float] | None = None
        self._highlight_vbo: moderngl.Buffer | None = None
        self._highlight_vao: moderngl.VertexArray | None = None

        # Workflow 2.5D pipelines
        self._bars_prog: moderngl.Program | None = None
        self._bars_unit_vbo: moderngl.Buffer | None = None
        self._bars_inst0_vbo: moderngl.Buffer | None = None
        self._bars_inst1_vbo: moderngl.Buffer | None = None
        self._bars_vao: moderngl.VertexArray | None = None

        self._heat_prog: moderngl.Program | None = None
        self._heat_vbo: moderngl.Buffer | None = None
        self._heat_vao: moderngl.VertexArray | None = None
        self._heat_vertex_count = 0

        self._flat_prog: moderngl.Program | None = None
        self._slice_vbo: moderngl.Buffer | None = None
        self._slice_vao: moderngl.VertexArray | None = None

        self._workflow_buffers: dict[str, np.ndarray] | None = None
        self._workflow_instance_count = 0
        self._workflow_rail_vbo: moderngl.Buffer | None = None
        self._workflow_tick_vbo: moderngl.Buffer | None = None
        self._workflow_sequence: str = ""
        self._workflow_last_mvp: np.ndarray | None = None
        self._workflow_rail_y: float | None = None

        # Simple window rail rendering (when no engine is present)
        self._window_prog: moderngl.Program | None = None
        self._window_vao: moderngl.VertexArray | None = None
        self._window_count: int = 0
        self._window_zoom_bp: float = 0.0
        self._window_pan_bp: float = 0.0
        self._overlay_prog: moderngl.Program | None = None
        self._overlay_vao: moderngl.VertexArray | None = None
        self._overlay_count: int = 0
        self._overlay_rels: np.ndarray | None = None
        self._overlay_labels: list[str] = []
        self._overlay_pick_thresh_bp: float = 10.0
        self._overlay_counts: np.ndarray | None = None
        self._overlay_buffers: list[moderngl.Buffer] = []
        self._search_mode = "window"

        # Mode + animation toggles
        self._mode = "3d"
        self._playing = True
        self._show_template = True
        self._show_flap = True
        self._show_bases = True  # flat-rail base glyphs
        self._rail_mode = RailViewMode.FLAT
        self._animate = True

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(16)
        self._render_active = True
        self._pending_reset = False
        self._need_rebuild = False
        self._inactive_paint_logged = False
        self._ctx_id: int | None = None

        # Optional perf HUD (disabled by default).
        self._perf_hud_enabled = _env_flag("HELIX_VIEWER_PERF_HUD", False)
        self._perf_last_frame_start_s: float | None = None
        self._perf_last_dt_ms: float = 0.0
        self._perf_last_cpu_ms: float = 0.0
        self._perf_frame_dt_ms: deque[float] = deque(maxlen=120)
        self._perf_cpu_ms: deque[float] = deque(maxlen=120)
        self._perf_refresh_hz: float | None = None
        self._perf_refresh_source: str = ""
        self._perf_text_update_interval_s: float = 0.25
        self._perf_last_text_update_s: float = 0.0
        self._perf_cached_lines: tuple[str, str] = ("", "")
        self._perf_stats = ViewerPerfStats(
            fps=0.0,
            frame_ms=0.0,
            cpu_ms=0.0,
            cpu_pct=0.0,
            bound="?",
            samples=0,
        )

        # Optional HiDPI debug HUD (disabled by default).
        self._dpi_debug_hud_enabled = _env_flag("HELIX_VIEWER_DPI_DEBUG_HUD", False)
        self._dpi_debug_last_input_logical: tuple[float, float] | None = None
        self._dpi_debug_last_input_px: tuple[int, int] | None = None
        self._last_viewport_px: tuple[int, int] | None = None

        # Resize allocation guard: debounce only *heavy* buffers. Critical
        # resources used for picking must stay aligned with mapping immediately.
        self._resize_alloc = _ResizeAllocationState(
            debounce_s=max(
                0.0,
                float(_env_int("HELIX_VIEWER_RESIZE_ALLOC_DEBOUNCE_MS", 75)) / 1000.0,
            )
        )
        self._pick_id_buffer: _PickIdBufferResources | None = None
        self._heavy_resources: _HeavyRenderResources | None = None

        # Misc state
        self._has_drawn_frame = False
        self._last_fbo = None
        self._custom_camera: dict[str, Any] | None = None
        self._spec: EditVisualizationSpec | None = None
        self._cut_semantics: CutSemantics | None = None
        self._overlay_time_s = 0.0
        self._resolve_flash_s = 0.0
        self._resolve_freeze_s = 0.0
        # One-shot locus pulse used by "Fit to Locus" / undo preview feedback.
        self._locus_pulse_t0 = 0.0
        self._locus_pulse_duration_s = 0.0
        self._locus_pulse_kind = "fit"
        self._timeline_dt_s = 1.0 / 60.0
        self._playback_speed = 1.0

        # Camera interaction state
        self._cam_target = np.array([0.0, 0.0, 0.0], dtype="f4")
        self._cam_distance = 6.0
        self._cam_yaw = 0.0
        self._cam_pitch = 0.3
        self._cam_sensitivity = 0.005
        self._zoom_sensitivity = 0.2
        self._pan_sensitivity = 0.002
        self._pan_sensitivity_2d = 1.0
        self._last_mouse_pos: QPointF | None = None
        self._drag_mode: str | None = None
        self._cam_ease_target: np.ndarray | None = None
        self._cam_ease_distance: float | None = None
        self._last_interaction_emit_s: float = 0.0

        if hasattr(self, "setMouseTracking"):
            self.setMouseTracking(True)  # type: ignore[attr-defined]
        if hasattr(self, "setFocusPolicy"):
            self.setFocusPolicy(Qt.StrongFocus)  # type: ignore[attr-defined]

        # Genome field scene (PAM seed lane)
        self._genome_scene: GenomeScene | None = None
        self._current_chrom: str | None = None
        self._current_tile_start: int = 0
        self._current_tile_seq: str | None = None
        self._guide_ctx: GuideContext | None = None
        self._prime_ctx: PrimeContext | None = None

        # Base glyph overlay controls
        self._max_base_glyphs: int = 80
        self._max_base_glyphs_sparse: int = 240
        self._base_fade_distance: float = 1.4
        self._base_overlay_last_spacing_px: float | None = None
        self._base_overlay_last_step: int = 1
        self._base_overlay_used_fallback: bool = False
        self._bp_positions_opposite: np.ndarray | None = None
        self._show_debug_overlay: bool = True
        self._hud_text_sink: Callable[[str, Sequence[str]], None] | None = None
        # Default to panel mode so the HUD doesn't cover the viewport; callers can
        # opt back into on-canvas drawing via set_hud_overlay_mode("overlay").
        self._hud_overlay_mode: str = "panel"

    def perf_hud_enabled(self) -> bool:
        return bool(getattr(self, "_perf_hud_enabled", False))

    def dpi_debug_hud_enabled(self) -> bool:
        return bool(getattr(self, "_dpi_debug_hud_enabled", False))

    def set_dpi_debug_hud_enabled(self, enabled: bool) -> None:
        self._dpi_debug_hud_enabled = bool(enabled)
        try:
            self.update()
        except Exception:
            pass

    def set_perf_hud_enabled(self, enabled: bool) -> None:
        enabled = bool(enabled)
        self._perf_hud_enabled = enabled
        try:
            self._perf_last_frame_start_s = None
            self._perf_frame_dt_ms.clear()
            self._perf_cpu_ms.clear()
            self._perf_refresh_hz = None
            self._perf_refresh_source = ""
            self._perf_last_text_update_s = 0.0
            self._perf_cached_lines = ("", "")
            self._perf_stats = ViewerPerfStats(0.0, 0.0, 0.0, 0.0, "?", 0)
        except Exception:
            pass
        try:
            self.update()
        except Exception:
            pass

    def _pick_asserts_enabled(self) -> bool:
        return bool(__debug__ or getattr(self, "_dpi_debug_hud_enabled", False))

    def perf_stats(self) -> ViewerPerfStats:
        return getattr(self, "_perf_stats", ViewerPerfStats(0.0, 0.0, 0.0, 0.0, "?", 0))

    def _record_dpi_debug_input(self, pos: QPointF) -> None:
        if not getattr(self, "_dpi_debug_hud_enabled", False):
            return
        try:
            x = float(pos.x())
        except Exception:
            x = 0.0
        try:
            y = float(pos.y())
        except Exception:
            y = 0.0
        self._dpi_debug_last_input_logical = (float(x), float(y))
        try:
            px, py = self.logical_pos_to_pick_px(pos)
            self._dpi_debug_last_input_px = (int(px), int(py))
        except Exception:
            self._dpi_debug_last_input_px = None

    def _note_resize_alloc_dirty(self, fb_w: int, fb_h: int, *, now_s: float) -> None:
        # Desired size always updates immediately.
        self._resize_alloc.note_desired(fb_w, fb_h, now_s=now_s)
        # Critical pick buffers must track mapping immediately.
        self._ensure_pick_resources(fb_w, fb_h)

    def _ensure_pick_resources(self, fb_w: int, fb_h: int) -> None:
        """Ensure critical picking resources match the desired size.

        Do NOT debounce this: if the ID buffer lags, picking drifts during resize storms.
        """

        size = (int(fb_w), int(fb_h))
        if size == getattr(self._resize_alloc, "active_pick_px", None):
            return
        self._reallocate_pick_resources(int(size[0]), int(size[1]))
        self._resize_alloc.active_pick_px = size
        self._assert_pick_sacredness(stage="after_pick_sync")

    def _assert_pick_sacredness(self, *, stage: str) -> None:
        """Crash loudly when critical pick invariants are violated."""

        if not self._pick_asserts_enabled():
            return

        desired = getattr(self._resize_alloc, "desired_fb_px", None)
        active = getattr(self._resize_alloc, "active_pick_px", None)
        if desired is not None and active is not None and tuple(desired) != tuple(active):
            raise AssertionError(
                f"[pick sacredness:{stage}] desired_fb_px {tuple(desired)} != active_pick_px {tuple(active)}. "
                "Picking must be defined in the active pick buffer basis; ensure _ensure_pick_resources stays "
                "immediate (see _alloc_pick_id_buffer_resources)."
            )

        pick = getattr(self, "_pick_id_buffer", None)
        if pick is None:
            return

        if getattr(pick, "color_tex", None) is None:
            raise AssertionError(f"[pick sacredness:{stage}] pick color_tex missing (see _alloc_pick_id_buffer_resources).")
        if getattr(pick, "depth", None) is None:
            raise AssertionError(f"[pick sacredness:{stage}] pick depth missing (see _alloc_pick_id_buffer_resources).")
        if getattr(pick, "fbo", None) is None:
            raise AssertionError(f"[pick sacredness:{stage}] pick fbo missing (see _alloc_pick_id_buffer_resources).")

        if active is not None and tuple(getattr(pick, "size_px", ())) != tuple(active):
            raise AssertionError(
                f"[pick sacredness:{stage}] pick buffer size {getattr(pick, 'size_px', None)} != active_pick_px {tuple(active)}. "
                "Reallocate pick ID resources immediately on resize/DPR change (see _alloc_pick_id_buffer_resources)."
            )

        def _require_size(obj: object, name: str) -> None:
            size = getattr(obj, "size", None)
            if size is None:
                return
            try:
                size_t = (int(size[0]), int(size[1]))  # type: ignore[index]
            except Exception:
                return
            if active is not None and size_t != tuple(active):
                raise AssertionError(
                    f"[pick sacredness:{stage}] {name}.size {size_t} != active_pick_px {tuple(active)} "
                    f"(see _alloc_pick_id_buffer_resources)."
                )

        _require_size(getattr(pick, "color_tex", object()), "pick_color_tex")
        _require_size(getattr(pick, "depth", object()), "pick_depth")
        _require_size(getattr(pick, "fbo", object()), "pick_fbo")

        color = getattr(pick, "color_tex", None)
        if color is not None:
            dtype = getattr(color, "dtype", None)
            if dtype is not None and str(dtype) != "u4":
                raise AssertionError(
                    f"[pick sacredness:{stage}] pick color dtype {dtype!r} is not 'u4' (R32UI). "
                    "IDs must be written as integer texels (see _alloc_pick_id_buffer_resources)."
                )
            components = getattr(color, "components", None)
            if components is not None and int(components) != 1:
                raise AssertionError(
                    f"[pick sacredness:{stage}] pick color components {components!r} != 1 "
                    "(see _alloc_pick_id_buffer_resources)."
                )
            samples = getattr(color, "samples", None)
            if samples is not None:
                try:
                    samples_i = int(samples)
                except Exception:
                    samples_i = None
                if samples_i is not None and samples_i not in (0, 1):
                    raise AssertionError(
                        f"[pick sacredness:{stage}] pick color samples {samples_i} != 1 (single-sample). "
                        "Never route pick through MSAA (see _alloc_pick_id_buffer_resources)."
                    )

        depth = getattr(pick, "depth", None)
        if depth is not None:
            samples = getattr(depth, "samples", None)
            if samples is not None:
                try:
                    samples_i = int(samples)
                except Exception:
                    samples_i = None
                if samples_i is not None and samples_i not in (0, 1):
                    raise AssertionError(
                        f"[pick sacredness:{stage}] pick depth samples {samples_i} != 1 (single-sample). "
                        "Never route pick through MSAA (see _alloc_pick_id_buffer_resources)."
                    )

        fbo = getattr(pick, "fbo", None)
        if fbo is not None:
            complete = getattr(fbo, "is_complete", None)
            if callable(complete):
                try:
                    is_ok = bool(complete())
                except Exception:
                    is_ok = True
            elif complete is not None:
                is_ok = bool(complete)
            else:
                is_ok = True
            if not is_ok:
                raise AssertionError(
                    f"[pick sacredness:{stage}] pick FBO is not complete (see _alloc_pick_id_buffer_resources)."
                )

    def _reallocate_pick_resources(self, fb_w: int, fb_h: int) -> None:
        if not getattr(self, "_pick_id_buffer_enabled", False):
            prev = getattr(self, "_pick_id_buffer", None)
            if prev is not None:
                _try_release_mgl(getattr(prev, "fbo", None))
                _try_release_mgl(getattr(prev, "color_tex", None))
                _try_release_mgl(getattr(prev, "depth", None))
            self._pick_id_buffer = None
            return

        ctx = getattr(self, "ctx", None)
        if ctx is None:
            return
        self._pick_id_buffer = _alloc_pick_id_buffer_resources(
            ctx=ctx,
            size_px=(int(fb_w), int(fb_h)),
            prev=getattr(self, "_pick_id_buffer", None),
        )
        self._assert_pick_sacredness(stage="after_pick_alloc")

    def _reallocate_heavy_resources(self, fb_w: int, fb_h: int) -> None:
        ctx = getattr(self, "ctx", None)
        if ctx is None:
            return
        self._heavy_resources = _alloc_heavy_render_resources(
            ctx=ctx,
            size_px=(int(fb_w), int(fb_h)),
            prev=getattr(self, "_heavy_resources", None),
        )

    def _maybe_commit_resize_allocations(self, *, now_s: float) -> None:
        commit = self._resize_alloc.pop_heavy_commit(now_s=now_s)
        if commit is not None:
            self._reallocate_heavy_resources(int(commit[0]), int(commit[1]))

    def _detect_refresh_hz(self) -> float | None:
        try:
            scr = self.screen()
            hz = float(scr.refreshRate()) if scr is not None else 0.0
        except Exception:
            hz = 0.0
        # Some platforms report 0 or garbage values (or omit the display rate).
        if hz <= 1e-3 or hz < 30.0 or hz > 360.0:
            return None
        return _snap_common_refresh_hz(float(hz))

    def _infer_refresh_hz_from_frame_times(self, dt_ms_values: list[float]) -> float | None:
        if len(dt_ms_values) < 24:
            return None
        # Histogram the frame times to find a dominant cadence, then back out a
        # plausible base refresh interval via small integer factors.
        bin_w = 0.5  # ms
        counts: dict[float, int] = {}
        filtered: list[float] = []
        for dt in dt_ms_values:
            if dt <= 1.0 or dt > 1000.0:
                continue
            filtered.append(float(dt))
            key = round(dt / bin_w) * bin_w
            counts[key] = counts.get(key, 0) + 1
        if len(filtered) < 24 or not counts:
            return None
        top_bins = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)[:8]

        best_key: tuple[float, float, int] | None = None
        best_hz: float | None = None
        # Score candidates by how much of the history they explain via small
        # integer multiples (k=1..4). This prevents mis-inference like choosing
        # 30Hz when both 16.7ms and 33.3ms peaks are present (prefer 60Hz and
        # treat the latter as VSync×2).
        for bin_ms, _count in top_bins:
            for factor in (1, 2, 3, 4):
                base_ms_raw = float(bin_ms) / float(factor)
                if base_ms_raw <= 1e-6:
                    continue
                hz = 1000.0 / base_ms_raw
                if hz < 30.0 or hz > 360.0:
                    continue
                hz = _snap_common_refresh_hz(float(hz))
                base_ms = 1000.0 / float(hz)

                matches = 0
                for dt in filtered:
                    ok = False
                    for k in (1, 2, 3, 4):
                        target = base_ms * float(k)
                        tol = max(0.7, 0.04 * target)
                        if abs(dt - target) <= tol:
                            ok = True
                            break
                    if ok:
                        matches += 1
                coverage = float(matches) / float(len(filtered))
                rel_err, rank = _typical_refresh_rank(float(hz))
                # Prefer higher coverage, then "more typical" (closeness + rank
                # ordering), avoiding the pathological bias toward the largest
                # possible refresh when only a single cadence is observed.
                key = (float(coverage), -float(rel_err), -int(rank))
                if best_key is None or key > best_key:
                    best_key = key
                    best_hz = float(hz)

        if best_key is None or best_hz is None:
            return None
        coverage = float(best_key[0])
        if coverage < 0.35:
            return None
        return float(best_hz)

    def _update_perf_text(self, *, now_s: float, stats: ViewerPerfStats) -> None:
        interval = float(getattr(self, "_perf_text_update_interval_s", 0.25))
        last = float(getattr(self, "_perf_last_text_update_s", 0.0))
        cached = getattr(self, "_perf_cached_lines", ("", ""))
        if cached[0] and (now_s - last) < interval:
            return
        self._perf_last_text_update_s = float(now_s)
        samples = int(getattr(stats, "samples", 0))
        window = int(getattr(stats, "window_frames", 0) or samples)
        avg_tag = f"avg{samples}/{window}f" if window else f"avg{samples}f"
        wait_ms = float(getattr(stats, "wait_ms", max(0.0, float(stats.frame_ms) - float(stats.cpu_ms))))
        self._perf_cached_lines = (
            f"FPS {stats.fps:5.1f} ({avg_tag}) · Frame {stats.frame_ms:5.1f} ms",
            f"CPUsub {stats.cpu_ms:5.1f} ms ({stats.cpu_pct:3.0f}%) · Wait {wait_ms:5.1f} ms · {stats.bound}",
        )

    def _update_perf_stats(self, frame_start_s: float, frame_end_s: float) -> None:
        prev = getattr(self, "_perf_last_frame_start_s", None)
        dt_ms = (frame_start_s - prev) * 1000.0 if prev is not None else 0.0
        self._perf_last_frame_start_s = frame_start_s
        cpu_ms = max(0.0, (frame_end_s - frame_start_s) * 1000.0)
        self._perf_last_dt_ms = float(dt_ms)
        self._perf_last_cpu_ms = float(cpu_ms)

        if dt_ms <= 1e-6 or dt_ms > 2000.0:
            return

        self._perf_frame_dt_ms.append(float(dt_ms))
        self._perf_cpu_ms.append(float(cpu_ms))
        if not self._perf_frame_dt_ms:
            return

        dt_avg = float(sum(self._perf_frame_dt_ms) / len(self._perf_frame_dt_ms))
        cpu_avg = float(sum(self._perf_cpu_ms) / len(self._perf_cpu_ms))
        fps = 1000.0 / dt_avg if dt_avg > 1e-6 else 0.0
        cpu_pct = (cpu_avg / dt_avg) * 100.0 if dt_avg > 1e-6 else 0.0

        wait_raw = float(dt_avg) - float(cpu_avg)
        wait_avg = max(0.0, float(wait_raw))

        dt_values = list(self._perf_frame_dt_ms)
        dt_median = float(statistics.median(dt_values)) if dt_values else float(dt_avg)
        abs_dev = [abs(x - dt_median) for x in dt_values]
        mad = float(statistics.median(abs_dev)) if abs_dev else 0.0
        pacing_ms = 1.4826 * mad  # MAD->sigma approximation (robust to single hitches).

        def _period_ms(hz_value: float) -> float:
            return 1000.0 / float(hz_value)

        def _period_equiv(hz_a: float, hz_b: float) -> bool:
            if hz_a <= 1e-6 or hz_b <= 1e-6:
                return False
            return abs(_period_ms(hz_a) - _period_ms(hz_b)) <= 0.25

        def _coverage(candidate_hz: float) -> float:
            period = _period_ms(float(candidate_hz))
            matched = 0
            for dt in dt_values:
                ok = False
                for k in (1, 2, 3, 4):
                    target = period * float(k)
                    tol = max(0.7, 0.04 * float(target))
                    if abs(float(dt) - float(target)) <= tol:
                        ok = True
                        break
                if ok:
                    matched += 1
            return float(matched) / float(len(dt_values)) if dt_values else 0.0

        hz = getattr(self, "_perf_refresh_hz", None)
        hz_src = str(getattr(self, "_perf_refresh_source", "") or "")

        if isinstance(hz, (int, float)) and float(hz) > 1e-3 and len(dt_values) >= 48:
            # If the cached refresh no longer explains the history window,
            # invalidate and re-detect. This prevents "early lock-in" when
            # initial samples are ambiguous (e.g. only VSync×2 frames seen).
            try:
                if _coverage(float(hz)) < 0.70:
                    hz = None
                    hz_src = ""
                    self._perf_refresh_hz = None
                    self._perf_refresh_source = ""
            except Exception:
                pass

        if len(dt_values) >= 24 and (hz is None or hz_src == "screen"):
            hz_screen = self._detect_refresh_hz()
            hz_infer = self._infer_refresh_hz_from_frame_times(dt_values)

            candidates: list[tuple[str, float, float, float, int]] = []
            if hz_screen is not None:
                hz_s = _snap_common_refresh_hz(float(hz_screen))
                cov = _coverage(hz_s)
                if cov >= 0.35:
                    rel, rank = _typical_refresh_rank(float(hz_s))
                    candidates.append(("screen", float(hz_s), float(cov), float(rel), int(rank)))
            if hz_infer is not None:
                hz_i = _snap_common_refresh_hz(float(hz_infer))
                cov = _coverage(hz_i)
                if cov >= 0.35:
                    rel, rank = _typical_refresh_rank(float(hz_i))
                    candidates.append(("inferred", float(hz_i), float(cov), float(rel), int(rank)))

            if candidates:
                screen = next((c for c in candidates if c[0] == "screen"), None)
                inferred = next((c for c in candidates if c[0] == "inferred"), None)

                if screen is not None and inferred is not None and _period_equiv(float(screen[1]), float(inferred[1])):
                    chosen = screen
                else:
                    best_cov = max(c[2] for c in candidates)
                    top = [c for c in candidates if (best_cov - c[2]) <= 0.05]
                    # Prefer screen when both are similarly plausible; otherwise
                    # pick the most typical cadence among the top coverage set.
                    chosen = next((c for c in top if c[0] == "screen"), None)
                    if chosen is None:
                        chosen = min(top, key=lambda c: (c[4], c[3], -c[2]))

                src, chosen_hz, chosen_cov, _rel, _rank = chosen

                should_update = hz is None
                if not should_update and hz_src == "screen" and src == "inferred":
                    # Upgrade only when inferred materially improves coverage over screen.
                    if screen is None:
                        should_update = True
                    else:
                        screen_cov = float(screen[2])
                        should_update = (float(chosen_cov) - screen_cov) >= 0.10

                if should_update:
                    hz = float(chosen_hz)
                    hz_src = str(src)
                    self._perf_refresh_hz = hz
                    self._perf_refresh_source = hz_src

        vsync_mult: int | None = None
        if isinstance(hz, (int, float)) and float(hz) > 1e-3:
            period = 1000.0 / float(hz)
            for k in (1, 2, 3, 4):
                target = period * float(k)
                tol = max(0.7, 0.04 * target)
                if abs(dt_median - target) <= tol:
                    pace_tol = max(0.6, 0.06 * target)
                    if pacing_ms <= pace_tol:
                        vsync_mult = int(k)
                        break

        if vsync_mult is not None:
            bound = "VSync" if vsync_mult == 1 else f"VSync×{vsync_mult}"
        else:
            limiter = "CPU-submit" if cpu_pct >= 70.0 else "Wait"
            bound = f"Uncapped/{limiter}"

        stats = ViewerPerfStats(
            fps=float(fps),
            frame_ms=float(dt_avg),
            cpu_ms=float(cpu_avg),
            cpu_pct=float(cpu_pct),
            bound=str(bound),
            samples=int(len(self._perf_frame_dt_ms)),
            wait_ms=float(wait_avg),
            wait_raw_ms=float(wait_raw),
            refresh_hz_used=float(hz) if isinstance(hz, (int, float)) else None,
            refresh_hz_source=str(hz_src),
            pacing_ms=float(pacing_ms),
            window_frames=int(getattr(self._perf_frame_dt_ms, "maxlen", 0) or len(self._perf_frame_dt_ms)),
        )
        self._perf_stats = stats
        self._update_perf_text(now_s=float(frame_end_s), stats=stats)

    def _paint_perf_hud(self) -> None:
        if not getattr(self, "_perf_hud_enabled", False):
            return
        w = max(1, int(self.width()))
        h = max(1, int(self.height()))
        if w < 320 or h < 180:
            return

        stats = getattr(self, "_perf_stats", None)
        if stats is None or getattr(stats, "samples", 0) < 2:
            dt = float(getattr(self, "_perf_last_dt_ms", 0.0))
            cpu = float(getattr(self, "_perf_last_cpu_ms", 0.0))
            fps = 1000.0 / dt if dt > 1e-6 else 0.0
            cpu_pct = (cpu / dt) * 100.0 if dt > 1e-6 else 0.0
            limiter = "CPU-submit" if cpu_pct >= 70.0 else "Wait"
            bound = f"Uncapped/{limiter}"
            wait_raw = dt - cpu
            wait_ms = max(0.0, float(wait_raw))
            stats = ViewerPerfStats(
                fps=fps,
                frame_ms=dt,
                cpu_ms=cpu,
                cpu_pct=cpu_pct,
                bound=bound,
                samples=1,
                wait_ms=float(wait_ms),
                wait_raw_ms=float(wait_raw),
                refresh_hz_used=None,
                refresh_hz_source="",
                pacing_ms=0.0,
                window_frames=int(getattr(self._perf_frame_dt_ms, "maxlen", 0) or 0),
            )

        p = QPainter(self)
        p.setRenderHint(QPainter.TextAntialiasing, True)

        font = QFont("Consolas", 9)
        p.setFont(font)
        fm = p.fontMetrics()
        line_h = fm.height()
        lines = list(getattr(self, "_perf_cached_lines", ("", "")))
        if not lines[0]:
            # Before we have a stable history window, render a direct snapshot
            # without updating the throttled cached strings.
            samples = int(getattr(stats, "samples", 0))
            window = int(getattr(stats, "window_frames", 0) or samples)
            avg_tag = f"avg{samples}/{window}f" if window else f"avg{samples}f"
            wait_ms = float(getattr(stats, "wait_ms", max(0.0, float(stats.frame_ms) - float(stats.cpu_ms))))
            lines = [
                f"FPS {stats.fps:5.1f} ({avg_tag}) · Frame {stats.frame_ms:5.1f} ms",
                f"CPUsub {stats.cpu_ms:5.1f} ms ({stats.cpu_pct:3.0f}%) · Wait {wait_ms:5.1f} ms · {stats.bound}",
            ]
        pad_x = 10
        pad_y = 8
        text_w = max(fm.horizontalAdvance(ln) for ln in lines)
        rect_w = max(220, text_w + pad_x * 2)
        rect_h = pad_y * 2 + line_h * len(lines)
        x = max(8, w - rect_w - 16)
        y = 16
        rect = QRect(x, y, rect_w, rect_h)

        p.setPen(QColor(120, 160, 255, 60))
        p.setBrush(QColor(10, 14, 24, 175))
        p.drawRoundedRect(rect, 10, 10)

        p.setPen(QColor(245, 248, 255, 235))
        y_text = rect.y() + pad_y + fm.ascent()
        for ln in lines:
            p.drawText(rect.x() + pad_x, y_text, ln)
            y_text += line_h
        if saved:
            try:
                p.restore()
            except Exception:
                pass
        if owns_painter:
            p.end()

    def _paint_dpi_debug_hud(self) -> None:
        if not getattr(self, "_dpi_debug_hud_enabled", False):
            return
        w = max(1, int(self.width()))
        h = max(1, int(self.height()))
        if w < 360 or h < 220:
            return

        dpr = self._device_pixel_ratio()
        fb_w, fb_h = _framebuffer_size_px(logical_w=w, logical_h=h, dpr=dpr)
        vp = getattr(self, "_last_viewport_px", None)
        in_log = getattr(self, "_dpi_debug_last_input_logical", None)
        in_px = getattr(self, "_dpi_debug_last_input_px", None)
        desired = getattr(self._resize_alloc, "desired_fb_px", None) or (int(fb_w), int(fb_h))
        active_pick = getattr(self._resize_alloc, "active_pick_px", None) or desired
        heavy_committed = getattr(self._resize_alloc, "heavy_committed_px", None)
        heavy_pending = getattr(self._resize_alloc, "heavy_pending_px", None)

        lines = [
            f"Logical {w}×{h}",
            f"DPR {dpr:.2f}",
            f"Desired {int(desired[0])}×{int(desired[1])}px",
            f"Pick {int(active_pick[0])}×{int(active_pick[1])}px",
        ]
        if heavy_committed is not None and tuple(heavy_committed) != tuple(desired):
            lines.append(f"Heavy {int(heavy_committed[0])}×{int(heavy_committed[1])}px")
        if heavy_pending is not None and tuple(heavy_pending) != tuple(heavy_committed or (-1, -1)):
            lines.append(f"HeavyPending {int(heavy_pending[0])}×{int(heavy_pending[1])}px")
        if vp is not None:
            lines.append(f"Viewport {int(vp[0])}×{int(vp[1])}px")
        if in_log is not None and in_px is not None:
            lx, ly = in_log
            px, py = in_px
            lines.append(f"Input ({lx:.1f},{ly:.1f}) → ({px},{py})px")

        p = QPainter(self)
        p.setRenderHint(QPainter.TextAntialiasing, True)

        font = QFont("Consolas", 9)
        p.setFont(font)
        fm = p.fontMetrics()
        line_h = fm.height()
        pad_x = 10
        pad_y = 8
        text_w = max(fm.horizontalAdvance(ln) for ln in lines)
        rect_w = max(260, text_w + pad_x * 2)
        rect_h = pad_y * 2 + line_h * len(lines)
        x = 16
        y = 16
        rect = QRect(x, y, rect_w, rect_h)

        p.setPen(QColor(140, 220, 180, 70))
        p.setBrush(QColor(10, 14, 24, 175))
        p.drawRoundedRect(rect, 10, 10)

        p.setPen(QColor(245, 248, 255, 235))
        y_text = rect.y() + pad_y + fm.ascent()
        for ln in lines:
            p.drawText(rect.x() + pad_x, y_text, ln)
            y_text += line_h
        p.end()

    def _workflow_base_positions(self) -> np.ndarray | None:
        seq = self._workflow_sequence
        if not seq:
            return None
        try:
            n = len(seq)
        except Exception:
            return None
        if n <= 0:
            return None
        y = float(self._workflow_rail_y) if self._workflow_rail_y is not None else 0.0
        x = np.arange(n, dtype="f4")
        y_arr = np.full_like(x, y, dtype="f4")
        z = np.zeros_like(x, dtype="f4")
        return np.stack([x, y_arr, z], axis=1).astype("f4")

    # --- Window-driven sequence feed ------------------------------------
    def set_window(self, chrom: str, start: int, sequence_bytes: bytes) -> None:
        """Accept a genome window and refresh rail buffers.

        The renderer treats bases as codes (A=2, C=1, G=3, T=0) and maps them
        to colors in shaders. This method keeps state minimal and avoids any
        FASTA/two-bit knowledge in the viewer.
        """
        try:
            self._current_chrom = chrom
            self._current_tile_start = int(start)
            seq = sequence_bytes.decode("ascii") if isinstance(sequence_bytes, (bytes, bytearray)) else str(sequence_bytes)
            self._current_tile_seq = seq
            self._upload_sequence_to_gpu(seq, self._current_tile_start)
        except Exception:
            # Keep viewer resilient; log could be added if desired.
            return

    def set_overlays(
        self,
        rel_indices: np.ndarray,
        kinds: np.ndarray,
        values: np.ndarray,
        window_len: int,
        labels: list[str] | None = None,
        counts: np.ndarray | None = None,
    ) -> None:
        """Upload overlay ticks (window-relative indices) plus optional labels for hover."""
        if self.ctx is None or rel_indices.size == 0:
            if self._overlay_vao is not None:
                try:
                    self._overlay_vao.release()
                except Exception:
                    pass
            self._overlay_vao = None
            self._overlay_count = 0
            for buf in self._overlay_buffers:
                try:
                    buf.release()
                except Exception:
                    pass
            self._overlay_buffers = []
            self._overlay_rels = None
            self._overlay_labels = []
            self._overlay_counts = None
            return
        if self._overlay_prog is None:
            self._overlay_prog = self.ctx.program(
                vertex_shader=self._overlay_vertex_shader(),
                fragment_shader=self._overlay_fragment_shader(),
            )
        # Cleanup previous buffers/VAO
        if self._overlay_vao is not None:
            try:
                self._overlay_vao.release()
            except Exception:
                pass
        for buf in self._overlay_buffers:
            try:
                buf.release()
            except Exception:
                pass
        self._overlay_buffers = []

        idx_buf = self.ctx.buffer(rel_indices.astype("f4").tobytes())
        kind_buf = self.ctx.buffer(kinds.astype("u1").tobytes())
        val_buf = self.ctx.buffer(values.astype("f4").tobytes())
        self._overlay_buffers = [idx_buf, kind_buf, val_buf]
        self._overlay_vao = self.ctx.vertex_array(
            self._overlay_prog,
            [
                (idx_buf, "1f", "in_idx"),
                (kind_buf, "1u1", "in_kind"),
                (val_buf, "1f", "in_val"),
            ],
        )
        self._overlay_count = rel_indices.size
        self._window_zoom_bp = max(1.0, float(window_len))
        self._window_pan_bp = float(self._current_tile_start + window_len / 2)
        self._overlay_rels = rel_indices.astype("f4")
        self._overlay_labels = labels or [""] * rel_indices.size
        self._overlay_counts = counts.astype("f4") if counts is not None else None
        self.update()

    def set_search_mode(self, mode: str) -> None:
        m = (mode or "window").lower()
        self._search_mode = m
        self.setProperty("wholeMode", m == "whole")
        try:
            self.style().unpolish(self)
            self.style().polish(self)
        except Exception:
            pass
        # fallback inline tint
        if m == "whole":
            self.setStyleSheet(
                f"border: 1px solid {_css_rgb(58, 232, 200)}; background-color: {_css_rgba(58, 232, 200, 0.05)};"
            )
        else:
            self.setStyleSheet("")

    def _encode_bases(self, seq: str) -> np.ndarray:
        # Map bases to small ints; fallback to 0 for unknown
        map_tbl = {"T": 0, "C": 1, "A": 2, "G": 3, "t": 0, "c": 1, "a": 2, "g": 3}
        return np.fromiter((map_tbl.get(ch, 0) for ch in seq), dtype="u1", count=len(seq))

    def _upload_sequence_to_gpu(self, seq: str, start_bp: int) -> None:
        if self.ctx is None:
            return
        codes = self._encode_bases(seq)
        self._bp_positions = None  # reset cached positions
        self._bp_positions_opposite = None
        # Upload or update VBO for rail bases
        if self._rail_vbo is None or self._rail_vbo.size < codes.nbytes:
            self._rail_vbo = self.ctx.buffer(codes.tobytes())
        else:
            self._rail_vbo.write(codes.tobytes())
        self._rail_vertex_count = len(codes)
        self._current_tile_start = start_bp
        self._window_count = len(codes)
        self._window_zoom_bp = float(max(1, len(codes)))
        self._window_pan_bp = float(start_bp + len(codes) // 2)
        if self._window_prog is None:
            self._window_prog = self.ctx.program(
                vertex_shader=self._window_vertex_shader(),
                fragment_shader=self._window_fragment_shader(),
            )
        self._window_vao = self.ctx.vertex_array(
            self._window_prog,
            [(self._rail_vbo, "1u1", "in_code")],
        )
        self.update()

    def mouseMoveEvent(self, event):  # type: ignore[override]
        try:
            if self._overlay_rels is None or self._overlay_rels.size == 0:
                return super().mouseMoveEvent(event)
            w = self.width() or 1
            x_ndc = (2.0 * (event.position().x() / float(w))) - 1.0  # -1..1
            half_span = max(1.0, self._window_zoom_bp * 0.5)
            center = self._window_pan_bp
            idx_est = center + x_ndc * half_span
            rel_est = idx_est - float(self._current_tile_start)
            diffs = np.abs(self._overlay_rels - rel_est)
            min_idx = int(np.argmin(diffs))
            min_dist = diffs[min_idx]
            thresh = max(5.0, self._window_zoom_bp * 0.01)
            if min_dist <= thresh:
                label = self._overlay_labels[min_idx] if self._overlay_labels and min_idx < len(self._overlay_labels) else ""
                if not label and self._overlay_counts is not None and min_idx < self._overlay_counts.size:
                    cnt = int(self._overlay_counts[min_idx])
                    label = f"{cnt} off-targets here"
                if label:
                    from PySide6.QtWidgets import QToolTip

                    QToolTip.showText(event.globalPosition().toPoint(), label, self)
            else:
                from PySide6.QtWidgets import QToolTip

                QToolTip.hideText()
        finally:
            return super().mouseMoveEvent(event)

    # ------------------------------------------------------------------
    # Qt overrides
    # ------------------------------------------------------------------
    def _device_pixel_ratio(self) -> float:
        try:
            dpr = float(self.devicePixelRatioF())
        except Exception:
            dpr = 1.0
        if not (dpr > 1e-6) or not math.isfinite(dpr):
            return 1.0
        return float(dpr)

    def framebuffer_size_px(self) -> tuple[int, int]:
        dpr = self._device_pixel_ratio()
        return _framebuffer_size_px(logical_w=max(1, int(self.width())), logical_h=max(1, int(self.height())), dpr=dpr)

    def pick_buffer_size_px(self) -> tuple[int, int]:
        """Physical pixel size for the picking buffer basis.

        This stays aligned with logical->physical mapping even during resize/DPR storms.
        """

        desired_w, desired_h = self.framebuffer_size_px()
        try:
            self._note_resize_alloc_dirty(int(desired_w), int(desired_h), now_s=clock.perf_counter())
        except Exception:
            pass
        size = getattr(self._resize_alloc, "active_pick_px", None)
        if size is None:
            return int(desired_w), int(desired_h)
        return int(size[0]), int(size[1])

    def logical_pos_to_physical_px(self, pos: QPointF) -> tuple[int, int]:
        """Map a Qt logical mouse position into physical framebuffer pixels."""

        fb_w, fb_h = self.framebuffer_size_px()
        dpr = self._device_pixel_ratio()
        try:
            x = float(pos.x())
        except Exception:
            x = 0.0
        try:
            y = float(pos.y())
        except Exception:
            y = 0.0
        px = _logical_to_physical_pos_px(x, dpr, limit_px=fb_w)
        py = _logical_to_physical_pos_px(y, dpr, limit_px=fb_h)
        return int(px), int(py)

    def logical_pos_to_pick_px(self, pos: QPointF) -> tuple[int, int]:
        """Map a Qt logical mouse position into physical pixels for picking."""

        pick_w, pick_h = self.pick_buffer_size_px()
        self._assert_pick_sacredness(stage="before_pick_mapping")
        dpr = self._device_pixel_ratio()
        try:
            x = float(pos.x())
        except Exception:
            x = 0.0
        try:
            y = float(pos.y())
        except Exception:
            y = 0.0
        px = _logical_to_physical_pos_px(x, dpr, limit_px=pick_w)
        py = _logical_to_physical_pos_px(y, dpr, limit_px=pick_h)
        return int(px), int(py)

    def _read_pick_id_at_pick_px(self, px: int, py: int) -> int:
        """Read a uint32 ID from the pick buffer at a pick-basis (top-left) pixel.

        IMPORTANT: This must remain an *integer* readback end-to-end. Any
        accidental normalized read will silently scramble IDs.
        """

        pick = getattr(self, "_pick_id_buffer", None)
        if pick is None:
            return 0
        self._assert_pick_sacredness(stage="before_pick_read")

        w_px, h_px = (int(pick.size_px[0]), int(pick.size_px[1]))
        if w_px <= 0 or h_px <= 0:
            return 0

        x = max(0, min(w_px - 1, int(px)))
        y_top = max(0, min(h_px - 1, int(py)))
        # Qt/mapping basis uses top-left origin; OpenGL readback uses bottom-left.
        y_gl = (h_px - 1) - y_top

        data = pick.fbo.read(viewport=(int(x), int(y_gl), 1, 1), components=1, dtype="u4")  # type: ignore[attr-defined]
        arr = np.frombuffer(data, dtype=np.uint32)
        if arr.size != 1:
            raise RuntimeError(f"Pick ID readback returned {len(data)} bytes (expected 4)")
        return int(arr[0])

    def _read_pick_id_at_logical_pos(self, pos: QPointF) -> int:
        px, py = self.logical_pos_to_pick_px(pos)
        return self._read_pick_id_at_pick_px(int(px), int(py))

    def _handle_possible_dpr_change(self) -> None:
        dpr = self._device_pixel_ratio()
        prev = float(getattr(self, "_last_dpr", 1.0))
        if abs(dpr - prev) <= 1e-6:
            return
        self._last_dpr = float(dpr)
        try:
            if self.ctx is not None:
                w_px, h_px = self.framebuffer_size_px()
                self._last_fb_size_px = (int(w_px), int(h_px))
                self.ctx.viewport = (0, 0, int(w_px), int(h_px))
                self._last_viewport_px = (int(w_px), int(h_px))
                try:
                    self._note_resize_alloc_dirty(int(w_px), int(h_px), now_s=clock.perf_counter())
                except Exception:
                    pass
        except Exception:
            pass
        try:
            self.update()
        except Exception:
            pass

    def _on_screen_changed(self, _screen) -> None:
        self._handle_possible_dpr_change()

    def event(self, event: QEvent) -> bool:  # type: ignore[override]
        try:
            et = event.type()
            # Qt 6: watch for internal screen/DPI changes that don't trigger resizeGL.
            watch = []
            try:
                watch.append(QEvent.Type.ScreenChangeInternal)
            except Exception:
                pass
            try:
                watch.append(QEvent.Type.DevicePixelRatioChange)
            except Exception:
                pass
            try:
                watch.append(QEvent.Type.DpiChange)
            except Exception:
                pass
            if watch and et in watch:
                self._handle_possible_dpr_change()
        except Exception:
            pass
        return super().event(event)

    def initializeGL(self) -> None:  # pragma: no cover
        print("[HelixModernWidget] initializeGL", flush=True)
        self.makeCurrent()
        self.ctx = moderngl.create_context()
        self._ctx_id = id(self.ctx)
        print("[HelixModernWidget] GL version:", self.ctx.version_code, flush=True)

        self._gl_set_blend(True)
        self._gl_set_depth_test(True)
        # Premult alpha-like blending for cleaner strands (avoid overbright intersections)
        self.ctx.blend_func = (moderngl.SRC_ALPHA, moderngl.ONE_MINUS_SRC_ALPHA)
        if _HAS_GL:
            GL.glEnable(GL.GL_FRAMEBUFFER_SRGB)

        # Field registry / genome scene for PAM lane
        try:
            shader_root = _resolve_shader_root()
            self._genome_scene = GenomeScene(ctx=self.ctx, shader_root=shader_root)
        except Exception:
            self._genome_scene = None

        self._gl_error = None
        errors: list[str] = []
        try:
            self._rail_program = self.ctx.program(
                vertex_shader=self._rail_vertex_shader(),
                fragment_shader=self._rail_fragment_shader(),
            )
        except Exception as exc:
            self._rail_program = None
            errors.append(f"rail_program: {exc}")
        try:
            self._arc_program = self.ctx.program(
                vertex_shader=self._arc_vertex_shader(),
                fragment_shader=self._arc_fragment_shader(),
            )
        except Exception as exc:
            self._arc_program = None
            errors.append(f"arc_program: {exc}")
        try:
            self._bars_prog = self.ctx.program(
                vertex_shader=self._bars_vertex_shader(),
                fragment_shader=self._bars_fragment_shader(),
            )
        except Exception as exc:
            self._bars_prog = None
            errors.append(f"bars_prog: {exc}")
        try:
            self._heat_prog = self.ctx.program(
                vertex_shader=self._heat_vertex_shader(),
                fragment_shader=self._heat_fragment_shader(),
            )
        except Exception as exc:
            self._heat_prog = None
            errors.append(f"heat_prog: {exc}")
        try:
            self._flat_prog = self.ctx.program(
                vertex_shader=self._flat_vertex_shader(),
                fragment_shader=self._flat_fragment_shader(),
            )
        except Exception as exc:
            self._flat_prog = None
            errors.append(f"flat_prog: {exc}")
        if errors:
            self._gl_error = " | ".join(errors)

        # Window shaders are lazily created when a genome window is set.
        self._upload_buffers()

    def resizeGL(self, width: int, height: int) -> None:  # pragma: no cover
        if self.ctx is not None:
            dpr = self._device_pixel_ratio()
            w_px, h_px = _framebuffer_size_px(logical_w=max(1, int(width)), logical_h=max(1, int(height)), dpr=dpr)
            self.ctx.viewport = (0, 0, int(w_px), int(h_px))
            self._last_dpr = float(dpr)
            self._last_fb_size_px = (int(w_px), int(h_px))
            self._last_viewport_px = (int(w_px), int(h_px))
            try:
                self._note_resize_alloc_dirty(int(w_px), int(h_px), now_s=clock.perf_counter())
            except Exception:
                pass

    def _gl_set_depth_test(self, enabled: bool) -> None:
        ctx = self.ctx
        if ctx is None:
            return
        enabled = bool(enabled)
        try:
            if enabled:
                ctx.enable(moderngl.DEPTH_TEST)
            else:
                ctx.disable(moderngl.DEPTH_TEST)
        finally:
            self._gl_depth_test_enabled = enabled

    @contextmanager
    def _gl_depth_test_guard(self, enabled: bool):
        with _bool_state_guard(
            current=lambda: self._gl_depth_test_enabled,
            set_state=self._gl_set_depth_test,
            default=True,
            desired=enabled,
        ):
            yield

    def _gl_set_blend(self, enabled: bool) -> None:
        ctx = self.ctx
        if ctx is None:
            return
        enabled = bool(enabled)
        try:
            if enabled:
                ctx.enable(moderngl.BLEND)
            else:
                ctx.disable(moderngl.BLEND)
        finally:
            self._gl_blend_enabled = enabled

    @contextmanager
    def _gl_blend_guard(self, enabled: bool):
        with _bool_state_guard(
            current=lambda: self._gl_blend_enabled,
            set_state=self._gl_set_blend,
            default=True,
            desired=enabled,
        ):
            yield

    @contextmanager
    def _gl_pick_id_pass_guard(self):
        """Guard the GL state required for correct GPU ID-buffer picking."""

        ctx = getattr(self, "ctx", None)
        if ctx is None:
            raise RuntimeError("No ModernGL context; cannot run pick ID pass.")

        pick = getattr(self, "_pick_id_buffer", None)
        if pick is None:
            raise RuntimeError(
                "Pick ID buffer not allocated. Enable HELIX_VIEWER_PICK_ID_BUFFER and ensure resize sync ran."
            )

        size = getattr(pick, "size_px", (0, 0))
        w_px, h_px = (int(size[0]), int(size[1]))
        prev_fbo = getattr(ctx, "fbo", None)
        prev_viewport = tuple(getattr(ctx, "viewport", (0, 0, w_px, h_px)))
        prev_depth_mask: bool | None = None
        prev_color_mask: tuple[bool, bool, bool, bool] | None = None
        if _HAS_GL:
            try:
                prev_depth_mask = bool(GL.glGetBooleanv(GL.GL_DEPTH_WRITEMASK))
            except Exception:
                prev_depth_mask = None
            try:
                cm = GL.glGetBooleanv(GL.GL_COLOR_WRITEMASK)
                prev_color_mask = tuple(bool(v) for v in cm)  # type: ignore[assignment]
            except Exception:
                prev_color_mask = None

        try:
            with self._gl_blend_guard(False), self._gl_depth_test_guard(True):
                pick.fbo.use()  # type: ignore[attr-defined]
                ctx.viewport = (0, 0, int(w_px), int(h_px))
                self._assert_pick_sacredness(stage="before_pick_pass")
                if bool(getattr(self, "_gl_blend_enabled", False)):
                    raise AssertionError("[pick sacredness:before_pick_pass] Blending must be disabled for ID picking.")
                if tuple(getattr(ctx, "viewport", ())) != (0, 0, int(w_px), int(h_px)):
                    raise AssertionError(
                        f"[pick sacredness:before_pick_pass] viewport {getattr(ctx, 'viewport', None)} != "
                        f"(0,0,{int(w_px)},{int(h_px)}) for pick pass."
                    )
                if _HAS_GL:
                    # ModernGL does not expose mask state; only enforce when PyOpenGL is available.
                    try:
                        GL.glDepthMask(True)
                    except Exception:
                        pass
                    try:
                        GL.glColorMask(True, True, True, True)
                    except Exception:
                        pass
                yield
        finally:
            # Restore framebuffer binding and viewport regardless of how the pick pass exits.
            try:
                if prev_fbo is not None:
                    prev_fbo.use()  # type: ignore[attr-defined]
                else:
                    screen = getattr(ctx, "screen", None)
                    if screen is not None:
                        screen.use()  # type: ignore[attr-defined]
            except Exception:
                pass
            try:
                ctx.viewport = prev_viewport
            except Exception:
                pass
            if _HAS_GL:
                try:
                    if prev_depth_mask is not None:
                        GL.glDepthMask(bool(prev_depth_mask))
                except Exception:
                    pass
                try:
                    if prev_color_mask is not None and len(prev_color_mask) == 4:
                        GL.glColorMask(
                            bool(prev_color_mask[0]),
                            bool(prev_color_mask[1]),
                            bool(prev_color_mask[2]),
                            bool(prev_color_mask[3]),
                        )
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Qt overrides
    # ------------------------------------------------------------------
    def paintGL(self) -> None:  # pragma: no cover
        if not getattr(self, "_render_active", True):
            if not getattr(self, "_inactive_paint_logged", False):
                print("[HelixModernWidget] paintGL called while inactive; skipping.", flush=True)
                self._inactive_paint_logged = True
            return
        if self.ctx is None:
            return
        perf_enabled = bool(getattr(self, "_perf_hud_enabled", False))
        frame_start = clock.perf_counter() if perf_enabled else 0.0
        try:
            self.makeCurrent()
            self._maybe_reset_and_rebuild()
            if self._pending_reset or self._need_rebuild:
                return
            w = max(1, self.width())
            h = max(1, self.height())
            dpr = self._device_pixel_ratio()
            fb_w, fb_h = _framebuffer_size_px(logical_w=w, logical_h=h, dpr=dpr)
            now_s = clock.perf_counter()
            try:
                self._note_resize_alloc_dirty(int(fb_w), int(fb_h), now_s=now_s)
                self._maybe_commit_resize_allocations(now_s=now_s)
            except Exception:
                pass

            self.ctx.viewport = (0, 0, int(fb_w), int(fb_h))
            self._last_dpr = float(dpr)
            self._last_fb_size_px = (int(fb_w), int(fb_h))
            self._last_viewport_px = (int(fb_w), int(fb_h))

            if self._mode == "workflow_2p5d" and self._workflow_buffers:
                self.ctx.clear(0.02, 0.02, 0.05, 1.0, 1.0)
                self._render_workflow()
                try:
                    self._paint_workflow_overlay()
                except Exception:
                    pass
                if self._show_bases and self._workflow_last_mvp is not None:
                    try:
                        positions = self._workflow_base_positions()
                        if positions is not None:
                            cut_idx = None
                            try:
                                cut_idx = int(self._workflow_buffers.get("cut_index", 0))  # type: ignore[attr-defined]
                            except Exception:
                                cut_idx = None
                            self._paint_base_letters_generic(
                                self._workflow_last_mvp,
                                seq=self._workflow_sequence or None,
                                positions=positions,
                                positions_opposite=None,
                                cut_idx=cut_idx,
                            )
                    except Exception:
                        pass
                if not self._has_drawn_frame:
                    self._has_drawn_frame = True
                    self.frameDrawn.emit()
                return

            # Simple window-only rendering path when no engine geometry is present
            if (
                self.engine is None
                and self._window_prog is not None
                and self._window_vao is not None
                and self._window_count > 1
            ):
                self.ctx.clear(0.01, 0.02, 0.06, 1.0, 1.0)
                self._window_prog["u_count"].value = float(self._window_count)
                self._window_prog["u_zoom_bp"].value = max(1.0, self._window_zoom_bp)
                self._window_prog["u_pan_bp"].value = self._window_pan_bp
                self._window_vao.render(mode=moderngl.LINE_STRIP, vertices=self._window_count)
                if self._overlay_vao is not None and self._overlay_count > 0:
                    self._overlay_prog["u_window_len"].value = float(self._window_count)
                    self._overlay_prog["u_zoom_bp"].value = max(1.0, self._window_zoom_bp)
                    self._overlay_prog["u_pan_bp"].value = self._window_pan_bp
                    self._overlay_vao.render(mode=moderngl.POINTS, vertices=self._overlay_count)
                if not self._has_drawn_frame:
                    self._has_drawn_frame = True
                    self.frameDrawn.emit()
                return

            # Linear rail mode (3D tab)
            if self._rail_mode is RailViewMode.FLAT:
                # Deep indigo for flat param-space rails
                self.ctx.clear(0.03, 0.05, 0.14, 1.0, 1.0)
            else:
                # Darker, more neutral space-like backdrop for helix view
                self.ctx.clear(0.01, 0.02, 0.06, 1.0, 1.0)
            # Even if rails aren't ready yet, continue so HUD/debug overlays render.

            time_value = 0.0
            phase = AnimationPhase.APPROACH
            if self.engine is not None:
                st = self.engine.state
                raw_time = float(getattr(st, "time", 0.0))
                phase = getattr(st, "phase", AnimationPhase.APPROACH)
                loop = float(getattr(self.engine, "loop_duration", 0.0))
                base_gate = max(0.0, min(1.0, raw_time / loop)) if loop > 0.0 else 1.0
            else:
                raw_time = 0.0
                base_gate = 1.0
            event_times_normalized = bool(getattr(getattr(self, "engine", None), "event_times_normalized", False))

            # Freeze rail/ribbon motion when animation is disabled, but keep time gating tied to the current timeline position.
            time_value = raw_time if self._animate else 0.0
            weights_norm = self._arc_weights_normalized
            if weights_norm is None:
                weights_norm = event_times_normalized
            t_gate = base_gate if weights_norm else raw_time
            if _env_flag("HELIX_SHOW_ALL_RAILS", False):
                t_gate = 1e9

            aspect = float(fb_w) / max(1.0, float(fb_h))
            if self._rail_mode is RailViewMode.FLAT:
                # 2D param-space view: rails + ribbons share a simple pan/zoom MVP.
                mvp = self._mvp_matrix(aspect, orbit_time=time_value)
                flat_value = 1.0
            else:
                # 3D helix view: orbit a perspective camera around the helix
                # center to reveal a proper double helix.
                mvp = self._helix_mvp(aspect)
                flat_value = 0.0

            # Rails (both modes; vertex shader unwraps when flat_value=1.0).
            if self._rail_program:
                self._rail_program["u_mvp"].write(self._gl_mat4(mvp))
                self._rail_program["u_time"].value = time_value
                self._rail_program["u_phase"].value = self._phase_value(phase)
                self._rail_program["u_template"].value = 1.0 if self._show_template else 0.0
                self._rail_program["u_glow"].value = 0.0
                if "u_hi_t0" in self._rail_program and "u_hi_t1" in self._rail_program:
                    if self._highlight_param is not None:
                        t0, t1 = self._highlight_param
                    else:
                        t0 = t1 = -1.0
                    self._rail_program["u_hi_t0"].value = float(t0)
                    self._rail_program["u_hi_t1"].value = float(t1)
                self._rail_program["u_flat"].value = float(flat_value)
                self._rail_program["u_spacing"].value = float(MODERN_STYLE.flat_rail_spacing)

                prev_line_width: float | None = None
                try:
                    prev_line_width = float(self.ctx.line_width)
                except Exception:
                    prev_line_width = None

                try:
                    try:
                        if self._rail_mode is RailViewMode.FLAT:
                            # Give the flat rails more visual mass so they read like tracks.
                            self.ctx.line_width = float(
                                _logical_to_physical_px(MODERN_STYLE.flat_rail_thickness_px, dpr)
                            )
                        else:
                            # 3D helix: keep strand width in physical pixels for crispness on HiDPI.
                            self.ctx.line_width = float(
                                _logical_to_physical_px(MODERN_STYLE.helix_strand_thickness_px, dpr)
                            )
                    except Exception:
                        pass

                    n = self._rail_vertex_count // 2
                    if n > 1 and self._vao:
                        self._vao.render(mode=moderngl.LINE_STRIP, vertices=n, first=0)
                        self._vao.render(mode=moderngl.LINE_STRIP, vertices=n, first=n)

                    # Glow pass for highlighted window
                    if n > 1 and self._highlight_param is not None and self._vao:
                        self._rail_program["u_glow"].value = 1.0
                        if "u_hi_t0" in self._rail_program and "u_hi_t1" in self._rail_program:
                            t0, t1 = self._highlight_param
                            self._rail_program["u_hi_t0"].value = float(t0)
                            self._rail_program["u_hi_t1"].value = float(t1)
                        with self._gl_depth_test_guard(False):
                            self._vao.render(mode=moderngl.LINE_STRIP, vertices=n, first=0)
                            self._vao.render(mode=moderngl.LINE_STRIP, vertices=n, first=n)
                        self._rail_program["u_glow"].value = 0.0

                    # Highlighted window from Outcome Explorer
                    if self._rail_mode is RailViewMode.FLAT and self._highlight_vao is not None and self._flat_prog:
                        self._flat_prog["u_mvp"].write(self._gl_mat4(mvp))
                        self._flat_prog["u_color"].value = (0.2, 0.9, 1.0, 0.35)
                        self._highlight_vao.render(mode=moderngl.TRIANGLE_STRIP)
                finally:
                    if prev_line_width is not None:
                        try:
                            self.ctx.line_width = float(prev_line_width)
                        except Exception:
                            pass

            # Param-space ribbons (arcs) between genome positions.
            # In flat rail mode, depth test stays off to avoid Z-fighting and keep draw ordering deterministic.
            if self._rail_mode is RailViewMode.FLAT and self._show_ribbons and self._arc_program:
                with self._gl_depth_test_guard(False):

                    def _set_arc_uniforms(conf: float) -> None:
                        self._arc_program["u_mvp"].write(self._gl_mat4(mvp))
                        if "u_time" in self._arc_program:
                            self._arc_program["u_time"].value = time_value
                        self._arc_program["u_flap"].value = 1.0 if self._show_flap else 0.0
                        if "u_t_gate" in self._arc_program:
                            self._arc_program["u_t_gate"].value = t_gate
                        if "u_selected_kind" in self._arc_program:
                            sel = self._selected_kind if self._selected_kind is not None else -1.0
                            self._arc_program["u_selected_kind"].value = float(sel)
                        if "u_confidence" in self._arc_program:
                            self._arc_program["u_confidence"].value = float(conf)

                    if self._arc_vao and self._arc_ranges:
                        for idx, (start, count) in enumerate(self._arc_ranges):
                            conf = 0.5
                            if self._arc_confidence and idx < len(self._arc_confidence):
                                conf = self._arc_confidence[idx]
                            _set_arc_uniforms(conf)
                            if count > 1:
                                self._arc_vao.render(
                                    mode=moderngl.LINE_STRIP,
                                    first=start,
                                    vertices=count,
                                )

                    if self._arc_heads_vao and self._arc_heads_count:
                        conf = 0.5
                        if self._arc_confidence:
                            conf = self._arc_confidence[0]
                        _set_arc_uniforms(conf)
                        self._arc_heads_vao.render(
                            mode=moderngl.TRIANGLES,
                            vertices=self._arc_heads_count,
                        )

            # Draw nucleotide letters in both flat and helix modes when zoomed in.
            if self._show_bases:
                self._paint_base_letters(mvp)

            if not self._has_drawn_frame:
                self._has_drawn_frame = True
                self.frameDrawn.emit()

            try:
                self._paint_story_overlay(
                    mvp=mvp,
                    phase=phase,
                    raw_time=raw_time,
                    t_gate=t_gate,
                )
            except Exception:
                pass
            self._paint_hud()
            try:
                self._paint_dpi_debug_hud()
            except Exception:
                pass
        finally:
            if perf_enabled:
                frame_end = clock.perf_counter()
                try:
                    self._update_perf_stats(frame_start, frame_end)
                    self._paint_perf_hud()
                except Exception:
                    pass

    def _clip_to_screen(self, clip: np.ndarray) -> tuple[float, float] | None:
        w = float(clip[3])
        if abs(w) < 1e-6:
            return None
        ndc_x = float(clip[0]) / w
        ndc_y = float(clip[1]) / w
        sx = (ndc_x * 0.5 + 0.5) * float(self.width())
        sy = (1.0 - (ndc_y * 0.5 + 0.5)) * float(self.height())
        return sx, sy

    def _world_to_screen(
        self,
        *,
        mvp: np.ndarray,
        x: float,
        y: float,
        z: float = 0.0,
    ) -> tuple[float, float] | None:
        pos = np.array([float(x), float(y), float(z), 1.0], dtype="f4")
        clip = mvp @ pos
        return self._clip_to_screen(clip)

    def _paint_base_letters(self, mvp: np.ndarray) -> None:
        """Paint base letters in flat rail mode when zoomed in."""
        return self._paint_base_letters_generic(
            mvp,
            seq=None,
            positions=self._bp_positions,
            positions_opposite=self._bp_positions_opposite,
            cut_idx=None,
        )

    def _paint_base_letters_generic(
        self,
        mvp: np.ndarray,
        *,
        seq: str | None,
        positions: np.ndarray | None,
        positions_opposite: np.ndarray | None,
        cut_idx: int | None,
    ) -> None:
        if seq is None:
            spec = self._spec
            if spec is None and self.engine is not None:
                spec = getattr(self.engine, "spec", None)
            seq = getattr(spec, "sequence", "") or ""
        if not seq:
            return
        if positions is None:
            positions = self._bp_positions
        positions_ok = True
        try:
            positions_ok = (
                isinstance(positions, np.ndarray)
                and positions.ndim == 2
                and positions.shape[0] > 0
                and positions.shape[1] >= 3
            )
        except Exception:
            positions_ok = False
        if not positions_ok:
            positions = None
        if positions is None:
            self._base_overlay_used_fallback = True
            # Fallback: derive base centers from the uploaded rail geometry so we
            # can still show letters even if base-index metadata is missing.
            window_len = int(max(0, min(len(seq), int(getattr(self, "_num_bp", 0) or len(seq)))))
            if window_len <= 0:
                return
            verts = getattr(self, "_world_rail_vertices", None)
            if isinstance(verts, np.ndarray) and verts.ndim == 2 and verts.shape[0] >= 2 and verts.shape[1] >= 3:
                half = int(verts.shape[0] // 2)
                if half > 0:
                    n = min(int(window_len), half)
                    if n <= 0:
                        return
                    if half == n:
                        idx = np.arange(n, dtype="i4")
                    else:
                        idx = np.floor(np.linspace(0.0, float(half - 1), n, dtype="f4")).astype("i4")
                    positions = verts[idx, :3].astype("f4")
                    opp_ok = True
                    try:
                        opp_ok = (
                            isinstance(positions_opposite, np.ndarray)
                            and positions_opposite.ndim == 2
                            and positions_opposite.shape[0] == positions.shape[0]
                            and positions_opposite.shape[1] >= 3
                        )
                    except Exception:
                        opp_ok = False
                    if not opp_ok and verts.shape[0] >= half + int(idx.max()) + 1:
                        positions_opposite = verts[idx + half, :3].astype("f4")
            if positions is None and self._rail_mode is RailViewMode.FLAT:
                # Last resort: synthesize base centers for flat rails.
                t = np.linspace(0.0, 1.0, window_len, dtype="f4") if window_len > 1 else np.array([0.0], dtype="f4")
                x = (t * 2.0 - 1.0) * 0.9
                y = np.full_like(x, float(MODERN_STYLE.flat_rail_spacing), dtype="f4")
                z = np.zeros_like(x, dtype="f4")
                positions = np.stack([x, y, z], axis=1).astype("f4")
                opp_ok = True
                try:
                    opp_ok = (
                        isinstance(positions_opposite, np.ndarray)
                        and positions_opposite.ndim == 2
                        and positions_opposite.shape[0] == positions.shape[0]
                        and positions_opposite.shape[1] >= 3
                    )
                except Exception:
                    opp_ok = False
                if not opp_ok:
                    y2 = np.full_like(x, -float(MODERN_STYLE.flat_rail_spacing), dtype="f4")
                    positions_opposite = np.stack([x, y2, z], axis=1).astype("f4")
            if positions is None:
                return
        else:
            self._base_overlay_used_fallback = False
        if not self._show_bases:
            return
        window_len = min(len(seq), positions.shape[0])
        if window_len == 0:
            return

        # Estimate local on-screen base spacing (px) to adapt density.
        base_spacing_px = None
        if window_len >= 2:
            try:
                mid = max(0, min(window_len - 2, window_len // 2))
                a = positions[mid]
                b = positions[mid + 1]
                sa = self._world_to_screen(mvp=mvp, x=float(a[0]), y=float(a[1]), z=float(a[2]))
                sb = self._world_to_screen(mvp=mvp, x=float(b[0]), y=float(b[1]), z=float(b[2]))
                if sa is not None and sb is not None:
                    base_spacing_px = float(math.hypot(float(sb[0]) - float(sa[0]), float(sb[1]) - float(sa[1])))
            except Exception:
                base_spacing_px = None

        # LOD by count
        step = 1
        if window_len > self._max_base_glyphs:
            budget = max(1, self._max_base_glyphs_sparse)
            step = max(1, int(math.ceil(window_len / float(budget))))

        n = min(window_len, len(seq))

        p = QPainter(self)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        font = QFont("Consolas")
        font.setPixelSize(11)
        font.setBold(True)
        p.setFont(font)
        try:
            glyph_w = float(p.fontMetrics().horizontalAdvance("M"))
        except Exception:
            glyph_w = 10.0
        desired_spacing_px = max(8.0, glyph_w + 2.0)
        if base_spacing_px is not None and base_spacing_px > 1e-6 and math.isfinite(base_spacing_px):
            try:
                step_spacing = int(math.ceil(desired_spacing_px / float(base_spacing_px)))
            except Exception:
                step_spacing = 1
            step = max(step, max(1, step_spacing))
        try:
            self._base_overlay_last_spacing_px = float(base_spacing_px) if base_spacing_px is not None else None
        except Exception:
            self._base_overlay_last_spacing_px = None
        self._base_overlay_last_step = int(step)
        colors = {
            "A": QColor(135, 206, 250),  # light blue
            "C": QColor(255, 206, 86),   # amber
            "G": QColor(144, 238, 144),  # light green
            "T": QColor(255, 160, 160),  # light red
            "N": QColor(200, 200, 200),
        }
        w = max(1, self.width())
        h = max(1, self.height())
        complement = {"A": "T", "T": "A", "C": "G", "G": "C", "N": "N"}

        def _draw_letter(
            pos_arr: np.ndarray,
            ch: str,
            base_color: QColor,
            alpha_scale: float,
            pixel_offset_y: float,
        ) -> None:
            screen = self._world_to_screen(
                mvp=mvp,
                x=float(pos_arr[0]),
                y=float(pos_arr[1]),
                z=float(pos_arr[2]),
            )
            if screen is None:
                return
            sx, sy = screen
            if not (0 <= sx <= w and 0 <= sy <= h):
                return
            c = QColor(base_color)
            c.setAlpha(int(max(0, min(1, alpha_scale)) * 255))
            p.setPen(c)
            p.drawText(int(sx) - 4, int(sy + pixel_offset_y), ch)

        cut_idx2 = cut_idx if cut_idx is not None else self._cut_index_from_spec()
        cut_screen: tuple[float, float] | None = None
        if cut_idx2 is not None and 0 <= cut_idx2 < positions.shape[0]:
            pos_cut = positions[cut_idx2]
            cut_screen = self._world_to_screen(mvp=mvp, x=float(pos_cut[0]), y=float(pos_cut[1]), z=float(pos_cut[2]))

        for i in range(0, n, step):
            base_ch = seq[i].upper()
            pos = positions[i]
            color = colors.get(base_ch, colors["N"])
            _draw_letter(pos, base_ch, color, 1.0, pixel_offset_y=-8.0)

            if positions_opposite is not None and i < positions_opposite.shape[0]:
                opp = complement.get(base_ch, "N")
                pos_o = positions_opposite[i]
                _draw_letter(pos_o, opp, color, 0.95, pixel_offset_y=8.0)

        p.end()

    def _cut_index_from_spec(self) -> int | None:
        spec = self._spec
        if spec is None and self.engine is not None:
            spec = getattr(self.engine, "spec", None)
        if spec is None:
            return None

        cut_idx = None
        try:
            for ev in spec.events:
                if ev.type in (EditEventType.NICK_PRIMARY, EditEventType.CUT) and ev.index is not None:
                    cut_idx = int(ev.index)
                    break
        except Exception:
            cut_idx = None

        if cut_idx is None:
            try:
                rail_bands = (spec.metadata or {}).get("rail_bands") if spec.metadata else None
                if isinstance(rail_bands, Mapping) and rail_bands.get("cut_index") is not None:
                    cut_idx = int(rail_bands.get("cut_index"))
            except Exception:
                cut_idx = None

        if cut_idx is None:
            return None
        return max(0, min(len(spec.sequence) - 1, int(cut_idx)))

    @staticmethod
    def _choose_tick_step(n_bp: int) -> int:
        n_bp = int(max(1, n_bp))
        if n_bp <= 60:
            return 10
        if n_bp <= 120:
            return 20
        if n_bp <= 300:
            return 50
        if n_bp <= 700:
            return 100
        if n_bp <= 1500:
            return 200
        return 500

    def _phase_progress(self, gate_value: float) -> float:
        engine = self.engine
        if engine is None:
            return 0.0
        thresholds = list(getattr(engine, "_phase_thresholds", ()) or ())
        if not thresholds:
            return 0.0
        gate_value = float(gate_value)
        end_default = 1.0 if bool(getattr(engine, "event_times_normalized", False)) else float(getattr(engine, "loop_duration", 1.0))

        start_t = float(thresholds[0][0])
        end_t = end_default
        for idx, (t, _phase) in enumerate(thresholds):
            t = float(t)
            if gate_value >= t:
                start_t = t
                end_t = float(thresholds[idx + 1][0]) if idx + 1 < len(thresholds) else end_default
            else:
                break
        denom = max(1e-6, end_t - start_t)
        return max(0.0, min(1.0, (gate_value - start_t) / denom))

    def _paint_story_overlay(
        self,
        *,
        mvp: np.ndarray,
        phase: AnimationPhase,
        raw_time: float,
        t_gate: float,
        painter: QPainter | None = None,
    ) -> None:
        if self.engine is None:
            return

        cut_idx = self._cut_index_from_spec()
        if cut_idx is None:
            return

        anim_t = float(raw_time)
        pulse = 0.5 + 0.5 * math.sin(anim_t * 4.0)
        locus_pulse = float(self._locus_pulse_amount())
        phase_key = getattr(phase, "value", str(phase)).lower()
        hot = phase_key in {"cut", "prime", "repair"}

        owns_painter = False
        if painter is None:
            painter = QPainter(self)
            owns_painter = True

        p = painter
        saved = False
        try:
            p.save()
            saved = True
        except Exception:
            saved = False

        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        style = MODERN_STYLE
        font = QFont("Consolas")
        if self._rail_mode is RailViewMode.FLAT:
            font.setPixelSize(int(style.flat_rail_label_font_px))
        else:
            font.setPointSize(9)
        p.setFont(font)

        if self._rail_mode is RailViewMode.HELIX:
            try:
                loop = float(getattr(self.engine, "loop_duration", 1.0))
            except Exception:
                loop = 1.0
            if not math.isfinite(loop) or loop <= 1e-6:
                loop = 1.0
            frac = max(0.0, min(1.0, float(raw_time) / float(loop)))

            bounds = self._helix_reference_bounds
            if bounds is not None:
                try:
                    _draw_helix_reference_frame(
                        p,
                        project=lambda x, y, z: self._world_to_screen(mvp=mvp, x=x, y=y, z=z),
                        bounds=bounds,
                        now_frac=frac,
                        pulse=pulse,
                    )
                except Exception:
                    pass

        glyph_cut = "■"
        glyph_repair = "◆"
        try:
            sem = getattr(self, "_cut_semantics", None)
            if sem is not None:
                glyph_cut = str(getattr(sem, "glyph_cut", glyph_cut) or glyph_cut)
                glyph_repair = str(getattr(sem, "glyph_repair", glyph_repair) or glyph_repair)
        except Exception:
            pass

        # --- Cut marker -------------------------------------------------
        cut_pos = None
        try:
            if self._bp_positions is not None and 0 <= cut_idx < self._bp_positions.shape[0]:
                cut_pos = self._bp_positions[cut_idx]
        except Exception:
            cut_pos = None

        cut_world_x: float | None = None
        cut_world_y = 0.0
        cut_world_z = 0.0
        if cut_pos is not None:
            cut_world_x = float(cut_pos[0])
            cut_world_y = float(cut_pos[1])
            cut_world_z = float(cut_pos[2])
        else:
            # Flat fallback: assume linear x in [-0.9, 0.9]
            denom = max(1, self._num_bp - 1)
            cut_world_x = (float(cut_idx) / float(denom) * 2.0 - 1.0) * 0.9

        sx_sy = None
        if cut_world_x is not None:
            sx_sy = self._world_to_screen(mvp=mvp, x=cut_world_x, y=cut_world_y, z=cut_world_z)

        if sx_sy is not None:
            sx, sy = sx_sy
            glow_alpha = 24 + int(24 * pulse)
            core_alpha = 190 if hot else 150
            core_w = 5 if hot else 3
            tag = "CUT" if hot else "cut"
            if locus_pulse > 1e-6:
                glow_alpha = min(255, glow_alpha + int(150 * locus_pulse))
                core_alpha = min(255, core_alpha + int(105 * locus_pulse))

            if self._rail_mode is RailViewMode.FLAT:
                glow_w = 14 + int(round(8 * locus_pulse))
                p.setPen(QPen(QColor(255, 160, 90, glow_alpha), glow_w))
                p.drawLine(int(sx), 10, int(sx), self.height() - 10)
                core_w2 = max(1, int(core_w + round(3 * locus_pulse)))
                p.setPen(QPen(QColor(255, 196, 120, core_alpha), core_w2))
                p.drawLine(int(sx), 10, int(sx), self.height() - 10)
                p.setPen(QColor(255, 236, 160, 230))
                p.drawText(int(sx) + 8, 22, f"{glyph_cut} {tag} @{cut_idx}")

                # Tiny locus marker directly on the template rail (fast mapping from label/cursor → locus).
                if cut_world_x is not None:
                    dot = self._world_to_screen(
                        mvp=mvp,
                        x=float(cut_world_x),
                        y=float(style.flat_rail_spacing),
                        z=0.0,
                    )
                    if dot is not None:
                        dx, dy = dot
                        r = max(2, int(style.flat_rail_marker_radius_px))
                        r = int(r + round(2 * locus_pulse))
                        glow = int(r * 2.2)
                        p.setPen(Qt.NoPen)
                        p.setBrush(QColor(255, 160, 90, min(120, glow_alpha + 40)))
                        p.drawEllipse(int(dx - glow), int(dy - glow), int(glow * 2), int(glow * 2))
                        p.setBrush(QColor(255, 236, 160, 235))
                        p.drawEllipse(int(dx - r), int(dy - r), int(r * 2), int(r * 2))
            else:
                base_r = max(3, int(style.event_marker_radius_px))
                glow = int(round(float(base_r) * (3.0 if hot else 2.3)))
                core = int(round(float(base_r) * (1.2 if hot else 1.0)))
                if locus_pulse > 1e-6:
                    glow = int(glow + round(float(base_r) * 1.4 * locus_pulse))
                    core = int(core + round(float(base_r) * 0.8 * locus_pulse))
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(255, 160, 90, glow_alpha))
                p.drawEllipse(int(sx - glow), int(sy - glow), int(glow * 2), int(glow * 2))
                p.setBrush(QColor(255, 236, 160, core_alpha))
                p.drawEllipse(int(sx - core), int(sy - core), int(core * 2), int(core * 2))
                p.setPen(QColor(255, 236, 160, 230))
                p.drawText(int(sx) + 10, int(sy) - 10, f"{glyph_cut} {tag} @{cut_idx}")

        # --- Flat-rail axis + guide bracket -----------------------------
        if self._rail_mode is RailViewMode.FLAT and self._spec is not None:
            spec = self._spec
            n_bp = max(1, len(spec.sequence))
            step = self._choose_tick_step(n_bp)
            axis_y = self.height() - 22

            p.setPen(QPen(QColor(160, 175, 210, 140), 1))
            p.drawLine(14, axis_y, self.width() - 14, axis_y)

            last_label_x = -1e9
            for idx in range(0, n_bp, step):
                denom = max(1, n_bp - 1)
                wx = (float(idx) / float(denom) * 2.0 - 1.0) * 0.9
                pt = self._world_to_screen(mvp=mvp, x=wx, y=0.0, z=0.0)
                if pt is None:
                    continue
                x_px, _ = pt
                if x_px < -20 or x_px > self.width() + 20:
                    continue
                p.drawLine(int(x_px), axis_y, int(x_px), axis_y + 6)
                if x_px - last_label_x >= 44:
                    p.setPen(QColor(200, 220, 255, 210))
                    p.drawText(int(x_px) + 2, axis_y + 18, str(idx))
                    p.setPen(QPen(QColor(160, 175, 210, 140), 1))
                    last_label_x = x_px

            # Guide window bracket (within the visualized sequence window)
            g0, g1 = spec.guide_range
            denom = max(1, n_bp - 1)
            wx0 = (float(g0) / float(denom) * 2.0 - 1.0) * 0.9
            wx1 = (float(g1) / float(denom) * 2.0 - 1.0) * 0.9
            a = self._world_to_screen(mvp=mvp, x=wx0, y=0.0, z=0.0)
            b = self._world_to_screen(mvp=mvp, x=wx1, y=0.0, z=0.0)
            if a is not None and b is not None:
                x0, _ = a
                x1, _ = b
                y = axis_y - 10
                p.setPen(QPen(QColor(120, 210, 255, 210), 2))
                p.drawLine(int(x0), y, int(x1), y)
                p.drawLine(int(x0), y - 4, int(x0), y + 4)
                p.drawLine(int(x1), y - 4, int(x1), y + 4)
                p.setPen(QColor(220, 245, 255, 230))
                p.drawText(int((x0 + x1) * 0.5) - 18, y - 6, "Guide")

            # Arc motion dot: gives the story a "heartbeat"
            if self._arc_cpu is not None and self._arc_ranges:
                target_kind = 0.0 if phase_key in {"cut", "prime"} else 2.0

                start = count = None
                for first, n in self._arc_ranges:
                    if n <= 1:
                        continue
                    try:
                        kind = float(self._arc_cpu[first, 4])
                    except Exception:
                        continue
                    if abs(kind - target_kind) < 0.5:
                        start, count = int(first), int(n)
                        break
                if start is None or count is None:
                    # Fallback: any arc range is better than nothing.
                    first, n = self._arc_ranges[0]
                    start, count = int(first), int(n)

                if count >= 2:
                    progress = 1.0 if phase_key == "resolve" else self._phase_progress(float(t_gate))
                    i = start + int(progress * float(count - 1))
                    i = max(start, min(start + count - 1, i))
                    pos = self._arc_cpu[i, :3]
                    pt = self._world_to_screen(mvp=mvp, x=float(pos[0]), y=float(pos[1]), z=float(pos[2]))
                    if pt is not None:
                        dx, dy = pt
                        r = max(2, int(style.flat_rail_marker_radius_px) + (1 if hot else 0))
                        glow = int(r * 2.2)
                        p.setPen(Qt.NoPen)
                        p.setBrush(QColor(60, 220, 255, 28 + int(40 * pulse)))
                        p.drawEllipse(int(dx - glow), int(dy - glow), int(glow * 2), int(glow * 2))
                        p.setBrush(QColor(190, 250, 255, 220))
                        p.drawEllipse(int(dx - r), int(dy - r), int(r * 2), int(r * 2))
                        if phase_key == "resolve":
                            p.setPen(QColor(245, 248, 255, 235))
                            p.drawText(int(dx + 10), int(dy + 4), f"{glyph_repair} Repair resolved")

            # Strand labels (screen anchored, so users don't need the legend to infer semantics)
            top_y = int(self.height() * 0.25)
            bottom_y = int(self.height() * 0.75)
            top = self._world_to_screen(mvp=mvp, x=0.0, y=float(style.flat_rail_spacing), z=0.0)
            bottom = self._world_to_screen(mvp=mvp, x=0.0, y=-float(style.flat_rail_spacing), z=0.0)
            if top is not None and bottom is not None:
                _, top_y = top
                _, bottom_y = bottom
                top_y = int(top_y)
                bottom_y = int(bottom_y)
            p.setPen(QColor(200, 220, 255, 220))
            fm = p.fontMetrics()
            label_a = "Template"
            label_b = "Opposite"
            x_right = self.width() - 16
            offset = max(0, int(style.flat_rail_label_offset_px))
            top_baseline = int(top_y - offset - fm.descent())
            bottom_baseline = int(bottom_y + offset + fm.ascent())
            p.drawText(x_right - fm.horizontalAdvance(label_a), top_baseline, label_a)
            p.drawText(x_right - fm.horizontalAdvance(label_b), bottom_baseline, label_b)

        # Resolve moment: brief stamp/glow so the outcome reads as a "moment".
        try:
            flash_u = max(0.0, min(1.0, float(self._resolve_flash_s) / 0.5))
        except Exception:
            flash_u = 0.0
        if phase_key == "resolve" and flash_u > 1e-6:
            stamp = "Repair resolved"
            stamp_font = QFont("Consolas", 24)
            stamp_font.setBold(True)
            p.setFont(stamp_font)
            fm2 = p.fontMetrics()
            x = int((self.width() - fm2.horizontalAdvance(stamp)) * 0.5)
            y = int(self.height() * 0.14) + fm2.ascent()
            glow_alpha = int(160 * flash_u)
            core_alpha = int(235 * flash_u)
            p.setPen(QPen(QColor(255, 176, 96, glow_alpha), 6))
            p.drawText(x, y, stamp)
            p.setPen(QColor(255, 255, 255, core_alpha))
            p.drawText(x, y, stamp)

        if saved:
            try:
                p.restore()
            except Exception:
                pass
        if owns_painter:
            p.end()

    def _paint_workflow_overlay(self) -> None:
        buffers = self._workflow_buffers
        if not isinstance(buffers, Mapping):
            return

        w = max(1, self.width())
        h = max(1, self.height())
        x_extent = float(buffers.get("x_extent", 1.0))
        left, right = -1.0, x_extent + 1.0
        span = max(1e-6, right - left)

        def _x_px(x: float) -> float:
            return ((float(x) - left) / span) * float(w)

        anim_t = float(self._overlay_time_s)
        pulse = 0.5 + 0.5 * math.sin(anim_t * 4.0)
        locus_pulse = float(self._locus_pulse_amount())

        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setRenderHint(QPainter.TextAntialiasing, True)
        p.setFont(QFont("Consolas", 9))

        # Axis + ticks
        axis_y = h - 22
        p.setPen(QPen(QColor(160, 175, 210, 140), 1))
        p.drawLine(14, axis_y, w - 14, axis_y)

        n_bp = int(max(1.0, x_extent)) + 1
        step = self._choose_tick_step(n_bp)
        last_label_x = -1e9
        for idx in range(0, n_bp, step):
            x = _x_px(float(idx))
            if x < -20 or x > w + 20:
                continue
            p.drawLine(int(x), axis_y, int(x), axis_y + 6)
            if x - last_label_x >= 44:
                p.setPen(QColor(200, 220, 255, 210))
                p.drawText(int(x) + 2, axis_y + 18, str(idx))
                p.setPen(QPen(QColor(160, 175, 210, 140), 1))
                last_label_x = x

        # Guide bracket
        gs = buffers.get("guide_start")
        ge = buffers.get("guide_end")
        if gs is not None and ge is not None:
            x0 = _x_px(float(gs))
            x1 = _x_px(float(ge))
            y = axis_y - 10
            p.setPen(QPen(QColor(120, 210, 255, 210), 2))
            p.drawLine(int(x0), y, int(x1), y)
            p.drawLine(int(x0), y - 4, int(x0), y + 4)
            p.drawLine(int(x1), y - 4, int(x1), y + 4)
            p.setPen(QColor(220, 245, 255, 230))
            p.drawText(int((x0 + x1) * 0.5) - 18, y - 6, "Guide")

        # Cut marker (pulse)
        cut = buffers.get("cut_index")
        if cut is not None:
            x = _x_px(float(cut))
            glow_alpha = 24 + int(24 * pulse)
            if locus_pulse > 1e-6:
                glow_alpha = min(255, glow_alpha + int(150 * locus_pulse))
            glow_w = 14 + int(round(8 * locus_pulse))
            p.setPen(QPen(QColor(255, 160, 90, glow_alpha), glow_w))
            p.drawLine(int(x), 10, int(x), h - 10)
            core_alpha = 170
            if locus_pulse > 1e-6:
                core_alpha = min(255, core_alpha + int(105 * locus_pulse))
            core_w = max(1, 3 + int(round(3 * locus_pulse)))
            p.setPen(QPen(QColor(255, 196, 120, core_alpha), core_w))
            p.drawLine(int(x), 10, int(x), h - 10)
            p.setPen(QColor(255, 236, 160, 230))
            p.drawText(int(x) + 8, 22, f"cut @{int(round(float(cut)))}")

        # Minimal status so the canvas doesn't read as "empty"
        captured = buffers.get("captured_mass")
        total = buffers.get("total_mass")
        pct = None
        try:
            if captured is not None and total is not None and float(total) > 1e-12:
                pct = 100.0 * float(captured) / float(total)
        except Exception:
            pct = None
        p.setPen(QColor(220, 245, 255, 220))
        label = "2.5D Workflow"
        if pct is not None:
            label += f" · captured {pct:.1f}%"
        p.drawText(16, 22, label)

        p.end()

    def _collect_debug_hud_lines(self) -> tuple[str, list[str]]:
        title = "HELIX · Realtime Viz"
        lines: list[str] = []
        if self.engine is None:
            return title, lines

        st = self.engine.state
        phase = getattr(st, "phase", None)
        phase_txt = getattr(phase, "value", str(phase))

        mode = "Flat rails" if self._rail_mode is RailViewMode.FLAT else "3D helix"
        t = float(getattr(st, "time", 0.0))
        loop = float(getattr(self.engine, "loop_duration", 0.0))
        pct = int(round(100.0 * (t / loop))) if loop > 1e-6 else 0

        lines.append(f"Mode: {mode}")
        lines.append(f"Time: {t:.2f}s ({pct}%) · Phase: {phase_txt}")

        if not self._show_debug_overlay:
            lines.append("Press H or enable \"Show rail debug HUD\" to view diagnostics.")
            return title, lines

        try:
            rail_events = len(getattr(self, "_arc_events", []) or [])
        except Exception:
            rail_events = 0
        rail_vertices = int(self._rail_vertex_count or 0)
        gate_domain = "normalized" if bool(getattr(self, "_arc_weights_normalized", False)) else "seconds"
        w_min = self._arc_weight_min
        w_max = self._arc_weight_max
        t_gate_dbg = None
        base_window = min(len(getattr(self._spec, "sequence", "") or ""), getattr(self, "_num_bp", 0) or 0)
        base_mode = "off"
        if self._show_bases:
            if base_window == 0:
                base_mode = "off"
            elif base_window <= self._max_base_glyphs:
                base_mode = "full"
            elif base_window <= self._max_base_glyphs_sparse:
                base_mode = "sparse"
            else:
                base_mode = "too_many"
        try:
            raw_time = float(getattr(self.engine, "state").time)  # type: ignore[attr-defined]
        except Exception:
            raw_time = None
        try:
            loop_dbg = float(getattr(self.engine, "loop_duration", 0.0))
            base_gate = max(0.0, min(1.0, (raw_time or 0.0) / loop_dbg)) if loop_dbg > 1e-6 else 1.0
            weights_norm = self._arc_weights_normalized
            if weights_norm is None:
                weights_norm = bool(getattr(self.engine, "event_times_normalized", False))
            t_gate_dbg = base_gate if weights_norm else (raw_time or 0.0)
        except Exception:
            t_gate_dbg = None
        visible = None
        if self._arc_ranges and self._arc_cpu is not None and t_gate_dbg is not None:
            try:
                visible = sum(1 for (start, _count) in self._arc_ranges if self._arc_cpu[start, 3] <= t_gate_dbg + 1e-6)
            except Exception:
                visible = None
        if self._rail_mode in (RailViewMode.FLAT, RailViewMode.HELIX):
            if rail_events == 0:
                lines.append("Rail events: 0 (instrumented run required)")
            else:
                segs = max(0, rail_vertices // 2)
                lines.append(f"Rail events: {rail_events} · rail vertices: {rail_vertices} (~{segs} segments)")
            lines.append(f"Rail time gate: {gate_domain}")
            if t_gate_dbg is not None:
                lines.append(f"t_gate={t_gate_dbg:.3f}")
            if w_min is not None and w_max is not None:
                lines.append(f"weights=[{w_min:.3f}, {w_max:.3f}]")
            if visible is not None:
                lines.append(f"visible arcs: {visible}/{len(self._arc_ranges)}")
            lines.append(
                f"Bases: {'on' if self._show_bases else 'off'} · window={base_window} · mode={base_mode} · step={int(getattr(self, '_base_overlay_last_step', 1) or 1)}"
                + (
                    f" · spacingPx={float(getattr(self, '_base_overlay_last_spacing_px', 0.0) or 0.0):.1f}"
                    if getattr(self, "_base_overlay_last_spacing_px", None) is not None
                    else ""
                )
                + (f" · fallback={'1' if bool(getattr(self, '_base_overlay_used_fallback', False)) else '0'}")
                + f" · max={self._max_base_glyphs}/{self._max_base_glyphs_sparse}"
            )
            lines.append(
                "GL: "
                f"rail_prog={'ok' if self._rail_program else 'none'} "
                f"arc_prog={'ok' if self._arc_program else 'none'} "
                f"rail_vao={'ok' if self._vao else 'none'} "
                f"arc_vao={'ok' if self._arc_vao else 'none'}"
            )
            if self._gl_error:
                msg = str(self._gl_error)
                if len(msg) > 180:
                    msg = msg[:177] + "..."
                lines.append(f"GL error: {msg}")
        try:
            units = "normalized" if bool(getattr(self.engine, "event_times_normalized", False)) else "seconds"
            src = str(getattr(self.engine, "event_time_units_source", "auto"))
            if src not in {"auto", "explicit"}:
                src = "auto"
            lines.append(f"Event times: {units} ({src})")
        except Exception:
            pass

        if self._rail_mode is RailViewMode.FLAT:
            lines.append("Rails: top=template, bottom=opposite; X = bp across window")
            lines.append("Cut locus pulses; guide bracket shows bind span; arcs = cut/repair")
            lines.append("LMB orbit · RMB pan · Wheel zoom · R reset · Space play/pause")
            lines.append("←/→ jump events · ,/. step frames (Shift=10)")
        else:
            lines.append("Helix view: rails wrapped into 3D; highlight band = selected window")
            lines.append("Orange arc=cut/nick · cyan arc=repair; LMB orbit, RMB/CTRL pan, wheel zoom · Space play/pause")
            lines.append("←/→ jump events · ,/. step frames (Shift=10)")
        return title, lines

    def _paint_hud(self) -> None:
        title, lines = self._collect_debug_hud_lines()

        sink = getattr(self, "_hud_text_sink", None)
        if sink is not None:
            try:
                sink(title, lines)
            except Exception:
                pass

        if getattr(self, "_hud_overlay_mode", "overlay") != "overlay":
            return
        if self.engine is None:
            return

        p = QPainter(self)
        p.setRenderHint(QPainter.TextAntialiasing, True)

        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(10)
        body_font = QFont("Consolas", 9)

        self._draw_hud_block(p, title_font, body_font, lines)
        p.end()

    def _draw_hud_block(self, p: QPainter, title_font: QFont, body_font: QFont, lines: list[str]) -> None:
        p.setFont(title_font)
        fm_title = p.fontMetrics()
        title_width = fm_title.horizontalAdvance("HELIX · Realtime Viz")
        p.setFont(body_font)
        fm_body = p.fontMetrics()
        max_line_width = max([title_width] + [fm_body.horizontalAdvance(ln) for ln in lines])
        line_height = fm_body.height()
        pad_x = 12
        pad_y = 12
        rect_w = max(360, max_line_width + pad_x * 2)
        rect_h = pad_y * 3 + fm_title.height() + line_height * len(lines)
        rect = QRect(16, 16, rect_w, rect_h)

        p.setPen(QColor(120, 160, 255, 60))
        p.setBrush(QColor(10, 14, 24, 175))
        p.drawRoundedRect(rect, 12, 12)

        p.setFont(title_font)
        p.setPen(QColor(245, 248, 255, 235))
        p.drawText(rect.x() + pad_x, rect.y() + pad_y + fm_title.ascent(), "HELIX · Realtime Viz")

        p.setFont(body_font)
        y = rect.y() + pad_y * 2 + fm_title.height()
        for ln in lines:
            p.drawText(rect.x() + pad_x, y + fm_body.ascent(), ln)
            y += line_height

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _trigger_resolve_moment(self) -> None:
        if self._resolve_flash_s > 1e-6 or self._resolve_freeze_s > 1e-6:
            return
        self._resolve_flash_s = 0.5
        self._resolve_freeze_s = 0.5

    def _tick(self) -> None:
        if not getattr(self, "_render_active", True):
            return
        dt = float(self._timeline_dt_s)

        # Camera easing (fast, non-cinematic): used by "Fit to Locus" so the
        # view glides instead of teleporting, without fighting manual drags.
        if (self._cam_ease_target is not None or self._cam_ease_distance is not None) and self._drag_mode is None:
            tau = 0.12
            alpha = 1.0 - math.exp(-max(0.0, dt) / tau)
            alpha = max(0.05, min(0.85, float(alpha)))
            target = self._cam_ease_target
            dist_target = self._cam_ease_distance
            if target is not None:
                try:
                    self._cam_target = self._cam_target + (target - self._cam_target) * alpha
                except Exception:
                    pass
            if dist_target is not None:
                try:
                    self._cam_distance = float(self._cam_distance) + (float(dist_target) - float(self._cam_distance)) * alpha
                except Exception:
                    pass
            try:
                self._update_camera_meta()
            except Exception:
                pass
            # Settle when sufficiently close.
            done = True
            try:
                if target is not None and float(np.linalg.norm(target - self._cam_target)) > 1e-3:
                    done = False
            except Exception:
                pass
            try:
                if dist_target is not None and abs(float(dist_target) - float(self._cam_distance)) > 1e-3:
                    done = False
            except Exception:
                pass
            if done:
                if target is not None:
                    try:
                        self._cam_target = target.astype("f4")
                    except Exception:
                        pass
                if dist_target is not None:
                    try:
                        self._cam_distance = float(dist_target)
                    except Exception:
                        pass
                self._cam_ease_target = None
                self._cam_ease_distance = None
                try:
                    self._update_camera_meta()
                except Exception:
                    pass

        if self._mode == "workflow_2p5d":
            self._overlay_time_s += dt

        if self._resolve_flash_s > 1e-6:
            self._resolve_flash_s = max(0.0, self._resolve_flash_s - dt)
        if self._resolve_freeze_s > 1e-6:
            self._resolve_freeze_s = max(0.0, self._resolve_freeze_s - dt)
        if self._locus_pulse_duration_s > 1e-9:
            try:
                if clock.monotonic() >= float(self._locus_pulse_t0) + float(self._locus_pulse_duration_s):
                    self._locus_pulse_duration_s = 0.0
            except Exception:
                self._locus_pulse_duration_s = 0.0

        if self.engine and self._playing and self._resolve_freeze_s <= 1e-6:
            prev_phase = getattr(self.engine.state, "phase", AnimationPhase.APPROACH)
            dt_sim = dt * max(0.0, float(self._playback_speed))
            state = self.engine.advance(dt_sim)
            self.timeUpdated.emit(state.time)
            self.phaseChanged.emit(state.phase.value)
            if prev_phase != state.phase and state.phase == AnimationPhase.RESOLVE:
                self._trigger_resolve_moment()
        self.update()

    @staticmethod
    def _infer_base_count(helix_geom: Any, spec: Any, fallback_samples: int) -> int:
        """Infer true base pairs from geometry + metadata, not oversampled rails."""

        num_bp = 0
        try:
            base_idx = getattr(helix_geom, "base_indices", None)
            if isinstance(base_idx, np.ndarray):
                num_bp = int(base_idx.shape[0])
            elif base_idx is not None:
                num_bp = int(len(base_idx))
        except Exception:
            num_bp = 0

        if num_bp <= 0:
            try:
                base_centers = getattr(helix_geom, "base_centers", None)
                if isinstance(base_centers, np.ndarray):
                    num_bp = int(base_centers.shape[0])
                elif base_centers is not None:
                    num_bp = int(len(base_centers))
            except Exception:
                num_bp = 0

        if num_bp <= 0 and spec is not None:
            try:
                num_bp = int(len(getattr(spec, "sequence", "") or 0))
            except Exception:
                num_bp = 0

        if num_bp <= 0:
            num_bp = int(fallback_samples)

        return max(0, int(num_bp))

    def _upload_buffers(self) -> None:
        """Upload linear rails and param-space arcs into GPU buffers."""
        if not getattr(self, "_render_active", True):
            return
        if self.ctx is None or self.engine is None:
            self._rail_vertex_count = 0
            self._vao = None
            self._arc_vao = None
            self._arc_heads_vao = None
            self._arc_heads_count = 0
            self._arc_ranges = []
            self._arc_firsts = np.zeros((0,), dtype="i4")
            self._arc_counts = np.zeros((0,), dtype="i4")
            return
        try:
            if self._ctx_id is not None and id(self.ctx) != self._ctx_id:
                self._pending_reset = True
                self._need_rebuild = True
                return
        except Exception:
            pass

        # Use helix_geometry as the authoritative source of base count
        # and helix-space positions.
        helix_geom = self.engine.helix_geometry
        total = int(helix_geom.rail_vertices.shape[0])
        samples_per_strand = total // 2
        if total == 0:
            self._rail_vertex_count = 0
            self._vao = None
            self._arc_vao = None
            self._arc_ranges = []
            self._arc_firsts = np.zeros((0,), dtype="i4")
            self._arc_counts = np.zeros((0,), dtype="i4")
            return

        # Infer the true base count from explicit metadata when available, and
        # fall back to the sequence length instead of the oversampled rail
        # vertex count (which includes segments_per_base and blows up in helix
        # mode).
        num_bp = self._infer_base_count(
            helix_geom,
            getattr(self.engine, "spec", None),
            samples_per_strand,
        )
        self._num_bp = num_bp
        self._bp_positions = None
        self._bp_positions_template = None
        self._bp_positions_opposite = None
        self._helix_reference_bounds = None
        self._highlight_range = None

        if self._rail_mode is RailViewMode.FLAT:
            print(
                "[HelixModernWidget] uploading LINEAR rails:",
                num_bp,
                "bp",
                flush=True,
            )
            # ---- Build straight rails using param_coords from geometry ----
            spacing = float(MODERN_STYLE.flat_rail_spacing)
            params = helix_geom.param_coords.astype("f4").reshape(-1)  # (2N,)
            rail_ids = helix_geom.rail_ids.astype("f4").reshape(-1, 1)  # (2N,1)
            x = (params * 2.0 - 1.0) * 0.9
            y = (rail_ids.flatten() * 2.0 - 1.0) * spacing
            z = np.zeros_like(x, dtype="f4")
            rail_vertices = np.stack([x, y, z], axis=1).astype("f4")
            # Base centers: use base_indices to map into params for accurate positions.
            base_idx = helix_geom.base_indices.astype("f4")
            if base_idx.size == 0 and num_bp > 0:
                base_idx = np.arange(num_bp, dtype="f4")
            base_min = float(base_idx.min()) if base_idx.size else 0.0
            base_max = float(base_idx.max()) if base_idx.size else 1.0
            denom = max(1e-6, base_max - base_min)
            t_base = (base_idx - base_min) / denom
            x_base = (t_base * 2.0 - 1.0) * 0.9
            z_base = np.zeros_like(x_base, dtype="f4")
            y_top = np.full_like(x_base, spacing)
            y_bot = np.full_like(x_base, -spacing)
            self._bp_positions = np.stack([x_base, y_top, z_base], axis=1).astype("f4")
            self._bp_positions_opposite = np.stack([x_base, y_bot, z_base], axis=1).astype("f4")
            self._bp_positions_template = None
            self._helix_reference_bounds = None

            # For flat rails we keep param coordinates matching the VBO layout.
            param_coords = params.reshape(-1, 1).astype("f4")
        else:
            print(
                "[HelixModernWidget] uploading HELIX rails:",
                num_bp,
                "bp",
                flush=True,
            )
            # ---- Build a proper double helix in 3D ----
            samples = max(2, min(MAX_HELIX_SAMPLES, num_bp * HELIX_SAMPLES_PER_BP))
            t = np.linspace(0.0, 1.0, samples, dtype="f4")  # param along genome (oversampled for smoothness)

            # Turns along this window (~1 turn per 10 bases).
            turns = max(1.0, num_bp / 10.0)
            theta = t * turns * 2.0 * math.pi

            radius = 1.0
            height = 0.34 * num_bp
            z = (t - 0.5) * height

            # Strand A
            x_a = radius * np.cos(theta)
            y_a = radius * np.sin(theta)
            strand_a = np.stack([x_a, y_a, z], axis=1)

            # Strand B: 180° out of phase
            x_b = radius * np.cos(theta + math.pi)
            y_b = radius * np.sin(theta + math.pi)
            strand_b = np.stack([x_b, y_b, z], axis=1)

            rail_vertices = np.vstack([strand_a, strand_b]).astype("f4")
            # Map base index → 3D position on strand A
            idx_param = np.linspace(0.0, 1.0, num_bp, dtype="f4")
            lut_idx = np.clip((idx_param * (samples - 1)).astype(int), 0, samples - 1)
            self._bp_positions = strand_a[lut_idx]
            self._bp_positions_opposite = strand_b[lut_idx]
            self._bp_positions_template = strand_b[lut_idx]
            try:
                xy_radius = float(np.max(np.sqrt(x_a * x_a + y_a * y_a))) if samples > 0 else 1.0
            except Exception:
                xy_radius = 1.0
            self._helix_reference_bounds = (
                float(np.min(z)) if samples > 0 else 0.0,
                float(np.max(z)) if samples > 0 else 0.0,
                max(1.0, float(xy_radius)),
            )

            rail_ids = np.zeros((2 * samples, 1), dtype="f4")
            rail_ids[samples:, 0] = 1.0

            param_coords = np.concatenate([t, t], axis=0).reshape(-1, 1).astype("f4")

        # Interleave: [pos.xyz, rail_id, param]
        self._world_rail_vertices = rail_vertices
        combined = np.hstack([rail_vertices, rail_ids, param_coords]).astype("f4")
        self._rail_vertex_count = combined.shape[0]

        if self._rail_vbo is None:
            self._rail_vbo = self.ctx.buffer(combined.tobytes())
        else:
            self._rail_vbo.orphan(combined.nbytes)
            self._rail_vbo.write(combined.tobytes())

        self._vao = None
        if self._rail_program is None:
            self._gl_error = (self._gl_error or "") + " | rail_program_missing"
        else:
            try:
                self._vao = self.ctx.vertex_array(
                    self._rail_program,
                    [
                        (self._rail_vbo, "3f 1f 1f", "in_pos", "in_rail", "in_param"),
                    ],
                )
            except Exception as exc:
                self._vao = None
                self._gl_error = (self._gl_error or "") + f" | rail_vao: {exc}"

        # ------------------------------------------------------------------
        # Param-space arcs: build ribbons directly from the spec.
        # ------------------------------------------------------------------
        self._arc_vao = None
        self._arc_heads_vao = None
        self._arc_heads_count = 0
        self._arc_ranges = []
        self._arc_firsts = np.zeros((0,), dtype="i4")
        self._arc_counts = np.zeros((0,), dtype="i4")
        self._arc_cpu = None
        self._arc_events = []
        self._arc_confidence = []
        self._arc_weights_normalized = None
        self._arc_weight_min = None
        self._arc_weight_max = None

        spec = self._spec
        if spec is None or self._arc_program is None:
            return

        interleaved, arc_ranges, head_interleaved = HelixModernWidget._build_param_ribbons_from_spec(spec)
        if interleaved.size == 0 or not arc_ranges:
            return

        self._arc_events = HelixModernWidget._select_param_ribbon_events(spec)
        # Per-arc confidence list (used as uniform during render; keep event times in buffers)
        self._arc_confidence = []
        if self._arc_events:
            try:
                for ev in self._arc_events:
                    try:
                        self._arc_confidence.append(event_confidence(ev, spec))
                    except Exception:
                        self._arc_confidence.append(0.5)
            except Exception:
                self._arc_confidence = []
        self._arc_cpu = interleaved
        try:
            if interleaved.size > 0:
                w_min = float(np.min(interleaved[:, 3]))
                w_max = float(np.max(interleaved[:, 3]))
                self._arc_weight_min = w_min
                self._arc_weight_max = w_max
                # Heuristic: <=1.1 means normalized (0..1), otherwise seconds.
                self._arc_weights_normalized = w_max <= 1.1 and w_min >= -0.1
        except Exception:
            self._arc_weights_normalized = None
            self._arc_weight_min = None
            self._arc_weight_max = None

        if self._arc_vbo is None:
            self._arc_vbo = self.ctx.buffer(interleaved.tobytes())
        else:
            self._arc_vbo.orphan(interleaved.nbytes)
            self._arc_vbo.write(interleaved.tobytes())

        try:
            self._arc_vao = self.ctx.vertex_array(
                self._arc_program,
                [
                    (self._arc_vbo, "3f 1f 1f", "in_pos", "in_weight", "in_kind"),
                ],
            )
        except Exception as exc:
            self._arc_vao = None
            self._gl_error = (self._gl_error or "") + f" | arc_vao: {exc}"

        # Arrowhead geometry
        if head_interleaved is not None:
            if self._arc_heads_vbo is None:
                self._arc_heads_vbo = self.ctx.buffer(head_interleaved.tobytes())
            else:
                self._arc_heads_vbo.orphan(head_interleaved.nbytes)
                self._arc_heads_vbo.write(head_interleaved.tobytes())

            try:
                self._arc_heads_vao = self.ctx.vertex_array(
                    self._arc_program,
                    [(self._arc_heads_vbo, "3f 1f 1f", "in_pos", "in_weight", "in_kind")],
                )
                self._arc_heads_count = head_interleaved.shape[0]
            except Exception as exc:
                self._arc_heads_vao = None
                self._arc_heads_count = 0
                self._gl_error = (self._gl_error or "") + f" | arc_heads_vao: {exc}"
        else:
            self._arc_heads_vao = None
            self._arc_heads_count = 0

        self._arc_ranges = arc_ranges
        if arc_ranges:
            firsts = [start for start, _ in arc_ranges]
            counts = [count for _, count in arc_ranges]
            self._arc_firsts = np.array(firsts, dtype="i4")
            self._arc_counts = np.array(counts, dtype="i4")

    def _upload_workflow_buffers(self) -> None:
        """Upload 2.5D workflow geometry (bars, heat, rail, ticks)."""
        if not getattr(self, "_render_active", True):
            return
        if self.ctx is None or not self._workflow_buffers:
            self._bars_vao = None
            self._workflow_instance_count = 0
            self._workflow_rail_vbo = None
            self._workflow_tick_vbo = None
            self._heat_vao = None
            self._slice_vao = None
            return
        try:
            if self._ctx_id is not None and id(self.ctx) != self._ctx_id:
                self._pending_reset = True
                self._need_rebuild = True
                return
        except Exception:
            pass

        buffers = self._workflow_buffers

        # Bars (instanced quads)
        inst = buffers.get("inst_events")
        if inst is not None and inst.size:
            data = inst.astype("f4")
            col0 = data[:, :4].astype("f4")
            col1 = data[:, 4:].astype("f4")

            if self._bars_inst0_vbo is None:
                self._bars_inst0_vbo = self.ctx.buffer(col0.tobytes())
            else:
                self._bars_inst0_vbo.orphan(col0.nbytes)
                self._bars_inst0_vbo.write(col0.tobytes())

            if self._bars_inst1_vbo is None:
                self._bars_inst1_vbo = self.ctx.buffer(col1.tobytes())
            else:
                self._bars_inst1_vbo.orphan(col1.nbytes)
                self._bars_inst1_vbo.write(col1.tobytes())

            if self._bars_unit_vbo is None:
                unit = np.array(
                    [
                        [-0.5, -0.5],
                        [0.5, -0.5],
                        [0.5, 0.5],
                        [-0.5, -0.5],
                        [0.5, 0.5],
                        [-0.5, 0.5],
                    ],
                    dtype="f4",
                )
                self._bars_unit_vbo = self.ctx.buffer(unit.tobytes())

            self._bars_vao = self.ctx.vertex_array(
                self._bars_prog,
                [
                    (self._bars_unit_vbo, "2f", "in_unit"),      # per-vertex
                    (self._bars_inst0_vbo, "4f/i", "in_box0"),   # per-instance
                    (self._bars_inst1_vbo, "3f/i", "in_box1"),   # per-instance
                ],
            )
            self._workflow_instance_count = data.shape[0]
        else:
            self._bars_vao = None
            self._workflow_instance_count = 0

        # Heat strip
        heat = buffers.get("heat_values")
        if (
            heat is not None
            and self._heat_prog is not None
            and heat.size >= 2
        ):
            values = np.asarray(heat, dtype="f4").flatten()
            y = float(buffers.get("heat_y", -1.0))
            height = float(buffers.get("heat_height", 0.6))
            verts = np.zeros((values.shape[0] * 2, 4), dtype="f4")
            for i, val in enumerate(values):
                x = float(i)
                verts[2 * i] = (x, y, -0.5, val)
                verts[2 * i + 1] = (x, y + height, -0.5, val)

            if self._heat_vbo is None:
                self._heat_vbo = self.ctx.buffer(verts.tobytes())
            else:
                self._heat_vbo.orphan(verts.nbytes)
                self._heat_vbo.write(verts.tobytes())

            self._heat_vao = self.ctx.vertex_array(
                self._heat_prog,
                [
                    (self._heat_vbo, "3f 1f", "in_pos", "in_value"),
                ],
            )
            self._heat_vertex_count = verts.shape[0]
        else:
            self._heat_vao = None
            self._heat_vertex_count = 0

        # Cut marker slice
        cut_index = buffers.get("cut_index")
        if cut_index is not None and self._flat_prog is not None:
            cut = float(cut_index)
            width = float(buffers.get("slice_width", 0.12))
            extent = float(buffers.get("y_extent", 4.0)) + 1.0
            y_min = -extent
            y_max = extent
            data = np.array(
                [
                    [cut - width * 0.5, y_min, -0.4],
                    [cut - width * 0.5, y_max, -0.4],
                    [cut + width * 0.5, y_min, -0.4],
                    [cut + width * 0.5, y_max, -0.4],
                ],
                dtype="f4",
            )
            if self._slice_vbo is None:
                self._slice_vbo = self.ctx.buffer(data.tobytes())
            else:
                self._slice_vbo.orphan(data.nbytes)
                self._slice_vbo.write(data.tobytes())
            self._slice_vao = self.ctx.vertex_array(
                self._flat_prog,
                [(self._slice_vbo, "3f", "in_pos")],
            )
        else:
            self._slice_vao = None

        # Workflow rail line
        rail = buffers.get("rail_xy")
        if rail is not None and rail.size:
            rail_xy = np.asarray(rail, dtype="f4").reshape(-1, 2)
            z = np.zeros((rail_xy.shape[0], 1), dtype="f4")
            data = np.hstack([rail_xy, z])
            if self._workflow_rail_vbo is None:
                self._workflow_rail_vbo = self.ctx.buffer(data.tobytes())
            else:
                self._workflow_rail_vbo.orphan(data.nbytes)
                self._workflow_rail_vbo.write(data.tobytes())
        else:
            self._workflow_rail_vbo = None

        # Workflow tick marks
        ticks = buffers.get("tick_xy")
        if ticks is not None and ticks.size:
            tick_xy = np.asarray(ticks, dtype="f4").reshape(-1, 2)
            z = np.zeros((tick_xy.shape[0], 1), dtype="f4")
            data = np.hstack([tick_xy, z])
            if self._workflow_tick_vbo is None:
                self._workflow_tick_vbo = self.ctx.buffer(data.tobytes())
            else:
                self._workflow_tick_vbo.orphan(data.nbytes)
                self._workflow_tick_vbo.write(data.tobytes())
        else:
            self._workflow_tick_vbo = None

    def _bp_to_x(self, idx: int) -> float:
        if self._num_bp <= 1:
            return 0.0
        t = max(0.0, min(1.0, float(idx) / float(self._num_bp - 1)))
        return (t * 2.0 - 1.0) * 0.9

    def _build_highlight_quad(self) -> None:
        if self.ctx is None or self._highlight_range is None:
            self._highlight_vao = None
            return
        if self._flat_prog is None:
            return
        a, b = self._highlight_range
        start = min(a, b)
        end = max(a, b)
        x0 = self._bp_to_x(start)
        x1 = self._bp_to_x(end)
        width_pad = 0.0
        x0 -= width_pad
        x1 += width_pad
        y_min, y_max = -0.6, 0.6
        data = np.array(
            [
                [x0, y_min, -0.3],
                [x0, y_max, -0.3],
                [x1, y_min, -0.3],
                [x1, y_max, -0.3],
            ],
            dtype="f4",
        )
        if self._highlight_vbo is None:
            self._highlight_vbo = self.ctx.buffer(data.tobytes())
        else:
            self._highlight_vbo.orphan(data.nbytes)
            self._highlight_vbo.write(data.tobytes())
        self._highlight_vao = self.ctx.vertex_array(
            self._flat_prog,
            [(self._highlight_vbo, "3f", "in_pos")],
        )

    def _mvp_matrix(self, aspect: float, orbit_time: float) -> np.ndarray:
        # Simple 2D zoom/pan based on _cam_distance and _cam_target.x/y
        scale = 1.0 / self._cam_distance
        tx, ty, _ = self._cam_target

        m = np.identity(4, dtype="f4")
        m[0, 0] = scale
        m[1, 1] = scale
        m[0, 3] = -tx * scale
        m[1, 3] = -ty * scale
        return m

    @staticmethod
    def _gl_mat4(m: np.ndarray) -> bytes:
        """Convert row-major numpy mat4 to column-major bytes for GL uniforms."""
        return np.ascontiguousarray(m.T, dtype="f4").tobytes()

    # ------------------------------------------------------------------
    # Workflow 2.5D renderer
    # ------------------------------------------------------------------
    def _render_workflow(self) -> None:
        if self.ctx is None or not self._workflow_buffers:
            return

        w = max(1, self.width())
        h = max(1, self.height())
        dpr = self._device_pixel_ratio()
        fb_w, fb_h = _framebuffer_size_px(logical_w=w, logical_h=h, dpr=dpr)

        buffers = self._workflow_buffers
        x_extent = float(buffers.get("x_extent", 1.0))
        y_extent = float(buffers.get("y_extent", 4.0))
        full_left, full_right = -1.0, x_extent + 1.0
        full_span = max(1e-6, float(full_right) - float(full_left))
        # Reuse window pan/zoom fields as the workflow "camera" so Workflow2p5DPanel
        # can persist and restore it via get_view_state/apply_view_state.
        span_x = float(self._window_zoom_bp) if float(self._window_zoom_bp) > 0.0 else full_span
        span_x = max(1.0, min(full_span, float(span_x)))
        center_x = float(self._window_pan_bp) if float(self._window_zoom_bp) > 0.0 else float(x_extent) * 0.5
        center_x = max(0.0, min(float(x_extent), float(center_x)))
        left = float(center_x) - float(span_x) * 0.5
        right = float(center_x) + float(span_x) * 0.5
        if left < full_left:
            right += float(full_left) - float(left)
            left = full_left
        if right > full_right:
            left -= float(right) - float(full_right)
            right = full_right
        bottom, top = -y_extent - 0.5, y_extent + 1.5

        mvp = self._ortho_mvp(left, right, bottom, top)
        self._workflow_last_mvp = mvp
        try:
            rail_y_val = float(buffers.get("rail_xy", [[0.0, 0.0, 0.0]])[0][1])
            self._workflow_rail_y = rail_y_val
        except Exception:
            self._workflow_rail_y = 0.0
        px_scale = np.array(
            [
                (right - left) / max(1.0, float(fb_w)),
                (top - bottom) / max(1.0, float(fb_h)),
            ],
            dtype="f4",
        )

        # Heat bar
        if self._heat_vao and self._heat_vertex_count:
            self._heat_prog["u_mvp"].write(self._gl_mat4(mvp))
            self._heat_prog["u_color_low"].value = (0.08, 0.14, 0.28)
            self._heat_prog["u_color_high"].value = (0.98, 0.53, 0.18)
            self._heat_vao.render(mode=moderngl.TRIANGLE_STRIP, vertices=self._heat_vertex_count)

        # Bars
        if self._bars_vao and self._workflow_instance_count:
            self._bars_prog["u_mvp"].write(self._gl_mat4(mvp))
            self._bars_prog["u_px2world"].write(px_scale.tobytes())
            self._bars_vao.render(mode=moderngl.TRIANGLES, instances=self._workflow_instance_count)

        # Cut slice
        if self._slice_vao:
            self._flat_prog["u_mvp"].write(self._gl_mat4(mvp))
            pulse = 0.45 + 0.25 * (0.5 + 0.5 * math.sin(float(self._overlay_time_s) * 4.0))
            pulse += 0.25 * float(self._locus_pulse_amount())
            pulse = max(0.0, min(1.0, float(pulse)))
            self._flat_prog["u_color"].value = (1.0, 0.55, 0.18, float(pulse))
            self._slice_vao.render(mode=moderngl.TRIANGLE_STRIP)

        # Rail line
        if self._workflow_rail_vbo is not None:
            rail_vao = self.ctx.vertex_array(
                self._rail_program,
                [(self._workflow_rail_vbo, "3f", "in_pos")],
            )
            self._rail_program["u_mvp"].write(self._gl_mat4(mvp))
            self._rail_program["u_time"].value = 0.0
            self._rail_program["u_phase"].value = 0.0
            self._rail_program["u_template"].value = 1.0
            self._rail_program["u_glow"].value = 0.0
            if "u_hi_t0" in self._rail_program and "u_hi_t1" in self._rail_program:
                self._rail_program["u_hi_t0"].value = -1.0
                self._rail_program["u_hi_t1"].value = -1.0
            # Do NOT unwrap workflow lines (already XY)
            self._rail_program["u_flat"].value = 0.0
            self._rail_program["u_spacing"].value = 0.35
            rail_vao.render(mode=moderngl.LINE_STRIP)

        # Tick marks
        if self._workflow_tick_vbo is not None:
            tick_vao = self.ctx.vertex_array(
                self._rail_program,
                [(self._workflow_tick_vbo, "3f", "in_pos")],
            )
            self._rail_program["u_flat"].value = 0.0
            self._rail_program["u_spacing"].value = 0.6
            tick_vao.render(mode=moderngl.LINES)

        # Field-based genome lanes (PAM, prime DP)
        if self._genome_scene is not None:
            try:
                self._genome_scene.render(int(fb_w), int(fb_h))
            except Exception:
                pass

    # --- Genome lane helpers -------------------------------------------------

    def set_tile_context(self, chrom: str, tile_start_bp: int, tile_seq: str) -> None:
        self._current_chrom = chrom
        self._current_tile_start = tile_start_bp
        self._current_tile_seq = tile_seq
        self._invalidate_pam_seed()
        self._invalidate_prime_dp()
        self._invalidate_indel_risk()
        self._invalidate_offtarget()
        self._invalidate_composite()
        self._invalidate_gc()
        self._invalidate_dcas()
        self._invalidate_gc()

    def set_guide_context(self, guide_ctx: GuideContext | None) -> None:
        self._guide_ctx = guide_ctx
        self._invalidate_pam_seed()
        self._invalidate_offtarget()
        self._invalidate_composite()
        self._invalidate_gc()
        self._invalidate_dcas()
        self._invalidate_gc()

    def set_prime_context(self, prime_ctx: PrimeContext | None) -> None:
        self._prime_ctx = prime_ctx
        self._invalidate_prime_dp()
        self._invalidate_composite()
        self._invalidate_gc()
        self._invalidate_dcas()

    def set_pam_seed_enabled(self, enabled: bool) -> None:
        if self._genome_scene is not None:
            self._genome_scene.set_pam_seed_enabled(enabled)
        self.update()

    def set_prime_dp_enabled(self, enabled: bool) -> None:
        if self._genome_scene is not None:
            self._genome_scene.set_prime_dp_enabled(enabled)
        self.update()

    def set_indel_risk_enabled(self, enabled: bool) -> None:
        if self._genome_scene is not None:
            self._genome_scene.set_indel_risk_enabled(enabled)
        self.update()

    def set_offtarget_enabled(self, enabled: bool) -> None:
        if self._genome_scene is not None:
            self._genome_scene.set_offtarget_enabled(enabled)
        self.update()

    def set_gc_enabled(self, enabled: bool) -> None:
        if self._genome_scene is not None:
            self._genome_scene.set_gc_enabled(enabled)
        self.update()

    def set_dcas_enabled(self, enabled: bool) -> None:
        if self._genome_scene is not None:
            self._genome_scene.set_dcas_enabled(enabled)
        self.update()

    def set_composite_enabled(self, enabled: bool) -> None:
        if self._genome_scene is not None:
            self._genome_scene.set_composite_enabled(enabled)
        self.update()

    def _invalidate_pam_seed(self) -> None:
        if self._genome_scene is None:
            return
        if self._guide_ctx is None:
            return
        if self._current_chrom is None or self._current_tile_seq is None:
            return

        try:
            self._genome_scene.update_pam_seed_field(
                chrom=self._current_chrom,
                tile_start_bp=self._current_tile_start,
                tile_seq=self._current_tile_seq,
                guide_seq=self._guide_ctx.guide_seq,
                pam_pattern=self._guide_ctx.pam_pattern,
            )
            self.update()
        except Exception:
            pass

    def _invalidate_prime_dp(self) -> None:
        if self._genome_scene is None:
            return
        if self._prime_ctx is None:
            return
        if self._current_chrom is None or self._current_tile_seq is None:
            return

        try:
            self._genome_scene.update_prime_dp_field(
                chrom=self._current_chrom,
                tile_start_bp=self._current_tile_start,
                tile_seq=self._current_tile_seq,
                prime_ctx=self._prime_ctx,
            )
            self.update()
        except Exception:
            pass

    def _invalidate_indel_risk(self) -> None:
        if self._genome_scene is None:
            return
        if self._current_chrom is None or self._current_tile_seq is None:
            return
        try:
            self._genome_scene.update_indel_risk_field(
                chrom=self._current_chrom,
                tile_start_bp=self._current_tile_start,
                tile_seq=self._current_tile_seq,
            )
            self.update()
        except Exception:
            pass

    def _invalidate_offtarget(self) -> None:
        if self._genome_scene is None:
            return
        if self._guide_ctx is None:
            return
        if self._current_chrom is None or self._current_tile_seq is None:
            return
        try:
            self._genome_scene.update_offtarget_field(
                chrom=self._current_chrom,
                tile_start_bp=self._current_tile_start,
                tile_seq=self._current_tile_seq,
                guide_seq=self._guide_ctx.guide_seq,
                pam_pattern=self._guide_ctx.pam_pattern,
            )
            self.update()
        except Exception:
            pass

    def _invalidate_gc(self) -> None:
        if self._genome_scene is None:
            return
        if self._current_chrom is None or self._current_tile_seq is None:
            return
        try:
            self._genome_scene.update_gc_field(
                chrom=self._current_chrom,
                tile_start_bp=self._current_tile_start,
                tile_seq=self._current_tile_seq,
            )
            self.update()
        except Exception:
            pass

    def _invalidate_dcas(self) -> None:
        if self._genome_scene is None:
            return
        if self._guide_ctx is None:
            return
        if self._current_chrom is None or self._current_tile_seq is None:
            return
        try:
            self._genome_scene.update_dcas_field(
                chrom=self._current_chrom,
                tile_start_bp=self._current_tile_start,
                tile_seq=self._current_tile_seq,
                guide_seq=self._guide_ctx.guide_seq,
                pam_pattern=self._guide_ctx.pam_pattern,
            )
            self.update()
        except Exception:
            pass
    def _invalidate_composite(self) -> None:
        if self._genome_scene is None:
            return
        if self._current_chrom is None or self._current_tile_seq is None:
            return
        try:
            self._genome_scene.update_composite_field(
                chrom=self._current_chrom,
                tile_start_bp=self._current_tile_start,
                tile_seq=self._current_tile_seq,
            )
            self.update()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Math / camera helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _look_at(eye: np.ndarray, target: np.ndarray, up: np.ndarray) -> np.ndarray:
        f = target - eye
        f /= max(np.linalg.norm(f), 1e-6)
        u = up / max(np.linalg.norm(up), 1e-6)
        s = np.cross(f, u)
        s /= max(np.linalg.norm(s), 1e-6)
        u = np.cross(s, f)

        m = np.identity(4, dtype="f4")
        m[0, :3] = s
        m[1, :3] = u
        m[2, :3] = -f
        translate = np.identity(4, dtype="f4")
        translate[:3, 3] = -eye
        return m @ translate

    @staticmethod
    def _perspective(fovy: float, aspect: float, z_near: float, z_far: float) -> np.ndarray:
        f = 1.0 / math.tan(fovy / 2.0)
        m = np.zeros((4, 4), dtype="f4")
        m[0, 0] = f / aspect
        m[1, 1] = f
        m[2, 2] = (z_far + z_near) / (z_near - z_far)
        m[2, 3] = (2 * z_far * z_near) / (z_near - z_far)
        m[3, 2] = -1.0
        return m

    @staticmethod
    def _ortho_mvp(left: float, right: float, bottom: float, top: float,
                   near: float = -5.0, far: float = 5.0) -> np.ndarray:
        m = np.identity(4, dtype="f4")
        m[0, 0] = 2.0 / (right - left)
        m[1, 1] = 2.0 / (top - bottom)
        m[2, 2] = -2.0 / (far - near)
        m[0, 3] = -(right + left) / (right - left)
        m[1, 3] = -(top + bottom) / (top - bottom)
        m[2, 3] = -(far + near) / (far - near)
        return m

    @staticmethod
    def _phase_value(phase: AnimationPhase) -> float:
        mapping = {
            AnimationPhase.APPROACH: 0.0,
            AnimationPhase.RECOGNITION: 0.2,
            AnimationPhase.CUT: 0.4,
            AnimationPhase.PRIME: 0.6,
            AnimationPhase.REPAIR: 0.8,
            AnimationPhase.RESOLVE: 1.0,
        }
        return mapping.get(phase, 0.0)

    # ------------------------------------------------------------------
    # Interaction events (unchanged)
    # ------------------------------------------------------------------
    # ... keep your existing mousePressEvent / mouseMoveEvent / wheelEvent /
    # keyPressEvent / _reset_camera_defaults / _update_camera_meta / _assert_geometry
    # exactly as you have them now – they’ll work with this core.

    # ------------------------------------------------------------------
    # Shader sources (unchanged from your latest version)
    # ------------------------------------------------------------------
    @staticmethod
    def _rail_vertex_shader() -> str:
        return """
        #version 330
        layout (location = 0) in vec3  in_pos;
        layout (location = 1) in float in_rail;   // 0.0 (strand A) or 1.0 (strand B)
        layout (location = 2) in float in_param;  // 0..1 along the strand

        uniform mat4  u_mvp;
        uniform float u_time;
        uniform float u_phase;
        uniform float u_template;
        uniform float u_hi_t0;
        uniform float u_hi_t1;

        // NEW: 1.0 => unwrap to linear rails, 0.0 => draw the true helix positions
        uniform float u_flat;
        // NEW: half-distance between the two rails when flat
        uniform float u_spacing;

        out vec3  v_world;
        out float v_param;
        out float v_rail;
        out float v_phase;
        out float v_hi_mask;

        void main() {
            vec3 pos = in_pos;

            // When flat, map param to x in [-0.9, 0.9], y to +/- spacing, z = 0
            if (u_flat > 0.5) {
                float x = (in_param * 2.0 - 1.0) * 0.9;
                float y = (in_rail * 2.0 - 1.0) * u_spacing;
                pos = vec3(x, y, 0.0);
            }

            gl_Position = u_mvp * vec4(pos, 1.0);

            // Keep varyings for fragment shader effects
            v_world = pos;
            v_param = in_param;
            v_rail  = clamp(in_rail, 0.0, 1.0);
            v_phase = u_phase;
            bool hi = (u_hi_t0 >= 0.0 && u_hi_t1 >= 0.0 && v_param >= u_hi_t0 && v_param <= u_hi_t1);
            v_hi_mask = hi ? 1.0 : 0.0;
        }
        """

    @staticmethod
    def _rail_fragment_shader() -> str:
        return """
        #version 330
        in vec3  v_world;
        in float v_param;
        in float v_rail;
        in float v_phase;
        in float v_hi_mask;

        uniform float u_template;
        uniform float u_time;
        uniform float u_phase;
        uniform float u_glow;
        uniform float u_flat;

        out vec4 f_color;

        vec3 strand_color(float rail) {
            vec3 color_a = vec3(0.98, 0.42, 0.24);
            vec3 color_b = vec3(0.16, 0.72, 0.96);
            return mix(color_a, color_b, clamp(rail, 0.0, 1.0));
        }

        void main() {
            float ripple = sin(v_param * 12.0 + u_time * 2.0 + v_phase);
            float sweep = cos(v_world.z * 4.0 + u_time * 0.8);
            float pulse = 0.6 + 0.4 * ripple;
            vec3 base = strand_color(v_rail);
            vec3 highlight = mix(base, vec3(0.95, 0.99, 1.0), 0.15 + 0.15 * sweep);
            vec3 color = highlight * pulse;

            float alpha = mix(0.08, 0.95, clamp(u_template, 0.0, 1.0));
            // In flat mode, keep rails fully legible; in helix mode keep soft fog.
            if (u_flat > 0.5) {
                alpha = max(alpha, 0.65);
            }
            // Gentle, bounded fog that keeps the helix visible
            float z = clamp(gl_FragCoord.z, 0.0, 1.0);
            float f = smoothstep(0.15, 0.95, z);   // 0 near, 1 far
            float fog = max(1.0 - f, 0.35);        // never vanish
            vec3 bg = vec3(0.02, 0.04, 0.08);
            color = mix(bg, color, fog);
            alpha *= (0.65 + 0.35 * fog);          // nudge alpha, don't crush it

            // Optional glow pass support: brighten but thin the alpha
            if (u_glow > 0.5) {
                color *= 1.25;
                alpha *= 0.25;
            }
            if (v_hi_mask > 0.5) {
                if (u_glow > 0.5) {
                    color = mix(color, vec3(1.0, 0.95, 0.75), 0.7);
                    alpha = min(1.0, alpha * 1.8);
                } else {
                    color = mix(color, vec3(1.0, 0.95, 0.75), 0.4);
                    alpha = min(1.0, alpha * 1.3);
                }
            }
            f_color = vec4(color, alpha);
        }
        """

    @staticmethod
    def _arc_vertex_shader() -> str:
        return """
        #version 330
        in vec3  in_pos;
        in float in_weight;
        in float in_kind;
        uniform mat4 u_mvp;
        uniform float u_time;
        out float v_weight;
        out float v_kind;
        void main() {
            vec3 pos = in_pos;
            // Remove global breathing scale so arc endpoints stay glued to rails
            // pos *= 1.02 + sin(u_time * 1.5) * 0.03;
            gl_Position = u_mvp * vec4(pos, 1.0);
            v_weight = in_weight;
            v_kind = in_kind;
        }
        """

    @staticmethod
    def _arc_fragment_shader() -> str:
        return """
        #version 330
        uniform float u_flap;
        uniform float u_t_gate;
        uniform float u_confidence;
        uniform float u_selected_kind;
        in float v_weight;
        in float v_kind;
        out vec4 f_color;
        vec3 kind_color(float k) {
            if (k < 0.5) return vec3(0.98, 0.65, 0.22);
            if (k < 1.5) return vec3(0.92, 0.33, 0.82);
            if (k < 2.5) return vec3(0.26, 0.86, 0.98);
            if (k < 3.5) return vec3(0.20, 0.40, 0.55);
            return vec3(0.76, 0.65, 0.92);
        }
        void main() {
            // Time gating: discard ribbons whose event time is in the future.
            if (v_weight > u_t_gate) {
                discard;
            }
            float alpha = 0.95 * u_flap;
            float confidence = clamp(u_confidence, 0.0, 1.0);
            alpha *= mix(0.35, 1.0, confidence);

            vec3 color = kind_color(v_kind);
            // Subtle glow toward higher confidence
            color = mix(color, vec3(1.0, 0.98, 0.88), 0.12 * confidence);

            if (u_selected_kind > -0.5 && abs(v_kind - u_selected_kind) < 0.5) {
                color = mix(color, vec3(1.0, 1.0, 1.0), 0.4);
            }
            f_color = vec4(color, alpha);
        }
        """

    @staticmethod
    def _select_param_ribbon_events(spec: EditVisualizationSpec) -> list[EditEvent]:
        if not getattr(spec, "events", None):
            return []
        cut_ev: EditEvent | None = None
        repair_ev: EditEvent | None = None
        for ev in spec.events:
            if cut_ev is None and ev.type in (EditEventType.NICK_PRIMARY, EditEventType.CUT):
                cut_ev = ev
            if repair_ev is None and ev.type is EditEventType.REPAIR_COMPLETE:
                repair_ev = ev
        chosen = [ev for ev in (cut_ev, repair_ev) if ev is not None]
        if not chosen:
            return []

        def _kind_code(ev: EditEvent) -> float:
            if ev.type in (EditEventType.NICK_PRIMARY, EditEventType.CUT):
                return 0.0
            if ev.type is EditEventType.REPAIR_COMPLETE:
                return 2.0
            return 9.0

        def _idx(ev: EditEvent) -> int:
            idx = ev.index if ev.index is not None else ev.start
            return int(idx) if idx is not None else -1

        # Stable ordering: later-terminating arcs draw first (behind earlier arcs).
        return sorted(
            chosen,
            key=lambda ev: (-float(getattr(ev, "t", 0.0)), _kind_code(ev), _idx(ev)),
        )

    @staticmethod
    def _build_param_ribbons_from_spec(
        spec: EditVisualizationSpec,
    ) -> tuple[np.ndarray, list[tuple[int, int]], np.ndarray | None]:
        """Pure helper that builds param-space ribbon geometry from a viz spec.

        Returns:
            interleaved: (N, 5) float32 array [pos.xyz, event_time, kind_code]
            arc_ranges: list of (first, count) index ranges per ribbon
            head_interleaved: (M, 5) float32 array for arrowheads, or None
        """
        if not getattr(spec, "events", None):
            return np.zeros((0, 5), dtype="f4"), [], None

        seq_len = len(spec.sequence)
        if seq_len <= 1:
            return np.zeros((0, 5), dtype="f4"), [], None

        denom = max(1, seq_len - 1)
        rail_spacing = float(MODERN_STYLE.flat_rail_spacing)
        y_top = rail_spacing
        y_bottom = -rail_spacing
        base_z = -0.05

        chosen = HelixModernWidget._select_param_ribbon_events(spec)
        if not chosen:
            return np.zeros((0, 5), dtype="f4"), [], None

        # Debug invariant: if times are declared normalized, all events must be within [0, 1].
        try:
            time_units = str(getattr(spec, "time_units", "")).lower()
            if __debug__ and time_units == "normalized":
                for ev in chosen:
                    t_evt = float(getattr(ev, "t", 0.0))
                    if not (0.0 <= t_evt <= 1.0):
                        raise ValueError(f"Rail event time not normalized: t={t_evt}")
        except Exception:
            # Keep rendering even if invariant trips in production; tests will surface in debug.
            pass

        verts_list: list[np.ndarray] = []
        weights_list: list[np.ndarray] = []
        kinds_list: list[np.ndarray] = []
        arc_ranges: list[tuple[int, int]] = []
        cursor = 0

        # Stacking: fan ribbons that share a locus
        stack_bins: dict[int, int] = {}
        stack_dx = 0.03
        stack_dh = 0.05

        for ev in chosen:
            # Determine a base genome index
            if getattr(ev, "index", None) is not None:
                idx = int(ev.index)
            elif getattr(ev, "start", None) is not None:
                idx = int(ev.start)
            else:
                continue

            idx = max(0, min(seq_len - 1, idx))
            t_pos = idx / denom

            # Stack level for this locus
            center_idx = idx
            stack_level = stack_bins.get(center_idx, 0)
            stack_bins[center_idx] = stack_level + 1

            x_center = (t_pos * 2.0 - 1.0) * 0.8 + stack_level * stack_dx

            if ev.type in (EditEventType.NICK_PRIMARY, EditEventType.CUT):
                # Short arch above the top rail
                span = 0.04
                x0 = x_center - span
                x1 = x_center + span
                p0 = np.array([x0, y_top, base_z], dtype="f4")
                p2 = np.array([x1, y_top, base_z], dtype="f4")
                base_height = 0.2
                height = base_height + stack_level * stack_dh
                mid = np.array([x_center, y_top + height, base_z], dtype="f4")
                kind_code = 0.0  # "cut"
                p1 = mid
            else:
                # Repair ribbon: from top rail down toward bottom rail, bowed right
                p0 = np.array([x_center, y_top, base_z], dtype="f4")
                p2 = np.array([x_center, y_bottom, base_z], dtype="f4")
                bend = 0.12
                p1 = np.array([x_center + bend, 0.0, base_z], dtype="f4")
                kind_code = 2.0  # "repair"

            # Sample quadratic Bezier
            s = np.linspace(0.0, 1.0, 40, dtype="f4")
            um = 1.0 - s
            curve = (
                (um[:, None] ** 2) * p0
                + 2.0 * (um[:, None] * s[:, None]) * p1
                + (s[:, None] ** 2) * p2
            ).astype("f4")

            verts_list.append(curve)
            # Use event time as a gating parameter (0..1) for the fragment shader
            t_evt = float(getattr(ev, "t", 1.0))
            weights_list.append(np.full((curve.shape[0], 1), t_evt, dtype="f4"))
            kinds_list.append(np.full((curve.shape[0], 1), kind_code, dtype="f4"))

            count = curve.shape[0]
            arc_ranges.append((cursor, count))
            cursor += count

        if not verts_list:
            return np.zeros((0, 5), dtype="f4"), [], None

        # --- Build arrowheads at the end of each ribbon ---
        head_verts_list: list[np.ndarray] = []
        head_weights_list: list[np.ndarray] = []
        head_kinds_list: list[np.ndarray] = []

        arrow_len = float(MODERN_STYLE.flat_ribbon_arrow_len)
        arrow_width = float(MODERN_STYLE.flat_ribbon_arrow_width)

        for curve, kind_array, weight_array in zip(verts_list, kinds_list, weights_list):
            if curve.shape[0] < 2:
                continue
            tip = curve[-1]
            prev = curve[-2]
            d = tip - prev
            d_xy = d.copy()
            d_xy[2] = 0.0
            norm = float(np.linalg.norm(d_xy))
            if norm < 1e-6:
                continue
            d_xy /= norm

            n_xy = np.array([-d_xy[1], d_xy[0], 0.0], dtype="f4")

            base = tip - d_xy * arrow_len
            left = base + n_xy * arrow_width
            right = base - n_xy * arrow_width

            head = np.stack([tip, left, right], axis=0).astype("f4")
            head_verts_list.append(head)

            kind_val = float(kind_array[0, 0])
            t_evt = float(weight_array[0, 0])
            head_weights_list.append(np.full((3, 1), t_evt, dtype="f4"))
            head_kinds_list.append(np.full((3, 1), kind_val, dtype="f4"))

        verts = np.vstack(verts_list).astype("f4")
        weights = np.vstack(weights_list).astype("f4")
        kinds = np.vstack(kinds_list).astype("f4")
        interleaved = np.hstack([verts, weights, kinds]).astype("f4")

        head_interleaved: np.ndarray | None
        if head_verts_list:
            head_verts = np.vstack(head_verts_list).astype("f4")
            head_weights = np.vstack(head_weights_list).astype("f4")
            head_kinds = np.vstack(head_kinds_list).astype("f4")
            head_interleaved = np.hstack(
                [head_verts, head_weights, head_kinds]
            ).astype("f4")
        else:
            head_interleaved = None

        return interleaved, arc_ranges, head_interleaved

    @staticmethod
    def _bars_vertex_shader() -> str:
        return """
        #version 330
        in vec2 in_unit;
        in vec4 in_box0;
        in vec3 in_box1;
        uniform mat4 u_mvp;
        uniform vec2 u_px2world;
        out float v_weight;
        out float v_kind;
        void main() {
            float xc = in_box0.x;
            float hw = max(in_box0.y, 1e-5);
            float yc = in_box0.z;
            float base_h = in_box0.w;
            float w = in_box1.x;
            float kind = in_box1.y;
            float z = in_box1.z;
            float px_h = 14.0 * u_px2world.y;
            float world_h = max(base_h, px_h);
            float x = xc + in_unit.x * (2.0 * hw);
            float y = yc + in_unit.y * world_h;
            gl_Position = u_mvp * vec4(x, y, z, 1.0);
            v_weight = w;
            v_kind = kind;
        }
        """

    @staticmethod
    def _bars_fragment_shader() -> str:
        return """
        #version 330
        in float v_weight;
        in float v_kind;
        out vec4 f_color;
        vec3 kind_color(float kind) {
            if (kind < 0.5) return vec3(0.98, 0.65, 0.22);
            if (kind < 1.5) return vec3(0.92, 0.33, 0.82);
            if (kind < 2.5) return vec3(0.26, 0.86, 0.98);
            if (kind < 3.5) return vec3(0.20, 0.40, 0.55);
            if (kind < 4.5) return vec3(0.35, 0.88, 0.75);
            return vec3(0.65, 0.65, 0.72);
        }
        void main() {
            float w = clamp(v_weight, 0.0, 1.0);
            vec3 color = kind_color(v_kind);
            float alpha = mix(0.2, 0.95, w);
            f_color = vec4(color, alpha);
        }
        """

    @staticmethod
    def _heat_vertex_shader() -> str:
        return """
        #version 330
        in vec3 in_pos;
        in float in_value;
        uniform mat4 u_mvp;
        out float v_value;
        void main() {
            gl_Position = u_mvp * vec4(in_pos, 1.0);
            v_value = in_value;
        }
        """

    @staticmethod
    def _heat_fragment_shader() -> str:
        return """
        #version 330
        in float v_value;
        uniform vec3 u_color_low;
        uniform vec3 u_color_high;
        out vec4 f_color;
        void main() {
            float t = clamp(v_value, 0.0, 1.0);
            vec3 color = mix(u_color_low, u_color_high, t);
            float alpha = mix(0.12, 0.55, t);
            f_color = vec4(color, alpha);
        }
        """

    @staticmethod
    def _flat_vertex_shader() -> str:
        return """
        #version 330
        in vec3 in_pos;
        uniform mat4 u_mvp;
        void main() {
            gl_Position = u_mvp * vec4(in_pos, 1.0);
        }
        """

    @staticmethod
    def _flat_fragment_shader() -> str:
        return """
        #version 330
        uniform vec4 u_color;
        out vec4 f_color;
        void main() {
            f_color = u_color;
        }
        """

    @staticmethod
    def _window_vertex_shader() -> str:
        return """
        #version 330 core
        layout(location=0) in uint in_code;
        uniform float u_zoom_bp;   // span of bases shown across the viewport
        uniform float u_pan_bp;    // center position in base coordinates
        uniform float u_count;     // total bases in buffer
        flat out uint v_code;
        void main() {
            float idx = float(gl_VertexID);
            float center = u_pan_bp;
            float half_span = max(1.0, u_zoom_bp * 0.5);
            float x = (idx - center) / half_span; // -1..1 when idx=center±half_span
            v_code = in_code;
            gl_Position = vec4(x, 0.0, 0.0, 1.0);
        }
        """

    @staticmethod
    def _window_fragment_shader() -> str:
        return """
        #version 330 core
        flat in uint v_code;
        out vec4 f_color;

        vec3 base_color(uint c) {
            if (c == 0u) return vec3(0.90, 0.20, 0.20); // T
            if (c == 1u) return vec3(0.20, 0.70, 0.20); // C
            if (c == 2u) return vec3(0.20, 0.40, 0.90); // A
            return vec3(0.95, 0.90, 0.30);               // G or unknown
        }

        void main() {
            f_color = vec4(base_color(v_code), 1.0);
        }
        """

    @staticmethod
    def _overlay_vertex_shader() -> str:
        return """
        #version 330 core
        layout(location=0) in float in_idx;
        layout(location=1) in uint in_kind;
        layout(location=2) in float in_val;
        uniform float u_window_len;
        uniform float u_zoom_bp;
        uniform float u_pan_bp;
        flat out uint v_kind;
        out float v_val;
        void main() {
            float norm = in_idx / max(1.0, u_window_len - 1.0);
            float base_pos = norm * max(1.0, u_window_len);
            float x = (base_pos - u_pan_bp) / max(1.0, u_zoom_bp * 0.5);
            v_kind = in_kind;
            v_val = in_val;
            gl_Position = vec4(x, 0.08, 0.0, 1.0);
            gl_PointSize = 6.0;
        }
        """

    @staticmethod
    def _overlay_fragment_shader() -> str:
        return """
        #version 330 core
        flat in uint v_kind;
        in float v_val;
        out vec4 f_color;
        vec3 overlay_color(uint k) {
            if (k == 0u) return vec3(1.0, 0.85, 0.25);
            if (k == 1u) return vec3(0.35, 0.95, 0.45);
            return vec3(0.8, 0.5, 1.0);
        }
        void main() {
            float alpha = clamp(0.3 + 0.7 * v_val, 0.3, 1.0);
            f_color = vec4(overlay_color(v_kind), alpha);
        }
        """

    # Public API: window camera tuning
    def set_window_camera(self, zoom_bp: float, center_bp: float) -> None:
        self._window_zoom_bp = max(1.0, float(zoom_bp))
        self._window_pan_bp = float(center_bp)
        self.update()

    def _start_camera_ease(self, *, target: np.ndarray, distance: float) -> None:
        """Begin a short, smooth camera glide toward (target, distance)."""
        try:
            self._cam_ease_target = np.asarray(target, dtype="f4").reshape((3,))
        except Exception:
            self._cam_ease_target = None
        try:
            self._cam_ease_distance = max(0.05, float(distance))
        except Exception:
            self._cam_ease_distance = None

    def pulse_locus(self, kind: str = "fit") -> None:
        """Pulse the locus marker once (UI training cue).

        Used by Fit-to-Locus and its one-step undo. Manual camera input wins:
        if the user is currently dragging, skip the pulse.
        """
        try:
            if self._drag_mode is not None:
                return
        except Exception:
            pass
        k = "undo" if str(kind).lower() == "undo" else "fit"
        duration_s = 0.55 if k == "fit" else 0.38
        now = clock.monotonic()
        self._locus_pulse_kind = k
        self._locus_pulse_t0 = float(now)
        self._locus_pulse_duration_s = float(duration_s)
        self.update()

    def _locus_pulse_amount(self) -> float:
        dur = float(self._locus_pulse_duration_s)
        if dur <= 1e-9:
            return 0.0
        u = (clock.monotonic() - float(self._locus_pulse_t0)) / dur
        if u >= 1.0:
            return 0.0
        ease = max(0.0, min(1.0, 1.0 - float(u)))
        # Ease-out so the pulse reads as a single "moment", not a throb.
        ease = ease * ease
        strength = 1.0 if self._locus_pulse_kind == "fit" else 0.55
        return float(ease * strength)

    def fit_to_locus(self) -> None:
        """Fit the camera to the active locus + story geometry.

        - In realtime 3D: centers on the cut locus and fits guide bracket + active arcs.
        - In workflow 2.5D: centers on cut index and zooms to keep the guide readable.
        """
        if self._mode == "workflow_2p5d" and self._workflow_buffers is not None:
            buffers = self._workflow_buffers
            try:
                x_extent = float(buffers.get("x_extent", 1.0))
            except Exception:
                x_extent = 1.0
            if x_extent <= 1e-6:
                return
            try:
                cut_x = float(buffers.get("cut_index", x_extent * 0.5))
            except Exception:
                cut_x = x_extent * 0.5
            try:
                g0 = float(buffers.get("guide_start", cut_x))
                g1 = float(buffers.get("guide_end", cut_x))
            except Exception:
                g0 = g1 = cut_x
            if g1 < g0:
                g0, g1 = g1, g0
            cut_x = max(0.0, min(float(x_extent), float(cut_x)))
            full_span = max(1.0, float(x_extent) + 2.0)
            radius = max(abs(float(g0) - float(cut_x)), abs(float(g1) - float(cut_x)), 20.0)
            span = max(80.0, min(full_span, float(radius) * 2.0 * 1.6))
            self.set_window_camera(span, cut_x)
            return

        engine = self.engine
        spec = self._spec
        if engine is None or spec is None:
            return

        cut_idx = self._cut_index_from_spec()
        if cut_idx is None:
            return

        raw_time = float(getattr(getattr(engine, "state", None), "time", 0.0))
        loop = float(getattr(engine, "loop_duration", 0.0))
        base_gate = max(0.0, min(1.0, raw_time / loop)) if loop > 1e-6 else 1.0
        weights_norm = getattr(self, "_arc_weights_normalized", None)
        if weights_norm is None:
            weights_norm = bool(getattr(engine, "event_times_normalized", False))
        t_gate = base_gate if weights_norm else raw_time
        # Debug escape hatch: allow disabling gating entirely for diagnostics.
        if _env_flag("HELIX_SHOW_ALL_RAILS", False):
            t_gate = 1e9

        # --- Flat rails (2D param view) -----------------------------------
        if self._rail_mode is RailViewMode.FLAT:
            n_bp = max(1, len(spec.sequence))
            denom = max(1, n_bp - 1)
            cut_x = (float(cut_idx) / float(denom) * 2.0 - 1.0) * 0.9
            points: list[tuple[float, float]] = []

            g0, g1 = spec.guide_range
            wx0 = (float(g0) / float(denom) * 2.0 - 1.0) * 0.9
            wx1 = (float(g1) / float(denom) * 2.0 - 1.0) * 0.9
            points.extend([(cut_x, 0.0), (wx0, 0.0), (wx1, 0.0)])

            # Include active ribbons/arcs (those whose gating weight is <= current time).
            if self._arc_cpu is not None and self._arc_ranges:
                try:
                    arc = self._arc_cpu
                    for start, count in self._arc_ranges:
                        if count <= 0:
                            continue
                        w = float(arc[start, 3])
                        if w > float(t_gate) + 1e-6:
                            continue
                        seg = arc[start : start + count, :2]
                        for x, y in seg:
                            points.append((float(x), float(y)))
                except Exception:
                    pass

            dist = fit_ortho_camera_distance(center_xy=(cut_x, 0.0), points_xy=points, margin=1.25, min_distance=0.25)
            self._start_camera_ease(target=np.array([cut_x, 0.0, 0.0], dtype="f4"), distance=dist)
            return

        # --- Helix (3D orbit) --------------------------------------------
        if self._bp_positions is None or self._bp_positions.size == 0:
            return
        try:
            locus = self._bp_positions[max(0, min(self._bp_positions.shape[0] - 1, int(cut_idx)))]
        except Exception:
            return

        g0, g1 = spec.guide_range
        idxs = [
            max(0, min(self._bp_positions.shape[0] - 1, int(g0))),
            max(0, min(self._bp_positions.shape[0] - 1, int(g1))),
        ]
        pts = [self._bp_positions[i] for i in idxs]
        radius = radius_from_points(center=locus, points=pts)
        # Add a little extra for rail thickness / readability.
        radius = max(radius, 0.4)
        fb_w, fb_h = self.framebuffer_size_px()
        aspect = float(fb_w) / max(1.0, float(fb_h))
        dist = fit_perspective_orbit_distance(radius=radius, fov_y_deg=40.0, aspect=aspect, margin=1.25, min_distance=1.0)
        self._start_camera_ease(target=np.array(locus, dtype="f4"), distance=dist)

    def get_view_state(self) -> dict[str, Any]:
        """Return a small, JSON-serializable snapshot of the viewer state.

        This is intended for UI persistence (restore last camera + toggles).
        """
        try:
            tx, ty, tz = (
                float(self._cam_target[0]),
                float(self._cam_target[1]),
                float(self._cam_target[2]),
            )
        except Exception:
            tx, ty, tz = 0.0, 0.0, 0.0

        return {
            "rail_mode": str(self._rail_mode.value),
            "animate": bool(self._animate),
            "playback_speed": float(self._playback_speed),
            "cam_target": [tx, ty, tz],
            "cam_distance": float(self._cam_distance),
            "cam_yaw": float(self._cam_yaw),
            "cam_pitch": float(self._cam_pitch),
            "window_zoom_bp": float(self._window_zoom_bp),
            "window_pan_bp": float(self._window_pan_bp),
        }

    def apply_view_state(self, state: Mapping[str, Any]) -> None:
        """Best-effort restore of `get_view_state()` output."""
        if not isinstance(state, Mapping):
            return
        # Applying a view state is a manual/explicit action; cancel any in-flight easing.
        self._cam_ease_target = None
        self._cam_ease_distance = None

        def _as_float(value: object) -> float | None:
            if value is None:
                return None
            try:
                return float(value)  # type: ignore[arg-type]
            except Exception:
                return None

        rail_mode = state.get("rail_mode")
        if isinstance(rail_mode, str):
            try:
                self.set_rail_mode(rail_mode)
            except Exception:
                pass

        if "animate" in state:
            try:
                self.set_animate(bool(state.get("animate")))
            except Exception:
                pass
        if "playback_speed" in state:
            speed = _as_float(state.get("playback_speed"))
            if speed is not None:
                try:
                    self.set_playback_speed(speed)
                except Exception:
                    pass

        # Window zoom/pan (used in 2D "window" search mode).
        zoom_bp = _as_float(state.get("window_zoom_bp"))
        pan_bp = _as_float(state.get("window_pan_bp"))
        if zoom_bp is not None and pan_bp is not None:
            try:
                self.set_window_camera(zoom_bp, pan_bp)
            except Exception:
                pass

        # Prefer interactive camera fields; fall back to a metadata-style camera dict.
        target = state.get("cam_target")
        if isinstance(target, (list, tuple)) and len(target) == 3:
            tx = _as_float(target[0])
            ty = _as_float(target[1])
            tz = _as_float(target[2])
            if tx is not None and ty is not None and tz is not None:
                try:
                    self._cam_target = np.array([tx, ty, tz], dtype="f4")
                except Exception:
                    pass
        else:
            camera = state.get("camera")
            if isinstance(camera, Mapping):
                try:
                    self._sync_camera_state_from_meta(camera)
                    self._update_camera_meta()
                    self.update()
                except Exception:
                    pass
                return

        distance = _as_float(state.get("cam_distance"))
        yaw = _as_float(state.get("cam_yaw"))
        pitch = _as_float(state.get("cam_pitch"))
        if distance is not None:
            self._cam_distance = max(0.05, float(distance))
        if yaw is not None:
            self._cam_yaw = float(yaw)
        if pitch is not None:
            self._cam_pitch = float(pitch)

        try:
            self._update_camera_meta()
        except Exception:
            pass
        self.update()

    # Public API -------------------------------------------------------
    def set_time_norm(self, value: float) -> None:
        """Scrub the engine timeline by normalized fraction [0, 1]."""
        if self.engine is None:
            return
        loop = float(getattr(self.engine, "loop_duration", 0.0))
        if loop <= 1e-6:
            return
        frac = max(0.0, min(1.0, float(value)))
        t = frac * loop
        # Avoid modulo wrap at the exact loop boundary.
        t = max(0.0, min(loop - 1e-6, float(t)))
        state = self.engine.set_time(t)
        try:
            self.timeUpdated.emit(state.time)
        except Exception:
            pass
        try:
            self.phaseChanged.emit(state.phase.value)
        except Exception:
            pass
        self.update()

    def set_time_seconds(self, t: float, *, pause: bool = False) -> None:
        """Scrub the engine timeline by absolute seconds within the loop."""
        self._set_time_seconds(t, pause=pause)

    def set_loop_range_seconds(self, start: float, end: float) -> None:
        """Set an A/B loop range (seconds) for playback and scrubbing."""
        engine = self.engine
        if engine is None:
            return
        try:
            engine.set_loop_range(float(start), float(end))
        except Exception:
            return
        # Re-apply current time so enabling loop clamps immediately.
        try:
            now = float(getattr(getattr(engine, "state", None), "time", 0.0))
        except Exception:
            now = 0.0
        state = engine.set_time(now)
        try:
            self.timeUpdated.emit(state.time)
        except Exception:
            pass
        try:
            self.phaseChanged.emit(state.phase.value)
        except Exception:
            pass
        self.update()

    def clear_loop_range(self) -> None:
        engine = self.engine
        if engine is None:
            return
        try:
            engine.clear_loop_range()
        except Exception:
            return
        state = engine.set_time(float(getattr(getattr(engine, "state", None), "time", 0.0)))
        try:
            self.timeUpdated.emit(state.time)
        except Exception:
            pass
        try:
            self.phaseChanged.emit(state.phase.value)
        except Exception:
            pass
        self.update()

    def set_loop_enabled(self, enabled: bool) -> None:
        engine = self.engine
        if engine is None:
            return
        try:
            engine.set_loop_enabled(bool(enabled))
        except Exception:
            return
        state = engine.set_time(float(getattr(getattr(engine, "state", None), "time", 0.0)))
        try:
            self.timeUpdated.emit(state.time)
        except Exception:
            pass
        try:
            self.phaseChanged.emit(state.phase.value)
        except Exception:
            pass
        self.update()

    def _set_time_seconds(self, t: float, *, pause: bool = False) -> None:
        engine = self.engine
        if engine is None:
            return
        loop = float(getattr(engine, "loop_duration", 0.0))
        if loop > 1e-6:
            # Clamp instead of wrapping: UI stepping/scrubbing should never jump
            # across the loop boundary unless explicitly requested.
            try:
                raw = float(t)
            except Exception:
                return
            if not math.isfinite(raw):
                return
            t = max(0.0, min(loop - 1e-6, raw))
        if pause:
            try:
                self.set_playing(False)
            except Exception:
                self._playing = False
        state = engine.set_time(float(t))
        try:
            self.timeUpdated.emit(state.time)
        except Exception:
            pass
        try:
            self.phaseChanged.emit(state.phase.value)
        except Exception:
            pass
        self.update()

    def _event_times_seconds(self) -> list[float]:
        engine = self.engine
        if engine is None:
            return []
        try:
            return list(engine.event_times_seconds())
        except Exception:
            return []

    def _snap_to_event(self, direction: int) -> None:
        """Jump to next/prev timeline event and pause playback."""
        engine = self.engine
        if engine is None:
            return
        times = self._event_times_seconds()
        if not times:
            return
        now = float(getattr(getattr(engine, "state", None), "time", 0.0))
        loop = float(getattr(engine, "loop_duration", 0.0))
        if loop > 1e-6:
            now = now % loop
        eps = 1e-6
        target = times[0] if direction >= 0 else times[-1]
        if direction >= 0:
            for t in times:
                if t > now + eps:
                    target = t
                    break
        else:
            for t in reversed(times):
                if t < now - eps:
                    target = t
                    break
        self._set_time_seconds(target, pause=True)

    def _step_frames(self, frames: int) -> None:
        engine = self.engine
        if engine is None:
            return
        dt = float(frames) * float(self._timeline_dt_s)
        if abs(dt) <= 1e-12:
            return
        now = float(getattr(getattr(engine, "state", None), "time", 0.0))
        loop = float(getattr(engine, "loop_duration", 0.0))
        target = now + dt
        if loop > 1e-6:
            target = max(0.0, min(loop - 1e-6, target))

        # If we would cross an event boundary within this step, snap to that
        # event so stepping never "skips the interesting moment".
        eps = 1e-6
        try:
            times = list(engine.event_times_seconds())  # type: ignore[attr-defined]
        except Exception:
            times = []
        if times:
            if dt > 0.0:
                for t_evt in times:
                    if (now + eps) < t_evt <= (target + eps):
                        target = t_evt
                        break
            else:
                for t_evt in reversed(times):
                    if (target - eps) <= t_evt < (now - eps):
                        target = t_evt
                        break

        self._set_time_seconds(target, pause=True)

    def set_playback_speed(self, speed: float) -> None:
        """Set realtime playback speed multiplier (ex: 0.25x, 1x, 4x)."""
        try:
            value = float(speed)
        except Exception:
            return
        if not (value > 0.0):
            return
        self._playback_speed = max(0.05, min(8.0, value))
        self.update()

    def _maybe_reset_and_rebuild(self) -> None:
        """Handle deferred resets/rebuilds once a current context is available."""
        if not self._render_active:
            return
        # Reset first; if it defers, bail until next frame.
        if self._pending_reset:
            if not self._reset_geometry_buffers(force=True):
                return

        if not self._need_rebuild:
            return

        # Only rebuild when we have a valid context, nonzero size, and matching ctx id.
        ctx = getattr(self, "ctx", None)
        if ctx is None:
            self._need_rebuild = True
            return
        try:
            if self._ctx_id is not None and id(ctx) != self._ctx_id:
                # Context changed (platform rebuild). Defer until initializeGL resets id.
                self._need_rebuild = True
                self._pending_reset = True
                return
        except Exception:
            pass

        if self.width() <= 0 or self.height() <= 0:
            self._need_rebuild = True
            return

        try:
            self.makeCurrent()
        except Exception:
            self._need_rebuild = True
            return

        # Rebuild buffers lazily; _upload_buffers handles missing spec/engine.
        try:
            if self.ctx is not None:
                self._upload_buffers()
                if self._mode == "workflow_2p5d" and self._workflow_buffers:
                    self._upload_workflow_buffers()
                self._need_rebuild = False
        except Exception:
            # Keep the rebuild pending; logging stays in existing error channels.
            self._need_rebuild = True

    def set_render_active(self, active: bool) -> None:
        """Start/stop render + simulation ticks when the viewer is off-screen."""
        active = bool(active)
        if active == getattr(self, "_render_active", True):
            return
        self._render_active = active
        self._inactive_paint_logged = False
        # Drop any in-flight input state to avoid stale grabs on deactivation.
        self._drag_mode = None
        self._last_mouse_pos = None
        try:
            self.releaseMouse()
        except Exception:
            pass
        # Stop heavy timers/queues when inactive.
        try:
            if active:
                self._timer.start()
                self.update()
            else:
                self._timer.stop()
        except Exception:
            pass

    def _reset_geometry_buffers(self, *, force: bool = False) -> bool:
        """
        Release GPU buffers/VAOs. Only safe with a current context.

        Returns True if a reset was performed; False if deferred.
        """
        ctx = getattr(self, "ctx", None)
        exposed = bool(self.isExposed()) if hasattr(self, "isExposed") else bool(self.isVisible())
        if ctx is None or (not exposed and not force):
            self._pending_reset = True
            return False

        # Ensure we are on the owning context; if not, defer.
        try:
            if self._ctx_id is not None and id(ctx) != self._ctx_id:
                self._pending_reset = True
                return False
        except Exception:
            pass

        try:
            self.makeCurrent()
        except Exception:
            self._pending_reset = True
            return False

        # VAOs
        for vao in (
            getattr(self, "_vao", None),
            getattr(self, "_arc_vao", None),
            getattr(self, "_arc_heads_vao", None),
            getattr(self, "_bars_vao", None),
            getattr(self, "_heat_vao", None),
            getattr(self, "_slice_vao", None),
            getattr(self, "_overlay_vao", None),
            getattr(self, "_window_vao", None),
            getattr(self, "_highlight_vao", None),
        ):
            _try_release_mgl(vao)
        self._vao = None
        self._arc_vao = None
        self._arc_heads_vao = None
        self._bars_vao = None
        self._heat_vao = None
        self._slice_vao = None
        self._overlay_vao = None
        self._window_vao = None
        self._highlight_vao = None

        # VBOs / buffers
        for buf in (
            getattr(self, "_rail_vbo", None),
            getattr(self, "_arc_vbo", None),
            getattr(self, "_arc_heads_vbo", None),
            getattr(self, "_bars_inst0_vbo", None),
            getattr(self, "_bars_inst1_vbo", None),
            getattr(self, "_bars_unit_vbo", None),
            getattr(self, "_heat_vbo", None),
            getattr(self, "_slice_vbo", None),
            getattr(self, "_workflow_rail_vbo", None),
            getattr(self, "_workflow_tick_vbo", None),
        ):
            _try_release_mgl(buf)
        for buf in list(getattr(self, "_overlay_buffers", []) or []):
            _try_release_mgl(buf)
        self._overlay_buffers = []
        self._rail_vbo = None
        self._arc_vbo = None
        self._arc_heads_vbo = None
        self._bars_inst0_vbo = None
        self._bars_inst1_vbo = None
        self._bars_unit_vbo = None
        self._heat_vbo = None
        self._slice_vbo = None
        self._workflow_rail_vbo = None
        self._workflow_tick_vbo = None

        # Pick/heavy resources
        pick = getattr(self, "_pick_id_buffer", None)
        if pick is not None:
            _try_release_mgl(getattr(pick, "fbo", None))
            _try_release_mgl(getattr(pick, "color_tex", None))
            _try_release_mgl(getattr(pick, "depth", None))
            self._pick_id_buffer = None
        self._heavy_resources = None

        # Counters / cached CPU arrays
        self._rail_vertex_count = 0
        self._arc_ranges = []
        self._arc_firsts = np.zeros((0,), dtype="i4")
        self._arc_counts = np.zeros((0,), dtype="i4")
        self._arc_heads_count = 0
        self._workflow_instance_count = 0
        self._heat_vertex_count = 0
        self._overlay_count = 0
        self._window_count = 0
        self._world_rail_vertices = None
        self._arc_cpu = None
        self._arc_events = []
        self._arc_confidence = []
        self._overlay_rels = None
        self._overlay_labels = []
        self._workflow_buffers = None
        self._workflow_last_mvp = None
        self._workflow_rail_y = None
        self._bp_positions = None
        self._bp_positions_template = None
        self._bp_positions_opposite = None

        self._pending_reset = False
        self._need_rebuild = True
        return True

    def set_spec(self, spec: EditVisualizationSpec) -> None:
        print(
            "[HelixModernWidget] set_spec called:",
            getattr(spec, "edit_type", "<unknown>"),
            "sequence len:",
            len(spec.sequence),
            flush=True,
        )
        # Defer buffer reset if the context is not current/visible.
        self._pending_reset = True
        self._need_rebuild = True
        try:
            exposed = bool(self.isExposed()) if hasattr(self, "isExposed") else bool(self.isVisible())
            if self.ctx is not None and exposed:
                self._reset_geometry_buffers(force=True)
        except Exception:
            pass
        self._spec = spec
        self._cut_semantics = CutSemantics.from_spec(spec)
        self._mode = "3d"
        self._workflow_buffers = None
        self._highlight_range = None
        self._highlight_param = None
        self.engine = HelixVizEngine(spec)
        # If legacy specs omit time units, persist the resolved value so that
        # any subsequent save emits an explicit `time_units` field.
        try:
            if getattr(spec, "time_units", None) is None and self.engine is not None:
                spec.time_units = str(getattr(self.engine, "event_time_units", "seconds"))
        except Exception:
            pass
        cam_meta = (spec.metadata or {}).get("camera") if spec.metadata else None
        if isinstance(cam_meta, Mapping):
            self._custom_camera = dict(cam_meta)
            self._sync_camera_state_from_meta(cam_meta)
        else:
            self._custom_camera = None
            self._reset_camera_defaults()
        self._has_drawn_frame = False
        print(
            "[HelixModernWidget] engine geometry:",
            self.engine.helix_geometry.rail_vertices.shape,
            "arcs:",
            self.engine.repair_geometry.vertices.shape,
            flush=True,
        )
        if __debug__:
            self._assert_geometry()
        # Rebuild lazily on the next active paint when the context is current.
        self._need_rebuild = True

        # Seed genome lanes with the current sequence so PAM/prime fields render
        try:
            if isinstance(spec.sequence, str) and spec.sequence:
                chrom = "chr0"
                start = 0
                # If reference locus is present, use it
                locus = None
                meta = spec.metadata or {}
                locus = meta.get("referenceLocus") if isinstance(meta, Mapping) else None
                if isinstance(locus, Mapping):
                    chrom = str(locus.get("chrom", chrom))
                    try:
                        start = int(locus.get("start", start))
                    except Exception:
                        start = 0
                self.set_tile_context(chrom, start, spec.sequence)
        except Exception:
            pass
        self.update()
        if self.engine:
            self.phaseChanged.emit(self.engine.state.phase.value)

    def cut_semantics(self) -> CutSemantics | None:
        return self._cut_semantics

    def set_workflow_view(self, buffers: dict[str, np.ndarray] | None) -> None:
        """Switch into/out of the 2.5D workflow mode."""
        self._workflow_buffers = buffers
        self._mode = "workflow_2p5d" if buffers else "3d"
        self._workflow_last_mvp = None
        self._workflow_rail_y = None
        self._workflow_sequence = ""
        if buffers and "sequence" in buffers and isinstance(buffers.get("sequence"), str):
            try:
                self._workflow_sequence = str(buffers.get("sequence") or "")
            except Exception:
                self._workflow_sequence = ""
        if buffers and not self._workflow_sequence:
            # Back-compat: workflow buffers may omit the sequence; fall back to the
            # currently loaded spec so the base-letter overlay can still render.
            try:
                if self._spec is not None and isinstance(getattr(self._spec, "sequence", None), str):
                    self._workflow_sequence = str(getattr(self._spec, "sequence") or "")
            except Exception:
                self._workflow_sequence = ""
        if buffers:
            try:
                x_extent = float(buffers.get("x_extent", 1.0))
                full_span = max(1.0, float(x_extent) + 2.0)
                if float(self._window_zoom_bp) <= 0.0:
                    self._window_zoom_bp = float(full_span)
                    self._window_pan_bp = float(x_extent) * 0.5
            except Exception:
                pass
        self._need_rebuild = True
        if self.ctx is not None and self._render_active:
            self._upload_workflow_buffers()
            self._need_rebuild = False
        self.update()

    # Public hooks for Outcome Explorer
    def highlight_window(self, start_bp: int, end_bp: int) -> None:
        self._highlight_range = (int(start_bp), int(end_bp))
        self._highlight_param = self._compute_highlight_param_range()
        if not self._render_active:
            self._need_rebuild = True
            self.update()
            return
        if self.ctx is not None:
            self._build_highlight_quad()
        self.update()

    def focus_on_positions(self, indices: Sequence[int]) -> None:
        if not indices:
            return

        # Flat rails: focus in param-space X (logical camera zoom/pan).
        if self._rail_mode is RailViewMode.FLAT:
            num_bp = int(self._num_bp)
            if num_bp <= 1:
                return
            idxs = [max(0, min(num_bp - 1, int(i))) for i in indices]
            xs = [float(self._bp_to_x(i)) for i in idxs]
            if not xs:
                return
            cx = float(sum(xs) / float(len(xs)))
            points = [(x, 0.0) for x in xs]
            # Include a nominal Y extent so we don't over-zoom into an empty band.
            points.extend([(cx, -0.6), (cx, 0.6)])
            dist = fit_ortho_camera_distance(center_xy=(cx, 0.0), points_xy=points, margin=1.15, min_distance=0.25)
            self._start_camera_ease(target=np.array([cx, 0.0, 0.0], dtype="f4"), distance=dist)
            self.update()
            return

        # Helix: focus in world-space with the orbit camera.
        if self._bp_positions is None or self._bp_positions.size == 0:
            return
        idxs = [max(0, min(self._bp_positions.shape[0] - 1, int(i))) for i in indices]
        pts = self._bp_positions[idxs]
        try:
            center = np.mean(pts, axis=0).astype("f4")
        except Exception:
            return
        radius = radius_from_points(center=center, points=pts)
        radius = max(float(radius), 0.4)
        fb_w, fb_h = self.framebuffer_size_px()
        aspect = float(fb_w) / max(1.0, float(fb_h))
        dist = fit_perspective_orbit_distance(radius=radius, fov_y_deg=40.0, aspect=aspect, margin=1.25, min_distance=1.0)
        self._start_camera_ease(target=np.array(center, dtype="f4"), distance=dist)
        self.update()

    def highlight_outcome(self, sel: object) -> None:
        if sel is None or self.engine is None:
            return
        # expected OutcomeSelection-like object
        start_rel, end_rel = 0, 0
        try:
            start_rel, end_rel = sel.position_range  # type: ignore[attr-defined]
        except Exception:
            return
        peak = getattr(sel, "peak_position", 0)
        cut = self._num_bp // 2 if self._num_bp else 0
        cut_meta = getattr(self.engine, "cut_index", None)
        if cut_meta is None and isinstance(self._workflow_buffers, Mapping):
            cut_meta = self._workflow_buffers.get("cut_index")
        if cut_meta is None and self._spec is not None:
            meta = getattr(self._spec, "metadata", {}) or {}
            cut_meta = meta.get("cut_index")
        if cut_meta is not None:
            cut = int(cut_meta)
        start = cut + int(start_rel)
        end = cut + int(end_rel)
        self.set_rail_mode(RailViewMode.FLAT)
        self.highlight_window(start, end)
        self.focus_on_positions([start, end, cut])

    def _compute_highlight_param_range(self) -> tuple[float, float] | None:
        if self.engine is None or self._highlight_range is None:
            return None
        geom = getattr(self.engine, "helix_geometry", None)
        if geom is None:
            return None
        num_bp = int(getattr(geom.rail_vertices, "shape", [0])[0] // 2)
        if num_bp <= 1:
            return None
        denom = max(1, num_bp - 1)
        start_bp, end_bp = self._highlight_range
        t0 = max(0.0, min(1.0, float(start_bp) / float(denom)))
        t1 = max(0.0, min(1.0, float(end_bp) / float(denom)))
        return (min(t0, t1), max(t0, t1))

    def set_playing(self, playing: bool) -> None:
        playing = bool(playing)
        if playing == self._playing:
            return
        self._playing = playing
        try:
            self.playingChanged.emit(self._playing)
        except Exception:
            pass
        self.update()

    def set_template_visible(self, visible: bool) -> None:
        self._show_template = visible
        self.update()

    def set_animate(self, enabled: bool) -> None:
        self._animate = bool(enabled)
        self.update()

    def set_rail_mode(self, mode: str | RailViewMode) -> None:
        if isinstance(mode, RailViewMode):
            new_mode = mode
        else:
            try:
                new_mode = RailViewMode(str(mode))
            except ValueError:
                return
        if new_mode is self._rail_mode:
            return
        self._rail_mode = new_mode
        # Reset camera and selection when switching rail modes so each
        # view (flat vs helix) feels like a distinct workspace.
        self._reset_camera_defaults()
        self._selected_kind = None
        if self.ctx is not None and self.engine is not None:
            self._upload_buffers()
        self.update()

    def set_flap_visible(self, visible: bool) -> None:
        self._show_flap = visible
        self._show_ribbons = visible
        self.update()

    def set_base_overlay_enabled(self, enabled: bool) -> None:
        self._show_bases = bool(enabled)
        self.update()

    def set_base_max(self, max_bases: int) -> None:
        self._max_base_glyphs = max(10, int(max_bases))
        self.update()

    def set_base_fade_distance(self, distance: float) -> None:
        self._base_fade_distance = max(0.2, float(distance))
        self.update()

    def set_debug_overlay_enabled(self, enabled: bool) -> None:
        self._show_debug_overlay = bool(enabled)
        self.update()

    def set_hud_text_sink(self, sink: Callable[[str, Sequence[str]], None] | None) -> None:
        """Route HUD text to an external sink (e.g., a bottom panel)."""
        self._hud_text_sink = sink
        if sink is not None and self._hud_overlay_mode == "overlay":
            # When a sink exists, prefer panel mode to avoid drawing over the viewport.
            self._hud_overlay_mode = "panel"

    def set_hud_overlay_mode(self, mode: str) -> None:
        """
        Control whether the HUD is drawn over the viewport or redirected to a dock/panel.
        mode: "overlay" (default) or "panel" to suppress painting on the viewport.
        """
        mode_norm = str(mode or "overlay").lower()
        if mode_norm not in {"overlay", "panel"}:
            mode_norm = "overlay"
        self._hud_overlay_mode = mode_norm
        self.update()

    def scrub_to(self, normalized_t: float) -> None:
        if self.engine is None:
            return
        target_time = max(0.0, min(1.0, normalized_t)) * self.engine.loop_duration
        state = self.engine.set_time(target_time)
        self.timeUpdated.emit(state.time)
        self.phaseChanged.emit(state.phase.value)
        self.update()




    def _camera_mvp(self, aspect: float, camera: Mapping[str, Any]) -> np.ndarray:
        center, radius = self._scene_bounds()
        default_pos = center + np.array([radius * 1.5, -radius * 1.2, radius * 0.6], dtype="f4")
        pos = np.array(camera.get("pos", default_pos), dtype="f4")
        target = np.array(camera.get("target", center), dtype="f4")
        up = np.array(camera.get("up", (0.0, 0.0, 1.0)), dtype="f4")
        fov = math.radians(float(camera.get("fov_deg", 45.0)))
        view = HelixModernWidget._look_at(pos, target, up)
        cam_dist = max(1e-3, float(np.linalg.norm(pos - target)))
        near = max(0.05, cam_dist - radius * 2.0)
        far = max(near + 5.0, cam_dist + radius * 2.5)
        proj = HelixModernWidget._perspective(fov, aspect, near, far)
        return (proj @ view).astype("f4")

    def _helix_mvp(self, aspect: float) -> np.ndarray:
        """Interactive camera for helix mode (orbit / pan / zoom)."""
        center, radius = self._scene_bounds()
        r = max(radius, 1.0)

        cp = math.cos(self._cam_pitch)
        sp = math.sin(self._cam_pitch)
        cy = math.cos(self._cam_yaw)
        sy = math.sin(self._cam_yaw)
        tx, ty, tz = self._cam_target

        # Eye derived from interactive yaw/pitch/distance around the target.
        eye = np.array(
            [
                tx + self._cam_distance * cp * cy,
                ty + self._cam_distance * cp * sy,
                tz + self._cam_distance * sp,
            ],
            dtype="f4",
        )
        target = np.array([tx, ty, tz], dtype="f4")
        up = np.array([0.0, 0.0, 1.0], dtype="f4")

        view = HelixModernWidget._look_at(eye, target, up)

        cam_dist = max(1e-3, float(np.linalg.norm(eye - target)))
        # Near/far tied to scene bounds for stable depth precision
        near = max(0.01, cam_dist - r * 2.5)
        far = max(near + 1.0, cam_dist + r * 2.5)
        proj = HelixModernWidget._perspective(math.radians(40.0), aspect, near, far)

        return (proj @ view).astype("f4")


    def _reset_camera_defaults(self) -> None:
        if self._rail_mode is RailViewMode.FLAT:
            self._cam_target = np.array([0.0, 0.0, 0.0], dtype="f4")
            self._cam_yaw = 0.0
            self._cam_distance = 1.0   # show full [-0.9..0.9] width
            self._cam_pitch = 0.0
        else:
            center, radius = self._scene_bounds()
            self._cam_target = np.array(center, dtype="f4")
            w = max(1.0, float(self.width() or 1))
            h = max(1.0, float(self.height() or 1))
            aspect = w / h
            self._cam_distance = fit_perspective_orbit_distance(
                radius=float(radius),
                fov_y_deg=40.0,
                aspect=float(aspect),
                margin=1.35,
                min_distance=1.0,
            )
            self._cam_pitch = 0.38

            # Bias yaw so the helix is never perfectly symmetric and the
            # template strand tends to read as the nearer rail at the cut locus.
            yaw = -0.55
            try:
                cut_idx = self._cut_index_from_spec()
                pts = self._bp_positions_template
                if cut_idx is not None and pts is not None and pts.size and pts.ndim == 2 and pts.shape[1] >= 2:
                    i = max(0, min(int(pts.shape[0] - 1), int(cut_idx)))
                    x = float(pts[i, 0])
                    y = float(pts[i, 1])
                    if math.isfinite(x) and math.isfinite(y) and (abs(x) + abs(y)) > 1e-6:
                        # Look from the opposite side of the template tangent so it reads "in front".
                        yaw = math.atan2(y, x) + math.pi + 0.30
            except Exception:
                yaw = -0.55
            self._cam_yaw = float(yaw)
        self._update_camera_meta()
        
    def reset_camera(self) -> None:
        """Public slot to reset the interactive camera."""
        self._reset_camera_defaults()
        self.update()

    def _sync_camera_state_from_meta(self, camera: Mapping[str, Any]) -> None:
        target = camera.get("target", (0.0, 0.0, 0.0))
        pos = camera.get("pos")
        if pos is None:
            self._reset_camera_defaults()
            return
        tx, ty, tz = target
        dx = pos[0] - tx
        dy = pos[1] - ty
        dz = pos[2] - tz
        distance = max(0.5, math.sqrt(dx * dx + dy * dy + dz * dz))
        yaw = math.atan2(dy, dx)
        pitch = math.asin(max(-0.999, min(0.999, dz / distance)))
        self._cam_target = np.array([tx, ty, tz], dtype="f4")
        self._cam_distance = distance
        self._cam_yaw = yaw
        self._cam_pitch = pitch

    def _update_camera_meta(self) -> None:
        cp = math.cos(self._cam_pitch)
        sp = math.sin(self._cam_pitch)
        cy = math.cos(self._cam_yaw)
        sy = math.sin(self._cam_yaw)
        tx, ty, tz = self._cam_target
        px = tx + self._cam_distance * cp * cy
        py = ty + self._cam_distance * cp * sy
        pz = tz + self._cam_distance * sp
        camera = {
            "pos": (float(px), float(py), float(pz)),
            "target": (float(tx), float(ty), float(tz)),
            "up": (0.0, 0.0, 1.0),
            "fov_deg": 45.0,
        }
        self._custom_camera = camera
        if self._spec is not None:
            meta = self._spec.metadata or {}
            meta["camera"] = camera
            self._spec.metadata = meta

    def _scene_bounds(self) -> tuple[np.ndarray, float]:
        vertices: np.ndarray | None
        if self._world_rail_vertices is not None:
            vertices = self._world_rail_vertices
        elif self.engine is not None:
            vertices = getattr(self.engine.helix_geometry, "rail_vertices", None)
            if vertices is None or not vertices.size:
                return np.zeros(3, dtype="f4"), 5.0
        else:
            return np.zeros(3, dtype="f4"), 5.0
        mn = vertices.min(axis=0)
        mx = vertices.max(axis=0)
        center = (mn + mx) * 0.5
        radius = float(np.linalg.norm(mx - center))
        return center.astype("f4"), max(radius, 1.0)

    def _pick_ribbon_at(self, pos: QPointF) -> None:
        if (
            self._arc_cpu is None
            or not self._arc_ranges
            or not self._arc_events
            or self._arc_cpu.size == 0
        ):
            self._selected_kind = None
            return

        w, h = self.pick_buffer_size_px()
        aspect = float(w) / max(1.0, float(h))
        time_value = 0.0
        if self.engine is not None:
            time_value = float(getattr(self.engine.state, "time", 0.0))
        mvp = self._mvp_matrix(aspect, orbit_time=time_value)

        px, py = self.logical_pos_to_pick_px(pos)
        # Click in NDC (sample at pixel center to match ID-buffer style picking).
        ndc_x = ((float(px) + 0.5) / float(w)) * 2.0 - 1.0
        ndc_y = 1.0 - ((float(py) + 0.5) / float(h)) * 2.0

        verts = self._arc_cpu[:, :3].astype("f4")
        ones = np.ones((verts.shape[0], 1), dtype="f4")
        hom = np.hstack([verts, ones])
        mvp_gl = np.ascontiguousarray(mvp.T, dtype="f4")  # Same layout used for GPU upload
        clip = hom @ mvp_gl
        w_comp = np.clip(clip[:, 3:4], 1e-6, None)
        ndc = clip[:, :2] / w_comp

        dx = (ndc[:, 0] - ndc_x) * (w * 0.5)
        dy = (ndc[:, 1] - ndc_y) * (h * 0.5)
        dist2 = dx * dx + dy * dy
        idx = int(np.argmin(dist2))
        if dist2[idx] > 10.0 * 10.0:
            self._selected_kind = None
            self.update()
            self.eventPicked.emit(None)
            return

        arc_index = 0
        for i, (start, count) in enumerate(self._arc_ranges):
            if start <= idx < start + count:
                arc_index = i
                break
        if arc_index >= len(self._arc_events):
            self._selected_kind = None
            self.update()
            self.eventPicked.emit(None)
            return

        ev = self._arc_events[arc_index]
        # kind codes: 0=cut, 2=repair
        self._selected_kind = 0.0 if ev.type in (EditEventType.NICK_PRIMARY, EditEventType.CUT) else 2.0
        self.eventPicked.emit(ev)
        self.update()

    # Interaction events -----------------------------------------------
    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        self._last_mouse_pos = event.position()
        try:
            self._record_dpi_debug_input(event.position())
        except Exception:
            pass
        # Manual camera interaction always wins over auto-fit easing.
        self._cam_ease_target = None
        self._cam_ease_distance = None
        if event.button() == Qt.LeftButton:
            self._drag_mode = "orbit"
        elif event.button() == Qt.MiddleButton:
            self._drag_mode = "pan"
        elif event.button() == Qt.RightButton:
            if self._rail_mode is RailViewMode.FLAT:
                self._drag_mode = "pan"
            elif event.modifiers() & Qt.ControlModifier:
                self._drag_mode = "pan"
            else:
                self._drag_mode = None
        else:
            self._drag_mode = None
        if (
            event.button() == Qt.LeftButton
            and self._mode == "3d"
            and self._rail_mode is RailViewMode.FLAT
        ):
            self._pick_ribbon_at(event.position())
        self._signal_interaction()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # type: ignore[override]
        self._drag_mode = None
        self._last_mouse_pos = None
        super().mouseReleaseEvent(event)

    def mouseMoveEvent(self, event) -> None:  # type: ignore[override]
        try:
            self._record_dpi_debug_input(event.position())
        except Exception:
            pass
        if self._last_mouse_pos is None or self._drag_mode is None:
            super().mouseMoveEvent(event)
            return
        pos = event.position()
        dx = pos.x() - self._last_mouse_pos.x()
        dy = pos.y() - self._last_mouse_pos.y()
        self._last_mouse_pos = pos
        if self._drag_mode == "orbit":
            self._cam_yaw += dx * self._cam_sensitivity
            self._cam_pitch -= dy * self._cam_sensitivity
            limit = math.radians(89.0)
            self._cam_pitch = max(-limit, min(limit, self._cam_pitch))
        elif self._drag_mode == "pan":
            if self._rail_mode is RailViewMode.FLAT:
                # 2D pan in screen space for flat rails (more predictable).
                width = max(1.0, float(self.width()))
                height = max(1.0, float(self.height()))
                world_per_px_x = (2.0 * self._cam_distance) / width
                world_per_px_y = (2.0 * self._cam_distance) / height
                scale = self._pan_sensitivity_2d
                self._cam_target[0] -= dx * world_per_px_x * scale
                self._cam_target[1] += dy * world_per_px_y * scale
            else:
                cy = math.cos(self._cam_yaw)
                sy = math.sin(self._cam_yaw)
                cp = math.cos(self._cam_pitch)
                sp = math.sin(self._cam_pitch)
                forward = np.array([cp * cy, cp * sy, sp], dtype="f4")
                up = np.array([0.0, 0.0, 1.0], dtype="f4")
                right = np.cross(forward, up)
                rn = float(np.linalg.norm(right))
                if rn > 1e-6:
                    right /= rn
                else:
                    right = np.array([1.0, 0.0, 0.0], dtype="f4")
                pan_scale = self._cam_distance * self._pan_sensitivity
                self._cam_target -= dx * pan_scale * right
                self._cam_target += dy * pan_scale * up
        self._update_camera_meta()
        self._signal_interaction()
        self.update()

    def wheelEvent(self, event) -> None:  # type: ignore[override]
        try:
            self._record_dpi_debug_input(event.position())
        except Exception:
            pass
        delta = event.angleDelta().y() / 120.0
        # Manual zoom wins over any in-flight camera easing.
        self._cam_ease_target = None
        self._cam_ease_distance = None
        factor = math.exp(-delta * self._zoom_sensitivity)
        self._cam_distance = max(0.5, self._cam_distance * factor)
        self._update_camera_meta()
        self._signal_interaction()
        self.update()
        super().wheelEvent(event)

    def keyPressEvent(self, event) -> None:  # type: ignore[override]
        key = event.key()
        mods = event.modifiers()
        shift = bool(mods & Qt.ShiftModifier)

        if key == Qt.Key_H and mods == Qt.NoModifier:
            try:
                self.hudToggleRequested.emit()
            except Exception:
                pass
            return
        if key == Qt.Key_L and mods == Qt.NoModifier:
            try:
                self.legendToastRequested.emit()
            except Exception:
                pass
            return

        if key == Qt.Key_R:
            self._signal_interaction()
            self._reset_camera_defaults()
            self.update()
            return
        if key == Qt.Key_Space:
            self._signal_interaction()
            try:
                self.set_playing(not self._playing)
            except Exception:
                self._playing = not self._playing
                self.update()
            return

        # Timeline interrogation hotkeys:
        # - Left/Right (or P/N) jumps between storyboard events
        # - ,/. steps one frame (Shift = 10 frames)
        if key in (Qt.Key_Right, Qt.Key_N, Qt.Key_BracketRight):
            self._signal_interaction()
            self._snap_to_event(+1)
            return
        if key in (Qt.Key_Left, Qt.Key_P, Qt.Key_BracketLeft):
            self._signal_interaction()
            self._snap_to_event(-1)
            return
        if key in (Qt.Key_Period, Qt.Key_Greater):
            self._signal_interaction()
            self._step_frames(10 if shift else 1)
            return
        if key in (Qt.Key_Comma, Qt.Key_Less):
            self._signal_interaction()
            self._step_frames(-(10 if shift else 1))
            return
        super().keyPressEvent(event)

    def _signal_interaction(self) -> None:
        now = clock.monotonic()
        last = float(getattr(self, "_last_interaction_emit_s", 0.0))
        if (now - last) < 0.05:
            return
        self._last_interaction_emit_s = float(now)
        try:
            self.userInteracted.emit()
        except Exception:
            pass

    def _assert_geometry(self) -> None:
        if not self.engine:
            return
        try:
            rv = self.engine.helix_geometry.rail_vertices
            if rv.size == 0:
                return
            n = rv.shape[0] // 2
            if n == 0:
                return
            strand_a = rv[:n]
            strand_b = rv[n:]

            # z should move monotonically upward
            assert np.all(np.diff(strand_a[:, 2]) >= -1e-6)
            assert np.all(np.diff(strand_b[:, 2]) >= -1e-6)
            assert np.allclose(strand_a[:, 2], strand_b[:, 2], atol=1e-3)

            # radii roughly match, angle diff ≈ π
            ra = np.linalg.norm(strand_a[:, :2], axis=1)
            rb = np.linalg.norm(strand_b[:, :2], axis=1)
            assert np.allclose(ra, rb, atol=0.2), "Strand radii mismatch"

            ang_a = np.arctan2(strand_a[:, 1], strand_a[:, 0])
            ang_b = np.arctan2(strand_b[:, 1], strand_b[:, 0])
            delta = (ang_a - ang_b + np.pi) % (2 * np.pi) - np.pi
            assert np.allclose(np.abs(np.abs(delta) - np.pi), 0.0, atol=0.4), "Strands not opposite in angle"
        except AssertionError as exc:
            print(f"[HelixModernWidget] Geometry invariant failed: {exc}", flush=True)


class HelixControlPanel(QWidget):
    """Side panel with edit selector, transport, and toggles."""

    specSelected = Signal(int)
    timeScrubbed = Signal(float)
    playToggled = Signal(bool)
    templateToggled = Signal(bool)
    flapToggled = Signal(bool)
    baseShowToggled = Signal(bool)
    baseMaxChanged = Signal(int)
    baseFadeChanged = Signal(float)
    debugHudToggled = Signal(bool)
    railModeChanged = Signal(str)
    animationToggled = Signal(bool)
    viewLegendChanged = Signal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._block_slider = False
        self._benchmark_worker: BenchmarkWorker | None = None
        self._benchmark_config_args = {
            "backends": ["cpu-reference", "native-cpu", "gpu"],
            "crispr_shapes": [(1, 512, 20), (96, 4096, 20), (256, 16384, 20)],
            "prime_workloads": [(32, 2000, 20), (64, 4000, 20)],
            "seed": 0,
        }
        self._bench_cache_path = Path.home() / ".helix" / "benchmarks.json"
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        self.phase_label = QLabel("Phase: approach", self)
        layout.addWidget(self.phase_label)

        self.spec_combo = QComboBox(self)
        self.spec_combo.currentIndexChanged.connect(self.specSelected.emit)
        layout.addWidget(self.spec_combo)

        self.play_button = QPushButton("Pause", self)
        self.play_button.setCheckable(True)
        self.play_button.setChecked(True)
        self.play_button.toggled.connect(self._on_play_toggled)
        layout.addWidget(self.play_button)

        self.animation_toggle = QCheckBox("Animate", self)
        self.animation_toggle.setChecked(True)
        self.animation_toggle.toggled.connect(self.animationToggled.emit)
        layout.addWidget(self.animation_toggle)

        slider_label = QLabel("Time", self)
        layout.addWidget(slider_label)
        self.time_slider = QSlider(Qt.Horizontal, self)
        self.time_slider.setRange(0, 1000)
        self.time_slider.valueChanged.connect(self._on_slider)
        layout.addWidget(self.time_slider)

        self.template_toggle = QCheckBox("Show template strand", self)
        self.template_toggle.setChecked(True)
        self.template_toggle.toggled.connect(self.templateToggled.emit)
        layout.addWidget(self.template_toggle)

        self.flap_toggle = QCheckBox("Show flap/template path", self)
        self.flap_toggle.setChecked(True)
        self.flap_toggle.toggled.connect(self.flapToggled.emit)
        layout.addWidget(self.flap_toggle)

        self.bases_toggle = QCheckBox("Show bases", self)
        self.bases_toggle.setChecked(True)
        self.bases_toggle.toggled.connect(self.baseShowToggled.emit)
        layout.addWidget(self.bases_toggle)

        self.debug_hud_toggle = QCheckBox("Show rail debug HUD", self)
        self.debug_hud_toggle.setChecked(True)
        self.debug_hud_toggle.toggled.connect(self.debugHudToggled.emit)
        layout.addWidget(self.debug_hud_toggle)

        self.base_max_spin = QSpinBox(self)
        self.base_max_spin.setRange(10, 2000)
        self.base_max_spin.setValue(80)
        self.base_max_spin.setPrefix("Max bases: ")
        self.base_max_spin.valueChanged.connect(self.baseMaxChanged.emit)
        layout.addWidget(self.base_max_spin)

        self.base_fade_spin = QDoubleSpinBox(self)
        self.base_fade_spin.setRange(0.2, 5.0)
        self.base_fade_spin.setSingleStep(0.1)
        self.base_fade_spin.setValue(1.4)
        self.base_fade_spin.setPrefix("Fade dist: ")
        self.base_fade_spin.valueChanged.connect(self.baseFadeChanged.emit)
        layout.addWidget(self.base_fade_spin)

        self.engine_box = QGroupBox("Engine Health", self)
        engine_layout = QVBoxLayout(self.engine_box)
        self.backend_label = QLabel("CRISPR engine: --", self.engine_box)
        engine_layout.addWidget(self.backend_label)
        self.physics_backend_label = QLabel("Physics backend: --", self.engine_box)
        engine_layout.addWidget(self.physics_backend_label)
        self.scoring_label = QLabel("Scoring versions: -- / --", self.engine_box)
        engine_layout.addWidget(self.scoring_label)
        self.last_bench_label = QLabel("Last bench: --", self.engine_box)
        engine_layout.addWidget(self.last_bench_label)
        self.benchmark_status = QLabel("Benchmark not run", self.engine_box)
        engine_layout.addWidget(self.benchmark_status)
        self.run_benchmark_button = QPushButton("Run Benchmark", self.engine_box)
        self.run_benchmark_button.clicked.connect(self._on_run_benchmark)
        engine_layout.addWidget(self.run_benchmark_button)
        self.benchmark_output = QTextBrowser(self.engine_box)
        self.benchmark_output.setReadOnly(True)
        self.benchmark_output.setMinimumHeight(120)
        engine_layout.addWidget(self.benchmark_output)
        self._load_last_benchmark()
        layout.addWidget(self.engine_box)

        self.physics_box = QGroupBox("Prime Physics Score", self)
        phys_layout = QFormLayout(self.physics_box)
        self.pbs_label = QLabel("--", self.physics_box)
        self.pbs_hint_label = QLabel("", self.physics_box)
        phys_layout.addRow("PBS ΔG", self.pbs_label)
        phys_layout.addRow("PBS hint", self.pbs_hint_label)
        self.rtt_label = QLabel("--", self.physics_box)
        phys_layout.addRow("RT path ΔG", self.rtt_label)
        self.flap_label = QLabel("--", self.physics_box)
        phys_layout.addRow("Flap ΔΔG", self.flap_label)
        self.micro_label = QLabel("--", self.physics_box)
        phys_layout.addRow("Microhomology", self.micro_label)
        self.nick_label = QLabel("--", self.physics_box)
        phys_layout.addRow("Nick distance", self.nick_label)
        self.p_rt_label = QLabel("--", self.physics_box)
        phys_layout.addRow("P_RT", self.p_rt_label)
        self.p_flap_label = QLabel("--", self.physics_box)
        phys_layout.addRow("P_flap", self.p_flap_label)
        self.e_pred_label = QLabel("--", self.physics_box)
        phys_layout.addRow("E_pred", self.e_pred_label)
        layout.addWidget(self.physics_box)
        self.physics_box.hide()

        mode_label = QLabel("Rail view", self)
        layout.addWidget(mode_label)
        self.rail_mode_combo = QComboBox(self)
        self.rail_mode_combo.addItem("Flat rails", "flat")
        self.rail_mode_combo.addItem("3D helix", "helix")
        self.rail_mode_combo.setCurrentIndex(0)
        self.rail_mode_combo.currentIndexChanged.connect(self._on_rail_mode_changed)
        layout.addWidget(self.rail_mode_combo)

        self.legend_box = QGroupBox("Legend", self)
        self.legend_label = QLabel("", self.legend_box)
        self.legend_label.setWordWrap(True)
        leg_layout = QVBoxLayout(self.legend_box)
        leg_layout.addWidget(self.legend_label)
        layout.addWidget(self.legend_box)

        # Quiet abstraction badge (model layer)
        self.model_layer_box = QGroupBox("Model layer", self)
        ml_layout = QVBoxLayout(self.model_layer_box)
        self.model_layer_label = QLabel("--", self.model_layer_box)
        self.model_layer_label.setWordWrap(True)
        self.model_layer_hint = QLabel("", self.model_layer_box)
        self.model_layer_hint.setWordWrap(True)
        self.model_layer_hint.setStyleSheet(f"color: {_css_rgb(159, 182, 255)};")
        ml_layout.addWidget(self.model_layer_label)
        ml_layout.addWidget(self.model_layer_hint)
        layout.addWidget(self.model_layer_box)

        self.selection_box = QGroupBox("Selection", self)
        sel_layout = QFormLayout(self.selection_box)
        self.sel_event = QLabel("--", self.selection_box)
        self.sel_index = QLabel("--", self.selection_box)
        self.sel_time = QLabel("--", self.selection_box)
        self.sel_rt = QLabel("--", self.selection_box)
        self.sel_pbs = QLabel("--", self.selection_box)
        self.sel_flap = QLabel("--", self.selection_box)
        self.sel_epred = QLabel("--", self.selection_box)
        sel_layout.addRow("Event", self.sel_event)
        sel_layout.addRow("Index", self.sel_index)
        sel_layout.addRow("t", self.sel_time)
        sel_layout.addRow("RT (start,len)", self.sel_rt)
        self.sel_meaning = QLabel("--", self.selection_box)
        self.sel_meaning.setWordWrap(True)
        sel_layout.addRow("Meaning", self.sel_meaning)
        sel_layout.addRow("PBS ΔG", self.sel_pbs)
        sel_layout.addRow("Flap ΔΔG", self.sel_flap)
        sel_layout.addRow("E_pred", self.sel_epred)
        self.sel_outcomes = QLabel("--", self.selection_box)
        sel_layout.addRow("Outcomes", self.sel_outcomes)
        layout.addWidget(self.selection_box)

        layout.addStretch(1)

    def set_specs(self, labels: Sequence[str]) -> None:
        block = self.spec_combo.blockSignals(True)
        self.spec_combo.clear()
        self.spec_combo.addItems(labels)
        self.spec_combo.blockSignals(block)

    def set_time_norm(self, value: float) -> None:
        clamped = max(0.0, min(1.0, value))
        self._block_slider = True
        self.time_slider.setValue(int(clamped * 1000))
        self._block_slider = False

    def set_phase(self, phase: str) -> None:
        self.phase_label.setText(f"Phase: {phase}")

    def set_engine_status(self, text: str) -> None:
        self.backend_label.setText(text)

    def set_engine_info(self, engine) -> None:
        try:
            name = getattr(engine, "name", "") or getattr(engine, "backend", "")
            backend = getattr(engine, "backend", "")
            backend_reason = getattr(engine, "backend_reason", None)
            backend_label = {
                "gpu": "GPU",
                "native-cpu": "CPU (native)",
                "cpu-reference": "CPU (reference)",
            }.get(str(backend), str(backend))
            self.backend_label.setText(f"Physics engine: {name} · {backend_label}")
            if backend_reason:
                self.physics_backend_label.setText(f"physics_backend: {backend} ({backend_reason})")
            else:
                self.physics_backend_label.setText(f"physics_backend: {backend}")
            csv = getattr(engine, "crispr_scoring_version", None)
            psv = getattr(engine, "prime_scoring_version", None)
            if csv is not None and psv is not None:
                self.scoring_label.setText(f"Scoring versions: CRISPR {csv} | Prime {psv}")
        except Exception:
            pass

    def set_scoring_versions(self, crispr: str, prime: str) -> None:
        self.scoring_label.setText(f"Scoring versions: CRISPR {crispr} | Prime {prime}")

    def set_prime_physics_score(self, score: Mapping[str, Any] | None) -> None:
        if not score:
            self.physics_box.hide()
            return
        self.physics_box.show()
        pbs_dg = float(score.get("pbs_dG", 0.0))
        self.pbs_label.setText(f"{pbs_dg:.2f} kcal/mol")
        self.pbs_hint_label.setText(self._pbs_hint(pbs_dg))
        rt_cum = score.get("rt_cum_dG") or []
        rt_final = float(rt_cum[-1]) if rt_cum else 0.0
        self.rtt_label.setText(f"{rt_final:.2f} kcal/mol")
        flap_ddg = float(score.get("flap_ddG", 0.0))
        self.flap_label.setText(f"{flap_ddg:.2f}")
        micro = int(score.get("microhomology", 0))
        self.micro_label.setText(f"{micro} nt")
        self.nick_label.setText(str(int(score.get("nick_distance", 0))))
        p_rt = float(score.get("P_RT", 0.0))
        p_flap = float(score.get("P_flap", 0.0))
        self.p_rt_label.setText(f"{p_rt:.3f}")
        self.p_flap_label.setText(f"{p_flap:.3f}")
        e_pred = float(score.get("E_pred", 0.0))
        self.e_pred_label.setText(f"{e_pred:.3f}")
        self.e_pred_label.setStyleSheet(f"color: {self._score_color(e_pred)};")

    def _on_slider(self, value: int) -> None:
        if self._block_slider:
            return
        self.timeScrubbed.emit(value / 1000.0)

    def _on_rail_mode_changed(self, index: int) -> None:
        mode = self.rail_mode_combo.itemData(index) or "flat"
        self.railModeChanged.emit(str(mode))
        self.viewLegendChanged.emit(str(mode))

    def set_legend(self, mode: str) -> None:
        if mode == RailViewMode.HELIX.value:
            self.legend_label.setText(
                "Helix view maps the same coordinate into 3D so spatial relationships are easier to read. "
                "Helix axis = genome index; two strands are the same genome in 3D. Crossovers are visual, not strand swapping."
            )
        else:
            self.legend_label.setText(
                "Flat view unwraps the genome into a straight coordinate so you can see event timing and positions precisely. "
                "X = genome index (0→N). Top rail = template, bottom rail = opposite. Ribbons = events revealed as time advances."
            )

    def set_model_layer(self, label: str, detail: str = "") -> None:
        self.model_layer_label.setText(label or "--")
        self.model_layer_hint.setText(detail)

    def set_selection(self, ev: EditEvent | None, physics: Mapping[str, Any] | None = None) -> None:
        if ev is None:
            self.sel_event.setText("--")
            self.sel_index.setText("--")
            self.sel_time.setText("--")
            self.sel_rt.setText("--")
            self.sel_pbs.setText("--")
            self.sel_flap.setText("--")
            self.sel_epred.setText("--")
            self.sel_meaning.setText("--")
            self.sel_outcomes.setText("--")
            return
        ev_type = getattr(ev, "type", None)
        self.sel_event.setText(getattr(ev_type, "name", str(ev_type)))
        idx = getattr(ev, "index", getattr(ev, "start", None))
        self.sel_index.setText(str(idx) if idx is not None else "--")
        t_val = getattr(ev, "t", None)
        self.sel_time.setText(f"{float(t_val):.2f}" if t_val is not None else "--")
        rt_start = getattr(ev, "start", None)
        rt_len = getattr(ev, "length", None)
        if rt_start is not None or rt_len is not None:
            self.sel_rt.setText(f"{rt_start or 0}, {rt_len or 0}")
        else:
            self.sel_rt.setText("--")
        meaning_map = {
            "APPROACH": "Complex approaches the target locus.",
            "RECOGNITION": "Guide binds and PAM is checked.",
            "CUT": "A cut/nick is made at the target index.",
            "NICK_PRIMARY": "A cut/nick is made at the target index.",
            "PRIME": "RT synthesis extends from the pegRNA.",
            "PRIME_INIT": "RT synthesis extends from the pegRNA.",
            "RT_SYNTHESIS": "RT synthesis extends from the pegRNA.",
            "REPAIR": "Flaps resolve; repair pathways compete.",
            "FLAP_RESOLUTION": "Flaps resolve; repair pathways compete.",
            "REPAIR_COMPLETE": "Repair completes; outcome is finalized.",
            "RESOLVE": "Repair completes; outcome is finalized.",
        }
        ev_name = getattr(ev_type, "name", "") if ev_type else ""
        self.sel_meaning.setText(meaning_map.get(ev_name, "Event selected."))
        if physics:
            pbs_dg = physics.get("pbs_dG")
            flap_ddg = physics.get("flap_ddG")
            e_pred = physics.get("E_pred")
            self.sel_pbs.setText(f"{float(pbs_dg):.2f}" if pbs_dg is not None else "--")
            self.sel_flap.setText(f"{float(flap_ddg):.2f}" if flap_ddg is not None else "--")
            self.sel_epred.setText(f"{float(e_pred):.3f}" if e_pred is not None else "--")
            conf = physics.get("confidence") if isinstance(physics, Mapping) else None
            if conf is not None:
                self.sel_meaning.setText(self.sel_meaning.text() + f" · Confidence≈{float(conf):.2f}")
        else:
            self.sel_pbs.setText("--")
            self.sel_flap.setText("--")
            self.sel_epred.setText("--")
        # Outcomes count from physics if present
        if physics and "outcomes" in physics and isinstance(physics["outcomes"], Sequence) and not isinstance(physics["outcomes"], (str, bytes)):
            self.sel_outcomes.setText(str(len(physics["outcomes"])))
        else:
            self.sel_outcomes.setText("--")

    def _on_play_toggled(self, checked: bool) -> None:
        self.play_button.setText("Pause" if checked else "Play")
        self.playToggled.emit(checked)

    def _on_run_benchmark(self) -> None:
        if self._benchmark_worker is not None:
            return
        self.run_benchmark_button.setEnabled(False)
        self.benchmark_status.setText("Running benchmark…")
        self.benchmark_output.clear()
        self._benchmark_worker = BenchmarkWorker(self._benchmark_config_args, self)
        self._benchmark_worker.completed.connect(self._on_benchmark_complete)
        self._benchmark_worker.failed.connect(self._on_benchmark_failed)
        self._benchmark_worker.finished.connect(self._on_benchmark_finished)
        self._benchmark_worker.start()

    def _on_benchmark_complete(self, payload: Mapping[str, Any]) -> None:
        self.benchmark_status.setText("Benchmark complete")
        self._update_benchmark_output(payload)
        self._save_last_benchmark(payload)

    def _on_benchmark_failed(self, message: str) -> None:
        self.benchmark_status.setText(f"Benchmark failed: {message}")

    def _on_benchmark_finished(self) -> None:
        self.run_benchmark_button.setEnabled(True)
        self._benchmark_worker = None

    def _update_benchmark_output(self, payload: Mapping[str, Any]) -> None:
        lines = ["CRISPR:"]
        for entry in payload.get("benchmarks", {}).get("crispr", []):
            if "error" in entry:
                lines.append(
                    f"  {entry.get('backend_requested')}: {entry['error']}"
                )
            else:
                lines.append(
                    f"  {entry.get('backend_used') or entry.get('backend_requested')}: {entry.get('mpairs_per_s', 0):.2f} MPairs/s"
                )
        lines.append("Prime:")
        for entry in payload.get("benchmarks", {}).get("prime", []):
            lines.append(
                f"  {entry.get('backend_used') or entry.get('backend_requested')}: {entry.get('predictions_per_s', 0):.2f} preds/sec"
            )
        self.benchmark_output.setPlainText("\n".join(lines))

        # set summary label
        try:
            crispr_vals = [e.get("mpairs_per_s") for e in payload.get("benchmarks", {}).get("crispr", []) if "mpairs_per_s" in e]
            prime_vals = [e.get("predictions_per_s") for e in payload.get("benchmarks", {}).get("prime", []) if "predictions_per_s" in e]
            backend = None
            if payload.get("benchmarks", {}).get("crispr"):
                backend = payload["benchmarks"]["crispr"][0].get("backend_used") or payload["benchmarks"]["crispr"][0].get("backend_requested")
            summary = "Last bench: --"
            if crispr_vals or prime_vals:
                summary = "Last bench: "
                if crispr_vals:
                    summary += f"CRISPR {max(crispr_vals):.1f} MPairs/s"
                if prime_vals:
                    summary += " · " if crispr_vals else ""
                    summary += f"PRIME {max(prime_vals)/1000.0:.1f}k preds/s"
                if backend:
                    summary += f" (backend={backend})"
            self.last_bench_label.setText(summary)
        except Exception:
            pass

    def _load_last_benchmark(self) -> None:
        try:
            if not self._bench_cache_path.exists():
                return
            raw = json.loads(self._bench_cache_path.read_text(encoding="utf8"))
            bench = raw.get("last_benchmark") or {}
            summary = "Last bench: --"
            c = bench.get("crispr_mpairs_per_s")
            p = bench.get("prime_preds_per_s")
            if c or p:
                summary = "Last bench: "
                if c:
                    summary += f"CRISPR {float(c):.1f} MPairs/s"
                if p:
                    summary += (" · " if c else "") + f"PRIME {float(p)/1000.0:.1f}k preds/s"
            if bench.get("backend"):
                summary += f" (backend={bench.get('backend')})"
            if bench.get("timestamp"):
                summary += f" at {bench.get('timestamp')}"
            self.last_bench_label.setText(summary)
        except Exception:
            pass

    def _save_last_benchmark(self, payload: Mapping[str, Any]) -> None:
        try:
            cfg_dir = self._bench_cache_path.parent
            cfg_dir.mkdir(parents=True, exist_ok=True)
            crispr = payload.get("benchmarks", {}).get("crispr", [])
            prime = payload.get("benchmarks", {}).get("prime", [])
            crispr_vals = [e.get("mpairs_per_s") for e in crispr if "mpairs_per_s" in e]
            prime_vals = [e.get("predictions_per_s") for e in prime if "predictions_per_s" in e]
            backend = None
            if crispr:
                backend = crispr[0].get("backend_used") or crispr[0].get("backend_requested")
            bench_blob = {
                "backend": backend,
                "engine_name": backend,
                "gpu_name": payload.get("env", {}).get("gpu_name"),
                "crispr_mpairs_per_s": max(crispr_vals) if crispr_vals else None,
                "prime_preds_per_s": max(prime_vals) if prime_vals else None,
                "timestamp": clock.utc_now_iso(),
            }
            self._bench_cache_path.write_text(json.dumps({"last_benchmark": bench_blob}, indent=2), encoding="utf8")
            self.last_bench_label.setText(f"Last bench: CRISPR {bench_blob.get('crispr_mpairs_per_s') or '--'} MPairs/s")
        except Exception:
            pass

    def _pbs_hint(self, dg: float) -> str:
        if dg <= -10:
            return "Strong binding"
        if dg <= -3:
            return "Within target"
        return "Weak binding"

    def _score_color(self, value: float) -> str:
        clamped = max(0.0, min(1.0, value))
        red = int((1.0 - clamped) * 200 + 55)
        green = int(clamped * 200 + 55)
        return _css_rgb(red, green, 90)


class HelixModernWindow(QMainWindow):
    """Main window combining the ModernGL viewport and control panel."""

    def __init__(self, specs: Sequence[EditVisualizationSpec]) -> None:
        super().__init__()
        self.setWindowTitle("Helix – ModernGL CRISPR Viz")
        self.viewer = HelixModernWidget(self)
        self.viewer_container = self.viewer
        self._show_floating_hud = False
        self.hud = FloatingHud(self)
        try:
            self.hud.set_hidden(True)
        except Exception:
            pass
        self.hud_anchor = HudAnchor(
            self.viewer_container,
            self.hud,
            should_show=lambda: bool(self._show_floating_hud),
        )
        self.legend_toast = LegendToastOverlay(self)
        self.legend_toast_anchor = HudAnchor(
            self.viewer_container,
            self.legend_toast,
            corner="bottom-left",
            should_show=lambda: self.legend_toast.toast_state() is LegendToastState.ACTIVE,
        )
        self.panel = HelixControlPanel(self)
        self.panel.specSelected.connect(self._on_spec_selected)
        self.panel.timeScrubbed.connect(self.viewer.scrub_to)
        self.panel.playToggled.connect(self.viewer.set_playing)
        self.panel.templateToggled.connect(self.viewer.set_template_visible)
        self.panel.flapToggled.connect(self.viewer.set_flap_visible)
        self.panel.baseShowToggled.connect(self.viewer.set_base_overlay_enabled)
        self.panel.baseMaxChanged.connect(self.viewer.set_base_max)
        self.panel.baseFadeChanged.connect(self.viewer.set_base_fade_distance)
        self.panel.debugHudToggled.connect(self.viewer.set_debug_overlay_enabled)
        self.panel.animationToggled.connect(self.viewer.set_animate)
        self.panel.railModeChanged.connect(self.viewer.set_rail_mode)
        self.panel.viewLegendChanged.connect(self.panel.set_legend)
        self.panel.viewLegendChanged.connect(self.hud.set_view_mode)
        self.viewer.timeUpdated.connect(self._on_time_update)
        self.viewer.phaseChanged.connect(self.panel.set_phase)
        self.viewer.phaseChanged.connect(self.hud.set_phase)
        self.viewer.eventPicked.connect(self._on_event_picked)
        self.viewer.eventPicked.connect(self.hud.set_selected_event)
        self.viewer.userInteracted.connect(self.hud.note_interaction)
        self.viewer.hudToggleRequested.connect(self._toggle_bottom_hud_tab)
        self.viewer.legendToastRequested.connect(self._on_legend_toast_requested)
        self._hud_tab = HudTabPanel(self)
        self.viewer.set_hud_text_sink(self._hud_tab.set_content)
        self.viewer.set_hud_overlay_mode("panel")

        # --- Responsive horizontal layout (ultra-wide friendly) ----------
        self._settings = QSettings("Helix", "ModernViz")
        self._layout_save_timer = QTimer(self)
        self._layout_save_timer.setSingleShot(True)
        self._layout_save_timer.timeout.connect(self._save_layout_settings)

        main = QWidget(self)

        self._layout_bar = QWidget(main)
        bar_layout = QHBoxLayout(self._layout_bar)
        bar_layout.setContentsMargins(8, 6, 8, 6)
        bar_layout.setSpacing(8)
        bar_layout.addWidget(QLabel("Workspace layout", self._layout_bar))
        self._layout_combo = QComboBox(self._layout_bar)
        self._layout_combo.addItem("Standard", "standard")
        self._layout_combo.addItem("Wide", "wide")
        self._layout_combo.addItem("Ultra wide", "ultra")
        bar_layout.addWidget(self._layout_combo)
        policy_env = os.getenv("HELIX_POLICY_PATH")
        policy_label = "Policy: unlocked (dev-fast)" if not policy_env else f"Policy locked: {Path(policy_env).name}"
        self._policy_label = QLabel(policy_label, self._layout_bar)
        bar_layout.addWidget(self._policy_label)
        self._reset_layout_btn = QPushButton("Reset layout", self._layout_bar)
        self._reset_layout_btn.clicked.connect(self._reset_layout_to_preset_defaults)
        bar_layout.addWidget(self._reset_layout_btn)
        bar_layout.addStretch(1)

        self._splitter = QSplitter(Qt.Horizontal, main)
        try:
            self._splitter.setChildrenCollapsible(False)
        except Exception:
            pass
        self._splitter.addWidget(self.viewer_container)
        self._splitter.addWidget(self.panel)
        self._splitter.setStretchFactor(0, 10)
        self._splitter.setStretchFactor(1, 0)
        try:
            self._splitter.splitterMoved.connect(lambda _pos, _idx: self._schedule_layout_save())
        except Exception:
            pass

        # Bottom tabbed area for HUD/diagnostics (dock-style)
        self._bottom_tabs = QTabWidget(main)
        try:
            self._bottom_tabs.setTabPosition(QTabWidget.South)
            self._bottom_tabs.setDocumentMode(True)
        except Exception:
            pass
        self._bottom_tabs.setMinimumHeight(140)
        self._bottom_tabs.addTab(self._hud_tab, "Realtime Viz")

        # Vertical splitter stacks main content over bottom tabs
        self._root_splitter = QSplitter(Qt.Vertical, main)
        try:
            self._root_splitter.setChildrenCollapsible(False)
            self._root_splitter.setCollapsible(1, True)
        except Exception:
            pass
        self._root_splitter.addWidget(self._splitter)
        self._root_splitter.addWidget(self._bottom_tabs)
        self._root_splitter.setStretchFactor(0, 5)
        self._root_splitter.setStretchFactor(1, 1)
        try:
            self._root_splitter.setSizes([720, 200])
        except Exception:
            pass
        try:
            self._root_splitter.splitterMoved.connect(lambda _pos, _idx: self._schedule_layout_save())
        except Exception:
            pass

        # Side rail width policy: sensible defaults, user-resizable, capped.
        try:
            self.panel.setMinimumWidth(360)
            self.panel.setMaximumWidth(640)
        except Exception:
            pass

        try:
            self._layout_combo.currentIndexChanged.connect(self._on_layout_preset_changed)
        except Exception:
            pass
        self._layout_preset = self._load_layout_preset_name()

        root = QVBoxLayout(main)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._layout_bar)
        root.addWidget(self._root_splitter, stretch=1)
        self.setCentralWidget(main)

        self.specs = list(specs)
        self._current_spec: EditVisualizationSpec | None = None
        labels = [spec.metadata.get("label") or spec.metadata.get("name") or spec.edit_type for spec in self.specs]
        self.panel.set_specs(labels)
        backend, allow = resolve_crispr_backend(None, use_gpu=False)
        native_ok = native_backend_available()
        status_parts = [f"CRISPR engine: {backend}"]
        status_parts.append(f"native {'available' if native_ok else 'missing'}")
        status_parts.append(f"fallback {'on' if allow else 'off'}")
        self.panel.set_engine_status(" | ".join(status_parts))
        from ...crispr.physics import (
            CRISPR_SCORING_VERSION,  # local import to avoid cycles
        )
        from ...prime.physics import PRIME_SCORING_VERSION

        self.panel.set_scoring_versions(CRISPR_SCORING_VERSION, PRIME_SCORING_VERSION)
        self.panel.set_legend(RailViewMode.FLAT.value)
        self.hud.set_view_mode(RailViewMode.FLAT.value)
        if self.specs:
            self.viewer.set_spec(self.specs[0])
            self._current_spec = self.specs[0]
            self._update_prime_physics(self.specs[0])
            self.hud.set_spec_meta(self.specs[0])

    def showEvent(self, event):  # type: ignore[override]
        super().showEvent(event)
        QTimer.singleShot(0, self._apply_saved_layout)
        QTimer.singleShot(0, self.hud_anchor._reposition)
        QTimer.singleShot(50, self.hud_anchor._reposition)
        QTimer.singleShot(0, self.legend_toast_anchor._reposition)
        QTimer.singleShot(50, self.legend_toast_anchor._reposition)

    def _load_layout_preset_name(self) -> str:
        try:
            preset = self._settings.value("modern/layout/preset", "standard")
        except Exception:
            preset = "standard"
        preset = str(preset or "standard")
        if preset not in {"standard", "wide", "ultra"}:
            preset = "standard"
        try:
            idx = self._layout_combo.findData(preset)
            if idx >= 0:
                block = self._layout_combo.blockSignals(True)
                self._layout_combo.setCurrentIndex(idx)
                self._layout_combo.blockSignals(block)
        except Exception:
            pass
        return preset

    def _current_layout_preset(self) -> str:
        try:
            preset = str(self._layout_combo.currentData() or "standard")
        except Exception:
            preset = "standard"
        return preset if preset in {"standard", "wide", "ultra"} else "standard"

    def _preset_default_panel_width(self, preset: str) -> int:
        return {"standard": 380, "wide": 440, "ultra": 480}.get(str(preset), 380)

    def _apply_layout_preset(self, preset: str, *, allow_custom: bool) -> None:
        preset = str(preset or "standard")
        if preset not in {"standard", "wide", "ultra"}:
            preset = "standard"

        restored = False
        if allow_custom:
            try:
                key = f"modern/presets/{preset}/splitter_state"
                state = self._settings.value(key, None)
                if state is not None:
                    restored = bool(self._splitter.restoreState(state))
            except Exception:
                restored = False

        if not restored:
            total_w = max(1, int(self.width()))
            panel_w = self._preset_default_panel_width(preset)
            try:
                panel_min = int(getattr(self.panel, "minimumWidth")())
            except Exception:
                panel_min = 360
            try:
                panel_max = int(getattr(self.panel, "maximumWidth")())
            except Exception:
                panel_max = 640

            panel_w = max(panel_min, min(panel_w, panel_max))
            # Keep the canvas usable in narrow windows.
            canvas_min = 520
            panel_w = min(panel_w, max(panel_min, total_w - canvas_min))
            canvas_w = max(1, total_w - panel_w)
            try:
                self._splitter.setSizes([canvas_w, panel_w])
            except Exception:
                pass

    def _apply_saved_layout(self) -> None:
        # Load the currently-selected preset (and its last splitter positions)
        # once the window has a concrete size.
        preset = getattr(self, "_layout_preset", "standard")
        self._apply_layout_preset(str(preset), allow_custom=True)

    def _on_layout_preset_changed(self, _index: int) -> None:
        preset = self._current_layout_preset()
        self._layout_preset = preset
        self._apply_layout_preset(preset, allow_custom=True)
        self._schedule_layout_save()

    def _reset_layout_to_preset_defaults(self) -> None:
        preset = self._current_layout_preset()
        self._layout_preset = preset
        self._apply_layout_preset(preset, allow_custom=False)
        self._save_layout_settings()

    def _schedule_layout_save(self) -> None:
        try:
            self._layout_save_timer.start(150)
        except Exception:
            pass

    def _save_layout_settings(self) -> None:
        preset = self._current_layout_preset()
        try:
            self._settings.setValue("modern/layout/preset", preset)
        except Exception:
            pass
        try:
            self._settings.setValue(f"modern/presets/{preset}/splitter_state", self._splitter.saveState())
        except Exception:
            pass
        try:
            self._settings.setValue("modern/geometry", self.saveGeometry())
        except Exception:
            pass

    def _toggle_bottom_hud_tab(self) -> None:
        sizes = self._root_splitter.sizes()
        top = sizes[0] if len(sizes) > 0 else max(1, int(self.height() * 0.7))
        bottom = sizes[1] if len(sizes) > 1 else 0
        if bottom <= 2:
            new_bottom = max(140, int(top * 0.3))
            self._root_splitter.setSizes([max(1, top - new_bottom), new_bottom])
            self._bottom_tabs.show()
            return
        self._root_splitter.setSizes([top + bottom, 0])
        self._bottom_tabs.hide()

    def _on_legend_toast_requested(self) -> None:
        self.legend_toast.arm()
        self.legend_toast_anchor._reposition()

    def _on_spec_selected(self, index: int) -> None:
        if 0 <= index < len(self.specs):
            spec = self.specs[index]
            self.viewer.set_spec(spec)
            self._current_spec = spec
            self.hud.set_spec_meta(spec)
            self._update_prime_physics(spec)
            try:
                label, detail = infer_model_layer(getattr(spec, "metadata", None))
            except Exception:
                label, detail = "unspecified", ""
            self.panel.set_model_layer(label, detail)

    def _on_time_update(self, time_value: float) -> None:
        if not self.viewer.engine:
            return
        norm = time_value / self.viewer.engine.loop_duration
        self.panel.set_time_norm(norm)
        self.hud.set_time(time_value, self.viewer.engine.loop_duration)

    def _update_prime_physics(self, spec: EditVisualizationSpec) -> None:
        metadata = getattr(spec, "metadata", {}) or {}
        score = metadata.get("physics_score")
        self.panel.set_prime_physics_score(score if isinstance(score, Mapping) else None)

    @staticmethod
    def _spec_kind(spec: EditVisualizationSpec) -> str:
        source = (spec.metadata or {}).get("source", "")
        if "prime" in str(source):
            return "PRIME SIM"
        if "crispr" in str(source):
            return "CRISPR SIM"
        return "HELIX SIM"

    def _on_event_picked(self, ev: EditEvent | None) -> None:
        if ev is None:
            self.setWindowTitle("Helix – ModernGL CRISPR Viz")
            self.panel.set_selection(None)
            return
        idx = getattr(ev, "index", getattr(ev, "start", None))
        label = f"{ev.type.name}"
        if idx is not None:
            label += f" @ {idx}"
        self.setWindowTitle(f"Helix – {label}")
        physics = None
        outcomes = None
        if self._current_spec is not None:
            meta = self._current_spec.metadata or {}
            physics = meta.get("physics_score")
            outcomes = meta.get("outcomes") or meta.get("rail_bands", {}).get("bands")
        bundle: dict[str, Any] | None
        if isinstance(physics, Mapping):
            bundle = dict(physics)
        else:
            bundle = {}
        if outcomes is not None:
            bundle["outcomes"] = outcomes
        # Confidence: drive a subtle thickness/glow channel via probability mass.
        try:
            conf = event_confidence(ev, self._current_spec)
        except Exception:
            conf = None
        if conf is not None:
            bundle["confidence"] = conf
        # Emit structured selection payload for downstream panels / telemetry.
        try:
            phase = None
            if self.viewer.engine is not None:
                phase = getattr(self.viewer.engine.state, "phase", None)
                if phase is not None:
                    phase = getattr(phase, "value", str(phase))
            selection_payload = compute_selection_payload(ev, self._current_spec, phase=phase)
            bundle["selection_payload"] = selection_payload
            if selection_payload.get("probability") is not None:
                bundle["probability"] = selection_payload.get("probability")
            if selection_payload.get("confidence") is not None and "confidence" not in bundle:
                bundle["confidence"] = selection_payload.get("confidence")
        except Exception:
            pass
        self.panel.set_selection(ev, bundle if bundle is not None else None)


def run_modern_viz(spec_source: str | Path | Sequence[EditVisualizationSpec] | None = None) -> None:
    """Launch the PyQt + ModernGL helix visualizer."""

    app = QApplication.instance()
    owns_app = False
    if app is None:
        app = QApplication(sys.argv)
        owns_app = True
    apply_helix_theme(app)

    if spec_source is None:
        specs = [load_viz_spec(
            {
                "sequence": "ACGTACGTACGTACGTACGTACGT",
                "pam_index": 10,
                "guide_range": [4, 24],
                "edit_type": "prime",
                "edit_events": [
                    {"t": 0.2, "type": "recognition", "index": 8},
                    {"t": 0.5, "type": "nick_primary", "index": 10},
                    {"t": 0.8, "type": "rt_synthesis", "start": 11, "length": 6},
                    {"t": 1.2, "type": "flap_resolution", "index": 12},
                    {"t": 1.6, "type": "repair_complete", "index": 12},
                ],
            }
        )]
    elif isinstance(spec_source, Sequence) and spec_source and isinstance(spec_source[0], EditVisualizationSpec):  # type: ignore[index]
        specs = list(spec_source)  # type: ignore[assignment]
    else:
        specs = load_viz_specs(spec_source)  # type: ignore[arg-type]

    window = HelixModernWindow(specs)
    window.resize(1280, 800)
    window.show()

    with allow_nondeterminism(reason="ui"):
        if owns_app:
            sys.exit(app.exec())
        else:  # pragma: no cover - embedded Qt contexts
            app.exec()


if __name__ == "__main__":  # pragma: no cover - manual launch helper
    source = Path(sys.argv[1]).expanduser() if len(sys.argv) > 1 else None
    run_modern_viz(source)
