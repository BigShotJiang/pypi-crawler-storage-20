"""Selection + confidence helpers for modern rail/helix viz.

These utilities stay Qt-free so they can be exercised in tests without a GUI
stack. They work on the viz spec / event dataclasses and plain metadata maps.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence, Tuple, List

import numpy as np

from .spec import EditEvent, EditEventType, EditVisualizationSpec


VISIBLE_CONFIDENCE_FLOOR = 0.05  # keep confidence visually non-zero without overpowering


def _clamp01(value: Any) -> float:
    try:
        v = float(value)
    except Exception:
        return 0.0
    if not (v == v) or v == float("inf") or v == float("-inf"):
        return 0.0
    if v < 0.0:
        return 0.0
    if v > 1.0:
        return 1.0
    return v


def _extract_probability(meta: Mapping[str, Any] | None) -> float | None:
    if not isinstance(meta, Mapping):
        return None
    for key in ("probability", "prob", "p", "confidence"):
        if key in meta and meta[key] is not None:
            try:
                return _clamp01(meta[key])
            except Exception:
                continue
    return None


def _best_outcome(meta: Mapping[str, Any] | None) -> Mapping[str, Any] | None:
    if not isinstance(meta, Mapping):
        return None
    candidate = meta.get("best_outcome")
    return candidate if isinstance(candidate, Mapping) else None


def _railband_top_probability(meta: Mapping[str, Any] | None) -> float | None:
    if not isinstance(meta, Mapping):
        return None
    rail = meta.get("rail_bands") if isinstance(meta, Mapping) else None
    if not isinstance(rail, Mapping):
        return None
    bands = rail.get("bands")
    if not isinstance(bands, Sequence) or not bands:
        return None
    top = 0.0
    for band in bands:
        if not isinstance(band, Mapping):
            continue
        prob = _extract_probability(band)
        if prob is None:
            continue
        top = max(top, prob)
    return top if top > 0.0 else None


def event_confidence(ev: EditEvent, spec: EditVisualizationSpec | None) -> float:
    """Return a 0..1 confidence weight for a picked event.

    Priority order:
    1. Explicit probability/confidence on the event.metadata
    2. best_outcome probability from spec.metadata
    3. Highest rail-band probability (top outcome mass) from spec.metadata
    4. Fallback by event type (cuts default to 1, repair-ish to 0.6, other 0.5)
    """

    meta = spec.metadata if isinstance(spec, EditVisualizationSpec) else {}
    # 1) Event-level confidence
    ev_prob = _extract_probability(getattr(ev, "metadata", {}) or {})
    if ev_prob is not None:
        return max(VISIBLE_CONFIDENCE_FLOOR, _clamp01(ev_prob))

    # 2) Best-outcome probability
    best = _best_outcome(meta)
    best_prob = _extract_probability(best)
    if best_prob is not None:
        return max(VISIBLE_CONFIDENCE_FLOOR, _clamp01(best_prob))

    # 3) Rail-band top probability
    rb_prob = _railband_top_probability(meta)
    if rb_prob is not None:
        return max(VISIBLE_CONFIDENCE_FLOOR, _clamp01(rb_prob))

    # 4) Semantic fallback by phase
    if ev.type in (EditEventType.CUT, EditEventType.NICK_PRIMARY, EditEventType.NICK_SECONDARY):
        return 1.0
    if ev.type in (EditEventType.REPAIR_COMPLETE, EditEventType.FLAP_RESOLUTION):
        return 0.6
    if ev.type in (EditEventType.PRIME_INIT, EditEventType.RT_SYNTHESIS):
        return 0.55
    return 0.5


def infer_model_layer(meta: Mapping[str, Any] | None) -> Tuple[str, str]:
    """Derive a short (label, detail) tuple describing the abstraction layer.

    Understands either a simple string ("mechanistic") or a mapping with
    keys like {"label": "mechanistic", "detail": "rule-based CRISPR sim"}.
    Falls back to heuristics based on the source tag when absent.
    """

    if not isinstance(meta, Mapping):
        return "unspecified", ""

    layer = meta.get("model_layer") or meta.get("abstraction_layer") or meta.get("model")
    label = ""
    detail = ""
    if isinstance(layer, Mapping):
        label = str(layer.get("label") or layer.get("kind") or "").strip()
        detail = str(layer.get("detail") or layer.get("description") or "").strip()
    elif isinstance(layer, str):
        label = layer.strip()

    if not label:
        source = str(meta.get("source") or "").lower()
        if "prime" in source:
            label = "mechanistic + thermodynamic"
            detail = "Prime edit simulator with peg/RT physics hints"
        elif "crispr" in source:
            label = "mechanistic stochastic"
            detail = "CRISPR cut/repair simulator with empirical priors"
        else:
            label = "unspecified"

    return label, detail


def compute_selection_payload(
    ev: EditEvent,
    spec: EditVisualizationSpec,
    *,
    phase: str | None = None,
    locus: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a structured, serializable selection payload for downstream consumers."""

    meta = spec.metadata or {}
    locus_meta = locus if isinstance(locus, Mapping) else meta.get("referenceLocus") if isinstance(meta, Mapping) else {}
    locus_meta = locus_meta if isinstance(locus_meta, Mapping) else {}

    chrom = locus_meta.get("chrom") if locus_meta else None
    try:
        locus_start = int(locus_meta.get("start")) if locus_meta and locus_meta.get("start") is not None else None
    except Exception:
        locus_start = None
    try:
        locus_end = int(locus_meta.get("end")) if locus_meta and locus_meta.get("end") is not None else None
    except Exception:
        locus_end = None

    cut_idx = None
    if getattr(ev, "index", None) is not None:
        cut_idx = int(getattr(ev, "index"))
    elif getattr(ev, "start", None) is not None:
        cut_idx = int(getattr(ev, "start"))
    elif isinstance(meta, Mapping):
        try:
            bands = meta.get("rail_bands")
            if isinstance(bands, Mapping) and bands.get("cut_index") is not None:
                cut_idx = int(bands.get("cut_index"))
        except Exception:
            cut_idx = None

    cut_abs = cut_idx + locus_start if (cut_idx is not None and locus_start is not None) else None

    guide_id = None
    if isinstance(meta, Mapping):
        for key in ("guide_id", "guide", "guide_name", "peg"):
            if meta.get(key):
                guide_id = str(meta.get(key))
                break
    if not guide_id:
        guide_id = getattr(spec, "edit_type", "guide")

    # Repair mode: prefer best_outcome label, fall back to event metadata label/stage.
    repair_mode = None
    best = _best_outcome(meta)
    if isinstance(best, Mapping):
        repair_mode = best.get("label") or best.get("description") or best.get("stage")
    if repair_mode is None:
        ev_meta = getattr(ev, "metadata", {}) or {}
        if isinstance(ev_meta, Mapping):
            repair_mode = ev_meta.get("label") or ev_meta.get("stage")

    best_prob = _extract_probability(best)
    ev_prob = _extract_probability(getattr(ev, "metadata", {}) or {})
    probability = best_prob if best_prob is not None else ev_prob
    confidence = event_confidence(ev, spec)

    payload = {
        "event": str(getattr(getattr(ev, "type", None), "value", getattr(ev, "type", ""))),
        "event_time": float(getattr(ev, "t", 0.0) or 0.0),
        "phase": phase,
        "guide_id": guide_id,
        "cut_index": cut_idx,
        "repair_mode": repair_mode,
        "probability": probability,
        "confidence": confidence,
        "locus": {
            "chrom": chrom,
            "start": locus_start,
            "end": locus_end,
            "cut_absolute": cut_abs,
            "cut_relative": cut_idx,
        },
    }
    return SelectionPayload(payload).to_dict()


__all__ = [
    "compute_selection_payload",
    "event_confidence",
    "infer_model_layer",
    "build_cpu_pick_buffer",
    "SelectionPayload",
]


class SelectionPayload(dict):
    """Typed selection payload to avoid schema drift."""

    REQUIRED_FIELDS = {
        "event": str,
        "event_time": float,
        "phase": (str, type(None)),
        "guide_id": str,
        "cut_index": (int, type(None)),
        "repair_mode": (str, type(None)),
        "probability": (float, type(None)),
        "confidence": float,
        "locus": dict,
    }

    def __init__(self, payload: Mapping[str, Any]):
        super().__init__(payload)
        self._validate()

    def _validate(self) -> None:
        for key, typ in self.REQUIRED_FIELDS.items():
            if key not in self:
                raise ValueError(f"SelectionPayload missing required field: {key}")
            val = self[key]
            if not isinstance(val, typ):
                raise TypeError(f"SelectionPayload.{key} expected {typ}, got {type(val)}")
        if not isinstance(self["locus"], Mapping):
            raise TypeError("SelectionPayload.locus must be a mapping")

    def to_dict(self) -> dict[str, Any]:
        return dict(self)


# ---------------------------------------------------------------------------
# CPU pick buffer helper (test-only, Qt/GL free)
# ---------------------------------------------------------------------------

def _param_ribbons_from_spec(spec: EditVisualizationSpec) -> tuple[np.ndarray, list[tuple[int, int]], list[EditEvent]]:
    """
    Lightweight clone of HelixModernWidget._build_param_ribbons_from_spec
    for test use only (avoids Qt/GL import).
    Returns (interleaved_vertices, arc_ranges, arc_events).
    """
    events = _select_param_ribbon_events(spec)
    if not events:
        return np.zeros((0, 5), dtype="f4"), [], []

    seq_len = len(spec.sequence)
    denom = max(1, seq_len - 1)
    rail_spacing = 0.525  # matches MODERN_STYLE.flat_rail_spacing
    y_top = rail_spacing
    y_bottom = -rail_spacing
    base_z = -0.05

    verts_list: list[np.ndarray] = []
    weights_list: list[np.ndarray] = []
    kinds_list: list[np.ndarray] = []
    arc_ranges: list[tuple[int, int]] = []
    cursor = 0

    stack_bins: dict[int, int] = {}
    stack_dx = 0.03
    stack_dh = 0.05

    for ev in events:
        if getattr(ev, "index", None) is not None:
            idx = int(ev.index)
        elif getattr(ev, "start", None) is not None:
            idx = int(ev.start)
        else:
            continue

        idx = max(0, min(seq_len - 1, idx))
        t_pos = idx / denom
        stack_level = stack_bins.get(idx, 0)
        stack_bins[idx] = stack_level + 1
        x_center = (t_pos * 2.0 - 1.0) * 0.8 + stack_level * stack_dx

        if ev.type in (EditEventType.NICK_PRIMARY, EditEventType.CUT):
            span = 0.04
            x0 = x_center - span
            x1 = x_center + span
            p0 = np.array([x0, y_top, base_z], dtype="f4")
            p2 = np.array([x1, y_top, base_z], dtype="f4")
            base_height = 0.2
            height = base_height + stack_level * stack_dh
            mid = np.array([x_center, y_top + height, base_z], dtype="f4")
            kind_code = 0.0
            p1 = mid
        else:
            p0 = np.array([x_center, y_top, base_z], dtype="f4")
            p2 = np.array([x_center, y_bottom, base_z], dtype="f4")
            bend = 0.12
            p1 = np.array([x_center + bend, 0.0, base_z], dtype="f4")
            kind_code = 2.0

        s = np.linspace(0.0, 1.0, 40, dtype="f4")
        um = 1.0 - s
        curve = (
            (um[:, None] ** 2) * p0
            + 2.0 * (um[:, None] * s[:, None]) * p1
            + (s[:, None] ** 2) * p2
        ).astype("f4")
        verts_list.append(curve)
        t_evt = float(getattr(ev, "t", 1.0))
        weights_list.append(np.full((curve.shape[0], 1), t_evt, dtype="f4"))
        kinds_list.append(np.full((curve.shape[0], 1), kind_code, dtype="f4"))

        count = curve.shape[0]
        arc_ranges.append((cursor, count))
        cursor += count

    if not verts_list:
        return np.zeros((0, 5), dtype="f4"), [], events

    verts = np.vstack(verts_list).astype("f4")
    weights = np.vstack(weights_list).astype("f4")
    kinds = np.vstack(kinds_list).astype("f4")
    interleaved = np.hstack([verts, weights, kinds]).astype("f4")
    return interleaved, arc_ranges, events


def _select_param_ribbon_events(spec: EditVisualizationSpec) -> list[EditEvent]:
    if not getattr(spec, "events", None):
        return []
    cut_ev: EditEvent | None = None
    repair_ev: EditEvent | None = None
    for ev in spec.events:
        if cut_ev is None and ev.type in (EditEventType.NICK_PRIMARY, EditEventType.CUT):
            cut_ev = ev
        if repair_ev is None and ev.type is EditEventType.REPAIR_COMPLETE:
            repair_ev = ev
    chosen = [ev for ev in (cut_ev, repair_ev) if ev is not None]
    if not chosen:
        return []

    def _kind_code(ev: EditEvent) -> float:
        if ev.type in (EditEventType.NICK_PRIMARY, EditEventType.CUT):
            return 0.0
        if ev.type is EditEventType.REPAIR_COMPLETE:
            return 2.0
        return 9.0

    def _idx(ev: EditEvent) -> int:
        idx = ev.index if ev.index is not None else ev.start
        return int(idx) if idx is not None else -1

    return sorted(
        chosen,
        key=lambda ev: (-float(getattr(ev, "t", 0.0)), _kind_code(ev), _idx(ev)),
    )


def build_cpu_pick_buffer(
    spec: EditVisualizationSpec,
    width: int = 192,
    height: int = 192,
) -> tuple[np.ndarray, List[EditEvent]]:
    """
    Rasterize param-space ribbons into a uint32 pick buffer for tests.
    - ID 0 = no hit
    - ID n = arc index n-1 (arc order matches _select_param_ribbon_events)
    - Tie-break: later arcs win (last write wins), matching GL draw order with depth disabled.
    """

    interleaved, arc_ranges, events = _param_ribbons_from_spec(spec)
    buf = np.zeros((height, width), dtype=np.uint32)
    if interleaved.size == 0 or not arc_ranges:
        return buf, events

    coords = interleaved[:, :2]  # x, y
    # Assume coords roughly in [-1.2, 1.2]; map to [0, W-1] / [0, H-1]
    def to_px(xy: np.ndarray) -> np.ndarray:
        x = (xy[:, 0] * 0.5 + 0.5) * (width - 1)
        y = (1.0 - (xy[:, 1] * 0.5 + 0.5)) * (height - 1)
        return np.stack([x, y], axis=1)

    coords_px = to_px(coords)

    def draw_line(p0, p1, arc_id: int) -> None:
        steps = int(max(abs(p1[0] - p0[0]), abs(p1[1] - p0[1]), 1))
        xs = np.linspace(p0[0], p1[0], steps, dtype=np.float32)
        ys = np.linspace(p0[1], p1[1], steps, dtype=np.float32)
        xi = np.clip(xs.round().astype(int), 0, width - 1)
        yi = np.clip(ys.round().astype(int), 0, height - 1)
        buf[yi, xi] = arc_id

    for arc_idx, (start, count) in enumerate(arc_ranges):
        arc_id = arc_idx + 1  # 0 reserved for "no hit"
        if count < 2:
            continue
        pts = coords_px[start : start + count]
        for i in range(len(pts) - 1):
            draw_line(pts[i], pts[i + 1], arc_id)

    return buf, events
