from __future__ import annotations

from typing import Any


def qt_move(widget: Any, *args: Any) -> None:
    widget.move(*args)


def qt_set_geometry(widget: Any, *args: Any) -> None:
    widget.setGeometry(*args)

