"""Application-wide Qt theme helpers."""

from __future__ import annotations

import importlib
import importlib.util
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PySide6.QtCore import QSettings
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication

SETTINGS_ORG = "Helix"
SETTINGS_APP = "Studio"
SETTINGS_THEME_KEY = "appearance/theme"
_TOKEN_PATH = Path(__file__).resolve().parents[3] / "helix" / "theme" / "tokens.json"
_DEFAULT_THEME_NAME = os.environ.get("HELIX_THEME", "dark")
# Writable theme cache; defaults to ~/.helix/theme unless overridden.
_GENERATED_OUT_DIR = Path(os.environ.get("HELIX_THEME_OUT", Path.home() / ".helix" / "theme"))

_GLOBAL_STYLESHEET = """
QMainWindow, QDialog {
  background: palette(window);
  color: palette(windowText);
}

/* Avoid "black boxes" by keeping scroll-area viewports transparent. */
QScrollArea > QWidget > QWidget {
  background: transparent;
}
""".strip()


@dataclass(frozen=True, slots=True)
class HelixTheme:
    name: str
    label: str
    font_family: str | None = None
    font_size_px: int | None = None


def _display_name(name: str) -> str:
    parts = str(name).replace("_", " ").split()
    return " ".join(p.capitalize() for p in parts) if parts else name


def _load_tokens() -> dict[str, Any]:
    if not _TOKEN_PATH.is_file():
        return {}
    try:
        return json.loads(_TOKEN_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _token_typography(tokens: dict[str, Any]) -> tuple[str | None, int | None]:
    typography = tokens.get("typography")
    if not isinstance(typography, dict):
        return None, None
    family = typography.get("font_family_ui")
    size = None
    sizes = typography.get("size")
    if isinstance(sizes, dict):
        size = sizes.get("md")
    return family, size


def token_theme_names() -> list[str]:
    tokens = _load_tokens()
    themes = tokens.get("themes")
    if isinstance(themes, dict):
        return list(themes.keys())
    return []


def available_themes() -> tuple[HelixTheme, ...]:
    tokens = _load_tokens()
    names = token_theme_names()
    font_family, font_size_px = _token_typography(tokens)
    return tuple(
        HelixTheme(name=n, label=_display_name(n), font_family=font_family, font_size_px=font_size_px)
        for n in names
    )


def current_theme_name(app: QApplication | None = None) -> str:
    app = app or QApplication.instance()
    if app is not None:
        existing = app.property("helix_theme_name")
        if isinstance(existing, str) and existing:
            return existing
    try:
        settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
        stored = settings.value(SETTINGS_THEME_KEY, None)
        if isinstance(stored, str) and stored:
            return stored
    except Exception:
        pass
    return _DEFAULT_THEME_NAME


def _read_env_int(name: str, *, default: int | None) -> int | None:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _apply_generated_theme(app: QApplication, theme_name: str) -> bool:
    """If generator outputs are present, apply them and return True."""
    try:
        try:
            import helix.theme.icons_rc  # type: ignore  # noqa: F401
        except Exception:
            # Fall back to loading the icons_rc from the tokens directory if not packaged.
            icons_rc_path = _TOKEN_PATH.parent / "icons_rc.py"
            if icons_rc_path.is_file():
                spec = importlib.util.spec_from_file_location("helix.theme.icons_rc", icons_rc_path)
                if spec and spec.loader:
                    mod = importlib.util.module_from_spec(spec)
                    import sys as _sys
                    _sys.modules[spec.name] = mod
                    spec.loader.exec_module(mod)  # type: ignore[arg-type]

        out_dir = _GENERATED_OUT_DIR
        qss_path = out_dir / "theme_generated.qss"
        pal_path = out_dir / "theme_palette_generated.py"
        if not _TOKEN_PATH.is_file():
            return False

        def _generate() -> None:
            gen_path = _TOKEN_PATH.parent / "generate_theme.py"
            module = None
            try:
                from helix.theme import generate_theme  # type: ignore
                module = generate_theme
            except Exception:
                if gen_path.is_file():
                    spec = importlib.util.spec_from_file_location("helix.theme.generate_theme", gen_path)
                    if spec and spec.loader:
                        module = importlib.util.module_from_spec(spec)
                        import sys as _sys
                        _sys.modules[spec.name] = module
                        spec.loader.exec_module(module)  # type: ignore[arg-type]
            if module is None or not hasattr(module, "generate"):
                raise ImportError("generate_theme not found")
            out_dir.mkdir(parents=True, exist_ok=True)
            module.generate(_TOKEN_PATH, out_dir, theme_name)

        if not qss_path.is_file() or not pal_path.is_file():
            _generate()

        # Ensure theme outputs match the requested theme (regen if stale).
        try:
            _generate()
        except Exception:
            pass

        importlib.invalidate_caches()
        spec = importlib.util.spec_from_file_location("helix.theme.out.theme_palette_generated", pal_path)
        if spec is None or spec.loader is None:
            return False
        module = importlib.util.module_from_spec(spec)
        import sys as _sys
        _sys.modules[spec.name] = module
        spec.loader.exec_module(module)  # type: ignore[arg-type]
        apply_palette = getattr(module, "apply_palette", None)
        if not callable(apply_palette):
            return False
        apply_palette(app)
        app.setStyleSheet(qss_path.read_text(encoding="utf-8"))
        app.setProperty("helix_theme_name", theme_name)
        return True
    except Exception:
        return False


def _apply_font(app: QApplication, *, family: str | None, size_px: int | None) -> None:
    if family is None and size_px is None:
        return
    font = app.font() or QFont()
    if family:
        font.setFamily(family)
    if size_px:
        font.setPixelSize(size_px)
    app.setFont(font)


def apply_helix_theme(
    app: QApplication,
    *,
    theme_name: str | None = None,
    font_family: str | None = None,
    font_size_px: int | None = None,
    persist: bool = True,
) -> None:
    """Apply the Helix Qt palette/stylesheet, optionally switching theme."""

    resolved_theme = theme_name or current_theme_name(app)
    tokens = _load_tokens()
    token_font_family, token_font_size = _token_typography(tokens)

    if font_family is None:
        font_family = os.environ.get("HELIX_THEME_FONT_FAMILY", token_font_family or "")
    if not font_family:
        font_family = None
    if font_size_px is None:
        font_size_px = _read_env_int("HELIX_THEME_FONT_SIZE_PX", default=token_font_size)

    prev_name = app.property("helix_theme_name")
    prev_font = app.property("helix_theme_font")
    prev_size = app.property("helix_theme_font_px")
    if (
        app.property("helix_theme_applied")
        and prev_name == resolved_theme
        and prev_font == font_family
        and prev_size == font_size_px
    ):
        return

    _apply_font(app, family=font_family, size_px=font_size_px)

    if not _apply_generated_theme(app, resolved_theme):
        return

    app.setProperty("helix_theme_applied", True)
    app.setProperty("helix_theme_font", font_family)
    app.setProperty("helix_theme_font_px", font_size_px)

    if persist:
        try:
            settings = QSettings(SETTINGS_ORG, SETTINGS_APP)
            settings.setValue(SETTINGS_THEME_KEY, resolved_theme)
        except Exception:
            pass
