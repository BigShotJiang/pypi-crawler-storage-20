"""2D rail band visualization widget."""

from __future__ import annotations

from typing import Any, Mapping, Sequence

try:
    from PySide6.QtCore import Qt, QTimer, QRectF
    from PySide6.QtGui import QColor, QFont, QPainter, QPen
    from PySide6.QtWidgets import QWidget

    _HAS_QT = True
except Exception:  # pragma: no cover - headless/libEGL missing
    _HAS_QT = False

    class _Dummy:
        def __init__(self, *args, **kwargs) -> None:
            pass

    class _DummyQt:
        AlignCenter = 0
        AlignLeft = 0
        AlignVCenter = 0
        NoPen = 0

    Qt = _DummyQt()  # type: ignore[assignment]
    QTimer = QRectF = QColor = QFont = QPainter = QPen = QWidget = _Dummy  # type: ignore[assignment]

from helix.gui.modern.spec import EditVisualizationSpec


if _HAS_QT:

    class RailBandWidget(QWidget):
        """Simple QWidget renderer for CRISPR rail bands."""

        _COLORS = {
            "deletion": QColor("#f97316"),
            "insertion": QColor("#ec4899"),
            "substitution": QColor("#0ea5e9"),
            "no_cut": QColor("#22d3ee"),
            "other": QColor("#a78bfa"),
        }

        def __init__(self, parent: QWidget | None = None) -> None:
            super().__init__(parent)
            self.setMinimumHeight(360)
            self._sequence = ""
            self._bands: list[Mapping[str, Any]] = []
            self._guide_range = (0, 0)
            self._pam_index = 0
            self._cut_index = 0
            self._hotspots: Mapping[str, Any] | None = None
            self._prime_overlay: Mapping[str, Any] | None = None
            self._base_overlay: Mapping[str, Any] | None = None
            self._title = ""
            self._message = "No visualization data."
            self._anim_progress = 1.0
            self._anim_timer = QTimer(self)
            self._anim_timer.setInterval(16)
            self._anim_timer.timeout.connect(self._advance_animation)

        def set_spec(self, spec: EditVisualizationSpec | None) -> None:
            if spec is None or not spec.metadata:
                self._sequence = ""
                self._bands = []
                self._title = ""
                self._message = "No visualization data."
                self._anim_progress = 1.0
                self._anim_timer.stop()
                self.update()
                return
            meta = spec.metadata.get("rail_bands")
            if not isinstance(meta, Mapping):
                self._sequence = ""
                self._bands = []
                self._title = ""
                self._message = "Rail band metadata unavailable."
                self._anim_progress = 1.0
                self._anim_timer.stop()
                self.update()
                return
            self._sequence = str(meta.get("sequence") or spec.sequence or "")
            self._bands = list(meta.get("bands") or [])
            self._guide_range = tuple(meta.get("guide_range") or spec.guide_range)
            self._pam_index = int(meta.get("pam_index", spec.pam_index))
            self._cut_index = int(meta.get("cut_index", self._guide_range[0]))
            self._hotspots = meta.get("hotspots") if isinstance(meta.get("hotspots"), Mapping) else None
            self._prime_overlay = meta.get("prime_overlay") if isinstance(meta.get("prime_overlay"), Mapping) else None
            self._base_overlay = meta.get("base_overlay") if isinstance(meta.get("base_overlay"), Mapping) else None
            self._title = spec.edit_type
            if not self._bands:
                self._message = "No outcomes to display."
                self._anim_progress = 1.0
                self._anim_timer.stop()
            else:
                self._message = ""
                self._start_animation()
            self.update()

        def paintEvent(self, event) -> None:  # type: ignore[override]
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing, True)
            rect = self.rect()
            painter.fillRect(rect, QColor("#050910"))
            if not self._sequence or not self._bands:
                painter.setPen(QColor("#94a3b8"))
                painter.setFont(QFont("Inter", 14))
                painter.drawText(rect, Qt.AlignCenter, self._message or "No data.")
                return

            margin_x = 60.0
            margin_top = 50.0
            seq_len = max(1, len(self._sequence) - 1)
            width = rect.width() - margin_x * 2
            height = rect.height() - margin_top - 60.0

            def x_for(idx: int) -> float:
                idx = max(0, min(len(self._sequence) - 1, idx))
                return margin_x + (idx / max(1, seq_len)) * width

            rail_y = margin_top
            painter.setPen(QPen(QColor("#38bdf8"), 3))
            painter.drawLine(x_for(0), rail_y, x_for(len(self._sequence) - 1), rail_y)
            cut_x = x_for(self._cut_index)

            # Guide region
            g0, g1 = self._guide_range
            painter.setPen(Qt.NoPen)
            guide_color = QColor("#22d3ee")
            guide_color.setAlpha(60)
            painter.setBrush(guide_color)
            painter.drawRect(x_for(g0), rail_y - 12, max(2.0, x_for(g1) - x_for(g0)), 24)

            # PAM marker
            pam_color = QColor("#be123c")
            painter.setBrush(pam_color)
            painter.drawRect(x_for(self._pam_index) - 2, rail_y - 18, 4, 36)

            # Cut line
            painter.setPen(QPen(QColor("#f97316"), 2))
            painter.drawLine(cut_x, rail_y - 30, cut_x, rail_y + height * 0.5)
            self._draw_hotspot_overlay(painter, x_for, rail_y, len(self._sequence))
            self._draw_prime_overlay(painter, x_for, rail_y, len(self._sequence))
            self._draw_base_overlay(painter, x_for, rail_y, len(self._sequence))
            self._draw_axis_annotations(painter, QRectF(margin_x, margin_top - 20, width, 20))
            self._draw_probability_scale(painter, QRectF(margin_x, rail_y + height + 10, width, 40))
            painter.setFont(QFont("Inter", 10, QFont.Medium))
            painter.setPen(QColor("#fbbf24"))
            painter.drawText(QRectF(cut_x + 6, rail_y - 48, 140, 18), Qt.AlignLeft | Qt.AlignVCenter, "Cut site (0 bp)")

            self._draw_reference_strip(painter, x_for, rail_y, len(self._sequence))

            painter.setFont(QFont("Inter", 16, QFont.Bold))
            painter.setPen(QColor("#e2e8f0"))
            painter.drawText(rect.adjusted(16, 10, -16, 0), Qt.AlignLeft | Qt.AlignTop, self._title)

            painter.setFont(QFont("Inter", 12))
            band_height = 20
            gap = 18
            for band in self._bands:
                start = int(band.get("start", 0))
                end = int(band.get("end", start + 1))
                label = str(band.get("label") or "")
                prob = float(band.get("probability") or 0.0)
                kind = str(band.get("kind") or "other")
                row = int(band.get("row", 0))
                y = rail_y + 40 + row * (band_height + gap)
                base_start = x_for(start)
                base_end = x_for(end)
                anim_start = cut_x + (base_start - cut_x) * self._anim_progress
                anim_end = cut_x + (base_end - cut_x) * self._anim_progress
                x_left = min(anim_start, anim_end)
                bar_width = max(2.0, abs(anim_end - anim_start))
                band_rect = QRectF(x_left, y, bar_width, band_height)

                color = QColor(self._COLORS.get(kind, self._COLORS["other"]))
                alpha = int(90 + min(prob, 1.0) * 160)
                color.setAlpha(max(60, min(alpha, 255)))

                glow = QColor(color)
                glow.setAlpha(int(glow.alpha() * 0.45))
                painter.setPen(Qt.NoPen)
                painter.setBrush(glow)
                painter.drawRoundedRect(band_rect.adjusted(-2.0, -2.0, 2.0, 2.0), 6, 6)

                painter.setBrush(color)
                painter.drawRoundedRect(band_rect, 4, 4)
                self._draw_band_texture(painter, band_rect, kind, prob)

                painter.setPen(QPen(QColor("#0f172a")))
                painter.drawRoundedRect(band_rect, 4, 4)
                painter.setPen(QColor("#cbd5f5"))
                painter.drawText(
                    int(band_rect.left()),
                    int(band_rect.bottom()) + 14,
                    f"{label} ({prob * 100:.1f}%)",
                )

        def _draw_reference_strip(self, painter: QPainter, x_for, rail_y: float, seq_len: int) -> None:
            painter.save()
            strip_y = rail_y + 26.0
            base_pen = QPen(QColor("#0f172a"), 1)
            painter.setPen(base_pen)
            painter.drawLine(x_for(0), strip_y, x_for(seq_len - 1), strip_y)
            label_pen = QPen(QColor("#475569"), 1)
            font = QFont("Inter", 9)
            painter.setFont(font)
            for idx in range(0, seq_len, 5):
                x = x_for(idx)
                major = idx % 10 == 0
                tick_len = 8 if major else 4
                painter.setPen(base_pen if major else QPen(QColor("#0b1120"), 1))
                painter.drawLine(x, strip_y, x, strip_y + tick_len)
                if major:
                    painter.setPen(label_pen)
                    offset = idx - self._cut_index
                    label = f"{offset:+d}"
                    painter.drawText(int(x - 10), int(strip_y + tick_len + 12), label)
            painter.restore()

        def _draw_hotspot_overlay(self, painter: QPainter, x_for, rail_y: float, seq_len: int) -> None:
            meta = self._hotspots
            if not isinstance(meta, Mapping):
                return
            if not bool(meta.get("show", True)):
                return
            segments = meta.get("segments")
            context_segments = meta.get("context_segments")
            selected_segments = meta.get("selected_segments")
            if not isinstance(segments, Sequence) and not isinstance(context_segments, Sequence):
                return
            levels = int(meta.get("levels", 5) or 5)
            if levels <= 0:
                return

            context_alpha = [20, 35, 50, 70, 90]
            selected_alpha = [140, 160, 180, 200, 220]
            while len(context_alpha) < levels:
                context_alpha.append(context_alpha[-1])
            while len(selected_alpha) < levels:
                selected_alpha.append(selected_alpha[-1])

            painter.save()
            painter.setPen(Qt.NoPen)
            band_half = 6

            def draw_segments(seg_list: Sequence[Mapping[str, Any]], alpha_map: list[int]) -> None:
                for seg in seg_list:
                    if not isinstance(seg, Mapping):
                        continue
                    try:
                        start = int(seg.get("start", 0))
                        end = int(seg.get("end", start + 1))
                        level = int(seg.get("level", 1))
                    except Exception:
                        continue
                    if end <= start:
                        continue
                    if start < 0:
                        start = 0
                    if start >= seq_len:
                        continue
                    end = max(start + 1, min(end, seq_len))
                    end_idx = max(start, end - 1)
                    level_idx = max(1, min(level, levels)) - 1
                    color = QColor("#f97316")
                    color.setAlpha(alpha_map[level_idx])
                    x0 = int(round(x_for(start)))
                    x1 = int(round(x_for(end_idx)))
                    width = max(1, x1 - x0 + 1)
                    painter.fillRect(x0, int(rail_y - band_half), width, band_half * 2, color)

            if isinstance(context_segments, Sequence) and context_segments:
                draw_segments(context_segments, context_alpha)
                if isinstance(selected_segments, Sequence) and selected_segments:
                    draw_segments(selected_segments, selected_alpha)
            elif isinstance(segments, Sequence) and segments:
                draw_segments(segments, context_alpha)

            painter.restore()

        def _draw_prime_overlay(self, painter: QPainter, x_for, rail_y: float, seq_len: int) -> None:
            meta = self._prime_overlay
            if not isinstance(meta, Mapping):
                return
            if not bool(meta.get("show", True)):
                return
            desired = meta.get("desired")
            partial = meta.get("partial")
            nick_index = meta.get("nick_index")

            band_half = 8
            painter.save()
            painter.setBrush(Qt.NoBrush)

            def draw_outline(segments: Sequence[Mapping[str, Any]], color: QColor, width: int, style) -> None:
                if not isinstance(segments, Sequence):
                    return
                pen = QPen(color, width)
                pen.setStyle(style)
                painter.setPen(pen)
                for seg in segments:
                    if not isinstance(seg, Mapping):
                        continue
                    try:
                        start = int(seg.get("start", 0))
                        end = int(seg.get("end", start + 1))
                    except Exception:
                        continue
                    if end <= start:
                        continue
                    if start < 0:
                        start = 0
                    if start >= seq_len:
                        continue
                    end = max(start + 1, min(end, seq_len))
                    end_idx = max(start, end - 1)
                    x0 = x_for(start)
                    x1 = x_for(end_idx)
                    width_px = max(2.0, x1 - x0 + 1.0)
                    rect = QRectF(x0, rail_y - band_half, width_px, band_half * 2)
                    painter.drawRect(rect)

            desired_color = QColor("#22c55e")
            partial_color = QColor("#facc15")
            partial_color.setAlpha(150)
            draw_outline(desired if isinstance(desired, Sequence) else [], desired_color, 2, Qt.SolidLine)
            draw_outline(partial if isinstance(partial, Sequence) else [], partial_color, 1, Qt.DashLine)

            if nick_index is not None:
                try:
                    nick_idx = int(nick_index)
                except Exception:
                    nick_idx = None
                if nick_idx is not None and 0 <= nick_idx < seq_len:
                    nick_x = x_for(nick_idx)
                    pen = QPen(QColor("#a855f7"), 2)
                    painter.setPen(pen)
                    painter.drawLine(int(nick_x), int(rail_y - 26), int(nick_x), int(rail_y - 14))

            painter.restore()

        def _draw_base_overlay(self, painter: QPainter, x_for, rail_y: float, seq_len: int) -> None:
            meta = self._base_overlay
            if not isinstance(meta, Mapping):
                return
            if not bool(meta.get("show", True)):
                return
            desired = meta.get("desired")
            bystander = meta.get("bystander")
            ticks = meta.get("ticks") if isinstance(meta.get("ticks"), Sequence) else None
            tick_levels = int(meta.get("tick_levels", 4) or 4)

            band_half = 8
            painter.save()
            painter.setBrush(Qt.NoBrush)

            def draw_outline(
                segments: Sequence[Mapping[str, Any]],
                color: QColor,
                width: int,
                dash_pattern: list[float] | None = None,
                alpha: int | None = None,
            ) -> None:
                if not isinstance(segments, Sequence):
                    return
                pen = QPen(color, width)
                if dash_pattern:
                    pen.setDashPattern(dash_pattern)
                if alpha is not None:
                    pen_color = QColor(color)
                    pen_color.setAlpha(alpha)
                    pen.setColor(pen_color)
                painter.setPen(pen)
                for seg in segments:
                    if not isinstance(seg, Mapping):
                        continue
                    try:
                        start = int(seg.get("start", 0))
                        end = int(seg.get("end", start + 1))
                    except Exception:
                        continue
                    if end <= start:
                        continue
                    if start < 0:
                        start = 0
                    if start >= seq_len:
                        continue
                    end = max(start + 1, min(end, seq_len))
                    end_idx = max(start, end - 1)
                    x0 = x_for(start)
                    x1 = x_for(end_idx)
                    width_px = max(2.0, x1 - x0 + 1.0)
                    rect = QRectF(x0, rail_y - band_half, width_px, band_half * 2)
                    painter.drawRect(rect)

            desired_color = QColor("#38bdf8")
            bystander_color = QColor("#a78bfa")
            draw_outline(desired if isinstance(desired, Sequence) else [], desired_color, 2)
            draw_outline(
                bystander if isinstance(bystander, Sequence) else [],
                bystander_color,
                1,
                dash_pattern=[4.0, 3.0],
                alpha=150,
            )

            if ticks:
                level_count = max(1, tick_levels)
                multipliers = [1.0, 1.4, 1.9, 2.5]
                base_len = 6.0
                anchor_y = rail_y - 16.0
                for tick in ticks:
                    if not isinstance(tick, Mapping):
                        continue
                    try:
                        pos = int(tick.get("pos", -1))
                        level = int(tick.get("level", 0))
                    except Exception:
                        continue
                    if pos < 0 or pos >= seq_len:
                        continue
                    level = max(0, min(level_count - 1, level))
                    mult = multipliers[level] if level < len(multipliers) else multipliers[-1]
                    length = base_len * mult
                    role = str(tick.get("role") or "").lower()
                    color = desired_color if "desired" in role else bystander_color
                    thickness = 1 if level < 2 else 2
                    painter.setPen(Qt.NoPen)
                    painter.setBrush(color)
                    x = int(round(x_for(pos)))
                    half = thickness // 2
                    x0 = x - half
                    y0 = int(round(anchor_y - length))
                    height = max(1, int(round(length)))
                    width = max(1, int(thickness))
                    painter.drawRect(x0, y0, width, height)

            painter.restore()

        def _draw_axis_annotations(self, painter: QPainter, rect: QRectF) -> None:
            painter.save()
            painter.setPen(QColor("#94a3b8"))
            painter.setFont(QFont("Inter", 10))
            painter.drawText(
                rect.adjusted(0, 0, 0, 0),
                Qt.AlignLeft | Qt.AlignVCenter,
                "Position (bp relative to cut)",
            )
            painter.drawText(rect.adjusted(0, 0, 0, 0), Qt.AlignRight | Qt.AlignVCenter, "Probability")
            painter.restore()

        def _draw_probability_scale(self, painter: QPainter, rect: QRectF) -> None:
            painter.save()
            painter.setPen(QColor("#475569"))
            painter.setFont(QFont("Inter", 10))
            painter.drawLine(rect.left(), rect.center().y(), rect.right(), rect.center().y())
            for idx in range(6):
                x = rect.left() + (idx / 5.0) * rect.width()
                painter.drawLine(x, rect.center().y() - 4, x, rect.center().y() + 4)
                painter.drawText(int(x - 8), int(rect.center().y() + 20), f"{idx * 20}%")
            painter.restore()

        def _draw_band_texture(self, painter: QPainter, rect: QRectF, kind: str, prob: float) -> None:
            painter.save()
            pen = QPen(QColor("#0ea5e9") if kind == "no_cut" else QColor("#0b1120"))
            pen.setWidth(2)
            pen.setStyle(Qt.DotLine if kind == "no_cut" else Qt.SolidLine)
            painter.setPen(pen)
            painter.drawLine(rect.left(), rect.center().y(), rect.right(), rect.center().y())
            painter.restore()

        def _start_animation(self) -> None:
            self._anim_progress = 0.0
            self._anim_timer.start()

        def _advance_animation(self) -> None:
            self._anim_progress = min(1.0, self._anim_progress + 0.05)
            if self._anim_progress >= 1.0:
                self._anim_timer.stop()
            self.update()


else:

    class RailBandWidget:  # pragma: no cover - headless stub
        def __init__(self, *args, **kwargs) -> None:
            raise RuntimeError("Qt GUI stack not available; RailBandWidget cannot be used.")
