from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


def ensure_icon_resources_loaded() -> bool:
    """Best-effort registration of Qt icon resources (:/icons/*).

    In packaged builds, `helix.theme.icons_rc` may be importable directly.
    In source-tree dev, icons are generated to `helix/theme/icons_rc.py` (repo root),
    so we dynamically load that module if needed.
    """

    if bool(getattr(ensure_icon_resources_loaded, "_loaded", False)):
        return True

    try:
        import helix.theme.icons_rc  # type: ignore  # noqa: F401

        ensure_icon_resources_loaded._loaded = True  # type: ignore[attr-defined]
        return True
    except Exception:
        pass

    try:
        repo_root = Path(__file__).resolve().parents[3]
        icons_rc_path = repo_root / "helix" / "theme" / "icons_rc.py"
        if not icons_rc_path.is_file():
            return False
        spec = importlib.util.spec_from_file_location("helix.theme.icons_rc", icons_rc_path)
        if spec and spec.loader:
            mod = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = mod
            spec.loader.exec_module(mod)  # type: ignore[arg-type]
            ensure_icon_resources_loaded._loaded = True  # type: ignore[attr-defined]
            return True
    except Exception:
        return False

    return False


__all__ = ["ensure_icon_resources_loaded"]

