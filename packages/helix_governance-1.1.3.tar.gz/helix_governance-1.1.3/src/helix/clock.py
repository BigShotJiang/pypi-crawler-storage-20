from __future__ import annotations

import contextvars
import hashlib
import os
import time
from datetime import datetime, timezone

from helix.determinism.nondet import nondeterminism_allowed


DETERMINISTIC_UTC_ISO = "1970-01-01T00:00:00Z"

_RUN_ANCHOR_NS: contextvars.ContextVar[int] = contextvars.ContextVar("helix_deterministic_anchor_ns", default=0)


def _truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _deterministic_mode() -> bool:
    return _truthy(os.getenv("HELIX_DETERMINISTIC")) or _truthy(os.getenv("HELIX_FORBID_RANDOM"))


def set_deterministic_anchor_from_run_id(run_id: str) -> None:
    token = str(run_id or "").strip()
    if not token:
        _RUN_ANCHOR_NS.set(0)
        return
    digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
    _RUN_ANCHOR_NS.set(int.from_bytes(digest, "big"))


def deterministic_now_ns() -> int:
    return int(_RUN_ANCHOR_NS.get() or 0)


def now_ns() -> int:
    """
    Current wall-clock time in ns.

    In deterministic mode, this returns a deterministic value unless
    `helix.determinism.allow_nondeterminism()` is active.
    """

    if _deterministic_mode() and not nondeterminism_allowed():
        return deterministic_now_ns()
    return int(time.time_ns())


def deterministic_utc_iso() -> str:
    """Deterministic timestamp string for artifact writers."""

    return DETERMINISTIC_UTC_ISO


def utc_now_iso() -> str:
    """
    Current UTC timestamp as ISO-8601 with trailing 'Z'.

    In deterministic mode, this returns a deterministic value unless
    `helix.determinism.allow_nondeterminism()` is active.
    """

    if _deterministic_mode() and not nondeterminism_allowed():
        return deterministic_utc_iso()
    ts_ns = now_ns()
    dt = datetime.fromtimestamp(ts_ns / 1_000_000_000, tz=timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


def perf_counter() -> float:
    """
    High-resolution monotonic clock.

    In deterministic mode, this returns 0.0 unless nondeterminism is explicitly allowed.
    """

    if _deterministic_mode() and not nondeterminism_allowed():
        return 0.0
    return float(time.perf_counter())


def monotonic() -> float:
    """
    Monotonic clock in seconds.

    In deterministic mode, this returns 0.0 unless nondeterminism is explicitly allowed.
    """

    if _deterministic_mode() and not nondeterminism_allowed():
        return 0.0
    return float(time.monotonic())


def unix_time_s() -> float:
    """
    Unix epoch time in seconds.

    In deterministic mode, this returns a deterministic value unless nondeterminism is explicitly allowed.
    """

    return float(now_ns()) / 1_000_000_000


def utc_now_iso_offset() -> str:
    """UTC ISO timestamp with explicit +00:00 offset (no trailing 'Z')."""

    return utc_now_iso().replace("Z", "+00:00")


def utc_now_stamp() -> str:
    """UTC compact timestamp for filenames (YYYYmmdd_HHMMSS)."""

    if _deterministic_mode() and not nondeterminism_allowed():
        return "19700101_000000"
    ts_ns = now_ns()
    dt = datetime.fromtimestamp(ts_ns / 1_000_000_000, tz=timezone.utc)
    return dt.strftime("%Y%m%d_%H%M%S")


def local_now_stamp() -> str:
    """Local-time compact timestamp for filenames (YYYYmmdd_HHMMSS)."""

    if _deterministic_mode() and not nondeterminism_allowed():
        return "19700101_000000"
    ts_ns = now_ns()
    dt = datetime.fromtimestamp(ts_ns / 1_000_000_000).astimezone()
    return dt.strftime("%Y%m%d_%H%M%S")


__all__ = [
    "DETERMINISTIC_UTC_ISO",
    "deterministic_now_ns",
    "deterministic_utc_iso",
    "local_now_stamp",
    "monotonic",
    "now_ns",
    "perf_counter",
    "set_deterministic_anchor_from_run_id",
    "unix_time_s",
    "utc_now_iso",
    "utc_now_iso_offset",
    "utc_now_stamp",
]
