# ampseq_indel_profile_v1

Canonical AMP-seq style workflow: paired-end FASTQ ➜ deterministic indel profile and allele table.

Inputs:
- `inputs/reads_R1.fastq.gz`, `inputs/reads_R2.fastq.gz` (paired-end; R2 is reverse-complement of R1 in this fixture)
- `inputs/amplicon.fasta` (amplicon reference)
- `inputs/target.json` (cut index + reporting options)

Expected outputs (exact-golden):
- `alleles.tsv` (stable sort, integer-derived fractions)
- `top_alleles.tsv`
- `indel_hist.json`
- `summary.json`

