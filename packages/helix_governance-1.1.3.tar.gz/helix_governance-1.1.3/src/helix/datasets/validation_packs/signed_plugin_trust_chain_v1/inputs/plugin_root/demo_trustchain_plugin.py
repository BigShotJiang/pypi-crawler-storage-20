def activate(host_api):
    loaded = getattr(host_api, "loaded", None)
    if isinstance(loaded, list):
        loaded.append("demo.trustchain")
    return None
