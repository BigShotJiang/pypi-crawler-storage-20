# signed_plugin_trust_chain_v1

Canonical supply-chain workflow: build/install/load a signed plugin, then fail deterministically on a tampered package.

Inputs:
- `inputs/plugin_root/` (minimal plugin source tree)
- `inputs/publisher.ed25519` (deterministic test key; not a production credential)

Expected outputs (exact-golden):
- `trust_chain.json` (signed path succeeds; tampered path fails with explicit reason)

