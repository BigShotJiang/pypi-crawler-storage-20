# bam_qc_coverage_v1

Canonical BAM workflow: coordinate-sorted BAM ➜ deterministic QC + coverage artifacts.

Inputs:
- `inputs/sample.bam` + `inputs/sample.bam.bai`
- `inputs/regions.bed`

Expected outputs (exact-golden integers):
- `summary.json` (read counts, duplicates, reference lengths)
- `coverage_hist.json` (binned depth histogram)
- `region_coverage.tsv` (per-region depth totals and integer-derived means)

