# cas9_nhej_outcome_prediction_v1

Cas9 NHEJ outcome distribution validation pack (pre-clinical, in silico).

This pack validates that Helix can:
- generate a deterministic allele spectrum for cut outcomes
- reduce it to a delta-bp distribution (ins/del length + OTHER bucket)
- compute stable, diffable accuracy-style metrics (top-k + KL + frameshift proxy)

Inputs:
- `inputs/cases.json` (case manifest + metric thresholds)
- `inputs/*_input.json` (experiment_spec/edit_plan/reference_context fixtures)
- `inputs/*_observed.json` (observed delta-bp distributions; swap in real empirical distributions to make this a biological accuracy pack)

Outputs:
- `metrics.json` (aggregate + per-case metrics; written under the run output directory)

