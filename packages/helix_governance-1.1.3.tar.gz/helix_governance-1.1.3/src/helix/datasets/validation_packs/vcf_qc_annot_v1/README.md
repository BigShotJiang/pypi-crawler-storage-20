# vcf_qc_annot_v1

Canonical VCF workflow: VCF ➜ QC summary + lightweight annotation join, deterministically.

Inputs:
- `inputs/sample.vcf`
- `inputs/annotations.tsv` (static, pack-bundled annotation fixture)

Expected outputs (exact-golden):
- `qc_summary.json` (counts, Ti/Tv, AF bins)
- `annotated_variants.tsv` (stable sort order, normalized fields)

