# crisprresso_import_v1

Canonical ingestion workflow: CRISPResso-style output directory ➜ normalized Helix artifacts.

Inputs:
- `inputs/CRISPResso_output/` (minimal CRISPResso fixture: quantification, alleles table, info json)

Expected outputs (exact-golden):
- `editing_summary.tsv` (counts + integer-derived editing rate)
- `alleles.tsv` (stable sort, raw counts)
- `metadata.json` (normalized version/params)

