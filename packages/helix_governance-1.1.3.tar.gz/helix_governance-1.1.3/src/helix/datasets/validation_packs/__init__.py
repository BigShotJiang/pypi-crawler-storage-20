"""Packaged validation pack fixtures."""
