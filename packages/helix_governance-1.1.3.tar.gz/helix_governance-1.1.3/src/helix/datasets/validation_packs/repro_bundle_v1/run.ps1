$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:PYTHONHASHSEED = "0"
$env:LC_ALL = "C"
$env:TZ = "UTC"

$Spec = Join-Path $Root "inputs/case01.spec.json"
$Out = Join-Path $Root "out/case01"

helix-cli run $Spec --out $Out
