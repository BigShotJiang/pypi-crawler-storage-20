# Helix Repro Bundle v1

This bundle provides a deterministic, offline-verifiable reproduction case for Helix.

## Quick Start

- Run: `./run.sh` (or `run.ps1` on Windows)
- Verify: `./verify.sh` (or `verify.ps1` on Windows)

## Layout

- `inputs/` minimal case spec + case manifest
- `expected/` canonical expected outputs for CPU/GPU backends
- `policy.json` determinism policy
- `manifest.json` bundle manifest with SHA256 for every artifact

## Verification Command Shape

```
helix-cli run inputs/case01.spec.json --out out/case01
helix-cli verify out/case01 --deterministic --manifest inputs/case01.manifest.json
```
