#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONHASHSEED=0
export LC_ALL=C
export TZ=UTC

helix-cli run "$ROOT/inputs/case01.spec.json" --out "$ROOT/out/case01"
