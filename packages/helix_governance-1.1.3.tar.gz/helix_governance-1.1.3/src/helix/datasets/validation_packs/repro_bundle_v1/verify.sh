#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONHASHSEED=0
export LC_ALL=C
export TZ=UTC

helix-cli verify "$ROOT/out/case01" --deterministic --manifest "$ROOT/inputs/case01.manifest.json"
