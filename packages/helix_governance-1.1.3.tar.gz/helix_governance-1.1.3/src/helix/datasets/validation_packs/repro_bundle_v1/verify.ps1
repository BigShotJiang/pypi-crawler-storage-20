$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:PYTHONHASHSEED = "0"
$env:LC_ALL = "C"
$env:TZ = "UTC"

$Out = Join-Path $Root "out/case01"
$Manifest = Join-Path $Root "inputs/case01.manifest.json"

helix-cli verify $Out --deterministic --manifest $Manifest
