from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, Tuple

import moderngl
import numpy as np

from .base import FieldOp, FieldSpec, TileSpec
import helix_cuda_fields


@dataclass
class CompositeEditabilityFieldOp(FieldOp):
    ctx: moderngl.Context
    shader_dir: str

    spec: FieldSpec = field(
        default_factory=lambda: FieldSpec(
            name="composite_editability",
            components=1,
            dtype="f4",
            normalized=True,
            description="Composite editability/safety field (PAM+Prime minus Indel/Off-target)",
        )
    )

    _prog: Optional[moderngl.Program] = None
    _vao: Optional[moderngl.VertexArray] = None
    _vbo: Optional[moderngl.Buffer] = None
    _tex: Optional[moderngl.Texture] = None
    _tile_len_alloc: int = 0
    _scores_host: Optional[np.ndarray] = None

    def _ensure_program(self) -> None:
        if self._prog is not None:
            return
        with open(f"{self.shader_dir}/heatmap.vert.glsl", encoding="utf8") as f:
            vs_src = f.read()
        with open(f"{self.shader_dir}/heatmap.frag.glsl", encoding="utf8") as f:
            fs_src = f.read()
        self._prog = self.ctx.program(vertex_shader=vs_src, fragment_shader=fs_src)

        quad = np.array(
            [
                -1.0, -1.0, 0.0, 0.0,
                 1.0, -1.0, 1.0, 0.0,
                -1.0,  1.0, 0.0, 1.0,
                 1.0,  1.0, 1.0, 1.0,
            ],
            dtype="f4",
        )
        self._vbo = self.ctx.buffer(quad.tobytes())
        self._vao = self.ctx.vertex_array(
            self._prog,
            [(self._vbo, "2f 2f", "in_pos", "in_uv")],
        )

    def ensure_resources(self, ctx: moderngl.Context, tile_len_bp: int) -> None:
        self._ensure_program()
        if tile_len_bp <= self._tile_len_alloc:
            return

        if self._tex is not None:
            self._tex.release()
        # 1D field as 2D texture (W x 1)
        self._tex = ctx.texture((tile_len_bp, 1), components=1, dtype="f4")
        self._tile_len_alloc = tile_len_bp

    def compute(
        self,
        ctx: moderngl.Context,
        tile: TileSpec,
        seq_slice: str,  # unused but kept for interface parity
        params: Dict[str, Any],
    ) -> np.ndarray:
        pam = np.asarray(params.get("pam"), dtype=np.float32)
        prime = np.asarray(params.get("prime"), dtype=np.float32)
        indel = np.asarray(params.get("indel"), dtype=np.float32)
        off = np.asarray(params.get("off"), dtype=np.float32)
        n = tile.tile_len_bp

        def _pad(arr: np.ndarray) -> np.ndarray:
            if arr.shape[0] == n:
                return arr
            out = np.zeros(n, dtype=np.float32)
            m = min(n, arr.shape[0])
            out[:m] = arr[:m]
            return out

        pam = _pad(pam)
        prime = _pad(prime)
        indel = _pad(indel)
        off = _pad(off)

        pam_w = float(params.get("pam_weight", 1.0))
        prime_w = float(params.get("prime_weight", 1.0))
        indel_w = float(params.get("indel_weight", 1.0))
        off_w = float(params.get("off_weight", 1.0))
        normalize = bool(params.get("normalize", False))

        scores = helix_cuda_fields.composite_editability_scores(
            pam,
            prime,
            indel,
            off,
            pam_w,
            prime_w,
            indel_w,
            off_w,
            normalize,
        )
        scores = np.asarray(scores, dtype=np.float32)

        self._scores_host = scores
        if self._tex is not None and scores.size > 0:
            self._tex.write(scores.tobytes())
        return scores

    def render(
        self,
        ctx: moderngl.Context,
        viewport_px: Tuple[int, int, int, int],
        debug_overrides: Optional[Dict[str, Any]] = None,
    ) -> None:
        if self._prog is None or self._vao is None or self._tex is None:
            return
        if self._scores_host is None or self._scores_host.size == 0:
            return

        x, y, w, h = viewport_px
        ctx.viewport = (x, y, w, h)
        ctx.disable(moderngl.DEPTH_TEST)

        self._tex.use(0)
        self._prog["scores_tex"].value = 0
        self._prog["score_len"].value = int(self._scores_host.shape[0])

        max_score = float(self._scores_host.max())
        if max_score <= 0.0:
            return
        self._prog["max_score"].value = max_score

        self._vao.render(moderngl.TRIANGLE_STRIP)
