from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

import moderngl
import numpy as np

from .base import FieldOp, FieldSpec, TileSpec

try:
    import helix_cuda_fields  # type: ignore
except ImportError:  # pragma: no cover
    helix_cuda_fields = None

BASE_MAP = {
    ord("A"): 0,
    ord("C"): 1,
    ord("G"): 2,
    ord("T"): 3,
}


def encode_seq_to_codes(seq_str: str) -> np.ndarray:
    seq_bytes = np.frombuffer(seq_str.upper().encode("ascii"), dtype=np.uint8)
    out = np.zeros(len(seq_bytes), dtype=np.uint8)
    for ch, code in BASE_MAP.items():
        mask = seq_bytes == ch
        if mask.any():
            out[mask] = code
    return out


def encode_pam(pattern: str) -> np.ndarray:
    pattern = pattern.upper()
    out = np.zeros(len(pattern), dtype=np.uint8)
    for i, ch in enumerate(pattern):
        if ch == "N":
            out[i] = 4
        else:
            out[i] = BASE_MAP.get(ord(ch), 4)
    return out


@dataclass
class OfftargetDensityFieldOp(FieldOp):
    ctx: moderngl.Context
    shader_dir: str

    spec: FieldSpec = field(
        default_factory=lambda: FieldSpec(
            name="offtarget_density",
            components=1,
            dtype="f4",
            normalized=True,
            description="Per-base off-target affinity (PAM + mismatches)",
        )
    )

    _prog: Optional[moderngl.Program] = None
    _vao: Optional[moderngl.VertexArray] = None
    _vbo: Optional[moderngl.Buffer] = None
    _tex: Optional[moderngl.Texture] = None
    _tile_len_alloc: int = 0
    _scores_host: Optional[np.ndarray] = None

    def _ensure_program(self) -> None:
        if self._prog is not None:
            return
        with open(f"{self.shader_dir}/heatmap.vert.glsl", encoding="utf8") as f:
            vs_src = f.read()
        with open(f"{self.shader_dir}/heatmap.frag.glsl", encoding="utf8") as f:
            fs_src = f.read()
        self._prog = self.ctx.program(vertex_shader=vs_src, fragment_shader=fs_src)

        quad = np.array(
            [
                -1.0, -1.0, 0.0, 0.0,
                 1.0, -1.0, 1.0, 0.0,
                -1.0,  1.0, 0.0, 1.0,
                 1.0,  1.0, 1.0, 1.0,
            ],
            dtype="f4",
        )
        self._vbo = self.ctx.buffer(quad.tobytes())
        self._vao = self.ctx.vertex_array(
            self._prog,
            [(self._vbo, "2f 2f", "in_pos", "in_uv")],
        )

    def ensure_resources(self, ctx: moderngl.Context, tile_len_bp: int) -> None:
        self._ensure_program()
        if tile_len_bp <= self._tile_len_alloc:
            return
        if self._tex is not None:
            self._tex.release()
        self._tex = ctx.texture((tile_len_bp, 1), components=1, dtype="f4")
        self._tex.filter = (moderngl.NEAREST, moderngl.NEAREST)
        self._tile_len_alloc = tile_len_bp

    def compute(
        self,
        ctx: moderngl.Context,
        tile: TileSpec,
        seq_slice: str,
        params: Dict[str, Any],
    ) -> np.ndarray:
        if helix_cuda_fields is None:
            raise RuntimeError("helix_cuda_fields module not available")

        guide = params["guide"]
        pam_pattern = params.get("pam_pattern", "NGG")
        mismatch_penalty = float(params.get("mismatch_penalty", 1.0))
        score_scale = float(params.get("score_scale", 1.0))

        seq_codes = encode_seq_to_codes(seq_slice)
        guide_codes = encode_seq_to_codes(guide)
        pam_codes = encode_pam(pam_pattern)

        scores = helix_cuda_fields.offtarget_density_scores(
            seq_codes,
            guide_codes,
            pam_codes,
            mismatch_penalty=mismatch_penalty,
            score_scale=score_scale,
        )
        scores = np.asarray(scores, dtype=np.float32)

        self._scores_host = scores
        if self._tex is not None and scores.size > 0:
            self._tex.write(scores.tobytes())
        return scores

    def render(
        self,
        ctx: moderngl.Context,
        viewport_px: Tuple[int, int, int, int],
        debug_overrides: Optional[Dict[str, Any]] = None,
    ) -> None:
        if self._prog is None or self._vao is None or self._tex is None:
            return
        if self._scores_host is None or self._scores_host.size == 0:
            return

        x, y, w, h = viewport_px
        ctx.viewport = (x, y, w, h)
        ctx.disable(moderngl.DEPTH_TEST)

        self._tex.use(0)
        self._prog["scores_tex"].value = 0
        self._prog["score_len"].value = int(self._scores_host.shape[0])
        max_score = float(self._scores_host.max())
        if max_score <= 0.0:
            return
        self._prog["max_score"].value = max_score
        self._vao.render(moderngl.TRIANGLE_STRIP)
