from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Protocol, Tuple

import moderngl
import numpy as np


@dataclass
class TileSpec:
    chrom: str
    tile_start_bp: int
    tile_len_bp: int

    @property
    def tile_end_bp(self) -> int:
        return self.tile_start_bp + self.tile_len_bp


@dataclass
class FieldSpec:
    name: str
    components: int = 1
    dtype: str = "f4"
    normalized: bool = True
    description: str = ""


class FieldOp(Protocol):
    spec: FieldSpec

    def ensure_resources(self, ctx: moderngl.Context, tile_len_bp: int) -> None: ...

    def compute(
        self,
        ctx: moderngl.Context,
        tile: TileSpec,
        seq_slice: str,
        params: Dict[str, Any],
    ) -> np.ndarray: ...

    def render(
        self,
        ctx: moderngl.Context,
        viewport_px: Tuple[int, int, int, int],
        debug_overrides: Optional[Dict[str, Any]] = None,
    ) -> None: ...


@dataclass
class FieldRegistry:
    ctx: moderngl.Context
    _ops: Dict[str, FieldOp] = field(default_factory=dict)

    def register(self, op: FieldOp) -> None:
        if op.spec.name in self._ops:
            raise ValueError(f"Field '{op.spec.name}' already registered")
        self._ops[op.spec.name] = op

    def get(self, name: str) -> FieldOp:
        try:
            return self._ops[name]
        except KeyError as exc:  # pragma: no cover
            raise KeyError(f"Unknown field '{name}'") from exc

    def compute_field(
        self,
        field_name: str,
        tile: TileSpec,
        seq_slice: str,
        params: Dict[str, Any],
    ) -> np.ndarray:
        op = self.get(field_name)
        op.ensure_resources(self.ctx, tile.tile_len_bp)
        return op.compute(self.ctx, tile, seq_slice, params)

    def render_field(
        self,
        field_name: str,
        viewport_px: Tuple[int, int, int, int],
        debug_overrides: Optional[Dict[str, Any]] = None,
    ) -> None:
        op = self.get(field_name)
        op.render(self.ctx, viewport_px, debug_overrides)
