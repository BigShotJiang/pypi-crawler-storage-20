from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional, Tuple

import moderngl
import numpy as np

from .base import FieldOp, FieldSpec, TileSpec

try:
    import helix_cuda_fields  # type: ignore
except Exception:  # pragma: no cover - optional build
    helix_cuda_fields = None  # type: ignore

BASE_MAP = {
    ord("A"): 0,
    ord("C"): 1,
    ord("G"): 2,
    ord("T"): 3,
}


def _encode(seq: str) -> np.ndarray:
    seq_bytes = seq.upper().encode("ascii")
    arr = np.frombuffer(seq_bytes, dtype=np.uint8)
    out = np.zeros_like(arr, dtype=np.uint8)
    for ch, code in BASE_MAP.items():
        out[arr == ch] = code
    return out


@dataclass
class PrimeDpFieldOp(FieldOp):
    ctx: moderngl.Context
    shader_dir: str

    spec: FieldSpec = field(
        default_factory=lambda: FieldSpec(
            name="prime_dp",
            components=1,
            dtype="f4",
            normalized=True,
            description="Prime editing RT extension DP field",
        ),
        init=False,
        repr=False,
    )

    _prog: Optional[moderngl.Program] = None
    _vao: Optional[moderngl.VertexArray] = None
    _vbo: Optional[moderngl.Buffer] = None
    _tex: Optional[moderngl.Texture] = None
    _tile_len_alloc: int = 0
    _scores_host: Optional[np.ndarray] = None

    def _ensure_program(self) -> None:
        if self._prog is not None:
            return
        with open(f"{self.shader_dir}/heatmap.vert.glsl", encoding="utf8") as f:
            vs_src = f.read()
        with open(f"{self.shader_dir}/heatmap.frag.glsl", encoding="utf8") as f:
            fs_src = f.read()
        self._prog = self.ctx.program(vertex_shader=vs_src, fragment_shader=fs_src)

        quad = np.array(
            [
                -1.0, -1.0, 0.0, 0.0,
                 1.0, -1.0, 1.0, 0.0,
                -1.0,  1.0, 0.0, 1.0,
                 1.0,  1.0, 1.0, 1.0,
            ],
            dtype="f4",
        )
        self._vbo = self.ctx.buffer(quad.tobytes())
        self._vao = self.ctx.vertex_array(
            self._prog,
            [(self._vbo, "2f 2f", "in_pos", "in_uv")],
        )

    def ensure_resources(self, ctx: moderngl.Context, tile_len_bp: int) -> None:
        self._ensure_program()
        if tile_len_bp <= self._tile_len_alloc:
            return
        if self._tex is not None:
            self._tex.release()
        self._tex = ctx.texture((tile_len_bp, 1), components=1, dtype="f4")
        self._tex.filter = (moderngl.NEAREST, moderngl.NEAREST)
        self._tile_len_alloc = tile_len_bp

    def compute(
        self,
        ctx: moderngl.Context,
        tile: TileSpec,
        seq_slice: str,
        params: Dict[str, Any],
    ) -> np.ndarray:
        if helix_cuda_fields is None:
            raise RuntimeError("helix_cuda_fields module not available")

        rt_template = params["rt_template"]
        nick_pos_global = int(params["nick_pos_bp"])

        nick_local = nick_pos_global - tile.tile_start_bp
        if nick_local < 0 or nick_local >= tile.tile_len_bp:
            scores = np.zeros(tile.tile_len_bp, dtype=np.float32)
        else:
            seq_codes = _encode(seq_slice)
            rt_codes = _encode(rt_template)
            scores = helix_cuda_fields.prime_dp_scores(
                seq_codes,
                rt_codes,
                int(nick_local),
                mismatch_penalty=float(params.get("mismatch_penalty", 1.0)),
                gap_penalty=float(params.get("gap_penalty", 1.0)),
                extension_bonus=float(params.get("extension_bonus", 1.0)),
                max_extension=int(params.get("max_extension", len(rt_template))),
            )
            scores = np.asarray(scores, dtype=np.float32)

        self._scores_host = scores
        if self._tex is not None and scores.size > 0:
            self._tex.write(scores.tobytes())
        return scores

    def render(
        self,
        ctx: moderngl.Context,
        viewport_px: Tuple[int, int, int, int],
        debug_overrides: Optional[Dict[str, Any]] = None,
    ) -> None:
        if self._prog is None or self._vao is None or self._tex is None:
            return
        if self._scores_host is None or self._scores_host.size == 0:
            return
        max_score = float(self._scores_host.max())
        if max_score <= 0.0:
            return

        x, y, w, h = viewport_px
        ctx.viewport = (x, y, w, h)
        ctx.disable(moderngl.DEPTH_TEST)

        self._tex.use(0)
        self._prog["scores_tex"].value = 0
        self._prog["score_len"].value = int(self._scores_host.shape[0])
        self._prog["max_score"].value = max_score
        self._vao.render(moderngl.TRIANGLE_STRIP)
