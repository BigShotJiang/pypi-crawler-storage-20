"""Microhomology-weighted cut outcome spectrum helpers.

This module provides a lightweight, deterministic approximation of the indel
spectrum near a CRISPR cut site. It is intended for *relative comparisons*
within a sequence window and for powering UI tooling (DAG branching, proxies),
not for decision-grade predictions.
"""

from __future__ import annotations

import math
from typing import Any, Mapping


def _normalize_base(base: str) -> str:
    base = (base or "").upper()
    return base if base in {"A", "C", "G", "T"} else "A"


def microhomology_len(seq: str, left_end: int, right_start: int, *, max_k: int = 6) -> int:
    """Return the longest exact microhomology length up to `max_k`.

    `left_end` is exclusive, `right_start` is inclusive (Python slicing semantics).
    """

    max_k = max(0, int(max_k))
    best = 0
    for k in range(1, max_k + 1):
        if left_end - k < 0 or right_start + k > len(seq):
            continue
        left = seq[left_end - k : left_end]
        right = seq[right_start : right_start + k]
        if any(base not in {"A", "C", "G", "T"} for base in left + right):
            continue
        if left == right:
            best = k
    return best


def _gc_fraction(seq: str) -> float:
    if not seq:
        return 0.0
    gc = sum(1 for ch in seq.upper() if ch in {"G", "C"})
    return float(gc) / float(len(seq))


def build_microhomology_indel_spectrum(
    sequence: str,
    cut_index: int,
    *,
    max_alleles: int = 50,
    min_frequency: float = 0.0,
    max_del: int = 30,
    max_ins: int = 3,
    max_shift: int = 4,
) -> list[dict[str, Any]] | None:
    """Return a microhomology-weighted indel spectrum around `cut_index`.

    The returned spectrum is a list of dicts with:
      - sequenceDelta: {type: del|ins|other, ...}
      - frequency: normalized probability mass
      - confidence: heuristic confidence (0..1), relative within spectrum

    Notes:
    - This spectrum is conditional on an indel occurring (no explicit no-cut term).
    - Coordinates are 0-based indices into `sequence`.
    """

    if not isinstance(sequence, str):
        return None
    seq = sequence.strip().upper()
    if not seq:
        return None
    try:
        cut = int(cut_index)
    except Exception:
        return None
    if not (0 <= cut < len(seq)):
        return None

    max_alleles = max(1, int(max_alleles))
    min_frequency = max(0.0, float(min_frequency))
    max_del = max(1, int(max_del))
    max_ins = max(1, int(max_ins))
    max_shift = max(0, int(max_shift))

    gc = _gc_fraction(seq[max(0, cut - 10) : min(len(seq), cut + 10)])
    gc_factor = 1.0 + (gc - 0.5) * 0.2

    candidates: list[dict[str, Any]] = []

    for del_len in range(1, max_del + 1):
        base_prior = math.exp(-float(del_len) / 8.0)
        for shift in range(0, min(max_shift, del_len) + 1):
            start = cut - shift
            end = start + del_len
            if start < 0 or end > len(seq):
                continue
            mh = microhomology_len(seq, start, end, max_k=6)
            weight = base_prior * (1.0 + 0.15 * float(mh)) * gc_factor * (1.0 - 0.04 * shift)
            if not math.isfinite(weight) or weight <= 0.0:
                continue
            candidates.append(
                {
                    "sequenceDelta": {
                        "type": "del",
                        "start": int(start),
                        "end": int(end),
                        "length": int(del_len),
                        "microhomology": int(mh),
                    },
                    "weight": float(weight),
                }
            )

    ins_base = _normalize_base(seq[cut - 1] if cut > 0 else "A")
    for ins_len in range(1, max_ins + 1):
        weight = math.exp(-float(ins_len) / 2.0) * 0.6 * gc_factor
        if not math.isfinite(weight) or weight <= 0.0:
            continue
        candidates.append(
            {
                "sequenceDelta": {
                    "type": "ins",
                    "start": int(cut),
                    "sequence": ins_base * ins_len,
                    "length": int(ins_len),
                },
                "weight": float(weight),
            }
        )

    if not candidates:
        return None

    total = sum(float(c.get("weight") or 0.0) for c in candidates)
    if not math.isfinite(total) or total <= 0.0:
        return None

    max_weight = max(float(c.get("weight") or 0.0) for c in candidates)
    if max_weight <= 0.0:
        return None

    def _delta_key(delta: Mapping[str, Any]) -> str:
        kind = str(delta.get("type") or "")
        if kind == "del":
            return f"del:{delta.get('start')}:{delta.get('end')}:{delta.get('length')}:{delta.get('microhomology')}"
        if kind == "ins":
            return f"ins:{delta.get('start')}:{delta.get('length')}:{delta.get('sequence')}"
        return f"other:{delta.get('label')}"

    enriched: list[dict[str, Any]] = []
    for entry in candidates:
        weight = float(entry.get("weight") or 0.0)
        if weight <= 0.0:
            continue
        freq = weight / total
        delta = entry["sequenceDelta"]
        conf = 0.2 + 0.6 * (weight / max_weight)
        enriched.append(
            {
                "sequenceDelta": delta,
                "frequency": float(freq),
                "confidence": round(float(conf), 4),
                "_delta_key": _delta_key(delta),
            }
        )

    enriched.sort(key=lambda d: (-float(d.get("frequency") or 0.0), str(d.get("_delta_key") or "")))

    kept: list[dict[str, Any]] = []
    remainder = 0.0
    truncated = False
    for entry in enriched:
        freq = float(entry.get("frequency") or 0.0)
        if min_frequency > 0.0 and freq < min_frequency:
            remainder += freq
            truncated = True
            continue
        if len(kept) < max_alleles:
            kept.append(entry)
        else:
            remainder += freq
            truncated = True

    spectrum: list[dict[str, Any]] = []
    for entry in kept:
        spectrum.append(
            {
                "sequenceDelta": entry["sequenceDelta"],
                "frequency": float(entry["frequency"]),
                "confidence": float(entry["confidence"]),
                "_delta_key": entry["_delta_key"],
            }
        )

    if truncated and remainder > 0.0:
        spectrum.append(
            {
                "sequenceDelta": {"type": "other", "length": 0, "label": "OTHER"},
                "frequency": float(remainder),
                "confidence": 0.0,
                "_delta_key": "OTHER",
            }
        )

    if not spectrum:
        return None

    running = 0.0
    for idx, entry in enumerate(spectrum):
        if idx < len(spectrum) - 1:
            freq = round(float(entry.get("frequency") or 0.0), 8)
            running += freq
        else:
            freq = round(max(0.0, 1.0 - running), 8)
        entry["frequency"] = float(freq)
        entry.pop("_delta_key", None)

    total_freq = sum(float(entry.get("frequency") or 0.0) for entry in spectrum)
    if abs(total_freq - 1.0) > 1e-6 and spectrum:
        last = spectrum[-1]
        corrected = max(0.0, float(last.get("frequency") or 0.0) + (1.0 - total_freq))
        last["frequency"] = round(corrected, 8)

    return spectrum


__all__ = ["build_microhomology_indel_spectrum", "microhomology_len"]

