"""GPU-friendly CTMC approximation for CRISPR cut/repair via fixed-Δt hazard stepping.

This is a CPU reference implementation designed to be "CUDA-shaped":
- Structure-of-arrays state
- One logical thread per (cell, locus, allele)
- Counter-based RNG keyed by (seed, replicate, cell, locus, allele, step, subdraw)

It approximates an underlying continuous-time Markov jump process (CTMC) with a
tau-leap step:

  p(event in Δt) = 1 - exp(-λΔt)

For competing hazards {λ_i}, we use Λ = Σ λ_i, sample if any event happens, and
then choose the event by λ_i / Λ. This preserves pathway competition while
avoiding event-by-event Gillespie divergence.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
import hashlib
import json
import math
import struct
from typing import Any, Mapping, Sequence

import numpy as np

MASK_32 = 0xFFFFFFFF
MASK_64 = 0xFFFFFFFFFFFFFFFF

RNG_ENGINE_ID = "philox4x32_10"

RNG_SCHEDULE_ID = "helix.ctmc_tau_leap.rng_schedule.v1"
RNG_COUNTER_TUPLE = ("replicate", "cell", "locus", "allele", "step", "subdraw")

# subdraw_id allocation: keep stable; bump RNG_SCHEDULE_ID if changed.
RNG_SUBDRAWS: dict[str, int] = {
    "cut.u": 0,
    "dsb.any.u": 1,
    "dsb.pick.u": 2,
    "nhej.mode.u": 10,
    "nhej.len.u": 11,
    "altej.mh.u": 12,
    "altej.del.u": 13,
    "hdr.precise.u": 14,
    "hdr_fallback_nhej.mode.u": 15,
    "hdr_fallback_nhej.len.u": 16,
    "chrom.relax.u": 30,
    "chrom.transient_open.u": 31,
    # Heterogeneity draws use a separate subdraw range to avoid collisions.
    "hetero.repair.z.u1.base": 100,
    "hetero.donor.z.u1": 200,
}

# Cached integer constants to keep the call sites clean.
_SD_CUT_U = RNG_SUBDRAWS["cut.u"]
_SD_DSB_ANY_U = RNG_SUBDRAWS["dsb.any.u"]
_SD_DSB_PICK_U = RNG_SUBDRAWS["dsb.pick.u"]
_SD_NHEJ_MODE_U = RNG_SUBDRAWS["nhej.mode.u"]
_SD_NHEJ_LEN_U = RNG_SUBDRAWS["nhej.len.u"]
_SD_ALTEJ_MH_U = RNG_SUBDRAWS["altej.mh.u"]
_SD_ALTEJ_DEL_U = RNG_SUBDRAWS["altej.del.u"]
_SD_HDR_PRECISE_U = RNG_SUBDRAWS["hdr.precise.u"]
_SD_HDR_FB_NHEJ_MODE_U = RNG_SUBDRAWS["hdr_fallback_nhej.mode.u"]
_SD_HDR_FB_NHEJ_LEN_U = RNG_SUBDRAWS["hdr_fallback_nhej.len.u"]
_SD_CHROM_RELAX_U = RNG_SUBDRAWS["chrom.relax.u"]
_SD_CHROM_TRANSIENT_OPEN_U = RNG_SUBDRAWS["chrom.transient_open.u"]
_SD_HET_REPAIR_BASE = RNG_SUBDRAWS["hetero.repair.z.u1.base"]
_SD_HET_DONOR_U1 = RNG_SUBDRAWS["hetero.donor.z.u1"]


def _canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


RNG_SCHEDULE_SHA256 = hashlib.sha256(_canonical_json_bytes(RNG_SUBDRAWS)).hexdigest()


def _config_sha256(config: Mapping[str, Any]) -> str:
    return hashlib.sha256(_canonical_json_bytes(config)).hexdigest()


def _round6(value: float) -> float:
    if not math.isfinite(value):
        return 0.0
    return float(round(float(value), 6))


class Phase(IntEnum):
    G1 = 0
    S = 1
    G2 = 2
    M = 3


class AlleleState(IntEnum):
    INTACT = 0
    DSB = 1
    REPAIRED_MUT = 2


class ChromState(IntEnum):
    OPEN = 0
    TRANSIENT = 1
    REFRACTORY = 2


class OutcomeClass(IntEnum):
    NO_CUT = 0
    NHEJ = 1
    ALTEJ = 2
    HDR_PRECISE = 3
    SSA = 4
    UNREPAIRED = 5


@dataclass(frozen=True)
class LocusSpec:
    locus_id: str
    grna_eff: float
    baseline_accessibility: float = 1.0
    repeat_context: bool = False
    coding_frame: int | None = None


@dataclass(frozen=True)
class TauLeapSimSpec:
    dt: float
    t_end: float
    n_cells: int
    seed: int
    replicates: int = 1
    backend: str = "auto"
    record_every_steps: int | None = None
    max_lambda_dt: float | None = None
    small_x_lin_thresh: float = 1e-3

    @property
    def steps(self) -> int:
        return max(1, int(math.ceil(self.t_end / self.dt)))


@dataclass(frozen=True)
class HazardParams:
    k_cut: float = 0.0
    k_resect_by_phase: tuple[float, float, float, float] = (0.0, 0.0, 0.0, 0.0)
    k_nhej: float = 0.0
    k_alt_ej: float = 0.0
    k_hdr: float = 0.0
    k_ssa: float = 0.0
    k_relax: float = 0.0
    k_transient_open: float = 0.0


@dataclass(frozen=True)
class ChromMultipliers:
    open: float = 1.0
    transient: float = 1.0
    refractory: float = 1.0

    def as_array(self) -> np.ndarray:
        return np.asarray([self.open, self.transient, self.refractory], dtype=np.float32)


@dataclass(frozen=True)
class Multipliers:
    phase_cut: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0)
    phase_nhej: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0)
    phase_alt_ej: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0)
    phase_hdr: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0)
    phase_ssa: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0)
    chrom_cut: ChromMultipliers = field(
        default_factory=lambda: ChromMultipliers(open=1.0, transient=1.0, refractory=0.1)
    )
    chrom_repair: ChromMultipliers = field(
        default_factory=lambda: ChromMultipliers(open=1.0, transient=1.0, refractory=1.0)
    )
    chrom_resect: ChromMultipliers = field(
        default_factory=lambda: ChromMultipliers(open=1.0, transient=1.0, refractory=1.0)
    )

    def phase_array(self, phase_mult: tuple[float, float, float, float]) -> np.ndarray:
        return np.asarray(list(phase_mult), dtype=np.float32)


@dataclass(frozen=True)
class CellHeterogeneity:
    repair_level_baseline: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 1.0)  # NHEJ,ALTEJ,HDR,SSA
    repair_level_sigma_ln: float = 0.0
    donor_baseline: float = 0.0
    donor_sigma_ln: float = 0.0


@dataclass(frozen=True)
class NhejOutcomeParams:
    p_ins: float = 0.3
    del_geom_p: float = 0.35
    ins_geom_p: float = 0.5
    del_max: int = 20
    ins_max: int = 10


@dataclass(frozen=True)
class AltEjOutcomeParams:
    mh_geom_p: float = 0.4
    mh_max: int = 8
    del_geom_p: float = 0.25
    del_max: int = 60


@dataclass(frozen=True)
class HdrOutcomeParams:
    p_precise: float = 1.0
    allow_recut_after_precise: bool = True


@dataclass(frozen=True)
class SsaOutcomeParams:
    del_size: int = 200


@dataclass(frozen=True)
class OutcomeParams:
    nhej: NhejOutcomeParams = field(default_factory=NhejOutcomeParams)
    alt_ej: AltEjOutcomeParams = field(default_factory=AltEjOutcomeParams)
    hdr: HdrOutcomeParams = field(default_factory=HdrOutcomeParams)
    ssa: SsaOutcomeParams = field(default_factory=SsaOutcomeParams)


@dataclass(frozen=True)
class GeneTrigger:
    locus_id: str
    condition: str  # "biallelic_frameshift" | "biallelic_disruptive"


@dataclass(frozen=True)
class GeneFeedbackRule:
    gene_id: str
    bit: int
    trigger: GeneTrigger
    multipliers: tuple[float | None, float | None, float | None, float | None]  # NHEJ,ALTEJ,HDR,SSA


@dataclass(frozen=True)
class TauLeapConfig:
    sim: TauLeapSimSpec
    loci: tuple[LocusSpec, ...]
    hazards: HazardParams
    multipliers: Multipliers = field(default_factory=Multipliers)
    cell_heterogeneity: CellHeterogeneity = field(default_factory=CellHeterogeneity)
    outcomes: OutcomeParams = field(default_factory=OutcomeParams)
    feedback: tuple[GeneFeedbackRule, ...] = ()

    @property
    def n_loci(self) -> int:
        return len(self.loci)


PHILOX_M0 = 0xD2511F53
PHILOX_M1 = 0xCD9E8D57
PHILOX_W0 = 0x9E3779B9
PHILOX_W1 = 0xBB67AE85


def _mulhilo_u32(a: int, b: int) -> tuple[int, int]:
    prod = (int(a) & MASK_32) * (int(b) & MASK_32)
    lo = prod & MASK_32
    hi = (prod >> 32) & MASK_32
    return hi, lo


def philox4x32_10(counter: tuple[int, int, int, int], key: tuple[int, int]) -> tuple[int, int, int, int]:
    """Philox 4x32-10 (Random123) with 32-bit words.

    Pure Python reference used to keep CPU↔GPU parity debuggable.
    """

    c0, c1, c2, c3 = (int(counter[0]) & MASK_32, int(counter[1]) & MASK_32, int(counter[2]) & MASK_32, int(counter[3]) & MASK_32)
    k0, k1 = (int(key[0]) & MASK_32, int(key[1]) & MASK_32)
    for _ in range(10):
        hi0, lo0 = _mulhilo_u32(PHILOX_M0, c0)
        hi1, lo1 = _mulhilo_u32(PHILOX_M1, c2)
        n0 = (hi1 ^ c1 ^ k0) & MASK_32
        n1 = lo1 & MASK_32
        n2 = (hi0 ^ c3 ^ k1) & MASK_32
        n3 = lo0 & MASK_32
        c0, c1, c2, c3 = n0, n1, n2, n3
        k0 = (k0 + PHILOX_W0) & MASK_32
        k1 = (k1 + PHILOX_W1) & MASK_32
    return c0, c1, c2, c3


def rng_u01(
    *,
    seed: int,
    replicate: int,
    cell: int,
    locus: int,
    allele: int,
    step: int,
    subdraw: int,
) -> float:
    """
    Counter-based RNG (deterministic, order-independent).

    Uses Philox4x32_10; converts to a float in [0, 1) via the top 24 bits of
    output word 0 so CPU and GPU can match bitwise under float32 math.
    """

    seed64 = int(seed) & MASK_64
    key0 = seed64 & MASK_32
    key1 = ((seed64 >> 32) & MASK_32) ^ (int(replicate) & MASK_32)
    counter = (
        int(cell) & MASK_32,
        int(locus) & MASK_32,
        int(step) & MASK_32,
        ((int(subdraw) & MASK_32) << 1) | (int(allele) & 1),
    )
    r0, _, _, _ = philox4x32_10(counter, (key0, key1))
    # Uniform in [0, 1) with 24 bits of resolution (float32-friendly).
    return float(((r0 >> 8) & 0xFFFFFF) * (1.0 / float(1 << 24)))


def _u_to_standard_normal(u1: float, u2: float) -> float:
    u1 = min(max(float(u1), 1e-12), 1.0 - 1e-12)
    u2 = min(max(float(u2), 0.0), 1.0 - 1e-12)
    return math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)


def _p_event(
    lam: float,
    dt: float,
    *,
    small_x_lin_thresh: float,
    max_lambda_dt: float | None,
) -> float:
    x = np.float32(lam) * np.float32(dt)
    if max_lambda_dt is not None:
        x_max = np.float32(max_lambda_dt)
        if x > x_max:
            x = x_max
    if float(x) <= 0.0:
        return 0.0
    if x < np.float32(small_x_lin_thresh):
        return float(x)
    # stable: 1-exp(-x), computed in float32
    return float(-np.expm1(-x))


def _sample_geometric_trunc(u: float, p: float, k_max: int) -> int:
    """Geometric(k>=1) truncated by tail clamping to k_max (CUDA-friendly).

    This implementation avoids transcendental inverse-CDF math so CPU/GPU can
    match more reliably under float32 arithmetic.
    """

    k_max = max(1, int(k_max))
    p_f = np.float32(p)
    if float(p_f) <= 0.0:
        return k_max
    if float(p_f) >= 1.0:
        return 1
    u_f = np.float32(min(max(float(u), 0.0), 1.0 - 1e-7))
    q = np.float32(1.0) - p_f
    prob = p_f
    cdf = prob
    for k in range(1, k_max):
        if u_f < cdf:
            return k
        prob = prob * q
        cdf = cdf + prob
    return k_max


def _as_float(value: Any, default: float) -> float:
    try:
        return float(value)
    except Exception:
        return float(default)


def _as_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except Exception:
        return int(default)


def _as_bool(value: Any, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return bool(default)
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "on"}:
        return True
    if text in {"0", "false", "no", "off"}:
        return False
    return bool(default)


def _as_phase4(value: Any, default: tuple[float, float, float, float]) -> tuple[float, float, float, float]:
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        items = list(value)
        if len(items) >= 4:
            return tuple(float(_as_float(items[i], default[i])) for i in range(4))  # type: ignore[return-value]
    return default


def tau_leap_config_from_dict(payload: Mapping[str, Any]) -> TauLeapConfig:
    schema = str(payload.get("schema") or "")
    if schema and schema != "helix_ctmc_tau_leap_v1":
        raise ValueError(f"Unsupported schema: {schema}")

    sim_raw = payload.get("sim") if isinstance(payload.get("sim"), Mapping) else {}
    dt = _as_float(sim_raw.get("dt"), 0.0)
    t_end = _as_float(sim_raw.get("tEnd"), 0.0)
    n_cells = _as_int(sim_raw.get("nCells"), 0)
    seed = _as_int(sim_raw.get("seed"), 0)
    replicates = max(1, _as_int(sim_raw.get("replicates"), 1))
    backend = str(sim_raw.get("backend") or "auto").strip().lower() or "auto"
    record_every = sim_raw.get("recordEverySteps")
    record_every_steps = None if record_every is None else max(1, _as_int(record_every, 1))
    max_lambda_dt = sim_raw.get("maxLambdaDt")
    max_lambda_dt_f = None if max_lambda_dt is None else float(_as_float(max_lambda_dt, 0.0))
    small_x_lin_thresh = _as_float(sim_raw.get("smallXLinThresh"), 1e-3)
    if dt <= 0.0:
        raise ValueError("sim.dt must be > 0")
    if t_end <= 0.0:
        raise ValueError("sim.tEnd must be > 0")
    if n_cells <= 0:
        raise ValueError("sim.nCells must be >= 1")

    sim = TauLeapSimSpec(
        dt=float(dt),
        t_end=float(t_end),
        n_cells=int(n_cells),
        seed=int(seed),
        replicates=int(replicates),
        backend=backend,
        record_every_steps=record_every_steps,
        max_lambda_dt=max_lambda_dt_f,
        small_x_lin_thresh=float(small_x_lin_thresh),
    )

    loci_raw = payload.get("loci")
    if not isinstance(loci_raw, Sequence) or isinstance(loci_raw, (str, bytes, bytearray)):
        raise ValueError("loci must be a non-empty array")
    loci: list[LocusSpec] = []
    for entry in loci_raw:
        if not isinstance(entry, Mapping):
            continue
        locus_id = str(entry.get("locusId") or "").strip()
        if not locus_id:
            continue
        loci.append(
            LocusSpec(
                locus_id=locus_id,
                grna_eff=float(_as_float(entry.get("gRnaEff"), 0.0)),
                baseline_accessibility=float(_as_float(entry.get("baselineAccessibility"), 1.0)),
                repeat_context=_as_bool(entry.get("repeatContext"), False),
                coding_frame=None if entry.get("codingFrame") is None else _as_int(entry.get("codingFrame"), 0),
            )
        )
    if not loci:
        raise ValueError("loci must contain at least one locus with locusId")

    params_raw = payload.get("params") if isinstance(payload.get("params"), Mapping) else {}
    hazards_raw = params_raw.get("hazards") if isinstance(params_raw.get("hazards"), Mapping) else {}
    k_resect_by_phase = hazards_raw.get("kResectByPhase")
    if isinstance(k_resect_by_phase, Sequence) and not isinstance(k_resect_by_phase, (str, bytes, bytearray)):
        k_resect = tuple(float(_as_float(k_resect_by_phase[i], 0.0)) for i in range(min(4, len(k_resect_by_phase))))
        if len(k_resect) < 4:
            k_resect = tuple(list(k_resect) + [0.0] * (4 - len(k_resect)))  # type: ignore[assignment]
    else:
        k_resect = (0.0, 0.0, 0.0, 0.0)

    hazards = HazardParams(
        k_cut=float(_as_float(hazards_raw.get("kCut"), 0.0)),
        k_resect_by_phase=(float(k_resect[0]), float(k_resect[1]), float(k_resect[2]), float(k_resect[3])),
        k_nhej=float(_as_float(hazards_raw.get("kNhej"), 0.0)),
        k_alt_ej=float(_as_float(hazards_raw.get("kAltEj"), 0.0)),
        k_hdr=float(_as_float(hazards_raw.get("kHdr"), 0.0)),
        k_ssa=float(_as_float(hazards_raw.get("kSsa"), 0.0)),
        k_relax=float(_as_float(hazards_raw.get("kRelax"), 0.0)),
        k_transient_open=float(_as_float(hazards_raw.get("kTransientOpen"), 0.0)),
    )

    multipliers_raw = params_raw.get("multipliers") if isinstance(params_raw.get("multipliers"), Mapping) else {}
    chrom_cut_raw = multipliers_raw.get("chromCut") if isinstance(multipliers_raw.get("chromCut"), Mapping) else {}
    chrom_repair_raw = multipliers_raw.get("chromRepair") if isinstance(multipliers_raw.get("chromRepair"), Mapping) else {}
    chrom_resect_raw = multipliers_raw.get("chromResect") if isinstance(multipliers_raw.get("chromResect"), Mapping) else {}
    multipliers_defaults = Multipliers()
    multipliers = Multipliers(
        phase_cut=_as_phase4(multipliers_raw.get("phaseCut"), multipliers_defaults.phase_cut),
        phase_nhej=_as_phase4(multipliers_raw.get("phaseNhej"), multipliers_defaults.phase_nhej),
        phase_alt_ej=_as_phase4(multipliers_raw.get("phaseAltEj"), multipliers_defaults.phase_alt_ej),
        phase_hdr=_as_phase4(multipliers_raw.get("phaseHdr"), multipliers_defaults.phase_hdr),
        phase_ssa=_as_phase4(multipliers_raw.get("phaseSsa"), multipliers_defaults.phase_ssa),
        chrom_cut=ChromMultipliers(
            open=float(_as_float(chrom_cut_raw.get("OPEN"), multipliers_defaults.chrom_cut.open)),
            transient=float(_as_float(chrom_cut_raw.get("TRANSIENT"), multipliers_defaults.chrom_cut.transient)),
            refractory=float(_as_float(chrom_cut_raw.get("REFRACTORY"), multipliers_defaults.chrom_cut.refractory)),
        ),
        chrom_repair=ChromMultipliers(
            open=float(_as_float(chrom_repair_raw.get("OPEN"), multipliers_defaults.chrom_repair.open)),
            transient=float(_as_float(chrom_repair_raw.get("TRANSIENT"), multipliers_defaults.chrom_repair.transient)),
            refractory=float(_as_float(chrom_repair_raw.get("REFRACTORY"), multipliers_defaults.chrom_repair.refractory)),
        ),
        chrom_resect=ChromMultipliers(
            open=float(_as_float(chrom_resect_raw.get("OPEN"), multipliers_defaults.chrom_resect.open)),
            transient=float(_as_float(chrom_resect_raw.get("TRANSIENT"), multipliers_defaults.chrom_resect.transient)),
            refractory=float(_as_float(chrom_resect_raw.get("REFRACTORY"), multipliers_defaults.chrom_resect.refractory)),
        ),
    )

    hetero_raw = params_raw.get("cellHeterogeneity") if isinstance(params_raw.get("cellHeterogeneity"), Mapping) else {}
    repair_base_raw = hetero_raw.get("repairLevelBaseline") if isinstance(hetero_raw.get("repairLevelBaseline"), Mapping) else {}
    cell_heterogeneity = CellHeterogeneity(
        repair_level_baseline=(
            float(_as_float(repair_base_raw.get("NHEJ"), 1.0)),
            float(_as_float(repair_base_raw.get("ALTEJ"), 1.0)),
            float(_as_float(repair_base_raw.get("HDR"), 1.0)),
            float(_as_float(repair_base_raw.get("SSA"), 1.0)),
        ),
        repair_level_sigma_ln=float(_as_float(hetero_raw.get("repairLevelSigmaLn"), 0.0)),
        donor_baseline=float(_as_float(hetero_raw.get("donorBaseline"), 0.0)),
        donor_sigma_ln=float(_as_float(hetero_raw.get("donorSigmaLn"), 0.0)),
    )

    outcomes_raw = params_raw.get("outcomes") if isinstance(params_raw.get("outcomes"), Mapping) else {}
    nhej_raw = outcomes_raw.get("nhej") if isinstance(outcomes_raw.get("nhej"), Mapping) else {}
    alt_raw = outcomes_raw.get("altEj") if isinstance(outcomes_raw.get("altEj"), Mapping) else {}
    hdr_raw = outcomes_raw.get("hdr") if isinstance(outcomes_raw.get("hdr"), Mapping) else {}
    ssa_raw = outcomes_raw.get("ssa") if isinstance(outcomes_raw.get("ssa"), Mapping) else {}
    outcomes = OutcomeParams(
        nhej=NhejOutcomeParams(
            p_ins=float(_as_float(nhej_raw.get("pIns"), NhejOutcomeParams.p_ins)),
            del_geom_p=float(_as_float(nhej_raw.get("delGeomP"), NhejOutcomeParams.del_geom_p)),
            ins_geom_p=float(_as_float(nhej_raw.get("insGeomP"), NhejOutcomeParams.ins_geom_p)),
            del_max=int(_as_int(nhej_raw.get("delMax"), NhejOutcomeParams.del_max)),
            ins_max=int(_as_int(nhej_raw.get("insMax"), NhejOutcomeParams.ins_max)),
        ),
        alt_ej=AltEjOutcomeParams(
            mh_geom_p=float(_as_float(alt_raw.get("mhGeomP"), AltEjOutcomeParams.mh_geom_p)),
            mh_max=int(_as_int(alt_raw.get("mhMax"), AltEjOutcomeParams.mh_max)),
            del_geom_p=float(_as_float(alt_raw.get("delGeomP"), AltEjOutcomeParams.del_geom_p)),
            del_max=int(_as_int(alt_raw.get("delMax"), AltEjOutcomeParams.del_max)),
        ),
        hdr=HdrOutcomeParams(
            p_precise=float(_as_float(hdr_raw.get("pPrecise"), HdrOutcomeParams.p_precise)),
            allow_recut_after_precise=_as_bool(
                hdr_raw.get("allowRecutAfterPrecise"),
                HdrOutcomeParams.allow_recut_after_precise,
            ),
        ),
        ssa=SsaOutcomeParams(
            del_size=int(_as_int(ssa_raw.get("delSize"), SsaOutcomeParams.del_size)),
        ),
    )

    feedback_rules: list[GeneFeedbackRule] = []
    feedback_raw = payload.get("feedback") if isinstance(payload.get("feedback"), Mapping) else {}
    genes_raw = feedback_raw.get("genes")
    if isinstance(genes_raw, Sequence) and not isinstance(genes_raw, (str, bytes, bytearray)):
        for entry in genes_raw:
            if not isinstance(entry, Mapping):
                continue
            trigger_raw = entry.get("trigger") if isinstance(entry.get("trigger"), Mapping) else {}
            mult_raw = entry.get("multipliers") if isinstance(entry.get("multipliers"), Mapping) else {}
            feedback_rules.append(
                GeneFeedbackRule(
                    gene_id=str(entry.get("geneId") or "").strip() or "gene",
                    bit=int(_as_int(entry.get("bit"), 0)),
                    trigger=GeneTrigger(
                        locus_id=str(trigger_raw.get("locusId") or "").strip(),
                        condition=str(trigger_raw.get("condition") or "").strip(),
                    ),
                    multipliers=(
                        None if "NHEJ" not in mult_raw else float(_as_float(mult_raw.get("NHEJ"), 1.0)),
                        None if "ALTEJ" not in mult_raw else float(_as_float(mult_raw.get("ALTEJ"), 1.0)),
                        None if "HDR" not in mult_raw else float(_as_float(mult_raw.get("HDR"), 1.0)),
                        None if "SSA" not in mult_raw else float(_as_float(mult_raw.get("SSA"), 1.0)),
                    ),
                )
            )

    return TauLeapConfig(
        sim=sim,
        loci=tuple(loci),
        hazards=hazards,
        multipliers=multipliers,
        cell_heterogeneity=cell_heterogeneity,
        outcomes=outcomes,
        feedback=tuple(feedback_rules),
    )


def _init_cell_heterogeneity(cfg: TauLeapConfig, *, replicate: int) -> tuple[np.ndarray, np.ndarray]:
    n = cfg.sim.n_cells
    base = np.asarray(cfg.cell_heterogeneity.repair_level_baseline, dtype=np.float32)
    repair = np.tile(base[None, :], (n, 1)).astype(np.float32, copy=False)
    donor = np.full(n, float(cfg.cell_heterogeneity.donor_baseline), dtype=np.float32)
    sigma_r = float(cfg.cell_heterogeneity.repair_level_sigma_ln)
    sigma_d = float(cfg.cell_heterogeneity.donor_sigma_ln)
    if sigma_r > 0.0:
        for cell in range(n):
            for j in range(4):
                u1 = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=0, allele=0, step=0, subdraw=_SD_HET_REPAIR_BASE + j * 2)
                u2 = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=0, allele=0, step=0, subdraw=_SD_HET_REPAIR_BASE + j * 2 + 1)
                z = _u_to_standard_normal(u1, u2)
                repair[cell, j] *= float(math.exp(sigma_r * z))
    if sigma_d > 0.0:
        for cell in range(n):
            u1 = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=0, allele=0, step=0, subdraw=_SD_HET_DONOR_U1)
            u2 = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=0, allele=0, step=0, subdraw=_SD_HET_DONOR_U1 + 1)
            z = _u_to_standard_normal(u1, u2)
            donor[cell] *= float(math.exp(sigma_d * z))
    donor = np.clip(donor, 0.0, 1.0).astype(np.float32, copy=False)
    return repair, donor


def _apply_gene_feedback(
    cfg: TauLeapConfig,
    *,
    locus_index_by_id: Mapping[str, int],
    frameshift: np.ndarray,
    ko_mask: np.ndarray,
    repair_levels: np.ndarray,
) -> None:
    if not cfg.feedback:
        return
    n_cells = cfg.sim.n_cells
    n_loci = cfg.n_loci
    for rule in cfg.feedback:
        if rule.bit < 0 or rule.bit >= 64:
            raise ValueError(f"feedback bit out of supported range [0,63]: {rule.bit}")
        locus = locus_index_by_id.get(rule.trigger.locus_id)
        if locus is None:
            continue
        if rule.trigger.condition not in {"biallelic_frameshift", "biallelic_disruptive"}:
            continue
        bit_mask = np.uint64(1) << np.uint64(rule.bit)
        for cell in range(n_cells):
            if int(ko_mask[cell] & bit_mask) != 0:
                continue
            idx0 = (cell * n_loci + locus) * 2 + 0
            idx1 = idx0 + 1
            if rule.trigger.condition == "biallelic_frameshift":
                trig = bool(frameshift[idx0]) and bool(frameshift[idx1])
            else:
                trig = bool(frameshift[idx0]) and bool(frameshift[idx1])
            if not trig:
                continue
            ko_mask[cell] |= bit_mask
            for j, mult in enumerate(rule.multipliers):
                if mult is None:
                    continue
                repair_levels[cell, j] *= float(mult)


def _sample_nhej(
    *,
    cfg: TauLeapConfig,
    locus: int,
    u_mode: float,
    u_len: float,
) -> tuple[int, bool]:
    params = cfg.outcomes.nhej
    if float(u_mode) < float(params.p_ins):
        ins_len = _sample_geometric_trunc(u_len, params.ins_geom_p, params.ins_max)
        delta = int(ins_len)
    else:
        del_len = _sample_geometric_trunc(u_len, params.del_geom_p, params.del_max)
        delta = -int(del_len)
    coding = cfg.loci[locus].coding_frame is not None
    frameshift = bool(coding and (delta % 3 != 0))
    return delta, frameshift


def _sample_alt_ej(
    *,
    cfg: TauLeapConfig,
    locus: int,
    u_mh: float,
    u_del: float,
) -> tuple[int, bool]:
    params = cfg.outcomes.alt_ej
    mh_len = _sample_geometric_trunc(u_mh, params.mh_geom_p, params.mh_max)
    extra = _sample_geometric_trunc(u_del, params.del_geom_p, params.del_max)
    delta = -int(mh_len + extra)
    coding = cfg.loci[locus].coding_frame is not None
    frameshift = bool(coding and (delta % 3 != 0))
    return delta, frameshift


def _sample_ssa(*, cfg: TauLeapConfig, locus: int) -> tuple[int, bool]:
    # In v1 SSA is a fixed-size deletion; locus-specific repeats can override later.
    delta = -int(cfg.outcomes.ssa.del_size)
    coding = cfg.loci[locus].coding_frame is not None
    frameshift = bool(coding and (delta % 3 != 0))
    return delta, frameshift


@dataclass(frozen=True)
class TauLeapReplicateSummary:
    replicate: int
    steps: int
    dt: float
    t_end: float
    n_cells: int
    n_loci: int
    allele_spectrum: list[dict[str, Any]]
    summary: dict[str, Any]
    trace: dict[str, Any]


def _iter_indices(n: int, *, order: str) -> range:
    n = int(n)
    order = str(order or "").strip().lower() or "linear"
    if order == "linear":
        return range(n)
    if order == "reverse":
        return range(n - 1, -1, -1)
    raise ValueError(f"Unknown execution order: {order}")


def _shannon_bits(probs: Sequence[float]) -> float:
    h = 0.0
    for p in probs:
        p = float(p)
        if p <= 0.0:
            continue
        h -= p * math.log(p, 2)
    return float(h)


def _build_allele_spectrum(
    *,
    outcome_class: np.ndarray,
    delta_bp: np.ndarray,
    frameshift: np.ndarray,
) -> list[dict[str, Any]]:
    n = int(outcome_class.size)
    counts: dict[tuple[int, int, int], int] = {}
    for i in range(n):
        key = (int(outcome_class[i]), int(delta_bp[i]), int(frameshift[i]))
        counts[key] = counts.get(key, 0) + 1
    out: list[dict[str, Any]] = []
    for (cls, delta, fs), count in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])):
        category = "other"
        label = "other"
        if cls == OutcomeClass.NO_CUT:
            category = "no_cut"
            label = "no_cut"
        elif cls == OutcomeClass.HDR_PRECISE:
            category = "intended_edit"
            label = "intended_edit"
        elif cls == OutcomeClass.NHEJ or cls == OutcomeClass.ALTEJ or cls == OutcomeClass.SSA:
            if delta < 0:
                category = "small_deletion" if abs(delta) <= 10 else "large_deletion"
                label = category
            elif delta > 0:
                category = "small_insertion" if delta <= 10 else "large_insertion"
                label = category
        elif cls == OutcomeClass.UNREPAIRED:
            category = "dsb_unrepaired"
            label = "dsb_unrepaired"
        out.append(
            {
                "label": label,
                "category": category,
                "probability": float(count) / float(n) if n else 0.0,
                "count": int(count),
                "delta_bp": int(delta),
                "frameshift": bool(fs),
            }
        )
    return out


def _run_tau_leap_replicate(
    cfg: TauLeapConfig,
    *,
    replicate: int,
    execution_order: str = "linear",
) -> TauLeapReplicateSummary:
    n_cells = cfg.sim.n_cells
    n_loci = cfg.n_loci
    steps = cfg.sim.steps
    dt = float(cfg.sim.dt)
    dt_f = np.float32(dt)
    record_every = cfg.sim.record_every_steps
    idx_iter = _iter_indices(n_cells * n_loci * 2, order=execution_order)

    # Per-cell state (minimal v1: fixed G1 unless caller adds phase plumbing later).
    phase = np.full(n_cells, int(Phase.G1), dtype=np.uint8)
    repair_levels, donor = _init_cell_heterogeneity(cfg, replicate=replicate)
    ko_mask = np.zeros(n_cells, dtype=np.uint64)

    # Per-allele state (flattened (cell,locus,allele)).
    n_alleles = n_cells * n_loci * 2
    allele_state = np.full(n_alleles, int(AlleleState.INTACT), dtype=np.uint8)
    chrom_state = np.full(n_alleles, int(ChromState.OPEN), dtype=np.uint8)
    resection = np.zeros(n_alleles, dtype=np.uint8)
    dsb_age = np.zeros(n_alleles, dtype=np.float32)

    outcome_class = np.full(n_alleles, int(OutcomeClass.NO_CUT), dtype=np.uint8)
    delta_bp = np.zeros(n_alleles, dtype=np.int16)
    frameshift = np.zeros(n_alleles, dtype=np.uint8)

    locus_index_by_id = {l.locus_id: i for i, l in enumerate(cfg.loci)}
    phase_cut = np.asarray(cfg.multipliers.phase_cut, dtype=np.float32)
    phase_nhej = np.asarray(cfg.multipliers.phase_nhej, dtype=np.float32)
    phase_alt = np.asarray(cfg.multipliers.phase_alt_ej, dtype=np.float32)
    phase_hdr = np.asarray(cfg.multipliers.phase_hdr, dtype=np.float32)
    phase_ssa = np.asarray(cfg.multipliers.phase_ssa, dtype=np.float32)

    chrom_cut = cfg.multipliers.chrom_cut.as_array()
    chrom_repair = cfg.multipliers.chrom_repair.as_array()
    chrom_resect = cfg.multipliers.chrom_resect.as_array()

    k_cut = np.float32(cfg.hazards.k_cut)
    k_resect_by_phase = np.asarray(cfg.hazards.k_resect_by_phase, dtype=np.float32)
    k_nhej = np.float32(cfg.hazards.k_nhej)
    k_alt = np.float32(cfg.hazards.k_alt_ej)
    k_hdr = np.float32(cfg.hazards.k_hdr)
    k_ssa = np.float32(cfg.hazards.k_ssa)
    k_relax = np.float32(cfg.hazards.k_relax)
    k_transient_open = np.float32(cfg.hazards.k_transient_open)

    grna_eff = np.asarray([l.grna_eff for l in cfg.loci], dtype=np.float32)
    access = np.asarray([l.baseline_accessibility for l in cfg.loci], dtype=np.float32)
    repeat_ctx = np.asarray([bool(l.repeat_context) for l in cfg.loci], dtype=np.bool_)
    coding = np.asarray([l.coding_frame is not None for l in cfg.loci], dtype=np.bool_)

    trace_hasher = hashlib.sha256()
    step_events: list[dict[str, int]] | None = [] if record_every is not None else None
    step_state_hashes: list[dict[str, Any]] | None = [] if record_every is not None else None
    totals = {
        "cuts": 0,
        "resections": 0,
        "nhej": 0,
        "altej": 0,
        "hdr_precise": 0,
        "ssa": 0,
        "chrom_relax": 0,
        "chrom_transient_open": 0,
    }

    for step in range(steps):
        cuts_step = 0
        resect_step = 0
        nhej_step = 0
        altej_step = 0
        hdr_step = 0
        ssa_step = 0
        relax_step = 0
        transient_open_step = 0

        # Kernel 2: cut intact alleles -> DSB
        for idx in idx_iter:
            if int(allele_state[idx]) != int(AlleleState.INTACT):
                continue
            cell = idx // (n_loci * 2)
            locus = (idx // 2) % n_loci
            allele = idx % 2
            ph = int(phase[cell])
            chrom = int(chrom_state[idx])
            lam_cut = k_cut * grna_eff[locus] * access[locus] * phase_cut[ph] * chrom_cut[chrom]
            p_cut = _p_event(
                lam_cut,
                dt_f,
                small_x_lin_thresh=cfg.sim.small_x_lin_thresh,
                max_lambda_dt=cfg.sim.max_lambda_dt,
            )
            u = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_CUT_U)
            if u >= p_cut:
                continue
            allele_state[idx] = int(AlleleState.DSB)
            resection[idx] = 0
            dsb_age[idx] = 0.0
            chrom_state[idx] = int(ChromState.TRANSIENT)
            cuts_step += 1

        # Kernel 3: DSB progress (resection + competing repair)
        for idx in idx_iter:
            if int(allele_state[idx]) != int(AlleleState.DSB):
                continue
            cell = idx // (n_loci * 2)
            locus = (idx // 2) % n_loci
            allele = idx % 2
            ph = int(phase[cell])
            chrom = int(chrom_state[idx])
            rs = int(resection[idx])

            lam_resect = np.float32(0.0)
            if rs < 2:
                lam_resect = k_resect_by_phase[ph] * chrom_resect[chrom]

            lam_nhej = np.float32(0.0)
            lam_alt = np.float32(0.0)
            lam_hdr = np.float32(0.0)
            lam_ssa = np.float32(0.0)
            if rs == 0:
                lam_nhej = k_nhej * phase_nhej[ph] * chrom_repair[chrom] * repair_levels[cell, 0]
            if rs >= 1:
                lam_alt = k_alt * phase_alt[ph] * chrom_repair[chrom] * repair_levels[cell, 1]
            if rs == 2:
                lam_hdr = k_hdr * phase_hdr[ph] * chrom_repair[chrom] * repair_levels[cell, 2] * donor[cell]
                if bool(repeat_ctx[locus]):
                    lam_ssa = k_ssa * phase_ssa[ph] * chrom_repair[chrom] * repair_levels[cell, 3]

            lam_total = lam_resect + lam_nhej + lam_alt + lam_hdr + lam_ssa
            p_any = _p_event(
                lam_total,
                dt_f,
                small_x_lin_thresh=cfg.sim.small_x_lin_thresh,
                max_lambda_dt=cfg.sim.max_lambda_dt,
            )
            u_any = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_DSB_ANY_U)
            if u_any >= p_any:
                dsb_age[idx] += float(dt_f)
                continue

            v = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_DSB_PICK_U) * lam_total
            # Order matters for GPU determinism; keep consistent.
            if v < lam_resect:
                resection[idx] = min(2, rs + 1)
                dsb_age[idx] = 0.0
                resect_step += 1
                continue
            v -= lam_resect

            picked: OutcomeClass | None = None
            delta = 0
            fs = False

            if v < lam_nhej:
                picked = OutcomeClass.NHEJ
                u_mode = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_NHEJ_MODE_U)
                u_len = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_NHEJ_LEN_U)
                delta, fs = _sample_nhej(cfg=cfg, locus=locus, u_mode=u_mode, u_len=u_len)
                nhej_step += 1
            else:
                v -= lam_nhej
                if v < lam_alt:
                    picked = OutcomeClass.ALTEJ
                    u_mh = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_ALTEJ_MH_U)
                    u_del = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_ALTEJ_DEL_U)
                    delta, fs = _sample_alt_ej(cfg=cfg, locus=locus, u_mh=u_mh, u_del=u_del)
                    altej_step += 1
                else:
                    v -= lam_alt
                    if v < lam_hdr:
                        # HDR "wins" the hazard race; outcome may still be imprecise.
                        u_precise = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_HDR_PRECISE_U)
                        if u_precise < float(cfg.outcomes.hdr.p_precise):
                            picked = OutcomeClass.HDR_PRECISE
                            delta, fs = 0, False
                            hdr_step += 1
                        else:
                            picked = OutcomeClass.NHEJ
                            u_mode = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_HDR_FB_NHEJ_MODE_U)
                            u_len = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_HDR_FB_NHEJ_LEN_U)
                            delta, fs = _sample_nhej(cfg=cfg, locus=locus, u_mode=u_mode, u_len=u_len)
                            nhej_step += 1
                    else:
                        picked = OutcomeClass.SSA
                        delta, fs = _sample_ssa(cfg=cfg, locus=locus)
                        ssa_step += 1

            outcome_class[idx] = int(picked or OutcomeClass.UNREPAIRED)
            delta_bp[idx] = int(delta)
            frameshift[idx] = int(bool(fs and bool(coding[locus])))

            # Resolve post-repair state / re-cut.
            if picked == OutcomeClass.HDR_PRECISE and cfg.outcomes.hdr.allow_recut_after_precise:
                allele_state[idx] = int(AlleleState.INTACT)
            else:
                allele_state[idx] = int(AlleleState.REPAIRED_MUT) if picked != OutcomeClass.UNREPAIRED else int(AlleleState.DSB)

            resection[idx] = 0
            dsb_age[idx] = 0.0
            # Chromatin memory: repaired alleles enter refractory state.
            chrom_state[idx] = int(ChromState.REFRACTORY)

        # Kernel 4: chromatin relaxation
        if float(k_relax) > 0.0 or float(k_transient_open) > 0.0:
            for idx in idx_iter:
                cell = idx // (n_loci * 2)
                locus = (idx // 2) % n_loci
                allele = idx % 2
                chrom = int(chrom_state[idx])
                if chrom == int(ChromState.REFRACTORY) and float(k_relax) > 0.0:
                    p_relax = _p_event(
                        k_relax,
                        dt_f,
                        small_x_lin_thresh=cfg.sim.small_x_lin_thresh,
                        max_lambda_dt=cfg.sim.max_lambda_dt,
                    )
                    u = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_CHROM_RELAX_U)
                    if u < p_relax:
                        chrom_state[idx] = int(ChromState.OPEN)
                        relax_step += 1
                elif chrom == int(ChromState.TRANSIENT) and float(k_transient_open) > 0.0:
                    p_open = _p_event(
                        k_transient_open,
                        dt_f,
                        small_x_lin_thresh=cfg.sim.small_x_lin_thresh,
                        max_lambda_dt=cfg.sim.max_lambda_dt,
                    )
                    u = rng_u01(seed=cfg.sim.seed, replicate=replicate, cell=cell, locus=locus, allele=allele, step=step, subdraw=_SD_CHROM_TRANSIENT_OPEN_U)
                    if u < p_open:
                        chrom_state[idx] = int(ChromState.OPEN)
                        transient_open_step += 1

        # Kernel 5: phenotype feedback (minimal biallelic KO -> repair multipliers)
        _apply_gene_feedback(
            cfg,
            locus_index_by_id=locus_index_by_id,
            frameshift=frameshift,
            ko_mask=ko_mask,
            repair_levels=repair_levels,
        )

        totals["cuts"] += int(cuts_step)
        totals["resections"] += int(resect_step)
        totals["nhej"] += int(nhej_step)
        totals["altej"] += int(altej_step)
        totals["hdr_precise"] += int(hdr_step)
        totals["ssa"] += int(ssa_step)
        totals["chrom_relax"] += int(relax_step)
        totals["chrom_transient_open"] += int(transient_open_step)

        trace_hasher.update(
            struct.pack(
                "<9i",
                int(step),
                int(cuts_step),
                int(resect_step),
                int(nhej_step),
                int(altej_step),
                int(hdr_step),
                int(ssa_step),
                int(relax_step),
                int(transient_open_step),
            )
        )
        if record_every is not None and step_events is not None and step % int(record_every) == 0:
            step_events.append(
                {
                    "step": int(step),
                    "cuts": int(cuts_step),
                    "resections": int(resect_step),
                    "nhej": int(nhej_step),
                    "altej": int(altej_step),
                    "hdr_precise": int(hdr_step),
                    "ssa": int(ssa_step),
                    "chrom_relax": int(relax_step),
                    "chrom_transient_open": int(transient_open_step),
                }
            )
            if step_state_hashes is not None:
                state_hasher = hashlib.sha256()
                # Only discrete state arrays (bitwise parity target). Do not include float buffers here.
                state_hasher.update(allele_state.tobytes())
                state_hasher.update(chrom_state.tobytes())
                state_hasher.update(resection.tobytes())
                state_hasher.update(outcome_class.tobytes())
                state_hasher.update(delta_bp.tobytes())
                state_hasher.update(frameshift.tobytes())
                step_state_hashes.append({"step": int(step), "hash_sha256": state_hasher.hexdigest()})

    # Any remaining DSB at end -> UNREPAIRED outcome for reporting.
    for idx in idx_iter:
        if int(allele_state[idx]) == int(AlleleState.DSB):
            outcome_class[idx] = int(OutcomeClass.UNREPAIRED)

    allele_spectrum = _build_allele_spectrum(outcome_class=outcome_class, delta_bp=delta_bp, frameshift=frameshift)

    # Summary stats (allele-level unless otherwise stated).
    cls = outcome_class.astype(np.int64, copy=False)
    n_no_cut = int(np.sum(cls == int(OutcomeClass.NO_CUT)))
    n_nhej = int(np.sum(cls == int(OutcomeClass.NHEJ)))
    n_altej = int(np.sum(cls == int(OutcomeClass.ALTEJ)))
    n_hdr = int(np.sum(cls == int(OutcomeClass.HDR_PRECISE)))
    n_ssa = int(np.sum(cls == int(OutcomeClass.SSA)))
    n_unrepaired = int(np.sum(cls == int(OutcomeClass.UNREPAIRED)))
    n_cut = int(n_alleles - n_no_cut)
    n_repaired = int(n_nhej + n_altej + n_hdr + n_ssa)

    def frac(num: int, den: int) -> float:
        return float(num) / float(den) if den > 0 else 0.0

    chrom = chrom_state.astype(np.int64, copy=False)
    chrom_open = int(np.sum(chrom == int(ChromState.OPEN)))
    chrom_transient = int(np.sum(chrom == int(ChromState.TRANSIENT)))
    chrom_refractory = int(np.sum(chrom == int(ChromState.REFRACTORY)))

    dsb_mask = allele_state == int(AlleleState.DSB)
    dsb_count = int(np.sum(dsb_mask))
    dsb_age_mean = float(np.mean(dsb_age[dsb_mask])) if dsb_count > 0 else 0.0

    frameshift_mass = float(np.mean(frameshift.astype(bool))) if n_alleles else 0.0
    mosaicism_bits = _shannon_bits([float(e.get("probability") or 0.0) for e in allele_spectrum])

    summary = {
        "no_cut_prob": _round6(frac(n_no_cut, n_alleles)),
        "edit_prob": _round6(frac(n_cut, n_alleles)),
        "intended_prob": _round6(frac(n_hdr, n_alleles)),
        "frameshift_prob": _round6(frameshift_mass),
        "dsb_unrepaired_prob": _round6(frac(n_unrepaired, n_alleles)),
        "ko_cells_prob": _round6(float(np.mean(ko_mask != 0)) if n_cells else 0.0),
        "pathway_frac_given_cut": {
            "NHEJ": _round6(frac(n_nhej, n_cut)),
            "ALTEJ": _round6(frac(n_altej, n_cut)),
            "HDR_PRECISE": _round6(frac(n_hdr, n_cut)),
            "SSA": _round6(frac(n_ssa, n_cut)),
            "UNREPAIRED": _round6(frac(n_unrepaired, n_cut)),
        },
        "pathway_frac_given_repair": {
            "NHEJ": _round6(frac(n_nhej, n_repaired)),
            "ALTEJ": _round6(frac(n_altej, n_repaired)),
            "HDR_PRECISE": _round6(frac(n_hdr, n_repaired)),
            "SSA": _round6(frac(n_ssa, n_repaired)),
        },
        "mosaicism_shannon_bits": _round6(mosaicism_bits),
        "chromatin_state_frac": {
            "OPEN": _round6(frac(chrom_open, n_alleles)),
            "TRANSIENT": _round6(frac(chrom_transient, n_alleles)),
            "REFRACTORY": _round6(frac(chrom_refractory, n_alleles)),
        },
        "dsb_state_frac": _round6(frac(dsb_count, n_alleles)),
        "dsb_age_mean": _round6(dsb_age_mean),
        "event_totals": dict(totals),
    }

    trace = {
        "schedule_id": RNG_SCHEDULE_ID,
        "schedule_sha256": RNG_SCHEDULE_SHA256,
        "engine_id": RNG_ENGINE_ID,
        "counter_tuple": list(RNG_COUNTER_TUPLE),
        "hash_sha256": trace_hasher.hexdigest(),
    }
    if record_every is not None and step_events is not None:
        trace["record_every_steps"] = int(record_every)
        trace["events_by_step"] = step_events
    if record_every is not None and step_state_hashes is not None:
        trace["state_hash_by_step"] = step_state_hashes

    return TauLeapReplicateSummary(
        replicate=int(replicate),
        steps=int(steps),
        dt=float(cfg.sim.dt),
        t_end=float(cfg.sim.t_end),
        n_cells=int(n_cells),
        n_loci=int(n_loci),
        allele_spectrum=allele_spectrum,
        summary=summary,
        trace=trace,
    )


def _run_tau_leap_replicate_cuda(cfg: TauLeapConfig, *, replicate: int, config_sha256: str) -> TauLeapReplicateSummary:
    from helix_engine import native as helix_native

    if not helix_native.cuda_available():
        raise RuntimeError("CUDA backend requested but no CUDA device is available (or helix_engine lacks CUDA support).")

    n_cells = int(cfg.sim.n_cells)
    n_loci = int(cfg.n_loci)
    steps = int(cfg.sim.steps)
    dt = float(cfg.sim.dt)
    record_every = cfg.sim.record_every_steps

    phase_cut = np.asarray(cfg.multipliers.phase_cut, dtype=np.float32)
    phase_nhej = np.asarray(cfg.multipliers.phase_nhej, dtype=np.float32)
    phase_alt = np.asarray(cfg.multipliers.phase_alt_ej, dtype=np.float32)
    phase_hdr = np.asarray(cfg.multipliers.phase_hdr, dtype=np.float32)
    phase_ssa = np.asarray(cfg.multipliers.phase_ssa, dtype=np.float32)
    chrom_cut = cfg.multipliers.chrom_cut.as_array().astype(np.float32, copy=False)
    chrom_repair = cfg.multipliers.chrom_repair.as_array().astype(np.float32, copy=False)
    chrom_resect = cfg.multipliers.chrom_resect.as_array().astype(np.float32, copy=False)

    grna_eff = np.asarray([l.grna_eff for l in cfg.loci], dtype=np.float32)
    access = np.asarray([l.baseline_accessibility for l in cfg.loci], dtype=np.float32)
    repeat_ctx = np.asarray([1 if bool(l.repeat_context) else 0 for l in cfg.loci], dtype=np.uint8)
    coding = np.asarray([1 if l.coding_frame is not None else 0 for l in cfg.loci], dtype=np.uint8)

    feedback_rules = list(cfg.feedback)
    locus_index_by_id = {l.locus_id: i for i, l in enumerate(cfg.loci)}
    fb_locus = np.asarray(
        [int(locus_index_by_id.get(rule.trigger.locus_id, -1)) for rule in feedback_rules],
        dtype=np.int32,
    )
    fb_bit = np.asarray([int(rule.bit) for rule in feedback_rules], dtype=np.uint8)
    fb_mult = np.ones((len(feedback_rules), 4), dtype=np.float32)
    for i, rule in enumerate(feedback_rules):
        for j, mult in enumerate(rule.multipliers):
            if mult is None:
                continue
            fb_mult[i, j] = float(mult)

    if fb_locus.size == 0:
        fb_locus = np.zeros((0,), dtype=np.int32)
        fb_bit = np.zeros((0,), dtype=np.uint8)
        fb_mult = np.zeros((0, 4), dtype=np.float32)

    max_lambda_dt = cfg.sim.max_lambda_dt
    max_lambda_dt_f = -1.0 if max_lambda_dt is None else float(max_lambda_dt)
    record_every_steps = 0 if record_every is None else int(record_every)

    out = helix_native.ctmc_tau_leap_simulate_cuda(
        str(config_sha256),
        RNG_SCHEDULE_ID,
        RNG_SCHEDULE_SHA256,
        RNG_ENGINE_ID,
        n_cells,
        n_loci,
        steps,
        float(dt),
        int(cfg.sim.seed) & MASK_64,
        int(replicate),
        int(record_every_steps),
        float(cfg.sim.small_x_lin_thresh),
        float(max_lambda_dt_f),
        float(cfg.hazards.k_cut),
        np.asarray(cfg.hazards.k_resect_by_phase, dtype=np.float32),
        float(cfg.hazards.k_nhej),
        float(cfg.hazards.k_alt_ej),
        float(cfg.hazards.k_hdr),
        float(cfg.hazards.k_ssa),
        float(cfg.hazards.k_relax),
        float(cfg.hazards.k_transient_open),
        phase_cut,
        phase_nhej,
        phase_alt,
        phase_hdr,
        phase_ssa,
        chrom_cut,
        chrom_repair,
        chrom_resect,
        np.asarray(cfg.cell_heterogeneity.repair_level_baseline, dtype=np.float32),
        float(cfg.cell_heterogeneity.repair_level_sigma_ln),
        float(cfg.cell_heterogeneity.donor_baseline),
        float(cfg.cell_heterogeneity.donor_sigma_ln),
        float(cfg.outcomes.nhej.p_ins),
        float(cfg.outcomes.nhej.del_geom_p),
        float(cfg.outcomes.nhej.ins_geom_p),
        int(cfg.outcomes.nhej.del_max),
        int(cfg.outcomes.nhej.ins_max),
        float(cfg.outcomes.alt_ej.mh_geom_p),
        int(cfg.outcomes.alt_ej.mh_max),
        float(cfg.outcomes.alt_ej.del_geom_p),
        int(cfg.outcomes.alt_ej.del_max),
        float(cfg.outcomes.hdr.p_precise),
        bool(cfg.outcomes.hdr.allow_recut_after_precise),
        int(cfg.outcomes.ssa.del_size),
        grna_eff,
        access,
        repeat_ctx,
        coding,
        fb_locus,
        fb_bit,
        fb_mult,
    )

    allele_state = np.asarray(out["allele_state"], dtype=np.uint8)
    chrom_state = np.asarray(out["chrom_state"], dtype=np.uint8)
    resection = np.asarray(out["resection"], dtype=np.uint8)
    dsb_age = np.asarray(out["dsb_age"], dtype=np.float32)
    outcome_class = np.asarray(out["outcome_class"], dtype=np.uint8)
    delta_bp = np.asarray(out["delta_bp"], dtype=np.int16)
    frameshift = np.asarray(out["frameshift"], dtype=np.uint8)
    ko_mask = np.asarray(out["ko_mask"], dtype=np.uint64)
    events_by_step = np.asarray(out["events_by_step"], dtype=np.int32)
    state_hash_by_step = list(out.get("state_hash_by_step") or [])

    # Trace hash: sha256 over packed per-step event counters (matches CPU contract).
    trace_hasher = hashlib.sha256()
    totals = {
        "cuts": int(events_by_step[:, 1].sum()) if steps else 0,
        "resections": int(events_by_step[:, 2].sum()) if steps else 0,
        "nhej": int(events_by_step[:, 3].sum()) if steps else 0,
        "altej": int(events_by_step[:, 4].sum()) if steps else 0,
        "hdr_precise": int(events_by_step[:, 5].sum()) if steps else 0,
        "ssa": int(events_by_step[:, 6].sum()) if steps else 0,
        "chrom_relax": int(events_by_step[:, 7].sum()) if steps else 0,
        "chrom_transient_open": int(events_by_step[:, 8].sum()) if steps else 0,
    }
    for step in range(steps):
        row = events_by_step[step]
        trace_hasher.update(
            struct.pack(
                "<9i",
                int(row[0]),
                int(row[1]),
                int(row[2]),
                int(row[3]),
                int(row[4]),
                int(row[5]),
                int(row[6]),
                int(row[7]),
                int(row[8]),
            )
        )

    step_events: list[dict[str, int]] | None = None
    if record_every is not None:
        step_events = []
        for step in range(steps):
            if step % int(record_every) != 0:
                continue
            row = events_by_step[step]
            step_events.append(
                {
                    "step": int(row[0]),
                    "cuts": int(row[1]),
                    "resections": int(row[2]),
                    "nhej": int(row[3]),
                    "altej": int(row[4]),
                    "hdr_precise": int(row[5]),
                    "ssa": int(row[6]),
                    "chrom_relax": int(row[7]),
                    "chrom_transient_open": int(row[8]),
                }
            )

    allele_spectrum = _build_allele_spectrum(outcome_class=outcome_class, delta_bp=delta_bp, frameshift=frameshift)

    # Summary stats (allele-level unless otherwise stated).
    n_alleles = int(outcome_class.size)
    cls = outcome_class.astype(np.int64, copy=False)
    n_no_cut = int(np.sum(cls == int(OutcomeClass.NO_CUT)))
    n_nhej = int(np.sum(cls == int(OutcomeClass.NHEJ)))
    n_altej = int(np.sum(cls == int(OutcomeClass.ALTEJ)))
    n_hdr = int(np.sum(cls == int(OutcomeClass.HDR_PRECISE)))
    n_ssa = int(np.sum(cls == int(OutcomeClass.SSA)))
    n_unrepaired = int(np.sum(cls == int(OutcomeClass.UNREPAIRED)))
    n_cut = int(n_alleles - n_no_cut)
    n_repaired = int(n_nhej + n_altej + n_hdr + n_ssa)

    def frac(num: int, den: int) -> float:
        return float(num) / float(den) if den > 0 else 0.0

    chrom = chrom_state.astype(np.int64, copy=False)
    chrom_open = int(np.sum(chrom == int(ChromState.OPEN)))
    chrom_transient = int(np.sum(chrom == int(ChromState.TRANSIENT)))
    chrom_refractory = int(np.sum(chrom == int(ChromState.REFRACTORY)))

    dsb_mask = allele_state == int(AlleleState.DSB)
    dsb_count = int(np.sum(dsb_mask))
    dsb_age_mean = float(np.mean(dsb_age[dsb_mask])) if dsb_count > 0 else 0.0

    frameshift_mass = float(np.mean(frameshift.astype(bool))) if n_alleles else 0.0
    mosaicism_bits = _shannon_bits([float(e.get("probability") or 0.0) for e in allele_spectrum])

    summary = {
        "no_cut_prob": _round6(frac(n_no_cut, n_alleles)),
        "edit_prob": _round6(frac(n_cut, n_alleles)),
        "intended_prob": _round6(frac(n_hdr, n_alleles)),
        "frameshift_prob": _round6(frameshift_mass),
        "dsb_unrepaired_prob": _round6(frac(n_unrepaired, n_alleles)),
        "ko_cells_prob": _round6(float(np.mean(ko_mask != 0)) if n_cells else 0.0),
        "pathway_frac_given_cut": {
            "NHEJ": _round6(frac(n_nhej, n_cut)),
            "ALTEJ": _round6(frac(n_altej, n_cut)),
            "HDR_PRECISE": _round6(frac(n_hdr, n_cut)),
            "SSA": _round6(frac(n_ssa, n_cut)),
            "UNREPAIRED": _round6(frac(n_unrepaired, n_cut)),
        },
        "pathway_frac_given_repair": {
            "NHEJ": _round6(frac(n_nhej, n_repaired)),
            "ALTEJ": _round6(frac(n_altej, n_repaired)),
            "HDR_PRECISE": _round6(frac(n_hdr, n_repaired)),
            "SSA": _round6(frac(n_ssa, n_repaired)),
        },
        "mosaicism_shannon_bits": _round6(mosaicism_bits),
        "chromatin_state_frac": {
            "OPEN": _round6(frac(chrom_open, n_alleles)),
            "TRANSIENT": _round6(frac(chrom_transient, n_alleles)),
            "REFRACTORY": _round6(frac(chrom_refractory, n_alleles)),
        },
        "dsb_state_frac": _round6(frac(dsb_count, n_alleles)),
        "dsb_age_mean": _round6(dsb_age_mean),
        "event_totals": dict(totals),
    }

    trace = {
        "schedule_id": RNG_SCHEDULE_ID,
        "schedule_sha256": RNG_SCHEDULE_SHA256,
        "engine_id": RNG_ENGINE_ID,
        "counter_tuple": list(RNG_COUNTER_TUPLE),
        "hash_sha256": trace_hasher.hexdigest(),
    }
    diagnostics = out.get("diagnostics")
    if isinstance(diagnostics, Mapping):
        diag = dict(diagnostics)
        if "divergence_by_step" in out:
            try:
                div = np.asarray(out.get("divergence_by_step"), dtype=np.int32)
                cols = out.get("divergence_columns")
                if isinstance(cols, (list, tuple)):
                    diag["divergence_columns"] = [str(c) for c in cols]
                diag["divergence_by_step"] = div.tolist()
            except Exception:
                pass
        trace["diagnostics"] = diag
    if record_every is not None:
        trace["record_every_steps"] = int(record_every)
        trace["events_by_step"] = step_events or []
        trace["state_hash_by_step"] = state_hash_by_step

    return TauLeapReplicateSummary(
        replicate=int(replicate),
        steps=int(steps),
        dt=float(cfg.sim.dt),
        t_end=float(cfg.sim.t_end),
        n_cells=int(n_cells),
        n_loci=int(n_loci),
        allele_spectrum=allele_spectrum,
        summary=summary,
        trace=trace,
    )


def simulate_ctmc_tau_leap(config: Mapping[str, Any]) -> dict[str, Any]:
    """
    Run tau-leap CTMC simulation from a helix_ctmc_tau_leap_v1 config mapping.

    Returns a JSON-serializable payload suitable for downstream visualization.
    """

    cfg = tau_leap_config_from_dict(config)
    backend = str(cfg.sim.backend or "auto").strip().lower() or "auto"
    if backend not in {"auto", "cpu", "cuda"}:
        raise ValueError(f"Unsupported backend: {backend}")

    # Contract default: keep CPU as the source of truth unless explicitly requested.
    selected_backend = "cpu" if backend == "auto" else backend
    if selected_backend == "cuda":
        try:
            from helix_engine import native as helix_native  # noqa: F401
        except Exception as exc:
            raise RuntimeError("CUDA backend requested but helix_engine is unavailable.") from exc

    config_sha256 = _config_sha256(config)
    run_id = hashlib.blake2b(config_sha256.encode("utf-8"), digest_size=8).hexdigest()
    reps = []
    for rep in range(cfg.sim.replicates):
        if selected_backend == "cuda":
            reps.append(_run_tau_leap_replicate_cuda(cfg, replicate=rep, config_sha256=config_sha256))
        else:
            reps.append(_run_tau_leap_replicate(cfg, replicate=rep))

    # Aggregate allele spectrum by (label,category,delta_bp,frameshift).
    agg_counts: dict[tuple[str, str, int, bool], int] = {}
    total = 0
    for rep in reps:
        for entry in rep.allele_spectrum:
            key = (
                str(entry.get("label") or ""),
                str(entry.get("category") or ""),
                int(entry.get("delta_bp") or 0),
                bool(entry.get("frameshift") or False),
            )
            c = int(entry.get("count") or 0)
            agg_counts[key] = agg_counts.get(key, 0) + c
            total += c

    allele_spectrum: list[dict[str, Any]] = []
    for (label, category, delta, fs), count in sorted(agg_counts.items(), key=lambda kv: (-kv[1], kv[0])):
        allele_spectrum.append(
            {
                "label": label,
                "category": category,
                "probability": _round6(float(count) / float(total) if total else 0.0),
                "count": int(count),
                "delta_bp": int(delta),
                "frameshift": bool(fs),
            }
        )

    def _avg_float(key: str) -> float:
        vals = [float(rep.summary.get(key) or 0.0) for rep in reps]
        return float(sum(vals) / float(len(vals))) if vals else 0.0

    def _avg_dict(key: str) -> dict[str, float]:
        out: dict[str, float] = {}
        for rep in reps:
            raw = rep.summary.get(key)
            if not isinstance(raw, Mapping):
                continue
            for k2, v2 in raw.items():
                if k2 not in out:
                    out[k2] = 0.0
                out[k2] += float(v2 or 0.0)
        if not reps:
            return {}
        for k2 in list(out):
            out[k2] = _round6(out[k2] / float(len(reps)))
        return out

    event_totals_sum: dict[str, int] = {}
    for rep in reps:
        raw = rep.summary.get("event_totals")
        if not isinstance(raw, Mapping):
            continue
        for k, v in raw.items():
            event_totals_sum[k] = int(event_totals_sum.get(k, 0) + int(v or 0))

    summary = {
        "replicates": int(cfg.sim.replicates),
        "aggregate": {
            "no_cut_prob": _round6(_avg_float("no_cut_prob")),
            "edit_prob": _round6(_avg_float("edit_prob")),
            "intended_prob": _round6(_avg_float("intended_prob")),
            "frameshift_prob": _round6(_avg_float("frameshift_prob")),
            "dsb_unrepaired_prob": _round6(_avg_float("dsb_unrepaired_prob")),
            "ko_cells_prob": _round6(_avg_float("ko_cells_prob")),
            "mosaicism_shannon_bits": _round6(_avg_float("mosaicism_shannon_bits")),
            "dsb_state_frac": _round6(_avg_float("dsb_state_frac")),
            "dsb_age_mean": _round6(_avg_float("dsb_age_mean")),
            "pathway_frac_given_cut": _avg_dict("pathway_frac_given_cut"),
            "pathway_frac_given_repair": _avg_dict("pathway_frac_given_repair"),
            "chromatin_state_frac": _avg_dict("chromatin_state_frac"),
            "event_totals_sum": event_totals_sum,
        },
        "replicates_detail": [
            {
                "replicate": int(rep.replicate),
                "summary": rep.summary,
                "trace": rep.trace,
            }
            for rep in reps
        ],
    }
    return {
        "schema": {"kind": "crispr.ctmc_tau_leap", "spec_version": "1.0", "schema_version": 1},
        "meta": {
            "run_id": run_id,
            "seed": int(cfg.sim.seed),
            "dt": float(cfg.sim.dt),
            "t_end": float(cfg.sim.t_end),
            "steps": int(cfg.sim.steps),
            "backend": selected_backend,
            "config_sha256": config_sha256,
            "rng_schedule_id": RNG_SCHEDULE_ID,
            "rng_schedule_sha256": RNG_SCHEDULE_SHA256,
            "rng_engine_id": RNG_ENGINE_ID,
        },
        "config": dict(config),
        "results": {
            "allele_spectrum": allele_spectrum,
            "summary": summary,
        },
    }


def simulate_ctmc_tau_leap_cuda(
    config: Mapping[str, Any],
    *,
    seed: int | None = None,
    schedule_id: str = RNG_SCHEDULE_ID,
) -> dict[str, Any]:
    """Convenience wrapper to force the CUDA backend (contract-matching output)."""

    cfg = dict(config)
    sim = cfg.get("sim") if isinstance(cfg.get("sim"), Mapping) else {}
    sim = dict(sim)
    sim["backend"] = "cuda"
    if seed is not None:
        sim["seed"] = int(seed)
    cfg["sim"] = sim
    if schedule_id != RNG_SCHEDULE_ID:
        raise ValueError(f"Unsupported schedule_id (expected {RNG_SCHEDULE_ID}): {schedule_id}")
    return simulate_ctmc_tau_leap(cfg)


__all__ = [
    "AlleleState",
    "ChromState",
    "HazardParams",
    "LocusSpec",
    "Multipliers",
    "OutcomeClass",
    "TauLeapConfig",
    "TauLeapSimSpec",
    "simulate_ctmc_tau_leap",
    "simulate_ctmc_tau_leap_cuda",
    "tau_leap_config_from_dict",
]
