"""OnTargetX utilities (simulation-only).

This package intentionally keeps its core utilities free of heavy ML dependencies
so Helix remains usable in minimal environments. Torch-based models can be built
on top of the deterministic encodings exposed here.
"""

from __future__ import annotations

from .encoding import (
    CLS,
    NUC_VOCAB,
    PAD,
    SEP,
    SPECIAL_TOKENS,
    VOCAB_SIZE,
    dot_bracket_pairs,
    dot_bracket_to_adj,
    encode_nt_sequence,
    make_tokens_and_bias,
    make_valid_token_mask,
    padding_key_bias,
)

__all__ = [
    "NUC_VOCAB",
    "SPECIAL_TOKENS",
    "VOCAB_SIZE",
    "PAD",
    "SEP",
    "CLS",
    "encode_nt_sequence",
    "dot_bracket_pairs",
    "dot_bracket_to_adj",
    "make_tokens_and_bias",
    "make_valid_token_mask",
    "padding_key_bias",
]

