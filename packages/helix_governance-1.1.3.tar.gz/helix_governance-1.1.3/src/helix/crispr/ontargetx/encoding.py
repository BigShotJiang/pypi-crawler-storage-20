from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

import numpy as np

# Minimal vocabulary shared across DNA/RNA inputs.
# - RNA 'U' is canonicalized to 'T' for encoding.
NUC_VOCAB: dict[str, int] = {"A": 0, "C": 1, "G": 2, "T": 3, "N": 4}
PAD = 5
SEP = 6
CLS = 7
SPECIAL_TOKENS: dict[str, int] = {"PAD": PAD, "SEP": SEP, "CLS": CLS}
VOCAB_SIZE = 8  # A,C,G,T,N,PAD,SEP,CLS


def encode_nt_sequence(seq: str) -> np.ndarray:
    """Encode a nucleotide string into token IDs.

    Unknown characters are mapped to 'N'. RNA 'U' is mapped to 'T'.

    Returns an int64 vector of shape (L,).
    """

    if not seq:
        return np.zeros((0,), dtype=np.int64)

    tokens = np.empty((len(seq),), dtype=np.int64)
    for i, raw in enumerate(seq):
        ch = raw.upper()
        if ch == "U":
            ch = "T"
        tokens[i] = NUC_VOCAB.get(ch, NUC_VOCAB["N"])
    return tokens


def dot_bracket_pairs(dot_bracket: str) -> list[tuple[int, int]]:
    """Parse dot-bracket notation into base-pair indices.

    - Supports only '(' and ')' pairing symbols.
    - Ignores unmatched closing parentheses.
    - Leaves unmatched openings unpaired.
    - Returns sorted pairs (i, j) with i < j.
    """

    pairs: list[tuple[int, int]] = []
    stack: list[int] = []
    for i, ch in enumerate(dot_bracket):
        if ch == "(":
            stack.append(i)
            continue
        if ch == ")":
            if not stack:
                continue
            j = stack.pop()
            if j < i:
                pairs.append((j, i))
            continue
    pairs.sort()
    return pairs


def dot_bracket_to_adj(dot_bracket: str, *, dtype: np.dtype = np.float32) -> np.ndarray:
    """Convert dot-bracket notation into a dense symmetric adjacency matrix.

    Returns a (L, L) matrix with 1.0 for paired positions, else 0.0.
    """

    length = len(dot_bracket)
    adj = np.zeros((length, length), dtype=dtype)
    for i, j in dot_bracket_pairs(dot_bracket):
        adj[i, j] = 1.0
        adj[j, i] = 1.0
    return adj


@dataclass(frozen=True)
class TokensAndBias:
    tokens: np.ndarray  # (L,) int64
    bias: np.ndarray  # (L, L) float
    rna_start: int
    rna_end: int


def make_tokens_and_bias(
    dna_seq: str,
    rna_seq: str,
    dot_bracket: str,
    *,
    bias_dtype: np.dtype = np.float32,
) -> TokensAndBias:
    """Build [CLS] DNA [SEP] RNA tokens plus a global attention bias matrix.

    The RNA pairing adjacency (from dot-bracket) is injected into the RNA-RNA
    sub-block of the bias matrix. Other regions are zero.
    """

    dna = encode_nt_sequence(dna_seq)
    rna = encode_nt_sequence(rna_seq)
    if len(dot_bracket) != int(rna.shape[0]):
        raise ValueError(
            "dot_bracket length must match rna_seq length "
            f"(got {len(dot_bracket)} vs {int(rna.shape[0])})"
        )

    tokens = np.concatenate(
        (
            np.asarray([CLS], dtype=np.int64),
            dna,
            np.asarray([SEP], dtype=np.int64),
            rna,
        ),
        axis=0,
    )

    length = int(tokens.shape[0])
    bias = np.zeros((length, length), dtype=bias_dtype)

    rna_start = 1 + int(dna.shape[0]) + 1
    rna_end = rna_start + int(rna.shape[0])
    if rna_start != rna_end:
        bias[rna_start:rna_end, rna_start:rna_end] = dot_bracket_to_adj(
            dot_bracket, dtype=bias_dtype
        )

    return TokensAndBias(tokens=tokens, bias=bias, rna_start=rna_start, rna_end=rna_end)


def make_valid_token_mask(tokens: np.ndarray, *, pad_token_id: int = PAD) -> np.ndarray:
    """Return a boolean mask (L,) that is True for non-pad tokens."""

    if tokens.dtype != np.int64:
        tokens = tokens.astype(np.int64, copy=False)
    return tokens != int(pad_token_id)


def padding_key_bias(
    valid_token_mask: np.ndarray,
    *,
    neg_inf: float = -1e4,
    dtype: np.dtype = np.float32,
) -> np.ndarray:
    """Build an additive attention bias that masks *key* positions that are padding.

    This creates an (L, L) matrix that adds `neg_inf` to columns corresponding to
    invalid tokens. Query rows are left unmasked so every query has at least one
    valid key to attend to.
    """

    mask = np.asarray(valid_token_mask, dtype=bool)
    length = int(mask.shape[0])
    bias = np.zeros((length, length), dtype=dtype)
    invalid = ~mask
    if invalid.any():
        bias[:, invalid] = float(neg_inf)
    return bias


def pad_1d(tokens: np.ndarray, *, length: int, pad_token_id: int = PAD) -> np.ndarray:
    """Pad a 1D token vector to `length`."""

    if tokens.dtype != np.int64:
        tokens = tokens.astype(np.int64, copy=False)
    cur = int(tokens.shape[0])
    if cur > length:
        raise ValueError(f"tokens length {cur} exceeds pad length {length}")
    if cur == length:
        return tokens
    out = np.full((length,), int(pad_token_id), dtype=np.int64)
    out[:cur] = tokens
    return out


def pad_2d_square(matrix: np.ndarray, *, length: int, pad_value: float = 0.0) -> np.ndarray:
    """Pad a square (L, L) matrix to (length, length)."""

    cur = int(matrix.shape[0])
    if matrix.shape != (cur, cur):
        raise ValueError(f"expected square matrix, got {matrix.shape}")
    if cur > length:
        raise ValueError(f"matrix length {cur} exceeds pad length {length}")
    if cur == length:
        return matrix
    out = np.full((length, length), float(pad_value), dtype=matrix.dtype)
    out[:cur, :cur] = matrix
    return out


@dataclass(frozen=True)
class Batch:
    tokens: np.ndarray  # (B, Lmax) int64
    bias: np.ndarray  # (B, Lmax, Lmax) float
    valid_mask: np.ndarray  # (B, Lmax) bool


def pad_batch(
    examples: Sequence[TokensAndBias],
    *,
    pad_token_id: int = PAD,
    bias_pad_value: float = 0.0,
) -> Batch:
    """Pad a list of variable-length examples into a batch."""

    if not examples:
        tokens = np.zeros((0, 0), dtype=np.int64)
        bias = np.zeros((0, 0, 0), dtype=np.float32)
        valid_mask = np.zeros((0, 0), dtype=bool)
        return Batch(tokens=tokens, bias=bias, valid_mask=valid_mask)

    max_len = max(int(ex.tokens.shape[0]) for ex in examples)
    tokens_batch = np.stack(
        [pad_1d(ex.tokens, length=max_len, pad_token_id=pad_token_id) for ex in examples],
        axis=0,
    )
    bias_batch = np.stack(
        [pad_2d_square(ex.bias, length=max_len, pad_value=bias_pad_value) for ex in examples],
        axis=0,
    )
    valid_mask = tokens_batch != int(pad_token_id)
    return Batch(tokens=tokens_batch, bias=bias_batch, valid_mask=valid_mask)


__all__ = [
    "NUC_VOCAB",
    "SPECIAL_TOKENS",
    "VOCAB_SIZE",
    "PAD",
    "SEP",
    "CLS",
    "TokensAndBias",
    "Batch",
    "encode_nt_sequence",
    "dot_bracket_pairs",
    "dot_bracket_to_adj",
    "make_tokens_and_bias",
    "make_valid_token_mask",
    "padding_key_bias",
    "pad_1d",
    "pad_2d_square",
    "pad_batch",
]

