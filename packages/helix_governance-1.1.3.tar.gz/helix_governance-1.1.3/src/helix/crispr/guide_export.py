"""Export helpers for guide discovery."""

from __future__ import annotations

import csv
import json
from typing import Any, IO, Mapping, Sequence

from .coords import COORDINATE_SYSTEM, focus_index

GUIDES_CSV_FIELDS_LEGACY = (
    "id",
    "sequence",
    "strand",
    "start",
    "end",
    "pam_profile",
    "pam_start",
    "pam_end",
    "pam_seq",
    "gc_content",
    "anchor_index",
    "cut_index",
    "viable",
    "reject_reasons",
    "extra_json",
)

GUIDES_CSV_FIELDS_DUAL = GUIDES_CSV_FIELDS_LEGACY + (
    "coordinate_system",
    "start0",
    "end0_excl",
    "anchor_index0",
    "cut_index0",
    "position_index0",
)


def _int_or_blank(value: object) -> str:
    if value is None:
        return ""
    try:
        return str(int(value))
    except Exception:
        return ""


def write_guides_csv(
    handle: IO[str],
    guides: Sequence[Mapping[str, Any]],
    *,
    pam_profile: str | None = None,
) -> None:
    """Write a stable CSV export of guide candidates.

    The input is intentionally permissive (Mappings from UI / discovery code).
    Unknown fields are preserved in `extra_json`.
    """

    writer = csv.DictWriter(handle, fieldnames=list(GUIDES_CSV_FIELDS_DUAL), extrasaction="ignore")
    writer.writeheader()

    for guide in guides:
        pam_site = guide.get("pam_site") if isinstance(guide.get("pam_site"), Mapping) else None
        anchor_index = guide.get("anchor_index")
        cut_index = guide.get("cut_index")
        viable = bool(guide.get("viable", True))
        reject_reasons = guide.get("reject_reasons") if isinstance(guide.get("reject_reasons"), list) else []
        reject_str = ";".join(str(r) for r in reject_reasons if str(r))
        position_index0 = ""
        if anchor_index is not None:
            try:
                position_index0 = str(focus_index(int(cut_index) if cut_index is not None else None, int(anchor_index)))
            except Exception:
                position_index0 = _int_or_blank(cut_index) or _int_or_blank(anchor_index)
        elif cut_index is not None:
            position_index0 = _int_or_blank(cut_index)
        row = {
            "id": str(guide.get("id") or ""),
            "sequence": str(guide.get("sequence") or ""),
            "strand": str(guide.get("strand") or ""),
            "start": _int_or_blank(guide.get("start")),
            "end": _int_or_blank(guide.get("end")),
            "pam_profile": str(pam_profile or guide.get("pam_profile") or guide.get("pam") or ""),
            "pam_start": _int_or_blank(pam_site.get("start") if pam_site else None),
            "pam_end": _int_or_blank(pam_site.get("end") if pam_site else None),
            "pam_seq": str(guide.get("pam_seq") or ""),
            "gc_content": str(guide.get("gc_content") or ""),
            "anchor_index": _int_or_blank(anchor_index),
            "cut_index": _int_or_blank(cut_index),
            "viable": int(1 if viable else 0),
            "reject_reasons": reject_str,
            "coordinate_system": COORDINATE_SYSTEM,
            "start0": _int_or_blank(guide.get("start")),
            "end0_excl": _int_or_blank(guide.get("end")),
            "anchor_index0": _int_or_blank(anchor_index),
            "cut_index0": _int_or_blank(cut_index),
            "position_index0": position_index0,
        }
        extra = {
            k: v
            for k, v in guide.items()
            if k not in {
                "id",
                "sequence",
                "strand",
                "start",
                "end",
                "pam_profile",
                "pam",
                "pam_seq",
                "pam_site",
                "gc_content",
                "anchor_index",
                "cut_index",
                "viable",
                "reject_reasons",
                "coordinate_system",
                "start0",
                "end0_excl",
                "anchor_index0",
                "cut_index0",
                "position_index0",
            }
        }
        row["extra_json"] = json.dumps(extra, sort_keys=True, separators=(",", ":"), ensure_ascii=False) if extra else ""
        writer.writerow(row)
