from __future__ import annotations

import math
import os
from dataclasses import dataclass
from typing import Any, Dict, Optional, Protocol, runtime_checkable

from .model import CasSystem, GuideRNA, TargetSite


@runtime_checkable
class CutSite(Protocol):
    start: int
    end: int
    strand: int | str


@runtime_checkable
class CutCas(Protocol):
    cut_offset: int


def compute_cut_position(*, site: CutSite, cas: CutCas) -> int:
    """
    Shared cut position logic for CRISPR rules + simulator.

    - `site.start`/`site.end` are expected to be 0-based coordinates (end exclusive).
    - `site.strand` may be `+`/`-` or `1`/`-1`.
    - `cas.cut_offset` is interpreted using the simulator convention:
        + strand: start + cut_offset
        - strand: end - cut_offset

    Returned cut positions are clamped to `[site.start, site.end]` to avoid
    emitting out-of-window edits for extreme offsets.
    """

    start = int(getattr(site, "start"))
    end = int(getattr(site, "end"))
    cut_offset = int(getattr(cas, "cut_offset"))

    strand = getattr(site, "strand", "+")
    if isinstance(strand, str):
        strand_value = strand.strip()
        is_reverse = strand_value.startswith("-")
    else:
        is_reverse = int(strand) < 0

    cut = end - cut_offset if is_reverse else start + cut_offset
    return max(start, min(end, int(cut)))


class OnTargetScorer(Protocol):
    """
    Interface for on-target scoring engines.

    Must be deterministic for a fixed input.
    Return values are unitless scores in [0, 1].
    """

    name: str

    def score(self, *, guide: GuideRNA, site: TargetSite, cas: CasSystem) -> float:
        ...


@dataclass(frozen=True, slots=True)
class OnTargetEngineResult:
    """
    Deterministic scoring contract returned by Helix on-target engines.

    - `raw_score` is the engine score used for ranking (unitless, typically [0, 1]).
    - `p_edit` is a probability-like value derived from `raw_score` using
      `get_score_to_prob()`.
    - `novelty` is a 0..1 heuristic derived from kNN distance to training
      embeddings (0 = familiar, 1 = maximally novel).
    - `ood` flags out-of-distribution inputs per the engine's calibrated threshold.
    """

    raw_score: float
    p_edit: float
    novelty: float
    ood: bool
    engine_id: str
    engine_version: str
    model_hash: str
    features: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "raw_score": float(self.raw_score),
            "p_edit": float(self.p_edit),
            "novelty": float(self.novelty),
            "ood": bool(self.ood),
            "engine_id": str(self.engine_id),
            "engine_version": str(self.engine_version),
            "model_hash": str(self.model_hash),
            "features": dict(self.features),
        }


@dataclass(frozen=True)
class ScoreToProb:
    """
    Maps an engine score to a probability-like quantity used by edit rules.

    mode:
      - log_score: p is score (rules use log(p))
      - power:     p is score ** k
      - sigmoid:   p is sigmoid(a * score + b)
    """

    mode: str = "log_score"
    k: float = 1.0
    a: float = 12.0
    b: float = -6.0
    min_p: float = 1e-6

    @staticmethod
    def _sigmoid(z: float) -> float:
        if z >= 0:
            ez = math.exp(-z)
            return 1.0 / (1.0 + ez)
        ez = math.exp(z)
        return ez / (1.0 + ez)

    def to_prob(self, score: float) -> float:
        s = max(0.0, min(1.0, float(score)))

        if self.mode == "log_score":
            p = s
        elif self.mode == "power":
            p = s ** float(self.k)
        elif self.mode == "sigmoid":
            p = self._sigmoid(float(self.a) * s + float(self.b))
        else:
            raise ValueError(f"Unknown HELIX_ON_TARGET_SCORE_TO_PROB mode: {self.mode!r}")

        min_p = max(0.0, min(1.0, float(self.min_p)))
        if p < min_p:
            p = min_p
        if p > 1.0:
            p = 1.0
        return p


_SCORERS: Dict[str, OnTargetScorer] = {}
_BUILTINS_LOADED = False


def register_scorer(scorer: OnTargetScorer) -> None:
    _SCORERS[scorer.name] = scorer


def load_builtin_scorers() -> None:
    global _BUILTINS_LOADED
    if _BUILTINS_LOADED:
        return
    from importlib import import_module

    import_module("helix.crispr.on_target_engines")
    _BUILTINS_LOADED = True


def get_scorer(name: Optional[str] = None) -> OnTargetScorer:
    load_builtin_scorers()
    engine = (name or os.environ.get("HELIX_ON_TARGET_ENGINE") or "physics").strip() or "physics"
    scorer = _SCORERS.get(engine)
    if scorer is None:
        known = ", ".join(sorted(_SCORERS))
        raise ValueError(f"Unknown HELIX_ON_TARGET_ENGINE={engine!r}. Known: {known}")
    return scorer


def _float_env(key: str, default: float) -> float:
    raw = os.environ.get(key)
    if raw is None:
        return default
    try:
        return float(raw)
    except Exception:
        return default


def get_score_to_prob() -> ScoreToProb:
    """
    Load the score->prob mapping from env vars.

    This keeps the rules configurable without threading config through every call site.
    """

    mode = (os.environ.get("HELIX_ON_TARGET_SCORE_TO_PROB") or "log_score").strip() or "log_score"
    return ScoreToProb(
        mode=mode,
        k=_float_env("HELIX_ON_TARGET_POWER_K", 1.0),
        a=_float_env("HELIX_ON_TARGET_SIGMOID_A", 12.0),
        b=_float_env("HELIX_ON_TARGET_SIGMOID_B", -6.0),
        min_p=_float_env("HELIX_ON_TARGET_MIN_P", 1e-6),
    )


def evaluate(
    scorer: OnTargetScorer,
    *,
    guide: GuideRNA,
    site: TargetSite,
    cas: CasSystem,
) -> OnTargetEngineResult:
    """
    Score a site and return a deterministic, metadata-rich result.

    Engines may optionally provide an `evaluate(...) -> OnTargetEngineResult`
    method. If absent, Helix synthesizes a minimal result from `score(...)`.
    """

    maybe = getattr(scorer, "evaluate", None)
    if callable(maybe):
        result = maybe(guide=guide, site=site, cas=cas)
        if isinstance(result, OnTargetEngineResult):
            return result

    raw = float(scorer.score(guide=guide, site=site, cas=cas))
    p_edit = get_score_to_prob().to_prob(raw)
    return OnTargetEngineResult(
        raw_score=raw,
        p_edit=p_edit,
        novelty=0.0,
        ood=False,
        engine_id=getattr(scorer, "name", "unknown"),
        engine_version="unknown",
        model_hash="builtin",
        features={},
    )


# Ensure built-in engines are registered deterministically at import time, so
# later user registration can intentionally override them.
load_builtin_scorers()
