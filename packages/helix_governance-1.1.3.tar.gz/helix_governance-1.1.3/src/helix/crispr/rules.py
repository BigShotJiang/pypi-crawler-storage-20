"""CRISPR edit rules plugged into the edit DAG runtime."""
from __future__ import annotations

import math
from typing import Dict, Iterable, List, Tuple

from helix.edit.dag import EditNode
from helix.edit.events import EditEvent
from helix.edit.physics import edit_rule
from helix.edit.simulate import SimulationContext

from .model import CasSystem, DigitalGenome, GuideRNA
from .on_target import compute_cut_position
from .physics import CRISPRPhysicsBase
from .simulator import find_candidate_sites
from .cut_spectrum import build_microhomology_indel_spectrum


def _get_context_objects(ctx: SimulationContext) -> Tuple[DigitalGenome, CasSystem, GuideRNA]:
    genome: DigitalGenome = ctx.extra["legacy_genome"]
    cas: CasSystem = ctx.extra["cas"]
    guide: GuideRNA = ctx.extra["guide"]
    return genome, cas, guide


def _get_physics(ctx: SimulationContext) -> CRISPRPhysicsBase | None:
    physics = ctx.extra.get("physics")
    if isinstance(physics, CRISPRPhysicsBase):
        return physics
    return None


@edit_rule("crispr.clean_cut")
def crispr_clean_cut(node: EditNode, ctx: SimulationContext) -> Iterable[Tuple[EditEvent, float, Dict]]:
    """First-stage CRISPR rule: propose clean-cut events."""
    if node.metadata.get("stage", "root") != "root":
        return []

    genome, cas, guide = _get_context_objects(ctx)
    max_sites = ctx.extra.get("max_sites", 3) or 3
    no_edit_prob = ctx.extra.get("no_edit_prob", 0.1)

    physics = _get_physics(ctx)
    candidates = find_candidate_sites(genome, cas, guide, max_sites=max_sites, physics=physics)
    proposals: List[Tuple[EditEvent, float, Dict]] = []

    if not candidates:
        event = EditEvent(chrom="__none__", start=0, end=0, replacement="", metadata={"label": "no_target"})
        proposals.append((event, 0.0, {"stage": "no_target", "label": "no_target"}))
        return proposals

    for site in candidates:
        cut_pos = compute_cut_position(site=site, cas=cas)
        log_prob = math.log(max(site.on_target_score or 1e-6, 1e-6))
        event = EditEvent(
            chrom=site.chrom,
            start=cut_pos,
            end=cut_pos,
            replacement="",
            metadata={
                "label": "clean_cut",
                "mechanism": "crispr",
                "site_chrom": site.chrom,
                "site_start": site.start,
                "site_end": site.end,
                "cut_position": cut_pos,
                "strand": site.strand,
                "stage": "cut",
            },
        )
        proposals.append(
            (
                event,
                log_prob,
                {
                    "stage": "cut",
                    "site_chrom": site.chrom,
                    "site_start": site.start,
                    "site_end": site.end,
                    "cut_position": cut_pos,
                    "strand": site.strand,
                },
            )
        )

    if no_edit_prob > 0:
        event = EditEvent(
            chrom="__none__",
            start=0,
            end=0,
            replacement="",
            metadata={"label": "no_edit", "mechanism": "crispr", "stage": "no_edit"},
        )
        proposals.append((event, math.log(max(no_edit_prob, 1e-6)), {"stage": "no_edit", "label": "no_cut"}))

    return proposals


@edit_rule("crispr.indel_branch")
def crispr_indel_branch(node: EditNode, ctx: SimulationContext) -> Iterable[Tuple[EditEvent, float, Dict]]:
    """Second-stage CRISPR rule: branch into indel/intended repair outcomes."""
    if node.metadata.get("stage") != "cut":
        return []

    chrom = node.metadata.get("site_chrom")
    cut_pos = node.metadata.get("cut_position")
    if chrom is None or cut_pos is None:
        return []

    seq = node.genome_view.materialize_chrom(chrom)
    proposals: List[Tuple[EditEvent, float, Dict]] = []

    # Default: deterministic microhomology-weighted spectrum of small indels.
    # This makes guide comparisons meaningful even when physics scores are identical.
    try:
        max_alleles = int(ctx.extra.get("indel_max_alleles", 16))
    except Exception:
        max_alleles = 16
    max_alleles = max(4, min(64, max_alleles))

    spectrum = build_microhomology_indel_spectrum(seq, int(cut_pos), max_alleles=max_alleles, min_frequency=0.0)
    if not spectrum:
        del_start = int(cut_pos)
        del_end = min(del_start + 1, len(seq))
        indel_event = EditEvent(
            chrom=chrom,
            start=del_start,
            end=del_end,
            replacement="",
            metadata={"mechanism": "crispr", "stage": "repaired"},
        )
        proposals.append((indel_event, -0.5, {"stage": "repaired", "label": "indel"}))
        return proposals

    for entry in spectrum:
        if not isinstance(entry, dict):
            continue
        delta = entry.get("sequenceDelta")
        if not isinstance(delta, dict):
            continue
        kind = str(delta.get("type") or "").strip().lower()
        if kind not in {"del", "ins"}:
            continue
        try:
            freq = float(entry.get("frequency") or 0.0)
        except Exception:
            continue
        if not (freq > 0.0 and math.isfinite(freq)):
            continue
        log_prob = math.log(max(freq, 1e-12))

        if kind == "del":
            start = int(delta.get("start") or 0)
            end = int(delta.get("end") or start)
            length = int(delta.get("length") or max(0, end - start))
            mh = delta.get("microhomology")
            offset = start - int(cut_pos)
            label = f"del{length}@{offset:+d}"
            event = EditEvent(
                chrom=chrom,
                start=start,
                end=end,
                replacement="",
                metadata={"mechanism": "crispr", "stage": "repaired"},
            )
            meta: Dict[str, object] = {"stage": "repaired", "label": label}
            if mh is not None:
                try:
                    meta["microhomology"] = int(mh)
                except Exception:
                    pass
            proposals.append((event, log_prob, meta))
        else:
            start = int(delta.get("start") or 0)
            ins_seq = str(delta.get("sequence") or "")
            ins_len = delta.get("length")
            if ins_len is None:
                ins_len = len(ins_seq)
            label = f"ins{int(ins_len or 0)}"
            event = EditEvent(
                chrom=chrom,
                start=start,
                end=start,
                replacement=ins_seq,
                metadata={"mechanism": "crispr", "stage": "repaired"},
            )
            proposals.append((event, log_prob, {"stage": "repaired", "label": label}))

    # Keep deterministic ordering for stable leaf IDs/probs.
    proposals.sort(key=lambda p: (str(p[2].get("label") or ""), p[0].start, p[0].end))
    return proposals


@edit_rule("crispr.no_edit")
def crispr_no_edit(node: EditNode, ctx: SimulationContext) -> Iterable[Tuple[EditEvent, float, Dict]]:
    """Generic no-op branch to keep 'no edit' paths alive."""
    event = EditEvent(
        chrom="__none__",
        start=0,
        end=0,
        replacement="",
        metadata={"label": "no_edit_branch", "mechanism": "crispr"},
    )
    stage = node.metadata.get("stage", "root")
    return [(event, -1.0, {"stage": stage, "label": "no_cut"})]
