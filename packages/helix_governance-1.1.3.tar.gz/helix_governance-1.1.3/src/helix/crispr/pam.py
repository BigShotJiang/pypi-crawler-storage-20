"""PAM definitions, validators, and helpers."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Sequence

from helix import bioinformatics

_IUPAC: Mapping[str, Sequence[str]] = {
    "A": ("A",),
    "C": ("C",),
    "G": ("G",),
    "T": ("T", "U"),
    "U": ("T", "U"),
    "R": ("A", "G"),
    "Y": ("C", "T", "U"),
    "S": ("G", "C"),
    "W": ("A", "T", "U"),
    "K": ("G", "T", "U"),
    "M": ("A", "C"),
    "B": ("C", "G", "T", "U"),
    "D": ("A", "G", "T", "U"),
    "H": ("A", "C", "T", "U"),
    "V": ("A", "C", "G"),
    "N": ("A", "C", "G", "T", "U"),
}


@dataclass(frozen=True)
class PAM:
    """Container describing a PAM pattern."""

    name: str
    pattern: str
    orientation: str = "3prime"  # guide-3' adjacency (SpCas9 default)
    notes: str | None = None

    def as_dict(self) -> Dict[str, str]:
        return {"name": self.name, "pattern": self.pattern, "orientation": self.orientation, "notes": self.notes}


_DEFAULT_PAMS: Dict[str, PAM] = {
    "SpCas9-NGG": PAM(name="SpCas9-NGG", pattern="NGG", orientation="3prime", notes="canonical SpCas9"),
    "SaCas9-NNGRRT": PAM(name="SaCas9-NNGRRT", pattern="NNGRRT", orientation="3prime"),
    "SpRY-NNN": PAM(name="SpRY-NNN", pattern="NNN", orientation="3prime", notes="near-PAMless"),
}

# Upper-case alias keys so lookups can be case-insensitive and tolerate separators.
_PAM_ALIASES: Mapping[str, str] = {
    "NGG": "SpCas9-NGG",
    "SPCAS9-NGG": "SpCas9-NGG",
    "NNGRRT": "SaCas9-NNGRRT",
    "SACAS9-NNGRRT": "SaCas9-NNGRRT",
    "NNN": "SpRY-NNN",
    "SPRY-NNN": "SpRY-NNN",
}


def list_pams() -> Sequence[str]:
    """Return the registered PAM names."""

    return tuple(sorted(_DEFAULT_PAMS))


def get_pam(name: str) -> Dict[str, str]:
    """Return a PAM definition by name."""

    key_raw = str(name or "").strip()
    if not key_raw:
        raise ValueError("PAM name must be a non-empty string.")

    # Exact match first (fast path)
    pam = _DEFAULT_PAMS.get(key_raw)
    if pam:
        return pam.as_dict()

    # Normalize separators and try again (e.g., "SpCas9_NGG" -> "SpCas9-NGG")
    key_norm = key_raw.replace("_", "-")
    pam = _DEFAULT_PAMS.get(key_norm)
    if pam:
        return pam.as_dict()

    # Case-insensitive match against registered names
    key_lower = key_norm.lower()
    for registered_name, registered_pam in _DEFAULT_PAMS.items():
        if registered_name.lower() == key_lower:
            return registered_pam.as_dict()

    # Alias map (case-insensitive)
    alias_key = key_norm.upper()
    canonical = _PAM_ALIASES.get(alias_key)
    if canonical:
        return get_pam(canonical)

    # Treat bare IUPAC patterns (e.g., "NGG", "NNGRRT") as valid PAMs and auto-register.
    pattern = key_raw.upper()
    if pattern and all(ch in _IUPAC for ch in pattern):
        pam = PAM(name=pattern, pattern=pattern, orientation="3prime", notes="auto-registered pattern")
        register_pam(pam)
        return pam.as_dict()

    raise ValueError(f"Unknown PAM '{name}'. Known PAMs: {', '.join(list_pams())}.")


def register_pam(pam: PAM) -> None:
    """Register a PAM at runtime (useful for notebooks/tests)."""

    _DEFAULT_PAMS[pam.name] = pam


def match_pam(seq: str, pam: Mapping[str, str] | PAM, pos: int = 0) -> bool:
    """Return True if `seq[pos:pos+len(pattern)]` satisfies the PAM rule."""

    if isinstance(pam, PAM):
        pattern = pam.pattern
    else:
        pattern = str(pam.get("pattern", ""))
    if not pattern:
        return False
    region = seq[pos : pos + len(pattern)].upper()
    if len(region) != len(pattern):
        return False
    for base, symbol in zip(region, pattern.upper()):
        allowed = _IUPAC.get(symbol)
        if not allowed or base.upper() not in allowed:
            return False
    return True


_IUPAC_COMPLEMENT = {
    "A": "T",
    "C": "G",
    "G": "C",
    "T": "A",
    "U": "A",
    "R": "Y",
    "Y": "R",
    "S": "S",
    "W": "W",
    "K": "M",
    "M": "K",
    "B": "V",
    "D": "H",
    "H": "D",
    "V": "B",
    "N": "N",
}


def reverse_complement_pattern(pattern: str) -> str:
    """Return the reverse complement for an IUPAC pattern string."""

    letters = []
    for char in reversed(pattern.upper()):
        letters.append(_IUPAC_COMPLEMENT.get(char, "N"))
    return "".join(letters)


PAM_MOTIFS: Dict[str, str] = {
    "SpCas9_NGG": "NGG",
    "SpG_NGN": "NGN",
    "SpRY_NNN": "NNN",
    "SaCas9_NNGRRT": "NNGRRT",
    "Cas12a_TTTN": "TTTN",
}


def _match_motif(seq: str, motif: str) -> bool:
    """Return True when `seq` satisfies the provided motif (supports N wildcards)."""

    seq = seq.upper()
    motif = motif.upper()
    if len(seq) != len(motif):
        return False
    for base, symbol in zip(seq, motif):
        if symbol == "N":
            continue
        if base != symbol:
            return False
    return True


def build_crispr_pam_mask(
    site_seq: str,
    guide: Mapping[str, object] | None,
    pam_profile: str,
    pam_softness: float,
) -> List[float]:
    """
    Construct a position-wise PAM weight mask.

    Positions that match the PAM motif receive weight 1.0.
    Additionally, for Cas9-style models, the expected cut/nick position
    associated with a matching PAM is also assigned weight 1.0.

    All other positions receive `pam_softness` (clamped to [0, 1]).
    """

    normalized = bioinformatics.normalize_sequence(site_seq)
    length = len(normalized)
    if length == 0:
        return []

    key = (pam_profile or "SpCas9_NGG").strip() or "SpCas9_NGG"
    motif = PAM_MOTIFS.get(key) or PAM_MOTIFS.get(key.replace("-", "_"))
    if motif is None:
        raise ValueError(f"Unknown PAM profile: {pam_profile}")

    softness = max(0.0, min(1.0, float(pam_softness)))
    if softness >= 1.0:
        return [1.0] * length

    mask = [softness] * length
    motif = motif.upper()
    motif_len = len(motif)
    upper_seq = normalized.upper()

    # This is a lightweight, sequence-only proxy: mark any positions that
    # participate in a PAM match (either strand) and the adjacent Cas9 cut site.
    rc_motif = reverse_complement_pattern(motif)
    cas9_cut_offset = 3

    for idx in range(length - motif_len + 1):
        window = upper_seq[idx : idx + motif_len]
        if _match_motif(window, motif):
            for offset in range(motif_len):
                mask[idx + offset] = 1.0
            cut_pos = idx - cas9_cut_offset
            if 0 <= cut_pos < length:
                mask[cut_pos] = 1.0
        if _match_motif(window, rc_motif):
            for offset in range(motif_len):
                mask[idx + offset] = 1.0
            cut_pos = idx + motif_len + cas9_cut_offset
            if 0 <= cut_pos < length:
                mask[cut_pos] = 1.0

    _ = guide
    return mask


def build_prime_pam_mask(
    site_seq: str,
    peg: Mapping[str, object] | None,
    pam_profile: str,
    pam_softness: float,
) -> List[float]:
    """Alias of build_crispr_pam_mask for semantic clarity."""

    return build_crispr_pam_mask(site_seq, peg, pam_profile, pam_softness)
