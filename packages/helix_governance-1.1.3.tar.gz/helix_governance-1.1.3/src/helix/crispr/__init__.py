"""CRISPR design helpers (PAMs, guide discovery, scoring, simulation)."""

from __future__ import annotations

from importlib import import_module
from typing import Any, Dict, Tuple

_MODULE_EXPORTS: Dict[str, str] = {
    "score": "helix.crispr.score",
    "simulate": "helix.crispr.simulate",
    "dynamic": "helix.crispr.dynamic",
}

_ATTR_EXPORTS: Dict[str, Tuple[str, str]] = {
    "get_pam": ("helix.crispr.pam", "get_pam"),
    "match_pam": ("helix.crispr.pam", "match_pam"),
    "list_pams": ("helix.crispr.pam", "list_pams"),
    "find_guides": ("helix.crispr.guide", "find_guides"),
    "CasSystemType": ("helix.crispr.model", "CasSystemType"),
    "PAMRule": ("helix.crispr.model", "PAMRule"),
    "CasSystem": ("helix.crispr.model", "CasSystem"),
    "GuideRNA": ("helix.crispr.model", "GuideRNA"),
    "TargetSite": ("helix.crispr.model", "TargetSite"),
    "DigitalGenome": ("helix.crispr.model", "DigitalGenome"),
    "CutEvent": ("helix.crispr.simulator", "CutEvent"),
    "EfficiencyTargetRequest": ("helix.crispr.simulator", "EfficiencyTargetRequest"),
    "EfficiencyPrediction": ("helix.crispr.simulator", "EfficiencyPrediction"),
    "create_crispr_physics": ("helix.crispr.physics", "create_crispr_physics"),
    "find_candidate_sites": ("helix.crispr.simulator", "find_candidate_sites"),
    "predict_efficiency_for_targets": ("helix.crispr.simulator", "predict_efficiency_for_targets"),
    "simulate_cuts": ("helix.crispr.simulator", "simulate_cuts"),
    "rank_off_targets": ("helix.crispr.simulator", "rank_off_targets"),
    "build_crispr_edit_dag": ("helix.crispr.dag_api", "build_crispr_edit_dag"),
}


def __getattr__(name: str) -> Any:  # pragma: no cover - exercised via imports
    if name in _MODULE_EXPORTS:
        module = import_module(_MODULE_EXPORTS[name])
        globals()[name] = module
        return module
    if name in _ATTR_EXPORTS:
        module_name, attr = _ATTR_EXPORTS[name]
        module = import_module(module_name)
        value = getattr(module, attr)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "get_pam",
    "match_pam",
    "list_pams",
    "find_guides",
    "score",
    "simulate",
    "dynamic",
    "CasSystemType",
    "PAMRule",
    "CasSystem",
    "GuideRNA",
    "TargetSite",
    "DigitalGenome",
    "CutEvent",
    "EfficiencyTargetRequest",
    "EfficiencyPrediction",
    "create_crispr_physics",
    "find_candidate_sites",
    "predict_efficiency_for_targets",
    "simulate_cuts",
    "rank_off_targets",
    "build_crispr_edit_dag",
]

