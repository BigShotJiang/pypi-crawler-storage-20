"""Structured interaction proxies for Cas–DNA guide/target pairs.

These values are **not** mechanistic kinetics or thermodynamics. They are explicit,
auditable proxies intended to separate:

- binding (sequence compatibility + PAM gating), and
- cleavage given binding (mismatch identity/position sensitivity)

This makes the causal chain visible in artifacts without claiming physics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence


def _clamp01(value: float) -> float:
    if value <= 0.0:
        return 0.0
    if value >= 1.0:
        return 1.0
    return value


def _pam_proximal_index(position: int, guide_len: int, pam_orientation: str) -> int:
    """Return 0-based index counting from the PAM-proximal end of the protospacer."""

    if guide_len <= 0:
        return 0
    pos = min(max(int(position), 0), guide_len - 1)
    orientation = str(pam_orientation or "3prime").lower()
    if orientation == "5prime":
        return pos
    return (guide_len - 1) - pos


@dataclass(frozen=True)
class CasDNAInteractionProxy:
    pam_match_quality: float
    pam_orientation: str
    guide_len: int
    seed_len: int
    mismatch_vector: tuple[int, ...]
    pam_proximal_mismatch_count: int
    distal_mismatch_count: int
    pam_proximal_penalty: float
    distal_tolerance_score: float
    binding_affinity_proxy: float
    binding_stability_proxy: float
    off_rate_proxy: float
    cleavage_given_bound_proxy: float
    cleavage_probability_proxy: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "pam_match_quality": float(self.pam_match_quality),
            "pam_orientation": str(self.pam_orientation),
            "guide_len": int(self.guide_len),
            "seed_len": int(self.seed_len),
            "mismatch_vector": list(self.mismatch_vector),
            "pam_proximal_mismatch_count": int(self.pam_proximal_mismatch_count),
            "distal_mismatch_count": int(self.distal_mismatch_count),
            "pam_proximal_penalty": float(self.pam_proximal_penalty),
            "distal_tolerance_score": float(self.distal_tolerance_score),
            "binding_affinity_proxy": float(self.binding_affinity_proxy),
            "binding_stability_proxy": float(self.binding_stability_proxy),
            "off_rate_proxy": float(self.off_rate_proxy),
            "cleavage_given_bound_proxy": float(self.cleavage_given_bound_proxy),
            "cleavage_probability_proxy": float(self.cleavage_probability_proxy),
        }


def build_interaction_proxy(
    mismatches: Sequence[Mapping[str, object]],
    *,
    guide_len: int,
    pam_ok: bool,
    pam_orientation: str,
    weights: Mapping[str, object],
) -> CasDNAInteractionProxy:
    """Compute interaction proxies for a guide/target pair.

    Inputs are intentionally minimal and sequence-derived. Downstream callers can
    choose to add context (chromatin, cell-type, etc.) later without changing the
    conceptual API.
    """

    guide_len = max(0, int(guide_len))
    orientation = str(pam_orientation or "3prime").lower()
    seed_len = int(weights.get("seed_len") or 8)
    seed_len = min(max(seed_len, 1), guide_len) if guide_len else max(seed_len, 1)

    default_mismatch = float(weights.get("default_mismatch") or 0.8)
    mismatch_penalties = weights.get("mismatch_penalties") or {}
    position_penalties = list(weights.get("position_penalties") or [])

    pam_penalty = float(weights.get("pam_penalty") or 0.75)
    pam_match_quality = 1.0 if bool(pam_ok) else _clamp01(pam_penalty)

    seed_mismatch_penalty = float(weights.get("seed_mismatch_penalty") or 0.35)
    distal_mismatch_penalty = float(weights.get("distal_mismatch_penalty") or 0.8)
    seed_mismatch_penalty = _clamp01(seed_mismatch_penalty)
    distal_mismatch_penalty = _clamp01(distal_mismatch_penalty)

    mismatch_vector = [0] * guide_len
    pam_proximal_mismatch_count = 0
    distal_mismatch_count = 0

    position_penalty_product = 1.0
    pam_proximal_penalty = 1.0
    distal_tolerance_score = 1.0
    identity_penalty_product = 1.0

    for mismatch in mismatches:
        try:
            pos = int(mismatch.get("position", 0))
        except Exception:
            pos = 0
        if 0 <= pos < guide_len:
            mismatch_vector[pos] = 1

        if guide_len:
            from_pam = _pam_proximal_index(pos, guide_len, orientation)
        else:
            from_pam = 0
        is_seed = from_pam < seed_len

        if position_penalties:
            idx = min(max(pos, 0), len(position_penalties) - 1)
            pos_penalty = _clamp01(float(position_penalties[idx]))
        else:
            pos_penalty = seed_mismatch_penalty if is_seed else distal_mismatch_penalty

        position_penalty_product *= pos_penalty
        if is_seed:
            pam_proximal_mismatch_count += 1
            pam_proximal_penalty *= pos_penalty
        else:
            distal_mismatch_count += 1
            distal_tolerance_score *= pos_penalty

        ref = str(mismatch.get("target", "N"))
        alt = str(mismatch.get("guide", "N"))
        key = f"{ref}>{alt}"
        if isinstance(mismatch_penalties, Mapping) and key in mismatch_penalties:
            try:
                identity_penalty = float(mismatch_penalties.get(key, default_mismatch))
            except Exception:
                identity_penalty = default_mismatch
        else:
            identity_penalty = default_mismatch
        identity_penalty_product *= _clamp01(identity_penalty)

    binding_affinity_proxy = _clamp01(pam_match_quality * position_penalty_product)
    cleavage_given_bound_proxy = _clamp01(identity_penalty_product)
    cleavage_probability_proxy = _clamp01(
        binding_affinity_proxy * cleavage_given_bound_proxy
    )

    # Placeholder kinetic separation: stability is distinct from affinity, but we
    # currently use the same proxy until a dwell-time / off-rate model lands.
    binding_stability_proxy = binding_affinity_proxy
    off_rate_proxy = _clamp01(1.0 - binding_stability_proxy)

    return CasDNAInteractionProxy(
        pam_match_quality=pam_match_quality,
        pam_orientation=orientation,
        guide_len=guide_len,
        seed_len=seed_len,
        mismatch_vector=tuple(int(x) for x in mismatch_vector),
        pam_proximal_mismatch_count=pam_proximal_mismatch_count,
        distal_mismatch_count=distal_mismatch_count,
        pam_proximal_penalty=_clamp01(pam_proximal_penalty),
        distal_tolerance_score=_clamp01(distal_tolerance_score),
        binding_affinity_proxy=binding_affinity_proxy,
        binding_stability_proxy=binding_stability_proxy,
        off_rate_proxy=off_rate_proxy,
        cleavage_given_bound_proxy=cleavage_given_bound_proxy,
        cleavage_probability_proxy=cleavage_probability_proxy,
    )
