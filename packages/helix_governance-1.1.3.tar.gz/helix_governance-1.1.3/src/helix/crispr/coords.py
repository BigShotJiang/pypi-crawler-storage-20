from __future__ import annotations

COORDINATE_SYSTEM = "0-based half-open"


def anchor_midpoint_index(start: int, end: int) -> int:
    """Return the midpoint anchor index for a guide span.

    Helix uses 0-based, half-open coordinates `[start, end)`.

    For robustness we accept `start > end` and compute the midpoint of the
    absolute span.
    """

    start_i = int(start)
    end_i = int(end)
    if start_i <= end_i:
        return start_i + (end_i - start_i) // 2
    return end_i + (start_i - end_i) // 2


def focus_index(cut_index: int | None, anchor_index: int) -> int:
    """Return a canonical focus index for a guide span.

    Prefer `cut_index` when provided (Cas-style cut position); otherwise fall back
    to `anchor_index` (typically the midpoint of the guide span).
    """

    return cut_index if cut_index is not None else anchor_index
