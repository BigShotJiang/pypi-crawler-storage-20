from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Mapping, Sequence

import yaml


class DeliveryMode(str, Enum):
    RNP = "RNP"
    MRNA = "mRNA"
    PLASMID = "plasmid"
    VIRAL = "viral"


def _parse_delivery_mode(raw: object) -> DeliveryMode:
    token = str(raw).strip()
    if not token:
        return DeliveryMode.RNP
    normalized = token.lower()
    if normalized == "rnp":
        return DeliveryMode.RNP
    if normalized in {"mrna", "m-rna"}:
        return DeliveryMode.MRNA
    if normalized == "plasmid":
        return DeliveryMode.PLASMID
    if normalized == "viral":
        return DeliveryMode.VIRAL
    raise ValueError(f"Unknown delivery mode: {raw!r}")


@dataclass(frozen=True)
class TimeConfig:
    dt_h: float = 0.25
    t_end_h: float = 48.0


@dataclass(frozen=True)
class PopulationConfig:
    n_cells: int = 1000
    seed: int = 0


@dataclass(frozen=True)
class HeterogeneityConfig:
    model: str = "lognormal"
    params: Mapping[str, Any] = field(default_factory=dict)

    def sample_scale(self, *, rng: Any) -> float:
        if self.model != "lognormal":
            raise ValueError(f"Unknown heterogeneity model: {self.model}")
        sigma = float(self.params.get("sigma", 0.0))
        if sigma <= 0.0:
            return 1.0
        mu = float(self.params.get("mu", 0.0))
        return float(rng.lognormvariate(mu, sigma))


@dataclass(frozen=True)
class DeliveryConfig:
    mode: DeliveryMode = DeliveryMode.RNP
    heterogeneity: HeterogeneityConfig = field(default_factory=HeterogeneityConfig)
    params: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CasKineticsConfig:
    k_deg_per_h: float = 0.2
    k_dil_per_h: float = 0.0


@dataclass(frozen=True)
class GuideConfig:
    id: str
    abundance: float = 1.0
    load_efficiency: float = 1.0  # interpreted as 1/K_i (lower -> loads more)


@dataclass(frozen=True)
class TargetConfig:
    id: str
    grna_id: str
    chr: str
    pos: int
    accessibility: float = 1.0


@dataclass(frozen=True)
class LocusConfig:
    locus_id: str
    copies: int = 2
    allele_accessibility: Sequence[float] = ()


@dataclass(frozen=True)
class PloidyConfig:
    loci: Sequence[LocusConfig] = ()


@dataclass(frozen=True)
class TargetEngagementConfig:
    k_eff_per_h: float = 0.25


@dataclass(frozen=True)
class RepairSaturationConfig:
    Vmax_per_h: float = 2.0
    Km: float = 2.0


@dataclass(frozen=True)
class SVConfig:
    enabled: bool = True
    alpha: float = 1.0
    eps_bp: float = 10.0
    k_sv: float = 0.5
    interchrom_weight: float = 0.05
    inversion_fraction: float = 0.2


@dataclass(frozen=True)
class IndelConfig:
    p_precise_repair: float = 0.1
    small_insertion_weight: float = 0.18
    small_deletion_weight: float = 0.17
    large_deletion_weight: float = 0.10
    small_insertion_min: int = 1
    small_insertion_max: int = 2
    small_deletion_min: int = 1
    small_deletion_max: int = 5
    large_deletion_min: int = 6
    large_deletion_max: int = 20
    large_del_weight_boost: float = 1.0


@dataclass(frozen=True)
class RepairConfig:
    saturation: RepairSaturationConfig = field(default_factory=RepairSaturationConfig)
    sv: SVConfig = field(default_factory=SVConfig)
    indel: IndelConfig = field(default_factory=IndelConfig)


@dataclass(frozen=True)
class DSBToxicityConfig:
    enabled: bool = True
    model: str = "sigmoid"
    max_death_rate_per_h: float = 0.05
    dsb_50: float = 4.0
    slope: float = 1.2


@dataclass(frozen=True)
class FateConfig:
    dsb_toxicity: DSBToxicityConfig = field(default_factory=DSBToxicityConfig)


@dataclass(frozen=True)
class AmpliconConfig:
    id: str
    chr: str
    start: int
    end: int
    locus_id: str | None = None


@dataclass(frozen=True)
class DropoutConfig:
    large_del_threshold_bp: int = 50
    dropout_prob: float = 0.5


@dataclass(frozen=True)
class PCRBiasConfig:
    enabled: bool = False
    weights: Mapping[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class AlignAmbiguityConfig:
    enabled: bool = False
    misclass_prob: float = 0.0


@dataclass(frozen=True)
class MeasurementConfig:
    amplicons: Sequence[AmpliconConfig] = ()
    dropout: DropoutConfig = field(default_factory=DropoutConfig)
    pcr_bias: PCRBiasConfig = field(default_factory=PCRBiasConfig)
    align_ambiguity: AlignAmbiguityConfig = field(default_factory=AlignAmbiguityConfig)


@dataclass(frozen=True)
class CrisprDynamicSimConfig:
    time: TimeConfig = field(default_factory=TimeConfig)
    population: PopulationConfig = field(default_factory=PopulationConfig)
    delivery: DeliveryConfig = field(default_factory=DeliveryConfig)
    cas_kinetics: CasKineticsConfig = field(default_factory=CasKineticsConfig)
    engagement: TargetEngagementConfig = field(default_factory=TargetEngagementConfig)
    repair: RepairConfig = field(default_factory=RepairConfig)
    fate: FateConfig = field(default_factory=FateConfig)
    measurement: MeasurementConfig = field(default_factory=MeasurementConfig)
    grnas: Sequence[GuideConfig] = ()
    targets: Sequence[TargetConfig] = ()
    ploidy: PloidyConfig = field(default_factory=PloidyConfig)

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "CrisprDynamicSimConfig":
        time_raw = dict(raw.get("time") or {})
        pop_raw = dict(raw.get("population") or {})
        delivery_raw = dict(raw.get("delivery") or {})
        cas_raw = dict(raw.get("cas_kinetics") or {})
        engagement_raw = dict(raw.get("target_engagement") or raw.get("engagement") or {})
        repair_raw = dict(raw.get("repair") or {})
        fate_raw = dict(raw.get("fate") or {})
        measurement_raw = dict(raw.get("measurement") or {})

        delivery_mode = _parse_delivery_mode(delivery_raw.get("mode", DeliveryMode.RNP))
        hetero_raw = dict(delivery_raw.get("heterogeneity") or {})

        grnas = [
            GuideConfig(
                id=str(entry["id"]),
                abundance=float(entry.get("abundance", 1.0)),
                load_efficiency=float(entry.get("load_efficiency", 1.0)),
            )
            for entry in list(raw.get("grnas") or [])
        ]
        targets = [
            TargetConfig(
                id=str(entry["id"]),
                grna_id=str(entry["grna_id"]),
                chr=str(entry["chr"]),
                pos=int(entry["pos"]),
                accessibility=float(entry.get("accessibility", 1.0)),
            )
            for entry in list(raw.get("targets") or [])
        ]

        loci_raw = raw.get("ploidy", {}).get("loci") if isinstance(raw.get("ploidy"), dict) else []
        loci: list[LocusConfig] = []
        for entry in list(loci_raw or []):
            allele_accessibility = entry.get("allele_accessibility")
            if allele_accessibility is None:
                allele_accessibility = []
            loci.append(
                LocusConfig(
                    locus_id=str(entry["locus_id"]),
                    copies=int(entry.get("copies", 2)),
                    allele_accessibility=list(float(v) for v in allele_accessibility),
                )
            )

        saturation_raw = dict(repair_raw.get("saturation") or {})
        sv_raw = dict(repair_raw.get("sv") or {})
        indel_raw = dict(repair_raw.get("indel") or {})

        dsb_tox_raw = dict(
            (fate_raw.get("dsb_toxicity") or {}) if isinstance(fate_raw.get("dsb_toxicity"), dict) else {}
        )

        amplicons: list[AmpliconConfig] = []
        for entry in list(measurement_raw.get("amplicons") or []):
            amplicons.append(
                AmpliconConfig(
                    id=str(entry["id"]),
                    chr=str(entry["chr"]),
                    start=int(entry["start"]),
                    end=int(entry["end"]),
                    locus_id=str(entry["locus_id"]) if entry.get("locus_id") is not None else None,
                )
            )
        dropout_raw = dict(measurement_raw.get("dropout") or {})
        pcr_bias_raw = dict(measurement_raw.get("pcr_bias") or {})
        align_raw = dict(measurement_raw.get("align_ambiguity") or {})

        return cls(
            time=TimeConfig(
                dt_h=float(time_raw.get("dt_h", 0.25)),
                t_end_h=float(time_raw.get("t_end_h", 48.0)),
            ),
            population=PopulationConfig(
                n_cells=int(pop_raw.get("n_cells", 1000)),
                seed=int(pop_raw.get("seed", 0)),
            ),
            delivery=DeliveryConfig(
                mode=delivery_mode,
                heterogeneity=HeterogeneityConfig(
                    model=str(hetero_raw.get("model", "lognormal")),
                    params=dict(hetero_raw.get("params") or {}),
                ),
                params=dict(delivery_raw.get("params") or {}),
            ),
            cas_kinetics=CasKineticsConfig(
                k_deg_per_h=float(cas_raw.get("k_deg", cas_raw.get("k_deg_per_h", 0.2))),
                k_dil_per_h=float(cas_raw.get("k_dil", cas_raw.get("k_dil_per_h", 0.0))),
            ),
            engagement=TargetEngagementConfig(
                k_eff_per_h=float(engagement_raw.get("k_eff", engagement_raw.get("k_eff_per_h", 0.25))),
            ),
            repair=RepairConfig(
                saturation=RepairSaturationConfig(
                    Vmax_per_h=float(saturation_raw.get("Vmax", saturation_raw.get("Vmax_per_h", 2.0))),
                    Km=float(saturation_raw.get("Km", 2.0)),
                ),
                sv=SVConfig(
                    enabled=bool(sv_raw.get("enabled", True)),
                    alpha=float(sv_raw.get("alpha", 1.0)),
                    eps_bp=float(sv_raw.get("eps_bp", 10.0)),
                    k_sv=float(sv_raw.get("k_sv", 0.5)),
                    interchrom_weight=float(sv_raw.get("interchrom_weight", 0.05)),
                    inversion_fraction=float(sv_raw.get("inversion_fraction", 0.2)),
                ),
                indel=IndelConfig(
                    p_precise_repair=float(indel_raw.get("p_precise_repair", 0.1)),
                    small_insertion_weight=float(
                        indel_raw.get("small_insertion", indel_raw.get("small_insertion_weight", 0.18))
                    ),
                    small_deletion_weight=float(
                        indel_raw.get("small_deletion", indel_raw.get("small_deletion_weight", 0.17))
                    ),
                    large_deletion_weight=float(
                        indel_raw.get("large_deletion", indel_raw.get("large_deletion_weight", 0.10))
                    ),
                    small_insertion_min=int(indel_raw.get("small_insertion_min", 1)),
                    small_insertion_max=int(indel_raw.get("small_insertion_max", 2)),
                    small_deletion_min=int(indel_raw.get("small_deletion_min", 1)),
                    small_deletion_max=int(indel_raw.get("small_deletion_max", 5)),
                    large_deletion_min=int(indel_raw.get("large_deletion_min", 6)),
                    large_deletion_max=int(indel_raw.get("large_deletion_max", 20)),
                    large_del_weight_boost=float(indel_raw.get("large_del_weight_boost", 1.0)),
                ),
            ),
            fate=FateConfig(
                dsb_toxicity=DSBToxicityConfig(
                    enabled=bool(dsb_tox_raw.get("enabled", True)),
                    model=str(dsb_tox_raw.get("death_rate_fn", dsb_tox_raw.get("model", "sigmoid"))),
                    max_death_rate_per_h=float(dsb_tox_raw.get("max_death_rate_per_h", 0.05)),
                    dsb_50=float(dsb_tox_raw.get("dsb_50", 4.0)),
                    slope=float(dsb_tox_raw.get("slope", 1.2)),
                )
            ),
            measurement=MeasurementConfig(
                amplicons=amplicons,
                dropout=DropoutConfig(
                    large_del_threshold_bp=int(
                        dropout_raw.get("large_del_threshold", dropout_raw.get("large_del_threshold_bp", 50))
                    ),
                    dropout_prob=float(dropout_raw.get("dropout_prob", 0.5)),
                ),
                pcr_bias=PCRBiasConfig(
                    enabled=bool(pcr_bias_raw.get("enabled", False)),
                    weights=dict(pcr_bias_raw.get("weights") or {}),
                ),
                align_ambiguity=AlignAmbiguityConfig(
                    enabled=bool(align_raw.get("enabled", False)),
                    misclass_prob=float(align_raw.get("misclass_prob", 0.0)),
                ),
            ),
            grnas=grnas,
            targets=targets,
            ploidy=PloidyConfig(loci=loci),
        )

    @classmethod
    def from_yaml(cls, raw_yaml: str) -> "CrisprDynamicSimConfig":
        loaded = yaml.safe_load(raw_yaml) or {}
        if not isinstance(loaded, Mapping):
            raise TypeError("Dynamic CRISPR config YAML must parse to a mapping at the top level.")
        return cls.from_dict(loaded)

    @classmethod
    def from_yaml_path(cls, path: str | Path) -> "CrisprDynamicSimConfig":
        config_path = Path(path)
        return cls.from_yaml(config_path.read_text(encoding="utf-8"))

