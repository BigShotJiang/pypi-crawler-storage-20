from __future__ import annotations

import math

from helix.rng import Rng

from .config import DSBToxicityConfig, FateConfig
from .state import CellState
from .utils import clamp01


def _sigmoid(x: float) -> float:
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    z = math.exp(x)
    return z / (1.0 + z)


def _death_rate_per_h(cfg: DSBToxicityConfig, *, dsb_load: int) -> float:
    if not cfg.enabled:
        return 0.0
    model = (cfg.model or "sigmoid").lower()
    if model != "sigmoid":
        raise ValueError(f"Unsupported death_rate_fn model: {cfg.model}")
    slope = float(cfg.slope)
    dsb_50 = float(cfg.dsb_50)
    max_rate = max(0.0, float(cfg.max_death_rate_per_h))
    return max_rate * _sigmoid(slope * (float(dsb_load) - dsb_50))


def fate_step(cell: CellState, cfg: FateConfig, *, dt_h: float, rng: Rng) -> None:
    if not cell.alive:
        return
    dsb_load = cell.active_dsb_count()
    rate = _death_rate_per_h(cfg.dsb_toxicity, dsb_load=dsb_load)
    if rate <= 0.0:
        return
    p_die = 1.0 - math.exp(-rate * dt_h)
    if rng.random() < clamp01(p_die):
        cell.alive = False
