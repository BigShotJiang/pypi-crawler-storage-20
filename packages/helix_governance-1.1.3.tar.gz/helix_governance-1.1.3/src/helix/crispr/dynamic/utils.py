from __future__ import annotations

import math
from typing import Sequence, TypeVar

from helix.rng import Rng

T = TypeVar("T")


def clamp01(value: float) -> float:
    if value <= 0.0:
        return 0.0
    if value >= 1.0:
        return 1.0
    return float(value)


def poisson_sample(lam: float, rng: Rng) -> int:
    if lam <= 0.0:
        return 0
    if lam < 30.0:
        l = math.exp(-lam)
        k = 0
        p = 1.0
        while p > l:
            k += 1
            p *= rng.random()
        return max(0, k - 1)
    z = rng.gauss(0.0, 1.0)
    sample = int(round(lam + math.sqrt(lam) * z))
    return max(0, sample)


def weighted_choice(items: Sequence[T], weights: Sequence[float], rng: Rng) -> T:
    if len(items) != len(weights):
        raise ValueError("items and weights must have the same length")
    total = 0.0
    for w in weights:
        if w < 0.0 or not math.isfinite(w):
            raise ValueError(f"Invalid weight: {w}")
        total += w
    if total <= 0.0:
        raise ValueError("Sum of weights must be > 0")
    r = rng.random() * total
    acc = 0.0
    for item, w in zip(items, weights):
        acc += w
        if r <= acc:
            return item
    return items[-1]
