from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Sequence

from .config import AlignAmbiguityConfig, AmpliconConfig, DropoutConfig, MeasurementConfig, PCRBiasConfig, TargetConfig
from .state import CellState, IndelEdit, StructuralVariantEdit
from .utils import clamp01


@dataclass(frozen=True)
class AmpliconObservation:
    amplicon_id: str
    truth_counts: Mapping[str, float]
    observed_counts: Mapping[str, float]


@dataclass(frozen=True)
class MeasurementResult:
    amplicons: Sequence[AmpliconObservation]


def _edit_overlaps_amplicon(edit_start: int, edit_end: int, amp: AmpliconConfig) -> bool:
    return not (edit_end <= amp.start or edit_start >= amp.end)


def _dropout_multiplier(
    amp: AmpliconConfig,
    *,
    indels: Iterable[IndelEdit],
    svs: Iterable[StructuralVariantEdit],
    cfg: DropoutConfig,
) -> float:
    threshold = int(cfg.large_del_threshold_bp)
    if threshold <= 0:
        return 1.0
    drop_prob = clamp01(cfg.dropout_prob)
    if drop_prob <= 0.0:
        return 1.0

    for indel in indels:
        if indel.kind != "del":
            continue
        if indel.length_bp < threshold:
            continue
        if indel.chrom != amp.chr:
            continue
        if _edit_overlaps_amplicon(indel.start, indel.end, amp):
            return 1.0 - drop_prob

    for sv in svs:
        if sv.kind != "deletion":
            continue
        if sv.length_bp is None or sv.length_bp < threshold:
            continue
        if sv.chrom_a != amp.chr or sv.chrom_b != amp.chr:
            continue
        start = min(sv.pos_a, sv.pos_b)
        end = max(sv.pos_a, sv.pos_b)
        if _edit_overlaps_amplicon(start, end, amp):
            return 1.0 - drop_prob

    return 1.0


def _apply_pcr_bias(label: str, *, cfg: PCRBiasConfig) -> float:
    if not cfg.enabled:
        return 1.0
    weight = float(cfg.weights.get(label, 1.0))
    return max(0.0, weight)


def _apply_alignment_ambiguity(counts: Dict[str, float], *, cfg: AlignAmbiguityConfig) -> Dict[str, float]:
    if not cfg.enabled:
        return counts
    p = clamp01(cfg.misclass_prob)
    if p <= 0.0:
        return counts
    observed: Dict[str, float] = dict(counts)
    wt = observed.get("WT", 0.0)
    for label in list(observed.keys()):
        if label == "WT":
            continue
        moved = observed[label] * p
        observed[label] -= moved
        wt += moved
    observed["WT"] = wt
    return observed


def _amplicon_locus_ids(amp: AmpliconConfig, targets: Sequence[TargetConfig]) -> Sequence[str]:
    if amp.locus_id is not None:
        return [amp.locus_id]
    locus_ids: list[str] = []
    for t in targets:
        if t.chr != amp.chr:
            continue
        if amp.start <= t.pos < amp.end:
            locus_ids.append(t.id)
    return locus_ids


def observe_population(
    *,
    cells: Sequence[CellState],
    targets: Sequence[TargetConfig],
    cfg: MeasurementConfig,
) -> MeasurementResult:
    observations: list[AmpliconObservation] = []
    for amp in cfg.amplicons:
        locus_ids = _amplicon_locus_ids(amp, targets)
        truth: Dict[str, float] = {}
        observed: Dict[str, float] = {}
        for cell in cells:
            if not cell.alive:
                continue
            dropout_mult = _dropout_multiplier(amp, indels=cell.indels, svs=cell.svs, cfg=cfg.dropout)
            for locus_id in locus_ids:
                for label in cell.edited_alleles(locus_id):
                    truth[label] = truth.get(label, 0.0) + 1.0
                    if dropout_mult <= 0.0:
                        continue
                    biased = dropout_mult * _apply_pcr_bias(label, cfg=cfg.pcr_bias)
                    if biased <= 0.0:
                        continue
                    observed[label] = observed.get(label, 0.0) + biased

        observed = _apply_alignment_ambiguity(observed, cfg=cfg.align_ambiguity)
        observations.append(
            AmpliconObservation(
                amplicon_id=amp.id,
                truth_counts=truth,
                observed_counts=observed,
            )
        )
    return MeasurementResult(amplicons=observations)

