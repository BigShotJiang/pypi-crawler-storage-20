from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Mapping, Sequence

from helix.rng import Rng

from .config import CrisprDynamicSimConfig, DeliveryMode, GuideConfig, LocusConfig, TargetConfig
from .fate import fate_step
from .measurement import MeasurementResult, observe_population
from .repair import build_target_index, repair_step
from .state import CellState, Cut, DSB
from .utils import clamp01


@dataclass(frozen=True)
class CrisprDynamicSimResult:
    config: CrisprDynamicSimConfig
    cells: Sequence[CellState]
    measurement: MeasurementResult | None = None

    def edited_fraction(self, locus_id: str) -> float:
        edited = 0
        total = 0
        for cell in self.cells:
            if not cell.alive:
                continue
            alleles = cell.allele_labels.get(locus_id) or []
            for label in alleles:
                total += 1
                if label != "WT":
                    edited += 1
        return edited / total if total else 0.0


def _ploidy_index(cfg: CrisprDynamicSimConfig) -> Dict[str, LocusConfig]:
    return {entry.locus_id: entry for entry in cfg.ploidy.loci}


def _init_alleles(cfg: CrisprDynamicSimConfig) -> Dict[str, List[str]]:
    ploidy = _ploidy_index(cfg)
    result: Dict[str, List[str]] = {}
    for target in cfg.targets:
        locus = ploidy.get(target.id) or LocusConfig(locus_id=target.id, copies=2, allele_accessibility=())
        result[target.id] = ["WT"] * max(1, int(locus.copies))
    return result


def _effective_accessibility(target: TargetConfig, locus_cfg: LocusConfig | None, allele_id: int) -> float:
    a = float(target.accessibility)
    if locus_cfg is None:
        return clamp01(a)
    if locus_cfg.allele_accessibility and 0 <= allele_id < len(locus_cfg.allele_accessibility):
        a *= float(locus_cfg.allele_accessibility[allele_id])
    return clamp01(a)


def _step_cas(cell: CellState, cfg: CrisprDynamicSimConfig, *, dt_h: float, t_h: float) -> None:
    k_total = max(0.0, cfg.cas_kinetics.k_deg_per_h) + max(0.0, cfg.cas_kinetics.k_dil_per_h)

    mode = cfg.delivery.mode
    params = cfg.delivery.params
    scale = cell.uptake_scale

    if mode == DeliveryMode.RNP:
        if t_h == 0.0:
            cell.cas = float(params.get("C0", 1.0)) * scale
        cell.cas *= math.exp(-k_total * dt_h)
        return

    if mode in {DeliveryMode.PLASMID, DeliveryMode.VIRAL}:
        k_expr = float(params.get("k_expr", 0.1)) * scale
        cell.cas += (k_expr - k_total * cell.cas) * dt_h
        if cell.cas < 0.0:
            cell.cas = 0.0
        return

    if mode == DeliveryMode.MRNA:
        if t_h == 0.0:
            cell.mrna = float(params.get("M0", 1.0)) * scale
            cell.cas = float(params.get("C_init", 0.0))
        k_m = float(params.get("k_M", 0.5))
        k_tl = float(params.get("k_tl", 0.5))
        cell.mrna += (-k_m * cell.mrna) * dt_h
        if cell.mrna < 0.0:
            cell.mrna = 0.0
        cell.cas += (k_tl * cell.mrna - k_total * cell.cas) * dt_h
        if cell.cas < 0.0:
            cell.cas = 0.0
        return

    raise ValueError(f"Unsupported delivery mode: {mode}")


def _step_rnp(cell: CellState, guides: Sequence[GuideConfig]) -> None:
    if not guides:
        cell.rnp = {}
        return
    weights: List[float] = []
    ids: List[str] = []
    for g in guides:
        ids.append(g.id)
        kd_inv = 1.0 / max(float(g.load_efficiency), 1e-12)  # K_i = 1/(1/K_i)
        weights.append(max(0.0, float(g.abundance)) * kd_inv)
    wsum = sum(weights)
    if wsum <= 0.0 or cell.cas <= 0.0:
        cell.rnp = {gid: 0.0 for gid in ids}
        return
    cell.rnp = {gid: cell.cas * (w / wsum) for gid, w in zip(ids, weights)}


def _sample_cuts(
    cell: CellState,
    cfg: CrisprDynamicSimConfig,
    *,
    targets: Sequence[TargetConfig],
    ploidy: Mapping[str, LocusConfig],
    dt_h: float,
    t_h: float,
    rng: Rng,
) -> None:
    for target in targets:
        rnp = float(cell.rnp.get(target.grna_id, 0.0))
        if rnp <= 0.0:
            continue
        locus = ploidy.get(target.id)
        allele_labels = cell.allele_labels.get(target.id) or []
        for allele_id, label in enumerate(allele_labels):
            if label != "WT":
                continue
            a = _effective_accessibility(target, locus, allele_id)
            if a <= 0.0:
                continue
            lam = max(0.0, cfg.engagement.k_eff_per_h) * rnp * a
            p = 1.0 - math.exp(-lam * dt_h)
            if rng.random() < p:
                allele_labels[allele_id] = "DSB"
                cell.cuts.append(
                    Cut(
                        target_id=target.id,
                        locus_id=target.id,
                        allele_id=allele_id,
                        chrom=target.chr,
                        pos=target.pos,
                        time_h=t_h,
                    )
                )
                dsb_id = cell.next_dsb_id
                cell.next_dsb_id += 1
                cell.dsbs.append(
                    DSB(
                        dsb_id=dsb_id,
                        locus_id=target.id,
                        allele_id=allele_id,
                        chrom=target.chr,
                        pos=target.pos,
                        time_h=t_h,
                    )
                )


def simulate_crispr_dynamic(config: CrisprDynamicSimConfig) -> CrisprDynamicSimResult:
    rng = Rng(int(config.population.seed), stream_id="crispr:dynamic:population_v1")

    ploidy = _ploidy_index(config)
    targets = list(config.targets)
    guides = list(config.grnas)
    target_index = build_target_index(targets)

    cells: List[CellState] = []
    for _ in range(int(config.population.n_cells)):
        scale = float(config.delivery.heterogeneity.sample_scale(rng=rng))
        cells.append(
            CellState(
                alive=True,
                cas=0.0,
                mrna=0.0,
                rnp={},
                allele_labels=_init_alleles(config),
                cuts=[],
                dsbs=[],
                indels=[],
                svs=[],
                uptake_scale=scale,
                next_dsb_id=0,
            )
        )

    dt_h = float(config.time.dt_h)
    if dt_h <= 0.0:
        raise ValueError("time.dt_h must be > 0")
    t_end = float(config.time.t_end_h)
    if t_end < 0.0:
        raise ValueError("time.t_end_h must be >= 0")

    t_h = 0.0
    while t_h <= t_end + 1e-9:
        for cell in cells:
            if not cell.alive:
                continue
            _step_cas(cell, config, dt_h=dt_h, t_h=t_h)
            _step_rnp(cell, guides)
            _sample_cuts(cell, config, targets=targets, ploidy=ploidy, dt_h=dt_h, t_h=t_h, rng=rng)
            repair_step(cell, config, target_index=target_index, dt_h=dt_h, t_h=t_h, rng=rng)
            fate_step(cell, config.fate, dt_h=dt_h, rng=rng)
        t_h += dt_h

    measurement = observe_population(cells=cells, targets=targets, cfg=config.measurement)
    return CrisprDynamicSimResult(config=config, cells=cells, measurement=measurement)
