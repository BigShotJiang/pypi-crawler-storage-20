from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Sequence


@dataclass(frozen=True)
class Cut:
    target_id: str
    locus_id: str
    allele_id: int
    chrom: str
    pos: int
    time_h: float


@dataclass(frozen=True)
class DSB:
    dsb_id: int
    locus_id: str
    allele_id: int
    chrom: str
    pos: int
    time_h: float


@dataclass(frozen=True)
class IndelEdit:
    locus_id: str
    allele_id: int
    chrom: str
    start: int
    end: int
    kind: str  # ins | del
    length_bp: int
    time_h: float


@dataclass(frozen=True)
class StructuralVariantEdit:
    kind: str  # deletion | inversion | translocation
    chrom_a: str
    pos_a: int
    chrom_b: str
    pos_b: int
    locus_a: str
    allele_a: int
    locus_b: str
    allele_b: int
    length_bp: int | None
    time_h: float


@dataclass
class CellState:
    alive: bool = True
    cas: float = 0.0
    mrna: float = 0.0
    rnp: Dict[str, float] = field(default_factory=dict)
    allele_labels: Dict[str, List[str]] = field(default_factory=dict)
    cuts: List[Cut] = field(default_factory=list)
    dsbs: List[DSB] = field(default_factory=list)
    indels: List[IndelEdit] = field(default_factory=list)
    svs: List[StructuralVariantEdit] = field(default_factory=list)
    uptake_scale: float = 1.0
    next_dsb_id: int = 0

    def active_dsb_count(self) -> int:
        return len(self.dsbs)

    def edited_alleles(self, locus_id: str) -> Sequence[str]:
        return self.allele_labels.get(locus_id) or ()

