from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Sequence, Tuple

from helix.rng import Rng

from .config import CrisprDynamicSimConfig, IndelConfig, SVConfig, TargetConfig
from .state import CellState, DSB, IndelEdit, StructuralVariantEdit
from .utils import clamp01, poisson_sample, weighted_choice


@dataclass(frozen=True)
class TargetIndex:
    by_id: Dict[str, TargetConfig]


def build_target_index(targets: Sequence[TargetConfig]) -> TargetIndex:
    return TargetIndex(by_id={t.id: t for t in targets})


def _indel_weights(cfg: IndelConfig, *, dsb_load: int) -> Tuple[List[str], List[float]]:
    boost = 1.0 + max(0.0, cfg.large_del_weight_boost) * (dsb_load / (1.0 + dsb_load))
    kinds = ["small_insertion", "small_deletion", "large_deletion"]
    weights = [
        max(0.0, cfg.small_insertion_weight),
        max(0.0, cfg.small_deletion_weight),
        max(0.0, cfg.large_deletion_weight) * boost,
    ]
    return kinds, weights


def _apply_local_repair(
    cell: CellState,
    dsb: DSB,
    *,
    indel_cfg: IndelConfig,
    target: TargetConfig | None,
    t_h: float,
    rng: Rng,
) -> None:
    locus_id = dsb.locus_id
    allele_id = dsb.allele_id
    labels = cell.allele_labels.get(locus_id)
    if labels is None or not (0 <= allele_id < len(labels)):
        return

    p_precise = clamp01(indel_cfg.p_precise_repair)
    if rng.random() < p_precise:
        labels[allele_id] = "WT"
        return

    dsb_load = max(0, cell.active_dsb_count())
    kinds, weights = _indel_weights(indel_cfg, dsb_load=dsb_load)
    outcome = weighted_choice(kinds, weights, rng)

    chrom = target.chr if target is not None else dsb.chrom
    cut_pos = int(target.pos) if target is not None else int(dsb.pos)

    if outcome == "small_insertion":
        length = rng.randint(indel_cfg.small_insertion_min, indel_cfg.small_insertion_max)
        start = cut_pos
        end = cut_pos
        cell.indels.append(
            IndelEdit(
                locus_id=locus_id,
                allele_id=allele_id,
                chrom=chrom,
                start=start,
                end=end,
                kind="ins",
                length_bp=length,
                time_h=t_h,
            )
        )
        labels[allele_id] = "INDEL"
        return

    if outcome == "small_deletion":
        length = rng.randint(indel_cfg.small_deletion_min, indel_cfg.small_deletion_max)
    else:
        length = rng.randint(indel_cfg.large_deletion_min, indel_cfg.large_deletion_max)
    start = max(0, cut_pos - length // 2)
    end = start + length
    cell.indels.append(
        IndelEdit(
            locus_id=locus_id,
            allele_id=allele_id,
            chrom=chrom,
            start=start,
            end=end,
            kind="del",
            length_bp=length,
            time_h=t_h,
        )
    )
    labels[allele_id] = "INDEL"


def _sv_pair_weights(dsbs: Sequence[DSB], sv_cfg: SVConfig) -> Tuple[List[Tuple[int, int]], List[float]]:
    pairs: List[Tuple[int, int]] = []
    weights: List[float] = []
    alpha = max(0.0, float(sv_cfg.alpha))
    eps = max(0.0, float(sv_cfg.eps_bp))
    inter_w = max(0.0, float(sv_cfg.interchrom_weight))
    for i in range(len(dsbs)):
        for j in range(i + 1, len(dsbs)):
            a = dsbs[i]
            b = dsbs[j]
            if a.chrom != b.chrom:
                w = inter_w
            else:
                dist = abs(int(a.pos) - int(b.pos))
                w = (dist + eps) ** (-alpha) if alpha > 0.0 else 1.0
            if w <= 0.0 or not math.isfinite(w):
                continue
            pairs.append((i, j))
            weights.append(float(w))
    return pairs, weights


def _apply_sv_repair(
    cell: CellState,
    dsb_a: DSB,
    dsb_b: DSB,
    *,
    sv_cfg: SVConfig,
    t_h: float,
    rng: Rng,
) -> None:
    if dsb_a.chrom != dsb_b.chrom:
        kind = "translocation"
        length_bp: int | None = None
        label = "SV_TRA"
    else:
        length_bp = abs(int(dsb_a.pos) - int(dsb_b.pos))
        if rng.random() < clamp01(sv_cfg.inversion_fraction):
            kind = "inversion"
            label = "SV_INV"
        else:
            kind = "deletion"
            label = "SV_DEL"

    cell.svs.append(
        StructuralVariantEdit(
            kind=kind,
            chrom_a=dsb_a.chrom,
            pos_a=int(dsb_a.pos),
            chrom_b=dsb_b.chrom,
            pos_b=int(dsb_b.pos),
            locus_a=dsb_a.locus_id,
            allele_a=dsb_a.allele_id,
            locus_b=dsb_b.locus_id,
            allele_b=dsb_b.allele_id,
            length_bp=length_bp,
            time_h=t_h,
        )
    )

    for dsb, allele_label in ((dsb_a, label), (dsb_b, label)):
        labels = cell.allele_labels.get(dsb.locus_id)
        if labels is None:
            continue
        if 0 <= dsb.allele_id < len(labels):
            labels[dsb.allele_id] = allele_label


def repair_step(
    cell: CellState,
    cfg: CrisprDynamicSimConfig,
    *,
    target_index: TargetIndex,
    dt_h: float,
    t_h: float,
    rng: Rng,
) -> None:
    D = cell.active_dsb_count()
    if D <= 0:
        return

    vmax = max(0.0, cfg.repair.saturation.Vmax_per_h)
    km = max(0.0, cfg.repair.saturation.Km)
    join_rate = vmax * D / (km + D) if vmax > 0.0 else 0.0
    events = poisson_sample(join_rate * dt_h, rng)
    if events <= 0:
        return

    while events > 0 and cell.dsbs:
        D = cell.active_dsb_count()
        if D <= 0:
            break
        p_sv = 0.0
        if cfg.repair.sv.enabled and D >= 2:
            p_sv = clamp01(max(0.0, cfg.repair.sv.k_sv) * (D / (1.0 + D)))

        if p_sv > 0.0 and rng.random() < p_sv:
            pairs, weights = _sv_pair_weights(cell.dsbs, cfg.repair.sv)
            if pairs and weights:
                i, j = weighted_choice(pairs, weights, rng)
                dsb_a = cell.dsbs[i]
                dsb_b = cell.dsbs[j]
                for idx in sorted((i, j), reverse=True):
                    del cell.dsbs[idx]
                _apply_sv_repair(cell, dsb_a, dsb_b, sv_cfg=cfg.repair.sv, t_h=t_h, rng=rng)
                events -= 1
                continue

        dsb = cell.dsbs.pop(rng.randrange(len(cell.dsbs)))
        target = target_index.by_id.get(dsb.locus_id)
        _apply_local_repair(cell, dsb, indel_cfg=cfg.repair.indel, target=target, t_h=t_h, rng=rng)
        events -= 1
