"""Contract helpers for CTMC tau-leap parity (CPU reference ↔ GPU backend).

This module defines:
- which *summary metrics* must be reproduced by the CUDA backend
- tolerances for statistical parity

The CPU implementation in :mod:`helix.crispr.ctmc_tau_leap` remains the source
of truth for event semantics and RNG schedule.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class ParityMetric:
    key: str
    abs_tol: float


PARITY_METRICS_V1: tuple[ParityMetric, ...] = (
    ParityMetric("no_cut_prob", abs_tol=5e-4),
    ParityMetric("edit_prob", abs_tol=5e-4),
    ParityMetric("intended_prob", abs_tol=5e-4),
    ParityMetric("frameshift_prob", abs_tol=5e-4),
    ParityMetric("dsb_unrepaired_prob", abs_tol=5e-4),
    ParityMetric("ko_cells_prob", abs_tol=5e-4),
    ParityMetric("mosaicism_shannon_bits", abs_tol=2e-2),
    ParityMetric("dsb_state_frac", abs_tol=5e-4),
    ParityMetric("dsb_age_mean", abs_tol=1e-3),
    ParityMetric("pathway_frac_given_cut.NHEJ", abs_tol=5e-4),
    ParityMetric("pathway_frac_given_cut.ALTEJ", abs_tol=5e-4),
    ParityMetric("pathway_frac_given_cut.HDR_PRECISE", abs_tol=5e-4),
    ParityMetric("pathway_frac_given_cut.SSA", abs_tol=5e-4),
    ParityMetric("pathway_frac_given_cut.UNREPAIRED", abs_tol=5e-4),
    ParityMetric("pathway_frac_given_repair.NHEJ", abs_tol=5e-4),
    ParityMetric("pathway_frac_given_repair.ALTEJ", abs_tol=5e-4),
    ParityMetric("pathway_frac_given_repair.HDR_PRECISE", abs_tol=5e-4),
    ParityMetric("pathway_frac_given_repair.SSA", abs_tol=5e-4),
    ParityMetric("chromatin_state_frac.OPEN", abs_tol=5e-4),
    ParityMetric("chromatin_state_frac.TRANSIENT", abs_tol=5e-4),
    ParityMetric("chromatin_state_frac.REFRACTORY", abs_tol=5e-4),
)


def _as_float(value: Any) -> float | None:
    try:
        return float(value)
    except Exception:
        return None


def flatten_tau_leap_summary(summary: Mapping[str, Any]) -> dict[str, float]:
    """Flatten the nested tau-leap per-replicate summary into scalar metrics."""

    out: dict[str, float] = {}
    for key in (
        "no_cut_prob",
        "edit_prob",
        "intended_prob",
        "frameshift_prob",
        "dsb_unrepaired_prob",
        "ko_cells_prob",
        "mosaicism_shannon_bits",
        "dsb_state_frac",
        "dsb_age_mean",
    ):
        v = _as_float(summary.get(key))
        if v is not None:
            out[key] = v

    def _flatten_dict(prefix: str, obj: Any) -> None:
        if not isinstance(obj, Mapping):
            return
        for k, v in obj.items():
            fv = _as_float(v)
            if fv is None:
                continue
            out[f"{prefix}.{k}"] = fv

    _flatten_dict("pathway_frac_given_cut", summary.get("pathway_frac_given_cut"))
    _flatten_dict("pathway_frac_given_repair", summary.get("pathway_frac_given_repair"))
    _flatten_dict("chromatin_state_frac", summary.get("chromatin_state_frac"))
    return out


def required_parity_keys() -> set[str]:
    return {m.key for m in PARITY_METRICS_V1}

