"""CRISPR cut/repair simulation."""
from __future__ import annotations

import hashlib
import json
import logging
import math
import os
from collections.abc import Mapping, Sequence
from bisect import bisect_left
from typing import Any, Dict, Tuple

from .. import bioinformatics
from .. import entropy
from ..clock import deterministic_utc_iso, utc_now_iso
from ..rng import Rng, derive_seed
from ..sim.posterior import (
    CredibleInterval,
    OffTargetBurden,
    TailRiskSummary,
    build_posterior,
)
from .coords import COORDINATE_SYSTEM, focus_index
from . import score as crispr_score

LOGGER = logging.getLogger(__name__)

DEFAULT_PRIORS = {
    "no_cut": {"weight": 0.55},
    "small_insertion": {"weight": 0.18, "min": 1, "max": 2},
    "small_deletion": {"weight": 0.17, "min": 1, "max": 5},
    "large_deletion": {"weight": 0.10, "min": 6, "max": 20},
}

CRISPR_PRIOR_PROFILES: Dict[str, Dict[str, Dict[str, float]]] = {
    "default_indel": DEFAULT_PRIORS,
    "scarless": {
        "no_cut": {"weight": 0.7},
        "small_insertion": {"weight": 0.15, "min": 1, "max": 1},
        "small_deletion": {"weight": 0.1, "min": 1, "max": 3},
        "microhomology_del": {"weight": 0.05, "min": 3, "max": 10},
    },
    "indel_heavy": {
        "small_insertion": {"weight": 0.35, "min": 1, "max": 4},
        "small_deletion": {"weight": 0.35, "min": 1, "max": 8},
        "large_deletion": {"weight": 0.25, "min": 8, "max": 40},
        "no_cut": {"weight": 0.05},
    },
    "hdr_only": {
        "no_cut": {"weight": 0.1},
        "scarless_hdr": {"weight": 0.9},
    },
}


def _sequence_sha(sequence: str) -> str:
    return hashlib.sha256(sequence.encode("utf-8")).hexdigest()


def _normalize_priors(priors: Mapping[str, Mapping[str, float]] | None) -> Dict[str, Dict[str, float]]:
    priors = priors or DEFAULT_PRIORS
    return {label: dict(config) for label, config in priors.items()}


def _seed_or_entropy(seed: int | None) -> int:
    if seed is None:
        if os.getenv("HELIX_DETERMINISTIC"):
            raise ValueError("seed is required in deterministic mode")
        return int.from_bytes(entropy.token_bytes(8), "big")
    return int(seed)


def _stable_run_id(*parts: object) -> str:
    payload = ":".join(str(part) for part in parts).encode("utf-8")
    return hashlib.blake2b(payload, digest_size=8).hexdigest()


def _cut_position(guide: Mapping[str, object]) -> int:
    if guide.get("cut_index") is not None:
        return int(guide.get("cut_index") or 0)
    if guide.get("anchor_index") is not None:
        return int(guide.get("anchor_index") or 0)
    start = int(guide.get("start", 0))
    end = int(guide.get("end", start))
    strand = guide.get("strand", "+")
    if strand == "+":
        return max(start, end - 3)
    return min(end, start + 3)


def _sample_diff(label: str, rng: Rng, cut_pos: int, site_len: int, config: Mapping[str, float]) -> Dict[str, object] | None:
    if label == "no_cut":
        return None
    if label == "small_insertion":
        length = rng.randint(int(config.get("min", 1)), int(config.get("max", 2)))
        return {"start": cut_pos, "end": cut_pos, "edit": f"ins{length}"}
    if label in {"small_deletion", "large_deletion"}:
        length = rng.randint(int(config.get("min", 1)), int(config.get("max", 10)))
        start = max(0, cut_pos - length // 2)
        end = min(site_len, start + length)
        return {"start": start, "end": end, "edit": f"del{length}"}
    return {"start": cut_pos, "end": cut_pos, "edit": label}


def _compute_off_target_burden(
    site_seq: str,
    guide: Mapping[str, object],
    pam_profile: str | None,
) -> OffTargetBurden:
    burden, _hits = _compute_off_target_burden_with_hits(site_seq, guide, pam_profile)
    return burden


def _compute_off_target_burden_with_hits(
    site_seq: str,
    guide: Mapping[str, object],
    pam_profile: str | None,
) -> tuple[OffTargetBurden, list[dict[str, Any]]]:
    pam_token = (pam_profile or guide.get("pam") or guide.get("pam_profile"))
    pam_token = str(pam_token or "").strip()
    guide_seq = str(guide.get("sequence") or "").strip().upper()
    if not guide_seq:
        has_span = guide.get("start") is not None and guide.get("end") is not None
        if not has_span:
            return OffTargetBurden(
                status="not_computed",
                executed_mode="not_computed",
                calibration_status="not_computed",
                reason="missing_guide_sequence",
            ), []
    if not pam_token:
        return OffTargetBurden(
            status="not_computed",
            executed_mode="not_computed",
            calibration_status="not_computed",
            reason="missing_pam_profile",
        ), []

    try:
        hits = crispr_score.enumerate_off_targets(site_seq, guide, pam_token, max_mm=3)
        scored = crispr_score.score_off_targets(hits, crispr_score.DEFAULT_WEIGHTS["off_target"])
    except Exception as exc:
        return OffTargetBurden(
            status="not_computed",
            executed_mode="not_computed",
            calibration_status="not_computed",
            reason=f"off_target_error:{exc.__class__.__name__}",
        ), []

    candidates = [
        float(hit.get("score") or 0.0)
        for hit in scored
        if int(hit.get("distance") or 0) > 0
    ]

    scored_hits: list[dict[str, Any]] = []
    guide_start = guide.get("start")
    guide_end = guide.get("end")
    guide_strand = guide.get("strand")
    for hit in scored:
        try:
            distance = int(hit.get("distance") or 0)
        except Exception:
            distance = 0
        if distance <= 0:
            continue
        hit_copy = dict(hit)
        hit_copy.setdefault("pam", pam_token)
        if guide_start is not None and guide_end is not None and guide_strand is not None:
            try:
                is_intended = (
                    int(hit_copy.get("start", -1)) == int(guide_start)
                    and int(hit_copy.get("end", -1)) == int(guide_end)
                    and str(hit_copy.get("strand") or "") == str(guide_strand)
                )
            except Exception:
                is_intended = False
            if is_intended:
                continue
        try:
            cut_idx = _cut_position(hit_copy)
        except Exception:
            cut_idx = None
        if cut_idx is not None:
            hit_copy.setdefault("cut_index", int(cut_idx))
            hit_copy.setdefault("pos", int(cut_idx))
        scored_hits.append(hit_copy)

    mean = sum(candidates)
    var = sum(p * (1.0 - p) for p in candidates)
    std = math.sqrt(max(var, 0.0))
    z = 1.64  # ~90% interval for a normal proxy
    lower = max(0.0, mean - z * std)
    upper_bound = max(1.0, float(len(candidates)))
    upper = min(upper_bound, mean + z * std)

    tail_val = max(candidates) if candidates else 0.0

    expected = CredibleInterval(mean=mean, lower=lower, upper=upper, level=0.9)
    tail = TailRiskSummary(
        metric="max_candidate_score",
        value=tail_val,
        notes="Window-local off-target proxy; genome-wide sweep not yet computed.",
    )

    burden = OffTargetBurden(
        status="computed",
        executed_mode="window_local",
        calibration_status="uncalibrated",
        provider_id="crispr.enumerate_off_targets.v0",
        expected_cuts=expected,
        tail_risk=tail,
    )
    return burden, scored_hits


def resolve_crispr_priors(profile: str | None) -> Dict[str, Dict[str, float]]:
    """Map a profile name to a normalized priors configuration."""

    key = (profile or "default_indel").strip() or "default_indel"
    try:
        template = CRISPR_PRIOR_PROFILES[key]
    except KeyError as exc:
        raise ValueError(f"Unknown CRISPR priors profile: {key}") from exc
    return {label: dict(config) for label, config in template.items()}


def simulate_cut_repair(
    site_seq: str,
    guide: Mapping[str, object],
    priors: Mapping[str, Mapping[str, float]] | None = None,
    *,
    draws: int = 1000,
    seed: int | None = None,
    emit_sequence: bool = False,
    pam_mask: Sequence[float] | None = None,
    pam_profile: str | None = None,
    off_target_mode: str | None = None,
    experiment_spec: Mapping[str, Any] | None = None,
    edit_plan: Mapping[str, Any] | None = None,
    edit_spec: Mapping[str, Any] | None = None,
    context: Mapping[str, Any] | None = None,
    evidence: Mapping[str, Any] | None = None,
) -> Dict[str, object]:
    """Sample a simple multinomial outcome distribution for CRISPR cut/repair."""

    if draws <= 0:
        raise ValueError("draws must be > 0.")

    seed_value = _seed_or_entropy(seed)
    run_id = _stable_run_id("crispr.sim", seed_value, guide.get("id"), draws)
    LOGGER.debug(
        "simulate_cut_repair start: guide=%s draws=%s seed=%s run_id=%s",
        guide.get("id"),
        draws,
        seed_value,
        run_id,
    )
    normalized_site = bioinformatics.normalize_sequence(site_seq)
    site_len = len(normalized_site)
    normalized_priors = _normalize_priors(priors)
    if not normalized_priors:
        raise ValueError("priors must contain at least one entry.")

    cut_pos = _cut_position(guide)
    if not (0 <= cut_pos <= site_len):
        raise ValueError(f"Computed cut position {cut_pos} invalid for sequence length {site_len}.")

    pam_factor = 1.0
    if pam_mask is not None:
        if len(pam_mask) != site_len:
            raise ValueError(f"pam_mask length {len(pam_mask)} does not match site length {site_len}.")
        pam_factor = max(0.0, min(1.0, float(pam_mask[cut_pos])))
        if not math.isfinite(pam_factor):
            raise ValueError("pam_mask values must be finite.")

    labels: list[str] = []
    weights: list[float] = []
    for label, config in normalized_priors.items():
        if "weight" not in config:
            raise ValueError(f"Prior '{label}' missing 'weight'.")
        weight = float(config["weight"])
        if not (math.isfinite(weight) and weight >= 0.0):
            raise ValueError(f"Prior '{label}' has invalid weight {weight}.")
        labels.append(label)
        weights.append(weight)

    total_weight = sum(weights)
    if total_weight <= 0.0:
        raise ValueError("Sum of prior weights must be > 0.")

    efficacies = [weight * pam_factor for weight in weights]
    total_efficacy = sum(efficacies)
    if total_efficacy <= 0.0:
        raise ValueError(
            f"Effective weights at cut_pos={cut_pos} are zero; PAM profile forbids cutting at this site."
        )

    cumulative: list[float] = []
    acc = 0.0
    for value in efficacies:
        acc += value
        cumulative.append(acc)

    rng_counts = Rng(seed_value, stream_id="crispr:counts_v1")
    diff_rngs = {label: Rng(derive_seed(seed_value, label), stream_id=f"crispr:diff:{label}") for label in labels}

    counts = {label: 0 for label in labels}
    diffs: Dict[str, Dict[str, object] | None] = {label: None for label in labels}
    for draw_idx in range(draws):
        r = rng_counts.random() * total_efficacy
        idx = bisect_left(cumulative, r)
        if idx >= len(labels):
            idx = len(labels) - 1
        label = labels[idx]
        counts[label] += 1
        if diffs[label] is None:
            diffs[label] = _sample_diff(label, diff_rngs[label], cut_pos, site_len, normalized_priors[label])

        if LOGGER.isEnabledFor(logging.DEBUG) and (draw_idx + 1) % 1000 == 0:
            LOGGER.debug(
                "simulate_cut_repair progress: %s/%s draws (run_id=%s)",
                draw_idx + 1,
                draws,
                run_id,
            )

    outcomes = []
    for label in labels:
        count = counts[label]
        probability = count / draws if draws else 0.0
        outcomes.append(
            {
                "label": label,
                "count": count,
                "probability": round(probability, 4),
                "diff": diffs[label],
            }
        )
    outcomes.sort(key=lambda entry: (-entry["count"], entry["label"]))

    site_block = {"length": site_len, "sequence_sha256": _sequence_sha(normalized_site)}
    if emit_sequence:
        site_block["sequence"] = normalized_site

    guide_block = {
        "id": guide.get("id"),
        "start": guide.get("start"),
        "end": guide.get("end"),
        "strand": guide.get("strand"),
        "gc_content": guide.get("gc_content"),
        "coordinate_system": COORDINATE_SYSTEM,
    }
    anchor_index = guide.get("anchor_index")
    cut_index = guide.get("cut_index")
    guide_block["anchor_index"] = int(anchor_index) if anchor_index is not None else None
    guide_block["cut_index"] = int(cut_index) if cut_index is not None else None
    if anchor_index is not None:
        try:
            guide_block["focus_index"] = int(
                focus_index(int(cut_index) if cut_index is not None else None, int(anchor_index))
            )
        except Exception:
            guide_block["focus_index"] = int(cut_index) if cut_index is not None else int(anchor_index)
    else:
        guide_block["focus_index"] = None
    if emit_sequence:
        guide_block["sequence"] = guide.get("sequence")

    on_target_payload: dict[str, object] | None = None
    try:
        from .model import CasSystem, CasSystemType, GuideRNA, PAMRule, TargetSite
        from .on_target import evaluate as evaluate_on_target, get_scorer
        from .physics import create_crispr_physics, _encode_sequence_to_uint8
        from .pam import PAM_MOTIFS

        guide_start_raw = guide.get("start", 0)
        guide_end_raw = guide.get("end", guide_start_raw)
        guide_start = int(guide_start_raw) if guide_start_raw is not None else 0
        guide_end = int(guide_end_raw) if guide_end_raw is not None else int(guide_start)
        guide_start = max(0, min(site_len, guide_start))
        guide_end = max(guide_start, min(site_len, guide_end))
        if guide_end <= guide_start:
            raise ValueError("guide_span_invalid")

        strand_raw = str(guide.get("strand") or "+")
        strand = -1 if strand_raw.strip().startswith("-") else 1
        window_plus = normalized_site[guide_start:guide_end]
        if not window_plus:
            raise ValueError("guide_window_empty")
        target_seq = window_plus if strand > 0 else bioinformatics.reverse_complement(window_plus)

        guide_seq_candidate = bioinformatics.normalize_sequence(str(guide.get("sequence") or ""))
        guide_seq = guide_seq_candidate if guide_seq_candidate and len(guide_seq_candidate) == len(target_seq) else target_seq

        pam_token = str(pam_profile or guide.get("pam_profile") or guide.get("pam") or guide.get("pam_seq") or "")
        pam_token = pam_token.strip() or "SpCas9_NGG"
        pam_key = pam_token.replace("-", "_")
        motif = PAM_MOTIFS.get(pam_key) or PAM_MOTIFS.get(pam_token)
        if motif is None:
            candidate = pam_token.upper()
            motif = candidate if candidate and candidate.isalpha() else "NGG"

        cas = CasSystem(
            name=str(pam_token),
            system_type=CasSystemType.CAS9,
            pam_rules=[PAMRule(pattern=str(motif), description="from pam_profile")],
            cut_offset=3,
        )
        guide_obj = GuideRNA(sequence=guide_seq, pam=str(motif), name=str(guide.get("id") or "guide"))

        physics = create_crispr_physics(cas, guide_obj, use_gpu=False)
        encoded = _encode_sequence_to_uint8(target_seq)
        physics_score = float(physics.on_target_score_encoded(encoded, pam_penalty=0.0))

        site_obj = TargetSite(
            chrom="target",
            start=int(guide_start),
            end=int(guide_end),
            strand=int(strand),
            sequence=str(target_seq),
            on_target_score=float(physics_score),
        )
        scorer = get_scorer()
        on_target = evaluate_on_target(scorer, guide=guide_obj, site=site_obj, cas=cas)
        on_target_payload = on_target.to_dict()
    except Exception as exc:
        try:
            from .on_target import OnTargetEngineResult, get_score_to_prob

            score_to_prob = get_score_to_prob()
            engine_id = (os.environ.get("HELIX_ON_TARGET_ENGINE") or "unknown").strip() or "unknown"
            on_target_payload = OnTargetEngineResult(
                raw_score=0.0,
                p_edit=float(score_to_prob.min_p),
                novelty=1.0,
                ood=True,
                engine_id=str(engine_id),
                engine_version="unknown",
                model_hash="none",
                features={"reason": f"on_target_error:{type(exc).__name__}"},
            ).to_dict()
        except Exception:
            on_target_payload = None

    payload = {
        "schema": {"kind": "crispr.sim", "spec_version": "1.0", "schema_version": 1},
        "meta": {
            "timestamp": deterministic_utc_iso() if os.getenv("HELIX_DETERMINISTIC") else utc_now_iso(),
            "seed": seed_value,
            "run_id": run_id,
            "weights_sum": total_efficacy,
            "pam_mask_scale": pam_factor,
        },
        "site": site_block,
        "guide": guide_block,
        "on_target": on_target_payload,
        "priors": normalized_priors,
        "draws": draws,
        "outcomes": outcomes,
    }
    base_edit_spec = {
        "kind": "crispr_cut_repair",
        "guide": dict(guide_block),
        "site": dict(site_block),
    }
    edit_spec_payload = dict(edit_spec or {})
    edit_spec_payload.setdefault("kind", base_edit_spec["kind"])
    edit_spec_payload.setdefault("guide", base_edit_spec["guide"])
    edit_spec_payload.setdefault("site", base_edit_spec["site"])
    if experiment_spec is not None:
        edit_spec_payload.setdefault("experiment_spec", dict(experiment_spec))
    if edit_plan is not None:
        edit_spec_payload.setdefault("edit_plan", dict(edit_plan))

    context_payload = dict(context or {})
    context_payload.setdefault("priors", normalized_priors)
    context_payload.setdefault("pam_mask_scale", pam_factor)

    evidence_payload = dict(evidence) if isinstance(evidence, Mapping) else None

    mode = str(off_target_mode or "").strip().lower()
    offtarget_hits: list[dict[str, Any]] = []
    if mode in {"none", "off", "disabled", "no"}:
        off_target = OffTargetBurden(
            status="not_computed",
            executed_mode="not_computed",
            calibration_status="not_computed",
            reason="disabled_by_mode",
        )
    else:
        off_target, offtarget_hits = _compute_off_target_burden_with_hits(normalized_site, guide, pam_profile)
    payload["offtarget_hits"] = offtarget_hits

    posterior = build_posterior(
        outcomes,
        draws=draws,
        model_id="crispr_cut_repair_stub",
        model_version="1.0",
        model_kind="monte_carlo_stub",
        model_notes="Multinomial priors over indel categories.",
        edit_spec=edit_spec_payload,
        context=context_payload,
        evidence=evidence_payload,
        off_target=off_target,
        calibration_status="uncalibrated",
    )
    posterior_payload = posterior.to_dict()
    prior_strength = 10.0
    trials = 64
    planner_seed = 0
    try:
        from ..sim.experiment_planner import (
            DEFAULT_ASSAY_READS,
            build_planner_trace,
            build_planner_trace_not_computed,
            recommend_next_experiment,
        )
    except Exception as exc:
        posterior_payload["planner_trace"] = {
            "planner_version": "v0_entropy_proxy_dirichlet",
            "status": "not_computed",
            "objective": "entropy_reduction",
            "reason": "entropy_proxy",
            "recommendation_reason": "planner_import_failed",
            "note": "entropy proxy (in silico), not a wet-lab protocol instruction",
            "inputs_hash": "sha256:unavailable",
            "posterior_hash": "sha256:unavailable",
            "candidates_hash": "sha256:unavailable",
            "ranked_candidates": [],
            "error": str(exc),
        }
    else:
        try:
            rec = recommend_next_experiment(
                posterior,
                assays=DEFAULT_ASSAY_READS,
                prior_strength=prior_strength,
                trials=trials,
                seed=planner_seed,
            )
            posterior_payload["planner_trace"] = build_planner_trace(
                posterior_payload=posterior_payload,
                recommendation=rec,
                assay_candidates=DEFAULT_ASSAY_READS,
                prior_strength=prior_strength,
                trials=trials,
                seed=planner_seed,
            )
        except Exception as exc:
            posterior_payload["planner_trace"] = build_planner_trace_not_computed(
                posterior_payload=posterior_payload,
                assay_candidates=DEFAULT_ASSAY_READS,
                prior_strength=prior_strength,
                trials=trials,
                seed=planner_seed,
                error=str(exc),
            )
    payload["posterior"] = posterior_payload
    LOGGER.debug(
        "simulate_cut_repair completed: guide=%s top_outcome=%s run_id=%s",
        guide.get("id"),
        outcomes[0]["label"] if outcomes else None,
        run_id,
    )
    return json.loads(json.dumps(payload))
