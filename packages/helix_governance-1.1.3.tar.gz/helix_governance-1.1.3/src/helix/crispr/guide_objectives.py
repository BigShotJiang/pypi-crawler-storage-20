from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, MutableMapping, Sequence


_DIRECTION_VALUES = {"minimize", "maximize"}


@dataclass(frozen=True)
class GuideObjective:
    name: str
    direction: str
    weight: float | None = None
    priority: int | None = None
    source: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip():
            raise ValueError("GuideObjective.name must be a non-empty string.")
        direction = str(self.direction or "").strip().lower()
        if direction not in _DIRECTION_VALUES:
            raise ValueError(f"GuideObjective.direction must be one of {sorted(_DIRECTION_VALUES)}.")


def _norm(value: Any) -> str:
    return str(value or "").strip().lower()


def parse_guide_objectives(payload: Mapping[str, Any] | None) -> list[GuideObjective]:
    """Parse a guideObjectives payload into a normalized objective list."""
    payload = payload if isinstance(payload, Mapping) else {}
    block = payload.get("guideObjectives") if isinstance(payload.get("guideObjectives"), Mapping) else payload
    if not isinstance(block, Mapping):
        return []
    raw = block.get("objectives")
    if not isinstance(raw, list):
        return []
    out: list[GuideObjective] = []
    for entry in raw:
        if not isinstance(entry, Mapping):
            continue
        name = str(entry.get("name") or "").strip()
        direction = _norm(entry.get("direction") or "")
        if not direction:
            direction = "minimize"
        weight = entry.get("weight")
        priority = entry.get("priority")
        source = entry.get("source")
        try:
            weight_val = float(weight) if weight is not None else None
        except Exception:
            weight_val = None
        try:
            priority_val = int(priority) if priority is not None else None
        except Exception:
            priority_val = None
        source_val = str(source).strip() if isinstance(source, str) and source.strip() else None
        if not name:
            continue
        try:
            out.append(
                GuideObjective(
                    name=name,
                    direction=direction,
                    weight=weight_val,
                    priority=priority_val,
                    source=source_val,
                )
            )
        except Exception:
            continue
    return out


def _gc_fraction(seq: str) -> float:
    seq = str(seq or "").upper()
    if not seq:
        return 0.0
    valid = [b for b in seq if b in {"A", "C", "G", "T"}]
    if not valid:
        return 0.0
    gc = sum(1 for b in valid if b in {"G", "C"})
    return float(gc) / float(len(valid))


def _reverse_complement(seq: str) -> str:
    comp = {"A": "T", "C": "G", "G": "C", "T": "A"}
    return "".join(comp.get(b, "N") for b in reversed(str(seq or "").upper()))


def rna_hairpin_max_stem(seq: str, *, min_loop: int = 3) -> int:
    """Cheap guide RNA structure proxy: longest reverse-complement stem with a loop gap."""
    s = str(seq or "").upper()
    if not s:
        return 0
    if any(b not in {"A", "C", "G", "T"} for b in s):
        return 0
    n = len(s)
    if n < 4:
        return 0
    rc = _reverse_complement(s)
    best = 0

    for i in range(n):
        for j in range(n):
            k = 0
            while i + k < n and j + k < n and s[i + k] == rc[j + k]:
                k += 1
            if k <= best:
                continue
            seg1_end = i + k - 1
            seg2_start = n - (j + k)
            loop_len = seg2_start - seg1_end - 1
            if loop_len >= int(min_loop):
                best = k
    return int(best)


def compute_guide_metrics(
    guide: Mapping[str, Any],
    *,
    target_index_abs: int | None = None,
    end_window: int = 5,
) -> dict[str, Any]:
    """Compute an explicit, JSON-friendly metric vector for a guide candidate."""
    seq = str(guide.get("sequence") or "").upper()
    gc = float(guide.get("gc_content") or _gc_fraction(seq))
    gc_dev = abs(gc - 0.5)
    cut_abs = guide.get("abs_cut_index")
    if cut_abs is None:
        cut_abs = guide.get("cut_index")
    try:
        cut_abs_int = int(cut_abs) if cut_abs is not None else None
    except Exception:
        cut_abs_int = None
    dist = None
    if cut_abs_int is not None and target_index_abs is not None:
        dist = abs(int(cut_abs_int) - int(target_index_abs))

    k = max(1, min(int(end_window), len(seq))) if seq else 1
    gc_5 = _gc_fraction(seq[:k]) if seq else 0.0
    gc_3 = _gc_fraction(seq[-k:]) if seq else 0.0
    end_skew = abs(gc_5 - gc_3)

    frameshift = guide.get("frameshift_fraction")
    try:
        frameshift_val = float(frameshift) if frameshift is not None else None
    except Exception:
        frameshift_val = None

    ot_worst = guide.get("offtarget_worst_score")
    try:
        ot_worst_val = float(ot_worst) if ot_worst is not None else None
    except Exception:
        ot_worst_val = None

    ot_burden = guide.get("offtarget_burden")
    try:
        ot_burden_val = float(ot_burden) if ot_burden is not None else None
    except Exception:
        ot_burden_val = None

    return {
        "distance_to_target": dist,
        "gc_fraction": round(float(gc), 6),
        "gc_deviation": round(float(gc_dev), 6),
        "pam_quality": 1.0,
        "rna_hairpin_max_stem": int(rna_hairpin_max_stem(seq, min_loop=3)) if seq else 0,
        "rna_end_gc_skew": round(float(end_skew), 6),
        "frameshift_fraction": frameshift_val,
        "offtarget_worst_score": ot_worst_val,
        "offtarget_burden": ot_burden_val,
        "intent_alignment": frameshift_val,
    }


def _objective_value(metrics: Mapping[str, Any], objective: GuideObjective) -> float | None:
    raw = metrics.get(objective.name)
    if raw is None:
        return None
    try:
        return float(raw)
    except Exception:
        return None


def _dominates(
    a: Mapping[str, Any],
    b: Mapping[str, Any],
    objectives: Sequence[GuideObjective],
) -> bool:
    any_strict = False
    for obj in objectives:
        a_val = _objective_value(a, obj)
        b_val = _objective_value(b, obj)
        if a_val is None or b_val is None:
            return False
        if obj.direction == "maximize":
            if a_val < b_val:
                return False
            if a_val > b_val:
                any_strict = True
        else:
            if a_val > b_val:
                return False
            if a_val < b_val:
                any_strict = True
    return any_strict


def pareto_front_ranks(
    metrics_list: Sequence[Mapping[str, Any]],
    objectives: Sequence[GuideObjective],
) -> list[int | None]:
    """Compute Pareto front ranks (0 = non-dominated) for a set of metric vectors."""
    n = len(metrics_list)
    if n == 0:
        return []
    if not objectives:
        return [None for _ in metrics_list]

    unresolved = list(range(n))
    ranks: list[int | None] = [None for _ in range(n)]
    front = 0

    while unresolved:
        flags = [True] * len(unresolved)
        for i, idx_i in enumerate(unresolved):
            if not flags[i]:
                continue
            vi = metrics_list[idx_i]
            # Require all objective metrics to be present for Pareto participation.
            if any(_objective_value(vi, obj) is None for obj in objectives):
                flags[i] = False
                continue
            for j, idx_j in enumerate(unresolved):
                if i == j:
                    continue
                vj = metrics_list[idx_j]
                if _dominates(vj, vi, objectives):
                    flags[i] = False
                    break

        picked = [unresolved[i] for i, keep in enumerate(flags) if keep]
        if not picked:
            break
        for idx in picked:
            ranks[idx] = front
        picked_set = set(picked)
        unresolved = [idx for idx in unresolved if idx not in picked_set]
        front += 1

    return ranks


def annotate_guides_with_metrics(
    guides: Sequence[MutableMapping[str, Any]],
    *,
    target_index_abs: int | None = None,
    end_window: int = 5,
    key: str = "metrics",
) -> None:
    """In-place helper to attach metric vectors to guide mappings."""
    for guide in guides:
        guide[key] = compute_guide_metrics(guide, target_index_abs=target_index_abs, end_window=end_window)


DEFAULT_GUIDE_OBJECTIVES_V1: list[GuideObjective] = [
    GuideObjective(name="frameshift_fraction", direction="maximize", source="proxy"),
    GuideObjective(name="offtarget_worst_score", direction="minimize", source="proxy"),
    GuideObjective(name="gc_deviation", direction="minimize", source="derived"),
    GuideObjective(name="distance_to_target", direction="minimize", source="derived"),
    GuideObjective(name="rna_hairpin_max_stem", direction="minimize", source="proxy"),
]


__all__ = [
    "DEFAULT_GUIDE_OBJECTIVES_V1",
    "GuideObjective",
    "annotate_guides_with_metrics",
    "compute_guide_metrics",
    "parse_guide_objectives",
    "pareto_front_ranks",
    "rna_hairpin_max_stem",
]
