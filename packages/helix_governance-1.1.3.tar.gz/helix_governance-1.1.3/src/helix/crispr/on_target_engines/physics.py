from __future__ import annotations

from ..model import CasSystem, GuideRNA, TargetSite
from ..on_target import OnTargetEngineResult, get_score_to_prob, register_scorer
from ..physics import CRISPR_SCORING_VERSION


class PhysicsOnTargetScorer:
    """
    Adapter around the existing CRISPR physics output.

    Expects the candidate `TargetSite` already has `on_target_score` populated.
    """

    name = "physics"

    def score(self, *, guide: GuideRNA, site: TargetSite, cas: CasSystem) -> float:
        _ = guide, cas
        value = site.on_target_score
        if value is None:
            raise RuntimeError("PhysicsOnTargetScorer requires site.on_target_score to be populated")
        return float(value)

    def evaluate(self, *, guide: GuideRNA, site: TargetSite, cas: CasSystem) -> OnTargetEngineResult:
        raw = self.score(guide=guide, site=site, cas=cas)
        p_edit = get_score_to_prob().to_prob(raw)
        return OnTargetEngineResult(
            raw_score=float(raw),
            p_edit=float(p_edit),
            novelty=0.0,
            ood=False,
            engine_id=self.name,
            engine_version=CRISPR_SCORING_VERSION,
            model_hash="builtin",
            features={"physics_version": CRISPR_SCORING_VERSION},
        )


register_scorer(PhysicsOnTargetScorer())
