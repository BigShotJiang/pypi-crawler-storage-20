from __future__ import annotations

import hashlib
import json
import os
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from ...nussinov_algorithm import fold_to_dot_bracket
from ..model import CasSystem, GuideRNA, TargetSite
from ..on_target import OnTargetEngineResult, get_score_to_prob, register_scorer
from ..ontargetx import encoding
from ..physics import CRISPR_SCORING_VERSION

ENGINE_ID = "ontargetx"
ENGINE_VERSION = "0.1.0"

FORMAT_VERSION = "helix_ontargetx_bundle_v1"

_SINGLE_THREAD_ENV_KEYS = (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
    "VECLIB_MAXIMUM_THREADS",
    "BLIS_NUM_THREADS",
)


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[4]


def _allowed_bundle_roots() -> list[Path]:
    raw = (
        os.environ.get("HELIX_ONTARGETX_ALLOWED_DIRS")
        or os.environ.get("HELIX_ONTARGETX_ALLOWED_DIR")
        or ""
    ).strip()
    if raw:
        roots: list[Path] = []
        for part in raw.split(os.pathsep):
            text = part.strip()
            if text:
                roots.append(Path(text).expanduser().resolve())
        return roots

    # Default: restrict bundles to within the repo /models tree.
    return [_repo_root() / "models"]


def _realpath_strict(path: Path) -> Path:
    return path.expanduser().resolve(strict=True)


def _allowed_bundle_roots_real() -> list[Path]:
    roots: list[Path] = []
    for root in _allowed_bundle_roots():
        try:
            resolved = _realpath_strict(root)
        except FileNotFoundError:
            continue
        if not resolved.is_absolute():
            continue
        if not resolved.is_dir():
            continue
        roots.append(resolved)
    return roots


def _require_allowed_bundle_path(path: Path) -> None:
    """
    Refuse bundle files outside allowlisted directories (symlink-safe).

    Uses real path resolution (`resolve(strict=True)`) for both the candidate and
    allowlisted roots, then checks containment via `Path.is_relative_to`.

    Note: This check is applied to *both* bundle files (bundle.json and tensors.npz)
    to prevent symlink escapes from an otherwise-allowed bundle directory.
    """

    allowed_roots = _allowed_bundle_roots_real()
    if not allowed_roots:
        raise PermissionError(
            "OnTargetX bundle allowlist is empty (no existing allowed directories). "
            "Set HELIX_ONTARGETX_ALLOWED_DIRS/HELIX_ONTARGETX_ALLOWED_DIR to permit a bundle path."
        )

    if _truthy(os.environ.get("HELIX_ONTARGETX_DENY_SYMLINKS") or "0"):
        raw = Path(path).expanduser()
        if not raw.is_absolute():
            raw = raw.absolute()
        for p in (raw, *raw.parents):
            try:
                if p.is_symlink():
                    raise PermissionError(
                        "OnTargetX bundle path contains a symlink. "
                        "Refusing to load because HELIX_ONTARGETX_DENY_SYMLINKS=1."
                    )
            except PermissionError:
                raise
            except Exception:
                # Best-effort: if we cannot stat a parent, keep checking containment via realpaths.
                continue

    candidate = _realpath_strict(Path(path))
    if not candidate.is_absolute():
        raise PermissionError("OnTargetX bundle path must resolve to an absolute path")
    if candidate.is_dir():
        raise PermissionError("OnTargetX bundle allowlist expects a file path (bundle.json or tensors.npz), got a directory")
    for root in allowed_roots:
        if candidate.is_relative_to(root):
            return
    raise PermissionError(
        "OnTargetX bundle path is not in an allowed directory. "
        "Set HELIX_ONTARGETX_ALLOWED_DIRS/HELIX_ONTARGETX_ALLOWED_DIR to permit it."
    )


def _sha256_concat_files(a: Path, b: Path) -> str:
    """Return sha256(meta_bytes + tensors_bytes) without loading both into RAM."""

    hasher = hashlib.sha256()
    with a.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    with b.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def _resolve_npz_bundle_paths(raw_path: str) -> tuple[Path, Path, Path]:
    """Resolve (bundle_root, meta_path, tensors_path) for the npz+json format."""

    bundle_path = Path(raw_path).expanduser()
    if bundle_path.is_dir():
        base = bundle_path
        return base, base / "bundle.json", base / "tensors.npz"

    base = bundle_path.parent
    suffix = bundle_path.suffix.lower()
    if suffix == ".npz":
        return base, bundle_path.with_suffix(".json"), bundle_path
    if suffix == ".json":
        return base, bundle_path, bundle_path.with_suffix(".npz")
    raise ValueError("OnTargetX bundle must be a directory, *.npz, or *.json (npz+json format).")


def _load_json(path: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, dict):
        raise TypeError("bundle.json must contain a JSON object")
    return data


def _validate_bundle_meta(meta: dict[str, Any]) -> dict[str, Any]:
    allowed = {
        "schema_version",
        "engine_id",
        "engine_version",
        "distance_metric",
        "embedding_norm",
        "knn_k",
        "knn_block_size",
        "ood_distance_threshold",
        "max_ref_embeddings",
    }
    unknown = set(meta) - allowed
    if unknown:
        raise ValueError("Unknown bundle metadata keys: " + ", ".join(sorted(unknown)))

    schema_version = str(meta.get("schema_version") or "").strip()
    if schema_version != FORMAT_VERSION:
        raise ValueError(f"Unsupported OnTargetX bundle schema_version: {schema_version!r}")

    engine_id = str(meta.get("engine_id") or "").strip()
    if engine_id != ENGINE_ID:
        raise ValueError(f"bundle engine_id must be {ENGINE_ID!r}, got {engine_id!r}")

    engine_version = str(meta.get("engine_version") or "").strip()
    if not engine_version:
        raise ValueError("bundle engine_version is required")

    distance_metric = str(meta.get("distance_metric") or "").strip().lower()
    if distance_metric not in {"euclidean", "cosine"}:
        raise ValueError("distance_metric must be 'euclidean' or 'cosine'")

    embedding_norm = str(meta.get("embedding_norm") or "").strip().lower()
    if embedding_norm not in {"none", "l2"}:
        raise ValueError("embedding_norm must be 'none' or 'l2'")

    if distance_metric == "cosine" and embedding_norm != "l2":
        raise ValueError("cosine distance requires embedding_norm='l2'")

    knn_k = meta.get("knn_k", 32)
    try:
        knn_k_int = int(knn_k)
    except Exception as exc:
        raise ValueError("knn_k must be an int") from exc
    if knn_k_int <= 0:
        raise ValueError("knn_k must be > 0")

    knn_block = meta.get("knn_block_size", None)
    knn_block_int: int | None
    if knn_block is None:
        knn_block_int = None
    else:
        try:
            knn_block_int = int(knn_block)
        except Exception as exc:
            raise ValueError("knn_block_size must be an int") from exc
        if knn_block_int <= 0:
            knn_block_int = None

    threshold = meta.get("ood_distance_threshold")
    if threshold is None:
        raise ValueError("ood_distance_threshold is required")
    try:
        threshold_f = float(threshold)
    except Exception as exc:
        raise ValueError("ood_distance_threshold must be a float") from exc
    if not (threshold_f > 0.0) or not np.isfinite(np.asarray(threshold_f, dtype=np.float32)):
        raise ValueError("ood_distance_threshold must be > 0")

    max_ref = meta.get("max_ref_embeddings", None)
    max_ref_int: int | None
    if max_ref is None:
        max_ref_int = None
    else:
        try:
            max_ref_int = int(max_ref)
        except Exception as exc:
            raise ValueError("max_ref_embeddings must be an int") from exc
        if max_ref_int <= 0:
            max_ref_int = None

    return {
        "schema_version": schema_version,
        "engine_id": engine_id,
        "engine_version": engine_version,
        "distance_metric": distance_metric,
        "embedding_norm": embedding_norm,
        "knn_k": knn_k_int,
        "knn_block_size": knn_block_int,
        "ood_distance_threshold": threshold_f,
        "max_ref_embeddings": max_ref_int,
    }


def _load_npz_arrays(path: Path) -> dict[str, np.ndarray]:
    max_bytes_raw = (os.environ.get("HELIX_ONTARGETX_MAX_TENSORS_NPZ_BYTES") or "").strip()
    try:
        max_bytes = int(max_bytes_raw) if max_bytes_raw else 512 * 1024 * 1024  # 512 MiB default
    except Exception:
        max_bytes = 512 * 1024 * 1024
    if max_bytes > 0:
        size = int(path.stat().st_size)
        if size > max_bytes:
            raise ValueError(
                f"tensors.npz exceeds size limit: {size} bytes > {max_bytes} (HELIX_ONTARGETX_MAX_TENSORS_NPZ_BYTES)"
            )

    max_uncompressed_raw = (os.environ.get("HELIX_ONTARGETX_MAX_TENSORS_UNCOMPRESSED_BYTES") or "").strip()
    try:
        max_uncompressed = int(max_uncompressed_raw) if max_uncompressed_raw else 2 * 1024 * 1024 * 1024  # 2 GiB default
    except Exception:
        max_uncompressed = 2 * 1024 * 1024 * 1024
    if max_uncompressed > 0:
        try:
            with zipfile.ZipFile(path) as zf:
                total = 0
                for info in zf.infolist():
                    total += int(getattr(info, "file_size", 0))
            if total > max_uncompressed:
                raise ValueError(
                    f"tensors.npz exceeds uncompressed limit: {total} bytes > {max_uncompressed} "
                    "(HELIX_ONTARGETX_MAX_TENSORS_UNCOMPRESSED_BYTES)"
                )
        except ValueError:
            raise
        except Exception:
            # Best-effort: if the zip can't be inspected (corrupt), np.load will fail and we report bundle_invalid.
            pass

    with np.load(path, allow_pickle=False) as loaded:
        arrays: dict[str, np.ndarray] = {}
        for key in loaded.files:
            arrays[str(key)] = np.asarray(loaded[key])
        return arrays


def _validate_bundle_arrays(arrays: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    allowed = {"token_embedding", "residual_weight", "residual_bias", "ref_embeddings"}
    unknown = set(arrays) - allowed
    if unknown:
        raise ValueError("Unknown bundle tensor keys: " + ", ".join(sorted(unknown)))
    missing = allowed - set(arrays)
    if missing:
        raise ValueError("Missing bundle tensor keys: " + ", ".join(sorted(missing)))

    token_emb = np.asarray(arrays["token_embedding"])
    ref_embeddings = np.asarray(arrays["ref_embeddings"])
    residual_weight = np.asarray(arrays["residual_weight"])
    residual_bias_arr = np.asarray(arrays["residual_bias"])

    if token_emb.dtype != np.float32:
        raise ValueError("token_embedding must be float32")
    if ref_embeddings.dtype != np.float32:
        raise ValueError("ref_embeddings must be float32")
    if residual_weight.dtype != np.float32:
        raise ValueError("residual_weight must be float32")
    if residual_bias_arr.dtype != np.float32:
        raise ValueError("residual_bias must be float32")

    if token_emb.ndim != 2 or int(token_emb.shape[0]) != encoding.VOCAB_SIZE:
        raise ValueError(
            f"token_embedding must have shape ({encoding.VOCAB_SIZE}, D), got {tuple(token_emb.shape)}"
        )
    d_model = int(token_emb.shape[1])
    if d_model <= 0:
        raise ValueError("token_embedding D must be > 0")

    if residual_weight.shape != (d_model,):
        raise ValueError("residual_weight must have shape (D,) matching token_embedding dim")

    if residual_bias_arr.ndim == 0:
        residual_bias = float(residual_bias_arr)
    elif residual_bias_arr.shape == (1,):
        residual_bias = float(residual_bias_arr.reshape(()))
    else:
        raise ValueError("residual_bias must be a scalar or shape (1,)")

    if ref_embeddings.ndim != 2 or int(ref_embeddings.shape[1]) != d_model:
        raise ValueError("ref_embeddings must have shape (N, D) matching token_embedding dim")
    if int(ref_embeddings.shape[0]) <= 0:
        raise ValueError("ref_embeddings must have N > 0")

    # Fail fast if any tensor contains NaN/inf (prevents subtle scoring drift).
    for name, arr in (
        ("token_embedding", token_emb),
        ("residual_weight", residual_weight),
        ("ref_embeddings", ref_embeddings),
    ):
        if not np.isfinite(arr).all():
            raise ValueError(f"{name} must not contain NaN/inf")
    if not np.isfinite(np.asarray(residual_bias, dtype=np.float32)):
        raise ValueError("residual_bias must not be NaN/inf")

    return {
        "token_embedding": token_emb,
        "residual_weight": residual_weight,
        "residual_bias": np.asarray(residual_bias, dtype=np.float32),
        "ref_embeddings": ref_embeddings,
    }


def _truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


class _EnvOverride:
    def __init__(self, mapping: dict[str, str]) -> None:
        self._mapping = dict(mapping)
        self._prior: dict[str, str | None] = {}

    def __enter__(self):
        for k, v in self._mapping.items():
            self._prior[k] = os.environ.get(k)
            os.environ[k] = str(v)
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        for k, prev in self._prior.items():
            if prev is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = prev
        return False


def _single_thread_numpy() -> _EnvOverride:
    """
    Best-effort determinism guard for BLAS-backed NumPy ops.

    Note: Some BLAS libraries read these env vars only at process start.
    We still apply them here because it is cheap, explicit, and can help in common builds.
    """

    if not _truthy(os.environ.get("HELIX_ONTARGETX_FORCE_SINGLE_THREAD") or "1"):
        return _EnvOverride({})
    return _EnvOverride({k: "1" for k in _SINGLE_THREAD_ENV_KEYS})


def _knn_distance_mean(
    *,
    embedding: np.ndarray,
    ref_embeddings: np.ndarray,
    ref_sq_norms: np.ndarray | None,
    metric: str,
    k: int,
    block_size: int | None = None,
) -> np.float32:
    """
    Deterministic kNN distance (mean of k nearest distances) in float32.

    - `embedding` must be (D,) float32
    - `ref_embeddings` must be (N, D) float32
    - `ref_sq_norms` is optional (N,) float32 for Euclidean metric
    - `metric` is "euclidean" or "cosine"
    """

    if ref_embeddings.size == 0:
        return np.asarray(np.inf, dtype=np.float32)

    emb = np.asarray(embedding, dtype=np.float32)
    ref = np.asarray(ref_embeddings, dtype=np.float32)
    n_ref = int(ref.shape[0])

    k_int = int(k)
    if k_int <= 1:
        k_int = 1
    k_int = min(k_int, n_ref)

    block_int = None
    if block_size is not None:
        try:
            block_int = int(block_size)
        except Exception:
            block_int = None
    if block_int is not None and block_int <= 0:
        block_int = None

    if block_int is None or block_int >= n_ref:
        # Vectorized distances; keep dtype pinned to float32 for determinism.
        if metric == "cosine":
            dots = ref @ emb
            dists = np.asarray(1.0, dtype=np.float32) - dots.astype(np.float32, copy=False)
        else:
            ref_sq = (
                np.asarray(ref_sq_norms, dtype=np.float32)
                if isinstance(ref_sq_norms, np.ndarray) and ref_sq_norms.shape == (n_ref,) and ref_sq_norms.dtype == np.float32
                else np.sum(ref * ref, axis=1, dtype=np.float32)
            )
            emb_sq = np.sum(emb * emb, dtype=np.float32)
            dots = ref @ emb
            d2 = (ref_sq + emb_sq - (np.asarray(2.0, dtype=np.float32) * dots.astype(np.float32, copy=False))).astype(
                np.float32, copy=False
            )
            d2 = np.maximum(d2, np.asarray(0.0, dtype=np.float32))
            dists = np.sqrt(d2, dtype=np.float32)

        if dists.size == 0:
            return np.asarray(np.inf, dtype=np.float32)
        if k_int == 1:
            return np.asarray(dists.min(initial=np.inf), dtype=np.float32)
        smallest = np.partition(dists, k_int - 1)[:k_int]
        return np.asarray(np.mean(smallest, dtype=np.float32), dtype=np.float32)

    # Chunked computation: keep only k best per block, then merge.
    best: np.ndarray | None = None
    emb_sq = np.sum(emb * emb, dtype=np.float32) if metric == "euclidean" else np.asarray(0.0, dtype=np.float32)
    ref_sq_all = None
    if metric == "euclidean" and isinstance(ref_sq_norms, np.ndarray) and ref_sq_norms.shape == (n_ref,) and ref_sq_norms.dtype == np.float32:
        ref_sq_all = ref_sq_norms

    for start in range(0, n_ref, int(block_int)):
        end = min(n_ref, start + int(block_int))
        ref_block = ref[start:end]
        if metric == "cosine":
            dots = ref_block @ emb
            dists = np.asarray(1.0, dtype=np.float32) - dots.astype(np.float32, copy=False)
        else:
            ref_sq_block = (
                ref_sq_all[start:end] if ref_sq_all is not None else np.sum(ref_block * ref_block, axis=1, dtype=np.float32)
            )
            dots = ref_block @ emb
            d2 = (ref_sq_block + emb_sq - (np.asarray(2.0, dtype=np.float32) * dots.astype(np.float32, copy=False))).astype(
                np.float32, copy=False
            )
            d2 = np.maximum(d2, np.asarray(0.0, dtype=np.float32))
            dists = np.sqrt(d2, dtype=np.float32)

        if dists.size == 0:
            continue
        if k_int == 1:
            block_best = np.asarray(dists.min(initial=np.inf), dtype=np.float32).reshape((1,))
        elif int(dists.shape[0]) <= k_int:
            block_best = dists.astype(np.float32, copy=False)
        else:
            block_best = np.partition(dists, k_int - 1)[:k_int].astype(np.float32, copy=False)

        if best is None:
            best = block_best
        else:
            combined = np.concatenate((best, block_best), axis=0)
            if int(combined.shape[0]) <= k_int:
                best = combined.astype(np.float32, copy=False)
            else:
                best = np.partition(combined, k_int - 1)[:k_int].astype(np.float32, copy=False)

    if best is None or best.size == 0:
        return np.asarray(np.inf, dtype=np.float32)
    if k_int == 1:
        return np.asarray(best.min(initial=np.inf), dtype=np.float32)
    return np.asarray(np.mean(best, dtype=np.float32), dtype=np.float32)


def _l2_normalize_rows(matrix: np.ndarray, *, eps: float = 1e-12) -> np.ndarray:
    denom = np.sqrt(np.sum(matrix * matrix, axis=1, keepdims=True))
    denom = np.maximum(denom, np.asarray(eps, dtype=matrix.dtype))
    return matrix / denom


def _l2_normalize_vec(vec: np.ndarray, *, eps: float = 1e-12) -> np.ndarray:
    denom = float(np.sqrt(np.sum(vec * vec)))
    denom = max(denom, eps)
    return vec / np.asarray(denom, dtype=vec.dtype)


@dataclass(frozen=True, slots=True)
class _Bundle:
    bundle_root: Path
    meta_path: Path
    tensors_path: Path
    engine_version: str
    model_hash: str
    distance_metric: str
    embedding_norm: str
    token_embedding: np.ndarray  # (VOCAB_SIZE, D) float32
    residual_weight: np.ndarray  # (D,) float32
    residual_bias: float
    ref_embeddings: np.ndarray  # (N, D) float32
    ref_sq_norms: np.ndarray | None
    knn_k: int
    knn_block_size: int | None
    ood_distance_threshold: float
    ref_total: int
    ref_used: int


_BUNDLE_CACHE: dict[str, _Bundle] = {}
_BUNDLE_PATH_CACHE: dict[str, tuple[int, int, int, int, _Bundle]] = {}


def _load_bundle(path: str) -> _Bundle:
    bundle_root, meta_path, tensors_path = _resolve_npz_bundle_paths(path)
    # Symlink-safe allowlist: validate both bundle files, not just the directory.
    _require_allowed_bundle_path(meta_path)
    _require_allowed_bundle_path(tensors_path)
    bundle_root_real = _realpath_strict(bundle_root)
    meta_real = _realpath_strict(meta_path)
    tensors_real = _realpath_strict(tensors_path)

    if not meta_path.exists():
        raise FileNotFoundError(str(meta_path))
    if not tensors_path.exists():
        raise FileNotFoundError(str(tensors_path))

    meta_stat = meta_path.stat()
    tensors_stat = tensors_path.stat()

    cache_key = str(bundle_root_real)
    cached_by_path = _BUNDLE_PATH_CACHE.get(cache_key)
    if cached_by_path is not None:
        meta_mtime_ns, meta_size, tensors_mtime_ns, tensors_size, bundle = cached_by_path
        if (
            meta_mtime_ns == int(meta_stat.st_mtime_ns)
            and meta_size == int(meta_stat.st_size)
            and tensors_mtime_ns == int(tensors_stat.st_mtime_ns)
            and tensors_size == int(tensors_stat.st_size)
        ):
            return bundle

    model_hash = _sha256_concat_files(meta_path, tensors_path)
    cached_by_hash = _BUNDLE_CACHE.get(model_hash)
    if cached_by_hash is not None:
        _BUNDLE_PATH_CACHE[cache_key] = (
            int(meta_stat.st_mtime_ns),
            int(meta_stat.st_size),
            int(tensors_stat.st_mtime_ns),
            int(tensors_stat.st_size),
            cached_by_hash,
        )
        return cached_by_hash

    raw_meta = _load_json(meta_path)
    has_knn_block_size = "knn_block_size" in raw_meta
    meta = _validate_bundle_meta(raw_meta)
    arrays = _validate_bundle_arrays(_load_npz_arrays(tensors_path))

    token_embedding = arrays["token_embedding"]
    residual_weight = arrays["residual_weight"]
    residual_bias = float(arrays["residual_bias"])
    ref_embeddings = arrays["ref_embeddings"]
    ref_total = int(ref_embeddings.shape[0])

    max_ref = meta.get("max_ref_embeddings")
    if max_ref is None:
        max_ref_env = (os.environ.get("HELIX_ONTARGETX_MAX_REF") or "").strip()
        try:
            max_ref = int(max_ref_env) if max_ref_env else None
        except Exception:
            max_ref = None
    if max_ref is not None and ref_total > int(max_ref) > 0:
        idx = np.linspace(0, ref_total - 1, num=int(max_ref), dtype=np.int64)
        ref_embeddings = ref_embeddings[idx]
    ref_used = int(ref_embeddings.shape[0])

    distance_metric = str(meta["distance_metric"])
    embedding_norm = str(meta["embedding_norm"])

    knn_block_size = meta.get("knn_block_size")
    if knn_block_size is None and not has_knn_block_size:
        raw_block = (os.environ.get("HELIX_ONTARGETX_KNN_BLOCK_SIZE") or "").strip()
        if raw_block:
            try:
                knn_block_size = int(raw_block)
            except Exception:
                knn_block_size = None
        else:
            knn_block_size = 16_384
    if knn_block_size is not None and int(knn_block_size) <= 0:
        knn_block_size = None

    if embedding_norm == "l2":
        ref_embeddings = _l2_normalize_rows(ref_embeddings)

    ref_sq_norms: np.ndarray | None = None
    if distance_metric == "euclidean":
        ref_sq_norms = np.sum(ref_embeddings * ref_embeddings, axis=1).astype(np.float32, copy=False)

    bundle = _Bundle(
        bundle_root=bundle_root_real,
        meta_path=meta_real,
        tensors_path=tensors_real,
        engine_version=str(meta["engine_version"]),
        model_hash=model_hash,
        distance_metric=distance_metric,
        embedding_norm=embedding_norm,
        token_embedding=token_embedding,
        residual_weight=residual_weight,
        residual_bias=float(residual_bias),
        ref_embeddings=ref_embeddings,
        ref_sq_norms=ref_sq_norms,
        knn_k=max(1, min(int(meta["knn_k"]), ref_used)),
        knn_block_size=int(knn_block_size) if knn_block_size is not None else None,
        ood_distance_threshold=float(meta["ood_distance_threshold"]),
        ref_total=ref_total,
        ref_used=ref_used,
    )
    _BUNDLE_CACHE[model_hash] = bundle
    _BUNDLE_PATH_CACHE[cache_key] = (
        int(meta_stat.st_mtime_ns),
        int(meta_stat.st_size),
        int(tensors_stat.st_mtime_ns),
        int(tensors_stat.st_size),
        bundle,
    )
    return bundle


def _encoding_only_result(*, physics_score: float, reason: str) -> OnTargetEngineResult:
    score_to_prob = get_score_to_prob()
    p_edit = score_to_prob.to_prob(float(physics_score))
    return OnTargetEngineResult(
        raw_score=float(physics_score),
        p_edit=float(p_edit),
        novelty=1.0,
        ood=True,
        engine_id=ENGINE_ID,
        engine_version=f"{ENGINE_VERSION}+encoding_only",
        model_hash="none",
        features={
            "mode": "encoding_only",
            "reason": str(reason),
            "physics_score": float(physics_score),
            "physics_version": CRISPR_SCORING_VERSION,
        },
    )


class OnTargetXOnTargetScorer:
    """
    Hybrid on-target scorer: physics baseline + residual NN, plus novelty/OOD sensing.

    Bundle contract (non-executable npz+json):
      - directory layout: {bundle.json, tensors.npz}

    bundle.json fields (strict, no unknown keys):
      - schema_version: "helix_ontargetx_bundle_v1"
      - engine_id: "ontargetx"
      - engine_version: str
      - distance_metric: "euclidean" | "cosine"
      - embedding_norm: "none" | "l2"  (cosine requires l2)
      - knn_k: int (optional, default 32)
      - knn_block_size: int (optional; chunk size for kNN, default 16384 when unspecified)
      - ood_distance_threshold: float (>0)
      - max_ref_embeddings: int (optional)

    tensors.npz arrays (float32, strict, no unknown keys):
      - token_embedding: (VOCAB_SIZE, D)
      - residual_weight: (D,)
      - residual_bias: scalar
      - ref_embeddings: (N, D)
    """

    name = ENGINE_ID

    def score(self, *, guide: GuideRNA, site: TargetSite, cas: CasSystem) -> float:
        return float(self.evaluate(guide=guide, site=site, cas=cas).raw_score)

    def evaluate(self, *, guide: GuideRNA, site: TargetSite, cas: CasSystem) -> OnTargetEngineResult:
        _ = cas

        physics_score_raw = site.on_target_score
        if physics_score_raw is None:
            raise RuntimeError("OnTargetXOnTargetScorer requires site.on_target_score to be populated")
        physics_score = float(physics_score_raw)
        bundle_path = (os.environ.get("HELIX_ONTARGETX_BUNDLE") or "").strip()
        if not bundle_path:
            return _encoding_only_result(physics_score=physics_score, reason="bundle_missing")

        try:
            bundle = _load_bundle(bundle_path)
        except PermissionError:
            return _encoding_only_result(physics_score=physics_score, reason="bundle_path_not_allowed")
        except FileNotFoundError:
            return _encoding_only_result(physics_score=physics_score, reason="bundle_not_found")
        except Exception as exc:
            return _encoding_only_result(physics_score=physics_score, reason=f"bundle_invalid:{type(exc).__name__}")

        dot_bracket = fold_to_dot_bracket(guide.sequence)
        packed = encoding.make_tokens_and_bias(site.sequence, guide.sequence, dot_bracket)
        tokens = packed.tokens.astype(np.int64, copy=False)

        tok_embed = bundle.token_embedding[tokens]  # (L, D)
        mean_all = tok_embed.mean(axis=0, dtype=np.float32).astype(np.float32, copy=False)

        rna_len = len(dot_bracket)
        paired_mean = np.zeros_like(mean_all)
        if rna_len:
            paired_mask = np.fromiter((ch != "." for ch in dot_bracket), dtype=np.bool_, count=rna_len)
            if bool(paired_mask.any()):
                rna_embed = tok_embed[packed.rna_start : packed.rna_end, :]
                paired_mean = rna_embed[paired_mask, :].mean(axis=0, dtype=np.float32).astype(np.float32, copy=False)

        embedding = (mean_all + paired_mean).astype(np.float32, copy=False)
        if bundle.embedding_norm == "l2":
            embedding = _l2_normalize_vec(embedding)

        threshold = np.asarray(bundle.ood_distance_threshold, dtype=np.float32)
        with _single_thread_numpy():
            knn_distance_f32 = _knn_distance_mean(
                embedding=embedding,
                ref_embeddings=bundle.ref_embeddings,
                ref_sq_norms=bundle.ref_sq_norms,
                metric=str(bundle.distance_metric),
                k=int(bundle.knn_k),
                block_size=bundle.knn_block_size,
            )
            residual = np.sum(embedding * bundle.residual_weight, dtype=np.float32) + np.asarray(bundle.residual_bias, dtype=np.float32)

        if not np.isfinite(knn_distance_f32):
            novelty = 1.0
            ood = True
            knn_distance = float("inf")
        else:
            knn_distance = float(knn_distance_f32)
            ratio = np.asarray(knn_distance_f32 / threshold, dtype=np.float32)
            novelty = float(np.clip(ratio, 0.0, 1.0))
            ood = bool(knn_distance_f32 > threshold)

        residual = float(np.asarray(residual, dtype=np.float32))
        residual_scale = 0.0 if ood else max(0.0, 1.0 - float(novelty))
        residual_applied = residual * residual_scale

        raw_score = physics_score + residual_applied
        if raw_score < 0.0:
            raw_score = 0.0
        if raw_score > 1.0:
            raw_score = 1.0

        score_to_prob = get_score_to_prob()
        p_edit = score_to_prob.to_prob(float(raw_score))

        return OnTargetEngineResult(
            raw_score=float(raw_score),
            p_edit=float(p_edit),
            novelty=float(max(0.0, min(1.0, novelty))),
            ood=bool(ood),
            engine_id=ENGINE_ID,
            engine_version=str(bundle.engine_version),
            model_hash=str(bundle.model_hash),
            features={
                "engine_impl_version": ENGINE_VERSION,
                "physics_score": float(physics_score),
                "physics_version": CRISPR_SCORING_VERSION,
                "bundle_schema_version": FORMAT_VERSION,
                "distance_metric": str(bundle.distance_metric),
                "embedding_norm": str(bundle.embedding_norm),
                "knn_k": int(bundle.knn_k),
                "knn_block_size": int(bundle.knn_block_size) if bundle.knn_block_size is not None else None,
                "knn_distance": float(knn_distance),
                "ood_distance_threshold": float(threshold),
                "ref_embeddings_total": int(bundle.ref_total),
                "ref_embeddings_used": int(bundle.ref_used),
                "residual": float(residual),
                "residual_scale": float(residual_scale),
                "residual_applied": float(residual_applied),
                "rna_paired_fraction": float(
                    0.0 if not dot_bracket else sum(1 for ch in dot_bracket if ch != ".") / len(dot_bracket)
                ),
            },
        )


register_scorer(OnTargetXOnTargetScorer())
