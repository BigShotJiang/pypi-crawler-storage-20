from __future__ import annotations

import hashlib
import hmac
from dataclasses import dataclass
from typing import Union


def _to_bytes(root_seed: Union[int, bytes, bytearray]) -> bytes:
    if isinstance(root_seed, (bytes, bytearray)):
        return bytes(root_seed)
    return int(root_seed).to_bytes(32, "big", signed=False)


def _hkdf_sha256(key_material: bytes, info: bytes, length: int = 32) -> bytes:
    # Simple HKDF with empty salt; deterministic and portable.
    prk = hmac.new(b"", key_material, hashlib.sha256).digest()
    t = b""
    okm = b""
    counter = 1
    while len(okm) < length:
        t = hmac.new(prk, t + info + bytes([counter]), hashlib.sha256).digest()
        okm += t
        counter += 1
    return okm[:length]


@dataclass(frozen=True)
class SeedTree:
    root_seed: Union[int, bytes, bytearray]
    policy_hash: str
    semantic_hash: str

    def _info(self, domain: str) -> bytes:
        return f"{domain}|{self.policy_hash}|{self.semantic_hash}".encode("utf-8")

    def seed_bytes(self, domain: str, length: int = 32) -> bytes:
        return _hkdf_sha256(_to_bytes(self.root_seed), self._info(domain), length=length)

    def seed(self, domain: str) -> int:
        return int.from_bytes(self.seed_bytes(domain, length=8), "big", signed=False)


__all__ = ["SeedTree"]
