from __future__ import annotations

import os

from helix.determinism.guard import ImplicitRandomnessError, RngBan

# Backwards-compatible alias for historical tests and callers.
ForbiddenRandomError = ImplicitRandomnessError


def enable_guard_from_env() -> None:
    flag = os.getenv("HELIX_FORBID_RANDOM", "").lower()
    if flag in {"1", "true", "yes", "on"}:
        RngBan.install()


# Auto-enable if env flag is set.
enable_guard_from_env()

__all__ = ["ForbiddenRandomError", "enable_guard_from_env"]
