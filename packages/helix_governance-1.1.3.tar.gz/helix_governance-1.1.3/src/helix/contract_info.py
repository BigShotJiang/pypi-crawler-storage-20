from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from importlib import resources
from pathlib import PurePosixPath
from typing import Iterable

from helix.studio.cli_session_contract_stamp import (
    CLI_SESSION_CONTRACT_HASH,
    CLI_SESSION_CONTRACT_ID,
)

_SCHEMA_DIR = "proof_kit"
_SCHEMA_SUFFIX = ".schema.json"
_HASH_PREFIX = "sha256:"


@dataclass(frozen=True)
class ContractInfo:
    contract_id: str
    contract_version: int
    contract_hash: str
    schema_digest: str
    schema_files: tuple[tuple[str, str], ...]


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_prefixed(data: bytes) -> str:
    return f"{_HASH_PREFIX}{_sha256_hex(data)}"


def _ensure_prefixed(token: str) -> str:
    text = str(token).strip()
    if not text:
        raise ValueError("Expected non-empty hash value")
    if text.startswith(_HASH_PREFIX):
        return text
    return f"{_HASH_PREFIX}{text}"


def _parse_contract_version(contract_id: str) -> int:
    prefix = "cli_session_contract_v"
    if not contract_id.startswith(prefix):
        raise ValueError(f"Unsupported contract id: {contract_id}")
    suffix = contract_id[len(prefix) :]
    if not suffix.isdigit():
        raise ValueError(f"Unsupported contract id: {contract_id}")
    return int(suffix)


def _iter_schema_resources(base, prefix: PurePosixPath) -> Iterable[tuple[str, bytes]]:
    entries = sorted(list(base.iterdir()), key=lambda entry: entry.name)
    for entry in entries:
        if entry.is_dir():
            yield from _iter_schema_resources(entry, prefix / entry.name)
        elif entry.is_file() and entry.name.endswith(_SCHEMA_SUFFIX):
            rel_path = (prefix / entry.name).as_posix()
            yield rel_path, entry.read_bytes()


def _load_schema_files() -> list[tuple[str, str]]:
    schema_root = resources.files("helix.schema").joinpath(_SCHEMA_DIR)
    if not schema_root.is_dir():
        raise RuntimeError(f"Missing helix.schema/{_SCHEMA_DIR} packaged schema directory")
    items = list(_iter_schema_resources(schema_root, PurePosixPath(_SCHEMA_DIR)))
    if not items:
        raise RuntimeError(f"No schema files found under helix.schema/{_SCHEMA_DIR}")
    return [(path, _sha256_prefixed(data)) for path, data in items]


def _compute_schema_digest(schema_files: Iterable[tuple[str, str]]) -> str:
    payload = {path: sha for path, sha in schema_files}
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return _sha256_prefixed(canonical.encode("utf-8"))


def get_contract_info() -> ContractInfo:
    contract_id = CLI_SESSION_CONTRACT_ID
    contract_version = _parse_contract_version(contract_id)
    contract_hash = _ensure_prefixed(CLI_SESSION_CONTRACT_HASH)
    schema_files = tuple(sorted(_load_schema_files(), key=lambda item: item[0]))
    schema_digest = _compute_schema_digest(schema_files)
    return ContractInfo(
        contract_id=contract_id,
        contract_version=contract_version,
        contract_hash=contract_hash,
        schema_digest=schema_digest,
        schema_files=schema_files,
    )
