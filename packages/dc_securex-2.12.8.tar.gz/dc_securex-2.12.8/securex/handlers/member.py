"""
Member protection handler (bot/ban/kick protection).
"""
import discord
import asyncio


class MemberHandler:
    """Handles member-related protection"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        """Revert unauthorized bans and punish violator"""
        try:
            await asyncio.sleep(0.5)
            
            # Check audit logs from last 30 seconds
            from datetime import datetime, timezone, timedelta
            cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
            
            async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.ban):
                if entry.created_at < cutoff_time:
                    break
                    
                if entry.target.id == user.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        executor = entry.user
                        
                        # INSTANT PUNISHMENT: Ban the violator
                        try:
                            await guild.ban(executor, reason=f"SecureX: Unauthorized ban of {user.name}")
                            print(f"🔨 Banned violator: {executor.name} ({executor.id}) for banning {user.name}")
                        except (discord.errors.Forbidden, discord.errors.HTTPException) as e:
                            print(f"⚠️ Failed to ban violator {executor.name}: {e}")
                        
                        # Unban victim
                        try:
                            await guild.unban(user, reason="SecureX: Restoring banned member")
                            print(f"🔄 Unbanned unauthorized member ban: {user.name}")
                        except (discord.errors.Forbidden, discord.errors.HTTPException):
                            pass
                    break
        except Exception as e:
            print(f"Error in on_member_ban: {e}")
    
    async def on_member_remove(self, member: discord.Member):
        """Detect unauthorized kicks and punish violator"""
        try:
            guild = member.guild
            await asyncio.sleep(0.5)
            
            # Check audit logs from last 30 seconds
            from datetime import datetime, timezone, timedelta
            cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
            
            async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.kick):
                if entry.created_at < cutoff_time:
                    break
                    
                if entry.target.id == member.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        executor = entry.user
                        
                        # INSTANT PUNISHMENT: Ban the violator
                        try:
                            await guild.ban(executor, reason=f"SecureX: Unauthorized kick of {member.name}")
                            print(f"🔨 Banned violator: {executor.name} ({executor.id}) for kicking {member.name}")
                        except (discord.errors.Forbidden, discord.errors.HTTPException) as e:
                            print(f"⚠️ Failed to ban violator {executor.name}: {e}")
                    break
        except Exception as e:
            print(f"Error in on_member_remove: {e}")
    
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        """Revert unauthorized role changes"""
        try:
            # Check if roles changed
            if before.roles == after.roles:
                return
            
            guild = after.guild
            await asyncio.sleep(0.5)
            
            # Find what roles were added/removed
            added_roles = set(after.roles) - set(before.roles)
            removed_roles = set(before.roles) - set(after.roles)
            
            if not added_roles and not removed_roles:
                return
            
            # Check audit logs from last 30 seconds
            from datetime import datetime, timezone, timedelta
            cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
            
            async for entry in guild.audit_logs(limit=50, action=discord.AuditLogAction.member_role_update):
                if entry.created_at < cutoff_time:
                    break
                if entry.target.id == after.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        # Restore target's roles to previous state
                        for role in added_roles:
                            try:
                                await after.remove_roles(role, reason="SecureX: Reverting unauthorized role addition")
                            except (discord.errors.Forbidden, discord.errors.HTTPException):
                                pass
                        
                        for role in removed_roles:
                            try:
                                await after.add_roles(role, reason="SecureX: Restoring removed role")
                            except (discord.errors.Forbidden, discord.errors.HTTPException):
                                pass
                    break
        except Exception:
            pass
