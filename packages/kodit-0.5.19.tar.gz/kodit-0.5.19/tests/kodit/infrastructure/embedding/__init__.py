"""Embedding infrastructure tests."""
