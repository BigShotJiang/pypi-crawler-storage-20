"""Tests for infrastructure layer."""
