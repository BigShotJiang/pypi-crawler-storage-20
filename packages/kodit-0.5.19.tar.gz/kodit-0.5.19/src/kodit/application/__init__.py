"""Application layer for Kodit."""
