"""Example enrichment package."""
