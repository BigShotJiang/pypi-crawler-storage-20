"""Example extraction services."""
