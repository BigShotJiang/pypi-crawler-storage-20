[![Python 3.11](https://img.shields.io/badge/Python-3.11-blue.svg)](https://www.python.org/downloads/release/python-31110/) 
[![C++][c++-image]][c++standard]
[![docs2](https://github.com/Deltares/ProbabilisticLibrary/actions/workflows/docs.yml/badge.svg)](https://github.com/Deltares/ProbabilisticLibrary/actions/workflows/docs.yml)

[c++-image]: https://img.shields.io/badge/C++-20-blue.svg?style=flat&logo=c%2B%2B
[c++standard]: https://isocpp.org/std/the-standard

# Probabilistic Library

This is the Probabilistic Library of Deltares.
The library provides a set of routines that enable reliability, uncertainty, and sensitivity analyses.

## Scientific background

The scientific background of the library can be found here:
[scientific_background.pdf](https://github.com/Deltares/ProbabilisticLibrary/releases/download/25.3.1/scientific_background.pdf)

## Python wrapper

A description of the Python classes is given here:
[API documentation](https://deltares.github.io/ProbabilisticLibrary/probabilistic_library.html)

## Tutorials

See the [Tutorials](https://github.com/Deltares/ProbabilisticLibrary/blob/master/sources/Deltares.Probabilistic.PWrapper.Notebooks/gallery/gallery.md) for several demonstrations and instructions on how to use the Probabilistic Library.
