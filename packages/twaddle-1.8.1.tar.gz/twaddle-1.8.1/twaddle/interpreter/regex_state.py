class RegexState:
    match = str("")
