"""Tests for loop module."""
