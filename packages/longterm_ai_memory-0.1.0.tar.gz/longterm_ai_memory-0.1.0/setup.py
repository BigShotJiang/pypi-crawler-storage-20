# setup.py
from setuptools import setup, find_packages

setup(
    name="longterm-ai-memory",
    version="0.1.0",
    author="Omkar Patil",
    author_email="omkar1344patil@gmail.com",
    description="Semantic memory layer for AI applications with vector storage and LLM-based extraction",
    url="https://github.com/omkar1344patil/longterm-ai-memory",
    packages=find_packages(),
    install_requires=[
        "pinecone>=8.0.0",
        "requests>=2.31.0",
        "python-dotenv>=1.0.0"
    ],
    python_requires=">=3.8",
)