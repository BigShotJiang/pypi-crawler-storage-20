# config.py - Centralized Configuration for Memory SDK
"""
All configurable settings for the Memory SDK project.
API keys should be stored in .env file, not here.
"""

import os
from dotenv import load_dotenv

load_dotenv()

# =============================================================================
# ENVIRONMENT VARIABLES (loaded from .env)
# =============================================================================

PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

# =============================================================================
# PINECONE CONFIGURATION
# =============================================================================

PINECONE_CONFIG = {
    "index_name": "memory-sdk",
    "dimension": 1024,
    "metric": "cosine",
    "cloud": "aws",
    "region": "us-east-1"
}

# =============================================================================
# EMBEDDING CONFIGURATION
# =============================================================================

EMBEDDING_CONFIG = {
    "model": "multilingual-e5-large",
    "input_type_query": "query",
    "input_type_passage": "passage",
    "truncate": "END"
}

# =============================================================================
# LOCAL LLM CONFIGURATION (Ollama)
# =============================================================================

LOCAL_LLM_CONFIG = {
    "base_url": "http://localhost:11434",
    "api_endpoint": "/api/generate",
    "extraction_model": "gemma3:4b",      # Model for memory extraction
    "chatbot_model": "phi3:mini",          # Model for chatbot responses
    "timeout": 30,
    "stream": False
}

# =============================================================================
# OPENROUTER (CLOUD LLM) CONFIGURATION
# =============================================================================

OPENROUTER_CONFIG = {
    "base_url": "https://openrouter.ai/api/v1/chat/completions",
    "extraction_model": "meta-llama/llama-3.1-405b-instruct:free",   # Model for memory extraction
    "chatbot_model": "google/gemma-3-27b-it:free",      # Model for chatbot responses
    "timeout": 30
}

# =============================================================================
# SEARCH CONFIGURATION
# =============================================================================

SEARCH_CONFIG = {
    "similarity_threshold": 0.7,
    "default_top_k": 5,
    "max_top_k": 20,
    "chatbot_context_top_k": 3  # Number of memories to use for chatbot context
}

# =============================================================================
# MEMORY CATEGORIES
# =============================================================================

MEMORY_CATEGORIES = [
    "work",
    "personal", 
    "family",
    "health",
    "finance",
    "preferences",
    "education",
    "travel",
    "shopping",
    "entertainment",
    "food",
    "technology",
    "sports",
    "hobbies",
    "misc"
]

# =============================================================================
# FASTAPI SERVER CONFIGURATION
# =============================================================================

SERVER_CONFIG = {
    "host": "0.0.0.0",
    "port": 8000,
    "reload": True
}

# =============================================================================
# PROMPTS
# =============================================================================

EXTRACTION_PROMPT_TEMPLATE = """You are a strict memory extraction system. Your job is to identify ONLY concrete, factual, long-term information worth remembering. Be very conservative - when in doubt, return null.

User message: "{user_message}"

═══════════════════════════════════════════════════════════════════════
CRITICAL RULES - FOLLOW EXACTLY
═══════════════════════════════════════════════════════════════════════

RULE 1: PURE QUESTIONS HAVE NO FACTS
- If the ENTIRE message is just a question with no factual statement, return null
- "What is my name?" → null
- "What should I eat?" → null
- "Do you remember?" → null
- HOWEVER: If a message CONTAINS a fact AND a question, EXTRACT THE FACT ONLY
- "I like apples. What do you like?" → extract "User likes apples" (ignore the question part)
- "My name is John, what's yours?" → extract "User's name is John" (ignore the question)

RULE 2: TEMPORARY STATES ARE NOT MEMORIES
- "I'm fine", "I'm good", "I'm okay" → null (momentary state)
- "I'm tired today" → null (temporary)
- "I think I'm done", "I think I'm gonna go" → null (momentary intent)
- "I'm not sure" → null (uncertainty)
- "It's great", "It's good" → null (momentary reaction)
- EXCEPTION: "I have chronic fatigue" → save (lasting condition)

RULE 3: CONVERSATIONAL FILLER IS NOT INFORMATION
Reject ALL of these:
- Acknowledgments: "okay", "I know", "I see", "got it", "sure", "alright", "fine", "yep", "yeah", "ok"
- Reactions: "interesting", "wow", "nice", "cool", "that's cool", "oh really", "haha", "lol"
- Continuations: "tell me more", "go on", "continue", "and then?", "what else"
- Agreement: "yes", "I agree", "exactly", "right", "makes sense", "I understand"
- Greetings: "hi", "hello", "hey", "good morning", "good night", "bye", "goodbye"
- Gratitude: "thanks", "thank you", "thanks for asking", "I appreciate it", "that's kind", "thanks for that"
- Farewells: "I'm gonna go", "gotta go", "see you", "talk later", "bye for now"
- Politeness: "please", "no problem", "you're welcome", "it's great thanks"

RULE 4: ONLY SAVE CONCRETE, LASTING FACTS
Save ONLY these types of information:
- Identity: names, age, birthday, location, nationality
- Work: job title, company, profession, skills, projects
- Education: school, degree, graduation year
- Family: relationships, family members, pets with names
- Strong preferences: "I love X", "I hate Y", "I prefer X", "my favorite is X"
- Health: allergies, medical conditions, dietary restrictions (NOT mood)
- Hobbies: regular activities, interests, sports
- Life events: milestones, achievements, significant dates

RULE 5: FORMAT
- Convert "I/my/me" → "User/User's/User"
- Extract ONLY the factual part, ignore questions/filler in same message
- Return ONLY valid JSON: {{"memory": "...", "categories": ["..."]}}
- Categories (pick 1-2): {categories}
- No concrete fact → {{"memory": null, "categories": []}}

═══════════════════════════════════════════════════════════════════════
EXAMPLES
═══════════════════════════════════════════════════════════════════════

SAVE THESE:
"My name is Sarah" → {{"memory": "User's name is Sarah", "categories": ["personal"]}}
"I work at Google" → {{"memory": "User works at Google", "categories": ["work"]}}
"I'm allergic to shellfish" → {{"memory": "User is allergic to shellfish", "categories": ["health"]}}
"I love hiking" → {{"memory": "User loves hiking", "categories": ["hobbies"]}}
"I have a dog named Max" → {{"memory": "User has a dog named Max", "categories": ["personal"]}}
"I hate waking up early" → {{"memory": "User hates waking up early", "categories": ["preferences"]}}
"I like apples. What do you like?" → {{"memory": "User likes apples", "categories": ["preferences"]}}
"My favorite color is blue, do you have one?" → {{"memory": "User's favorite color is blue", "categories": ["preferences"]}}

REJECT THESE (null):
"I know" → {{"memory": null, "categories": []}}
"I think I'm fine for now" → {{"memory": null, "categories": []}}
"What is my name?" → {{"memory": null, "categories": []}}
"It's great. Thanks for asking" → {{"memory": null, "categories": []}}
"Thanks for that" → {{"memory": null, "categories": []}}
"I think I'm gonna go" → {{"memory": null, "categories": []}}
"Okay cool" → {{"memory": null, "categories": []}}
"I'm good" → {{"memory": null, "categories": []}}
"That's interesting" → {{"memory": null, "categories": []}}
"Hello!" → {{"memory": null, "categories": []}}
"What do you think?" → {{"memory": null, "categories": []}}
"How are you?" → {{"memory": null, "categories": []}}

Return ONLY JSON:"""

CHATBOT_SYSTEM_PROMPT = """You are a friendly AI assistant with memory capabilities.

STRICT RULES - FOLLOW EXACTLY:

1. RESPONSE LENGTH: Maximum 1-2 sentences. Never exceed 2 sentences. Be concise.

2. NO HALLUCINATIONS - THIS IS CRITICAL:
   - NEVER invent shared experiences or past conversations
   - NEVER reference events that aren't in the provided context
   - NEVER pretend you have history with the user that doesn't exist
   - NEVER make up things like "remember when we..." or "last time you mentioned..."
   - If you have no relevant context, just respond helpfully WITHOUT fabricating history

3. USING MEMORIES:
   - Only reference information explicitly provided in "Known context about the user"
   - Weave facts naturally without saying "I remember that you..."
   - If no context is relevant to the current message, don't force it

4. TONE:
   - Be warm but not overly familiar
   - Be helpful and direct
   - Don't be sycophantic or excessively enthusiastic"""

CHATBOT_CONTEXT_TEMPLATE = """Known context about the user:
{memory_context}

User: {user_message}

Respond in 1-2 sentences maximum. Only use context if directly relevant. Never invent information:"""

CHATBOT_NO_CONTEXT_TEMPLATE = """User: {user_message}

Respond helpfully in 1-2 sentences maximum. Do not invent any history or shared experiences:"""

# =============================================================================
# LOGGING CONFIGURATION
# =============================================================================

LOGGING_CONFIG = {
    "level": "INFO",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    "file": None  # Set to "memory_sdk.log" to enable file logging
}

# =============================================================================
# VALIDATION SETTINGS
# =============================================================================

VALIDATION_CONFIG = {
    "max_message_length": 10000,
    "min_message_length": 1,
    "user_id_max_length": 100,
    "user_id_pattern": r"^[a-zA-Z0-9_-]+$"
}

# =============================================================================
# DEFAULT USER SETTINGS
# =============================================================================

DEFAULT_USER_CONFIG = {
    "default_user_id": "demo-user",
    "use_local_llm": True  # Default to local LLM to avoid API costs
}