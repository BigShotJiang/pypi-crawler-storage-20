# memory_sdk/utils/validation.py
"""
Validation utilities for memory extraction.
Provides pre-filtering and post-validation to catch LLM extraction failures.
"""

import re
from typing import Optional, Dict, Any, List

# =============================================================================
# PRE-FILTER PATTERNS (Skip LLM call entirely)
# =============================================================================

# Messages that are too short to contain meaningful facts
MIN_MESSAGE_LENGTH = 3

# Exact matches to skip (lowercase)
SKIP_EXACT = {
    # Acknowledgments
    "ok", "okay", "k", "kk", "yes", "no", "yep", "yup", "nope", "yeah", "nah",
    "sure", "fine", "alright", "right", "got it", "gotcha", "understood",
    "i see", "i know", "i understand", "makes sense", "fair enough",
    
    # Reactions
    "wow", "whoa", "nice", "cool", "great", "awesome", "amazing", "interesting",
    "haha", "hehe", "lol", "lmao", "rofl", "omg", "oh", "ah", "hmm", "hm",
    "mhm", "uh huh", "oh really", "really", "seriously", "no way",
    
    # Greetings
    "hi", "hello", "hey", "heya", "yo", "sup", "howdy",
    "good morning", "good afternoon", "good evening", "good night",
    "morning", "afternoon", "evening", "night",
    
    # Farewells
    "bye", "goodbye", "see you", "see ya", "later", "cya", "ttyl",
    "gotta go", "gtg", "i gotta go", "i have to go", "talk later",
    "take care", "peace", "cheers",
    
    # Gratitude
    "thanks", "thank you", "thx", "ty", "thanks for that", "thanks for asking",
    "appreciate it", "i appreciate it", "much appreciated",
    
    # Politeness
    "please", "no problem", "np", "you're welcome", "yw", "no worries",
    "my pleasure", "don't mention it",
    
    # Filler
    "i guess", "i guess so", "i suppose", "whatever", "anyway", "anyways",
    "so", "well", "um", "uh", "hmm", "let me think", "good to know",
    "that's good", "that's great", "that's nice", "that's cool",
    "sounds good", "sounds great", "fair", "true", "same",
    
    # Temporary states
    "i'm fine", "i'm good", "i'm okay", "i'm ok", "i'm alright",
    "i'm fine today", "i'm good today", "i'm okay today",
    "i'm doing fine", "i'm doing good", "i'm doing okay", "i'm doing well",
    "all good", "all fine", "doing well", "doing good", "doing fine",
    "not bad", "pretty good", "can't complain",
    
    # Intent to leave
    "i think i'm gonna go", "i'm gonna go", "i should go", "i need to go",
    "i'll go now", "i'm leaving", "i'm off", "i'm out",
}

# Patterns to skip (regex)
SKIP_PATTERNS = [
    r"^(what|who|where|when|why|how|which|can you|could you|do you|are you|is there|will you|would you)\b.*\?$",  # Pure questions
    r"^(it's|its|that's|thats) (good|great|nice|fine|cool|interesting|awesome)\.?$",  # Reactions with "it's"
    r"^how are you\??$",  # How are you
    r"^what about you\??$",  # What about you
    r"^and you\??$",  # And you
    r"^you\??$",  # Just "you?"
    r"^same here\.?$",  # Same here
    r"^me too\.?$",  # Me too
    r"^i don'?t know\.?$",  # I don't know
    r"^no idea\.?$",  # No idea
    r"^not sure\.?$",  # Not sure
    r"^i'?m not sure\.?$",  # I'm not sure
    r"^maybe\.?$",  # Maybe
    r"^perhaps\.?$",  # Perhaps
    r"^probably\.?$",  # Probably
    r"^definitely\.?$",  # Definitely
    r"^absolutely\.?$",  # Absolutely
    r"^exactly\.?$",  # Exactly
    r"^(ok|okay|sure|yes|no|yeah|nope|yep|fine|alright|right)[\.\!\,\?]?$",  # Single word responses
]

# Compiled patterns for efficiency
COMPILED_SKIP_PATTERNS = [re.compile(p, re.IGNORECASE) for p in SKIP_PATTERNS]


# =============================================================================
# POST-VALIDATION PATTERNS (Catch LLM failures)
# =============================================================================

# Extracted memories to reject (patterns)
REJECT_MEMORY_PATTERNS = [
    r"^user'?s? (name is )?unknown",  # Name unknown
    r"^user'?s? fine",  # User's fine (temporary)
    r"^user'?s? good",  # User's good (temporary)
    r"^user'?s? okay",  # User's okay (temporary)
    r"^user'?s? doing (fine|good|well|okay)",  # User's doing fine
    r"^user said ",  # User said X (filler)
    r"^user stated ",  # User stated X (filler)
    r"^user mentioned ",  # User mentioned (too vague)
    r"^user expressed ",  # User expressed gratitude etc
    r"^user asked ",  # User asked (questions aren't facts)
    r"^user wants to know",  # User wants to know (question rephrased)
    r"^user is wondering",  # User is wondering (question rephrased)
    r"^user greeted",  # User greeted (filler)
    r"^user acknowledged",  # User acknowledged (filler)
    r"^user thanked",  # User thanked (filler)
    r"^user is (fine|good|okay|well|alright)",  # Temporary state
    r"^user feels (fine|good|okay|well|alright)",  # Temporary state
    r"^user believes user is",  # Circular/weird
    r"unknown",  # Contains unknown anywhere
    r"not specified",  # Not specified
    r"not provided",  # Not provided
    r"^typical weather",  # Weather info (not about user)
    r"^the weather",  # Weather info (not about user)
    r"^weather in",  # Weather info (not about user)
]

COMPILED_REJECT_PATTERNS = [re.compile(p, re.IGNORECASE) for p in REJECT_MEMORY_PATTERNS]

# Minimum extracted memory length (words)
MIN_MEMORY_WORDS = 3

# Maximum vagueness - memories that are too generic
VAGUE_MEMORIES = {
    "user",
    "user's",
    "the user",
    "user is",
    "user has",
    "user was",
    "user said",
    "user likes",  # Too vague without object
    "user wants",  # Too vague without object
}


# =============================================================================
# PRE-FILTER FUNCTION
# =============================================================================

def should_skip_extraction(message: str) -> bool:
    """
    Check if a message should skip LLM extraction entirely.
    Returns True if the message is obviously not worth extracting.
    
    Args:
        message: Raw user message
        
    Returns:
        True if should skip, False if should proceed to LLM
    """
    if not message:
        return True
    
    # Normalize
    cleaned = message.strip().lower()
    
    # Too short
    if len(cleaned) < MIN_MESSAGE_LENGTH:
        return True
    
    # Exact match skip
    if cleaned in SKIP_EXACT:
        return True
    
    # Remove trailing punctuation for matching
    cleaned_no_punct = cleaned.rstrip(".,!?")
    if cleaned_no_punct in SKIP_EXACT:
        return True
    
    # Pattern match skip
    for pattern in COMPILED_SKIP_PATTERNS:
        if pattern.match(cleaned):
            return True
    
    # Pure question (ends with ? and no statement before it)
    if cleaned.endswith("?"):
        # Check if there's a statement before the question
        parts = re.split(r'[.!]', cleaned)
        if len(parts) == 1:
            # Only one part, it's a pure question
            # But check if it starts with factual statement patterns
            if not re.match(r"^(i |my |i'm |i am |i have |i've |i work |i live |i like |i love |i hate )", cleaned):
                return True
    
    return False


# =============================================================================
# POST-VALIDATION FUNCTION
# =============================================================================

def validate_extraction(extraction: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """
    Validate an LLM extraction result.
    Returns None if the extraction should be rejected.
    
    Args:
        extraction: Dict with 'memory' and 'categories' keys, or None
        
    Returns:
        The extraction if valid, None if should be rejected
    """
    if not extraction:
        return None
    
    memory = extraction.get("memory")
    
    if not memory:
        return None
    
    # Normalize for checking
    memory_lower = memory.strip().lower()
    
    # Too short
    word_count = len(memory_lower.split())
    if word_count < MIN_MEMORY_WORDS:
        return None
    
    # Too vague
    if memory_lower in VAGUE_MEMORIES:
        return None
    
    # Check rejection patterns
    for pattern in COMPILED_REJECT_PATTERNS:
        if pattern.search(memory_lower):
            return None
    
    # Must start with "User" (properly formatted)
    if not memory.startswith("User"):
        return None
    
    # Check if it's actually about the user (not general info)
    # Valid patterns: User's X, User is X, User has X, User likes X, etc.
    valid_starts = [
        "User's ", "User is ", "User has ", "User had ", "User have ",
        "User likes ", "User loves ", "User hates ", "User dislikes ", "User prefers ",
        "User works ", "User worked ", "User lives ", "User lived ",
        "User studies ", "User studied ", "User goes ", "User went ",
        "User plays ", "User played ", "User enjoys ", "User enjoyed ",
        "User wants ", "User wanted ", "User needs ", "User needed ",
        "User owns ", "User owned ", "User bought ", "User sold ",
        "User graduated ", "User completed ", "User finished ",
        "User married ", "User divorced ", "User born ",
        "User can ", "User cannot ", "User will ", "User would ",
        "User was ", "User were ", "User does ", "User did ",
        "User speaks ", "User spoke ", "User knows ", "User knew ",
        "User met ", "User visited ", "User traveled ", "User travelled ",
    ]
    
    if not any(memory.startswith(start) for start in valid_starts):
        # Check for possessive form
        if not memory.startswith("User's "):
            return None
    
    return extraction


# =============================================================================
# COMBINED FILTER FUNCTION
# =============================================================================

def should_extract_memory(message: str) -> bool:
    """
    Convenience function to check if extraction should proceed.
    
    Args:
        message: Raw user message
        
    Returns:
        True if should attempt extraction, False if should skip
    """
    return not should_skip_extraction(message)