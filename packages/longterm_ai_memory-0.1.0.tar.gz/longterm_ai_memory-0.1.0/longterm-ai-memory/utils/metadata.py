# utils/metadata.py
from datetime import datetime
from typing import Dict, Any

class MetadataGenerator:
    """Generate structured metadata for memory objects"""
    
    @staticmethod
    def generate_temporal_metadata() -> Dict[str, Any]:
        """
        Generate time-based metadata matching mem0's structure
        
        Returns:
            Dict with temporal fields: day, month, year, hour, etc.
        """
        now = datetime.now()
        
        return {
            "day": now.day,
            "month": now.month,
            "year": now.year,
            "hour": now.hour,
            "minute": now.minute,
            "quarter": (now.month - 1) // 3 + 1,
            "day_of_week": now.strftime("%A").lower(),
            "day_of_year": now.timetuple().tm_yday,
            "week_of_year": now.isocalendar()[1],
            "is_weekend": now.weekday() >= 5
        }
    
    @staticmethod
    def create_full_metadata(
        memory: str,
        user_id: str,
        categories: list = None
    ) -> Dict[str, Any]:
        """
        Create complete metadata object for a memory
        
        Args:
            memory: The extracted memory text
            user_id: User identifier
            categories: Optional list of category tags
            
        Returns:
            Full metadata dict
        """
        now = datetime.now().isoformat()
        temporal = MetadataGenerator.generate_temporal_metadata()
        
        return {
            "memory": memory,
            "user_id": user_id,
            "categories": categories or [],
            "created_at": now,
            "updated_at": now,
            **temporal  # Unpack temporal metadata
        }