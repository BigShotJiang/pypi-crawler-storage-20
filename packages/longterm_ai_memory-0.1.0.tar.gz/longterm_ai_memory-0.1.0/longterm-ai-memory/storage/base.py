# storage/base.py
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

class VectorStore(ABC):
    """Abstract interface for vector storage backends"""
    
    @abstractmethod
    def upsert(
        self, 
        id: str, 
        vector: List[float], 
        metadata: Dict[str, Any],
        namespace: str
    ) -> bool:
        """Store or update a vector with metadata"""
        pass
    
    @abstractmethod
    def query(
        self,
        vector: List[float],
        namespace: str,
        top_k: int = 5,
        filter: Optional[Dict[str, Any]] = None,
        min_score: float = 0.0
    ) -> List[Dict[str, Any]]:
        """Search for similar vectors"""
        pass
    
    @abstractmethod
    def fetch(
        self,
        ids: List[str],
        namespace: str
    ) -> List[Dict[str, Any]]:
        """Fetch specific vectors by IDs"""
        pass
    
    @abstractmethod
    def list_ids(
        self,
        namespace: str,
        limit: Optional[int] = None
    ) -> List[str]:
        """List all vector IDs in a namespace"""
        pass
    
    @abstractmethod
    def list(self, namespace: str, limit: int = 100) -> List[Dict[str, Any]]:
        """List all memories for a user"""
        pass
    
    @abstractmethod
    def delete(self, id: str, namespace: str) -> bool:
        """Delete a specific memory"""
        pass
    
    @abstractmethod
    def delete_all(self, namespace: str) -> bool:
        """Delete all memories for a user"""
        pass