# storage/pinecone_store.py
import time
from typing import List, Dict, Any, Optional
from pinecone import Pinecone, ServerlessSpec
from .base import VectorStore

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import PINECONE_CONFIG


class PineconeStore(VectorStore):
    """Pinecone implementation of VectorStore"""
    
    def __init__(
        self, 
        api_key: str, 
        index_name: Optional[str] = None,
        dimension: Optional[int] = None,
        metric: Optional[str] = None,
        cloud: Optional[str] = None,
        region: Optional[str] = None
    ):
        """
        Initialize Pinecone store
        
        Args:
            api_key: Pinecone API key
            index_name: Index name (defaults to config)
            dimension: Vector dimension (defaults to config)
            metric: Distance metric (defaults to config)
            cloud: Cloud provider (defaults to config)
            region: Region (defaults to config)
        """
        self.pc = Pinecone(api_key=api_key)
        self.index_name = index_name or PINECONE_CONFIG["index_name"]
        
        _dimension = dimension or PINECONE_CONFIG["dimension"]
        _metric = metric or PINECONE_CONFIG["metric"]
        _cloud = cloud or PINECONE_CONFIG["cloud"]
        _region = region or PINECONE_CONFIG["region"]
        
        # Create index if doesn't exist
        if self.index_name not in self.pc.list_indexes().names():
            self.pc.create_index(
                name=self.index_name,
                dimension=_dimension,
                metric=_metric,
                spec=ServerlessSpec(cloud=_cloud, region=_region)
            )
            time.sleep(1)
        
        self.index = self.pc.Index(self.index_name)
    
    def upsert(
        self,
        id: str,
        vector: List[float],
        metadata: Dict[str, Any],
        namespace: str
    ) -> bool:
        """Store vector in Pinecone"""
        try:
            self.index.upsert(
                vectors=[{
                    "id": id,
                    "values": vector,
                    "metadata": metadata
                }],
                namespace=namespace
            )
            return True
        except Exception as e:
            print(f"Pinecone upsert error: {e}")
            return False
    
    def query(
        self,
        vector: List[float],
        namespace: str,
        top_k: int = 5,
        filter: Optional[Dict[str, Any]] = None,
        min_score: float = 0.0
    ) -> List[Dict[str, Any]]:
        """Query similar vectors from Pinecone"""
        try:
            results = self.index.query(
                vector=vector,
                namespace=namespace,
                top_k=top_k,
                filter=filter,
                include_metadata=True
            )
            
            matches = []
            for match in results.matches:
                if match.score >= min_score:
                    matches.append({
                        "id": match.id,
                        "score": match.score,
                        "metadata": match.metadata
                    })
            
            return matches
        except Exception as e:
            print(f"Pinecone query error: {e}")
            return []
    
    def fetch(
        self,
        ids: List[str],
        namespace: str
    ) -> List[Dict[str, Any]]:
        """Fetch specific vectors by IDs"""
        try:
            result = self.index.fetch(ids=ids, namespace=namespace)
            
            memories = []
            for id, vector_data in result.vectors.items():
                memories.append({
                    "id": id,
                    "metadata": vector_data.metadata,
                    "values": vector_data.values
                })
            
            return memories
        except Exception as e:
            print(f"Pinecone fetch error: {e}")
            return []
    
    def list_ids(
        self,
        namespace: str,
        limit: Optional[int] = None
    ) -> List[str]:
        """List all vector IDs in namespace"""
        try:
            all_ids = []
            
            # index.list() returns a generator, iterate through it
            for id_batch in self.index.list(namespace=namespace):
                # id_batch might be a single ID string or a list of IDs
                if isinstance(id_batch, str):
                    all_ids.append(id_batch)
                elif isinstance(id_batch, list):
                    all_ids.extend(id_batch)
                else:
                    # If it's an object with an 'id' attribute
                    all_ids.append(str(id_batch))
                
                # Check if we've hit the limit
                if limit and len(all_ids) >= limit:
                    all_ids = all_ids[:limit]
                    break
                
            return all_ids
        except Exception as e:
            print(f"Pinecone list_ids error: {e}")
            return []
    
    def list(self, namespace: str, limit: int = 100) -> List[Dict[str, Any]]:
        """List all memories for a user"""
        try:
            # Get all IDs in the namespace using list()
            ids = self.list_ids(namespace=namespace, limit=limit)
            
            if not ids:
                return []
            
            # Fetch all vectors by IDs in batches (Pinecone fetch limit is ~1000)
            batch_size = 100
            all_memories = []
            
            for i in range(0, len(ids), batch_size):
                batch_ids = ids[i:i + batch_size]
                memories = self.fetch(ids=batch_ids, namespace=namespace)
                all_memories.extend(memories)
            
            return all_memories
        except Exception as e:
            print(f"Pinecone list error: {e}")
            return []
    
    def delete(self, id: str, namespace: str) -> bool:
        """Delete specific vector"""
        try:
            self.index.delete(ids=[id], namespace=namespace)
            return True
        except Exception as e:
            print(f"Pinecone delete error: {e}")
            return False
    
    def delete_all(self, namespace: str) -> bool:
        """Delete all vectors in namespace"""
        try:
            self.index.delete(delete_all=True, namespace=namespace)
            return True
        except Exception as e:
            print(f"Pinecone delete_all error: {e}")
            return False