# embeddings/pinecone_embed.py
from typing import List, Optional
from pinecone import Pinecone
from .base import EmbeddingProvider

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import EMBEDDING_CONFIG


class PineconeEmbedding(EmbeddingProvider):
    """Pinecone inference API for embeddings"""
    
    def __init__(
        self, 
        api_key: str,
        model: Optional[str] = None
    ):
        """
        Initialize Pinecone embedding provider
        
        Args:
            api_key: Pinecone API key
            model: Embedding model (defaults to config)
        """
        self.pc = Pinecone(api_key=api_key)
        self.model = model or EMBEDDING_CONFIG["model"]
    
    def embed_query(self, text: str) -> List[float]:
        """Embed a query using Pinecone inference"""
        response = self.pc.inference.embed(
            model=self.model,
            inputs=[text],
            parameters={
                "input_type": EMBEDDING_CONFIG["input_type_query"],
                "truncate": EMBEDDING_CONFIG["truncate"]
            }
        )
        return response.data[0]['values']
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed documents using Pinecone inference"""
        response = self.pc.inference.embed(
            model=self.model,
            inputs=texts,
            parameters={
                "input_type": EMBEDDING_CONFIG["input_type_passage"],
                "truncate": EMBEDDING_CONFIG["truncate"]
            }
        )
        return [item['values'] for item in response.data]