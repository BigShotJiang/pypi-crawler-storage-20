# core.py
import uuid
from typing import List, Dict, Any, Optional
from .storage.pinecone_store import PineconeStore
from .embeddings.pinecone_embed import PineconeEmbedding
from .extractors.memory_extractor import MemoryExtractor
from .extractors.local_llm_extractor import LocalLLMExtractor
from .utils.metadata import MetadataGenerator
from .utils.validation import should_skip_extraction, validate_extraction

# Import config
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import (
    PINECONE_CONFIG,
    EMBEDDING_CONFIG,
    LOCAL_LLM_CONFIG,
    OPENROUTER_CONFIG,
    SEARCH_CONFIG,
    PINECONE_API_KEY,
    OPENROUTER_API_KEY
)


class Memory:
    """Main SDK class for AI memory management"""
    
    def __init__(
        self,
        user_id: str,
        pinecone_api_key: Optional[str] = None,
        openrouter_api_key: Optional[str] = None,
        index_name: Optional[str] = None,
        embedding_model: Optional[str] = None,
        llm_model: Optional[str] = None,
        similarity_threshold: Optional[float] = None,
        use_local_llm: bool = True,
        local_llm_model: Optional[str] = None,
        local_llm_url: Optional[str] = None,
        skip_health_check: bool = False
    ):
        """
        Initialize Memory SDK
        
        Args:
            user_id: Unique identifier for the user
            pinecone_api_key: Pinecone API key (defaults to env/config)
            openrouter_api_key: OpenRouter API key (defaults to env/config)
            index_name: Pinecone index name (defaults to config)
            embedding_model: Model for embeddings (defaults to config)
            llm_model: Model for memory extraction (defaults to config)
            similarity_threshold: Minimum score for search results (defaults to config)
            use_local_llm: If True, uses local LLM instead of OpenRouter
            local_llm_model: Local model name for Ollama (defaults to config)
            local_llm_url: Base URL for local LLM server (defaults to config)
            skip_health_check: Skip startup validation
        """
        self.user_id = user_id
        self.similarity_threshold = similarity_threshold or SEARCH_CONFIG["similarity_threshold"]
        
        # Use provided keys or fall back to config/env
        _pinecone_api_key = pinecone_api_key or PINECONE_API_KEY
        _openrouter_api_key = openrouter_api_key or OPENROUTER_API_KEY
        
        if not _pinecone_api_key:
            raise ValueError("Pinecone API key is required. Set PINECONE_API_KEY in .env or pass pinecone_api_key")
        
        # Initialize storage with config defaults
        self.storage = PineconeStore(
            api_key=_pinecone_api_key,
            index_name=index_name or PINECONE_CONFIG["index_name"],
            dimension=PINECONE_CONFIG["dimension"],
            metric=PINECONE_CONFIG["metric"],
            cloud=PINECONE_CONFIG["cloud"],
            region=PINECONE_CONFIG["region"]
        )
        
        # Initialize embeddings with config defaults
        self.embeddings = PineconeEmbedding(
            api_key=_pinecone_api_key,
            model=embedding_model or EMBEDDING_CONFIG["model"]
        )
        
        # Choose extractor based on preference
        if use_local_llm:
            self.extractor = LocalLLMExtractor(
                model=local_llm_model or LOCAL_LLM_CONFIG["extraction_model"],
                base_url=local_llm_url or LOCAL_LLM_CONFIG["base_url"]
            )
        else:
            if not _openrouter_api_key:
                raise ValueError("OpenRouter API key required when use_local_llm=False. Set OPENROUTER_API_KEY in .env or pass openrouter_api_key")
            self.extractor = MemoryExtractor(
                api_key=_openrouter_api_key,
                model=llm_model or OPENROUTER_CONFIG["extraction_model"]
            )
    
    def add(self, user_message: str, categories: Optional[List[str]] = None) -> Optional[Dict[str, Any]]:
        """Add a new memory from user message (categories auto-generated)"""
        
        # PRE-FILTER: Skip obvious non-facts before calling LLM
        if should_skip_extraction(user_message):
            return None
        
        # Extract clean memory and categories via LLM
        extraction = self.extractor.extract_memory(user_message)
        
        # POST-VALIDATION: Catch LLM failures
        extraction = validate_extraction(extraction)
        
        if not extraction:
            return None
        
        memory_text = extraction["memory"]
        extracted_categories = extraction["categories"]
        
        # Use provided categories if specified, otherwise use extracted
        final_categories = categories if categories else extracted_categories
        
        # Generate unique ID
        memory_id = str(uuid.uuid4())
        
        # Create metadata
        metadata = MetadataGenerator.create_full_metadata(
            memory=memory_text,
            user_id=self.user_id,
            categories=final_categories
        )
        
        # Generate embedding
        embedding = self.embeddings.embed_documents([memory_text])[0]
        
        # Store in vector database
        success = self.storage.upsert(
            id=memory_id,
            vector=embedding,
            metadata=metadata,
            namespace=self.user_id
        )
        
        if success:
            return {
                "id": memory_id,
                "memory": memory_text,
                "metadata": metadata
            }
        
        return None
    
    def search(
        self,
        query: str,
        top_k: Optional[int] = None,
        filter: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """Search for relevant memories"""
        top_k = top_k or SEARCH_CONFIG["default_top_k"]
        
        query_embedding = self.embeddings.embed_query(query)
        
        results = self.storage.query(
            vector=query_embedding,
            namespace=self.user_id,
            top_k=top_k,
            filter=filter,
            min_score=self.similarity_threshold
        )
        
        return results
    
    def get_all(self, filter: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Get all memories for the current user with optional filtering"""
        all_memories = self.storage.list(namespace=self.user_id, limit=10000)
        
        if filter:
            filtered_memories = []
            for memory in all_memories:
                metadata = memory.get("metadata", {})
                
                matches = True
                for key, value in filter.items():
                    if key == "categories":
                        if value not in metadata.get("categories", []):
                            matches = False
                            break
                    else:
                        if metadata.get(key) != value:
                            matches = False
                            break
                
                if matches:
                    filtered_memories.append(memory)
            
            return filtered_memories
        
        return all_memories
    
    def list(self, limit: int = 100) -> List[Dict[str, Any]]:
        """List all memories"""
        return self.storage.list(namespace=self.user_id, limit=limit)
    
    def delete_all(self) -> bool:
        """Delete all memories for the user"""
        return self.storage.delete_all(namespace=self.user_id)