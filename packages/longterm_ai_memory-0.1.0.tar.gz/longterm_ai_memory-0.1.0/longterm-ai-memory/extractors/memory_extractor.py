# extractors/memory_extractor.py
import requests
import json
from typing import Optional, Dict, Any

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import (
    OPENROUTER_CONFIG,
    EXTRACTION_PROMPT_TEMPLATE,
    MEMORY_CATEGORIES
)


class MemoryExtractor:
    """Extract clean, factual memories from conversational text using LLM"""
    
    def __init__(
        self,
        api_key: str,
        model: Optional[str] = None
    ):
        """
        Initialize OpenRouter memory extractor
        
        Args:
            api_key: OpenRouter API key
            model: Model to use (defaults to config)
        """
        self.api_key = api_key
        self.model = model or OPENROUTER_CONFIG["extraction_model"]
        self.api_url = OPENROUTER_CONFIG["base_url"]
        self.timeout = OPENROUTER_CONFIG["timeout"]
    
    def extract_memory(self, user_message: str) -> Optional[Dict[str, Any]]:
        """
        Convert raw user message into clean memory with auto-generated categories
        
        Args:
            user_message: Raw message from user
            
        Returns:
            Dict with 'memory' and 'categories' keys, or None
        """
        # Build prompt from template
        categories_str = ", ".join(MEMORY_CATEGORIES)
        extraction_prompt = EXTRACTION_PROMPT_TEMPLATE.format(
            user_message=user_message,
            categories=categories_str
        )

        try:
            response = requests.post(
                self.api_url,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": self.model,
                    "messages": [{"role": "user", "content": extraction_prompt}]
                },
                timeout=self.timeout
            )
            
            response.raise_for_status()
            result_text = response.json()["choices"][0]["message"]["content"].strip()
            
            # Parse JSON response
            # Clean potential markdown code blocks
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()
            
            result = json.loads(result_text)
            
            # Validate response
            if not result.get("memory") or result["memory"] == "null":
                return None
            
            return {
                "memory": result["memory"],
                "categories": result.get("categories", [])
            }
            
        except Exception as e:
            print(f"Memory extraction error: {e}")
            return None