# extractors/local_llm_extractor.py
import requests
import json
from typing import Optional, Dict, Any

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from config import (
    LOCAL_LLM_CONFIG,
    EXTRACTION_PROMPT_TEMPLATE,
    MEMORY_CATEGORIES
)


class LocalLLMExtractor:
    """Extract memories using local LLM via Ollama or compatible server"""
    
    def __init__(
        self,
        model: Optional[str] = None,
        base_url: Optional[str] = None
    ):
        """
        Initialize local LLM extractor
        
        Args:
            model: Model name (defaults to config)
            base_url: Base URL for Ollama server (defaults to config)
        """
        self.model = model or LOCAL_LLM_CONFIG["extraction_model"]
        self.base_url = base_url or LOCAL_LLM_CONFIG["base_url"]
        self.api_url = f"{self.base_url}{LOCAL_LLM_CONFIG['api_endpoint']}"
        self.timeout = LOCAL_LLM_CONFIG["timeout"]
    
    def extract_memory(self, user_message: str) -> Optional[Dict[str, Any]]:
        """
        Convert raw user message into clean memory with auto-generated categories
        
        Args:
            user_message: Raw message from user
            
        Returns:
            Dict with 'memory' and 'categories' keys, or None
        """
        # Build prompt from template
        categories_str = ", ".join(MEMORY_CATEGORIES)
        extraction_prompt = EXTRACTION_PROMPT_TEMPLATE.format(
            user_message=user_message,
            categories=categories_str
        )

        try:
            response = requests.post(
                self.api_url,
                headers={"Content-Type": "application/json"},
                json={
                    "model": self.model,
                    "prompt": extraction_prompt,
                    "stream": LOCAL_LLM_CONFIG["stream"],
                    "format": "json"  # Ollama's JSON mode
                },
                timeout=self.timeout
            )
            
            response.raise_for_status()
            result_text = response.json()["response"].strip()
            
            # Parse JSON response
            # Clean potential markdown code blocks
            if "```json" in result_text:
                result_text = result_text.split("```json")[1].split("```")[0].strip()
            elif "```" in result_text:
                result_text = result_text.split("```")[1].split("```")[0].strip()
            
            result = json.loads(result_text)
            
            # Validate response
            if not result.get("memory") or result["memory"] == "null":
                return None
            
            return {
                "memory": result["memory"],
                "categories": result.get("categories", [])
            }
            
        except Exception as e:
            print(f"Local LLM extraction error: {e}")
            return None