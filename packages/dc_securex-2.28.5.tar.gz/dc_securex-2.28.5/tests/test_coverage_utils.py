import pytest
import asyncio
import discord
import os
import json
from datetime import datetime, timezone
from securex.models import ThreatEvent, BackupInfo, RestoreResult, WhitelistChange, UserToken
from securex.utils.punishment import PunishmentExecutor
from securex.utils.whitelist import WhitelistManager
from unittest.mock import Mock, AsyncMock, patch

@pytest.mark.asyncio
class TestUtilsExhaustive:
    """Exhaustive tests for models, punishment, and whitelist to reach 100% coverage"""

    async def test_models_full(self):
        """Test all models serialization"""
        # ThreatEvent
        te = ThreatEvent(
            type="test", guild_id=1, actor_id=2, target_id=3, target_name="n",
            prevented=True, restored=True, timestamp=datetime.now(timezone.utc)
        )
        d = te.to_dict()
        assert d['type'] == "test"
        assert isinstance(d['timestamp'], str)
        assert te.to_json().startswith('{"type": "test"')

        # BackupInfo
        bi = BackupInfo(guild_id=1, timestamp=datetime.now(timezone.utc), channel_count=5, role_count=10, backup_path="/p")
        bd = bi.to_dict()
        assert bd['channel_count'] == 5

        # RestoreResult
        rr = RestoreResult(success=True, items_restored=5, items_failed=0)
        assert rr.to_dict()['success'] is True

        # WhitelistChange
        wc = WhitelistChange(guild_id=1, user_id=2, action="added")
        assert wc.to_dict()['action'] == "added"
        
        # UserToken
        ut = UserToken(guild_id=123, token="test_token", set_by=999, description="Test")
        assert ut.guild_id == 123
        assert ut.token == "test_token"
        assert ut.last_used is None
        ut.mark_used()
        assert ut.last_used is not None
        ud = ut.to_dict()
        assert ud['guild_id'] == 123
        assert isinstance(ud['timestamp'], str)

    async def test_punishment_full(self):
        """Test all punishment branches"""
        bot = Mock()
        executor = PunishmentExecutor(bot)
        guild = Mock()
        user = Mock(id=123)
        sdk = Mock()
        sdk.timeout_duration = 60
        sdk.notify_punished_user = True
        
        # sdk is None
        assert await executor.punish(guild, user, "type", sdk=None) == "none"
        
        # action is none
        sdk.punishments = {"type": "none"}
        assert await executor.punish(guild, user, "type", sdk=sdk) == "none"
        
        # Not a member
        guild.get_member.return_value = None
        sdk.punishments = {"type": "kick"}
        assert await executor.punish(guild, user, "type", sdk=sdk) == "kick"
        
        # Owner bypass
        member = Mock(id=123)
        guild.owner_id = 123
        guild.get_member.return_value = member
        assert await executor.punish(guild, user, "type", sdk=sdk) == "kick"
        
        # Warn
        guild.owner_id = 999
        sdk.punishments = {"type": "warn"}
        assert await executor.punish(guild, user, "type", sdk=sdk) == "warn"
        
        # Timeout
        sdk.punishments = {"type": "timeout"}
        member.timeout = AsyncMock()
        member.send = AsyncMock()
        assert await executor.punish(guild, user, "type", sdk=sdk) == "timeout"
        member.timeout.assert_called_once()
        
        # Kick
        sdk.punishments = {"type": "kick"}
        member.kick = AsyncMock()
        assert await executor.punish(guild, user, "type", sdk=sdk) == "kick"
        
        # Ban
        sdk.punishments = {"type": "ban"}
        member.ban = AsyncMock()
        assert await executor.punish(guild, user, "type", sdk=sdk) == "ban"
        
        # Forbidden error
        member.ban.side_effect = discord.Forbidden(Mock(), "fail")
        await executor.punish(guild, user, "type", sdk=sdk)
        
        # General Exception
        member.ban.side_effect = Exception("err")
        await executor.punish(guild, user, "type", sdk=sdk)

        # Notify user branches
        member.send.side_effect = discord.Forbidden(Mock(), "fail")
        await executor._notify_user(member, "type", "ban", "details", sdk)
        member.send.side_effect = Exception("err")
        await executor._notify_user(member, "type", "ban", "details", sdk)

    async def test_whitelist_full(self, tmp_path):
        """Test whitelist manager branches"""
        sdk = Mock()
        sdk.bot = Mock()
        sdk._trigger_callbacks = AsyncMock()
        
        # Patch data_dir to tmp_path
        with patch("securex.utils.whitelist.Path", return_value=tmp_path):
            # We need to be careful with Path inheritance. 
            # Better to just set manager.data_dir directly if possible, but __init__ sets it.
            # Let's patch WhitelistManager's Path in its module.
            with patch("securex.utils.whitelist.Path") as mock_path:
                mock_path.return_value = tmp_path
                manager = WhitelistManager(sdk)
                manager.data_dir = tmp_path # Ensure it's set
                
                # add/is_whitelisted
                await manager.add(777, 123)
                assert await manager.is_whitelisted(777, 123) is True
                assert await manager.is_whitelisted(777, 999) is False
                
                # remove
                await manager.remove(777, 123)
                assert await manager.is_whitelisted(777, 123) is False
                
                # get_all
                await manager.add(777, 456)
                assert 456 in await manager.get_all(777)
                
                # Preload (success)
                (tmp_path / "888.json").write_text(json.dumps({"users": [1, 2]}))
                manager._cache_loaded = False
                await manager.preload_all()
                assert await manager.is_whitelisted(888, 1) is True
                
                # Preload (already loaded)
                await manager.preload_all()
                
                # Preload (error)
                (tmp_path / "bad.json").write_text("invalid")
                manager._cache_loaded = False
                await manager.preload_all()
                
                # clear
                await manager.clear(777)
                assert len(await manager.get_all(777)) == 0
                
                # Load fallback in remove
                (tmp_path / "998.json").write_text(json.dumps({"users": [8]}))
                manager._whitelists.pop(998, None)
                await manager.remove(998, 8)
                assert 8 not in await manager.get_all(998)
                
                # Load fallback in get_all
                (tmp_path / "997.json").write_text(json.dumps({"users": [7]}))
                manager._whitelists.pop(997, None)
                assert 7 in await manager.get_all(997)
                
                # Load fallback in is_whitelisted
                (tmp_path / "999.json").write_text(json.dumps({"users": [9]}))
                manager._whitelists.pop(999, None)
                assert await manager.is_whitelisted(999, 9) is True
