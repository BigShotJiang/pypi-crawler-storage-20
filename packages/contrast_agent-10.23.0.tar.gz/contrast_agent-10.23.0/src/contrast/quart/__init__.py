# Copyright © 2026 Contrast Security, Inc.
# See https://www.contrastsecurity.com/enduser-terms-0317a for more details.
from .middleware import QuartMiddleware as ContrastMiddleware  # noqa
