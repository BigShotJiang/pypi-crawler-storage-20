"""
AI Sentinel Python SDK

Simple, type-safe SDK for integrating AI Sentinel security into your AI agents.

Basic usage:
    from ai_sentinel_sdk import Sentinel

    sentinel = Sentinel(api_key="your-api-key")

    # Scan input
    result = sentinel.scan_input("Hello, how are you?", agent_id="my-agent")
    if not result.allowed:
        print(f"Blocked: {result.reason}")

    # Authorize tool call
    auth = sentinel.authorize_tool(
        agent_id="my-agent",
        tool_name="send_email",
        user_role="USER",
        user_id="user-123"
    )
    if not auth.allowed:
        print(f"Denied: {auth.reason}")
"""

__version__ = "0.1.0"

from ai_sentinel_sdk.client import Sentinel, AsyncSentinel
from ai_sentinel_sdk.models import (
    ScanResult,
    AuthorizeResult,
    ActionSourceResult,
    HierarchyResult,
    Incident,
)
from ai_sentinel_sdk.exceptions import (
    SentinelError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
)

__all__ = [
    # Client
    "Sentinel",
    "AsyncSentinel",
    # Models
    "ScanResult",
    "AuthorizeResult",
    "ActionSourceResult",
    "HierarchyResult",
    "Incident",
    # Exceptions
    "SentinelError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
]
