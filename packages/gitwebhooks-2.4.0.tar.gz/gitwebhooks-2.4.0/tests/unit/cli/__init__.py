"""CLI unit tests module"""
