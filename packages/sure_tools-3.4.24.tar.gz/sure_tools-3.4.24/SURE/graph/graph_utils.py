import numpy as np
import networkx as nx
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from scipy.spatial.distance import cdist
from scipy import sparse
import matplotlib.pyplot as plt

class ClusterNetworkBuilder:
    """聚类中心网络构建器"""
    
    def __init__(self, assignment_method='gaussian', temperature=1.0):
        """
        参数:
        assignment_method: 分配方法 ('softmax', 'hard', 'gaussian', 'knn')
        temperature: softmax的温度参数
        """
        self.assignment_method = assignment_method
        self.temperature = temperature
    
    def build_network(self, x, c, k_neighbors=5, metric='euclidean', 
                     min_edge_weight=1e-6, normalize=True):
        """
        构建聚类中心网络
        
        返回:
        G: NetworkX图
        assignments: 数据点分配矩阵
        metrics: 网络指标字典
        """
        n_samples = x.shape[0]
        n_clusters = c.shape[0]
        
        # 1. 计算数据分配
        assignments = self._compute_assignments(x, c, metric)
        
        # 2. 计算节点权重
        node_weights = assignments.sum(axis=0) / n_samples
        
        # 3. 构建网络
        G = nx.Graph()
        
        # 添加节点
        for i in range(n_clusters):
            G.add_node(i, 
                      weight=node_weights[i],
                      center=c[i],
                      cluster_size=int(np.sum(assignments[:, i])),
                      samples=list(np.where(assignments[:, i] > 0.5)[0]))
        
        # 4. 计算边权重
        edges_info = self._compute_edge_weights(c, assignments, k_neighbors, 
                                               metric, min_edge_weight)
        
        # 添加边
        for (i, j), weight, distance, shared_samples in edges_info:
            G.add_edge(i, j, 
                      weight=weight,
                      distance=distance,
                      shared_samples=shared_samples)
        
        return G
    
    def _compute_assignments(self, x, c, metric):
        """计算数据点分配"""
        n_samples = x.shape[0]
        n_clusters = c.shape[0]
        
        # 计算距离
        distances = cdist(x, c, metric=metric)
        
        if self.assignment_method == 'hard':
            # 硬分配：每个点分配到最近的聚类
            assignments = np.zeros((n_samples, n_clusters))
            nearest = np.argmin(distances, axis=1)
            assignments[np.arange(n_samples), nearest] = 1
        
        elif self.assignment_method == 'softmax':
            # softmax分配
            # 使用负距离（距离越小，概率越大）
            similarities = np.exp(-distances / self.temperature)
            assignments = similarities / similarities.sum(axis=1, keepdims=True)
        
        elif self.assignment_method == 'gaussian':
            # 高斯核分配
            sigma = np.median(distances)  # 使用中值作为带宽
            similarities = np.exp(-distances**2 / (2 * sigma**2))
            assignments = similarities / similarities.sum(axis=1, keepdims=True)
        
        elif self.assignment_method == 'knn':
            # k近邻分配
            k = min(5, n_clusters)
            assignments = np.zeros((n_samples, n_clusters))
            knn_indices = np.argsort(distances, axis=1)[:, :k]
            
            for i in range(n_samples):
                # 平均分配给k个最近邻
                assignments[i, knn_indices[i]] = 1.0 / k
        
        else:
            raise ValueError(f"未知的分配方法: {self.assignment_method}")
        
        return assignments
    
    def _compute_edge_weights(self, c, assignments, k_neighbors, metric, min_edge_weight):
        """计算边权重"""
        n_clusters = c.shape[0]
        n_samples = assignments.shape[0]
        
        # 计算聚类中心之间的距离
        center_distances = cdist(c, c, metric=metric)
        
        # 找到每个聚类的k个最近邻
        edges_info = []
        
        for i in range(n_clusters):
            # 获取距离最近的k+1个聚类（包括自己）
            k = min(k_neighbors + 1, n_clusters)
            nearest = np.argsort(center_distances[i])[:k]
            
            for j in nearest:
                if i < j:  # 避免重复
                    distance = center_distances[i, j]
                    
                    # 计算边权重：共享数据点的比重
                    # 方法1: 使用Jaccard相似度
                    mask_i = assignments[:, i] > 0
                    mask_j = assignments[:, j] > 0
                    shared = np.logical_and(mask_i, mask_j)
                    
                    if shared.sum() > 0:
                        # 计算共享数据点的总分配权重
                        weight_ij = (assignments[shared, i] + assignments[shared, j]).sum() / 2
                        weight = weight_ij / n_samples
                        
                        if weight >= min_edge_weight:
                            edges_info.append(((i, j), weight, distance, shared.sum()))
                    
                    # 方法2: 使用最小分配权重（备选）
                    # min_assign = np.minimum(assignments[:, i], assignments[:, j])
                    # weight = min_assign.sum() / n_samples
        
        return edges_info
    
def visualize_network(G, c=None, figsize=(12, 10)):
    """可视化聚类中心网络"""
    fig, ax1 = plt.subplots(1, 1, figsize=figsize)
    
    # 位置布局（如果提供了聚类中心坐标，使用它们；否则使用力导向布局）
    if c is not None and c.shape[1] >= 2:
        # 使用前两个维度作为位置
        pos = {i: (c[i, 0], c[i, 1]) for i in G.nodes()}
        
        # 如果只有1D，添加一个虚拟维度
        if c.shape[1] == 1:
            pos = {i: (c[i, 0], i) for i in G.nodes()}
    else:
        pos = nx.spring_layout(G, seed=42, weight='weight')
    
    # 节点大小基于权重
    node_weights = [G.nodes[node]['weight'] for node in G.nodes()]
    node_sizes = [3000 * w for w in node_weights]
    
    # 节点颜色基于权重
    node_colors = node_weights
    
    # 边宽度基于权重
    edge_weights = [G[u][v]['weight'] for u, v in G.edges()]
    edge_widths = [10 * w for w in edge_weights]
    
    # 绘制网络
    nodes = nx.draw_networkx_nodes(G, pos, 
                                  node_size=node_sizes,
                                  node_color=node_colors,
                                  cmap='viridis',
                                  alpha=0.8,
                                  edgecolors='black',
                                  linewidths=1,
                                  ax=ax1)
    
    nx.draw_networkx_edges(G, pos,
                          width=edge_widths,
                          alpha=0.6,
                          edge_color='gray',
                          ax=ax1)
    
    nx.draw_networkx_labels(G, pos,
                           font_size=10,
                           font_weight='bold',
                           ax=ax1)
    
    # 添加颜色条
    sm = plt.cm.ScalarMappable(cmap='viridis', 
                               norm=plt.Normalize(vmin=min(node_colors), 
                                                  vmax=max(node_colors)))
    sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax1, shrink=0.8)
    cbar.set_label('Node Weight (Cluster Proportion)')
    
    ax1.axis('off')
    
    plt.tight_layout()
    plt.show()