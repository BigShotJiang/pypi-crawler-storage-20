# /verify - 검증 (Shovel + Boris 방식)

> **Boris Cherny**: "피드백 루프가 있으면 품질이 2-3배 올라간다"
> **핵심**: Context Bias 제거 후 검증해야 진짜 검증

---

## 🔴 Context Bias 제거 (Boris 방식)

### 문제
```
같은 세션에서 검증하면 자기가 짠 코드라 문제를 못 봄
→ "Context Bias"
```

### 해결
```
/handoff → /clear → /verify
  (기록)   (초기화)   (검증)
```

### 검증 전 확인

```markdown
⚠️ 이 검증이 유효하려면:

□ /clear 실행했거나
□ 새 세션에서 시작했거나
□ /handoff 후 충분한 시간 경과

위 조건 중 하나 충족? → 계속
아니면? → /clear 먼저 실행 권장
```

---

## 🟢 Gate 검증 (Shovel 방식)

> **원칙**
> 1. `/gate`의 **개별 단계 실행**
> 2. **수시로** 실행 권장
> 3. 최종은 반드시 **/gate**

---

## 사용법

```bash
# 개별 검증
/verify typecheck    # 타입체크만
/verify lint         # 린트만
/verify test         # 테스트만
/verify build        # 빌드만

# 조합 검증
/verify typecheck lint   # 타입 + 린트

# 빠른 검증 (타입 + 린트)
/verify --quick

# 특정 파일/폴더
/verify lint src/modules/auth
/verify test src/modules/auth
```

---

## /verify vs /gate

| 항목 | /verify | /gate |
|------|---------|-------|
| 용도 | 수시 체크 | 최종 검증 |
| 단계 | 개별 선택 | 전체 필수 |
| 중단 | 안 함 | 실패 시 중단 |
| 증거 | 없음 | EVIDENCE.md |
| 완료 정의 | ❌ | ✅ |

**결론**: `/verify`는 개발 중 편의, `/gate`는 완료 정의

---

## TypeCheck

### 실행

```bash
/verify typecheck
# 또는
pnpm typecheck
pnpm tsc --noEmit
```

### 성공

```markdown
## ✅ TypeCheck 통과

| 항목 | 값 |
|------|-----|
| 파일 수 | {N} |
| 에러 | 0 |
| 시간 | {X}s |
```

### 실패

```markdown
## ❌ TypeCheck 실패

### 에러 목록

```
src/auth/login.ts:15:3
TS2322: Type 'string' is not assignable to type 'number'.
```

### 수정 제안
{구체적 수정 방법}

### 자동 수정?
일부 타입 에러는 자동 수정 불가. 수동 수정 필요.
```

---

## Lint

### 실행

```bash
/verify lint
# 또는
pnpm lint
pnpm eslint . --ext .ts,.tsx
```

### 성공

```markdown
## ✅ Lint 통과

| 항목 | 값 |
|------|-----|
| 파일 수 | {N} |
| 에러 | 0 |
| 경고 | {N} |
```

### 실패

```markdown
## ❌ Lint 실패

### 에러

```
src/auth/login.ts
  23:5  error  'result' is never used  @typescript-eslint/no-unused-vars
```

### 자동 수정 가능
```bash
pnpm lint --fix
```

실행하시겠습니까?
> **(y)** 자동 수정
> **(n)** 수동 수정
```

---

## Test

### 실행

```bash
/verify test
# 또는
pnpm test
pnpm vitest run
```

### 성공

```markdown
## ✅ Test 통과

```
Test Files  5 passed
     Tests  23 passed
  Duration  2.3s
```
```

### 실패

```markdown
## ❌ Test 실패

### 실패한 테스트

```
FAIL  src/auth/login.test.ts > should authenticate user
AssertionError: expected 200 to equal 401
```

### 분석
{원인 분석}

### 수정 제안
{제안}
```

### 특정 테스트만

```bash
/verify test auth
# → src/**/*auth*.test.ts 만 실행
```

---

## Build

### 실행

```bash
/verify build
# 또는
pnpm build
```

### 성공

```markdown
## ✅ Build 성공

| 항목 | 값 |
|------|-----|
| 시간 | {X}s |
| 출력 | dist/ |
| 크기 | {X}KB |
```

### 실패

```markdown
## ❌ Build 실패

### 에러

```
error TS2307: Cannot find module '@/core/errors'
```

### 원인
{원인}

### 수정 방법
{방법}
```

---

## 빠른 검증

### /verify --quick

```bash
# 타입 + 린트만 (빠름)
pnpm typecheck && pnpm lint
```

### 사용 시점

- 파일 5개마다
- Step 완료마다
- 커밋 전 빠른 체크

---

## 전체 결과

### 모두 성공

```markdown
## 🎉 검증 통과

| 단계 | 결과 | 시간 |
|------|------|------|
| TypeCheck | ✅ | {X}s |
| Lint | ✅ | {X}s |
| Test | ✅ | {X}s |

### 다음 단계
```bash
/gate    # 최종 검증 + EVIDENCE.md 생성
```

⚠️ **커밋 전 반드시 /gate 실행**
```

### 일부 실패

```markdown
## ⚠️ 검증 일부 실패

| 단계 | 결과 |
|------|------|
| TypeCheck | ✅ |
| Lint | ⚠️ 경고 {N}개 |
| Test | ❌ 실패 {M}개 |

### 필요한 조치
1. 테스트 실패 수정
2. 린트 경고 확인 (선택)

수정 후 다시 `/verify` 또는 `/gate`
```

---

## 팁

### 검증 빈도

```
많이 = 좋음

파일 수정 → /verify --quick
Step 완료 → /verify
모든 구현 완료 → /gate
```

### Gate와의 관계

```
/verify = 개발 중 피드백 (선택)
/gate = 완료 정의 (필수)

/verify 통과해도 /gate는 필수!
```
