# [1.1.0](https://github.com/oddessentials/ado-git-repo-insights/compare/v1.0.6...v1.1.0) (2026-01-13)


### Features

* expand CI matrix for cross-platform testing and consolidate docs ([8d88fb4](https://github.com/oddessentials/ado-git-repo-insights/commit/8d88fb4980de07ef83de35babd8c574a83eef6c1))

## [1.0.6](https://github.com/oddessentials/ado-git-repo-insights/compare/v1.0.5...v1.0.6) (2026-01-13)


### Bug Fixes

* Resolve deprecation warnings and add coverage threshold ([139cc7e](https://github.com/oddessentials/ado-git-repo-insights/commit/139cc7ea0643bfac9a2ed88d8742e2a9b2e15727))

## [1.0.5](https://github.com/oddessentials/ado-git-repo-insights/compare/v1.0.4...v1.0.5) (2026-01-13)


### Bug Fixes

* Match PyPI environment name to trusted publisher config ([f106638](https://github.com/oddessentials/ado-git-repo-insights/commit/f106638d18a141ecd9825eeeb12949b5294d16bc))

## [1.0.4](https://github.com/oddessentials/ado-git-repo-insights/compare/v1.0.3...v1.0.4) (2026-01-13)


### Bug Fixes

* Add pandas-stubs to dev dependencies for CI mypy ([902045c](https://github.com/oddessentials/ado-git-repo-insights/commit/902045cdf7ec71348918bc2abd116fd4be587283))

## [1.0.3](https://github.com/oddessentials/ado-git-repo-insights/compare/v1.0.2...v1.0.3) (2026-01-13)


### Bug Fixes

* Fix formatting and add pre-push quality gates ([3c4399e](https://github.com/oddessentials/ado-git-repo-insights/commit/3c4399e324fd4fc37611b28a6211cad87ae5ddb2))

## [1.0.2](https://github.com/oddessentials/ado-git-repo-insights/compare/v1.0.1...v1.0.2) (2026-01-13)


### Bug Fixes

* Re-enable PyPI publishing after trusted publisher setup ([83285e8](https://github.com/oddessentials/ado-git-repo-insights/commit/83285e8f59fe171166024b4fb39dba28f77fd6e7))

## [1.0.1](https://github.com/oddessentials/ado-git-repo-insights/compare/v1.0.0...v1.0.1) (2026-01-13)


### Bug Fixes

* Make PyPI publishing optional with continue-on-error ([21ef435](https://github.com/oddessentials/ado-git-repo-insights/commit/21ef4358888e9a9c808cb46acc6e7cb58cc299d9))

# 1.0.0 (2026-01-13)


### Bug Fixes

* Add explicit generic type parameters for mypy strict mode ([fc0dd3b](https://github.com/oddessentials/ado-git-repo-insights/commit/fc0dd3b84a6ad561111a5ed4d6984ce037724c89))


### Features

* Add semantic-release for automated versioning ([8e61606](https://github.com/oddessentials/ado-git-repo-insights/commit/8e61606608c24bf296dd6297eb979e7d0fddacf2))
* Close all implementation gaps ([a13b5f0](https://github.com/oddessentials/ado-git-repo-insights/commit/a13b5f0b92cd7142349749f410a22583d9bed3dd))
* Integration tests for Victory Gates 1.3-1.5 ([7ba49af](https://github.com/oddessentials/ado-git-repo-insights/commit/7ba49afb176e3a3c62d486c5ed42644648dd0987))
* phase 1 & 2 ([f922a03](https://github.com/oddessentials/ado-git-repo-insights/commit/f922a03661db0ac49ea53c382c6d24e10eb70ae0))
* Phase 1 & 2 - Repository foundation and persistence layer ([a0a3fe9](https://github.com/oddessentials/ado-git-repo-insights/commit/a0a3fe99d2d9ec664376b5186c52cfd19e0616fd))
* Phase 11 - Extension metadata, icon, and Node20 upgrade ([4ac18bf](https://github.com/oddessentials/ado-git-repo-insights/commit/4ac18bf553478e7210115b29f9945d30cc3cdcbf))
* Phase 3 - Extraction strategy with ADO client ([570e0ee](https://github.com/oddessentials/ado-git-repo-insights/commit/570e0ee086cf45263137e3cbb2c73cea2dd40726))
* Phase 4 - CSV generation with deterministic output ([6a95612](https://github.com/oddessentials/ado-git-repo-insights/commit/6a95612cdaf243b27d304942c7e14e2bf3767b27))
* Phase 5 - CLI integration and secret redaction ([0ed0cce](https://github.com/oddessentials/ado-git-repo-insights/commit/0ed0cce375b78b393e30f11bdf41ed23b50b003f))
* Phase 7 CI/CD and Phase 10 rollout ([d22e548](https://github.com/oddessentials/ado-git-repo-insights/commit/d22e5488d32276a169d701e78758f250f66a77be))
