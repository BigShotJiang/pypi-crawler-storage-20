# nlsmodels

[![PyPI version](https://img.shields.io/pypi/v/nlsmodels.svg)](https://pypi.org/project/nlsmodels/)
[![Python Versions](https://img.shields.io/pypi/pyversions/nlsmodels.svg)](https://pypi.org/project/nlsmodels/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

**nlsmodels** is a Python package for Nonlinear Least Squares regression, inspired by R's `nls()` function. It provides an intuitive interface for fitting nonlinear models with comprehensive diagnostics.

## Features

**Intuitive formula syntax** (`y ~ a * exp(b * x)`)
**Auto-initialization** for common models (SSlogis, SSexpo, SSmicmen, SSgompertz)
**Comprehensive diagnostics** (residuals, leverage, Cook's distance)
Statistical metrics** (AIC, BIC, R², confidence intervals)
Visualization tools** (residual plots, diagnostic plots)
**Robust error handling** and validation

## Installation

```bash
pip install nlsmodels
