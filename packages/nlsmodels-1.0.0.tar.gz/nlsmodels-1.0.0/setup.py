from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r") as f:
    requirements = f.read().splitlines()

setup(
    name="nlsmodels",
    version="1.0.0",
    author="Juan David Garcia",
    author_email="juandavidgh2011@gmail.com",
    description="Nonlinear Least Squares regression models for Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/tuusuario/nlsmodels",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Topic :: Scientific/Engineering",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Topic :: Scientific/Engineering :: Information Analysis",
    ],
    python_requires=">=3.7",
    install_requires=requirements,
    keywords=[
        "statistics",
        "regression", 
        "nonlinear",
        "least-squares",
        "modeling",
        "data-science"
    ],
    project_urls={
        "Bug Reports": "https://github.com/tuusuario/nlsmodels/issues",
        "Source": "https://github.com/tuusuario/nlsmodels",
        "Documentation": "https://github.com/tuusuario/nlsmodels#readme",
    },
)