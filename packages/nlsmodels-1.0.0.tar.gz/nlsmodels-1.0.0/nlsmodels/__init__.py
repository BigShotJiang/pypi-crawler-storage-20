"""
nlsmodels
=========
Nonlinear Least Squares Regression Models
"""

__version__ = "0.1.0"
__author__ = "Juan David Garcia"
__email__ = "juandavidgh2011@gmail.com"

# Importar la clase principal
from .core import nls


# --------------------------------------------------
# Alias de clase (nombre alternativo)
# --------------------------------------------------
class NonReg(nls):
    """
    Alias for nls class.
    Provides exactly the same functionality as nls.
    """
    pass


# --------------------------------------------------
# Función de fábrica (API funcional)
# --------------------------------------------------
def nonreg(formula, data, p0=None):
    """
    Factory function for nonlinear regression.

    Parameters
    ----------
    formula : str
        Model formula, e.g. "y ~ a * exp(b * x)"
    data : pandas.DataFrame
        Dataset containing variables
    p0 : dict, optional
        Initial parameter guesses

    Returns
    -------
    NonReg
        Instance of nonlinear regression model
    """
    return NonReg(formula, data, p0)


# --------------------------------------------------
# API pública
# --------------------------------------------------
__all__ = [
    "nls",
    "NonReg",
    "nonreg",
]
