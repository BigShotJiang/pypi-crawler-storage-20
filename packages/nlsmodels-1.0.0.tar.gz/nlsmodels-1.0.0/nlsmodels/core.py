from logging import info
import sys, subprocess
from time import time_ns

from statsmodels.iolib.summary import summary_return
packages = ["numpy", "pandas", "scipy", "statsmodels","sympy","matplotlib"]
for p in packages:
    try:
        __import__(p)
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", p])


import numpy as np
import sympy as sp
import pandas as pd
from scipy.optimize import least_squares
from sympy import sympify, symbols, lambdify
import scipy.stats as stats
from statsmodels.iolib.table import SimpleTable
from datetime import date
import matplotlib.pyplot as plt
import re

class nls:
    def __init__(self,formula, data, p0 = None):

        """
        NonLinear Least Squares regression model.
        
        Parameters
        ----------
        formula : str
            Formula specifying the nonlinear model in format "y ~ f(x, theta)".
            Special functions supported: SSlogis, SSexpo, SSmicmen, SSgompertz.
            Example: "y ~ SSlogis(x, Asym, xmid, scal)" or "y ~ a * exp(b * x)"
        
        data : pd.DataFrame
            DataFrame containing all variables referenced in the formula.
        
        p0 : Optional[Dict[str, float]], default=None
            Initial parameter guesses. If None, defaults to 1.0 for all parameters
            or uses auto-initialization for special functions (SSlogis, SSexpo, etc.).
        
        Raises
        ------
        ValueError
            If formula is malformed, variables are missing from data, 
            or other validation errors occur.
        
        Notes
        -----
        Parameter and variable identification:
        - Symbols found in DataFrame columns are treated as exogenous variables
        - Symbols NOT found in columns are treated as parameters to estimate
        - Parameters without initial values in p0 are initialized to 1.0
        - For special functions (SSlogis, SSexpo, etc.), initial values are 
          automatically calculated from the data
        
        Examples
        --------
        >>> import numpy as np
        >>> import pandas as pd
        >>> # Exponential data
        >>> x = np.linspace(0, 5, 50)
        >>> y = 2.5 * np.exp(0.8 * x) + np.random.normal(0, 0.5, 50)
        >>> df = pd.DataFrame({'x': x, 'y': y})
        >>> 
        >>> # Fit model with explicit initial values
        >>> model = nls("y ~ a * exp(b * x)", df, p0={'a': 1, 'b': 0.5})
        >>> model.fit()
        >>> model.summary()
        >>> 
        >>> # Using auto-initialization (parameters default to 1.0)
        >>> model2 = nls("y ~ a * exp(b * x)", df)  # a=1, b=1
        >>> model2.fit()
        >>> 
        >>> # Special function with auto-initialization
        >>> model3 = nls("y ~ SSlogis(x, Asym, xmid, scal)", df)
        >>> model3.fit()
        """
        """
        ...
        
        Notes
        -----
        Important: Python is case-sensitive
        - 'X' and 'x' are DIFFERENT variables
        - Formula variables must match DataFrame column names exactly
        - If you get a "variable not found" error, check your spelling and case
        
        Parameter and variable identification:
        1. Symbols that EXACTLY match DataFrame columns → variables
        2. Symbols NOT in columns → parameters to estimate
        3. The system will suggest possible case mismatches
        
        Examples
        --------
        >>> df = pd.DataFrame({'X': [1, 2, 3], 'Y': [2, 4, 8]})
        
        # CORRECT: matches column names exactly
        >>> model = nls("Y ~ a * X ** b", df, p0={'a': 1, 'b': 1})
        
        # ERROR: case mismatch (will suggest correction)
        >>> model = nls("y ~ a * x ** b", df)  # Error: 'y' not found, did you mean 'Y'?
        
        # Parameters are always lowercase in this example
        >>> model = nls("Y ~ A * X ** B", df)  # A, B are parameters (not in columns)
        """

        # Validate formula structure

        if "~" not in formula:
            raise ValueError("Formula must contain '~'")
        
        # Validate data type
        if not isinstance(data, pd.DataFrame):
            raise ValueError("Data must be a pandas DataFrame")
        
        if p0 is not None and not isinstance(p0, dict):
            raise ValueError("p0 must be a dictionary")


        # Store inputs
        self.formula = formula
        self.data = data
        names_colums = list(self.data.keys())

        # Parse formula: split into left-hand side (response) and right-hand side (model)
        lhs, rhs = formula.strip().split("~")

        # Handle special functions for auto-initialization
        if 'SSlogis' in self.formula:
            # Parse SSlogis(variable, Asym, xmid, scal) - logistic growth model
            # f(x) = Asym / (1 + exp((xmid - x) / scal))
            search_logis = re.search(r'\(([^,]+), ([^,]+), ([^,]+), ([^)]+)\)', rhs)
            exog_name, *thetas = search_logis.groups()
            exogenous = [exog_name]
            thetas = list(thetas)
            func_log = f'{thetas[0]} / (1 + exp(({thetas[1]} - {exogenous[0]})/{thetas[2]}))'
            function = sp.sympify(func_log)

            if not search_logis:
                raise ValueError("SSlogis syntax must be: SSlogis(variable, Asym, xmid, scal)")

        # Parse SSexpo(variable, a, b) - exponential model
        elif 'SSexpo' in self.formula:
            # Parse SSexpo(variable, a, b)
            # f(x) = a * exp(b * x)
            search_expo = re.search(r'SSexpo\(\s*([^,]+),\s*([^,]+),\s*([^,]+)\s*\)', rhs)
            exog_name, *thetas = search_expo.groups()
            exogenous = [exog_name]
            thetas = list(thetas)
            func_expo = f'{thetas[0]} * exp({exog_name}*{thetas[1]})'
            function = sp.sympify(func_expo)
            
            if not search_expo:
                raise ValueError("SSexpo syntax must be: SSexpo(variable, a, b)")
        
        elif 'SSmicmen' in self.formula:
            # Parse SSmicmen(variable, Vmax, Km) - Michaelis-Menten model
            # f(x) = Vmax * x / (Km + x)
            search_expo = re.search(r'SSmicmen\(\s*([^,]+),\s*([^,]+),\s*([^,]+)\s*\)', rhs)
            exog_name, *thetas = search_expo.groups()
            exogenous = [exog_name]
            thetas = list(thetas)
            func_micmen = f'{thetas[0]} * {exog_name} /({thetas[1]} + {exog_name})'
            function = sp.sympify(func_micmen)
            
            if not search_expo:
                raise ValueError("SSmicmen syntax must be: SSmicmen(variable, Vmax, Km)")
        
        elif 'SSgompertz' in self.formula:
            # Parse SSgompertz(variable, A, B, C) - Gompertz model
            # f(x) = A * exp(-exp((B - x) / C))
            search_gompertz = re.search(r'SSgompertz\(\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*([^,]+)\s*\)', rhs)
            exog_name, *thetas = search_gompertz.groups()
            exogenous = [exog_name]
            thetas = list(thetas)
            func_gompertz = f'{thetas[0]} * exp(-exp(({thetas[1]} - {exog_name})/{thetas[2]}))'
            function = sp.sympify(func_gompertz)
            
            if not search_gompertz:
                raise ValueError("SSgompertz syntax must be: SSgompertz(variable, A, B, C)")

        else:
            # General nonlinear formula - parse symbols
            function = sp.sympify(rhs)
            all_symbols = list(function.free_symbols)
            exogenous = [str(sym) for sym in all_symbols if str(sym) in names_colums]
            thetas = [str(sym) for sym in all_symbols if str(sym) not in names_colums]
        
        # Separate exogenous variables (in data) from parameters (to estimate)
        self._thetas = thetas  # Parameter names to estimate
        self._exogenous = exogenous  # Exogenous variable names
        self._endogenous = lhs.strip()  # Response variable name


        # Validate that all required variables exist in data
        for exg in exogenous:
            if exg not in self.data.columns:
                raise ValueError(f"Exogenous variable '{exg}' not found in data")
        if self._endogenous not in self.data.columns:
            raise ValueError(f"Endogenous variable '{self._endogenous}' not found in data")

        # Validate that no variables contain NaN values
        for var in self._exogenous + [self._endogenous]:
            if self.data[var].isna().any():
                raise ValueError(f"Variable '{var}' contains NaN values")

        # Validate sufficient observations
        if len(self.data) < len(self._thetas):
            raise ValueError(
                f"Insufficient observations ({len(self.data)}) "
                f"for {len(self._thetas)} parameters. "
                f"Need at least {len(self._thetas)} observations.")
        
        # Extract data arrays for optimization
        self.exog = self.data[self._exogenous].values # Predictor matrix 
        self.endog = self.data[self._endogenous].values # Response vector

        
        # Create callable function for predictions
        args = self._exogenous + self._thetas
        self._func = sp.lambdify(args, function, 'numpy') # Convert symbolic function to numpy callable

        self._params = None  # Estimated parameters
        self._resid = None  # Residuals
        self._jac = None  # Jacobian matrix
        self._mse = None  # Mean squared error
        self._rss = None  # Residual sum of squares
        self._aic = None  # Akaike information criterion
        self._bic = None  # Bayesian information criterion
        self._cov = None  # Covariance matrix
        self._rsquared = None  # R-squared
        self._log_lik = None  # Log-likelihood
        self._df_resid = None  # Degrees of freedom
        self._resid_pearson = None  # Pearson residuals
        self._leverage = None  # Leverage values
        self._cook_distance = None  # Cook's distance

        def _calcular_iniciales_logistico(x, y, SS):
            """
            Calculate intelligent initial parameter guesses for logistic/exponential/other models.
            
            Parameters
            ----------
            x : np.ndarray
                Predictor variable values.
            y : np.ndarray
                Response variable values.
            model_type : str
                Either 'SSlogis' or 'SSexpo'.
            
            Returns
            -------
            Dict[str, float]
                Dictionary of initial parameter values.
            """
            
            if SS == 'SSlogis':
                # Logistic model: y = Asym / (1 + exp((xmid - x)/scal))
                max_y = np.max(y)
                Asym = max_y * 1.05  # Slightly above maximum for asymptote
            
                mitad_Asym = Asym / 2 # Slightly above maximum for asymptote

                # Find x value where y crosses mitad_Asym
                # If no crossing point, use median of x
                idx = np.where(y >= mitad_Asym)[0]
                if len(idx) > 0 and idx[0] > 0:
                    i = idx[0]
                    x1, y1 = x[i-1], y[i-1]
                    x2, y2 = x[i], y[i]
                    
                    # Linear interpolation to find exact xmid
                    xmid = x1 + (mitad_Asym - y1) * (x2 - x1) / (y2 - y1)
                else:
                    xmid = np.median(x)
                
                # Estimate scale parameter from slope at inflection point
                if 'x1' in locals() and 'x2' in locals():
                    pendiente = (y2 - y1) / (x2 - x1)
                    scal = Asym / (4 * pendiente)
                else:
                    scal = (np.max(x) - np.min(x)) / 10 # Theoretical relationship for logistic
                
                inic_theta = {f'{self._thetas[0]}': Asym, f'{self._thetas[1]}': xmid.item(), f'{self._thetas[2]}': scal.item()}
            
            elif SS == 'SSexpo':

                # Exponential model: y = a * exp(b * x)
                # Fit log(y) = log(a) + b*x using linear regression
                poly = np.polyfit(x, np.log(np.abs(y)), 1)
                A = np.exp(poly[1])
                B = -poly[0]
                inic_theta = {f'{self._thetas[0]}': A, f'{self._thetas[1]}': B}
            
            elif SS == 'SSmicmen':
                # Michaelis-Menten model: y = Vmax * x / (Km + x)
                Vmax = np.max(y) * 1.1  
                Vmax_median = Vmax / 2
                idx = np.argmin(np.abs(y - Vmax_median))
                Km = x[idx]
                
                if abs(y[idx] - Vmax_median) > Vmax_median * 0.5:   
                    Km = np.median(x)
                
                Vmax = max(Vmax, 1e-10)
                Km = max(Km, 1e-10)
                        
                inic_theta = {f'{self._thetas[0]}': Vmax, f'{self._thetas[1]}': Km}
            
            elif SS == 'SSgompertz':
                # Gompertz model: y = A * exp(-exp((B - x) / C))
                # Fit using nonlinear least squares with bounds
                # Initial guess: A = 1.05 * max(y)
                
                A = 1.05 * np.max(y)

                y_rel = y / A
                Y = np.log(-np.log(y_rel))

                # Filtrar valores finitos (importante!)
                mask = np.isfinite(Y)
                x_clean = x[mask]
                Y_clean = Y[mask]

                # Regresión lineal
                poly = np.polyfit(x_clean, Y_clean, 1)

                # Parámetros CORRECTOS:
                alpha = poly[1]   # Intercepto (α = B/C)
                beta = poly[0]    # Pendiente (β = -1/C)

                C = -1 / beta      # Porque β = -1/C ⇒ C = -1/β
                B = C * alpha
                inic_theta = {f'{self._thetas[0]}': A, f'{self._thetas[1]}': B, f'{self._thetas[2]}': C}
            
            else:
                raise ValueError(f"Unsupported model type: {SS}")
                
            # Return dictionary with parameter names from formula
            return inic_theta


        # Set initial parameter values (p0)
        if 'SSlogis' in self.formula:
            # Auto-initialize logistic parameters  
            self.p0 = _calcular_iniciales_logistico(self.exog, self.endog, 'SSlogis')
        
        elif 'SSexpo' in self.formula:
            # Auto-initialize exponential parameters
            self.p0 = _calcular_iniciales_logistico(self.exog[:,0], self.endog, 'SSexpo')
        
        elif 'SSmicmen' in self.formula:
            self.p0 = _calcular_iniciales_logistico(self.exog[:,0], self.endog, 'SSmicmen')
        
        elif 'SSgompertz' in self.formula:
            self.p0 = _calcular_iniciales_logistico(self.exog[:,0], self.endog, 'SSgompertz')

        elif p0 is None:
            # Default: all parameters initialized to 1.0
            self.p0 = {}
            for theta in self._thetas:
                self.p0[theta] = 1
        
        # parameter validation

        else:
            if len(p0) != len(self._thetas):
                raise ValueError(
                    f"Parameter count mismatch: p0 has {len(p0)} value(s) "
                    f"but formula needs {len(self._thetas)} parameter(s).\n"
                    f"Formula: {self.formula}\n"
                    f"Provide initial values for: {', '.join(self._thetas)}"
                )
            else:
                self.p0 = p0
        
    def fit(self, 
    method='trf', 
    ftol=1e-08, 
    xtol=1e-08, 
    gtol=1e-08, 
    x_scale=None,
    loss='linear', 
    f_scale=1.0, 
    diff_step=None, 
    tr_solver=None,
    tr_options=None, 
    jac_sparsity=None, 
    max_nfev=None, 
    verbose=0, 
    kwargs=None, 
    callback=None, 
    workers=None):

        """
        Fit the nonlinear model to data using least squares optimization.
        
        Parameters
        ----------
        method : str, default='trf'
            Optimization algorithm:
            - 'trf': Trust Region Reflective (default, robust)
            - 'lm': Levenberg-Marquardt (fast for small problems)
            - 'dogbox': dogleg algorithm with rectangular trust regions
        ftol : float, default=1e-8
            Tolerance for termination by change of the cost function.
        xtol : float, default=1e-8
            Tolerance for termination by change of the independent variables.
        gtol : float, default=1e-8
            Tolerance for termination by the norm of the gradient.
        x_scale : Optional[str], default=None
            Characteristic scale of each variable.
        loss : str, default='linear'
            Loss function. 'linear' is standard least squares.
        f_scale : float, default=1.0
            Value of soft margin between inlier and outlier residuals.
        diff_step : Optional[float], default=None
            Determines the relative step size for finite difference approximation.
        tr_solver : Optional[str], default=None
            Method for solving trust region subproblems.
        tr_options : Optional[Dict], default=None
            Additional options passed to the trust region solver.
        jac_sparsity : Optional[Any], default=None
            Sparsity structure of the Jacobian matrix.
        max_nfev : Optional[int], default=None
            Maximum number of function evaluations.
        verbose : int, default=0
            Level of algorithm's verbosity: 0 (silent) to 2 (detailed).
        kwargs : Optional[Dict], default=None
            Additional keyword arguments passed to the optimizer.
        callback : Optional[Callable], default=None
            Function called after each iteration.
        workers : Optional[int], default=None
            Number of CPU cores to use for parallel Jacobian computation.
        
        Returns
        -------
        self : nls
            Returns the instance itself for method chaining.
        
        Notes
        -----
        The optimization uses SciPy's least_squares function which implements
        modified versions of Levenberg-Marquardt and trust-region algorithms.
        """

        def residual(parms,X,Y):

            """
            Residual function for optimization: predicted - observed.
            
            Parameters
            ----------
            params : np.ndarray
                Current parameter values.
            X : np.ndarray
                Predictor variables matrix.
            Y : np.ndarray
                Observed response vector.
            
            Returns
            -------
            np.ndarray
                Residual vector (predicted - observed).
            """
            # Evaluate model function with current parameters

            result = self._func(*X.T, *parms)
            return result - Y
        
        # Convert initial parameter dictionary to array in correct order
        initial_theta = [self.p0[name] for name in self._thetas]

        # Perform nonlinear least squares optimization

        try:
            results = least_squares(fun = residual, 
            x0=initial_theta, 
            args=(self.exog, self.endog), 
            method=method,
            ftol=ftol, 
            xtol=xtol, 
            gtol=gtol, 
            x_scale=x_scale, 
            loss=loss, 
            f_scale=f_scale, 
            diff_step=diff_step, 
            tr_solver=tr_solver,
            tr_options=tr_options, 
            jac_sparsity=jac_sparsity, 
            max_nfev=max_nfev, 
            verbose=verbose, 
            kwargs=kwargs, 
            callback=callback, 
            workers=workers)
        except Exception as e:
            print(f"Optimization failed: {e}")
        
        if not results.success:
            print(f"WARNING: Optimization did not converge: {results.message}")
            print("Parameters may not be reliable")
        
        if results.success:
            print("Optimization successful")
            print(f"Message: {results.message}")
        else:
            print("Optimization failed")
            print(f"Message: {results.message}")
        print(f"Function evaluations: {results.nfev}")
        print("-"*80)
        print("\n")
        
        # Store optimization results
        self._params = results.x # Estimated parameters
        self._resid = results.fun # Residuals
        self._jac = results.jac # Jacobian matrix
        self._success = results.success # Optimization success flag
        self._message = results.message # Optimization message
        self._nfev = results.nfev # Number of function evaluations
        self._njev = getattr(results, 'njev', 0) # Number of Jacobian evaluations

        return self
    
    @property
    def success(self):
        if self._success is None:
            raise RuntimeError("Model not fitted.")
        return self._success  # ¡Fuera del if!
    
    @property
    # Get estimated parameters
    def params(self):
        """
        Estimated model parameters.
        
        Returns
        -------
        np.ndarray
            Array of estimated parameter values in the order defined by self._thetas.
        
        Raises
        ------
        ValueError
            If model hasn't been fitted yet.
        """

        if self._params is None:
            raise ValueError("Model must be fitted before accessing parameters")
        return self._params
    
    @property
    # Get leverage values
    def leverage(self):
        """
        Leverage (hat) values for each observation.
        
        Leverage measures the influence of each observation on its own fitted value.
        High leverage points (close to 1) have potential to influence parameter estimates.
        
        Returns
        -------
        np.ndarray
            Leverage values for each observation (between 0 and 1).
        
        Notes
        -----
        Calculated as diagonal of the hat matrix: H = J(J'J)^(-1)J'
        where J is the Jacobian matrix.
        """
        if hasattr(self, '_jac') and self._jac is not None:
            h = np.diag(self._jac @ np.linalg.pinv(self._jac.T @ self._jac) @ self._jac.T)
            return h
        else:
            raise RuntimeError("Jacobian matrix not available. Model must be fitted first.")

    @property
    # Get residuals
    def resid(self):
        """
        Raw residuals (observed - predicted).
        
        Returns
        -------
        np.ndarray
            Residuals for each observation.
        
        Raises
        ------
        RuntimeError
            If model hasn't been fitted yet.
        """
        if self._resid is None:
            raise RuntimeError("Model not fitted.")
        return self._resid
    
    @property
    # Get Pearson residuals
    def resid_pearson(self):
        """
        Standardized Pearson residuals.
        
        Pearson residuals are scaled by their estimated standard deviation,
        making them approximately N(0,1) under model assumptions.
        
        Returns
        -------
        np.ndarray
            Standardized residuals.
        
        Notes
        -----
        For nonlinear models: r_i = e_i / sqrt(MSE * (1 - h_ii))
        where h_ii are leverage values.
        """
        if hasattr(self, '_jac') and self._jac is not None:

            h = np.diag(self._jac @ np.linalg.pinv(self._jac.T @ self._jac) @ self._jac.T)
            se_residuals = np.sqrt( (1 - h) * self.mse )

        else:

            se_residuals = np.sqrt(self.mse)

        self._resid_pearson = self._resid / se_residuals
    
        return self._resid_pearson
       
    @property
    # Get residual sum of squares
    def rss(self):
        """
        Residual Sum of Squares (RSS).
        
        RSS = Σ(y_i - ŷ_i)²
        Measures total unexplained variation in the data.
        
        Returns
        -------
        float
            Sum of squared residuals.
        """
        if self._rss is None:
            self._rss = np.sum(self.resid ** 2)
        return self._rss
    
    @property
    # Get mean squared error
    def mse(self):
        """
        Mean Squared Error (MSE).
        
        MSE = RSS / (n - p)
        where n = number of observations, p = number of parameters.
        
        Returns
        -------
        float
            Unbiased estimate of error variance.
        
        Notes
        -----
        Denominator uses (n-p) for degrees of freedom correction.
        """
        if self._mse is None:
            self._mse = np.sum(self.resid ** 2) / (len(self.exog) - len(self._thetas))
        return self._mse
    
    @property
    # Get covariance matrix
    def cov(self):
        """
        Covariance matrix of parameter estimates.
        
        Returns
        -------
        np.ndarray
            p × p covariance matrix where p = number of parameters.
        
        Notes
        -----
        Estimated as: MSE * (J'J)^(-1)
        where J is the Jacobian matrix evaluated at the solution.
        This assumes errors are homoscedastic and uncorrelated.
        """
        if self._cov is None:
            self._cov = self.mse * np.linalg.pinv(self._jac.T @ self._jac)
        return self._cov
    
    @property
    # Get Akaike information criterion
    def aic(self):
        """
        Akaike Information Criterion (AIC).
        
        AIC = n * ln(RSS/n) + 2k
        where n = sample size, k = number of parameters.
        
        Returns
        -------
        float
            AIC value for model comparison (lower is better).
        
        Notes
        -----
        Used for model selection. Penalizes model complexity.
        """
        if self._aic is None:
            n = len(self.endog)
            k = len(self.params)
            self._aic = n * np.log(self.rss / n) + 2 * k
        return self._aic
    
    @property
    # Get Bayesian information criterion
    def bic(self):
        """
        Bayesian Information Criterion (BIC).
        
        BIC = n * ln(RSS/n) + k * ln(n)
        where n = sample size, k = number of parameters.
        
        Returns
        -------
        float
            BIC value for model comparison (lower is better).
        
        Notes
        -----
        Similar to AIC but with stronger penalty for complexity.
        Preferred for larger samples.
        """
        if self._bic is None:
            n = len(self.endog)
            k = len(self.params)
            self._bic = n * np.log(self.rss / n) + k * np.log(n)
        return self._bic
    
    @property
    # Get coefficient of determination
    def rsquared(self):
        """
        Coefficient of determination (R²).
        
        R² = 1 - (RSS / TSS)
        where TSS = total sum of squares.
        
        Returns
        -------
        float
            Proportion of variance explained by the model (0 to 1).
        
        Notes
        -----
        For nonlinear models, R² can be negative if model fits worse
        than a horizontal line at the mean.
        """
        if self._rsquared is None:
            tss = np.sum((self.endog - np.mean(self.endog)) ** 2)
            self._rsquared = 1 - (self.rss / tss)
        return self._rsquared
    
    @property
    # Get log-likelihood
    def log_lik(self):
        """
        Log-likelihood of the model.
        
        Assumes normally distributed errors with constant variance.
        
        Returns
        -------
        float
            Log-likelihood value.
        
        Notes
        -----
        Formula: -n/2 * ln(2π) - n/2 * ln(MSE) - RSS/(2*MSE)
        """
        n = len(self.endog)
        if self._log_lik is None:
            self._log_lik = - (n/2) * np.log(2 * np.pi) - (n/2) * np.log(self.mse) - self.rss / (2 * self.mse)
        return self._log_lik
    
    @property
    # Get degrees of freedom for residuals
    def df_resid(self):
        """
        Residual degrees of freedom.
        
        Returns
        -------
        int
            Degrees of freedom for residuals: n - p.
        """
        if self._df_resid is None:
            self._df_resid = len(self.endog) - len(self.params)
        return self._df_resid
    
    @property

    def cook_distance(self):
        """
        Cook's distance for each observation.
        
        Returns
        -------
        np.ndarray
            Cook's distance for each observation.
        """
        if self._params is None:
            raise RuntimeError("Model must be fitted before computing Cook's distance")
        
        if not hasattr(self, '_cook_distance') or self._cook_distance is None:
            h = self.leverage
            p = len(self._thetas)
            self._cook_distance = (self.resid_pearson ** 2 / p) * (h / (1 - h) ** 2)
        
        return self._cook_distance

    # Predict method
    def predict(self, new_data=None):

        """
        Generate predictions from the fitted model.
        
        Parameters
        ----------
        new_data : pd.DataFrame, optional
            DataFrame containing exogenous variables for prediction.
            If None, uses training data.
        
        Returns
        -------
        np.ndarray
            Predicted values.
        
        Notes
        -----
        If new_data contains the endogenous variable column, it is dropped.
        """

        if new_data is None:
            X = self.data[self._exogenous].values
        else:
            if self._endogenous in new_data.columns:
                missing_cols = [col for col in self._exogenous if col not in new_data.columns]
                if missing_cols:
                    raise ValueError(f"Faltan variables en new_data: {missing_cols}")
                new_df = new_data.drop(columns=self._endogenous)
            else:
                missing_cols = [col for col in self._exogenous if col not in new_data.columns]
                if missing_cols:
                    raise ValueError(f"Faltan variables en new_data: {missing_cols}")
                new_df = new_data.copy()
        
            X = new_df[self._exogenous].values
        return self._func(*X.T, *self.params)
    
    
    # Confidence intervals
    def conf_int(self, alpha=0.05):
        """
        Confidence intervals for parameters.
        
        Parameters
        ----------
        alpha : float, default=0.05
            Significance level (95% CI by default).
        
        Returns
        -------
        SimpleTable
            Table with lower and upper bounds for each parameter.
        
        Notes
        -----
        Based on t-distribution with n-p degrees of freedom.
        Assumes asymptotic normality of parameter estimates.
        """
        n = len(self.exog)
        p = len(self._thetas)
        
        SE_theta = np.sqrt(np.diag(self.cov))
        IC_lower = self.params - stats.t.ppf(1 - alpha/2, n-p) * SE_theta
        IC_upper = self.params + stats.t.ppf(1 - alpha/2, n-p) * SE_theta

        data = [
            [f"{lw:8.3f}",f"{up:8.3f}"]
            for lw, up in zip(IC_lower, IC_upper)
        ]

        conf_int_table = SimpleTable(
            data,
            headers=[f"[{alpha/2:.3f}",f"{1-alpha/2:.3f}]"],
            stubs=self._thetas)
        
        return conf_int_table

    # Summary method
    def summary(self,alpha = 0.05):
        
        from statsmodels.iolib.table import SimpleTable
        from statsmodels.iolib.summary import Summary
        from datetime import datetime

        # Model information
        n = len(self.exog)
        p = len(self._thetas)
        
        # Date and time
        now = datetime.now()
        date_day = now.strftime("%Y-%m-%d")
        time_ns = now.strftime("%H:%M:%S")    

        # Parameter estimates
        params = np.asarray(self.params)
        SE_theta = np.sqrt(np.diag(self.cov))

        # t-tests and confidence intervals
        tvals = params / SE_theta
        pvals = 2 * (1 - stats.t.cdf(np.abs(tvals), n - p))
        IC_lower = self.params - stats.t.ppf(1 - alpha/2, n-p) * SE_theta
        IC_upper = self.params + stats.t.ppf(1 - alpha/2, n-p) * SE_theta

        # Model fit statistics
        # Total Sum of Squares
        tss = np.sum((self.endog - np.mean(self.endog)) ** 2)
        # Explained Sum of Squares
        ess = tss - self.rss
        # Degrees of freedom
        df_model = p
        df_resid = n - p - 1
        # F-statistic
        F_stat = (ess / df_model) / (self.rss / df_resid)
        # p-value
        f_p_value = 1 - stats.f.cdf(F_stat, df_model, df_resid)

        # Adjusted R-squared
        rsquared = 1 - self.rss / tss
        rsquared_abj = 1 - (1-rsquared)*(n-1)/(n-p-1)

        # General information
        general_info = [
            ["Dep. Variable:",f"{self._endogenous}","Pseudo-R:",f"{rsquared:.3f}"],
            ["Model:","NLS","Adj. Pseudo-R:",f"{rsquared_abj:.3f}"],
            ["Method:","Least Squares","F-statistic:",f"{F_stat:.3f}"],
            ["Date:",f"{date_day}","Prob (F-statistic):",f"{f_p_value:.3f}"],
            ["Time:",f"{time_ns}","Log-Likelihood:",f"{self.log_lik:.3f}"],
            ["No. observations:",f"{n}","AIC:",f"{self.aic:.3f}"],
            ["Df Residuals:",f"{n-p}","BIC:",f"{self.bic:.3f}"],
            ["Df Model:",f"{p}"," "," "]
        ]

        top_table = SimpleTable(general_info,title = 'NONLINEAR LEAST SQUARES REGRESSION')

        # Coefficient table
        coef_data = [
            [f"{b:8.3f}", f"{se:8.3f}", f"{t:8.3f}", f"{pv:8.3f}",f"{lw:8.3f}",f"{up:8.3f}"]
            for b, se, t, pv,lw,up in zip(params, SE_theta, tvals, pvals, IC_lower,IC_upper)
        ]

        headers = ["coef", "std err", "t", "P>|t|", "[0.025", "0.975]"]

        # Coefficient table
        coef_table = SimpleTable(
        coef_data,
        headers=headers,
        stubs=self._thetas)

        coef_table.float_format = "%8.4f"
        coef_table.align = "r"

        # Summary table 
        summary_obj = Summary()
        summary_obj.tables.append(top_table)
        summary_obj.tables.append(coef_table)

        notes = [
            "Notes:",
            "Pseudo-R² and F-statistic are reported as descriptive measures.",
            "Inference is based on local linearization of the nonlinear model."
        ]

        summary_obj.add_extra_txt(notes)

        return summary_obj

    # Residual plot method
    def resid_plot(self,figsize = (7,7), grid = False, color = None, s = None, bins = 10):

        """
        Create diagnostic residual plots.
        
        Parameters
        ----------
        figsize : tuple, default=(10, 10)
            Figure dimensions (width, height) in inches.
        grid : bool, default=False
            Whether to display grid lines.
        color : str or array-like, optional
            Color for scatter plot points.
        s : float or array-like, optional
            Size of scatter plot points.
        bins : int, default=10
            Number of bins for histogram.
        
        Returns
        -------
        matplotlib.figure.Figure
            Figure object containing four diagnostic plots.
        
        Plots
        -----
        1. Residuals vs Fitted: Check for heteroscedasticity, nonlinearity
        2. Histogram: Check distribution of residuals
        3. Q-Q Plot: Check normality assumption
        4. Leverage vs Residuals: Identify influential points
        """

        residuals = self.resid_pearson
        residuals_order = np.sort(residuals)
        n = len(residuals)
        # Theoretical quantiles from standard normal
        theoretical_quantiles = stats.norm.ppf(np.linspace(0, 1, n))

        # 1. Residuals vs Fitted
        fig, ax = plt.subplots(2,2,figsize = figsize)
        ax[0,0].scatter(self.predict(), self.resid_pearson, color = color, s = s)
        ax[0,0].set_xlabel("Fitted values")
        ax[0,0].set_ylabel("Residual Pearson")
        ax[0,0].set_title("Residual Pearson vs Fitted Values")
        ax[0,0].grid(grid)

        # 2. Histogram of residuals
        ax[0,1].hist(self.resid,density=True, edgecolor = 'black', color = color, bins = bins)
        ax[0,1].set_xlabel("Residual Pearson")
        ax[0,1].set_ylabel("Frequency")
        ax[0,1].set_title("Residual Histogram")
        ax[0,1].grid(grid)
        
        # 3. Q-Q Plot
        ax[1,0].scatter(theoretical_quantiles, residuals_order)
        ax[1,0].plot(theoretical_quantiles, theoretical_quantiles, 'r')
        ax[1,0].set_xlabel("Theoretical Quantiles")
        ax[1,0].set_ylabel("Ordered Residuals")
        ax[1,0].set_title("Normal Q-Q Plot")
        ax[1,0].grid(grid)

        # 4. Leverage vs Residuals
        ax[1,1].scatter(self.resid, self.leverage, color = color, s = s)
        ax[1,1].set_xlabel("Residual")
        ax[1,1].set_ylabel("Leverage")
        ax[1,1].set_title("Leverage vs Residual")
        ax[1,1].grid(grid)
        plt.tight_layout()
        
        return fig
