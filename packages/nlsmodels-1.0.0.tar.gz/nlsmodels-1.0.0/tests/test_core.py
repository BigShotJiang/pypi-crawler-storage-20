import pytest
import numpy as np
import pandas as pd
import sys
import os

# Añadir nlsmodels al path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from nlsmodels.core import nls

def test_basic_initialization():
    """Test básico de inicialización."""
    df = pd.DataFrame({'x': [1, 2, 3], 'y': [2, 4, 6]})
    model = nls("y ~ a * x", data=df)
    
    assert model.formula == "y ~ a * x"
    assert 'x' in model._exogenous
    assert 'y' == model._endogenous
    assert 'a' in model._thetas

def test_simple_fit():
    """Test de ajuste simple."""
    df = pd.DataFrame({
        'x': [1, 2, 3, 4, 5],
        'y': [2.1, 4.2, 6.1, 8.0, 9.9]
    })
    
    model = nls("y ~ a * x", data=df, p0={'a': 1})
    model.fit(method='lm')
    
    assert model._success
    assert len(model.params) == 1
    # El parámetro 'a' debería estar cerca de 2
    assert abs(model.params[0] - 2.0) < 0.2

def test_predict():
    """Test de predicciones."""
    df = pd.DataFrame({'x': [1, 2, 3], 'y': [2, 4, 6]})
    model = nls("y ~ a * x", data=df, p0={'a': 2})
    model.fit()
    
    predictions = model.predict()
    assert len(predictions) == 3
    assert predictions.shape == (3,)

def test_logistic_ss():
    """Test del modelo SSlogis."""
    np.random.seed(42)
    x = np.linspace(0, 10, 20)
    y = 10 / (1 + np.exp((5 - x)/1)) + np.random.normal(0, 0.1, 20)
    
    df = pd.DataFrame({'x': x, 'y': y})
    model = nls("y ~ SSlogis(x, Asym, xmid, scal)", data=df)
    model.fit()
    
    assert model._success
    assert len(model.params) == 3

if __name__ == "__main__":
    pytest.main([__file__, "-v"])