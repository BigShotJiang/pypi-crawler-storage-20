# Publishing Guide

This guide explains how to publish the MLOps Project Generator to PyPI and set up automated publishing.

## 🚀 Quick Publishing

### Option 1: Automated Publishing (Recommended)

1. **Create GitHub Secrets:**
   - Go to your repository → Settings → Secrets and variables → Actions
   - Add these secrets:
     - `PYPI_API_TOKEN`: Your PyPI API token
     - `TEST_PYPI_API_TOKEN`: Your Test PyPI API token

2. **Create a Release:**
   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```
   - Go to GitHub → Releases → "Create a new release"
   - Create a release with tag `v1.0.0`
   - The workflow will automatically publish to PyPI

3. **Manual Trigger:**
   - Go to Actions → "Publish to PyPI" → "Run workflow"
   - Enter version and choose Test PyPI option

### Option 2: Manual Publishing

1. **Use the publishing script:**
   ```bash
   python scripts/publish.py
   ```

2. **Or manual commands:**
   ```bash
   # Install dependencies
   pip install build twine
   
   # Build package
   python -m build
   
   # Check package
   twine check dist/*
   
   # Publish to Test PyPI
   twine upload --repository testpypi dist/*
   
   # Publish to PyPI (after testing)
   twine upload dist/*
   ```

## 🔧 Setup Instructions

### 1. PyPI Account Setup

1. **Create PyPI Account:**
   - Go to [pypi.org](https://pypi.org) and create an account
   - Verify your email address

2. **Create Test PyPI Account:**
   - Go to [test.pypi.org](https://test.pypi.org) and create an account
   - Use the same email as your production PyPI account

3. **Generate API Tokens:**
   - Go to Account Settings → API tokens
   - Create token with "Entire account" scope
   - Copy the token immediately (it won't be shown again)

### 2. GitHub Secrets Setup

1. **Add PyPI Token:**
   - Repository → Settings → Secrets and variables → Actions
   - Click "New repository secret"
   - Name: `PYPI_API_TOKEN`
   - Value: Your production PyPI API token

2. **Add Test PyPI Token:**
   - Name: `TEST_PYPI_API_TOKEN`
   - Value: Your Test PyPI API token

### 3. Local Setup

1. **Install publishing dependencies:**
   ```bash
   pip install build twine wheel
   ```

2. **Configure ~/.pypirc (optional):**
   ```ini
   [distutils]
   index-servers =
       pypi
       testpypi
   
   [pypi]
   username = __token__
   password = your-pypi-token
   
   [testpypi]
   repository = https://test.pypi.org/legacy/
   username = __token__
   password = your-test-pypi-token
   ```

## 🔄 Automated Publishing Workflow

### Release-based Publishing
- Triggered when you create a GitHub release
- Automatically publishes to both Test PyPI and PyPI
- Runs tests on multiple Python versions

### Manual Publishing
- Triggered via Actions → "Run workflow"
- Choose version and whether to test first
- Full test suite runs before publishing

### Workflow Steps
1. **Build**: Tests on Python 3.8, 3.9, 3.10, 3.11
2. **Quality Checks**: Code formatting, linting, type checking
3. **Test PyPI**: Publish to test environment first
4. **PyPI**: Publish to production (if release-based or manual)

## 📋 Pre-Publishing Checklist

### Code Quality
- [ ] All tests pass: `pytest tests/ -v`
- [ ] Code formatted: `black generator/ tests/`
- [ ] Imports sorted: `isort generator/ tests/`
- [ ] Linting passes: `flake8 generator/ tests/`
- [ ] Type checking passes: `mypy generator/`

### Documentation
- [ ] README.md is up to date
- [ ] Version number updated in pyproject.toml
- [ ] CHANGELOG.md updated (if applicable)
- [ ] Documentation builds correctly

### Package Quality
- [ ] Package builds: `python -m build`
- [ ] Package checks pass: `twine check dist/*`
- [ ] All necessary files included (check MANIFEST.in)

### Testing
- [ ] Install from test PyPI works
- [ ] CLI commands work after installation
- [ ] Project generation works correctly

## 🧪 Testing Before Publishing

### 1. Local Testing
```bash
# Build and install locally
python -m build
pip install dist/mlops_project_generator-1.0.0-py3-none-any.whl

# Test CLI
mlops-project-generator --help
mlops-project-generator version
```

### 2. Test PyPI Testing
```bash
# Install from Test PyPI
pip install --index-url https://test.pypi.org/simple/ mlops-project-generator

# Test functionality
mlops-project-generator init
```

### 3. Clean Up
```bash
# Uninstall test version
pip uninstall mlops-project-generator

# Clean build artifacts
rm -rf build/ dist/ *.egg-info/
```

## 🎯 Publishing Commands

### Quick Publish (Test Only)
```bash
python scripts/publish.py
# Choose option 1 for Test PyPI
```

### Full Publish (Test + Production)
```bash
python scripts/publish.py
# Choose option 3 for both
```

### Manual Production Publish
```bash
# Only if you've already tested
twine upload dist/*
```

## 🔍 Troubleshooting

### Common Issues

1. **"File already exists" error**
   - Increment version number in pyproject.toml
   - Delete existing files from PyPI if needed

2. **"Invalid distribution" error**
   - Check package with `twine check dist/*`
   - Ensure all metadata is correct

3. **"Permission denied" error**
   - Check API token is correct
   - Ensure token has proper permissions

4. **"Build failed" error**
   - Check all dependencies are installed
   - Ensure MANIFEST.in includes all necessary files

### Getting Help

- Check the [GitHub Actions logs](https://github.com/NotHarshhaa/MLOps-Project-Generator/actions)
- Review the [PyPI documentation](https://packaging.python.org/)
- Check the [Twine documentation](https://twine.readthedocs.io/)

## 📈 Post-Publishing

1. **Verify Installation:**
   ```bash
   pip install mlops-project-generator
   mlops-project-generator --help
   ```

2. **Update Documentation:**
   - Update any version-specific documentation
   - Add release notes to GitHub

3. **Promote:**
   - Share on social media
   - Update relevant communities
   - Add to your portfolio

4. **Monitor:**
   - Check download stats on PyPI
   - Monitor for issues and feedback
   - Respond to user questions

## 🔄 Version Management

### Semantic Versioning
- **Major (X.0.0)**: Breaking changes
- **Minor (X.Y.0)**: New features, backward compatible
- **Patch (X.Y.Z)**: Bug fixes, backward compatible

### Version Bumping
1. Update version in `pyproject.toml`
2. Update CHANGELOG.md
3. Create git tag: `git tag v1.0.0`
4. Push tag: `git push origin v1.0.0`
5. Create GitHub release

### Rollback Process
If something goes wrong:
1. Delete the release from PyPI (if possible)
2. Yank the version: `twine yank mlops-project-generator==1.0.0`
3. Fix the issue
4. Publish a new version

## 🎉 Success!

Once published, users can install your package with:

```bash
pip install mlops-project-generator
```

And start using it immediately:

```bash
mlops-project-generator init
```
