# @diff MVP Plan

## High-Level Use Cases & Story Priorities
- **Regression triage for product engineers**: Review the last week of commits, drill into grouped diffs, and copy hunks into follow-up tickets without leaving the viewer.
- **Cross-team review prep**: Cluster files by domain (auth, payments, infra) so reviewers can copy the precise lines that moved into review checklists or docs.
- **Release sweep for tech leads**: Step through release-branch commits, export a combined diff blob for release notes, and manually flag missing tests/docs.
- **Documentation backfill**: Filter for docs-related paths, copy relevant diffs into documentation tooling, and track which updates still need authoring.
- **Incident retrospectives**: Replay commits touching a hot path, capture key hunks into the incident doc, and tag related commits for deeper investigation.

### User Story Preferences
- Keyboard-first navigation across commit timeline (X axis) and file groups (Y axis); mouse interactions remain optional.
- Copy-first workflow: every hunk panel exposes a one-click "Copy diff" control (no AI conversation in v1).
- Saved views remember commit range, grouping filters, and scroll position for quick rehydration.
- Minimal ceremony: no sign-in for local runs, no patch application or staging from the viewer, and no opinionated annotations.

## Assumptions & Constraints
- Git metadata is local; Next.js API routes execute `git` commands and cache results—no separate backend service.
- On first load the user selects a repository path (validated via `.git`); we store a history of recent paths.
- File grouping seeds come from a JSON manifest (glob → label) with directory-name fallbacks when no rule matches.
- Scope is one repository per active tab; multi-repo flows rely on a required `repo_id` query parameter and isolated caches.
- Operations are read-only; we never write to the repo or `.git` directory.
- Local mode skips authentication; Sweet Potato auth can be layered later if sharing is needed.

## Experience Overview
1. **Commit Timeline (X axis)**  
   Horizontal strip listing commits in the selected window (default last 7 days). Filters: branch, author, tag. Selecting a commit highlights intersecting file-group rows.
2. **Contextual File Groupings (Y axis)**  
   Vertical lanes derived from manifest tags (auth, payments, docs, infra). Each cell contains files from the commit that match the group.
3. **Diff Workspace**  
   Expanding a cell reveals unified diff hunks plus metadata (commit message, author, parent hash). Inline controls: copy hunk as diff text, jump to related files.
4. **Peripheral Insight Strip**  
   Lightweight list of adjacent commits touching the same files (±3 commits) for quick context.
5. **Saved Views Drawer**  
   Persisted layouts (repo path, commit range, active groups) scoped by `repo_id` for repeat workflows.

## Data & Context Mapping
- **Git Adapter**: wraps `git log`, `git show`, `git diff`, and optional `git blame`; normalizes output into structured JSON.
- **Grouping Catalog**: reads `config/diff-groups.json` (or defaults) and tags files with group labels.
- **History Window Selector**: defaults to 7 days; users can extend via date picker or commit count.
- **Snapshot Cache**: LRU keyed by `repo_id + commit_hash + group_filters`, storing normalized diff payloads.

### Core Snapshot Schema
```
commit_snapshot
  repo_id
  hash
  timestamp
  author
  message
  files[] -> file_path, status, groups[], related_docs[], related_tests[]
  hunks[] -> file_path, header, diff_text, previous_hash, blame_context
```

## Local Ingestion & Refresh Strategy
- **In-memory LRU (default)**: caches snapshots; evict when branch/range changes or user hits refresh.
- **Optional file-backed cache**: `.cache/diff/<repo_id>/<hash>.json` with schema version to survive restarts; regenerate when hashes diverge.
- **Refresh triggers**:
  - Compare `git rev-parse HEAD` with cached head whenever window regains focus.
  - Poll `git status --porcelain` at a light cadence while active.
  - Manual "Refresh timeline" button clears affected cache entries.
- **Chunking policy**: initial load pulls the last 7 days; provide "Load older commits" to paginate backwards without overwhelming the UI.

## API Surface (Next.js Local Runtime)
- `GET /api/commits?repo_id=<id>&from=<sha>&to=<sha>&branch=main&author=...`
- `GET /api/diff?repo_id=<id>&commit=<sha>&groups=auth,infra`
- `POST /api/views` → save view (repo_id, range, groups, label)
- `GET /api/views?repo_id=<id>` → list saved views
- `POST /api/diff/copy` → bundle selected hunks into a single diff blob for clipboard/export (massive unified diff file is the default output)

Server modules (`GitRepository`, `GroupingCatalog`, `DiffContextBuilder`, `ViewStore`) run inside Next.js API routes and are sandboxed per validated `repo_id` path.

## Local Git Artifacts & Viewer Content Guidance
- Pull only committed data via `git log`, `git show`, `git diff` against the immediate parent, plus optional `git blame` for context.
- Skip rendering large binary diffs; show a placeholder with size info and an "Open externally" option.
- Expose remote metadata from `.git/config` only on user request; hide by default to keep the viewer local-first.
- Never write inside `.git`; all cache/write operations land under `~/.diff-viewer/cache/<repo_id>`.
- Link to related docs/tests (from manifest) as contextual pointers; do not auto-modify those files.

## AI & Automation Posture
- V1 ships without conversational AI. Automation is limited to copy buttons (single hunk or aggregated view) and optional diff export API.
- Future flag can enable AI summaries using the same snapshot schema once core copying workflows prove valuable.

## Implementation Milestones
1. **Foundations**
   - Repo selector UI + path validation.
   - Git adapter + snapshot normalization.
   - Grouped grid layout with 7-day default window.
   - Tests: git adapter unit tests, grouping catalog tests.
2. **Diff Workspace & Copy Actions**
   - Hunk viewer with copy button + aggregated diff export endpoint.
   - Peripheral insight strip (adjacent commits).
   - Saved views persistence (memory or JSON file per repo_id).
   - Tests: API route tests for `/api/diff`, `/api/commits`, `/api/views`.
3. **Polish & Telemetry**
   - Clipboard success toast, keyboard shortcuts, and light theming.
   - Optional file-backed cache toggle.
   - Local usage logging (no network) for future prioritization.

## Testing & Validation Strategy
- Fixture-based git command mocks for unit tests.
- Next.js API handler tests via supertest/fetch mocks.
- UI integration tests (Playwright) covering repo selection, grid navigation, hunk copy, and saved view restore.
- Usability pilot with two personas (engineer, release lead) to validate navigation flow and clipboard ergonomics.

## V1 Decisions (Resolved Open Questions)
- **Air-gapped support**: rely entirely on local git; no remote mirrors or sync.
- **Conversation persistence**: unnecessary; saved views capture revisit context, and exports are copy-only.
- **Export format**: single unified diff blob ("massive diff file") for copy/export; JSON optional later.
- **Multi-repo handling**: `repo_id` required in API/view state; each tab/session manages one repo at a time.
- **Confidence signals**: omitted; users judge risk manually.

## Follow-up Considerations
- Allow pagination beyond 7-day default via "Load older" while keeping cache size bounded.
- Batch rendering for very large commits (e.g., per-file virtualization) to maintain performance.
- Evaluate optional AI summarization or risk cues once copy-first MVP adoption is proven.
