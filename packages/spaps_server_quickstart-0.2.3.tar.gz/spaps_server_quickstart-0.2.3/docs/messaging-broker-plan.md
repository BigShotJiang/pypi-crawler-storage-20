# Messaging Broker Concept

## TL;DR
- Build a lightweight FastAPI service (via the quickstart) that brokers messages between CLI agents acting as `product-manager` and `dev`.
- Use Redis first for storage, queues, and cursor tracking; keep persistence behind a `MessageStore` interface so Postgres can be added later without touching handlers.
- Reuse Codex session hashes as conversation IDs, and embed those IDs in RBAC tokens so `require_roles` protects each conversation.
- Wire bearer/API keys to hydrate `AuthenticatedUser` with stable `agent_id` values, keeping authorization aligned with stored conversation participants.

## User Stories
- As a product manager, I can start a new conversation using a Codex session hash so all downstream tooling references the same thread.
- As a product manager, I can send a structured instruction (`codex continue <hash> …`) to a developer agent and see acknowledgements or follow-up questions.
- As a developer agent, I can retrieve pending instructions in chronological order and mark them as read so I only process fresh work.
- As either role, I can review the conversation history for context while staying within RBAC constraints.

## Agent Stories
- As a CLI coding agent, I can poll `GET /messages/{conversation}?after=<last_seen>` to fetch only new instructions.
- As a CLI coding tool, I can post execution results back to the same conversation so both agents share outcomes and next steps.
- As an automation agent, I can subscribe to Redis events (or Celery tasks) to trigger notifications when a new instruction arrives.

## Data Model Primer
```
agent_profile
  agent_id (string, Codex session identifier)
  role (enum: product-manager | dev)
  display_name (optional)

conversation
  conversation_hash (string, Codex hash)
  product_manager_id (fk agent_profile)
  dev_id (fk agent_profile)
  subject / status / timestamps

message
  message_id (ULID/UUID)
  conversation_hash (fk conversation)
  sender_id (fk agent_profile)
  role (redundant cache for filters)
  body (text)
  command_payload (json: literal "codex continue …")
  created_at

message_cursor
  conversation_hash
  agent_id
  last_seen_message_id
  updated_at
```

### Redis Implementation Notes
- `HMSET conversation:{hash}` stores conversation metadata; keys match the `conversation` columns.
- `RPUSH messages:{hash}` appends JSON blobs mirroring the `message` schema (include `message_id` ULID for ordering).
- `HSET cursor:{hash} {agent_id}=<last_seen_id>` tracks per-agent read positions.
- Optional `XADD notifications:{agent_id}` stream mirrors new message IDs for event-driven workflows.

### Postgres-Ready Path
- Table layouts mirror the structures above; add indexes on `(conversation_hash, created_at)` and `(conversation_hash, message_id)`.
- Keep DTOs (`Message`, `Conversation`, `Cursor`) consistent so the `MessageStore` switch is an implementation change, not an API refactor.
- Migrations add `conversation_participant` later if more than two roles join a conversation.

## Service Layer Outline
- `MessageStore` abstraction exposes `save_message`, `list_messages(conversation_hash, after_id)`, `create_conversation`, and `upsert_cursor`.
- FastAPI routes call the store and rely on `require_roles` coupled with conversation ownership checks (`AuthenticatedUser.user_id == conversation.dev_id`, etc.).
- Celery worker (optional) fans out notifications or escalations; uses the same store interface so Redis/Postgres parity holds.

## RBAC & Auth
- Issue bearer tokens that embed `agent_id` and `role`; middleware hydrates `AuthenticatedUser` with those values.
- Enforce “only assigned PM/dev may post or read” by checking the stored participants before serving each request.
- Support one-to-many PM → dev mappings during conversation creation by validating the `dev_id` against an allowlist or configuration.

## Next Steps
- Prototype the Redis-backed `MessageStore` and FastAPI routes (`POST /conversations`, `POST /messages`, `GET /messages/{conversation}`).
- Define token issuance (manual API keys vs MCP handshake) and document how CLI agents obtain their `agent_id`.
- Add a migration doc stub (`docs/architecture/messaging.md`) describing how to promote Redis data into Postgres when durability requirements grow.
