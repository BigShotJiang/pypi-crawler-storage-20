"""
Local development mode for auth bypass.

This module provides tools for local development without requiring external
auth services. Use when development_environment="local" in settings.

Usage:
    from spaps_server_quickstart.local_mode import (
        LocalPersona,
        LocalPersonaRegistry,
        LocalAuthMiddleware,
        get_default_registry,
        DEFAULT_PERSONAS,
    )

    # In your app setup:
    if settings.is_local_development:
        app.add_middleware(LocalAuthMiddleware, registry=get_default_registry())
"""

from .personas import (
    LocalPersona,
    LocalPersonaRegistry,
    DEFAULT_PERSONAS,
    get_default_registry,
)
from .middleware import LocalAuthMiddleware

__all__ = [
    "LocalPersona",
    "LocalPersonaRegistry",
    "LocalAuthMiddleware",
    "DEFAULT_PERSONAS",
    "get_default_registry",
]
