"""
Local auth middleware for development mode.

Intercepts local-* tokens and sets authenticated_user on request state,
bypassing external auth services for local development.

WARNING: This middleware bypasses all authentication. Never use in production.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from spaps_server_quickstart.auth import AuthenticatedUser

if TYPE_CHECKING:
    from typing import Callable, Awaitable
    from starlette.types import ASGIApp
    from .personas import LocalPersonaRegistry

logger = logging.getLogger(__name__)


class LocalAuthMiddleware(BaseHTTPMiddleware):
    """
    Middleware that intercepts local-* tokens for development auth bypass.

    Only handles tokens with the "local-" prefix, passing through all other
    requests unchanged. When a local token is found, sets authenticated_user
    on request.state with the corresponding persona's data.

    Usage:
        from spaps_server_quickstart.local_mode import LocalAuthMiddleware, get_default_registry

        if settings.is_local_development:
            app.add_middleware(LocalAuthMiddleware, registry=get_default_registry())
    """

    def __init__(
        self,
        app: ASGIApp,
        registry: LocalPersonaRegistry,
    ) -> None:
        """
        Initialize the middleware.

        Args:
            app: The ASGI application to wrap
            registry: LocalPersonaRegistry containing available personas
        """
        super().__init__(app)
        self.registry = registry
        logger.warning(
            "⚠️  LocalAuthMiddleware is ACTIVE - authentication is bypassed! "
            "This should ONLY be used for local development."
        )

    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        """
        Process the request, intercepting local-* tokens.

        Args:
            request: The incoming HTTP request
            call_next: The next middleware/handler in the chain

        Returns:
            The response from the downstream handler
        """
        auth_header = request.headers.get("authorization", "")

        # Only intercept Bearer tokens with local-* prefix
        if auth_header.startswith("Bearer local-"):
            token = auth_header.removeprefix("Bearer ").strip()
            persona = self.registry.get_by_token(token)

            if persona is not None:
                # Set authenticated_user as AuthenticatedUser dataclass
                # This ensures compatibility with require_roles and other auth dependencies
                request.state.authenticated_user = AuthenticatedUser(
                    user_id=persona.user_id,
                    session_id=f"local-session-{persona.code}",
                    application_id="local-development",
                    roles=set(persona.roles),
                    subscription_active=True,
                    subscription_plan="Local Development",
                    tier="local",
                )

        return await call_next(request)
