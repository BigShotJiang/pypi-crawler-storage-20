"""
Local development personas for auth bypass.

Provides pre-configured personas (admin/user) for local development without
requiring external auth services.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache


@dataclass(frozen=True, slots=True)
class LocalPersona:
    """
    Immutable representation of a local development persona.

    Attributes:
        code: Short identifier (e.g., "admin", "user")
        token: Auth token in local-* format (e.g., "local-admin")
        display_name: Human-readable name for the persona
        user_id: UUID string for the mock user
        roles: Tuple of role strings assigned to this persona
    """

    code: str
    token: str
    display_name: str
    user_id: str
    roles: tuple[str, ...]


class LocalPersonaRegistry:
    """
    Registry for managing local development personas.

    Provides lookup by token or code, and allows registering custom personas.
    """

    def __init__(self) -> None:
        self._by_token: dict[str, LocalPersona] = {}
        self._by_code: dict[str, LocalPersona] = {}

    def register(self, persona: LocalPersona) -> None:
        """
        Register a persona in the registry.

        Args:
            persona: The LocalPersona to register
        """
        self._by_token[persona.token] = persona
        self._by_code[persona.code] = persona

    def get_by_token(self, token: str) -> LocalPersona | None:
        """
        Retrieve a persona by its token.

        Args:
            token: The token string (e.g., "local-admin")

        Returns:
            The matching LocalPersona or None if not found
        """
        return self._by_token.get(token)

    def get_by_code(self, code: str) -> LocalPersona | None:
        """
        Retrieve a persona by its code.

        Args:
            code: The code string (e.g., "admin")

        Returns:
            The matching LocalPersona or None if not found
        """
        return self._by_code.get(code)

    def list_all(self) -> list[LocalPersona]:
        """
        List all registered personas.

        Returns:
            List of all LocalPersona objects in the registry
        """
        return list(self._by_code.values())


# Default personas available out of the box
DEFAULT_PERSONAS: tuple[LocalPersona, ...] = (
    LocalPersona(
        code="admin",
        token="local-admin",
        display_name="Local Admin",
        user_id="00000000-0000-0000-0000-000000000001",
        roles=("admin", "user"),
    ),
    LocalPersona(
        code="user",
        token="local-user",
        display_name="Local User",
        user_id="00000000-0000-0000-0000-000000000002",
        roles=("user",),
    ),
)


@lru_cache(maxsize=1)
def get_default_registry() -> LocalPersonaRegistry:
    """
    Get the default registry with pre-configured admin and user personas.

    Returns:
        LocalPersonaRegistry with default personas registered
    """
    registry = LocalPersonaRegistry()
    for persona in DEFAULT_PERSONAS:
        registry.register(persona)
    return registry
