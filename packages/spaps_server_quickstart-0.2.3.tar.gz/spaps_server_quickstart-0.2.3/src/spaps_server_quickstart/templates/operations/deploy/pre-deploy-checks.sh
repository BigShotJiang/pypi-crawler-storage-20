#!/usr/bin/env bash
# Pre-deployment validation checks
# Runs before deployment to catch potential issues early

set -euo pipefail

# ============================================================================
# Configuration
# ============================================================================

SERVICE_NAME="${SERVICE_NAME:-quickstart}"
REQUIRED_PORTS="${REQUIRED_PORTS:-8000}"
MIN_DISK_SPACE_GB="${MIN_DISK_SPACE_GB:-5}"
REQUIRED_ENV_VARS="${REQUIRED_ENV_VARS:-}"
SKIP_NETWORK_CHECK="${SKIP_NETWORK_CHECK:-0}"
SKIP_DISK_CHECK="${SKIP_DISK_CHECK:-0}"
SKIP_ENV_CHECK="${SKIP_ENV_CHECK:-0}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# ============================================================================
# Helper Functions
# ============================================================================

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

check_passed() {
    echo -e "  ${GREEN}✓${NC} $1"
}

check_failed() {
    echo -e "  ${RED}✗${NC} $1" >&2
}

# ============================================================================
# Check Functions
# ============================================================================

check_docker_available() {
    log_info "Checking Docker availability..."
    if ! command -v docker &> /dev/null; then
        check_failed "Docker is not installed"
        return 1
    fi

    if ! docker info &> /dev/null; then
        check_failed "Docker daemon is not running"
        return 1
    fi

    check_passed "Docker is available and running"
    return 0
}

check_port_availability() {
    if [[ "$SKIP_NETWORK_CHECK" == "1" ]]; then
        log_warn "Skipping port availability check (SKIP_NETWORK_CHECK=1)"
        return 0
    fi

    log_info "Checking port availability..."
    local failed=0

    IFS=',' read -ra PORTS <<< "$REQUIRED_PORTS"
    for port in "${PORTS[@]}"; do
        port=$(echo "$port" | tr -d ' ')
        if [[ -z "$port" ]]; then
            continue
        fi

        # Check if port is in use
        if command -v ss &> /dev/null; then
            if ss -tuln | grep -q ":${port} "; then
                check_failed "Port $port is already in use"
                failed=1
            else
                check_passed "Port $port is available"
            fi
        elif command -v netstat &> /dev/null; then
            if netstat -tuln | grep -q ":${port} "; then
                check_failed "Port $port is already in use"
                failed=1
            else
                check_passed "Port $port is available"
            fi
        else
            log_warn "Neither ss nor netstat available, skipping port check"
        fi
    done

    return $failed
}

check_dev_container_conflicts() {
    log_info "Checking for dev container conflicts..."

    # Look for containers with dev-related names that might conflict
    local dev_containers
    dev_containers=$(docker ps --format '{{.Names}}' | grep -E "^${SERVICE_NAME}[-_]dev|[-_]dev[-_]" || true)

    if [[ -n "$dev_containers" ]]; then
        log_warn "Found development containers that might conflict:"
        echo "$dev_containers" | while read -r container; do
            log_warn "  - $container"
        done
        log_warn "Consider stopping dev containers before production deployment"
    else
        check_passed "No conflicting dev containers found"
    fi

    return 0
}

check_docker_network() {
    if [[ "$SKIP_NETWORK_CHECK" == "1" ]]; then
        log_warn "Skipping Docker network check (SKIP_NETWORK_CHECK=1)"
        return 0
    fi

    log_info "Checking Docker network..."

    # Check for reverse-proxy network
    if docker network ls --format '{{.Name}}' | grep -q "reverse-proxy"; then
        check_passed "reverse-proxy network exists"
    else
        log_warn "reverse-proxy network not found (may be created during deployment)"
    fi

    return 0
}

check_nginx_proxy() {
    log_info "Checking shared reverse proxy..."

    if docker ps --format '{{.Names}}' | grep -q "^shared-reverse-proxy$"; then
        check_passed "shared-reverse-proxy container is running"

        # Check if nginx is healthy
        if docker exec shared-reverse-proxy nginx -t &> /dev/null; then
            check_passed "Nginx configuration is valid"
        else
            log_warn "Nginx configuration test failed (may need refresh)"
        fi
    else
        log_warn "shared-reverse-proxy not running (may not be required)"
    fi

    return 0
}

check_disk_space() {
    if [[ "$SKIP_DISK_CHECK" == "1" ]]; then
        log_warn "Skipping disk space check (SKIP_DISK_CHECK=1)"
        return 0
    fi

    log_info "Checking disk space..."

    local available_gb
    if [[ "$(uname)" == "Darwin" ]]; then
        available_gb=$(df -g / | awk 'NR==2 {print $4}')
    else
        available_gb=$(df -BG / | awk 'NR==2 {gsub(/G/,""); print $4}')
    fi

    if [[ "$available_gb" -lt "$MIN_DISK_SPACE_GB" ]]; then
        check_failed "Insufficient disk space: ${available_gb}GB available, ${MIN_DISK_SPACE_GB}GB required"
        return 1
    fi

    check_passed "Disk space OK: ${available_gb}GB available (minimum ${MIN_DISK_SPACE_GB}GB)"
    return 0
}

check_env_vars() {
    if [[ "$SKIP_ENV_CHECK" == "1" ]]; then
        log_warn "Skipping environment variable check (SKIP_ENV_CHECK=1)"
        return 0
    fi

    if [[ -z "$REQUIRED_ENV_VARS" ]]; then
        log_info "No required environment variables specified"
        return 0
    fi

    log_info "Checking required environment variables..."
    local failed=0

    IFS=',' read -ra VARS <<< "$REQUIRED_ENV_VARS"
    for var in "${VARS[@]}"; do
        var=$(echo "$var" | tr -d ' ')
        if [[ -z "$var" ]]; then
            continue
        fi

        if [[ -z "${!var:-}" ]]; then
            check_failed "Required environment variable $var is not set"
            failed=1
        else
            check_passed "Environment variable $var is set"
        fi
    done

    return $failed
}

check_database_connectivity() {
    log_info "Checking database connectivity..."

    # Check if pg_isready is available
    if ! command -v pg_isready &> /dev/null; then
        log_warn "pg_isready not available, skipping database check"
        return 0
    fi

    # Extract database host/port from DATABASE_URL if available
    if [[ -z "${DATABASE_URL:-}" ]]; then
        log_warn "DATABASE_URL not set, skipping database connectivity check"
        return 0
    fi

    # Simple regex to extract host:port from DATABASE_URL
    local db_host db_port
    if [[ "$DATABASE_URL" =~ @([^:/]+)(:([0-9]+))? ]]; then
        db_host="${BASH_REMATCH[1]}"
        db_port="${BASH_REMATCH[3]:-5432}"

        if pg_isready -h "$db_host" -p "$db_port" -t 5 &> /dev/null; then
            check_passed "Database at $db_host:$db_port is reachable"
        else
            log_warn "Database at $db_host:$db_port is not reachable (may be OK if in Docker)"
        fi
    else
        log_warn "Could not parse DATABASE_URL for connectivity check"
    fi

    return 0
}

# ============================================================================
# Main
# ============================================================================

main() {
    echo ""
    echo "============================================"
    echo "Pre-Deployment Checks for ${SERVICE_NAME}"
    echo "============================================"
    echo ""

    local exit_code=0

    # Critical checks (failure = abort deployment)
    check_docker_available || exit_code=1

    # Important checks
    check_port_availability || exit_code=1
    check_disk_space || exit_code=1
    check_env_vars || exit_code=1

    # Informational checks (warnings only)
    check_dev_container_conflicts
    check_docker_network
    check_nginx_proxy
    check_database_connectivity

    echo ""
    if [[ $exit_code -eq 0 ]]; then
        log_info "All pre-deployment checks passed"
    else
        log_error "Some pre-deployment checks failed"
    fi
    echo ""

    return $exit_code
}

main "$@"
