#!/usr/bin/env bash
# Local development loop with database caching
# Caches seeded database state to speed up `make local-up`

set -euo pipefail

# ============================================================================
# Configuration
# ============================================================================

SERVICE_NAME="${SERVICE_NAME:-quickstart}"
SERVICE_NAME_UPPER="${SERVICE_NAME^^}"

# Cache configuration (can be overridden via env vars)
# Supports service-specific overrides like QUICKSTART_CACHE_ROOT
_SERVICE_CACHE_ROOT_VAR="${SERVICE_NAME_UPPER}_CACHE_ROOT"
_SERVICE_FORCE_RESEED_VAR="${SERVICE_NAME_UPPER}_FORCE_RESEED"
_SERVICE_SKIP_DB_CACHE_VAR="${SERVICE_NAME_UPPER}_SKIP_DB_CACHE"

CACHE_ROOT="${CACHE_ROOT:-${!_SERVICE_CACHE_ROOT_VAR:-$HOME/.cache/${SERVICE_NAME}}}"
FORCE_RESEED="${FORCE_RESEED:-${!_SERVICE_FORCE_RESEED_VAR:-0}}"
SKIP_DB_CACHE="${SKIP_DB_CACHE:-${!_SERVICE_SKIP_DB_CACHE_VAR:-0}}"
LOCAL_WATCH="${LOCAL_WATCH:-0}"

# Database configuration
DB_CONTAINER="${DB_CONTAINER:-${SERVICE_NAME}-db}"
DB_USER="${DB_USER:-postgres}"
DB_NAME="${DB_NAME:-${SERVICE_NAME}}"
DB_PORT="${DB_PORT:-5432}"

# Directories to include in hash calculation
CACHE_TARGETS="${CACHE_TARGETS:-alembic scripts/seeds fixtures}"

# Cache paths
CACHE_DIR="${CACHE_ROOT}/db"
CACHE_FILE="${CACHE_DIR}/seeded.sql.gz"
HASH_FILE="${CACHE_DIR}/hash.txt"
STATE_DIR="${CACHE_ROOT}/state"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# ============================================================================
# Helper Functions
# ============================================================================

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

log_debug() {
    if [[ "${DEBUG:-0}" == "1" ]]; then
        echo -e "${BLUE}[DEBUG]${NC} $1"
    fi
}

ensure_dirs() {
    mkdir -p "$CACHE_DIR" "$STATE_DIR"
}

# ============================================================================
# Hash Computation
# ============================================================================

compute_cache_hash() {
    log_debug "Computing hash from cache targets: $CACHE_TARGETS"

    local hash_input=""

    for target in $CACHE_TARGETS; do
        if [[ -d "$target" ]]; then
            # Hash all files in directory
            hash_input+=$(find "$target" -type f -exec sha256sum {} \; 2>/dev/null | sort || true)
        elif [[ -f "$target" ]]; then
            hash_input+=$(sha256sum "$target" 2>/dev/null || true)
        fi
    done

    # Also include requirements/pyproject if present
    for req_file in requirements.txt requirements-dev.txt pyproject.toml; do
        if [[ -f "$req_file" ]]; then
            hash_input+=$(sha256sum "$req_file" 2>/dev/null || true)
        fi
    done

    if [[ -z "$hash_input" ]]; then
        log_warn "No cache targets found, using timestamp as hash"
        echo "$(date +%s)"
        return
    fi

    echo "$hash_input" | sha256sum | cut -d' ' -f1
}

get_stored_hash() {
    if [[ -f "$HASH_FILE" ]]; then
        cat "$HASH_FILE"
    else
        echo ""
    fi
}

store_hash() {
    local hash="$1"
    echo "$hash" > "$HASH_FILE"
}

# ============================================================================
# Database Cache Operations
# ============================================================================

wait_for_db() {
    log_info "Waiting for database..."

    local max_attempts=30
    local attempt=0

    while [[ $attempt -lt $max_attempts ]]; do
        if docker exec "$DB_CONTAINER" pg_isready -U "$DB_USER" -d "$DB_NAME" &>/dev/null; then
            log_info "Database is ready"
            return 0
        fi

        attempt=$((attempt + 1))
        sleep 1
    done

    log_error "Database did not become ready in time"
    return 1
}

save_cache() {
    if [[ "$SKIP_DB_CACHE" == "1" ]]; then
        log_info "Skipping cache save (SKIP_DB_CACHE=1)"
        return 0
    fi

    log_info "Saving database cache..."

    docker exec "$DB_CONTAINER" pg_dump \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        --format=custom \
        --compress=9 \
        > "$CACHE_FILE" 2>/dev/null || {
        log_warn "Failed to create cache dump"
        return 1
    }

    local current_hash
    current_hash=$(compute_cache_hash)
    store_hash "$current_hash"

    log_info "Cache saved to $CACHE_FILE (hash: ${current_hash:0:12}...)"
}

restore_cache() {
    if [[ ! -f "$CACHE_FILE" ]]; then
        log_info "No cache file found, will run full seed"
        return 1
    fi

    log_info "Restoring database from cache..."

    # Drop and recreate database
    docker exec "$DB_CONTAINER" psql -U "$DB_USER" -d postgres -c "DROP DATABASE IF EXISTS $DB_NAME;" 2>/dev/null || true
    docker exec "$DB_CONTAINER" psql -U "$DB_USER" -d postgres -c "CREATE DATABASE $DB_NAME;" 2>/dev/null || {
        log_warn "Failed to recreate database"
        return 1
    }

    # Restore from cache
    docker exec -i "$DB_CONTAINER" pg_restore \
        -U "$DB_USER" \
        -d "$DB_NAME" \
        --no-owner \
        --no-privileges \
        < "$CACHE_FILE" 2>/dev/null || {
        log_warn "Failed to restore cache (may be corrupted)"
        return 1
    }

    log_info "Database restored from cache"
    return 0
}

should_use_cache() {
    # Check if forced reseed
    if [[ "$FORCE_RESEED" == "1" ]]; then
        log_info "Forced reseed requested"
        return 1
    fi

    # Check if caching disabled
    if [[ "$SKIP_DB_CACHE" == "1" ]]; then
        log_info "Caching disabled"
        return 1
    fi

    # Check if cache exists
    if [[ ! -f "$CACHE_FILE" ]]; then
        log_info "No cache file found"
        return 1
    fi

    # Compare hashes
    local current_hash stored_hash
    current_hash=$(compute_cache_hash)
    stored_hash=$(get_stored_hash)

    if [[ "$current_hash" == "$stored_hash" ]]; then
        log_info "Cache is valid (hash matches)"
        return 0
    else
        log_info "Cache invalidated (hash mismatch)"
        log_debug "Current: ${current_hash:0:12}... Stored: ${stored_hash:0:12}..."
        return 1
    fi
}

# ============================================================================
# Docker Compose Operations
# ============================================================================

start_containers() {
    log_info "Starting containers..."

    # Check for compose file
    local compose_file=""
    for f in docker-compose.dev.yml docker-compose.yml docker-compose.local.yml; do
        if [[ -f "$f" ]]; then
            compose_file="$f"
            break
        fi
    done

    if [[ -z "$compose_file" ]]; then
        log_error "No docker-compose file found"
        return 1
    fi

    docker compose -f "$compose_file" up -d

    log_info "Containers started"
}

run_seeds() {
    log_info "Running database seeds..."

    # Try common seeding patterns
    if [[ -f "scripts/seeds/seed.py" ]]; then
        docker compose exec -T api python scripts/seeds/seed.py 2>/dev/null || \
        python scripts/seeds/seed.py
    elif [[ -f "scripts/seed.sh" ]]; then
        ./scripts/seed.sh
    elif [[ -f "Makefile" ]] && grep -q "^seed:" Makefile; then
        make seed
    else
        log_warn "No seed script found, skipping"
    fi

    log_info "Seeds completed"
}

run_migrations() {
    log_info "Running migrations..."

    # Try common migration patterns
    if command -v alembic &>/dev/null; then
        alembic upgrade head 2>/dev/null || true
    elif [[ -f "Makefile" ]] && grep -q "^migrate:" Makefile; then
        make migrate
    else
        docker compose exec -T api alembic upgrade head 2>/dev/null || log_warn "Migrations may have failed"
    fi

    log_info "Migrations completed"
}

# ============================================================================
# Watch Mode
# ============================================================================

watch_loop() {
    log_info "Starting watch mode..."

    # Use fswatch if available, otherwise inotifywait, otherwise poll
    if command -v fswatch &>/dev/null; then
        fswatch -o $CACHE_TARGETS | while read -r; do
            log_info "Changes detected, rebuilding..."
            run_migrations
            run_seeds
            save_cache
        done
    elif command -v inotifywait &>/dev/null; then
        while inotifywait -r -e modify,create,delete $CACHE_TARGETS 2>/dev/null; do
            log_info "Changes detected, rebuilding..."
            run_migrations
            run_seeds
            save_cache
        done
    else
        log_warn "No file watcher available (fswatch/inotifywait), polling every 30s"
        while true; do
            sleep 30
            local current_hash stored_hash
            current_hash=$(compute_cache_hash)
            stored_hash=$(get_stored_hash)
            if [[ "$current_hash" != "$stored_hash" ]]; then
                log_info "Changes detected, rebuilding..."
                run_migrations
                run_seeds
                save_cache
            fi
        done
    fi
}

# ============================================================================
# Main
# ============================================================================

main() {
    echo ""
    echo "============================================"
    echo "Local Debug Loop for ${SERVICE_NAME}"
    echo "============================================"
    echo ""

    ensure_dirs

    # Start containers
    start_containers

    # Wait for database
    wait_for_db

    # Decide whether to use cache or reseed
    if should_use_cache; then
        if restore_cache; then
            log_info "Using cached database state"
        else
            log_warn "Cache restore failed, running full seed"
            run_migrations
            run_seeds
            save_cache
        fi
    else
        run_migrations
        run_seeds
        save_cache
    fi

    echo ""
    log_info "Local environment ready!"
    echo ""

    # Enter watch mode if requested
    if [[ "$LOCAL_WATCH" == "1" ]]; then
        watch_loop
    fi
}

main "$@"
