"""
Users domain - Example domain-driven structure.

Copy this pattern for your domains.
"""
from .router import router

__all__ = ["router"]
