"""
Business logic for the users domain.

Replace {{SERVICE_MODULE}} with your service module name.
"""
from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from . import repository
from .models import User
from .schemas import UserCreate, UserUpdate


class UserService:
    """Service layer for user operations."""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_user(self, user_id: str) -> User | None:
        """Get a user by ID."""
        return await repository.get_user_by_id(self.session, user_id)

    async def get_user_by_email(self, email: str) -> User | None:
        """Get a user by email."""
        return await repository.get_user_by_email(self.session, email)

    async def list_users(self, *, limit: int = 50, offset: int = 0) -> list[User]:
        """List users with pagination."""
        return await repository.list_users(self.session, limit=limit, offset=offset)

    async def create_user(self, data: UserCreate) -> User:
        """Create a new user."""
        # Add business logic here (validation, events, etc.)
        return await repository.create_user(self.session, data)

    async def update_user(self, user_id: str, data: UserUpdate) -> User | None:
        """Update a user."""
        user = await self.get_user(user_id)
        if not user:
            return None
        return await repository.update_user(self.session, user, data)

    async def delete_user(self, user_id: str) -> bool:
        """Delete a user. Returns True if deleted, False if not found."""
        user = await self.get_user(user_id)
        if not user:
            return False
        await repository.delete_user(self.session, user)
        return True
