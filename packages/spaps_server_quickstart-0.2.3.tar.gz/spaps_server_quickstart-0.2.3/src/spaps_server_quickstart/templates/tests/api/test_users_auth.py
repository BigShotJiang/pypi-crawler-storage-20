"""
Auth integration tests for the users domain.

Demonstrates patterns for testing:
- Role-based access control with require_roles
- The /me endpoints for current user operations
- Dependency overrides for auth testing without middleware

These tests serve as examples - adapt them to your service's test setup.
"""
from __future__ import annotations

import pytest
from httpx import AsyncClient

from spaps_server_quickstart.auth import AuthenticatedUser
from spaps_server_quickstart.local_mode import LocalPersona


class TestUsersMe:
    """Tests for /users/me endpoints."""

    @pytest.mark.asyncio
    async def test_get_me_returns_profile_with_auth_context(
        self,
        async_client: AsyncClient,
        admin_auth_header: dict[str, str],
    ) -> None:
        """
        GET /users/me returns profile with auth context for authenticated users.

        The response includes:
        - Standard user fields (id, email, display_name, etc.)
        - roles: List of roles from the auth token
        - auth_mode: "local" for local personas, "spaps" for production auth
        """
        response = await async_client.get("/v1/users/me", headers=admin_auth_header)

        # Note: Will return 404 if no user record exists for the persona
        # In production tests, seed the user first
        assert response.status_code in (200, 404)

        if response.status_code == 200:
            data = response.json()
            assert "roles" in data
            assert "auth_mode" in data
            assert data["auth_mode"] == "local"
            assert "admin" in data["roles"]

    @pytest.mark.asyncio
    async def test_get_me_requires_authentication(
        self,
        async_client: AsyncClient,
    ) -> None:
        """GET /users/me returns 401 without authentication."""
        response = await async_client.get("/v1/users/me")

        assert response.status_code == 401
        assert response.json()["detail"] == "Authentication required"

    @pytest.mark.asyncio
    async def test_patch_me_updates_own_profile(
        self,
        async_client: AsyncClient,
        user_auth_header: dict[str, str],
    ) -> None:
        """PATCH /users/me allows users to update their own profile."""
        response = await async_client.patch(
            "/v1/users/me",
            headers=user_auth_header,
            json={"display_name": "Updated Name"},
        )

        # Will return 404 if user record doesn't exist
        assert response.status_code in (200, 404)


class TestRoleBasedAccess:
    """Tests demonstrating role-based access control patterns."""

    @pytest.mark.asyncio
    async def test_admin_can_create_users(
        self,
        async_client: AsyncClient,
        admin_auth_header: dict[str, str],
    ) -> None:
        """POST /users requires admin role - admin can create users."""
        response = await async_client.post(
            "/v1/users",
            headers=admin_auth_header,
            json={"email": "newuser@example.com", "display_name": "New User"},
        )

        # 201 if created, 409 if email exists, 501 if service not implemented
        assert response.status_code in (201, 409, 501)

    @pytest.mark.asyncio
    async def test_user_cannot_create_users(
        self,
        async_client: AsyncClient,
        user_auth_header: dict[str, str],
    ) -> None:
        """POST /users denied for non-admin users - returns 403 Forbidden."""
        response = await async_client.post(
            "/v1/users",
            headers=user_auth_header,
            json={"email": "newuser@example.com", "display_name": "New User"},
        )

        assert response.status_code == 403
        assert response.json()["detail"] == "Forbidden"

    @pytest.mark.asyncio
    async def test_unauthenticated_cannot_create_users(
        self,
        async_client: AsyncClient,
    ) -> None:
        """POST /users without auth returns 401 Unauthorized."""
        response = await async_client.post(
            "/v1/users",
            json={"email": "newuser@example.com", "display_name": "New User"},
        )

        assert response.status_code == 401


class TestDependencyOverridePattern:
    """
    Demonstrates the dependency override pattern for auth testing.

    Use this pattern when:
    - LocalAuthMiddleware is not configured in the test app
    - You need to test with specific user attributes (custom roles, etc.)
    - You want to bypass all middleware for unit-style endpoint tests
    """

    @pytest.mark.asyncio
    async def test_with_dependency_override(
        self,
        async_client: AsyncClient,
        admin_authenticated_user: AuthenticatedUser,
    ) -> None:
        """
        Use dependency overrides for controlled auth testing.

        This injects the AuthenticatedUser directly, bypassing middleware.
        """
        from spaps_server_quickstart.auth.dependencies import require_authenticated_user

        # Set up the override
        async_client.app.dependency_overrides[require_authenticated_user] = (
            lambda: admin_authenticated_user
        )

        try:
            response = await async_client.get("/v1/users/me")
            # Response depends on whether user record exists in DB
            assert response.status_code in (200, 404)
        finally:
            # CRITICAL: Always clean up overrides to prevent test pollution
            async_client.app.dependency_overrides.pop(require_authenticated_user, None)

    @pytest.mark.asyncio
    async def test_override_cleanup_prevents_pollution(
        self,
        async_client: AsyncClient,
    ) -> None:
        """
        Verify auth is required after override cleanup.

        This test runs after the previous one to ensure cleanup worked.
        If cleanup failed, this would incorrectly pass.
        """
        response = await async_client.get("/v1/users/me")
        assert response.status_code == 401

    @pytest.mark.asyncio
    async def test_custom_roles_with_override(
        self,
        async_client: AsyncClient,
        user_persona: LocalPersona,
    ) -> None:
        """
        Override allows testing with custom role configurations.

        Useful for testing edge cases like users with unusual role combinations.
        """
        from spaps_server_quickstart.auth.dependencies import require_authenticated_user

        # Create a user with both staff and user roles (unusual combination)
        custom_user = AuthenticatedUser(
            user_id=user_persona.user_id,
            session_id="test-session-custom",
            application_id="test-application",
            roles={"staff", "user"},  # Custom role set
            subscription_active=True,
            subscription_plan="Custom Plan",
            tier="local",
        )

        async_client.app.dependency_overrides[require_authenticated_user] = (
            lambda: custom_user
        )

        try:
            # This user should be able to list users (requires staff or admin)
            response = await async_client.get("/v1/users")
            # 200 if works, 501 if service not implemented
            assert response.status_code in (200, 501)
        finally:
            async_client.app.dependency_overrides.pop(require_authenticated_user, None)
