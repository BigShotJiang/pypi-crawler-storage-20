"""
Example API test - Health endpoint.

Tests the /health endpoint returns expected format.
Replace {{SERVICE_MODULE}} with your service module name.
"""
import pytest


@pytest.mark.asyncio
async def test_health_endpoint_returns_ok(async_client):
    """Health endpoint should return status ok."""
    response = await async_client.get("/health")
    assert response.status_code == 200

    payload = response.json()
    assert payload["status"] == "ok"
    assert "version" in payload


@pytest.mark.asyncio
async def test_health_endpoint_includes_details(async_client):
    """Health endpoint should include diagnostic details."""
    response = await async_client.get("/health")
    payload = response.json()

    assert "details" in payload
    # Add assertions for your service's health details
