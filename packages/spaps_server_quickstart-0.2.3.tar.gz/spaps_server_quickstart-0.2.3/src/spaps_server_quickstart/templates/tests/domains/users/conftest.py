"""
Auth-aware fixtures for the users domain.

Provides persona fixtures and auth header helpers for testing role-based
access control. Uses the local persona system for predictable test identities.

Example usage:
    async def test_admin_can_create_users(async_client, admin_auth_header):
        response = await async_client.post(
            "/v1/users",
            headers=admin_auth_header,
            json={"email": "new@example.com", "display_name": "New User"},
        )
        assert response.status_code == 201
"""
from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from spaps_server_quickstart.auth import AuthenticatedUser
from spaps_server_quickstart.local_mode import LocalPersona, get_default_registry

if TYPE_CHECKING:
    from httpx import AsyncClient


# ============================================================================
# Persona Fixtures
# ============================================================================


@pytest.fixture
def admin_persona() -> LocalPersona:
    """Return the default admin persona for testing admin-only operations."""
    registry = get_default_registry()
    persona = registry.get_by_code("admin")
    assert persona is not None, "Admin persona not found in default registry"
    return persona


@pytest.fixture
def user_persona() -> LocalPersona:
    """Return the default user persona for testing user-level operations."""
    registry = get_default_registry()
    persona = registry.get_by_code("user")
    assert persona is not None, "User persona not found in default registry"
    return persona


# ============================================================================
# Auth Header Fixtures
# ============================================================================


@pytest.fixture
def admin_auth_header(admin_persona: LocalPersona) -> dict[str, str]:
    """
    Return Authorization header for admin persona.

    Use this when making requests that require admin role:
        response = await async_client.get("/users", headers=admin_auth_header)
    """
    return {"Authorization": f"Bearer {admin_persona.token}"}


@pytest.fixture
def user_auth_header(user_persona: LocalPersona) -> dict[str, str]:
    """
    Return Authorization header for user persona.

    Use this when testing non-admin authenticated requests.
    """
    return {"Authorization": f"Bearer {user_persona.token}"}


# ============================================================================
# AuthenticatedUser Fixtures
# ============================================================================


@pytest.fixture
def admin_authenticated_user(admin_persona: LocalPersona) -> AuthenticatedUser:
    """
    Return an AuthenticatedUser object for admin persona.

    Use this with dependency overrides when you need full control:
        app.dependency_overrides[require_authenticated_user] = lambda: admin_authenticated_user
    """
    return AuthenticatedUser(
        user_id=admin_persona.user_id,
        session_id=f"test-session-{admin_persona.code}",
        application_id="test-application",
        roles=set(admin_persona.roles),
        subscription_active=True,
        subscription_plan="Test Plan",
        tier="local",
    )


@pytest.fixture
def user_authenticated_user(user_persona: LocalPersona) -> AuthenticatedUser:
    """Return an AuthenticatedUser object for user persona."""
    return AuthenticatedUser(
        user_id=user_persona.user_id,
        session_id=f"test-session-{user_persona.code}",
        application_id="test-application",
        roles=set(user_persona.roles),
        subscription_active=True,
        subscription_plan="Test Plan",
        tier="local",
    )


# ============================================================================
# Dependency Override Helpers
# ============================================================================


def override_auth_dependency(
    async_client: "AsyncClient",
    authenticated_user: AuthenticatedUser,
) -> None:
    """
    Override require_authenticated_user to return the specified user.

    This bypasses all middleware and directly injects the authenticated user.
    Useful when LocalAuthMiddleware is not configured in the test app.

    Usage:
        override_auth_dependency(async_client, admin_authenticated_user)
        try:
            response = await async_client.get("/users/me")
            assert response.status_code == 200
        finally:
            clear_auth_overrides(async_client)
    """
    from spaps_server_quickstart.auth.dependencies import require_authenticated_user

    async_client.app.dependency_overrides[require_authenticated_user] = (
        lambda: authenticated_user
    )


def clear_auth_overrides(async_client: "AsyncClient") -> None:
    """
    Remove all auth-related dependency overrides.

    CRITICAL: Always call this in a finally block to prevent test pollution.
    """
    from spaps_server_quickstart.auth.dependencies import require_authenticated_user

    async_client.app.dependency_overrides.pop(require_authenticated_user, None)
