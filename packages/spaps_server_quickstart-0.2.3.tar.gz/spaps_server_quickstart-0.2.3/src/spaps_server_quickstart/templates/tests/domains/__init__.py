# Domain-specific test fixtures and helpers
