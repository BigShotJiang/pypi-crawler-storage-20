"""
Example integration test - Database connectivity.

Tests that the database connection works.
Replace {{SERVICE_MODULE}} with your service module name.
"""
import pytest
from sqlalchemy import text


@pytest.mark.integration
@pytest.mark.asyncio
async def test_database_connection(db_session):
    """Should be able to connect and query database."""
    result = await db_session.execute(text("SELECT 1"))
    assert result.scalar() == 1


@pytest.mark.integration
@pytest.mark.asyncio
async def test_admin_session_has_superuser(admin_session):
    """Admin session should have elevated permissions."""
    result = await admin_session.execute(text("SELECT current_user"))
    user = result.scalar()
    # Admin session uses postgres superuser
    assert user is not None


@pytest.mark.integration
@pytest.mark.asyncio
async def test_database_pgvector_extension(admin_session):
    """Database should have pgvector extension available."""
    result = await admin_session.execute(
        text("SELECT extname FROM pg_extension WHERE extname = 'vector'")
    )
    # Extension may or may not be installed depending on setup
    # This test documents the expected state
    pass
