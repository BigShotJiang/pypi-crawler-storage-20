# Operations Playbook: {{SERVICE_NAME}}

## Quick Reference

| Action | Command |
|--------|---------|
| Deploy | `git push origin main` (triggers CI) |
| Manual Deploy | `./deploy/deploy.sh --droplet $IP --tag $TAG` |
| Rollback | Actions > Rollback > Enter SHA |
| View Logs | `docker logs {{SERVICE_NAME}}-api` |
| Health Check | `curl https://api.example.com/health` |

## Deployment

### Prerequisites
- [ ] SSH access to production server
- [ ] GHCR credentials configured
- [ ] Environment variables set in GitHub Secrets

### Standard Deployment
```bash
git push origin main  # Triggers GitHub Actions
```

### Manual Deployment
```bash
./deploy/deploy.sh --droplet $DROPLET_IP --tag $IMAGE_TAG
```

### Verify Deployment
```bash
# Check containers are running
docker ps --filter name={{SERVICE_NAME}}

# Check health endpoint
curl https://api.example.com/health

# Check logs for errors
docker logs {{SERVICE_NAME}}-api --tail 50
```

## Rollback Procedures

### Via GitHub Actions (Recommended)
1. Go to Actions > Rollback
2. Enter the commit SHA to rollback to
3. Click "Run workflow"
4. Monitor the deployment

### Manual Rollback
```bash
# SSH to production
ssh root@$DROPLET_IP

# Navigate to service directory
cd /opt/{{SERVICE_NAME}}

# Pull the previous image
export API_IMAGE=ghcr.io/org/service:$PREVIOUS_SHA
docker compose -f deploy/docker-compose.prod.yml pull

# Deploy
docker compose -f deploy/docker-compose.prod.yml up -d

# Verify
./deploy/post-deploy-verify.sh
```

### Database Rollback (if needed)
```bash
# SSH to production
ssh root@$DROPLET_IP

# Run migration rollback
docker exec {{SERVICE_NAME}}-api alembic downgrade -1

# Verify migration status
docker exec {{SERVICE_NAME}}-api alembic current
```

## Database Operations

### Run Migrations
```bash
docker exec {{SERVICE_NAME}}-api alembic upgrade head
```

### Check Migration Status
```bash
docker exec {{SERVICE_NAME}}-api alembic current
```

### Create Backup
```bash
./scripts/backup-db.sh
# Backup saved to: /var/backups/{{SERVICE_NAME}}/
```

### Restore Backup
```bash
./scripts/restore-db.sh $BACKUP_FILE
```

## Health Checks

### Check Service Health
```bash
curl https://api.example.com/health
```

Expected response:
```json
{
  "status": "ok",
  "version": "abc123",
  "details": {
    "database": "ok",
    "redis": "ok"
  }
}
```

### Check Container Status
```bash
docker ps --filter name={{SERVICE_NAME}}
docker stats --no-stream {{SERVICE_NAME}}-api
```

### Check Logs
```bash
# API logs
docker logs {{SERVICE_NAME}}-api --tail 100

# Worker logs
docker logs {{SERVICE_NAME}}-worker --tail 100

# All logs with timestamps
docker logs {{SERVICE_NAME}}-api -t --since 1h
```

## Secrets Management

### Required Environment Variables
| Variable | Description | Where Set |
|----------|-------------|-----------|
| DATABASE_URL | PostgreSQL connection string | GitHub Secrets |
| REDIS_URL | Redis connection string | GitHub Secrets |
| SPAPS_API_KEY | Auth service API key | GitHub Secrets |
| SPAPS_APPLICATION_ID | Application identifier | GitHub Secrets |

### Updating Secrets
1. Go to GitHub repo > Settings > Secrets
2. Update the secret value
3. Re-deploy to apply changes

### Local Development Secrets
```bash
# Copy example env file
cp .env.example .env

# Edit with your values
vim .env
```

## Troubleshooting

### Container Won't Start
1. Check logs: `docker logs {{SERVICE_NAME}}-api`
2. Verify env vars: `docker exec {{SERVICE_NAME}}-api env | grep -E 'DATABASE|REDIS'`
3. Check disk space: `df -h`
4. Check memory: `free -m`

### Database Connection Issues
1. Verify DATABASE_URL format
2. Check network connectivity:
   ```bash
   docker exec {{SERVICE_NAME}}-api pg_isready -h $DB_HOST -p 5432
   ```
3. Check database logs: `docker logs {{SERVICE_NAME}}-db`

### High Memory Usage
1. Check container stats: `docker stats`
2. Review recent deployments
3. Check for memory leaks in application logs
4. Consider scaling or resource limits

### Service Unavailable
1. Check if containers are running: `docker ps`
2. Check nginx proxy: `docker logs shared-reverse-proxy`
3. Verify SSL certificates
4. Check health endpoint directly: `curl http://localhost:8000/health`

## Monitoring

### Key Metrics
- Request latency (p50, p95, p99)
- Error rate (5xx responses)
- Database connection pool usage
- Memory and CPU utilization

### Alerting Thresholds
| Metric | Warning | Critical |
|--------|---------|----------|
| Error Rate | > 1% | > 5% |
| P95 Latency | > 500ms | > 2s |
| CPU Usage | > 70% | > 90% |
| Memory Usage | > 80% | > 95% |

## Contacts

| Role | Contact |
|------|---------|
| On-call | #oncall-channel |
| Infrastructure | @infra-team |
| Security | security@example.com |
