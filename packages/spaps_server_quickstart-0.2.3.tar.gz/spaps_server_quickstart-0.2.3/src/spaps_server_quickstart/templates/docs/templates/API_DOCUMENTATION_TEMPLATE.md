# [Resource Name] API

Brief description of what this API manages.

## Authentication

Describe auth requirements (Bearer token, API key, etc.)

- `Authorization: Bearer <token>` - Required for authenticated endpoints
- Public endpoints marked as such

## Endpoints

### GET `/v1/resource`

List all resources.

**Query Parameters:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| limit | int | No | Max results (default: 50) |
| offset | int | No | Pagination offset |
| status | string | No | Filter by status |

**Response:** `200 OK`
```json
{
  "items": [
    {
      "id": "uuid",
      "name": "Example",
      "created_at": "2024-01-01T00:00:00Z"
    }
  ],
  "total": 100,
  "limit": 50,
  "offset": 0
}
```

### GET `/v1/resource/{id}`

Get a single resource.

**Path Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| id | uuid | Resource ID |

**Response:** `200 OK`
```json
{
  "id": "uuid",
  "name": "Example",
  "status": "active",
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-01T00:00:00Z"
}
```

### POST `/v1/resource`

Create a new resource.

**Request Body:**
```json
{
  "name": "Example",
  "description": "Optional description"
}
```

**Response:** `201 Created`
```json
{
  "id": "uuid",
  "name": "Example",
  "status": "active",
  "created_at": "2024-01-01T00:00:00Z"
}
```

### PATCH `/v1/resource/{id}`

Update a resource.

**Request Body:**
```json
{
  "name": "Updated Name",
  "status": "inactive"
}
```

**Response:** `200 OK`

### DELETE `/v1/resource/{id}`

Delete a resource.

**Response:** `204 No Content`

## Error Codes

| Status | Code | Description |
|--------|------|-------------|
| 400 | VALIDATION_ERROR | Invalid request body |
| 401 | UNAUTHORIZED | Missing or invalid token |
| 403 | FORBIDDEN | Insufficient permissions |
| 404 | NOT_FOUND | Resource not found |
| 409 | CONFLICT | Resource already exists |
| 422 | UNPROCESSABLE_ENTITY | Request validation failed |

## Rate Limits

| Tier | Requests/min | Burst |
|------|-------------|-------|
| Standard | 60 | 10 |
| Premium | 300 | 50 |

## Related Files

- Router: `src/.../domains/resource/router.py`
- Service: `src/.../domains/resource/service.py`
- Models: `src/.../domains/resource/models.py`
- Schemas: `src/.../domains/resource/schemas.py`
