"""
Alembic environment configuration.
Generated from spaps-server-quickstart template.

TEMPLATE: Replace {{SERVICE_MODULE}} with your service module name.
Example: htma_server, ingredient_server
"""

from __future__ import annotations

import sys
from pathlib import Path

from alembic import context
from sqlalchemy import engine_from_config, pool, text
from sqlalchemy.engine import Connection

# Ensure src/ is in path for imports
PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_PATH = PROJECT_ROOT / "src"
for path in (SRC_PATH, PROJECT_ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

# TODO: Replace with your service imports
# from {{SERVICE_MODULE}}.core.settings import get_settings
# from {{SERVICE_MODULE}}.models import Base, _import_all_models

# For now, import from spaps_server_quickstart for basic setup
from spaps_server_quickstart.settings import get_settings  # noqa: E402

# Placeholder - services should define their own Base and model imports
# _import_all_models()

config = context.config

# Services should set target_metadata = Base.metadata
# For template, we use None (no autogenerate without models)
target_metadata = None


def get_sync_url() -> str:
    """Get synchronous database URL for Alembic."""
    settings = get_settings()
    return settings.sync_database_url


def run_migrations_offline() -> None:
    """
    Run migrations in 'offline' mode.

    Generates SQL without connecting to the database.
    Useful for reviewing migration SQL before applying.
    """
    context.configure(
        url=get_sync_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        compare_type=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    """Execute migrations with the given connection."""
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        compare_type=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """
    Run migrations in 'online' mode.

    Connects to the actual database and applies migrations.
    Handles pgvector extension creation automatically.
    """
    configuration = config.get_section(config.config_ini_section, {})
    configuration["sqlalchemy.url"] = get_sync_url()

    connectable = engine_from_config(
        configuration,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        # Ensure pgvector extension exists
        # Try 'vector' first (standard name), fall back to 'pgvector' (older name)
        connection.execute(
            text(
                """
                DO $$
                BEGIN
                    CREATE EXTENSION IF NOT EXISTS vector;
                EXCEPTION
                    WHEN undefined_file THEN
                        BEGIN
                            CREATE EXTENSION IF NOT EXISTS pgvector;
                        EXCEPTION
                            WHEN undefined_file THEN
                                RAISE NOTICE 'pgvector extension not available';
                        END;
                END;
                $$;
                """
            )
        )
        connection.commit()

        do_run_migrations(connection)

    connectable.dispose()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
