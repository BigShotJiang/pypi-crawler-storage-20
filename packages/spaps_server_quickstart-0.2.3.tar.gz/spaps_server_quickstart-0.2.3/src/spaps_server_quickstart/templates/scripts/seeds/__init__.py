"""Seed data templates and validation schemas."""
