"""
Startup validation for Sweet Potato services.

Provides fail-fast configuration validation and startup logging with masked secrets.
Call startup_checks() in your app's lifespan context manager before yielding.
"""

from __future__ import annotations

import os
import re
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from .settings import BaseServiceSettings

logger = structlog.get_logger(__name__)


def startup_checks(settings: "BaseServiceSettings") -> None:
    """
    Run all startup validation and logging.

    Call this in your lifespan context manager before yielding.
    Raises RuntimeError if configuration is invalid.

    Example:
        @asynccontextmanager
        async def lifespan(app: FastAPI):
            startup_checks(settings)
            yield
    """
    logger.info("startup_validation_begin")
    validate_settings(settings)
    log_startup_config(settings)
    logger.info("startup_validation_complete")


def validate_settings(settings: "BaseServiceSettings") -> None:
    """
    Validate settings and fail fast if invalid.

    Collects all errors and raises a single RuntimeError with all issues.
    This catches configuration problems early before they cause confusing
    failures later in the application lifecycle.

    Raises:
        RuntimeError: If configuration is invalid.
    """
    errors: list[str] = []

    # Required: DATABASE_URL must be set and valid PostgreSQL
    if not settings.database_url:
        errors.append("DATABASE_URL is required")
    elif not settings.database_url.startswith("postgresql"):
        errors.append(
            f"DATABASE_URL must start with 'postgresql', got: {settings.database_url[:30]}..."
        )

    # Conditional: if SPAPS auth is enabled, require related vars
    if settings.spaps_auth_enabled:
        if not settings.spaps_api_key:
            errors.append("SPAPS_API_KEY is required when SPAPS_AUTH_ENABLED=true")
        if not settings.spaps_application_id:
            errors.append("SPAPS_APPLICATION_ID is required when SPAPS_AUTH_ENABLED=true")
        if not settings.spaps_api_url:
            errors.append("SPAPS_API_URL is required when SPAPS_AUTH_ENABLED=true")

    if errors:
        error_msg = "Configuration validation failed:\n  - " + "\n  - ".join(errors)
        logger.error("startup_validation_failed", errors=errors)
        raise RuntimeError(error_msg)


def log_startup_config(settings: "BaseServiceSettings") -> None:
    """
    Log configuration summary at startup with masked secrets.

    Provides visibility into what configuration the service is running with,
    while ensuring sensitive values (like passwords) are not exposed in logs.
    """
    db_display = _mask_database_url(settings.database_url)
    version = os.environ.get("GIT_COMMIT_SHA", settings.version)

    logger.info(
        "startup_config",
        app_name=settings.app_name,
        version=version,
        environment=settings.env,
        auth_enabled=settings.spaps_auth_enabled,
        database=db_display,
        cors_origins_count=len(settings.cors_allow_origins),
        debug=settings.debug,
        log_level=settings.log_level,
    )


def _mask_database_url(url: str | None) -> str:
    """
    Mask password in database URL for safe logging.

    Handles standard PostgreSQL connection strings:
        postgresql+asyncpg://user:password@host:port/dbname
        postgresql+psycopg://user:password@host:port/dbname

    Args:
        url: Database connection URL or None.

    Returns:
        Masked URL safe for logging, or placeholder if not set.
    """
    if not url:
        return "<not set>"

    # Match PostgreSQL URLs with password
    # postgresql+driver://user:password@host:port/dbname
    match = re.match(
        r"(postgresql(?:\+\w+)?://)([^:]+):([^@]+)@(.+)",
        url,
    )
    if match:
        prefix, user, _password, rest = match.groups()
        return f"{prefix}{user}:****@{rest}"

    # Fallback: truncate unrecognized formats
    if len(url) > 30:
        return url[:30] + "..."
    return url
