"""
CLI for seed validation.
"""
from __future__ import annotations

import sys
from pathlib import Path

try:
    import click

    CLICK_AVAILABLE = True
except ImportError:
    CLICK_AVAILABLE = False
    click = None  # type: ignore[assignment]

from .schemas import list_registered_schemas
from .validator import validate_file, validate_directory


if CLICK_AVAILABLE:

    @click.group()
    def seeds():
        """Seed file management commands."""
        pass

    @seeds.command()
    @click.argument("path", type=click.Path(exists=True, path_type=Path))
    @click.option("--verbose", "-v", is_flag=True, help="Show detailed output")
    def validate(path: Path, verbose: bool) -> None:
        """
        Validate seed YAML files against registered schemas.

        PATH can be a single file or directory (recursive).
        """
        if path.is_file():
            success, error = validate_file(path, verbose)
            if success:
                click.echo(click.style(f"  {path.name}: Valid", fg="green"))
            else:
                click.echo(
                    click.style(f"  {path.name}: {error}", fg="red"), err=True
                )
                raise SystemExit(1)
        else:
            passed, failed, errors = validate_directory(path, verbose)

            click.echo(f"\nResults: {passed} passed, {failed} failed")

            if errors:
                click.echo(click.style("\nErrors:", fg="red"))
                for filepath, error in errors:
                    click.echo(f"  {filepath}: {error}")
                raise SystemExit(1)

            if verbose:
                click.echo(click.style("\n  All seed files valid", fg="green"))

    @seeds.command("list-schemas")
    def list_schemas_cmd() -> None:
        """List all registered seed schemas."""
        schemas = list_registered_schemas()
        if not schemas:
            click.echo("No schemas registered.")
            return

        click.echo("Registered schemas:")
        for pattern, name in schemas.items():
            click.echo(f"  {pattern}: {name}")

else:
    # Fallback when click is not available
    def seeds():  # type: ignore[misc]
        """Seed file management commands (click not installed)."""
        print("Click is not installed. Install with: pip install click")
        sys.exit(1)

    def validate(path=None, verbose=False):  # type: ignore[misc]
        """Validate seed files (click not installed)."""
        print("Click is not installed. Install with: pip install click")
        sys.exit(1)

    def list_schemas_cmd():  # type: ignore[misc]
        """List schemas (click not installed)."""
        print("Click is not installed. Install with: pip install click")
        sys.exit(1)
