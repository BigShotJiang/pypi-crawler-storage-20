"""
Validation logic for seed files.
"""
from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import ValidationError

from .schemas import get_schema_for_file


def validate_file(
    file_path: Path,
    verbose: bool = False,
) -> tuple[bool, str | None]:
    """
    Validate a single YAML file against its registered schema.

    Returns:
        (success: bool, error_message: str | None)
    """
    schema = get_schema_for_file(str(file_path))
    if schema is None:
        return True, None  # No schema = no validation (warning in verbose)

    try:
        with open(file_path) as f:
            data = yaml.safe_load(f)

        if data is None:
            # Empty file
            return True, None

        if isinstance(data, dict):
            schema(**data)
        elif isinstance(data, list):
            # Handle list-based schemas (e.g., RootModel)
            if hasattr(schema, "model_validate"):
                schema.model_validate(data)
            else:
                # Try to validate as root list
                for item in data:
                    if isinstance(item, dict):
                        schema(**item)
        return True, None

    except yaml.YAMLError as e:
        return False, f"YAML parse error: {e}"
    except ValidationError as e:
        return False, f"Validation error: {e}"
    except Exception as e:
        return False, f"Unexpected error: {e}"


def validate_directory(
    directory: Path,
    verbose: bool = False,
) -> tuple[int, int, list[tuple[Path, str]]]:
    """
    Validate all YAML files in a directory recursively.

    Returns:
        (passed: int, failed: int, errors: list[(path, error_msg)])
    """
    passed = 0
    failed = 0
    errors: list[tuple[Path, str]] = []

    # Find all .yaml and .yml files
    yaml_files: list[Path] = []
    yaml_files.extend(directory.rglob("*.yaml"))
    yaml_files.extend(directory.rglob("*.yml"))

    for yaml_file in yaml_files:
        success, error = validate_file(yaml_file, verbose)
        if success:
            passed += 1
        else:
            failed += 1
            if error:
                errors.append((yaml_file, error))

    return passed, failed, errors
