"""
Base schemas and registry for seed file validation.

Services extend these and register their own schemas.
"""
from __future__ import annotations

import re
from typing import TypeVar

from pydantic import BaseModel, ConfigDict

T = TypeVar("T", bound=BaseModel)

# Registry: pattern -> schema class
_SCHEMA_REGISTRY: dict[str, type[BaseModel]] = {}


class SeedSchemaBase(BaseModel):
    """
    Base class for seed file schemas.

    Uses strict validation by default:
    - extra="forbid" - Fail on unknown fields
    """

    model_config = ConfigDict(extra="forbid")


def register_schema(pattern: str, schema: type[BaseModel]) -> None:
    """
    Register a Pydantic schema for files matching a regex pattern.

    Example:
        register_schema(r"personas\\.yaml$", PersonaListSchema)
        register_schema(r"products/.*\\.yaml$", ProductSchema)
    """
    _SCHEMA_REGISTRY[pattern] = schema


def get_schema_for_file(filename: str) -> type[BaseModel] | None:
    """Get the registered schema for a filename, or None if no match."""
    for pattern, schema in _SCHEMA_REGISTRY.items():
        if re.search(pattern, filename):
            return schema
    return None


def list_registered_schemas() -> dict[str, str]:
    """Return dict of pattern -> schema name for debugging."""
    return {pattern: schema.__name__ for pattern, schema in _SCHEMA_REGISTRY.items()}


def clear_registry() -> None:
    """Clear all registered schemas. Useful for testing."""
    _SCHEMA_REGISTRY.clear()
