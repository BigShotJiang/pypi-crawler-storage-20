"""
Shared health endpoint factory.
"""

from __future__ import annotations

import inspect
import os
from collections.abc import AsyncIterator, Awaitable, Callable, Mapping
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession

from ..schemas.health import HealthResponse
from ..settings import BaseServiceSettings

ExtraMetrics = Mapping[str, Any] | dict[str, Any]
ExtraMetricsProvider = Callable[[BaseServiceSettings, AsyncSession | None], Awaitable[ExtraMetrics] | ExtraMetrics]

_SERVICE_STARTED_AT = datetime.now(tz=UTC)
_UPTIME_UNITS: tuple[tuple[str, int], ...] = (
    ("year", 365 * 24 * 60 * 60),
    ("month", 30 * 24 * 60 * 60),
    ("day", 24 * 60 * 60),
    ("hour", 60 * 60),
    ("minute", 60),
    ("second", 1),
)


def _summarize_uptime(*, now: datetime | None = None) -> dict[str, Any]:
    """Return human-friendly uptime metadata for the health endpoint."""
    now = now or datetime.now(tz=UTC)
    elapsed_seconds = max(int((now - _SERVICE_STARTED_AT).total_seconds()), 0)

    unit_name = "second"
    unit_seconds = 1
    for candidate_unit, candidate_seconds in _UPTIME_UNITS:
        if elapsed_seconds >= candidate_seconds or candidate_unit == "second":
            unit_name = candidate_unit
            unit_seconds = candidate_seconds
            break

    value = elapsed_seconds / unit_seconds if unit_seconds else 0
    if unit_name == "second":
        rounded_value: int | float = elapsed_seconds
    elif value >= 10:
        rounded_value = round(value)
    else:
        rounded_value = round(value, 1)

    if isinstance(rounded_value, float) and rounded_value.is_integer():
        rounded_value = int(rounded_value)

    label = f"{rounded_value} {unit_name}{'s' if rounded_value != 1 else ''}"

    return {
        "display": label,
        "granularity": unit_name,
        "seconds": elapsed_seconds,
        "started_at": _SERVICE_STARTED_AT.isoformat(),
    }


def _get_version_info() -> dict[str, str]:
    """Return git commit information from environment variables."""
    git_sha = os.environ.get("GIT_COMMIT_SHA", "unknown")
    return {
        "commit": git_sha,
        "short_commit": git_sha[:7] if git_sha != "unknown" else "unknown",
    }


def _check_redis_connectivity(redis_url: str) -> dict[str, Any]:
    """Check Redis connectivity and return status."""
    try:
        import redis
    except ImportError:
        return {"status": "unavailable", "error": "redis package not installed"}

    redis_status = "disconnected"
    redis_error: str | None = None
    try:
        redis_client = redis.from_url(redis_url, socket_connect_timeout=2, socket_timeout=2)
        redis_client.ping()
        redis_status = "connected"
        redis_client.close()
    except redis.ConnectionError as e:
        redis_error = f"connection_error: {e}"
    except redis.TimeoutError as e:
        redis_error = f"timeout: {e}"
    except Exception as e:  # noqa: BLE001 - broad exception for health check
        redis_error = f"error: {type(e).__name__}"

    if redis_error:
        return {"status": redis_status, "error": redis_error}
    return {"status": redis_status}


class HealthRouterFactory:
    """
    Compose a standard `/health` endpoint with optional database checks.
    """

    def __init__(
        self,
        *,
        settings_loader: Callable[[], BaseServiceSettings],
        session_dependency: Callable[[], AsyncIterator[AsyncSession]] | None = None,
        extra_metrics_provider: ExtraMetricsProvider | None = None,
        include_uptime: bool = True,
        include_version: bool = True,
        include_redis: bool = True,
    ) -> None:
        self._settings_loader = settings_loader
        self._session_dependency = session_dependency
        self._extra_metrics_provider = extra_metrics_provider
        self._include_uptime = include_uptime
        self._include_version = include_version
        self._include_redis = include_redis

    def create_router(self) -> APIRouter:
        router = APIRouter()
        dependency = self._session_dependency
        extra_provider = self._extra_metrics_provider
        settings_loader = self._settings_loader

        if dependency is not None:

            async def health_endpoint(
                session: AsyncSession = Depends(dependency),
            ) -> HealthResponse:
                return await self._build_response(settings_loader(), session, extra_provider)

            router.add_api_route(
                "/health",
                health_endpoint,
                response_model=HealthResponse,
                tags=["health"],
            )
        else:

            async def health_endpoint_no_db() -> HealthResponse:
                return await self._build_response(settings_loader(), None, extra_provider)

            router.add_api_route(
                "/health",
                health_endpoint_no_db,
                response_model=HealthResponse,
                tags=["health"],
            )

        return router

    async def _build_response(
        self,
        settings: BaseServiceSettings,
        session: AsyncSession | None,
        extra_provider: ExtraMetricsProvider | None,
    ) -> HealthResponse:
        database_ready = True
        if session is not None:
            try:
                await session.execute(text("SELECT 1"))
            except SQLAlchemyError:
                database_ready = False

        details: dict[str, Any] = {}

        # Add default metrics
        if self._include_uptime:
            details["uptime"] = _summarize_uptime()

        if self._include_version:
            details["version"] = _get_version_info()

        if self._include_redis:
            details["redis"] = _check_redis_connectivity(settings.redis_url)

        # Add custom extra metrics from provider
        if extra_provider is not None:
            result = extra_provider(settings, session)
            if inspect.isawaitable(result):
                result = await result  # type: ignore[assignment]
            details.update(dict(result))

        return HealthResponse(
            status="ok" if database_ready else "degraded",
            service=settings.resolved_service_slug,
            version=settings.version,
            database_ready=database_ready,
            details=details,
        )
