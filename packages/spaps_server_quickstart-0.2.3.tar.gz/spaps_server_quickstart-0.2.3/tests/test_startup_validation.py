"""
Tests for startup validation functionality.

TDD: These tests were written first per docs/TDD_PLAN.md.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from spaps_server_quickstart.settings import BaseServiceSettings


class ValidSettings(BaseServiceSettings):
    """Test settings with valid defaults."""

    app_name: str = "Test Service"
    database_url: str = "postgresql+asyncpg://user:secret@localhost:5432/testdb"


class AuthEnabledSettings(BaseServiceSettings):
    """Test settings with SPAPS auth enabled."""

    app_name: str = "Auth Service"
    database_url: str = "postgresql+asyncpg://user:pass@localhost:5432/authdb"
    spaps_auth_enabled: bool = True
    spaps_api_key: str = "test-api-key"
    spaps_application_id: str = "test-app-id"
    spaps_api_url: str = "https://api.test.com"


# Alias for cleaner test code
TestSettings = ValidSettings


# =============================================================================
# Tests for validate_settings()
# =============================================================================


def test_validate_settings_passes_valid_config() -> None:
    """Valid configuration should pass validation without errors."""
    from spaps_server_quickstart.startup import validate_settings

    settings = TestSettings()
    # Should not raise
    validate_settings(settings)


def test_validate_settings_missing_database_url() -> None:
    """Missing DATABASE_URL should fail validation."""

    class EmptyDbSettings(BaseServiceSettings):
        database_url: str = ""

    # Pydantic validator catches this first, but our validate_settings should too
    with pytest.raises(ValueError):
        EmptyDbSettings()


def test_validate_settings_invalid_database_url_prefix() -> None:
    """DATABASE_URL must start with postgresql."""
    from spaps_server_quickstart.startup import validate_settings

    class BadUrlSettings(BaseServiceSettings):
        database_url: str = "mysql://user:pass@localhost/db"

    settings = BadUrlSettings()
    with pytest.raises(RuntimeError, match="must start with 'postgresql'"):
        validate_settings(settings)


def test_validate_settings_spaps_auth_requires_api_key() -> None:
    """SPAPS auth enabled without API key should fail."""
    from spaps_server_quickstart.startup import validate_settings

    class MissingKeySettings(BaseServiceSettings):
        database_url: str = "postgresql+asyncpg://user:pass@localhost/db"
        spaps_auth_enabled: bool = True
        spaps_api_key: str | None = None
        spaps_application_id: str = "app-id"
        spaps_api_url: str = "https://api.test.com"

    settings = MissingKeySettings()
    with pytest.raises(RuntimeError, match="SPAPS_API_KEY is required"):
        validate_settings(settings)


def test_validate_settings_spaps_auth_requires_application_id() -> None:
    """SPAPS auth enabled without application ID should fail."""
    from spaps_server_quickstart.startup import validate_settings

    class MissingAppIdSettings(BaseServiceSettings):
        database_url: str = "postgresql+asyncpg://user:pass@localhost/db"
        spaps_auth_enabled: bool = True
        spaps_api_key: str = "test-key"
        spaps_application_id: str | None = None
        spaps_api_url: str = "https://api.test.com"

    settings = MissingAppIdSettings()
    with pytest.raises(RuntimeError, match="SPAPS_APPLICATION_ID is required"):
        validate_settings(settings)


def test_validate_settings_spaps_auth_requires_api_url() -> None:
    """SPAPS auth enabled without API URL should fail."""
    from spaps_server_quickstart.startup import validate_settings

    class MissingUrlSettings(BaseServiceSettings):
        database_url: str = "postgresql+asyncpg://user:pass@localhost/db"
        spaps_auth_enabled: bool = True
        spaps_api_key: str = "test-key"
        spaps_application_id: str = "app-id"
        spaps_api_url: str = ""

    settings = MissingUrlSettings()
    with pytest.raises(RuntimeError, match="SPAPS_API_URL is required"):
        validate_settings(settings)


def test_validate_settings_collects_all_errors() -> None:
    """Multiple validation errors should all be reported."""
    from spaps_server_quickstart.startup import validate_settings

    class MultiErrorSettings(BaseServiceSettings):
        database_url: str = "mysql://user:pass@localhost/db"  # Wrong prefix
        spaps_auth_enabled: bool = True
        spaps_api_key: str | None = None  # Missing
        spaps_application_id: str | None = None  # Missing
        spaps_api_url: str = ""  # Missing

    settings = MultiErrorSettings()
    with pytest.raises(RuntimeError) as exc_info:
        validate_settings(settings)

    error_msg = str(exc_info.value)
    assert "postgresql" in error_msg
    assert "SPAPS_API_KEY" in error_msg
    assert "SPAPS_APPLICATION_ID" in error_msg
    assert "SPAPS_API_URL" in error_msg


def test_validate_settings_passes_with_auth_enabled_and_all_fields() -> None:
    """SPAPS auth with all required fields should pass."""
    from spaps_server_quickstart.startup import validate_settings

    settings = AuthEnabledSettings()
    # Should not raise
    validate_settings(settings)


# =============================================================================
# Tests for log_startup_config()
# =============================================================================


def test_log_startup_config_masks_password() -> None:
    """Database password should be masked in startup logs."""
    from spaps_server_quickstart.startup import log_startup_config

    settings = TestSettings()

    with patch("spaps_server_quickstart.startup.logger") as mock_logger:
        log_startup_config(settings)

        mock_logger.info.assert_called_once()
        call_kwargs = mock_logger.info.call_args.kwargs

        # Password "secret" should NOT appear in logged database value
        assert "secret" not in call_kwargs["database"]
        # But masked version should
        assert "****" in call_kwargs["database"]
        assert "user" in call_kwargs["database"]


def test_log_startup_config_includes_app_name() -> None:
    """Startup logs should include app name."""
    from spaps_server_quickstart.startup import log_startup_config

    settings = TestSettings()

    with patch("spaps_server_quickstart.startup.logger") as mock_logger:
        log_startup_config(settings)

        call_kwargs = mock_logger.info.call_args.kwargs
        assert call_kwargs["app_name"] == "Test Service"


def test_log_startup_config_includes_environment() -> None:
    """Startup logs should include environment."""
    from spaps_server_quickstart.startup import log_startup_config

    class ProdSettings(BaseServiceSettings):
        env: str = "production"
        database_url: str = "postgresql+asyncpg://user:pass@localhost/db"

    settings = ProdSettings()

    with patch("spaps_server_quickstart.startup.logger") as mock_logger:
        log_startup_config(settings)

        call_kwargs = mock_logger.info.call_args.kwargs
        assert call_kwargs["environment"] == "production"


def test_log_startup_config_includes_version() -> None:
    """Startup logs should include version from env or settings."""
    from spaps_server_quickstart.startup import log_startup_config

    settings = TestSettings()

    with patch.dict("os.environ", {"GIT_COMMIT_SHA": "abc123"}):
        with patch("spaps_server_quickstart.startup.logger") as mock_logger:
            log_startup_config(settings)

            call_kwargs = mock_logger.info.call_args.kwargs
            assert call_kwargs["version"] == "abc123"


# =============================================================================
# Tests for startup_checks() integration
# =============================================================================


def test_startup_checks_calls_validate_then_log() -> None:
    """startup_checks should validate settings and log config."""
    from spaps_server_quickstart.startup import startup_checks

    settings = TestSettings()

    with patch("spaps_server_quickstart.startup.logger") as mock_logger:
        startup_checks(settings)

        # Should log startup_validation_begin, startup_config, startup_validation_complete
        calls = [call.args[0] for call in mock_logger.info.call_args_list]
        assert "startup_validation_begin" in calls
        assert "startup_config" in calls
        assert "startup_validation_complete" in calls


def test_startup_checks_raises_on_validation_failure() -> None:
    """startup_checks should raise if validation fails."""
    from spaps_server_quickstart.startup import startup_checks

    class BadSettings(BaseServiceSettings):
        database_url: str = "mysql://user:pass@localhost/db"

    settings = BadSettings()
    with pytest.raises(RuntimeError, match="Configuration validation failed"):
        startup_checks(settings)


# =============================================================================
# Tests for _mask_database_url() helper
# =============================================================================


def test_mask_database_url_standard_format() -> None:
    """Standard PostgreSQL URL password should be masked."""
    from spaps_server_quickstart.startup import _mask_database_url

    url = "postgresql+asyncpg://myuser:mysecretpassword@db.example.com:5432/mydb"
    masked = _mask_database_url(url)

    assert "mysecretpassword" not in masked
    assert "myuser" in masked
    assert "db.example.com" in masked
    assert "mydb" in masked
    assert "****" in masked


def test_mask_database_url_handles_none() -> None:
    """None URL should return placeholder."""
    from spaps_server_quickstart.startup import _mask_database_url

    masked = _mask_database_url(None)
    assert masked == "<not set>"


def test_mask_database_url_handles_empty() -> None:
    """Empty URL should return placeholder."""
    from spaps_server_quickstart.startup import _mask_database_url

    masked = _mask_database_url("")
    assert masked == "<not set>"


def test_mask_database_url_handles_unusual_format() -> None:
    """Non-standard URL format should be truncated safely."""
    from spaps_server_quickstart.startup import _mask_database_url

    url = "some-weird-connection-string-that-is-very-long"
    masked = _mask_database_url(url)

    # Should truncate long strings
    assert len(masked) <= 40
    assert "..." in masked


def test_mask_database_url_psycopg_driver() -> None:
    """psycopg driver URL should also be masked."""
    from spaps_server_quickstart.startup import _mask_database_url

    url = "postgresql+psycopg://user:password@localhost:5432/db"
    masked = _mask_database_url(url)

    assert "password" not in masked
    assert "user" in masked
    assert "****" in masked
