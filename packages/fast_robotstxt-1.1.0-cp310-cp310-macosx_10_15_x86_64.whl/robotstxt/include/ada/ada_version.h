/**
 * @file ada_version.h
 * @brief Definitions for Ada's version number.
 */
#ifndef ADA_ADA_VERSION_H
#define ADA_ADA_VERSION_H

#define ADA_VERSION "3.4.1"

namespace ada {

enum {
  ADA_VERSION_MAJOR = 3,
  ADA_VERSION_MINOR = 4,
  ADA_VERSION_REVISION = 1,
};

}  // namespace ada

#endif  // ADA_ADA_VERSION_H
