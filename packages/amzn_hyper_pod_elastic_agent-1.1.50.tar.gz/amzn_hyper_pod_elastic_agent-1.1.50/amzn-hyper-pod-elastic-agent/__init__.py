"""
amzn-hyper-pod-elastic-agent

Experimental Python package for research and educational purposes.
"""

__version__ = "10.0.2"
