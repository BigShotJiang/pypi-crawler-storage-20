def hello():
    return "Hello from amzn-hyper-pod-elastic-agent"
