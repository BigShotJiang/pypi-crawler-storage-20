"""
Guild Restoration Worker - Restores ALL guild settings (name, icon, banner, vanity, etc.)
"""
import asyncio
import discord
from datetime import datetime
from typing import Dict, Any


class GuildWorker:
    """Background worker for guild settings restoration"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.restore_queue = asyncio.Queue()
        self._worker_task = None
    
    async def start(self):
        """Start the guild restoration worker"""
        if self._worker_task is None or self._worker_task.done():
            self._worker_task = asyncio.create_task(self._restoration_loop())
            print("⚡ Guild Restoration Worker started")
    
    async def stop(self):
        """Stop the worker"""
        if self._worker_task:
            self._worker_task.cancel()
            self._worker_task = None
    
    async def queue_restoration(self, guild: discord.Guild, changes: Dict[str, Any]):
        """Queue a guild settings restoration"""
        await self.restore_queue.put({
            "guild": guild,
            "changes": changes,
            "timestamp": datetime.now()
        })
    
    async def _restoration_loop(self):
        """Main worker loop"""
        while True:
            try:
                task = await self.restore_queue.get()
                await self._restore_guild_settings(task)
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error in guild restoration worker: {e}")
    
    async def _restore_guild_settings(self, task: dict):
        """Restore guild settings"""
        try:
            guild = task["guild"]
            changes = task["changes"]
            
            start_time = datetime.now()
            
            backup_data = await self.sdk.backup_manager.get_guild_settings(guild.id)
            if not backup_data:
                print(f"⚠️ No backup found for guild {guild.name}")
                return
            
            restore_params = {}
            restored_items = []
            
            if "vanity_url_code" in changes and backup_data.get("vanity_url_code"):
                restore_params["vanity_code"] = backup_data["vanity_url_code"]
                restored_items.append(f"vanity (discord.gg/{backup_data['vanity_url_code']})")
            
            if "name" in changes and backup_data.get("name"):
                restore_params["name"] = backup_data["name"]
                restored_items.append(f"name ({backup_data['name']})")
            
            if "icon" in changes and "icon" in backup_data:
                if backup_data["icon"]:
                    restore_params["icon"] = None
                restored_items.append("icon")
            
            if "banner" in changes and "banner" in backup_data:
                if backup_data["banner"]:
                    restore_params["banner"] = None
                restored_items.append("banner")
            
            if "description" in changes and backup_data.get("description"):
                restore_params["description"] = backup_data["description"]
                restored_items.append("description")
            
            if restore_params:
                await guild.edit(**restore_params, reason="SecureX: Restoring unauthorized guild changes")
                
                elapsed = (datetime.now() - start_time).total_seconds() * 1000
                items_str = ", ".join(restored_items)
                print(f"⚡ Restored guild settings in {elapsed:.0f}ms: {items_str}")
            
        except discord.errors.HTTPException as e:
            if e.code == 50035:
                print(f"⚠️ Some settings could not be restored: {e}")
            else:
                print(f"Error restoring guild settings: {e}")
        except Exception as e:
            print(f"Error in guild restoration: {e}")
