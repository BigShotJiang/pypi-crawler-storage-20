:orphan:

..
   This page is not included in the TOC tree, but must exist so that the
   autosummary pages are generated for scanspec and all its
   subpackages

API
===

.. autosummary::
    :toctree: _api
    :template: custom-module-template.rst
    :recursive:

    scanspec
