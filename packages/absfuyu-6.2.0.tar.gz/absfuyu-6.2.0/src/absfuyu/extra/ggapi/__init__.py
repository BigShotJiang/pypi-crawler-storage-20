"""
Absfuyu: Google related
-----------------------
Google API

Version: 6.2.0
Date updated: 30/12/2025 (dd/mm/yyyy)
"""
