"""
Absfuyu: Audio
--------------
Audio related

Version: 6.2.0
Date updated: 30/12/2025 (dd/mm/yyyy)
"""
