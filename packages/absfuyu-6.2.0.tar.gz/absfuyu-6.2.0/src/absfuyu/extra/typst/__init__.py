"""
Absfuyu: Typst
--------------
Typst related

Version: 6.2.0
Date updated: 17/01/2026 (dd/mm/yyyy)
"""
