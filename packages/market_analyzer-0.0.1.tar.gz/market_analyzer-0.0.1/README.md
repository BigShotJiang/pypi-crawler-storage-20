# 📊 Smart Money Concepts (SMC) & Stocks (Gaps, fib, S/R, chart_patterns) Analysis Toolkit

A high-performance Python toolkit for advanced stock market analysis, focusing on Smart Money Concepts (SMC) and stocks (Gaps, fib, S/R, chart_patterns) analysis.

## 🚀 Key Features

### 1. Smart Money Concepts (SMC) Analysis
- **Market Structure**           : Vectorized detection of Swing and Internal structure (BOS, CHoCH).
- **Supply & Demand**            : Identification of Order Blocks (OB) and Fair Value Gaps (FVG).
- **Liquidity**                  : Detection of Equal Highs and Equal Lows.
- **Screener**                   : A dedicated screener to find stocks currently trading near these institutional levels.

### 2. Stocks (Gaps, fib, S/R, chart_patterns) Analysis Suite
- **LTP Near Gaps**              : Finds stocks trading near unfilled or partially filled gaps.
- **Support & Resistance**       : Vectorized detection of high-probability S/R zones.
- **Fibonacci Levels**           : Automated Fibonacci retracement analysis.
- **Chart Patterns**             : Detects Head & Shoulders, Double Tops/Bottoms, Triangles, Flags, Pennants, and Wedges.
- **Candle & Gap Analysis**      : Deep dive into daily candle patterns and gap dynamics.

### 3. "Super Fast" Performance Architecture
- **Centralized Data Manager**   : Unified fetching via `yfinance` with robust retry logic.
- **Aggressive Cache Slicing**   : Automatically reuses larger period caches (e.g., `max`) to fulfill shorter period requests (e.g., `1y`, `1d`) instantly.
- **In-Memory Caching**          : Minimizes disk I/O by keeping dataframes in memory during execution.
- **Vectorized Logic**           : Most analysis modules use NumPy and Pandas vectorization for rapid processing of hundreds of stocks.

## 🛠 Installation

1. Install dependencies:
   ```bash
   pip install .
   ```

## 📈 Usage

### Run SMC Screener & Analysis
This is the primary entry point for Smart Money Concepts analysis. It provides an interactive menu to run Analysis, Screening, or Both.
```bash
python "SMC Screener.py"
```

### Run Multi-Indicator Analysis
Executes the full suite of other indicators (Gaps, S/R, Fibonacci, Patterns) in one go.
```bash
python run_analysis.py
```

## ⚙️ Configuration
- **Cache**                : Data is stored in `data_cache/` as `.pkl` files. Default expiry is 24 hours.
- **Output**               : Results are saved in `outputs/` and `analysis/` directories (CSV format).
- **Google Sheets**        : Supports syncing results to Google Sheets (requires `credentials.json` in `Credentials/`).

## 📁 Project Structure
- `SMC Screener.py`        : Interactive entry point for SMC pipeline.
- `run_analysis.py`        : Main runner for multi-indicator suite.
- `stock_analysis/`        : Core logic modules.
  - `stock_data_manager.py`: High-performance data & cache handler.
  - `smc_analysis.py`      : The SMC engine.
  - `chart_patterns.py`    : Pattern detection logic.
  - `support_resistance.py`: S/R zone detection.
- `data_cache/`            : Local repository for stock data.

---
*Note: This toolkit is for educational and research purposes. Always perform your own due diligence before trading.*
