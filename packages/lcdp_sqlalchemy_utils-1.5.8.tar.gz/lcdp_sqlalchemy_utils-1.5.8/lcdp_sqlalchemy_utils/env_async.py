import asyncio
from logging.config import fileConfig

from sqlalchemy import engine_from_config
from sqlalchemy import pool

from alembic import context
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import AsyncEngine

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)


async def run_migrations_offline(**kwargs):
    """Run migrations in 'offline' mode.

  This configures the context with just a URL
  and not an Engine, though an Engine is acceptable
  here as well.  By skipping the Engine creation
  we don't even need a DBAPI to be available.

  Calls to context.execute() here emit the given string to the
  script output.

  """
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        **kwargs
    )

    async with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection, **kwargs) -> None:
    # target_metadata = MetaData()
    context.configure(connection=connection, compare_type=True,  **kwargs)

    with context.begin_transaction():
        context.run_migrations()


async def run_migrations_online(db_url=None, **kwargs):
    """Run migrations in 'online' mode.

  In this scenario we need to create an Engine
  and associate a connection with the context.

  """
    alembic_config = config.get_section(config.config_ini_section)
    connectable = AsyncEngine(
        engine_from_config(
            alembic_config,
            url=db_url,
            prefix="sqlalchemy.",
            poolclass=pool.NullPool,
            future=True,
        )
    )

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations, **kwargs)
    await connectable.dispose()
