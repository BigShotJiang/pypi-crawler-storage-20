
from typing import Tuple

import jax.numpy as jnp
import jax.random as jr
import jax.scipy.special as jsp
from jaxtyping import Array, ArrayLike, Integer, PRNGKeyArray, Real, Scalar

import bayinx.ops as byo
from bayinx.core.distribution import Parameterization
from bayinx.core.node import Node
from bayinx.nodes import Observed


def _log_binom_coeff(n: ArrayLike, x: ArrayLike) -> Array:
    n, x = jnp.asarray(n), jnp.asarray(x)
    return jsp.gammaln(n + 1) - jsp.gammaln(x + 1) - jsp.gammaln(n - x + 1)


def _prob(
    x: Integer[ArrayLike, "..."],
    n: Integer[ArrayLike, "..."],
    q: Real[ArrayLike, "..."],
) -> Real[Array, "..."]:
    # Cast to Array
    x, n, q = jnp.asarray(x), jnp.asarray(n), jnp.asarray(q)

    return jnp.exp(_logprob(x, n, q))


def _logprob(
    x: Integer[ArrayLike, "..."],
    n: Integer[ArrayLike, "..."],
    q: Real[ArrayLike, "..."],
) -> Real[Array, "..."]:
    # Cast to Array
    k, n, q = jnp.asarray(x), jnp.asarray(n), jnp.asarray(q)

    return _log_binom_coeff(n, k) + k * jnp.log1p(- q) + (n - k) * jnp.log(q)


def _cdf(
    x: Integer[ArrayLike, "..."],
    n: Integer[ArrayLike, "..."],
    q: Real[ArrayLike, "..."],
) -> Real[Array, "..."]:
    # Cast to Array
    x, n, q = jnp.asarray(x), jnp.asarray(n), jnp.asarray(q)

    return jsp.betainc(n - x, x + 1, q)


def _logcdf(
    x: Integer[ArrayLike, "..."],
    n: Integer[ArrayLike, "..."],
    q: Real[ArrayLike, "..."],
) -> Real[Array, "..."]:
    # Cast to Array
    x, n, q = jnp.asarray(x), jnp.asarray(n), jnp.asarray(q)

    return jnp.log(_cdf(x, n, q))


def _ccdf(
    x: Integer[ArrayLike, "..."],
    n: Integer[ArrayLike, "..."],
    q: Real[ArrayLike, "..."],
) -> Real[Array, "..."]:
    # Cast to Array
    x, n, q = jnp.asarray(x), jnp.asarray(n), jnp.asarray(q)

    return jsp.betainc(x + 1, n - x, 1 - q)


def _logccdf(
    x: Integer[ArrayLike, "..."],
    n: Integer[ArrayLike, "..."],
    q: Real[ArrayLike, "..."],
) -> Real[Array, "..."]:
    # Cast to Array
    x, n, q = jnp.asarray(x), jnp.asarray(n), jnp.asarray(q)

    return jnp.log(_ccdf(x, n, q))


class ProbFailureBinomial(Parameterization):
    """
    A probability-of-failure parameterization of the Binomial distribution.
    """

    n: Node[Integer[Array, "..."]]
    q: Node[Real[Array, "..."]]

    def __init__(
        self,
        n: Integer[ArrayLike, "..."] | Node[Integer[Array, "..."]],
        q: Real[ArrayLike, "..."] | Node[Real[Array, "..."]]
    ):
        # Initialize number of trials
        if isinstance(n, Node):
            if isinstance(n.obj, ArrayLike):
                self.n = n # type: ignore
        else:
            self.n = Observed(jnp.asarray(n))

        # Initialize probability of success
        if isinstance(q, Node):
            if isinstance(q.obj, ArrayLike):
                self.q = q # type: ignore
        else:
            self.q = Observed(jnp.asarray(q))

    def logprob(self, x: ArrayLike) -> Scalar:
        # Extract parameters
        n = byo.obj(self.n)
        q = byo.obj(self.q)

        return _logprob(x, n, q)

    def sample(self, shape: Tuple[int, ...], key: PRNGKeyArray):
        # Extract parameters
        n = byo.obj(self.n)
        q = byo.obj(self.q)

        # Transform to probability of success
        p = 1.0 - q

        return jr.binomial(key, n, p, shape)
