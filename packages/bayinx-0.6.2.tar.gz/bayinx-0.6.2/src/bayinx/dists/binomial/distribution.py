from typing import Optional

from jaxtyping import Array, ArrayLike, Real

from bayinx.core.distribution import Distribution, Parameterization
from bayinx.core.node import Node

from .pars import (
    LogitProbFailureBinomial,
    LogitProbSuccessBinomial,
    ProbFailureBinomial,
    ProbSuccessBinomial,
)


class Binomial(Distribution):
    """
    A Binomial distribution.

    Parameters:
        n: Parameterizes a Binomial distribution by the total number of trials.
        p: Parameterizes a Binomial distribution by its probability of success.
        q: Parameterizes a Binomial distribution by its probability of failure.
        logit_p: Parameterizes a Binomial distribution by the logit probability of success.
        logit_q: Parameterizes a Binomial distribution by the logit probability of failure.
    """

    par: Parameterization


    def __init__(
        self,
        n: Optional[Real[ArrayLike, "..."] | Node[Real[Array, "..."]]] = None,
        p: Optional[Real[ArrayLike, "..."] | Node[Real[Array, "..."]]] = None,
        q: Optional[Real[ArrayLike, "..."] | Node[Real[Array, "..."]]] = None,
        logit_p: Optional[Real[ArrayLike, "..."] | Node[Real[Array, "..."]]] = None,
        logit_q: Optional[Real[ArrayLike, "..."] | Node[Real[Array, "..."]]] = None
    ):
        if n is not None and p is not None:
            self.par = ProbSuccessBinomial(n, p)
        elif n is not None and q is not None:
            self.par = ProbFailureBinomial(n, q)
        elif n is not None and logit_p is not None:
            self.par = LogitProbSuccessBinomial(n, logit_p)
        elif n is not None and logit_q is not None:
            self.par = LogitProbFailureBinomial(n, logit_q)
        else:
            raise TypeError(f"Expected n: {n} and at least one of p: {p}, q: {q} to be not None.")
