"""
Repository layer for DNS-AID Agent Directory.

Provides data access patterns for agents and domains, abstracting
SQLAlchemy queries behind a clean async interface.
"""

import secrets
from collections.abc import Sequence
from datetime import UTC, datetime

import structlog
from sqlalchemy import delete, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from dns_aid.directory.models import Agent, CrawlHistory, Domain

logger = structlog.get_logger(__name__)


class DomainRepository:
    """
    Repository for domain operations.

    Handles domain submission, verification, and management.
    """

    def __init__(self, session: AsyncSession):
        self.session = session

    async def get(self, domain: str) -> Domain | None:
        """Get a domain by name."""
        result = await self.session.execute(select(Domain).where(Domain.domain == domain))
        return result.scalar_one_or_none()

    async def get_verified(self, domain: str) -> Domain | None:
        """Get a verified domain by name."""
        result = await self.session.execute(
            select(Domain).where(Domain.domain == domain, Domain.verified == True)  # noqa: E712
        )
        return result.scalar_one_or_none()

    async def list_all(
        self,
        verified_only: bool = False,
        limit: int = 100,
        offset: int = 0,
    ) -> Sequence[Domain]:
        """List domains with optional filtering."""
        query = select(Domain)
        if verified_only:
            query = query.where(Domain.verified == True)  # noqa: E712
        query = query.order_by(Domain.submitted_at.desc()).limit(limit).offset(offset)
        result = await self.session.execute(query)
        return result.scalars().all()

    async def count(self, verified_only: bool = False) -> int:
        """Count domains."""
        query = select(func.count()).select_from(Domain)
        if verified_only:
            query = query.where(Domain.verified == True)  # noqa: E712
        result = await self.session.execute(query)
        return result.scalar_one()

    async def create(self, domain: str) -> Domain:
        """
        Create a new domain submission with verification token.

        The verification token should be published as a DNS TXT record
        at _dns-aid-verify.{domain} to prove ownership.
        """
        # Generate a secure verification token
        verification_token = secrets.token_urlsafe(32)

        domain_obj = Domain(
            domain=domain,
            verified=False,
            verification_token=verification_token,
            crawl_status="pending",
        )
        self.session.add(domain_obj)
        await self.session.flush()

        logger.info(
            "Domain submitted",
            domain=domain,
            verification_token=verification_token[:8] + "...",
        )
        return domain_obj

    async def verify(self, domain: str) -> Domain | None:
        """
        Mark a domain as verified.

        Should be called after DNS TXT verification succeeds.
        """
        result = await self.session.execute(
            update(Domain)
            .where(Domain.domain == domain)
            .values(
                verified=True,
                verified_at=datetime.now(UTC),
                crawl_status="pending",
            )
            .returning(Domain)
        )
        domain_obj = result.scalar_one_or_none()
        if domain_obj:
            logger.info("Domain verified", domain=domain)
        return domain_obj

    async def update_crawl_status(
        self,
        domain: str,
        status: str,
        agent_count: int | None = None,
    ) -> None:
        """Update the crawl status for a domain."""
        values: dict = {
            "crawl_status": status,
            "last_crawled": datetime.now(UTC),
        }
        if agent_count is not None:
            values["agent_count"] = agent_count

        await self.session.execute(update(Domain).where(Domain.domain == domain).values(**values))

    async def delete(self, domain: str) -> bool:
        """Delete a domain and all its agents."""
        result = await self.session.execute(delete(Domain).where(Domain.domain == domain))
        deleted = result.rowcount > 0  # type: ignore[attr-defined]
        if deleted:
            logger.info("Domain deleted", domain=domain)
        return deleted


class AgentRepository:
    """
    Repository for agent operations.

    Handles agent storage, retrieval, and search.
    """

    def __init__(self, session: AsyncSession):
        self.session = session

    async def get(self, fqdn: str) -> Agent | None:
        """Get an agent by FQDN."""
        result = await self.session.execute(select(Agent).where(Agent.fqdn == fqdn))
        return result.scalar_one_or_none()

    async def get_by_domain(
        self,
        domain: str,
        protocol: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Sequence[Agent]:
        """Get agents for a domain with optional protocol filter."""
        query = select(Agent).where(Agent.domain == domain)
        if protocol:
            query = query.where(Agent.protocol == protocol)
        query = query.order_by(Agent.security_score.desc()).limit(limit).offset(offset)
        result = await self.session.execute(query)
        return result.scalars().all()

    async def list_all(
        self,
        protocol: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Sequence[Agent]:
        """List all agents with optional protocol filter."""
        query = select(Agent)
        if protocol:
            query = query.where(Agent.protocol == protocol)
        query = query.order_by(Agent.popularity_score.desc()).limit(limit).offset(offset)
        result = await self.session.execute(query)
        return result.scalars().all()

    async def count(self, domain: str | None = None, protocol: str | None = None) -> int:
        """Count agents with optional filters."""
        query = select(func.count()).select_from(Agent)
        if domain:
            query = query.where(Agent.domain == domain)
        if protocol:
            query = query.where(Agent.protocol == protocol)
        result = await self.session.execute(query)
        return result.scalar_one()

    async def create(
        self,
        fqdn: str,
        domain: str,
        name: str,
        protocol: str,
        endpoint_url: str | None = None,
        port: int = 443,
        capabilities: list[str] | None = None,
        version: str | None = None,
        security_score: int = 0,
        metadata: dict | None = None,
    ) -> Agent:
        """Create a new agent."""
        agent = Agent(
            fqdn=fqdn,
            domain=domain,
            name=name,
            protocol=protocol,
            endpoint_url=endpoint_url,
            port=port,
            capabilities=capabilities,
            version=version,
            security_score=security_score,
            metadata_=metadata or {},
        )
        self.session.add(agent)
        await self.session.flush()

        logger.info("Agent created", fqdn=fqdn, name=name, protocol=protocol)
        return agent

    async def upsert(
        self,
        fqdn: str,
        domain: str,
        name: str,
        protocol: str,
        endpoint_url: str | None = None,
        port: int = 443,
        capabilities: list[str] | None = None,
        version: str | None = None,
        security_score: int = 0,
        metadata: dict | None = None,
    ) -> tuple[Agent, bool]:
        """
        Create or update an agent.

        Returns:
            Tuple of (agent, created) where created is True if new agent.
        """
        existing = await self.get(fqdn)
        if existing:
            # Update existing agent
            existing.endpoint_url = endpoint_url
            existing.port = port
            existing.capabilities = capabilities
            existing.version = version
            existing.security_score = security_score
            existing.last_seen = datetime.now(UTC)
            if metadata:
                existing.metadata_ = {**(existing.metadata_ or {}), **metadata}
            await self.session.flush()
            logger.debug("Agent updated", fqdn=fqdn)
            return existing, False
        else:
            # Create new agent
            agent = await self.create(
                fqdn=fqdn,
                domain=domain,
                name=name,
                protocol=protocol,
                endpoint_url=endpoint_url,
                port=port,
                capabilities=capabilities,
                version=version,
                security_score=security_score,
                metadata=metadata,
            )
            return agent, True

    async def update_scores(
        self,
        fqdn: str,
        security_score: int | None = None,
        trust_score: int | None = None,
        popularity_score: int | None = None,
    ) -> None:
        """Update scoring fields for an agent."""
        values: dict = {"last_verified": datetime.now(UTC)}
        if security_score is not None:
            values["security_score"] = security_score
        if trust_score is not None:
            values["trust_score"] = trust_score
        if popularity_score is not None:
            values["popularity_score"] = popularity_score

        await self.session.execute(update(Agent).where(Agent.fqdn == fqdn).values(**values))

    async def update_threat_flags(self, fqdn: str, threat_flags: dict) -> None:
        """Update threat flags for an agent."""
        await self.session.execute(
            update(Agent).where(Agent.fqdn == fqdn).values(threat_flags=threat_flags)
        )

    async def delete(self, fqdn: str) -> bool:
        """Delete an agent by FQDN."""
        result = await self.session.execute(delete(Agent).where(Agent.fqdn == fqdn))
        deleted = result.rowcount > 0  # type: ignore[attr-defined]
        if deleted:
            logger.info("Agent deleted", fqdn=fqdn)
        return deleted

    async def delete_by_domain(self, domain: str) -> int:
        """Delete all agents for a domain."""
        result = await self.session.execute(delete(Agent).where(Agent.domain == domain))
        count = result.rowcount  # type: ignore[attr-defined]
        logger.info("Agents deleted for domain", domain=domain, count=count)
        return count


class CrawlHistoryRepository:
    """
    Repository for crawl history operations.

    Tracks crawl attempts for auditing and debugging.
    """

    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, domain: str) -> CrawlHistory:
        """Start a new crawl record."""
        crawl = CrawlHistory(domain=domain, status="running")
        self.session.add(crawl)
        await self.session.flush()
        logger.info("Crawl started", domain=domain, crawl_id=crawl.id)
        return crawl

    async def complete(
        self,
        crawl_id: int,
        status: str = "completed",
        agents_found: int = 0,
        agents_added: int = 0,
        agents_updated: int = 0,
        error_message: str | None = None,
    ) -> None:
        """Mark a crawl as completed."""
        await self.session.execute(
            update(CrawlHistory)
            .where(CrawlHistory.id == crawl_id)
            .values(
                status=status,
                completed_at=datetime.now(UTC),
                agents_found=agents_found,
                agents_added=agents_added,
                agents_updated=agents_updated,
                error_message=error_message,
            )
        )
        logger.info(
            "Crawl completed",
            crawl_id=crawl_id,
            status=status,
            agents_found=agents_found,
        )

    async def get_recent(
        self, domain: str | None = None, limit: int = 10
    ) -> Sequence[CrawlHistory]:
        """Get recent crawl history."""
        query = select(CrawlHistory)
        if domain:
            query = query.where(CrawlHistory.domain == domain)
        query = query.order_by(CrawlHistory.started_at.desc()).limit(limit)
        result = await self.session.execute(query)
        return result.scalars().all()
