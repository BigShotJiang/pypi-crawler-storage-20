"""
Async database connection management for DNS-AID Agent Directory.

Provides connection pooling, session management, and database initialization
using SQLAlchemy 2.0 async patterns.

Supports both password-based and IAM authentication for AWS RDS.
"""

import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from urllib.parse import quote_plus

import structlog
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from dns_aid.directory.models import Base

logger = structlog.get_logger(__name__)


def get_rds_iam_auth_token(host: str, port: int, username: str, region: str) -> str:
    """
    Generate an IAM authentication token for RDS.

    Args:
        host: RDS endpoint hostname
        port: RDS port (usually 5432)
        username: Database username
        region: AWS region

    Returns:
        IAM auth token to use as password
    """
    try:
        import boto3

        client = boto3.client("rds", region_name=region)
        token = client.generate_db_auth_token(
            DBHostname=host,
            Port=port,
            DBUsername=username,
            Region=region,
        )
        logger.debug("Generated RDS IAM auth token", host=host, username=username)
        return token
    except Exception as e:
        logger.error("Failed to generate RDS IAM auth token", error=str(e))
        raise


def build_database_url_from_env() -> str:
    """
    Build database URL from environment variables.

    Supports IAM authentication when DB_USE_IAM_AUTH=true.

    Environment variables:
        DB_HOST: Database hostname
        DB_PORT: Database port (default: 5432)
        DB_NAME: Database name
        DB_USER: Database username
        DB_PASSWORD: Database password (not needed with IAM auth)
        DB_USE_IAM_AUTH: Set to "true" to use IAM auth
        AWS_REGION_NAME: AWS region (required for IAM auth)
    """
    host = os.getenv("DB_HOST")
    if not host:
        # Fall back to SQLite for local development
        return "sqlite+aiosqlite:///./dns_aid_directory.db"

    port = int(os.getenv("DB_PORT", "5432"))
    database = os.getenv("DB_NAME", "dns_aid")
    username = os.getenv("DB_USER", "dns_aid_admin")
    use_iam_auth = os.getenv("DB_USE_IAM_AUTH", "").lower() == "true"

    if use_iam_auth:
        # Generate IAM auth token
        region = os.getenv("AWS_REGION_NAME") or os.getenv("AWS_REGION", "eu-west-2")
        password = get_rds_iam_auth_token(host, port, username, region)
        logger.info("Using IAM authentication for RDS", host=host, username=username)
    else:
        password = os.getenv("DB_PASSWORD", "")
        if not password:
            logger.warning("No DB_PASSWORD set and IAM auth disabled")

    # URL-encode password (IAM tokens contain special characters)
    encoded_password = quote_plus(password)

    # Build PostgreSQL URL
    url = f"postgresql+asyncpg://{username}:{encoded_password}@{host}:{port}/{database}"

    return url


# Default database URL (SQLite for development/testing)
DEFAULT_DATABASE_URL = "sqlite+aiosqlite:///./dns_aid_directory.db"


class DatabaseManager:
    """
    Manages async database connections and sessions.

    Usage:
        db = DatabaseManager(database_url)
        await db.init()

        async with db.session() as session:
            # Use session for queries
            pass

        await db.close()
    """

    def __init__(self, database_url: str | None = None):
        """
        Initialize the database manager.

        Args:
            database_url: SQLAlchemy async database URL.
                         Defaults to built from env vars or SQLite.
        """
        if database_url:
            self.database_url = database_url
        elif os.getenv("DATABASE_URL"):
            self.database_url = os.getenv("DATABASE_URL", DEFAULT_DATABASE_URL)
        else:
            # Build from individual env vars (supports IAM auth)
            self.database_url = build_database_url_from_env()

        # Convert postgres:// to postgresql+asyncpg:// if needed
        if self.database_url.startswith("postgres://"):
            self.database_url = self.database_url.replace("postgres://", "postgresql+asyncpg://", 1)
        elif self.database_url.startswith("postgresql://"):
            self.database_url = self.database_url.replace(
                "postgresql://", "postgresql+asyncpg://", 1
            )

        self._engine: AsyncEngine | None = None
        self._session_factory: async_sessionmaker[AsyncSession] | None = None

    @property
    def engine(self) -> AsyncEngine:
        """Get the async engine, raising if not initialized."""
        if self._engine is None:
            raise RuntimeError("Database not initialized. Call init() first.")
        return self._engine

    @property
    def session_factory(self) -> async_sessionmaker[AsyncSession]:
        """Get the session factory, raising if not initialized."""
        if self._session_factory is None:
            raise RuntimeError("Database not initialized. Call init() first.")
        return self._session_factory

    async def init(self, create_tables: bool = True) -> None:
        """
        Initialize the database engine and optionally create tables.

        Args:
            create_tables: If True, create all tables defined in models.
        """
        logger.info("Initializing database", url=self._mask_url(self.database_url))

        # Configure engine based on database type
        if "sqlite" in self.database_url:
            # SQLite configuration
            self._engine = create_async_engine(
                self.database_url,
                echo=os.getenv("SQL_DEBUG", "").lower() == "true",
                connect_args={"check_same_thread": False},
            )
        else:
            # PostgreSQL configuration with connection pooling
            connect_args = {}
            use_iam_auth = os.getenv("DB_USE_IAM_AUTH", "").lower() == "true"

            # For IAM authentication with asyncpg, we need SSL
            if use_iam_auth:
                import ssl

                ssl_context = ssl.create_default_context()
                # Don't verify hostname for RDS (uses internal hostnames)
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE
                connect_args["ssl"] = ssl_context

            # For IAM auth, use NullPool to get fresh connections each time
            # IAM tokens expire after ~15 minutes, so we need fresh tokens
            pool_class = None
            if use_iam_auth:
                from sqlalchemy.pool import NullPool

                pool_class = NullPool
                logger.info("Using NullPool for IAM authentication (fresh token per connection)")

            engine_kwargs = {
                "echo": os.getenv("SQL_DEBUG", "").lower() == "true",
                "connect_args": connect_args,
            }

            if pool_class:
                engine_kwargs["poolclass"] = pool_class
            else:
                engine_kwargs.update(
                    {
                        "pool_size": int(os.getenv("DB_POOL_SIZE", "5")),
                        "max_overflow": int(os.getenv("DB_MAX_OVERFLOW", "10")),
                        "pool_timeout": int(os.getenv("DB_POOL_TIMEOUT", "30")),
                        "pool_recycle": int(os.getenv("DB_POOL_RECYCLE", "1800")),
                    }
                )

            self._engine = create_async_engine(self.database_url, **engine_kwargs)

        # Create session factory
        self._session_factory = async_sessionmaker(
            bind=self._engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False,
        )

        if create_tables:
            await self.create_tables()

        logger.info("Database initialized successfully")

    async def create_tables(self) -> None:
        """Create all tables defined in the models."""
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("Database tables created")

    async def drop_tables(self) -> None:
        """Drop all tables. Use with caution!"""
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
        logger.warning("Database tables dropped")

    async def close(self) -> None:
        """Close the database engine and release connections."""
        if self._engine:
            await self._engine.dispose()
            self._engine = None
            self._session_factory = None
            logger.info("Database connection closed")

    @asynccontextmanager
    async def session(self) -> AsyncGenerator[AsyncSession, None]:
        """
        Create a new async session context.

        Usage:
            async with db.session() as session:
                result = await session.execute(query)
        """
        session = self.session_factory()
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()

    def _mask_url(self, url: str) -> str:
        """Mask sensitive parts of the database URL for logging."""
        if "@" in url:
            # Mask password in URL
            parts = url.split("@")
            if ":" in parts[0]:
                proto_user = parts[0].rsplit(":", 1)[0]
                return f"{proto_user}:***@{parts[1]}"
        return url


# Global database manager instance (for FastAPI dependency injection)
_db_manager: DatabaseManager | None = None
_db_initialized: bool = False
_db_init_time: float = 0.0

# IAM tokens are valid for ~15 minutes, refresh after 10 minutes
IAM_TOKEN_REFRESH_SECONDS = 600


def get_database_manager() -> DatabaseManager:
    """Get the global database manager instance."""
    global _db_manager
    if _db_manager is None:
        _db_manager = DatabaseManager()
    return _db_manager


async def ensure_database_initialized() -> DatabaseManager:
    """
    Ensure database is initialized and return the manager.

    This supports Lambda where lifespan events don't run.
    For IAM auth, re-initializes if token might have expired.
    """
    import time

    global _db_manager, _db_initialized, _db_init_time

    use_iam_auth = os.getenv("DB_USE_IAM_AUTH", "").lower() == "true"
    current_time = time.time()

    # Check if we need to refresh the IAM token
    token_expired = (
        use_iam_auth
        and _db_initialized
        and (current_time - _db_init_time) > IAM_TOKEN_REFRESH_SECONDS
    )

    if token_expired:
        logger.info("IAM token may have expired, re-initializing database connection")
        if _db_manager:
            await _db_manager.close()
        _db_manager = None
        _db_initialized = False

    if _db_manager is None:
        _db_manager = DatabaseManager()

    if not _db_initialized:
        await _db_manager.init(create_tables=False)  # Tables created separately
        _db_initialized = True
        _db_init_time = current_time

    return _db_manager


def set_database_manager(manager: DatabaseManager) -> None:
    """Set the global database manager instance."""
    global _db_manager
    _db_manager = manager


async def init_database(database_url: str | None = None, create_tables: bool = True) -> None:
    """
    Initialize the global database manager.

    Args:
        database_url: Optional database URL. Defaults to DATABASE_URL env var.
        create_tables: If True, create tables on init.
    """
    global _db_manager
    _db_manager = DatabaseManager(database_url)
    await _db_manager.init(create_tables=create_tables)


async def close_database() -> None:
    """Close the global database manager."""
    global _db_manager
    if _db_manager:
        await _db_manager.close()
        _db_manager = None


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency for getting a database session.

    Auto-initializes database on first use (supports Lambda where lifespan is off).

    Usage in FastAPI:
        @app.get("/items")
        async def get_items(session: AsyncSession = Depends(get_db_session)):
            ...
    """
    db = await ensure_database_initialized()
    async with db.session() as session:
        yield session
