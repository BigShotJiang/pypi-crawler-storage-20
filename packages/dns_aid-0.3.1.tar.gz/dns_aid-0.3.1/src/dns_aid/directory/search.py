"""
Search engine for DNS-AID Agent Directory.

Provides full-text search capabilities for agents using PostgreSQL's
built-in full-text search or simple LIKE queries for SQLite.
"""

from dataclasses import dataclass

import structlog
from sqlalchemy import String, cast, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from dns_aid.directory.models import Agent, Domain

logger = structlog.get_logger(__name__)


@dataclass
class SearchResult:
    """A single search result with relevance score."""

    agent: Agent
    score: float
    highlights: dict[str, str] | None = None


@dataclass
class SearchResponse:
    """Search response with results and metadata."""

    query: str
    results: list[SearchResult]
    total: int
    limit: int
    offset: int

    @property
    def count(self) -> int:
        """Number of results returned."""
        return len(self.results)


class SearchEngine:
    """
    Full-text search engine for agents.

    Uses PostgreSQL's tsvector/tsquery for efficient full-text search,
    falling back to ILIKE for SQLite compatibility in development.
    """

    def __init__(self, session: AsyncSession):
        self.session = session

    async def search(
        self,
        query: str,
        protocol: str | None = None,
        domain: str | None = None,
        capabilities: list[str] | None = None,
        min_security_score: int | None = None,
        verified_only: bool = True,
        limit: int = 20,
        offset: int = 0,
    ) -> SearchResponse:
        """
        Search for agents matching the query.

        Args:
            query: Search query (searches name, capabilities, domain).
            protocol: Filter by protocol (mcp, a2a, https).
            domain: Filter by domain.
            capabilities: Filter by required capabilities.
            min_security_score: Minimum security score filter.
            verified_only: Only return agents from verified domains.
            limit: Maximum results to return.
            offset: Pagination offset.

        Returns:
            SearchResponse with matching agents.
        """
        logger.info(
            "Searching agents",
            query=query,
            protocol=protocol,
            domain=domain,
            limit=limit,
        )

        # Build base query
        stmt = select(Agent)

        # Join with Domain for verified filter
        if verified_only:
            stmt = stmt.join(Domain, Agent.domain == Domain.domain).where(
                Domain.verified == True  # noqa: E712
            )

        # Apply filters
        conditions = []

        # Text search on name, capabilities, domain
        if query:
            search_term = f"%{query.lower()}%"
            conditions.append(
                or_(
                    func.lower(Agent.name).like(search_term),
                    func.lower(Agent.domain).like(search_term),
                    func.lower(cast(Agent.capabilities, String)).like(search_term),
                )
            )

        if protocol:
            conditions.append(Agent.protocol == protocol)

        if domain:
            conditions.append(Agent.domain == domain)

        if capabilities:
            # Agent must have ALL requested capabilities
            for cap in capabilities:
                conditions.append(Agent.capabilities.contains([cap]))

        if min_security_score is not None:
            conditions.append(Agent.security_score >= min_security_score)

        if conditions:
            stmt = stmt.where(*conditions)

        # Get total count before pagination
        count_stmt = select(func.count()).select_from(stmt.subquery())
        total_result = await self.session.execute(count_stmt)
        total = total_result.scalar_one()

        # Apply ordering and pagination
        stmt = (
            stmt.order_by(
                Agent.popularity_score.desc(),
                Agent.security_score.desc(),
                Agent.last_seen.desc(),
            )
            .limit(limit)
            .offset(offset)
        )

        # Execute query
        result = await self.session.execute(stmt)
        agents = result.scalars().all()

        # Build search results with scores
        results = []
        for agent in agents:
            # Calculate a simple relevance score based on various factors
            score = self._calculate_relevance(agent, query)
            results.append(SearchResult(agent=agent, score=score))

        # Sort by score
        results.sort(key=lambda r: r.score, reverse=True)

        logger.info(
            "Search complete",
            query=query,
            total=total,
            returned=len(results),
        )

        return SearchResponse(
            query=query,
            results=results,
            total=total,
            limit=limit,
            offset=offset,
        )

    def _calculate_relevance(self, agent: Agent, query: str) -> float:
        """
        Calculate relevance score for an agent.

        Combines multiple factors:
        - Name match (highest weight)
        - Capability match
        - Popularity score
        - Security score
        """
        score = 0.0
        query_lower = query.lower() if query else ""

        # Name match (0-40 points)
        if query_lower:
            if agent.name.lower() == query_lower:
                score += 40  # Exact match
            elif query_lower in agent.name.lower():
                score += 25  # Partial match
            elif agent.name.lower() in query_lower:
                score += 15  # Reverse partial

        # Capability match (0-20 points)
        if query_lower and agent.capabilities:
            caps_lower = [c.lower() for c in agent.capabilities]
            if query_lower in caps_lower:
                score += 20  # Exact capability match
            elif any(query_lower in c for c in caps_lower):
                score += 10  # Partial capability match

        # Popularity score (0-20 points)
        score += (agent.popularity_score or 0) * 0.2

        # Security score (0-20 points)
        score += (agent.security_score or 0) * 0.2

        return round(score, 2)

    async def get_suggestions(
        self,
        prefix: str,
        limit: int = 10,
    ) -> list[str]:
        """
        Get search suggestions based on prefix.

        Returns agent names that start with the given prefix.
        """
        stmt = (
            select(Agent.name)
            .where(func.lower(Agent.name).like(f"{prefix.lower()}%"))
            .distinct()
            .limit(limit)
        )
        result = await self.session.execute(stmt)
        return [row[0] for row in result.fetchall()]

    async def get_popular_capabilities(self, limit: int = 20) -> list[tuple[str, int]]:
        """
        Get the most common capabilities across all agents.

        Returns list of (capability, count) tuples.
        """
        # This requires unnesting the capabilities array
        # Works with PostgreSQL, approximate with SQLite
        stmt = (
            select(func.unnest(Agent.capabilities).label("cap"), func.count().label("cnt"))
            .group_by("cap")
            .order_by(func.count().desc())
            .limit(limit)
        )

        try:
            result = await self.session.execute(stmt)
            return [(row.cap, row.cnt) for row in result.fetchall()]
        except Exception:
            # Fallback for SQLite (no unnest support)
            logger.debug("Capability aggregation not supported on this database")
            return []

    async def get_stats(self) -> dict:
        """
        Get search index statistics.

        Returns counts of agents, domains, protocols, etc.
        """
        # Total agents
        agents_result = await self.session.execute(select(func.count()).select_from(Agent))
        total_agents = agents_result.scalar_one()

        # Total domains
        domains_result = await self.session.execute(select(func.count()).select_from(Domain))
        total_domains = domains_result.scalar_one()

        # Verified domains
        verified_result = await self.session.execute(
            select(func.count()).select_from(Domain).where(Domain.verified == True)  # noqa: E712
        )
        verified_domains = verified_result.scalar_one()

        # Agents by protocol
        protocol_result = await self.session.execute(
            select(Agent.protocol, func.count()).group_by(Agent.protocol)
        )
        agents_by_protocol = {row[0]: row[1] for row in protocol_result.fetchall()}

        return {
            "total_agents": total_agents,
            "total_domains": total_domains,
            "verified_domains": verified_domains,
            "agents_by_protocol": agents_by_protocol,
        }
