"""
DNS-AID Agent Directory - Database and Repository Layer

This module provides the data persistence layer for the DNS-AID Agent Directory,
enabling storage and retrieval of discovered agents, domains, and crawl history.
"""

from dns_aid.directory.database import (
    DatabaseManager,
    get_db_session,
    init_database,
)
from dns_aid.directory.models import Agent, CrawlHistory, Domain
from dns_aid.directory.repository import AgentRepository, DomainRepository
from dns_aid.directory.search import SearchEngine

__all__ = [
    # Database
    "DatabaseManager",
    "get_db_session",
    "init_database",
    # Models
    "Agent",
    "Domain",
    "CrawlHistory",
    # Repository
    "AgentRepository",
    "DomainRepository",
    # Search
    "SearchEngine",
]
