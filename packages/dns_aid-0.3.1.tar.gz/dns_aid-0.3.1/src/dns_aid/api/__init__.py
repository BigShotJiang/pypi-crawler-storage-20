"""
DNS-AID Agent Directory API

FastAPI-based REST API for the DNS-AID Agent Directory service.
Provides endpoints for domain submission, agent search, and verification.
"""

from dns_aid.api.app import create_app

__all__ = ["create_app"]
