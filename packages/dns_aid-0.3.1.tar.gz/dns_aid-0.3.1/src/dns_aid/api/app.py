"""
FastAPI application for DNS-AID Agent Directory.

Main entry point for the Agent Directory API service.
"""

import time
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

import structlog
import uvicorn
from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from dns_aid import __version__
from dns_aid.api.schemas import ErrorResponse, ValidationErrorResponse
from dns_aid.directory.database import close_database, init_database

logger = structlog.get_logger(__name__)

# Track startup time for uptime calculation
_start_time: float = 0.0


def get_uptime() -> float:
    """Get server uptime in seconds."""
    return time.time() - _start_time


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Application lifespan manager.

    Handles startup and shutdown tasks like database initialization.
    """
    global _start_time
    _start_time = time.time()

    logger.info("Starting DNS-AID Agent Directory API", version=__version__)

    # Initialize database
    await init_database()
    logger.info("Database initialized")

    yield

    # Cleanup
    await close_database()
    logger.info("DNS-AID Agent Directory API shutdown complete")


def create_app() -> FastAPI:
    """
    Create and configure the FastAPI application.

    Returns:
        Configured FastAPI application instance.
    """
    app = FastAPI(
        title="DNS-AID Agent Directory",
        description=(
            "REST API for the DNS-AID Agent Directory - discover and manage "
            "AI agents published via DNS. Part of the DNS-based Agent Identification "
            "and Discovery (DNS-AID) reference implementation."
        ),
        version=__version__,
        docs_url="/api/v1/docs",
        redoc_url="/api/v1/redoc",
        openapi_url="/api/v1/openapi.json",
        lifespan=lifespan,
    )

    # Configure CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure appropriately for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Register exception handlers
    _register_exception_handlers(app)

    # Register routes
    _register_routes(app)

    # Add request logging middleware
    @app.middleware("http")
    async def log_requests(request: Request, call_next: Any) -> Any:
        start = time.time()
        response = await call_next(request)
        duration_ms = (time.time() - start) * 1000

        logger.info(
            "Request processed",
            method=request.method,
            path=request.url.path,
            status=response.status_code,
            duration_ms=round(duration_ms, 2),
        )
        return response

    return app


def _register_exception_handlers(app: FastAPI) -> None:
    """Register custom exception handlers."""

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        """Handle Pydantic validation errors."""
        errors = []
        for error in exc.errors():
            errors.append(
                {
                    "field": ".".join(str(loc) for loc in error["loc"]),
                    "message": error["msg"],
                    "type": error["type"],
                }
            )

        response = ValidationErrorResponse(errors=errors)
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content=response.model_dump(),
        )

    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        """Handle unexpected exceptions."""
        logger.exception("Unexpected error", exc_info=exc)
        response = ErrorResponse(
            code="DNS_AID_500",
            message="Internal server error",
        )
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=response.model_dump(),
        )


def _register_routes(app: FastAPI) -> None:
    """Register API routes."""
    from dns_aid.api.routes import agents, domains, health, search

    # Health routes (no prefix)
    app.include_router(health.router, tags=["Health"])

    # API v1 routes
    app.include_router(domains.router, prefix="/api/v1", tags=["Domains"])
    app.include_router(agents.router, prefix="/api/v1", tags=["Agents"])
    app.include_router(search.router, prefix="/api/v1", tags=["Search"])


# Create app instance for uvicorn
app = create_app()


def main() -> None:
    """Run the API server."""
    import os

    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8080"))
    reload = os.getenv("RELOAD", "").lower() == "true"

    logger.info("Starting server", host=host, port=port, reload=reload)

    uvicorn.run(
        "dns_aid.api.app:app",
        host=host,
        port=port,
        reload=reload,
    )


if __name__ == "__main__":
    main()
