"""
Agent endpoints for DNS-AID Agent Directory API.
"""

import structlog
from fastapi import APIRouter, HTTPException, Query, status

from dns_aid.api.dependencies import AgentRepo, DomainRepo
from dns_aid.api.schemas import AgentListResponse, AgentResponse, ErrorResponse

logger = structlog.get_logger(__name__)

router = APIRouter()


@router.get(
    "/agents/{fqdn:path}",
    response_model=AgentResponse,
    summary="Get agent details",
    description="Get detailed information about a specific agent by its FQDN.",
    responses={
        404: {"model": ErrorResponse, "description": "Agent not found"},
    },
)
async def get_agent(
    fqdn: str,
    repo: AgentRepo,
) -> AgentResponse:
    """
    Get agent details by FQDN.

    The FQDN should be the full DNS-AID agent name, e.g.:
    _chat._mcp._agents.example.com
    """
    agent = await repo.get(fqdn.lower())
    if not agent:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "DNS_AID_002",
                "message": f"Agent {fqdn} not found in directory",
            },
        )

    return AgentResponse(
        fqdn=agent.fqdn,
        domain=agent.domain,
        name=agent.name,
        protocol=agent.protocol,
        endpoint_url=agent.endpoint_url,
        port=agent.port,
        capabilities=agent.capabilities,
        version=agent.version,
        security_score=agent.security_score,
        trust_score=agent.trust_score,
        popularity_score=agent.popularity_score,
        threat_flags=agent.threat_flags,
        first_seen=agent.first_seen,
        last_seen=agent.last_seen,
        last_verified=agent.last_verified,
    )


@router.get(
    "/agents",
    response_model=AgentListResponse,
    summary="List agents",
    description="List agents with optional filtering by domain or protocol.",
)
async def list_agents(
    repo: AgentRepo,
    domain: str | None = Query(None, description="Filter by domain"),
    protocol: str | None = Query(None, description="Filter by protocol (mcp, a2a, https)"),
    limit: int = Query(20, ge=1, le=100, description="Maximum results"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
) -> AgentListResponse:
    """
    List agents with optional filters.

    Returns a paginated list of agents, optionally filtered by domain or protocol.
    """
    if domain:
        agents = await repo.get_by_domain(
            domain=domain.lower(),
            protocol=protocol,
            limit=limit,
            offset=offset,
        )
        total = await repo.count(domain=domain.lower(), protocol=protocol)
    else:
        agents = await repo.list_all(
            protocol=protocol,
            limit=limit,
            offset=offset,
        )
        total = await repo.count(protocol=protocol)

    return AgentListResponse(
        agents=[
            AgentResponse(
                fqdn=a.fqdn,
                domain=a.domain,
                name=a.name,
                protocol=a.protocol,
                endpoint_url=a.endpoint_url,
                port=a.port,
                capabilities=a.capabilities,
                version=a.version,
                security_score=a.security_score,
                trust_score=a.trust_score,
                popularity_score=a.popularity_score,
                threat_flags=a.threat_flags,
                first_seen=a.first_seen,
                last_seen=a.last_seen,
                last_verified=a.last_verified,
            )
            for a in agents
        ],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.get(
    "/domains/{domain}/agents",
    response_model=AgentListResponse,
    summary="List agents for domain",
    description="List all agents for a specific domain.",
    responses={
        404: {"model": ErrorResponse, "description": "Domain not found"},
    },
)
async def list_domain_agents(
    domain: str,
    agent_repo: AgentRepo,
    domain_repo: DomainRepo,
    protocol: str | None = Query(None, description="Filter by protocol"),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
) -> AgentListResponse:
    """
    List agents for a specific domain.

    Only returns agents for verified domains.
    """
    # Check domain exists and is verified
    domain_obj = await domain_repo.get_verified(domain.lower())
    if not domain_obj:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "DNS_AID_002",
                "message": f"Domain {domain} not found or not verified",
            },
        )

    agents = await agent_repo.get_by_domain(
        domain=domain.lower(),
        protocol=protocol,
        limit=limit,
        offset=offset,
    )
    total = await agent_repo.count(domain=domain.lower(), protocol=protocol)

    return AgentListResponse(
        agents=[
            AgentResponse(
                fqdn=a.fqdn,
                domain=a.domain,
                name=a.name,
                protocol=a.protocol,
                endpoint_url=a.endpoint_url,
                port=a.port,
                capabilities=a.capabilities,
                version=a.version,
                security_score=a.security_score,
                trust_score=a.trust_score,
                popularity_score=a.popularity_score,
                threat_flags=a.threat_flags,
                first_seen=a.first_seen,
                last_seen=a.last_seen,
                last_verified=a.last_verified,
            )
            for a in agents
        ],
        total=total,
        limit=limit,
        offset=offset,
    )


@router.delete(
    "/agents/{fqdn:path}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete agent",
    description="Delete an agent from the directory.",
    responses={
        404: {"model": ErrorResponse, "description": "Agent not found"},
    },
)
async def delete_agent(
    fqdn: str,
    repo: AgentRepo,
) -> None:
    """
    Delete an agent by FQDN.

    This removes the agent from the directory index.
    The DNS records are not affected.
    """
    deleted = await repo.delete(fqdn.lower())
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "DNS_AID_002",
                "message": f"Agent {fqdn} not found",
            },
        )

    logger.info("Agent deleted", fqdn=fqdn)
