"""
Health check endpoints for DNS-AID Agent Directory API.
"""

import structlog
from fastapi import APIRouter, status
from fastapi.responses import JSONResponse
from sqlalchemy import text

from dns_aid import __version__
from dns_aid.api.app import get_uptime
from dns_aid.api.dependencies import Search
from dns_aid.api.schemas import HealthResponse, StatsResponse
from dns_aid.directory.database import ensure_database_initialized

logger = structlog.get_logger(__name__)

router = APIRouter()


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Health check",
    description="Check the health status of the API and its dependencies.",
)
async def health_check() -> HealthResponse:
    """
    Health check endpoint.

    Returns the service status, version, and database connection status.
    """
    # Check database connection (auto-initializes if needed for Lambda)
    db_status = "unknown"
    try:
        db = await ensure_database_initialized()
        async with db.session() as session:
            await session.execute(text("SELECT 1"))
        db_status = "connected"
    except Exception as e:
        logger.warning("Database health check failed", error=str(e))
        db_status = "disconnected"

    service_status = "healthy" if db_status == "connected" else "degraded"

    return HealthResponse(
        status=service_status,
        version=__version__,
        database=db_status,
        uptime_seconds=round(get_uptime(), 2),
    )


@router.get(
    "/ready",
    summary="Readiness check",
    description="Check if the service is ready to accept traffic.",
)
async def readiness_check() -> JSONResponse:
    """
    Readiness check for container orchestration.

    Returns 200 if ready, 503 if not ready.
    """
    try:
        db = await ensure_database_initialized()
        async with db.session() as session:
            await session.execute(text("SELECT 1"))
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={"ready": True},
        )
    except Exception as e:
        logger.warning("Readiness check failed", error=str(e))
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content={"ready": False, "reason": "Database not available"},
        )


@router.get(
    "/",
    summary="Root endpoint",
    description="Basic service information.",
)
async def root() -> dict:
    """Root endpoint with service information."""
    return {
        "service": "DNS-AID Agent Directory",
        "version": __version__,
        "docs": "/api/v1/docs",
        "health": "/health",
    }


@router.get(
    "/api/v1/stats",
    response_model=StatsResponse,
    summary="Directory statistics",
    description="Get statistics about the agent directory.",
)
async def get_stats(search: Search) -> StatsResponse:
    """
    Get directory statistics.

    Returns counts of agents, domains, and breakdown by protocol.
    """
    stats = await search.get_stats()
    return StatsResponse(**stats)
