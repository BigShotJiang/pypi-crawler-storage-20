"""
Search endpoints for DNS-AID Agent Directory API.
"""

import structlog
from fastapi import APIRouter, Query

from dns_aid.api.dependencies import Search
from dns_aid.api.schemas import AgentResponse, SearchResponse, SearchResultItem

logger = structlog.get_logger(__name__)

router = APIRouter()


@router.get(
    "/search",
    response_model=SearchResponse,
    summary="Search agents",
    description="Search for agents by name, capabilities, or domain.",
)
async def search_agents(  # noqa: B008
    search: Search,
    q: str = Query(..., min_length=1, max_length=100, description="Search query"),
    protocol: str | None = Query(None, description="Filter by protocol (mcp, a2a, https)"),
    domain: str | None = Query(None, description="Filter by domain"),
    capabilities: list[str] | None = Query(None, description="Required capabilities"),  # noqa: B008
    min_security_score: int | None = Query(
        None, ge=0, le=100, description="Minimum security score"
    ),
    verified_only: bool = Query(
        False,
        description="Only return agents from verified domains (via DNS TXT challenge). "
        "Crawler-discovered agents are from DNS-published records which is inherent verification.",
    ),
    limit: int = Query(20, ge=1, le=100, description="Maximum results"),
    offset: int = Query(0, ge=0, description="Pagination offset"),
) -> SearchResponse:
    """
    Search for agents.

    Searches across agent names, capabilities, and domains.
    Results are ranked by relevance, popularity, and security score.
    """
    result = await search.search(
        query=q,
        protocol=protocol,
        domain=domain.lower() if domain else None,
        capabilities=capabilities,
        min_security_score=min_security_score,
        verified_only=verified_only,
        limit=limit,
        offset=offset,
    )

    return SearchResponse(
        query=result.query,
        results=[
            SearchResultItem(
                agent=AgentResponse(
                    fqdn=r.agent.fqdn,
                    domain=r.agent.domain,
                    name=r.agent.name,
                    protocol=r.agent.protocol,
                    endpoint_url=r.agent.endpoint_url,
                    port=r.agent.port,
                    capabilities=r.agent.capabilities,
                    version=r.agent.version,
                    security_score=r.agent.security_score,
                    trust_score=r.agent.trust_score,
                    popularity_score=r.agent.popularity_score,
                    threat_flags=r.agent.threat_flags,
                    first_seen=r.agent.first_seen,
                    last_seen=r.agent.last_seen,
                    last_verified=r.agent.last_verified,
                ),
                score=r.score,
            )
            for r in result.results
        ],
        total=result.total,
        limit=result.limit,
        offset=result.offset,
    )


@router.get(
    "/search/suggestions",
    summary="Get search suggestions",
    description="Get autocomplete suggestions for a search prefix.",
)
async def get_suggestions(
    search: Search,
    prefix: str = Query(..., min_length=1, max_length=50, description="Search prefix"),
    limit: int = Query(10, ge=1, le=20, description="Maximum suggestions"),
) -> list[str]:
    """
    Get search suggestions.

    Returns agent names that match the given prefix for autocomplete.
    """
    return await search.get_suggestions(prefix=prefix, limit=limit)


@router.get(
    "/search/capabilities",
    summary="Get popular capabilities",
    description="Get the most common capabilities across all agents.",
)
async def get_popular_capabilities(
    search: Search,
    limit: int = Query(20, ge=1, le=50, description="Maximum capabilities"),
) -> list[dict]:
    """
    Get popular capabilities.

    Returns the most common capabilities with their counts.
    Useful for filtering UI and discovery.
    """
    caps = await search.get_popular_capabilities(limit=limit)
    return [{"capability": cap, "count": count} for cap, count in caps]
