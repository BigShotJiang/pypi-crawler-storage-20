"""
API routes for DNS-AID Agent Directory.
"""

from dns_aid.api.routes import agents, domains, health, search

__all__ = ["agents", "domains", "health", "search"]
