"""
Domain management endpoints for DNS-AID Agent Directory API.
"""

import dns.resolver
import structlog
from fastapi import APIRouter, HTTPException, status

from dns_aid.api.dependencies import AgentRepo, CrawlHistoryRepo, DomainRepo
from dns_aid.api.schemas import (
    DomainCrawlResponse,
    DomainResponse,
    DomainSubmitRequest,
    DomainSubmitResponse,
    DomainVerifyRequest,
    DomainVerifyResponse,
    ErrorResponse,
)
from dns_aid.crawlers.submission import SubmissionCrawler

logger = structlog.get_logger(__name__)

router = APIRouter()


@router.post(
    "/domains/submit",
    response_model=DomainSubmitResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Submit domain for indexing",
    description="Submit a domain to be indexed by the DNS-AID directory.",
    responses={
        409: {"model": ErrorResponse, "description": "Domain already submitted"},
    },
)
async def submit_domain(
    request: DomainSubmitRequest,
    repo: DomainRepo,
) -> DomainSubmitResponse:
    """
    Submit a domain for indexing.

    After submission, the domain owner must verify ownership by publishing
    a DNS TXT record with the verification token.
    """
    # Check if domain already exists
    existing = await repo.get(request.domain)
    if existing:
        if existing.verified:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "code": "DNS_AID_409",
                    "message": f"Domain {request.domain} is already verified",
                },
            )
        else:
            # Return existing verification token
            return DomainSubmitResponse(
                domain=existing.domain,
                verification_token=existing.verification_token or "",
                verification_record=f'_dns-aid-verify.{existing.domain}. TXT "{existing.verification_token}"',
                instructions=(
                    f"Domain {request.domain} is pending verification. "
                    f"Create the DNS TXT record shown above, then call POST /api/v1/domains/verify"
                ),
            )

    # Create new domain submission
    domain = await repo.create(request.domain)

    logger.info("Domain submitted", domain=request.domain)

    return DomainSubmitResponse(
        domain=domain.domain,
        verification_token=domain.verification_token or "",
        verification_record=f'_dns-aid-verify.{domain.domain}. TXT "{domain.verification_token}"',
        instructions=(
            f"To verify ownership of {domain.domain}, create the DNS TXT record shown above. "
            f"Then call POST /api/v1/domains/verify with your domain."
        ),
    )


@router.post(
    "/domains/verify",
    response_model=DomainVerifyResponse,
    summary="Verify domain ownership",
    description="Verify domain ownership by checking the DNS TXT record.",
    responses={
        404: {"model": ErrorResponse, "description": "Domain not submitted"},
        400: {"model": ErrorResponse, "description": "Verification failed"},
    },
)
async def verify_domain(
    request: DomainVerifyRequest,
    repo: DomainRepo,
) -> DomainVerifyResponse:
    """
    Verify domain ownership.

    Checks for the verification TXT record at _dns-aid-verify.{domain}
    and marks the domain as verified if found with correct token.
    """
    # Get domain
    domain = await repo.get(request.domain)
    if not domain:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "DNS_AID_001",
                "message": f"Domain {request.domain} not found. Submit it first.",
            },
        )

    # Already verified?
    if domain.verified:
        return DomainVerifyResponse(
            domain=domain.domain,
            verified=True,
            message="Domain is already verified",
        )

    # Check DNS TXT record
    verification_fqdn = f"_dns-aid-verify.{request.domain}"
    expected_token = domain.verification_token

    try:
        answers = dns.resolver.resolve(verification_fqdn, "TXT")
        txt_records = []
        for rdata in answers:
            for txt_string in rdata.strings:
                txt_records.append(txt_string.decode("utf-8"))

        # Check if any TXT record matches the expected token
        if expected_token in txt_records:
            # Mark domain as verified
            await repo.verify(request.domain)

            logger.info("Domain verified", domain=request.domain)

            return DomainVerifyResponse(
                domain=request.domain,
                verified=True,
                message="Domain verified successfully! Your agents will now be indexed.",
            )
        else:
            logger.warning(
                "Verification token mismatch",
                domain=request.domain,
                expected=expected_token[:8] + "...",
                found=txt_records,
            )
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "code": "DNS_AID_001",
                    "message": (
                        f"Verification failed. Expected token not found in TXT records. "
                        f'Create: {verification_fqdn} TXT "{expected_token}"'
                    ),
                },
            )

    except dns.resolver.NXDOMAIN:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "DNS_AID_001",
                "message": f"Verification TXT record not found at {verification_fqdn}",
            },
        ) from None
    except dns.resolver.NoAnswer:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "DNS_AID_001",
                "message": f"No TXT record found at {verification_fqdn}",
            },
        ) from None
    except dns.resolver.Timeout:
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail={
                "code": "DNS_AID_006",
                "message": "DNS query timed out. Please try again.",
            },
        ) from None


@router.get(
    "/domains/{domain}",
    response_model=DomainResponse,
    summary="Get domain information",
    description="Get information about a submitted domain.",
    responses={
        404: {"model": ErrorResponse, "description": "Domain not found"},
    },
)
async def get_domain(
    domain: str,
    repo: DomainRepo,
) -> DomainResponse:
    """Get information about a domain."""
    domain_obj = await repo.get(domain.lower())
    if not domain_obj:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "DNS_AID_002",
                "message": f"Domain {domain} not found",
            },
        )

    return DomainResponse(
        domain=domain_obj.domain,
        verified=domain_obj.verified,
        verification_token=domain_obj.verification_token if not domain_obj.verified else None,
        submitted_at=domain_obj.submitted_at,
        verified_at=domain_obj.verified_at,
        last_crawled=domain_obj.last_crawled,
        crawl_status=domain_obj.crawl_status,
        agent_count=domain_obj.agent_count,
    )


@router.delete(
    "/domains/{domain}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete domain",
    description="Delete a domain and all its agents from the directory.",
    responses={
        404: {"model": ErrorResponse, "description": "Domain not found"},
    },
)
async def delete_domain(
    domain: str,
    repo: DomainRepo,
) -> None:
    """Delete a domain and all its agents."""
    deleted = await repo.delete(domain.lower())
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "DNS_AID_002",
                "message": f"Domain {domain} not found",
            },
        )

    logger.info("Domain deleted", domain=domain)


@router.post(
    "/domains/{domain}/crawl",
    response_model=DomainCrawlResponse,
    summary="Crawl domain for agents",
    description="Trigger a crawl of a verified domain to discover and index DNS-AID agents.",
    responses={
        404: {"model": ErrorResponse, "description": "Domain not found"},
        400: {"model": ErrorResponse, "description": "Domain not verified"},
    },
)
async def crawl_domain(
    domain: str,
    domain_repo: DomainRepo,
    agent_repo: AgentRepo,
    crawl_history_repo: CrawlHistoryRepo,
) -> DomainCrawlResponse:
    """
    Crawl a verified domain for DNS-AID agents.

    Discovers agents published via DNS SVCB/TXT records and indexes them
    in the directory. Only verified domains can be crawled.
    """
    domain = domain.lower()

    # Check if domain exists
    domain_obj = await domain_repo.get(domain)
    if not domain_obj:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "code": "DNS_AID_002",
                "message": f"Domain {domain} not found. Submit it first.",
            },
        )

    # Check if domain is verified
    if not domain_obj.verified:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "code": "DNS_AID_001",
                "message": f"Domain {domain} is not verified. Verify it first.",
            },
        )

    # Start crawl history record
    crawl = await crawl_history_repo.create(domain)

    try:
        # Update domain status to crawling
        await domain_repo.update_crawl_status(domain, "crawling")

        # Run the submission crawler
        crawler = SubmissionCrawler()
        result = await crawler.crawl(domain)

        agents_added = 0
        agents_updated = 0

        # Save discovered agents to database
        for agent in result.agents_found:
            _, created = await agent_repo.upsert(
                fqdn=agent.fqdn,
                domain=agent.domain,
                name=agent.name,
                protocol=agent.protocol,
                endpoint_url=agent.endpoint_url,
                port=agent.port,
                capabilities=agent.capabilities,
                version=agent.version,
                security_score=agent.security_score,
                metadata=agent.metadata,
            )
            if created:
                agents_added += 1
            else:
                agents_updated += 1

        # Complete crawl history
        await crawl_history_repo.complete(
            crawl_id=crawl.id,
            status=result.status,
            agents_found=len(result.agents_found),
            agents_added=agents_added,
            agents_updated=agents_updated,
            error_message=result.error_message,
        )

        # Update domain crawl status and agent count
        agent_count = await agent_repo.count(domain=domain)
        await domain_repo.update_crawl_status(domain, result.status, agent_count)

        logger.info(
            "Domain crawl completed",
            domain=domain,
            status=result.status,
            agents_found=len(result.agents_found),
            agents_added=agents_added,
            agents_updated=agents_updated,
        )

        return DomainCrawlResponse(
            domain=domain,
            status=result.status,
            agents_found=len(result.agents_found),
            agents_added=agents_added,
            agents_updated=agents_updated,
            message=(
                f"Crawl completed. Found {len(result.agents_found)} agents "
                f"({agents_added} new, {agents_updated} updated)."
            ),
            errors=result.error_message.split("; ") if result.error_message else None,
        )

    except Exception as e:
        logger.error("Domain crawl failed", domain=domain, error=str(e))

        # Record failure
        await crawl_history_repo.complete(
            crawl_id=crawl.id,
            status="failed",
            error_message=str(e),
        )
        await domain_repo.update_crawl_status(domain, "failed")

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "code": "DNS_AID_006",
                "message": f"Crawl failed: {e}",
            },
        ) from e
