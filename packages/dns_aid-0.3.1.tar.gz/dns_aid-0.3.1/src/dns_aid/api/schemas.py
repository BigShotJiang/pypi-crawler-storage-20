"""
Pydantic schemas for DNS-AID Agent Directory API.

Defines request/response models with validation for all API endpoints.
"""

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

# ==============================================================================
# Base Schemas
# ==============================================================================


class BaseSchema(BaseModel):
    """Base schema with common configuration."""

    model_config = ConfigDict(from_attributes=True)


# ==============================================================================
# Domain Schemas
# ==============================================================================


class DomainSubmitRequest(BaseModel):
    """Request to submit a domain for indexing."""

    domain: str = Field(
        ...,
        min_length=3,
        max_length=255,
        pattern=r"^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*$",
        description="Domain name to submit (e.g., example.com)",
        examples=["example.com", "agents.mycompany.io"],
    )

    @field_validator("domain")
    @classmethod
    def lowercase_domain(cls, v: str) -> str:
        return v.lower()


class DomainVerifyRequest(BaseModel):
    """Request to verify domain ownership."""

    domain: str = Field(..., min_length=3, max_length=255, description="Domain to verify")

    @field_validator("domain")
    @classmethod
    def lowercase_domain(cls, v: str) -> str:
        return v.lower()


class DomainResponse(BaseSchema):
    """Domain information response."""

    domain: str
    verified: bool
    verification_token: str | None = Field(
        None, description="Token to publish in DNS TXT record for verification"
    )
    submitted_at: datetime
    verified_at: datetime | None = None
    last_crawled: datetime | None = None
    crawl_status: str
    agent_count: int


class DomainSubmitResponse(BaseModel):
    """Response after submitting a domain."""

    domain: str
    verification_token: str
    verification_record: str = Field(..., description="DNS TXT record to create for verification")
    instructions: str


class DomainVerifyResponse(BaseModel):
    """Response after domain verification attempt."""

    domain: str
    verified: bool
    message: str


class DomainCrawlResponse(BaseModel):
    """Response after crawling a domain for agents."""

    domain: str
    status: str = Field(..., description="Crawl status: success, partial, failed")
    agents_found: int = Field(..., description="Total agents discovered")
    agents_added: int = Field(..., description="New agents added to index")
    agents_updated: int = Field(..., description="Existing agents updated")
    message: str
    errors: list[str] | None = Field(None, description="Any errors encountered")


# ==============================================================================
# Agent Schemas
# ==============================================================================


class AgentResponse(BaseSchema):
    """Agent information response."""

    fqdn: str = Field(..., description="Fully qualified domain name of the agent")
    domain: str
    name: str
    protocol: str = Field(..., description="Protocol: mcp, a2a, or https")
    endpoint_url: str | None = None
    port: int = 443
    capabilities: list[str] | None = None
    version: str | None = None

    # Scores
    security_score: int = Field(0, ge=0, le=100)
    trust_score: int = Field(0, ge=0, le=100)
    popularity_score: int = Field(0, ge=0, le=100)

    # Threat info
    threat_flags: dict[str, Any] = Field(default_factory=dict)

    # Timestamps
    first_seen: datetime
    last_seen: datetime
    last_verified: datetime | None = None


class AgentListResponse(BaseModel):
    """Paginated list of agents."""

    agents: list[AgentResponse]
    total: int
    limit: int
    offset: int

    @property
    def count(self) -> int:
        return len(self.agents)


# ==============================================================================
# Search Schemas
# ==============================================================================


class SearchRequest(BaseModel):
    """Search request parameters."""

    q: str = Field(
        ...,
        min_length=1,
        max_length=100,
        description="Search query",
        examples=["chat", "crm", "code-review"],
    )
    protocol: str | None = Field(None, description="Filter by protocol")
    domain: str | None = Field(None, description="Filter by domain")
    capabilities: list[str] | None = Field(None, description="Required capabilities")
    min_security_score: int | None = Field(None, ge=0, le=100)
    limit: int = Field(20, ge=1, le=100)
    offset: int = Field(0, ge=0)


class SearchResultItem(BaseModel):
    """A single search result."""

    agent: AgentResponse
    score: float = Field(..., description="Relevance score")


class SearchResponse(BaseModel):
    """Search results response."""

    query: str
    results: list[SearchResultItem]
    total: int
    limit: int
    offset: int

    @property
    def count(self) -> int:
        return len(self.results)


# ==============================================================================
# Health Schemas
# ==============================================================================


class HealthResponse(BaseModel):
    """Health check response."""

    status: str = Field(..., description="Service status: healthy, degraded, or unhealthy")
    version: str
    database: str = Field(..., description="Database connection status")
    uptime_seconds: float


class StatsResponse(BaseModel):
    """Directory statistics response."""

    total_agents: int
    total_domains: int
    verified_domains: int
    agents_by_protocol: dict[str, int]


# ==============================================================================
# Error Schemas
# ==============================================================================


class ErrorResponse(BaseModel):
    """Error response model."""

    code: str = Field(..., description="Error code (e.g., DNS_AID_001)")
    message: str = Field(..., description="Human-readable error message")
    details: dict[str, Any] | None = None


class ValidationErrorResponse(BaseModel):
    """Validation error response."""

    code: str = "DNS_AID_400"
    message: str = "Validation error"
    errors: list[dict[str, Any]]
