"""AWS Lambda handler for DNS-AID API.

This module provides the Lambda handler function that wraps the FastAPI
application using Mangum for AWS Lambda compatibility.

Mangum is an adapter that allows ASGI applications (like FastAPI) to run
on AWS Lambda behind API Gateway.
"""

import os

from mangum import Mangum

from dns_aid.api.app import app

# Configure Mangum adapter for API Gateway HTTP API (v2)
# lifespan="off" prevents startup/shutdown events from running on each invocation
handler = Mangum(app, lifespan="off", api_gateway_base_path="/")


# Optional: Cold start optimization
# Pre-import heavy modules to reduce cold start time
def _warm_imports():
    """Pre-import modules to reduce cold start latency."""
    try:
        import pydantic  # noqa: F401
        import sqlalchemy  # noqa: F401
        import structlog  # noqa: F401
    except ImportError:
        pass


# Run warm imports on module load (cold start)
if os.environ.get("AWS_LAMBDA_FUNCTION_NAME"):
    _warm_imports()
