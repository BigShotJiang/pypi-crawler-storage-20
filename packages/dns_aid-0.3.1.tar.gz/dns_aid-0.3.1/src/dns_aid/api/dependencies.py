"""
FastAPI dependencies for DNS-AID Agent Directory API.

Provides dependency injection for database sessions, repositories, and services.
"""

from collections.abc import AsyncGenerator
from typing import Annotated

from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession

from dns_aid.directory.database import get_db_session
from dns_aid.directory.repository import (
    AgentRepository,
    CrawlHistoryRepository,
    DomainRepository,
)
from dns_aid.directory.search import SearchEngine

# Type alias for session dependency
DbSession = Annotated[AsyncSession, Depends(get_db_session)]


async def get_domain_repository(session: DbSession) -> AsyncGenerator[DomainRepository, None]:
    """Get a DomainRepository instance."""
    yield DomainRepository(session)


async def get_agent_repository(session: DbSession) -> AsyncGenerator[AgentRepository, None]:
    """Get an AgentRepository instance."""
    yield AgentRepository(session)


async def get_crawl_history_repository(
    session: DbSession,
) -> AsyncGenerator[CrawlHistoryRepository, None]:
    """Get a CrawlHistoryRepository instance."""
    yield CrawlHistoryRepository(session)


async def get_search_engine(session: DbSession) -> AsyncGenerator[SearchEngine, None]:
    """Get a SearchEngine instance."""
    yield SearchEngine(session)


# Type aliases for dependency injection
DomainRepo = Annotated[DomainRepository, Depends(get_domain_repository)]
AgentRepo = Annotated[AgentRepository, Depends(get_agent_repository)]
CrawlHistoryRepo = Annotated[CrawlHistoryRepository, Depends(get_crawl_history_repository)]
Search = Annotated[SearchEngine, Depends(get_search_engine)]
