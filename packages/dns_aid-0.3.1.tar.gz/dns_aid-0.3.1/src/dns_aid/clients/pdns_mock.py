"""
Mock Passive DNS Provider for testing.

Provides sample DNS-AID records for development and testing
without requiring access to real pDNS data sources.
"""

from __future__ import annotations

import fnmatch
import re
import time
from datetime import UTC, datetime, timedelta

from dns_aid.clients.pdns_base import PDNSProvider, PDNSQueryResult, PDNSRecord

# Sample DNS-AID records for testing
# These simulate what we'd find in a real pDNS database
SAMPLE_RECORDS: list[dict] = [
    # High-traffic MCP agent (popular)
    {
        "rrname": "_assistant._mcp._agents.openai.com",
        "rrtype": "SVCB",
        "rdata": '1 mcp.openai.com. alpn="mcp" port=443',
        "time_first": int((datetime.now(UTC) - timedelta(days=180)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(hours=1)).timestamp()),
        "count": 1500000,  # 1.5M queries - very popular
        "bailiwick": "openai.com",
    },
    {
        "rrname": "_assistant._mcp._agents.openai.com",
        "rrtype": "TXT",
        "rdata": "capabilities=chat,code,analysis version=2.0.0",
        "time_first": int((datetime.now(UTC) - timedelta(days=180)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(hours=1)).timestamp()),
        "count": 1200000,
        "bailiwick": "openai.com",
    },
    # Medium-traffic A2A agent
    {
        "rrname": "_chat._a2a._agents.anthropic.com",
        "rrtype": "SVCB",
        "rdata": '1 a2a.anthropic.com. alpn="a2a" port=443',
        "time_first": int((datetime.now(UTC) - timedelta(days=90)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(hours=6)).timestamp()),
        "count": 85000,  # 85K queries
        "bailiwick": "anthropic.com",
    },
    {
        "rrname": "_chat._a2a._agents.anthropic.com",
        "rrtype": "TXT",
        "rdata": "capabilities=conversation,reasoning version=1.5.0",
        "time_first": int((datetime.now(UTC) - timedelta(days=90)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(hours=6)).timestamp()),
        "count": 75000,
        "bailiwick": "anthropic.com",
    },
    # Enterprise MCP agent (network specialist)
    {
        "rrname": "_network._mcp._agents.cisco.com",
        "rrtype": "SVCB",
        "rdata": '1 mcp.cisco.com. alpn="mcp" port=443',
        "time_first": int((datetime.now(UTC) - timedelta(days=60)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(days=1)).timestamp()),
        "count": 12000,  # 12K queries
        "bailiwick": "cisco.com",
    },
    {
        "rrname": "_network._mcp._agents.cisco.com",
        "rrtype": "TXT",
        "rdata": "capabilities=ipam,dns,vpn,firewall version=3.1.0",
        "time_first": int((datetime.now(UTC) - timedelta(days=60)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(days=1)).timestamp()),
        "count": 11500,
        "bailiwick": "cisco.com",
    },
    # Low-traffic test agent
    {
        "rrname": "_test._mcp._agents.example.org",
        "rrtype": "SVCB",
        "rdata": '1 mcp.example.org. alpn="mcp" port=8443',
        "time_first": int((datetime.now(UTC) - timedelta(days=7)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(days=2)).timestamp()),
        "count": 42,  # Very low traffic
        "bailiwick": "example.org",
    },
    # Multi-protocol agent (supports both MCP and A2A)
    {
        "rrname": "_multiagent._mcp._agents.google.com",
        "rrtype": "SVCB",
        "rdata": '1 agents.google.com. alpn="mcp" port=443',
        "time_first": int((datetime.now(UTC) - timedelta(days=120)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(hours=2)).timestamp()),
        "count": 250000,
        "bailiwick": "google.com",
    },
    {
        "rrname": "_multiagent._a2a._agents.google.com",
        "rrtype": "SVCB",
        "rdata": '1 agents.google.com. alpn="a2a" port=443',
        "time_first": int((datetime.now(UTC) - timedelta(days=120)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(hours=2)).timestamp()),
        "count": 180000,
        "bailiwick": "google.com",
    },
    {
        "rrname": "_multiagent._mcp._agents.google.com",
        "rrtype": "TXT",
        "rdata": "capabilities=search,maps,translate,calendar version=4.0.0",
        "time_first": int((datetime.now(UTC) - timedelta(days=120)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(hours=2)).timestamp()),
        "count": 230000,
        "bailiwick": "google.com",
    },
    # Stale agent (not queried recently)
    {
        "rrname": "_oldbot._mcp._agents.defunct.io",
        "rrtype": "SVCB",
        "rdata": '1 mcp.defunct.io. alpn="mcp" port=443',
        "time_first": int((datetime.now(UTC) - timedelta(days=365)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(days=180)).timestamp()),
        "count": 5000,
        "bailiwick": "defunct.io",
    },
    # Agent with IPv4 hint
    {
        "rrname": "_api._https._agents.fastly.com",
        "rrtype": "SVCB",
        "rdata": '1 api.fastly.com. alpn="https" port=443 ipv4hint=151.101.1.57',
        "time_first": int((datetime.now(UTC) - timedelta(days=30)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(hours=12)).timestamp()),
        "count": 45000,
        "bailiwick": "fastly.com",
    },
    # DNS-AID demo agents (from project test domains)
    {
        "rrname": "_demo._mcp._agents.highvelocitynetworking.com",
        "rrtype": "SVCB",
        "rdata": '1 mcp.highvelocitynetworking.com. alpn="mcp" port=443',
        "time_first": int((datetime.now(UTC) - timedelta(days=14)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(hours=4)).timestamp()),
        "count": 320,
        "bailiwick": "highvelocitynetworking.com",
    },
    {
        "rrname": "_demo._mcp._agents.highvelocitynetworking.com",
        "rrtype": "TXT",
        "rdata": "capabilities=demo,testing version=0.2.1",
        "time_first": int((datetime.now(UTC) - timedelta(days=14)).timestamp()),
        "time_last": int((datetime.now(UTC) - timedelta(hours=4)).timestamp()),
        "count": 310,
        "bailiwick": "highvelocitynetworking.com",
    },
]


class MockPDNSProvider(PDNSProvider):
    """
    Mock Passive DNS provider for testing.

    Uses sample data to simulate pDNS queries without
    requiring access to real data sources.
    """

    def __init__(self, records: list[dict] | None = None):
        """
        Initialize mock provider.

        Args:
            records: Custom records to use (defaults to SAMPLE_RECORDS)
        """
        super().__init__(name="mock")
        self._records = [PDNSRecord.from_dict(r) for r in (records or SAMPLE_RECORDS)]

    def _match_pattern(self, rrname: str, pattern: str) -> bool:
        """
        Match rrname against wildcard pattern.

        Supports * as wildcard for any characters.
        """
        # Convert glob pattern to regex
        regex_pattern = fnmatch.translate(pattern.lower())
        return bool(re.match(regex_pattern, rrname.lower()))

    async def query_rrset(
        self,
        rrname: str,
        rrtype: str | None = None,
        limit: int = 1000,
    ) -> PDNSQueryResult:
        """Query by exact rrname."""
        start_time = time.perf_counter()

        matches = []
        for record in self._records:
            if record.rrname.lower() == rrname.lower() and (
                rrtype is None or record.rrtype.upper() == rrtype.upper()
            ):
                matches.append(record)

        elapsed_ms = (time.perf_counter() - start_time) * 1000
        truncated = len(matches) > limit
        matches = matches[:limit]

        return PDNSQueryResult(
            records=matches,
            query_pattern=rrname,
            provider=self.name,
            query_time_ms=elapsed_ms,
            truncated=truncated,
        )

    async def query_rdata(
        self,
        rdata: str,
        rrtype: str | None = None,
        limit: int = 1000,
    ) -> PDNSQueryResult:
        """Query by rdata content."""
        start_time = time.perf_counter()

        matches = []
        rdata_lower = rdata.lower()

        for record in self._records:
            # Check if rdata matches (substring match)
            record_rdata = record.rdata
            if isinstance(record_rdata, list):
                rdata_str = " ".join(record_rdata).lower()
            else:
                rdata_str = record_rdata.lower()

            if rdata_lower in rdata_str and (
                rrtype is None or record.rrtype.upper() == rrtype.upper()
            ):
                matches.append(record)

        elapsed_ms = (time.perf_counter() - start_time) * 1000
        truncated = len(matches) > limit
        matches = matches[:limit]

        return PDNSQueryResult(
            records=matches,
            query_pattern=f"rdata:{rdata}",
            provider=self.name,
            query_time_ms=elapsed_ms,
            truncated=truncated,
        )

    async def query_wildcard(
        self,
        pattern: str,
        rrtype: str | None = None,
        limit: int = 1000,
    ) -> PDNSQueryResult:
        """Query using wildcard pattern."""
        start_time = time.perf_counter()

        matches = []
        for record in self._records:
            if self._match_pattern(record.rrname, pattern) and (
                rrtype is None or record.rrtype.upper() == rrtype.upper()
            ):
                matches.append(record)

        elapsed_ms = (time.perf_counter() - start_time) * 1000
        truncated = len(matches) > limit
        matches = matches[:limit]

        self.logger.debug(
            "Wildcard query completed",
            pattern=pattern,
            rrtype=rrtype,
            matches=len(matches),
            time_ms=f"{elapsed_ms:.2f}",
        )

        return PDNSQueryResult(
            records=matches,
            query_pattern=pattern,
            provider=self.name,
            query_time_ms=elapsed_ms,
            truncated=truncated,
        )

    async def health_check(self) -> bool:
        """Mock provider is always healthy."""
        return True

    def add_record(self, record: PDNSRecord | dict) -> None:
        """
        Add a record to the mock database.

        Useful for testing specific scenarios.
        """
        if isinstance(record, dict):
            record = PDNSRecord.from_dict(record)
        self._records.append(record)

    def clear_records(self) -> None:
        """Clear all records from mock database."""
        self._records.clear()

    def reset_to_defaults(self) -> None:
        """Reset to default sample records."""
        self._records = [PDNSRecord.from_dict(r) for r in SAMPLE_RECORDS]


def get_provider(provider_name: str = "mock") -> PDNSProvider:
    """
    Factory function to get a pDNS provider by name.

    Args:
        provider_name: Provider name (mock, infoblox, farsight, etc.)

    Returns:
        PDNSProvider instance

    Raises:
        ValueError: If provider is not supported
    """
    providers = {
        "mock": MockPDNSProvider,
        # Future providers:
        # "infoblox": InfobloxPDNSProvider,
        # "farsight": FarsightPDNSProvider,
        # "securitytrails": SecurityTrailsPDNSProvider,
    }

    if provider_name not in providers:
        available = ", ".join(providers.keys())
        raise ValueError(f"Unknown pDNS provider: {provider_name}. Available: {available}")

    return providers[provider_name]()
