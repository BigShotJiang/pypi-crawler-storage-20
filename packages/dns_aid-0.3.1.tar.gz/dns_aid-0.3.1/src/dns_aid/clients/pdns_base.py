"""
Passive DNS Provider Base Interface.

Defines the abstract interface for passive DNS data providers,
following the Passive DNS Common Output Format (COF) specification:
https://datatracker.ietf.org/doc/html/draft-dulaunoy-dnsop-passive-dns-cof

Supported providers:
- Infoblox (internal pDNS data)
- Farsight DNSDB
- SecurityTrails
- CIRCL Passive DNS
- Mock (for testing)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from datetime import UTC, datetime

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class PDNSRecord:
    """
    A Passive DNS record following the Common Output Format (COF).

    Reference: draft-dulaunoy-dnsop-passive-dns-cof

    Mandatory fields (per COF spec):
    - rrname: The queried resource record name
    - rrtype: Resource record type (A, AAAA, CNAME, SVCB, TXT, etc.)
    - rdata: Resource record data (may be string or list)
    - time_first: First observation timestamp (Unix epoch)
    - time_last: Last observation timestamp (Unix epoch)

    Optional fields:
    - count: Number of times this record was observed
    - bailiwick: Zone apex where this data is authoritative
    - sensor_id: Sensor/collector identifier
    """

    # Mandatory fields (COF spec)
    rrname: str
    rrtype: str
    rdata: str | list[str]
    time_first: int  # Unix timestamp
    time_last: int  # Unix timestamp

    # Optional fields (COF spec)
    count: int | None = None
    bailiwick: str | None = None
    sensor_id: str | None = None

    # Extended fields (DNS-AID specific)
    zone_time_first: int | None = None
    zone_time_last: int | None = None
    origin: str | None = None  # Provider URI

    @property
    def time_first_dt(self) -> datetime:
        """First observation as datetime."""
        return datetime.fromtimestamp(self.time_first, tz=UTC)

    @property
    def time_last_dt(self) -> datetime:
        """Last observation as datetime."""
        return datetime.fromtimestamp(self.time_last, tz=UTC)

    @property
    def rdata_list(self) -> list[str]:
        """Get rdata as a list (normalize single string to list)."""
        if isinstance(self.rdata, list):
            return self.rdata
        return [self.rdata]

    @property
    def age_seconds(self) -> int:
        """Seconds since last observation."""
        now = int(datetime.now(UTC).timestamp())
        return now - self.time_last

    @property
    def is_dns_aid_record(self) -> bool:
        """Check if this record is a DNS-AID agent record."""
        return "._agents." in self.rrname and self.rrtype in ("SVCB", "TXT", "HTTPS")

    def to_dict(self) -> dict:
        """Convert to COF-compliant dictionary."""
        result = {
            "rrname": self.rrname,
            "rrtype": self.rrtype,
            "rdata": self.rdata,
            "time_first": self.time_first,
            "time_last": self.time_last,
        }
        if self.count is not None:
            result["count"] = self.count
        if self.bailiwick:
            result["bailiwick"] = self.bailiwick
        if self.sensor_id:
            result["sensor_id"] = self.sensor_id
        if self.zone_time_first is not None:
            result["zone_time_first"] = self.zone_time_first
        if self.zone_time_last is not None:
            result["zone_time_last"] = self.zone_time_last
        if self.origin:
            result["origin"] = self.origin
        return result

    @classmethod
    def from_dict(cls, data: dict) -> PDNSRecord:
        """Create from COF-compliant dictionary."""
        return cls(
            rrname=data["rrname"],
            rrtype=data["rrtype"],
            rdata=data["rdata"],
            time_first=int(data["time_first"]),
            time_last=int(data["time_last"]),
            count=data.get("count"),
            bailiwick=data.get("bailiwick"),
            sensor_id=data.get("sensor_id"),
            zone_time_first=data.get("zone_time_first"),
            zone_time_last=data.get("zone_time_last"),
            origin=data.get("origin"),
        )


@dataclass
class PDNSQueryResult:
    """Result of a passive DNS query."""

    records: list[PDNSRecord] = field(default_factory=list)
    query_pattern: str = ""
    provider: str = ""
    query_time_ms: float = 0.0
    truncated: bool = False  # True if results were limited
    error: str | None = None

    @property
    def count(self) -> int:
        """Number of records returned."""
        return len(self.records)

    @property
    def dns_aid_records(self) -> list[PDNSRecord]:
        """Filter to only DNS-AID agent records."""
        return [r for r in self.records if r.is_dns_aid_record]


class PDNSProvider(ABC):
    """
    Abstract base class for Passive DNS providers.

    Implementations must support querying by:
    - RRset (forward lookup by rrname)
    - Rdata (inverse lookup by record value)
    - Wildcard patterns (for DNS-AID discovery)
    """

    def __init__(self, name: str = "base"):
        """Initialize the provider."""
        self.name = name
        self.logger = logger.bind(provider=name)

    @abstractmethod
    async def query_rrset(
        self,
        rrname: str,
        rrtype: str | None = None,
        limit: int = 1000,
    ) -> PDNSQueryResult:
        """
        Query by RRset (forward lookup).

        Args:
            rrname: The resource record name to query
            rrtype: Optional record type filter (A, AAAA, SVCB, TXT, etc.)
            limit: Maximum records to return

        Returns:
            PDNSQueryResult with matching records
        """
        pass

    @abstractmethod
    async def query_rdata(
        self,
        rdata: str,
        rrtype: str | None = None,
        limit: int = 1000,
    ) -> PDNSQueryResult:
        """
        Query by Rdata (inverse lookup).

        Args:
            rdata: The record data to search for
            rrtype: Optional record type filter
            limit: Maximum records to return

        Returns:
            PDNSQueryResult with matching records
        """
        pass

    @abstractmethod
    async def query_wildcard(
        self,
        pattern: str,
        rrtype: str | None = None,
        limit: int = 1000,
    ) -> PDNSQueryResult:
        """
        Query using wildcard pattern.

        This is the primary method for DNS-AID discovery.
        Pattern examples: "*._mcp._agents.*", "*._agents.example.com"

        Args:
            pattern: Wildcard pattern to match rrnames
            rrtype: Optional record type filter
            limit: Maximum records to return

        Returns:
            PDNSQueryResult with matching records
        """
        pass

    async def query_dns_aid_agents(
        self,
        domain: str | None = None,
        protocol: str | None = None,
        limit: int = 1000,
    ) -> PDNSQueryResult:
        """
        Query for DNS-AID agent records.

        Convenience method that constructs the appropriate wildcard pattern.

        Args:
            domain: Optional domain filter (None = all domains)
            protocol: Optional protocol filter (mcp, a2a, https)
            limit: Maximum records to return

        Returns:
            PDNSQueryResult with DNS-AID records only
        """
        # Build pattern based on filters
        if domain and protocol:
            pattern = f"*._{protocol}._agents.{domain}"
        elif domain:
            pattern = f"*._agents.{domain}"
        elif protocol:
            pattern = f"*._{protocol}._agents.*"
        else:
            pattern = "*._agents.*"

        self.logger.debug(
            "Querying for DNS-AID agents",
            pattern=pattern,
            domain=domain,
            protocol=protocol,
        )

        # Query for SVCB and TXT records
        result = await self.query_wildcard(pattern, limit=limit)

        # Filter to DNS-AID records only
        result.records = [r for r in result.records if r.is_dns_aid_record]

        return result

    async def stream_records(
        self,
        pattern: str,
        rrtype: str | None = None,
    ) -> AsyncIterator[PDNSRecord]:
        """
        Stream records matching pattern.

        For large result sets, this avoids loading all records into memory.
        Default implementation fetches in batches.

        Args:
            pattern: Wildcard pattern to match
            rrtype: Optional record type filter

        Yields:
            PDNSRecord objects
        """
        offset = 0
        batch_size = 1000

        while True:
            result = await self.query_wildcard(
                pattern,
                rrtype=rrtype,
                limit=batch_size,
            )

            for record in result.records:
                yield record

            if len(result.records) < batch_size or not result.truncated:
                break

            offset += batch_size

    @abstractmethod
    async def health_check(self) -> bool:
        """
        Check if the provider is available.

        Returns:
            True if provider is healthy and accessible
        """
        pass

    async def close(self) -> None:
        """
        Clean up resources.

        Override in implementations that need cleanup.
        Default implementation does nothing.
        """
        return None  # noqa: B027 - intentionally not abstract, provides default no-op

    async def __aenter__(self) -> PDNSProvider:
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()
