"""
DNS-AID External API Clients.

Provides client implementations for external services like
Passive DNS providers, Certificate Transparency logs, etc.
"""

from dns_aid.clients.pdns_base import (
    PDNSProvider,
    PDNSQueryResult,
    PDNSRecord,
)
from dns_aid.clients.pdns_mock import MockPDNSProvider, get_provider

__all__ = [
    "PDNSProvider",
    "PDNSRecord",
    "PDNSQueryResult",
    "MockPDNSProvider",
    "get_provider",
]
