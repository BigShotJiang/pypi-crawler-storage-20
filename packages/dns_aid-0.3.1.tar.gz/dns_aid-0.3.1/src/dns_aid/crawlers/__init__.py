"""
DNS-AID Agent Directory Crawlers

Crawler infrastructure for discovering and indexing DNS-AID agents
from various sources including domain submissions, CT logs, and pDNS.
"""

from dns_aid.crawlers.base import BaseCrawler, CrawlResult, DiscoveredAgent
from dns_aid.crawlers.ct_monitor import CTLogEntry, CTLogSource, CTMatch, CTMonitor
from dns_aid.crawlers.index_reader import AgentRef, IndexReaderCrawler, read_index
from dns_aid.crawlers.passive_dns import PassiveDNSCrawler
from dns_aid.crawlers.pattern_prober import PatternProberCrawler
from dns_aid.crawlers.scheduler import (
    BatchScheduler,
    CrawlJob,
    CrawlPriority,
    CrawlQueue,
    CrawlScheduler,
    CrawlStatus,
)
from dns_aid.crawlers.submission import BatchSubmissionCrawler, SubmissionCrawler
from dns_aid.crawlers.zone_walker import NSECZoneWalker

# Lambda handlers (for AWS deployment)
# These are optional - only available when aws_lambda_powertools is installed
try:
    from dns_aid.crawlers.lambda_handler import handler as crawler_handler
    from dns_aid.crawlers.scheduler_handler import handler as scheduler_handler
except ImportError:
    crawler_handler = None  # type: ignore[assignment,misc]
    scheduler_handler = None  # type: ignore[assignment,misc]

__all__ = [
    # Base classes
    "BaseCrawler",
    "CrawlResult",
    "DiscoveredAgent",
    # Crawlers
    "BatchScheduler",
    "BatchSubmissionCrawler",
    "CTMonitor",
    "CrawlScheduler",
    "IndexReaderCrawler",
    "NSECZoneWalker",
    "PassiveDNSCrawler",
    "PatternProberCrawler",
    "SubmissionCrawler",
    # Job types
    "CrawlJob",
    "CrawlPriority",
    "CrawlQueue",
    "CrawlStatus",
    # CT Monitor types
    "CTLogEntry",
    "CTLogSource",
    "CTMatch",
    # Utilities
    "AgentRef",
    "read_index",
    # Lambda handlers
    "crawler_handler",
    "scheduler_handler",
]
