"""
Pattern Prober Crawler for DNS-AID Agent Directory.

Fallback discovery method that probes for common agent names when
no _index._agents.* record is published.

This is less efficient than index-based discovery but works for
domains that haven't published an index record.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime

import dns.asyncresolver
import dns.resolver
import structlog

from dns_aid.core.discoverer import discover
from dns_aid.core.validator import verify
from dns_aid.crawlers.base import BaseCrawler, CrawlResult, DiscoveredAgent
from dns_aid.crawlers.config import (
    DEFAULT_PROBE_NAMES,
    DEFAULT_PROBE_PROTOCOLS,
    DNS_QUERY_CONFIG,
    ENABLE_PATTERN_PROBER,
    RATE_LIMIT_CONFIG,
    is_domain_blocked,
)

logger = structlog.get_logger(__name__)


async def svcb_exists(fqdn: str) -> bool:
    """
    Check if an SVCB record exists for the given FQDN.

    Fast check without fetching full record details.

    Args:
        fqdn: Fully qualified domain name to check

    Returns:
        True if SVCB record exists
    """
    try:
        resolver = dns.asyncresolver.Resolver()
        resolver.timeout = DNS_QUERY_CONFIG.timeout_seconds
        resolver.lifetime = DNS_QUERY_CONFIG.timeout_seconds

        # Try SVCB first, then HTTPS
        try:
            await resolver.resolve(fqdn, "SVCB")
            return True
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
            pass

        try:
            await resolver.resolve(fqdn, "HTTPS")
            return True
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
            pass

    except dns.exception.Timeout:
        pass
    except Exception:
        pass

    return False


class PatternProberCrawler(BaseCrawler):
    """
    Crawler that probes for agents using common name patterns.

    This is a FALLBACK method used when:
    - No _index._agents.* record is published
    - We want to discover agents at domains we don't know much about

    Probes patterns like:
    - _assistant._mcp._agents.{domain}
    - _chat._a2a._agents.{domain}
    - _api._mcp._agents.{domain}
    - etc.
    """

    def __init__(
        self,
        names: list[str] | None = None,
        protocols: list[str] | None = None,
        verify_agents: bool = True,
        max_concurrent: int = 10,
    ):
        """
        Initialize the pattern prober crawler.

        Args:
            names: Agent names to probe (defaults to common names)
            protocols: Protocols to try (defaults to mcp, a2a)
            verify_agents: Whether to verify discovered agents
            max_concurrent: Maximum concurrent probes
        """
        super().__init__(name="pattern-prober")
        self._names = names or DEFAULT_PROBE_NAMES
        self._protocols = protocols or DEFAULT_PROBE_PROTOCOLS
        self._verify_agents = verify_agents
        self._max_concurrent = max_concurrent

    async def crawl(self, domain: str) -> CrawlResult:
        """
        Probe a domain for agents using common name patterns.

        Args:
            domain: Domain to probe

        Returns:
            CrawlResult with discovered agents
        """
        if not ENABLE_PATTERN_PROBER:
            self.logger.info("Pattern prober is disabled")
            result = CrawlResult(domain=domain, status="skipped")
            result.complete("skipped", "Pattern prober disabled")
            return result

        if is_domain_blocked(domain):
            self.logger.warning("Domain is blocked", domain=domain)
            result = CrawlResult(domain=domain, status="blocked")
            result.complete("blocked", f"Domain {domain} is in blocklist")
            return result

        result = CrawlResult(domain=domain, status="running")
        agents_found: list[DiscoveredAgent] = []
        probes_made = 0
        probes_hit = 0

        self.logger.info(
            "Starting pattern probing",
            domain=domain,
            names=len(self._names),
            protocols=len(self._protocols),
            total_probes=len(self._names) * len(self._protocols),
        )

        # Build list of FQDNs to probe
        probe_targets = []
        for name in self._names:
            for protocol in self._protocols:
                fqdn = f"_{name}._{protocol}._agents.{domain}"
                probe_targets.append((name, protocol, fqdn))

        # Probe with concurrency limit
        semaphore = asyncio.Semaphore(self._max_concurrent)

        async def probe_one(name: str, protocol: str, fqdn: str) -> DiscoveredAgent | None:
            """Probe a single FQDN."""
            async with semaphore:
                # Rate limiting delay
                await asyncio.sleep(1.0 / RATE_LIMIT_CONFIG.queries_per_second_per_domain)

                if not await svcb_exists(fqdn):
                    return None

                # Record exists - fetch full details
                try:
                    discovery_result = await discover(
                        domain=domain,
                        protocol=protocol,
                        name=name,
                    )

                    for agent in discovery_result.agents:
                        security_score = 0
                        metadata = {
                            "source": "pattern-probe",
                            "probe_timestamp": datetime.now(UTC).isoformat(),
                        }

                        if self._verify_agents:
                            try:
                                verification = await verify(agent.fqdn)
                                security_score = verification.security_score
                                metadata.update(
                                    {
                                        "dnssec_valid": str(verification.dnssec_valid),
                                        "dane_valid": str(verification.dane_valid),
                                        "endpoint_reachable": str(verification.endpoint_reachable),
                                        "svcb_valid": str(verification.svcb_valid),
                                    }
                                )
                            except Exception as e:
                                self.logger.debug(
                                    "Verification failed",
                                    fqdn=agent.fqdn,
                                    error=str(e),
                                )

                        return DiscoveredAgent(
                            fqdn=agent.fqdn,
                            domain=domain,
                            name=agent.name,
                            protocol=protocol,
                            endpoint_url=agent.endpoint_url,
                            port=agent.port or 443,
                            capabilities=agent.capabilities or [],
                            version=agent.version,
                            security_score=security_score,
                            metadata=metadata,
                        )

                except Exception as e:
                    self.logger.debug(
                        "Discovery failed after probe hit",
                        fqdn=fqdn,
                        error=str(e),
                    )

                return None

        # Execute probes concurrently
        tasks = [probe_one(n, p, f) for n, p, f in probe_targets]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Collect results
        for (name, protocol, fqdn), res in zip(probe_targets, results, strict=True):
            probes_made += 1
            if isinstance(res, DiscoveredAgent):
                probes_hit += 1
                agents_found.append(res)
                self.logger.info(
                    "Agent found via probing",
                    fqdn=fqdn,
                    name=name,
                    protocol=protocol,
                )
            elif isinstance(res, Exception):
                self.logger.debug(
                    "Probe failed",
                    fqdn=fqdn,
                    error=str(res),
                )

        result.agents_found = agents_found
        result.complete("success")

        self.logger.info(
            "Pattern probing completed",
            domain=domain,
            probes_made=probes_made,
            probes_hit=probes_hit,
            agents_found=len(agents_found),
        )

        return result

    async def probe_single(
        self,
        domain: str,
        name: str,
        protocol: str,
    ) -> DiscoveredAgent | None:
        """
        Probe for a single specific agent.

        Args:
            domain: Domain to probe
            name: Agent name
            protocol: Protocol

        Returns:
            DiscoveredAgent if found, None otherwise
        """
        fqdn = f"_{name}._{protocol}._agents.{domain}"

        if not await svcb_exists(fqdn):
            return None

        try:
            discovery_result = await discover(
                domain=domain,
                protocol=protocol,
                name=name,
            )

            for agent in discovery_result.agents:
                return DiscoveredAgent(
                    fqdn=agent.fqdn,
                    domain=domain,
                    name=agent.name,
                    protocol=protocol,
                    endpoint_url=agent.endpoint_url,
                    port=agent.port or 443,
                    capabilities=agent.capabilities or [],
                    version=agent.version,
                    security_score=0,
                    metadata={"source": "pattern-probe"},
                )

        except Exception as e:
            self.logger.debug(
                "Single probe failed",
                fqdn=fqdn,
                error=str(e),
            )

        return None
