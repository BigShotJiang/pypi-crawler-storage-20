"""
NSEC Zone Walker for DNS-AID Agent Directory.

Enumerates DNS zones using NSEC/NSEC3 chain walking to discover
all _agents.* records in DNSSEC-enabled zones.

**WARNING: This is a SENSITIVE feature.**

IETF/DNSOP have historically opposed zone enumeration mechanisms
for privacy reasons. This module is:
- Controlled by ENABLE_NSEC_WALKER feature flag (default: False)
- Only works on DNSSEC-enabled zones
- Respects rate limits to avoid DNS abuse

Use cases:
- Research/academic discovery
- Security auditing (with permission)
- Testing DNSSEC deployment

The pattern prober is the recommended fallback for normal discovery.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import UTC, datetime

import dns.asyncresolver
import dns.dnssec
import dns.name
import dns.rdatatype
import dns.resolver
import structlog

from dns_aid.core.discoverer import discover
from dns_aid.core.validator import verify
from dns_aid.crawlers.base import BaseCrawler, CrawlResult, DiscoveredAgent
from dns_aid.crawlers.config import (
    DNS_QUERY_CONFIG,
    ENABLE_NSEC_WALKER,
    RATE_LIMIT_CONFIG,
    is_domain_blocked,
)

logger = structlog.get_logger(__name__)


@dataclass
class NSECRecord:
    """Parsed NSEC record."""

    owner: str
    next_name: str
    types: list[str]


@dataclass
class WalkResult:
    """Result of zone walking."""

    domain: str
    records_found: list[str]
    agents_zone: str  # _agents.{domain}
    dnssec_enabled: bool
    walk_complete: bool
    error: str | None = None


async def check_dnssec_enabled(domain: str) -> bool:
    """
    Check if a domain has DNSSEC enabled.

    Args:
        domain: Domain to check

    Returns:
        True if DNSSEC is enabled
    """
    try:
        resolver = dns.asyncresolver.Resolver()
        resolver.timeout = DNS_QUERY_CONFIG.timeout_seconds
        resolver.use_edns(edns=True, ednsflags=dns.flags.DO)

        # Query for DNSKEY record
        try:
            await resolver.resolve(domain, "DNSKEY")
            return True
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
            pass

        # Check for DS record at parent
        try:
            await resolver.resolve(domain, "DS")
            return True
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
            pass

    except Exception:
        pass

    return False


async def query_nsec(name: str) -> NSECRecord | None:
    """
    Query for NSEC record at a name.

    NSEC records are returned in the authority section when
    querying for a non-existent name.

    Args:
        name: DNS name to query

    Returns:
        NSECRecord if found
    """
    try:
        resolver = dns.asyncresolver.Resolver()
        resolver.timeout = DNS_QUERY_CONFIG.timeout_seconds
        resolver.use_edns(edns=True, ednsflags=dns.flags.DO)

        # Query for a type that's unlikely to exist to get NSEC
        try:
            await resolver.resolve(name, "NSEC")
        except dns.resolver.NoAnswer as e:
            # NSEC is in the authority section
            if hasattr(e, "response") and e.response:
                for rrset in e.response.authority:  # type: ignore[attr-defined]
                    if rrset.rdtype == dns.rdatatype.NSEC:
                        for rdata in rrset:
                            return NSECRecord(
                                owner=str(rrset.name),
                                next_name=str(rdata.next),
                                types=[dns.rdatatype.to_text(t) for t in rdata.windows],
                            )
        except dns.resolver.NXDOMAIN as e:
            # NXDOMAIN also contains NSEC in authority
            if hasattr(e, "response") and e.response:
                for rrset in e.response.authority:  # type: ignore[attr-defined]
                    if rrset.rdtype == dns.rdatatype.NSEC:
                        for rdata in rrset:
                            return NSECRecord(
                                owner=str(rrset.name),
                                next_name=str(rdata.next),
                                types=[dns.rdatatype.to_text(t) for t in rdata.windows],
                            )

    except Exception:
        pass

    return None


def is_under_agents_zone(name: str, domain: str) -> bool:
    """Check if a name is under the _agents.{domain} zone."""
    agents_zone = f"_agents.{domain}".lower()
    return name.lower().rstrip(".").endswith(agents_zone)


def extract_agent_name(fqdn: str, domain: str) -> tuple[str, str] | None:
    """
    Extract agent name and protocol from FQDN.

    Format: _{name}._{protocol}._agents.{domain}

    Returns:
        Tuple of (name, protocol) or None
    """
    fqdn = fqdn.lower().rstrip(".")
    suffix = f"._agents.{domain}".lower()

    if not fqdn.endswith(suffix):
        return None

    prefix = fqdn[: -len(suffix)]
    parts = prefix.split(".")

    if len(parts) >= 2 and parts[-1].startswith("_") and parts[-2].startswith("_"):
        protocol = parts[-1][1:]  # Remove leading underscore
        name = parts[-2][1:]  # Remove leading underscore
        return (name, protocol)

    return None


class NSECZoneWalker(BaseCrawler):
    """
    Zone walker using NSEC chain enumeration.

    FEATURE-FLAGGED: Only enabled when ENABLE_NSEC_WALKER=true.

    Walks the NSEC chain to enumerate all records under _agents.{domain},
    providing comprehensive discovery for DNSSEC-enabled zones.
    """

    def __init__(
        self,
        verify_agents: bool = True,
        max_records: int = 1000,
    ):
        """
        Initialize the zone walker.

        Args:
            verify_agents: Whether to verify discovered agents
            max_records: Maximum records to enumerate (safety limit)
        """
        super().__init__(name="nsec-walker")
        self._verify_agents = verify_agents
        self._max_records = max_records

    async def crawl(self, domain: str) -> CrawlResult:
        """
        Walk the _agents.{domain} zone to enumerate all agents.

        Args:
            domain: Domain to walk

        Returns:
            CrawlResult with discovered agents
        """
        # Check feature flag
        if not ENABLE_NSEC_WALKER:
            self.logger.info("NSEC walker is disabled by feature flag")
            result = CrawlResult(domain=domain, status="skipped")
            result.complete(
                "skipped",
                "NSEC zone walking disabled. Set ENABLE_NSEC_WALKER=true to enable.",
            )
            return result

        # Check blocklist
        if is_domain_blocked(domain):
            self.logger.warning("Domain is blocked", domain=domain)
            result = CrawlResult(domain=domain, status="blocked")
            result.complete("blocked", f"Domain {domain} is in blocklist")
            return result

        # Check DNSSEC
        if not await check_dnssec_enabled(domain):
            self.logger.info(
                "Domain does not have DNSSEC enabled, cannot walk zone",
                domain=domain,
            )
            result = CrawlResult(domain=domain, status="skipped")
            result.complete(
                "skipped",
                "DNSSEC not enabled - NSEC walking requires DNSSEC",
            )
            return result

        result = CrawlResult(domain=domain, status="running")
        agents_found: list[DiscoveredAgent] = []

        self.logger.info(
            "Starting NSEC zone walk",
            domain=domain,
            agents_zone=f"_agents.{domain}",
        )

        try:
            # Walk the zone
            walk_result = await self._walk_zone(domain)

            if walk_result.error:
                result.complete("failed", walk_result.error)
                return result

            self.logger.info(
                "Zone walk found records",
                domain=domain,
                records=len(walk_result.records_found),
            )

            # Discover agents for each found record
            for fqdn in walk_result.records_found:
                agent_info = extract_agent_name(fqdn, domain)
                if not agent_info:
                    continue

                name, protocol = agent_info

                try:
                    # Rate limit
                    await asyncio.sleep(1.0 / RATE_LIMIT_CONFIG.queries_per_second_per_domain)

                    discovery_result = await discover(
                        domain=domain,
                        protocol=protocol,
                        name=name,
                    )

                    for agent in discovery_result.agents:
                        security_score = 0
                        metadata = {
                            "source": "nsec-walk",
                            "walk_timestamp": datetime.now(UTC).isoformat(),
                        }

                        if self._verify_agents:
                            try:
                                verification = await verify(agent.fqdn)
                                security_score = verification.security_score
                                metadata.update(
                                    {
                                        "dnssec_valid": str(verification.dnssec_valid),
                                        "dane_valid": str(verification.dane_valid),
                                        "endpoint_reachable": str(verification.endpoint_reachable),
                                    }
                                )
                            except Exception as e:
                                self.logger.debug(
                                    "Verification failed",
                                    fqdn=agent.fqdn,
                                    error=str(e),
                                )

                        agents_found.append(
                            DiscoveredAgent(
                                fqdn=agent.fqdn,
                                domain=domain,
                                name=agent.name,
                                protocol=protocol,
                                endpoint_url=agent.endpoint_url,
                                port=agent.port or 443,
                                capabilities=agent.capabilities or [],
                                version=agent.version,
                                security_score=security_score,
                                metadata=metadata,
                            )
                        )

                        self.logger.info(
                            "Agent discovered via NSEC walk",
                            fqdn=agent.fqdn,
                            name=name,
                            protocol=protocol,
                        )

                except Exception as e:
                    self.logger.debug(
                        "Failed to discover agent from walked record",
                        fqdn=fqdn,
                        error=str(e),
                    )

            result.agents_found = agents_found
            result.complete("success")

        except Exception as e:
            self.logger.exception("Zone walk failed", domain=domain, error=str(e))
            result.complete("failed", str(e))

        self.logger.info(
            "NSEC zone walk completed",
            domain=domain,
            agents_found=len(agents_found),
        )

        return result

    async def _walk_zone(self, domain: str) -> WalkResult:
        """
        Walk the NSEC chain for _agents.{domain}.

        NSEC walking works by:
        1. Query for a name, get NSEC showing the next name
        2. Query just before that next name to get its NSEC
        3. Repeat until we wrap around to start

        Args:
            domain: Domain to walk

        Returns:
            WalkResult with enumerated records
        """
        agents_zone = f"_agents.{domain}"
        records_found: list[str] = []
        seen_names: set[str] = set()

        # Start at the beginning of the _agents zone
        current = agents_zone
        iterations = 0

        while iterations < self._max_records:
            iterations += 1

            # Rate limiting
            await asyncio.sleep(1.0 / RATE_LIMIT_CONFIG.queries_per_second_per_domain)

            nsec = await query_nsec(current)
            if nsec is None:
                self.logger.debug("No NSEC record found", name=current)
                break

            # Check if we've wrapped around
            if nsec.next_name in seen_names:
                self.logger.debug("Zone walk completed (wrapped around)")
                break

            seen_names.add(nsec.owner)

            # Check if the record is under our agents zone
            if is_under_agents_zone(nsec.owner, domain):
                records_found.append(nsec.owner)
                self.logger.debug("Found record in agents zone", name=nsec.owner)

            # Check if next_name is still in our zone
            if (
                not is_under_agents_zone(nsec.next_name, domain)
                and nsec.next_name.lower().rstrip(".") > agents_zone.lower()
            ):
                # We've walked past the _agents zone
                self.logger.debug(
                    "Zone walk exited agents zone",
                    next_name=nsec.next_name,
                )
                break

            current = nsec.next_name

        return WalkResult(
            domain=domain,
            records_found=records_found,
            agents_zone=agents_zone,
            dnssec_enabled=True,
            walk_complete=iterations < self._max_records,
            error=None if iterations < self._max_records else "Max records limit reached",
        )

    async def check_walkable(self, domain: str) -> bool:
        """
        Check if a domain can be walked.

        Args:
            domain: Domain to check

        Returns:
            True if DNSSEC enabled and NSEC walking possible
        """
        if not ENABLE_NSEC_WALKER:
            return False

        return await check_dnssec_enabled(domain)
