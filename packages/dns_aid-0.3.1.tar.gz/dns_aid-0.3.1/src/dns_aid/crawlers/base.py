"""
Base crawler interface for DNS-AID Agent Directory.

Defines the abstract base class that all crawlers must implement.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class DiscoveredAgent:
    """An agent discovered during crawling."""

    fqdn: str
    domain: str
    name: str
    protocol: str
    endpoint_url: str | None = None
    port: int = 443
    capabilities: list[str] = field(default_factory=list)
    version: str | None = None
    security_score: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CrawlResult:
    """Result of a crawl operation."""

    domain: str
    status: str  # "success", "partial", "failed"
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    completed_at: datetime | None = None
    agents_found: list[DiscoveredAgent] = field(default_factory=list)
    agents_added: int = 0
    agents_updated: int = 0
    error_message: str | None = None

    @property
    def duration_seconds(self) -> float | None:
        """Calculate crawl duration in seconds."""
        if self.completed_at and self.started_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None

    def complete(self, status: str = "success", error_message: str | None = None) -> None:
        """Mark the crawl as complete."""
        self.status = status
        self.completed_at = datetime.now(UTC)
        self.error_message = error_message


class BaseCrawler(ABC):
    """
    Abstract base class for DNS-AID crawlers.

    All crawlers must implement the crawl() method to discover agents.
    """

    def __init__(self, name: str = "base"):
        """Initialize the crawler."""
        self.name = name
        self.logger = logger.bind(crawler=name)

    @abstractmethod
    async def crawl(self, domain: str) -> CrawlResult:
        """
        Crawl a domain for DNS-AID agents.

        Args:
            domain: The domain to crawl.

        Returns:
            CrawlResult with discovered agents and status.
        """
        pass

    async def validate_domain(self, domain: str) -> bool:
        """
        Validate that a domain is suitable for crawling.

        Override to add custom validation logic.
        """
        # Basic validation
        if not domain or len(domain) < 3:
            return False
        return ".." not in domain

    async def pre_crawl(self, domain: str) -> None:
        """
        Hook called before crawling starts.

        Override to add setup logic.
        """
        self.logger.info("Starting crawl", domain=domain)

    async def post_crawl(self, result: CrawlResult) -> None:
        """
        Hook called after crawling completes.

        Override to add cleanup or reporting logic.
        """
        self.logger.info(
            "Crawl completed",
            domain=result.domain,
            status=result.status,
            agents_found=len(result.agents_found),
            duration_seconds=result.duration_seconds,
        )

    async def run(self, domain: str) -> CrawlResult:
        """
        Run the complete crawl workflow.

        Handles pre/post hooks and error handling.
        """
        result = CrawlResult(domain=domain, status="running")

        try:
            # Validate
            if not await self.validate_domain(domain):
                result.complete("failed", f"Invalid domain: {domain}")
                return result

            # Pre-crawl hook
            await self.pre_crawl(domain)

            # Perform crawl
            result = await self.crawl(domain)

            # Post-crawl hook
            await self.post_crawl(result)

        except Exception as e:
            self.logger.exception("Crawl failed", domain=domain, error=str(e))
            result.complete("failed", str(e))

        return result
