"""
Passive DNS Crawler for DNS-AID Agent Directory.

Discovers agents by querying passive DNS databases for DNS-AID record patterns.
This crawler finds agents that are ACTUALLY being queried (not just published),
providing real-world usage data and popularity metrics.

Key advantages over active crawling:
- Discovers agents without knowing domain names in advance
- Provides popularity scores from actual DNS query volumes
- Finds agents that may not have published an index record
"""

from __future__ import annotations

import contextlib
import re
from dataclasses import dataclass
from datetime import UTC, datetime

import structlog

from dns_aid.clients.pdns_base import PDNSProvider, PDNSRecord
from dns_aid.clients.pdns_mock import get_provider
from dns_aid.crawlers.base import BaseCrawler, CrawlResult, DiscoveredAgent
from dns_aid.crawlers.config import (
    ENABLE_PDNS_CRAWLER,
    PDNS_CONFIG,
    calculate_popularity_score,
    is_domain_blocked,
)

logger = structlog.get_logger(__name__)


@dataclass
class ParsedDNSAIDRecord:
    """Parsed components of a DNS-AID FQDN."""

    name: str  # Agent name (e.g., "chat")
    protocol: str  # Protocol (e.g., "mcp", "a2a")
    domain: str  # Base domain (e.g., "example.com")
    fqdn: str  # Full FQDN


def parse_dns_aid_fqdn(fqdn: str) -> ParsedDNSAIDRecord | None:
    """
    Parse a DNS-AID FQDN into its components.

    Format: _{name}._{protocol}._agents.{domain}

    Args:
        fqdn: Full DNS-AID record name

    Returns:
        ParsedDNSAIDRecord or None if not valid DNS-AID format
    """
    # Pattern: _{name}._{protocol}._agents.{domain}
    pattern = r"^_([a-z0-9-]+)\._([a-z0-9]+)\._agents\.(.+)$"
    match = re.match(pattern, fqdn.lower().rstrip("."))

    if not match:
        return None

    return ParsedDNSAIDRecord(
        name=match.group(1),
        protocol=match.group(2),
        domain=match.group(3),
        fqdn=fqdn.lower().rstrip("."),
    )


def parse_svcb_rdata(rdata: str) -> dict:
    """
    Parse SVCB record rdata into components.

    Format: "1 target.example.com. alpn=\"mcp\" port=443"

    Returns:
        Dict with priority, target, alpn, port, and other params
    """
    result = {
        "priority": 1,
        "target": "",
        "alpn": None,
        "port": 443,
    }

    parts = rdata.split()
    if len(parts) >= 2:
        with contextlib.suppress(ValueError):
            result["priority"] = int(parts[0])
        result["target"] = parts[1].rstrip(".")

    # Parse key=value params
    for part in parts[2:]:
        if "=" in part:
            key, value = part.split("=", 1)
            value = value.strip('"')
            if key == "alpn":
                result["alpn"] = value
            elif key == "port":
                with contextlib.suppress(ValueError):
                    result["port"] = int(value)
            else:
                result[key] = value

    return result


def parse_txt_rdata(rdata: str | list[str]) -> dict:
    """
    Parse TXT record rdata into components.

    Format: "capabilities=chat,code version=1.0.0"

    Returns:
        Dict with capabilities, version, and other fields
    """
    result: dict[str, list[str] | str | None] = {
        "capabilities": [],
        "version": None,
    }

    # Normalize to single string
    if isinstance(rdata, list):
        txt = " ".join(rdata)
    else:
        txt = rdata

    # Parse key=value pairs
    for part in txt.split():
        if "=" in part:
            key, value = part.split("=", 1)
            if key == "capabilities":
                result["capabilities"] = [c.strip() for c in value.split(",")]
            elif key == "version":
                result["version"] = value
            else:
                result[key] = value

    return result


class PassiveDNSCrawler(BaseCrawler):
    """
    Crawler that discovers agents via passive DNS databases.

    Uses pDNS data to find DNS-AID records that have been queried,
    providing popularity metrics based on actual usage.
    """

    def __init__(
        self,
        provider: PDNSProvider | None = None,
        provider_name: str | None = None,
    ):
        """
        Initialize the passive DNS crawler.

        Args:
            provider: PDNSProvider instance to use
            provider_name: Provider name to instantiate (if provider not given)
        """
        super().__init__(name="passive-dns")

        if provider:
            self._provider = provider
        else:
            name = provider_name or PDNS_CONFIG.default_provider
            self._provider = get_provider(name)

        self._protocols = ["mcp", "a2a", "https"]

    async def crawl(self, domain: str) -> CrawlResult:
        """
        Crawl a specific domain using pDNS data.

        Args:
            domain: Domain to search for agents

        Returns:
            CrawlResult with discovered agents and popularity scores
        """
        if not ENABLE_PDNS_CRAWLER:
            self.logger.info("Passive DNS crawler is disabled")
            result = CrawlResult(domain=domain, status="skipped")
            result.complete("skipped", "Passive DNS crawler disabled")
            return result

        if is_domain_blocked(domain):
            self.logger.warning("Domain is blocked", domain=domain)
            result = CrawlResult(domain=domain, status="blocked")
            result.complete("blocked", f"Domain {domain} is in blocklist")
            return result

        result = CrawlResult(domain=domain, status="running")
        agents_found: list[DiscoveredAgent] = []
        errors: list[str] = []

        # Query pDNS for DNS-AID records at this domain
        try:
            pdns_result = await self._provider.query_dns_aid_agents(
                domain=domain,
                limit=PDNS_CONFIG.max_records_per_pattern,
            )

            # Group records by FQDN to combine SVCB + TXT data
            records_by_fqdn = self._group_records_by_fqdn(pdns_result.records)

            # Convert to DiscoveredAgent objects
            for fqdn, records in records_by_fqdn.items():
                try:
                    agent = self._records_to_agent(fqdn, records)
                    if agent:
                        agents_found.append(agent)
                except Exception as e:
                    self.logger.warning(
                        "Failed to parse agent records",
                        fqdn=fqdn,
                        error=str(e),
                    )
                    errors.append(f"Parse error for {fqdn}: {e}")

            self.logger.info(
                "pDNS crawl completed",
                domain=domain,
                records_found=len(pdns_result.records),
                agents_found=len(agents_found),
            )

        except Exception as e:
            self.logger.exception("pDNS query failed", domain=domain, error=str(e))
            errors.append(f"pDNS query failed: {e}")

        # Set result
        result.agents_found = agents_found
        if agents_found and not errors:
            result.complete("success")
        elif agents_found and errors:
            result.complete("partial", "; ".join(errors))
        elif not errors:
            result.complete("success")  # No agents is valid
        else:
            result.complete("failed", "; ".join(errors))

        return result

    async def discover_all(
        self,
        protocol: str | None = None,
        limit: int = 1000,
    ) -> CrawlResult:
        """
        Discover all DNS-AID agents across all domains in pDNS.

        This is the primary discovery method - finds agents without
        knowing domain names in advance.

        Args:
            protocol: Optional protocol filter (mcp, a2a, https)
            limit: Maximum agents to return

        Returns:
            CrawlResult with all discovered agents
        """
        if not ENABLE_PDNS_CRAWLER:
            self.logger.info("Passive DNS crawler is disabled")
            result = CrawlResult(domain="*", status="skipped")
            result.complete("skipped", "Passive DNS crawler disabled")
            return result

        result = CrawlResult(domain="*", status="running")
        all_records: list[PDNSRecord] = []

        # Query each pattern
        patterns = PDNS_CONFIG.search_patterns
        if protocol:
            patterns = (f"*._{protocol}._agents.*",)

        for pattern in patterns:
            try:
                pdns_result = await self._provider.query_wildcard(
                    pattern,
                    limit=PDNS_CONFIG.max_records_per_pattern,
                )
                all_records.extend(pdns_result.records)

                self.logger.debug(
                    "Pattern query completed",
                    pattern=pattern,
                    records=len(pdns_result.records),
                )

            except Exception as e:
                self.logger.warning(
                    "Pattern query failed",
                    pattern=pattern,
                    error=str(e),
                )

        # Filter to DNS-AID records only
        dns_aid_records = [r for r in all_records if r.is_dns_aid_record]

        # Group by FQDN and convert to agents
        records_by_fqdn = self._group_records_by_fqdn(dns_aid_records)
        agents_found: list[DiscoveredAgent] = []

        for fqdn, records in records_by_fqdn.items():
            # Check domain blocklist
            parsed = parse_dns_aid_fqdn(fqdn)
            if parsed and is_domain_blocked(parsed.domain):
                continue

            try:
                agent = self._records_to_agent(fqdn, records)
                if agent:
                    agents_found.append(agent)
            except Exception as e:
                self.logger.debug(
                    "Failed to parse agent",
                    fqdn=fqdn,
                    error=str(e),
                )

        # Sort by popularity (highest first)
        agents_found.sort(key=lambda a: a.metadata.get("popularity_score", 0), reverse=True)
        agents_found = agents_found[:limit]

        result.agents_found = agents_found
        result.complete("success")

        self.logger.info(
            "Global pDNS discovery completed",
            total_records=len(all_records),
            dns_aid_records=len(dns_aid_records),
            agents_found=len(agents_found),
        )

        return result

    def _group_records_by_fqdn(
        self,
        records: list[PDNSRecord],
    ) -> dict[str, list[PDNSRecord]]:
        """Group pDNS records by FQDN."""
        grouped: dict[str, list[PDNSRecord]] = {}

        for record in records:
            fqdn = record.rrname.lower().rstrip(".")
            if fqdn not in grouped:
                grouped[fqdn] = []
            grouped[fqdn].append(record)

        return grouped

    def _records_to_agent(
        self,
        fqdn: str,
        records: list[PDNSRecord],
    ) -> DiscoveredAgent | None:
        """
        Convert pDNS records to a DiscoveredAgent.

        Combines data from SVCB and TXT records.
        """
        parsed = parse_dns_aid_fqdn(fqdn)
        if not parsed:
            return None

        # Find SVCB and TXT records
        svcb_record = None
        txt_record = None
        total_count = 0

        for record in records:
            if record.rrtype.upper() == "SVCB":
                svcb_record = record
            elif record.rrtype.upper() == "TXT":
                txt_record = record
            # Sum up query counts
            if record.count:
                total_count += record.count

        # Parse SVCB data
        endpoint_url = None
        port = 443
        if svcb_record:
            svcb_data = parse_svcb_rdata(
                svcb_record.rdata
                if isinstance(svcb_record.rdata, str)
                else " ".join(svcb_record.rdata)
            )
            if svcb_data["target"]:
                port = svcb_data.get("port", 443)
                endpoint_url = f"https://{svcb_data['target']}:{port}"

        # Parse TXT data
        capabilities = []
        version = None
        if txt_record:
            txt_data = parse_txt_rdata(txt_record.rdata)
            capabilities = txt_data.get("capabilities", [])
            version = txt_data.get("version")

        # Calculate popularity score
        popularity_score = calculate_popularity_score(total_count)

        # Get timestamps
        first_seen = None
        last_seen = None
        for record in records:
            if first_seen is None or record.time_first < first_seen:
                first_seen = record.time_first
            if last_seen is None or record.time_last > last_seen:
                last_seen = record.time_last

        return DiscoveredAgent(
            fqdn=fqdn,
            domain=parsed.domain,
            name=parsed.name,
            protocol=parsed.protocol,
            endpoint_url=endpoint_url,
            port=port,
            capabilities=capabilities,
            version=version,
            security_score=0,  # Will be filled by verification
            metadata={
                "source": "pdns",
                "provider": self._provider.name,
                "query_count": total_count,
                "popularity_score": popularity_score,
                "first_seen": datetime.fromtimestamp(first_seen, tz=UTC).isoformat()
                if first_seen
                else None,
                "last_seen": datetime.fromtimestamp(last_seen, tz=UTC).isoformat()
                if last_seen
                else None,
            },
        )

    async def close(self) -> None:
        """Clean up provider resources."""
        await self._provider.close()

    async def __aenter__(self) -> PassiveDNSCrawler:
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()
