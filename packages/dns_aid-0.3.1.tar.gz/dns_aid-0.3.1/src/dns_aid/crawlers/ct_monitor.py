"""
Certificate Transparency Log Monitor for DNS-AID Agent Directory.

Watches CT logs for new certificates that might indicate DNS-AID agents:
- Certificates for mcp.*, a2a.*, agent.* subdomains
- Any certificate with *._agents.* in the SAN

When matching certificates are found, the base domain is queued
for crawling by the submission crawler.

This is a STREAMING service designed to run continuously (Fargate).

CT Log Sources:
- Google Argon/Xenon logs
- Cloudflare Nimbus
- DigiCert logs
- Let's Encrypt logs

Integration options:
1. certstream (websocket stream) - Easiest, real-time
2. Direct CT log API polling - More control, batched
3. crt.sh API - Historical search
"""

from __future__ import annotations

import asyncio
import fnmatch
import re
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime

import structlog

from dns_aid.crawlers.config import CT_LOG_CONFIG, ENABLE_CT_MONITOR, is_domain_blocked

logger = structlog.get_logger(__name__)


@dataclass
class CTLogEntry:
    """A Certificate Transparency log entry."""

    # Certificate details
    serial_number: str
    issuer: str
    not_before: datetime
    not_after: datetime

    # Domain information
    common_name: str
    san_domains: list[str] = field(default_factory=list)

    # CT log metadata
    log_name: str = ""
    log_index: int = 0
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))

    @property
    def all_domains(self) -> list[str]:
        """All domains from CN and SANs."""
        domains = set(self.san_domains)
        if self.common_name:
            domains.add(self.common_name)
        return list(domains)


@dataclass
class CTMatch:
    """A matched CT entry that looks like a DNS-AID related domain."""

    entry: CTLogEntry
    matched_domain: str
    matched_pattern: str
    base_domain: str  # Extracted base domain for crawling


def extract_base_domain(domain: str) -> str:
    """
    Extract the base domain from a subdomain.

    Examples:
        mcp.example.com -> example.com
        _chat._mcp._agents.example.com -> example.com
        api.sub.example.co.uk -> example.co.uk (simplified)
    """
    domain = domain.lower().strip().rstrip(".")

    # Remove leading underscores (DNS-AID convention)
    parts = [p for p in domain.split(".") if not p.startswith("_")]

    # Simple heuristic: take last 2-3 parts depending on TLD
    # This is simplified - production would use publicsuffix list
    two_part_tlds = {"co.uk", "com.au", "co.nz", "co.jp", "com.br"}

    if len(parts) >= 3:
        potential_tld = ".".join(parts[-2:])
        if potential_tld in two_part_tlds:
            return ".".join(parts[-3:])

    if len(parts) >= 2:
        return ".".join(parts[-2:])

    return domain


def matches_pattern(domain: str, pattern: str) -> bool:
    """
    Check if domain matches a glob pattern.

    Patterns like: mcp.*, *._agents.*, agent.*
    """
    # Convert glob to regex
    regex_pattern = fnmatch.translate(pattern.lower())
    return bool(re.match(regex_pattern, domain.lower()))


class CTLogSource(ABC):
    """Abstract base for CT log data sources."""

    @abstractmethod
    def stream_entries(self) -> AsyncIterator[CTLogEntry]:
        """Stream CT log entries. Implementations should be async generators."""
        ...

    @abstractmethod
    async def health_check(self) -> bool:
        """Check if source is available."""
        pass

    async def close(self) -> None:
        """Clean up resources. Default no-op implementation."""
        return None  # noqa: B027


class MockCTLogSource(CTLogSource):
    """
    Mock CT log source for testing.

    Generates sample entries that simulate real CT log data.
    """

    def __init__(self, entries_per_batch: int = 10, delay_seconds: float = 1.0):
        """
        Initialize mock source.

        Args:
            entries_per_batch: Number of entries to generate per batch
            delay_seconds: Delay between batches
        """
        self._entries_per_batch = entries_per_batch
        self._delay_seconds = delay_seconds
        self._running = False
        self._batch_count = 0

    async def stream_entries(self) -> AsyncIterator[CTLogEntry]:
        """Generate mock CT log entries."""
        self._running = True

        # Sample domains that might appear in CT logs
        sample_domains = [
            # DNS-AID related (should match)
            "mcp.example.com",
            "a2a.acme.io",
            "agent.startup.dev",
            "_chat._mcp._agents.enterprise.com",
            "mcp-server.techcorp.net",
            "agents.bigcompany.com",
            # Non-matching (noise)
            "www.example.com",
            "api.regular.com",
            "mail.company.org",
            "cdn.website.net",
            "shop.store.com",
        ]

        while self._running:
            self._batch_count += 1

            for i in range(self._entries_per_batch):
                # Cycle through sample domains
                domain = sample_domains[(self._batch_count * i) % len(sample_domains)]

                yield CTLogEntry(
                    serial_number=f"mock-{self._batch_count}-{i}",
                    issuer="Mock CA",
                    not_before=datetime.now(UTC),
                    not_after=datetime.now(UTC),
                    common_name=domain,
                    san_domains=[domain, f"www.{domain}"],
                    log_name="mock-log",
                    log_index=self._batch_count * self._entries_per_batch + i,
                )

            await asyncio.sleep(self._delay_seconds)

            # Stop after a few batches in test mode
            if self._batch_count >= 5:
                self._running = False

    async def health_check(self) -> bool:
        """Mock source is always healthy."""
        return True

    def stop(self) -> None:
        """Stop the mock stream."""
        self._running = False


class CTMonitor:
    """
    Certificate Transparency log monitor.

    Watches CT logs for certificates that might indicate DNS-AID agents
    and queues matching domains for crawling.
    """

    def __init__(
        self,
        source: CTLogSource | None = None,
        patterns: list[str] | None = None,
        on_match: Callable[[CTMatch], None] | None = None,
    ):
        """
        Initialize CT monitor.

        Args:
            source: CT log source (defaults to mock for testing)
            patterns: Domain patterns to match
            on_match: Callback function when a match is found
        """
        self._source = source or MockCTLogSource()
        self._patterns = patterns or list(CT_LOG_CONFIG.match_patterns)
        self._on_match = on_match
        self._matches: list[CTMatch] = []
        self._running = False
        self._entries_processed = 0
        self.logger = logger.bind(component="ct-monitor")

    @property
    def matches(self) -> list[CTMatch]:
        """Get all matches found."""
        return self._matches.copy()

    @property
    def unique_domains(self) -> set[str]:
        """Get unique base domains from matches."""
        return {m.base_domain for m in self._matches}

    async def start(self) -> None:
        """
        Start monitoring CT logs.

        This runs continuously until stop() is called.
        """
        if not ENABLE_CT_MONITOR:
            self.logger.info("CT monitor is disabled")
            return

        self._running = True
        self.logger.info(
            "Starting CT log monitoring",
            patterns=self._patterns,
        )

        try:
            async for entry in self._source.stream_entries():  # type: ignore[attr-defined]
                if not self._running:
                    break

                self._entries_processed += 1
                await self._process_entry(entry)

        except Exception as e:
            self.logger.exception("CT monitoring error", error=str(e))
        finally:
            self._running = False

    async def _process_entry(self, entry: CTLogEntry) -> None:
        """Process a single CT log entry."""
        for domain in entry.all_domains:
            for pattern in self._patterns:
                if matches_pattern(domain, pattern):
                    base_domain = extract_base_domain(domain)

                    # Skip blocked domains
                    if is_domain_blocked(base_domain):
                        continue

                    match = CTMatch(
                        entry=entry,
                        matched_domain=domain,
                        matched_pattern=pattern,
                        base_domain=base_domain,
                    )

                    self._matches.append(match)

                    self.logger.info(
                        "CT match found",
                        domain=domain,
                        pattern=pattern,
                        base_domain=base_domain,
                    )

                    if self._on_match:
                        self._on_match(match)

                    # Only match once per domain
                    break

    def stop(self) -> None:
        """Stop monitoring."""
        self._running = False
        self.logger.info(
            "Stopping CT monitor",
            entries_processed=self._entries_processed,
            matches_found=len(self._matches),
        )

    async def run_batch(self, max_entries: int = 1000) -> list[CTMatch]:
        """
        Run a single batch of CT log processing.

        Useful for scheduled/Lambda execution instead of continuous streaming.

        Args:
            max_entries: Maximum entries to process

        Returns:
            List of matches found
        """
        if not ENABLE_CT_MONITOR:
            self.logger.info("CT monitor is disabled")
            return []

        self._running = True
        batch_matches: list[CTMatch] = []
        count = 0

        self.logger.info("Starting CT batch processing", max_entries=max_entries)

        try:
            async for entry in self._source.stream_entries():  # type: ignore[attr-defined]
                if not self._running or count >= max_entries:
                    break

                count += 1
                self._entries_processed += 1

                # Check for matches
                for domain in entry.all_domains:
                    for pattern in self._patterns:
                        if matches_pattern(domain, pattern):
                            base_domain = extract_base_domain(domain)

                            if is_domain_blocked(base_domain):
                                continue

                            match = CTMatch(
                                entry=entry,
                                matched_domain=domain,
                                matched_pattern=pattern,
                                base_domain=base_domain,
                            )

                            batch_matches.append(match)
                            self._matches.append(match)

                            if self._on_match:
                                self._on_match(match)

                            break

        except Exception as e:
            self.logger.exception("CT batch error", error=str(e))
        finally:
            self._running = False

        self.logger.info(
            "CT batch completed",
            entries_processed=count,
            matches_found=len(batch_matches),
        )

        return batch_matches

    async def close(self) -> None:
        """Clean up resources."""
        self.stop()
        await self._source.close()

    async def __aenter__(self) -> CTMonitor:
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()
