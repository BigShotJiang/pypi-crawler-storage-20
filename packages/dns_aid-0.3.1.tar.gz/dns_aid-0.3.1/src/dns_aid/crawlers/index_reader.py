"""
Index Reader Crawler for DNS-AID Agent Directory.

Reads the _index._agents.{domain} TXT record to efficiently discover
all agents published at a domain with a single DNS query.

This is the PRIMARY active discovery method - most efficient when
domains publish an index record listing their agents.

Index Record Format:
    _index._agents.example.com. TXT "agents=chat:mcp,assistant:a2a,api:https"

Each entry is: {name}:{protocol}
"""

from __future__ import annotations

from dataclasses import dataclass

import dns.asyncresolver
import dns.resolver
import structlog

from dns_aid.core.discoverer import discover
from dns_aid.core.validator import verify
from dns_aid.crawlers.base import BaseCrawler, CrawlResult, DiscoveredAgent
from dns_aid.crawlers.config import DNS_QUERY_CONFIG, is_domain_blocked

logger = structlog.get_logger(__name__)


@dataclass
class AgentRef:
    """Reference to an agent from an index record."""

    name: str
    protocol: str


async def read_index(domain: str) -> list[AgentRef] | None:
    """
    Read _index._agents.{domain} TXT record.

    The index record is the most efficient way to discover agents -
    a single DNS query returns all agent names and protocols.

    Format: "agents=network:mcp,chat:a2a,billing:https"

    Args:
        domain: Domain to read index from

    Returns:
        List of AgentRef objects, or None if no index exists
    """
    fqdn = f"_index._agents.{domain}"

    try:
        resolver = dns.asyncresolver.Resolver()
        resolver.timeout = DNS_QUERY_CONFIG.timeout_seconds
        resolver.lifetime = DNS_QUERY_CONFIG.timeout_seconds * 2

        answers = await resolver.resolve(fqdn, "TXT")

        for rdata in answers:
            for txt_string in rdata.strings:
                txt = txt_string.decode("utf-8")

                # Parse "agents=name:proto,name:proto,..."
                if txt.startswith("agents="):
                    agents_str = txt[len("agents=") :]
                    refs = []

                    for entry in agents_str.split(","):
                        entry = entry.strip()
                        if ":" in entry:
                            parts = entry.split(":", 1)
                            refs.append(
                                AgentRef(
                                    name=parts[0].strip(),
                                    protocol=parts[1].strip().lower(),
                                )
                            )

                    logger.debug(
                        "Index record parsed",
                        domain=domain,
                        agent_count=len(refs),
                    )
                    return refs

    except dns.resolver.NXDOMAIN:
        logger.debug("No index record found", domain=domain)
    except dns.resolver.NoAnswer:
        logger.debug("No TXT answer for index", domain=domain)
    except dns.resolver.NoNameservers:
        logger.warning("No nameservers for domain", domain=domain)
    except dns.exception.Timeout:
        logger.warning("DNS timeout reading index", domain=domain)
    except Exception as e:
        logger.warning("Index read failed", domain=domain, error=str(e))

    return None


async def index_exists(domain: str) -> bool:
    """
    Check if a domain has an index record.

    Args:
        domain: Domain to check

    Returns:
        True if _index._agents.{domain} exists
    """
    refs = await read_index(domain)
    return refs is not None


class IndexReaderCrawler(BaseCrawler):
    """
    Crawler that discovers agents via the _index._agents.* record.

    This is the most efficient active discovery method:
    1. Query _index._agents.{domain} TXT (1 DNS query)
    2. Parse to get list of all agent names and protocols
    3. Query each agent individually for full details

    Falls back to pattern probing if no index is published.
    """

    def __init__(self, verify_agents: bool = True):
        """
        Initialize the index reader crawler.

        Args:
            verify_agents: Whether to verify each discovered agent
        """
        super().__init__(name="index-reader")
        self._verify_agents = verify_agents

    async def crawl(self, domain: str) -> CrawlResult:
        """
        Crawl a domain using its index record.

        Args:
            domain: Domain to crawl

        Returns:
            CrawlResult with discovered agents
        """
        if is_domain_blocked(domain):
            self.logger.warning("Domain is blocked", domain=domain)
            result = CrawlResult(domain=domain, status="blocked")
            result.complete("blocked", f"Domain {domain} is in blocklist")
            return result

        result = CrawlResult(domain=domain, status="running")
        agents_found: list[DiscoveredAgent] = []
        errors: list[str] = []

        # Read index record
        refs = await read_index(domain)

        if refs is None:
            self.logger.info(
                "No index record found, will need pattern probing",
                domain=domain,
            )
            result.complete("success")  # No index is not an error
            result.error_message = "No index record published"
            return result

        self.logger.info(
            "Index record found",
            domain=domain,
            agents=len(refs),
        )

        # Discover each agent from the index
        for ref in refs:
            try:
                self.logger.debug(
                    "Discovering agent from index",
                    name=ref.name,
                    protocol=ref.protocol,
                )

                # Use core discovery function
                discovery_result = await discover(
                    domain=domain,
                    protocol=ref.protocol,
                    name=ref.name,
                )

                for agent in discovery_result.agents:
                    # Optionally verify the agent
                    security_score = 0
                    metadata = {"source": "index"}

                    if self._verify_agents:
                        try:
                            verification = await verify(agent.fqdn)
                            security_score = verification.security_score
                            metadata.update(
                                {
                                    "dnssec_valid": str(verification.dnssec_valid),
                                    "dane_valid": str(verification.dane_valid),
                                    "endpoint_reachable": str(verification.endpoint_reachable),
                                    "svcb_valid": str(verification.svcb_valid),
                                }
                            )
                        except Exception as e:
                            self.logger.warning(
                                "Agent verification failed",
                                fqdn=agent.fqdn,
                                error=str(e),
                            )

                    discovered = DiscoveredAgent(
                        fqdn=agent.fqdn,
                        domain=domain,
                        name=agent.name,
                        protocol=ref.protocol,
                        endpoint_url=agent.endpoint_url,
                        port=agent.port or 443,
                        capabilities=agent.capabilities or [],
                        version=agent.version,
                        security_score=security_score,
                        metadata=metadata,
                    )
                    agents_found.append(discovered)

                    self.logger.info(
                        "Agent discovered via index",
                        fqdn=agent.fqdn,
                        protocol=ref.protocol,
                        security_score=security_score,
                    )

            except Exception as e:
                self.logger.warning(
                    "Failed to discover agent from index",
                    name=ref.name,
                    protocol=ref.protocol,
                    error=str(e),
                )
                errors.append(f"Discovery failed for {ref.name}:{ref.protocol}: {e}")

        # Set result
        result.agents_found = agents_found

        if agents_found and not errors:
            result.complete("success")
        elif agents_found and errors:
            result.complete("partial", "; ".join(errors))
        elif not errors:
            result.complete("success")  # Index exists but no agents found
        else:
            result.complete("failed", "; ".join(errors))

        return result

    async def has_index(self, domain: str) -> bool:
        """
        Check if a domain publishes an index record.

        Args:
            domain: Domain to check

        Returns:
            True if index exists
        """
        return await index_exists(domain)
