"""
Crawler configuration and feature flags for DNS-AID Agent Directory.

Configuration can be overridden via environment variables.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


def _env_bool(key: str, default: bool = False) -> bool:
    """Get boolean from environment variable."""
    val = os.environ.get(key, "").lower()
    if val in ("true", "1", "yes", "on"):
        return True
    if val in ("false", "0", "no", "off"):
        return False
    return default


def _env_int(key: str, default: int) -> int:
    """Get integer from environment variable."""
    try:
        return int(os.environ.get(key, default))
    except (TypeError, ValueError):
        return default


def _env_float(key: str, default: float) -> float:
    """Get float from environment variable."""
    try:
        return float(os.environ.get(key, default))
    except (TypeError, ValueError):
        return default


def _env_list(key: str, default: list[str]) -> list[str]:
    """Get list from comma-separated environment variable."""
    val = os.environ.get(key)
    if val:
        return [item.strip() for item in val.split(",") if item.strip()]
    return default


# =============================================================================
# FEATURE FLAGS
# =============================================================================

# NSEC Zone Walker - controversial feature, can be disabled if IETF objects
# Zone enumeration via NSEC walking may raise privacy concerns
ENABLE_NSEC_WALKER: bool = _env_bool("DNS_AID_ENABLE_NSEC_WALKER", default=False)

# Certificate Transparency monitoring
ENABLE_CT_MONITOR: bool = _env_bool("DNS_AID_ENABLE_CT_MONITOR", default=True)

# Passive DNS discovery
ENABLE_PDNS_CRAWLER: bool = _env_bool("DNS_AID_ENABLE_PDNS_CRAWLER", default=True)

# Pattern probing (fallback when no index)
ENABLE_PATTERN_PROBER: bool = _env_bool("DNS_AID_ENABLE_PATTERN_PROBER", default=True)


# =============================================================================
# DNS QUERY SETTINGS
# =============================================================================


@dataclass(frozen=True)
class DNSQueryConfig:
    """DNS query safety settings."""

    # Query timeout in seconds
    timeout_seconds: float = 10.0

    # Maximum retry attempts
    max_retries: int = 3

    # Delay between retries (exponential backoff base)
    retry_delay_seconds: float = 1.0

    # Maximum concurrent DNS queries per crawler
    max_concurrent_queries: int = 50


DNS_QUERY_CONFIG = DNSQueryConfig(
    timeout_seconds=_env_float("DNS_AID_QUERY_TIMEOUT", 10.0),
    max_retries=_env_int("DNS_AID_QUERY_MAX_RETRIES", 3),
    retry_delay_seconds=_env_float("DNS_AID_QUERY_RETRY_DELAY", 1.0),
    max_concurrent_queries=_env_int("DNS_AID_MAX_CONCURRENT_QUERIES", 50),
)


# =============================================================================
# RATE LIMITING
# =============================================================================


@dataclass(frozen=True)
class RateLimitConfig:
    """Rate limiting settings to prevent abuse."""

    # Maximum DNS queries per second per domain
    queries_per_second_per_domain: float = 10.0

    # Maximum DNS queries per second globally
    queries_per_second_global: float = 100.0

    # Maximum domains to crawl per minute
    domains_per_minute: int = 60

    # Cooldown period for a domain after crawling (seconds)
    domain_cooldown_seconds: int = 300


RATE_LIMIT_CONFIG = RateLimitConfig(
    queries_per_second_per_domain=_env_float("DNS_AID_RATE_LIMIT_PER_DOMAIN", 10.0),
    queries_per_second_global=_env_float("DNS_AID_RATE_LIMIT_GLOBAL", 100.0),
    domains_per_minute=_env_int("DNS_AID_DOMAINS_PER_MINUTE", 60),
    domain_cooldown_seconds=_env_int("DNS_AID_DOMAIN_COOLDOWN", 300),
)


# =============================================================================
# SCHEDULER SETTINGS
# =============================================================================


@dataclass(frozen=True)
class SchedulerConfig:
    """Scheduler settings for automated crawling."""

    # Re-crawl interval in seconds (default: 6 hours)
    recrawl_interval_seconds: int = 6 * 60 * 60

    # Convenience property for hours
    @property
    def recrawl_interval_hours(self) -> float:
        """Re-crawl interval in hours."""
        return self.recrawl_interval_seconds / 3600

    # Maximum domains to process per scheduler run
    max_domains_per_run: int = 1000

    # Maximum concurrent crawls
    max_concurrent_crawls: int = 10

    # Priority boost for recently submitted domains
    new_domain_priority_boost: int = 10

    # Maximum age of a crawl before it's considered stale (seconds)
    stale_crawl_threshold_seconds: int = 24 * 60 * 60

    # Whether to automatically schedule re-crawls after completing
    auto_recrawl: bool = True


SCHEDULER_CONFIG = SchedulerConfig(
    recrawl_interval_seconds=_env_int("DNS_AID_RECRAWL_INTERVAL", 6 * 60 * 60),
    max_domains_per_run=_env_int("DNS_AID_MAX_DOMAINS_PER_RUN", 1000),
    max_concurrent_crawls=_env_int("DNS_AID_MAX_CONCURRENT_CRAWLS", 10),
    new_domain_priority_boost=_env_int("DNS_AID_NEW_DOMAIN_PRIORITY", 10),
    stale_crawl_threshold_seconds=_env_int("DNS_AID_STALE_THRESHOLD", 24 * 60 * 60),
    auto_recrawl=_env_bool("DNS_AID_AUTO_RECRAWL", True),
)


# =============================================================================
# PATTERN PROBER SETTINGS
# =============================================================================

# Common agent names to probe when no index is available
DEFAULT_PROBE_NAMES: list[str] = _env_list(
    "DNS_AID_PROBE_NAMES",
    [
        "assistant",
        "chat",
        "api",
        "agent",
        "help",
        "support",
        "bot",
        "ai",
        "service",
        "mcp",
    ],
)

# Protocols to probe for each name
DEFAULT_PROBE_PROTOCOLS: list[str] = _env_list(
    "DNS_AID_PROBE_PROTOCOLS",
    ["mcp", "a2a"],
)


# =============================================================================
# PASSIVE DNS SETTINGS
# =============================================================================


@dataclass(frozen=True)
class PDNSConfig:
    """Passive DNS crawler settings."""

    # Default provider (infoblox, farsight, securitytrails, mock)
    default_provider: str = "mock"

    # Search patterns for DNS-AID records
    search_patterns: tuple[str, ...] = (
        "*._mcp._agents.*",
        "*._a2a._agents.*",
        "*._https._agents.*",
    )

    # Minimum query count to consider an agent "popular"
    popularity_threshold: int = 100

    # Maximum records to fetch per pattern
    max_records_per_pattern: int = 10000


PDNS_CONFIG = PDNSConfig(
    default_provider=os.environ.get("DNS_AID_PDNS_PROVIDER", "mock"),
    popularity_threshold=_env_int("DNS_AID_PDNS_POPULARITY_THRESHOLD", 100),
    max_records_per_pattern=_env_int("DNS_AID_PDNS_MAX_RECORDS", 10000),
)


# =============================================================================
# CT LOG SETTINGS
# =============================================================================


@dataclass(frozen=True)
class CTLogConfig:
    """Certificate Transparency log monitoring settings."""

    # CT log URLs to monitor
    log_urls: tuple[str, ...] = (
        "https://ct.googleapis.com/logs/argon2024/",
        "https://ct.googleapis.com/logs/xenon2024/",
        "https://ct.cloudflare.com/logs/nimbus2024/",
    )

    # Patterns to match in certificate SANs
    match_patterns: tuple[str, ...] = (
        "mcp.*",
        "agent.*",
        "a2a.*",
        "*._agents.*",
    )

    # Batch size for processing CT entries
    batch_size: int = 100

    # Polling interval in seconds
    poll_interval_seconds: int = 60


CT_LOG_CONFIG = CTLogConfig(
    batch_size=_env_int("DNS_AID_CT_BATCH_SIZE", 100),
    poll_interval_seconds=_env_int("DNS_AID_CT_POLL_INTERVAL", 60),
)


# =============================================================================
# ABUSE PREVENTION
# =============================================================================

# Domains to never crawl (blocklist)
BLOCKED_DOMAINS: set[str] = set(
    _env_list(
        "DNS_AID_BLOCKED_DOMAINS",
        [
            "localhost",
            "example.com",
            "example.org",
            "example.net",
            "test",
            "local",
            "invalid",
        ],
    )
)

# TLDs to never crawl
BLOCKED_TLDS: set[str] = set(
    _env_list(
        "DNS_AID_BLOCKED_TLDS",
        [
            "test",
            "local",
            "localhost",
            "invalid",
            "example",
            "onion",
        ],
    )
)


def is_domain_blocked(domain: str) -> bool:
    """Check if a domain should not be crawled."""
    domain_lower = domain.lower().rstrip(".")

    # Check exact blocklist
    if domain_lower in BLOCKED_DOMAINS:
        return True

    # Check TLD blocklist
    parts = domain_lower.split(".")
    return bool(parts and parts[-1] in BLOCKED_TLDS)


# =============================================================================
# POPULARITY SCORING
# =============================================================================


def calculate_popularity_score(query_count: int) -> int:
    """
    Calculate popularity score from pDNS query count.

    Uses logarithmic scale:
    - 1M queries = 100
    - 100K queries = 83
    - 10K queries = 67
    - 1K queries = 50
    - 100 queries = 33
    - 10 queries = 17
    - 1 query = 0

    Args:
        query_count: Number of DNS queries observed

    Returns:
        Score from 0-100
    """
    import math

    if query_count <= 0:
        return 0

    # Logarithmic scale: log10(1M) * 16.67 = 100
    score = int(math.log10(query_count) * 16.67)
    return min(100, max(0, score))
