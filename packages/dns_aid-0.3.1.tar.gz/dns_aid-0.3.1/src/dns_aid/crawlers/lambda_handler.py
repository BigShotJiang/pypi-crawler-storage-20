"""
AWS Lambda Handler for DNS-AID Crawler.

Processes crawl jobs from SQS queue:
- crawl-jobs: New domain submissions, CT detections
- recrawl-jobs: Scheduled re-crawls

This handler is triggered by SQS event source mapping.

IMPORTANT: Discovered agents are persisted to RDS PostgreSQL
via AgentRepository.upsert() for searchability via the API.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

import structlog
from aws_lambda_powertools import Logger, Metrics, Tracer
from aws_lambda_powertools.metrics import MetricUnit
from aws_lambda_powertools.utilities.typing import LambdaContext

from dns_aid.crawlers.base import CrawlResult
from dns_aid.crawlers.config import (
    ENABLE_CT_MONITOR,
    ENABLE_NSEC_WALKER,
    ENABLE_PDNS_CRAWLER,
)
from dns_aid.crawlers.scheduler import (
    CrawlJob,
    CrawlPriority,
    CrawlScheduler,
)
from dns_aid.directory.database import ensure_database_initialized
from dns_aid.directory.repository import AgentRepository, CrawlHistoryRepository, DomainRepository

# Initialize AWS Lambda Powertools
logger = Logger(service="dns-aid-crawler")
tracer = Tracer(service="dns-aid-crawler")
metrics = Metrics(namespace="DNS-AID", service="crawler")

# Structlog for application-level logging
app_logger = structlog.get_logger(__name__)


async def _store_crawl_results(result: CrawlResult) -> dict[str, int]:
    """
    Store discovered agents in the database.

    This is the critical piece that makes agents searchable via the API.
    Without this, agents are discovered but never persisted.

    Args:
        result: CrawlResult containing discovered agents

    Returns:
        dict with counts: agents_added, agents_updated
    """
    if not result.agents_found:
        app_logger.debug("No agents to store", domain=result.domain)
        return {"agents_added": 0, "agents_updated": 0}

    try:
        # Get database connection (auto-initializes with IAM auth)
        db = await ensure_database_initialized()

        async with db.session() as session:
            agent_repo = AgentRepository(session)
            domain_repo = DomainRepository(session)
            crawl_repo = CrawlHistoryRepository(session)

            agents_added = 0
            agents_updated = 0

            # First, ensure domain exists (required for foreign key constraints)
            existing_domain = await domain_repo.get(result.domain)
            if not existing_domain:
                app_logger.info(
                    "Creating domain record for crawler-discovered domain",
                    domain=result.domain,
                )
                try:
                    await domain_repo.create(result.domain)
                    await session.flush()  # Ensure domain is in DB before crawl_history
                except Exception as e:
                    app_logger.warning(
                        "Could not create domain record (may already exist)",
                        domain=result.domain,
                        error=str(e),
                    )

            # Start crawl history record (now domain exists)
            crawl_record = await crawl_repo.create(result.domain)

            # Store each discovered agent
            for agent in result.agents_found:
                try:
                    stored_agent, was_created = await agent_repo.upsert(
                        fqdn=agent.fqdn,
                        domain=agent.domain,
                        name=agent.name,
                        protocol=agent.protocol,
                        endpoint_url=agent.endpoint_url,
                        port=agent.port,
                        capabilities=agent.capabilities,
                        version=agent.version,
                        security_score=agent.security_score,
                        metadata=agent.metadata,
                    )

                    if was_created:
                        agents_added += 1
                        app_logger.info(
                            "Agent stored (new)",
                            fqdn=agent.fqdn,
                            protocol=agent.protocol,
                            security_score=agent.security_score,
                        )
                    else:
                        agents_updated += 1
                        app_logger.info(
                            "Agent stored (updated)",
                            fqdn=agent.fqdn,
                            protocol=agent.protocol,
                            security_score=agent.security_score,
                        )

                except Exception as e:
                    app_logger.error(
                        "Failed to store agent",
                        fqdn=agent.fqdn,
                        error=str(e),
                    )
                    # Continue with other agents even if one fails

            # Update domain crawl status (domain was ensured to exist above)
            await domain_repo.update_crawl_status(
                result.domain,
                status=result.status,
                agent_count=len(result.agents_found),
            )

            # Complete crawl history
            await crawl_repo.complete(
                crawl_id=crawl_record.id,
                status=result.status,
                agents_found=len(result.agents_found),
                agents_added=agents_added,
                agents_updated=agents_updated,
                error_message=result.error_message,
            )

            # Commit is handled by db.session() context manager
            app_logger.info(
                "Crawl results stored",
                domain=result.domain,
                agents_added=agents_added,
                agents_updated=agents_updated,
            )

            return {"agents_added": agents_added, "agents_updated": agents_updated}

    except Exception as e:
        app_logger.error(
            "Failed to store crawl results",
            domain=result.domain,
            error=str(e),
        )
        # Re-raise to let caller handle
        raise


def _parse_sqs_message(record: dict[str, Any]) -> CrawlJob | None:
    """
    Parse an SQS record into a CrawlJob.

    Expected message body format:
    {
        "domain": "example.com",
        "priority": "NORMAL",  # Optional
        "source": "submission"  # Optional: submission, ct_log, pdns, scheduled
    }
    """
    try:
        body = json.loads(record["body"])
        domain = body.get("domain")

        if not domain:
            app_logger.warning("SQS message missing domain", record_id=record.get("messageId"))
            return None

        # Parse priority (default NORMAL)
        priority_str = body.get("priority", "NORMAL").upper()
        try:
            priority = CrawlPriority[priority_str]
        except KeyError:
            priority = CrawlPriority.NORMAL

        source = body.get("source", "manual")

        return CrawlJob(
            domain=domain,
            priority=priority,
            source=source,
        )

    except json.JSONDecodeError as e:
        app_logger.error(
            "Failed to parse SQS message", error=str(e), record_id=record.get("messageId")
        )
        return None


async def _process_crawl_job(job: CrawlJob) -> dict[str, Any]:
    """
    Process a single crawl job.

    Uses the CrawlScheduler to coordinate multiple crawlers:
    - IndexReaderCrawler (primary)
    - PatternProberCrawler (fallback)
    - PassiveDNSCrawler (if enabled)

    After discovery, agents are stored in RDS PostgreSQL for API searchability.
    """
    scheduler = CrawlScheduler()

    # Submit the domain to the scheduler's queue
    scheduler.submit_domain(
        domain=job.domain,
        priority=job.priority,
        source=job.source,
    )

    # Process the job we just added
    result = await scheduler.process_one()

    if result is None:
        return {
            "domain": job.domain,
            "status": "failed",
            "agents_found": 0,
            "agents_added": 0,
            "agents_updated": 0,
            "error": "No result returned from scheduler",
        }

    # CRITICAL: Store discovered agents in database for API searchability
    # This was previously missing - agents were discovered but never persisted!
    storage_counts = {"agents_added": 0, "agents_updated": 0}
    if result.agents_found:
        try:
            storage_counts = await _store_crawl_results(result)
            app_logger.info(
                "Agents persisted to database",
                domain=job.domain,
                agents_found=len(result.agents_found),
                agents_added=storage_counts["agents_added"],
                agents_updated=storage_counts["agents_updated"],
            )
        except Exception as e:
            app_logger.error(
                "Failed to persist agents - they will NOT be searchable via API",
                domain=job.domain,
                error=str(e),
            )
            # Don't fail the whole job - discovery still succeeded
            # But mark it as partial success

    return {
        "domain": job.domain,
        "status": result.status,  # Already a string: "success", "partial", "failed"
        "agents_found": len(result.agents_found),
        "agents_added": storage_counts["agents_added"],
        "agents_updated": storage_counts["agents_updated"],
        "error": result.error_message,
    }


@tracer.capture_lambda_handler
@logger.inject_lambda_context
@metrics.log_metrics(capture_cold_start_metric=True)
def handler(event: dict[str, Any], context: LambdaContext) -> dict[str, Any]:
    """
    AWS Lambda entry point for crawler.

    Triggered by SQS with batch of crawl jobs.

    Args:
        event: SQS event with Records array
        context: Lambda context

    Returns:
        Processing results summary
    """
    logger.info("Crawler Lambda invoked", record_count=len(event.get("Records", [])))

    # Log feature flags for debugging
    logger.debug(
        "Feature flags",
        enable_pdns=ENABLE_PDNS_CRAWLER,
        enable_ct=ENABLE_CT_MONITOR,
        enable_nsec=ENABLE_NSEC_WALKER,
    )

    records = event.get("Records", [])
    if not records:
        logger.warning("No records to process")
        return {"statusCode": 200, "body": "No records"}

    # Parse SQS messages into CrawlJobs
    jobs: list[CrawlJob] = []
    for record in records:
        job = _parse_sqs_message(record)
        if job:
            jobs.append(job)
            metrics.add_metric(name="JobsReceived", unit=MetricUnit.Count, value=1)

    if not jobs:
        logger.warning("No valid jobs after parsing")
        return {"statusCode": 200, "body": "No valid jobs"}

    # Process jobs asynchronously
    results = []
    failed_count = 0
    success_count = 0

    for job in jobs:
        try:
            result = asyncio.run(_process_crawl_job(job))
            results.append(result)

            if result.get("status") in ("success", "partial"):
                success_count += 1
                metrics.add_metric(name="JobsSucceeded", unit=MetricUnit.Count, value=1)
                metrics.add_metric(
                    name="AgentsDiscovered",
                    unit=MetricUnit.Count,
                    value=result.get("agents_found", 0),
                )
                # Track database persistence metrics
                metrics.add_metric(
                    name="AgentsStored",
                    unit=MetricUnit.Count,
                    value=result.get("agents_added", 0) + result.get("agents_updated", 0),
                )
            else:
                failed_count += 1
                metrics.add_metric(name="JobsFailed", unit=MetricUnit.Count, value=1)

        except Exception as e:
            logger.exception("Job processing failed", domain=job.domain, error=str(e))
            failed_count += 1
            metrics.add_metric(name="JobsFailed", unit=MetricUnit.Count, value=1)
            results.append(
                {
                    "domain": job.domain,
                    "status": "error",
                    "error": str(e),
                }
            )

    logger.info(
        "Crawler batch complete",
        total_jobs=len(jobs),
        succeeded=success_count,
        failed=failed_count,
    )

    # Return batch processing result
    # Note: SQS handles message deletion on success
    return {
        "statusCode": 200,
        "batchItemFailures": [],  # SQS partial batch response
        "body": {
            "processed": len(jobs),
            "succeeded": success_count,
            "failed": failed_count,
            "results": results,
        },
    }


# For local testing
if __name__ == "__main__":
    # Example SQS event
    test_event = {
        "Records": [
            {
                "messageId": "test-1",
                "body": json.dumps(
                    {
                        "domain": "example.com",
                        "priority": "NORMAL",
                        "source": "submission",
                    }
                ),
            }
        ]
    }

    class MockContext:
        function_name = "dns-aid-crawler"
        memory_limit_in_mb = 512
        invoked_function_arn = "arn:aws:lambda:eu-west-2:123456789:function:dns-aid-crawler"
        aws_request_id = "test-request-id"

    result = handler(test_event, MockContext())
    print(json.dumps(result, indent=2))
