"""
AWS Lambda Handler for DNS-AID Scheduler.

Triggered by EventBridge on schedule (every 6 hours by default).
Queries the database for domains due for re-crawl and queues them to SQS.

This handler coordinates the periodic discovery refresh cycle.
"""

from __future__ import annotations

import asyncio
import json
import os
from typing import Any

import boto3
import structlog
from aws_lambda_powertools import Logger, Metrics, Tracer
from aws_lambda_powertools.metrics import MetricUnit
from aws_lambda_powertools.utilities.typing import LambdaContext

from dns_aid.crawlers.scheduler import (
    CrawlPriority,
)

# Initialize AWS Lambda Powertools
logger = Logger(service="dns-aid-scheduler")
tracer = Tracer(service="dns-aid-scheduler")
metrics = Metrics(namespace="DNS-AID", service="scheduler")

# Structlog for application-level logging
app_logger = structlog.get_logger(__name__)

# Environment variables
RECRAWL_QUEUE_URL = os.environ.get("RECRAWL_QUEUE_URL", "")
RECRAWL_INTERVAL_HOURS = int(os.environ.get("RECRAWL_INTERVAL_HOURS", "6"))
DB_HOST = os.environ.get("DB_HOST", "")
DB_NAME = os.environ.get("DB_NAME", "dns_aid")


def _get_sqs_client():
    """Get boto3 SQS client."""
    return boto3.client("sqs")


async def _get_domains_due_for_recrawl(interval_hours: int) -> list[str]:
    """
    Query database for domains that need re-crawling.

    In production, this queries RDS for:
    - Domains not crawled in the last N hours
    - Domains with known agents (priority)
    - Verified domains only

    For now, this is a placeholder that would be replaced with actual DB queries.
    """
    # TODO: Replace with actual database query
    # This would use asyncpg with IAM authentication:
    #
    # async with get_db_connection() as conn:
    #     cutoff = datetime.now(UTC) - timedelta(hours=interval_hours)
    #     rows = await conn.fetch('''
    #         SELECT domain FROM domains
    #         WHERE verified = TRUE
    #         AND (last_crawled IS NULL OR last_crawled < $1)
    #         ORDER BY agent_count DESC, last_crawled ASC
    #         LIMIT 1000
    #     ''', cutoff)
    #     return [row['domain'] for row in rows]

    app_logger.info(
        "Fetching domains due for re-crawl",
        interval_hours=interval_hours,
        db_host=DB_HOST,
    )

    # Placeholder: return empty list (no domains to crawl)
    # In production, this queries the domains table
    return []


def _queue_domains_to_sqs(sqs_client, queue_url: str, domains: list[str]) -> int:
    """
    Send domains to SQS queue for re-crawling.

    Uses batch sending for efficiency (up to 10 messages per batch).

    Args:
        sqs_client: boto3 SQS client
        queue_url: Target SQS queue URL
        domains: List of domains to queue

    Returns:
        Number of messages successfully queued
    """
    if not domains:
        return 0

    queued_count = 0

    # SQS batch limit is 10 messages
    batch_size = 10
    for i in range(0, len(domains), batch_size):
        batch = domains[i : i + batch_size]

        entries = [
            {
                "Id": str(idx),
                "MessageBody": json.dumps(
                    {
                        "domain": domain,
                        "priority": CrawlPriority.NORMAL.name,
                        "source": "scheduled",
                    }
                ),
            }
            for idx, domain in enumerate(batch)
        ]

        try:
            response = sqs_client.send_message_batch(
                QueueUrl=queue_url,
                Entries=entries,
            )

            # Count successes
            successful = len(response.get("Successful", []))
            queued_count += successful

            # Log failures
            failed = response.get("Failed", [])
            if failed:
                app_logger.warning(
                    "Some messages failed to queue",
                    failed_count=len(failed),
                    errors=[f.get("Message") for f in failed],
                )

        except Exception as e:
            app_logger.error(
                "Failed to send SQS batch",
                error=str(e),
                batch_start=i,
            )

    return queued_count


@tracer.capture_lambda_handler
@logger.inject_lambda_context
@metrics.log_metrics(capture_cold_start_metric=True)
def handler(event: dict[str, Any], context: LambdaContext) -> dict[str, Any]:
    """
    AWS Lambda entry point for scheduler.

    Triggered by EventBridge rule on schedule.

    Expected event format (from EventBridge):
    {
        "action": "schedule_recrawls",
        "source": "eventbridge"
    }

    Args:
        event: EventBridge scheduled event
        context: Lambda context

    Returns:
        Scheduling results summary
    """
    logger.info(
        "Scheduler Lambda invoked",
        event_source=event.get("source", "unknown"),
        action=event.get("action", "unknown"),
    )

    # Validate event
    action = event.get("action", "schedule_recrawls")
    if action != "schedule_recrawls":
        logger.warning("Unknown action", action=action)
        return {"statusCode": 400, "body": f"Unknown action: {action}"}

    # Check required config
    if not RECRAWL_QUEUE_URL:
        logger.error("RECRAWL_QUEUE_URL not configured")
        return {"statusCode": 500, "body": "Queue URL not configured"}

    # Get domains due for re-crawl
    try:
        domains = asyncio.run(_get_domains_due_for_recrawl(RECRAWL_INTERVAL_HOURS))
        metrics.add_metric(name="DomainsDueForRecrawl", unit=MetricUnit.Count, value=len(domains))
    except Exception as e:
        logger.exception("Failed to fetch domains", error=str(e))
        return {"statusCode": 500, "body": f"Database error: {str(e)}"}

    if not domains:
        logger.info("No domains due for re-crawl")
        return {
            "statusCode": 200,
            "body": {
                "message": "No domains due for re-crawl",
                "domains_checked": 0,
                "domains_queued": 0,
            },
        }

    # Queue domains to SQS
    try:
        sqs_client = _get_sqs_client()
        queued_count = _queue_domains_to_sqs(sqs_client, RECRAWL_QUEUE_URL, domains)
        metrics.add_metric(name="DomainsQueued", unit=MetricUnit.Count, value=queued_count)
    except Exception as e:
        logger.exception("Failed to queue domains", error=str(e))
        return {"statusCode": 500, "body": f"SQS error: {str(e)}"}

    logger.info(
        "Scheduler complete",
        domains_found=len(domains),
        domains_queued=queued_count,
    )

    return {
        "statusCode": 200,
        "body": {
            "message": "Re-crawl jobs scheduled",
            "domains_found": len(domains),
            "domains_queued": queued_count,
            "interval_hours": RECRAWL_INTERVAL_HOURS,
        },
    }


# For local testing
if __name__ == "__main__":
    # Simulate EventBridge event
    test_event = {
        "action": "schedule_recrawls",
        "source": "eventbridge",
    }

    class MockContext:
        function_name = "dns-aid-scheduler"
        memory_limit_in_mb = 256
        invoked_function_arn = "arn:aws:lambda:eu-west-2:123456789:function:dns-aid-scheduler"
        aws_request_id = "test-request-id"

    # Set test environment
    os.environ["RECRAWL_QUEUE_URL"] = "https://sqs.eu-west-2.amazonaws.com/123456789/test-queue"
    os.environ["RECRAWL_INTERVAL_HOURS"] = "6"

    result = handler(test_event, MockContext())
    print(json.dumps(result, indent=2))
