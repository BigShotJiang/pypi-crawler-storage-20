"""
Submission crawler for DNS-AID Agent Directory.

Processes verified domains by discovering and indexing their DNS-AID agents.
"""

from datetime import UTC, datetime

import structlog

from dns_aid.core.discoverer import discover
from dns_aid.core.validator import verify
from dns_aid.crawlers.base import BaseCrawler, CrawlResult, DiscoveredAgent

logger = structlog.get_logger(__name__)

# Supported protocols for discovery
SUPPORTED_PROTOCOLS = ["mcp", "a2a", "https"]


class SubmissionCrawler(BaseCrawler):
    """
    Crawler for processing submitted and verified domains.

    Uses the core dns-aid discovery and verification functions to find
    agents published via DNS records and assess their security.
    """

    def __init__(self, protocols: list[str] | None = None):
        """
        Initialize the submission crawler.

        Args:
            protocols: Protocols to discover. Defaults to all supported.
        """
        super().__init__(name="submission")
        self.protocols = protocols or SUPPORTED_PROTOCOLS

    async def crawl(self, domain: str) -> CrawlResult:
        """
        Crawl a verified domain for DNS-AID agents.

        Discovers agents for each supported protocol and verifies
        their security configuration (DNSSEC, DANE, endpoint reachability).

        Args:
            domain: The verified domain to crawl.

        Returns:
            CrawlResult with discovered and verified agents.
        """
        result = CrawlResult(domain=domain, status="running")
        agents_found: list[DiscoveredAgent] = []
        errors: list[str] = []

        for protocol in self.protocols:
            try:
                self.logger.debug(
                    "Discovering agents",
                    domain=domain,
                    protocol=protocol,
                )

                # Use core discovery function
                discovery_result = await discover(
                    domain=domain,
                    protocol=protocol,
                )

                for agent in discovery_result.agents:
                    try:
                        # Verify each discovered agent
                        verification = await verify(agent.fqdn)

                        discovered = DiscoveredAgent(
                            fqdn=agent.fqdn,
                            domain=domain,
                            name=agent.name,
                            protocol=protocol,
                            endpoint_url=agent.endpoint_url,
                            port=agent.port or 443,
                            capabilities=agent.capabilities or [],
                            version=agent.version,
                            security_score=verification.security_score,
                            metadata={
                                "dnssec_valid": verification.dnssec_valid,
                                "dane_valid": verification.dane_valid,
                                "endpoint_reachable": verification.endpoint_reachable,
                                "svcb_valid": verification.svcb_valid,
                                "verification_timestamp": datetime.now(UTC).isoformat(),
                            },
                        )
                        agents_found.append(discovered)

                        self.logger.info(
                            "Agent discovered and verified",
                            fqdn=agent.fqdn,
                            protocol=protocol,
                            security_score=verification.security_score,
                        )

                    except Exception as e:
                        self.logger.warning(
                            "Agent verification failed",
                            fqdn=agent.fqdn,
                            error=str(e),
                        )
                        errors.append(f"Verification failed for {agent.fqdn}: {e}")

            except Exception as e:
                self.logger.warning(
                    "Protocol discovery failed",
                    domain=domain,
                    protocol=protocol,
                    error=str(e),
                )
                errors.append(f"Discovery failed for {protocol}: {e}")

        # Set result status based on outcomes
        result.agents_found = agents_found

        if agents_found and not errors:
            result.complete("success")
        elif agents_found and errors:
            result.complete("partial", "; ".join(errors))
        elif not agents_found and not errors:
            result.complete("success")  # No agents is valid
        else:
            result.complete("failed", "; ".join(errors))

        return result


class BatchSubmissionCrawler(BaseCrawler):
    """
    Crawler for processing multiple domains in batch.

    Useful for scheduled re-crawling of verified domains.
    """

    def __init__(
        self,
        protocols: list[str] | None = None,
        max_concurrent: int = 5,
    ):
        """
        Initialize the batch crawler.

        Args:
            protocols: Protocols to discover.
            max_concurrent: Maximum concurrent domain crawls.
        """
        super().__init__(name="batch-submission")
        self.protocols = protocols or SUPPORTED_PROTOCOLS
        self.max_concurrent = max_concurrent
        self._single_crawler = SubmissionCrawler(protocols=self.protocols)

    async def crawl(self, domain: str) -> CrawlResult:
        """
        Crawl a single domain (delegates to SubmissionCrawler).

        For batch operations, use crawl_batch() instead.
        """
        return await self._single_crawler.crawl(domain)

    async def crawl_batch(self, domains: list[str]) -> list[CrawlResult]:
        """
        Crawl multiple domains with controlled concurrency.

        Args:
            domains: List of domains to crawl.

        Returns:
            List of CrawlResults for each domain.
        """
        import asyncio

        semaphore = asyncio.Semaphore(self.max_concurrent)

        async def crawl_with_semaphore(domain: str) -> CrawlResult:
            async with semaphore:
                return await self._single_crawler.run(domain)

        self.logger.info(
            "Starting batch crawl",
            domain_count=len(domains),
            max_concurrent=self.max_concurrent,
        )

        results = await asyncio.gather(
            *[crawl_with_semaphore(d) for d in domains],
            return_exceptions=True,
        )

        # Convert exceptions to failed results
        final_results: list[CrawlResult] = []
        for domain, result in zip(domains, results, strict=True):
            if isinstance(result, BaseException):
                failed = CrawlResult(domain=domain, status="failed")
                failed.complete("failed", str(result))
                final_results.append(failed)
            elif isinstance(result, CrawlResult):
                final_results.append(result)

        successful = sum(1 for r in final_results if r.status == "success")
        self.logger.info(
            "Batch crawl completed",
            total=len(domains),
            successful=successful,
            failed=len(domains) - successful,
        )

        return final_results
