"""
Crawl Scheduler for DNS-AID Agent Directory.

Orchestrates the discovery pipeline:
1. Processes domain submissions from queue
2. Schedules periodic re-crawls (6-hour default)
3. Coordinates multiple crawler types
4. Manages crawl priorities and deduplication

Designed for AWS Lambda + SQS, but can run standalone.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum

import structlog

from dns_aid.crawlers.base import CrawlResult
from dns_aid.crawlers.config import SCHEDULER_CONFIG, is_domain_blocked
from dns_aid.crawlers.index_reader import IndexReaderCrawler, index_exists
from dns_aid.crawlers.pattern_prober import PatternProberCrawler

logger = structlog.get_logger(__name__)


class CrawlPriority(Enum):
    """Priority levels for crawl jobs."""

    IMMEDIATE = 0  # User submission, needs fast response
    HIGH = 1  # CT log detection, recent activity
    NORMAL = 2  # Scheduled re-crawl
    LOW = 3  # Bulk/batch processing


class CrawlStatus(Enum):
    """Status of a crawl job."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class CrawlJob:
    """A single crawl job in the queue."""

    domain: str
    priority: CrawlPriority = CrawlPriority.NORMAL
    source: str = "manual"  # manual, ct_log, pdns, scheduled
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    scheduled_for: datetime | None = None
    attempt: int = 0
    max_attempts: int = 3
    status: CrawlStatus = CrawlStatus.PENDING
    result: CrawlResult | None = None
    error: str | None = None

    @property
    def is_due(self) -> bool:
        """Check if job is ready to run."""
        if self.scheduled_for is None:
            return True
        return datetime.now(UTC) >= self.scheduled_for

    @property
    def can_retry(self) -> bool:
        """Check if job can be retried."""
        return self.attempt < self.max_attempts


@dataclass
class DomainState:
    """Tracks crawl state for a domain."""

    domain: str
    last_crawled: datetime | None = None
    last_result: CrawlResult | None = None
    crawl_count: int = 0
    agent_count: int = 0
    has_index: bool = False
    consecutive_failures: int = 0


class CrawlQueue:
    """
    In-memory crawl queue with priority support.

    For production, this would be backed by SQS/Redis.
    This implementation is suitable for:
    - Local development/testing
    - Single Lambda invocation processing
    """

    def __init__(self, max_size: int = 10000):
        """
        Initialize the crawl queue.

        Args:
            max_size: Maximum queue size to prevent memory issues
        """
        self._queue: list[CrawlJob] = []
        self._max_size = max_size
        self._seen_domains: set[str] = set()  # For deduplication
        self.logger = logger.bind(component="crawl-queue")

    def add(self, job: CrawlJob) -> bool:
        """
        Add a job to the queue.

        Args:
            job: CrawlJob to add

        Returns:
            True if added, False if duplicate or blocked
        """
        # Check blocklist
        if is_domain_blocked(job.domain):
            self.logger.debug("Domain blocked", domain=job.domain)
            return False

        # Deduplicate pending jobs for same domain
        if job.domain in self._seen_domains:
            self.logger.debug("Domain already queued", domain=job.domain)
            return False

        # Check queue size
        if len(self._queue) >= self._max_size:
            self.logger.warning("Queue full, dropping job", domain=job.domain)
            return False

        self._queue.append(job)
        self._seen_domains.add(job.domain)

        # Sort by priority (lower number = higher priority)
        self._queue.sort(key=lambda j: (j.priority.value, j.created_at))

        self.logger.debug(
            "Job added",
            domain=job.domain,
            priority=job.priority.name,
            queue_size=len(self._queue),
        )
        return True

    def pop(self) -> CrawlJob | None:
        """
        Get the next job to process.

        Returns:
            Next due job, or None if queue empty
        """
        for i, job in enumerate(self._queue):
            if job.is_due:
                self._queue.pop(i)
                self._seen_domains.discard(job.domain)
                return job
        return None

    def peek(self) -> CrawlJob | None:
        """Look at next job without removing it."""
        for job in self._queue:
            if job.is_due:
                return job
        return None

    def clear(self) -> None:
        """Clear all jobs from queue."""
        self._queue.clear()
        self._seen_domains.clear()

    @property
    def size(self) -> int:
        """Current queue size."""
        return len(self._queue)

    @property
    def pending_count(self) -> int:
        """Count of due jobs."""
        return sum(1 for j in self._queue if j.is_due)


class CrawlScheduler:
    """
    Orchestrates the DNS-AID crawl pipeline.

    Coordinates multiple crawlers and manages the crawl queue.
    Implements the discovery strategy from the plan:

    1. Index reader (primary) - most efficient
    2. Pattern prober (fallback) - if no index
    3. pDNS enrichment runs separately (background)
    """

    def __init__(
        self,
        index_crawler: IndexReaderCrawler | None = None,
        pattern_crawler: PatternProberCrawler | None = None,
        on_agents_found: Callable[[CrawlResult], Awaitable[None]] | None = None,
    ):
        """
        Initialize the scheduler.

        Args:
            index_crawler: Crawler for _index._agents.* records
            pattern_crawler: Fallback crawler for common patterns
            on_agents_found: Callback when agents are discovered
        """
        self._index_crawler = index_crawler or IndexReaderCrawler()
        self._pattern_crawler = pattern_crawler or PatternProberCrawler()
        self._on_agents_found = on_agents_found

        self._queue = CrawlQueue()
        self._domain_states: dict[str, DomainState] = {}
        self._running = False

        # Statistics
        self._stats = {
            "jobs_processed": 0,
            "jobs_succeeded": 0,
            "jobs_failed": 0,
            "agents_discovered": 0,
            "domains_with_index": 0,
        }

        self.logger = logger.bind(component="scheduler")

    @property
    def stats(self) -> dict:
        """Get scheduler statistics."""
        return {
            **self._stats,
            "queue_size": self._queue.size,
            "domains_tracked": len(self._domain_states),
        }

    def submit_domain(
        self,
        domain: str,
        priority: CrawlPriority = CrawlPriority.NORMAL,
        source: str = "manual",
    ) -> bool:
        """
        Submit a domain for crawling.

        Args:
            domain: Domain to crawl
            priority: Crawl priority
            source: Where the submission came from

        Returns:
            True if queued, False if rejected
        """
        domain = domain.lower().strip()

        job = CrawlJob(
            domain=domain,
            priority=priority,
            source=source,
        )

        return self._queue.add(job)

    def schedule_recrawl(self, domain: str) -> bool:
        """
        Schedule a domain for re-crawling after the configured interval.

        Args:
            domain: Domain to re-crawl

        Returns:
            True if scheduled
        """
        recrawl_time = datetime.now(UTC) + timedelta(
            seconds=SCHEDULER_CONFIG.recrawl_interval_seconds
        )

        job = CrawlJob(
            domain=domain,
            priority=CrawlPriority.NORMAL,
            source="scheduled",
            scheduled_for=recrawl_time,
        )

        self.logger.debug(
            "Scheduled recrawl",
            domain=domain,
            scheduled_for=recrawl_time.isoformat(),
        )

        return self._queue.add(job)

    async def process_one(self) -> CrawlResult | None:
        """
        Process a single job from the queue.

        Returns:
            CrawlResult if processed, None if queue empty
        """
        job = self._queue.pop()
        if job is None:
            return None

        job.status = CrawlStatus.RUNNING
        job.attempt += 1

        self.logger.info(
            "Processing crawl job",
            domain=job.domain,
            source=job.source,
            attempt=job.attempt,
        )

        try:
            result = await self._crawl_domain(job.domain)
            job.status = CrawlStatus.COMPLETED
            job.result = result

            # Update domain state
            self._update_domain_state(job.domain, result)

            # Callback for found agents
            if result.agents_found and self._on_agents_found:
                await self._on_agents_found(result)

            # Schedule recrawl if enabled
            if SCHEDULER_CONFIG.auto_recrawl:
                self.schedule_recrawl(job.domain)

            self._stats["jobs_processed"] += 1
            self._stats["jobs_succeeded"] += 1
            self._stats["agents_discovered"] += len(result.agents_found)

            return result

        except Exception as e:
            self.logger.exception("Crawl failed", domain=job.domain, error=str(e))

            job.status = CrawlStatus.FAILED
            job.error = str(e)

            # Retry if possible
            if job.can_retry:
                job.status = CrawlStatus.PENDING
                job.scheduled_for = datetime.now(UTC) + timedelta(minutes=5 * job.attempt)
                self._queue.add(job)
                self.logger.info(
                    "Job scheduled for retry",
                    domain=job.domain,
                    attempt=job.attempt,
                    retry_at=job.scheduled_for.isoformat(),
                )
            else:
                self._stats["jobs_failed"] += 1
                state = self._get_or_create_state(job.domain)
                state.consecutive_failures += 1

            return None

    async def _crawl_domain(self, domain: str) -> CrawlResult:
        """
        Execute the crawl strategy for a domain.

        Strategy:
        1. Try index reader first (most efficient)
        2. If no index, fall back to pattern probing
        """
        # Check for index record
        has_index = await index_exists(domain)

        if has_index:
            self._stats["domains_with_index"] += 1
            self.logger.debug("Using index-based discovery", domain=domain)
            result = await self._index_crawler.crawl(domain)

            # If index found agents, we're done
            if result.agents_found:
                return result

        # Fallback to pattern probing
        self.logger.debug("Falling back to pattern probing", domain=domain)
        return await self._pattern_crawler.crawl(domain)

    def _get_or_create_state(self, domain: str) -> DomainState:
        """Get or create domain state."""
        if domain not in self._domain_states:
            self._domain_states[domain] = DomainState(domain=domain)
        return self._domain_states[domain]

    def _update_domain_state(self, domain: str, result: CrawlResult) -> None:
        """Update domain state after crawl."""
        state = self._get_or_create_state(domain)
        state.last_crawled = datetime.now(UTC)
        state.last_result = result
        state.crawl_count += 1
        state.agent_count = len(result.agents_found)
        state.consecutive_failures = 0  # Reset on success

    async def run(self, max_jobs: int | None = None) -> dict:
        """
        Run the scheduler, processing jobs from the queue.

        Args:
            max_jobs: Maximum jobs to process (None = until empty)

        Returns:
            Statistics dict
        """
        self._running = True
        jobs_processed = 0

        self.logger.info(
            "Scheduler starting",
            queue_size=self._queue.size,
            max_jobs=max_jobs,
        )

        while self._running:
            if max_jobs is not None and jobs_processed >= max_jobs:
                break

            if self._queue.pending_count == 0:
                break

            result = await self.process_one()
            if result is not None:
                jobs_processed += 1

            # Small delay to prevent tight loop
            await asyncio.sleep(0.1)

        self._running = False
        self.logger.info(
            "Scheduler stopped",
            jobs_processed=jobs_processed,
            stats=self.stats,
        )

        return self.stats

    def stop(self) -> None:
        """Stop the scheduler."""
        self._running = False


class BatchScheduler:
    """
    Batch scheduler for processing multiple domains.

    Useful for:
    - Initial bulk import
    - Scheduled batch jobs (EventBridge → Lambda)
    - Processing CT log matches
    """

    def __init__(
        self,
        scheduler: CrawlScheduler | None = None,
        max_concurrent: int = 10,
    ):
        """
        Initialize batch scheduler.

        Args:
            scheduler: CrawlScheduler instance
            max_concurrent: Maximum concurrent crawls
        """
        self._scheduler = scheduler or CrawlScheduler()
        self._max_concurrent = max_concurrent
        self.logger = logger.bind(component="batch-scheduler")

    async def process_domains(
        self,
        domains: list[str],
        priority: CrawlPriority = CrawlPriority.NORMAL,
        source: str = "batch",
    ) -> dict:
        """
        Process a batch of domains.

        Args:
            domains: List of domains to crawl
            priority: Priority for all jobs
            source: Source identifier

        Returns:
            Batch statistics
        """
        # Queue all domains
        queued = 0
        for domain in domains:
            if self._scheduler.submit_domain(domain, priority, source):
                queued += 1

        self.logger.info(
            "Batch queued",
            total=len(domains),
            queued=queued,
            skipped=len(domains) - queued,
        )

        # Process with concurrency limit
        semaphore = asyncio.Semaphore(self._max_concurrent)
        results: list[CrawlResult] = []

        async def process_with_limit():
            async with semaphore:
                result = await self._scheduler.process_one()
                if result:
                    results.append(result)
                return result

        # Process all queued jobs
        tasks = [process_with_limit() for _ in range(queued)]
        await asyncio.gather(*tasks, return_exceptions=True)

        # Compile statistics
        stats = {
            "domains_submitted": len(domains),
            "domains_queued": queued,
            "domains_processed": len(results),
            "agents_found": sum(len(r.agents_found) for r in results),
            "successful": sum(1 for r in results if r.status == "success"),
            "failed": sum(1 for r in results if r.status == "failed"),
        }

        self.logger.info("Batch completed", **stats)
        return stats


# Convenience functions for Lambda handlers


async def process_submission_event(event: dict) -> dict:
    """
    Process a domain submission event (from SQS/API Gateway).

    Args:
        event: Event containing domain info

    Returns:
        Processing result
    """
    domain = event.get("domain")
    if not domain:
        return {"error": "No domain provided"}

    scheduler = CrawlScheduler()
    scheduler.submit_domain(
        domain,
        priority=CrawlPriority.IMMEDIATE,
        source=event.get("source", "api"),
    )

    result = await scheduler.process_one()

    return {
        "domain": domain,
        "status": result.status if result else "failed",
        "agents_found": len(result.agents_found) if result else 0,
    }


async def process_scheduled_recrawl(domains: list[str] | None = None) -> dict:
    """
    Process scheduled re-crawl job (from EventBridge).

    Args:
        domains: Optional specific domains, otherwise uses due domains

    Returns:
        Batch statistics
    """
    batch = BatchScheduler()

    if domains:
        return await batch.process_domains(
            domains,
            priority=CrawlPriority.NORMAL,
            source="scheduled",
        )

    # In production, this would query the database for domains
    # due for re-crawl based on last_crawled timestamp
    return {"message": "No domains specified for recrawl"}
