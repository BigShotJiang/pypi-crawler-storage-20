# DNS-AID Agent Directory HTTP API Reference

Version: 1.0.0  
Base URL: `https://api.dns-aid.io/v1`

## Overview

The DNS-AID Agent Directory API provides HTTP endpoints for discovering, searching, and managing DNS-published AI agents. This API implements the Phase 1 MVP of the Agent Directory as specified in the IETF draft-mozleywilliams-dnsop-bandaid protocol.

## Authentication

Phase 1 uses public endpoints. Future versions will support API key authentication for write operations.

## Rate Limits

| Endpoint Type | Rate Limit | Burst Limit |
|---------------|------------|-------------|
| Search/Read | 100 req/s | 200 req |
| Write | 10 req/s | 20 req |

Rate limit headers are included in responses:
- `X-RateLimit-Limit`: Maximum requests per second
- `X-RateLimit-Remaining`: Remaining requests in window
- `X-RateLimit-Reset`: Unix timestamp when limit resets

---

## Endpoints

### Health & Status

#### GET /health

Health check endpoint for monitoring and load balancer probes.

**Response**

```json
{
  "status": "healthy",
  "version": "1.0.0",
  "timestamp": "2024-01-15T10:30:00Z",
  "checks": {
    "database": "healthy",
    "dns_resolver": "healthy"
  }
}
```

**Status Codes**
- `200 OK` - Service is healthy
- `503 Service Unavailable` - Service is unhealthy

---

#### GET /stats

Directory statistics.

**Response**

```json
{
  "total_agents": 1250,
  "total_domains": 340,
  "agents_by_protocol": {
    "mcp": 650,
    "a2a": 420,
    "https": 180
  },
  "domains_verified": 310,
  "domains_pending": 30
}
```

---

### Search

#### GET /search

Search for agents by name, capabilities, or other criteria.

**Query Parameters**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `q` | string | Yes | Search query (min 1 char, max 200 chars) |
| `protocol` | string | No | Filter by protocol: `mcp`, `a2a`, `https` |
| `domain` | string | No | Filter by domain |
| `min_security_score` | integer | No | Minimum security score (0-100) |
| `min_popularity_score` | integer | No | Minimum popularity score (0-100) |
| `limit` | integer | No | Results per page (default: 20, max: 100) |
| `offset` | integer | No | Pagination offset (default: 0) |

**Example Request**

```bash
GET /search?q=network&protocol=mcp&min_security_score=80&limit=10
```

**Response**

```json
{
  "query": "network",
  "total": 45,
  "limit": 10,
  "offset": 0,
  "results": [
    {
      "agent": {
        "fqdn": "_network._mcp._agents.example.com",
        "domain": "example.com",
        "name": "network",
        "protocol": "mcp",
        "endpoint_url": "https://mcp.example.com:443",
        "port": 443,
        "capabilities": ["ipam", "dns", "vpn"],
        "version": "1.0.0",
        "security_score": 95,
        "popularity_score": 80
      },
      "relevance_score": 0.95
    }
  ]
}
```

---

#### GET /search/suggestions

Get search suggestions based on partial input.

**Query Parameters**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `prefix` | string | Yes | Search prefix (min 1 char) |
| `limit` | integer | No | Max suggestions (default: 5, max: 10) |

**Response**

```json
{
  "prefix": "net",
  "suggestions": ["network", "networking", "netops"]
}
```

---

### Agents

#### GET /agents/{fqdn}

Get detailed information about a specific agent.

**Path Parameters**

| Parameter | Type | Description |
|-----------|------|-------------|
| `fqdn` | string | Agent FQDN (e.g., `_network._mcp._agents.example.com`) |

**Response**

```json
{
  "fqdn": "_network._mcp._agents.example.com",
  "domain": "example.com",
  "name": "network",
  "protocol": "mcp",
  "endpoint_url": "https://mcp.example.com:443",
  "port": 443,
  "capabilities": ["ipam", "dns", "vpn"],
  "version": "1.0.0",
  "security_score": 95,
  "trust_score": 90,
  "popularity_score": 80,
  "threat_flags": {},
  "first_seen": "2024-01-10T08:00:00Z",
  "last_seen": "2024-01-15T10:30:00Z",
  "last_verified": "2024-01-15T06:00:00Z"
}
```

---

### Domains

#### POST /domains/submit

Submit a domain for indexing. Returns verification instructions.

**Request Body**

```json
{
  "domain": "example.com"
}
```

**Response** (201 Created)

```json
{
  "domain": "example.com",
  "verification_token": "dns-aid-verify=abc123xyz789",
  "verification_record": "_dns-aid-verify.example.com TXT \"dns-aid-verify=abc123xyz789\"",
  "instructions": "Add the TXT record above to your DNS zone, then call POST /domains/verify"
}
```

---

#### POST /domains/verify

Verify domain ownership via DNS TXT record.

**Request Body**

```json
{
  "domain": "example.com"
}
```

**Response** (200 OK)

```json
{
  "domain": "example.com",
  "verified": true,
  "verified_at": "2024-01-15T10:30:00Z"
}
```

---

#### GET /domains/{domain}

Get domain details and verification status.

**Response**

```json
{
  "domain": "example.com",
  "verified": true,
  "submitted_at": "2024-01-14T08:00:00Z",
  "verified_at": "2024-01-14T08:30:00Z",
  "last_crawled": "2024-01-15T06:00:00Z",
  "crawl_status": "completed",
  "agent_count": 5
}
```

---

#### DELETE /domains/{domain}

Remove a domain and all its agents from the directory.

**Status Codes**
- `204 No Content` - Domain deleted
- `404 Not Found` - Domain not found

---

#### GET /domains/{domain}/agents

List all agents for a specific domain.

**Response**

```json
{
  "domain": "example.com",
  "total": 5,
  "limit": 20,
  "offset": 0,
  "agents": [
    {
      "fqdn": "_network._mcp._agents.example.com",
      "name": "network",
      "protocol": "mcp",
      "security_score": 95
    }
  ]
}
```

---

## Error Responses

All errors follow a consistent format:

```json
{
  "detail": {
    "code": "DNS_AID_404",
    "message": "Agent not found: _invalid._mcp._agents.example.com"
  }
}
```

### Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `DNS_AID_400` | 400 | Bad request / validation error |
| `DNS_AID_404` | 404 | Resource not found |
| `DNS_AID_409` | 409 | Conflict (e.g., duplicate domain) |
| `DNS_AID_422` | 422 | Unprocessable entity |
| `DNS_AID_429` | 429 | Rate limit exceeded |
| `DNS_AID_500` | 500 | Internal server error |

---

## Security Scoring

Security scores (0-100) are calculated based on:

| Factor | Weight | Description |
|--------|--------|-------------|
| DNSSEC | 40 | DNSSEC validation passes |
| DANE/TLSA | 30 | DANE certificate binding present |
| Endpoint | 20 | Endpoint is reachable via TLS |
| SVCB | 10 | Valid SVCB record format |

---

## Examples

### cURL Examples

**Search for MCP agents:**
```bash
curl "https://api.dns-aid.io/v1/search?q=network&protocol=mcp"
```

**Submit a domain:**
```bash
curl -X POST "https://api.dns-aid.io/v1/domains/submit" \
  -H "Content-Type: application/json" \
  -d '{"domain": "example.com"}'
```

**Verify a domain:**
```bash
curl -X POST "https://api.dns-aid.io/v1/domains/verify" \
  -H "Content-Type: application/json" \
  -d '{"domain": "example.com"}'
```

---

## Changelog

### v1.0.0 (Phase 1)
- Initial release
- Domain submission and verification
- Agent search with filtering
- Security scoring
- PostgreSQL full-text search
