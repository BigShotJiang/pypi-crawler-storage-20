"""Unit tests for health check endpoints."""

import pytest
from httpx import AsyncClient


class TestHealthEndpoints:
    """Tests for health check endpoints."""

    @pytest.mark.asyncio
    async def test_health_check(self, test_client: AsyncClient):
        """Test the /health endpoint."""
        response = await test_client.get("/health")

        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert "version" in data
        assert "database" in data
        assert "uptime_seconds" in data

    @pytest.mark.asyncio
    async def test_readiness_check(self, test_client: AsyncClient):
        """Test the /ready endpoint."""
        response = await test_client.get("/ready")

        # Should be 200 if DB is available
        assert response.status_code in [200, 503]
        data = response.json()
        assert "ready" in data

    @pytest.mark.asyncio
    async def test_root_endpoint(self, test_client: AsyncClient):
        """Test the root endpoint."""
        response = await test_client.get("/")

        assert response.status_code == 200
        data = response.json()
        assert data["service"] == "DNS-AID Agent Directory"
        assert "version" in data
        assert "docs" in data
        assert "health" in data

    @pytest.mark.asyncio
    async def test_stats_endpoint(self, test_client: AsyncClient):
        """Test the /api/v1/stats endpoint."""
        response = await test_client.get("/api/v1/stats")

        assert response.status_code == 200
        data = response.json()
        assert "total_agents" in data
        assert "total_domains" in data
        assert "verified_domains" in data
        assert "agents_by_protocol" in data

    @pytest.mark.asyncio
    async def test_stats_with_data(self, test_client: AsyncClient, seeded_db):
        """Test stats endpoint with seeded data."""
        response = await test_client.get("/api/v1/stats")

        assert response.status_code == 200
        data = response.json()
        assert data["total_agents"] >= 1
        assert data["total_domains"] >= 1
