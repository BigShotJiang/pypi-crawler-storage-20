"""Pytest fixtures for API tests."""

from collections.abc import AsyncGenerator
from datetime import UTC, datetime

import pytest
import pytest_asyncio
from fastapi.testclient import TestClient
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from dns_aid.api.app import app
from dns_aid.directory.database import get_db_session
from dns_aid.directory.models import Agent, Base, Domain


@pytest.fixture(scope="function")
def anyio_backend():
    """Use asyncio backend for async tests."""
    return "asyncio"


@pytest_asyncio.fixture(scope="function")
async def async_engine():
    """Create an async SQLite engine for testing."""
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        echo=False,
    )

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    yield engine

    await engine.dispose()


@pytest_asyncio.fixture(scope="function")
async def async_session(async_engine) -> AsyncGenerator[AsyncSession, None]:
    """Create an async session for testing."""
    session_factory = async_sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    async with session_factory() as session:
        yield session
        await session.rollback()


@pytest_asyncio.fixture(scope="function")
async def session_factory(async_engine):
    """Create a shared session factory for the test."""
    return async_sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )


@pytest_asyncio.fixture(scope="function")
async def test_client(session_factory) -> AsyncGenerator[AsyncClient, None]:
    """Create an async test client with database override."""

    async def override_get_db():
        """Override that commits sessions like production does."""
        session = session_factory()
        try:
            yield session
            await session.commit()  # Match production behavior
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()

    app.dependency_overrides[get_db_session] = override_get_db

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as client:
        yield client

    app.dependency_overrides.clear()


@pytest.fixture
def sync_client():
    """Create a synchronous test client for simple tests."""
    return TestClient(app)


@pytest.fixture
def sample_domain_data():
    """Sample domain data for testing."""
    return {
        "domain": "example.com",
        "verified": True,
        "verification_token": "test-token-12345",
        "submitted_at": datetime.now(UTC),
        "verified_at": datetime.now(UTC),
        "crawl_status": "completed",
        "agent_count": 2,
    }


@pytest.fixture
def sample_agent_data():
    """Sample agent data for testing."""
    return {
        "fqdn": "_network._mcp._agents.example.com",
        "domain": "example.com",
        "name": "network",
        "protocol": "mcp",
        "endpoint_url": "https://mcp.example.com:443",
        "port": 443,
        "capabilities": ["ipam", "dns", "vpn"],
        "version": "1.0.0",
        "security_score": 85,
        "trust_score": 90,
        "popularity_score": 75,
        "threat_flags": {},
        "first_seen": datetime.now(UTC),
        "last_seen": datetime.now(UTC),
        "last_verified": datetime.now(UTC),
    }


@pytest_asyncio.fixture
async def seeded_db(session_factory, sample_domain_data, sample_agent_data):
    """Seed the database with test data using the shared session factory."""
    async with session_factory() as session:
        domain = Domain(**sample_domain_data)
        agent = Agent(**sample_agent_data)

        session.add(domain)
        session.add(agent)
        await session.commit()

        return {"domain": domain, "agent": agent}
