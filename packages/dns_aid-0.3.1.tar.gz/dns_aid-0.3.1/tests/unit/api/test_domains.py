"""Unit tests for domain endpoints."""

from unittest.mock import MagicMock, patch

import pytest
from httpx import AsyncClient


def create_mock_dns_answer(token: str):
    """Create a mock DNS answer with a TXT record."""
    mock_rdata = MagicMock()
    mock_rdata.strings = [token.encode("utf-8")]
    return [mock_rdata]


class TestDomainSubmission:
    """Tests for domain submission endpoints."""

    @pytest.mark.asyncio
    async def test_submit_domain(self, test_client: AsyncClient):
        """Test submitting a new domain."""
        response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "newdomain.com"},
        )

        assert response.status_code == 201
        data = response.json()
        assert data["domain"] == "newdomain.com"
        assert "verification_token" in data
        assert "verification_record" in data
        assert "instructions" in data

    @pytest.mark.asyncio
    async def test_submit_domain_invalid(self, test_client: AsyncClient):
        """Test submitting an invalid domain."""
        response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": ""},
        )

        assert response.status_code == 422  # Validation error

    @pytest.mark.asyncio
    async def test_submit_domain_duplicate(self, test_client: AsyncClient, seeded_db):
        """Test submitting a duplicate verified domain returns 409."""
        # example.com is seeded as a verified domain
        response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "example.com"},
        )

        assert response.status_code == 409
        data = response.json()
        assert "already" in data["detail"]["message"].lower()

    @pytest.mark.asyncio
    async def test_submit_domain_duplicate_unverified(self, test_client: AsyncClient):
        """Test submitting an unverified domain again returns existing token (idempotent)."""
        # First submission
        first_response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "idempotent.com"},
        )
        assert first_response.status_code == 201
        first_token = first_response.json()["verification_token"]

        # Second submission returns same token (idempotent)
        second_response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "idempotent.com"},
        )
        assert second_response.status_code == 201
        assert second_response.json()["verification_token"] == first_token

    @pytest.mark.asyncio
    async def test_submit_domain_normalizes_case(self, test_client: AsyncClient):
        """Test that domain submission normalizes to lowercase."""
        response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "UPPERCASE.COM"},
        )

        assert response.status_code == 201
        data = response.json()
        assert data["domain"] == "uppercase.com"


class TestDomainVerification:
    """Tests for domain verification endpoints."""

    @pytest.mark.asyncio
    async def test_verify_domain_success(self, test_client: AsyncClient):
        """Test successful domain verification."""
        # First submit the domain
        submit_response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "verify-test.com"},
        )
        token = submit_response.json()["verification_token"]

        # Mock DNS lookup to return the token
        with patch(
            "dns_aid.api.routes.domains.dns.resolver.resolve",
            return_value=create_mock_dns_answer(token),
        ):
            response = await test_client.post(
                "/api/v1/domains/verify",
                json={"domain": "verify-test.com"},
            )

        assert response.status_code == 200
        data = response.json()
        assert data["domain"] == "verify-test.com"
        assert data["verified"] is True

    @pytest.mark.asyncio
    async def test_verify_domain_not_found(self, test_client: AsyncClient):
        """Test verification of non-existent domain."""
        response = await test_client.post(
            "/api/v1/domains/verify",
            json={"domain": "nonexistent.com"},
        )

        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_verify_domain_wrong_token(self, test_client: AsyncClient):
        """Test verification with wrong token."""
        # First submit the domain
        await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "wrong-token.com"},
        )

        # Mock DNS lookup to return wrong token
        with patch(
            "dns_aid.api.routes.domains.dns.resolver.resolve",
            return_value=create_mock_dns_answer("wrong-token"),
        ):
            response = await test_client.post(
                "/api/v1/domains/verify",
                json={"domain": "wrong-token.com"},
            )

        assert response.status_code == 400
        data = response.json()
        assert "verification" in data["detail"]["message"].lower()

    @pytest.mark.asyncio
    async def test_verify_domain_dns_error(self, test_client: AsyncClient):
        """Test verification when DNS lookup fails."""
        import dns.resolver

        # First submit the domain
        await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "dns-error.com"},
        )

        # Mock DNS lookup to raise NXDOMAIN
        with patch(
            "dns_aid.api.routes.domains.dns.resolver.resolve",
            side_effect=dns.resolver.NXDOMAIN(),
        ):
            response = await test_client.post(
                "/api/v1/domains/verify",
                json={"domain": "dns-error.com"},
            )

        assert response.status_code == 400


class TestDomainRetrieval:
    """Tests for domain retrieval endpoints."""

    @pytest.mark.asyncio
    async def test_get_domain(self, test_client: AsyncClient, seeded_db):
        """Test getting domain details."""
        response = await test_client.get("/api/v1/domains/example.com")

        assert response.status_code == 200
        data = response.json()
        assert data["domain"] == "example.com"
        assert data["verified"] is True
        assert "agent_count" in data

    @pytest.mark.asyncio
    async def test_get_domain_not_found(self, test_client: AsyncClient):
        """Test getting non-existent domain."""
        response = await test_client.get("/api/v1/domains/nonexistent.com")

        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_get_domain_case_insensitive(self, test_client: AsyncClient, seeded_db):
        """Test domain lookup is case insensitive."""
        response = await test_client.get("/api/v1/domains/EXAMPLE.COM")

        assert response.status_code == 200
        data = response.json()
        assert data["domain"] == "example.com"


class TestDomainDeletion:
    """Tests for domain deletion endpoints."""

    @pytest.mark.asyncio
    async def test_delete_domain(self, test_client: AsyncClient, seeded_db):
        """Test deleting a domain."""
        response = await test_client.delete("/api/v1/domains/example.com")

        assert response.status_code == 204

        # Verify it's gone
        get_response = await test_client.get("/api/v1/domains/example.com")
        assert get_response.status_code == 404

    @pytest.mark.asyncio
    async def test_delete_domain_not_found(self, test_client: AsyncClient):
        """Test deleting non-existent domain."""
        response = await test_client.delete("/api/v1/domains/nonexistent.com")

        assert response.status_code == 404
