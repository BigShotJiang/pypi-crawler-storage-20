"""Unit tests for agent endpoints."""

import pytest
from httpx import AsyncClient


class TestAgentRetrieval:
    """Tests for agent retrieval endpoints."""

    @pytest.mark.asyncio
    async def test_get_agent(self, test_client: AsyncClient, seeded_db):
        """Test getting agent details by FQDN."""
        response = await test_client.get("/api/v1/agents/_network._mcp._agents.example.com")

        assert response.status_code == 200
        data = response.json()
        assert data["fqdn"] == "_network._mcp._agents.example.com"
        assert data["name"] == "network"
        assert data["protocol"] == "mcp"
        assert data["domain"] == "example.com"
        assert "security_score" in data
        assert "capabilities" in data

    @pytest.mark.asyncio
    async def test_get_agent_not_found(self, test_client: AsyncClient):
        """Test getting non-existent agent."""
        response = await test_client.get("/api/v1/agents/_nonexistent._mcp._agents.example.com")

        assert response.status_code == 404
        data = response.json()
        assert data["detail"]["code"] == "DNS_AID_002"

    @pytest.mark.asyncio
    async def test_get_agent_case_insensitive(self, test_client: AsyncClient, seeded_db):
        """Test agent lookup is case insensitive."""
        response = await test_client.get("/api/v1/agents/_NETWORK._MCP._AGENTS.EXAMPLE.COM")

        assert response.status_code == 200


class TestAgentListing:
    """Tests for agent listing endpoints."""

    @pytest.mark.asyncio
    async def test_list_agents(self, test_client: AsyncClient, seeded_db):
        """Test listing all agents."""
        response = await test_client.get("/api/v1/agents")

        assert response.status_code == 200
        data = response.json()
        assert "agents" in data
        assert "total" in data
        assert "limit" in data
        assert "offset" in data
        assert len(data["agents"]) >= 1

    @pytest.mark.asyncio
    async def test_list_agents_by_domain(self, test_client: AsyncClient, seeded_db):
        """Test listing agents filtered by domain."""
        response = await test_client.get("/api/v1/agents?domain=example.com")

        assert response.status_code == 200
        data = response.json()
        assert all(a["domain"] == "example.com" for a in data["agents"])

    @pytest.mark.asyncio
    async def test_list_agents_by_protocol(self, test_client: AsyncClient, seeded_db):
        """Test listing agents filtered by protocol."""
        response = await test_client.get("/api/v1/agents?protocol=mcp")

        assert response.status_code == 200
        data = response.json()
        assert all(a["protocol"] == "mcp" for a in data["agents"])

    @pytest.mark.asyncio
    async def test_list_agents_pagination(self, test_client: AsyncClient, seeded_db):
        """Test agent listing pagination."""
        response = await test_client.get("/api/v1/agents?limit=1&offset=0")

        assert response.status_code == 200
        data = response.json()
        assert data["limit"] == 1
        assert data["offset"] == 0
        assert len(data["agents"]) <= 1

    @pytest.mark.asyncio
    async def test_list_agents_empty(self, test_client: AsyncClient):
        """Test listing agents when none exist."""
        response = await test_client.get("/api/v1/agents")

        assert response.status_code == 200
        data = response.json()
        assert data["agents"] == []
        assert data["total"] == 0


class TestDomainAgents:
    """Tests for domain-specific agent endpoints."""

    @pytest.mark.asyncio
    async def test_list_domain_agents(self, test_client: AsyncClient, seeded_db):
        """Test listing agents for a specific domain."""
        response = await test_client.get("/api/v1/domains/example.com/agents")

        assert response.status_code == 200
        data = response.json()
        assert "agents" in data
        assert all(a["domain"] == "example.com" for a in data["agents"])

    @pytest.mark.asyncio
    async def test_list_domain_agents_with_protocol(self, test_client: AsyncClient, seeded_db):
        """Test listing domain agents filtered by protocol."""
        response = await test_client.get("/api/v1/domains/example.com/agents?protocol=mcp")

        assert response.status_code == 200
        data = response.json()
        assert all(a["protocol"] == "mcp" for a in data["agents"])

    @pytest.mark.asyncio
    async def test_list_domain_agents_not_found(self, test_client: AsyncClient):
        """Test listing agents for non-existent domain."""
        response = await test_client.get("/api/v1/domains/nonexistent.com/agents")

        assert response.status_code == 404


class TestAgentDeletion:
    """Tests for agent deletion endpoints."""

    @pytest.mark.asyncio
    async def test_delete_agent(self, test_client: AsyncClient, seeded_db):
        """Test deleting an agent."""
        response = await test_client.delete("/api/v1/agents/_network._mcp._agents.example.com")

        assert response.status_code == 204

        # Verify it's gone
        get_response = await test_client.get("/api/v1/agents/_network._mcp._agents.example.com")
        assert get_response.status_code == 404

    @pytest.mark.asyncio
    async def test_delete_agent_not_found(self, test_client: AsyncClient):
        """Test deleting non-existent agent."""
        response = await test_client.delete("/api/v1/agents/_nonexistent._mcp._agents.example.com")

        assert response.status_code == 404


class TestAgentResponseFormat:
    """Tests for agent response format."""

    @pytest.mark.asyncio
    async def test_agent_response_has_all_fields(self, test_client: AsyncClient, seeded_db):
        """Test that agent response includes all expected fields."""
        response = await test_client.get("/api/v1/agents/_network._mcp._agents.example.com")

        assert response.status_code == 200
        data = response.json()

        # Required fields
        required_fields = [
            "fqdn",
            "domain",
            "name",
            "protocol",
            "port",
            "capabilities",
            "security_score",
            "trust_score",
            "popularity_score",
            "threat_flags",
            "first_seen",
            "last_seen",
        ]

        for field in required_fields:
            assert field in data, f"Missing field: {field}"

    @pytest.mark.asyncio
    async def test_agent_response_scores_are_integers(self, test_client: AsyncClient, seeded_db):
        """Test that scores are returned as integers."""
        response = await test_client.get("/api/v1/agents/_network._mcp._agents.example.com")

        data = response.json()
        assert isinstance(data["security_score"], int)
        assert isinstance(data["trust_score"], int)
        assert isinstance(data["popularity_score"], int)
