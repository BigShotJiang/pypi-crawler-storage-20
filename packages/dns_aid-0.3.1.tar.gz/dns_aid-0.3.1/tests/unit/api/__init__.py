"""Unit tests for DNS-AID API module."""
