"""Unit tests for search endpoints."""

import pytest
from httpx import AsyncClient


class TestSearchEndpoint:
    """Tests for the main search endpoint."""

    @pytest.mark.asyncio
    async def test_search_basic(self, test_client: AsyncClient, seeded_db):
        """Test basic search functionality."""
        response = await test_client.get("/api/v1/search?q=network")

        assert response.status_code == 200
        data = response.json()
        assert "query" in data
        assert "results" in data
        assert "total" in data
        assert data["query"] == "network"

    @pytest.mark.asyncio
    async def test_search_returns_matching_agents(self, test_client: AsyncClient, seeded_db):
        """Test that search returns matching agents."""
        response = await test_client.get("/api/v1/search?q=network")

        assert response.status_code == 200
        data = response.json()
        assert data["total"] >= 1
        assert any("network" in r["agent"]["name"].lower() for r in data["results"])

    @pytest.mark.asyncio
    async def test_search_by_capability(self, test_client: AsyncClient, seeded_db):
        """Test searching by capability."""
        response = await test_client.get("/api/v1/search?q=ipam")

        assert response.status_code == 200
        data = response.json()
        # Should find agents with ipam capability
        assert data["total"] >= 0

    @pytest.mark.asyncio
    async def test_search_with_protocol_filter(self, test_client: AsyncClient, seeded_db):
        """Test search with protocol filter."""
        response = await test_client.get("/api/v1/search?q=network&protocol=mcp")

        assert response.status_code == 200
        data = response.json()
        assert all(r["agent"]["protocol"] == "mcp" for r in data["results"])

    @pytest.mark.asyncio
    async def test_search_with_domain_filter(self, test_client: AsyncClient, seeded_db):
        """Test search with domain filter."""
        response = await test_client.get("/api/v1/search?q=network&domain=example.com")

        assert response.status_code == 200
        data = response.json()
        assert all(r["agent"]["domain"] == "example.com" for r in data["results"])

    @pytest.mark.asyncio
    async def test_search_with_min_security_score(self, test_client: AsyncClient, seeded_db):
        """Test search with minimum security score filter."""
        response = await test_client.get("/api/v1/search?q=network&min_security_score=80")

        assert response.status_code == 200
        data = response.json()
        assert all(r["agent"]["security_score"] >= 80 for r in data["results"])

    @pytest.mark.asyncio
    async def test_search_pagination(self, test_client: AsyncClient, seeded_db):
        """Test search pagination."""
        response = await test_client.get("/api/v1/search?q=network&limit=1&offset=0")

        assert response.status_code == 200
        data = response.json()
        assert data["limit"] == 1
        assert data["offset"] == 0
        assert len(data["results"]) <= 1

    @pytest.mark.asyncio
    async def test_search_no_results(self, test_client: AsyncClient):
        """Test search with no matching results."""
        response = await test_client.get("/api/v1/search?q=nonexistentquery12345")

        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 0
        assert data["results"] == []

    @pytest.mark.asyncio
    async def test_search_empty_query_rejected(self, test_client: AsyncClient):
        """Test that empty query is rejected."""
        response = await test_client.get("/api/v1/search?q=")

        assert response.status_code == 422  # Validation error

    @pytest.mark.asyncio
    async def test_search_query_too_long(self, test_client: AsyncClient):
        """Test that overly long query is rejected."""
        long_query = "a" * 101
        response = await test_client.get(f"/api/v1/search?q={long_query}")

        assert response.status_code == 422

    @pytest.mark.asyncio
    async def test_search_results_have_score(self, test_client: AsyncClient, seeded_db):
        """Test that search results include relevance score."""
        response = await test_client.get("/api/v1/search?q=network")

        assert response.status_code == 200
        data = response.json()
        for result in data["results"]:
            assert "score" in result
            assert isinstance(result["score"], (int, float))


class TestSearchSuggestions:
    """Tests for search suggestions endpoint."""

    @pytest.mark.asyncio
    async def test_get_suggestions(self, test_client: AsyncClient, seeded_db):
        """Test getting search suggestions."""
        response = await test_client.get("/api/v1/search/suggestions?prefix=net")

        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        # All suggestions should start with prefix
        assert all(s.lower().startswith("net") for s in data)

    @pytest.mark.asyncio
    async def test_suggestions_with_limit(self, test_client: AsyncClient, seeded_db):
        """Test suggestions with custom limit."""
        response = await test_client.get("/api/v1/search/suggestions?prefix=n&limit=5")

        assert response.status_code == 200
        data = response.json()
        assert len(data) <= 5

    @pytest.mark.asyncio
    async def test_suggestions_empty_prefix(self, test_client: AsyncClient):
        """Test suggestions with empty prefix is rejected."""
        response = await test_client.get("/api/v1/search/suggestions?prefix=")

        assert response.status_code == 422

    @pytest.mark.asyncio
    async def test_suggestions_no_matches(self, test_client: AsyncClient):
        """Test suggestions with no matching prefix."""
        response = await test_client.get("/api/v1/search/suggestions?prefix=xyz123nonexistent")

        assert response.status_code == 200
        data = response.json()
        assert data == []


class TestPopularCapabilities:
    """Tests for popular capabilities endpoint."""

    @pytest.mark.asyncio
    async def test_get_popular_capabilities(self, test_client: AsyncClient, seeded_db):
        """Test getting popular capabilities."""
        response = await test_client.get("/api/v1/search/capabilities")

        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        # Each item should have capability and count
        for item in data:
            assert "capability" in item
            assert "count" in item

    @pytest.mark.asyncio
    async def test_capabilities_with_limit(self, test_client: AsyncClient, seeded_db):
        """Test capabilities with custom limit."""
        response = await test_client.get("/api/v1/search/capabilities?limit=5")

        assert response.status_code == 200
        data = response.json()
        assert len(data) <= 5

    @pytest.mark.asyncio
    async def test_capabilities_empty_db(self, test_client: AsyncClient):
        """Test capabilities on empty database."""
        response = await test_client.get("/api/v1/search/capabilities")

        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)


class TestSearchResponseFormat:
    """Tests for search response format."""

    @pytest.mark.asyncio
    async def test_search_result_agent_format(self, test_client: AsyncClient, seeded_db):
        """Test that search result agents have correct format."""
        response = await test_client.get("/api/v1/search?q=network")

        assert response.status_code == 200
        data = response.json()

        for result in data["results"]:
            agent = result["agent"]
            # Check required agent fields
            assert "fqdn" in agent
            assert "domain" in agent
            assert "name" in agent
            assert "protocol" in agent
            assert "capabilities" in agent
            assert "security_score" in agent
