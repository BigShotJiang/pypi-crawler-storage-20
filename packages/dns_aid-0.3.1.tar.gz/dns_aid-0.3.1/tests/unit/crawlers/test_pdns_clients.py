"""Unit tests for passive DNS client infrastructure."""

import pytest

from dns_aid.clients.pdns_base import PDNSProvider, PDNSQueryResult, PDNSRecord
from dns_aid.clients.pdns_mock import MockPDNSProvider, get_provider


class TestPDNSRecord:
    """Tests for PDNSRecord dataclass."""

    def test_pdns_record_creation(self):
        """Test creating a pDNS record."""
        record = PDNSRecord(
            rrname="_chat._mcp._agents.example.com",
            rrtype="SVCB",
            rdata='1 mcp.example.com. alpn="mcp" port=443',
            time_first=1704067200,
            time_last=1704153600,
            count=1500,
            bailiwick="example.com",
        )

        assert record.rrname == "_chat._mcp._agents.example.com"
        assert record.rrtype == "SVCB"
        assert record.count == 1500

    def test_pdns_record_defaults(self):
        """Test default values for pDNS record."""
        record = PDNSRecord(
            rrname="example.com",
            rrtype="A",
            rdata="93.184.216.34",
            time_first=1704067200,
            time_last=1704153600,
        )

        assert record.count is None
        assert record.bailiwick is None

    def test_pdns_record_is_dns_aid(self):
        """Test DNS-AID record detection."""
        # Valid DNS-AID record
        dns_aid_record = PDNSRecord(
            rrname="_chat._mcp._agents.example.com",
            rrtype="SVCB",
            rdata="1 mcp.example.com.",
            time_first=1704067200,
            time_last=1704153600,
        )
        assert dns_aid_record.is_dns_aid_record is True

        # Non-DNS-AID record
        normal_record = PDNSRecord(
            rrname="www.example.com",
            rrtype="A",
            rdata="93.184.216.34",
            time_first=1704067200,
            time_last=1704153600,
        )
        assert normal_record.is_dns_aid_record is False

    def test_pdns_record_agent_patterns(self):
        """Test various DNS-AID naming patterns."""
        patterns = [
            "_assistant._mcp._agents.example.com",
            "_chat._a2a._agents.example.com",
            "_api._https._agents.example.com",
            "_network._mcp._agents.sub.example.com",
        ]

        for pattern in patterns:
            record = PDNSRecord(
                rrname=pattern,
                rrtype="SVCB",
                rdata="1 target.example.com.",
                time_first=1704067200,
                time_last=1704153600,
            )
            assert record.is_dns_aid_record is True, f"Pattern {pattern} should be DNS-AID"

    def test_pdns_record_non_agent_patterns(self):
        """Test non-DNS-AID patterns."""
        patterns = [
            "www.example.com",
            "_dmarc.example.com",
            "_acme-challenge.example.com",
            "mcp.example.com",  # Not underscore prefixed
            "_agents.example.com",  # Missing name/protocol
        ]

        for pattern in patterns:
            record = PDNSRecord(
                rrname=pattern,
                rrtype="TXT",
                rdata="v=test",
                time_first=1704067200,
                time_last=1704153600,
            )
            assert record.is_dns_aid_record is False, f"Pattern {pattern} should NOT be DNS-AID"


class TestPDNSQueryResult:
    """Tests for PDNSQueryResult dataclass."""

    def test_query_result_creation(self):
        """Test creating a query result."""
        records = [
            PDNSRecord(
                rrname="_chat._mcp._agents.example.com",
                rrtype="SVCB",
                rdata="1 mcp.example.com.",
                time_first=1704067200,
                time_last=1704153600,
            )
        ]
        result = PDNSQueryResult(
            records=records,
            query_pattern="*.mcp._agents.*",
            truncated=False,
        )

        assert len(result.records) == 1
        assert result.query_pattern == "*.mcp._agents.*"
        assert result.truncated is False
        assert result.count == 1  # count property


class TestMockPDNSProvider:
    """Tests for MockPDNSProvider."""

    def test_mock_provider_creation(self):
        """Test creating a mock provider."""
        provider = MockPDNSProvider()
        assert provider.name == "mock"

    @pytest.mark.asyncio
    async def test_mock_provider_health_check(self):
        """Test mock provider health check."""
        provider = MockPDNSProvider()
        assert await provider.health_check() is True

    @pytest.mark.asyncio
    async def test_query_rrset(self):
        """Test querying by rrname."""
        provider = MockPDNSProvider()

        result = await provider.query_rrset("_assistant._mcp._agents.openai.com")

        assert len(result.records) > 0
        assert all(r.rrname == "_assistant._mcp._agents.openai.com" for r in result.records)

    @pytest.mark.asyncio
    async def test_query_rrset_with_type(self):
        """Test querying by rrname with specific type."""
        provider = MockPDNSProvider()

        result = await provider.query_rrset(
            "_assistant._mcp._agents.openai.com",
            rrtype="SVCB",
        )

        assert all(r.rrtype == "SVCB" for r in result.records)

    @pytest.mark.asyncio
    async def test_query_wildcard(self):
        """Test wildcard pattern query."""
        provider = MockPDNSProvider()

        result = await provider.query_wildcard("*._mcp._agents.*")

        assert len(result.records) > 0
        assert all("_mcp" in r.rrname for r in result.records)

    @pytest.mark.asyncio
    async def test_query_wildcard_with_limit(self):
        """Test wildcard query respects limit."""
        provider = MockPDNSProvider()

        result = await provider.query_wildcard("*._agents.*", limit=2)

        assert len(result.records) <= 2

    @pytest.mark.asyncio
    async def test_query_dns_aid_agents(self):
        """Test querying for DNS-AID agents at a domain."""
        provider = MockPDNSProvider()

        result = await provider.query_dns_aid_agents("openai.com")

        assert len(result.records) > 0
        # All records should be for the domain and be DNS-AID records
        for record in result.records:
            assert "openai.com" in record.rrname
            assert record.is_dns_aid_record

    @pytest.mark.asyncio
    async def test_query_dns_aid_agents_no_results(self):
        """Test querying domain with no agents."""
        provider = MockPDNSProvider()

        result = await provider.query_dns_aid_agents("nonexistent-domain.xyz")

        assert len(result.records) == 0

    @pytest.mark.asyncio
    async def test_mock_data_includes_popularity(self):
        """Test mock data includes popularity counts."""
        provider = MockPDNSProvider()

        result = await provider.query_wildcard("*._agents.*")

        # At least some records should have count
        records_with_count = [r for r in result.records if r.count is not None]
        assert len(records_with_count) > 0

    @pytest.mark.asyncio
    async def test_close_is_safe(self):
        """Test close method doesn't error."""
        provider = MockPDNSProvider()
        await provider.close()  # Should not raise


class TestGetProvider:
    """Tests for provider factory function."""

    def test_get_mock_provider(self):
        """Test getting mock provider."""
        provider = get_provider("mock")
        assert isinstance(provider, MockPDNSProvider)

    def test_get_mock_provider_default(self):
        """Test default provider is mock."""
        provider = get_provider()
        assert isinstance(provider, MockPDNSProvider)

    def test_get_unknown_provider(self):
        """Test unknown provider raises error."""
        with pytest.raises(ValueError, match="Unknown pDNS provider"):
            get_provider("nonexistent")


class TestPDNSProviderAbstract:
    """Tests for PDNSProvider abstract class."""

    def test_cannot_instantiate_abstract(self):
        """Test PDNSProvider cannot be instantiated directly."""
        with pytest.raises(TypeError):
            PDNSProvider()  # type: ignore
