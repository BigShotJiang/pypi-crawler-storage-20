"""Unit tests for Certificate Transparency log monitor."""

from datetime import UTC, datetime
from unittest.mock import patch

import pytest

from dns_aid.crawlers.ct_monitor import (
    CTLogEntry,
    CTMatch,
    CTMonitor,
    MockCTLogSource,
    extract_base_domain,
    matches_pattern,
)


class TestExtractBaseDomain:
    """Tests for extract_base_domain function."""

    def test_simple_subdomain(self):
        """Test extracting from simple subdomain."""
        assert extract_base_domain("mcp.example.com") == "example.com"

    def test_multi_level_subdomain(self):
        """Test extracting from multi-level subdomain."""
        assert extract_base_domain("api.sub.example.com") == "example.com"

    def test_agents_convention(self):
        """Test extracting from DNS-AID convention."""
        assert extract_base_domain("_chat._mcp._agents.example.com") == "example.com"

    def test_two_part_tld(self):
        """Test extracting with two-part TLD."""
        assert extract_base_domain("mcp.example.co.uk") == "example.co.uk"
        assert extract_base_domain("api.sub.example.co.uk") == "example.co.uk"

    def test_case_insensitive(self):
        """Test extraction is case insensitive."""
        assert extract_base_domain("MCP.EXAMPLE.COM") == "example.com"

    def test_trailing_dot(self):
        """Test handling trailing dot."""
        assert extract_base_domain("mcp.example.com.") == "example.com"

    def test_bare_domain(self):
        """Test handling bare domain."""
        assert extract_base_domain("example.com") == "example.com"


class TestMatchesPattern:
    """Tests for matches_pattern function."""

    def test_exact_prefix_match(self):
        """Test matching prefix pattern."""
        assert matches_pattern("mcp.example.com", "mcp.*") is True
        assert matches_pattern("agent.example.com", "agent.*") is True

    def test_wildcard_in_middle(self):
        """Test wildcard in middle of pattern."""
        assert matches_pattern("_chat._mcp._agents.example.com", "*._agents.*") is True

    def test_no_match(self):
        """Test non-matching domain."""
        assert matches_pattern("www.example.com", "mcp.*") is False
        assert matches_pattern("api.example.com", "agent.*") is False

    def test_case_insensitive(self):
        """Test matching is case insensitive."""
        assert matches_pattern("MCP.EXAMPLE.COM", "mcp.*") is True


class TestCTLogEntry:
    """Tests for CTLogEntry dataclass."""

    def test_entry_creation(self):
        """Test creating a CT log entry."""
        entry = CTLogEntry(
            serial_number="abc123",
            issuer="Let's Encrypt",
            not_before=datetime.now(UTC),
            not_after=datetime.now(UTC),
            common_name="mcp.example.com",
            san_domains=["mcp.example.com", "www.example.com"],
            log_name="argon",
            log_index=12345,
        )

        assert entry.serial_number == "abc123"
        assert entry.common_name == "mcp.example.com"

    def test_all_domains(self):
        """Test all_domains property."""
        entry = CTLogEntry(
            serial_number="abc123",
            issuer="Test CA",
            not_before=datetime.now(UTC),
            not_after=datetime.now(UTC),
            common_name="mcp.example.com",
            san_domains=["www.example.com", "api.example.com"],
        )

        all_domains = entry.all_domains
        assert "mcp.example.com" in all_domains
        assert "www.example.com" in all_domains
        assert "api.example.com" in all_domains

    def test_all_domains_deduplicates(self):
        """Test all_domains deduplicates CN and SANs."""
        entry = CTLogEntry(
            serial_number="abc123",
            issuer="Test CA",
            not_before=datetime.now(UTC),
            not_after=datetime.now(UTC),
            common_name="mcp.example.com",
            san_domains=["mcp.example.com"],  # Same as CN
        )

        all_domains = entry.all_domains
        assert len(all_domains) == 1


class TestCTMatch:
    """Tests for CTMatch dataclass."""

    def test_match_creation(self):
        """Test creating a CT match."""
        entry = CTLogEntry(
            serial_number="abc123",
            issuer="Test CA",
            not_before=datetime.now(UTC),
            not_after=datetime.now(UTC),
            common_name="mcp.example.com",
        )

        match = CTMatch(
            entry=entry,
            matched_domain="mcp.example.com",
            matched_pattern="mcp.*",
            base_domain="example.com",
        )

        assert match.matched_pattern == "mcp.*"
        assert match.base_domain == "example.com"


class TestMockCTLogSource:
    """Tests for MockCTLogSource."""

    def test_source_creation(self):
        """Test creating mock source."""
        source = MockCTLogSource(entries_per_batch=5, delay_seconds=0.1)

        assert source._entries_per_batch == 5
        assert source._delay_seconds == 0.1

    @pytest.mark.asyncio
    async def test_health_check(self):
        """Test mock source health check."""
        source = MockCTLogSource()

        assert await source.health_check() is True

    @pytest.mark.asyncio
    async def test_stream_entries(self):
        """Test streaming entries from mock source."""
        source = MockCTLogSource(entries_per_batch=3, delay_seconds=0.01)

        entries = []
        async for entry in source.stream_entries():
            entries.append(entry)
            if len(entries) >= 5:
                source.stop()
                break

        assert len(entries) >= 3

    @pytest.mark.asyncio
    async def test_stream_includes_dns_aid_domains(self):
        """Test stream includes DNS-AID relevant domains."""
        source = MockCTLogSource(entries_per_batch=20, delay_seconds=0.01)

        dns_aid_found = False
        async for entry in source.stream_entries():
            for domain in entry.all_domains:
                if "mcp" in domain or "agent" in domain or "a2a" in domain:
                    dns_aid_found = True
                    break
            if dns_aid_found:
                source.stop()
                break

        assert dns_aid_found, "Mock source should include DNS-AID relevant domains"


class TestCTMonitor:
    """Tests for CTMonitor."""

    def test_monitor_creation(self):
        """Test creating CT monitor."""
        monitor = CTMonitor()

        assert monitor._running is False
        assert len(monitor._patterns) > 0

    def test_monitor_custom_patterns(self):
        """Test monitor with custom patterns."""
        patterns = ["custom.*", "test.*"]
        monitor = CTMonitor(patterns=patterns)

        assert monitor._patterns == patterns

    def test_matches_property(self):
        """Test matches property returns copy."""
        monitor = CTMonitor()

        matches = monitor.matches
        assert isinstance(matches, list)
        assert matches is not monitor._matches  # Should be a copy

    def test_unique_domains_property(self):
        """Test unique_domains property."""
        monitor = CTMonitor()

        domains = monitor.unique_domains
        assert isinstance(domains, set)

    @pytest.mark.asyncio
    async def test_start_disabled(self):
        """Test start when CT monitor is disabled."""
        monitor = CTMonitor()

        with patch("dns_aid.crawlers.ct_monitor.ENABLE_CT_MONITOR", False):
            await monitor.start()

        # Should return immediately without processing

    @pytest.mark.asyncio
    async def test_run_batch(self):
        """Test batch processing."""
        source = MockCTLogSource(entries_per_batch=10, delay_seconds=0.01)
        monitor = CTMonitor(source=source)

        matches = await monitor.run_batch(max_entries=20)

        assert isinstance(matches, list)
        # May or may not have matches depending on random data

    @pytest.mark.asyncio
    async def test_run_batch_disabled(self):
        """Test batch when CT monitor is disabled."""
        monitor = CTMonitor()

        with patch("dns_aid.crawlers.ct_monitor.ENABLE_CT_MONITOR", False):
            matches = await monitor.run_batch(max_entries=10)

        assert matches == []

    @pytest.mark.asyncio
    async def test_on_match_callback(self):
        """Test on_match callback is called."""
        source = MockCTLogSource(entries_per_batch=5, delay_seconds=0.01)
        callback_called = []

        def on_match(match):
            callback_called.append(match)

        monitor = CTMonitor(
            source=source,
            patterns=["mcp.*", "*._agents.*"],  # Patterns that will match
            on_match=on_match,
        )

        await monitor.run_batch(max_entries=50)

        # Callback should be called for any matches
        # (may be empty if no matching domains in batch)

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test monitor as async context manager."""
        async with CTMonitor() as monitor:
            assert monitor is not None

    def test_stop(self):
        """Test stop method."""
        monitor = CTMonitor()
        monitor._running = True

        monitor.stop()

        assert monitor._running is False
