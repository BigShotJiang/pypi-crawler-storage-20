"""Unit tests for passive DNS crawler."""

from unittest.mock import AsyncMock, patch

import pytest

from dns_aid.clients.pdns_base import PDNSQueryResult, PDNSRecord
from dns_aid.clients.pdns_mock import MockPDNSProvider
from dns_aid.crawlers.passive_dns import (
    PassiveDNSCrawler,
    parse_dns_aid_fqdn,
    parse_svcb_rdata,
    parse_txt_rdata,
)


class TestParseDNSAIDFqdn:
    """Tests for parse_dns_aid_fqdn function."""

    def test_parse_valid_fqdn(self):
        """Test parsing valid DNS-AID FQDN."""
        result = parse_dns_aid_fqdn("_chat._mcp._agents.example.com")

        assert result is not None
        assert result.name == "chat"
        assert result.protocol == "mcp"
        assert result.domain == "example.com"
        assert result.fqdn == "_chat._mcp._agents.example.com"

    def test_parse_fqdn_with_trailing_dot(self):
        """Test parsing FQDN with trailing dot."""
        result = parse_dns_aid_fqdn("_chat._mcp._agents.example.com.")

        assert result is not None
        assert result.domain == "example.com"

    def test_parse_fqdn_case_insensitive(self):
        """Test parsing is case insensitive."""
        result = parse_dns_aid_fqdn("_CHAT._MCP._AGENTS.EXAMPLE.COM")

        assert result is not None
        assert result.name == "chat"
        assert result.protocol == "mcp"

    def test_parse_fqdn_with_hyphen(self):
        """Test parsing name with hyphen."""
        result = parse_dns_aid_fqdn("_my-agent._mcp._agents.example.com")

        assert result is not None
        assert result.name == "my-agent"

    def test_parse_fqdn_a2a_protocol(self):
        """Test parsing A2A protocol."""
        result = parse_dns_aid_fqdn("_assistant._a2a._agents.anthropic.com")

        assert result is not None
        assert result.protocol == "a2a"
        assert result.domain == "anthropic.com"

    def test_parse_fqdn_subdomain(self):
        """Test parsing with subdomain in base domain."""
        result = parse_dns_aid_fqdn("_api._mcp._agents.sub.example.com")

        assert result is not None
        assert result.domain == "sub.example.com"

    def test_parse_invalid_fqdn_missing_agents(self):
        """Test invalid FQDN without _agents."""
        result = parse_dns_aid_fqdn("_chat._mcp.example.com")
        assert result is None

    def test_parse_invalid_fqdn_normal_record(self):
        """Test invalid FQDN for normal record."""
        result = parse_dns_aid_fqdn("www.example.com")
        assert result is None

    def test_parse_invalid_fqdn_empty(self):
        """Test invalid empty FQDN."""
        result = parse_dns_aid_fqdn("")
        assert result is None


class TestParseSVCBRdata:
    """Tests for parse_svcb_rdata function."""

    def test_parse_basic_svcb(self):
        """Test parsing basic SVCB rdata."""
        result = parse_svcb_rdata('1 target.example.com. alpn="mcp" port=443')

        assert result["priority"] == 1
        assert result["target"] == "target.example.com"
        assert result["alpn"] == "mcp"
        assert result["port"] == 443

    def test_parse_svcb_default_port(self):
        """Test SVCB with default port."""
        result = parse_svcb_rdata('1 target.example.com. alpn="mcp"')

        assert result["port"] == 443  # Default

    def test_parse_svcb_priority_only(self):
        """Test minimal SVCB with just priority and target."""
        result = parse_svcb_rdata("1 target.example.com.")

        assert result["priority"] == 1
        assert result["target"] == "target.example.com"
        assert result["alpn"] is None

    def test_parse_svcb_with_extra_params(self):
        """Test SVCB with additional parameters."""
        result = parse_svcb_rdata('1 target.example.com. alpn="mcp" port=8443 ipv4hint=192.168.1.1')

        assert result["port"] == 8443
        assert result["ipv4hint"] == "192.168.1.1"


class TestParseTXTRdata:
    """Tests for parse_txt_rdata function."""

    def test_parse_txt_capabilities(self):
        """Test parsing TXT with capabilities."""
        result = parse_txt_rdata("capabilities=chat,code,analysis version=1.0.0")

        assert result["capabilities"] == ["chat", "code", "analysis"]
        assert result["version"] == "1.0.0"

    def test_parse_txt_list_input(self):
        """Test parsing TXT from list of strings."""
        result = parse_txt_rdata(["capabilities=chat,code", "version=2.0"])

        assert "chat" in result["capabilities"]
        assert result["version"] == "2.0"

    def test_parse_txt_empty(self):
        """Test parsing empty TXT."""
        result = parse_txt_rdata("")

        assert result["capabilities"] == []
        assert result["version"] is None


class TestPassiveDNSCrawler:
    """Tests for PassiveDNSCrawler."""

    def test_crawler_creation(self):
        """Test creating passive DNS crawler."""
        crawler = PassiveDNSCrawler()
        assert crawler.name == "passive-dns"

    def test_crawler_with_custom_provider(self):
        """Test creating crawler with custom provider."""
        provider = MockPDNSProvider()
        crawler = PassiveDNSCrawler(provider=provider)
        assert crawler._provider is provider

    @pytest.mark.asyncio
    async def test_crawl_domain(self):
        """Test crawling a specific domain."""
        crawler = PassiveDNSCrawler()

        with patch.object(
            crawler._provider,
            "query_dns_aid_agents",
            new_callable=AsyncMock,
            return_value=PDNSQueryResult(
                records=[
                    PDNSRecord(
                        rrname="_chat._mcp._agents.test.com",
                        rrtype="SVCB",
                        rdata='1 mcp.test.com. alpn="mcp" port=443',
                        time_first=1704067200,
                        time_last=1704153600,
                        count=1000,
                    ),
                ],
                query_pattern="test.com",
                truncated=False,
            ),
        ):
            result = await crawler.crawl("test.com")

        assert result.status in ["success", "partial"]

    @pytest.mark.asyncio
    async def test_crawl_blocked_domain(self):
        """Test crawling blocked domain."""
        crawler = PassiveDNSCrawler()

        result = await crawler.crawl("example.com")  # example.com is in blocklist

        assert result.status == "blocked"

    @pytest.mark.asyncio
    async def test_crawl_disabled(self):
        """Test crawl when pDNS is disabled."""
        crawler = PassiveDNSCrawler()

        with patch("dns_aid.crawlers.passive_dns.ENABLE_PDNS_CRAWLER", False):
            result = await crawler.crawl("valid-domain.com")

        assert result.status == "skipped"

    @pytest.mark.asyncio
    async def test_discover_all(self):
        """Test global discovery."""
        provider = MockPDNSProvider()
        crawler = PassiveDNSCrawler(provider=provider)

        result = await crawler.discover_all(limit=5)

        assert result.status in ["success", "skipped"]
        # If not skipped, should have agents
        if result.status == "success":
            assert isinstance(result.agents_found, list)

    @pytest.mark.asyncio
    async def test_discover_all_with_protocol_filter(self):
        """Test global discovery with protocol filter."""
        provider = MockPDNSProvider()
        crawler = PassiveDNSCrawler(provider=provider)

        result = await crawler.discover_all(protocol="mcp", limit=5)

        assert result.status in ["success", "skipped"]

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Test crawler as async context manager."""
        async with PassiveDNSCrawler() as crawler:
            assert crawler is not None

    @pytest.mark.asyncio
    async def test_popularity_score_in_metadata(self):
        """Test agents have popularity score in metadata."""
        crawler = PassiveDNSCrawler()

        with patch.object(
            crawler._provider,
            "query_dns_aid_agents",
            new_callable=AsyncMock,
            return_value=PDNSQueryResult(
                records=[
                    PDNSRecord(
                        rrname="_chat._mcp._agents.popular.com",
                        rrtype="SVCB",
                        rdata='1 mcp.popular.com. alpn="mcp"',
                        time_first=1704067200,
                        time_last=1704153600,
                        count=100000,  # 100K queries
                    ),
                ],
                query_pattern="popular.com",
                truncated=False,
            ),
        ):
            result = await crawler.crawl("popular.com")

        if result.agents_found:
            agent = result.agents_found[0]
            assert "popularity_score" in agent.metadata
            assert agent.metadata["popularity_score"] > 0
