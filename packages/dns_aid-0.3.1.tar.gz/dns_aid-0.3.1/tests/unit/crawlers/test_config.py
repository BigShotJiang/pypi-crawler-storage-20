"""Unit tests for crawler configuration module."""

import os
from unittest.mock import patch

import pytest

from dns_aid.crawlers.config import (
    CT_LOG_CONFIG,
    DNS_QUERY_CONFIG,
    ENABLE_CT_MONITOR,
    ENABLE_NSEC_WALKER,
    ENABLE_PATTERN_PROBER,
    ENABLE_PDNS_CRAWLER,
    PDNS_CONFIG,
    RATE_LIMIT_CONFIG,
    SCHEDULER_CONFIG,
    calculate_popularity_score,
    is_domain_blocked,
)


class TestFeatureFlags:
    """Tests for feature flag configuration."""

    def test_default_feature_flags(self):
        """Test default values for feature flags."""
        # These are the defaults when env vars are not set
        # Note: actual values depend on environment
        assert isinstance(ENABLE_NSEC_WALKER, bool)
        assert isinstance(ENABLE_PDNS_CRAWLER, bool)
        assert isinstance(ENABLE_CT_MONITOR, bool)
        assert isinstance(ENABLE_PATTERN_PROBER, bool)

    def test_enable_nsec_walker_default_false(self):
        """Test NSEC walker is disabled by default (privacy concern)."""
        # Per the plan, NSEC walker should be disabled by default
        with patch.dict(os.environ, {}, clear=True):
            from importlib import reload

            import dns_aid.crawlers.config as config_module

            reload(config_module)
            # The actual default is defined in the module
            assert config_module.ENABLE_NSEC_WALKER is False


class TestDNSQueryConfig:
    """Tests for DNS query configuration."""

    def test_dns_query_config_values(self):
        """Test DNS query config has reasonable defaults."""
        assert DNS_QUERY_CONFIG.timeout_seconds > 0
        assert DNS_QUERY_CONFIG.timeout_seconds <= 30
        assert DNS_QUERY_CONFIG.max_retries >= 1
        assert DNS_QUERY_CONFIG.max_retries <= 10

    def test_dns_query_config_immutable(self):
        """Test config dataclass is frozen."""
        with pytest.raises(AttributeError):
            DNS_QUERY_CONFIG.timeout_seconds = 999  # type: ignore


class TestRateLimitConfig:
    """Tests for rate limit configuration."""

    def test_rate_limit_config_values(self):
        """Test rate limit config has reasonable defaults."""
        assert RATE_LIMIT_CONFIG.queries_per_second_global > 0
        assert RATE_LIMIT_CONFIG.queries_per_second_per_domain > 0
        assert (
            RATE_LIMIT_CONFIG.queries_per_second_per_domain
            <= RATE_LIMIT_CONFIG.queries_per_second_global
        )


class TestSchedulerConfig:
    """Tests for scheduler configuration."""

    def test_scheduler_config_values(self):
        """Test scheduler config has reasonable defaults."""
        assert SCHEDULER_CONFIG.recrawl_interval_seconds >= 3600  # At least 1 hour
        assert SCHEDULER_CONFIG.recrawl_interval_hours >= 1  # Convenience property
        assert SCHEDULER_CONFIG.max_concurrent_crawls >= 1
        assert isinstance(SCHEDULER_CONFIG.auto_recrawl, bool)


class TestPDNSConfig:
    """Tests for passive DNS configuration."""

    def test_pdns_config_values(self):
        """Test pDNS config has reasonable defaults."""
        assert PDNS_CONFIG.default_provider in ["mock", "infoblox", "farsight"]
        assert len(PDNS_CONFIG.search_patterns) > 0
        assert PDNS_CONFIG.max_records_per_pattern > 0

    def test_pdns_search_patterns(self):
        """Test pDNS search patterns include DNS-AID patterns."""
        patterns = PDNS_CONFIG.search_patterns
        # Should have patterns for all protocols
        assert any("_mcp" in p for p in patterns)
        assert any("_a2a" in p for p in patterns)


class TestCTLogConfig:
    """Tests for CT log configuration."""

    def test_ct_log_config_values(self):
        """Test CT log config has reasonable defaults."""
        assert len(CT_LOG_CONFIG.match_patterns) > 0

    def test_ct_log_match_patterns(self):
        """Test CT log patterns match agent-related certs."""
        patterns = CT_LOG_CONFIG.match_patterns
        # Should match common agent subdomains
        assert any("mcp" in p.lower() for p in patterns)
        assert any("agent" in p.lower() for p in patterns)


class TestPopularityScore:
    """Tests for popularity score calculation."""

    def test_popularity_score_zero_queries(self):
        """Test score is 0 for zero queries."""
        assert calculate_popularity_score(0) == 0

    def test_popularity_score_negative_queries(self):
        """Test score is 0 for negative queries."""
        assert calculate_popularity_score(-1) == 0
        assert calculate_popularity_score(-100) == 0

    def test_popularity_score_low_queries(self):
        """Test score for low query counts."""
        score = calculate_popularity_score(10)
        assert 0 < score < 50

    def test_popularity_score_medium_queries(self):
        """Test score for medium query counts (1K)."""
        score = calculate_popularity_score(1000)
        assert 40 <= score <= 60  # ~50 per the formula

    def test_popularity_score_high_queries(self):
        """Test score for high query counts (1M)."""
        score = calculate_popularity_score(1_000_000)
        assert 90 <= score <= 100  # ~100 per the formula

    def test_popularity_score_capped_at_100(self):
        """Test score is capped at 100."""
        score = calculate_popularity_score(10_000_000_000)  # 10B queries
        assert score == 100

    def test_popularity_score_logarithmic(self):
        """Test score increases logarithmically."""
        score_10 = calculate_popularity_score(10)
        score_100 = calculate_popularity_score(100)
        score_1000 = calculate_popularity_score(1000)

        # Each 10x increase should add ~16.67 points
        diff_1 = score_100 - score_10
        diff_2 = score_1000 - score_100

        # Differences should be roughly equal (logarithmic)
        assert abs(diff_1 - diff_2) < 5


class TestDomainBlocklist:
    """Tests for domain blocklist functionality."""

    def test_blocked_domain_localhost(self):
        """Test localhost is blocked."""
        assert is_domain_blocked("localhost") is True
        # Note: only exact "localhost" is blocked, not localhost.localdomain

    def test_blocked_domain_example_domains(self):
        """Test example domains are blocked."""
        assert is_domain_blocked("example.com") is True
        assert is_domain_blocked("example.org") is True
        assert is_domain_blocked("example.net") is True

    def test_blocked_domain_test_tld(self):
        """Test .test TLD is blocked."""
        assert is_domain_blocked("anything.test") is True
        assert is_domain_blocked("sub.domain.test") is True

    def test_blocked_domain_local_tld(self):
        """Test .local TLD is blocked."""
        assert is_domain_blocked("server.local") is True
        assert is_domain_blocked("anything.local") is True

    def test_allowed_domain(self):
        """Test normal domains are not blocked."""
        assert is_domain_blocked("google.com") is False
        assert is_domain_blocked("cloudflare.com") is False
        assert is_domain_blocked("anthropic.com") is False

    def test_blocked_domain_case_insensitive(self):
        """Test blocklist is case insensitive."""
        assert is_domain_blocked("LOCALHOST") is True
        assert is_domain_blocked("Example.COM") is True

    def test_blocklist_exact_match_only(self):
        """Test blocklist uses exact domain match, not subdomain match."""
        # The implementation only blocks exact matches and TLDs,
        # not subdomains of blocked domains
        # This is intentional - sub.example.com could be a valid test target
        # while example.com is explicitly blocked
        assert is_domain_blocked("example.com") is True
        # Subdomains are NOT automatically blocked (by design)
        # Only TLD-based blocking applies
