"""Unit tests for pattern prober crawler."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from dns_aid.crawlers.pattern_prober import PatternProberCrawler, svcb_exists


class TestSvcbExists:
    """Tests for svcb_exists function."""

    @pytest.mark.asyncio
    async def test_svcb_exists_true(self):
        """Test SVCB exists returns True when record found."""
        with patch("dns_aid.crawlers.pattern_prober.dns.asyncresolver.Resolver") as MockResolver:
            resolver = MockResolver.return_value
            resolver.timeout = 5
            resolver.lifetime = 5
            resolver.resolve = AsyncMock(return_value=MagicMock())

            result = await svcb_exists("_chat._mcp._agents.example.com")

        assert result is True

    @pytest.mark.asyncio
    async def test_svcb_exists_nxdomain(self):
        """Test SVCB exists returns False on NXDOMAIN."""
        import dns.resolver

        with patch("dns_aid.crawlers.pattern_prober.dns.asyncresolver.Resolver") as MockResolver:
            resolver = MockResolver.return_value
            resolver.timeout = 5
            resolver.lifetime = 5
            resolver.resolve = AsyncMock(side_effect=dns.resolver.NXDOMAIN())

            result = await svcb_exists("_nonexistent._mcp._agents.example.com")

        assert result is False

    @pytest.mark.asyncio
    async def test_svcb_exists_timeout(self):
        """Test SVCB exists returns False on timeout."""
        import dns.exception

        with patch("dns_aid.crawlers.pattern_prober.dns.asyncresolver.Resolver") as MockResolver:
            resolver = MockResolver.return_value
            resolver.timeout = 5
            resolver.lifetime = 5
            resolver.resolve = AsyncMock(side_effect=dns.exception.Timeout())

            result = await svcb_exists("_timeout._mcp._agents.example.com")

        assert result is False


class TestPatternProberCrawler:
    """Tests for PatternProberCrawler."""

    def test_crawler_creation(self):
        """Test creating pattern prober crawler."""
        crawler = PatternProberCrawler()

        assert crawler.name == "pattern-prober"
        assert len(crawler._names) > 0
        assert len(crawler._protocols) > 0

    def test_crawler_custom_names(self):
        """Test crawler with custom names."""
        crawler = PatternProberCrawler(names=["custom", "agent"])

        assert crawler._names == ["custom", "agent"]

    def test_crawler_custom_protocols(self):
        """Test crawler with custom protocols."""
        crawler = PatternProberCrawler(protocols=["mcp"])

        assert crawler._protocols == ["mcp"]

    def test_crawler_default_names_include_common(self):
        """Test default names include common agent names."""
        crawler = PatternProberCrawler()

        # Should include common names from the plan
        common_names = ["assistant", "chat", "api", "agent", "help"]
        for name in common_names:
            assert name in crawler._names, f"Expected {name} in default names"

    def test_crawler_default_protocols(self):
        """Test default protocols include mcp and a2a."""
        crawler = PatternProberCrawler()

        assert "mcp" in crawler._protocols
        assert "a2a" in crawler._protocols

    @pytest.mark.asyncio
    async def test_crawl_disabled(self):
        """Test crawl when pattern prober is disabled."""
        crawler = PatternProberCrawler()

        with patch("dns_aid.crawlers.pattern_prober.ENABLE_PATTERN_PROBER", False):
            result = await crawler.crawl("valid-domain.com")

        assert result.status == "skipped"

    @pytest.mark.asyncio
    async def test_crawl_blocked_domain(self):
        """Test crawling blocked domain."""
        crawler = PatternProberCrawler()

        result = await crawler.crawl("example.com")  # Blocked

        assert result.status == "blocked"

    @pytest.mark.asyncio
    async def test_crawl_no_agents_found(self):
        """Test crawling domain with no agents."""
        crawler = PatternProberCrawler(names=["test"], protocols=["mcp"])

        with patch(
            "dns_aid.crawlers.pattern_prober.svcb_exists",
            new_callable=AsyncMock,
            return_value=False,
        ):
            result = await crawler.crawl("valid-domain.com")

        assert result.status == "success"
        assert len(result.agents_found) == 0

    @pytest.mark.asyncio
    async def test_crawl_finds_agents(self):
        """Test crawling finds agents."""
        crawler = PatternProberCrawler(
            names=["chat"],
            protocols=["mcp"],
            verify_agents=False,
        )

        mock_agent = MagicMock()
        mock_agent.fqdn = "_chat._mcp._agents.valid-domain.com"
        mock_agent.name = "chat"
        mock_agent.endpoint_url = "https://mcp.valid-domain.com"
        mock_agent.port = 443
        mock_agent.capabilities = ["chat"]
        mock_agent.version = "1.0"

        mock_discovery = MagicMock()
        mock_discovery.agents = [mock_agent]

        with (
            patch(
                "dns_aid.crawlers.pattern_prober.svcb_exists",
                new_callable=AsyncMock,
                return_value=True,
            ),
            patch(
                "dns_aid.crawlers.pattern_prober.discover",
                new_callable=AsyncMock,
                return_value=mock_discovery,
            ),
        ):
            result = await crawler.crawl("valid-domain.com")

        assert result.status == "success"
        assert len(result.agents_found) == 1
        assert result.agents_found[0].name == "chat"

    @pytest.mark.asyncio
    async def test_crawl_concurrent_probes(self):
        """Test crawler respects concurrency limits."""
        crawler = PatternProberCrawler(
            names=["a", "b", "c", "d"],
            protocols=["mcp"],
            max_concurrent=2,
            verify_agents=False,
        )

        probe_count = 0

        async def mock_svcb(*args):
            nonlocal probe_count
            probe_count += 1
            return False

        with patch(
            "dns_aid.crawlers.pattern_prober.svcb_exists",
            side_effect=mock_svcb,
        ):
            await crawler.crawl("valid-domain.com")

        # Should have probed all combinations
        assert probe_count == 4  # 4 names * 1 protocol

    @pytest.mark.asyncio
    async def test_probe_single(self):
        """Test probing single agent."""
        crawler = PatternProberCrawler(verify_agents=False)

        mock_agent = MagicMock()
        mock_agent.fqdn = "_chat._mcp._agents.test.com"
        mock_agent.name = "chat"
        mock_agent.endpoint_url = "https://mcp.test.com"
        mock_agent.port = 443
        mock_agent.capabilities = []
        mock_agent.version = None

        mock_discovery = MagicMock()
        mock_discovery.agents = [mock_agent]

        with (
            patch(
                "dns_aid.crawlers.pattern_prober.svcb_exists",
                new_callable=AsyncMock,
                return_value=True,
            ),
            patch(
                "dns_aid.crawlers.pattern_prober.discover",
                new_callable=AsyncMock,
                return_value=mock_discovery,
            ),
        ):
            result = await crawler.probe_single("test.com", "chat", "mcp")

        assert result is not None
        assert result.name == "chat"
        assert result.protocol == "mcp"

    @pytest.mark.asyncio
    async def test_probe_single_not_found(self):
        """Test probing single agent that doesn't exist."""
        crawler = PatternProberCrawler()

        with patch(
            "dns_aid.crawlers.pattern_prober.svcb_exists",
            new_callable=AsyncMock,
            return_value=False,
        ):
            result = await crawler.probe_single("test.com", "nonexistent", "mcp")

        assert result is None
