"""Unit tests for index reader crawler."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from dns_aid.crawlers.index_reader import (
    AgentRef,
    IndexReaderCrawler,
    index_exists,
    read_index,
)


class TestAgentRef:
    """Tests for AgentRef dataclass."""

    def test_agent_ref_creation(self):
        """Test creating an agent reference."""
        ref = AgentRef(name="chat", protocol="mcp")

        assert ref.name == "chat"
        assert ref.protocol == "mcp"


class TestReadIndex:
    """Tests for read_index function."""

    @pytest.mark.asyncio
    async def test_read_index_success(self):
        """Test reading a valid index record."""
        mock_response = MagicMock()
        mock_rdata = MagicMock()
        mock_rdata.strings = [b"agents=chat:mcp,assistant:a2a,api:https"]
        mock_response.__iter__ = lambda self: iter([mock_rdata])

        with patch("dns_aid.crawlers.index_reader.dns.asyncresolver.Resolver") as MockResolver:
            resolver_instance = MockResolver.return_value
            resolver_instance.resolve = AsyncMock(return_value=mock_response)

            refs = await read_index("example.com")

        assert refs is not None
        assert len(refs) == 3
        assert refs[0].name == "chat"
        assert refs[0].protocol == "mcp"
        assert refs[1].name == "assistant"
        assert refs[1].protocol == "a2a"
        assert refs[2].name == "api"
        assert refs[2].protocol == "https"

    @pytest.mark.asyncio
    async def test_read_index_nxdomain(self):
        """Test reading index when record doesn't exist."""
        import dns.resolver

        with patch("dns_aid.crawlers.index_reader.dns.asyncresolver.Resolver") as MockResolver:
            resolver_instance = MockResolver.return_value
            resolver_instance.resolve = AsyncMock(side_effect=dns.resolver.NXDOMAIN())

            refs = await read_index("no-index.example.com")

        assert refs is None

    @pytest.mark.asyncio
    async def test_read_index_no_answer(self):
        """Test reading index when no TXT answer."""
        import dns.resolver

        with patch("dns_aid.crawlers.index_reader.dns.asyncresolver.Resolver") as MockResolver:
            resolver_instance = MockResolver.return_value
            resolver_instance.resolve = AsyncMock(side_effect=dns.resolver.NoAnswer())

            refs = await read_index("no-txt.example.com")

        assert refs is None

    @pytest.mark.asyncio
    async def test_read_index_malformed(self):
        """Test reading index with malformed TXT record."""
        mock_response = MagicMock()
        mock_rdata = MagicMock()
        mock_rdata.strings = [b"not-an-index-record"]
        mock_response.__iter__ = lambda self: iter([mock_rdata])

        with patch("dns_aid.crawlers.index_reader.dns.asyncresolver.Resolver") as MockResolver:
            resolver_instance = MockResolver.return_value
            resolver_instance.resolve = AsyncMock(return_value=mock_response)

            refs = await read_index("malformed.example.com")

        # Should return None for malformed records
        assert refs is None


class TestIndexExists:
    """Tests for index_exists function."""

    @pytest.mark.asyncio
    async def test_index_exists_true(self):
        """Test index_exists returns True when index found."""
        with patch(
            "dns_aid.crawlers.index_reader.read_index",
            new_callable=AsyncMock,
            return_value=[AgentRef("chat", "mcp")],
        ):
            result = await index_exists("has-index.com")

        assert result is True

    @pytest.mark.asyncio
    async def test_index_exists_false(self):
        """Test index_exists returns False when no index."""
        with patch(
            "dns_aid.crawlers.index_reader.read_index",
            new_callable=AsyncMock,
            return_value=None,
        ):
            result = await index_exists("no-index.com")

        assert result is False


class TestIndexReaderCrawler:
    """Tests for IndexReaderCrawler."""

    def test_crawler_creation(self):
        """Test creating index reader crawler."""
        crawler = IndexReaderCrawler()
        assert crawler.name == "index-reader"
        assert crawler._verify_agents is True

    def test_crawler_without_verification(self):
        """Test creating crawler without verification."""
        crawler = IndexReaderCrawler(verify_agents=False)
        assert crawler._verify_agents is False

    @pytest.mark.asyncio
    async def test_crawl_blocked_domain(self):
        """Test crawling blocked domain."""
        crawler = IndexReaderCrawler()

        result = await crawler.crawl("example.com")  # Blocked domain

        assert result.status == "blocked"

    @pytest.mark.asyncio
    async def test_crawl_no_index(self):
        """Test crawling domain without index record."""
        crawler = IndexReaderCrawler()

        with patch(
            "dns_aid.crawlers.index_reader.read_index",
            new_callable=AsyncMock,
            return_value=None,
        ):
            result = await crawler.crawl("valid-domain.com")

        assert result.status == "success"
        assert "No index record published" in (result.error_message or "")

    @pytest.mark.asyncio
    async def test_crawl_with_index(self):
        """Test crawling domain with valid index."""
        crawler = IndexReaderCrawler(verify_agents=False)

        mock_agent = MagicMock()
        mock_agent.fqdn = "_chat._mcp._agents.valid-domain.com"
        mock_agent.name = "chat"
        mock_agent.endpoint_url = "https://mcp.valid-domain.com"
        mock_agent.port = 443
        mock_agent.capabilities = ["chat"]
        mock_agent.version = "1.0"

        mock_discovery = MagicMock()
        mock_discovery.agents = [mock_agent]

        with (
            patch(
                "dns_aid.crawlers.index_reader.read_index",
                new_callable=AsyncMock,
                return_value=[AgentRef("chat", "mcp")],
            ),
            patch(
                "dns_aid.crawlers.index_reader.discover",
                new_callable=AsyncMock,
                return_value=mock_discovery,
            ),
        ):
            result = await crawler.crawl("valid-domain.com")

        assert result.status == "success"
        assert len(result.agents_found) == 1
        assert result.agents_found[0].name == "chat"

    @pytest.mark.asyncio
    async def test_crawl_with_verification(self):
        """Test crawling with agent verification enabled."""
        crawler = IndexReaderCrawler(verify_agents=True)

        mock_agent = MagicMock()
        mock_agent.fqdn = "_chat._mcp._agents.valid-domain.com"
        mock_agent.name = "chat"
        mock_agent.endpoint_url = "https://mcp.valid-domain.com"
        mock_agent.port = 443
        mock_agent.capabilities = []
        mock_agent.version = None

        mock_discovery = MagicMock()
        mock_discovery.agents = [mock_agent]

        mock_verification = MagicMock()
        mock_verification.security_score = 75
        mock_verification.dnssec_valid = True
        mock_verification.dane_valid = False
        mock_verification.endpoint_reachable = True
        mock_verification.svcb_valid = True

        with (
            patch(
                "dns_aid.crawlers.index_reader.read_index",
                new_callable=AsyncMock,
                return_value=[AgentRef("chat", "mcp")],
            ),
            patch(
                "dns_aid.crawlers.index_reader.discover",
                new_callable=AsyncMock,
                return_value=mock_discovery,
            ),
            patch(
                "dns_aid.crawlers.index_reader.verify",
                new_callable=AsyncMock,
                return_value=mock_verification,
            ),
        ):
            result = await crawler.crawl("valid-domain.com")

        assert result.status == "success"
        assert result.agents_found[0].security_score == 75

    @pytest.mark.asyncio
    async def test_has_index(self):
        """Test has_index method."""
        crawler = IndexReaderCrawler()

        with patch(
            "dns_aid.crawlers.index_reader.index_exists",
            new_callable=AsyncMock,
            return_value=True,
        ):
            result = await crawler.has_index("has-index.com")

        assert result is True
