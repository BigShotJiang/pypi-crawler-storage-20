"""Unit tests for NSEC zone walker."""

from unittest.mock import AsyncMock, patch

import pytest

from dns_aid.crawlers.zone_walker import (
    NSECRecord,
    NSECZoneWalker,
    check_dnssec_enabled,
    extract_agent_name,
    is_under_agents_zone,
)


class TestIsUnderAgentsZone:
    """Tests for is_under_agents_zone function."""

    def test_valid_agents_zone(self):
        """Test name under _agents zone."""
        assert is_under_agents_zone("_chat._mcp._agents.example.com", "example.com") is True

    def test_not_under_agents_zone(self):
        """Test name not under _agents zone."""
        assert is_under_agents_zone("www.example.com", "example.com") is False

    def test_different_domain(self):
        """Test name under different domain."""
        assert is_under_agents_zone("_chat._mcp._agents.other.com", "example.com") is False

    def test_case_insensitive(self):
        """Test check is case insensitive."""
        assert is_under_agents_zone("_CHAT._MCP._AGENTS.EXAMPLE.COM", "example.com") is True

    def test_with_trailing_dot(self):
        """Test handling trailing dot."""
        assert is_under_agents_zone("_chat._mcp._agents.example.com.", "example.com") is True


class TestExtractAgentName:
    """Tests for extract_agent_name function."""

    def test_valid_extraction(self):
        """Test extracting from valid FQDN."""
        result = extract_agent_name("_chat._mcp._agents.example.com", "example.com")

        assert result is not None
        assert result == ("chat", "mcp")

    def test_a2a_protocol(self):
        """Test extracting A2A protocol."""
        result = extract_agent_name("_assistant._a2a._agents.example.com", "example.com")

        assert result is not None
        assert result == ("assistant", "a2a")

    def test_invalid_format(self):
        """Test with invalid format."""
        result = extract_agent_name("www.example.com", "example.com")
        assert result is None

    def test_wrong_domain(self):
        """Test with wrong domain."""
        result = extract_agent_name("_chat._mcp._agents.other.com", "example.com")
        assert result is None

    def test_case_insensitive(self):
        """Test extraction is case insensitive."""
        result = extract_agent_name("_CHAT._MCP._AGENTS.EXAMPLE.COM", "example.com")

        assert result is not None
        assert result == ("chat", "mcp")


class TestNSECRecord:
    """Tests for NSECRecord dataclass."""

    def test_record_creation(self):
        """Test creating an NSEC record."""
        record = NSECRecord(
            owner="_agents.example.com",
            next_name="_chat._mcp._agents.example.com",
            types=["SVCB", "TXT", "NSEC"],
        )

        assert record.owner == "_agents.example.com"
        assert record.next_name == "_chat._mcp._agents.example.com"
        assert "SVCB" in record.types


class TestCheckDNSSECEnabled:
    """Tests for check_dnssec_enabled function."""

    @pytest.mark.asyncio
    async def test_dnssec_enabled(self):
        """Test detecting DNSSEC enabled zone."""
        with patch("dns_aid.crawlers.zone_walker.dns.asyncresolver.Resolver") as MockResolver:
            resolver = MockResolver.return_value
            resolver.timeout = 5
            resolver.use_edns = lambda *args, **kwargs: None
            resolver.resolve = AsyncMock(return_value=[])  # DNSKEY exists

            result = await check_dnssec_enabled("secure.example.com")

        assert result is True

    @pytest.mark.asyncio
    async def test_dnssec_disabled(self):
        """Test detecting DNSSEC disabled zone."""
        import dns.resolver

        with patch("dns_aid.crawlers.zone_walker.dns.asyncresolver.Resolver") as MockResolver:
            resolver = MockResolver.return_value
            resolver.timeout = 5
            resolver.use_edns = lambda *args, **kwargs: None
            resolver.resolve = AsyncMock(side_effect=dns.resolver.NoAnswer())

            result = await check_dnssec_enabled("insecure.example.com")

        assert result is False


class TestNSECZoneWalker:
    """Tests for NSECZoneWalker."""

    def test_walker_creation(self):
        """Test creating zone walker."""
        walker = NSECZoneWalker()

        assert walker.name == "nsec-walker"
        assert walker._verify_agents is True
        assert walker._max_records == 1000

    def test_walker_custom_params(self):
        """Test walker with custom parameters."""
        walker = NSECZoneWalker(verify_agents=False, max_records=100)

        assert walker._verify_agents is False
        assert walker._max_records == 100

    @pytest.mark.asyncio
    async def test_crawl_feature_disabled(self):
        """Test crawl when NSEC walker is disabled."""
        walker = NSECZoneWalker()

        with patch("dns_aid.crawlers.zone_walker.ENABLE_NSEC_WALKER", False):
            result = await walker.crawl("example.com")

        assert result.status == "skipped"
        assert "disabled" in result.error_message.lower()

    @pytest.mark.asyncio
    async def test_crawl_blocked_domain(self):
        """Test crawling blocked domain."""
        walker = NSECZoneWalker()

        with patch("dns_aid.crawlers.zone_walker.ENABLE_NSEC_WALKER", True):
            result = await walker.crawl("example.com")  # Blocked

        assert result.status == "blocked"

    @pytest.mark.asyncio
    async def test_crawl_no_dnssec(self):
        """Test crawling zone without DNSSEC."""
        walker = NSECZoneWalker()

        with (
            patch("dns_aid.crawlers.zone_walker.ENABLE_NSEC_WALKER", True),
            patch("dns_aid.crawlers.zone_walker.is_domain_blocked", return_value=False),
            patch(
                "dns_aid.crawlers.zone_walker.check_dnssec_enabled",
                new_callable=AsyncMock,
                return_value=False,
            ),
        ):
            result = await walker.crawl("no-dnssec.com")

        assert result.status == "skipped"
        assert "DNSSEC not enabled" in result.error_message

    @pytest.mark.asyncio
    async def test_check_walkable(self):
        """Test check_walkable method."""
        walker = NSECZoneWalker()

        with (
            patch("dns_aid.crawlers.zone_walker.ENABLE_NSEC_WALKER", True),
            patch(
                "dns_aid.crawlers.zone_walker.check_dnssec_enabled",
                new_callable=AsyncMock,
                return_value=True,
            ),
        ):
            result = await walker.check_walkable("secure-zone.com")

        assert result is True

    @pytest.mark.asyncio
    async def test_check_walkable_disabled(self):
        """Test check_walkable when feature disabled."""
        walker = NSECZoneWalker()

        with patch("dns_aid.crawlers.zone_walker.ENABLE_NSEC_WALKER", False):
            result = await walker.check_walkable("any.com")

        assert result is False

    @pytest.mark.asyncio
    async def test_crawl_success(self):
        """Test successful zone walk."""
        walker = NSECZoneWalker(verify_agents=False)

        mock_agent = AsyncMock()
        mock_agent.fqdn = "_chat._mcp._agents.walkable.com"
        mock_agent.name = "chat"
        mock_agent.endpoint_url = "https://mcp.walkable.com"
        mock_agent.port = 443
        mock_agent.capabilities = []
        mock_agent.version = None

        mock_discovery = AsyncMock()
        mock_discovery.agents = [mock_agent]

        # Mock walk_zone to return some records
        walk_result = AsyncMock()
        walk_result.records_found = ["_chat._mcp._agents.walkable.com"]
        walk_result.error = None

        with (
            patch("dns_aid.crawlers.zone_walker.ENABLE_NSEC_WALKER", True),
            patch("dns_aid.crawlers.zone_walker.is_domain_blocked", return_value=False),
            patch(
                "dns_aid.crawlers.zone_walker.check_dnssec_enabled",
                new_callable=AsyncMock,
                return_value=True,
            ),
            patch.object(walker, "_walk_zone", new_callable=AsyncMock, return_value=walk_result),
            patch(
                "dns_aid.crawlers.zone_walker.discover",
                new_callable=AsyncMock,
                return_value=mock_discovery,
            ),
        ):
            result = await walker.crawl("walkable.com")

        assert result.status == "success"
