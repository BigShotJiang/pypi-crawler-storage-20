"""Unit tests for crawl scheduler."""

from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, patch

import pytest

from dns_aid.crawlers.base import CrawlResult, DiscoveredAgent
from dns_aid.crawlers.scheduler import (
    BatchScheduler,
    CrawlJob,
    CrawlPriority,
    CrawlQueue,
    CrawlScheduler,
    CrawlStatus,
)


class TestCrawlPriority:
    """Tests for CrawlPriority enum."""

    def test_priority_values(self):
        """Test priority enum values."""
        assert CrawlPriority.IMMEDIATE.value == 0
        assert CrawlPriority.HIGH.value == 1
        assert CrawlPriority.NORMAL.value == 2
        assert CrawlPriority.LOW.value == 3

    def test_priority_ordering(self):
        """Test priorities can be compared for ordering."""
        assert CrawlPriority.IMMEDIATE.value < CrawlPriority.HIGH.value
        assert CrawlPriority.HIGH.value < CrawlPriority.NORMAL.value
        assert CrawlPriority.NORMAL.value < CrawlPriority.LOW.value


class TestCrawlStatus:
    """Tests for CrawlStatus enum."""

    def test_status_values(self):
        """Test status enum values."""
        assert CrawlStatus.PENDING.value == "pending"
        assert CrawlStatus.RUNNING.value == "running"
        assert CrawlStatus.COMPLETED.value == "completed"
        assert CrawlStatus.FAILED.value == "failed"
        assert CrawlStatus.SKIPPED.value == "skipped"


class TestCrawlJob:
    """Tests for CrawlJob dataclass."""

    def test_job_creation(self):
        """Test creating a crawl job."""
        job = CrawlJob(domain="example.com")

        assert job.domain == "example.com"
        assert job.priority == CrawlPriority.NORMAL
        assert job.status == CrawlStatus.PENDING
        assert job.attempt == 0

    def test_job_custom_values(self):
        """Test job with custom values."""
        job = CrawlJob(
            domain="urgent.com",
            priority=CrawlPriority.IMMEDIATE,
            source="ct_log",
            max_attempts=5,
        )

        assert job.priority == CrawlPriority.IMMEDIATE
        assert job.source == "ct_log"
        assert job.max_attempts == 5

    def test_job_is_due_no_schedule(self):
        """Test is_due with no scheduled time."""
        job = CrawlJob(domain="example.com")
        assert job.is_due is True

    def test_job_is_due_future(self):
        """Test is_due with future scheduled time."""
        future = datetime.now(UTC) + timedelta(hours=1)
        job = CrawlJob(domain="example.com", scheduled_for=future)
        assert job.is_due is False

    def test_job_is_due_past(self):
        """Test is_due with past scheduled time."""
        past = datetime.now(UTC) - timedelta(hours=1)
        job = CrawlJob(domain="example.com", scheduled_for=past)
        assert job.is_due is True

    def test_job_can_retry(self):
        """Test can_retry based on attempts."""
        job = CrawlJob(domain="example.com", max_attempts=3)

        assert job.can_retry is True  # 0 < 3

        job.attempt = 2
        assert job.can_retry is True  # 2 < 3

        job.attempt = 3
        assert job.can_retry is False  # 3 >= 3


class TestCrawlQueue:
    """Tests for CrawlQueue."""

    def test_queue_creation(self):
        """Test creating a queue."""
        queue = CrawlQueue()
        assert queue.size == 0

    def test_add_job(self):
        """Test adding a job to queue."""
        queue = CrawlQueue()
        job = CrawlJob(domain="example.org")  # Not in blocklist

        # Patch is_domain_blocked to allow any domain for testing
        with patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False):
            result = queue.add(job)

        assert result is True
        assert queue.size == 1

    def test_add_blocked_domain(self):
        """Test adding blocked domain."""
        queue = CrawlQueue()
        job = CrawlJob(domain="example.com")  # Blocked domain

        result = queue.add(job)

        assert result is False
        assert queue.size == 0

    def test_add_duplicate(self):
        """Test adding duplicate domain."""
        queue = CrawlQueue()
        job1 = CrawlJob(domain="test.com")
        job2 = CrawlJob(domain="test.com")

        with patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False):
            queue.add(job1)
            result = queue.add(job2)

        assert result is False
        assert queue.size == 1

    def test_add_respects_max_size(self):
        """Test queue respects max size."""
        queue = CrawlQueue(max_size=2)

        with patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False):
            queue.add(CrawlJob(domain="a.com"))
            queue.add(CrawlJob(domain="b.com"))
            result = queue.add(CrawlJob(domain="c.com"))

        assert result is False
        assert queue.size == 2

    def test_pop_empty(self):
        """Test popping from empty queue."""
        queue = CrawlQueue()
        assert queue.pop() is None

    def test_pop_returns_due_job(self):
        """Test pop returns due job."""
        queue = CrawlQueue()
        job = CrawlJob(domain="test.com")

        with patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False):
            queue.add(job)
            popped = queue.pop()

        assert popped is not None
        assert popped.domain == "test.com"
        assert queue.size == 0

    def test_pop_respects_schedule(self):
        """Test pop skips future jobs."""
        queue = CrawlQueue()
        future = datetime.now(UTC) + timedelta(hours=1)
        job = CrawlJob(domain="test.com", scheduled_for=future)

        with patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False):
            queue.add(job)
            popped = queue.pop()

        assert popped is None  # Job not due yet
        assert queue.size == 1  # Still in queue

    def test_priority_ordering(self):
        """Test jobs are ordered by priority."""
        queue = CrawlQueue()

        with patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False):
            queue.add(CrawlJob(domain="low.com", priority=CrawlPriority.LOW))
            queue.add(CrawlJob(domain="high.com", priority=CrawlPriority.HIGH))
            queue.add(CrawlJob(domain="immediate.com", priority=CrawlPriority.IMMEDIATE))

        first = queue.pop()
        assert first.domain == "immediate.com"

        second = queue.pop()
        assert second.domain == "high.com"

    def test_clear(self):
        """Test clearing queue."""
        queue = CrawlQueue()

        with patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False):
            queue.add(CrawlJob(domain="a.com"))
            queue.add(CrawlJob(domain="b.com"))

        queue.clear()
        assert queue.size == 0


class TestCrawlScheduler:
    """Tests for CrawlScheduler."""

    def test_scheduler_creation(self):
        """Test creating a scheduler."""
        scheduler = CrawlScheduler()

        assert scheduler._running is False
        assert scheduler.stats["jobs_processed"] == 0

    def test_submit_domain(self):
        """Test submitting a domain."""
        scheduler = CrawlScheduler()

        with patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False):
            result = scheduler.submit_domain("test.com")

        assert result is True
        assert scheduler._queue.size == 1

    def test_submit_domain_with_priority(self):
        """Test submitting with priority."""
        scheduler = CrawlScheduler()

        with patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False):
            scheduler.submit_domain(
                "urgent.com",
                priority=CrawlPriority.IMMEDIATE,
                source="ct_log",
            )

        job = scheduler._queue.peek()
        assert job.priority == CrawlPriority.IMMEDIATE
        assert job.source == "ct_log"

    @pytest.mark.asyncio
    async def test_process_one_empty_queue(self):
        """Test processing with empty queue."""
        scheduler = CrawlScheduler()

        result = await scheduler.process_one()

        assert result is None

    @pytest.mark.asyncio
    async def test_process_one_success(self):
        """Test processing a job successfully."""
        scheduler = CrawlScheduler()

        mock_result = CrawlResult(domain="test.com", status="success")
        mock_result.agents_found = []

        with (
            patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False),
            patch(
                "dns_aid.crawlers.scheduler.index_exists",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch.object(
                scheduler._pattern_crawler,
                "crawl",
                new_callable=AsyncMock,
                return_value=mock_result,
            ),
            patch.object(scheduler, "schedule_recrawl", return_value=True),
        ):
            scheduler.submit_domain("test.com")
            result = await scheduler.process_one()

        assert result is not None
        assert result.domain == "test.com"
        assert scheduler.stats["jobs_processed"] == 1
        assert scheduler.stats["jobs_succeeded"] == 1

    @pytest.mark.asyncio
    async def test_process_uses_index_when_available(self):
        """Test scheduler uses index crawler when index exists."""
        scheduler = CrawlScheduler()

        mock_result = CrawlResult(domain="indexed.com", status="success")
        mock_result.agents_found = [
            DiscoveredAgent(
                fqdn="_chat._mcp._agents.indexed.com",
                domain="indexed.com",
                name="chat",
                protocol="mcp",
            )
        ]

        with (
            patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False),
            patch(
                "dns_aid.crawlers.scheduler.index_exists", new_callable=AsyncMock, return_value=True
            ),
            patch.object(
                scheduler._index_crawler,
                "crawl",
                new_callable=AsyncMock,
                return_value=mock_result,
            ),
            patch.object(scheduler, "schedule_recrawl", return_value=True),
        ):
            scheduler.submit_domain("indexed.com")
            result = await scheduler.process_one()

        assert result is not None
        assert len(result.agents_found) == 1

    @pytest.mark.asyncio
    async def test_run_processes_until_empty(self):
        """Test run processes all jobs."""
        scheduler = CrawlScheduler()

        mock_result = CrawlResult(domain="test.com", status="success")
        mock_result.agents_found = []

        with (
            patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False),
            patch(
                "dns_aid.crawlers.scheduler.index_exists",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch.object(
                scheduler._pattern_crawler,
                "crawl",
                new_callable=AsyncMock,
                return_value=mock_result,
            ),
            patch.object(scheduler, "schedule_recrawl", return_value=True),
        ):
            scheduler.submit_domain("a.com")
            scheduler.submit_domain("b.com")

            stats = await scheduler.run()

        assert stats["jobs_processed"] == 2
        assert scheduler._queue.size == 0

    @pytest.mark.asyncio
    async def test_run_respects_max_jobs(self):
        """Test run respects max_jobs limit."""
        scheduler = CrawlScheduler()

        mock_result = CrawlResult(domain="test.com", status="success")
        mock_result.agents_found = []

        with (
            patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False),
            patch(
                "dns_aid.crawlers.scheduler.index_exists",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch.object(
                scheduler._pattern_crawler,
                "crawl",
                new_callable=AsyncMock,
                return_value=mock_result,
            ),
            patch.object(scheduler, "schedule_recrawl", return_value=True),
        ):
            scheduler.submit_domain("a.com")
            scheduler.submit_domain("b.com")
            scheduler.submit_domain("c.com")

            stats = await scheduler.run(max_jobs=2)

        assert stats["jobs_processed"] == 2
        assert scheduler._queue.size == 1  # One job left

    def test_stop(self):
        """Test stop method."""
        scheduler = CrawlScheduler()
        scheduler._running = True

        scheduler.stop()

        assert scheduler._running is False


class TestBatchScheduler:
    """Tests for BatchScheduler."""

    def test_batch_scheduler_creation(self):
        """Test creating batch scheduler."""
        batch = BatchScheduler()

        assert batch._max_concurrent == 10

    def test_batch_scheduler_custom_concurrency(self):
        """Test batch scheduler with custom concurrency."""
        batch = BatchScheduler(max_concurrent=5)

        assert batch._max_concurrent == 5

    @pytest.mark.asyncio
    async def test_process_domains(self):
        """Test processing a batch of domains."""
        batch = BatchScheduler(max_concurrent=2)

        mock_result = CrawlResult(domain="test.com", status="success")
        mock_result.agents_found = []

        with (
            patch("dns_aid.crawlers.scheduler.is_domain_blocked", return_value=False),
            patch(
                "dns_aid.crawlers.scheduler.index_exists",
                new_callable=AsyncMock,
                return_value=False,
            ),
            patch.object(
                batch._scheduler._pattern_crawler,
                "crawl",
                new_callable=AsyncMock,
                return_value=mock_result,
            ),
            patch.object(batch._scheduler, "schedule_recrawl", return_value=True),
        ):
            stats = await batch.process_domains(["a.com", "b.com", "c.com"])

        assert stats["domains_submitted"] == 3
        assert stats["domains_queued"] == 3
