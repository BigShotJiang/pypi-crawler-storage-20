"""Unit tests for DNS-AID crawler infrastructure."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from dns_aid.crawlers.base import BaseCrawler, CrawlResult, DiscoveredAgent
from dns_aid.crawlers.submission import BatchSubmissionCrawler, SubmissionCrawler


class TestDiscoveredAgent:
    """Tests for DiscoveredAgent dataclass."""

    def test_discovered_agent_creation(self):
        """Test creating a discovered agent."""
        agent = DiscoveredAgent(
            fqdn="_network._mcp._agents.example.com",
            domain="example.com",
            name="network",
            protocol="mcp",
            endpoint_url="https://mcp.example.com",
            port=443,
            capabilities=["ipam", "dns"],
            version="1.0.0",
            security_score=85,
            metadata={"dnssec_valid": True},
        )

        assert agent.fqdn == "_network._mcp._agents.example.com"
        assert agent.name == "network"
        assert agent.protocol == "mcp"
        assert agent.security_score == 85
        assert "ipam" in agent.capabilities

    def test_discovered_agent_defaults(self):
        """Test default values for discovered agent."""
        agent = DiscoveredAgent(
            fqdn="_test._mcp._agents.example.com",
            domain="example.com",
            name="test",
            protocol="mcp",
        )

        assert agent.port == 443
        assert agent.capabilities == []
        assert agent.version is None
        assert agent.security_score == 0
        assert agent.metadata == {}


class TestCrawlResult:
    """Tests for CrawlResult dataclass."""

    def test_crawl_result_creation(self):
        """Test creating a crawl result."""
        result = CrawlResult(domain="example.com", status="running")

        assert result.domain == "example.com"
        assert result.status == "running"
        assert result.agents_found == []
        assert result.agents_added == 0

    def test_crawl_result_complete(self):
        """Test marking crawl as complete."""
        result = CrawlResult(domain="example.com", status="running")
        result.complete("success")

        assert result.status == "success"
        assert result.completed_at is not None
        assert result.error_message is None

    def test_crawl_result_complete_with_error(self):
        """Test marking crawl as failed with error."""
        result = CrawlResult(domain="example.com", status="running")
        result.complete("failed", "Connection timeout")

        assert result.status == "failed"
        assert result.error_message == "Connection timeout"

    def test_crawl_result_duration(self):
        """Test duration calculation."""
        result = CrawlResult(domain="example.com", status="running")
        result.complete("success")

        assert result.duration_seconds is not None
        assert result.duration_seconds >= 0

    def test_crawl_result_duration_incomplete(self):
        """Test duration is None when not complete."""
        result = CrawlResult(domain="example.com", status="running")

        assert result.duration_seconds is None


class TestBaseCrawler:
    """Tests for BaseCrawler abstract class."""

    def test_base_crawler_is_abstract(self):
        """Test that BaseCrawler cannot be instantiated directly."""
        with pytest.raises(TypeError):
            BaseCrawler()  # type: ignore

    def test_concrete_crawler_creation(self):
        """Test creating a concrete crawler implementation."""

        class TestCrawler(BaseCrawler):
            async def crawl(self, domain: str) -> CrawlResult:
                return CrawlResult(domain=domain, status="success")

        crawler = TestCrawler(name="test")
        assert crawler.name == "test"

    @pytest.mark.asyncio
    async def test_validate_domain_valid(self):
        """Test domain validation with valid domain."""

        class TestCrawler(BaseCrawler):
            async def crawl(self, domain: str) -> CrawlResult:
                return CrawlResult(domain=domain, status="success")

        crawler = TestCrawler(name="test")
        assert await crawler.validate_domain("example.com") is True
        assert await crawler.validate_domain("sub.example.com") is True

    @pytest.mark.asyncio
    async def test_validate_domain_invalid(self):
        """Test domain validation with invalid domain."""

        class TestCrawler(BaseCrawler):
            async def crawl(self, domain: str) -> CrawlResult:
                return CrawlResult(domain=domain, status="success")

        crawler = TestCrawler(name="test")
        assert await crawler.validate_domain("") is False
        assert await crawler.validate_domain("ab") is False
        assert await crawler.validate_domain("example..com") is False

    @pytest.mark.asyncio
    async def test_run_workflow(self):
        """Test the complete run workflow."""

        class TestCrawler(BaseCrawler):
            async def crawl(self, domain: str) -> CrawlResult:
                result = CrawlResult(domain=domain, status="success")
                result.agents_found = [
                    DiscoveredAgent(
                        fqdn=f"_test._mcp._agents.{domain}",
                        domain=domain,
                        name="test",
                        protocol="mcp",
                    )
                ]
                return result

        crawler = TestCrawler(name="test")
        result = await crawler.run("example.com")

        assert result.domain == "example.com"
        assert len(result.agents_found) == 1

    @pytest.mark.asyncio
    async def test_run_workflow_invalid_domain(self):
        """Test run workflow with invalid domain."""

        class TestCrawler(BaseCrawler):
            async def crawl(self, domain: str) -> CrawlResult:
                return CrawlResult(domain=domain, status="success")

        crawler = TestCrawler(name="test")
        result = await crawler.run("")

        assert result.status == "failed"
        assert "Invalid domain" in result.error_message

    @pytest.mark.asyncio
    async def test_run_workflow_exception(self):
        """Test run workflow handles exceptions."""

        class TestCrawler(BaseCrawler):
            async def crawl(self, domain: str) -> CrawlResult:
                raise RuntimeError("Test error")

        crawler = TestCrawler(name="test")
        result = await crawler.run("example.com")

        assert result.status == "failed"
        assert "Test error" in result.error_message


class TestSubmissionCrawler:
    """Tests for SubmissionCrawler."""

    def test_submission_crawler_creation(self):
        """Test creating a submission crawler."""
        crawler = SubmissionCrawler()

        assert crawler.name == "submission"
        assert "mcp" in crawler.protocols
        assert "a2a" in crawler.protocols
        assert "https" in crawler.protocols

    def test_submission_crawler_custom_protocols(self):
        """Test creating crawler with custom protocols."""
        crawler = SubmissionCrawler(protocols=["mcp"])

        assert crawler.protocols == ["mcp"]

    @pytest.mark.asyncio
    async def test_crawl_discovers_agents(self):
        """Test crawl discovers agents using core functions."""
        crawler = SubmissionCrawler(protocols=["mcp"])

        # Mock the core discovery and verify functions
        mock_agent = MagicMock()
        mock_agent.fqdn = "_test._mcp._agents.example.com"
        mock_agent.name = "test"
        mock_agent.endpoint_url = "https://test.example.com"
        mock_agent.port = 443
        mock_agent.capabilities = ["test"]
        mock_agent.version = "1.0.0"

        mock_discovery = MagicMock()
        mock_discovery.agents = [mock_agent]

        mock_verification = MagicMock()
        mock_verification.security_score = 85
        mock_verification.dnssec_valid = True
        mock_verification.dane_valid = False
        mock_verification.endpoint_reachable = True
        mock_verification.svcb_valid = True

        with (
            patch(
                "dns_aid.crawlers.submission.discover",
                new_callable=AsyncMock,
                return_value=mock_discovery,
            ),
            patch(
                "dns_aid.crawlers.submission.verify",
                new_callable=AsyncMock,
                return_value=mock_verification,
            ),
        ):
            result = await crawler.crawl("example.com")

        assert result.status == "success"
        assert len(result.agents_found) == 1
        assert result.agents_found[0].security_score == 85

    @pytest.mark.asyncio
    async def test_crawl_handles_discovery_error(self):
        """Test crawl handles discovery errors gracefully."""
        crawler = SubmissionCrawler(protocols=["mcp"])

        with patch(
            "dns_aid.crawlers.submission.discover",
            new_callable=AsyncMock,
            side_effect=Exception("DNS lookup failed"),
        ):
            result = await crawler.crawl("example.com")

        # Should still complete, just with no agents
        assert result.status in ["success", "failed"]

    @pytest.mark.asyncio
    async def test_crawl_handles_verification_error(self):
        """Test crawl handles verification errors gracefully."""
        crawler = SubmissionCrawler(protocols=["mcp"])

        mock_agent = MagicMock()
        mock_agent.fqdn = "_test._mcp._agents.example.com"
        mock_agent.name = "test"

        mock_discovery = MagicMock()
        mock_discovery.agents = [mock_agent]

        with (
            patch(
                "dns_aid.crawlers.submission.discover",
                new_callable=AsyncMock,
                return_value=mock_discovery,
            ),
            patch(
                "dns_aid.crawlers.submission.verify",
                new_callable=AsyncMock,
                side_effect=Exception("Verification failed"),
            ),
        ):
            result = await crawler.crawl("example.com")

        # Should complete with partial status
        assert result.status in ["partial", "failed"]

    @pytest.mark.asyncio
    async def test_crawl_no_agents_found(self):
        """Test crawl with no agents discovered."""
        crawler = SubmissionCrawler(protocols=["mcp"])

        mock_discovery = MagicMock()
        mock_discovery.agents = []

        with patch(
            "dns_aid.crawlers.submission.discover",
            new_callable=AsyncMock,
            return_value=mock_discovery,
        ):
            result = await crawler.crawl("example.com")

        assert result.status == "success"
        assert len(result.agents_found) == 0


class TestBatchSubmissionCrawler:
    """Tests for BatchSubmissionCrawler."""

    def test_batch_crawler_creation(self):
        """Test creating a batch crawler."""
        crawler = BatchSubmissionCrawler()

        assert crawler.name == "batch-submission"
        assert crawler.max_concurrent == 5

    def test_batch_crawler_custom_concurrency(self):
        """Test creating batch crawler with custom concurrency."""
        crawler = BatchSubmissionCrawler(max_concurrent=10)

        assert crawler.max_concurrent == 10

    @pytest.mark.asyncio
    async def test_crawl_delegates_to_single(self):
        """Test crawl delegates to single crawler."""
        crawler = BatchSubmissionCrawler(protocols=["mcp"])

        mock_discovery = MagicMock()
        mock_discovery.agents = []

        with patch(
            "dns_aid.crawlers.submission.discover",
            new_callable=AsyncMock,
            return_value=mock_discovery,
        ):
            result = await crawler.crawl("example.com")

        assert result.domain == "example.com"

    @pytest.mark.asyncio
    async def test_crawl_batch_multiple_domains(self):
        """Test batch crawling multiple domains."""
        crawler = BatchSubmissionCrawler(protocols=["mcp"], max_concurrent=2)

        mock_discovery = MagicMock()
        mock_discovery.agents = []

        with patch(
            "dns_aid.crawlers.submission.discover",
            new_callable=AsyncMock,
            return_value=mock_discovery,
        ):
            results = await crawler.crawl_batch(["example1.com", "example2.com", "example3.com"])

        assert len(results) == 3
        domains = {r.domain for r in results}
        assert domains == {"example1.com", "example2.com", "example3.com"}

    @pytest.mark.asyncio
    async def test_crawl_batch_handles_exceptions(self):
        """Test batch crawl handles individual failures."""
        crawler = BatchSubmissionCrawler(protocols=["mcp"], max_concurrent=2)

        call_count = 0

        async def mock_discover(domain, **kwargs):
            nonlocal call_count
            call_count += 1
            if "fail" in domain:
                raise Exception("Simulated failure")
            mock = MagicMock()
            mock.agents = []
            return mock

        with patch(
            "dns_aid.crawlers.submission.discover",
            side_effect=mock_discover,
        ):
            results = await crawler.crawl_batch(["example.com", "fail.com", "another.com"])

        assert len(results) == 3
        # At least one should have failed
        statuses = {r.status for r in results}
        assert "failed" in statuses or len(statuses) > 0

    @pytest.mark.asyncio
    async def test_crawl_batch_respects_concurrency(self):
        """Test batch crawl respects max_concurrent limit."""
        crawler = BatchSubmissionCrawler(protocols=["mcp"], max_concurrent=2)

        concurrent_count = 0
        max_concurrent_seen = 0

        async def mock_discover(domain, **kwargs):
            nonlocal concurrent_count, max_concurrent_seen
            concurrent_count += 1
            max_concurrent_seen = max(max_concurrent_seen, concurrent_count)
            # Simulate some work
            import asyncio

            await asyncio.sleep(0.01)
            concurrent_count -= 1
            mock = MagicMock()
            mock.agents = []
            return mock

        with patch(
            "dns_aid.crawlers.submission.discover",
            side_effect=mock_discover,
        ):
            await crawler.crawl_batch(["d1.com", "d2.com", "d3.com", "d4.com", "d5.com"])

        # Should not exceed max_concurrent
        assert max_concurrent_seen <= 2
