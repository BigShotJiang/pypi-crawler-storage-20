"""Unit tests for DNS-AID directory SQLAlchemy models."""

from datetime import UTC, datetime

import pytest
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from dns_aid.directory.models import Agent, CrawlHistory, Domain


class TestDomainModel:
    """Tests for the Domain model."""

    @pytest.mark.asyncio
    async def test_create_domain(self, async_session: AsyncSession, sample_domain: Domain):
        """Test creating a domain record."""
        async_session.add(sample_domain)
        await async_session.commit()

        result = await async_session.execute(select(Domain).where(Domain.domain == "example.com"))
        domain = result.scalar_one()

        assert domain.domain == "example.com"
        assert domain.verified is True
        assert domain.verification_token == "test-token-12345"
        assert domain.agent_count == 2

    @pytest.mark.asyncio
    async def test_domain_default_values(self, async_session: AsyncSession):
        """Test default values for domain model."""
        domain = Domain(
            domain="defaults.com",
            verification_token="token",
        )
        async_session.add(domain)
        await async_session.commit()

        result = await async_session.execute(select(Domain).where(Domain.domain == "defaults.com"))
        domain = result.scalar_one()

        assert domain.verified is False
        assert domain.crawl_status == "pending"
        assert domain.agent_count == 0
        assert domain.submitted_at is not None

    @pytest.mark.asyncio
    async def test_domain_metadata_jsonb(self, async_session: AsyncSession):
        """Test JSONB metadata field."""
        domain = Domain(
            domain="metadata.com",
            verification_token="token",
            metadata={"key1": "value1", "nested": {"a": 1, "b": 2}},
        )
        async_session.add(domain)
        await async_session.commit()

        result = await async_session.execute(select(Domain).where(Domain.domain == "metadata.com"))
        domain = result.scalar_one()

        assert domain.metadata["key1"] == "value1"
        assert domain.metadata["nested"]["a"] == 1


class TestAgentModel:
    """Tests for the Agent model."""

    @pytest.mark.asyncio
    async def test_create_agent(
        self, async_session: AsyncSession, sample_domain: Domain, sample_agent: Agent
    ):
        """Test creating an agent record."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        result = await async_session.execute(
            select(Agent).where(Agent.fqdn == "_network._mcp._agents.example.com")
        )
        agent = result.scalar_one()

        assert agent.name == "network"
        assert agent.protocol == "mcp"
        assert agent.domain == "example.com"
        assert agent.port == 443
        assert agent.security_score == 85

    @pytest.mark.asyncio
    async def test_agent_capabilities_array(
        self, async_session: AsyncSession, sample_domain: Domain, sample_agent: Agent
    ):
        """Test array capabilities field."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        result = await async_session.execute(
            select(Agent).where(Agent.fqdn == "_network._mcp._agents.example.com")
        )
        agent = result.scalar_one()

        # SQLite stores arrays as JSON, PostgreSQL as native arrays
        assert "ipam" in agent.capabilities
        assert "dns" in agent.capabilities
        assert len(agent.capabilities) == 3

    @pytest.mark.asyncio
    async def test_agent_threat_flags_jsonb(
        self, async_session: AsyncSession, sample_domain: Domain
    ):
        """Test JSONB threat_flags field."""
        agent = Agent(
            fqdn="_suspicious._mcp._agents.example.com",
            domain=sample_domain.domain,
            name="suspicious",
            protocol="mcp",
            threat_flags={
                "ioc_match": True,
                "severity": "high",
                "indicators": ["malware", "phishing"],
            },
        )
        async_session.add(sample_domain)
        async_session.add(agent)
        await async_session.commit()

        result = await async_session.execute(
            select(Agent).where(Agent.fqdn == "_suspicious._mcp._agents.example.com")
        )
        agent = result.scalar_one()

        assert agent.threat_flags["ioc_match"] is True
        assert agent.threat_flags["severity"] == "high"

    @pytest.mark.asyncio
    async def test_agent_default_scores(self, async_session: AsyncSession, sample_domain: Domain):
        """Test default score values for agent."""
        agent = Agent(
            fqdn="_minimal._mcp._agents.example.com",
            domain=sample_domain.domain,
            name="minimal",
            protocol="mcp",
        )
        async_session.add(sample_domain)
        async_session.add(agent)
        await async_session.commit()

        result = await async_session.execute(
            select(Agent).where(Agent.fqdn == "_minimal._mcp._agents.example.com")
        )
        agent = result.scalar_one()

        assert agent.security_score == 0
        assert agent.trust_score == 0
        assert agent.popularity_score == 0
        assert agent.port == 443

    @pytest.mark.asyncio
    async def test_agent_domain_relationship(
        self, async_session: AsyncSession, sample_domain: Domain, sample_agent: Agent
    ):
        """Test agent-domain foreign key relationship."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        result = await async_session.execute(select(Agent).where(Agent.domain == "example.com"))
        agents = result.scalars().all()

        assert len(agents) == 1
        assert agents[0].domain == sample_domain.domain


class TestCrawlHistoryModel:
    """Tests for the CrawlHistory model."""

    @pytest.mark.asyncio
    async def test_create_crawl_history(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_crawl_history: CrawlHistory,
    ):
        """Test creating a crawl history record."""
        async_session.add(sample_domain)
        async_session.add(sample_crawl_history)
        await async_session.commit()

        result = await async_session.execute(
            select(CrawlHistory).where(CrawlHistory.domain == "example.com")
        )
        history = result.scalar_one()

        assert history.status == "success"
        assert history.agents_found == 2
        assert history.agents_added == 2
        assert history.agents_updated == 0

    @pytest.mark.asyncio
    async def test_crawl_history_error_message(
        self, async_session: AsyncSession, sample_domain: Domain
    ):
        """Test crawl history with error message."""
        history = CrawlHistory(
            domain=sample_domain.domain,
            started_at=datetime.now(UTC),
            completed_at=datetime.now(UTC),
            status="failed",
            error_message="Connection timeout after 30 seconds",
        )
        async_session.add(sample_domain)
        async_session.add(history)
        await async_session.commit()

        result = await async_session.execute(
            select(CrawlHistory).where(CrawlHistory.status == "failed")
        )
        history = result.scalar_one()

        assert history.error_message == "Connection timeout after 30 seconds"

    @pytest.mark.asyncio
    async def test_crawl_history_autoincrement_id(
        self, async_session: AsyncSession, sample_domain: Domain
    ):
        """Test crawl history auto-incrementing ID."""
        async_session.add(sample_domain)

        history1 = CrawlHistory(domain=sample_domain.domain, status="success")
        history2 = CrawlHistory(domain=sample_domain.domain, status="success")

        async_session.add(history1)
        async_session.add(history2)
        await async_session.commit()

        result = await async_session.execute(select(CrawlHistory).order_by(CrawlHistory.id))
        histories = result.scalars().all()

        assert len(histories) == 2
        assert histories[0].id < histories[1].id


class TestModelRelationships:
    """Tests for model relationships and constraints."""

    @pytest.mark.asyncio
    async def test_multiple_agents_per_domain(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test multiple agents can belong to same domain."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        result = await async_session.execute(select(Agent).where(Agent.domain == "example.com"))
        agents = result.scalars().all()

        assert len(agents) == 2
        protocols = {a.protocol for a in agents}
        assert protocols == {"mcp", "a2a"}

    @pytest.mark.asyncio
    async def test_query_agents_by_protocol(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test querying agents by protocol."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        result = await async_session.execute(select(Agent).where(Agent.protocol == "mcp"))
        mcp_agents = result.scalars().all()

        assert len(mcp_agents) == 1
        assert mcp_agents[0].name == "network"

    @pytest.mark.asyncio
    async def test_query_agents_by_security_score(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test querying agents by minimum security score."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        result = await async_session.execute(select(Agent).where(Agent.security_score >= 90))
        secure_agents = result.scalars().all()

        assert len(secure_agents) == 1
        assert secure_agents[0].name == "chat"
