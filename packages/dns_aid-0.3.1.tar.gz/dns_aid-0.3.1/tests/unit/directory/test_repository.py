"""Unit tests for DNS-AID directory repository layer."""

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from dns_aid.directory.models import Agent, Domain
from dns_aid.directory.repository import (
    AgentRepository,
    CrawlHistoryRepository,
    DomainRepository,
)


class TestDomainRepository:
    """Tests for DomainRepository."""

    @pytest.mark.asyncio
    async def test_create_domain(self, async_session: AsyncSession):
        """Test creating a new domain submission."""
        repo = DomainRepository(async_session)

        domain = await repo.create("newdomain.com")
        await async_session.commit()

        assert domain.domain == "newdomain.com"
        assert domain.verified is False
        assert domain.verification_token is not None
        assert len(domain.verification_token) > 20  # URL-safe token

    @pytest.mark.asyncio
    async def test_get_domain(self, async_session: AsyncSession, sample_domain: Domain):
        """Test retrieving a domain by name."""
        async_session.add(sample_domain)
        await async_session.commit()

        repo = DomainRepository(async_session)
        domain = await repo.get("example.com")

        assert domain is not None
        assert domain.domain == "example.com"

    @pytest.mark.asyncio
    async def test_get_domain_not_found(self, async_session: AsyncSession):
        """Test retrieving a non-existent domain."""
        repo = DomainRepository(async_session)
        domain = await repo.get("nonexistent.com")

        assert domain is None

    @pytest.mark.asyncio
    async def test_get_verified_domain(self, async_session: AsyncSession, sample_domain: Domain):
        """Test retrieving only verified domains."""
        async_session.add(sample_domain)
        await async_session.commit()

        repo = DomainRepository(async_session)
        domain = await repo.get_verified("example.com")

        assert domain is not None
        assert domain.verified is True

    @pytest.mark.asyncio
    async def test_get_verified_domain_unverified(
        self, async_session: AsyncSession, sample_unverified_domain: Domain
    ):
        """Test get_verified returns None for unverified domains."""
        async_session.add(sample_unverified_domain)
        await async_session.commit()

        repo = DomainRepository(async_session)
        domain = await repo.get_verified("pending.com")

        assert domain is None

    @pytest.mark.asyncio
    async def test_list_all_domains(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_unverified_domain: Domain,
    ):
        """Test listing all domains."""
        async_session.add(sample_domain)
        async_session.add(sample_unverified_domain)
        await async_session.commit()

        repo = DomainRepository(async_session)
        domains = await repo.list_all()

        assert len(domains) == 2

    @pytest.mark.asyncio
    async def test_list_verified_only(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_unverified_domain: Domain,
    ):
        """Test listing only verified domains."""
        async_session.add(sample_domain)
        async_session.add(sample_unverified_domain)
        await async_session.commit()

        repo = DomainRepository(async_session)
        domains = await repo.list_all(verified_only=True)

        assert len(domains) == 1
        assert domains[0].domain == "example.com"

    @pytest.mark.asyncio
    async def test_list_with_pagination(self, async_session: AsyncSession):
        """Test list pagination."""
        repo = DomainRepository(async_session)

        # Create 5 domains
        for i in range(5):
            await repo.create(f"domain{i}.com")
        await async_session.commit()

        # Get first 2
        page1 = await repo.list_all(limit=2, offset=0)
        assert len(page1) == 2

        # Get next 2
        page2 = await repo.list_all(limit=2, offset=2)
        assert len(page2) == 2

        # Get remaining
        page3 = await repo.list_all(limit=2, offset=4)
        assert len(page3) == 1

    @pytest.mark.asyncio
    async def test_count_domains(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_unverified_domain: Domain,
    ):
        """Test counting domains."""
        async_session.add(sample_domain)
        async_session.add(sample_unverified_domain)
        await async_session.commit()

        repo = DomainRepository(async_session)

        total = await repo.count()
        assert total == 2

        verified = await repo.count(verified_only=True)
        assert verified == 1

    @pytest.mark.asyncio
    async def test_verify_domain(self, async_session: AsyncSession):
        """Test verifying a domain."""
        repo = DomainRepository(async_session)

        # Create unverified domain
        await repo.create("toverify.com")
        await async_session.commit()

        # Verify it
        domain = await repo.verify("toverify.com")
        await async_session.commit()

        assert domain is not None
        assert domain.verified is True
        assert domain.verified_at is not None

    @pytest.mark.asyncio
    async def test_update_crawl_status(self, async_session: AsyncSession, sample_domain: Domain):
        """Test updating crawl status."""
        async_session.add(sample_domain)
        await async_session.commit()

        repo = DomainRepository(async_session)
        await repo.update_crawl_status("example.com", "crawling", agent_count=5)
        await async_session.commit()

        # Refresh and check
        domain = await repo.get("example.com")
        assert domain.crawl_status == "crawling"
        assert domain.agent_count == 5

    @pytest.mark.asyncio
    async def test_delete_domain(self, async_session: AsyncSession, sample_domain: Domain):
        """Test deleting a domain."""
        async_session.add(sample_domain)
        await async_session.commit()

        repo = DomainRepository(async_session)
        deleted = await repo.delete("example.com")
        await async_session.commit()

        assert deleted is True

        # Verify it's gone
        domain = await repo.get("example.com")
        assert domain is None

    @pytest.mark.asyncio
    async def test_delete_nonexistent_domain(self, async_session: AsyncSession):
        """Test deleting a non-existent domain."""
        repo = DomainRepository(async_session)
        deleted = await repo.delete("nonexistent.com")

        assert deleted is False


class TestAgentRepository:
    """Tests for AgentRepository."""

    @pytest.mark.asyncio
    async def test_create_agent(self, async_session: AsyncSession, sample_domain: Domain):
        """Test creating a new agent."""
        async_session.add(sample_domain)
        await async_session.commit()

        repo = AgentRepository(async_session)
        agent = await repo.create(
            fqdn="_test._mcp._agents.example.com",
            domain="example.com",
            name="test",
            protocol="mcp",
            endpoint_url="https://test.example.com",
            port=443,
            capabilities=["test", "demo"],
            version="1.0.0",
            security_score=80,
        )
        await async_session.commit()

        assert agent.fqdn == "_test._mcp._agents.example.com"
        assert agent.name == "test"
        assert agent.protocol == "mcp"
        assert agent.security_score == 80

    @pytest.mark.asyncio
    async def test_get_agent(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
    ):
        """Test retrieving an agent by FQDN."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        repo = AgentRepository(async_session)
        agent = await repo.get("_network._mcp._agents.example.com")

        assert agent is not None
        assert agent.name == "network"

    @pytest.mark.asyncio
    async def test_get_agent_not_found(self, async_session: AsyncSession):
        """Test retrieving a non-existent agent."""
        repo = AgentRepository(async_session)
        agent = await repo.get("_nonexistent._mcp._agents.example.com")

        assert agent is None

    @pytest.mark.asyncio
    async def test_get_by_domain(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test getting agents by domain."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        repo = AgentRepository(async_session)
        agents = await repo.get_by_domain("example.com")

        assert len(agents) == 2

    @pytest.mark.asyncio
    async def test_get_by_domain_with_protocol(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test getting agents filtered by protocol."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        repo = AgentRepository(async_session)
        agents = await repo.get_by_domain("example.com", protocol="mcp")

        assert len(agents) == 1
        assert agents[0].protocol == "mcp"

    @pytest.mark.asyncio
    async def test_list_all_agents(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test listing all agents."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        repo = AgentRepository(async_session)
        agents = await repo.list_all()

        assert len(agents) == 2

    @pytest.mark.asyncio
    async def test_list_all_with_protocol_filter(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test listing agents with protocol filter."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        repo = AgentRepository(async_session)
        agents = await repo.list_all(protocol="a2a")

        assert len(agents) == 1
        assert agents[0].protocol == "a2a"

    @pytest.mark.asyncio
    async def test_count_agents(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test counting agents."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        repo = AgentRepository(async_session)

        total = await repo.count()
        assert total == 2

        by_domain = await repo.count(domain="example.com")
        assert by_domain == 2

        by_protocol = await repo.count(protocol="mcp")
        assert by_protocol == 1

    @pytest.mark.asyncio
    async def test_upsert_create(self, async_session: AsyncSession, sample_domain: Domain):
        """Test upsert creates new agent."""
        async_session.add(sample_domain)
        await async_session.commit()

        repo = AgentRepository(async_session)
        agent, created = await repo.upsert(
            fqdn="_new._mcp._agents.example.com",
            domain="example.com",
            name="new",
            protocol="mcp",
            security_score=50,
        )
        await async_session.commit()

        assert created is True
        assert agent.name == "new"
        assert agent.security_score == 50

    @pytest.mark.asyncio
    async def test_upsert_update(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
    ):
        """Test upsert updates existing agent."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        repo = AgentRepository(async_session)
        agent, created = await repo.upsert(
            fqdn="_network._mcp._agents.example.com",
            domain="example.com",
            name="network",
            protocol="mcp",
            security_score=99,
            version="2.0.0",
        )
        await async_session.commit()

        assert created is False
        assert agent.security_score == 99
        assert agent.version == "2.0.0"

    @pytest.mark.asyncio
    async def test_update_scores(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
    ):
        """Test updating agent scores."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        repo = AgentRepository(async_session)
        await repo.update_scores(
            fqdn="_network._mcp._agents.example.com",
            security_score=100,
            trust_score=95,
            popularity_score=80,
        )
        await async_session.commit()

        agent = await repo.get("_network._mcp._agents.example.com")
        assert agent.security_score == 100
        assert agent.trust_score == 95
        assert agent.popularity_score == 80

    @pytest.mark.asyncio
    async def test_update_threat_flags(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
    ):
        """Test updating threat flags."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        repo = AgentRepository(async_session)
        await repo.update_threat_flags(
            fqdn="_network._mcp._agents.example.com",
            threat_flags={"ioc_match": True, "severity": "high"},
        )
        await async_session.commit()

        agent = await repo.get("_network._mcp._agents.example.com")
        assert agent.threat_flags["ioc_match"] is True

    @pytest.mark.asyncio
    async def test_delete_agent(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
    ):
        """Test deleting an agent."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        repo = AgentRepository(async_session)
        deleted = await repo.delete("_network._mcp._agents.example.com")
        await async_session.commit()

        assert deleted is True
        assert await repo.get("_network._mcp._agents.example.com") is None

    @pytest.mark.asyncio
    async def test_delete_by_domain(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test deleting all agents for a domain."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        repo = AgentRepository(async_session)
        count = await repo.delete_by_domain("example.com")
        await async_session.commit()

        assert count == 2
        assert await repo.count(domain="example.com") == 0


class TestCrawlHistoryRepository:
    """Tests for CrawlHistoryRepository."""

    @pytest.mark.asyncio
    async def test_create_crawl(self, async_session: AsyncSession, sample_domain: Domain):
        """Test creating a crawl record."""
        async_session.add(sample_domain)
        await async_session.commit()

        repo = CrawlHistoryRepository(async_session)
        crawl = await repo.create("example.com")
        await async_session.commit()

        assert crawl.id is not None
        assert crawl.domain == "example.com"
        assert crawl.status == "running"

    @pytest.mark.asyncio
    async def test_complete_crawl(self, async_session: AsyncSession, sample_domain: Domain):
        """Test completing a crawl."""
        async_session.add(sample_domain)
        await async_session.commit()

        repo = CrawlHistoryRepository(async_session)
        crawl = await repo.create("example.com")
        await async_session.commit()

        await repo.complete(
            crawl_id=crawl.id,
            status="success",
            agents_found=5,
            agents_added=3,
            agents_updated=2,
        )
        await async_session.commit()

        # Check via get_recent
        recent = await repo.get_recent("example.com", limit=1)
        assert len(recent) == 1
        assert recent[0].status == "success"
        assert recent[0].agents_found == 5
        assert recent[0].completed_at is not None

    @pytest.mark.asyncio
    async def test_complete_crawl_with_error(
        self, async_session: AsyncSession, sample_domain: Domain
    ):
        """Test completing a failed crawl."""
        async_session.add(sample_domain)
        await async_session.commit()

        repo = CrawlHistoryRepository(async_session)
        crawl = await repo.create("example.com")
        await async_session.commit()

        await repo.complete(
            crawl_id=crawl.id,
            status="failed",
            error_message="Connection refused",
        )
        await async_session.commit()

        recent = await repo.get_recent("example.com")
        assert recent[0].status == "failed"
        assert recent[0].error_message == "Connection refused"

    @pytest.mark.asyncio
    async def test_get_recent_crawls(self, async_session: AsyncSession, sample_domain: Domain):
        """Test getting recent crawl history."""
        async_session.add(sample_domain)
        await async_session.commit()

        repo = CrawlHistoryRepository(async_session)

        # Create multiple crawls
        for _ in range(5):
            await repo.create("example.com")
        await async_session.commit()

        # Get recent with limit
        recent = await repo.get_recent("example.com", limit=3)
        assert len(recent) == 3

        # Get all recent
        all_recent = await repo.get_recent("example.com", limit=10)
        assert len(all_recent) == 5

    @pytest.mark.asyncio
    async def test_get_recent_all_domains(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_unverified_domain: Domain,
    ):
        """Test getting recent crawls across all domains."""
        async_session.add(sample_domain)
        async_session.add(sample_unverified_domain)
        await async_session.commit()

        repo = CrawlHistoryRepository(async_session)

        await repo.create("example.com")
        await repo.create("pending.com")
        await async_session.commit()

        # Get recent for all domains
        recent = await repo.get_recent(limit=10)
        assert len(recent) == 2
