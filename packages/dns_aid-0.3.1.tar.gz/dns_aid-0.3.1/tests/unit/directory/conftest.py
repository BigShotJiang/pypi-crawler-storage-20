"""Pytest fixtures for directory module tests."""

from collections.abc import AsyncGenerator
from datetime import UTC, datetime

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from dns_aid.directory.models import Agent, Base, CrawlHistory, Domain


@pytest.fixture(scope="function")
def anyio_backend():
    """Use asyncio backend for async tests."""
    return "asyncio"


@pytest_asyncio.fixture(scope="function")
async def async_engine():
    """Create an async SQLite engine for testing."""
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        echo=False,
    )

    # SQLite doesn't support arrays natively, so we need to handle this
    # For testing, we'll use JSON serialization for array fields

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    yield engine

    await engine.dispose()


@pytest_asyncio.fixture(scope="function")
async def async_session(async_engine) -> AsyncGenerator[AsyncSession, None]:
    """Create an async session for testing."""
    session_factory = async_sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    async with session_factory() as session:
        yield session
        await session.rollback()


@pytest.fixture
def sample_domain() -> Domain:
    """Create a sample domain for testing."""
    return Domain(
        domain="example.com",
        verified=True,
        verification_token="test-token-12345",
        submitted_at=datetime.now(UTC),
        verified_at=datetime.now(UTC),
        crawl_status="completed",
        agent_count=2,
        metadata={"source": "test"},
    )


@pytest.fixture
def sample_unverified_domain() -> Domain:
    """Create a sample unverified domain for testing."""
    return Domain(
        domain="pending.com",
        verified=False,
        verification_token="pending-token-67890",
        submitted_at=datetime.now(UTC),
        crawl_status="pending",
    )


@pytest.fixture
def sample_agent(sample_domain: Domain) -> Agent:
    """Create a sample agent for testing."""
    return Agent(
        fqdn="_network._mcp._agents.example.com",
        domain=sample_domain.domain,
        name="network",
        protocol="mcp",
        endpoint_url="https://mcp.example.com:443",
        port=443,
        capabilities=["ipam", "dns", "vpn"],
        version="1.0.0",
        security_score=85,
        trust_score=90,
        popularity_score=75,
        threat_flags={},
        first_seen=datetime.now(UTC),
        last_seen=datetime.now(UTC),
        last_verified=datetime.now(UTC),
        metadata={"provider": "test"},
    )


@pytest.fixture
def sample_a2a_agent(sample_domain: Domain) -> Agent:
    """Create a sample A2A agent for testing."""
    return Agent(
        fqdn="_chat._a2a._agents.example.com",
        domain=sample_domain.domain,
        name="chat",
        protocol="a2a",
        endpoint_url="https://chat.example.com:443",
        port=443,
        capabilities=["chat", "assistant", "search"],
        version="2.0.0",
        security_score=95,
        trust_score=85,
        popularity_score=90,
        threat_flags={},
        first_seen=datetime.now(UTC),
        last_seen=datetime.now(UTC),
        last_verified=datetime.now(UTC),
    )


@pytest.fixture
def sample_crawl_history(sample_domain: Domain) -> CrawlHistory:
    """Create a sample crawl history entry for testing."""
    return CrawlHistory(
        domain=sample_domain.domain,
        started_at=datetime.now(UTC),
        completed_at=datetime.now(UTC),
        status="success",
        agents_found=2,
        agents_added=2,
        agents_updated=0,
    )
