"""Unit tests for DNS-AID directory search engine."""

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from dns_aid.directory.models import Agent, Domain
from dns_aid.directory.search import SearchEngine, SearchResponse, SearchResult


class TestSearchResult:
    """Tests for SearchResult dataclass."""

    def test_search_result_creation(self, sample_agent: Agent):
        """Test creating a search result."""
        result = SearchResult(agent=sample_agent, score=75.5)

        assert result.agent == sample_agent
        assert result.score == 75.5
        assert result.highlights is None

    def test_search_result_with_highlights(self, sample_agent: Agent):
        """Test search result with highlights."""
        result = SearchResult(
            agent=sample_agent,
            score=80.0,
            highlights={"name": "<em>network</em>"},
        )

        assert result.highlights["name"] == "<em>network</em>"


class TestSearchResponse:
    """Tests for SearchResponse dataclass."""

    def test_search_response_count(self, sample_agent: Agent, sample_a2a_agent: Agent):
        """Test search response count property."""
        results = [
            SearchResult(agent=sample_agent, score=80.0),
            SearchResult(agent=sample_a2a_agent, score=70.0),
        ]
        response = SearchResponse(
            query="test",
            results=results,
            total=10,
            limit=20,
            offset=0,
        )

        assert response.count == 2
        assert response.total == 10


class TestSearchEngine:
    """Tests for SearchEngine."""

    @pytest.mark.asyncio
    async def test_search_by_name(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
    ):
        """Test searching agents by name."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)
        result = await engine.search("network", verified_only=False)

        assert result.total >= 1
        assert any(r.agent.name == "network" for r in result.results)

    @pytest.mark.asyncio
    async def test_search_by_capability(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
    ):
        """Test searching agents by capability."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)
        result = await engine.search("ipam", verified_only=False)

        assert result.total >= 1

    @pytest.mark.asyncio
    async def test_search_by_domain(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
    ):
        """Test searching agents by domain name."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)
        result = await engine.search("example", verified_only=False)

        assert result.total >= 1
        assert result.results[0].agent.domain == "example.com"

    @pytest.mark.asyncio
    async def test_search_case_insensitive(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
    ):
        """Test that search is case insensitive."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)

        result_upper = await engine.search("NETWORK", verified_only=False)
        result_lower = await engine.search("network", verified_only=False)

        assert result_upper.total == result_lower.total

    @pytest.mark.asyncio
    async def test_search_with_protocol_filter(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test filtering search by protocol."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)
        result = await engine.search("", protocol="mcp", verified_only=False)

        assert all(r.agent.protocol == "mcp" for r in result.results)

    @pytest.mark.asyncio
    async def test_search_with_domain_filter(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
    ):
        """Test filtering search by domain."""
        # Add another domain with agent
        other_domain = Domain(
            domain="other.com",
            verified=True,
            verification_token="token",
        )
        other_agent = Agent(
            fqdn="_test._mcp._agents.other.com",
            domain="other.com",
            name="test",
            protocol="mcp",
        )
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(other_domain)
        async_session.add(other_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)
        result = await engine.search("", domain="example.com", verified_only=False)

        assert all(r.agent.domain == "example.com" for r in result.results)

    @pytest.mark.asyncio
    async def test_search_with_min_security_score(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test filtering by minimum security score."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)  # security_score = 85
        async_session.add(sample_a2a_agent)  # security_score = 95
        await async_session.commit()

        engine = SearchEngine(async_session)
        result = await engine.search("", min_security_score=90, verified_only=False)

        assert all(r.agent.security_score >= 90 for r in result.results)
        assert result.total == 1

    @pytest.mark.asyncio
    async def test_search_verified_only(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_unverified_domain: Domain,
        sample_agent: Agent,
    ):
        """Test verified_only filter."""
        # Add agent to unverified domain
        unverified_agent = Agent(
            fqdn="_test._mcp._agents.pending.com",
            domain="pending.com",
            name="test",
            protocol="mcp",
        )
        async_session.add(sample_domain)
        async_session.add(sample_unverified_domain)
        async_session.add(sample_agent)
        async_session.add(unverified_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)

        # Verified only
        verified_result = await engine.search("", verified_only=True)
        assert all(r.agent.domain == "example.com" for r in verified_result.results)

        # All domains
        all_result = await engine.search("", verified_only=False)
        assert all_result.total >= verified_result.total

    @pytest.mark.asyncio
    async def test_search_pagination(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
    ):
        """Test search pagination."""
        # Create 10 agents
        for i in range(10):
            agent = Agent(
                fqdn=f"_agent{i}._mcp._agents.example.com",
                domain="example.com",
                name=f"agent{i}",
                protocol="mcp",
            )
            async_session.add(agent)
        async_session.add(sample_domain)
        await async_session.commit()

        engine = SearchEngine(async_session)

        # First page
        page1 = await engine.search("agent", limit=3, offset=0, verified_only=False)
        assert page1.count == 3
        assert page1.total == 10

        # Second page
        page2 = await engine.search("agent", limit=3, offset=3, verified_only=False)
        assert page2.count == 3

        # Ensure different results
        page1_fqdns = {r.agent.fqdn for r in page1.results}
        page2_fqdns = {r.agent.fqdn for r in page2.results}
        assert page1_fqdns.isdisjoint(page2_fqdns)

    @pytest.mark.asyncio
    async def test_search_no_results(self, async_session: AsyncSession):
        """Test search with no matching results."""
        engine = SearchEngine(async_session)
        result = await engine.search("nonexistent")

        assert result.total == 0
        assert result.count == 0

    @pytest.mark.asyncio
    async def test_search_empty_query(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test search with empty query returns all."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)
        result = await engine.search("", verified_only=False)

        assert result.total == 2


class TestSearchEngineRelevance:
    """Tests for relevance scoring."""

    @pytest.mark.asyncio
    async def test_exact_name_match_scores_higher(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
    ):
        """Test that exact name match gets highest score."""
        # Agent with exact name match
        exact_agent = Agent(
            fqdn="_network._mcp._agents.example.com",
            domain="example.com",
            name="network",
            protocol="mcp",
        )
        # Agent with partial match
        partial_agent = Agent(
            fqdn="_network-monitor._mcp._agents.example.com",
            domain="example.com",
            name="network-monitor",
            protocol="mcp",
        )
        async_session.add(sample_domain)
        async_session.add(exact_agent)
        async_session.add(partial_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)
        result = await engine.search("network", verified_only=False)

        # Exact match should be first after sorting
        assert result.results[0].agent.name == "network"
        assert result.results[0].score > result.results[1].score

    @pytest.mark.asyncio
    async def test_popularity_affects_score(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
    ):
        """Test that popularity affects relevance score."""
        popular_agent = Agent(
            fqdn="_popular._mcp._agents.example.com",
            domain="example.com",
            name="agent",
            protocol="mcp",
            popularity_score=100,
        )
        unpopular_agent = Agent(
            fqdn="_unpopular._mcp._agents.example.com",
            domain="example.com",
            name="agent",
            protocol="mcp",
            popularity_score=0,
        )
        async_session.add(sample_domain)
        async_session.add(popular_agent)
        async_session.add(unpopular_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)
        result = await engine.search("agent", verified_only=False)

        popular_result = next(
            r for r in result.results if r.agent.fqdn == "_popular._mcp._agents.example.com"
        )
        unpopular_result = next(
            r for r in result.results if r.agent.fqdn == "_unpopular._mcp._agents.example.com"
        )

        assert popular_result.score > unpopular_result.score


class TestSearchEngineSuggestions:
    """Tests for search suggestions."""

    @pytest.mark.asyncio
    async def test_get_suggestions(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
    ):
        """Test getting search suggestions."""
        agents = [
            Agent(
                fqdn=f"_network{i}._mcp._agents.example.com",
                domain="example.com",
                name=f"network{i}",
                protocol="mcp",
            )
            for i in range(5)
        ]
        async_session.add(sample_domain)
        for agent in agents:
            async_session.add(agent)
        await async_session.commit()

        engine = SearchEngine(async_session)
        suggestions = await engine.get_suggestions("net")

        assert len(suggestions) <= 10
        assert all(s.lower().startswith("net") for s in suggestions)

    @pytest.mark.asyncio
    async def test_get_suggestions_limit(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
    ):
        """Test suggestion limit."""
        agents = [
            Agent(
                fqdn=f"_test{i}._mcp._agents.example.com",
                domain="example.com",
                name=f"test{i}",
                protocol="mcp",
            )
            for i in range(20)
        ]
        async_session.add(sample_domain)
        for agent in agents:
            async_session.add(agent)
        await async_session.commit()

        engine = SearchEngine(async_session)
        suggestions = await engine.get_suggestions("test", limit=5)

        assert len(suggestions) == 5

    @pytest.mark.asyncio
    async def test_get_suggestions_case_insensitive(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_agent: Agent,
    ):
        """Test suggestions are case insensitive."""
        async_session.add(sample_domain)
        async_session.add(sample_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)

        suggestions_upper = await engine.get_suggestions("NET")
        suggestions_lower = await engine.get_suggestions("net")

        assert suggestions_upper == suggestions_lower


class TestSearchEngineStats:
    """Tests for search statistics."""

    @pytest.mark.asyncio
    async def test_get_stats(
        self,
        async_session: AsyncSession,
        sample_domain: Domain,
        sample_unverified_domain: Domain,
        sample_agent: Agent,
        sample_a2a_agent: Agent,
    ):
        """Test getting search statistics."""
        async_session.add(sample_domain)
        async_session.add(sample_unverified_domain)
        async_session.add(sample_agent)
        async_session.add(sample_a2a_agent)
        await async_session.commit()

        engine = SearchEngine(async_session)
        stats = await engine.get_stats()

        assert stats["total_agents"] == 2
        assert stats["total_domains"] == 2
        assert stats["verified_domains"] == 1
        assert "mcp" in stats["agents_by_protocol"]
        assert "a2a" in stats["agents_by_protocol"]

    @pytest.mark.asyncio
    async def test_get_stats_empty_database(self, async_session: AsyncSession):
        """Test stats on empty database."""
        engine = SearchEngine(async_session)
        stats = await engine.get_stats()

        assert stats["total_agents"] == 0
        assert stats["total_domains"] == 0
        assert stats["verified_domains"] == 0
        assert stats["agents_by_protocol"] == {}
