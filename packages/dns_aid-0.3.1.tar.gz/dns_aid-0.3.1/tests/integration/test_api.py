"""Integration tests for DNS-AID Agent Directory API.

These tests verify end-to-end flows through the API.
"""

from collections.abc import AsyncGenerator
from unittest.mock import MagicMock, patch

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from dns_aid.api.app import app
from dns_aid.directory.database import get_db_session
from dns_aid.directory.models import Agent, Base, Domain


def create_mock_dns_answer(token: str):
    """Create a mock DNS answer with a TXT record."""
    mock_rdata = MagicMock()
    mock_rdata.strings = [token.encode("utf-8")]
    return [mock_rdata]


@pytest.fixture(scope="function")
def anyio_backend():
    """Use asyncio backend for async tests."""
    return "asyncio"


@pytest_asyncio.fixture(scope="function")
async def async_engine():
    """Create an async SQLite engine for integration testing."""
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        echo=False,
    )

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    yield engine

    await engine.dispose()


@pytest_asyncio.fixture(scope="function")
async def session_factory(async_engine):
    """Create a shared session factory for integration tests."""
    return async_sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )


@pytest_asyncio.fixture(scope="function")
async def test_client(session_factory) -> AsyncGenerator[AsyncClient, None]:
    """Create an async test client with database override."""

    async def override_get_db():
        """Override that commits sessions like production does."""
        session = session_factory()
        try:
            yield session
            await session.commit()  # Match production behavior
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()

    app.dependency_overrides[get_db_session] = override_get_db

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as client:
        yield client

    app.dependency_overrides.clear()


class TestDomainSubmissionFlow:
    """Integration tests for the domain submission workflow."""

    @pytest.mark.asyncio
    async def test_full_submission_and_verification_flow(self, test_client: AsyncClient):
        """Test complete domain submission and verification flow."""
        # Step 1: Submit domain
        submit_response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "integration-test.com"},
        )

        assert submit_response.status_code == 201
        submit_data = submit_response.json()
        assert submit_data["domain"] == "integration-test.com"
        # DomainSubmitResponse returns verification_token, not verified
        assert "verification_token" in submit_data
        verification_token = submit_data["verification_token"]

        # Step 2: Check domain status (should be unverified)
        get_response = await test_client.get("/api/v1/domains/integration-test.com")
        assert get_response.status_code == 200
        assert get_response.json()["verified"] is False

        # Step 3: Verify domain (mock DNS lookup)
        with patch(
            "dns_aid.api.routes.domains.dns.resolver.resolve",
            return_value=create_mock_dns_answer(verification_token),
        ):
            verify_response = await test_client.post(
                "/api/v1/domains/verify",
                json={"domain": "integration-test.com"},
            )

        assert verify_response.status_code == 200
        assert verify_response.json()["verified"] is True

        # Step 4: Check domain status (should be verified)
        get_verified = await test_client.get("/api/v1/domains/integration-test.com")
        assert get_verified.status_code == 200
        assert get_verified.json()["verified"] is True

    @pytest.mark.asyncio
    async def test_submit_verify_and_delete_flow(self, test_client: AsyncClient):
        """Test submit, verify, and delete flow."""
        # Submit
        submit_response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "delete-test.com"},
        )
        token = submit_response.json()["verification_token"]

        # Verify
        with patch(
            "dns_aid.api.routes.domains.dns.resolver.resolve",
            return_value=create_mock_dns_answer(token),
        ):
            await test_client.post(
                "/api/v1/domains/verify",
                json={"domain": "delete-test.com"},
            )

        # Delete
        delete_response = await test_client.delete("/api/v1/domains/delete-test.com")
        assert delete_response.status_code == 204

        # Verify deletion
        get_response = await test_client.get("/api/v1/domains/delete-test.com")
        assert get_response.status_code == 404


class TestSearchFlow:
    """Integration tests for search functionality."""

    @pytest_asyncio.fixture
    async def seeded_agents(self, test_client: AsyncClient, session_factory):
        """Seed database with multiple agents for search testing."""
        async with session_factory() as session:
            # Create domain
            domain = Domain(
                domain="search-test.com",
                verified=True,
                verification_token="token",
            )
            session.add(domain)

            # Create multiple agents
            agents_data = [
                {
                    "fqdn": "_network._mcp._agents.search-test.com",
                    "name": "network",
                    "protocol": "mcp",
                    "capabilities": ["ipam", "dns", "vpn"],
                    "security_score": 90,
                    "popularity_score": 80,
                },
                {
                    "fqdn": "_chat._a2a._agents.search-test.com",
                    "name": "chat",
                    "protocol": "a2a",
                    "capabilities": ["chat", "assistant"],
                    "security_score": 85,
                    "popularity_score": 95,
                },
                {
                    "fqdn": "_billing._https._agents.search-test.com",
                    "name": "billing",
                    "protocol": "https",
                    "capabilities": ["billing", "payments"],
                    "security_score": 75,
                    "popularity_score": 60,
                },
            ]

            for agent_data in agents_data:
                agent = Agent(
                    fqdn=agent_data["fqdn"],
                    domain="search-test.com",
                    name=agent_data["name"],
                    protocol=agent_data["protocol"],
                    capabilities=agent_data["capabilities"],
                    security_score=agent_data["security_score"],
                    popularity_score=agent_data["popularity_score"],
                )
                session.add(agent)

            await session.commit()

    @pytest.mark.asyncio
    async def test_search_and_get_agent_flow(self, test_client: AsyncClient, seeded_agents):
        """Test searching and then getting agent details."""
        # Search for network agents
        search_response = await test_client.get("/api/v1/search?q=network")

        assert search_response.status_code == 200
        search_data = search_response.json()
        assert search_data["total"] >= 1

        # Get the first result's FQDN
        first_result = search_data["results"][0]
        fqdn = first_result["agent"]["fqdn"]

        # Get full agent details
        agent_response = await test_client.get(f"/api/v1/agents/{fqdn}")
        assert agent_response.status_code == 200

        agent_data = agent_response.json()
        assert agent_data["fqdn"] == fqdn
        assert "capabilities" in agent_data
        assert "security_score" in agent_data

    @pytest.mark.asyncio
    async def test_search_with_multiple_filters(self, test_client: AsyncClient, seeded_agents):
        """Test search with combined filters."""
        # Search with protocol filter
        mcp_response = await test_client.get("/api/v1/search?q=network&protocol=mcp")
        assert mcp_response.status_code == 200
        mcp_data = mcp_response.json()
        assert all(r["agent"]["protocol"] == "mcp" for r in mcp_data["results"])

        # Search with security score filter (query required, min_length=1)
        secure_response = await test_client.get("/api/v1/search?q=agent&min_security_score=85")
        assert secure_response.status_code == 200
        secure_data = secure_response.json()
        assert all(r["agent"]["security_score"] >= 85 for r in secure_data["results"])

    @pytest.mark.asyncio
    async def test_search_pagination_flow(self, test_client: AsyncClient, seeded_agents):
        """Test paginating through search results."""
        # Get first page (query required, using wildcard-like search)
        page1_response = await test_client.get("/api/v1/search?q=search&limit=2&offset=0")
        assert page1_response.status_code == 200
        page1_data = page1_response.json()

        # Get second page
        page2_response = await test_client.get("/api/v1/search?q=search&limit=2&offset=2")
        assert page2_response.status_code == 200
        page2_data = page2_response.json()

        # Both should have results or empty (depending on search match)
        # Just verify the pagination structure is correct
        assert "results" in page1_data
        assert "results" in page2_data
        assert page1_data["offset"] == 0
        assert page2_data["offset"] == 2


class TestAgentLifecycle:
    """Integration tests for agent lifecycle operations."""

    @pytest_asyncio.fixture
    async def verified_domain(self, test_client: AsyncClient, session_factory):
        """Create a verified domain for agent testing."""
        async with session_factory() as session:
            domain = Domain(
                domain="agent-test.com",
                verified=True,
                verification_token="token",
            )
            session.add(domain)
            await session.commit()

    @pytest.mark.asyncio
    async def test_list_agents_for_domain(
        self, test_client: AsyncClient, verified_domain, session_factory
    ):
        """Test listing agents for a specific domain."""
        # First add some agents
        async with session_factory() as session:
            for i in range(3):
                agent = Agent(
                    fqdn=f"_agent{i}._mcp._agents.agent-test.com",
                    domain="agent-test.com",
                    name=f"agent{i}",
                    protocol="mcp",
                )
                session.add(agent)
            await session.commit()

        # List domain agents
        response = await test_client.get("/api/v1/domains/agent-test.com/agents")
        assert response.status_code == 200
        data = response.json()
        assert data["total"] == 3
        assert all(a["domain"] == "agent-test.com" for a in data["agents"])


class TestStatsAccuracy:
    """Integration tests for stats accuracy."""

    @pytest.mark.asyncio
    async def test_stats_reflect_data(self, test_client: AsyncClient, session_factory):
        """Test that stats accurately reflect database state."""

        # Check initial stats
        initial_stats = await test_client.get("/api/v1/stats")
        initial_data = initial_stats.json()
        initial_agents = initial_data["total_agents"]
        initial_domains = initial_data["total_domains"]

        # Add data
        async with session_factory() as session:
            domain = Domain(
                domain="stats-test.com",
                verified=True,
                verification_token="token",
            )
            agent = Agent(
                fqdn="_test._mcp._agents.stats-test.com",
                domain="stats-test.com",
                name="test",
                protocol="mcp",
            )
            session.add(domain)
            session.add(agent)
            await session.commit()

        # Check updated stats
        updated_stats = await test_client.get("/api/v1/stats")
        updated_data = updated_stats.json()

        assert updated_data["total_agents"] == initial_agents + 1
        assert updated_data["total_domains"] == initial_domains + 1
        assert "mcp" in updated_data["agents_by_protocol"]


class TestErrorHandling:
    """Integration tests for error handling."""

    @pytest.mark.asyncio
    async def test_404_error_format(self, test_client: AsyncClient):
        """Test that 404 errors have correct format."""
        response = await test_client.get("/api/v1/agents/nonexistent")

        assert response.status_code == 404
        data = response.json()
        assert "detail" in data
        assert "code" in data["detail"]
        assert "message" in data["detail"]

    @pytest.mark.asyncio
    async def test_validation_error_format(self, test_client: AsyncClient):
        """Test that validation errors have correct format."""
        response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": ""},  # Invalid empty domain
        )

        assert response.status_code == 422
        data = response.json()
        # API returns ValidationErrorResponse format (flat, not nested in 'detail')
        assert "code" in data
        assert "message" in data
        assert "errors" in data
        assert data["code"] == "DNS_AID_400"

    @pytest.mark.asyncio
    async def test_duplicate_submission_error(self, test_client: AsyncClient):
        """Test that duplicate domain submission returns conflict error for verified domains."""
        # First submission
        submit_response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "duplicate.com"},
        )
        token = submit_response.json()["verification_token"]

        # Verify the domain (mock DNS lookup)
        with patch(
            "dns_aid.api.routes.domains.dns.resolver.resolve",
            return_value=create_mock_dns_answer(token),
        ):
            await test_client.post(
                "/api/v1/domains/verify",
                json={"domain": "duplicate.com"},
            )

        # Second submission (duplicate of verified domain) should return 409
        response = await test_client.post(
            "/api/v1/domains/submit",
            json={"domain": "duplicate.com"},
        )

        assert response.status_code == 409
