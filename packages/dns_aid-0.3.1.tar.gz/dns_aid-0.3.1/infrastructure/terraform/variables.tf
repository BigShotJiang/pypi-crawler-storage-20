# DNS-AID Agent Directory - Terraform Variables
# Phase 1: Foundation & MVP

# ============================================================================
# AWS Configuration
# ============================================================================

variable "aws_region" {
  description = "AWS region for deployment"
  type        = string
  default     = "eu-west-2"
}

variable "aws_profile" {
  description = "AWS CLI profile to use (e.g., okta-sso)"
  type        = string
  default     = "default"
}

variable "environment" {
  description = "Environment name (dev, staging, prod)"
  type        = string
  default     = "dev"

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "Environment must be one of: dev, staging, prod"
  }
}

# ============================================================================
# VPC Configuration
# ============================================================================

variable "vpc_cidr" {
  description = "CIDR block for VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "availability_zones" {
  description = "Availability zones for deployment"
  type        = list(string)
  default     = ["eu-west-2a", "eu-west-2b", "eu-west-2c"]
}

variable "public_subnet_cidrs" {
  description = "CIDR blocks for public subnets"
  type        = list(string)
  default     = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
}

variable "private_subnet_cidrs" {
  description = "CIDR blocks for private subnets (Lambda)"
  type        = list(string)
  default     = ["10.0.11.0/24", "10.0.12.0/24", "10.0.13.0/24"]
}

variable "database_subnet_cidrs" {
  description = "CIDR blocks for database subnets"
  type        = list(string)
  default     = ["10.0.21.0/24", "10.0.22.0/24", "10.0.23.0/24"]
}

variable "enable_vpc_flow_logs" {
  description = "Enable VPC Flow Logs for debugging"
  type        = bool
  default     = false
}

# ============================================================================
# Database Configuration (RDS Serverless v2)
# ============================================================================

variable "db_name" {
  description = "Database name"
  type        = string
  default     = "dns_aid"
}

variable "db_username" {
  description = "Database master username (for admin tasks)"
  type        = string
  default     = "dns_aid_admin"
}

variable "db_app_username" {
  description = "Database application username (uses IAM authentication)"
  type        = string
  default     = "dns_aid_app"
}

variable "db_min_capacity" {
  description = "Minimum ACU capacity for RDS Serverless v2 (0.5 - 128)"
  type        = number
  default     = 0.5

  validation {
    condition     = var.db_min_capacity >= 0.5 && var.db_min_capacity <= 128
    error_message = "db_min_capacity must be between 0.5 and 128"
  }
}

variable "db_max_capacity" {
  description = "Maximum ACU capacity for RDS Serverless v2 (0.5 - 128)"
  type        = number
  default     = 2

  validation {
    condition     = var.db_max_capacity >= 0.5 && var.db_max_capacity <= 128
    error_message = "db_max_capacity must be between 0.5 and 128"
  }
}

# ============================================================================
# Lambda Configuration
# ============================================================================

variable "lambda_memory_size" {
  description = "Lambda memory size in MB"
  type        = number
  default     = 512

  validation {
    condition     = var.lambda_memory_size >= 128 && var.lambda_memory_size <= 10240
    error_message = "lambda_memory_size must be between 128 and 10240 MB"
  }
}

variable "lambda_timeout" {
  description = "Lambda timeout in seconds"
  type        = number
  default     = 30

  validation {
    condition     = var.lambda_timeout >= 1 && var.lambda_timeout <= 900
    error_message = "lambda_timeout must be between 1 and 900 seconds"
  }
}

# ============================================================================
# API Gateway Configuration
# ============================================================================

variable "api_throttle_rate_limit" {
  description = "API Gateway throttle rate limit (requests per second)"
  type        = number
  default     = 100
}

variable "api_throttle_burst_limit" {
  description = "API Gateway throttle burst limit"
  type        = number
  default     = 200
}

# ============================================================================
# Domain Configuration (Optional)
# ============================================================================

variable "domain_name" {
  description = "Custom domain name for API Gateway (optional)"
  type        = string
  default     = ""
}

variable "certificate_arn" {
  description = "ACM certificate ARN for custom domain (required if domain_name is set)"
  type        = string
  default     = ""
}

# ============================================================================
# Required Tags (per InfoSec)
# ============================================================================

variable "owner" {
  description = "Owner email address (required per InfoSec)"
  type        = string
  default     = "iracic@infoblox.com"
}

variable "description" {
  description = "Resource description (required per InfoSec)"
  type        = string
  default     = "DNS-AID Agent Directory - DNS-based agent discovery service"
}

variable "infosec_certified" {
  description = "InfoSec certification status (required for public-accessible workloads)"
  type        = string
  default     = "true"
}

# ============================================================================
# Phase 2: Crawler Configuration
# ============================================================================

variable "crawler_memory_size" {
  description = "Crawler Lambda memory size in MB"
  type        = number
  default     = 512

  validation {
    condition     = var.crawler_memory_size >= 128 && var.crawler_memory_size <= 10240
    error_message = "crawler_memory_size must be between 128 and 10240 MB"
  }
}

variable "crawler_timeout" {
  description = "Crawler Lambda timeout in seconds"
  type        = number
  default     = 120

  validation {
    condition     = var.crawler_timeout >= 1 && var.crawler_timeout <= 900
    error_message = "crawler_timeout must be between 1 and 900 seconds"
  }
}

variable "crawler_max_concurrency" {
  description = "Maximum concurrent crawler Lambda invocations"
  type        = number
  default     = 10
}

variable "crawler_batch_size" {
  description = "Number of SQS messages per crawler Lambda invocation"
  type        = number
  default     = 5
}

# ============================================================================
# Crawler Feature Flags
# ============================================================================

variable "enable_pdns_crawler" {
  description = "Enable passive DNS crawler"
  type        = bool
  default     = true
}

variable "enable_nsec_walker" {
  description = "Enable NSEC zone walking (disabled by default due to privacy concerns)"
  type        = bool
  default     = false
}

variable "enable_ct_monitor" {
  description = "Enable Certificate Transparency monitoring"
  type        = bool
  default     = true
}

# ============================================================================
# Crawler Scheduling
# ============================================================================

variable "enable_scheduled_recrawl" {
  description = "Enable scheduled re-crawl via EventBridge"
  type        = bool
  default     = true
}

variable "recrawl_interval_hours" {
  description = "Hours between scheduled re-crawls"
  type        = number
  default     = 6

  validation {
    condition     = var.recrawl_interval_hours >= 1 && var.recrawl_interval_hours <= 168
    error_message = "recrawl_interval_hours must be between 1 and 168 (1 week)"
  }
}
