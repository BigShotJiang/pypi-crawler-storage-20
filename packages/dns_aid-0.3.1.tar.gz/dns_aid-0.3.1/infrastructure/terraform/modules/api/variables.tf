# DNS-AID API Module - Variables

variable "name_prefix" {
  description = "Prefix for resource names"
  type        = string
}

variable "environment" {
  description = "Environment name"
  type        = string
}

variable "vpc_id" {
  description = "VPC ID"
  type        = string
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for Lambda"
  type        = list(string)
}

# Lambda configuration
variable "lambda_memory_size" {
  description = "Lambda memory size in MB"
  type        = number
  default     = 512
}

variable "lambda_timeout" {
  description = "Lambda timeout in seconds"
  type        = number
  default     = 30
}

# Database configuration
variable "db_host" {
  description = "Database host"
  type        = string
}

variable "db_port" {
  description = "Database port"
  type        = number
  default     = 5432
}

variable "db_name" {
  description = "Database name"
  type        = string
}

variable "db_username" {
  description = "Database username"
  type        = string
}

variable "db_cluster_resource_id" {
  description = "RDS cluster resource ID for IAM auth"
  type        = string
}

variable "db_cluster_arn" {
  description = "RDS cluster ARN"
  type        = string
}

# API Gateway configuration
variable "api_throttle_rate_limit" {
  description = "API throttle rate limit"
  type        = number
  default     = 100
}

variable "api_throttle_burst_limit" {
  description = "API throttle burst limit"
  type        = number
  default     = 200
}

variable "tags" {
  description = "Tags to apply to resources"
  type        = map(string)
  default     = {}
}
