# DNS-AID Crawler Module Outputs

# ============================================================================
# SQS Queue Outputs
# ============================================================================

output "crawl_queue_url" {
  description = "URL of the crawl jobs SQS queue"
  value       = aws_sqs_queue.crawl_jobs.url
}

output "crawl_queue_arn" {
  description = "ARN of the crawl jobs SQS queue"
  value       = aws_sqs_queue.crawl_jobs.arn
}

output "recrawl_queue_url" {
  description = "URL of the re-crawl jobs SQS queue"
  value       = aws_sqs_queue.recrawl_jobs.url
}

output "recrawl_queue_arn" {
  description = "ARN of the re-crawl jobs SQS queue"
  value       = aws_sqs_queue.recrawl_jobs.arn
}

output "dlq_url" {
  description = "URL of the dead letter queue"
  value       = aws_sqs_queue.crawler_dlq.url
}

output "dlq_arn" {
  description = "ARN of the dead letter queue"
  value       = aws_sqs_queue.crawler_dlq.arn
}

# ============================================================================
# Lambda Outputs
# ============================================================================

output "crawler_function_name" {
  description = "Name of the crawler Lambda function"
  value       = aws_lambda_function.crawler.function_name
}

output "crawler_function_arn" {
  description = "ARN of the crawler Lambda function"
  value       = aws_lambda_function.crawler.arn
}

output "scheduler_function_name" {
  description = "Name of the scheduler Lambda function"
  value       = aws_lambda_function.scheduler.function_name
}

output "scheduler_function_arn" {
  description = "ARN of the scheduler Lambda function"
  value       = aws_lambda_function.scheduler.arn
}

# ============================================================================
# CloudWatch Outputs
# ============================================================================

output "crawler_log_group" {
  description = "CloudWatch Log Group for crawler Lambda"
  value       = aws_cloudwatch_log_group.crawler.name
}

output "scheduler_log_group" {
  description = "CloudWatch Log Group for scheduler Lambda"
  value       = aws_cloudwatch_log_group.scheduler.name
}

# ============================================================================
# EventBridge Outputs
# ============================================================================

output "recrawl_schedule_rule" {
  description = "EventBridge rule for scheduled re-crawls"
  value       = aws_cloudwatch_event_rule.recrawl_schedule.name
}

output "recrawl_schedule_arn" {
  description = "ARN of the EventBridge rule"
  value       = aws_cloudwatch_event_rule.recrawl_schedule.arn
}
