# DNS-AID Crawler Infrastructure Module
# Phase 2: Crawler Infrastructure
#
# This module creates:
# - SQS queues for crawl job processing
# - Lambda functions for crawler workers
# - EventBridge rules for scheduled re-crawls
# - Dead letter queues for failed messages
# - CloudWatch Log Groups and Alarms

# Data sources
data "aws_region" "current" {}
data "aws_caller_identity" "current" {}

# ============================================================================
# SQS Queues
# ============================================================================

# Dead Letter Queue for failed crawl jobs
resource "aws_sqs_queue" "crawler_dlq" {
  name                       = "${var.name_prefix}-crawler-dlq"
  message_retention_seconds  = 1209600  # 14 days
  visibility_timeout_seconds = 300

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-crawler-dlq"
  })
}

# Main crawl job queue
resource "aws_sqs_queue" "crawl_jobs" {
  name                       = "${var.name_prefix}-crawl-jobs"
  visibility_timeout_seconds = var.crawler_timeout * 6  # 6x Lambda timeout
  message_retention_seconds  = 86400  # 1 day
  receive_wait_time_seconds  = 20  # Long polling

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.crawler_dlq.arn
    maxReceiveCount     = 3
  })

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-crawl-jobs"
  })
}

# Scheduled re-crawl queue (lower priority)
resource "aws_sqs_queue" "recrawl_jobs" {
  name                       = "${var.name_prefix}-recrawl-jobs"
  visibility_timeout_seconds = var.crawler_timeout * 6
  message_retention_seconds  = 86400
  receive_wait_time_seconds  = 20

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.crawler_dlq.arn
    maxReceiveCount     = 3
  })

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-recrawl-jobs"
  })
}

# ============================================================================
# IAM Role for Crawler Lambda
# ============================================================================

resource "aws_iam_role" "crawler_lambda" {
  name = "${var.name_prefix}-crawler-lambda-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      }
    ]
  })

  tags = var.tags
}

# Basic Lambda execution policy
resource "aws_iam_role_policy_attachment" "crawler_lambda_basic" {
  role       = aws_iam_role.crawler_lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

# VPC access policy
resource "aws_iam_role_policy_attachment" "crawler_lambda_vpc" {
  role       = aws_iam_role.crawler_lambda.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole"
}

# Crawler-specific IAM policy (SQS, RDS, etc.)
resource "aws_iam_role_policy" "crawler_lambda_policy" {
  name = "${var.name_prefix}-crawler-lambda-policy"
  role = aws_iam_role.crawler_lambda.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        # SQS permissions
        Effect = "Allow"
        Action = [
          "sqs:ReceiveMessage",
          "sqs:DeleteMessage",
          "sqs:GetQueueAttributes",
          "sqs:SendMessage"
        ]
        Resource = [
          aws_sqs_queue.crawl_jobs.arn,
          aws_sqs_queue.recrawl_jobs.arn,
          aws_sqs_queue.crawler_dlq.arn
        ]
      },
      {
        # RDS IAM authentication
        Effect = "Allow"
        Action = [
          "rds-db:connect"
        ]
        Resource = [
          "arn:aws:rds-db:*:*:dbuser:${var.db_cluster_resource_id}/${var.db_username}"
        ]
      },
      {
        # Secrets Manager (for DB credentials if needed)
        Effect = "Allow"
        Action = [
          "secretsmanager:GetSecretValue"
        ]
        Resource = [
          "arn:aws:secretsmanager:*:*:secret:${var.name_prefix}-db-*"
        ]
      }
    ]
  })
}

# ============================================================================
# CloudWatch Log Groups
# ============================================================================

resource "aws_cloudwatch_log_group" "crawler" {
  name              = "/aws/lambda/${var.name_prefix}-crawler"
  retention_in_days = var.environment == "prod" ? 90 : 14

  tags = var.tags
}

resource "aws_cloudwatch_log_group" "scheduler" {
  name              = "/aws/lambda/${var.name_prefix}-scheduler"
  retention_in_days = var.environment == "prod" ? 90 : 14

  tags = var.tags
}

# ============================================================================
# Lambda Functions
# ============================================================================

# Placeholder Lambda code (actual deployment via CI/CD)
data "archive_file" "crawler_placeholder" {
  type        = "zip"
  output_path = "${path.module}/lambda_placeholder.zip"

  source {
    content  = <<-EOF
      # Placeholder - actual code deployed via CI/CD
      def handler(event, context):
          return {"statusCode": 200, "body": "DNS-AID Crawler"}
    EOF
    filename = "handler.py"
  }
}

# Crawler Lambda - processes crawl jobs from SQS
resource "aws_lambda_function" "crawler" {
  function_name = "${var.name_prefix}-crawler"
  description   = "DNS-AID Crawler - processes domain crawl jobs"
  role          = aws_iam_role.crawler_lambda.arn
  handler       = "dns_aid.crawlers.lambda_handler.handler"
  runtime       = "python3.12"
  architectures = ["arm64"]
  timeout       = var.crawler_timeout
  memory_size   = var.crawler_memory_size

  # Placeholder - CI/CD updates actual code
  filename         = data.archive_file.crawler_placeholder.output_path
  source_code_hash = data.archive_file.crawler_placeholder.output_base64sha256

  # VPC configuration (same as API)
  vpc_config {
    subnet_ids         = var.private_subnet_ids
    security_group_ids = [var.lambda_security_group_id]
  }

  # Environment variables
  environment {
    variables = {
      ENVIRONMENT                  = var.environment
      DB_HOST                      = var.db_host
      DB_PORT                      = tostring(var.db_port)
      DB_NAME                      = var.db_name
      DB_USER                      = var.db_username
      DB_USE_IAM_AUTH              = "true"
      AWS_REGION_NAME              = data.aws_region.current.name
      LOG_LEVEL                    = var.environment == "prod" ? "INFO" : "DEBUG"
      POWERTOOLS_SERVICE_NAME      = "dns-aid-crawler"
      POWERTOOLS_METRICS_NAMESPACE = "DNS-AID"
      CRAWL_QUEUE_URL              = aws_sqs_queue.crawl_jobs.url
      RECRAWL_QUEUE_URL            = aws_sqs_queue.recrawl_jobs.url
      # Crawler feature flags
      ENABLE_PDNS_CRAWLER          = tostring(var.enable_pdns_crawler)
      ENABLE_NSEC_WALKER           = tostring(var.enable_nsec_walker)
      ENABLE_CT_MONITOR            = tostring(var.enable_ct_monitor)
    }
  }

  reserved_concurrent_executions = var.crawler_max_concurrency

  depends_on = [
    aws_cloudwatch_log_group.crawler,
    aws_iam_role_policy_attachment.crawler_lambda_basic,
    aws_iam_role_policy_attachment.crawler_lambda_vpc,
  ]

  tags = var.tags
}

# Scheduler Lambda - triggers re-crawls on schedule
resource "aws_lambda_function" "scheduler" {
  function_name = "${var.name_prefix}-scheduler"
  description   = "DNS-AID Scheduler - queues domains for re-crawl"
  role          = aws_iam_role.crawler_lambda.arn
  handler       = "dns_aid.crawlers.scheduler_handler.handler"
  runtime       = "python3.12"
  architectures = ["arm64"]
  timeout       = 60
  memory_size   = 256

  filename         = data.archive_file.crawler_placeholder.output_path
  source_code_hash = data.archive_file.crawler_placeholder.output_base64sha256

  vpc_config {
    subnet_ids         = var.private_subnet_ids
    security_group_ids = [var.lambda_security_group_id]
  }

  environment {
    variables = {
      ENVIRONMENT             = var.environment
      DB_HOST                 = var.db_host
      DB_PORT                 = tostring(var.db_port)
      DB_NAME                 = var.db_name
      DB_USER                 = var.db_username
      DB_USE_IAM_AUTH         = "true"
      AWS_REGION_NAME         = data.aws_region.current.name
      LOG_LEVEL               = var.environment == "prod" ? "INFO" : "DEBUG"
      POWERTOOLS_SERVICE_NAME = "dns-aid-scheduler"
      RECRAWL_QUEUE_URL       = aws_sqs_queue.recrawl_jobs.url
      RECRAWL_INTERVAL_HOURS  = tostring(var.recrawl_interval_hours)
    }
  }

  depends_on = [
    aws_cloudwatch_log_group.scheduler,
    aws_iam_role_policy_attachment.crawler_lambda_basic,
    aws_iam_role_policy_attachment.crawler_lambda_vpc,
  ]

  tags = var.tags
}

# ============================================================================
# SQS -> Lambda Event Source Mappings
# ============================================================================

# Crawl jobs queue -> Crawler Lambda
resource "aws_lambda_event_source_mapping" "crawl_jobs" {
  event_source_arn                   = aws_sqs_queue.crawl_jobs.arn
  function_name                      = aws_lambda_function.crawler.arn
  batch_size                         = var.crawler_batch_size
  maximum_batching_window_in_seconds = 5
  enabled                            = true

  scaling_config {
    maximum_concurrency = var.crawler_max_concurrency
  }
}

# Re-crawl jobs queue -> Crawler Lambda
resource "aws_lambda_event_source_mapping" "recrawl_jobs" {
  event_source_arn                   = aws_sqs_queue.recrawl_jobs.arn
  function_name                      = aws_lambda_function.crawler.arn
  batch_size                         = var.crawler_batch_size
  maximum_batching_window_in_seconds = 30  # Batch up more for re-crawls
  enabled                            = true

  scaling_config {
    maximum_concurrency = floor(var.crawler_max_concurrency / 2)  # Lower priority
  }
}

# ============================================================================
# EventBridge Rules (Scheduled Re-crawls)
# ============================================================================

# Scheduled re-crawl trigger (every 6 hours by default)
resource "aws_cloudwatch_event_rule" "recrawl_schedule" {
  name                = "${var.name_prefix}-recrawl-schedule"
  description         = "Trigger DNS-AID domain re-crawl"
  schedule_expression = "rate(${var.recrawl_interval_hours} hours)"
  state               = var.enable_scheduled_recrawl ? "ENABLED" : "DISABLED"

  tags = var.tags
}

resource "aws_cloudwatch_event_target" "recrawl_scheduler" {
  rule      = aws_cloudwatch_event_rule.recrawl_schedule.name
  target_id = "dns-aid-scheduler"
  arn       = aws_lambda_function.scheduler.arn

  input = jsonencode({
    action = "schedule_recrawls"
    source = "eventbridge"
  })
}

resource "aws_lambda_permission" "eventbridge_scheduler" {
  statement_id  = "AllowEventBridgeInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.scheduler.function_name
  principal     = "events.amazonaws.com"
  source_arn    = aws_cloudwatch_event_rule.recrawl_schedule.arn
}

# ============================================================================
# CloudWatch Alarms (Production only)
# ============================================================================

resource "aws_cloudwatch_metric_alarm" "crawler_errors" {
  count = var.environment == "prod" ? 1 : 0

  alarm_name          = "${var.name_prefix}-crawler-errors"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "Errors"
  namespace           = "AWS/Lambda"
  period              = 300
  statistic           = "Sum"
  threshold           = 10
  alarm_description   = "Crawler Lambda errors exceed threshold"

  dimensions = {
    FunctionName = aws_lambda_function.crawler.function_name
  }

  tags = var.tags
}

resource "aws_cloudwatch_metric_alarm" "dlq_messages" {
  count = var.environment == "prod" ? 1 : 0

  alarm_name          = "${var.name_prefix}-crawler-dlq-messages"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 1
  metric_name         = "ApproximateNumberOfMessagesVisible"
  namespace           = "AWS/SQS"
  period              = 300
  statistic           = "Sum"
  threshold           = 100
  alarm_description   = "Crawler DLQ has too many failed messages"

  dimensions = {
    QueueName = aws_sqs_queue.crawler_dlq.name
  }

  tags = var.tags
}
