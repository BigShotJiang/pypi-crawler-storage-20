# DNS-AID Crawler Module Variables

# ============================================================================
# Required Variables
# ============================================================================

variable "name_prefix" {
  description = "Prefix for resource names (e.g., dns-aid-dev)"
  type        = string
}

variable "environment" {
  description = "Environment name (dev, staging, prod)"
  type        = string
}

variable "vpc_id" {
  description = "VPC ID for Lambda deployment"
  type        = string
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for Lambda"
  type        = list(string)
}

variable "lambda_security_group_id" {
  description = "Security group ID for Lambda (shared with API)"
  type        = string
}

# ============================================================================
# Database Configuration
# ============================================================================

variable "db_host" {
  description = "Database host endpoint"
  type        = string
}

variable "db_port" {
  description = "Database port"
  type        = number
  default     = 5432
}

variable "db_name" {
  description = "Database name"
  type        = string
}

variable "db_username" {
  description = "Database username (IAM auth)"
  type        = string
}

variable "db_cluster_resource_id" {
  description = "RDS cluster resource ID for IAM auth"
  type        = string
}

# ============================================================================
# Crawler Lambda Configuration
# ============================================================================

variable "crawler_memory_size" {
  description = "Crawler Lambda memory size in MB"
  type        = number
  default     = 512

  validation {
    condition     = var.crawler_memory_size >= 128 && var.crawler_memory_size <= 10240
    error_message = "crawler_memory_size must be between 128 and 10240 MB"
  }
}

variable "crawler_timeout" {
  description = "Crawler Lambda timeout in seconds"
  type        = number
  default     = 120

  validation {
    condition     = var.crawler_timeout >= 1 && var.crawler_timeout <= 900
    error_message = "crawler_timeout must be between 1 and 900 seconds"
  }
}

variable "crawler_max_concurrency" {
  description = "Maximum concurrent crawler Lambda invocations"
  type        = number
  default     = 10
}

variable "crawler_batch_size" {
  description = "Number of SQS messages per Lambda invocation"
  type        = number
  default     = 5
}

# ============================================================================
# Crawler Feature Flags
# ============================================================================

variable "enable_pdns_crawler" {
  description = "Enable passive DNS crawler"
  type        = bool
  default     = true
}

variable "enable_nsec_walker" {
  description = "Enable NSEC zone walking (controversial, disabled by default)"
  type        = bool
  default     = false
}

variable "enable_ct_monitor" {
  description = "Enable Certificate Transparency monitoring"
  type        = bool
  default     = true
}

# ============================================================================
# Scheduling Configuration
# ============================================================================

variable "enable_scheduled_recrawl" {
  description = "Enable scheduled re-crawl via EventBridge"
  type        = bool
  default     = true
}

variable "recrawl_interval_hours" {
  description = "Hours between scheduled re-crawls"
  type        = number
  default     = 6

  validation {
    condition     = var.recrawl_interval_hours >= 1 && var.recrawl_interval_hours <= 168
    error_message = "recrawl_interval_hours must be between 1 and 168 (1 week)"
  }
}

# ============================================================================
# Tags
# ============================================================================

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}
