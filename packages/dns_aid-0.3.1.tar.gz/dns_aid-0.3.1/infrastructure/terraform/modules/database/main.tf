# DNS-AID Database Module
# RDS PostgreSQL Serverless v2 with RDS Proxy
#
# This module creates:
# - RDS Aurora PostgreSQL Serverless v2 cluster
# - Database security group
# - Secrets Manager secret for credentials
# - Optional RDS Proxy for connection pooling

# ============================================================================
# Random Password Generation
# ============================================================================

resource "random_password" "db_password" {
  length           = 32
  special          = true
  override_special = "!#$%&*()-_=+[]{}<>:?"
}

# ============================================================================
# Secrets Manager Secret
# ============================================================================

resource "aws_secretsmanager_secret" "db_credentials" {
  name                    = "${var.name_prefix}-db-credentials"
  description             = "DNS-AID database credentials"
  recovery_window_in_days = var.tags["Environment"] == "prod" ? 30 : 0

  tags = var.tags
}

resource "aws_secretsmanager_secret_version" "db_credentials" {
  secret_id = aws_secretsmanager_secret.db_credentials.id
  secret_string = jsonencode({
    username = var.db_username
    password = random_password.db_password.result
    engine   = "postgres"
    host     = aws_rds_cluster.main.endpoint
    port     = aws_rds_cluster.main.port
    dbname   = var.db_name
  })
}

# ============================================================================
# Security Group
# ============================================================================

resource "aws_security_group" "database" {
  name        = "${var.name_prefix}-database-sg"
  description = "Security group for RDS PostgreSQL"
  vpc_id      = var.vpc_id

  # Allow inbound from Lambda security group
  ingress {
    description     = "PostgreSQL from Lambda"
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [var.lambda_security_group_id]
  }

  # Allow all outbound (for RDS Proxy)
  egress {
    description = "All outbound"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-database-sg"
  })
}

# ============================================================================
# DB Subnet Group
# ============================================================================

resource "aws_db_subnet_group" "main" {
  name        = "${var.name_prefix}-db-subnet-group"
  description = "Database subnet group for DNS-AID"
  subnet_ids  = var.database_subnet_ids

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-db-subnet-group"
  })
}

# ============================================================================
# RDS Aurora PostgreSQL Serverless v2 Cluster
# ============================================================================

resource "aws_rds_cluster" "main" {
  cluster_identifier = "${var.name_prefix}-db-cluster"
  engine             = "aurora-postgresql"
  engine_mode        = "provisioned"
  engine_version     = "15.15"
  database_name      = var.db_name
  master_username    = var.db_username
  master_password    = random_password.db_password.result

  db_subnet_group_name   = aws_db_subnet_group.main.name
  vpc_security_group_ids = [aws_security_group.database.id]

  # Serverless v2 scaling configuration
  serverlessv2_scaling_configuration {
    min_capacity = var.min_capacity
    max_capacity = var.max_capacity
  }

  # Backup configuration
  backup_retention_period      = var.tags["Environment"] == "prod" ? 35 : 7
  preferred_backup_window      = "03:00-04:00"
  preferred_maintenance_window = "mon:04:00-mon:05:00"

  # Security
  storage_encrypted                   = true
  iam_database_authentication_enabled = true

  # Enable Data API for Query Editor access
  enable_http_endpoint = true

  # Don't skip final snapshot in prod
  skip_final_snapshot       = var.tags["Environment"] != "prod"
  final_snapshot_identifier = var.tags["Environment"] == "prod" ? "${var.name_prefix}-final-snapshot" : null

  # Enable deletion protection in prod
  deletion_protection = var.tags["Environment"] == "prod"

  # Enable enhanced monitoring
  enabled_cloudwatch_logs_exports = ["postgresql"]

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-db-cluster"
  })
}

# ============================================================================
# RDS Serverless v2 Instance
# ============================================================================

resource "aws_rds_cluster_instance" "main" {
  count = var.tags["Environment"] == "prod" ? 2 : 1

  identifier           = "${var.name_prefix}-db-instance-${count.index}"
  cluster_identifier   = aws_rds_cluster.main.id
  instance_class       = "db.serverless"
  engine               = aws_rds_cluster.main.engine
  engine_version       = aws_rds_cluster.main.engine_version
  db_subnet_group_name = aws_db_subnet_group.main.name

  # Enable performance insights for debugging
  performance_insights_enabled = var.tags["Environment"] == "prod"

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-db-instance-${count.index}"
  })
}

# ============================================================================
# CloudWatch Alarms (Optional)
# ============================================================================

resource "aws_cloudwatch_metric_alarm" "database_cpu" {
  count = var.tags["Environment"] == "prod" ? 1 : 0

  alarm_name          = "${var.name_prefix}-db-cpu-utilization"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 3
  metric_name         = "CPUUtilization"
  namespace           = "AWS/RDS"
  period              = 300
  statistic           = "Average"
  threshold           = 80
  alarm_description   = "Database CPU utilization is high"

  dimensions = {
    DBClusterIdentifier = aws_rds_cluster.main.id
  }

  tags = var.tags
}
