# DNS-AID Database Module - Outputs

output "db_endpoint" {
  description = "RDS cluster endpoint"
  value       = aws_rds_cluster.main.endpoint
}

output "db_reader_endpoint" {
  description = "RDS cluster reader endpoint"
  value       = aws_rds_cluster.main.reader_endpoint
}

output "db_port" {
  description = "RDS port"
  value       = aws_rds_cluster.main.port
}

output "db_password" {
  description = "Database password (from Secrets Manager)"
  value       = random_password.db_password.result
  sensitive   = true
}

output "db_security_group_id" {
  description = "Database security group ID"
  value       = aws_security_group.database.id
}

output "db_cluster_id" {
  description = "RDS cluster identifier"
  value       = aws_rds_cluster.main.id
}

output "db_secret_arn" {
  description = "Secrets Manager secret ARN"
  value       = aws_secretsmanager_secret.db_credentials.arn
}

output "db_cluster_resource_id" {
  description = "RDS cluster resource ID (for IAM auth)"
  value       = aws_rds_cluster.main.cluster_resource_id
}

output "db_cluster_arn" {
  description = "RDS cluster ARN"
  value       = aws_rds_cluster.main.arn
}
