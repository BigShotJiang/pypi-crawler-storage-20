# DNS-AID Agent Directory - Terraform Outputs
# Phase 1: Foundation & MVP

# ============================================================================
# API Outputs
# ============================================================================

output "api_endpoint" {
  description = "API Gateway endpoint URL"
  value       = module.api.api_endpoint
}

output "api_stage_url" {
  description = "API Gateway stage URL (with /v1 path)"
  value       = "${module.api.api_endpoint}/v1"
}

output "health_check_url" {
  description = "Health check endpoint URL"
  value       = "${module.api.api_endpoint}/v1/health"
}

# ============================================================================
# Database Outputs
# ============================================================================

output "db_endpoint" {
  description = "RDS cluster endpoint"
  value       = module.database.db_endpoint
  sensitive   = true
}

output "db_reader_endpoint" {
  description = "RDS cluster reader endpoint"
  value       = module.database.db_reader_endpoint
  sensitive   = true
}

output "db_port" {
  description = "RDS port"
  value       = module.database.db_port
}

# ============================================================================
# VPC Outputs
# ============================================================================

output "vpc_id" {
  description = "VPC ID"
  value       = module.vpc.vpc_id
}

output "private_subnet_ids" {
  description = "Private subnet IDs (for Lambda)"
  value       = module.vpc.private_subnets
}

output "database_subnet_ids" {
  description = "Database subnet IDs"
  value       = module.vpc.database_subnets
}

# ============================================================================
# Lambda Outputs
# ============================================================================

output "lambda_function_name" {
  description = "Lambda function name"
  value       = module.api.lambda_function_name
}

output "lambda_function_arn" {
  description = "Lambda function ARN"
  value       = module.api.lambda_function_arn
}

output "lambda_log_group" {
  description = "CloudWatch Log Group for Lambda"
  value       = module.api.lambda_log_group
}

# ============================================================================
# Deployment Information
# ============================================================================

output "deployment_info" {
  description = "Deployment summary"
  value = {
    environment = var.environment
    region      = var.aws_region
    api_url     = module.api.api_endpoint
  }
}

# ============================================================================
# Phase 2: Crawler Outputs
# ============================================================================

output "crawl_queue_url" {
  description = "URL of the crawl jobs SQS queue"
  value       = module.crawlers.crawl_queue_url
}

output "recrawl_queue_url" {
  description = "URL of the re-crawl jobs SQS queue"
  value       = module.crawlers.recrawl_queue_url
}

output "crawler_dlq_url" {
  description = "URL of the dead letter queue"
  value       = module.crawlers.dlq_url
}

output "crawler_function_name" {
  description = "Name of the crawler Lambda function"
  value       = module.crawlers.crawler_function_name
}

output "crawler_function_arn" {
  description = "ARN of the crawler Lambda function"
  value       = module.crawlers.crawler_function_arn
}

output "scheduler_function_name" {
  description = "Name of the scheduler Lambda function"
  value       = module.crawlers.scheduler_function_name
}

output "scheduler_function_arn" {
  description = "ARN of the scheduler Lambda function"
  value       = module.crawlers.scheduler_function_arn
}

output "crawler_log_group" {
  description = "CloudWatch Log Group for crawler Lambda"
  value       = module.crawlers.crawler_log_group
}

output "scheduler_log_group" {
  description = "CloudWatch Log Group for scheduler Lambda"
  value       = module.crawlers.scheduler_log_group
}

output "recrawl_schedule_rule" {
  description = "EventBridge rule for scheduled re-crawls"
  value       = module.crawlers.recrawl_schedule_rule
}
