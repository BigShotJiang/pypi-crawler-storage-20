# DNS-AID Agent Directory - Terraform Configuration
# Phase 1: Foundation & MVP + Phase 2: Crawler Infrastructure
#
# This configuration deploys:
# - AWS Lambda for API handlers
# - API Gateway for HTTP routing
# - RDS PostgreSQL Serverless v2 for database
# - VPC with private subnets for security
# - SQS queues for crawler jobs (Phase 2)
# - Lambda functions for crawlers (Phase 2)
# - EventBridge rules for scheduled re-crawls (Phase 2)

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.5"
    }
  }

  # Uncomment for remote state (recommended for production)
  # backend "s3" {
  #   bucket         = "dns-aid-terraform-state"
  #   key            = "dns-aid/terraform.tfstate"
  #   region         = "us-east-1"
  #   dynamodb_table = "dns-aid-terraform-locks"
  #   encrypt        = true
  # }
}

provider "aws" {
  region  = var.aws_region
  profile = var.aws_profile

  default_tags {
    tags = {
      # Standard tags
      Project     = "DNS-AID"
      Environment = var.environment
      ManagedBy   = "Terraform"
      Phase       = "1"

      # Required tags (per InfoSec)
      owner             = var.owner
      description       = var.description
      infosec_certified = var.infosec_certified
    }
  }
}

# Data sources
data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

# Random suffix for unique resource names
resource "random_id" "suffix" {
  byte_length = 4
}

# Local variables
locals {
  name_prefix = "dns-aid-${var.environment}"
  common_tags = {
    # Standard tags
    Project     = "DNS-AID"
    Environment = var.environment
    ManagedBy   = "Terraform"

    # Required tags (per InfoSec)
    owner             = var.owner
    description       = var.description
    infosec_certified = var.infosec_certified
  }
}

# VPC Module (using AWS VPC module)
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"

  name = "${local.name_prefix}-vpc"
  cidr = var.vpc_cidr

  azs              = var.availability_zones
  private_subnets  = var.private_subnet_cidrs
  public_subnets   = var.public_subnet_cidrs
  database_subnets = var.database_subnet_cidrs

  # NAT Gateway for Lambda in private subnets
  enable_nat_gateway     = true
  single_nat_gateway     = var.environment != "prod"
  one_nat_gateway_per_az = var.environment == "prod"

  # DNS support
  enable_dns_hostnames = true
  enable_dns_support   = true

  # VPC Flow Logs (optional, for debugging)
  enable_flow_log                      = var.enable_vpc_flow_logs
  create_flow_log_cloudwatch_iam_role  = var.enable_vpc_flow_logs
  create_flow_log_cloudwatch_log_group = var.enable_vpc_flow_logs

  tags = local.common_tags
}

# Database Module
module "database" {
  source = "./modules/database"

  name_prefix         = local.name_prefix
  vpc_id              = module.vpc.vpc_id
  database_subnet_ids = module.vpc.database_subnets
  private_subnet_ids  = module.vpc.private_subnets

  db_name     = var.db_name
  db_username = var.db_username

  # Serverless v2 scaling configuration
  min_capacity = var.db_min_capacity
  max_capacity = var.db_max_capacity

  # Security
  lambda_security_group_id = module.api.lambda_security_group_id

  tags = local.common_tags
}

# API Module (Lambda + API Gateway)
module "api" {
  source = "./modules/api"

  name_prefix = local.name_prefix
  environment = var.environment

  vpc_id             = module.vpc.vpc_id
  private_subnet_ids = module.vpc.private_subnets

  # Lambda configuration
  lambda_memory_size = var.lambda_memory_size
  lambda_timeout     = var.lambda_timeout

  # Database connection (IAM auth - no password needed)
  db_host                = module.database.db_endpoint
  db_port                = module.database.db_port
  db_name                = var.db_name
  db_username            = var.db_app_username  # App user (IAM auth)
  db_cluster_resource_id = module.database.db_cluster_resource_id
  db_cluster_arn         = module.database.db_cluster_arn

  # API Gateway settings
  api_throttle_rate_limit  = var.api_throttle_rate_limit
  api_throttle_burst_limit = var.api_throttle_burst_limit

  tags = local.common_tags
}

# ============================================================================
# Phase 2: Crawler Infrastructure
# ============================================================================

module "crawlers" {
  source = "./modules/crawlers"

  name_prefix = local.name_prefix
  environment = var.environment

  vpc_id                   = module.vpc.vpc_id
  private_subnet_ids       = module.vpc.private_subnets
  lambda_security_group_id = module.api.lambda_security_group_id

  # Database connection (shared with API)
  db_host                = module.database.db_endpoint
  db_port                = module.database.db_port
  db_name                = var.db_name
  db_username            = var.db_app_username
  db_cluster_resource_id = module.database.db_cluster_resource_id

  # Crawler Lambda configuration
  crawler_memory_size     = var.crawler_memory_size
  crawler_timeout         = var.crawler_timeout
  crawler_max_concurrency = var.crawler_max_concurrency
  crawler_batch_size      = var.crawler_batch_size

  # Feature flags
  enable_pdns_crawler = var.enable_pdns_crawler
  enable_nsec_walker  = var.enable_nsec_walker
  enable_ct_monitor   = var.enable_ct_monitor

  # Scheduling
  enable_scheduled_recrawl = var.enable_scheduled_recrawl
  recrawl_interval_hours   = var.recrawl_interval_hours

  tags = merge(local.common_tags, {
    Phase = "2"
  })
}
