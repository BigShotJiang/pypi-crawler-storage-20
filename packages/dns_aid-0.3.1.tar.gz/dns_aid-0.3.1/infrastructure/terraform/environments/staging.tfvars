# DNS-AID Staging Environment Configuration

environment = "staging"
aws_region  = "eu-west-2"
aws_profile = "okta-sso"

# ============================================================================
# Required Tags (per InfoSec)
# ============================================================================
owner             = "iracic@infoblox.com"
description       = "DNS-AID Agent Directory - Staging Environment"
infosec_certified = "true"

# VPC Configuration
vpc_cidr = "10.1.0.0/16"

# Database Configuration (moderate for staging)
db_min_capacity = 0.5
db_max_capacity = 4

# Lambda Configuration
lambda_memory_size = 1024
lambda_timeout     = 30

# API Gateway Configuration
api_throttle_rate_limit  = 500
api_throttle_burst_limit = 1000

# Enable VPC flow logs for debugging
enable_vpc_flow_logs = true
