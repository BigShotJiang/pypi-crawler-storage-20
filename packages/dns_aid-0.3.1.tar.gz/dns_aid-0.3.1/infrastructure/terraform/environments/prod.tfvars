# DNS-AID Production Environment Configuration

environment = "prod"
aws_region  = "eu-west-2"
aws_profile = "okta-sso"

# ============================================================================
# Required Tags (per InfoSec)
# ============================================================================
owner             = "iracic@infoblox.com"
description       = "DNS-AID Agent Directory - Production Environment"
infosec_certified = "true"

# VPC Configuration
vpc_cidr = "10.2.0.0/16"

# Database Configuration (production-grade)
db_min_capacity = 2
db_max_capacity = 16

# Lambda Configuration (higher resources for prod)
lambda_memory_size = 2048
lambda_timeout     = 30

# API Gateway Configuration (higher limits for prod)
api_throttle_rate_limit  = 1000
api_throttle_burst_limit = 2000

# Enable VPC flow logs for security/debugging
enable_vpc_flow_logs = true
