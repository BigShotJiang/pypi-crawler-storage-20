# DNS-AID Development Environment Configuration

environment = "dev"
aws_region  = "eu-west-2"
aws_profile = "okta-sso"

# ============================================================================
# Required Tags (per InfoSec)
# ============================================================================
owner             = "iracic@infoblox.com"
description       = "DNS-AID Agent Directory - Development Environment"
infosec_certified = "true"

# VPC Configuration
vpc_cidr = "10.0.0.0/16"

# Database Configuration (minimal for dev)
db_min_capacity = 0.5
db_max_capacity = 2

# Lambda Configuration (lower resources for dev)
lambda_memory_size = 512
lambda_timeout     = 30

# API Gateway Configuration
api_throttle_rate_limit  = 100
api_throttle_burst_limit = 200

# Disable VPC flow logs for cost savings
enable_vpc_flow_logs = false

# ============================================================================
# Phase 2: Crawler Configuration
# ============================================================================

# Crawler Lambda Configuration (lower resources for dev)
crawler_memory_size     = 512
crawler_timeout         = 120
crawler_max_concurrency = 5   # Lower for dev
crawler_batch_size      = 3   # Lower for dev

# Crawler Feature Flags
enable_pdns_crawler = true   # Passive DNS discovery
enable_nsec_walker  = false  # Disabled (privacy concerns)
enable_ct_monitor   = true   # Certificate Transparency monitoring

# Crawler Scheduling
enable_scheduled_recrawl = true
recrawl_interval_hours   = 6  # Re-crawl every 6 hours
