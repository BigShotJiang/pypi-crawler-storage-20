#!/bin/bash
# DNS-AID Database Migration Script
# Runs Alembic migrations against the target environment
#
# Usage: ./migrate.sh [environment] [action]
#   environment: dev, staging, prod (default: dev)
#   action: upgrade, downgrade, current, history (default: upgrade)
#
# Examples:
#   ./migrate.sh dev upgrade      # Apply all pending migrations
#   ./migrate.sh dev current      # Show current revision
#   ./migrate.sh prod upgrade     # Migrate production (requires confirmation)

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${SCRIPT_DIR}/../.."
TERRAFORM_DIR="${SCRIPT_DIR}/../terraform"

# Default values
ENVIRONMENT="${1:-dev}"
ACTION="${2:-upgrade}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Get database connection string from Terraform outputs
get_db_connection() {
    cd "$TERRAFORM_DIR"

    local db_host=$(terraform output -raw db_endpoint 2>/dev/null || echo "")
    local db_port=$(terraform output -raw db_port 2>/dev/null || echo "5432")

    if [[ -z "$db_host" ]]; then
        log_error "Could not get database endpoint from Terraform outputs"
        log_error "Make sure the infrastructure is deployed first"
        exit 1
    fi

    # Get credentials from Secrets Manager
    local secret_name="dns-aid-${ENVIRONMENT}-db-credentials"
    local secret_json=$(aws secretsmanager get-secret-value \
        --secret-id "$secret_name" \
        --profile okta-sso \
        --query 'SecretString' \
        --output text 2>/dev/null || echo "")

    if [[ -z "$secret_json" ]]; then
        log_error "Could not retrieve database credentials from Secrets Manager"
        exit 1
    fi

    local db_user=$(echo "$secret_json" | jq -r '.username')
    local db_pass=$(echo "$secret_json" | jq -r '.password')
    local db_name=$(echo "$secret_json" | jq -r '.dbname')

    echo "postgresql+asyncpg://${db_user}:${db_pass}@${db_host}:${db_port}/${db_name}"
}

# Run migration
run_migration() {
    log_info "Getting database connection for $ENVIRONMENT..."
    local db_url=$(get_db_connection)

    cd "$PROJECT_ROOT"

    case "$ACTION" in
        upgrade)
            if [[ "$ENVIRONMENT" == "prod" ]]; then
                log_warn "⚠️  You are about to migrate PRODUCTION database!"
                read -p "Are you sure? (yes/no): " confirm
                if [[ "$confirm" != "yes" ]]; then
                    log_info "Migration cancelled."
                    exit 0
                fi
            fi
            log_info "Running upgrade migrations..."
            DATABASE_URL="$db_url" alembic upgrade head
            ;;
        downgrade)
            if [[ "$ENVIRONMENT" == "prod" ]]; then
                log_error "Cannot downgrade production database via script!"
                exit 1
            fi
            log_warn "⚠️  Downgrading database..."
            read -p "Steps to downgrade (or 'base'): " steps
            DATABASE_URL="$db_url" alembic downgrade "$steps"
            ;;
        current)
            log_info "Current database revision:"
            DATABASE_URL="$db_url" alembic current
            ;;
        history)
            log_info "Migration history:"
            DATABASE_URL="$db_url" alembic history
            ;;
        *)
            log_error "Invalid action: $ACTION"
            echo "Valid actions: upgrade, downgrade, current, history"
            exit 1
            ;;
    esac
}

# Main
main() {
    echo "========================================"
    echo "DNS-AID Database Migration"
    echo "========================================"
    echo "Environment: $ENVIRONMENT"
    echo "Action: $ACTION"
    echo "========================================"

    # Validate environment
    if [[ ! "$ENVIRONMENT" =~ ^(dev|staging|prod)$ ]]; then
        log_error "Invalid environment: $ENVIRONMENT"
        exit 1
    fi

    run_migration

    log_info "Done!"
}

main
