#!/bin/bash
# DNS-AID Rollback Script
# Rolls back Lambda deployment to previous version
#
# Usage: ./rollback.sh [environment]
#   environment: dev, staging, prod (default: dev)
#
# Examples:
#   ./rollback.sh dev      # Rollback dev Lambda to previous version

set -euo pipefail

# Configuration
ENVIRONMENT="${1:-dev}"
FUNCTION_NAME="dns-aid-${ENVIRONMENT}-api"
AWS_PROFILE="okta-sso"
AWS_REGION="eu-west-2"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Get Lambda versions
get_versions() {
    log_info "Fetching Lambda versions for $FUNCTION_NAME..."

    aws lambda list-versions-by-function \
        --function-name "$FUNCTION_NAME" \
        --profile "$AWS_PROFILE" \
        --region "$AWS_REGION" \
        --query 'Versions[*].{Version:Version,LastModified:LastModified,Description:Description}' \
        --output table
}

# Get current alias
get_current_alias() {
    local alias_info=$(aws lambda get-alias \
        --function-name "$FUNCTION_NAME" \
        --name "live" \
        --profile "$AWS_PROFILE" \
        --region "$AWS_REGION" 2>/dev/null || echo "")

    if [[ -n "$alias_info" ]]; then
        echo "$alias_info" | jq -r '.FunctionVersion'
    else
        echo "\$LATEST"
    fi
}

# Rollback to specific version
rollback_to_version() {
    local target_version="$1"

    if [[ "$ENVIRONMENT" == "prod" ]]; then
        log_warn "⚠️  You are about to rollback PRODUCTION!"
        read -p "Are you sure? (yes/no): " confirm
        if [[ "$confirm" != "yes" ]]; then
            log_info "Rollback cancelled."
            exit 0
        fi
    fi

    log_info "Rolling back to version $target_version..."

    # Update alias to point to previous version
    aws lambda update-alias \
        --function-name "$FUNCTION_NAME" \
        --name "live" \
        --function-version "$target_version" \
        --profile "$AWS_PROFILE" \
        --region "$AWS_REGION"

    log_info "Rollback complete! Now pointing to version $target_version"
}

# Main
main() {
    echo "========================================"
    echo "DNS-AID Rollback Script"
    echo "========================================"
    echo "Environment: $ENVIRONMENT"
    echo "Function: $FUNCTION_NAME"
    echo "========================================"

    # Validate environment
    if [[ ! "$ENVIRONMENT" =~ ^(dev|staging|prod)$ ]]; then
        log_error "Invalid environment: $ENVIRONMENT"
        exit 1
    fi

    # Show current state
    log_info "Current version: $(get_current_alias)"
    echo ""

    # Show available versions
    get_versions
    echo ""

    # Ask for target version
    read -p "Enter version to rollback to (or 'cancel'): " target_version

    if [[ "$target_version" == "cancel" ]]; then
        log_info "Rollback cancelled."
        exit 0
    fi

    rollback_to_version "$target_version"

    log_info "Done!"
}

main
