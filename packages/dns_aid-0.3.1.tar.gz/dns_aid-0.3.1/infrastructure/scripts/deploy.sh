#!/bin/bash
# DNS-AID Deployment Script
# Deploys infrastructure to AWS using Terraform
#
# Usage: ./deploy.sh [environment] [action]
#   environment: dev, staging, prod (default: dev)
#   action: plan, apply, destroy (default: plan)
#
# Examples:
#   ./deploy.sh dev plan      # Preview dev changes
#   ./deploy.sh dev apply     # Deploy to dev
#   ./deploy.sh prod apply    # Deploy to production

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TERRAFORM_DIR="${SCRIPT_DIR}/../terraform"
ENVIRONMENTS_DIR="${TERRAFORM_DIR}/environments"

# Default values
ENVIRONMENT="${1:-dev}"
ACTION="${2:-plan}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Validate environment
validate_environment() {
    if [[ ! "$ENVIRONMENT" =~ ^(dev|staging|prod)$ ]]; then
        log_error "Invalid environment: $ENVIRONMENT"
        echo "Valid environments: dev, staging, prod"
        exit 1
    fi
}

# Validate action
validate_action() {
    if [[ ! "$ACTION" =~ ^(plan|apply|destroy|init|output)$ ]]; then
        log_error "Invalid action: $ACTION"
        echo "Valid actions: plan, apply, destroy, init, output"
        exit 1
    fi
}

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."

    # Check Terraform
    if ! command -v terraform &> /dev/null; then
        log_error "Terraform is not installed"
        exit 1
    fi
    log_info "Terraform version: $(terraform version -json | jq -r '.terraform_version')"

    # Check AWS CLI
    if ! command -v aws &> /dev/null; then
        log_error "AWS CLI is not installed"
        exit 1
    fi

    # Check AWS credentials
    if ! aws sts get-caller-identity --profile okta-sso &> /dev/null; then
        log_warn "AWS credentials may not be configured. Run: aws sso login --profile okta-sso"
    else
        log_info "AWS identity: $(aws sts get-caller-identity --profile okta-sso --query 'Arn' --output text)"
    fi
}

# Initialize Terraform
terraform_init() {
    log_info "Initializing Terraform..."
    cd "$TERRAFORM_DIR"
    terraform init -upgrade
}

# Run Terraform
run_terraform() {
    local tfvars_file="${ENVIRONMENTS_DIR}/${ENVIRONMENT}.tfvars"

    if [[ ! -f "$tfvars_file" ]]; then
        log_error "Environment file not found: $tfvars_file"
        exit 1
    fi

    cd "$TERRAFORM_DIR"

    case "$ACTION" in
        init)
            terraform_init
            ;;
        plan)
            log_info "Planning changes for $ENVIRONMENT environment..."
            terraform plan -var-file="$tfvars_file" -out="${ENVIRONMENT}.tfplan"
            ;;
        apply)
            if [[ "$ENVIRONMENT" == "prod" ]]; then
                log_warn "⚠️  You are about to deploy to PRODUCTION!"
                read -p "Are you sure? (yes/no): " confirm
                if [[ "$confirm" != "yes" ]]; then
                    log_info "Deployment cancelled."
                    exit 0
                fi
            fi

            log_info "Applying changes to $ENVIRONMENT environment..."
            if [[ -f "${ENVIRONMENT}.tfplan" ]]; then
                terraform apply "${ENVIRONMENT}.tfplan"
            else
                terraform apply -var-file="$tfvars_file" -auto-approve
            fi
            ;;
        destroy)
            if [[ "$ENVIRONMENT" == "prod" ]]; then
                log_error "Cannot destroy production environment via script!"
                log_error "Manual intervention required for safety."
                exit 1
            fi

            log_warn "⚠️  You are about to DESTROY the $ENVIRONMENT environment!"
            read -p "Type the environment name to confirm: " confirm
            if [[ "$confirm" != "$ENVIRONMENT" ]]; then
                log_info "Destruction cancelled."
                exit 0
            fi

            log_info "Destroying $ENVIRONMENT environment..."
            terraform destroy -var-file="$tfvars_file" -auto-approve
            ;;
        output)
            log_info "Terraform outputs for $ENVIRONMENT:"
            terraform output
            ;;
    esac
}

# Main
main() {
    echo "========================================"
    echo "DNS-AID Deployment Script"
    echo "========================================"
    echo "Environment: $ENVIRONMENT"
    echo "Action: $ACTION"
    echo "========================================"

    validate_environment
    validate_action
    check_prerequisites

    # Always init first if not already
    if [[ ! -d "${TERRAFORM_DIR}/.terraform" ]]; then
        terraform_init
    fi

    run_terraform

    log_info "Done!"
}

main
