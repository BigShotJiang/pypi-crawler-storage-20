#!/bin/bash
# Deploy temporary Lambda to create IAM database user
# This Lambda runs inside the VPC where it can reach the database

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
TERRAFORM_DIR="$PROJECT_ROOT/infrastructure/terraform"

# Configuration
AWS_PROFILE="${AWS_PROFILE:-okta-sso}"
AWS_REGION="${AWS_REGION:-eu-west-2}"
FUNCTION_NAME="dns-aid-dev-db-setup"

echo "=== DNS-AID Database Setup Lambda Deployment ==="
echo "Profile: $AWS_PROFILE"
echo "Region: $AWS_REGION"

# Get Terraform outputs
cd "$TERRAFORM_DIR"
echo "Getting infrastructure details from Terraform..."

# Get VPC and subnet info
PRIVATE_SUBNET_IDS=$(terraform output -json private_subnet_ids | jq -r 'join(",")')
VPC_ID=$(terraform output -raw vpc_id)
DB_SECRET_ARN=$(terraform output -json db_secret_arn 2>/dev/null | tr -d '"' || echo "")

# Get the Lambda security group (reuse existing one)
LAMBDA_SG=$(aws ec2 describe-security-groups \
    --profile "$AWS_PROFILE" \
    --region "$AWS_REGION" \
    --filters "Name=group-name,Values=dns-aid-dev-lambda-sg" \
    --query "SecurityGroups[0].GroupId" \
    --output text)

# Get Lambda role ARN
LAMBDA_ROLE_ARN=$(aws iam get-role \
    --profile "$AWS_PROFILE" \
    --role-name dns-aid-dev-lambda-role \
    --query "Role.Arn" \
    --output text)

echo "VPC ID: $VPC_ID"
echo "Private Subnets: $PRIVATE_SUBNET_IDS"
echo "Lambda Security Group: $LAMBDA_SG"
echo "Lambda Role ARN: $LAMBDA_ROLE_ARN"

# Get the secret ARN for the db credentials
if [ -z "$DB_SECRET_ARN" ]; then
    DB_SECRET_ARN=$(aws secretsmanager list-secrets \
        --profile "$AWS_PROFILE" \
        --region "$AWS_REGION" \
        --filter Key=name,Values=dns-aid-dev-db-credentials \
        --query "SecretList[0].ARN" \
        --output text)
fi

echo "DB Secret ARN: $DB_SECRET_ARN"

# Create deployment package
echo ""
echo "Creating deployment package..."
TEMP_DIR=$(mktemp -d)
cd "$TEMP_DIR"

# Create the Lambda handler with pg8000 (pure Python driver)
cat > handler.py << 'HANDLER_EOF'
"""
Lambda function to create IAM database user.
Deploy this temporarily, invoke it once, then delete it.
"""

import json
import os
import boto3


def handler(event, context):
    """Create the IAM-enabled database user."""

    # Get database credentials from Secrets Manager
    secret_arn = os.environ["DB_SECRET_ARN"]
    region = os.environ.get("AWS_REGION", "eu-west-2")

    secrets_client = boto3.client("secretsmanager", region_name=region)
    secret_response = secrets_client.get_secret_value(SecretId=secret_arn)
    creds = json.loads(secret_response["SecretString"])

    # Import pg8000 (pure Python PostgreSQL driver)
    import pg8000.native

    host = creds["host"]
    port = int(creds["port"])
    database = creds["dbname"]
    master_user = creds["username"]
    master_password = creds["password"]
    iam_username = os.environ.get("IAM_USERNAME", "dns_aid_app")

    print(f"Connecting to {host}:{port}/{database} as {master_user}...")

    conn = pg8000.native.Connection(
        host=host,
        port=port,
        database=database,
        user=master_user,
        password=master_password,
        ssl_context=True
    )

    print(f"Connected! Creating IAM user: {iam_username}")

    # Check if user exists
    result = conn.run(
        "SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = :username",
        username=iam_username
    )

    if not result:
        print(f"Creating user {iam_username}...")
        conn.run(f"CREATE USER {iam_username}")
        print(f"User {iam_username} created")
    else:
        print(f"User {iam_username} already exists")

    # Grant rds_iam role (required for IAM authentication)
    print("Granting rds_iam role...")
    conn.run(f"GRANT rds_iam TO {iam_username}")

    # Grant database permissions
    print("Granting database permissions...")
    conn.run(f"GRANT CONNECT ON DATABASE {database} TO {iam_username}")
    conn.run(f"GRANT USAGE ON SCHEMA public TO {iam_username}")
    conn.run(f"GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO {iam_username}")
    conn.run(f"GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO {iam_username}")

    # Set default privileges for future tables
    print("Setting default privileges...")
    conn.run(f"ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO {iam_username}")
    conn.run(f"ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO {iam_username}")

    # Create the DNS-AID tables if they don't exist
    print("Creating DNS-AID tables...")

    conn.run("""
        CREATE TABLE IF NOT EXISTS domains (
            domain VARCHAR(255) PRIMARY KEY,
            verified BOOLEAN DEFAULT FALSE,
            verification_token VARCHAR(64),
            submitted_at TIMESTAMP DEFAULT NOW(),
            verified_at TIMESTAMP,
            last_crawled TIMESTAMP,
            crawl_status VARCHAR(20) DEFAULT 'pending',
            agent_count INTEGER DEFAULT 0,
            metadata JSONB
        )
    """)

    conn.run("""
        CREATE TABLE IF NOT EXISTS agents (
            fqdn VARCHAR(512) PRIMARY KEY,
            domain VARCHAR(255) REFERENCES domains(domain) ON DELETE CASCADE,
            name VARCHAR(63) NOT NULL,
            protocol VARCHAR(20) NOT NULL,
            endpoint_url VARCHAR(512),
            port INTEGER DEFAULT 443,
            capabilities TEXT[],
            version VARCHAR(32),
            security_score INTEGER DEFAULT 0,
            trust_score INTEGER DEFAULT 0,
            popularity_score INTEGER DEFAULT 0,
            threat_flags JSONB DEFAULT '{}',
            first_seen TIMESTAMP DEFAULT NOW(),
            last_seen TIMESTAMP DEFAULT NOW(),
            last_verified TIMESTAMP,
            metadata JSONB
        )
    """)

    conn.run("""
        CREATE TABLE IF NOT EXISTS crawl_history (
            id SERIAL PRIMARY KEY,
            domain VARCHAR(255) REFERENCES domains(domain) ON DELETE CASCADE,
            started_at TIMESTAMP DEFAULT NOW(),
            completed_at TIMESTAMP,
            status VARCHAR(20),
            agents_found INTEGER DEFAULT 0,
            agents_added INTEGER DEFAULT 0,
            agents_updated INTEGER DEFAULT 0,
            error_message TEXT
        )
    """)

    # Create indexes
    print("Creating indexes...")
    conn.run("CREATE INDEX IF NOT EXISTS idx_agents_domain ON agents(domain)")
    conn.run("CREATE INDEX IF NOT EXISTS idx_agents_protocol ON agents(protocol)")
    conn.run("CREATE INDEX IF NOT EXISTS idx_agents_security ON agents(security_score DESC)")

    # Add search_vector column if it doesn't exist (for full-text search)
    # Using trigger-based approach since to_tsvector() is not immutable (can't use GENERATED columns)
    print("Adding full-text search support...")

    # Step 1: Add the search_vector column as a regular TSVECTOR column
    conn.run("""
        DO $$
        BEGIN
            IF NOT EXISTS (
                SELECT 1 FROM information_schema.columns
                WHERE table_name = 'agents' AND column_name = 'search_vector'
            ) THEN
                ALTER TABLE agents ADD COLUMN search_vector TSVECTOR;
            END IF;
        END $$
    """)

    # Step 2: Create the trigger function to update search_vector
    print("Creating search vector trigger function...")
    conn.run("""
        CREATE OR REPLACE FUNCTION agents_search_vector_update() RETURNS trigger AS $$
        BEGIN
            NEW.search_vector :=
                setweight(to_tsvector('english', coalesce(NEW.name, '')), 'A') ||
                setweight(to_tsvector('english', coalesce(array_to_string(NEW.capabilities, ' '), '')), 'B');
            RETURN NEW;
        END
        $$ LANGUAGE plpgsql
    """)

    # Step 3: Create the trigger (drop first to ensure idempotency)
    print("Creating search vector trigger...")
    conn.run("DROP TRIGGER IF EXISTS agents_search_vector_trigger ON agents")
    conn.run("""
        CREATE TRIGGER agents_search_vector_trigger
        BEFORE INSERT OR UPDATE ON agents
        FOR EACH ROW EXECUTE FUNCTION agents_search_vector_update()
    """)

    # Step 4: Update existing rows (if any)
    print("Updating search vectors for existing rows...")
    conn.run("""
        UPDATE agents SET search_vector =
            setweight(to_tsvector('english', coalesce(name, '')), 'A') ||
            setweight(to_tsvector('english', coalesce(array_to_string(capabilities, ' '), '')), 'B')
        WHERE search_vector IS NULL
    """)

    # Step 5: Create the GIN index for fast full-text search
    conn.run("CREATE INDEX IF NOT EXISTS idx_agents_search ON agents USING GIN(search_vector)")

    # Re-grant permissions on newly created tables
    conn.run(f"GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO {iam_username}")
    conn.run(f"GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO {iam_username}")

    conn.close()

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": f"IAM user '{iam_username}' created and tables initialized",
            "database": database,
            "host": host
        })
    }
HANDLER_EOF

# Install pg8000 into the package
echo "Installing pg8000 dependency..."
python3 -m pip install pg8000 -t . --quiet --platform manylinux2014_aarch64 --only-binary=:all: 2>/dev/null || \
python3 -m pip install pg8000 -t . --quiet

# Create zip
echo "Creating zip file..."
zip -r deployment.zip . -q

cd "$SCRIPT_DIR"

# Check if function exists and delete it
echo ""
echo "Checking for existing setup function..."
if aws lambda get-function --function-name "$FUNCTION_NAME" --profile "$AWS_PROFILE" --region "$AWS_REGION" 2>/dev/null; then
    echo "Deleting existing function..."
    aws lambda delete-function --function-name "$FUNCTION_NAME" --profile "$AWS_PROFILE" --region "$AWS_REGION"
    sleep 2
fi

# Create the Lambda function
echo ""
echo "Creating Lambda function..."
aws lambda create-function \
    --function-name "$FUNCTION_NAME" \
    --runtime python3.12 \
    --architectures arm64 \
    --handler handler.handler \
    --role "$LAMBDA_ROLE_ARN" \
    --zip-file "fileb://$TEMP_DIR/deployment.zip" \
    --timeout 60 \
    --memory-size 256 \
    --vpc-config "SubnetIds=$PRIVATE_SUBNET_IDS,SecurityGroupIds=$LAMBDA_SG" \
    --environment "Variables={DB_SECRET_ARN=$DB_SECRET_ARN,IAM_USERNAME=dns_aid_app}" \
    --profile "$AWS_PROFILE" \
    --region "$AWS_REGION" \
    --no-cli-pager

# Wait for function to be active
echo ""
echo "Waiting for function to be active..."
aws lambda wait function-active --function-name "$FUNCTION_NAME" --profile "$AWS_PROFILE" --region "$AWS_REGION"

# Invoke the function
echo ""
echo "Invoking Lambda function to create IAM user..."
RESPONSE_FILE="$TEMP_DIR/response.json"
aws lambda invoke \
    --function-name "$FUNCTION_NAME" \
    --profile "$AWS_PROFILE" \
    --region "$AWS_REGION" \
    --log-type Tail \
    "$RESPONSE_FILE" \
    --no-cli-pager

echo ""
echo "Response:"
cat "$RESPONSE_FILE"
echo ""

# Check if it was successful
STATUS_CODE=$(cat "$RESPONSE_FILE" | jq -r '.statusCode // empty')
if [ "$STATUS_CODE" = "200" ]; then
    echo ""
    echo "✅ IAM user created successfully!"
else
    echo ""
    echo "⚠️  Check response for details. Function logs:"
    aws logs tail "/aws/lambda/$FUNCTION_NAME" --profile "$AWS_PROFILE" --region "$AWS_REGION" --since 5m 2>/dev/null || echo "No logs available yet"
fi

# Clean up - delete the Lambda function
echo ""
echo "Cleaning up - deleting temporary Lambda function..."
aws lambda delete-function --function-name "$FUNCTION_NAME" --profile "$AWS_PROFILE" --region "$AWS_REGION"

# Clean up temp directory
rm -rf "$TEMP_DIR"

echo ""
echo "=== Setup Complete ==="
echo "The dns_aid_app user is now ready for IAM authentication."
echo "Lambda can connect to the database using RDS IAM auth tokens."
