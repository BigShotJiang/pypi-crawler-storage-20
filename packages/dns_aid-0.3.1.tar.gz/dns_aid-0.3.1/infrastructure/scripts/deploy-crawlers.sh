#!/bin/bash
# DNS-AID Crawler Lambda Deployment Script
# Packages and deploys the crawler Lambda functions to AWS
#
# Usage: ./deploy-crawlers.sh [environment] [aws-profile]
#   environment: dev (default), staging, prod
#   aws-profile: okta-sso (default)

set -e

# Configuration
ENVIRONMENT="${1:-dev}"
AWS_PROFILE="${2:-okta-sso}"
AWS_REGION="eu-west-2"
PROJECT_ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
BUILD_DIR="${PROJECT_ROOT}/infrastructure/lambda-build"
CRAWLER_FUNCTION="dns-aid-${ENVIRONMENT}-crawler"
SCHEDULER_FUNCTION="dns-aid-${ENVIRONMENT}-scheduler"

echo "=============================================="
echo "DNS-AID Crawler Lambda Deployment"
echo "=============================================="
echo "Environment: ${ENVIRONMENT}"
echo "AWS Profile: ${AWS_PROFILE}"
echo "AWS Region:  ${AWS_REGION}"
echo "Project:     ${PROJECT_ROOT}"
echo "=============================================="

# Check AWS credentials
echo ""
echo "→ Checking AWS credentials..."
aws sts get-caller-identity --profile "${AWS_PROFILE}" --region "${AWS_REGION}" > /dev/null || {
    echo "ERROR: AWS credentials not valid. Run: aws sso login --profile ${AWS_PROFILE}"
    exit 1
}
echo "✓ AWS credentials valid"

# Clean build directory
echo ""
echo "→ Preparing build directory..."
rm -rf "${BUILD_DIR}"
mkdir -p "${BUILD_DIR}/package"
mkdir -p "${BUILD_DIR}/wheels"

# Install dependencies to package directory
echo ""
echo "→ Installing dependencies..."

# Install pure Python packages FIRST (without pydantic-core)
echo "  Installing pure Python packages..."
pip3 install \
    --target "${BUILD_DIR}/package" \
    --upgrade \
    --quiet \
    dnspython \
    httpx \
    httpcore \
    h11 \
    certifi \
    idna \
    sniffio \
    anyio \
    structlog \
    typing_extensions \
    annotated-types \
    typing_inspection \
    aws-lambda-powertools \
    aws-xray-sdk \
    2>&1 | grep -v "already satisfied" || true

# Install database dependencies for agent storage (pure Python parts)
echo "  Installing database packages..."
pip3 install \
    --target "${BUILD_DIR}/package" \
    --upgrade \
    --quiet \
    --no-deps \
    sqlalchemy \
    2>&1 | grep -v "already satisfied" || true

# Install pydantic WITHOUT its dependencies (we'll add pydantic-core manually)
echo "  Installing pydantic..."
pip3 install \
    --target "${BUILD_DIR}/package" \
    --upgrade \
    --quiet \
    --no-deps \
    pydantic \
    2>&1 || true

# Download and extract pydantic-core wheel for ARM64 Linux
echo "  Downloading pydantic-core for ARM64..."
pip3 download \
    --dest "${BUILD_DIR}/wheels" \
    --platform manylinux_2_17_aarch64 \
    --implementation cp \
    --python-version 3.12 \
    --only-binary=:all: \
    --no-deps \
    pydantic-core \
    2>&1 | tail -2 || true

# Download asyncpg for PostgreSQL async support (has C extensions)
echo "  Downloading asyncpg for ARM64..."
pip3 download \
    --dest "${BUILD_DIR}/wheels" \
    --platform manylinux_2_17_aarch64 \
    --implementation cp \
    --python-version 3.12 \
    --only-binary=:all: \
    --no-deps \
    asyncpg \
    2>&1 | tail -2 || true

# Download greenlet for SQLAlchemy async (has C extensions)
echo "  Downloading greenlet for ARM64..."
pip3 download \
    --dest "${BUILD_DIR}/wheels" \
    --platform manylinux_2_17_aarch64 \
    --implementation cp \
    --python-version 3.12 \
    --only-binary=:all: \
    --no-deps \
    greenlet \
    2>&1 | tail -2 || true

# Extract the wheels (will overwrite any existing versions)
if ls "${BUILD_DIR}/wheels"/*.whl 1> /dev/null 2>&1; then
    echo "  Extracting wheels for ARM64..."
    for wheel in "${BUILD_DIR}/wheels"/*.whl; do
        unzip -q -o "$wheel" -d "${BUILD_DIR}/package" 2>/dev/null || true
    done
    # Remove dist-info directories to save space
    rm -rf "${BUILD_DIR}/package"/*.dist-info 2>/dev/null || true
fi

# boto3 is included in Lambda runtime, no need to package

echo "✓ Dependencies installed"

# Copy source code
echo ""
echo "→ Copying source code..."
cp -r "${PROJECT_ROOT}/src/dns_aid" "${BUILD_DIR}/package/"
echo "✓ Source code copied"

# Remove unnecessary files to reduce package size
echo ""
echo "→ Cleaning up package..."
find "${BUILD_DIR}/package" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "${BUILD_DIR}/package" -type d -name "*.dist-info" -exec rm -rf {} + 2>/dev/null || true
find "${BUILD_DIR}/package" -type d -name "tests" -exec rm -rf {} + 2>/dev/null || true
find "${BUILD_DIR}/package" -type f -name "*.pyc" -delete 2>/dev/null || true
echo "✓ Package cleaned"

# Create ZIP file
echo ""
echo "→ Creating deployment package..."
cd "${BUILD_DIR}/package"
zip -r9 "${BUILD_DIR}/crawler-lambda.zip" . -x "*.pyc" -x "*__pycache__*" > /dev/null
PACKAGE_SIZE=$(du -h "${BUILD_DIR}/crawler-lambda.zip" | cut -f1)
echo "✓ Package created: ${PACKAGE_SIZE}"

# Deploy Crawler Lambda
echo ""
echo "→ Deploying ${CRAWLER_FUNCTION}..."
aws lambda update-function-code \
    --function-name "${CRAWLER_FUNCTION}" \
    --zip-file "fileb://${BUILD_DIR}/crawler-lambda.zip" \
    --profile "${AWS_PROFILE}" \
    --region "${AWS_REGION}" \
    --output text \
    --query 'FunctionName' || {
        echo "ERROR: Failed to deploy ${CRAWLER_FUNCTION}"
        exit 1
    }
echo "✓ Crawler Lambda deployed"

# Wait for update to complete
echo "→ Waiting for crawler update to complete..."
aws lambda wait function-updated \
    --function-name "${CRAWLER_FUNCTION}" \
    --profile "${AWS_PROFILE}" \
    --region "${AWS_REGION}"
echo "✓ Crawler Lambda ready"

# Deploy Scheduler Lambda
echo ""
echo "→ Deploying ${SCHEDULER_FUNCTION}..."
aws lambda update-function-code \
    --function-name "${SCHEDULER_FUNCTION}" \
    --zip-file "fileb://${BUILD_DIR}/crawler-lambda.zip" \
    --profile "${AWS_PROFILE}" \
    --region "${AWS_REGION}" \
    --output text \
    --query 'FunctionName' || {
        echo "ERROR: Failed to deploy ${SCHEDULER_FUNCTION}"
        exit 1
    }
echo "✓ Scheduler Lambda deployed"

# Wait for update to complete
echo "→ Waiting for scheduler update to complete..."
aws lambda wait function-updated \
    --function-name "${SCHEDULER_FUNCTION}" \
    --profile "${AWS_PROFILE}" \
    --region "${AWS_REGION}"
echo "✓ Scheduler Lambda ready"

# Verify deployment
echo ""
echo "=============================================="
echo "Deployment Complete!"
echo "=============================================="
echo ""
echo "Crawler Lambda:"
aws lambda get-function \
    --function-name "${CRAWLER_FUNCTION}" \
    --profile "${AWS_PROFILE}" \
    --region "${AWS_REGION}" \
    --query 'Configuration.{Name:FunctionName,Runtime:Runtime,Handler:Handler,CodeSize:CodeSize,LastModified:LastModified}' \
    --output table

echo ""
echo "Scheduler Lambda:"
aws lambda get-function \
    --function-name "${SCHEDULER_FUNCTION}" \
    --profile "${AWS_PROFILE}" \
    --region "${AWS_REGION}" \
    --query 'Configuration.{Name:FunctionName,Runtime:Runtime,Handler:Handler,CodeSize:CodeSize,LastModified:LastModified}' \
    --output table

echo ""
echo "=============================================="
echo "Test Commands:"
echo "=============================================="
echo ""
echo "# Send a test crawl job:"
echo "aws sqs send-message \\"
echo "  --queue-url https://sqs.${AWS_REGION}.amazonaws.com/\$(aws sts get-caller-identity --profile ${AWS_PROFILE} --query Account --output text)/dns-aid-${ENVIRONMENT}-crawl-jobs \\"
echo "  --message-body '{\"domain\": \"example.com\", \"source\": \"test\"}' \\"
echo "  --profile ${AWS_PROFILE} --region ${AWS_REGION}"
echo ""
echo "# Watch crawler logs:"
echo "aws logs tail /aws/lambda/${CRAWLER_FUNCTION} --follow --profile ${AWS_PROFILE} --region ${AWS_REGION}"
echo ""

# Cleanup
echo "→ Cleaning up build directory..."
rm -rf "${BUILD_DIR}"
echo "✓ Done!"
