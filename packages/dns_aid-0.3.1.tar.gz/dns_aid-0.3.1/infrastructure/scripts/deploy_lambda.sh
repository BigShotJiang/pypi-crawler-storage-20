#!/bin/bash
# DNS-AID Lambda Deployment Script
# Builds and deploys the Lambda function code to AWS
#
# Usage: ./deploy_lambda.sh [environment]
#   environment: dev, staging, prod (default: dev)

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
BUILD_DIR="$PROJECT_ROOT/build/lambda"

# AWS Configuration
AWS_PROFILE="${AWS_PROFILE:-okta-sso}"
AWS_REGION="${AWS_REGION:-eu-west-2}"
ENVIRONMENT="${1:-dev}"
FUNCTION_NAME="dns-aid-${ENVIRONMENT}-api"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Clean up previous build
cleanup() {
    log_info "Cleaning up previous build..."
    rm -rf "$BUILD_DIR"
    mkdir -p "$BUILD_DIR"
}

# Install dependencies
install_dependencies() {
    log_info "Installing dependencies for Lambda (ARM64)..."

    cd "$BUILD_DIR"

    # Create requirements file for Lambda dependencies
    cat > requirements.txt << EOF
# Core
dnspython>=2.6.0
pydantic>=2.5.0
httpx>=0.27.0
structlog>=24.0.0

# FastAPI
fastapi>=0.111.0
starlette>=0.37.0

# Database
sqlalchemy>=2.0.0
asyncpg>=0.29.0
greenlet>=3.0.0

# AWS
boto3>=1.34.0
mangum>=0.17.0

# ASGI
uvicorn>=0.30.0
EOF

    # Install dependencies targeting ARM64 Linux
    # Use --platform to ensure we get ARM64-compatible packages
    python3 -m pip install \
        --target . \
        --platform manylinux2014_aarch64 \
        --implementation cp \
        --python-version 3.12 \
        --only-binary=:all: \
        --upgrade \
        -r requirements.txt 2>/dev/null || \
    python3 -m pip install \
        --target . \
        --upgrade \
        -r requirements.txt

    # Remove unnecessary files to reduce package size
    log_info "Cleaning up unnecessary files..."
    find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
    find . -type d -name "*.dist-info" -exec rm -rf {} + 2>/dev/null || true
    find . -type d -name "*.egg-info" -exec rm -rf {} + 2>/dev/null || true
    find . -type f -name "*.pyc" -delete 2>/dev/null || true
    find . -type f -name "*.pyo" -delete 2>/dev/null || true

    # Remove test files
    rm -rf */tests */test 2>/dev/null || true
}

# Copy source code
copy_source() {
    log_info "Copying source code..."

    # Copy the dns_aid package
    cp -r "$PROJECT_ROOT/src/dns_aid" "$BUILD_DIR/"

    # Remove unnecessary source files
    find "$BUILD_DIR/dns_aid" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
    find "$BUILD_DIR/dns_aid" -type f -name "*.pyc" -delete 2>/dev/null || true
}

# Create deployment package
create_package() {
    log_info "Creating deployment package..."

    cd "$BUILD_DIR"

    # Create ZIP file
    zip -r -q ../lambda_package.zip .

    PACKAGE_SIZE=$(du -h "$BUILD_DIR/../lambda_package.zip" | cut -f1)
    log_info "Package size: $PACKAGE_SIZE"
}

# Deploy to Lambda
deploy_lambda() {
    log_info "Deploying to Lambda function: $FUNCTION_NAME"

    # Check if function exists
    if ! aws lambda get-function \
        --function-name "$FUNCTION_NAME" \
        --profile "$AWS_PROFILE" \
        --region "$AWS_REGION" &>/dev/null; then
        log_error "Lambda function '$FUNCTION_NAME' does not exist!"
        log_error "Please run Terraform first to create the infrastructure."
        exit 1
    fi

    # Update function code
    aws lambda update-function-code \
        --function-name "$FUNCTION_NAME" \
        --zip-file "fileb://$BUILD_DIR/../lambda_package.zip" \
        --profile "$AWS_PROFILE" \
        --region "$AWS_REGION" \
        --no-cli-pager

    log_info "Waiting for function to be updated..."
    aws lambda wait function-updated \
        --function-name "$FUNCTION_NAME" \
        --profile "$AWS_PROFILE" \
        --region "$AWS_REGION"

    log_info "Lambda function updated successfully!"
}

# Verify deployment
verify_deployment() {
    log_info "Verifying deployment..."

    # Get API Gateway URL
    API_URL=$(aws apigatewayv2 get-apis \
        --profile "$AWS_PROFILE" \
        --region "$AWS_REGION" \
        --query "Items[?Name=='dns-aid-${ENVIRONMENT}-api'].ApiEndpoint" \
        --output text)

    if [ -z "$API_URL" ]; then
        log_warn "Could not find API Gateway URL"
    else
        log_info "API URL: $API_URL"

        # Test health endpoint
        log_info "Testing health endpoint..."
        HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$API_URL/health" || echo "000")

        if [ "$HTTP_CODE" = "200" ]; then
            log_info "✅ Health check passed!"
            curl -s "$API_URL/health" | jq . 2>/dev/null || curl -s "$API_URL/health"
        else
            log_warn "Health check returned HTTP $HTTP_CODE"
            log_info "Response:"
            curl -s "$API_URL/health" || true
        fi
    fi
}

# Main
main() {
    echo "========================================"
    echo "DNS-AID Lambda Deployment"
    echo "========================================"
    echo "Environment: $ENVIRONMENT"
    echo "Function: $FUNCTION_NAME"
    echo "Region: $AWS_REGION"
    echo "========================================"

    cleanup
    install_dependencies
    copy_source
    create_package
    deploy_lambda
    verify_deployment

    log_info "Done!"
}

main
