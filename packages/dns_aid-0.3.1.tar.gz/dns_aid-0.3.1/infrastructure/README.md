# DNS-AID Infrastructure

Terraform configuration for deploying DNS-AID Agent Directory to AWS.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    DNS-AID AWS Architecture                  │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│   Internet                                                   │
│       │                                                      │
│       ▼                                                      │
│   ┌─────────────────────────────────────┐                   │
│   │     API Gateway HTTP API            │                   │
│   │     (Rate limiting, CORS)           │                   │
│   └─────────────────────────────────────┘                   │
│       │                                                      │
│       ▼                                                      │
│   ┌─────────────────────────────────────┐                   │
│   │     Lambda (FastAPI + Mangum)       │                   │
│   │     • ARM64 architecture            │                   │
│   │     • Python 3.12                   │                   │
│   │     • VPC-connected                 │                   │
│   └─────────────────────────────────────┘                   │
│       │                                                      │
│       ▼                                                      │
│   ┌─────────────────────────────────────┐                   │
│   │     RDS Aurora PostgreSQL           │                   │
│   │     Serverless v2                   │                   │
│   │     • Auto-scaling (0.5-16 ACU)     │                   │
│   │     • Multi-AZ in production        │                   │
│   └─────────────────────────────────────┘                   │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## Prerequisites

1. **Terraform** >= 1.5.0
2. **AWS CLI** v2
3. **AWS SSO Login** configured with `okta-sso` profile

```bash
# Install Terraform (macOS)
brew install terraform

# Configure AWS SSO
aws configure sso --profile okta-sso

# Login to AWS
aws sso login --profile okta-sso
```

## Quick Start

```bash
# Navigate to terraform directory
cd infrastructure/terraform

# Initialize Terraform
terraform init

# Preview changes (dev environment)
terraform plan -var-file=environments/dev.tfvars

# Deploy to dev
terraform apply -var-file=environments/dev.tfvars
```

## Environments

| Environment | Purpose | RDS Capacity | Lambda Memory |
|-------------|---------|--------------|---------------|
| `dev` | Development/testing | 0.5-2 ACU | 512 MB |
| `staging` | Pre-production | 0.5-4 ACU | 1024 MB |
| `prod` | Production | 2-16 ACU | 2048 MB |

## Deployment Scripts

```bash
# Deploy to an environment
./scripts/deploy.sh dev plan     # Preview changes
./scripts/deploy.sh dev apply    # Apply changes
./scripts/deploy.sh staging apply

# Database migrations
./scripts/migrate.sh dev upgrade
./scripts/migrate.sh dev current

# Rollback Lambda (if needed)
./scripts/rollback.sh dev
```

## Resource Tags (InfoSec Required)

All resources are tagged with:

| Tag | Description |
|-----|-------------|
| `owner` | Resource owner email |
| `description` | Resource description |
| `infosec_certified` | InfoSec certification status |
| `Project` | DNS-AID |
| `Environment` | dev/staging/prod |
| `ManagedBy` | Terraform |

## Costs (Estimated)

| Environment | Monthly Cost |
|-------------|--------------|
| Dev | $50-100 |
| Staging | $100-200 |
| Production | $200-500+ |

*Costs vary based on usage. RDS Serverless v2 scales to zero when idle.*

## Security

- All resources in private VPC subnets
- Database credentials in AWS Secrets Manager
- HTTPS/TLS enforced
- API Gateway rate limiting
- CloudWatch logging enabled

## Outputs

After deployment, Terraform outputs:

```bash
terraform output

# Key outputs:
# - api_endpoint: API Gateway URL
# - db_endpoint: RDS cluster endpoint
# - lambda_function_name: Lambda function name
```

## Destroying Resources

```bash
# Dev/Staging only (production requires manual intervention)
./scripts/deploy.sh dev destroy
```

## Troubleshooting

### Lambda Cold Starts
- ARM64 architecture reduces cold starts
- Pre-imported modules in `lambda_handler.py`

### Database Connection Issues
- Verify Lambda security group allows outbound to RDS
- Check RDS security group allows inbound from Lambda SG

### API Gateway 5xx Errors
- Check CloudWatch logs: `/aws/lambda/dns-aid-{env}-api`
- Verify environment variables are set correctly
