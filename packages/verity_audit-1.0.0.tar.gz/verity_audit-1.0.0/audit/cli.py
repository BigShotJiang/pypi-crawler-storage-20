"""Command-line interface for audit tool."""
import sys
from pathlib import Path
import argparse
from rich.console import Console
from rich.table import Table
from rich import box

from audit.config import Config
from audit.metrics import calculate_metrics
from audit.evidence import write_report
from audit.export import export_pdf, export_json
from typing import Optional
import os
import json
import requests


console = Console()


def run_audit(
    config_path: str,
    fail_on_threshold: bool = True,
    output_dir: Optional[str] = None,
    upload: bool = False
) -> bool:
    """
    Run audit and return True if passed, False if failed.
    
    NOTE: Local audits are for developer validation only. They do NOT provide:
    - Audit history or trend analysis
    - Comparison against past runs
    - Regulator-ready summaries
    - Signed evidence for compliance
    - CI/CD enforcement capabilities
    
    For governance enforcement, compliance evidence, and regulatory reporting,
    audits must be uploaded to Verity's platform.
    """
    # Show license notice for local audits (when no API key)
    api_key = os.getenv("VERITY_API_KEY") or os.getenv("GOVAI_API_KEY")
    if not api_key and not upload:
        console.print("\n[yellow]⚠️  LOCAL AUDIT MODE[/yellow]")
        console.print("[dim]Local audits are for developer validation only.[/dim]")
        console.print("[dim]For governance enforcement and compliance evidence, upload to Verity's platform.[/dim]\n")
    
    # Load configuration
    try:
        config = Config(config_path)
    except Exception as e:
        console.print(f"[red]Error loading config: {e}[/red]")
        return False
    
    # Warn if dataset metadata is missing (required for production)
    if not config.dataset_metadata:
        console.print("[yellow]⚠️  Warning: dataset_metadata not provided in config[/yellow]")
        console.print("[yellow]   For production audits, include: description, population, jurisdiction, sample_size[/yellow]")
    
    # Calculate metrics
    try:
        console.print("[cyan]Calculating fairness metrics...[/cyan]")
        metrics, dataset_info = calculate_metrics(
            str(config.dataset),
            str(config.model),
            config.label,
            config.sensitive
        )
        
        # Log dataset info (counts only, no raw data)
        console.print(f"[dim]Dataset: {dataset_info['shape']['rows']} rows × {dataset_info['shape']['columns']} columns[/dim]")
        if dataset_info.get('sensitive_attribute_distributions'):
            console.print("[dim]Sensitive attribute distributions logged[/dim]")
    except Exception as e:
        console.print(f"[red]Error calculating metrics: {e}[/red]")
        import traceback
        console.print(f"[red]{traceback.format_exc()}[/red]")
        return False
    
    # Determine plan from environment variable or API
    plan = os.getenv("VERITY_PLAN", "starter").lower()  # Default to starter for local audits
    
    # Starter plan: Only check these 3 specific thresholds
    STARTER_THRESHOLDS = {
        "demographic_parity_diff": 0.10,
        "equal_opportunity_diff": 0.10,
        "disparate_impact_ratio_min": 0.80
    }
    
    # Filter thresholds based on plan
    if plan == "starter":
        # For starter, only use the 3 basic thresholds
        filtered_thresholds = {}
        for key in STARTER_THRESHOLDS.keys():
            if key in config.thresholds:
                filtered_thresholds[key] = config.thresholds[key]
            else:
                # Use default values if not in config
                filtered_thresholds[key] = STARTER_THRESHOLDS[key]
        # Also check for any threshold keys that match the starter pattern
        for key, value in config.thresholds.items():
            if any(starter_key in key.lower() for starter_key in ["demographic_parity_diff", "equal_opportunity_diff", "disparate_impact_ratio_min"]):
                filtered_thresholds[key] = value
        config.thresholds = filtered_thresholds
        console.print(f"[dim]Starter plan: Checking only basic fairness thresholds[/dim]")
    elif plan in ["pro", "enterprise"]:
        # Pro/Enterprise: Use all thresholds from config
        console.print(f"[dim]{plan.capitalize()} plan: Checking all configured thresholds + governance checks[/dim]")
    
    # Check thresholds
    passed = True
    threshold_checks = {}
    
    for metric_name, value in metrics.items():
        # Try to find threshold by exact name first
        threshold = config.get_threshold(metric_name)
        threshold_key = None
        
        # If not found, try to match by base metric name (without attribute prefix)
        if threshold is None:
            # Try to find matching threshold by checking if threshold key appears in metric name
            # This handles cases where attributes have underscores (e.g., "age_group")
            for base_name in config.thresholds.keys():
                # Check if metric name ends with the threshold key (with or without underscore prefix)
                if metric_name.endswith(base_name) or metric_name.endswith(f"_{base_name}"):
                    threshold = config.get_threshold(base_name)
                    threshold_key = base_name
                    break
                # Check if threshold key starts with a suffix of the metric name
                # e.g., "disparate_impact_ratio_min" matches "gender_disparate_impact_ratio"
                if '_' in metric_name:
                    # Try removing attribute prefix by finding where the threshold might start
                    # Check all possible suffixes
                    for i in range(1, len(metric_name.split('_'))):
                        suffix = '_'.join(metric_name.split('_')[i:])
                        if base_name.startswith(suffix) or suffix in base_name:
                            threshold = config.get_threshold(base_name)
                            threshold_key = base_name
                            break
                    if threshold is not None:
                        break
        
        if threshold is not None:
            # Determine if metric passed based on its type
            # Check threshold key name or metric name for type
            is_ratio = "ratio" in metric_name or (threshold_key and "ratio" in threshold_key)
            is_diff = "diff" in metric_name or (threshold_key and "diff" in threshold_key)
            
            if is_diff:
                # For difference metrics, pass if value <= threshold
                metric_passed = value <= threshold
            elif is_ratio:
                # For ratio metrics, pass if value >= threshold
                metric_passed = value >= threshold
            else:
                # Default: pass if value <= threshold
                metric_passed = value <= threshold
            
            threshold_checks[metric_name] = {
                "value": value,
                "threshold": threshold,
                "passed": metric_passed
            }
            
            if not metric_passed:
                passed = False
    
    # Print summary
    console.print("\n[bold]Audit Summary[/bold]\n")
    
    table = Table(box=box.ROUNDED)
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="magenta")
    table.add_column("Threshold", style="yellow")
    table.add_column("Status", style="bold")
    
    for metric_name, check in threshold_checks.items():
        status = "[green]PASS[/green]" if check["passed"] else "[red]FAIL[/red]"
        table.add_row(
            metric_name,
            f"{check['value']:.4f}",
            f"{check['threshold']:.4f}",
            status
        )
    
    # Add metrics without thresholds
    for metric_name, value in metrics.items():
        if metric_name not in threshold_checks:
            table.add_row(
                metric_name,
                f"{value:.4f}",
                "N/A",
                "[dim]No threshold[/dim]"
            )
    
    console.print(table)
    
    # Overall status
    overall_status = "[green]PASSED[/green]" if passed else "[red]FAILED[/red]"
    console.print(f"\n[bold]Overall Status: {overall_status}[/bold]\n")
    
    # Override evidence_dir if output_dir is specified
    evidence_dir = Path(output_dir) if output_dir else config.evidence_dir
    
    # Get API key for upload
    api_key = os.getenv("VERITY_API_KEY") or os.getenv("GOVAI_API_KEY")
    
    # Check if this is a local audit (no API key = local only)
    is_local_audit = not api_key and not upload
    
    # Check if evidence storage is enabled (from environment or config)
    # Pro/Enterprise plans have evidence storage, but only when uploaded to platform
    has_evidence_storage = (plan in ["pro", "enterprise"] and not is_local_audit) or (os.getenv("GOVAI_EVIDENCE_STORAGE", "false").lower() == "true")
    has_api_access = api_key is not None  # If API key exists, API access is available
    
    # Governance checks and ACM ethics mapping only for Pro/Enterprise AND when uploaded
    # Local audits are intentionally incomplete - no governance checks or ethics mapping
    include_governance = (plan in ["pro", "enterprise"]) and not is_local_audit
    include_ethics = (plan in ["pro", "enterprise"]) and not is_local_audit
    
    # Write report with full metadata (Phase 2: Expanded structure)
    # Only include governance checks and ethics mapping for Pro/Enterprise
    try:
        report_path = write_report(
            evidence_dir,
            metrics,
            config.thresholds,
            passed,
            config_path=config.config_path,
            dataset_path=config.dataset,
            model_path=config.model,
            label_col=config.label,
            sensitive_attrs=config.sensitive,
            dataset_info=dataset_info,
            dataset_metadata={
                "description": config.dataset_description,
                "population": config.dataset_population,
                "jurisdiction": config.dataset_jurisdiction,
                "sample_size": config.dataset_sample_size
            } if config.dataset_metadata else None,
            has_evidence_storage=has_evidence_storage,
            has_api_access=has_api_access,
            include_governance=include_governance,
            include_ethics=include_ethics
        )
        console.print(f"[green]Report written to: {report_path}[/green]")
        
        # Reminder for local audits
        if is_local_audit:
            console.print("\n[yellow]⚠️  LOCAL AUDIT - VALIDATION ONLY[/yellow]")
            console.print("[dim]This local audit is for developer validation and debugging only.[/dim]")
            console.print("[dim]It does NOT provide:[/dim]")
            console.print("[dim]  • Audit history or trend analysis[/dim]")
            console.print("[dim]  • Comparison against past runs[/dim]")
            console.print("[dim]  • Regulator-ready summaries[/dim]")
            console.print("[dim]  • Signed evidence for compliance[/dim]")
            console.print("[dim]  • CI/CD enforcement capabilities[/dim]")
            console.print("[dim][/dim]")
            console.print("[dim]For governance enforcement, compliance evidence, and regulatory reporting,[/dim]")
            console.print("[dim]audits must be uploaded to Verity's platform.[/dim]")
            console.print("[dim]Local runs are advisory. Platform-recorded runs are authoritative.[/dim]\n")
    except Exception as e:
        console.print(f"[red]Error writing report: {e}[/red]")
        return False
    
    # Handle upload if requested or if API key is available
    should_upload = upload or (api_key is not None)
    
    if should_upload:
        api_url = os.getenv("GOVAI_API_URL", "http://localhost:8000")
        
        if not api_key:
            console.print("[yellow]GOVAI_API_KEY not set - skipping upload (offline mode)[/yellow]")
        else:
            try:
                # Read the report we just wrote
                with open(report_path, 'r') as f:
                    report_data = json.load(f)
                
                # Extract commit context from GitHub Actions environment (if available)
                # These are set automatically by GitHub Actions
                commit_sha = os.getenv("GITHUB_SHA")
                branch = os.getenv("GITHUB_REF_NAME")
                repo = os.getenv("GITHUB_REPOSITORY")
                pr_number = os.getenv("GITHUB_PR_NUMBER") or os.getenv("GITHUB_EVENT_PULL_REQUEST_NUMBER")
                github_server = os.getenv("GITHUB_SERVER_URL", "https://github.com")
                run_id = os.getenv("GITHUB_RUN_ID")
                
                # Build workflow run URL if we have the necessary info
                workflow_run_url = None
                if github_server and repo and run_id:
                    workflow_run_url = f"{github_server}/{repo}/actions/runs/{run_id}"
                
                # Add commit context to report metadata if available
                if commit_sha or branch or repo or pr_number or workflow_run_url:
                    if "metadata" not in report_data:
                        report_data["metadata"] = {}
                    if commit_sha:
                        report_data["metadata"]["commit_sha"] = commit_sha
                        report_data["commit_sha"] = commit_sha  # Also at top level for convenience
                    if branch:
                        report_data["metadata"]["branch"] = branch
                        report_data["branch"] = branch
                    if repo:
                        report_data["metadata"]["repo"] = repo
                        report_data["repo"] = repo
                    if pr_number:
                        try:
                            report_data["metadata"]["pr_number"] = int(pr_number)
                            report_data["pr_number"] = int(pr_number)
                        except (ValueError, TypeError):
                            pass
                    if workflow_run_url:
                        report_data["metadata"]["workflow_run_url"] = workflow_run_url
                
                # Upload to API
                headers = {
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json"
                }
                
                response = requests.post(
                    f"{api_url}/v1/audits",
                    json=report_data,
                    headers=headers,
                    timeout=10
                )
                
                if response.status_code == 200:
                    result = response.json()
                    console.print(f"[green]✓ Audit uploaded: {result.get('audit_id')}[/green]")
                    if commit_sha:
                        console.print(f"[dim]Commit: {commit_sha[:8]}[/dim]")
                elif response.status_code == 409:
                    console.print(f"[yellow]Audit already exists (append-only storage)[/yellow]")
                else:
                    console.print(f"[red]Upload failed: {response.status_code} - {response.text}[/red]")
            
            except requests.exceptions.RequestException as e:
                console.print(f"[red]Upload error: {e}[/red]")
                console.print("[yellow]Continuing in offline mode[/yellow]")
    
    # Return pass/fail based on fail_on_threshold flag
    if fail_on_threshold:
        return passed
    else:
        # If not failing on threshold, always return True (but still report the status)
        return True


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="AI Model Audit Tool",
        epilog="""
LICENSE NOTICE:
Local audits are allowed for personal or internal use only.
Redistribution, resale, or hosted use is prohibited.

Local audits are for developer validation only. They do NOT provide:
- Audit history or trend analysis
- Comparison against past runs
- Regulator-ready summaries
- Signed evidence for compliance
- CI/CD enforcement capabilities

For governance enforcement, compliance evidence, and regulatory reporting,
audits must be uploaded to Verity's platform. Local runs are advisory.
Platform-recorded runs are authoritative.

For licensing questions: licensing@verity.com
        """,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Run command
    run_parser = subparsers.add_parser("run", help="Run audit")
    run_parser.add_argument(
        "--config",
        required=True,
        help="Path to configuration YAML file"
    )
    run_parser.add_argument(
        "--fail-on-threshold",
        action="store_true",
        default=True,
        help="Exit with code 1 if any metric fails threshold (default: True)"
    )
    run_parser.add_argument(
        "--no-fail-on-threshold",
        dest="fail_on_threshold",
        action="store_false",
        help="Do not exit with code 1 on threshold failure"
    )
    run_parser.add_argument(
        "--output-dir",
        type=str,
        help="Directory to write audit evidence (overrides config)"
    )
    run_parser.add_argument(
        "--upload",
        action="store_true",
        default=False,
        help="Upload audit results (currently offline mode - no-op)"
    )
    run_parser.add_argument(
        "--no-upload",
        dest="upload",
        action="store_false",
        help="Do not upload audit results (default)"
    )
    run_parser.add_argument(
        "--export",
        choices=["pdf", "json"],
        help="Export report in specified format (validation only for local audits)"
    )
    
    args = parser.parse_args()
    
    if args.command == "run":
        passed = run_audit(
            args.config,
            fail_on_threshold=args.fail_on_threshold,
            output_dir=args.output_dir,
            upload=args.upload
        )
        
        # Handle export if requested
        if args.export:
            # Reload config to get evidence_dir
            config = Config(args.config)
            evidence_dir = Path(args.output_dir) if args.output_dir else config.evidence_dir
            report_path = evidence_dir / "report.json"
            
            if not report_path.exists():
                console.print(f"[red]Report not found: {report_path}[/red]")
                sys.exit(1)
            
            # Load report to get audit_id
            with open(report_path, 'r') as f:
                report = json.load(f)
            
            try:
                # Check if this is a local audit
                is_local = not report.get("evidence_metadata", {}).get("retention_status") == "active"
                
                if args.export == "pdf":
                    export_path = evidence_dir / f"audit_report_{report.get('audit_id', 'unknown')[:8]}.pdf"
                    export_pdf(report_path, export_path, config.config_path)
                    console.print(f"[green]PDF export written to: {export_path}[/green]")
                    if is_local:
                        console.print("[yellow]⚠️  This is a local validation export. It does not provide signed evidence or regulator-ready summaries.[/yellow]")
                elif args.export == "json":
                    export_path = evidence_dir / f"audit_report_{report.get('audit_id', 'unknown')[:8]}.json"
                    export_json(report_path, export_path, config.config_path)
                    console.print(f"[green]JSON export written to: {export_path}[/green]")
                    if is_local:
                        console.print("[yellow]⚠️  This is a local validation export. It does not provide signed evidence or regulator-ready summaries.[/yellow]")
            except Exception as e:
                console.print(f"[red]Export error: {e}[/red]")
                import traceback
                console.print(f"[red]{traceback.format_exc()}[/red]")
                sys.exit(1)
        
        # Ensure exit codes: 0 = pass, 1 = fail
        sys.exit(0 if passed else 1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()

