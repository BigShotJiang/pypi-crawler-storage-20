"""Configuration loading and validation."""
from pathlib import Path
from typing import Any, Dict, List
import yaml


class Config:
    """Audit configuration."""
    
    def __init__(self, config_path: str):
        """Load configuration from YAML file."""
        self.config_path = Path(config_path)
        if not self.config_path.exists():
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        with open(self.config_path, 'r') as f:
            self.data = yaml.safe_load(f)
        
        # Resolve paths relative to current working directory (where command is run from)
        dataset_path = Path(self.data['dataset'])
        model_path = Path(self.data['model'])
        
        # Resolve relative to current working directory
        if dataset_path.is_absolute():
            self.dataset = dataset_path
        else:
            self.dataset = Path.cwd() / dataset_path
        
        if model_path.is_absolute():
            self.model = model_path
        else:
            self.model = Path.cwd() / model_path
        
        self.label = self.data['label']
        self.sensitive = self.data.get('sensitive', [])
        self.thresholds = self.data.get('thresholds', {})
        
        # Dataset metadata (required for production audits)
        self.dataset_metadata = self.data.get('dataset_metadata', {})
        self.dataset_description = self.dataset_metadata.get('description', '')
        self.dataset_population = self.dataset_metadata.get('population', '')
        self.dataset_jurisdiction = self.dataset_metadata.get('jurisdiction', '')
        self.dataset_sample_size = self.dataset_metadata.get('sample_size', None)
        
        # Evidence dir is relative to current working directory
        evidence_dir_path = self.data.get('evidence_dir', 'audit_evidence')
        if Path(evidence_dir_path).is_absolute():
            self.evidence_dir = Path(evidence_dir_path)
        else:
            self.evidence_dir = Path.cwd() / evidence_dir_path
        
        # Validate paths
        if not self.dataset.exists():
            raise FileNotFoundError(f"Dataset not found: {self.dataset}")
        if not self.model.exists():
            raise FileNotFoundError(f"Model not found: {self.model}")
    
    def get_threshold(self, metric_name: str) -> float:
        """Get threshold for a metric, or None if not specified."""
        return self.thresholds.get(metric_name)

