import sys
import os

file_path = os.path.abspath(__file__)
end = file_path.index('mns') + 16
project_path = file_path[0:end]
sys.path.append(project_path)
import requests
from bs4 import BeautifulSoup


# 同花顺 美股地址:https://basic.10jqka.com.cn/168/PINS/company.html

# 获取美股公司信息 https://stockpage.10jqka.com.cn/LMT/company/
def get_us_ths_company_info(stock_code):
    """
    根据股票代码，获取同花顺公司基本信息
    :param stock_code: 股票代码，例如 LMT / AAPL 字符串格式，核心传参参数
    :return: dict 结构化的公司基本信息，失败返回空字典
    """
    # 1. 基础配置：参数化拼接URL + 请求头（必须加，否则会被反爬拦截）
    base_url = f"https://stockpage.10jqka.com.cn/{stock_code}/company/"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
    }
    company_data = {}  # 存储最终的公司信息

    try:
        # 2. 发起GET请求获取网页源码
        response = requests.get(url=base_url, headers=headers, timeout=10)
        response.raise_for_status()  # 抛出请求异常（404/500等）
        response.encoding = "utf-8"  # 指定编码，防止中文乱码

        # 3. 解析HTML网页结构
        soup = BeautifulSoup(response.text, "html.parser")
        # 精准定位目标表格（唯一核心表格）
        table = soup.find("table", class_="companyinfo-tab")
        if not table:
            print(f"错误：未找到 {stock_code} 的公司信息表格")
            return company_data

        # 4. 提取所有表格内的文本内容+清洗数据
        all_tds = table.find_all("td")
        for td in all_tds:
            td_text = td.get_text(strip=True)  # 自动去除首尾空格/换行
            if not td_text:
                continue
            # 按【字段名：字段值】的格式拆分数据，封装到字典
            if "：" in td_text:
                key, value = td_text.split("：", 1)  # 只分割第一个冒号
                company_data[key] = value

        # 单独提取：公司LOGO图片地址（补充信息，可选）
        logo_img = table.find("img")
        if logo_img:
            company_data["公司LOGO"] = logo_img.get("src", "")
            company_data["LOGO备注"] = logo_img.get("alt", "")

        # 特殊清洗：公司简介 去除多余空格/换行符，格式化展示
        if "公司简介" in company_data:
            company_data["公司简介"] = company_data["公司简介"].replace("\r", "").replace("\n", "").strip()

    except requests.exceptions.RequestException as e:
        print(f"请求失败：{e}")
    except Exception as e:
        print(f"解析数据异常：{e}")

    return company_data


# ------------------- 核心调用：参数传参 测试 -------------------
if __name__ == "__main__":
    # 股票代码 作为参数传入函数，满足你的核心要求 ✅
    stock_code_param = "GEV"  # 这里可替换任意股票代码，例如：AAPL、MSFT
    result = get_us_ths_company_info(stock_code_param)

    # 格式化打印结果
    print(f"===== {stock_code_param} 公司基本信息 =====")
    for k, v in result.items():
        print(f"{k}: {v}")
