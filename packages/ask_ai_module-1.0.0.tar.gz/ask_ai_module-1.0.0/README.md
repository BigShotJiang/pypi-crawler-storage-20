# Ask_AI

This is a simple python package made by groq and dotenv modules so that you implement AI in your projects easily

## Features

- Easily interact with the Groq API.
- Load API keys and environment variables from a `.env` file.
- Minimal setup for quick development and usage
- Use the ask function to ask AI in python program with the syntax ask(input)

## Usage
```python
# Import the ask function from your package
from ask_ai import ask

# Use the ask function to send a query to AI
response = ask("Hello, what is your name?")
print(response)

```