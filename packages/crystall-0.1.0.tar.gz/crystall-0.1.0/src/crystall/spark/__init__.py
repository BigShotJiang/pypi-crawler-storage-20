"""Spark state management for Crystall."""

from crystall.spark.state import SparkState, spiral_save_state, spiral_load_state

__all__ = ["SparkState", "spiral_save_state", "spiral_load_state"]
