"""Processing units for Crystall research engine."""
