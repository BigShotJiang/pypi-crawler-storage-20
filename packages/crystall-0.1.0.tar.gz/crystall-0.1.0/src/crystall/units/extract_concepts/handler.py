

from crystall.exec_prompt import exec_prompt
from crystall.units.project_intent.models import IntentionProjection
from crystall.units.extract_concepts.models import Concepts
from crystall.units.extract_concepts.models import Concept

async def extract_concepts(intent: str, projection: IntentionProjection)->list[Concept]:

    response = await exec_prompt(
        prompt_name = "extract_concepts/prompt",
        intent = intent,
        response_model = Concepts,
        intent_projection = projection
    )

    return response.concepts
