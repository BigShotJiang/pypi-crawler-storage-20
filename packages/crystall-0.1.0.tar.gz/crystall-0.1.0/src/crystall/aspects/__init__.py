"""Aspect definitions for the Crystall research engine."""

from crystall.aspects.service import service_aspect
from crystall.aspects.connect import connect_aspect
from crystall.aspects.understand import understand_aspect
from crystall.aspects.meta_learn import meta_learn_aspect
from crystall.aspects.meta_deep import meta_deep_aspect

__all__ = [
    "service_aspect",
    "connect_aspect",
    "understand_aspect",
    "meta_learn_aspect",
    "meta_deep_aspect",
]
