"""Crystall - Semantic Vector-Driven LLM Research Engine"""

from crystall.builder import SpiralBuilder, PhaseDefinition
from crystall.spark.state import SparkState
from crystall.persistence.persistence_layer import PersistenceLayer

__version__ = "0.1.0"
__all__ = [
    "SpiralBuilder",
    "PhaseDefinition",
    "SparkState",
    "PersistenceLayer",
    "__version__",
]
