from rich.console import Console

NOZOMI_BANNER = r"""
[cyan]
       _   ______  _____   ____  __  _______
      / | / / __ \/__  /  / __ \/  |/  /  _/
     /  |/ / / / /  / /  / / / / /|_/ // /
    / /|  / /_/ /  / /__/ /_/ / /  / // /
   /_/ |_/\____/  /____/\____/_/  /_/___/
[/cyan]

[yellow]In-Sandbox Commands:[/yellow]
  nozomid setup               Start guided setup
  nozomid status              Current sandbox status
  nozomid services            List managed services
  nozomid service logs <name> View service logs
  nozomid expose <svc> <port> Expose a port publicly

[dim]Press Ctrl+D or type 'exit' to detach (task keeps running)[/dim]
"""


def show_banner() -> None:
    console = Console()
    console.print(NOZOMI_BANNER)
