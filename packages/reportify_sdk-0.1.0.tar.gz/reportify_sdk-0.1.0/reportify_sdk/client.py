"""
Reportify Client

Main client class for interacting with the Reportify API.
"""

from typing import Any

import httpx

from reportify_sdk.exceptions import (
    APIError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
)


class Reportify:
    """
    Reportify API Client

    A user-friendly client for accessing financial data, document search,
    and knowledge base through the Reportify API.

    Args:
        api_key: Your Reportify API key
        base_url: Base URL for the API (default: https://api.reportify.cn)
        timeout: Request timeout in seconds (default: 30)

    Example:
        >>> from reportify_sdk import Reportify
        >>> client = Reportify(api_key="your-api-key")
        >>> docs = client.search("Tesla earnings", num=10)
    """

    DEFAULT_BASE_URL = "https://api.reportify.cn"

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        timeout: float = 30.0,
    ):
        if not api_key:
            raise AuthenticationError("API key is required")

        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout

        self._client = httpx.Client(
            base_url=self.base_url,
            headers=self._get_headers(),
            timeout=timeout,
        )

        # Initialize sub-modules (lazy loading)
        self._stock = None
        self._timeline = None
        self._kb = None
        self._docs = None
        self._tools = None

    def _get_headers(self) -> dict[str, str]:
        """Get default headers for API requests"""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "reportify-sdk-python/0.1.0",
        }

    def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """
        Make an HTTP request to the API

        Args:
            method: HTTP method (GET, POST, etc.)
            path: API endpoint path
            params: Query parameters
            json: JSON body data

        Returns:
            Response data as dictionary

        Raises:
            AuthenticationError: If API key is invalid
            RateLimitError: If rate limit is exceeded
            NotFoundError: If resource is not found
            APIError: For other API errors
        """
        try:
            response = self._client.request(
                method=method,
                url=path,
                params=params,
                json=json,
            )

            # Handle error responses
            if response.status_code == 401:
                raise AuthenticationError()
            elif response.status_code == 429:
                raise RateLimitError()
            elif response.status_code == 404:
                raise NotFoundError()
            elif response.status_code >= 400:
                error_msg = response.text
                try:
                    error_data = response.json()
                    error_msg = error_data.get("detail", error_data.get("message", error_msg))
                except Exception:
                    pass
                raise APIError(error_msg, status_code=response.status_code)

            return response.json()

        except httpx.TimeoutException:
            raise APIError("Request timeout", status_code=408)
        except httpx.RequestError as e:
            raise APIError(f"Request failed: {str(e)}")

    def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """Make a GET request"""
        return self._request("GET", path, params=params)

    def _post(self, path: str, json: dict[str, Any] | None = None) -> dict[str, Any]:
        """Make a POST request"""
        return self._request("POST", path, json=json)

    # -------------------------------------------------------------------------
    # Search Methods
    # -------------------------------------------------------------------------

    def search(
        self,
        query: str,
        *,
        num: int = 10,
        categories: list[str] | None = None,
        symbols: list[str] | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Search documents across all categories

        Args:
            query: Search query string
            num: Number of results to return (default: 10, max: 100)
            categories: Filter by document categories
            symbols: Filter by stock symbols (e.g., ["US:AAPL", "HK:0700"])
            start_date: Start date filter (YYYY-MM-DD)
            end_date: End date filter (YYYY-MM-DD)

        Returns:
            List of matching documents

        Example:
            >>> docs = client.search("Tesla earnings", num=10)
            >>> for doc in docs:
            ...     print(doc["title"])
        """
        data = {
            "query": query,
            "num": num,
        }
        if categories:
            data["categories"] = categories
        if symbols:
            data["symbols"] = symbols
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._post("/v2/search", json=data)
        return response.get("docs", [])

    def search_news(
        self,
        query: str,
        *,
        num: int = 10,
        symbols: list[str] | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Search news articles

        Args:
            query: Search query string
            num: Number of results to return
            symbols: Filter by stock symbols
            start_date: Start date filter (YYYY-MM-DD)
            end_date: End date filter (YYYY-MM-DD)

        Returns:
            List of news articles
        """
        data = {"query": query, "num": num}
        if symbols:
            data["symbols"] = symbols
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._post("/v2/search/news", json=data)
        return response.get("docs", [])

    def search_reports(
        self,
        query: str,
        *,
        num: int = 10,
        symbols: list[str] | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Search research reports

        Args:
            query: Search query string
            num: Number of results to return
            symbols: Filter by stock symbols
            start_date: Start date filter (YYYY-MM-DD)
            end_date: End date filter (YYYY-MM-DD)

        Returns:
            List of research reports
        """
        data = {"query": query, "num": num}
        if symbols:
            data["symbols"] = symbols
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._post("/v2/search/reports", json=data)
        return response.get("docs", [])

    def search_filings(
        self,
        query: str,
        *,
        num: int = 10,
        symbols: list[str] | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Search company filings and announcements

        Args:
            query: Search query string
            num: Number of results to return
            symbols: Filter by stock symbols
            start_date: Start date filter (YYYY-MM-DD)
            end_date: End date filter (YYYY-MM-DD)

        Returns:
            List of filings
        """
        data = {"query": query, "num": num}
        if symbols:
            data["symbols"] = symbols
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._post("/v2/search/filings", json=data)
        return response.get("docs", [])

    def search_transcripts(
        self,
        query: str,
        *,
        num: int = 10,
        symbols: list[str] | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Search earnings call transcripts

        Args:
            query: Search query string
            num: Number of results to return
            symbols: Filter by stock symbols
            start_date: Start date filter (YYYY-MM-DD)
            end_date: End date filter (YYYY-MM-DD)

        Returns:
            List of transcripts
        """
        data = {"query": query, "num": num}
        if symbols:
            data["symbols"] = symbols
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._post("/v2/search/conference-calls", json=data)
        return response.get("docs", [])

    # -------------------------------------------------------------------------
    # Sub-modules (lazy loading)
    # -------------------------------------------------------------------------

    @property
    def stock(self):
        """Stock data module for financial statements, prices, etc."""
        if self._stock is None:
            from reportify_sdk.stock import StockModule
            self._stock = StockModule(self)
        return self._stock

    @property
    def timeline(self):
        """Timeline module for following companies, topics, etc."""
        if self._timeline is None:
            from reportify_sdk.timeline import TimelineModule
            self._timeline = TimelineModule(self)
        return self._timeline

    @property
    def kb(self):
        """Knowledge base module for searching user uploaded documents"""
        if self._kb is None:
            from reportify_sdk.kb import KBModule
            self._kb = KBModule(self)
        return self._kb

    @property
    def docs(self):
        """Documents module for accessing document content and metadata"""
        if self._docs is None:
            from reportify_sdk.docs import DocsModule
            self._docs = DocsModule(self)
        return self._docs

    def close(self):
        """Close the HTTP client"""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
