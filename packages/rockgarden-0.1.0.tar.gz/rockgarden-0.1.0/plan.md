# rockgarden - Obsidian-Compatible Static Site Generator

## Vision

A Python-based SSG that works with Obsidian vaults directly, without requiring users to change how they organize or manage content. The simple case takes an Obsidian vault and produces a navigable static site. Advanced usage allows defining content models mapped to paths.

## Architecture Overview

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Obsidian Vault │ ──▶ │   Data Store    │ ──▶ │   HTML Output   │
│   (Markdown)    │     │   (API Layer)   │     │   (Jinja2)      │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

**Key insight:** Intermediate data store with API enables future use cases (MCP server, different output formats, etc.)

## Phase 1: Core SSG (Simple Case)

### 1.1 Project Setup
- Python package with uv
- CLI entry point
- Minimal config (source dir, output dir)

### 1.2 Content Ingestion
- Recursively read markdown files
- Parse YAML frontmatter (preserve all fields)
- Extract title from: frontmatter `title` → first H1 → filename
- Track file metadata (path, modified date, etc.)

### 1.3 Obsidian Compatibility
- **Wiki-links:** Convert `[[Page Name]]` and `[[Page Name|Display Text]]` to HTML links
- **Embeds:** Handle `![[image.png]]` and `![[note]]` transclusions
- **Callouts:** Convert Obsidian callout syntax to styled HTML
- **Assets:** Copy images/files, update references

### 1.4 Data Store & API
- In-memory store during build
- Simple API: `get_content(path)`, `list_content(dir)`, `get_backlinks(path)`, etc.
- All content is "Content" type by default

### 1.5 HTML Generation
- Jinja2 templates
- Default theme (can reference Quartz styling as inspiration)
- Core templates: page, index, folder listing

### 1.6 Navigation Features
- Directory-based explorer/sidebar
- Breadcrumbs
- Table of contents (per-page, from headings)
- Backlinks section

### 1.7 Search
- Build search index at build time (JSON)
- Client-side full-text search

## Phase 2: Content Models

### 2.1 Model Definition
Config file (`rockgarden.toml`) defining models:

```toml
[models.Character]
paths = ["/characters/"]
fields = ["name", "description"]

[models.NPC]
extends = "Character"
paths = ["/characters/npcs/"]
fields = ["location", "faction"]
```

### 2.2 Model Matching
- Files match models based on path
- A file can match multiple models (NPC is also Character)
- More specific paths take precedence for "primary" type
- API: `get_content_by_type("NPC")`, `content.types` returns all matching types

### 2.3 Model-Specific Templates
- Optional templates per model type
- Falls back to default content template

## Future Enhancements (Noted, Not Planned)
- CLI model discovery wizard
- Config drift detection
- MCP server for vault data
- Graph visualization
- Dark mode toggle
- RSS feed

---

## Project Structure

```
rockgarden/
├── pyproject.toml
├── src/
│   └── rockgarden/
│       ├── __init__.py
│       ├── cli.py              # typer CLI
│       ├── config.py           # TOML config loading
│       ├── content/
│       │   ├── __init__.py
│       │   ├── store.py        # Content store & API
│       │   ├── loader.py       # File discovery & parsing
│       │   └── models.py       # Content/model classes
│       ├── obsidian/
│       │   ├── __init__.py
│       │   ├── wikilinks.py    # [[link]] processing
│       │   ├── embeds.py       # ![[embed]] processing
│       │   └── callouts.py     # Callout conversion
│       ├── render/
│       │   ├── __init__.py
│       │   ├── engine.py       # Jinja2 setup
│       │   └── markdown.py     # markdown-it-py setup
│       └── output/
│           ├── __init__.py
│           ├── builder.py      # Site generation
│           └── search.py       # Search index
└── templates/                  # Default Jinja2 templates
    ├── base.html
    ├── page.html
    └── folder.html
```

## Core Dependencies

- `typer` - CLI
- `markdown-it-py` - Markdown parsing
- `jinja2` - Templates
- `python-frontmatter` - YAML frontmatter
- `tomllib` (stdlib 3.11+) - Config parsing

---

## Implementation Plan

### Step 1: Project Scaffold
- [ ] Initialize uv project (`rockgarden`)
- [ ] Set up package structure (see above)
- [ ] CLI with `build` and `serve` commands
- [ ] Config loading from `rockgarden.toml`

### Step 2: Content Reading
- [ ] Markdown file discovery
- [ ] Frontmatter parsing (python-frontmatter or similar)
- [ ] Content store class

### Step 3: Obsidian Processing
- [ ] Wiki-link parser/converter
- [ ] Embed handling
- [ ] Callout conversion
- [ ] Asset copying

### Step 4: HTML Output
- [ ] Jinja2 environment setup
- [ ] Base templates
- [ ] Page rendering
- [ ] Folder index generation

### Step 5: Navigation
- [ ] Explorer data structure
- [ ] Breadcrumb generation
- [ ] TOC extraction
- [ ] Backlink tracking

### Step 6: Search
- [ ] Build-time index generation
- [ ] Client-side search JS

---

## Decisions Made

- **Project name:** `rockgarden` (available on PyPI)
- **Config format:** TOML (`rockgarden.toml`)
- **Package manager:** uv
- **Templating:** Jinja2
- **CLI framework:** typer (rich integration later)
- **Markdown parser:** markdown-it-py (CommonMark, extensible)

## Verification

After each step, verify incrementally:

**Step 1:** `rockgarden --help` works, shows build/serve commands

**Step 2:** `rockgarden build` reads markdown files, prints discovered content

**Step 3:** Wiki-links in output HTML resolve to correct paths

**Step 4:** `rockgarden build` produces HTML files in output directory

**Step 5:** Generated pages include breadcrumbs, TOC, backlinks

**Step 6:** Search index JSON is generated, client search works

**End-to-end:** Run against your D&D Obsidian vault, compare to Quartz output
