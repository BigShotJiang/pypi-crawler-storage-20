"""Tests for observability module."""
