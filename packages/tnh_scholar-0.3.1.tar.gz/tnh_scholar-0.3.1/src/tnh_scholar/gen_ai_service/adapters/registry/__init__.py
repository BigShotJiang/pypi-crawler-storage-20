"""Registry adapter utilities."""
