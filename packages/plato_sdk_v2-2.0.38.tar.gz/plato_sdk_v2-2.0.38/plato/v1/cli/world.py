"""World CLI commands for Plato."""

import typer

from plato.v1.cli.agent import _publish_package

world_app = typer.Typer(help="Manage and deploy worlds")


@world_app.command(name="publish")
def world_publish(
    path: str = typer.Argument(".", help="Path to the world package directory (default: current directory)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Build without uploading"),
):
    """
    Build and publish a world package to the Plato worlds repository.

    Reads pyproject.toml for package info, builds with 'uv build',
    and uploads to the Plato worlds repository via the PyPI proxy.

    Requires PLATO_API_KEY environment variable.

    Example:
        plato world publish
        plato world publish ./my-world-package
        plato world publish --dry-run
    """
    _publish_package(path, "worlds", dry_run)
