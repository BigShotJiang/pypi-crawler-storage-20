#!/bin/bash
set -e

# Start OpenVSCode Server in the background
echo "Starting OpenVSCode Server on port ${VSCODE_PORT:-60001}..."
/openhands/.openvscode-server/bin/openvscode-server \
    --host 0.0.0.0 \
    --port ${VSCODE_PORT:-60001} \
    --connection-token ${SESSION_API_KEY:-plato-sandbox-key-2024} \
    --disable-workspace-trust &

# Give VS Code a moment to start
sleep 2

# Start the agent server in the foreground
echo "Starting OpenHands Agent Server..."
exec python -u -m openhands.agent_server
