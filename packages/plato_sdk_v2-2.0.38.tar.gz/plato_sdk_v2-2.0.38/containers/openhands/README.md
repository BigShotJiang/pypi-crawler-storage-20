# OpenHands Container

Docker container for running the OpenHands agent with Plato simulators.

## Image

ECR: `383806609161.dkr.ecr.us-west-1.amazonaws.com/app-sim/openhands-runtime`

Tags:
- `prod-latest` - Production
- `staging-latest` - Staging
- `{commit-hash}` - Specific commit

## Deploy

```bash
# Production
./deploy.sh --env prod

# Staging
./deploy.sh --env staging
```

## Build Locally

The Dockerfile is designed to be built from the OpenHands repo root:

```bash
cd ~/Github/OpenHands
docker build -f containers/plato/Dockerfile -t openhands-runtime:local .
```

## Usage

The container runs OpenHands with:
- OpenVSCode Server on port 60001
- Agent server on port 8000

Environment variables:
- `LLM_MODEL`: Model to use (e.g., `anthropic/claude-sonnet-4`)
- `SAVE_TRAJECTORY_PATH`: Directory to save agent trajectories
- Simulator URLs from World (e.g., `SPREE_BASE_URL`, `FIREFLY_BASE_URL`)
