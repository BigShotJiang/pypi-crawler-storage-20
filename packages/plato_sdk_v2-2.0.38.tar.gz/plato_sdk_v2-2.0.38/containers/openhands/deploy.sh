#!/bin/bash
set -e

# Configuration
ECR_REPOSITORY="383806609161.dkr.ecr.us-west-1.amazonaws.com/app-sim/openhands-runtime"
AWS_REGION="us-west-1"
ENV=""

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --env)
            ENV="$2"
            shift 2
            ;;
        --help|-h)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --env          Environment (dev, staging, prod) [REQUIRED]"
            echo "  --help, -h     Show this help message"
            echo ""
            echo "Examples:"
            echo "  $0 --env prod"
            echo "  $0 --env staging"
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            echo "Use --help for usage information"
            exit 1
            ;;
    esac
done

# Validate required parameters
if [ -z "$ENV" ]; then
    echo "Error: --env parameter is required"
    echo "Usage: $0 --env <environment>"
    echo "Available environments: dev, staging, prod"
    exit 1
fi

# Function to log with timestamp
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Get the script directory and repo root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Get git commit hash
cd "$REPO_ROOT"
if command -v git &> /dev/null && git rev-parse --git-dir > /dev/null 2>&1; then
    COMMIT_HASH=$(git rev-parse --short HEAD)
    log "Using commit hash: $COMMIT_HASH"
else
    COMMIT_HASH="unknown"
    log "Git not available, using 'unknown' for commit hash"
fi

# Set image tags
COMMIT_TAG="$ECR_REPOSITORY:$COMMIT_HASH"
ENV_TAG="$ECR_REPOSITORY:$ENV-latest"

log "Building openhands-runtime image..."
log "Environment: $ENV"
log "Commit tag: $COMMIT_TAG"
log "Environment tag: $ENV_TAG"
log "Building from: $REPO_ROOT"

# Check if Dockerfile exists
DOCKERFILE="$SCRIPT_DIR/Dockerfile"
if [ ! -f "$DOCKERFILE" ]; then
    log "Dockerfile not found at $DOCKERFILE"
    exit 1
fi

# Create ECR repository if it doesn't exist
REPO_NAME="app-sim/openhands-runtime"
log "Checking if ECR repository exists..."
if ! aws ecr describe-repositories --region $AWS_REGION --repository-names $REPO_NAME >/dev/null 2>&1; then
    log "Creating ECR repository: $REPO_NAME"
    if ! aws ecr create-repository --region $AWS_REGION --repository-name $REPO_NAME >/dev/null 2>&1; then
        log "Failed to create ECR repository"
        exit 1
    fi
    log "Created ECR repository: $REPO_NAME"
else
    log "ECR repository exists: $REPO_NAME"
fi

# Authenticate with ECR
log "Authenticating with ECR..."
if ! aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin "383806609161.dkr.ecr.us-west-1.amazonaws.com"; then
    log "Failed to authenticate with ECR"
    exit 1
fi

# Build the image for x86_64 from repo root
log "Building Docker image for linux/amd64..."
if ! docker build --platform linux/amd64 -f "$DOCKERFILE" -t openhands-runtime:local "$REPO_ROOT"; then
    log "Failed to build Docker image"
    exit 1
fi

# Tag the image with commit hash
log "Tagging with commit hash..."
docker tag openhands-runtime:local "$COMMIT_TAG"

# Tag the image with environment tag
log "Tagging with environment tag..."
docker tag openhands-runtime:local "$ENV_TAG"

# Push commit hash tag
log "Pushing commit tag: $COMMIT_TAG"
if ! docker push "$COMMIT_TAG"; then
    log "Failed to push commit tag"
    exit 1
fi

# Push environment tag
log "Pushing environment tag: $ENV_TAG"
if ! docker push "$ENV_TAG"; then
    log "Failed to push environment tag"
    exit 1
fi

# Clean up local tags
log "Cleaning up local tags..."
docker rmi openhands-runtime:local "$COMMIT_TAG" "$ENV_TAG" 2>/dev/null || true

log "Successfully deployed openhands-runtime image!"
log "Available tags:"
log "   - $COMMIT_TAG"
log "   - $ENV_TAG"
log ""
log "Usage examples:"
log "   docker pull $ENV_TAG"
log "   docker run -p 3000:3000 $ENV_TAG"
