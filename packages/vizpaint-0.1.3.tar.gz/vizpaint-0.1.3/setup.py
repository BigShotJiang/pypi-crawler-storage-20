from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="vizpaint",
    version="0.1.3",  # 必须是全新的、未上传过的版本号
    author="zhouxinjun",
    author_email="369013027@qq.com",
    description="A feature-rich Python visualization library with 2D/3D charts, rose plots, and an easy-to-use API built on Matplotlib.",
    url="https://pypi.org/project/vizpaint/",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["matplotlib>=3.3.0", "numpy>=1.19.0"],
    python_requires=">=3.7",
)