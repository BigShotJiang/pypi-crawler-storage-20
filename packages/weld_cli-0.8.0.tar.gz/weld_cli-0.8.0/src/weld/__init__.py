"""Weld: Human-in-the-loop coding harness with transcript provenance."""

__version__ = "0.8.0"
