from . import main

if __name__ == "__main__":
    print('abc')
    main()