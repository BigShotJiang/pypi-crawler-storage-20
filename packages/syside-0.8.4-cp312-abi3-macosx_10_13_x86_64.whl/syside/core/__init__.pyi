"""
Syside
======

**Native Syside module for Python.**

Internally, Syside uses ``snake_case`` for all non-type symbols, e.g. attributes and
functions, whereas the specification and the Pilot implementation both use ``camelCase``
instead. ``snake_case`` was chosen because it integrates far better into Python - 
the programming language that Syside uses.

Additionally, Syside does not use multiple inheritance to implement the standard model
and instead uses sum-types where appropriate (``typing.Union`` in Python). This improves
performance as methods and attributes can be inlined and are not required to be accessed 
through interfaces (no pointer chasing), reduces memory usage as unused members need not 
be stored (e.g. ``Relationship`` interface for ``Associations``), and improves usability 
by allowing more flexible constraints on element types.

Usability is further improved by storing child elements in separate members based on
their position in the textual syntax. This is in comparison to the Pilot implementation,
which only uses two such members, ``ownedRelationship`` and ``ownedRelatedElement``.
Syside implementation allows direct access to most special members without resorting to
filtering every time, improving performance. Moreover, modifying and inserting such
members does not require potentially expensive reshuffling of children arrays.

Lastly, because textual source files may contain syntax errors, all model elements may
return optional elements, even if the corresponding attribute in the specification
expects a non-null element. This also allows elements to be default constructible.

Additional Notes
----------------

-  For performance reasons, elements and their groups are stored as
   specific members in AST nodes based on their position in textual
   syntax which also makes mutation easier. Notably:

   -  ``prefixes`` - group for metadata prefixes, prefixed with ``#`` in
      textual notation
   -  ``heritage`` - type specializations and conjugations
   -  ``type_relationships`` - non-specialization type relationships
      appearing after specialization part, including feature chaining
   -  ``children`` - elements in the children block (in-between brackets
      ``{`` and ``}``) in textual notation, and expression arguments
   -  ``declared_ends``, ``declared_messages`` - end features and messages
      before the children block. In the textual syntax they appear in the same
      position, hence in contrast to similar groups there are additional
      ``try_append`` and ``try_insert`` methods that return ``None`` without
      throwing if modification failed because the slot is already occupied by
      either ends or messages.

-  Due to parser limitations, argument member references are parsed as
   argument members instead. This has little effect on analysis as
   intermediate ``FeatureReferenceExpression`` and ``OwningMembership``
   are excluded from the expression tree.
-  Elements can only be owned nodes in the same document to satisfy tree
   constraints, elements can be referenced by any appropriate element.
   Violating this constraint raises ``ValueError``. Similarly, trying to
   steal ownership also raises ``ValueError``.
-  Relationship ends cannot generally be modified unless they are member
   elements, and only a few allow this dependent on the textual syntax
   (KerML only but there are currently no checks that models constructed
   are actually representable in chosen textual syntax beyond some
   simple checks during printing).

Model Modifications
~~~~~~~~~~~~~~~~~~~

Adding new owned or referenced ``Elements`` to a model can raise:

-  ``TypeError``:

   -  if the relationship type is not allowed by the container/setter as
      this violates internal invariants.
   -  if the element type is not allowed by the container/setter as this
      violates internal invariants.
   -  if the element type is not allowed by the relationship as this
      violates internal invariants.
   -  if the element is owned but the relationship instead only
      references related element to prevent orphan elements.

-  ``ValueError``:

   -  if taking ownership of an element from another document as this
      violates internal invariants.
   -  if stealing ownership of the element as there is no good default
      behaviour on what should happen, remove the element from the model
      first before trying to re-parent it.

-  ``RuntimeError``:

   -  if the parent ``Element`` has been removed from the model. This
      can be fixed by adding the ``Element`` back into the model as an
      owned element.
"""

from collections.abc import Callable, Iterable, Iterator, Sequence
import datetime
import enum
import os
import types
from typing import (
    AnyStr,
    Generic,
    Self,
    TYPE_CHECKING,
    Tuple,
    TypeGuard as _TypeGuard,
    TypeVar,
    Union,
    overload
)
import uuid

from . import (
    debug as debug,
    experimental as experimental,
    gc as gc,
    ide as ide,
    version as version
)


# pyright reports false positive class var overrides because they are
# mutable and there are no read-only type hints
# pyright: reportIncompatibleVariableOverride=false
# mypy: disable-error-code="assignment"

if TYPE_CHECKING:
    Value = Union[int, float, bool, Infinity, str, range, Element, BoundMetaclass, None, list[Value]]

class AcceptActionUsage(ActionUsage):
    """
    Implementation of ``AcceptActionUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``AcceptActionUsage`` is an ``ActionUsage`` that specifies the
       acceptance of an ``incoming_transfer`` from the ``Occurrence`` given
       by the result of its ``receiver_argument`` Expression. (If no
       ``receiver_argument`` is provided, the default is the ``this``
       context of the AcceptActionUsage.) The payload of the accepted
       ``Transfer`` is output on its ``payload_parameter``. Which
       ``Transfers`` may be accepted is determined by conformance to the
       typing and (potentially) binding of the ``payload_parameter``.

    For language description, see section
    `7.17.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=138>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=343>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AcceptActionUsage'

    STD: tuple[type[AcceptActionUsage], ...] = (AcceptActionUsage,)

    if TYPE_CHECKING:
        Std = AcceptActionUsage

    @property
    def receiver_parameter(self) -> ReferenceUsage | None:
        """The parameter that owns the ``receiver_argument``."""

    @property
    def receiver_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``receiver``."""

    @property
    def receiver_argument(self) -> Expression | None:
        """
        Implementation of ``receiver_argument`` defined in the SysML
        specification.

        **Specification**:

           An ``Expression`` whose ``result`` is bound to the ``receiver`` input
           ``parameter`` of this ``AcceptActionUsage``.

        See section
        `8.3.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=344>`__
        of the SysML specification for more details.
        """

    @property
    def payload_parameter(self) -> ReferenceUsage | None:
        """
        Implementation of ``payload_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``nested_reference`` of this ``AcceptActionUsage`` that redefines
           the ``payload`` output ``parameter`` of the base
           ``AcceptActionUsage`` ``AcceptAction`` from the Systems Model
           Library.

        See section
        `8.3.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=344>`__
        of the SysML specification for more details.
        """

    @property
    def payload_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``payload``."""

    @property
    def payload_argument(self) -> Expression | None:
        """
        Implementation of ``payload_argument`` defined in the SysML
        specification.

        **Specification**:

           An ``Expression`` whose ``result`` is bound to the ``payload``
           ``parameter`` of this ``AcceptActionUsage``. If provided, the
           ``AcceptActionUsage`` will only accept a ``Transfer`` with exactly
           this ``payload``.

        See section
        `8.3.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=344>`__
        of the SysML specification for more details.
        """

class ActionDefinition(OccurrenceDefinition):
    """
    Implementation of ``ActionDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``ActionDefinition`` is a ``Definition`` that is also a
       ``Behavior`` that defines an ``Action`` performed by a system or part
       of a system.

    For language description, see section
    `7.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=130>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=345>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ActionDefinition'

    STD: tuple[type[ActionDefinition], ...] = (ActionDefinition,)

    if TYPE_CHECKING:
        Std = ActionDefinition

    @property
    def steps(self) -> LazyIterator[Step | ActionUsage | FlowUsage]:
        """
        Implementation of ``step`` defined in the KerML specification.

        **Specification**:

           The ``Steps`` that make up this ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The parameters of this ``Behavior``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

    @property
    def actions(self) -> LazyIterator[ActionUsage | FlowUsage]:
        """
        Implementation of ``action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsages`` that are ``steps`` in this ``ActionDefinition``,
           which define the actions that specify the behavior of the
           ``ActionDefinition``.

        See section
        `8.3.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=346>`__
        of the SysML specification for more details.
        """

class ActionParameterAccessor(OwnedMemberAccessor[ParameterMembership, ActionUsage]):
    @overload
    def set_member_element[M: ActionUsage](self, element: M, name: NameID = ...) -> tuple[ParameterMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ActionUsage](self, element: M | None, name: NameID = ...) -> tuple[ParameterMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ActionUsage](self, element: type[M]) -> tuple[ParameterMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ActionUsage(OccurrenceUsage):
    """
    Implementation of ``ActionUsage`` defined in the SysML specification.

    **Specification**:

       An ``ActionUsage`` is a ``Usage`` that is also a ``Step``, and, so,
       is typed by a ``Behavior``. Nominally, if the type is an
       ``ActionDefinition``, an ``ActionUsage`` is a ``Usage`` of that
       ``ActionDefinition`` within a system. However, other kinds of kernel
       ``Behaviors`` are also allowed, to permit use of ``Behaviors`` from
       the Kernel Model Libraries.

    For language description, see section
    `7.17.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=130>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=346>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ActionUsage'

    STD: tuple[Union[type[ActionUsage], type[FlowUsage]], ...] = (ActionUsage, FlowUsage)

    if TYPE_CHECKING:
        Std = Union[ActionUsage, FlowUsage]

    @property
    def behaviors(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``behavior`` defined in the KerML specification.

        **Specification**:

           The ``Behaviors`` that type this ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

    @property
    def owned_parameters(self) -> LazyIterator[Feature]:
        """The ``parameters`` owned by this ``Step``."""

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The ``parameters`` of this ``Step``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

    @property
    def action_definitions(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``action_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Behaviors`` that are the ``types`` of this ``ActionUsage``.
           Nominally, these would be ``ActionDefinitions``, but other kinds of
           Kernel ``Behaviors`` are also allowed, to permit use of ``Behaviors``
           from the Kernel Model Libraries.

        See section
        `8.3.17.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=346>`__
        of the SysML specification for more details.
        """

class ActorMembership(ParameterMembership):
    """
    Implementation of ``ActorMembership`` defined in the SysML
    specification.

    **Specification**:

       An ``ActorMembership`` is a ``ParameterMembership`` that identifies a
       ``PartUsage`` as an *actor* ``parameter``, which specifies a role
       played by an external entity in interaction with the ``owning_type``
       of the ``ActorMembership``.

    For language description, see section
    `7.21.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=160>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=387>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ActorMembership'

    STD: tuple[type[ActorMembership], ...] = (ActorMembership,)

    if TYPE_CHECKING:
        Std = ActorMembership

    @property
    def owned_actor_parameter(self) -> PartUsage | None:
        """
        Implementation of ``owned_actor_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``PartUsage`` specifying the actor.

        See section
        `8.3.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=387>`__
        of the SysML specification for more details.
        """

class AllocationDefinition(ConnectionDefinition):
    """
    Implementation of ``AllocationDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``AllocationDefinition`` is a ``ConnectionDefinition`` that
       specifies that some or all of the responsibility to realize the
       intent of the ``source`` is allocated to the ``target`` instances.
       Such allocations define mappings across the various structures and
       hierarchies of a system model, perhaps as a precursor to more
       rigorous specifications and implementations. An
       ``AllocationDefinition`` can itself be refined using nested
       ``allocations`` that give a finer-grained decomposition of the
       containing allocation mapping.

    For language description, see section
    `7.15.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=110>`__
    of the SysML specification. For more details on the model, see section
    `8.3.15.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=336>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AllocationDefinition'

    STD: tuple[type[AllocationDefinition], ...] = (AllocationDefinition,)

    if TYPE_CHECKING:
        Std = AllocationDefinition

    @property
    def allocations(self) -> LazyIterator[AllocationUsage]:
        """
        Implementation of ``allocation`` defined in the SysML specification.

        **Specification**:

           The ``AllocationUsages`` that refine the allocation mapping defined
           by this ``AllocationDefinition``.

        See section
        `8.3.15.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=337>`__
        of the SysML specification for more details.
        """

class AllocationUsage(ConnectionUsage):
    """
    Implementation of ``AllocationUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``AllocationUsage`` is a usage of an ``AllocationDefinition``
       asserting the allocation of the ``source`` feature to the ``target``
       feature.

    For language description, see section
    `7.15.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=110>`__
    of the SysML specification. For more details on the model, see section
    `8.3.15.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=337>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AllocationUsage'

    STD: tuple[type[AllocationUsage], ...] = (AllocationUsage,)

    if TYPE_CHECKING:
        Std = AllocationUsage

    @property
    def allocation_definitions(self) -> LazyIterator[AllocationDefinition]:
        """
        Implementation of ``allocation_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``AllocationDefinitions`` that are the types of this
           ``AllocationUsage``.

        See section
        `8.3.15.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=337>`__
        of the SysML specification for more details.
        """

class AlwaysNever(enum.Enum):
    Always = 0

    Never = 1

class AnalysisCaseDefinition(CaseDefinition):
    """
    Implementation of ``AnalysisCaseDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``AnalysisCaseDefinition`` is a ``CaseDefinition`` for the case of
       carrying out an analysis.

    For language description, see section
    `7.23.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=171>`__
    of the SysML specification. For more details on the model, see section
    `8.3.23.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=405>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AnalysisCaseDefinition'

    STD: tuple[type[AnalysisCaseDefinition], ...] = (AnalysisCaseDefinition,)

    if TYPE_CHECKING:
        Std = AnalysisCaseDefinition

class AnalysisCaseUsage(CaseUsage):
    """
    Implementation of ``AnalysisCaseUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``AnalysisCaseUsage`` is a ``Usage`` of an
       ``AnalysisCaseDefinition``.

    For language description, see section
    `7.23.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=171>`__
    of the SysML specification. For more details on the model, see section
    `8.3.23.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=406>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AnalysisCaseUsage'

    STD: tuple[type[AnalysisCaseUsage], ...] = (AnalysisCaseUsage,)

    if TYPE_CHECKING:
        Std = AnalysisCaseUsage

    @property
    def analysis_case_definition(self) -> AnalysisCaseDefinition | None:
        """
        Implementation of ``analysis_case_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``AnalysisCaseDefinition`` that is the ``definition`` of this
           ``AnalysisCaseUsage``.

        See section
        `8.3.23.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=406>`__
        of the SysML specification for more details.
        """

class AnnotatingElement(Element):
    """
    Implementation of ``AnnotatingElement`` defined in the KerML
    specification.

    **Specification**:

       An ``AnnotatingElement`` is an ``Element`` that provides additional
       description of or metadata on some other ``Element``. An
       ``AnnotatingElement`` is either attached to its
       ``annotated_elements`` by ``Annotation`` ``Relationships``, or it
       implicitly annotates its ``owning_namespace``.

    For language description, see section
    `7.2.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=44>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::AnnotatingElement'

    STD: tuple[Union[type[AnnotatingElement], type[MetadataFeature], type[MetadataUsage]], ...] = (AnnotatingElement, MetadataFeature, MetadataUsage)

    if TYPE_CHECKING:
        Std = Union[AnnotatingElement, MetadataFeature, MetadataUsage]

    @property
    def annotations(self) -> ContainerView[Annotation]:
        """
        Implementation of ``annotation`` defined in the KerML specification.

        **Specification**:

           The ``Annotations`` that relate this ``AnnotatingElement`` to its
           ``annotated_elements``. This includes the
           ``owning_annotating_relationship`` (if any) followed by all the
           ``owned_annotating_relationships``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
        of the KerML specification for more details.
        """

    @property
    def annotated_elements(self) -> ContainerView[Element]:
        """
        Implementation of ``annotated_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Elements`` that are annotated by this ``AnnotatingElement``. If
           ``annotation`` is not empty, these are the ``annotated_elements`` of
           the ``annotations``. If ``annotation`` is empty, then it is the
           ``owning_namespace`` of the ``AnnotatingElement``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
        of the KerML specification for more details.
        """

    @property
    def owned_annotating_relationships(self) -> ContainerView[Annotation]:
        """
        Implementation of ``owned_annotating_relationship`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``AnnotatingElement`` that are
           ``Annotations``, for which this ``AnnotatingElement`` is the
           ``annotating_element``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=147>`__
        of the KerML specification for more details.
        """

    @property
    def owning_annotating_relationship(self) -> Annotation | None:
        """
        Implementation of ``owning_annotating_relationship`` defined in the
        KerML specification.

        **Specification**:

           The ``owning_relationship`` of this ``AnnotatingRelationship``, if it
           is an ``Annotation``

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=147>`__
        of the KerML specification for more details.
        """

    @property
    def about(self) -> Annotations:
        """Container for owned annotations."""

class Annotation(Relationship):
    """
    Implementation of ``Annotation`` defined in the KerML specification.

    **Specification**:

       An ``Annotation`` is a Relationship between an ``AnnotatingElement``
       and the ``Element`` that is annotated by that ``AnnotatingElement``.

    For language description, see section
    `7.2.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=44>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=147>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Annotation'

    STD: tuple[type[Annotation], ...] = (Annotation,)

    if TYPE_CHECKING:
        Std = Annotation

    @property
    def annotated_element(self) -> Element | None:
        """
        Implementation of ``annotated_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Element`` that is annotated by the ``annotating_element`` of
           this Annotation.

        See section
        `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=148>`__
        of the KerML specification for more details.
        """

    @property
    def owning_annotated_element(self) -> Element | None:
        """
        Implementation of ``owning_annotated_element`` defined in the KerML
        specification.

        **Specification**:

           The ``annotated_element`` of this ``Annotation``, when it is also the
           ``owning_related_element``.

        See section
        `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=148>`__
        of the KerML specification for more details.
        """

    @property
    def owned_annotating_element(self) -> AnnotatingElement | MetadataFeature | MetadataUsage | None:
        """
        Implementation of ``owned_annotating_element`` defined in the KerML
        specification.

        **Specification**:

           The ``annotating_element`` of this ``Annotation``, when it is an
           ``owned_related_element``.

        See section
        `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=148>`__
        of the KerML specification for more details.
        """

    @property
    def annotating_element(self) -> AnnotatingElement | MetadataFeature | MetadataUsage | None:
        """
        Implementation of ``annotating_element`` defined in the KerML
        specification.

        **Specification**:

           The ``AnnotatingElement`` that annotates the ``annotated_element`` of
           this ``Annotation``. This is always either the
           ``owned_annotating_element`` or the ``owning_annotating_element``.

        See section
        `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=148>`__
        of the KerML specification for more details.
        """

    @property
    def owning_annotating_element(self) -> AnnotatingElement | MetadataFeature | MetadataUsage | None:
        """
        Implementation of ``owning_annotating_element`` defined in the KerML
        specification.

        **Specification**:

           The ``annotating_element`` of this ``Annotation``, when it is the
           ``owning_related_element``.

        See section
        `8.3.2.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=148>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> Element | None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> ContainerView[Element]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> ContainerView[Element]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

class Annotations(ChildrenNodes[Annotation, Element]):
    def append[R: Annotation, M: Element](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    def replace[R: Annotation, M: Element](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    def insert[R: Annotation, M: Element](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

class ArgumentsAccessor(LazyIterator[Expression]):
    @overload
    def append[M: Expression](self, arg: M, /) -> tuple[FeatureValue, M]:
        """
        Append a new invocation ``argument``. This takes care of constructing any intermediate elements.

        Returns a pair of (``feature_value``, ``argument``).
        """

    @overload
    def append[M: Expression](self, arg: type[M], /) -> tuple[FeatureValue, M]:
        """
        Append a new invocation ``argument`` with the corresponding type. This takes care of constructing
        any intermediate elements.

        Returns a pair of (``feature_value``, ``argument``).
        """

class AssertConstraintUsage(ConstraintUsage):
    """
    Implementation of ``AssertConstraintUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``AssertConstraintUsage`` is a ``ConstraintUsage`` that is also an
       ``Invariant`` and, so, is asserted to be true (by default). Unless it
       is the ``AssertConstraintUsage`` itself, the asserted
       ``ConstraintUsage`` is related to the ``AssertConstraintUsage`` by a
       ReferenceSubsetting ``Relationship``.

    For language description, see section
    `7.20.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=159>`__
    of the SysML specification. For more details on the model, see section
    `8.3.20.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=381>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AssertConstraintUsage'

    STD: tuple[Union[type[AssertConstraintUsage], type[SatisfyRequirementUsage]], ...] = (AssertConstraintUsage, SatisfyRequirementUsage)

    if TYPE_CHECKING:
        Std = Union[AssertConstraintUsage, SatisfyRequirementUsage]

    @property
    def is_negated(self) -> bool:
        """
        Implementation of ``is_negated`` defined in the KerML specification.

        **Specification**:

           Whether this ``Invariant`` is asserted to be false rather than true.

        See section
        `8.3.4.7.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=228>`__
        of the KerML specification for more details.
        """

    @is_negated.setter
    def is_negated(self, arg: bool, /) -> None: ...

    @property
    def asserted_constraint(self) -> ConstraintUsage | None:
        """
        Implementation of ``asserted_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsage`` to be performed by the
           ``AssertConstraintUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``AssertConstraintUsage``, if
           there is one, and, otherwise, the ``AssertConstraintUsage`` itself.

        See section
        `8.3.20.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=382>`__
        of the SysML specification for more details.
        """

class AssignmentActionUsage(ActionUsage):
    """
    Implementation of ``AssignmentActionUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``AssignmentActionUsage`` is an ``ActionUsage`` that is defined,
       directly or indirectly, by the ``ActionDefinition``
       ``AssignmentAction`` from the Systems Model Library. It specifies
       that the value of the ``referent`` ``Feature``, relative to the
       target given by the result of the ``target_argument`` ``Expression``,
       should be set to the result of the ``value_expression``.

    For language description, see section
    `7.17.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=140>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=348>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AssignmentActionUsage'

    STD: tuple[type[AssignmentActionUsage], ...] = (AssignmentActionUsage,)

    if TYPE_CHECKING:
        Std = AssignmentActionUsage

    @property
    def target_argument(self) -> Expression | None:
        """
        Implementation of ``target_argument`` defined in the SysML
        specification.

        **Specification**:

           The ``Expression`` whose value is an occurrence in the domain of the
           ``referent`` ``Feature``, for which the value of the ``referent``
           will be set to the result of the ``value_expression`` by this
           ``AssignmentActionUsage``.

        See section
        `8.3.17.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=348>`__
        of the SysML specification for more details.
        """

    @property
    def target_parameter(self) -> ReferenceUsage | None:
        """The parameter owning the ``target_argument``."""

    @property
    def target_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``target_parameter``."""

    @property
    def value_expression(self) -> Expression | None:
        """
        Implementation of ``value_expression`` defined in the SysML
        specification.

        **Specification**:

           The ``Expression`` whose result is to be assigned to the ``referent``
           ``Feature``.

        See section
        `8.3.17.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=348>`__
        of the SysML specification for more details.
        """

    @property
    def value_parameter(self) -> ReferenceUsage | None:
        """The parameter owning the ``value_expression``."""

    @property
    def value_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``value_parameter``."""

    @property
    def referent(self) -> Feature | None:
        """
        Implementation of ``referent`` defined in the SysML specification.

        **Specification**:

           The ``Feature`` whose value is to be set.

        See section
        `8.3.17.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=348>`__
        of the SysML specification for more details.
        """

    @property
    def referent_member(self) -> ChainedFeatureMemberAccessor:
        """Syside specific accessor for manipulating ``referent``."""

class Association(Classifier):
    """
    Implementation of ``Association`` defined in the KerML specification.

    **Specification**:

       An ``Association`` is a ``Relationship`` and a ``Classifier`` to
       enable classification of links between things (in the universe). The
       co-domains (``types``) of the ``association_end`` ``Features`` are
       the ``related_types``, as co-domain and participants (linked things)
       of an ``Association`` identify each other.

    For language description, see section
    `7.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=69>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=211>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Association'

    STD: tuple[Union[type[Association], type[ConnectionDefinition], type[FlowDefinition]], ...] = (Association, ConnectionDefinition, FlowDefinition)

    if TYPE_CHECKING:
        Std = Union[Association, ConnectionDefinition, FlowDefinition]

    @property
    def source(self) -> Feature | None:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> list[Feature]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def owned_related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def source_type(self) -> Type | None:
        """
        Implementation of ``source_type`` defined in the KerML specification.

        **Specification**:

           The source ``related_type`` for this ``Association``. It is the first
           ``related_type`` of the ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=211>`__
        of the KerML specification for more details.
        """

    @property
    def related_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``related_type`` defined in the KerML specification.

        **Specification**:

           The ``types`` of the ``association_ends`` of the ``Association``,
           which are the ``related_elements`` of the ``Association`` considered
           as a ``Relationship``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=211>`__
        of the KerML specification for more details.
        """

    @property
    def target_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``target_type`` defined in the KerML specification.

        **Specification**:

           The target ``related_types`` for this ``Association``. This includes
           all the ``related_types`` other than the ``source_type``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
        of the KerML specification for more details.
        """

    @property
    def association_ends(self) -> LazyIterator[Feature]:
        """
        Implementation of ``association_end`` defined in the KerML
        specification.

        **Specification**:

           The ``features`` of the ``Association`` that identify the things that
           can be related by it. A concrete ``Association`` must have at least
           two ``association_ends``. When it has exactly two, the
           ``Association`` is called a *binary* ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=211>`__
        of the KerML specification for more details.
        """

class AssociationStructure(Association):
    """
    Implementation of ``AssociationStructure`` defined in the KerML
    specification.

    **Specification**:

       An ``AssociationStructure`` is an ``Association`` that is also a
       ``Structure``, classifying link objects that are both links and
       objects. As objects, link objects can be created and destroyed, and
       their non-end ``Features`` can change over time. However, the values
       of the end ``Features`` of a link object are fixed and cannot change
       over its lifetime.

    For language description, see section
    `7.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=72>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=213>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::AssociationStructure'

    STD: tuple[Union[type[AssociationStructure], type[ConnectionDefinition]], ...] = (AssociationStructure, ConnectionDefinition)

    if TYPE_CHECKING:
        Std = Union[AssociationStructure, ConnectionDefinition]

class AstNode:
    def __str__(self) -> str: ...

    def __hash__(self) -> int: ...

    @overload
    def isinstance(self, type: type[TNode]) -> _TypeGuard[TNode]: ...

    @overload
    def isinstance(self, type: tuple[type[TNode], ...]) -> _TypeGuard[TNode]: ...

    @overload
    def try_cast(self, type: tuple[type[TNode], ...]) -> TNode | None: ...

    @overload
    def try_cast(self, *type: type[TNode]) -> TNode | None: ...

    @overload
    def cast(self, type: tuple[type[TNode], ...]) -> TNode: ...

    @overload
    def cast(self, *type: type[TNode]) -> TNode: ...

    @property
    def parent(self) -> Element | None: ...

    @property
    def document(self) -> Document: ...

    @property
    def cst_node(self) -> CstNode | None: ...

    @property
    def owned_elements(self) -> LazyIterator[Element]:
        """Returns a view into all elements directly owned by this ``Element``."""

class AttributeDefinition(Definition):
    """
    Implementation of ``AttributeDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``AttributeDefinition`` is a ``Definition`` and a ``DataType`` of
       information about a quality or characteristic of a system or part of
       a system that has no independent identity other than its value. All
       ``features`` of an ``AttributeDefinition`` must be referential
       (non-composite).

       As a ``DataType``, an ``AttributeDefinition`` must specialize,
       directly or indirectly, the base ``DataType`` ``Base::DataValue``
       from the Kernel Semantic Library.

    For language description, see section
    `7.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=76>`__
    of the SysML specification. For more details on the model, see section
    `8.3.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=312>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AttributeDefinition'

    STD: tuple[type[AttributeDefinition], ...] = (AttributeDefinition,)

    if TYPE_CHECKING:
        Std = AttributeDefinition

class AttributeMap:
    """Internal opaque type for deserialization attribute mapping"""

    def __eq__(self, arg: object, /) -> bool:
        pass

class AttributeUsage(Usage):
    """
    Implementation of ``AttributeUsage`` defined in the SysML specification.

    **Specification**:

       An ``AttributeUsage`` is a ``Usage`` whose type is a ``DataType``.
       Nominally, if the type is an ``AttributeDefinition``, an
       ``AttributeUsage`` is a usage of a ``AttributeDefinition`` to
       represent the value of some system quality or characteristic.
       However, other kinds of kernel ``DataTypes`` are also allowed, to
       permit use of ``DataTypes`` from the Kernel Model Libraries. An
       ``AttributeUsage`` itself as well as all its nested ``features`` must
       be referential (non-composite).

       An ``AttributeUsage`` must specialize, directly or indirectly, the
       base ``Feature`` ``Base::data_values`` from the Kernel Semantic
       Library.

    For language description, see section
    `7.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=76>`__
    of the SysML specification. For more details on the model, see section
    `8.3.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=312>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::AttributeUsage'

    STD: tuple[type[AttributeUsage], ...] = (AttributeUsage,)

    if TYPE_CHECKING:
        Std = AttributeUsage

    @property
    def attribute_definitions(self) -> LazyIterator[AttributeDefinition | DataType]:
        """
        Implementation of ``attribute_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``DataTypes`` that are the types of this ``AttributeUsage``.
           Nominally, these are ``AttributeDefinitions``, but other kinds of
           kernel ``DataTypes`` are also allowed, to permit use of ``DataTypes``
           from the Kernel Model Libraries.

        See section
        `8.3.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=313>`__
        of the SysML specification for more details.
        """

class BasicDocument:
    @property
    def text_document(self) -> SharedMutex[TextDocument] | None: ...

    @text_document.setter
    def text_document(self, text: SharedMutex[TextDocument] | None) -> None: ...

    @property
    def url(self) -> Url: ...

    @url.setter
    def url(self, arg: Url, /) -> None: ...

    @property
    def build_state(self) -> BuildState: ...

    @build_state.setter
    def build_state(self, arg: BuildState, /) -> None: ...

    @property
    def document_state(self) -> DocumentState: ...

    @property
    def document_tier(self) -> DocumentTier: ...

    def change_document_tier(self, arg: DocumentTier, /) -> None:
        """
        Set ``document_tier`` to another value. This is a method rather than a function because
        tier should not change throughout document lifetime. Nevertheless, this is still useful
        in cases where a document has just been constructed and its attributes need to be changed.
        """

    @property
    def language(self) -> str: ...

    @property
    def version(self) -> DocumentVersion:
        """
        The version of the last build. This corresponds to the version of
        ``TextDocument`` this was built from.
        """

    def increment_version(self) -> None:
        """
        Increment sema version. Source version is automatically handled by source parser.
        """

    def __hash__(self) -> int: ...

    @property
    def mutex(self) -> SharedMutex[Self]:
        """Retrieve the mutex associated with this document"""

    __cpp_name__: str = 'syside::BasicDocument'

class Behavior(Class):
    """
    Implementation of ``Behavior`` defined in the KerML specification.

    **Specification**:

       A ``Behavior`` coordinates occurrences of other ``Behaviors``, as
       well as changes in objects. ``Behaviors`` can be decomposed into
       ``Steps`` and be characterized by ``parameters``.

    For language description, see section
    `7.4.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=78>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=219>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Behavior'

    STD: tuple[Union[type[Behavior], type[ActionDefinition], type[ConstraintDefinition], type[Interaction]], ...] = (Behavior, ActionDefinition, ConstraintDefinition, Interaction)

    if TYPE_CHECKING:
        Std = Union[Behavior, ActionDefinition, ConstraintDefinition, Interaction]

    @property
    def steps(self) -> LazyIterator[Step | ActionUsage | FlowUsage]:
        """
        Implementation of ``step`` defined in the KerML specification.

        **Specification**:

           The ``Steps`` that make up this ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The parameters of this ``Behavior``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

class BindingConnector(Connector):
    """
    Implementation of ``BindingConnector`` defined in the KerML
    specification.

    **Specification**:

       A ``BindingConnector`` is a binary ``Connector`` that requires its
       ``related_features`` to identify the same things (have the same
       values).

    For language description, see section
    `7.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=77>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.5.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=214>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::BindingConnector'

    STD: tuple[Union[type[BindingConnector], type[BindingConnectorAsUsage]], ...] = (BindingConnector, BindingConnectorAsUsage)

    if TYPE_CHECKING:
        Std = Union[BindingConnector, BindingConnectorAsUsage]

class BindingConnectorAsUsage(ConnectorAsUsage):
    """
    Implementation of ``BindingConnectorAsUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``BindingConnectorAsUsage`` is both a ``BindingConnector`` and a
       ``ConnectorAsUsage``.

    For language description, see section
    `7.13.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=102>`__
    of the SysML specification. For more details on the model, see section
    `8.3.13.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=331>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::BindingConnectorAsUsage'

    STD: tuple[type[BindingConnectorAsUsage], ...] = (BindingConnectorAsUsage,)

    if TYPE_CHECKING:
        Std = BindingConnectorAsUsage

class BooleanExpression(Expression):
    """
    Implementation of ``BooleanExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``BooleanExpression`` is a ``Boolean``-valued ``Expression`` whose
       type is a ``Predicate``. It represents a logical condition resulting
       from the evaluation of the ``Predicate``.

    For language description, see section
    `7.4.8.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=83>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=223>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::BooleanExpression'

    STD: tuple[Union[type[BooleanExpression], type[ConstraintUsage]], ...] = (BooleanExpression, ConstraintUsage)

    if TYPE_CHECKING:
        Std = Union[BooleanExpression, ConstraintUsage]

    @property
    def predicate(self) -> Predicate | ConstraintDefinition | None:
        """
        Implementation of ``predicate`` defined in the KerML specification.

        **Specification**:

           The Predicate that types the Expression.

           The ``Predicate`` that types this ``BooleanExpression``.

        See section
        `8.3.4.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

class BoundMetaclass:
    @property
    def element(self) -> Element: ...

    @property
    def metaclass(self) -> Type: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::sysml::vm::BoundMetaclass'

class BuildState(enum.IntEnum):
    """Document build state"""

    none = 0
    """Document has only been created"""

    Changed = 1
    """Document content has changed"""

    Parsed = 2
    """Document content was parsed"""

    Indexed = 3
    """Document global and local exports have been indexed"""

    Built = 4
    """Model has been built and linked"""

    Validated = 5
    """Model has been validated"""

class CalculationDefinition(ActionDefinition):
    """
    Implementation of ``CalculationDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``CalculationDefinition`` is an ActionDefinition that also defines
       a ``Function`` producing a ``result``.

    For language description, see section
    `7.19.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=155>`__
    of the SysML specification. For more details on the model, see section
    `8.3.19.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=379>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::CalculationDefinition'

    STD: tuple[type[CalculationDefinition], ...] = (CalculationDefinition,)

    if TYPE_CHECKING:
        Std = CalculationDefinition

    @property
    def calculations(self) -> LazyIterator[CalculationUsage]:
        """
        Implementation of ``calculation`` defined in the SysML specification.

        **Specification**:

           The ``actions`` of this ``CalculationDefinition`` that are
           ``CalculationUsages``.

        See section
        `8.3.19.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=380>`__
        of the SysML specification for more details.
        """

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Function`` can be used as the ``function`` of a
           model-level evaluable ``InvocationExpression``. Certain ``Functions``
           from the Kernel Functions Library are considered to have
           ``is_model_level_evaluable = true``. For all other ``Functions`` it
           is ``false``.

           **Note:** See the specification of the KerML concrete syntax notation
           for ``Expressions`` for an identification of which library
           ``Functions`` are model-level evaluable.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
        of the KerML specification for more details.
        """

    @property
    def expressions(self) -> LazyIterator[Expression | CalculationUsage | ConstraintUsage]:
        """
        Implementation of ``expression`` defined in the KerML specification.

        **Specification**:

           The ``Expressions`` that are ``steps`` in the calculation of the
           ``result`` of this ``Function``.

           The set of expressions that represent computational steps or parts of
           a system of equations within the Function.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           The object or value that is the result of evaluating the Function.

           The ``result`` ``parameter`` of the ``Function``, which is owned by
           the ``Function`` via a ``ReturnParameterMembership``.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
        of the KerML specification for more details.
        """

    @property
    def any_result(self) -> Feature | None:
        """``result`` that also considers specialized ``Functions``."""

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``Function`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class CalculationUsage(ActionUsage):
    """
    Implementation of ``CalculationUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``CalculationUsage`` is an ``ActionUsage`` that is also an
       ``Expression``, and, so, is typed by a ``Function``. Nominally, if
       the ``type`` is a ``CalculationDefinition``, a ``CalculationUsage``
       is a ``Usage`` of that ``CalculationDefinition`` within a system.
       However, other kinds of kernel ``Functions`` are also allowed, to
       permit use of ``Functions`` from the Kernel Model Libraries.

    For language description, see section
    `7.19.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=155>`__
    of the SysML specification. For more details on the model, see section
    `8.3.19.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=380>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::CalculationUsage'

    STD: tuple[type[CalculationUsage], ...] = (CalculationUsage,)

    if TYPE_CHECKING:
        Std = CalculationUsage

    @property
    def calculation_definition(self) -> Function | CalculationDefinition | ConstraintDefinition | None:
        """
        Implementation of ``calculation_definition`` defined in the SysML
        specification.

        **Specification**:

           The Function that is the ``type`` of this ``CalculationUsage``.
           Nominally, this would be a ``CalculationDefinition``, but a kernel
           ``Function`` is also allowed, to permit use of ``Functions`` from the
           Kernel Model Libraries.

        See section
        `8.3.19.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=380>`__
        of the SysML specification for more details.
        """

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Expression`` meets the constraints necessary to be
           evaluated at *model level*, that is, using metadata within the model.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def function(self) -> Function | CalculationDefinition | ConstraintDefinition | None:
        """
        Implementation of ``function`` defined in the KerML specification.

        **Specification**:

           The ``Function`` that types this ``Expression``.

           This is the Function that types the Expression.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           An ``output`` ``parameter`` of the ``Expression`` whose value is the
           result of the ``Expression``. The result of an ``Expression`` is
           either inherited from its ``function`` or it is related to the
           ``Expression`` via a ``ReturnParameterMembership``, in which case it
           redefines the ``result`` ``parameter`` of its ``function``.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``CalculationUsage`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class CaseDefinition(CalculationDefinition):
    """
    Implementation of ``CaseDefinition`` defined in the SysML specification.

    **Specification**:

       A ``CaseDefinition`` is a ``CalculationDefinition`` for a process,
       often involving collecting evidence or data, relative to a subject,
       possibly involving the collaboration of one or more other actors,
       producing a result that meets an objective.

    For language description, see section
    `7.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=169>`__
    of the SysML specification. For more details on the model, see section
    `8.3.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=400>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::CaseDefinition'

    STD: tuple[type[CaseDefinition], ...] = (CaseDefinition,)

    if TYPE_CHECKING:
        Std = CaseDefinition

    @property
    def subject_parameter(self) -> Usage | None:
        """
        Implementation of ``subject_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameter`` of this ``CaseDefinition`` that represents its
           subject.

        See section
        `8.3.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=401>`__
        of the SysML specification for more details.
        """

    @property
    def actor_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``actor_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``CaseDefinition`` that represent actors
           involved in the case.

        See section
        `8.3.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=401>`__
        of the SysML specification for more details.
        """

    @property
    def objective_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``objective_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsage`` representing the objective of this
           ``CaseDefinition``.

        See section
        `8.3.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=401>`__
        of the SysML specification for more details.
        """

class CaseUsage(CalculationUsage):
    """
    Implementation of ``CaseUsage`` defined in the SysML specification.

    **Specification**:

       A ``CaseUsage`` is a ``Usage`` of a ``CaseDefinition``.

    For language description, see section
    `7.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=169>`__
    of the SysML specification. For more details on the model, see section
    `8.3.22.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=402>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::CaseUsage'

    STD: tuple[type[CaseUsage], ...] = (CaseUsage,)

    if TYPE_CHECKING:
        Std = CaseUsage

    @property
    def subject_parameter(self) -> Usage | None:
        """
        Implementation of ``subject_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameter`` of this ``CaseUsage`` that represents its subject.

        See section
        `8.3.22.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=402>`__
        of the SysML specification for more details.
        """

    @property
    def actor_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``actor_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``CaseUsage`` that represent actors
           involved in the case.

        See section
        `8.3.22.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=402>`__
        of the SysML specification for more details.
        """

    @property
    def objective_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``objective_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsage`` representing the objective of this
           ``CaseUsage``.

        See section
        `8.3.22.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=402>`__
        of the SysML specification for more details.
        """

    @property
    def case_definition(self) -> CaseDefinition | None:
        """
        Implementation of ``case_definition`` defined in the SysML
        specification.

        **Specification**:

           The CaseDefinition that is the type of this CaseUsage.

        See section
        `8.3.22.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=402>`__
        of the SysML specification for more details.
        """

class ChainedChildrenNodes(ChildrenNodes[R, M]):
    """
    Container that stores a vector of children nodes that may own feature chainings.
    """

    def append_chain(self, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Append a relationship with an owned chaining. Raises ``TypeError`` if the relationship type cannot have owned
        chaining in the textual syntax.
        """

    def insert_chain(self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Insert a relationship with an owned chaining at the specified index. Raises ``TypeError`` if the relationship
        type cannot have owned chaining in the textual syntax.
        """

    def replace_chain_at(self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Replace the relationship and its related element at the specified index with an owned chaining. The relationship
        may be reused if its type matches the current relationship at that index. Raises ``TypeError`` if the
        relationship type cannot have owned chaining in the textual syntax.
        """

class ChainedFeatureMemberAccessor(ChainedMemberAccessor[Membership, Feature]):
    @overload
    def set_member_element[M: Feature](self, element: M, name: NameID = ...) -> tuple[Membership, M]:
        """
        Set a new ``member_element``. ``element`` will only be referenced if the ``membership`` is ``Membership``,
        otherwise ownership constraints apply. Replaces the previous ``member_element``, which may be reused by the model
        if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Feature](self, element: M | None, name: NameID = ...) -> tuple[Membership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

class ChainedFeatureReference(ChainedReferenceAccessor[Feature]):
    def try_set[M: Feature](self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set[M: Feature](self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class ChainedMemberAccessor[R: Membership, M: Feature](MemberAccessor[R, M]):
    def set_member_element_chain(self, arg: Sequence[Feature], /) -> tuple[OwningMembership, Feature]:
        """
        Set the reference to a chain of ``Features``. Replaces the previous ``member_element``.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is the ``Feature``
        with owned ``FeatureChainings`` to the provided ``Features`` with order preserved.
        """

class ChainedReferenceAccessor(ReferenceAccessor[M]):
    def try_set_chain(self, arg: Sequence[Feature], /) -> Feature | None:
        """
        Try changing the referenced ``element`` to a chain of ``Features``. Returns ``None`` if this reference
        cannot be modified, otherwise returns a new owned ``Feature`` that chains all ``Features`` in order.
        """

    def set_chain(self, arg: Sequence[Feature], /) -> Feature:
        """
        ``try_set_chain`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class ChainedTypeReference(ChainedReferenceAccessor[Type]):
    def try_set[M: Type](self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set[M: Type](self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class ChildrenNodes(ChildrenNodesView[R, M]):
    """
    Container that stores a vector of children nodes.

    This is the primary object to modify the model through. In order to maintain type invariants,
    relationships can only be constructed internally by this container using the provided relationship type.
    The related element type is then checked against the types supported by the relationship and the container.
    However, due to limitations in the Python type system, this check can only be done at runtime. In addition,
    type system limitations do not allow generic ``TypeVar`` constraints which prevents fully resolved return types
    in this generic implementation.
    """

    def reserve(self, arg: int, /) -> None:
        """Increase the capacity of the container. Size is not changed."""

    def clear(self) -> None:
        """Clear all nodes from this container. Size is reset to 0 afterwards."""

    def append(self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    def replace(self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    def insert(self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    def pop(self, index: int = -1) -> tuple[R, M]:
        """
        Removes and returns a pair (relationship, element) from this container at the specified index. The relationship
        may be reused internally when constructing a new relationship of the same type, while the related element will
        only be reused if it was and owned related element. In this case, the related element may be assigned to a new
        owner in the same document. Note that removed owned related elements will have all the elements in the subtree
        removed as well.
        """

    def remove_relationship(self, arg: R, /) -> bool:
        """
        Removes a relationship and its related element from this container. Returns ``True`` if the relationship was
        removed, and ``False`` otherwise. Note that removed owned related elements will have all the elements in the
        subtree removed as well.
        """

    def remove_element(self, arg: M, /) -> bool:
        """
        Removes a related element from this container. Returns ``True`` if the related element was removed, and ``False``
        otherwise. Note that removed owned related elements will have all the elements in the subtree
        removed as well.
        """

    def extract(self, index: int = -1) -> M:
        """
        Extracts and returns the element from this container at the specified index without clearing its subtree. The
        relationship may be reused internally when constructing a new relationship of the same type, while the related
        element will not.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``IndexError`` if index is out of bounds.
        """

    def extract_with_relationship(self, arg: R, /) -> M:
        """
        Removes a relationship and extracts its related element from this container without clearing its subtree.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``ValueError`` if there is no such relationship.
        """

    def extract_element(self, arg: M, /) -> M:
        """
        Extracts a related element from this container without clearing its subtree.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``ValueError`` if there is no such related element.
        """

class ChildrenNodesView(Generic[R, M]):
    """A view to a container of children nodes."""

    @property
    def relationships(self) -> ContainerView[R]:
        """The relationships in this container."""

    @property
    def elements(self) -> ContainerView[M]:
        """The related elements in this container."""

    def __len__(self) -> int: ...

    def __bool__(self) -> bool: ...

    def __getitem__(self, arg: int, /) -> Tuple[R, M]: ...

    def at(self, arg: int, /) -> Tuple[R, M] | None: ...

class Class(Classifier):
    """
    Implementation of ``Class`` defined in the KerML specification.

    **Specification**:

       A ``Class`` is a ``Classifier`` of things (in the universe) that can
       be distinguished without regard to how they are related to other
       things (via ``Features``). This means multiple things classified by
       the same ``Class`` can be distinguished, even when they are related
       other things in exactly the same way.

    For language description, see section
    `7.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=67>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=209>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Class'

    STD: tuple[Union[type[Class], type[AssociationStructure], type[Interaction], type[OccurrenceDefinition]], ...] = (Class, AssociationStructure, Interaction, OccurrenceDefinition)

    if TYPE_CHECKING:
        Std = Union[Class, AssociationStructure, Interaction, OccurrenceDefinition]

class Classifier(Type):
    """
    Implementation of ``Classifier`` defined in the KerML specification.

    **Specification**:

       A ``Classifier`` is a ``Type`` that classifies:

       - Things (in the universe) regardless of how ``Features`` relate
         them. (These are interpreted semantically as sequences of exactly
         one thing.)
       - How the above things are related by ``Features.`` (These are
         interpreted semantically as sequences of multiple things, such that
         the last thing in the sequence is also classified by the
         ``Classifier``. Note that this means that a ``Classifier`` modeled
         as specializing a ``Feature`` cannot classify anything.)

    For language description, see section
    `7.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=57>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=181>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Classifier'

    STD: tuple[type[Classifier], ...] = (Classifier,)

    if TYPE_CHECKING:
        Std = Classifier

    @property
    def owned_subclassifications(self) -> LazyIterator[Subclassification]:
        """
        Implementation of ``owned_subclassification`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_specializations`` of this ``Classifier`` that are
           ``Subclassifications``, for which this ``Classifier`` is the
           ``subclassifier``.

        See section
        `8.3.3.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=181>`__
        of the KerML specification for more details.
        """

    @property
    def owned_subclassification_types(self) -> LazyIterator[Classifier]:
        """
        The ``Classifiers`` related to this ``Classifier`` by ``owned_subclassifications``.
        """

class ClassifierReference(ReferenceAccessor[Classifier]):
    def try_set[M: Classifier](self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set[M: Classifier](self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class CodeDescription:
    def __init__(self, href: str) -> None: ...

    @property
    def href(self) -> str:
        """An URI to open with more information about the diagnostic error."""

    @href.setter
    def href(self, arg: str, /) -> None: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::CodeDescription'

class CollectExpression(OperatorExpression):
    """
    Implementation of ``CollectExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``CollectExpression`` is an ``OperatorExpression`` whose
       ``operator`` is ``"collect"``, which resolves to the ``Function``
       ``ControlFunctions::collect`` from the Kernel Functions Library.

    For language description, see section
    `7.4.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=86>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=231>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::CollectExpression'

    STD: tuple[type[CollectExpression], ...] = (CollectExpression,)

    if TYPE_CHECKING:
        Std = CollectExpression

class Comment(AnnotatingElement):
    """
    Implementation of ``Comment`` defined in the KerML specification.

    **Specification**:

       A ``Comment`` is an ``AnnotatingElement`` whose ``body`` in some way
       describes its ``annotated_elements``.

    For language description, see section
    `7.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=44>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=149>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Comment'

    STD: tuple[type[Comment], ...] = (Comment,)

    if TYPE_CHECKING:
        Std = Comment

    @property
    def locale(self) -> str | None:
        """
        Implementation of ``locale`` defined in the KerML specification.

        **Specification**:

           Identification of the language of the ``body`` text and, optionally,
           the region and/or encoding. The format shall be a POSIX locale
           conformant to ISO/IEC 15897, with the format
           ``[language[_territory][.codeset][@modifier]]``.

        See section
        `8.3.2.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=149>`__
        of the KerML specification for more details.
        """

    @locale.setter
    def locale(self, arg: str | None) -> None: ...

    @property
    def body(self) -> str:
        """
        Implementation of ``body`` defined in the KerML specification.

        **Specification**:

           The annotation text for the ``Comment``.

        See section
        `8.3.2.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=149>`__
        of the KerML specification for more details.
        """

    @body.setter
    def body(self, arg: str, /) -> None: ...

class CompilationReport:
    @property
    def fatal(self) -> bool: ...

    @fatal.setter
    def fatal(self, arg: bool, /) -> None: ...

    @property
    def diagnostics(self) -> ContainerView[Diagnostic]: ...

    def __bool__(self) -> bool: ...

    __cpp_name__: str = 'syside::sysml::vm::CompilationReport'

class Compiler:
    def __init__(self, max_steps: int = 100000) -> None: ...

    @property
    def max_steps(self) -> int:
        """
        Maximum number of steps an expression evaluation may take. When this is reached, evaluation
        stops with an error. Actual steps are an implementation detail.
        """

    @max_steps.setter
    def max_steps(self, arg: int, /) -> None: ...

    def evaluate(self, expr: Expression, stdlib: Stdlib | None = None, scope: Type | None | None = None, experimental_quantities: bool = False) -> tuple[Value | None, CompilationReport]:
        """
        Evaluate expression. Note that custom functions and expressions, and most
        except a few standard library functions are not evaluatable. Constructor
        expressions evaluate as themselves because the constructor expressions
        conform to the constructed object implicitly. This primarily evaluates
        operator, metadata access, and feature reference expressions. If
        provided, ``stdlib`` is used to accelerate some common evaluations, e.g.
        checking for ``self`` expressions.

        If ``experimental_quantities`` is enabled, compiler will additionally
        attempt to evaluate scalar quantity expressions in SI units, other
        systems of quantities are not supported. The results will be returned in
        scalar ``float`` and no type-checking will be performed. In the future,
        when typed quantities are implemented, this may be changed.

        Note that quantity evaluation requires ``Stdlib`` to have found elements
        from ``MeasurementReferences`` library. Additionally, evaluation is
        tested to work with standard library quantities and prefixes. Custom
        package-level prefixes and quantities are also expected to work, however
        any nested feature chaining may or may not work.
        """

    def evaluate_feature(self, feature: Feature, scope: Type, stdlib: Stdlib | None = None, experimental_quantities: bool = False) -> tuple[Value | None, CompilationReport]:
        """
        Evaluate ``feature`` in ``scope``, taking into account redefinitions. If ``feature`` is an
        ``Expression``, this effectively performs ``evaluate``.
        """

    __cpp_name__: str = 'syside::sysml::vm::Compiler'

class ConcernDefinition(RequirementDefinition):
    r"""
    Implementation of ``ConcernDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``ConcernDefinition`` is a ``RequirementDefinition`` that one or
       more stakeholders may be interested in having addressed. These
       stakeholders are identified by the ``owned_stakeholders``\ of the
       ``ConcernDefinition``.

    For language description, see section
    `7.21.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=167>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=387>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConcernDefinition'

    STD: tuple[type[ConcernDefinition], ...] = (ConcernDefinition,)

    if TYPE_CHECKING:
        Std = ConcernDefinition

class ConcernUsage(RequirementUsage):
    """
    Implementation of ``ConcernUsage`` defined in the SysML specification.

    **Specification**:

       A ``ConcernUsage`` is a ``Usage`` of a ``ConcernDefinition``.

       The ``owned_stakeholder`` features of the ConcernUsage shall all
       subset the ``ConcernCheck::concerned_stakeholders`` feature. If the
       ConcernUsage is an ``owned_feature`` of a StakeholderDefinition or
       StakeholderUsage, then the ConcernUsage shall have an
       ``owned_stakeholder`` feature that is bound to the ``self`` feature
       of its owner.

    For language description, see section
    `7.21.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=167>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=388>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConcernUsage'

    STD: tuple[type[ConcernUsage], ...] = (ConcernUsage,)

    if TYPE_CHECKING:
        Std = ConcernUsage

    @property
    def concern_definition(self) -> ConcernDefinition | None:
        """
        Implementation of ``concern_definition`` defined in the SysML
        specification.

        **Specification**:

           The ConcernDefinition that is the single type of this ConcernUsage.

        See section
        `8.3.21.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=388>`__
        of the SysML specification for more details.
        """

class ConjugatedPortDefinition(PortDefinition):
    """
    Implementation of ``ConjugatedPortDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``ConjugatedPortDefinition`` is a ``PortDefinition`` that is a
       ``PortDefinition`` of its original ``PortDefinition``. That is, a
       ``ConjugatedPortDefinition`` inherits all the ``features`` of the
       original ``PortDefinition``, but input ``flows`` of the original
       ``PortDefinition`` become outputs on the ``ConjugatedPortDefinition``
       and output ``flows`` of the original ``PortDefinition`` become inputs
       on the ``ConjugatedPortDefinition``. Every ``PortDefinition`` (that
       is not itself a ``ConjugatedPortDefinition``) has exactly one
       corresponding ``ConjugatedPortDefinition``, whose effective name is
       the name of the ``original_port_definition``, with the character
       ``~`` prepended.

    For language description, see section
    `7.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=93>`__
    of the SysML specification. For more details on the model, see section
    `8.3.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=325>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConjugatedPortDefinition'

    STD: tuple[type[ConjugatedPortDefinition], ...] = (ConjugatedPortDefinition,)

    if TYPE_CHECKING:
        Std = ConjugatedPortDefinition

    @property
    def owned_port_conjugator(self) -> PortConjugation | None:
        """
        Implementation of ``owned_port_conjugator`` defined in the SysML
        specification.

        **Specification**:

           The ``PortConjugation`` that is the ``owned_conjugator`` of this
           ``ConjugatedPortDefinition``, linking it to its
           ``original_port_definition``.

        See section
        `8.3.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=326>`__
        of the SysML specification for more details.
        """

    @property
    def original_port_definition(self) -> PortDefinition | None:
        """
        Implementation of ``original_port_definition`` defined in the SysML
        specification.

        **Specification**:

           The original ``PortDefinition`` for this
           ``ConjugatedPortDefinition``, which is the ``owning_namespace`` of
           the ``ConjugatedPortDefinition``.

        See section
        `8.3.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=326>`__
        of the SysML specification for more details.
        """

class ConjugatedPortTyping(FeatureTyping):
    """
    Implementation of ``ConjugatedPortTyping`` defined in the SysML
    specification.

    **Specification**:

       A ``ConjugatedPortTyping`` is a ``FeatureTyping`` whose ``type`` is a
       ``ConjugatedPortDefinition``. (This relationship is intended to be an
       abstract-syntax marker for a special surface notation for conjugated
       typing of ports.)

    For language description, see section
    `7.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=93>`__
    of the SysML specification. For more details on the model, see section
    `8.3.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=326>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConjugatedPortTyping'

    STD: tuple[type[ConjugatedPortTyping], ...] = (ConjugatedPortTyping,)

    if TYPE_CHECKING:
        Std = ConjugatedPortTyping

    CHAINABLE: bool = False

    @property
    def port_definition(self) -> PortDefinition | None:
        """
        Implementation of ``port_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``original_port_definition`` of the
           ``conjugated_port_definition`` of this ``ConjugatedPortTyping``.

        See section
        `8.3.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=327>`__
        of the SysML specification for more details.
        """

    @property
    def conjugated_port_definition(self) -> ConjugatedPortDefinition | None:
        """
        Implementation of ``conjugated_port_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``type`` of this ``ConjugatedPortTyping`` considered as a
           ``FeatureTyping``, which must be a ``ConjugatedPortDefinition``.

        See section
        `8.3.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=327>`__
        of the SysML specification for more details.
        """

class Conjugation(Relationship):
    """
    Implementation of ``Conjugation`` defined in the KerML specification.

    **Specification**:

       ``Conjugation`` is a ``Relationship`` between two types in which the
       ``conjugated_type`` inherits all the ``Features`` of the
       ``original_type``, but with all ``input`` and ``output`` ``Features``
       reversed. That is, any ``Features`` with a ``direction`` *in*
       relative to the ``original_type`` are considered to have an effective
       ``direction`` of *out* relative to the ``conjugated_type`` and,
       similarly, ``Features`` with ``direction`` *out* in the
       ``original_type`` are considered to have an effective ``direction``
       of *in* in the ``conjugated_type``. ``Features`` with ``direction``
       *inout*, or with no ``direction``, in the ``original_type``, are
       inherited without change.

       A ``Type`` may participate as a ``conjugated_type`` in at most one
       ``Conjugation`` relationship, and such a ``Type`` may not also be the
       ``specific`` ``Type`` in any ``Specialization`` relationship.

    For language description, see section
    `7.3.2.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=54>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=166>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Conjugation'

    STD: tuple[type[Conjugation], ...] = (Conjugation,)

    if TYPE_CHECKING:
        Std = Conjugation

    CHAINABLE: bool = True

    @property
    def original_type(self) -> Type | None:
        """
        Implementation of ``original_type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` to be conjugated.

        See section
        `8.3.3.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=166>`__
        of the KerML specification for more details.
        """

    @property
    def conjugated_type(self) -> Type | None:
        """
        Implementation of ``conjugated_type`` defined in the KerML
        specification.

        **Specification**:

           The ``Type`` that is the result of applying ``Conjugation`` to the
           ``original_type``.

        See section
        `8.3.3.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=166>`__
        of the KerML specification for more details.
        """

    @property
    def owning_type(self) -> Type | None:
        """
        Implementation of ``owning_type`` defined in the KerML specification.

        **Specification**:

           The ``conjugated_type`` of this ``Conjugation`` that is also its
           ``owning_related_element``.

        See section
        `8.3.3.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=166>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def original_type_target(self) -> ChainedTypeReference:
        """
        Syside specific accessor for manipulating the target of ``original_type``.
        """

    @property
    def conjugated_type_target(self) -> ChainedTypeReference:
        """
        Syside specific accessor for manipulating the target of ``conjugated_type``.
        """

class ConnectionDefinition(PartDefinition):
    """
    Implementation of ``ConnectionDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``ConnectionDefinition`` is a ``PartDefinition`` that is also an
       ``AssociationStructure``. The end ``Features`` of a
       ``ConnectionDefinition`` must be ``Usages``.

    For language description, see section
    `7.13.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=98>`__
    of the SysML specification. For more details on the model, see section
    `8.3.13.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=331>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConnectionDefinition'

    STD: tuple[type[ConnectionDefinition], ...] = (ConnectionDefinition,)

    if TYPE_CHECKING:
        Std = ConnectionDefinition

    @property
    def connection_ends(self) -> LazyIterator[Usage]:
        """
        Implementation of ``connection_end`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that define the things related by the
           ``ConnectionDefinition``.

        See section
        `8.3.13.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=332>`__
        of the SysML specification for more details.
        """

    @property
    def source(self) -> Feature | None:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> list[Feature]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def owned_related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def source_type(self) -> Type | None:
        """
        Implementation of ``source_type`` defined in the KerML specification.

        **Specification**:

           The source ``related_type`` for this ``Association``. It is the first
           ``related_type`` of the ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=211>`__
        of the KerML specification for more details.
        """

    @property
    def related_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``related_type`` defined in the KerML specification.

        **Specification**:

           The ``types`` of the ``association_ends`` of the ``Association``,
           which are the ``related_elements`` of the ``Association`` considered
           as a ``Relationship``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=211>`__
        of the KerML specification for more details.
        """

    @property
    def target_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``target_type`` defined in the KerML specification.

        **Specification**:

           The target ``related_types`` for this ``Association``. This includes
           all the ``related_types`` other than the ``source_type``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
        of the KerML specification for more details.
        """

    @property
    def association_ends(self) -> LazyIterator[Feature]:
        """
        Implementation of ``association_end`` defined in the KerML
        specification.

        **Specification**:

           The ``features`` of the ``Association`` that identify the things that
           can be related by it. A concrete ``Association`` must have at least
           two ``association_ends``. When it has exactly two, the
           ``Association`` is called a *binary* ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=211>`__
        of the KerML specification for more details.
        """

class ConnectionUsage(ConnectorAsUsage):
    """
    Implementation of ``ConnectionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``ConnectionUsage`` is a ``ConnectorAsUsage`` that is also a
       ``PartUsage``. Nominally, if its type is a ``ConnectionDefinition``,
       then a ``ConnectionUsage`` is a Usage of that
       ``ConnectionDefinition``, representing a connection between parts of
       a system. However, other kinds of kernel ``AssociationStructures``
       are also allowed, to permit use of ``AssociationStructures`` from the
       Kernel Model Libraries.

    For language description, see section
    `7.13.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=98>`__
    of the SysML specification. For more details on the model, see section
    `8.3.13.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=332>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConnectionUsage'

    STD: tuple[type[ConnectionUsage], ...] = (ConnectionUsage,)

    if TYPE_CHECKING:
        Std = ConnectionUsage

    @property
    def connection_definitions(self) -> LazyIterator[ConnectionDefinition | AssociationStructure]:
        """
        Implementation of ``connection_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``AssociationStructures`` that are the types of this
           ``ConnectionUsage``. Nominally, these are , but other kinds of Kernel
           ``AssociationStructures`` are also allowed, to permit use of
           ``AssociationStructures`` from the Kernel Model Libraries

        See section
        `8.3.13.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=333>`__
        of the SysML specification for more details.
        """

    @property
    def item_definitions(self) -> LazyIterator[Structure | AssociationStructure | ConnectionDefinition | ItemDefinition | PortDefinition]:
        """
        Implementation of ``item_definition`` defined in the SysML
        specification.

        **Specification**:

           The Structures that are the ``definitions`` of this ItemUsage.
           Nominally, these are ItemDefinitions, but other kinds of Kernel
           Structures are also allowed, to permit use of Structures from the
           Kernel Library.

        See section
        `8.3.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=322>`__
        of the SysML specification for more details.
        """

    @property
    def part_definitions(self) -> LazyIterator[PartDefinition]:
        """
        Implementation of ``part_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``item_definitions`` of this PartUsage that are PartDefinitions.

        See section
        `8.3.11.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=324>`__
        of the SysML specification for more details.
        """

    @property
    def is_individual(self) -> bool:
        """
        Implementation of ``is_individual`` defined in the SysML specification.

        **Specification**:

           Whether this ``OccurrenceUsage`` represents the usage of the specific
           individual represented by its ``individual_definition``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

    @is_individual.setter
    def is_individual(self, arg: bool, /) -> None: ...

    @property
    def portion_kind(self) -> PortionKind | None:
        """
        Implementation of ``portion_kind`` defined in the SysML specification.

        **Specification**:

           The kind of temporal portion (time slice or snapshot) is represented
           by this ``OccurrenceUsage``. If ``portion_kind`` is not null, then
           the ``owning_type`` of the ``OccurrenceUsage`` must be non-null, and
           the ``OccurrenceUsage`` represents portions of the featuring instance
           of the ``owning_type``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

    @portion_kind.setter
    def portion_kind(self, arg: PortionKind | None) -> None: ...

    @property
    def occurrence_definitions(self) -> LazyIterator[OccurrenceDefinition]:
        """
        Implementation of ``occurrence_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Classes`` that are the types of this ``OccurrenceUsage``.
           Nominally, these are ``OccurrenceDefinitions``, but other kinds of
           kernel ``Classes`` are also allowed, to permit use of ``Classes``
           from the Kernel Model Libraries.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

    @property
    def individual_definition(self) -> OccurrenceDefinition | None:
        """
        Implementation of ``individual_definition`` defined in the SysML
        specification.

        **Specification**:

           The at most one ``occurrence_definition`` that has
           ``is_individual = true``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

class Connector(Feature):
    """
    Implementation of ``Connector`` defined in the KerML specification.

    **Specification**:

       A ``Connector`` is a usage of ``Associations``, with links restricted
       according to instances of the ``Type`` in which they are used (domain
       of the ``Connector``). The ``associations`` of the ``Connector``
       restrict what kinds of things might be linked. The ``Connector``
       further restricts these links to be between values of ``Features`` on
       instances of its domain.

    For language description, see section
    `7.4.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=73>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=215>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Connector'

    STD: tuple[Union[type[Connector], type[ConnectorAsUsage]], ...] = (Connector, ConnectorAsUsage)

    if TYPE_CHECKING:
        Std = Union[Connector, ConnectorAsUsage]

    @property
    def declared_ends(self) -> ConnectorEnds:
        """
        Ends that are explicitly declared using textual syntax shorthand before the children block.
        """

    @property
    def related_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Features`` that are related by this ``Connector`` considered as
           a ``Relationship`` and that restrict the links it identifies, given
           by the referenced ``Features`` of the ``connector_ends`` of the
           ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=216>`__
        of the KerML specification for more details.
        """

    @property
    def associations(self) -> LazyIterator[ConnectionDefinition | Association]:
        """
        Implementation of ``association`` defined in the KerML specification.

        **Specification**:

           The ``Associations`` that type the ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=215>`__
        of the KerML specification for more details.
        """

    @property
    def connector_ends(self) -> LazyIterator[Feature]:
        """
        Implementation of ``connector_end`` defined in the KerML specification.

        **Specification**:

           The ``end_features`` of a ``Connector``, which redefine the
           ``end_features`` of the ``associations`` of the ``Connector``. The
           ``connector_ends`` determine via ``ReferenceSubsetting``
           ``Relationships`` which ``Features`` are related by the
           ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=215>`__
        of the KerML specification for more details.
        """

    @property
    def source_feature(self) -> Feature | None:
        """
        Implementation of ``source_feature`` defined in the KerML specification.

        **Specification**:

           The source ``related_feature`` for this ``Connector``. It is the
           first ``related_feature``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=216>`__
        of the KerML specification for more details.
        """

    @property
    def target_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target_feature`` defined in the KerML specification.

        **Specification**:

           The target ``related_features`` for this ``Connector``. This includes
           all the ``related_features`` other than the ``source_feature``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=216>`__
        of the KerML specification for more details.
        """

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def source(self) -> Feature | None:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> list[Feature]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def default_featuring_type(self) -> Type | None:
        """
        Implementation of ``default_featuring_type`` defined in the KerML
        specification.

        **Specification**:

           The innermost ``Type`` that is a common direct or indirect
           ``featuring_type`` of the ``related_features``, such that, if it
           exists and was the ``featuring_type`` of this ``Connector``, the
           ``Connector`` would satisfy the ``check_connector_type_featuring``
           constraint.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=215>`__
        of the KerML specification for more details.
        """

    @property
    def owned_related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

class ConnectorAsUsage(Usage):
    """
    Implementation of ``ConnectorAsUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``ConnectorAsUsage`` is both a ``Connector`` and a ``Usage``.
       ``ConnectorAsUsage`` cannot itself be instantiated in a SysML model,
       but it is a base class for the concrete classes
       ``BindingConnectorAsUsage``, ``SuccessionAsUsage``,
       ``ConnectionUsage`` and ``FlowUsage``.

    For language description, see section
    `7.13.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=93>`__
    of the SysML specification. For more details on the model, see section
    `8.3.13.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=333>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConnectorAsUsage'

    STD: tuple[type[ConnectorAsUsage], ...] = (ConnectorAsUsage,)

    if TYPE_CHECKING:
        Std = ConnectorAsUsage

    @property
    def is_message_connection(self) -> bool:
        """
        Ends that are explicitly declared using textual syntax shorthand before the children block.
        """

    @property
    def declared_ends(self) -> ConnectorAsUsageEnds:
        """
        Ends that are explicitly declared using textual syntax shorthand before the children block.
        """

    @property
    def related_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Features`` that are related by this ``Connector`` considered as
           a ``Relationship`` and that restrict the links it identifies, given
           by the referenced ``Features`` of the ``connector_ends`` of the
           ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=216>`__
        of the KerML specification for more details.
        """

    @property
    def associations(self) -> LazyIterator[ConnectionDefinition | Association]:
        """
        Implementation of ``association`` defined in the KerML specification.

        **Specification**:

           The ``Associations`` that type the ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=215>`__
        of the KerML specification for more details.
        """

    @property
    def connector_ends(self) -> LazyIterator[Feature]:
        """
        Implementation of ``connector_end`` defined in the KerML specification.

        **Specification**:

           The ``end_features`` of a ``Connector``, which redefine the
           ``end_features`` of the ``associations`` of the ``Connector``. The
           ``connector_ends`` determine via ``ReferenceSubsetting``
           ``Relationships`` which ``Features`` are related by the
           ``Connector``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=215>`__
        of the KerML specification for more details.
        """

    @property
    def source_feature(self) -> Feature | None:
        """
        Implementation of ``source_feature`` defined in the KerML specification.

        **Specification**:

           The source ``related_feature`` for this ``Connector``. It is the
           first ``related_feature``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=216>`__
        of the KerML specification for more details.
        """

    @property
    def target_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target_feature`` defined in the KerML specification.

        **Specification**:

           The target ``related_features`` for this ``Connector``. This includes
           all the ``related_features`` other than the ``source_feature``.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=216>`__
        of the KerML specification for more details.
        """

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def source(self) -> Feature | None:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> list[Feature]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def default_featuring_type(self) -> Type | None:
        """
        Implementation of ``default_featuring_type`` defined in the KerML
        specification.

        **Specification**:

           The innermost ``Type`` that is a common direct or indirect
           ``featuring_type`` of the ``related_features``, such that, if it
           exists and was the ``featuring_type`` of this ``Connector``, the
           ``Connector`` would satisfy the ``check_connector_type_featuring``
           constraint.

        See section
        `8.3.4.5.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=215>`__
        of the KerML specification for more details.
        """

    @property
    def owned_related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

class ConnectorAsUsageEnds(ConnectorEndsAccessor[EndFeatureMembership, Feature]):
    pass

class ConnectorEnds(ConnectorEndsAccessor[EndFeatureMembership, Feature]):
    pass

class ConnectorEndsAccessor[R: FeatureMembership, M: Feature](ChildrenNodesView[R, M]):
    @property
    def modifiable(self) -> bool:
        """
        Returns ``True`` if the contents of this accessor can be modified. In such a case, ``try_`` methods will
        return values, and corresponding modification methods will not raise ``ValueErrors``.

        ``False`` is returned when the corresponding textual syntax position is already occupied by other elements,
        e.g. ``FlowUsage`` ``declared_messages`` and ``declared_ends`` share the same position.
        """

    @overload
    def try_append(self, arg0: M, /) -> tuple[R, M] | None:
        """
        Try appending a new ``Feature``. Ownership constraints apply.

        Returns a pair of (``membership``, ``feature``) where ``feature`` is the argument passed in if the contents
        can be modified. Note that generally empty ``Features`` are not syntactically correct, and the correct
        syntax depends on the owner type.
        """

    @overload
    def try_append(self) -> tuple[R, M] | None:
        """
        Try appending a new default constructed ``Feature`` with type inferred from the corresponding member
        type in the textual syntax dependent on the owner of this accessor.

        Returns a pair of (``membership``, ``feature``) if the contents can be modified. Note that generally empty
        ``Features`` are not syntactically correct, and the correct syntax depends on the owner type.
        """

    @overload
    def try_insert(self, arg0: int, arg1: M, /) -> tuple[R, M] | None:
        """
        Try inserting a new ``Feature`` at the specified index. Ownership constraints apply.

        Returns a pair of (``membership``, ``feature``) where ``feature`` is the argument passed in if the contents
        can be modified. Note that generally empty ``Features`` are not syntactically correct, and the correct
        syntax depends on the owner type.
        """

    @overload
    def try_insert(self, arg0: int, /) -> tuple[R, M] | None:
        """
        Try inserting a new default constructed ``Feature`` at the index specified with type inferred from the corresponding member
        type in the textual syntax dependent on the owner of this accessor.

        Returns a pair of (``membership``, ``feature``) if the contents can be modified. Note that generally empty
        ``Features`` are not syntactically correct, and the correct syntax depends on the owner type.
        """

    @overload
    def append(self, arg0: M, /) -> tuple[R, M]:
        """
        Same as ``try_append`` but will raise ``ValueError`` if the contents cannot be modified.
        """

    @overload
    def append(self, /) -> tuple[R, M]: ...

    @overload
    def insert(self, arg0: int, arg1: M, /) -> tuple[R, M]:
        """
        Same as ``insert`` but will raise ``ValueError`` if the contents cannot be modified.
        """

    @overload
    def insert(self, arg0: int, /) -> tuple[R, M]: ...

    def clear(self) -> None:
        """
        Clear the contents accessed by this accessor. Does nothing if the contents cannot be modified.
        """

    def erase(self, arg: int, /) -> None:
        """
        Erase ``Feature`` at the specified index. Raises ``IndexError`` if the index is out of bounds.
        """

    def extract(self, arg0: int, /) -> M:
        """
        Extract ``Feature`` at the specified index. Raises ``IndexError`` if the index is out of bounds.
        """

class ConstraintDefinition(OccurrenceDefinition):
    """
    Implementation of ``ConstraintDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``ConstraintDefinition`` is an ``OccurrenceDefinition`` that is
       also a ``Predicate`` that defines a constraint that may be asserted
       to hold on a system or part of a system.

    For language description, see section
    `7.20.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=159>`__
    of the SysML specification. For more details on the model, see section
    `8.3.20.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=382>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConstraintDefinition'

    STD: tuple[type[ConstraintDefinition], ...] = (ConstraintDefinition,)

    if TYPE_CHECKING:
        Std = ConstraintDefinition

    @property
    def steps(self) -> LazyIterator[Step | ActionUsage | FlowUsage]:
        """
        Implementation of ``step`` defined in the KerML specification.

        **Specification**:

           The ``Steps`` that make up this ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The parameters of this ``Behavior``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Function`` can be used as the ``function`` of a
           model-level evaluable ``InvocationExpression``. Certain ``Functions``
           from the Kernel Functions Library are considered to have
           ``is_model_level_evaluable = true``. For all other ``Functions`` it
           is ``false``.

           **Note:** See the specification of the KerML concrete syntax notation
           for ``Expressions`` for an identification of which library
           ``Functions`` are model-level evaluable.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
        of the KerML specification for more details.
        """

    @property
    def expressions(self) -> LazyIterator[Expression | CalculationUsage | ConstraintUsage]:
        """
        Implementation of ``expression`` defined in the KerML specification.

        **Specification**:

           The ``Expressions`` that are ``steps`` in the calculation of the
           ``result`` of this ``Function``.

           The set of expressions that represent computational steps or parts of
           a system of equations within the Function.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           The object or value that is the result of evaluating the Function.

           The ``result`` ``parameter`` of the ``Function``, which is owned by
           the ``Function`` via a ``ReturnParameterMembership``.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
        of the KerML specification for more details.
        """

    @property
    def any_result(self) -> Feature | None:
        """``result`` that also considers specialized ``Functions``."""

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``Function`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class ConstraintUsage(OccurrenceUsage):
    """
    Implementation of ``ConstraintUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``ConstraintUsage`` is an ``OccurrenceUsage`` that is also a
       ``BooleanExpression``, and, so, is typed by a ``Predicate``.
       Nominally, if the type is a ``ConstraintDefinition``, a
       ``ConstraintUsage`` is a ``Usage`` of that ``ConstraintDefinition``.
       However, other kinds of kernel ``Predicates`` are also allowed, to
       permit use of ``Predicates`` from the Kernel Model Libraries.

    For language description, see section
    `7.20.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=159>`__
    of the SysML specification. For more details on the model, see section
    `8.3.20.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=383>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConstraintUsage'

    STD: tuple[type[ConstraintUsage], ...] = (ConstraintUsage,)

    if TYPE_CHECKING:
        Std = ConstraintUsage

    @property
    def constraint_definition(self) -> ConstraintDefinition | Predicate | None:
        """
        Implementation of ``constraint_definition`` defined in the SysML
        specification.

        **Specification**:

           The (single) ``Predicate`` that is the type of this
           ``ConstraintUsage``. Nominally, this will be a
           ``ConstraintDefinition``, but other kinds of ``Predicates`` are also
           allowed, to permit use of ``Predicates`` from the Kernel Model
           Libraries.

        See section
        `8.3.20.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=383>`__
        of the SysML specification for more details.
        """

    @property
    def behaviors(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``behavior`` defined in the KerML specification.

        **Specification**:

           The ``Behaviors`` that type this ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

    @property
    def owned_parameters(self) -> LazyIterator[Feature]:
        """The ``parameters`` owned by this ``Step``."""

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The ``parameters`` of this ``Step``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Expression`` meets the constraints necessary to be
           evaluated at *model level*, that is, using metadata within the model.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def function(self) -> Function | CalculationDefinition | ConstraintDefinition | None:
        """
        Implementation of ``function`` defined in the KerML specification.

        **Specification**:

           The ``Function`` that types this ``Expression``.

           This is the Function that types the Expression.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           An ``output`` ``parameter`` of the ``Expression`` whose value is the
           result of the ``Expression``. The result of an ``Expression`` is
           either inherited from its ``function`` or it is related to the
           ``Expression`` via a ``ReturnParameterMembership``, in which case it
           redefines the ``result`` ``parameter`` of its ``function``.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def predicate(self) -> Predicate | ConstraintDefinition | None:
        """
        Implementation of ``predicate`` defined in the KerML specification.

        **Specification**:

           The Predicate that types the Expression.

           The ``Predicate`` that types this ``BooleanExpression``.

        See section
        `8.3.4.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``ConstraintUsage`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class ConstructorExpression(InstantiationExpression):
    """
    Implementation of ``ConstructorExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``ConstructorExpression`` is an ``InstantiationExpression`` whose
       ``result`` specializes its ``instantiated_type``, binding some or all
       of the ``features`` of the ``instantiated_type`` to the ``results``
       of its ``argument`` ``Expressions``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=232>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ConstructorExpression'

    STD: tuple[type[ConstructorExpression], ...] = (ConstructorExpression,)

    if TYPE_CHECKING:
        Std = ConstructorExpression

class ContainerView(Sequence[T]):
    """
    An immutable view into a native random-access container. Implements Sequence protocol.
    """

    def __contains__(self, value: object) -> bool: ...

    @overload
    def __getitem__(self, index: int) -> T: ...

    @overload
    def __getitem__(self, index: slice) -> list[T]: ...

    @overload
    def at(self, arg: int, /) -> T | None: ...

    @overload
    def at(self, arg0: int, arg1: T, /) -> T: ...

    def __iter__(self) -> Iterator[T]: ...

    def __reversed__(self) -> Iterator[T]: ...

    def __len__(self) -> int: ...

    def __bool__(self) -> bool: ...

    def empty(self) -> bool: ...

    def count(self, value: T) -> int: ...

    def index(self, value: T, start: int = 0, stop: int | None = None) -> int: ...

    def __str__(self) -> str: ...

class ControlNode(ActionUsage):
    """
    Implementation of ``ControlNode`` defined in the SysML specification.

    **Specification**:

       A ``ControlNode`` is an ``ActionUsage`` that does not have any
       inherent behavior but provides constraints on incoming and outgoing
       ``Successions`` that are used to control other ``Actions``. A
       ``ControlNode`` must be a composite owned ``usage`` of an
       ``ActionDefinition`` or ``ActionUsage``.

    For language description, see section
    `7.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=132>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=350>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ControlNode'

    STD: tuple[type[ControlNode], ...] = (ControlNode,)

    if TYPE_CHECKING:
        Std = ControlNode

class CrossSubsetting(Subsetting):
    r"""
    Implementation of ``CrossSubsetting`` defined in the KerML
    specification.

    **Specification**:

       ``CrossSubsetting`` is a kind of ``Subsetting`` for end ``Features``,
       as identified by ``crossing_feature``, to subset a chained
       ``Feature``, identified by ``crossed_feature.`` It navigates to
       instances of the end ``Feature``\ ’s type from instances of other end
       ``Feature`` types on the same ``owning_type`` (at least two end
       ``Features`` are required for any of them to have a
       ``CrossSubsetting``).

       The ``crossed_feature`` of a ``CrossSubsetting`` must have a feature
       chain of exactly two ``Features``. The second ``Feature`` in the
       chain is the ``cross_feature`` of the ``crossing_feature`` (end
       ``Feature``), which has the same type as the ``crossing_feature``.
       When the ``owning_type`` of the ``crossing_feature`` has exactly two
       end ``Features``, the first ``Feature`` in the chain of the
       ``crossed_feature`` is the other end ``Feature``. The
       ``cross_feature``\ ’s ``featuring_type`` in this case is the other
       end ``Feature``. When the ``owning_type`` has more than two end
       ``Features``, the first ``Feature`` in the chain is a ``Feature``
       that ``CrossMultiplies`` all the other end ``Features``, which is
       also the ``featuring_type`` of the ``cross_feature``.

       A ``cross_feature`` must be owned by its ``feature_crossing`` (end
       ``Feature``) when the ``feature_crossing`` ``owning_type`` has more
       than two end ``Features``. Otherwise, for exactly two end
       ``Features``, the ``cross_features`` of each the ends can instead
       optionally be inherited by the other end from one of its ``types`` or
       a subsetted ``Feature``.

    For language description, see section
    `7.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=74>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::CrossSubsetting'

    STD: tuple[type[CrossSubsetting], ...] = (CrossSubsetting,)

    if TYPE_CHECKING:
        Std = CrossSubsetting

    CHAINABLE: bool = True

    @property
    def crossed_feature(self) -> Feature | None:
        """
        Implementation of ``crossed_feature`` defined in the KerML
        specification.

        **Specification**:

           The chained ``Feature`` that is cross subset by the
           ``crossing_feature`` of this ``CrossSubsetting``.

        See section
        `8.3.3.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.
        """

    @property
    def crossing_feature(self) -> Feature | None:
        """
        Implementation of ``crossing_feature`` defined in the KerML
        specification.

        **Specification**:

           The end ``Feature`` that owns this ``CrossSubsetting`` relationship
           and is also its subsetting_feature.

        See section
        `8.3.3.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=186>`__
        of the KerML specification for more details.
        """

    @property
    def crossed_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``crossed_feature``.
        """

    @property
    def crossing_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``crossing_feature``.
        """

class CstNode:
    @property
    def id(self) -> int: ...

    @property
    def type(self) -> str: ...

    @property
    def symbol(self) -> Symbol: ...

    @property
    def grammar_type(self) -> str: ...

    @property
    def grammar_symbol(self) -> Symbol: ...

    @property
    def start_byte(self) -> int: ...

    @property
    def start_point(self) -> PositionUtf8: ...

    @property
    def end_byte(self) -> int: ...

    @property
    def end_point(self) -> PositionUtf8: ...

    @property
    def string(self) -> str: ...

    @property
    def is_named(self) -> bool: ...

    @property
    def is_missing(self) -> bool: ...

    @property
    def is_extra(self) -> bool: ...

    @property
    def has_changes(self) -> bool: ...

    @property
    def has_error(self) -> bool: ...

    @property
    def is_error(self) -> bool: ...

    @property
    def parse_state(self) -> StateId: ...

    @property
    def next_parse_state(self) -> StateId: ...

    def field_name_for_child(self, arg: int, /) -> str | None: ...

    @property
    def child_count(self) -> int: ...

    @property
    def named_child_count(self) -> int: ...

    @property
    def descendant_count(self) -> int: ...

    def text(self, arg: str, /) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'tree_sitter::Node'

DESERIALIZE_INTERNAL: AttributeMap = ...

DESERIALIZE_STANDARD: AttributeMap = ...

class DataType(Classifier):
    """
    Implementation of ``DataType`` defined in the KerML specification.

    **Specification**:

       A ``DataType`` is a ``Classifier`` of things (in the universe) that
       can only be distinguished by how they are related to other things
       (via Features). This means multiple things classified by the same
       ``DataType``

       - Cannot be distinguished when they are related to other things in
         exactly the same way, even when they are intended to be about
         different things.
       - Can be distinguished when they are related to other things in
         different ways, even when they are intended to be about the same
         thing.

    For language description, see section
    `7.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=66>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=208>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::DataType'

    STD: tuple[Union[type[DataType], type[AttributeDefinition]], ...] = (DataType, AttributeDefinition)

    if TYPE_CHECKING:
        Std = Union[DataType, AttributeDefinition]

class DecisionNode(ControlNode):
    """
    Implementation of ``DecisionNode`` defined in the SysML specification.

    **Specification**:

       A ``DecisionNode`` is a ``ControlNode`` that makes a selection from
       its outgoing ``Successions``.

    For language description, see section
    `7.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=132>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=351>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::DecisionNode'

    STD: tuple[type[DecisionNode], ...] = (DecisionNode,)

    if TYPE_CHECKING:
        Std = DecisionNode

class Definition(Classifier):
    """
    Implementation of ``Definition`` defined in the SysML specification.

    **Specification**:

       A ``Definition`` is a ``Classifier`` of ``Usages``. The actual kinds
       of ``Definition`` that may appear in a model are given by the
       subclasses of ``Definition`` (possibly as extended with user-defined
       ``SemanticMetadata``).

       Normally, a ``Definition`` has owned Usages that model ``features``
       of the thing being defined. A ``Definition`` may also have other
       ``Definitions`` nested in it, but this has no semantic significance,
       other than the nested scoping resulting from the ``Definition`` being
       considered as a ``Namespace`` for any nested ``Definitions``.

       However, if a ``Definition`` has ``is_variation`` = ``true``, then it
       represents a *variation point* ``Definition``. In this case, all of
       its ``members`` must be ``variant`` ``Usages``, related to the
       ``Definition`` by ``VariantMembership`` ``Relationships``. Rather
       than being ``features`` of the ``Definition``, ``variant`` ``Usages``
       model different concrete alternatives that can be chosen to fill in
       for an abstract ``Usage`` of the variation point ``Definition``.

    For language description, see section
    `7.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=61>`__
    of the SysML specification. For more details on the model, see section
    `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=295>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::Definition'

    STD: tuple[type[Definition], ...] = (Definition,)

    if TYPE_CHECKING:
        Std = Definition

    @property
    def is_variation(self) -> bool:
        """
        Implementation of ``is_variation`` defined in the SysML specification.

        **Specification**:

           Whether this ``Definition`` is for a variation point or not. If true,
           then all the ``memberships`` of the ``Definition`` must be
           ``VariantMemberships``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.


        The setter will throw ``TypeError`` on types that are implicitly variations already, e.g. ``EnumerationDefinition``.
        Use ``try_set_is_variation`` instead for a non-throwing behaviour.
        """

    @is_variation.setter
    def is_variation(self, arg: bool, /) -> None: ...

    def try_set_is_variation(self, arg: bool, /) -> bool:
        """
        Try setting ``is_variation``. For types that are implicitly variations, this will return ``False`` instead of throwing ``TypeError`` when using ``is_variation`` setter.
        """

    @property
    def variants(self) -> LazyIterator[Usage]:
        """
        Implementation of ``variant`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` which represent the variants of this ``Definition`` as
           a variation point ``Definition``, if ``is_variation`` = true. If
           ``is_variation = false``, the there must be no ``variants``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=298>`__
        of the SysML specification for more details.
        """

    @property
    def variant_memberships(self) -> LazyIterator[VariantMembership]:
        r"""
        Implementation of ``variant_membership`` defined in the SysML
        specification.

        **Specification**:

           The ``owned_memberships`` of this ``Definition`` that are
           ``VariantMemberships``. If ``is_variation`` = true, then this must be
           all ``owned_memberships`` of the ``Definition``. If ``is_variation``
           = false, then ``variant_membership``\ must be empty.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=298>`__
        of the SysML specification for more details.
        """

    @property
    def usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``usage`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that are ``features`` of this ``Definition`` (not
           necessarily owned).

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=298>`__
        of the SysML specification for more details.
        """

    @property
    def directed_usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``directed_usage`` defined in the SysML specification.

        **Specification**:

           The ``usages`` of this ``Definition`` that are ``directed_features``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``owned_usage`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that are ``owned_features`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=298>`__
        of the SysML specification for more details.
        """

    @property
    def owned_references(self) -> LazyIterator[ReferenceUsage]:
        """
        Implementation of ``owned_reference`` defined in the SysML
        specification.

        **Specification**:

           The ``ReferenceUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_attributes(self) -> LazyIterator[AttributeUsage]:
        """
        Implementation of ``owned_attribute`` defined in the SysML
        specification.

        **Specification**:

           The ``AttributeUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_enumerations(self) -> LazyIterator[EnumerationUsage]:
        """
        Implementation of ``owned_enumeration`` defined in the SysML
        specification.

        **Specification**:

           The ``EnumerationUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_occurrences(self) -> LazyIterator[OccurrenceUsage]:
        """
        Implementation of ``owned_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_items(self) -> LazyIterator[ItemUsage]:
        """
        Implementation of ``owned_item`` defined in the SysML specification.

        **Specification**:

           The ``ItemUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_parts(self) -> LazyIterator[PartUsage | ConnectionUsage]:
        """
        Implementation of ``owned_part`` defined in the SysML specification.

        **Specification**:

           The ``PartUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_ports(self) -> LazyIterator[PortUsage]:
        """
        Implementation of ``owned_port`` defined in the SysML specification.

        **Specification**:

           The ``PortUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_connections(self) -> LazyIterator[ConnectorAsUsage]:
        """
        Implementation of ``owned_connection`` defined in the SysML
        specification.

        **Specification**:

           The ``ConnectorAsUsages`` that are ``owned_usages`` of this
           ``Definition``. Note that this list includes
           ``BindingConnectorAsUsages``, ``SuccessionAsUsages``, and
           ``FlowUsages`` because these are ``ConnectorAsUsages`` even though
           they are not ``ConnectionUsages``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_flows(self) -> LazyIterator[FlowUsage]:
        """
        Implementation of ``owned_flow`` defined in the SysML specification.

        **Specification**:

           The ``FlowUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_interfaces(self) -> LazyIterator[InterfaceUsage]:
        """
        Implementation of ``owned_interface`` defined in the SysML
        specification.

        **Specification**:

           The ``InterfaceUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_allocations(self) -> LazyIterator[AllocationUsage]:
        """
        Implementation of ``owned_allocation`` defined in the SysML
        specification.

        **Specification**:

           The ``AllocationUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_actions(self) -> LazyIterator[ActionUsage | FlowUsage]:
        """
        Implementation of ``owned_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_states(self) -> LazyIterator[StateUsage]:
        """
        Implementation of ``owned_state`` defined in the SysML specification.

        **Specification**:

           The ``StateUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_transitions(self) -> LazyIterator[TransitionUsage]:
        """
        Implementation of ``owned_transition`` defined in the SysML
        specification.

        **Specification**:

           The ``TransitionUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=298>`__
        of the SysML specification for more details.
        """

    @property
    def owned_calculations(self) -> LazyIterator[CalculationUsage]:
        """
        Implementation of ``owned_calculation`` defined in the SysML
        specification.

        **Specification**:

           The ``CalculationUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``owned_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_concerns(self) -> LazyIterator[ConcernUsage]:
        """
        Implementation of ``owned_concern`` defined in the SysML specification.

        **Specification**:

           The ``ConcernUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_cases(self) -> LazyIterator[CaseUsage]:
        """
        Implementation of ``owned_case`` defined in the SysML specification.

        **Specification**:

           The code>CaseUsages that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_verification_cases(self) -> LazyIterator[VerificationCaseUsage]:
        """
        Implementation of ``owned_verification_case`` defined in the SysML
        specification.

        **Specification**:

           The ``VerificationCaseUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=298>`__
        of the SysML specification for more details.
        """

    @property
    def owned_use_cases(self) -> LazyIterator[UseCaseUsage]:
        """
        Implementation of ``owned_use_case`` defined in the SysML specification.

        **Specification**:

           The ``UseCaseUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=298>`__
        of the SysML specification for more details.
        """

    @property
    def owned_views(self) -> LazyIterator[ViewUsage]:
        """
        Implementation of ``owned_view`` defined in the SysML specification.

        **Specification**:

           The ``ViewUsages`` that are ``owned_usages`` of this ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=298>`__
        of the SysML specification for more details.
        """

    @property
    def owned_viewpoints(self) -> LazyIterator[ViewpointUsage]:
        """
        Implementation of ``owned_viewpoint`` defined in the SysML
        specification.

        **Specification**:

           The ``ViewpointUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=298>`__
        of the SysML specification for more details.
        """

    @property
    def owned_renderings(self) -> LazyIterator[RenderingUsage]:
        """
        Implementation of ``owned_rendering`` defined in the SysML
        specification.

        **Specification**:

           The ``RenderingUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_metadata(self) -> LazyIterator[MetadataUsage]:
        """
        Implementation of ``owned_metadata`` defined in the SysML specification.

        **Specification**:

           The ``MetadataUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

    @property
    def owned_analysis_cases(self) -> LazyIterator[AnalysisCaseUsage]:
        """
        Implementation of ``owned_analysis_case`` defined in the SysML
        specification.

        **Specification**:

           The ``AnalysisCaseUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=296>`__
        of the SysML specification for more details.
        """

    @property
    def owned_requirements(self) -> LazyIterator[RequirementUsage]:
        """
        Implementation of ``owned_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsages`` that are ``owned_usages`` of this
           ``Definition``.

        See section
        `8.3.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=297>`__
        of the SysML specification for more details.
        """

class Dependency(Relationship):
    """
    Implementation of ``Dependency`` defined in the KerML specification.

    **Specification**:

       A ``Dependency`` is a ``Relationship`` that indicates that one or
       more ``client`` ``Elements`` require one more ``supplier``
       ``Elements`` for their complete specification. In general, this means
       that a change to one of the ``supplier`` ``Elements`` may necessitate
       a change to, or re-specification of, the ``client`` ``Elements``.

       Note that a ``Dependency`` is entirely a model-level
       ``Relationship``, without instance-level semantics.

    For language description, see section
    `7.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=43>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=145>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Dependency'

    STD: tuple[type[Dependency], ...] = (Dependency,)

    if TYPE_CHECKING:
        Std = Dependency

    @property
    def prefixes(self) -> DependencyPrefixes:
        """Metadata prefixes, prefixed with ``#`` in textual syntax."""

    @property
    def clients(self) -> DependencyEnds:
        """
        Implementation of ``client`` defined in the KerML specification.

        **Specification**:

           The ``Element`` or ``Elements`` dependent on the ``supplier``
           ``Elements``.

        See section
        `8.3.2.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=145>`__
        of the KerML specification for more details.
        """

    @property
    def suppliers(self) -> DependencyEnds:
        """
        Implementation of ``supplier`` defined in the KerML specification.

        **Specification**:

           The ``Element`` or ``Elements`` on which the ``client`` ``Elements``
           depend in some respect.

        See section
        `8.3.2.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=145>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def owning_related_element(self) -> Element | None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> ContainerView[Element]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> ContainerView[Element]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

class DependencyEnds(ContainerView[Element]):
    def append(self, element: Element, name: NameID = NameID.Regular) -> None:
        """Append a new reference to this container."""

    def replace_at(self, index: int, element: Element, name: NameID = NameID.Regular) -> Element:
        """
        Replace reference element at ``index`` with ``element``. Returns the previously referenced element.

        Raises ``IndexError`` if ``index`` is out-of-bounds.
        """

    def pop(self, index: int = -1) -> Element:
        """
        Pop and return the reference element at ``index``. By default, the last reference is popped.

        Raises ``ValueError`` if the ``index`` is out of bounds.
        """

    def remove(self, arg: Element, /) -> bool:
        """
        Remove the referenced element. Returns ``True`` if the element was removed, and ``False`` otherwise.
        """

    def clear(self) -> None:
        """
        Clear all references from this container. Note that empty references cannot be represented
        in textual syntax, and is a semantic violation.
        """

class DependencyPrefixes(OwnedChildrenNodes[Annotation, MetadataFeature | MetadataUsage]):
    @overload
    def append[R: Annotation, M: MetadataFeature | MetadataUsage](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    @overload
    def append[R: Annotation, M: MetadataFeature | MetadataUsage](self, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Append a new *owned* element. Relationship must be a subtype of ``OwningMembership`` or ``Annotation``. Returns a
        newly constructed pair of (relationship, element) with the types provided.
        """

    @overload
    def replace[R: Annotation, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def replace[R: Annotation, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element must be *owned* so the same owning
        ``append`` limitations apply.
        """

    @overload
    def insert[R: Annotation, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def insert[R: Annotation, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element must be *owned* so the
        same owning ``append`` limitations apply.
        """

class DeserializedModel:
    """
    The model as it was deserialized, with references potentially unresolved.
    """

    @property
    def document(self) -> Document:
        """The document model was deserialized into"""

    @property
    def root(self) -> Element:
        """
        The root node of the deserialized model. Note that this may be an orphan node.
        """

    @property
    def pending_references(self) -> ContainerView[PendingReference]:
        """
        Currently unresolved pending references. These need to be resolved in a separate post-deserialization step
        to correctly resolve (potentially cyclical) dependencies between models.
        """

    def link(self, resolve: Callable[[str, uuid.UUID], Element | None]) -> tuple[SerdeReport[DocumentSegment | str | Element], bool]:
        """
        Attempt to resolve any pending references using custom ``resolve``. Signature is

        .. code-block:: python

            def resolve(uri: str, element_id: uuid.UUID) -> Element | None: ...

        Returns a pair of ``report`` and ``success``, whether all pending references have been resolved.
        Use ``pending_references`` again to get references that failed to resolve.
        """

class Deserializer:
    """
    Deserializer for SysML models. The actual deserialization input depends on used ``Reader``.

    Note that unlike ``Serializer`` deserialization cannot be completed in a single pass in general
    because documents may form reference cycles with each other. The typical deserialization pattern will be

    .. code-block:: python

        des = Deserializer(document)
        model, report = des.accept(reader, DESERIALIZE_STANDARD)
        # ... collect all valid element ids for linking
        link_report, all_linked = model.link(my_reference_resolve)
    """

    def __init__(self, document: Document) -> None:
        """
        Construct a new deserializer that will deserialize models into the provided ``document``.
        """

    @overload
    def accept(self, reader: Reader, attributes: AttributeMap) -> tuple[DeserializedModel, SerdeReport[DocumentSegment | str | Element]]:
        """
        Accept a ``reader`` for deserialization into currently bound ``document``.
        Returns the deserialized model, or raises a ``RuntimeError``. ``document`` without a
        :py:class:`Url <syside.Url>` with scheme will emit a warning that relative URIs will not be
        resolvable.

        Note that cross-references may not be resolved, and instead replaced by placeholder element references due
        to potential reference cycles between documents. Call ``link`` on the returned model when dependent documents
        have been loaded.
        """

    @overload
    def accept(self, document: Document, reader: Reader, attributes: AttributeMap) -> tuple[DeserializedModel, SerdeReport[DocumentSegment | str | Element]]:
        """
        Accept ``reader`` for deserialization into ``document``. Equivalent to

        .. code-block:: python

            deserializer.reset(document)
            return deserializer.accept(reader, attributes)

        Returns the deserialized model, or raises ``RuntimeError``.
        """

    @property
    def document(self) -> Document:
        """The document bound to this deserializer"""

    def reset(self, document: Document) -> None:
        """
        Reset the deserializer. Rebinds to the ``document`` and resets this ``Deserializer`` for new deserialization.
        """

class Diagnostic:
    def __init__(self, segment: DocumentSegment, code: str | str, message: str, severity: DiagnosticSeverity = DiagnosticSeverity.Error) -> None: ...

    @property
    def segment(self) -> DocumentSegment: ...

    @segment.setter
    def segment(self, arg: DocumentSegment, /) -> None: ...

    @property
    def code(self) -> str | str: ...

    @code.setter
    def code(self, arg: str | str, /) -> None: ...

    @property
    def message(self) -> str: ...

    @message.setter
    def message(self, arg: str, /) -> None: ...

    @property
    def severity(self) -> DiagnosticSeverity: ...

    @severity.setter
    def severity(self, arg: DiagnosticSeverity, /) -> None: ...

    @property
    def is_unnecessary(self) -> bool: ...

    @is_unnecessary.setter
    def is_unnecessary(self, arg: bool, /) -> None: ...

    @property
    def is_deprecated(self) -> bool: ...

    @is_deprecated.setter
    def is_deprecated(self, arg: bool, /) -> None: ...

    @property
    def code_description(self) -> CodeDescription | None: ...

    @code_description.setter
    def code_description(self, arg: CodeDescription | None) -> None: ...

    @property
    def source(self) -> str | None: ...

    @source.setter
    def source(self, arg: str | None) -> None: ...

    @property
    def related_information(self) -> ContainerView[DiagnosticRelatedInformation]: ...

    def append_related_information(self, arg: DiagnosticRelatedInformation, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Diagnostic'

class DiagnosticContext:
    def __init__(self, source: str = '', filename: str = '', related_sources: Callable[[Url], str | SharedMutex[TextDocument]] | TextDocuments | None = None) -> None: ...

    @property
    def source(self) -> str: ...

    @source.setter
    def source(self, arg: str, /) -> None: ...

    @property
    def filename(self) -> str: ...

    @filename.setter
    def filename(self, arg: str, /) -> None: ...

    @property
    def related_sources(self) -> Callable[[Url], str | SharedMutex[TextDocument]] | TextDocuments: ...

    @related_sources.setter
    def related_sources(self, arg: Callable[[Url], str | SharedMutex[TextDocument]] | TextDocuments, /) -> None: ...

    __cpp_name__: str = 'syside::py::PyDiagnosticContext'

class DiagnosticFormatOptions:
    def __init__(self, indent: int = 0, tab_size: int = 4, underline: str = '^', colours: bool = False, draw_tree: TreeDrawing = TreeDrawing.No) -> None: ...

    @property
    def indent(self) -> int: ...

    @indent.setter
    def indent(self, arg: int, /) -> None: ...

    @property
    def tab_size(self) -> int: ...

    @tab_size.setter
    def tab_size(self, arg: int, /) -> None: ...

    @property
    def underline(self) -> str: ...

    @underline.setter
    def underline(self, arg: str, /) -> None: ...

    @property
    def colours(self) -> bool: ...

    @colours.setter
    def colours(self, arg: bool, /) -> None: ...

    @property
    def draw_tree(self) -> TreeDrawing: ...

    @draw_tree.setter
    def draw_tree(self, arg: TreeDrawing, /) -> None: ...

    __cpp_name__: str = 'syside::DiagnosticFormatOptions'

class DiagnosticRelatedInformation:
    def __init__(self, uri: Url, segment: DocumentSegment, message: str, depth: int = 0) -> None: ...

    @property
    def uri(self) -> Url: ...

    @uri.setter
    def uri(self, arg: Url, /) -> None: ...

    @property
    def segment(self) -> DocumentSegment: ...

    @segment.setter
    def segment(self, arg: DocumentSegment, /) -> None: ...

    @property
    def message(self) -> str: ...

    @message.setter
    def message(self, arg: str, /) -> None: ...

    @property
    def depth(self) -> int: ...

    @depth.setter
    def depth(self, arg: int, /) -> None: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::DiagnosticRelatedInformation'

class DiagnosticResults:
    @property
    def parser(self) -> ContainerView[Diagnostic]: ...

    @property
    def sema(self) -> ContainerView[Diagnostic]: ...

    @property
    def validation(self) -> ContainerView[Diagnostic]: ...

    def passed(self, warnings_as_errors: bool = False) -> bool: ...

    @property
    def empty(self) -> bool:
        """Returns True if all diagnostic categories are empty"""

    def __bool__(self) -> bool:
        """Returns True if there are no Error diagnostics"""

    __cpp_name__: str = 'syside::DiagnosticResults'

class DiagnosticSeverity(enum.IntEnum):
    Error = 1

    Warning = 2

    Information = 3

    Hint = 4

class Differencing(Relationship):
    """
    Implementation of ``Differencing`` defined in the KerML specification.

    **Specification**:

       ``Differencing`` is a ``Relationship`` that makes its
       ``differencing_type`` one of the ``differencing_types`` of its
       ``type_differenced``.

    For language description, see section
    `7.3.2.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=56>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=167>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Differencing'

    STD: tuple[type[Differencing], ...] = (Differencing,)

    if TYPE_CHECKING:
        Std = Differencing

    CHAINABLE: bool = True

    @property
    def differencing_type(self) -> Type | None:
        """
        Implementation of ``differencing_type`` defined in the KerML
        specification.

        **Specification**:

           ``Type`` that partly determines interpretations of
           ``type_differenced``, as described in ``Type::differencing_type``.

        See section
        `8.3.3.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=167>`__
        of the KerML specification for more details.
        """

    @property
    def type_differenced(self) -> Type | None:
        """
        Implementation of ``type_differenced`` defined in the KerML
        specification.

        **Specification**:

           ``Type`` with interpretations partly determined by
           ``differencing_type``, as described in ``Type::differencing_type``.

        See section
        `8.3.3.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=167>`__
        of the KerML specification for more details.
        """

class Disjoining(Relationship):
    """
    Implementation of ``Disjoining`` defined in the KerML specification.

    **Specification**:

       A ``Disjoining`` is a ``Relationship`` between ``Types`` asserted to
       have interpretations that are not shared (disjoint) between them,
       identified as ``type_disjoined`` and ``disjoining_type``. For
       example, a ``Classifier`` for mammals is disjoint from a
       ``Classifier`` for minerals, and a ``Feature`` for people’s parents
       is disjoint from a ``Feature`` for their children.

    For language description, see section
    `7.3.2.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=55>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=167>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Disjoining'

    STD: tuple[type[Disjoining], ...] = (Disjoining,)

    if TYPE_CHECKING:
        Std = Disjoining

    CHAINABLE: bool = True

    @property
    def disjoining_type(self) -> Type | None:
        """
        Implementation of ``disjoining_type`` defined in the KerML
        specification.

        **Specification**:

           ``Type`` asserted to be disjoint with the ``type_disjoined``.

        See section
        `8.3.3.1.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=167>`__
        of the KerML specification for more details.
        """

    @property
    def type_disjoined(self) -> Type | None:
        """
        Implementation of ``type_disjoined`` defined in the KerML specification.

        **Specification**:

           ``Type`` asserted to be disjoint with the ``disjoining_type``.

        See section
        `8.3.3.1.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=167>`__
        of the KerML specification for more details.
        """

    @property
    def owning_type(self) -> Type | None:
        """
        Implementation of ``owning_type`` defined in the KerML specification.

        **Specification**:

           A ``type_disjoined`` that is also an ``owning_related_element``.

        See section
        `8.3.3.1.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=167>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def disjoining_type_target(self) -> ChainedTypeReference:
        """
        Syside specific accessor for manipulating the target of ``disjoining_type``.
        """

    @property
    def type_disjoined_target(self) -> ChainedTypeReference:
        """
        Syside specific accessor for manipulating the target of ``type_disjoined``.
        """

class Document(BasicDocument):
    @property
    def root_node(self) -> Namespace: ...

    def nodes(self, kind: type[TElement]) -> Iterable[TElement]:
        """
        Returns the iterator to nodes in this documents that are instances of ``kind``, excluding any subtypes.
        """

    def all_nodes(self, kind: type[TElement]) -> Iterable[TElement]:
        """
        Returns the iterator to all nodes in this document that are instances of ``kind``, including all subtypes.
        """

    @staticmethod
    def parse_string_st(source: str, language: ModelLanguage) -> tuple[SharedMutex[Document], list[Diagnostic]]:
        """
        Parse a document from string for single-threaded applications without resolving references. Note that this
        disables GIL optimization during ``Executor.run`` using this document.
        """

    @staticmethod
    def parse_string_mt(source: str, language: ModelLanguage) -> tuple[SharedMutex[Document], list[Diagnostic]]:
        """
        Parse a document from string for multi-threaded applications without resolving references. This allows the
        ``Executor`` to release GIL during execution allowing other Python threads to execute in the meantime but only
        if all the other documents were also created with ``create_mt``.
        """

    @overload
    @staticmethod
    def create_st() -> SharedMutex[Document]:
        """
        Create a document for single-threaded applications. Note that this disables GIL optimization during
        ``Executor.run`` using this document.
        """

    @overload
    @staticmethod
    def create_st(arg: DocumentOptions, /) -> SharedMutex[Document]: ...

    @overload
    @staticmethod
    def create_st(url: Url, language: ModelLanguage, tier: DocumentTier = DocumentTier.Project, document_id: DocumentID | None = None, owning_library: LibraryID | None = None) -> SharedMutex[Document]: ...

    @overload
    @staticmethod
    def create_mt() -> SharedMutex[Document]:
        """
        Create a document for multi-threaded applications. This allows the ``Executor`` to release GIL during execution
        allowing other Python threads to execute in the meantime but only if all the other documents were also created
        with ``create_mt``.
        """

    @overload
    @staticmethod
    def create_mt(arg: DocumentOptions, /) -> SharedMutex[Document]: ...

    @overload
    @staticmethod
    def create_mt(url: Url, language: ModelLanguage, tier: DocumentTier = DocumentTier.Project, document_id: DocumentID | None = None, owning_library: LibraryID | None = None) -> SharedMutex[Document]: ...

    __cpp_name__: str = 'syside::Document<syside::sysml::SysMLTraits>'

class DocumentID:
    def __init__(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __index__(self) -> int: ...

    def __hash__(self) -> int: ...

    @staticmethod
    def reserve_new() -> DocumentID: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::DocumentID'

class DocumentOptions:
    def __init__(self, url: Url, language: str = 'plaintext', tier: DocumentTier = DocumentTier.Project, document_id: DocumentID = ..., owning_library: LibraryID | None = None) -> None: ...

    @property
    def url(self) -> Url: ...

    @url.setter
    def url(self, arg: Url, /) -> None: ...

    @property
    def language(self) -> str: ...

    @language.setter
    def language(self, arg: str, /) -> None: ...

    @property
    def tier(self) -> DocumentTier: ...

    @tier.setter
    def tier(self, arg: DocumentTier, /) -> None: ...

    @property
    def document_id(self) -> DocumentID: ...

    @document_id.setter
    def document_id(self, arg: DocumentID, /) -> None: ...

    @property
    def owning_library(self) -> LibraryID | None: ...

    @owning_library.setter
    def owning_library(self, arg: LibraryID | None) -> None: ...

    __cpp_name__: str = 'syside::DocumentOptions'

class DocumentSegment:
    def __init__(self, range: RangeUtf8 = ..., offset: int = 0, end: int = 0) -> None: ...

    @property
    def range(self) -> RangeUtf8: ...

    @range.setter
    def range(self, arg: RangeUtf8, /) -> None: ...

    @property
    def offset(self) -> int: ...

    @offset.setter
    def offset(self, arg: int, /) -> None: ...

    @property
    def end(self) -> int: ...

    @end.setter
    def end(self, arg: int, /) -> None: ...

    @staticmethod
    def from_cst(arg: CstNode, /) -> DocumentSegment: ...

    @staticmethod
    def from_cst_start(arg: CstNode, /) -> DocumentSegment: ...

    @staticmethod
    def from_cst_end(arg: CstNode, /) -> DocumentSegment: ...

    @staticmethod
    def from_node(arg: AstNode, /) -> DocumentSegment:
        """
        Construct ``DocumentSegment`` from the nearest CST node that contains ``node``.
        """

    @staticmethod
    def from_node_field(node: AstNode, field: str, index: int = 0) -> DocumentSegment:
        """
        Construct ``DocumentSegment`` from a ``tree-sitter`` field named ``field`` at ``index``. If ``node``
        does not contain a CST node with a matching ``field``, the nearest CST segment is returned instead.
        """

    @staticmethod
    def from_node_symbol(node: AstNode, symbol: str, index: int = 0) -> DocumentSegment:
        """
        Construct ``DocumentSegment`` from a ``tree-sitter`` symbol named ``symbol`` at ``index``. If ``node``
        does not contain a CST node with a matching ``symbol``, the nearest CST segment is returned instead.
        """

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::DocumentSegment'

class DocumentState(enum.IntEnum):
    Created = 0
    """Document has been created"""

    Building = 1
    """Document is being built"""

    Completed = 2
    """Document was built successfully"""

    Cancelled = 3
    """Document building was cancelled"""

    Error = 4
    """Document building errored"""

class DocumentTier(enum.Enum):
    StandardLibrary = 0
    """
    Document is a part of standard library. Assume that such documents change very rarely, or only change with new tool versions.
    """

    External = 1
    """
    Document is imported from a third-party library. Assume that they do not change unless the third-party library is updated.
    """

    Project = 2
    """
    Document is a part of the current project and may be edited at any time.
    """

class DocumentTimes:
    @property
    def parse(self) -> datetime.timedelta: ...

    @parse.setter
    def parse(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def ast(self) -> datetime.timedelta: ...

    @ast.setter
    def ast(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def index(self) -> datetime.timedelta: ...

    @index.setter
    def index(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def sema(self) -> datetime.timedelta: ...

    @sema.setter
    def sema(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def validate(self) -> datetime.timedelta: ...

    @validate.setter
    def validate(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def sema_group(self) -> int | None: ...

    @sema_group.setter
    def sema_group(self, arg: int | None) -> None: ...

    __cpp_name__: str = 'syside::DocumentTimes'

class DocumentVersion:
    def __init__(self, source: int = 0, sema: int = 0) -> None: ...

    @property
    def source(self) -> int:
        """
        The version of the source ``TextDocument`` the document was built from.
        Always 0 if there is no actual source associated. Takes priority over
        ``sema``.
        """

    @source.setter
    def source(self, arg: int, /) -> None: ...

    @property
    def sema(self) -> int:
        """
        The sema version of the ``document``. This is separate from ``source`` since
        ``sema`` may be recomputed after one of the dependencies has changed. May also
        be reset to 0 on source changes. Most similar to patch version in
        semantic versioning scheme.
        """

    @sema.setter
    def sema(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::DocumentVersion'

class Documentation(Comment):
    """
    Implementation of ``Documentation`` defined in the KerML specification.

    **Specification**:

       ``Documentation`` is a ``Comment`` that specifically documents a
       ``documented_element``, which must be its ``owner``.

    For language description, see section
    `7.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=44>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.3.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=149>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Documentation'

    STD: tuple[type[Documentation], ...] = (Documentation,)

    if TYPE_CHECKING:
        Std = Documentation

    @property
    def documented_element(self) -> Element | None:
        """
        Implementation of ``documented_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Element`` that is documented by this ``Documentation``.

        See section
        `8.3.2.3.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=149>`__
        of the KerML specification for more details.
        """

class EffectAccessor(OwnedMemberAccessor[TransitionFeatureMembership, ActionUsage]):
    @overload
    def set_member_element[M: ActionUsage](self, element: M, name: NameID = ...) -> tuple[TransitionFeatureMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ActionUsage](self, element: M | None, name: NameID = ...) -> tuple[TransitionFeatureMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ActionUsage](self, element: type[M]) -> tuple[TransitionFeatureMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class Element(AstNode):
    """
    Implementation of ``Element`` defined in the KerML specification.

    **Specification**:

       An ``Element`` is a constituent of a model that is uniquely
       identified relative to all other ``Elements``. It can have
       ``Relationships`` with other ``Elements``. Some of these
       ``Relationships`` might imply ownership of other ``Elements``, which
       means that if an ``Element`` is deleted from a model, then so are all
       the ``Elements`` that it owns.

    For language description, see section
    `7.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=41>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=138>`__
    of the KerML specification.
    """

    def __str__(self) -> str: ...

    __cpp_name__: str = 'syside::sysml::Element'

    STD: tuple[type[Element], ...] = (Element,)

    if TYPE_CHECKING:
        Std = Element

    @property
    def element_id(self) -> uuid.UUID:
        """
        Implementation of ``element_id`` defined in the KerML specification.

        **Specification**:

           The globally unique identifier for this Element. This is intended to
           be set by tooling, and it must not change during the lifetime of the
           Element.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=139>`__
        of the KerML specification for more details.

        Note that ``element_id`` may be deprecated in a future release to improve
        performance as it has no use outside of serialization. In such cases, we may
        instead create and store ``element_ids`` only during serialization. Otherwise
        ``__hash__`` is guaranteed to remain stable while the ``Element`` is alive,
        however it may be reused on ``Document`` rebuilds.

        Note that ``element_id`` is currently only stable for elements with
        ``qualified_name``, and their owning memberships, using similar derivation
        strategy to the standard elements. ``path`` based element ids will be
        implemented in a future release when bulk-complexity can be guaranteed
        ``O(n)``. While ``qualified_name`` element id has complexity of ``O(d)``,
        ``path`` based has worst-case complexity of ``O(d^2)`` for elements without
        ``qualified_names`` because it needs to scan children linearly.

        We reserve the option to change non-standard element id generation in future
        versions.
        """

    @element_id.setter
    def element_id(self, arg: uuid.UUID, /) -> None: ...

    @property
    def sema_state(self) -> SemaState:
        """
        The state of semantic resolution for this ``Element``. Based on this, sema may skip elements to avoid duplicate work, e.g. when resolving elements in a group of related documents.
        """

    @sema_state.setter
    def sema_state(self, arg: SemaState, /) -> None: ...

    @property
    def declared_name(self) -> str | None:
        """
        Implementation of ``declared_name`` defined in the KerML specification.

        **Specification**:

           The declared name of this ``Element``.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=139>`__
        of the KerML specification for more details.
        """

    @declared_name.setter
    def declared_name(self, arg: str | None) -> None: ...

    @property
    def declared_short_name(self) -> str | None:
        """
        Implementation of ``declared_short_name`` defined in the KerML
        specification.

        **Specification**:

           An optional alternative name for the ``Element`` that is intended to
           be shorter or in some way more succinct than its primary ``name``. It
           may act as a modeler-specified identifier for the ``Element``, though
           it is then the responsibility of the modeler to maintain the
           uniqueness of this identifier within a model or relative to some
           other context.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=139>`__
        of the KerML specification for more details.
        """

    @declared_short_name.setter
    def declared_short_name(self, arg: str | None) -> None: ...

    @property
    def name(self) -> str | None:
        """
        Implementation of ``name`` defined in the KerML specification.

        **Specification**:

           The name to be used for this ``Element`` during name resolution
           within its ``owning_namespace``. This is derived using the
           ``effective_name()`` operation. By default, it is the same as the
           ``declared_name``, but this is overridden for certain kinds of
           ``Elements`` to compute a ``name`` even when the ``declared_name`` is
           null.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=139>`__
        of the KerML specification for more details.
        """

    @property
    def short_name(self) -> str | None:
        """
        Implementation of ``short_name`` defined in the KerML specification.

        **Specification**:

           The short name to be used for this ``Element`` during name resolution
           within its ``owning_namespace``. This is derived using the
           ``effective_short_name()`` operation. By default, it is the same as
           the ``declared_short_name``, but this is overridden for certain kinds
           of ``Elements`` to compute a ``short_name`` even when the
           ``declared_name`` is null.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def qualified_name(self) -> QualifiedName | None:
        """
        Implementation of ``qualified_name`` defined in the KerML specification.

        **Specification**:

           The full ownership-qualified name of this ``Element``, represented in
           a form that is valid according to the KerML textual concrete syntax
           for qualified names (including use of unrestricted name notation and
           escaped characters, as necessary). The ``qualified_name`` is null if
           this ``Element`` has no ``owning_namespace`` or if there is not a
           complete ownership chain of named ``Namespaces`` from a root
           ``Namespace`` to this ``Element``. If the ``owning_namespace`` has
           other ``Elements`` with the same name as this one, then the
           ``qualified_name`` is null for all such ``Elements`` other than the
           first.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def path(self) -> Path:
        """
        Return a unique description of the location of this ``Element`` in the
        containment structure rooted in a root ``Namespace``. In most cases the
        segments will be identical to ``QualifiedName``.

        For example, an ``OwningMembership`` will return its ``owned_member_element`` path
        with ``to_owning_membership == True``.

        *NOTE* that for now, this is only partially implemented, resolution of
        positions is not yet performed and an empty ``Path`` is returned instead.
        """

    def matches_qualified_name(self, arg: Sequence[str], /) -> bool:
        """
        Check if the qualified name of this ``Element`` matches the provided segments of a qualified name.
        """

    @property
    def is_implied_included(self) -> bool:
        """
        Implementation of ``is_implied_included`` defined in the KerML
        specification.

        **Specification**:

           Whether all necessary implied Relationships have been included in the
           ``owned_relationships`` of this Element. This property may be true,
           even if there are not actually any ``owned_relationships`` with
           ``is_implied = true``, meaning that no such Relationships are
           actually implied for this Element. However, if it is false, then
           ``owned_relationships`` may *not* contain any implied Relationships.
           That is, either *all* required implied Relationships must be
           included, or none of them.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=139>`__
        of the KerML specification for more details.
        """

    @property
    def is_library_element(self) -> bool:
        """
        Implementation of ``is_library_element`` defined in the KerML
        specification.

        **Specification**:

           Whether this Element is contained in the ownership tree of a library
           model.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=139>`__
        of the KerML specification for more details.
        """

    @property
    def owning_membership(self) -> OwningMembership | None:
        """
        Implementation of ``owning_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``owning_relationship`` of this ``Element``, if that
           ``Relationship`` is a ``Membership``.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def owned_relationships(self) -> LazyIterator[Relationship]:
        """
        Implementation of ``owned_relationship`` defined in the KerML
        specification.

        **Specification**:

           The Relationships for which this Element is the
           owning_related_element.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=139>`__
        of the KerML specification for more details.
        """

    @property
    def owning_relationship(self) -> Relationship | None:
        """
        Implementation of ``owning_relationship`` defined in the KerML
        specification.

        **Specification**:

           The Relationship for which this Element is an owned_related_element,
           if any.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def owning_namespace(self) -> Namespace | None:
        """
        Implementation of ``owning_namespace`` defined in the KerML
        specification.

        **Specification**:

           The ``Namespace`` that owns this ``Element``, which is the
           ``membership_owning_namespace`` of the ``owning_membership`` of this
           ``Element``, if any.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def owner(self) -> Element | None:
        """
        Implementation of ``owner`` defined in the KerML specification.

        **Specification**:

           The owner of this Element, derived as the ``owning_related_element``
           of the ``owning_relationship`` of this Element, if any.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=139>`__
        of the KerML specification for more details.
        """

    @property
    def scoped_owner(self) -> Element | None:
        """
        The owner of this ``Element`` as the parent of ``owning_membership`` or ``owning_relationship`` otherwise.
        """

    @property
    def owned_elements(self) -> LazyIterator[Element]:
        """
        Implementation of ``owned_element`` defined in the KerML specification.

        **Specification**:

           The Elements owned by this Element, derived as the
           owned_related_elements of the owned_relationships of this Element.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=139>`__
        of the KerML specification for more details.
        """

    @property
    def documentation(self) -> LazyIterator[Documentation]:
        """
        Implementation of ``documentation`` defined in the KerML specification.

        **Specification**:

           The Documentation owned by this Element.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=139>`__
        of the KerML specification for more details.
        """

    @property
    def owned_annotations(self) -> LazyIterator[Annotation]:
        """
        Implementation of ``owned_annotation`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Element`` that are
           ``Annotations``, for which this ``Element`` is the
           ``annotated_element``.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=139>`__
        of the KerML specification for more details.
        """

    @property
    def comments(self) -> LazyIterator[Comment]:
        """The owned ``Comments`` related by ``owned_relationships``."""

    @property
    def textual_representations(self) -> LazyIterator[TextualRepresentation]:
        """
        Implementation of ``textual_representation`` defined in the KerML
        specification.

        **Specification**:

           The ``TextualRepresentations`` that annotate this ``Element``.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=140>`__
        of the KerML specification for more details.
        """

    @property
    def metadata(self) -> LazyIterator[MetadataFeature | MetadataUsage]:
        """The owned metadata related by ``owned_relationships``."""

    @property
    def alias_ids(self) -> list[str]:
        """
        Implementation of ``alias_ids`` defined in the KerML specification.

        **Specification**:

           Various alternative identifiers for this Element. Generally, these
           will be set by tools.

        See section
        `8.3.2.1.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=138>`__
        of the KerML specification for more details.
        """

class ElementAccessor(MemberAccessor[Membership, Element]):
    @overload
    def set_member_element[M: Element](self, element: M, name: NameID = ...) -> tuple[Membership, M]:
        """
        Set a new ``member_element``. ``element`` will only be referenced if the ``membership`` is ``Membership``,
        otherwise ownership constraints apply. Replaces the previous ``member_element``, which may be reused by the model
        if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Element](self, element: M | None, name: NameID = ...) -> tuple[Membership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

class ElementFilterMembership(OwningMembership):
    """
    Implementation of ``ElementFilterMembership`` defined in the KerML
    specification.

    **Specification**:

       ``ElementFilterMembership`` is a ``Membership`` between a
       ``Namespace`` and a model-level evaluable ``Boolean``-valued
       ``Expression``, asserting that imported ``members`` of the
       ``Namespace`` should be filtered using the ``condition``
       ``Expression``. A general ``Namespace`` does not define any specific
       filtering behavior, but such behavior may be defined for various
       specialized kinds of ``Namespaces``.

    For language description, see section
    `7.2.5.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=49>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.13.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=262>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ElementFilterMembership'

    STD: tuple[type[ElementFilterMembership], ...] = (ElementFilterMembership,)

    if TYPE_CHECKING:
        Std = ElementFilterMembership

    @property
    def condition(self) -> Expression | None:
        """
        Implementation of ``condition`` defined in the KerML specification.

        **Specification**:

           The model-level evaluable ``Boolean``-valued ``Expression`` used to
           filter the imported ``members`` of the
           ``membership_owning_namespace`` of this ``ElementFilterMembership``.

        See section
        `8.3.4.13.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=263>`__
        of the KerML specification for more details.
        """

class EncodingOpts:
    """
    Percent-encoding options

    These options are used to customize the behavior of algorithms which use percent
    escapes, such as encoding or decoding.
    """

    def __init__(self, space_as_plus: bool = False, lower_case: bool = False, disallow_null: bool = False) -> None: ...

    @property
    def space_as_plus(self) -> bool:
        """
        True if spaces encode to and from plus signs

        This option controls whether or not the PLUS character ("+") is used to
        represent the SP character (" ") when encoding or decoding. Although not
        prescribed by the RFC, plus signs are commonly treated as spaces upon decoding
        when used in the query of URLs using well known schemes such as HTTP.
        """

    @space_as_plus.setter
    def space_as_plus(self, arg: bool, /) -> None: ...

    @property
    def lower_case(self) -> bool:
        """
        True if hexadecimal digits are emitted as lower case

        By default, percent-encoding algorithms emit hexadecimal digits A through F as
        uppercase letters. When this option is ``true``, lowercase letters are used.
        """

    @lower_case.setter
    def lower_case(self, arg: bool, /) -> None: ...

    @property
    def disallow_null(self) -> bool:
        """
        True if nulls are not allowed

        Normally all possible character values (from 0 to 255) are allowed, with
        reserved characters being replaced with escapes upon encoding. When this option
        is true, attempting to decode a null will result in an error.
        """

    @disallow_null.setter
    def disallow_null(self, arg: bool, /) -> None: ...

class EndFeatureMembership(FeatureMembership):
    """
    Implementation of ``EndFeatureMembership`` defined in the KerML
    specification.

    **Specification**:

       ``EndFeatureMembership`` is a ``FeatureMembership`` that requires its
       ``member_feature`` be owned and have ``is_end = true``.

    For language description, see section
    `7.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=69>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=187>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::EndFeatureMembership'

    STD: tuple[type[EndFeatureMembership], ...] = (EndFeatureMembership,)

    if TYPE_CHECKING:
        Std = EndFeatureMembership

class EnumerationDefinition(AttributeDefinition):
    """
    Implementation of ``EnumerationDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``EnumerationDefinition`` is an ``AttributeDefinition`` all of
       whose instances are given by an explicit list of
       ``enumerated_values``. This is realized by requiring that the
       ``EnumerationDefinition`` have ``is_variation = true``, with the
       ``enumerated_values`` being its ``variants``.

    For language description, see section
    `7.8.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=78>`__
    of the SysML specification. For more details on the model, see section
    `8.3.8.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=314>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::EnumerationDefinition'

    STD: tuple[type[EnumerationDefinition], ...] = (EnumerationDefinition,)

    if TYPE_CHECKING:
        Std = EnumerationDefinition

    @property
    def enumerated_values(self) -> LazyIterator[EnumerationUsage]:
        r"""
        Implementation of ``enumerated_value`` defined in the SysML
        specification.

        **Specification**:

           ``EnumerationUsages`` of this ``EnumerationDefinition``\ that have
           distinct, fixed values. Each ``enumerated_value`` specifies one of
           the allowed instances of the ``EnumerationDefinition``.

        See section
        `8.3.8.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=314>`__
        of the SysML specification for more details.
        """

class EnumerationUsage(AttributeUsage):
    """
    Implementation of ``EnumerationUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``EnumerationUsage`` is an ``AttributeUsage`` whose
       ``attribute_definition`` is an ``EnumerationDefinition``.

    For language description, see section
    `7.8.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=78>`__
    of the SysML specification. For more details on the model, see section
    `8.3.8.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=315>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::EnumerationUsage'

    STD: tuple[type[EnumerationUsage], ...] = (EnumerationUsage,)

    if TYPE_CHECKING:
        Std = EnumerationUsage

    @property
    def enumeration_definition(self) -> EnumerationDefinition | None:
        """
        Implementation of ``enumeration_definition`` defined in the SysML
        specification.

        **Specification**:

           The single EnumerationDefinition that is the type of this
           EnumerationUsage.

        See section
        `8.3.8.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=315>`__
        of the SysML specification for more details.
        """

class EventOccurrenceUsage(OccurrenceUsage):
    """
    Implementation of ``EventOccurrenceUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``EventOccurrenceUsage`` is an ``OccurrenceUsage`` that represents
       another ``OccurrenceUsage`` occurring as a ``suboccurrence`` of the
       containing occurrence of the ``EventOccurrenceUsage``. Unless it is
       the ``EventOccurrenceUsage`` itself, the referenced
       ``OccurrenceUsage`` is related to the ``EventOccurrenceUsage`` by a
       ``ReferenceSubsetting`` ``Relationship``.

       If the ``EventOccurrenceUsage`` is owned by an
       ``OccurrenceDefinition`` or ``OccurrenceUsage``, then it also subsets
       the ``time_enclosed_occurrences`` property of the ``Class``
       ``Occurrence`` from the Kernel Semantic Library model
       ``Occurrences``.

    For language description, see section
    `7.9.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=85>`__
    of the SysML specification. For more details on the model, see section
    `8.3.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::EventOccurrenceUsage'

    STD: tuple[Union[type[EventOccurrenceUsage], type[ExhibitStateUsage], type[IncludeUseCaseUsage], type[PerformActionUsage]], ...] = (EventOccurrenceUsage, ExhibitStateUsage, IncludeUseCaseUsage, PerformActionUsage)

    if TYPE_CHECKING:
        Std = Union[EventOccurrenceUsage, ExhibitStateUsage, IncludeUseCaseUsage, PerformActionUsage]

    @property
    def event_occurrence(self) -> OccurrenceUsage | ConnectionUsage | FlowUsage | None:
        """
        Implementation of ``event_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsage`` referenced as an event by this
           ``EventOccurrenceUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``EventOccurrenceUsage``, if
           there is one, and, otherwise, the ``EventOccurrenceUsage`` itself.

        See section
        `8.3.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

class ExecutionResult:
    @property
    def schedule(self) -> Schedule: ...

    @property
    def documents(self) -> ContainerView[SharedMutex[BasicDocument]]: ...

    @property
    def diagnostics(self) -> ContainerView[DiagnosticResults]: ...

    @property
    def times(self) -> ContainerView[DocumentTimes]: ...

    @property
    def total_times(self) -> StageTimes: ...

    @total_times.setter
    def total_times(self, arg: StageTimes, /) -> None: ...

    def rethrow_exception(self) -> None: ...

    def __bool__(self) -> bool: ...

    __cpp_name__: str = 'syside::ExecutionResult'

class Executor:
    @overload
    def __init__(self) -> None:
        """Default constructor using as many workers as possible"""

    @overload
    def __init__(self, num_workers: int) -> None: ...

    @overload
    def run(self, schedule: Schedule) -> ExecutionResult:
        """
        Execute a schedule. Note that schedules are consumed and trying to access them again will result in an error
        """

    @overload
    def run(self, schedule: IOSchedule) -> tuple[IOSchedule, list[SharedMutex[TextDocument]]]: ...

    @property
    def num_workers(self) -> int:
        """Returns the number of worker threads associated with this executor."""

class ExhibitStateUsage(StateUsage):
    """
    Implementation of ``ExhibitStateUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``ExhibitStateUsage`` is a ``StateUsage`` that represents the
       exhibiting of a ``StateUsage``. Unless it is the ``StateUsage``
       itself, the ``StateUsage`` to be exhibited is related to the
       ``ExhibitStateUsage`` by a ``ReferenceSubsetting`` ``Relationship``.
       An ``ExhibitStateUsage`` is also a ``PerformActionUsage``, with its
       ``exhibited_state`` as the ``performed_action``.

    For language description, see section
    `7.18.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=153>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=366>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ExhibitStateUsage'

    STD: tuple[type[ExhibitStateUsage], ...] = (ExhibitStateUsage,)

    if TYPE_CHECKING:
        Std = ExhibitStateUsage

    @property
    def exhibited_state(self) -> StateUsage | None:
        """
        Implementation of ``exhibited_state`` defined in the SysML
        specification.

        **Specification**:

           The ``StateUsage`` to be exhibited by the ``ExhibitStateUsage``. It
           is the ``performed_action`` of the ``ExhibitStateUsage`` considered
           as a ``PerformActionUsage``, which must be a ``StateUsage``.

        See section
        `8.3.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=367>`__
        of the SysML specification for more details.
        """

    @property
    def event_occurrence(self) -> OccurrenceUsage | ConnectionUsage | FlowUsage | None:
        """
        Implementation of ``event_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsage`` referenced as an event by this
           ``EventOccurrenceUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``EventOccurrenceUsage``, if
           there is one, and, otherwise, the ``EventOccurrenceUsage`` itself.

        See section
        `8.3.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @property
    def performed_action(self) -> ActionUsage | FlowUsage | None:
        """
        Implementation of ``performed_action`` defined in the SysML
        specification.

        **Specification**:

           The ``ActionUsage`` to be performed by this ``PerformedActionUsage``.
           It is the ``event_occurrence`` of the ``PerformActionUsage``
           considered as an ``EventOccurrenceUsage``, which must be an
           ``ActionUsage``.

        See section
        `8.3.17.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=358>`__
        of the SysML specification for more details.
        """

class ExplicitOperator(enum.Enum):
    def __str__(self) -> str: ...

    If = 0

    NullCoalescing = 1

    Implies = 2

    LogicalOr = 3

    Or = 4

    Xor = 5

    LogicalAnd = 6

    And = 7

    Equals = 8

    Same = 9

    NotEquals = 10

    NotSame = 11

    IsType = 12

    HasType = 13

    At = 14

    AtAt = 15

    As = 16

    Meta = 17

    Less = 18

    LessEqual = 19

    Greater = 20

    GreaterEqual = 21

    Range = 22

    Plus = 23

    Minus = 24

    Multiply = 25

    Divide = 26

    Modulo = 27

    ExponentStar = 28

    ExponentCaret = 29

    Conjugation = 30

    Not = 31

    All = 32

    Quantity = 33

    Comma = 34

    def from_string(self) -> ExplicitOperator: ...

class Expose(Import):
    """
    Implementation of ``Expose`` defined in the SysML specification.

    **Specification**:

       An ``Expose`` is an ``Import`` of ``Memberships`` into a
       ``ViewUsage`` that provide the ``Elements`` to be included in a view.
       Visibility is always ignored for an ``Expose`` (i.e.,
       ``is_import_all = true``).

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=417>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::Expose'

    STD: tuple[type[MembershipExpose], ...] = (MembershipExpose,)

    if TYPE_CHECKING:
        Std = MembershipExpose

class Expression(Step):
    """
    Implementation of ``Expression`` defined in the KerML specification.

    **Specification**:

       An ``Expression`` is a ``Step`` that is typed by a ``Function``. An
       ``Expression`` that also has a ``Function`` as its ``featuring_type``
       is a computational step within that ``Function``. An ``Expression``
       always has a single ``result`` parameter, which redefines the
       ``result`` parameter of its defining ``function``. This allows
       ``Expressions`` to be interconnected in tree structures, in which
       inputs to each ``Expression`` in the tree are determined as the
       results of other ``Expression`` in the tree.

    For language description, see section
    `7.4.8.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=82>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Expression'

    STD: tuple[Union[type[Expression], type[CalculationUsage], type[ConstraintUsage]], ...] = (Expression, CalculationUsage, ConstraintUsage)

    if TYPE_CHECKING:
        Std = Union[Expression, CalculationUsage, ConstraintUsage]

    @property
    def cached_result_type(self) -> None | Type | TypeGuard:
        """The result type of this ``Expression`` as inferred by sema"""

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Expression`` meets the constraints necessary to be
           evaluated at *model level*, that is, using metadata within the model.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def function(self) -> Function | CalculationDefinition | ConstraintDefinition | None:
        """
        Implementation of ``function`` defined in the KerML specification.

        **Specification**:

           The ``Function`` that types this ``Expression``.

           This is the Function that types the Expression.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           An ``output`` ``parameter`` of the ``Expression`` whose value is the
           result of the ``Expression``. The result of an ``Expression`` is
           either inherited from its ``function`` or it is related to the
           ``Expression`` via a ``ReturnParameterMembership``, in which case it
           redefines the ``result`` ``parameter`` of its ``function``.

        See section
        `8.3.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=224>`__
        of the KerML specification for more details.
        """

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``Expression`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class ExpressionParameterAccessor(OwnedMemberAccessor[ParameterMembership, Expression]):
    @overload
    def set_member_element[M: Expression](self, element: M, name: NameID = ...) -> tuple[ParameterMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Expression](self, element: M | None, name: NameID = ...) -> tuple[ParameterMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Expression](self, element: type[M]) -> tuple[ParameterMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class FailAction(enum.Enum):
    """Action taken when a serialization error is encountered."""

    Fail = 0
    """Stop serialization on the first error."""

    Diagnose = 1
    """Continue diagnosing errors but stop serialization."""

    Ignore = 2
    """Ignore errors and continue serialization."""

class Feature(Type):
    """
    Implementation of ``Feature`` defined in the KerML specification.

    **Specification**:

       A ``Feature`` is a ``Type`` that classifies relations between
       multiple things (in the universe). The domain of the relation is the
       intersection of the ``featuring_types`` of the ``Feature``. (The
       domain of a ``Feature`` with no ``featuring_types`` is implicitly the
       most general ``Type`` ``Base::Anything`` from the Kernel Semantic
       Library.) The co-domain of the relation is the intersection of the
       ``types`` of the ``Feature``.

       In the simplest cases, the ``featuring_types`` and ``types`` are
       ``Classifiers`` and the ``Feature`` relates two things, one from the
       domain and one from the range. Examples include cars paired with
       wheels, people paired with other people, and cars paired with numbers
       representing the car length.

       Since ``Features`` are ``Types``, their ``featuring_types`` and
       ``types`` can be ``Features``. In this case, the ``Feature``
       effectively classifies relations between relations, which can be
       interpreted as the sequence of things related by the domain
       ``Feature`` concatenated with the sequence of things related by the
       co-domain ``Feature``.

       The *values* of a ``Feature`` for a given instance of its domain are
       all the instances of its co-domain that are related to that domain
       instance by the ``Feature``. The values of a ``Feature`` with
       ``chaining_features`` are the same as values of the last ``Feature``
       in the chain, which can be found by starting with values of the first
       ``Feature``, then using those values as domain instances to obtain
       values of the second ``Feature``, and so on, to values of the last
       ``Feature``.

    For language description, see section
    `7.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=58>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=187>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Feature'

    STD: tuple[type[Feature], ...] = (Feature,)

    if TYPE_CHECKING:
        Std = Feature

    @property
    def is_unique(self) -> bool:
        """
        Implementation of ``is_unique`` defined in the KerML specification.

        **Specification**:

           Whether or not values for this ``Feature`` must have no duplicates or
           not.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=189>`__
        of the KerML specification for more details.
        """

    @is_unique.setter
    def is_unique(self, arg: bool, /) -> None: ...

    @property
    def is_nonunique(self) -> bool: ...

    @is_nonunique.setter
    def is_nonunique(self, arg: bool, /) -> None: ...

    @property
    def is_ordered(self) -> bool:
        """
        Implementation of ``is_ordered`` defined in the KerML specification.

        **Specification**:

           Whether an order exists for the values of this ``Feature`` or not.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=189>`__
        of the KerML specification for more details.
        """

    @is_ordered.setter
    def is_ordered(self, arg: bool, /) -> None: ...

    @property
    def is_composite(self) -> bool:
        """
        Implementation of ``is_composite`` defined in the KerML specification.

        **Specification**:

           Whether the ``Feature`` is a composite ``feature`` of its
           ``featuring_type``. If so, the values of the ``Feature`` cannot exist
           after its featuring instance no longer does and cannot be values of
           another composite feature that is not on the same featuring instance.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=189>`__
        of the KerML specification for more details.
        """

    @is_composite.setter
    def is_composite(self, arg: bool, /) -> None: ...

    @property
    def is_composite_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Feature`` has been declared ``composite`` in the textual syntax.
        """

    @property
    def is_end(self) -> bool:
        """
        Implementation of ``is_end`` defined in the KerML specification.

        **Specification**:

           Whether or not this ``Feature`` is an end ``Feature``. An end
           ``Feature`` always has multiplicity 1, mapping each of its domain
           instances to a single co-domain instance. However, it may have a
           ``cross_feature``, in which case values of the ``cross_feature`` must
           be the same as those found by navigation across instances of the
           ``owning_type`` from values of other end ``Features`` to values of
           this Feature. If the ``owning_type`` has *n* end ``Features``, then
           the multiplicity, ordering, and uniqueness declared for the
           ``cross_feature`` of any one of these end ``Features`` constrains the
           cardinality, ordering, and uniqueness of the collection of values of
           that ``Feature`` reached by navigation when the values of the other
           *n-1* end ``Features`` are held fixed.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=189>`__
        of the KerML specification for more details.
        """

    @is_end.setter
    def is_end(self, arg: bool, /) -> None: ...

    @property
    def is_end_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Feature`` has been declared ``end`` in the textual syntax.
        """

    @property
    def is_derived(self) -> bool:
        """
        Implementation of ``is_derived`` defined in the KerML specification.

        **Specification**:

           Whether the values of this ``Feature`` can always be computed from
           the values of other ``Features``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=189>`__
        of the KerML specification for more details.
        """

    @is_derived.setter
    def is_derived(self, arg: bool, /) -> None: ...

    @property
    def is_constant(self) -> bool:
        """
        Implementation of ``is_constant`` defined in the KerML specification.

        **Specification**:

           If ``is_variable`` is true, then whether the value of this
           ``Feature`` nevertheless does not change over all ``snapshots`` of
           its ``owning_type``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=189>`__
        of the KerML specification for more details.
        """

    @is_constant.setter
    def is_constant(self, arg: bool, /) -> None: ...

    @property
    def is_constant_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Feature`` has been declared ``constant`` in the textual syntax.
        """

    @property
    def is_variable(self) -> bool:
        """
        Implementation of ``is_variable`` defined in the KerML specification.

        **Specification**:

           Whether the value of this ``Feature`` might vary over time. That is,
           whether the ``Feature`` may have a different value for each
           ``snapshot`` of an ``owning_type`` that is an ``Occurrence``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=189>`__
        of the KerML specification for more details.

        Note that this will raise ``TypeError`` if attempting to set ``is_variable`` on ``Usages`` because it
        is computed by sema, see ``Usage.may_time_vary``. Prefer using ``try_set_is_variable`` for non-raising
        behaviour.
        """

    @is_variable.setter
    def is_variable(self, arg: bool, /) -> None: ...

    @property
    def is_variable_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Feature`` has been declared ``variable`` in the textual syntax.
        """

    def try_set_is_variable(self, arg: bool, /) -> bool:
        """
        Non-raising variant of ``is_variable`` setter that returns ``False`` on ``Usages``
        without modifying ``is_variable``.
        """

    @property
    def is_read_only(self) -> bool:
        """
        Alias for `is_constant`.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @is_read_only.setter
    def is_read_only(self, arg: bool, /) -> None: ...

    @property
    def is_portion(self) -> bool:
        """
        Implementation of ``is_portion`` defined in the KerML specification.

        **Specification**:

           Whether the values of this ``Feature`` are contained in the space and
           time of instances of the domain of the ``Feature`` and represent the
           same thing as those instances.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=189>`__
        of the KerML specification for more details.
        """

    @is_portion.setter
    def is_portion(self, arg: bool, /) -> None: ...

    @property
    def direction(self) -> FeatureDirectionKind | None:
        """
        Implementation of ``direction`` defined in the KerML specification.

        **Specification**:

           Indicates how values of this ``Feature`` are determined or used (as
           specified for the ``FeatureDirectionKind``).

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=188>`__
        of the KerML specification for more details.
        """

    @direction.setter
    def direction(self, arg: FeatureDirectionKind | None) -> None: ...

    @property
    def explicit_direction(self) -> FeatureDirectionKind | None:
        """
        Returns the direction this ``Feature`` has been declared with in the textual syntax.
        """

    @property
    def owning_feature_membership(self) -> FeatureMembership | None:
        """
        Implementation of ``owning_feature_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``FeatureMembership`` that owns this ``Feature`` as an
           ``owned_member_feature``, determining its ``owning_type``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=190>`__
        of the KerML specification for more details.
        """

    @property
    def owning_type(self) -> Type | None:
        """
        Implementation of ``owning_type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` that is the ``owning_type`` of the
           ``owning_feature_membership`` of this ``Feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=190>`__
        of the KerML specification for more details.
        """

    @property
    def end_owning_type(self) -> Type | None:
        """
        Implementation of ``end_owning_type`` defined in the KerML
        specification.

        **Specification**:

           The ``Type`` that is related to this ``Feature`` by an
           ``EndFeatureMembership`` in which the ``Feature`` is an
           ``owned_member_feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=188>`__
        of the KerML specification for more details.
        """

    @property
    def types(self) -> LazyIterator[Type]:
        """
        Implementation of ``type`` defined in the KerML specification.

        **Specification**:

           ``Types`` that restrict the values of this ``Feature``, such that the
           values must be instances of all the ``types``. The types of a
           ``Feature`` are derived from its ``typings`` and the ``types`` of its
           ``subsettings``. If the ``Feature`` is chained, then the ``types`` of
           the last ``Feature`` in the chain are also ``types`` of the chained
           ``Feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=190>`__
        of the KerML specification for more details.
        """

    @property
    def owned_redefinitions(self) -> LazyIterator[Redefinition]:
        """
        Implementation of ``owned_redefinition`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_subsettings`` of this ``Feature`` that are
           ``Redefinitions``, for which the ``Feature`` is the
           ``redefining_feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=190>`__
        of the KerML specification for more details.
        """

    @property
    def owned_subsettings(self) -> LazyIterator[Subsetting]:
        """
        Implementation of ``owned_subsetting`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_specializations`` of this ``Feature`` that are
           ``Subsettings``, for which the ``Feature`` is the
           ``subsetting_feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=190>`__
        of the KerML specification for more details.
        """

    @property
    def owned_typings(self) -> LazyIterator[FeatureTyping]:
        """
        Implementation of ``owned_typing`` defined in the KerML specification.

        **Specification**:

           The ``owned_specializations`` of this ``Feature`` that are
           ``FeatureTypings``, for which the ``Feature`` is the
           ``typed_feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=190>`__
        of the KerML specification for more details.
        """

    @property
    def featuring_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``featuring_type`` defined in the KerML specification.

        **Specification**:

           ``Types`` that feature this ``Feature``, such that any instance in
           the domain of the ``Feature`` must be classified by all of these
           ``Types``, including at least all the ``featuring_types`` of its
           ``type_featurings``. If the ``Feature`` is chained, then the
           ``featuring_types`` of the first ``Feature`` in the chain are also
           ``featuring_types`` of the chained ``Feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=188>`__
        of the KerML specification for more details.
        """

    @property
    def owned_type_featurings(self) -> LazyIterator[TypeFeaturing]:
        """
        Implementation of ``owned_type_featuring`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Feature`` that are
           ``TypeFeaturings`` and for which the ``Feature`` is the
           ``feature_of_type``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=190>`__
        of the KerML specification for more details.
        """

    @property
    def owned_feature_invertings(self) -> LazyIterator[FeatureInverting]:
        """
        Implementation of ``owned_feature_inverting`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Feature`` that are
           ``FeatureInvertings`` and for which the ``Feature`` is the
           ``feature_inverted``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=190>`__
        of the KerML specification for more details.
        """

    @property
    def owned_feature_chainings(self) -> LazyIterator[FeatureChaining]:
        """
        Implementation of ``owned_feature_chaining`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Feature`` that are
           ``FeatureChainings``, for which the ``Feature`` will be the
           ``feature_chained``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=189>`__
        of the KerML specification for more details.
        """

    @property
    def owned_reference_subsetting(self) -> ReferenceSubsetting | None:
        """
        Implementation of ``owned_reference_subsetting`` defined in the KerML
        specification.

        **Specification**:

           The one ``owned_subsetting`` of this ``Feature``, if any, that is a
           ``ReferenceSubsetting``, for which the ``Feature`` is the
           ``referencing_feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=190>`__
        of the KerML specification for more details.
        """

    @property
    def referenced_feature(self) -> Feature | None:
        """
        Returns the ``Feature`` this ``Feature`` references through ``ReferenceSubsetting`` if any.
        """

    @property
    def referenced_feature_target(self) -> Feature | None:
        """
        Returns the ``feature_target`` of ``referenced_feature``, i.e. ``referenced_feature.feature_target``.
        """

    @property
    def owned_cross_subsetting(self) -> CrossSubsetting | None:
        """
        Implementation of ``owned_cross_subsetting`` defined in the KerML
        specification.

        **Specification**:

           The one ``owned_subsetting`` of this ``Feature``, if any, that is a
           ``CrossSubsetting}, for which the Feature is the crossing_feature.``

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=189>`__
        of the KerML specification for more details.
        """

    @property
    def cross_feature(self) -> Feature | None:
        """
        Implementation of ``cross_feature`` defined in the KerML specification.

        **Specification**:

           The second ``chaining_feature`` of the ``crossed_feature`` of the
           ``owned_cross_subsetting`` of this ``Feature``, if it has one.
           Semantically, the values of the ``cross_feature`` of an end
           ``Feature`` must include all values of the end ``Feature`` obtained
           when navigating from values of the other end ``Features`` of the same
           ``owning_type``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=188>`__
        of the KerML specification for more details.
        """

    @property
    def owned_cross_feature_member(self) -> OwnedFeatureAccessor:
        """
        Syside specific accessor for either owned `crossing_feature` or `crossing_multiplicity`. This is the
        member ``Feature`` that is declared before any prefixes in the textual syntax.
        """

    @property
    def owned_cross_feature(self) -> Feature | None:
        """
        The member ``Feature`` that is declared before any prefixes in the textual syntax.
        """

    def find_owned_cross_feature(self) -> Feature | None:
        """
        Find the owned cross feature by potentially checking children. This is
        needed for spec that defined owned cross feature as the first member feature
        that is not a MetadataFeature or Multiplicity of an end feature. Since SysML
        does not allow member features (member keyword in KerML), this is equivalent
        to owned_cross_feature in SysML.
        """

    @property
    def feature_value(self) -> FeatureValue | None:
        """The ``FeatureValue`` owned by this ``Feature`` if any."""

    @property
    def feature_value_expression(self) -> Expression | None:
        """The feature value ``Expression`` of this ``Feature`` if any."""

    @property
    def feature_value_member(self) -> FeatureValueAccessor:
        """Syside specific accessor for manipulating ``feature_value``."""

    @property
    def first_chaining_feature(self) -> Feature | None:
        """
        The related ``Feature`` related by the first ``owned_feature_chaining`` if any.
        """

    @property
    def last_chaining_feature(self) -> Feature | None:
        """
        The related ``Feature`` related by the last ``owned_feature_chaining`` if any.
        """

    @property
    def basic_feature(self) -> Feature:
        """
        The ``last_chaining_feature`` if one exists, otherwise this ``Feature``.
        """

    @property
    def feature_target(self) -> Feature:
        """
        Implementation of ``feature_target`` defined in the KerML specification.

        **Specification**:

           The last of the ``chaining_features`` of this ``Feature``, if it has
           any. Otherwise, this ``Feature`` itself.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=188>`__
        of the KerML specification for more details.
        """

    @property
    def chaining_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``chaining_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that are chained together to determine the values of
           this ``Feature``, derived from the ``chaining_features`` of the
           ``owned_feature_chainings`` of this ``Feature``, in the same order.
           The values of a ``Feature`` with ``chaining_features`` are the same
           as values of the last ``Feature`` in the chain, which can be found by
           starting with the values of the first ``Feature`` (for each instance
           of the domain of the original ``Feature``), then using each of those
           as domain instances to find the values of the second ``Feature`` in
           chaining_features, and so on, to values of the last ``Feature``.

        See section
        `8.3.3.3.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=188>`__
        of the KerML specification for more details.
        """

class FeatureChainExpression(OperatorExpression):
    """
    Implementation of ``FeatureChainExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``FeatureChainExpression`` is an ``OperatorExpression`` whose
       operator is ``"."``, which resolves to the ``Function``
       ``ControlFunctions::'.'`` from the Kernel Functions Library. It
       evaluates to the result of chaining the ``result`` ``Feature`` of its
       single ``argument`` ``Expression`` with its ``target_feature``.

    For language description, see section
    `7.4.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=86>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=233>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureChainExpression'

    STD: tuple[type[FeatureChainExpression], ...] = (FeatureChainExpression,)

    if TYPE_CHECKING:
        Std = FeatureChainExpression

    @property
    def target_feature(self) -> Feature | None:
        """
        Implementation of ``target_feature`` defined in the KerML specification.

        **Specification**:

           The ``Feature`` that is accessed by this ``FeatureChainExpression``,
           which is its first non-``parameter`` ``member``.

        See section
        `8.3.4.8.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=234>`__
        of the KerML specification for more details.
        """

    @property
    def target_feature_member(self) -> TargetFeatureAccessor:
        """Syside specific accessor for manipulating ``target_feature``."""

class FeatureChaining(Relationship):
    """
    Implementation of ``FeatureChaining`` defined in the KerML
    specification.

    **Specification**:

       ``FeatureChaining`` is a ``Relationship`` that makes its target
       ``Feature`` one of the ``chaining_features`` of its owning
       ``Feature``.

    For language description, see section
    `7.3.4.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=64>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=202>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureChaining'

    STD: tuple[type[FeatureChaining], ...] = (FeatureChaining,)

    if TYPE_CHECKING:
        Std = FeatureChaining

    CHAINABLE: bool = False

    @property
    def chaining_feature(self) -> Feature | None:
        """
        Implementation of ``chaining_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` whose values partly determine values of
           ``feature_chained``, as described in ``Feature::chaining_feature``.

        See section
        `8.3.3.3.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=202>`__
        of the KerML specification for more details.
        """

    @property
    def feature_chained(self) -> Feature | None:
        """
        Implementation of ``feature_chained`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` whose values are partly determined by values of the
           ``chaining_feature``, as described in ``Feature::chaining_feature``.

        See section
        `8.3.3.3.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=202>`__
        of the KerML specification for more details.
        """

class FeatureDirectionKind(enum.Enum):
    """
    Implementation of ``FeatureDirectionKind`` defined in the KerML
    specification.

    **Specification**:

       ``FeatureDirectionKind`` enumerates the possible kinds of
       ``direction`` that a ``Feature`` may be given as a member of a
       ``Type``.

    For language description, see section
    `7.3.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=59>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=168>`__
    of the KerML specification.
    """

    In = 0

    Inout = 1

    Out = 2

class FeatureInverting(Relationship):
    """
    Implementation of ``FeatureInverting`` defined in the KerML
    specification.

    **Specification**:

       A ``FeatureInverting`` is a ``Relationship`` between ``Features``
       asserting that their interpretations (sequences) are the reverse of
       each other, identified as ``feature_inverted`` and
       ``inverting_feature``. For example, a ``Feature`` identifying each
       person’s parents is the inverse of a ``Feature`` identifying each
       person’s children. A person identified as a parent of another will
       identify that other as one of their children.

    For language description, see section
    `7.3.4.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=65>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=202>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureInverting'

    STD: tuple[type[FeatureInverting], ...] = (FeatureInverting,)

    if TYPE_CHECKING:
        Std = FeatureInverting

    CHAINABLE: bool = True

    @property
    def inverting_feature(self) -> Feature | None:
        """
        Implementation of ``inverting_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is an inverse of the ``inverted_feature``.

        See section
        `8.3.3.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=203>`__
        of the KerML specification for more details.
        """

    @property
    def feature_inverted(self) -> Feature | None:
        """
        Implementation of ``feature_inverted`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is an inverse of the ``inverting_feature``.

        See section
        `8.3.3.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=203>`__
        of the KerML specification for more details.
        """

    @property
    def owning_feature(self) -> Feature | None:
        """
        Implementation of ``owning_feature`` defined in the KerML specification.

        **Specification**:

           A ``feature_inverted`` that is also the ``owning_related_element`` of
           this ``FeatureInverting``.

        See section
        `8.3.3.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=203>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def inverting_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``inverting_feature``.
        """

    @property
    def feature_inverted_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``feature_inverted``.
        """

class FeatureMembership(OwningMembership):
    """
    Implementation of ``FeatureMembership`` defined in the KerML
    specification.

    **Specification**:

       A ``FeatureMembership`` is an ``OwningMembership`` between an
       ``owned_member_feature`` and an ``owning_type``. If the
       ``owned_member_feature`` has ``is_variable = false``, then the
       ``FeatureMembership`` implies that the ``owning_type`` is also a
       ``featuring_type`` of the ``owned_member_feature``. If the
       ``owned_member_feature`` has ``is_variable = true``, then the
       ``FeatureMembership`` implies that the ``owned_member_feature`` is
       featured by the ``snapshots`` of the ``owning_type``, which must
       specialize the Kernel Semantic Library base class ``Occurrence``.

    For language description, see section
    `7.3.2.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=56>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=168>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureMembership'

    STD: tuple[type[FeatureMembership], ...] = (FeatureMembership,)

    if TYPE_CHECKING:
        Std = FeatureMembership

    @property
    def owning_type(self) -> Type | None:
        """
        Implementation of ``owning_type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` that owns this ``FeatureMembership``.

        See section
        `8.3.3.1.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @property
    def owned_member_feature(self) -> Feature | None:
        """
        Implementation of ``owned_member_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that this ``FeatureMembership`` relates to its
           ``owning_type``, making it an ``owned_feature`` of the
           ``owning_type``.

        See section
        `8.3.3.1.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=168>`__
        of the KerML specification for more details.
        """

class FeatureReference(ReferenceAccessor[Feature]):
    def try_set[M: Feature](self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set[M: Feature](self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class FeatureReferenceExpression(Expression):
    """
    Implementation of ``FeatureReferenceExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``FeatureReferenceExpression`` is an ``Expression`` whose
       ``result`` is bound to a ``referent`` ``Feature``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=235>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureReferenceExpression'

    STD: tuple[type[FeatureReferenceExpression], ...] = (FeatureReferenceExpression,)

    if TYPE_CHECKING:
        Std = FeatureReferenceExpression

    @property
    def referent(self) -> Feature | None:
        """
        Implementation of ``referent`` defined in the KerML specification.

        **Specification**:

           The ``Feature`` that is referenced by this
           ``FeatureReferenceExpression``, which is its first non-``parameter``
           ``member``.

        See section
        `8.3.4.8.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=235>`__
        of the KerML specification for more details.
        """

    @property
    def referent_member(self) -> ReferentAccessor:
        """Syside specific accessor for manipulating ``referent``."""

class FeatureTyping(Specialization):
    """
    Implementation of ``FeatureTyping`` defined in the KerML specification.

    **Specification**:

       ``FeatureTyping`` is ``Specialization`` in which the ``specific``
       ``Type`` is a ``Feature``. This means the set of instances of the
       (specific) ``typed_feature`` is a subset of the set of instances of
       the (general) ``type``. In the simplest case, the ``type`` is a
       ``Classifier``, whereupon the ``typed_feature`` has values that are
       instances of the ``Classifier``.

    For language description, see section
    `7.3.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=61>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=203>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureTyping'

    STD: tuple[type[FeatureTyping], ...] = (FeatureTyping,)

    if TYPE_CHECKING:
        Std = FeatureTyping

    CHAINABLE: bool = False

    @property
    def typed_feature(self) -> Feature | None:
        """
        Implementation of ``typed_feature`` defined in the KerML specification.

        **Specification**:

           The ``Feature`` that has a ``type`` determined by this
           ``FeatureTyping``.

        See section
        `8.3.3.3.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=203>`__
        of the KerML specification for more details.
        """

    @property
    def type(self) -> Type | None:
        """
        Implementation of ``type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` that is being applied by this ``FeatureTyping``.

        See section
        `8.3.3.3.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=203>`__
        of the KerML specification for more details.
        """

    @property
    def owning_feature(self) -> Feature | None:
        """
        Implementation of ``owning_feature`` defined in the KerML specification.

        **Specification**:

           A ``typed_feature`` that is also the ``owning_related_element`` of
           this ``FeatureTyping``.

        See section
        `8.3.3.3.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=203>`__
        of the KerML specification for more details.
        """

    @property
    def typed_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``typed_feature``.
        """

    @property
    def type_target(self) -> ChainedTypeReference:
        """Syside specific accessor for manipulating the target of ``type``."""

class FeatureValue(OwningMembership):
    """
    Implementation of ``FeatureValue`` defined in the KerML specification.

    **Specification**:

       A ``FeatureValue`` is a ``Membership`` that identifies a particular
       member ``Expression`` that provides the value of the ``Feature`` that
       owns the ``FeatureValue``. The value is specified as either a bound
       value or an initial value, and as either a concrete or default value.
       A ``Feature`` can have at most one ``FeatureValue``.

       The result of the ``value`` ``Expression`` is bound to the
       ``feature_with_value`` using a ``BindingConnector``. If
       ``is_initial = false``, then the ``featuring_type`` of the
       ``BindingConnector`` is the same as the ``featuring_type`` of the
       ``feature_with_value``. If ``is_initial = true``, then the
       ``featuring_type`` of the ``BindingConnector`` is restricted to its
       ``start_shot``.

       If ``is_default = false``, then the above semantics of the
       ``FeatureValue`` are realized for the given ``feature_with_value``.
       Otherwise, the semantics are realized for any individual of the
       ``featuring_type`` of the ``feature_with_value``, unless another
       value is explicitly given for the ``feature_with_value`` for that
       individual.

    For language description, see section
    `7.4.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=93>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=254>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FeatureValue'

    STD: tuple[type[FeatureValue], ...] = (FeatureValue,)

    if TYPE_CHECKING:
        Std = FeatureValue

    @property
    def is_initial(self) -> bool:
        """
        Implementation of ``is_initial`` defined in the KerML specification.

        **Specification**:

           Whether this ``FeatureValue`` specifies a bound value or an initial
           value for the ``feature_with_value``.

        See section
        `8.3.4.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=254>`__
        of the KerML specification for more details.
        """

    @is_initial.setter
    def is_initial(self, arg: bool, /) -> None: ...

    @property
    def is_default(self) -> bool:
        """
        Implementation of ``is_default`` defined in the KerML specification.

        **Specification**:

           Whether this ``FeatureValue`` is a concrete specification of the
           bound or initial value of the ``feature_with_value``, or just a
           default value that may be overridden.

        See section
        `8.3.4.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=254>`__
        of the KerML specification for more details.
        """

    @is_default.setter
    def is_default(self, arg: bool, /) -> None: ...

    @property
    def feature_with_value(self) -> Feature | None:
        """
        Implementation of ``feature_with_value`` defined in the KerML
        specification.

        **Specification**:

           The Feature to be provided a value.

           The ``Feature`` to be provided a value.

        See section
        `8.3.4.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=254>`__
        of the KerML specification for more details.
        """

    @property
    def value(self) -> Expression | None:
        """
        Implementation of ``value`` defined in the KerML specification.

        **Specification**:

           The Expression that provides the value as a result.

           The ``Expression`` that provides the value of the
           ``feature_with_value`` as its ``result``.

        See section
        `8.3.4.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=254>`__
        of the KerML specification for more details.
        """

class FeatureValueAccessor(OwnedMemberAccessor[FeatureValue, Expression]):
    @overload
    def set_member_element[M: Expression](self, element: M, name: NameID = ...) -> tuple[FeatureValue, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Expression](self, element: M | None, name: NameID = ...) -> tuple[FeatureValue, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Expression](self, element: type[M]) -> tuple[FeatureValue, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class FieldId:
    def __init__(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __index__(self) -> int: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __hash__(self) -> int: ...

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'tree_sitter::FieldId'

class FloatFormat(enum.Enum):
    none = 0

    Exp = 1

    Prec = 2

class Flow(Connector):
    """
    Implementation of ``Flow`` defined in the KerML specification.

    **Specification**:

       An ``Flow`` is a ``Step`` that represents the transfer of values from
       one ``Feature`` to another. ``Flows`` can take non-zero time to
       complete.

    For language description, see section
    `7.4.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=91>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=249>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Flow'

    STD: tuple[Union[type[Flow], type[FlowUsage]], ...] = (Flow, FlowUsage)

    if TYPE_CHECKING:
        Std = Union[Flow, FlowUsage]

    @property
    def behaviors(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``behavior`` defined in the KerML specification.

        **Specification**:

           The ``Behaviors`` that type this ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

    @property
    def owned_parameters(self) -> LazyIterator[Feature]:
        """The ``parameters`` owned by this ``Step``."""

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The ``parameters`` of this ``Step``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

    @property
    def payload_types(self) -> LazyIterator[Classifier]:
        """
        Implementation of ``payload_type`` defined in the KerML specification.

        **Specification**:

           The type of values transferred, which is the ``type`` of the
           ``payload_feature`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=250>`__
        of the KerML specification for more details.
        """

    @property
    def target_input_feature(self) -> Feature | None:
        """
        Implementation of ``target_input_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that receives the values carried by the ``Flow``. It
           must be a ``feature`` of the ``target`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=250>`__
        of the KerML specification for more details.
        """

    @property
    def source_output_feature(self) -> Feature | None:
        """
        Implementation of ``source_output_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that provides the items carried by the ``Flow``. It
           must be a ``feature`` of the ``source`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=250>`__
        of the KerML specification for more details.
        """

    @property
    def flow_ends(self) -> LazyIterator[FlowEnd]:
        """
        Implementation of ``flow_end`` defined in the KerML specification.

        **Specification**:

           The ``connector_ends`` of this ``Flow`` that are ``FlowEnds``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=249>`__
        of the KerML specification for more details.
        """

    @property
    def payload_feature(self) -> PayloadFeature | None:
        """
        Implementation of ``payload_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_feature`` of the ``Flow`` that is a ``PayloadFeature``
           (if any).

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=250>`__
        of the KerML specification for more details.
        """

    @property
    def payload_feature_member(self) -> PayloadFeatureAccessor:
        """Syside specific accessor for manipulating ``payload_feature``."""

    @property
    def interactions(self) -> LazyIterator[FlowDefinition | Interaction]:
        """
        Implementation of ``interaction`` defined in the KerML specification.

        **Specification**:

           The ``Interactions`` that type this ``Flow``. ``Interactions`` are
           both ``Associations`` and ``Behaviors``, which can type
           ``Connectors`` and ``Steps``, respectively.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=249>`__
        of the KerML specification for more details.
        """

class FlowDefinition(ActionDefinition):
    """
    Implementation of ``FlowDefinition`` defined in the SysML specification.

    **Specification**:

       A ``FlowDefinition`` is an ``ActionDefinition`` that is also an
       ``Interaction`` (which is both a KerML ``Behavior`` and
       ``Association``), representing flows between ``Usages``.

    For language description, see section
    `7.16.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=113>`__
    of the SysML specification. For more details on the model, see section
    `8.3.16.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=338>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::FlowDefinition'

    STD: tuple[type[FlowDefinition], ...] = (FlowDefinition,)

    if TYPE_CHECKING:
        Std = FlowDefinition

    @property
    def flow_ends(self) -> LazyIterator[tuple[FeatureMembership, Usage]]:
        """
        Implementation of ``flow_end`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that define the things related by the
           ``FlowDefinition``.

        See section
        `8.3.16.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=338>`__
        of the SysML specification for more details.
        """

    @property
    def source(self) -> Feature | None:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> list[Feature]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def owning_related_element(self) -> None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> LazyIterator[Feature]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def owned_related_elements(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def source_type(self) -> Type | None:
        """
        Implementation of ``source_type`` defined in the KerML specification.

        **Specification**:

           The source ``related_type`` for this ``Association``. It is the first
           ``related_type`` of the ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=211>`__
        of the KerML specification for more details.
        """

    @property
    def related_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``related_type`` defined in the KerML specification.

        **Specification**:

           The ``types`` of the ``association_ends`` of the ``Association``,
           which are the ``related_elements`` of the ``Association`` considered
           as a ``Relationship``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=211>`__
        of the KerML specification for more details.
        """

    @property
    def target_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``target_type`` defined in the KerML specification.

        **Specification**:

           The target ``related_types`` for this ``Association``. This includes
           all the ``related_types`` other than the ``source_type``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=212>`__
        of the KerML specification for more details.
        """

    @property
    def association_ends(self) -> LazyIterator[Feature]:
        """
        Implementation of ``association_end`` defined in the KerML
        specification.

        **Specification**:

           The ``features`` of the ``Association`` that identify the things that
           can be related by it. A concrete ``Association`` must have at least
           two ``association_ends``. When it has exactly two, the
           ``Association`` is called a *binary* ``Association``.

        See section
        `8.3.4.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=211>`__
        of the KerML specification for more details.
        """

class FlowEnd(Feature):
    """
    Implementation of ``FlowEnd`` defined in the KerML specification.

    **Specification**:

       A ``FlowEnd`` is a ``Feature`` that is one of the ``connector_ends``
       giving the ``source`` or ``target`` of a ``Flow``. For ``Flows``
       typed by ``FlowTransfer`` or its specializations, ``FlowEnds`` must
       have exactly one ``owned_feature``, which redefines
       ``Transfer::source::source_output`` or
       ``Transfer::target::target_input`` and redefines the corresponding
       feature of the ``related_element`` for its end.

    For language description, see section
    `7.4.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=91>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=251>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::FlowEnd'

    STD: tuple[type[FlowEnd], ...] = (FlowEnd,)

    if TYPE_CHECKING:
        Std = FlowEnd

class FlowUsage(ConnectorAsUsage):
    """
    Implementation of ``FlowUsage`` defined in the SysML specification.

    **Specification**:

       A ``FlowUsage`` is an ``ActionUsage`` that is also a
       ``ConnectorAsUsage`` and a KerML ``Flow``.

    For language description, see section
    `7.16.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=113>`__
    of the SysML specification. For more details on the model, see section
    `8.3.16.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=339>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::FlowUsage'

    STD: tuple[type[FlowUsage], ...] = (FlowUsage,)

    if TYPE_CHECKING:
        Std = FlowUsage

    @property
    def flow_definitions(self) -> LazyIterator[FlowDefinition | Interaction]:
        """
        Implementation of ``flow_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Interactions`` that are the ``types`` of this ``FlowUsage``.
           Nominally, these are ``FlowDefinitions``, but other kinds of Kernel
           ``Interactions`` are also allowed, to permit use of Interactions from
           the Kernel Model Libraries.

        See section
        `8.3.16.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=339>`__
        of the SysML specification for more details.
        """

    @property
    def declared_messages(self) -> Messages:
        """
        The messages of this ``FlowUsage`` as declared before the children block in the textual syntax.
        """

    @property
    def behaviors(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``behavior`` defined in the KerML specification.

        **Specification**:

           The ``Behaviors`` that type this ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

    @property
    def owned_parameters(self) -> LazyIterator[Feature]:
        """The ``parameters`` owned by this ``Step``."""

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The ``parameters`` of this ``Step``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

    @property
    def action_definitions(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``action_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Behaviors`` that are the ``types`` of this ``ActionUsage``.
           Nominally, these would be ``ActionDefinitions``, but other kinds of
           Kernel ``Behaviors`` are also allowed, to permit use of ``Behaviors``
           from the Kernel Model Libraries.

        See section
        `8.3.17.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=346>`__
        of the SysML specification for more details.
        """

    @property
    def is_individual(self) -> bool:
        """
        Implementation of ``is_individual`` defined in the SysML specification.

        **Specification**:

           Whether this ``OccurrenceUsage`` represents the usage of the specific
           individual represented by its ``individual_definition``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

    @is_individual.setter
    def is_individual(self, arg: bool, /) -> None: ...

    @property
    def portion_kind(self) -> PortionKind | None:
        """
        Implementation of ``portion_kind`` defined in the SysML specification.

        **Specification**:

           The kind of temporal portion (time slice or snapshot) is represented
           by this ``OccurrenceUsage``. If ``portion_kind`` is not null, then
           the ``owning_type`` of the ``OccurrenceUsage`` must be non-null, and
           the ``OccurrenceUsage`` represents portions of the featuring instance
           of the ``owning_type``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

    @portion_kind.setter
    def portion_kind(self, arg: PortionKind | None) -> None: ...

    @property
    def occurrence_definitions(self) -> LazyIterator[OccurrenceDefinition]:
        """
        Implementation of ``occurrence_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Classes`` that are the types of this ``OccurrenceUsage``.
           Nominally, these are ``OccurrenceDefinitions``, but other kinds of
           kernel ``Classes`` are also allowed, to permit use of ``Classes``
           from the Kernel Model Libraries.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

    @property
    def individual_definition(self) -> OccurrenceDefinition | None:
        """
        Implementation of ``individual_definition`` defined in the SysML
        specification.

        **Specification**:

           The at most one ``occurrence_definition`` that has
           ``is_individual = true``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

    @property
    def payload_types(self) -> LazyIterator[Classifier]:
        """
        Implementation of ``payload_type`` defined in the KerML specification.

        **Specification**:

           The type of values transferred, which is the ``type`` of the
           ``payload_feature`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=250>`__
        of the KerML specification for more details.
        """

    @property
    def target_input_feature(self) -> Feature | None:
        """
        Implementation of ``target_input_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that receives the values carried by the ``Flow``. It
           must be a ``feature`` of the ``target`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=250>`__
        of the KerML specification for more details.
        """

    @property
    def source_output_feature(self) -> Feature | None:
        """
        Implementation of ``source_output_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that provides the items carried by the ``Flow``. It
           must be a ``feature`` of the ``source`` of the ``Flow``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=250>`__
        of the KerML specification for more details.
        """

    @property
    def flow_ends(self) -> LazyIterator[FlowEnd]:
        """
        Implementation of ``flow_end`` defined in the KerML specification.

        **Specification**:

           The ``connector_ends`` of this ``Flow`` that are ``FlowEnds``.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=249>`__
        of the KerML specification for more details.
        """

    @property
    def payload_feature(self) -> PayloadFeature | None:
        """
        Implementation of ``payload_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_feature`` of the ``Flow`` that is a ``PayloadFeature``
           (if any).

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=250>`__
        of the KerML specification for more details.
        """

    @property
    def payload_feature_member(self) -> PayloadFeatureAccessor:
        """Syside specific accessor for manipulating ``payload_feature``."""

    @property
    def interactions(self) -> LazyIterator[FlowDefinition | Interaction]:
        """
        Implementation of ``interaction`` defined in the KerML specification.

        **Specification**:

           The ``Interactions`` that type this ``Flow``. ``Interactions`` are
           both ``Associations`` and ``Behaviors``, which can type
           ``Connectors`` and ``Steps``, respectively.

        See section
        `8.3.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=249>`__
        of the KerML specification for more details.
        """

class ForLoopActionUsage(LoopActionUsage):
    """
    Implementation of ``ForLoopActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``ForLoopActionUsage`` is a ``LoopActionUsage`` that specifies that
       its ``body_action`` ``ActionUsage`` should be performed once for each
       value, in order, from the sequence of values obtained as the result
       of the ``seq_argument`` ``Expression``, with the ``loop_variable``
       set to the value for each iteration.

    For language description, see section
    `7.17.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=143>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=353>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ForLoopActionUsage'

    STD: tuple[type[ForLoopActionUsage], ...] = (ForLoopActionUsage,)

    if TYPE_CHECKING:
        Std = ForLoopActionUsage

    @property
    def seq_argument(self) -> Expression | None:
        """
        Implementation of ``seq_argument`` defined in the SysML specification.

        **Specification**:

           The ``Expression`` whose result provides the sequence of values to
           which the ``loop_variable`` is set for each iterative performance of
           the ``body_action``. It is the ``Expression`` whose ``result`` is
           bound to the ``seq`` ``input`` ``parameter`` of this
           ``ForLoopActionUsage``.

        See section
        `8.3.17.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=353>`__
        of the SysML specification for more details.
        """

    @property
    def seq_parameter(self) -> ReferenceUsage | None:
        """The parameter owning ``seq_argument``."""

    @property
    def loop_variable(self) -> ReferenceUsage | None:
        """
        Implementation of ``loop_variable`` defined in the SysML specification.

        **Specification**:

           The ``owned_feature`` of this ForLoopActionUsage that acts as the
           loop variable, which is assigned the successive values of the input
           sequence on each iteration. It is the ``owned_feature`` that
           redefines ``ForLoopAction::var``.

        See section
        `8.3.17.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=353>`__
        of the SysML specification for more details.
        """

    @property
    def loop_variable_member(self) -> ReferenceUsageAccessor:
        """Syside specific accessor for manipulating ``loop_variable``."""

class ForkNode(ControlNode):
    """
    Implementation of ``ForkNode`` defined in the SysML specification.

    **Specification**:

       A ``ForkNode`` is a ``ControlNode`` that must be followed by
       successor ``Actions`` as given by all its outgoing ``Successions``.

    For language description, see section
    `7.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=132>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=352>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ForkNode'

    STD: tuple[type[ForkNode], ...] = (ForkNode,)

    if TYPE_CHECKING:
        Std = ForkNode

class FormatOptions:
    def __init__(self) -> None: ...

    @property
    def null_expression(self) -> FormatPreserved[NullFormat]:
        """
        Controls ``NullExpression`` formatting:

        - ``null``: always formatted as ``null``
        - ``brackets``: always formatted as ``()``
        """

    @null_expression.setter
    def null_expression(self, arg: FormatPreserved[NullFormat], /) -> None: ...

    @property
    def literal_real(self) -> FloatFormat:
        """
        Controls ``LiteralReal`` formatting. Only applies to those numbers that
        are not in the source text.
        """

    @literal_real.setter
    def literal_real(self, arg: FloatFormat, /) -> None: ...

    @property
    def strip_unnecessary_quotes(self) -> bool:
        """
        Controls identifier formatting. If true, strips quotes from identifiers
        if the name doesn’t have restricted characters
        """

    @strip_unnecessary_quotes.setter
    def strip_unnecessary_quotes(self, arg: bool, /) -> None: ...

    @property
    def sequence_expression_trailing_comma(self) -> OptionalToken:
        """Controls ``SequenceExpression`` trailing comma formatting."""

    @sequence_expression_trailing_comma.setter
    def sequence_expression_trailing_comma(self, arg: OptionalToken, /) -> None: ...

    @property
    def operator_break(self) -> OperatorBreak:
        """
        Controls binary operator placement on line breaks.

        - ``after``: operators are placed on the same line as the LHS expression
        - ``before``: operators are placed on the same line as the RHS
          expression
        """

    @operator_break.setter
    def operator_break(self, arg: OperatorBreak, /) -> None: ...

    @property
    def comment_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``comment`` keyword formatting:

        - ``always``: ``comment`` will always be printed
        - ``as-needed``: ``comment`` will only be printed as needed
        """

    @comment_keyword.setter
    def comment_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def comment_about_break(self) -> OptionalKw:
        """
        Controls line break preceding ``about`` in ``Comment``:

        - ``always``: about list is always on a new line
        - ``as-needed``: printer tries to fit about list on the previous line
        """

    @comment_about_break.setter
    def comment_about_break(self, arg: OptionalKw, /) -> None: ...

    @property
    def markdown_comments(self) -> bool:
        """
        Controls ``Comment`` and ``Documentation`` body formatting. If true,
        trailing whitespace is preserved on each line but last.
        """

    @markdown_comments.setter
    def markdown_comments(self, arg: bool, /) -> None: ...

    @property
    def textual_representation_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``rep`` keyword formatting:

        - ``always``: ``rep`` will always be printed
        - ``as-needed``: ``rep`` will only be printed as needed
        """

    @textual_representation_keyword.setter
    def textual_representation_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def textual_representation_language_break(self) -> OptionalKw:
        """
        Controls line break preceding ``language`` in ``TextualRepresentation``:

        - ``always``: language is always on a new line
        - ``as-needed``: printer tries to fit language on the previous line
        """

    @textual_representation_language_break.setter
    def textual_representation_language_break(self, arg: OptionalKw, /) -> None: ...

    @property
    def empty_namespace_brackets(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls formatting of empty children blocks:

        - ``always``: empty blocks are always formatted as ``{}``
        - ``never``: empty blocks are always formatted as a trailing ``;``
        """

    @empty_namespace_brackets.setter
    def empty_namespace_brackets(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def merge_declaration_disjoining(self) -> bool:
        """
        Controls disjoining formatting in type declarations. If true, all
        disjoinings are merged into a single group. Requires KerML.
        """

    @merge_declaration_disjoining.setter
    def merge_declaration_disjoining(self, arg: bool, /) -> None: ...

    @property
    def merge_unioning(self) -> bool:
        """
        Controls unioning formatting in type declarations. If true, all
        unionings are merged into a single group. Requires KerML.
        """

    @merge_unioning.setter
    def merge_unioning(self, arg: bool, /) -> None: ...

    @property
    def merge_intersecting(self) -> bool:
        """
        Controls intersecting formatting in type declarations. If true, all
        intersectings are merged into a single group. Requires KerML.
        """

    @merge_intersecting.setter
    def merge_intersecting(self, arg: bool, /) -> None: ...

    @property
    def merge_differencing(self) -> bool:
        """
        Controls differencing formatting in type declarations. If true, all
        differencings are merged into a single group. Requires KerML.
        """

    @merge_differencing.setter
    def merge_differencing(self, arg: bool, /) -> None: ...

    @property
    def merge_feature_chaining(self) -> bool:
        """
        Controls feature chaining formatting in feature declarations. If true,
        all feature chainings are merged into a single group. Requires KerML.
        """

    @merge_feature_chaining.setter
    def merge_feature_chaining(self, arg: bool, /) -> None: ...

    @property
    def merge_declaration_type_featuring(self) -> bool:
        """
        Controls type featuring formatting in feature declarations. If true, all
        type featurings are merged into a single group. Requires KerML.
        """

    @merge_declaration_type_featuring.setter
    def merge_declaration_type_featuring(self, arg: bool, /) -> None: ...

    @property
    def declaration_specialization(self) -> FormatPreserved[KwToken]:
        """Controls specialization formatting."""

    @declaration_specialization.setter
    def declaration_specialization(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def declaration_conjugation(self) -> FormatPreserved[KwToken]:
        """Controls conjugation formatting. Requires KerML."""

    @declaration_conjugation.setter
    def declaration_conjugation(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def declaration_subsetting(self) -> FormatPreserved[KwToken]:
        """Controls subsetting formatting."""

    @declaration_subsetting.setter
    def declaration_subsetting(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def declaration_subclassification(self) -> FormatPreserved[KwToken]:
        """Controls subclassification formatting."""

    @declaration_subclassification.setter
    def declaration_subclassification(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def declaration_redefinition(self) -> FormatPreserved[KwToken]:
        """Controls redefinition formatting."""

    @declaration_redefinition.setter
    def declaration_redefinition(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def declaration_reference_subsetting(self) -> FormatPreserved[KwToken]:
        """Controls reference subsetting formatting in feature declarations."""

    @declaration_reference_subsetting.setter
    def declaration_reference_subsetting(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def declaration_cross_subsetting(self) -> FormatPreserved[KwToken]:
        """Controls cross subsetting formatting in feature declarations."""

    @declaration_cross_subsetting.setter
    def declaration_cross_subsetting(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def declaration_feature_typing(self) -> FormatPreserved[KwToken]:
        """Controls feature typing formatting."""

    @declaration_feature_typing.setter
    def declaration_feature_typing(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def declaration_conjugated_port_typing(self) -> FormatPreserved[KwToken]:
        """Controls conjugated port typing formatting in port declarations."""

    @declaration_conjugated_port_typing.setter
    def declaration_conjugated_port_typing(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def feature_value_equals(self) -> FormatPreserved[OptionalKw]:
        """
        Controls feature value equals token formatting whenever it can be
        omitted:

        - ``as-needed``: ``=`` will only be printed if it is required by the
          grammar
        - ``always``: ``=`` will be always printed when it is acceptable by the
          grammar
        """

    @feature_value_equals.setter
    def feature_value_equals(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def feature_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``feature`` keyword formatting in KerML:

        - ``always``: ``feature`` keyword is always printed
        - ``as-needed``: ``feature`` keyword is printed only when required by
          the grammar
        """

    @feature_keyword.setter
    def feature_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def public_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``public`` keyword formatting:

        - ``always``: ``public`` will always be printed
        - ``never``: ``public`` will never be printed
        """

    @public_keyword.setter
    def public_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def specialization_keyword_specialization(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``specialization`` keyword formatting in specialization
        members:

        - ``always``: ``specialization`` will always be printed.
        - ``as-needed``: ``specialization`` will be printed only if required by
          the grammar
        """

    @specialization_keyword_specialization.setter
    def specialization_keyword_specialization(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def specialization_keyword_subclassification(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``specialization`` keyword formatting in subclassification
        members:

        - ``always``: ``specialization`` will always be printed.
        - ``as-needed``: ``specialization`` will be printed only if required by
          the grammar
        """

    @specialization_keyword_subclassification.setter
    def specialization_keyword_subclassification(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def specialization_keyword_feature_typing(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``specialization`` keyword formatting in feature typing
        members:

        - ``always``: ``specialization`` will always be printed.
        - ``as-needed``: ``specialization`` will be printed only if required by
          the grammar
        """

    @specialization_keyword_feature_typing.setter
    def specialization_keyword_feature_typing(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def specialization_keyword_subsetting(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``specialization`` keyword formatting in subsetting members:

        - ``always``: ``specialization`` will always be printed.
        - ``as-needed``: ``specialization`` will be printed only if required by
          the grammar
        """

    @specialization_keyword_subsetting.setter
    def specialization_keyword_subsetting(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def specialization_keyword_redefinition(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``specialization`` keyword formatting in redefinition members:

        - ``always``: ``specialization`` will always be printed.
        - ``as-needed``: ``specialization`` will be printed only if required by
          the grammar
        """

    @specialization_keyword_redefinition.setter
    def specialization_keyword_redefinition(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def conjugation_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``conjugation`` keyword formatting in conjugation members:

        - ``always``: ``conjugation`` will always be printed.
        - ``as-needed``: ``conjugation`` will be printed only if required by the
          grammar
        """

    @conjugation_keyword.setter
    def conjugation_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def disjoining_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``disjoining`` keyword formatting in disjoining members:

        - ``always``: ``disjoining`` will always be printed.
        - ``as-needed``: ``disjoining`` will be printed only if required by the
          grammar
        """

    @disjoining_keyword.setter
    def disjoining_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def inverting_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``inverting`` keyword formatting in inverting members:

        - ``always``: ``inverting`` will always be printed.
        - ``as-needed``: ``inverting`` will be printed only if required by the
          grammar
        """

    @inverting_keyword.setter
    def inverting_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def featuring_of_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``of`` keyword formatting in type featuring members:

        - ``always``: ``of`` will always be printed.
        - ``as-needed``: ``of`` will be printed only if required by the grammar
        """

    @featuring_of_keyword.setter
    def featuring_of_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def dependency_from_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``from`` keyword formatting in dependencies:

        - ``always``: ``from`` will always be printed.
        - ``as-needed``: ``from`` will be printed only if required by the
          grammar
        """

    @dependency_from_keyword.setter
    def dependency_from_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def invariant_true_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``true`` keyword formatting in invariants:

        - ``never``: ``true`` is never printed
        - ``always``: ``true`` is always printed if invariant is not negated
        """

    @invariant_true_keyword.setter
    def invariant_true_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def multiplicity_placement(self) -> MultiPlacement:
        """
        Controls multiplicity placement in type declarations:

        - ``first``: multiplicity is printed before any specializations
        - ``first-specialization``: multiplicity is printed after the first
          specialization
        - ``last``: multiplicity is printed after all specializations
        """

    @multiplicity_placement.setter
    def multiplicity_placement(self, arg: MultiPlacement, /) -> None: ...

    @property
    def metadata_feature_keyword(self) -> FormatPreserved[KwToken]:
        """Controls metadata feature keyword used."""

    @metadata_feature_keyword.setter
    def metadata_feature_keyword(self, arg: FormatPreserved[KwToken], /) -> None: ...

    @property
    def metadata_body_feature_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``feature`` (KerML) and ``ref`` (SysML) keyword formatting in
        metadata features:

        - ``always``: keywords are always printed
        - ``never``: keywords are never printed
        """

    @metadata_body_feature_keyword.setter
    def metadata_body_feature_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def metadata_body_feature_redefines(self) -> FormatPreserved[OptionalKwToken]:
        """
        Controls first feature redefinition formatting inside MetadataFeature
        bodies:

        - ``keyword``: ``redefines`` is printed
        - ``token``: ``:>>`` is printed
        - ``none``: nothing is printed
        """

    @metadata_body_feature_redefines.setter
    def metadata_body_feature_redefines(self, arg: FormatPreserved[OptionalKwToken], /) -> None: ...

    @property
    def binary_allocation_usages(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls allocation usage ends formatting:

        - ``always``: binary ends are printed as binary declaration
        - ``never``: binary ends are printed as nary declaration
        """

    @binary_allocation_usages.setter
    def binary_allocation_usages(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def binary_connectors(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls connector ends formatting:

        - ``always``: binary ends are printed as binary declaration
        - ``never``: binary ends are printed as nary declaration
        """

    @binary_connectors.setter
    def binary_connectors(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def binary_connectors_from_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``from`` keyword formatting in binary connectors:

        - ``always``: ``from`` is always printed
        - ``as-needed``: ``from`` is only printed when required by the grammar
        """

    @binary_connectors_from_keyword.setter
    def binary_connectors_from_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def binary_binding_connectors(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls binding connector ends formatting:

        - ``always``: binary ends are printed as binary declaration
        - ``never``: binary ends are printed as nary declaration
        """

    @binary_binding_connectors.setter
    def binary_binding_connectors(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def binary_binding_connector_of_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``of`` keyword formatting in binary binding connectors:

        - ``always``: ``of`` is always printed
        - ``as-needed``: ``of`` is only printed when required by the grammar
        """

    @binary_binding_connector_of_keyword.setter
    def binary_binding_connector_of_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def binary_successions(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls succession ends formatting:

        - ``always``: binary ends are printed as binary declaration
        - ``never``: binary ends are printed as nary declaration
        """

    @binary_successions.setter
    def binary_successions(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def binary_succession_first_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``first`` keyword formatting in binary successions:

        - ``always``: ``first`` is always printed
        - ``as-needed``: ``first`` is only printed when required by the grammar
        """

    @binary_succession_first_keyword.setter
    def binary_succession_first_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def flow_from_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``from`` keyword formatting in flows:

        - ``always``: ``from`` is always printed
        - ``as-needed``: ``from`` is only printed when required by the grammar
        """

    @flow_from_keyword.setter
    def flow_from_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def succession_flow_from_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``from`` keyword formatting in succession flows:

        - ``always``: ``from`` is always printed
        - ``as-needed``: ``from`` is only printed when required by the grammar
        """

    @succession_flow_from_keyword.setter
    def succession_flow_from_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def flow_usage_from_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``from`` keyword formatting in flow usages:

        - ``always``: ``from`` is always printed
        - ``as-needed``: ``from`` is only printed when required by the grammar
        """

    @flow_usage_from_keyword.setter
    def flow_usage_from_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def succession_flow_usage_from_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``from`` keyword formatting in succession flow usages:

        - ``always``: ``from`` is always printed
        - ``as-needed``: ``from`` is only printed when required by the grammar
        """

    @succession_flow_usage_from_keyword.setter
    def succession_flow_usage_from_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def ordered_nonunique_priority(self) -> FormatPreserved[MultiOrder]:
        """
        Controls ``ordered`` and ``nonunique`` print order:

        - ``ordered``: ``ordered`` is printed first
        - ``nonunique``: ``nonunique`` is printed first
        """

    @ordered_nonunique_priority.setter
    def ordered_nonunique_priority(self, arg: FormatPreserved[MultiOrder], /) -> None: ...

    @property
    def enum_member_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``enum`` keyword formatting inside enum definitions:

        - ``always``: ``enum`` is always printed
        - ``never``: ``enum`` is never printed
        """

    @enum_member_keyword.setter
    def enum_member_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def occurrence_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``occurrence`` keyword formatting in occurrence usages and
        definitions:

        - ``always``: ``occurrence`` is always printed
        - ``as-needed``: ``occurrence`` is only printed when required by the
          grammar
        """

    @occurrence_keyword.setter
    def occurrence_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def binding_connector_as_usage_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``binding`` formatting in binding connectors as usages:

        - ``always``: ``binding`` is always printed
        - ``as-needed``: ``binding`` is only printed when required by the
          grammar
        """

    @binding_connector_as_usage_keyword.setter
    def binding_connector_as_usage_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def succession_as_usage_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``succession`` formatting in successions as usages:

        - ``always``: ``succession`` is always printed
        - ``as-needed``: ``succession`` is only printed when required by the
          grammar
        """

    @succession_as_usage_keyword.setter
    def succession_as_usage_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def assert_constraint_usage_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``constraint`` formatting in assert constraint usages:

        - ``always``: ``constraint`` is always printed
        - ``as-needed``: ``constraint`` is only printed when required by the
          grammar
        """

    @assert_constraint_usage_keyword.setter
    def assert_constraint_usage_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def event_occurrence_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``occurrence`` keyword formatting in event occurrence usages:

        - ``always``: ``occurrence`` is always printed
        - ``as-needed``: ``occurrence`` is only printed when required by the
          grammar
        """

    @event_occurrence_keyword.setter
    def event_occurrence_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def exhibit_state_usage_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``state`` formatting in exhibit state usages:

        - ``always``: ``state`` is always printed
        - ``as-needed``: ``state`` is only printed when required by the grammar
        """

    @exhibit_state_usage_keyword.setter
    def exhibit_state_usage_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def include_use_case_usage_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``use case`` formatting in include use case usages:

        - ``always``: ``use case`` is always printed
        - ``as-needed``: ``use case`` is only printed when required by the
          grammar
        """

    @include_use_case_usage_keyword.setter
    def include_use_case_usage_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def perform_action_usage_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``action`` formatting in perform action usages:

        - ``always``: ``action`` is always printed
        - ``as-needed``: ``action`` is only printed when required by the grammar
        """

    @perform_action_usage_keyword.setter
    def perform_action_usage_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def satisfy_requirement_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``requirement`` formatting in satisfy requirement usages:

        - ``always``: ``requirement`` is always printed
        - ``as-needed``: ``requirement`` is only printed when required by the
          grammar
        """

    @satisfy_requirement_keyword.setter
    def satisfy_requirement_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def satisfy_requirement_assert_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``assert`` formatting in satisfy requirement usages:

        - ``always``: ``assert`` is always printed
        - ``never``: ``assert`` is never printed
        """

    @satisfy_requirement_assert_keyword.setter
    def satisfy_requirement_assert_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def allocation_usage_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``allocation`` formatting in allocation usages:

        - ``always``: ``allocation`` is always printed
        - ``as-needed``: ``allocation`` is only printed when required by the
          grammar
        """

    @allocation_usage_keyword.setter
    def allocation_usage_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def connection_usage_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``connection`` formatting in connection usages:

        - ``always``: ``connection`` is always printed
        - ``as-needed``: ``connection`` is only printed when required by the
          grammar
        """

    @connection_usage_keyword.setter
    def connection_usage_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def binary_connection_usages(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls connection usage ends formatting:

        - ``always``: binary ends are printed as binary declaration
        - ``never``: binary ends are printed as nary declaration
        """

    @binary_connection_usages.setter
    def binary_connection_usages(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def binary_interface_usages(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls interface usage ends formatting:

        - ``always``: binary ends are printed as binary declaration
        - ``never``: binary ends are printed as nary declaration
        """

    @binary_interface_usages.setter
    def binary_interface_usages(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def interface_usage_connect_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``connect`` formatting in interface usages:

        - ``always``: ``connect`` is always printed
        - ``as-needed``: ``connect`` is only printed when required by the
          grammar
        """

    @interface_usage_connect_keyword.setter
    def interface_usage_connect_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def action_node_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``action`` formatting in action nodes:

        - ``always``: ``action`` is always printed
        - ``as-needed``: ``action`` is printed only if required by the grammar
        """

    @action_node_keyword.setter
    def action_node_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def while_loop_parenthesize_condition(self) -> OptionalToken:
        """
        Controls ``while (...)`` while loop action condition expression
        formatting:

        - ``always``: expression is printed with parentheses
        - ``never``: expression is printed without parentheses
        - ``on-break``: expression is printed with parentheses only if it breaks
        """

    @while_loop_parenthesize_condition.setter
    def while_loop_parenthesize_condition(self, arg: OptionalToken, /) -> None: ...

    @property
    def while_loop_parenthesize_until(self) -> OptionalToken:
        """
        Controls ``until (...)`` while loop action condition expression
        formatting:

        - ``always``: expression is printed with parentheses
        - ``never``: expression is printed without parentheses
        - ``on-break``: expression is printed with parentheses only if it breaks
        """

    @while_loop_parenthesize_until.setter
    def while_loop_parenthesize_until(self, arg: OptionalToken, /) -> None: ...

    @property
    def if_parenthesize_condition(self) -> OptionalToken:
        """
        Controls ``if (...)`` condition expression formatting:

        - ``always``: expression is printed with parentheses
        - ``never``: expression is printed without parentheses
        - ``on-break``: expression is printed with parentheses only if it breaks
        """

    @if_parenthesize_condition.setter
    def if_parenthesize_condition(self, arg: OptionalToken, /) -> None: ...

    @property
    def transition_usage_parenthesize_guard(self) -> OptionalToken:
        """
        Controls ``if (...)`` condition expression in transition usages
        formatting:

        - ``always``: expression is printed with parentheses
        - ``never``: expression is printed without parentheses
        - ``on-break``: expression is printed with parentheses only if it breaks
        """

    @transition_usage_parenthesize_guard.setter
    def transition_usage_parenthesize_guard(self, arg: OptionalToken, /) -> None: ...

    @property
    def element_filter_parenthesize(self) -> OptionalToken:
        """
        Controls ``filter (...)`` condition expression in element filter
        memberships formatting:

        - ``always``: expression is printed with parentheses
        - ``never``: expression is printed without parentheses
        - ``on-break``: expression is printed with parentheses only if it breaks
        """

    @element_filter_parenthesize.setter
    def element_filter_parenthesize(self, arg: OptionalToken, /) -> None: ...

    @property
    def transition_usage_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``transition`` formatting in transition usages:

        - ``always``: ``transition`` is always printed if permitted by the
          grammar
        - ``as-needed``: ``transition`` is only printed if required by the
          grammar
        """

    @transition_usage_keyword.setter
    def transition_usage_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def transition_usage_first_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``first`` formatting in transition usages:

        - ``always``: ``first`` is always printed if permitted by the grammar
        - ``as-needed``: ``first`` is only printed if required by the grammar
        """

    @transition_usage_first_keyword.setter
    def transition_usage_first_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def framed_concern_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``concern`` formatting in framed concern usages:

        - ``always``: ``concern`` is always printed
        - ``as-needed``: ``concern`` is only printed if required by the grammar
        """

    @framed_concern_keyword.setter
    def framed_concern_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def reference_usage_keyword(self) -> FormatPreserved[OptionalKw]:
        """
        Controls ``ref`` formatting in reference usages:

        - ``always``: ``ref`` is always printed
        - ``as-needed``: ``ref`` is only printed if required by the grammar
        """

    @reference_usage_keyword.setter
    def reference_usage_keyword(self, arg: FormatPreserved[OptionalKw], /) -> None: ...

    @property
    def attribute_usage_reference_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``ref`` formatting in attribute usages:

        - ``always``: ``ref`` is always printed
        - ``never``: ``ref`` is never printed
        """

    @attribute_usage_reference_keyword.setter
    def attribute_usage_reference_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def event_occurrence_reference_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``ref`` formatting in event occurrence usages:

        - ``always``: ``ref`` is always printed
        - ``never``: ``ref`` is never printed
        """

    @event_occurrence_reference_keyword.setter
    def event_occurrence_reference_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def port_usage_reference_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``ref`` formatting in attribute usages:

        - ``always``: ``ref`` is always printed
        - ``never``: ``ref`` is never printed
        """

    @port_usage_reference_keyword.setter
    def port_usage_reference_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def connection_usage_reference_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``ref`` formatting in connection usages:

        - ``always``: ``ref`` is always printed
        - ``never``: ``ref`` is never printed
        """

    @connection_usage_reference_keyword.setter
    def connection_usage_reference_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def connector_as_usage_reference_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``ref`` formatting in connector as usages:

        - ``always``: ``ref`` is always printed
        - ``never``: ``ref`` is never printed
        """

    @connector_as_usage_reference_keyword.setter
    def connector_as_usage_reference_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def exhibit_state_reference_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``ref`` formatting in exhibit state usages:

        - ``always``: ``ref`` is always printed
        - ``never``: ``ref`` is never printed
        """

    @exhibit_state_reference_keyword.setter
    def exhibit_state_reference_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def include_use_case_reference_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``ref`` formatting in include use case usages:

        - ``always``: ``ref`` is always printed
        - ``never``: ``ref`` is never printed
        """

    @include_use_case_reference_keyword.setter
    def include_use_case_reference_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def perform_action_reference_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``ref`` formatting in perform action usages:

        - ``always``: ``ref`` is always printed
        - ``never``: ``ref`` is never printed
        """

    @perform_action_reference_keyword.setter
    def perform_action_reference_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def interface_port_keyword(self) -> FormatPreserved[AlwaysNever]:
        """
        Controls ``port`` formatting of default interface ends:

        - ``always``: ``port`` is always printed
        - ``never``: ``port`` is never printed
        """

    @interface_port_keyword.setter
    def interface_port_keyword(self, arg: FormatPreserved[AlwaysNever], /) -> None: ...

    @property
    def force_break_bodies(self) -> bool:
        """If true, any child elements inside bodies will be printed on new line."""

    @force_break_bodies.setter
    def force_break_bodies(self, arg: bool, /) -> None: ...

    __cpp_name__: str = 'syside::sysml::FormatOptions'

class FormatPreserved(Generic[T]):
    @property
    def preserve(self) -> bool:
        """
        Controls formatting in majority of cases. Set to true to preserve tokens
        and keywords as they appear in the source code.
        """

    @preserve.setter
    def preserve(self, arg: bool, /) -> None: ...

    @property
    def fallback(self) -> T:
        """
        Controls ``preserve`` formatting for cases when there is no associated
        source text or ``preserve`` is false.
        """

    @fallback.setter
    def fallback(self, arg: T, /) -> None: ...

    __cpp_name__: str = 'syside::py::PyFormatPreserved'

class FramedConcernMembership(RequirementConstraintMembership):
    """
    Implementation of ``FramedConcernMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``FramedConcernMembership`` is a
       ``RequirementConstraintMembership`` for a framed ``ConcernUsage`` of
       a ``RequirementDefinition`` or ``RequirementUsage``.

    For language description, see section
    `7.21.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=167>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=389>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::FramedConcernMembership'

    STD: tuple[type[FramedConcernMembership], ...] = (FramedConcernMembership,)

    if TYPE_CHECKING:
        Std = FramedConcernMembership

    @property
    def owned_concern(self) -> ConcernUsage | None:
        """
        Implementation of ``owned_concern`` defined in the SysML specification.

        **Specification**:

           The ``ConcernUsage`` that is the ``owned_constraint`` of this
           ``FramedConcernMembership``.

        See section
        `8.3.21.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=389>`__
        of the SysML specification for more details.
        """

    @property
    def referenced_concern(self) -> ConcernUsage | None:
        """
        Implementation of ``referenced_concern`` defined in the SysML
        specification.

        **Specification**:

           The ``ConcernUsage`` that is referenced through this
           ``FramedConcernMembership``. It is the ``referenced_constraint`` of
           the ``FramedConcernMembership`` considered as a
           ``RequirementConstraintMembership``, which must be a
           ``ConcernUsage``.

        See section
        `8.3.21.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=389>`__
        of the SysML specification for more details.
        """

class Function(Behavior):
    """
    Implementation of ``Function`` defined in the KerML specification.

    **Specification**:

       A ``Function`` is a ``Behavior`` that has an ``out`` ``parameter``
       that is identified as its ``result``. A ``Function`` represents the
       performance of a calculation that produces the values of its
       ``result`` ``parameter``. This calculation may be decomposed into
       ``Expressions`` that are ``steps`` of the ``Function``.

    For language description, see section
    `7.4.8.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=80>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Function'

    STD: tuple[Union[type[Function], type[CalculationDefinition], type[ConstraintDefinition]], ...] = (Function, CalculationDefinition, ConstraintDefinition)

    if TYPE_CHECKING:
        Std = Union[Function, CalculationDefinition, ConstraintDefinition]

    @property
    def is_model_level_evaluable(self) -> bool:
        """
        Implementation of ``is_model_level_evaluable`` defined in the KerML
        specification.

        **Specification**:

           Whether this ``Function`` can be used as the ``function`` of a
           model-level evaluable ``InvocationExpression``. Certain ``Functions``
           from the Kernel Functions Library are considered to have
           ``is_model_level_evaluable = true``. For all other ``Functions`` it
           is ``false``.

           **Note:** See the specification of the KerML concrete syntax notation
           for ``Expressions`` for an identification of which library
           ``Functions`` are model-level evaluable.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
        of the KerML specification for more details.
        """

    @property
    def expressions(self) -> LazyIterator[Expression | CalculationUsage | ConstraintUsage]:
        """
        Implementation of ``expression`` defined in the KerML specification.

        **Specification**:

           The ``Expressions`` that are ``steps`` in the calculation of the
           ``result`` of this ``Function``.

           The set of expressions that represent computational steps or parts of
           a system of equations within the Function.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
        of the KerML specification for more details.
        """

    @property
    def result(self) -> Feature | None:
        """
        Implementation of ``result`` defined in the KerML specification.

        **Specification**:

           The object or value that is the result of evaluating the Function.

           The ``result`` ``parameter`` of the ``Function``, which is owned by
           the ``Function`` via a ``ReturnParameterMembership``.

        See section
        `8.3.4.7.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=227>`__
        of the KerML specification for more details.
        """

    @property
    def any_result(self) -> Feature | None:
        """``result`` that also considers specialized ``Functions``."""

    @property
    def result_expression(self) -> Expression | None:
        """
        The result expression of this ``Function`` owned by ``ResultExpressionMembership``.
        """

    @property
    def result_expression_member(self) -> ResultExpressionAccessor:
        """Syside specific accessor for manipulating ``result_expression``."""

class GuardAccessor(OwnedMemberAccessor[TransitionFeatureMembership, Expression]):
    @overload
    def set_member_element[M: Expression](self, element: M, name: NameID = ...) -> tuple[TransitionFeatureMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Expression](self, element: M | None, name: NameID = ...) -> tuple[TransitionFeatureMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Expression](self, element: type[M]) -> tuple[TransitionFeatureMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class Heritage(ChainedChildrenNodes[Conjugation | Specialization, Type]):
    def append[R: Conjugation | Specialization, M: Type](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    def replace[R: Conjugation | Specialization, M: Type](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    def insert[R: Conjugation | Specialization, M: Type](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    def append_chain[R: Conjugation | Specialization](self, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Append a relationship with an owned chaining. Raises ``TypeError`` if the relationship type cannot have owned
        chaining in the textual syntax.
        """

    def insert_chain[R: Conjugation | Specialization](self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Insert a relationship with an owned chaining at the specified index. Raises ``TypeError`` if the relationship
        type cannot have owned chaining in the textual syntax.
        """

    def replace_chain_at[R: Conjugation | Specialization](self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Replace the relationship and its related element at the specified index with an owned chaining. The relationship
        may be reused if its type matches the current relationship at that index. Raises ``TypeError`` if the
        relationship type cannot have owned chaining in the textual syntax.
        """

class HostType(enum.Enum):
    none = 0
    """No host is specified."""

    Name = 1
    """A host is specified by reg-name."""

    IPv4 = 2
    """A host is specified by ipv4_address."""

    IPv6 = 3
    """A host is specified by ipv6_address."""

    IPvFuture = 4
    """A host is specified by IPvFuture."""

class IOSchedule:
    @staticmethod
    def make_empty_schedule(multithreaded: bool = False) -> IOSchedule: ...

    @property
    def text_documents(self) -> TextDocuments | None:
        """``TextDocuments`` that new text files will be opened in"""

    @text_documents.setter
    def text_documents(self, arg: TextDocuments | None) -> None: ...

    @property
    def is_multithreaded(self) -> bool:
        """
        If true, new text documents will be constructed for multithreaded application, otherwise - single threaded. Only has effect if no ``TextDocuments`` is set.
        """

    @is_multithreaded.setter
    def is_multithreaded(self, arg: bool, /) -> None: ...

    def set_multithreaded(self, arg: bool, /) -> IOSchedule: ...

    def assign_text_documents(self, arg: TextDocuments, /) -> IOSchedule:
        """Set ``TextDocuments`` that new text files will be opened in"""

    def add_file(self, path: str | os.PathLike[AnyStr], language: str, tier: DocumentTier = DocumentTier.Project) -> IOSchedule: ...

    def add_source(self, url: Url, contents: str, language: str, tier: DocumentTier = DocumentTier.Project) -> IOSchedule: ...

    @property
    def size(self) -> int:
        """Returns the number of currently scheduled documents"""

    def set_completion_callback(self, arg: Callable[[SharedMutex[TextDocument], IOSchedule.CallbackData], None], /) -> IOSchedule:
        """
        Set completion callback that will be invoked when a text document is
        ready. The second callback argument contains the index of the document,
        and order between `add_*` is preserved. Note that this may be called from
        multiple other threads so this should be thread-safe, e.g. by sizing a
        result buffer to `size()` before executing this schedule and only
        modifying the element at the callback `index`.

        On a single-thread executor, only the first enqueued unique source will
        invoke this callback. On multithreaded executors, any one of duplicated
        sources may invoke this callback, however it is unspecified which.
        Deduplication is performed based on resolved absolute URLs.
        """

    __cpp_name__: str = 'syside::IOSchedule'

    class CallbackData:
        @property
        def index(self) -> int:
            """
            The index of the associated text document. Matches the order it was added to the schedule.
            """

        @index.setter
        def index(self, arg: int, /) -> None: ...

        @property
        def tier(self) -> DocumentTier:
            """Tier the text document was added with."""

        @tier.setter
        def tier(self, arg: DocumentTier, /) -> None: ...

class IPv4Address:
    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, arg: int, /) -> None: ...

    @overload
    def __init__(self, arg: Sequence[int], /) -> None: ...

    def to_bytes(self) -> list[int]: ...

    def to_uint(self) -> int: ...

    def __int__(self) -> int: ...

    def __deepcopy__(self) -> IPv4Address: ...

    def __copy__(self) -> IPv4Address: ...

    def __str__(self) -> str: ...

    def __repr__(self) -> str: ...

    @property
    def is_loopback(self) -> bool: ...

    @property
    def is_unspecified(self) -> bool: ...

    @property
    def is_multicast(self) -> bool: ...

    @staticmethod
    def any() -> IPv4Address: ...

    @staticmethod
    def loopback() -> IPv4Address: ...

    @staticmethod
    def broadcast() -> IPv4Address: ...

class IPv6Address:
    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, arg: Sequence[int], /) -> None: ...

    @overload
    def __init__(self, arg: str, /) -> None: ...

    def to_bytes(self) -> list[int]: ...

    def __deepcopy__(self) -> IPv6Address: ...

    def __copy__(self) -> IPv6Address: ...

    def __str__(self) -> str: ...

    def __repr__(self) -> str: ...

    @property
    def is_loopback(self) -> bool: ...

    @property
    def is_unspecified(self) -> bool: ...

    @property
    def is_v4_mapped(self) -> bool: ...

    @staticmethod
    def loopback() -> IPv6Address: ...

class IdMap:
    """
    ``DeserializedModel`` compatible mapping for elements. This will typically be used for linking pending references:

    .. code-block:: python

        map = IdMap()
        models_reports = [
            deserializer.accept(document, my_reader(input), DESERIALIZE_STANDARD)
            for document, input in zip(documents, inputs)
        ]
        for document in documents:
            map.insert_or_assign(document)
        reports_linked = [model.link(map) for model, _ in models_reports]
    """

    def __init__(self) -> None: ...

    def insert_or_assign(self, document: Document) -> tuple[int, bool]:
        """
        Insert all elements from ``document`` into this map.

        Returns the number of elements inserted, and ``True`` if insertion took place,
        ``False`` if ``document`` was already mapped.
        """

    def try_insert(self, document: Document) -> tuple[int, bool]:
        """
        Try insert all elements from ``document`` into this map.

        Returns the number of elements inserted, and ``True`` if insertion took place.
        This will not override already mapped document elements.
        """

    @overload
    def erase(self, document: Document) -> int:
        """
        Erase all elements assigned to ``document`` from this map.

        Returns the number of elements erased.
        """

    @overload
    def erase(self, uri: str) -> int:
        """
        Erase all elements assigned to document with ``uri`` from this map.

        Returns the number of elements erased.
        """

    def clear(self) -> None:
        """Clear all mapped elements."""

    def reserve(self, n: int) -> None:
        """Reserve space for ``n`` document mappings."""

    def find(self, uri: str, id: uuid.UUID) -> Element | None:
        """
        Find an element at document with ``uri`` that has ``id``.

        Returns the element found if any.
        """

    def search(self, id: uuid.UUID) -> Element | None:
        """
        Search across all registered documents for a matching id. This has complexity O(n)
        since it searches each document separately.

        Returns the element found if any.
        """

    def __call__(self, uri: str, id: uuid.UUID) -> Element | None:
        """
        Short-hand for ``find`` or ``search``. Will fall back to ``search`` if ``uri`` is empty.
        """

class IfActionUsage(ActionUsage):
    """
    Implementation of ``IfActionUsage`` defined in the SysML specification.

    **Specification**:

       An ``IfActionUsage`` is an ``ActionUsage`` that specifies that the
       ``then_action`` ``ActionUsage`` should be performed if the result of
       the ``if_argument`` ``Expression`` is true. It may also optionally
       specify an ``else_action`` ``ActionUsage`` that is performed if the
       result of the ``if_argument`` is false.

    For language description, see section
    `7.17.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=142>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=354>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::IfActionUsage'

    STD: tuple[type[IfActionUsage], ...] = (IfActionUsage,)

    if TYPE_CHECKING:
        Std = IfActionUsage

    @property
    def else_action(self) -> ActionUsage | None:
        """
        Implementation of ``else_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` that is to be performed if the result of the
           ``if_argument`` is false. It is the (optional) third ``parameter`` of
           the ``IfActionUsage``.

        See section
        `8.3.17.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=354>`__
        of the SysML specification for more details.
        """

    @property
    def else_action_member(self) -> ActionParameterAccessor:
        """Syside specific accessor for manipulating ``else_action``."""

    @property
    def then_action(self) -> ActionUsage | None:
        """
        Implementation of ``then_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` that is to be performed if the result of the
           ``if_argument`` is true. It is the second ``parameter`` of the
           ``IfActionUsage``.

        See section
        `8.3.17.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=355>`__
        of the SysML specification for more details.
        """

    @property
    def then_action_member(self) -> ActionParameterAccessor:
        """Syside specific accessor for manipulating ``then_action``."""

    @property
    def if_argument(self) -> Expression | None:
        """
        Implementation of ``if_argument`` defined in the SysML specification.

        **Specification**:

           The ``Expression`` whose result determines whether the
           ``then_action`` or (optionally) the ``else_action`` is performed. It
           is the first ``parameter`` of the ``IfActionUsage``.

        See section
        `8.3.17.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=355>`__
        of the SysML specification for more details.
        """

    @property
    def if_argument_member(self) -> ExpressionParameterAccessor:
        """Syside specific accessor for manipulating ``if_argument``."""

class ImplicitSpecializationKind(enum.Enum):
    AccessedFeature = 0

    ActionTransition = 1

    After = 2

    AnnotatedElement = 3

    Assumption = 4

    At = 5

    Base = 6

    BaseType = 7

    Binary = 8

    BinaryObject = 9

    CaseActor = 10

    CheckedConstraint = 11

    Classifier = 12

    Concern = 13

    DataValue = 14

    Decision = 15

    Do = 16

    Effect = 17

    EnclosedPerformance = 18

    Entry = 19

    ExclusiveState = 20

    Exit = 21

    Feature = 22

    FeatureWrite = 23

    Flow = 24

    Guard = 25

    IfThenElse = 26

    IncomingTransfer = 27

    Life = 28

    LoopVariable = 29

    Merge = 30

    Message = 31

    Negated = 32

    Object = 33

    Occurrence = 34

    OwnedAction = 35

    OwnedPerformance = 36

    OwnedPort = 37

    Participant = 38

    Payload = 39

    PerformedAction = 40

    Portion = 41

    Requirement = 42

    RequirementActor = 43

    RequirementStakeholder = 44

    Satisfied = 45

    Snapshot = 46

    SourceOutput = 47

    StartingAt = 48

    StateTransition = 49

    SubAnalysisCase = 50

    SubUseCase = 51

    SubVerificationCase = 52

    Subaction = 53

    Subcalculation = 54

    Subcase = 55

    Subitem = 56

    Subobject = 57

    Suboccurrence = 58

    Subpart = 59

    Subperformance = 60

    Subport = 61

    Subrendering = 62

    Subrequirement = 63

    Substate = 64

    Subview = 65

    Target = 66

    TargetInput = 67

    Timeslice = 68

    TransitionLink = 69

    Trigger = 70

    Verification = 71

    ViewRendering = 72

    When = 73

class Import(Relationship):
    """
    Implementation of ``Import`` defined in the KerML specification.

    **Specification**:

       An ``Import`` is an ``Relationship`` between its
       ``import_owning_namespace`` and either a ``Membership`` (for a
       ``MembershipImport``) or another ``Namespace`` (for a
       ``NamespaceImport``), which determines a set of ``Memberships`` that
       become ``imported_memberships`` of the ``import_owning_namespace``.
       If ``is_import_all = false`` (the default), then only public
       ``Memberships`` are considered “visible”. If
       ``is_import_all = true``, then all ``Memberships`` are considered
       “visible”, regardless of their declared ``visibility``. If
       ``is_recursive = true``, then visible ``Memberships`` are also
       recursively imported from owned sub-``Namespaces``.

    For language description, see section
    `7.2.5.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=49>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=153>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Import'

    STD: tuple[type[Import], ...] = (Import,)

    if TYPE_CHECKING:
        Std = Import

    @property
    def is_recursive(self) -> bool:
        """
        Implementation of ``is_recursive`` defined in the KerML specification.

        **Specification**:

           Whether to recursively import Memberships from visible, owned
           sub-Namespaces.

        See section
        `8.3.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=153>`__
        of the KerML specification for more details.
        """

    @is_recursive.setter
    def is_recursive(self, arg: bool, /) -> None: ...

    @property
    def is_import_all(self) -> bool:
        """
        Implementation of ``is_import_all`` defined in the KerML specification.

        **Specification**:

           Whether to import memberships without regard to declared visibility.

        See section
        `8.3.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=153>`__
        of the KerML specification for more details.


        The setter will throw ``TypeError`` on ``Expose`` elements which are always ``is_import_all``.
        Use ``try_set_is_import_all`` instead for a non-throwing behaviour.
        """

    @is_import_all.setter
    def is_import_all(self, arg: bool, /) -> None: ...

    def try_set_is_import_all(self, arg: bool, /) -> bool:
        """
        Try setting ``is_import_all``. For ``Expose`` elements, this will return ``False`` instead of throwing ``TypeError`` when using ``is_import_all`` setter.
        """

    @property
    def import_target(self) -> Membership | Namespace | None:
        """The target element of this ``Import``."""

    @property
    def imported_element(self) -> Element | None:
        """
        Implementation of ``imported_element`` defined in the KerML
        specification.

        **Specification**:

           The effectively imported ``Element`` for this Import. For a
           ``MembershipImport``, this is the ``member_element`` of the
           ``imported_membership``. For a ``NamespaceImport``, it is the
           ``imported_namespace``.

        See section
        `8.3.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=153>`__
        of the KerML specification for more details.
        """

    @property
    def import_owning_namespace(self) -> Namespace | None:
        """
        Implementation of ``import_owning_namespace`` defined in the KerML
        specification.

        **Specification**:

           The Namespace into which Memberships are imported by this Import,
           which must be the ``owning_related_element`` of the Import.

        See section
        `8.3.2.4.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=153>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def owning_related_element(self) -> Element | None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> ContainerView[Element]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> ContainerView[Element]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

class IncludeUseCaseUsage(UseCaseUsage):
    """
    Implementation of ``IncludeUseCaseUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``IncludeUseCaseUsage`` is a ``UseCaseUsage`` that represents the
       inclusion of a ``UseCaseUsage`` by a ``UseCaseDefinition`` or
       ``UseCaseUsage``. Unless it is the ``IncludeUseCaseUsage`` itself,
       the ``UseCaseUsage`` to be included is related to the
       ``included_use_case`` by a ``ReferenceSubsetting`` ``Relationship``.
       An ``IncludeUseCaseUsage`` is also a PerformActionUsage, with its
       ``use_case_included`` as the ``performed_action``.

    For language description, see section
    `7.25.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=180>`__
    of the SysML specification. For more details on the model, see section
    `8.3.25.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=412>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::IncludeUseCaseUsage'

    STD: tuple[type[IncludeUseCaseUsage], ...] = (IncludeUseCaseUsage,)

    if TYPE_CHECKING:
        Std = IncludeUseCaseUsage

    @property
    def use_case_included(self) -> UseCaseUsage | None:
        """
        Implementation of ``use_case_included`` defined in the SysML
        specification.

        **Specification**:

           The ``UseCaseUsage`` to be included by this ``IncludeUseCaseUsage``.
           It is the ``performed_action`` of the ``IncludeUseCaseUsage``
           considered as a ``PerformActionUsage``, which must be a
           ``UseCaseUsage``.

        See section
        `8.3.25.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=413>`__
        of the SysML specification for more details.
        """

    @property
    def event_occurrence(self) -> OccurrenceUsage | ConnectionUsage | FlowUsage | None:
        """
        Implementation of ``event_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsage`` referenced as an event by this
           ``EventOccurrenceUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``EventOccurrenceUsage``, if
           there is one, and, otherwise, the ``EventOccurrenceUsage`` itself.

        See section
        `8.3.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @property
    def performed_action(self) -> ActionUsage | FlowUsage | None:
        """
        Implementation of ``performed_action`` defined in the SysML
        specification.

        **Specification**:

           The ``ActionUsage`` to be performed by this ``PerformedActionUsage``.
           It is the ``event_occurrence`` of the ``PerformActionUsage``
           considered as an ``EventOccurrenceUsage``, which must be an
           ``ActionUsage``.

        See section
        `8.3.17.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=358>`__
        of the SysML specification for more details.
        """

class IndexExpression(OperatorExpression):
    """
    Implementation of ``IndexExpression`` defined in the KerML
    specification.

    **Specification**:

       An ``IndexExpression`` is an ``OperatorExpression`` whose operator is
       ``"#"``, which resolves to the ``Function`` ``BasicFunctions::'#'``
       from the Kernel Functions Library.

    For language description, see section
    `7.4.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=86>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=237>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::IndexExpression'

    STD: tuple[type[IndexExpression], ...] = (IndexExpression,)

    if TYPE_CHECKING:
        Std = IndexExpression

class IndexedSymbol:
    @property
    def node(self) -> Element: ...

    @property
    def document(self) -> DocumentID: ...

    @property
    def library(self) -> LibraryID: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = ...

class Infinity:
    def __init__(self, positive: bool = True) -> None: ...

    @property
    def positive(self) -> bool: ...

    @positive.setter
    def positive(self, arg: bool, /) -> None: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::sysml::vm::Infinity'

class InstantiationExpression(Expression):
    """
    Implementation of ``InstantiationExpression`` defined in the KerML
    specification.

    **Specification**:

       An ``InstantiationExpression`` is an ``Expression`` that instantiates
       its ``instantiated_type``, binding some or all of the ``features`` of
       that ``Type`` to the ``results`` of its ``arguments``.

       ``InstantiationExpression`` is abstract, with concrete subclasses
       ``InvocationExpression`` and ``ConstructorExpression``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=238>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::InstantiationExpression'

    STD: tuple[type[InstantiationExpression], ...] = (InstantiationExpression,)

    if TYPE_CHECKING:
        Std = InstantiationExpression

    @property
    def arguments(self) -> ArgumentsAccessor:
        """
        Implementation of ``argument`` defined in the KerML specification.

        **Specification**:

           The ``Expressions`` whose ``results`` are bound to ``features`` of
           the ``instantiated_type``. The ``arguments`` are ordered consistent
           with the order of the ``features``, though they may not be one-to-one
           with all the ``features``.

           **Note.** The derivation of ``argument`` is given in the concrete
           subclasses of ``InstantiationExpression``.

        See section
        `8.3.4.8.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=238>`__
        of the KerML specification for more details.
        """

    @property
    def instantiated_type(self) -> Type | None:
        """
        Implementation of ``instantiated_type`` defined in the KerML
        specification.

        **Specification**:

           The ``Type`` that is being instantiated.

        See section
        `8.3.4.8.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=238>`__
        of the KerML specification for more details.
        """

    @property
    def instantiated_type_membership(self) -> Membership | None:
        """
        The ``Membership`` that relates this ``InstantiationExpression`` to the ``instantiated_type``.
        """

class Interaction(Association):
    """
    Implementation of ``Interaction`` defined in the KerML specification.

    **Specification**:

       An ``Interaction`` is a ``Behavior`` that is also an ``Association``,
       providing a context for multiple objects that have behaviors that
       impact one another.

    For language description, see section
    `7.4.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=90>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=252>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Interaction'

    STD: tuple[Union[type[Interaction], type[FlowDefinition]], ...] = (Interaction, FlowDefinition)

    if TYPE_CHECKING:
        Std = Union[Interaction, FlowDefinition]

    @property
    def steps(self) -> LazyIterator[Step | ActionUsage | FlowUsage]:
        """
        Implementation of ``step`` defined in the KerML specification.

        **Specification**:

           The ``Steps`` that make up this ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The parameters of this ``Behavior``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Behavior``.

        See section
        `8.3.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

class InterfaceDefinition(ConnectionDefinition):
    """
    Implementation of ``InterfaceDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``InterfaceDefinition`` is a ``ConnectionDefinition`` all of whose
       ends are ``PortUsages``, defining an interface between elements that
       interact through such ports.

    For language description, see section
    `7.14.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=107>`__
    of the SysML specification. For more details on the model, see section
    `8.3.14.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=334>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::InterfaceDefinition'

    STD: tuple[type[InterfaceDefinition], ...] = (InterfaceDefinition,)

    if TYPE_CHECKING:
        Std = InterfaceDefinition

    @property
    def interface_ends(self) -> LazyIterator[PortUsage]:
        """
        Implementation of ``interface_end`` defined in the SysML specification.

        **Specification**:

           The ``PortUsages`` that are the ``connection_ends`` of this
           ``InterfaceDefinition``.

        See section
        `8.3.14.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=335>`__
        of the SysML specification for more details.
        """

class InterfaceUsage(ConnectionUsage):
    """
    Implementation of ``InterfaceUsage`` defined in the SysML specification.

    **Specification**:

       An ``InterfaceUsage`` is a Usage of an ``InterfaceDefinition`` to
       represent an interface connecting parts of a system through specific
       ports.

    For language description, see section
    `7.14.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=107>`__
    of the SysML specification. For more details on the model, see section
    `8.3.14.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=335>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::InterfaceUsage'

    STD: tuple[type[InterfaceUsage], ...] = (InterfaceUsage,)

    if TYPE_CHECKING:
        Std = InterfaceUsage

    @property
    def interface_definitions(self) -> LazyIterator[InterfaceDefinition]:
        """
        Implementation of ``interface_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``InterfaceDefinitions`` that type this ``InterfaceUsage``.

        See section
        `8.3.14.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=335>`__
        of the SysML specification for more details.
        """

class Intersecting(Relationship):
    """
    Implementation of ``Intersecting`` defined in the KerML specification.

    **Specification**:

       ``Intersecting`` is a ``Relationship`` that makes its
       ``intersecting_type`` one of the ``intersecting_types`` of its
       ``type_intersected``.

    For language description, see section
    `7.3.2.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=56>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Intersecting'

    STD: tuple[type[Intersecting], ...] = (Intersecting,)

    if TYPE_CHECKING:
        Std = Intersecting

    CHAINABLE: bool = True

    @property
    def intersecting_type(self) -> Type | None:
        """
        Implementation of ``intersecting_type`` defined in the KerML
        specification.

        **Specification**:

           ``Type`` that partly determines interpretations of
           ``type_intersected``, as described in ``Type::intersecting_type``.

        See section
        `8.3.3.1.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @property
    def type_intersected(self) -> Type | None:
        """
        Implementation of ``type_intersected`` defined in the KerML
        specification.

        **Specification**:

           ``Type`` with interpretations partly determined by
           ``intersecting_type``, as described in ``Type::intersecting_type``.

        See section
        `8.3.3.1.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

class Invariant(BooleanExpression):
    """
    Implementation of ``Invariant`` defined in the KerML specification.

    **Specification**:

       An ``Invariant`` is a ``BooleanExpression`` that is asserted to have
       a specific ``Boolean`` result value. If ``is_negated = false``, then
       the result is asserted to be true. If ``is_negated = true``, then the
       result is asserted to be false.

    For language description, see section
    `7.4.8.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=83>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=228>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Invariant'

    STD: tuple[Union[type[Invariant], type[AssertConstraintUsage], type[SatisfyRequirementUsage]], ...] = (Invariant, AssertConstraintUsage, SatisfyRequirementUsage)

    if TYPE_CHECKING:
        Std = Union[Invariant, AssertConstraintUsage, SatisfyRequirementUsage]

    @property
    def is_negated(self) -> bool:
        """
        Implementation of ``is_negated`` defined in the KerML specification.

        **Specification**:

           Whether this ``Invariant`` is asserted to be false rather than true.

        See section
        `8.3.4.7.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=228>`__
        of the KerML specification for more details.
        """

    @is_negated.setter
    def is_negated(self, arg: bool, /) -> None: ...

class InvocationExpression(InstantiationExpression):
    """
    Implementation of ``InvocationExpression`` defined in the KerML
    specification.

    **Specification**:

       An ``InvocationExpression`` is an ``InstantiationExpression`` whose
       ``instantiated_type`` must be a ``Behavior`` or a ``Feature`` typed
       by a single ``Behavior`` (such as a ``Step``). Each of the input
       ``parameters`` of the ``instantiated_type`` are bound to the
       ``result`` of an ``argument`` ``Expression``. If the
       ``instantiated_type`` is a ``Function`` or a ``Feature`` typed by a
       ``Function``, then the ``result`` of the ``InvocationExpression`` is
       the ``result`` of the invoked ``Function``. Otherwise, the ``result``
       is an instance of the ``instantiated_type`` (essentially like a
       behavioral ``ConstructorExpression``).

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=239>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::InvocationExpression'

    STD: tuple[type[InvocationExpression], ...] = (InvocationExpression,)

    if TYPE_CHECKING:
        Std = InvocationExpression

    @property
    def operands(self) -> LazyIterator[Expression]: ...

class ItemDefinition(OccurrenceDefinition):
    """
    Implementation of ``ItemDefinition`` defined in the SysML specification.

    **Specification**:

       An ``ItemDefinition`` is an ``OccurrenceDefinition`` of the
       ``Structure`` of things that may themselves be systems or parts of
       systems, but may also be things that are acted on by a system or
       parts of a system, but which do not necessarily perform actions
       themselves. This includes items that can be exchanged between parts
       of a system, such as water or electrical signals.

    For language description, see section
    `7.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=87>`__
    of the SysML specification. For more details on the model, see section
    `8.3.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=321>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ItemDefinition'

    STD: tuple[type[ItemDefinition], ...] = (ItemDefinition,)

    if TYPE_CHECKING:
        Std = ItemDefinition

class ItemUsage(OccurrenceUsage):
    """
    Implementation of ``ItemUsage`` defined in the SysML specification.

    **Specification**:

       An ``ItemUsage`` is a ``ItemUsage`` whose ``definition`` is a
       ``Structure``. Nominally, if the ``definition`` is an
       ``ItemDefinition``, an ``ItemUsage`` is a ``ItemUsage`` of that
       ``ItemDefinition`` within a system. However, other kinds of Kernel
       ``Structures`` are also allowed, to permit use of ``Structures`` from
       the Kernel Model Libraries.

    For language description, see section
    `7.10.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=87>`__
    of the SysML specification. For more details on the model, see section
    `8.3.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=321>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ItemUsage'

    STD: tuple[Union[type[ItemUsage], type[ConnectionUsage]], ...] = (ItemUsage, ConnectionUsage)

    if TYPE_CHECKING:
        Std = Union[ItemUsage, ConnectionUsage]

    @property
    def item_definitions(self) -> LazyIterator[Structure | AssociationStructure | ConnectionDefinition | ItemDefinition | PortDefinition]:
        """
        Implementation of ``item_definition`` defined in the SysML
        specification.

        **Specification**:

           The Structures that are the ``definitions`` of this ItemUsage.
           Nominally, these are ItemDefinitions, but other kinds of Kernel
           Structures are also allowed, to permit use of Structures from the
           Kernel Library.

        See section
        `8.3.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=322>`__
        of the SysML specification for more details.
        """

class JoinNode(ControlNode):
    """
    Implementation of ``JoinNode`` defined in the SysML specification.

    **Specification**:

       A ``JoinNode`` is a ``ControlNode`` that waits for the completion of
       all the predecessor ``Actions`` given by incoming ``Successions``.

    For language description, see section
    `7.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=132>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=356>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::JoinNode'

    STD: tuple[type[JoinNode], ...] = (JoinNode,)

    if TYPE_CHECKING:
        Std = JoinNode

class JsonReader:
    """Unbound reader for JSON deserialization"""

    def __init__(self) -> None: ...

    def bind(self, s: str) -> JsonReader.StrReader:
        """
        Bind a serialized JSON string for reading.

        Note that only one reader can be bound at a time, binding again will raise ``ValueError``.
        Suggested usage is through a context manager:

        .. code-block:: python

            with reader.bind(json_str) as json:
                model, report = deserializer.accept(json, syside.DESERIALIZE_STANDARD)

        The reader will attempt to infer the root node as:

        1. The first ``Namespace`` (not subtype) without an owning relationship.
        2. The first ``Element`` that has no serialized owning related element or owning relationship,
           starting from the first element in the JSON array, and following owning elements up.
        3. The first element in the array otherwise.
        """

    @property
    def is_bound(self) -> bool:
        """Whether there currently is a reader bound to this resource."""

    class StrReader(Reader):
        """
        Bound reader for JSON deserialization that can be used together with ``Deserializer``.

        Resource usage can be controlled through context manager.
        """

        def unbind(self) -> None:
            """
            Unbind this reader explicitly, allowing resources to be reused for other reads.

            Attempting to use this for deserialization again will raise ``RuntimeError``.
            """

        def attribute_hint(self) -> AttributeMap | None:
            """Get a hint for deserialization attributes."""

        def __enter__(self) -> JsonReader.StrReader: ...

        def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, traceback: types.TracebackType | None) -> None: ...

class JsonStringOptions:
    """Options for serialization writer to JSON strings"""

    def __init__(self, indent: int = 2, use_spaces: bool = True, final_new_line: bool = True, include_cross_ref_uris: bool = True) -> None: ...

    @property
    def indent(self) -> int: ...

    @indent.setter
    def indent(self, arg: int, /) -> None: ...

    @property
    def use_spaces(self) -> bool: ...

    @use_spaces.setter
    def use_spaces(self, arg: bool, /) -> None: ...

    @property
    def final_new_line(self) -> bool: ...

    @final_new_line.setter
    def final_new_line(self, arg: bool, /) -> None: ...

    @property
    def include_cross_ref_uris(self) -> bool:
        """
        If true, include document URIs in references if elements are referenced from other documents
        """

    @include_cross_ref_uris.setter
    def include_cross_ref_uris(self, arg: bool, /) -> None: ...

class JsonStringWriter(Writer[str]):
    """Serialization writer that outputs JSON string"""

    @overload
    def __init__(self, arg: JsonStringOptions = ...) -> None: ...

    @overload
    def __init__(self, indent: int = 2, use_spaces: bool = True, final_new_line: bool = True, include_cross_ref_uris: bool = True) -> None: ...

    @property
    def partial_result(self) -> str:
        """Currently written text. May be incomplete JSON string."""

    @property
    def result(self) -> str:
        """Result of serialization. Guaranteed to be valid JSON string."""

    def clear(self) -> None:
        """Clear result. This is called automatically when serialization starts."""

    @property
    def options(self) -> JsonStringOptions:
        """Currently set options. Note that this returns a copy of the options."""

    @options.setter
    def options(self, arg: JsonStringOptions, /) -> None: ...

class KwToken(enum.Enum):
    Token = 0

    Keyword = 1

class LazyIterator(Generic[T]):
    def at(self, arg0: int, /) -> T | None:
        """
        Get value at index. This is computed lazily. Returns ``None`` for out of bounds index.

        Notes:

        * Has complexity O(n) so should be used sparingly.
        * Only positive indices are allowed since size is unknown.
        """

    def __getitem__(self, arg0: int, /) -> T:
        """
        Get value at index, This is computed lazily. Throws ``IndexError`` on out of bounds.

        Notes:

        * Has complexity O(n) so should be used sparingly.
        * Only positive indices are allowed since size is unknown.
        """

    def empty(self) -> bool:
        """Check if this range is empty."""

    def __bool__(self) -> bool:
        """Returns ``True`` if this range is not empty."""

    def count(self) -> int:
        """Count the number of items in this range. This is computed lazily."""

    def collect(self) -> list[T]:
        """Collect all items into a ``list``."""

    def for_each(self, arg0: Callable[[T], None | bool | VisitAction], /) -> None:
        """
        Lazily visit each item in this range. Visitation is stopped on returning ``False`` or ``VisitAction.Stop``;
        """

class LibraryID:
    def __init__(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __index__(self) -> int: ...

    def __hash__(self) -> int: ...

    @staticmethod
    def reserve_new() -> LibraryID: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::LibraryID'

class LibraryPackage(Package):
    """
    Implementation of ``LibraryPackage`` defined in the KerML specification.

    **Specification**:

       A ``LibraryPackage`` is a ``Package`` that is the container for a
       model library. A ``LibraryPackage`` is itself a library ``Element``
       as are all ``Elements`` that are directly or indirectly contained in
       it.

    For language description, see section
    `7.4.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=97>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.13.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=263>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LibraryPackage'

    STD: tuple[type[LibraryPackage], ...] = (LibraryPackage,)

    if TYPE_CHECKING:
        Std = LibraryPackage

    @property
    def is_standard(self) -> bool:
        """
        Implementation of ``is_standard`` defined in the KerML specification.

        **Specification**:

           Whether this ``LibraryPackage`` contains a standard library model.
           This should only be set to true for ``LibraryPackages`` in the
           standard Kernel Model Libraries or in normative model libraries for a
           language built on KerML.

        See section
        `8.3.4.13.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=263>`__
        of the KerML specification for more details.
        """

    @is_standard.setter
    def is_standard(self, arg: bool, /) -> None: ...

class LineEnd(enum.Enum):
    LF = 0

    CRLF = 1

class LiteralBoolean(LiteralExpression):
    """
    Implementation of ``LiteralBoolean`` defined in the KerML specification.

    **Specification**:

       ``LiteralBoolean`` is a ``LiteralExpression`` that provides a
       ``Boolean`` value as a result. Its ``result`` ``parameter`` must have
       type ``Boolean``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=241>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralBoolean'

    STD: tuple[type[LiteralBoolean], ...] = (LiteralBoolean,)

    if TYPE_CHECKING:
        Std = LiteralBoolean

    @property
    def value(self) -> bool:
        """
        Implementation of ``value`` defined in the KerML specification.

        **Specification**:

           The ``Boolean`` value that is the result of evaluating this
           ``LiteralBoolean``.

           The Boolean value that is the result of evaluating this Expression.

        See section
        `8.3.4.8.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=241>`__
        of the KerML specification for more details.
        """

    @value.setter
    def value(self, arg: bool, /) -> None: ...

class LiteralExpression(Expression):
    """
    Implementation of ``LiteralExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``LiteralExpression`` is an ``Expression`` that provides a basic
       ``DataValue`` as a result.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=242>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralExpression'

    STD: tuple[type[LiteralExpression], ...] = (LiteralExpression,)

    if TYPE_CHECKING:
        Std = LiteralExpression

class LiteralInfinity(LiteralExpression):
    """
    Implementation of ``LiteralInfinity`` defined in the KerML
    specification.

    **Specification**:

       A ``LiteralInfinity`` is a ``LiteralExpression`` that provides the
       positive infinity value (``*``). It’s ``result`` must have the type
       ``Positive``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=242>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralInfinity'

    STD: tuple[type[LiteralInfinity], ...] = (LiteralInfinity,)

    if TYPE_CHECKING:
        Std = LiteralInfinity

class LiteralInteger(LiteralExpression):
    """
    Implementation of ``LiteralInteger`` defined in the KerML specification.

    **Specification**:

       A ``LiteralInteger`` is a ``LiteralExpression`` that provides an
       ``Integer`` value as a result. Its ``result`` ``parameter`` must have
       the type ``Integer``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=243>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralInteger'

    STD: tuple[type[LiteralInteger], ...] = (LiteralInteger,)

    if TYPE_CHECKING:
        Std = LiteralInteger

    @property
    def value(self) -> int:
        """
        Implementation of ``value`` defined in the KerML specification.

        **Specification**:

           The ``Integer`` value that is the result of evaluating this
           ``LiteralInteger``.

           The Integer value that is the result of evaluating this Expression.

        See section
        `8.3.4.8.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=243>`__
        of the KerML specification for more details.
        """

    @value.setter
    def value(self, arg: int, /) -> None: ...

class LiteralRational(LiteralExpression):
    """
    Implementation of ``LiteralRational`` defined in the KerML
    specification.

    **Specification**:

       A ``LiteralRational`` is a ``LiteralExpression`` that provides a
       ``Rational`` value as a result. Its ``result`` ``parameter`` must
       have the type ``Rational``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.13 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=243>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralRational'

    STD: tuple[type[LiteralRational], ...] = (LiteralRational,)

    if TYPE_CHECKING:
        Std = LiteralRational

    @property
    def value(self) -> float:
        """
        Implementation of ``value`` defined in the KerML specification.

        **Specification**:

           The value whose rational approximation is the result of evaluating
           this ``LiteralRational``.

           The Real value that is the result of evaluating this Expression.

        See section
        `8.3.4.8.13 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=244>`__
        of the KerML specification for more details.
        """

    @value.setter
    def value(self, arg: float, /) -> None: ...

class LiteralString(LiteralExpression):
    """
    Implementation of ``LiteralString`` defined in the KerML specification.

    **Specification**:

       A ``LiteralString`` is a ``LiteralExpression`` that provides a
       ``String`` value as a result. Its ``result`` ``parameter`` must have
       the type ``String``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=244>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::LiteralString'

    STD: tuple[type[LiteralString], ...] = (LiteralString,)

    if TYPE_CHECKING:
        Std = LiteralString

    @property
    def value(self) -> str:
        """
        Implementation of ``value`` defined in the KerML specification.

        **Specification**:

           The String value that is the result of evaluating this Expression.

           The ``String`` value that is the result of evaluating this
           ``LiteralString``.

        See section
        `8.3.4.8.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=244>`__
        of the KerML specification for more details.
        """

    @value.setter
    def value(self, arg: str, /) -> None: ...

class LoopActionUsage(ActionUsage):
    """
    Implementation of ``LoopActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``LoopActionUsage`` is an ``ActionUsage`` that specifies that its
       ``body_action`` should be performed repeatedly. Its subclasses
       ``WhileLoopActionUsage`` and ``ForLoopActionUsage`` provide different
       ways to determine how many times the ``body_action`` should be
       performed.

    For language description, see section
    `7.17.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=143>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=357>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::LoopActionUsage'

    STD: tuple[type[LoopActionUsage], ...] = (LoopActionUsage,)

    if TYPE_CHECKING:
        Std = LoopActionUsage

    @property
    def body_action(self) -> ActionUsage | None:
        """
        Implementation of ``body_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` to be performed repeatedly by the
           ``LoopActionUsage``. It is the second ``parameter`` of the
           ``LoopActionUsage``.

        See section
        `8.3.17.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=357>`__
        of the SysML specification for more details.
        """

    @property
    def body_action_member(self) -> ActionParameterAccessor:
        """Syside specific accessor for manipulating ``body_action``."""

M = TypeVar("M", bound=Element)

class MemberAccessor(Generic[R, M]):
    @property
    def membership(self) -> R:
        """The ``membership`` of this ``member`` if it is not empty."""

    @property
    def member_element(self) -> M:
        """The ``member_element`` of this ``member`` if it is not empty."""

    @overload
    def set_member_element(self, element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Set a new ``member_element``. ``element`` will only be referenced if the ``membership`` is ``Membership``,
        otherwise ownership constraints apply. Replaces the previous ``member_element``, which may be reused by the model
        if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element(self, element: M | None, name: NameID = ...) -> tuple[R, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    def remove_member_element(self) -> None:
        """
        Remove the ``member_element`` leaving this ``member`` empty. Note that not all empty ``members`` are valid textual syntax.
        This does not check that the model is left in a valid state.
        """

    def extract_member_element(self) -> M:
        """
        Extract the ``member_element`` leaving this ``member`` empty. Note that not all empty ``members`` are valid textual syntax.
        This does not check that the model is left in a valid state.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``ValueError`` if member is empty.
        """

    def __bool__(self) -> bool: ...

class Membership(Relationship):
    """
    Implementation of ``Membership`` defined in the KerML specification.

    **Specification**:

       A ``Membership`` is a ``Relationship`` between a ``Namespace`` and an
       ``Element`` that indicates the ``Element`` is a ``member`` of (i.e.,
       is contained in) the Namespace. Any ``member_names`` specify how the
       ``member_element`` is identified in the ``Namespace`` and the
       ``visibility`` specifies whether or not the ``member_element`` is
       publicly visible from outside the ``Namespace``.

       If a ``Membership`` is an ``OwningMembership``, then it owns its
       ``member_element``, which becomes an ``owned_member`` of the
       ``membership_owning_namespace``. Otherwise, the ``member_names`` of a
       ``Membership`` are effectively aliases within the
       ``membership_owning_namespace`` for an ``Element`` with a separate
       ``OwningMembership`` in the same or a different ``Namespace``.

    For language description, see section
    `7.2.5.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=47>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=154>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Membership'

    STD: tuple[type[Membership], ...] = (Membership,)

    if TYPE_CHECKING:
        Std = Membership

    @property
    def is_initial_node(self) -> bool:
        """
        Returns ``True`` if this ``Membership`` was parsed from ``InitialNode`` syntax rule.
        """

    @is_initial_node.setter
    def is_initial_node(self, arg: bool, /) -> None: ...

    @property
    def owning_related_element(self) -> Element | None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> ContainerView[Element]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> ContainerView[Element]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def member_element_id(self) -> uuid.UUID:
        """
        Implementation of ``member_element_id`` defined in the KerML
        specification.

        **Specification**:

           The ``element_id`` of the ``member_element``.

        See section
        `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=154>`__
        of the KerML specification for more details.
        """

    @property
    def member_short_name(self) -> str | None:
        """
        Implementation of ``member_short_name`` defined in the KerML
        specification.

        **Specification**:

           The short name of the ``member_element`` relative to the
           ``membership_owning_namespace``.

        See section
        `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=155>`__
        of the KerML specification for more details.
        """

    @property
    def member_name(self) -> str | None:
        """
        Implementation of ``member_name`` defined in the KerML specification.

        **Specification**:

           The name of the ``member_element`` relative to the
           ``membership_owning_namespace``.

        See section
        `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=154>`__
        of the KerML specification for more details.
        """

    @property
    def membership_owning_namespace(self) -> Namespace | None:
        """
        Implementation of ``membership_owning_namespace`` defined in the KerML
        specification.

        **Specification**:

           The ``Namespace`` of which the ``member_element`` becomes a
           ``member`` due to this ``Membership``.

        See section
        `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=154>`__
        of the KerML specification for more details.
        """

    @property
    def member_element(self) -> Element | None:
        """
        Implementation of ``member_element`` defined in the KerML specification.

        **Specification**:

           The ``Element`` that becomes a ``member`` of the
           ``membership_owning_namespace`` due to this ``Membership``.

        See section
        `8.3.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=154>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

class MembershipExpose(MembershipImport):
    """
    Implementation of ``MembershipExpose`` defined in the SysML
    specification.

    **Specification**:

       A ``MembershipExpose`` is an ``Expose`` that exposes a specific
       ``imported_membership`` and, if ``is_recursive = true``, additional
       ``Memberships`` recursively.

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=418>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::MembershipExpose'

    STD: tuple[type[MembershipExpose], ...] = (MembershipExpose,)

    if TYPE_CHECKING:
        Std = MembershipExpose

class MembershipImport(Import):
    """
    Implementation of ``MembershipImport`` defined in the KerML
    specification.

    **Specification**:

       A ``MembershipImport`` is an ``Import`` that imports its
       ``imported_membership`` into the ``import_owning_namespace``. If
       ``is_recursive = true`` and the ``member_element`` of the
       ``imported_membership`` is a ``Namespace``, then the equivalent of a
       recursive ``NamespaceImport`` is also performed on that
       ``Namespace``.

    For language description, see section
    `7.2.5.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=49>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=155>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::MembershipImport'

    STD: tuple[type[MembershipImport], ...] = (MembershipImport,)

    if TYPE_CHECKING:
        Std = MembershipImport

    @property
    def imported_membership(self) -> Membership | None:
        """
        Implementation of ``imported_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``Membership`` to be imported.

        See section
        `8.3.2.4.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=155>`__
        of the KerML specification for more details.
        """

class MergeNode(ControlNode):
    """
    Implementation of ``MergeNode`` defined in the SysML specification.

    **Specification**:

       A ``MergeNode`` is a ``ControlNode`` that asserts the merging of its
       incoming ``Successions``. A ``MergeNode`` may have at most one
       outgoing ``Successions``.

    For language description, see section
    `7.17.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=132>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.13 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=357>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::MergeNode'

    STD: tuple[type[MergeNode], ...] = (MergeNode,)

    if TYPE_CHECKING:
        Std = MergeNode

class Messages(ConnectorEndsAccessor[ParameterMembership, EventOccurrenceUsage]):
    pass

class Metaclass(Structure):
    """
    Implementation of ``Metaclass`` defined in the KerML specification.

    **Specification**:

       A ``Metaclass`` is a ``Structure`` used to type ``MetadataFeatures``.

    For language description, see section
    `7.4.13 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=95>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=259>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Metaclass'

    STD: tuple[Union[type[Metaclass], type[MetadataDefinition]], ...] = (Metaclass, MetadataDefinition)

    if TYPE_CHECKING:
        Std = Union[Metaclass, MetadataDefinition]

class MetadataAccessExpression(Expression):
    """
    Implementation of ``MetadataAccessExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``MetadataAccessExpression`` is an ``Expression`` whose ``result``
       is a sequence of instances of ``Metaclasses`` representing all the
       ``MetadataFeature`` annotations of the ``referenced_element``. In
       addition, the sequence includes an instance of the reflective
       ``Metaclass`` corresponding to the MOF class of the
       ``referenced_element``, with values for all the abstract syntax
       properties of the ``referenced_element``.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=245>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::MetadataAccessExpression'

    STD: tuple[type[MetadataAccessExpression], ...] = (MetadataAccessExpression,)

    if TYPE_CHECKING:
        Std = MetadataAccessExpression

    @property
    def referenced_element(self) -> Element | None:
        """
        Implementation of ``referenced_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Element`` whose metadata is being accessed.

        See section
        `8.3.4.8.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=245>`__
        of the KerML specification for more details.
        """

    def referenced_element_member(self) -> ElementAccessor:
        """Syside specific accessor for manipulating ``referenced_element``."""

class MetadataDefinition(ItemDefinition):
    """
    Implementation of ``MetadataDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``MetadataDefinition`` is an ``ItemDefinition`` that is also a
       ``Metaclass``.

    For language description, see section
    `7.27.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=191>`__
    of the SysML specification. For more details on the model, see section
    `8.3.27.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=427>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::MetadataDefinition'

    STD: tuple[type[MetadataDefinition], ...] = (MetadataDefinition,)

    if TYPE_CHECKING:
        Std = MetadataDefinition

class MetadataFeature(Feature):
    """
    Implementation of ``MetadataFeature`` defined in the KerML
    specification.

    **Specification**:

       A ``MetadataFeature`` is a ``Feature`` that is an
       ``AnnotatingElement`` used to annotate another ``Element`` with
       metadata. It is typed by a ``Metaclass``. All its ``owned_features``
       must redefine ``features`` of its ``metaclass`` and any feature
       bindings must be model-level evaluable.

    For language description, see section
    `7.4.13 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=95>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=259>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::MetadataFeature'

    STD: tuple[Union[type[MetadataFeature], type[MetadataUsage]], ...] = (MetadataFeature, MetadataUsage)

    if TYPE_CHECKING:
        Std = Union[MetadataFeature, MetadataUsage]

    @property
    def annotations(self) -> ContainerView[Annotation]:
        """
        Implementation of ``annotation`` defined in the KerML specification.

        **Specification**:

           The ``Annotations`` that relate this ``AnnotatingElement`` to its
           ``annotated_elements``. This includes the
           ``owning_annotating_relationship`` (if any) followed by all the
           ``owned_annotating_relationships``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
        of the KerML specification for more details.
        """

    @property
    def annotated_elements(self) -> ContainerView[Element]:
        """
        Implementation of ``annotated_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Elements`` that are annotated by this ``AnnotatingElement``. If
           ``annotation`` is not empty, these are the ``annotated_elements`` of
           the ``annotations``. If ``annotation`` is empty, then it is the
           ``owning_namespace`` of the ``AnnotatingElement``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
        of the KerML specification for more details.
        """

    @property
    def owned_annotating_relationships(self) -> ContainerView[Annotation]:
        """
        Implementation of ``owned_annotating_relationship`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``AnnotatingElement`` that are
           ``Annotations``, for which this ``AnnotatingElement`` is the
           ``annotating_element``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=147>`__
        of the KerML specification for more details.
        """

    @property
    def owning_annotating_relationship(self) -> Annotation | None:
        """
        Implementation of ``owning_annotating_relationship`` defined in the
        KerML specification.

        **Specification**:

           The ``owning_relationship`` of this ``AnnotatingRelationship``, if it
           is an ``Annotation``

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=147>`__
        of the KerML specification for more details.
        """

    @property
    def about(self) -> Annotations:
        """Container for owned annotations."""

    @property
    def metaclass(self) -> MetadataDefinition | Metaclass | None:
        """
        Implementation of ``metaclass`` defined in the KerML specification.

        **Specification**:

           The ``type`` of this ``MetadataFeature``, which must be a
           ``Metaclass``.

        See section
        `8.3.4.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=260>`__
        of the KerML specification for more details.
        """

class MetadataUsage(ItemUsage):
    """
    Implementation of ``MetadataUsage`` defined in the SysML specification.

    **Specification**:

       A ``MetadataUsage`` is a ``Usage`` and a ``MetadataFeature``, used to
       annotate other ``Elements`` in a system model with metadata. As a
       ``MetadataFeature``, its type must be a ``Metaclass``, which will
       nominally be a ``MetadataDefinition``. However, any kernel
       ``Metaclass`` is also allowed, to permit use of ``Metaclasses`` from
       the Kernel Model Libraries.

    For language description, see section
    `7.27.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=191>`__
    of the SysML specification. For more details on the model, see section
    `8.3.27.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=428>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::MetadataUsage'

    STD: tuple[type[MetadataUsage], ...] = (MetadataUsage,)

    if TYPE_CHECKING:
        Std = MetadataUsage

    @property
    def metadata_definition(self) -> MetadataDefinition | None:
        """
        Implementation of ``metadata_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``MetadataDefinition`` that is the ``definition`` of this
           ``MetadataUsage``.

        See section
        `8.3.27.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=428>`__
        of the SysML specification for more details.
        """

    @property
    def annotations(self) -> ContainerView[Annotation]:
        """
        Implementation of ``annotation`` defined in the KerML specification.

        **Specification**:

           The ``Annotations`` that relate this ``AnnotatingElement`` to its
           ``annotated_elements``. This includes the
           ``owning_annotating_relationship`` (if any) followed by all the
           ``owned_annotating_relationships``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
        of the KerML specification for more details.
        """

    @property
    def annotated_elements(self) -> ContainerView[Element]:
        """
        Implementation of ``annotated_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Elements`` that are annotated by this ``AnnotatingElement``. If
           ``annotation`` is not empty, these are the ``annotated_elements`` of
           the ``annotations``. If ``annotation`` is empty, then it is the
           ``owning_namespace`` of the ``AnnotatingElement``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=146>`__
        of the KerML specification for more details.
        """

    @property
    def owned_annotating_relationships(self) -> ContainerView[Annotation]:
        """
        Implementation of ``owned_annotating_relationship`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``AnnotatingElement`` that are
           ``Annotations``, for which this ``AnnotatingElement`` is the
           ``annotating_element``.

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=147>`__
        of the KerML specification for more details.
        """

    @property
    def owning_annotating_relationship(self) -> Annotation | None:
        """
        Implementation of ``owning_annotating_relationship`` defined in the
        KerML specification.

        **Specification**:

           The ``owning_relationship`` of this ``AnnotatingRelationship``, if it
           is an ``Annotation``

        See section
        `8.3.2.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=147>`__
        of the KerML specification for more details.
        """

    @property
    def about(self) -> Annotations:
        """Container for owned annotations."""

    @property
    def metaclass(self) -> MetadataDefinition | Metaclass | None:
        """
        Implementation of ``metaclass`` defined in the KerML specification.

        **Specification**:

           The ``type`` of this ``MetadataFeature``, which must be a
           ``Metaclass``.

        See section
        `8.3.4.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=260>`__
        of the KerML specification for more details.
        """

class ModelLanguage(enum.Enum):
    KerML = 1

    SysML = 0

class ModelPrinter:
    @staticmethod
    def kerml(format: FormatOptions = ..., force_formatting: bool = False, reference_printer: ReferencePrinter = ...) -> ModelPrinter: ...

    @staticmethod
    def sysml(format: FormatOptions = ..., force_formatting: bool = False, reference_printer: ReferencePrinter = ...) -> ModelPrinter: ...

    @property
    def mode(self) -> PrintMode: ...

    @mode.setter
    def mode(self, arg: PrintMode, /) -> None: ...

    @property
    def force_formatting(self) -> bool: ...

    @force_formatting.setter
    def force_formatting(self, arg: bool, /) -> None: ...

    @property
    def format(self) -> FormatOptions: ...

    @format.setter
    def format(self, arg: FormatOptions, /) -> None: ...

    __cpp_name__: str = 'syside::sysml::ModelPrinter'

class MultiOrder(enum.Enum):
    Ordered = 0

    Nonunique = 1

class MultiPlacement(enum.Enum):
    First = 0

    FirstSpecialization = 1

    Last = 2

class Multiplicity(Feature):
    r"""
    Implementation of ``Multiplicity`` defined in the KerML specification.

    **Specification**:

       A ``Multiplicity`` is a ``Feature`` whose co-domain is a set of
       natural numbers giving the allowed cardinalities of each
       ``type_with_multiplicity``. The *cardinality* of a ``Type`` is
       defined as follows, depending on whether the ``Type`` is a
       ``Classifier`` or ``Feature``.

       - ``Classifier`` – The number of basic instances of the
         ``Classifier``, that is, those instances representing things, which
         are not instances of any subtypes of the ``Classifier`` that are
         ``Features``.\* ``Features`` – The number of instances with the
         same featuring instances. In the case of a ``Feature`` with a
         ``Classifier`` as its ``featuring_type``, this is the number of
         values of ``Feature`` for each basic instance of the
         ``Classifier``. Note that, for non-unique ``Features``, all
         duplicate values are included in this count.

       ``Multiplicity`` co-domains (in models) can be specified by
       ``Expression`` that might vary in their results. If the
       ``type_with_multiplicity`` is a ``Classifier``, the domain of the
       ``Multiplicity`` shall be ``Base::Anything``. If the
       ``type_with_multiplicity`` is a ``Feature``, the ``Multiplicity``
       shall have the same domain as the ``type_with_multiplicity``.

    For language description, see section
    `7.4.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=94>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Multiplicity'

    STD: tuple[type[Multiplicity], ...] = (Multiplicity,)

    if TYPE_CHECKING:
        Std = Multiplicity

class MultiplicityRange(Multiplicity):
    """
    Implementation of ``MultiplicityRange`` defined in the KerML
    specification.

    **Specification**:

       A ``MultiplicityRange`` is a ``Multiplicity`` whose value is defined
       to be the (inclusive) range of natural numbers given by the result of
       a ``lower_bound`` ``Expression`` and the result of an ``upper_bound``
       ``Expression``. The result of these ``Expressions`` shall be of type
       ``Natural``. If the result of the ``upper_bound`` ``Expression`` is
       the unbounded value ``*``, then the specified range includes all
       natural numbers greater than or equal to the ``lower_bound`` value.
       If no ``lower_bound`` ``Expression``, then the default is that the
       lower bound has the same value as the upper bound, except if the
       ``upper_bound`` evaluates to ``*``, in which case the default for the
       lower bound is 0.

    For language description, see section
    `7.4.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=94>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=256>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::MultiplicityRange'

    STD: tuple[type[MultiplicityRange], ...] = (MultiplicityRange,)

    if TYPE_CHECKING:
        Std = MultiplicityRange

    @property
    def lower_bound(self) -> Expression | None:
        """
        Implementation of ``lower_bound`` defined in the KerML specification.

        **Specification**:

           The ``Expression`` whose result provides the lower bound of the
           ``MultiplicityRange``. If no ``lower_bound`` ``Expression`` is given,
           then the lower bound shall have the same value as the upper bound,
           unless the upper bound is unbounded (``*``), in which case the lower
           bound shall be 0.

        See section
        `8.3.4.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=256>`__
        of the KerML specification for more details.
        """

    @property
    def upper_bound(self) -> Expression | None:
        """
        Implementation of ``upper_bound`` defined in the KerML specification.

        **Specification**:

           The ``Expression`` whose result is the upper bound of the
           ``MultiplicityRange``.

        See section
        `8.3.4.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=256>`__
        of the KerML specification for more details.
        """

    @property
    def bounds(self) -> list[Expression | None]:
        """
        Implementation of ``bound`` defined in the KerML specification.

        **Specification**:

           The owned ``Expressions`` of the ``MultiplicityRange`` whose results
           provide its bounds. These must be the first ``owned_members`` of the
           ``MultiplicityRange``.

        See section
        `8.3.4.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=256>`__
        of the KerML specification for more details.
        """

    @property
    def bounds_expression(self) -> Expression | None:
        """The ``Expression`` of the bounds range."""

    @property
    def bounds_expression_member(self) -> OwnedExpressionAccessor:
        """Syside specific accessor for manipulating ``bounds_expression``."""

    @property
    def has_cached_bounds(self) -> bool:
        """Returns ``True`` if sema succeeded in computing bounds."""

    @property
    def cached_lower_bound(self) -> int:
        """The numerically evaluated lower bound if any."""

    @property
    def cached_upper_bound(self) -> int | None:
        """
        The numerically evaluated upper bound if any. Returns ``None`` if the upper bound is infinity.
        """

class NameID(enum.Enum):
    Regular = 1
    """Reference element by its regular ID"""

    Short = 0
    """Reference element by its short ID"""

class NamePreference(enum.Enum):
    Automatic = 0
    """Implementation defined name preference"""

    Regular = 1
    """Prefer regular name, otherwise fall back to short name"""

    Short = 2
    """Prefer short name, otherwise fall back to regular name"""

    Shortest = 3
    """Prefer shortest name"""

    Longest = 4
    """Prefer longest name (for completeness)"""

class Namespace(Element):
    """
    Implementation of ``Namespace`` defined in the KerML specification.

    **Specification**:

       A ``Namespace`` is an ``Element`` that contains other ``Elements``,
       known as its ``members``, via ``Membership`` ``Relationships`` with
       those ``Elements``. The ``members`` of a ``Namespace`` may be owned
       by the ``Namespace``, aliased in the ``Namespace``, or imported into
       the ``Namespace`` via ``Import`` ``Relationships``.

       A ``Namespace`` can provide names for its ``members`` via the
       ``member_names`` and ``member_short_names`` specified by the
       ``Memberships`` in the ``Namespace``. If a ``Membership`` specifies a
       ``member_name`` and/or ``member_short_name``, then those are names of
       the corresponding ``member_element`` relative to the ``Namespace``.
       For an ``OwningMembership``, the ``owned_member_name`` and
       ``owned_member_short_name`` are given by the ``Element`` ``name`` and
       ``short_name``. Note that the same ``Element`` may be the
       ``member_element`` of multiple ``Memberships`` in a ``Namespace``
       (though it may be owned at most once), each of which may define a
       separate alias for the ``Element`` relative to the ``Namespace``.

    For language description, see section
    `7.2.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=46>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=156>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Namespace'

    STD: tuple[type[Namespace], ...] = (Namespace,)

    if TYPE_CHECKING:
        Std = Namespace

    @property
    def prefixes(self) -> NamespacePrefixes:
        """Metadata prefixes, prefixed with ``#`` in textual syntax."""

    @property
    def children(self) -> NamespaceBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def owned_memberships(self) -> LazyIterator[Membership]:
        """
        Implementation of ``owned_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Namespace`` that are
           ``Memberships``, for which the ``Namespace`` is the
           ``membership_owning_namespace``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=157>`__
        of the KerML specification for more details.
        """

    @property
    def imported_memberships(self) -> LazyIterator[Membership]:
        """
        Implementation of ``imported_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``Memberships`` in this ``Namespace`` that result from the
           ``owned_imports`` of this ``Namespace``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=156>`__
        of the KerML specification for more details.
        """

    @property
    def owned_members(self) -> LazyIterator[Element]:
        """
        Implementation of ``owned_member`` defined in the KerML specification.

        **Specification**:

           The owned ``members`` of this ``Namespace``, which are the
           ``owned_member_elements`` of the ``owned_memberships`` of the
           ``Namespace``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=157>`__
        of the KerML specification for more details.
        """

    @property
    def memberships(self) -> LazyIterator[Membership]:
        """
        Implementation of ``membership`` defined in the KerML specification.

        **Specification**:

           All ``Memberships`` in this ``Namespace``, including (at least) the
           union of ``owned_memberships`` and ``imported_memberships``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=157>`__
        of the KerML specification for more details.
        """

    @property
    def members(self) -> LazyIterator[Element]:
        """
        Implementation of ``member`` defined in the KerML specification.

        **Specification**:

           The set of all member ``Elements`` of this ``Namespace``, which are
           the ``member_elements`` of all ``memberships`` of the ``Namespace``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=156>`__
        of the KerML specification for more details.
        """

    @property
    def owned_imports(self) -> LazyIterator[Import]:
        """
        Implementation of ``owned_import`` defined in the KerML specification.

        **Specification**:

           The ``owned_relationships`` of this ``Namespace`` that are
           ``Imports``, for which the ``Namespace`` is the
           ``import_owning_namespace``.

        See section
        `8.3.2.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=157>`__
        of the KerML specification for more details.
        """

    def __getitem__(self, arg: str, /) -> Element:
        """
        Access owned named members by name. Throws ``KeyError`` if a member with such name does not exist.
        """

    @overload
    def get_membership(self, arg: str, /) -> Membership | None:
        """
        Access owned memberships by name. Returns None if an owned member or membership with such name does not exist.
        """

    @overload
    def get_membership(self, arg0: str, arg1: Membership, /) -> Membership:
        """
        Overload for ``get_membership`` that returns the last argument if a member was not found.
        """

    @overload
    def get_member(self, arg: str, /) -> Element | None:
        """
        Non-throwing variant of ``__getitem__``. Returns None if a named member was not found.
        """

    @overload
    def get_member(self, arg0: str, arg1: Element, /) -> Element:
        """
        Overload for ``get_member`` that returns the last argument if a member was not found.
        """

class NamespaceBody(OwnedChildrenNodes[MembershipImport | NamespaceImport | Membership, Element]):
    @overload
    def append[R: MembershipImport | NamespaceImport | Membership, M: Element](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    @overload
    def append[R: MembershipImport | NamespaceImport | Membership, M: Element](self, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Append a new *owned* element. Relationship must be a subtype of ``OwningMembership`` or ``Annotation``. Returns a
        newly constructed pair of (relationship, element) with the types provided.
        """

    @overload
    def replace[R: MembershipImport | NamespaceImport | Membership, M: Element](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def replace[R: MembershipImport | NamespaceImport | Membership, M: Element](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element must be *owned* so the same owning
        ``append`` limitations apply.
        """

    @overload
    def insert[R: MembershipImport | NamespaceImport | Membership, M: Element](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def insert[R: MembershipImport | NamespaceImport | Membership, M: Element](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element must be *owned* so the
        same owning ``append`` limitations apply.
        """

class NamespaceExpose(NamespaceImport):
    """
    Implementation of ``NamespaceExpose`` defined in the SysML
    specification.

    **Specification**:

       A ``NamespaceExpose`` is an ``Expose`` ``Relationship`` that exposes
       the ``Memberships`` of a specific ``imported_namespace`` and, if
       ``is_recursive = true``, additional ``Memberships`` recursively.

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=419>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::NamespaceExpose'

    STD: tuple[type[NamespaceExpose], ...] = (NamespaceExpose,)

    if TYPE_CHECKING:
        Std = NamespaceExpose

class NamespaceImport(Import):
    """
    Implementation of ``NamespaceImport`` defined in the KerML
    specification.

    **Specification**:

       A ``NamespaceImport`` is an Import that imports ``Memberships`` from
       its ``imported_namespace`` into the ``import_owning_namespace``. If
       ``is_recursive = false``, then only the visible ``Memberships`` of
       the ``imported_namespace`` are imported. If ``is_recursive = true``,
       then, in addition, ``Memberships`` are recursively imported from any
       ``owned_members`` of the ``imported_namespace`` that are
       ``Namespaces``.

    For language description, see section
    `7.2.5.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=49>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=160>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::NamespaceImport'

    STD: tuple[type[NamespaceImport], ...] = (NamespaceImport,)

    if TYPE_CHECKING:
        Std = NamespaceImport

    @property
    def imported_namespace(self) -> Namespace | None:
        """
        Implementation of ``imported_namespace`` defined in the KerML
        specification.

        **Specification**:

           The ``Namespace`` whose visible ``Memberships`` are imported by this
           ``NamespaceImport``.

        See section
        `8.3.2.4.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=160>`__
        of the KerML specification for more details.
        """

class NamespacePrefixes(OwnedChildrenNodes[OwningMembership, MetadataFeature | MetadataUsage]):
    @overload
    def append[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    @overload
    def append[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Append a new *owned* element. Relationship must be a subtype of ``OwningMembership`` or ``Annotation``. Returns a
        newly constructed pair of (relationship, element) with the types provided.
        """

    @overload
    def replace[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def replace[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element must be *owned* so the same owning
        ``append`` limitations apply.
        """

    @overload
    def insert[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def insert[R: OwningMembership, M: MetadataFeature | MetadataUsage](self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element must be *owned* so the
        same owning ``append`` limitations apply.
        """

class NullExpression(Expression):
    """
    Implementation of ``NullExpression`` defined in the KerML specification.

    **Specification**:

       A ``NullExpression`` is an ``Expression`` that results in a null
       value.

    For language description, see section
    `7.4.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=88>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.16 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=246>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::NullExpression'

    STD: tuple[type[NullExpression], ...] = (NullExpression,)

    if TYPE_CHECKING:
        Std = NullExpression

class NullFormat(enum.Enum):
    Null = 0

    Brackets = 1

class ObjectiveMembership(FeatureMembership):
    """
    Implementation of ``ObjectiveMembership`` defined in the SysML
    specification.

    **Specification**:

       An ``ObjectiveMembership`` is a ``FeatureMembership`` that indicates
       that its ``owned_objective_requirement`` is the objective
       ``RequirementUsage`` for its ``owning_type``, which must be a
       ``CaseDefinition`` or ``CaseUsage``.

    For language description, see section
    `7.22.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=169>`__
    of the SysML specification. For more details on the model, see section
    `8.3.22.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=404>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ObjectiveMembership'

    STD: tuple[type[ObjectiveMembership], ...] = (ObjectiveMembership,)

    if TYPE_CHECKING:
        Std = ObjectiveMembership

    @property
    def owned_objective_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``owned_objective_requirement`` defined in the SysML
        specification.

        **Specification**:

           The RequirementUsage that is the ``owned_member_feature`` of this
           RequirementUsage.

        See section
        `8.3.22.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=404>`__
        of the SysML specification for more details.
        """

class OccurrenceDefinition(Definition):
    """
    Implementation of ``OccurrenceDefinition`` defined in the SysML
    specification.

    **Specification**:

       An ``OccurrenceDefinition`` is a ``Definition`` of a ``Class`` of
       individuals that have an independent life over time and potentially
       an extent over space. This includes both structural things and
       behaviors that act on such structures. If ``is_individual`` is true,
       then the ``OccurrenceDefinition`` is constrained to have (at most) a
       single instance that is the entire life of a single individual.

    For language description, see section
    `7.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=84>`__
    of the SysML specification. For more details on the model, see section
    `8.3.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=317>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::OccurrenceDefinition'

    STD: tuple[type[OccurrenceDefinition], ...] = (OccurrenceDefinition,)

    if TYPE_CHECKING:
        Std = OccurrenceDefinition

    @property
    def is_individual(self) -> bool:
        """
        Implementation of ``is_individual`` defined in the SysML specification.

        **Specification**:

           Whether this ``OccurrenceDefinition`` is constrained to represent at
           most one thing.

        See section
        `8.3.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=317>`__
        of the SysML specification for more details.
        """

    @is_individual.setter
    def is_individual(self, arg: bool, /) -> None: ...

class OccurrenceUsage(Usage):
    """
    Implementation of ``OccurrenceUsage`` defined in the SysML
    specification.

    **Specification**:

       An ``OccurrenceUsage`` is a ``Usage`` whose ``types`` are all
       ``Classes``. Nominally, if a ``type`` is an ``OccurrenceDefinition``,
       an ``OccurrenceUsage`` is a ``Usage`` of that
       ``OccurrenceDefinition`` within a system. However, other types of
       Kernel ``Classes`` are also allowed, to permit use of ``Classes``
       from the Kernel Model Libraries.

    For language description, see section
    `7.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=84>`__
    of the SysML specification. For more details on the model, see section
    `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::OccurrenceUsage'

    STD: tuple[Union[type[OccurrenceUsage], type[ConnectionUsage], type[FlowUsage]], ...] = (OccurrenceUsage, ConnectionUsage, FlowUsage)

    if TYPE_CHECKING:
        Std = Union[OccurrenceUsage, ConnectionUsage, FlowUsage]

    @property
    def is_individual(self) -> bool:
        """
        Implementation of ``is_individual`` defined in the SysML specification.

        **Specification**:

           Whether this ``OccurrenceUsage`` represents the usage of the specific
           individual represented by its ``individual_definition``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

    @is_individual.setter
    def is_individual(self, arg: bool, /) -> None: ...

    @property
    def portion_kind(self) -> PortionKind | None:
        """
        Implementation of ``portion_kind`` defined in the SysML specification.

        **Specification**:

           The kind of temporal portion (time slice or snapshot) is represented
           by this ``OccurrenceUsage``. If ``portion_kind`` is not null, then
           the ``owning_type`` of the ``OccurrenceUsage`` must be non-null, and
           the ``OccurrenceUsage`` represents portions of the featuring instance
           of the ``owning_type``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

    @portion_kind.setter
    def portion_kind(self, arg: PortionKind | None) -> None: ...

    @property
    def occurrence_definitions(self) -> LazyIterator[OccurrenceDefinition]:
        """
        Implementation of ``occurrence_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Classes`` that are the types of this ``OccurrenceUsage``.
           Nominally, these are ``OccurrenceDefinitions``, but other kinds of
           kernel ``Classes`` are also allowed, to permit use of ``Classes``
           from the Kernel Model Libraries.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

    @property
    def individual_definition(self) -> OccurrenceDefinition | None:
        """
        Implementation of ``individual_definition`` defined in the SysML
        specification.

        **Specification**:

           The at most one ``occurrence_definition`` that has
           ``is_individual = true``.

        See section
        `8.3.9.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=318>`__
        of the SysML specification for more details.
        """

class Operator(enum.Enum):
    def __str__(self) -> str: ...

    If = 0

    NullCoalescing = 1

    Implies = 2

    LogicalOr = 3

    Or = 4

    Xor = 5

    LogicalAnd = 6

    And = 7

    Equals = 8

    Same = 9

    NotEquals = 10

    NotSame = 11

    IsType = 12

    HasType = 13

    At = 14

    AtAt = 15

    As = 16

    Meta = 17

    Less = 18

    LessEqual = 19

    Greater = 20

    GreaterEqual = 21

    Range = 22

    Plus = 23

    Minus = 24

    Multiply = 25

    Divide = 26

    Modulo = 27

    ExponentStar = 28

    ExponentCaret = 29

    Conjugation = 30

    Not = 31

    All = 32

    Quantity = 33

    Comma = 34

    def from_string(self) -> Operator: ...

    Dot = 36

    Collect = 37

    Index = 35

    Select = 38

class OperatorBreak(enum.Enum):
    Before = 0

    After = 1

class OperatorExpression(InvocationExpression):
    """
    Implementation of ``OperatorExpression`` defined in the KerML
    specification.

    **Specification**:

       An ``OperatorExpression`` is an ``InvocationExpression`` whose
       ``function`` is determined by resolving its ``operator`` in the
       context of one of the standard packages from the Kernel Function
       Library.

    For language description, see section
    `7.4.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=84>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.17 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=247>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::OperatorExpression'

    STD: tuple[type[OperatorExpression], ...] = (OperatorExpression,)

    if TYPE_CHECKING:
        Std = OperatorExpression

    @property
    def operator(self) -> Operator:
        """
        Implementation of ``operator`` defined in the KerML specification.

        **Specification**:

           An ``operator`` symbol that names a corresponding ``Function`` from
           one of the standard packages from the Kernel Function Library .

        See section
        `8.3.4.8.17 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=247>`__
        of the KerML specification for more details.
        """

    @operator.setter
    def operator(self, arg: ExplicitOperator, /) -> None: ...

    def try_set_operator(self, arg: ExplicitOperator, /) -> bool:
        """
        Alternative for ``operator`` that will return ``False`` if this expression does not allow modifying its ``operator`` rather than raising ``TypeError``.
        """

class OptionalKw(enum.Enum):
    Always = 0

    AsNeeded = 1

class OptionalKwToken(enum.Enum):
    Token = 0

    Keyword = 1

    none = 2

class OptionalToken(enum.Enum):
    Never = 0

    Always = 1

    OnBreak = 2

class OwnedChildrenNodes(ChildrenNodes[R, M]):
    """Container that stores a vector of potentially owned children nodes."""

    @overload
    def append(self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    @overload
    def append(self, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Append a new *owned* element. Relationship must be a subtype of ``OwningMembership`` or ``Annotation``. Returns a
        newly constructed pair of (relationship, element) with the types provided.
        """

    @overload
    def replace(self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def replace(self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element must be *owned* so the same owning
        ``append`` limitations apply.
        """

    @overload
    def insert(self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    @overload
    def insert(self, index: int, relationship: type[R], element: type[M]) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element must be *owned* so the
        same owning ``append`` limitations apply.
        """

class OwnedExpressionAccessor(OwnedMemberAccessor[OwningMembership, Expression]):
    @overload
    def set_member_element[M: Expression](self, element: M, name: NameID = ...) -> tuple[OwningMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Expression](self, element: M | None, name: NameID = ...) -> tuple[OwningMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Expression](self, element: type[M]) -> tuple[OwningMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class OwnedFeatureAccessor(OwnedMemberAccessor[OwningMembership, Feature]):
    @overload
    def set_member_element[M: Feature](self, element: M, name: NameID = ...) -> tuple[OwningMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Feature](self, element: M | None, name: NameID = ...) -> tuple[OwningMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Feature](self, element: type[M]) -> tuple[OwningMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class OwnedMemberAccessor[R: OwningMembership, M: Element](MemberAccessor[R, M]):
    @overload
    def set_member_element(self, element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element(self, element: M | None, name: NameID = ...) -> tuple[R, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element(self, arg: type[M], /) -> tuple[R, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

    def add_member_element(self) -> tuple[R, M]:
        """
        Constructs a new ``member_element`` with the default type if this ``member`` is empty, otherwise does nothing.

        Returns a pair of (``membership``, ``member_element``)
        """

class OwnedMultiplicityAccessor(OwnedMemberAccessor[OwningMembership, MultiplicityRange]):
    @overload
    def set_member_element[M: MultiplicityRange](self, element: M, name: NameID = ...) -> tuple[OwningMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: MultiplicityRange](self, element: M | None, name: NameID = ...) -> tuple[OwningMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: MultiplicityRange](self, element: type[M]) -> tuple[OwningMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class OwnedSuccessionAccessor(OwnedMemberAccessor[OwningMembership, SuccessionAsUsage]):
    @overload
    def set_member_element[M: SuccessionAsUsage](self, element: M, name: NameID = ...) -> tuple[OwningMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: SuccessionAsUsage](self, element: M | None, name: NameID = ...) -> tuple[OwningMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: SuccessionAsUsage](self, element: type[M]) -> tuple[OwningMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class OwningMembership(Membership):
    """
    Implementation of ``OwningMembership`` defined in the KerML
    specification.

    **Specification**:

       An ``OwningMembership`` is a ``Membership`` that owns its
       ``member_element`` as a ``owned_related_element``. The
       ``owned_member_element`` becomes an ``owned_member`` of the
       ``membership_owning_namespace``.

    For language description, see section
    `7.2.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=46>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=161>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::OwningMembership'

    STD: tuple[type[OwningMembership], ...] = (OwningMembership,)

    if TYPE_CHECKING:
        Std = OwningMembership

    @property
    def owned_member_element_id(self) -> uuid.UUID:
        """
        Implementation of ``owned_member_element_id`` defined in the KerML
        specification.

        **Specification**:

           The ``element_id`` of the ``owned_member_element``.

        See section
        `8.3.2.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=162>`__
        of the KerML specification for more details.
        """

    @property
    def owned_member_short_name(self) -> str | None:
        """
        Implementation of ``owned_member_short_name`` defined in the KerML
        specification.

        **Specification**:

           The ``short_name`` of the ``owned_member_element``.

        See section
        `8.3.2.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=162>`__
        of the KerML specification for more details.
        """

    @property
    def owned_member_name(self) -> str | None:
        """
        Implementation of ``owned_member_name`` defined in the KerML
        specification.

        **Specification**:

           The ``name`` of the ``owned_member_element``.

        See section
        `8.3.2.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=162>`__
        of the KerML specification for more details.
        """

    @property
    def owned_member_element(self) -> Element | None:
        """
        Implementation of ``owned_member_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Element`` that becomes an ``owned_member`` of the
           ``membership_owning_namespace`` due to this ``OwningMembership``.

        See section
        `8.3.2.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=161>`__
        of the KerML specification for more details.
        """

class Package(Namespace):
    """
    Implementation of ``Package`` defined in the KerML specification.

    **Specification**:

       A ``Package`` is a ``Namespace`` used to group ``Elements``, without
       any instance-level semantics. It may have one or more model-level
       evaluable ``filter_condition`` ``Expressions`` used to filter its
       ``imported_memberships``. Any imported ``member`` must meet all of
       the ``filter_conditions``.

    For language description, see section
    `7.4.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=97>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.13.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=264>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Package'

    STD: tuple[type[Package], ...] = (Package,)

    if TYPE_CHECKING:
        Std = Package

    @property
    def filter_conditions(self) -> LazyIterator[ElementFilterMembership]:
        """
        Implementation of ``filter_condition`` defined in the KerML
        specification.

        **Specification**:

           The model-level evaluable ``Boolean``-valued ``Expression`` used to
           filter the ``members`` of this ``Package``, which are owned by the
           ``Package`` are via ``ElementFilterMemberships``.

        See section
        `8.3.4.13.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=264>`__
        of the KerML specification for more details.
        """

class ParameterAccessor(OwnedMemberAccessor[ParameterMembership, ReferenceUsage]):
    @property
    def argument(self) -> Expression | None:
        """The ``argument`` accessible by this ``parameter``."""

    @overload
    def set_argument[M: Expression](self, expression: M) -> tuple[FeatureValue, M]:
        """
        Set the ``argument`` to an owned ``expression``. Ownership constraints apply. An empty
        parameter will be constructed if there is none.

        Returns a pair of (``feature_value``, ``argument``).
        """

    @overload
    def set_argument[M: Expression](self, expression: M | None) -> tuple[FeatureValue, M] | None:
        """
        ``set_argument`` overload that will instead remove the argument if ``expression is None`` and return ``None``.
        Otherwise behaviour is the same.
        """

    @overload
    def set_argument[M: Expression](self, expression: type[M]) -> tuple[FeatureValue, M]:
        """
        Set the ``argument`` to an empty ``Expression`` with the corresponding type. An empty
        parameter will be constructed if there is none.

        Returns a pair of (``feature_value``, ``argument``).
        """

    def remove_argument(self) -> None:
        """
        Remove the ``argument`` while leaving ``parameter`` intact. Does nothing if there is no ``argument``.
        """

    def extract_argument(self) -> Expression:
        """
        Extract the ``argument`` while leaving ``parameter`` intact. Raises ``ValueError`` if there is no ``argument``.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M, name: NameID = ...) -> tuple[ParameterMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M | None, name: NameID = ...) -> tuple[ParameterMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: type[M]) -> tuple[ParameterMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ParameterMembership(FeatureMembership):
    """
    Implementation of ``ParameterMembership`` defined in the KerML
    specification.

    **Specification**:

       A ``ParameterMembership`` is a ``FeatureMembership`` that identifies
       its ``member_feature`` as a parameter, which is always owned, and
       must have a ``direction``. A ``ParameterMembership`` must be owned by
       a ``Behavior``, a ``Step``, or the ``result`` parameter of a
       ``ConstructorExpression``.

    For language description, see section
    `7.4.7.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=78>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=222>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ParameterMembership'

    STD: tuple[type[ParameterMembership], ...] = (ParameterMembership,)

    if TYPE_CHECKING:
        Std = ParameterMembership

    @property
    def owned_member_parameter(self) -> Feature | None:
        """
        Implementation of ``owned_member_parameter`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is identified as a ``parameter`` by this
           ``ParameterMembership``.

        See section
        `8.3.4.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=222>`__
        of the KerML specification for more details.
        """

    def parameter_direction(self) -> FeatureDirectionKind:
        """
        Return the required value of the direction of the ``owned_member_parameter``. By default, this is ``in``.
        """

class PartDefinition(ItemDefinition):
    """
    Implementation of ``PartDefinition`` defined in the SysML specification.

    **Specification**:

       A ``PartDefinition`` is an ``ItemDefinition`` of a ``Class`` of
       systems or parts of systems. Note that all parts may be considered
       items for certain purposes, but not all items are parts that can
       perform actions within a system.

    For language description, see section
    `7.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=90>`__
    of the SysML specification. For more details on the model, see section
    `8.3.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=323>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PartDefinition'

    STD: tuple[type[PartDefinition], ...] = (PartDefinition,)

    if TYPE_CHECKING:
        Std = PartDefinition

class PartUsage(ItemUsage):
    """
    Implementation of ``PartUsage`` defined in the SysML specification.

    **Specification**:

       A ``PartUsage`` is a usage of a ``PartDefinition`` to represent a
       system or a part of a system. At least one of the
       ``item_definitions`` of the ``PartUsage`` must be a
       ``PartDefinition``.

       A ``PartUsage`` must subset, directly or indirectly, the base
       ``PartUsage`` ``parts`` from the Systems Model Library.

    For language description, see section
    `7.11.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=90>`__
    of the SysML specification. For more details on the model, see section
    `8.3.11.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=323>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PartUsage'

    STD: tuple[Union[type[PartUsage], type[ConnectionUsage]], ...] = (PartUsage, ConnectionUsage)

    if TYPE_CHECKING:
        Std = Union[PartUsage, ConnectionUsage]

    @property
    def part_definitions(self) -> LazyIterator[PartDefinition]:
        """
        Implementation of ``part_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``item_definitions`` of this PartUsage that are PartDefinitions.

        See section
        `8.3.11.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=324>`__
        of the SysML specification for more details.
        """

class PartialTextDocumentData:
    def __init__(self, content: str, version: int = 0) -> None: ...

    @property
    def content(self) -> str: ...

    @content.setter
    def content(self, arg: str, /) -> None: ...

    @property
    def version(self) -> int: ...

    @version.setter
    def version(self, arg: int, /) -> None: ...

class Path(Sequence[str | int]):
    """
    A sequence of path segments that stringifies with unrestricted names as needed. Similar to
    ``QualifiedName`` but may contain indices to unnamed elements, that are printed literally with ``/``
    separator instead.

    Note that indices are expected to use 1-based indexing according to the specification.
    """

    @overload
    def __init__(self) -> None:
        """Default constructor"""

    @overload
    def __init__(self, arg: Path) -> None:
        """Copy constructor"""

    @overload
    def __init__(self, arg: Iterable[str | int], /) -> None:
        """Construct from an iterable object"""

    def __len__(self) -> int: ...

    def __bool__(self) -> bool:
        """Check whether the vector is nonempty"""

    def __repr__(self) -> str: ...

    @overload
    def __getitem__(self, index: int) -> str | int: ...

    @overload
    def __getitem__(self, index: slice) -> Path: ...

    def clear(self) -> None:
        """Remove all items from list."""

    def append(self, arg: str | int, /) -> None:
        """Append `arg` to the end of the list."""

    def insert(self, arg0: int, arg1: str | int, /) -> None:
        """Insert object `arg1` before index `arg0`."""

    def pop(self, index: int = -1) -> str | int:
        """Remove and return item at `index` (default last)."""

    def extend(self, arg: Path, /) -> None:
        """Extend `self` by appending elements from `arg`."""

    @overload
    def __setitem__(self, arg0: int, arg1: str | int, /) -> None: ...

    @overload
    def __setitem__(self, arg0: slice, arg1: Path, /) -> None: ...

    @overload
    def __delitem__(self, arg: int, /) -> None: ...

    @overload
    def __delitem__(self, arg: slice, /) -> None: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    @overload
    def __contains__(self, arg: str | int, /) -> bool: ...

    @overload
    def __contains__(self, arg: object, /) -> bool: ...

    def count(self, arg: str | int, /) -> int:
        """Return number of occurrences of `arg`."""

    def remove(self, arg: str | int, /) -> None:
        """Remove first occurrence of `arg`."""

    def __iter__(self) -> Iterator[str | int]: ...

    def __str__(self) -> str: ...

    @property
    def to_owning_membership(self) -> bool:
        """
        If this is true, this path is to the owning membership of the element the
        segments would resolve to. This is a flag rather than a segment since
        owning memberships can effectively only ever be the last segment. When
        formatted, this will add ``/owningMembership`` suffix.
        """

    @to_owning_membership.setter
    def to_owning_membership(self, arg: bool, /) -> None: ...

class PayloadFeature(Feature):
    """
    Implementation of ``PayloadFeature`` defined in the KerML specification.

    **Specification**:

       A ``PayloadFeature`` is the ``owned_feature`` of a ``Flow`` that
       identifies the things carried by the kinds of transfers that are
       instances of the ``Flow``.

    For language description, see section
    `7.4.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=91>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.9.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=252>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::PayloadFeature'

    STD: tuple[type[PayloadFeature], ...] = (PayloadFeature,)

    if TYPE_CHECKING:
        Std = PayloadFeature

class PayloadFeatureAccessor(OwnedMemberAccessor[FeatureMembership, PayloadFeature]):
    @overload
    def set_member_element[M: PayloadFeature](self, element: M, name: NameID = ...) -> tuple[FeatureMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: PayloadFeature](self, element: M | None, name: NameID = ...) -> tuple[FeatureMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: PayloadFeature](self, element: type[M]) -> tuple[FeatureMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class PendingReference:
    """Reference that has yet to be linked."""

    @property
    def uri(self) -> str:
        """Document URI this reference is resolved from"""

    @property
    def id(self) -> uuid.UUID:
        """Element ID of the reference element"""

    @property
    def referent(self) -> Element:
        """The element this reference is owned by"""

class PerformActionUsage(ActionUsage):
    """
    Implementation of ``PerformActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``PerformActionUsage`` is an ``ActionUsage`` that represents the
       performance of an ``ActionUsage``. Unless it is the
       ``PerformActionUsage`` itself, the ``ActionUsage`` to be performed is
       related to the ``PerformActionUsage`` by a ``ReferenceSubsetting``
       relationship. A ``PerformActionUsage`` is also an
       ``EventOccurrenceUsage``, with its ``performed_action`` as the
       ``event_occurrence``.

    For language description, see section
    `7.17.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=135>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=358>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PerformActionUsage'

    STD: tuple[Union[type[PerformActionUsage], type[ExhibitStateUsage], type[IncludeUseCaseUsage]], ...] = (PerformActionUsage, ExhibitStateUsage, IncludeUseCaseUsage)

    if TYPE_CHECKING:
        Std = Union[PerformActionUsage, ExhibitStateUsage, IncludeUseCaseUsage]

    @property
    def event_occurrence(self) -> OccurrenceUsage | ConnectionUsage | FlowUsage | None:
        """
        Implementation of ``event_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsage`` referenced as an event by this
           ``EventOccurrenceUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``EventOccurrenceUsage``, if
           there is one, and, otherwise, the ``EventOccurrenceUsage`` itself.

        See section
        `8.3.9.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=316>`__
        of the SysML specification for more details.
        """

    @property
    def performed_action(self) -> ActionUsage | FlowUsage | None:
        """
        Implementation of ``performed_action`` defined in the SysML
        specification.

        **Specification**:

           The ``ActionUsage`` to be performed by this ``PerformedActionUsage``.
           It is the ``event_occurrence`` of the ``PerformActionUsage``
           considered as an ``EventOccurrenceUsage``, which must be an
           ``ActionUsage``.

        See section
        `8.3.17.14 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=358>`__
        of the SysML specification for more details.
        """

class Pipeline:
    def schedule(self, documents: Sequence[SharedMutex[BasicDocument]], options: ScheduleOptions = ..., invalidated: Sequence[SharedMutex[BasicDocument]] = []) -> Schedule:
        """
        Schedule ``documents`` for building with this ``Pipeline``. ``documents``
        with ``build_state`` equal or greater to the state at the end of particular
        pipeline stage will not be scheduled for that stage. For example, a
        document with ``build_state >= BuildState.Parsed`` will not be scheduled
        for parsing.

        Pipeline also accepts additional ``invalidated`` documents that will have
        their semantic states reset. These documents will then pass through sema
        and validation stages as normal. This should typically be used for
        documents that have had their dependencies modified. Any documents for
        which ``build_state < BuildState.Built`` will not be invalidated as there
        should be nothing to invalidate.

        The returned schedule should be executed on an ``Executor``:

        .. code-block:: python

            executor = syside.Executor(...)
            schedule = pipeline.schedule(...)
            ...
            result = executor.run(schedule)

        Note that pipeline will skip indexing certain URLs that are used by IDEs to display
        virtual documents:

        * ``git*://*``, e.g. used by VS Code to display ``git`` diffs
        * ``vscode*://*``, e.g. used by VS Code to display editor previews
        * ``<scheme>[:|://]`` (URL with scheme only), e.g. used by Neovim for new unnamed buffers

        The first two patterns additionally skip validation since those virtual documents are
        never a part of the workspace. Indexing is skipped only for known URL patterns to
        avoid unexpected behaviour. However, prefer using common schemes such as ``file`` or
        ``http[s]`` to ensure that the documents are handled correctly as more URL patterns may
        be added as more IDEs are tested.
        """

    __cpp_name__: str = 'syside::Pipeline'

class PipelineOptions:
    def __init__(self, static_index: StaticIndex | None = None, lib: Stdlib | None = None) -> None: ...

    @property
    def static_index(self) -> StaticIndex: ...

    @static_index.setter
    def static_index(self, arg: StaticIndex, /) -> None: ...

    @property
    def lib(self) -> Stdlib: ...

    @lib.setter
    def lib(self, arg: Stdlib, /) -> None: ...

    __cpp_name__: str = 'syside::sysml::PipelineOptions'

class PortConjugation(Conjugation):
    """
    Implementation of ``PortConjugation`` defined in the SysML
    specification.

    **Specification**:

       A ``PortConjugation`` is a ``Conjugation`` ``Relationship`` between a
       ``PortDefinition`` and its corresponding
       ``ConjugatedPortDefinition``. As a result of this ``Relationship``,
       the ``ConjugatedPortDefinition`` inherits all the ``features`` of the
       original ``PortDefinition``, but input ``flows`` of the original
       ``PortDefinition`` become outputs on the ``ConjugatedPortDefinition``
       and output ``flows`` of the original ``PortDefinition`` become inputs
       on the ``ConjugatedPortDefinition``.

    For language description, see section
    `7.12.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=93>`__
    of the SysML specification. For more details on the model, see section
    `8.3.12.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=327>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PortConjugation'

    STD: tuple[type[PortConjugation], ...] = (PortConjugation,)

    if TYPE_CHECKING:
        Std = PortConjugation

    CHAINABLE: bool = False

    @property
    def original_port_definition(self) -> PortDefinition | None:
        """
        Implementation of ``original_port_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``PortDefinition`` being conjugated.

        See section
        `8.3.12.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=327>`__
        of the SysML specification for more details.
        """

    @property
    def conjugated_port_definition(self) -> Type | None:
        """
        Implementation of ``conjugated_port_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``ConjugatedPortDefinition`` that is conjugate to the
           ``original_port_definition``.

        See section
        `8.3.12.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=327>`__
        of the SysML specification for more details.
        """

class PortDefinition(OccurrenceDefinition):
    """
    Implementation of ``PortDefinition`` defined in the SysML specification.

    **Specification**:

       A ``PortDefinition`` defines a point at which external entities can
       connect to and interact with a system or part of a system. Any
       ``owned_usages`` of a ``PortDefinition``, other than ``PortUsages``,
       must not be composite.

    For language description, see section
    `7.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=93>`__
    of the SysML specification. For more details on the model, see section
    `8.3.12.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=328>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PortDefinition'

    STD: tuple[type[PortDefinition], ...] = (PortDefinition,)

    if TYPE_CHECKING:
        Std = PortDefinition

    @property
    def conjugated_port_definition(self) -> ConjugatedPortDefinition | None:
        """
        Implementation of ``conjugated_port_definition`` defined in the SysML
        specification.

        **Specification**:

           The that is conjugate to this ``PortDefinition``.

        See section
        `8.3.12.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=328>`__
        of the SysML specification for more details.
        """

class PortUsage(OccurrenceUsage):
    """
    Implementation of ``PortUsage`` defined in the SysML specification.

    **Specification**:

       A ``PortUsage`` is a usage of a ``PortDefinition``. A ``PortUsage``
       itself as well as all its ``nested_usages`` must be referential
       (non-composite).

    For language description, see section
    `7.12.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=93>`__
    of the SysML specification. For more details on the model, see section
    `8.3.12.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=329>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::PortUsage'

    STD: tuple[type[PortUsage], ...] = (PortUsage,)

    if TYPE_CHECKING:
        Std = PortUsage

    @property
    def port_definitions(self) -> LazyIterator[PortDefinition]:
        """
        Implementation of ``port_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``occurrence_definitions`` of this ``PortUsage``, which must all
           be ``PortDefinitions``.

        See section
        `8.3.12.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=329>`__
        of the SysML specification for more details.
        """

class PortionKind(enum.Enum):
    """
    Implementation of ``PortionKind`` defined in the SysML specification.

    **Specification**:

       ``PortionKind`` is an enumeration of the specific kinds of
       ``Occurrence`` portions that can be represented by an
       ``OccurrenceUsage``.

    For language description, see section
    `7.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=84>`__
    of the SysML specification. For more details on the model, see section
    `8.3.9.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=320>`__
    of the SysML specification.
    """

    Timeslice = 0

    Snapshot = 1

class PositionUtf16:
    def __init__(self, line: int = 0, character: int = 0) -> None: ...

    @property
    def line(self) -> int: ...

    @line.setter
    def line(self, arg: int, /) -> None: ...

    @property
    def character(self) -> int: ...

    @character.setter
    def character(self, arg: int, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Position<Utf16Tag>'

class PositionUtf32:
    def __init__(self, line: int = 0, character: int = 0) -> None: ...

    @property
    def line(self) -> int: ...

    @line.setter
    def line(self, arg: int, /) -> None: ...

    @property
    def character(self) -> int: ...

    @character.setter
    def character(self, arg: int, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Position<Utf32Tag>'

class PositionUtf8:
    def __init__(self, line: int = 0, character: int = 0) -> None: ...

    @property
    def line(self) -> int: ...

    @line.setter
    def line(self, arg: int, /) -> None: ...

    @property
    def character(self) -> int: ...

    @character.setter
    def character(self, arg: int, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Position<Utf8Tag>'

class Predicate(Function):
    """
    Implementation of ``Predicate`` defined in the KerML specification.

    **Specification**:

       A ``Predicate`` is a ``Function`` whose ``result`` ``parameter`` has
       type ``Boolean`` and multiplicity ``1..1``.

    For language description, see section
    `7.4.8.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=82>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=229>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Predicate'

    STD: tuple[Union[type[Predicate], type[ConstraintDefinition]], ...] = (Predicate, ConstraintDefinition)

    if TYPE_CHECKING:
        Std = Union[Predicate, ConstraintDefinition]

class PrintMode(enum.Enum):
    KerML = 0

    SysML = 1

class PrinterConfig:
    def __init__(self, line_width: int = 100, tab_width: int = 4, line_end: LineEnd = LineEnd.LF, use_spaces: bool = True, add_final_newline: bool = True) -> None: ...

    @property
    def line_width(self) -> int: ...

    @line_width.setter
    def line_width(self, arg: int, /) -> None: ...

    @property
    def tab_width(self) -> int: ...

    @tab_width.setter
    def tab_width(self, arg: int, /) -> None: ...

    @property
    def line_end(self) -> LineEnd: ...

    @line_end.setter
    def line_end(self, arg: LineEnd, /) -> None: ...

    @property
    def use_spaces(self) -> bool: ...

    @use_spaces.setter
    def use_spaces(self, arg: bool, /) -> None: ...

    @property
    def add_final_newline(self) -> bool: ...

    @add_final_newline.setter
    def add_final_newline(self, arg: bool, /) -> None: ...

class QualifiedName(Sequence[str]):
    """
    A sequence of qualified name segments that stringifies with unrestricted names as needed.
    Unlike string, this allows querying segments in a qualified name without having to parse it again,
    and is cheaper to construct as string conversion is performed only when needed.
    """

    @overload
    def __init__(self) -> None:
        """Default constructor"""

    @overload
    def __init__(self, arg: QualifiedName) -> None:
        """Copy constructor"""

    @overload
    def __init__(self, arg: Iterable[str], /) -> None:
        """Construct from an iterable object"""

    def __len__(self) -> int: ...

    def __bool__(self) -> bool:
        """Check whether the vector is nonempty"""

    def __repr__(self) -> str: ...

    @overload
    def __getitem__(self, index: int) -> str: ...

    @overload
    def __getitem__(self, index: slice) -> QualifiedName: ...

    def clear(self) -> None:
        """Remove all items from list."""

    def append(self, arg: str, /) -> None:
        """Append `arg` to the end of the list."""

    def insert(self, arg0: int, arg1: str, /) -> None:
        """Insert object `arg1` before index `arg0`."""

    def pop(self, index: int = -1) -> str:
        """Remove and return item at `index` (default last)."""

    def extend(self, arg: QualifiedName, /) -> None:
        """Extend `self` by appending elements from `arg`."""

    @overload
    def __setitem__(self, arg0: int, arg1: str, /) -> None: ...

    @overload
    def __setitem__(self, arg0: slice, arg1: QualifiedName, /) -> None: ...

    @overload
    def __delitem__(self, arg: int, /) -> None: ...

    @overload
    def __delitem__(self, arg: slice, /) -> None: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    @overload
    def __contains__(self, arg: str, /) -> bool: ...

    @overload
    def __contains__(self, arg: object, /) -> bool: ...

    def count(self, arg: str, /) -> int:
        """Return number of occurrences of `arg`."""

    def remove(self, arg: str, /) -> None:
        """Remove first occurrence of `arg`."""

    def __iter__(self) -> Iterator[str]: ...

    def __str__(self) -> str: ...

R = TypeVar("R", bound=Relationship)

class RangeUtf16:
    def __init__(self, start: PositionUtf16, end: PositionUtf16) -> None: ...

    @property
    def start(self) -> PositionUtf16: ...

    @start.setter
    def start(self, arg: PositionUtf16, /) -> None: ...

    @property
    def end(self) -> PositionUtf16: ...

    @end.setter
    def end(self, arg: PositionUtf16, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Range<Utf16Tag>'

class RangeUtf32:
    def __init__(self, start: PositionUtf32, end: PositionUtf32) -> None: ...

    @property
    def start(self) -> PositionUtf32: ...

    @start.setter
    def start(self, arg: PositionUtf32, /) -> None: ...

    @property
    def end(self) -> PositionUtf32: ...

    @end.setter
    def end(self, arg: PositionUtf32, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Range<Utf32Tag>'

class RangeUtf8:
    def __init__(self, start: PositionUtf8, end: PositionUtf8) -> None: ...

    @property
    def start(self) -> PositionUtf8: ...

    @start.setter
    def start(self, arg: PositionUtf8, /) -> None: ...

    @property
    def end(self) -> PositionUtf8: ...

    @end.setter
    def end(self, arg: PositionUtf8, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::Range<Utf8Tag>'

class Reader:
    """Abstract base class for all deserialization readers."""

class Redefinition(Subsetting):
    """
    Implementation of ``Redefinition`` defined in the KerML specification.

    **Specification**:

       ``Redefinition`` is a kind of ``Subsetting`` that requires the
       ``redefined_feature`` and the ``redefining_feature`` to have the same
       values (on each instance of the domain of the
       ``redefining_feature``). This means any restrictions on the
       ``redefining_feature``, such as ``type`` or ``multiplicity``, also
       apply to the ``redefined_feature`` (on each instance of the domain of
       the ``redefining_feature``), and vice versa. The
       ``redefined_feature`` might have values for instances of the domain
       of the ``redefining_feature``, but only as instances of the domain of
       the ``redefined_feature`` that happen to also be instances of the
       domain of the ``redefining_feature``. This is supported by the
       constraints inherited from ``Subsetting`` on the domains of the
       ``redefining_feature`` and ``redefined_feature``. However, these
       constraints are narrowed for ``Redefinition`` to require the
       ``owning_types`` of the ``redefining_feature`` and
       ``redefined_feature`` to be different and the ``redefined_feature``
       to not be inherited into the ``owning_namespace`` of the
       ``redefining_feature``.This enables the ``redefining_feature`` to
       have the same name as the ``redefined_feature``, if desired.

    For language description, see section
    `7.3.4.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=62>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=204>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Redefinition'

    STD: tuple[type[Redefinition], ...] = (Redefinition,)

    if TYPE_CHECKING:
        Std = Redefinition

    CHAINABLE: bool = True

    @property
    def redefining_feature(self) -> Feature | None:
        """
        Implementation of ``redefining_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is redefining the ``redefined_feature`` of this
           ``Redefinition``.

        See section
        `8.3.3.3.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=204>`__
        of the KerML specification for more details.
        """

    @property
    def redefined_feature(self) -> Feature | None:
        """
        Implementation of ``redefined_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is redefined by the ``redefining_feature`` of
           this ``Redefinition``.

        See section
        `8.3.3.3.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=204>`__
        of the KerML specification for more details.
        """

    @property
    def redefining_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``redefining_feature``.
        """

    @property
    def redefined_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``redefined_feature``.
        """

class ReferenceAccessor(Generic[M]):
    @property
    def element(self) -> Element | None:
        """
        Returns the referenced ``Element``. This may return ``None``, e.g. when reference resolution failed,
        although in most such cases a placeholder element will be returned instead.
        """

    @property
    def modifiable(self) -> bool:
        """
        Returns ``True`` if this reference can be modified, that is the owning ``Relationship`` is an owned member
        of a ``Namespace``. Calling ``set`` methods when ``modifiable == False`` will raise ``ValueError``.
        """

    def try_set(self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set(self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class ReferenceParameterAccessor(OwnedMemberAccessor[ParameterMembership, ReferenceUsage]):
    @overload
    def set_member_element[M: ReferenceUsage](self, element: M, name: NameID = ...) -> tuple[ParameterMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M | None, name: NameID = ...) -> tuple[ParameterMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: type[M]) -> tuple[ParameterMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ReferencePrinter:
    """
    An opaque reference print function that will be called only for synthetic references.
    """

    @overload
    def __init__(self) -> None:
        """Construct a default reference printer"""

    @overload
    def __init__(self, preference: NamePreference) -> None:
        """
        Construct a reference printer that will select identifiers for printing using the given preference.
        """

    @overload
    def __init__(self, callback: Callable[[Element, Element], Sequence[str] | NamePreference]) -> None:
        """
        Construct a reference printer with a custom path callback. The signature is
        ``(target: Element, referent: Element) -> Sequence[str] | NamePreference``, where:

        - ``target`` is the element that is referenced. Callback should return the path to it.
        - ``referent`` is the referent element, e.g. ``Membership``.

        Callback may also choose to return a name preference which will be used to print the reference
        instead.
        """

class ReferenceSubsetting(Subsetting):
    """
    Implementation of ``ReferenceSubsetting`` defined in the KerML
    specification.

    **Specification**:

       ``ReferenceSubsetting`` is a kind of ``Subsetting`` in which the
       ``referenced_feature`` is syntactically distinguished from other
       ``Features`` subsetted by the ``referencing_feature``.
       ``ReferenceSubsetting`` has the same semantics as ``Subsetting``, but
       the ``referenced_feature`` may have a special purpose relative to the
       ``referencing_feature``. For instance, ``ReferenceSubsetting`` is
       used to identify the ``related_features`` of a ``Connector``.

       ``ReferenceSubsetting`` is always an ``owned_relationship`` of its
       ``referencing_feature``. A ``Feature`` can have at most one
       ``owned_reference_subsetting``.

    For language description, see section
    `7.4.6.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=74>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=205>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ReferenceSubsetting'

    STD: tuple[type[ReferenceSubsetting], ...] = (ReferenceSubsetting,)

    if TYPE_CHECKING:
        Std = ReferenceSubsetting

    CHAINABLE: bool = True

    @property
    def referenced_feature(self) -> Feature | None:
        """
        Implementation of ``referenced_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is referenced by the ``referencing_feature`` of
           this ``ReferenceSubsetting``.

        See section
        `8.3.3.3.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=205>`__
        of the KerML specification for more details.
        """

    @property
    def referencing_feature(self) -> Feature | None:
        """
        Implementation of ``referencing_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that owns this ``ReferenceSubsetting`` relationship,
           which is also its ``subsetting_feature``.

        See section
        `8.3.3.3.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=206>`__
        of the KerML specification for more details.
        """

    @property
    def referenced_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``referenced_feature``.
        """

    @property
    def referencing_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``referencing_feature``.
        """

class ReferenceUsage(Usage):
    """
    Implementation of ``ReferenceUsage`` defined in the SysML specification.

    **Specification**:

       A ``ReferenceUsage`` is a ``Usage`` that specifies a
       non-compositional (``is_composite = false``) reference to something.
       The ``definition`` of a ``ReferenceUsage`` can be any kind of
       ``Classifier``, with the default being the top-level ``Classifier``
       ``Base::Anything`` from the Kernel Semantic Library. This allows the
       specification of a generic reference without distinguishing if the
       thing referenced is an attribute value, item, action, etc.

    For language description, see section
    `7.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=72>`__
    of the SysML specification. For more details on the model, see section
    `8.3.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=302>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ReferenceUsage'

    STD: tuple[type[ReferenceUsage], ...] = (ReferenceUsage,)

    if TYPE_CHECKING:
        Std = ReferenceUsage

class ReferenceUsageAccessor(OwnedMemberAccessor[FeatureMembership, ReferenceUsage]):
    @overload
    def set_member_element[M: ReferenceUsage](self, element: M, name: NameID = ...) -> tuple[FeatureMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M | None, name: NameID = ...) -> tuple[FeatureMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: type[M]) -> tuple[FeatureMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ReferentAccessor(MemberAccessor[Membership, Feature]):
    @overload
    def set_member_element[M: Feature](self, element: M, name: NameID = ...) -> tuple[Membership, M]:
        """
        Set a new ``member_element``. ``element`` will only be referenced if the ``membership`` is ``Membership``,
        otherwise ownership constraints apply. Replaces the previous ``member_element``, which may be reused by the model
        if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Feature](self, element: M | None, name: NameID = ...) -> tuple[Membership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_owned_expression[M: Expression](self, arg: M, /) -> tuple[FeatureMembership, M]:
        """
        Set the referent to an owned ``Expression``. Ownership constraints apply.

        Returns a pair of (``feature_membership``, ``referent``).
        """

    @overload
    def set_owned_expression[M: Expression](self, arg: type[M], /) -> tuple[FeatureMembership, M]:
        """
        Set the referent to an empty ``Expression`` with the corresponding tye.

        Returns a pair of (``feature_membership``, ``referent``). Note that empty ``Expressions`` may not be representable
        in textual syntax.
        """

class Relationship(Element):
    """
    Implementation of ``Relationship`` defined in the KerML specification.

    **Specification**:

       A ``Relationship`` is an ``Element`` that relates other ``Element``.
       Some of its ``related_elements`` may be owned, in which case those
       ``owned_related_elements`` will be deleted from a model if their
       ``owning_relationship`` is. A ``Relationship`` may also be owned by
       another ``Element``, in which case the ``owned_related_elements`` of
       the ``Relationship`` are also considered to be transitively owned by
       the ``owning_related_element`` of the ``Relationship``.

       The ``related_elements`` of a ``Relationship`` are divided into
       ``source`` and ``target`` ``Elements``. The ``Relationship`` is
       considered to be directed from the ``source`` to the ``target``
       ``Elements``. An undirected ``Relationship`` may have either all
       ``source`` or all ``target`` ``Elements``.

       A “relationship ``Element``” in the abstract syntax is generically
       any ``Element`` that is an instance of either ``Relationship`` or a
       direct or indirect specialization of ``Relationship``. Any other kind
       of ``Element`` is a “non-relationship ``Element``”. It is a
       convention of that non-relationship ``Elements`` are *only* related
       via reified relationship ``Elements``. Any meta-associations directly
       between non-relationship ``Elements`` must be derived from underlying
       reified ``Relationship``.

    For language description, see section
    `7.2.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=41>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Relationship'

    STD: tuple[Union[type[Relationship], type[Association], type[ConnectionDefinition], type[Connector], type[ConnectorAsUsage], type[FlowDefinition]], ...] = (Relationship, Association, ConnectionDefinition, Connector, ConnectorAsUsage, FlowDefinition)

    if TYPE_CHECKING:
        Std = Union[Relationship, Association, ConnectionDefinition, Connector, ConnectorAsUsage, FlowDefinition]

    @property
    def is_implied(self) -> bool:
        """
        Implementation of ``is_implied`` defined in the KerML specification.

        **Specification**:

           Whether this Relationship was generated by tooling to meet semantic
           rules, rather than being directly created by a modeler.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @is_implied.setter
    def is_implied(self, arg: bool, /) -> None: ...

    @property
    def visibility(self) -> VisibilityKind:
        """
        The visibility level of the related elements from this ``Relationship`` relative to the ``owning_related_element``.

        Raises ``TypeError`` if visibility is immutable, e.g. on ``Expose`` elements.
        """

    @visibility.setter
    def visibility(self, arg: VisibilityKind | None) -> None: ...

    def try_set_visibility(self, arg: VisibilityKind | None) -> bool:
        """Non-throwing alternative to ``visibility`` setter."""

    def reset_visibility(self) -> None:
        """Reset visibility to its implicit value."""

    @property
    def is_visibility_implied(self) -> bool:
        """
        Returns ``True`` if this ``Relationship`` is using implicit visibility.
        """

    @property
    def owning_related_element(self) -> Element | None:
        """
        Implementation of ``owning_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_element of this Relationship that owns the Relationship,
           if any.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def sources(self) -> ContainerView[Element]:
        """
        Implementation of ``source`` defined in the KerML specification.

        **Specification**:

           The
           ``related_elements from which this Relationship is considered to be directed.``

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def targets(self) -> ContainerView[Element]:
        """
        Implementation of ``target`` defined in the KerML specification.

        **Specification**:

           The ``related_elements`` to which this Relationship is considered to
           be directed.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def related_elements(self) -> LazyIterator[Element]:
        """
        Implementation of ``related_element`` defined in the KerML
        specification.

        **Specification**:

           The Elements that are related by this Relationship, derived as the
           union of the ``source`` and ``target`` Elements of the Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

    @property
    def first_source(self) -> Element | None:
        """Convenience method for sources[0]."""

    @property
    def first_target(self) -> Element | None:
        """Convenience method for targets[0]."""

    @property
    def owned_related_elements(self) -> LazyIterator[Element]:
        """
        Implementation of ``owned_related_element`` defined in the KerML
        specification.

        **Specification**:

           The related_elements of this Relationship that are owned by the
           Relationship.

        See section
        `8.3.2.1.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=143>`__
        of the KerML specification for more details.
        """

class RelationshipBody(ContainerView[Element]):
    """
    Container for relationship bodies. Works similarly to ``ChildrenNodes`` except
    relationships are not needed and all elements are taken ownership off.

    TODO: add insert and replace methods.
    """

    @overload
    def append(self, element: type[TElement]) -> TElement:
        """
        Append an owned related element. Returns newly constructed related element.
        """

    @overload
    def append(self, element: TElement) -> TElement:
        """
        Append an owned existing related element. Returns the same related element.
        """

    @overload
    def append_annotation[M: AnnotatingElement | MetadataUsage | MetadataFeature](self, element: type[M]) -> tuple[Annotation, M]:
        """
        Append an owned annotation to an annotating element. Returns a pair of newly constructed
        (annotation, annotating element).
        """

    @overload
    def append_annotation[M: AnnotatingElement | MetadataUsage | MetadataFeature](self, element: M) -> tuple[Annotation, M]:
        """
        Append an owned annotation to an existing annotating element. Returns a pair of
        (annotation, annotating element) where only the annotation is newly constructed.
        """

    def pop(self, index: int = -1) -> Element:
        """
        Removes a related element at the specified index from the model tree and returns it.
        """

    def remove_element(self, arg: Element, /) -> bool:
        """
        Removes a related element from the model tree. Returns ``True`` if the element was
        removed, otherwise ``False``.
        """

    def extract(self, index: int = -1) -> Element:
        """
        Extracts a related element at the specified index from the model tree and returns it.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``IndexError`` if index is out of bounds.
        """

    def extract_element[T: Element](self, arg: T, /) -> T:
        """
        Extracts a related element from the model tree.

        Note that it is up to the user to ensure that the returned orphan element is not leaked.

        Raises ``ValueError`` if there is no such element.
        """

    def clear(self) -> None:
        """
        Removes and releases all elements in this container. Afterwards, ``len`` is 0.
        """

class RenderingDefinition(PartDefinition):
    """
    Implementation of ``RenderingDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``RenderingDefinition`` is a ``PartDefinition`` that defines a
       specific rendering of the content of a model view (e.g., symbols,
       style, layout, etc.).

    For language description, see section
    `7.26.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=186>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=419>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::RenderingDefinition'

    STD: tuple[type[RenderingDefinition], ...] = (RenderingDefinition,)

    if TYPE_CHECKING:
        Std = RenderingDefinition

    @property
    def renderings(self) -> LazyIterator[RenderingUsage]:
        """
        Implementation of ``rendering`` defined in the SysML specification.

        **Specification**:

           The ``usages`` of a ``RenderingDefinition`` that are
           ``RenderingUsages``.

        See section
        `8.3.26.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=419>`__
        of the SysML specification for more details.
        """

class RenderingUsage(PartUsage):
    """
    Implementation of ``RenderingUsage`` defined in the SysML specification.

    **Specification**:

       A ``RenderingUsage`` is the usage of a ``RenderingDefinition`` to
       specify the rendering of a specific model view to produce a physical
       view artifact.

    For language description, see section
    `7.26.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=186>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=420>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::RenderingUsage'

    STD: tuple[type[RenderingUsage], ...] = (RenderingUsage,)

    if TYPE_CHECKING:
        Std = RenderingUsage

    @property
    def rendering_definition(self) -> RenderingDefinition | None:
        """
        Implementation of ``rendering_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``RenderingDefinition`` that is the ``definition`` of this
           ``RenderingUsage``.

        See section
        `8.3.26.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=420>`__
        of the SysML specification for more details.
        """

class RequirementConstraintKind(enum.Enum):
    """
    Implementation of ``RequirementConstraintKind`` defined in the SysML
    specification.

    **Specification**:

       A ``RequirementConstraintKind`` indicates whether a
       ``ConstraintUsage`` is an assumption or a requirement in a
       ``RequirementDefinition`` or ``RequirementUsage``.

    For language description, see section
    `7.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=164>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=389>`__
    of the SysML specification.
    """

    Assumption = 0

    Requirement = 1

class RequirementConstraintMembership(FeatureMembership):
    """
    Implementation of ``RequirementConstraintMembership`` defined in the
    SysML specification.

    **Specification**:

       A ``RequirementConstraintMembership`` is a ``FeatureMembership`` for
       an assumed or required ``ConstraintUsage`` of a
       ``RequirementDefinition`` or ``RequirementUsage``.

    For language description, see section
    `7.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=164>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=390>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::RequirementConstraintMembership'

    STD: tuple[type[RequirementConstraintMembership], ...] = (RequirementConstraintMembership,)

    if TYPE_CHECKING:
        Std = RequirementConstraintMembership

    @property
    def kind(self) -> RequirementConstraintKind:
        """
        Implementation of ``kind`` defined in the SysML specification.

        **Specification**:

           Whether the ``RequirementConstraintMembership`` is for an assumed or
           required ``ConstraintUsage``.

        See section
        `8.3.21.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=390>`__
        of the SysML specification for more details.


        Note that setting ``kind`` on ``RequirementConstraintMembership`` subtypes will throw ``TypeError``.
        """

    @kind.setter
    def kind(self, arg: RequirementConstraintKind, /) -> None: ...

    def try_set_kind(self, arg: RequirementConstraintKind, /) -> bool:
        """
        An alternative to ``kind`` that will return ``False`` if this ``RequirementConstraintMembership`` does not allow modifying its ``kind`` rather than raising ``TypeError``.
        """

    @property
    def owned_constraint(self) -> ConstraintUsage | None:
        """
        Implementation of ``owned_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsage`` that is the ``owned_member_feature`` of this
           ``RequirementConstraintMembership``.

        See section
        `8.3.21.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=390>`__
        of the SysML specification for more details.
        """

    @property
    def referenced_constraint(self) -> ConstraintUsage | None:
        """
        Implementation of ``referenced_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsage`` that is referenced through this
           ``RequirementConstraintMembership``. It is the ``referenced_feature``
           of the ``owned_reference_subsetting`` of the ``owned_constraint``, if
           there is one, and, otherwise, the ``owned_constraint`` itself.

        See section
        `8.3.21.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=390>`__
        of the SysML specification for more details.
        """

class RequirementDefinition(ConstraintDefinition):
    """
    Implementation of ``RequirementDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``RequirementDefinition`` is a ``ConstraintDefinition`` that
       defines a requirement used in the context of a specification as a
       constraint that a valid solution must satisfy. The specification is
       relative to a specified subject, possibly in collaboration with one
       or more external actors.

    For language description, see section
    `7.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=164>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=391>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::RequirementDefinition'

    STD: tuple[type[RequirementDefinition], ...] = (RequirementDefinition,)

    if TYPE_CHECKING:
        Std = RequirementDefinition

    @property
    def subject_parameter(self) -> Usage | None:
        """
        Implementation of ``subject_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameter`` of this ``RequirementDefinition`` that represents
           its subject.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @property
    def actor_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``actor_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``RequirementDefinition`` that represent
           actors involved in the requirement.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=391>`__
        of the SysML specification for more details.
        """

    @property
    def req_id(self) -> str | None:
        """
        Implementation of ``req_id`` defined in the SysML specification.

        **Specification**:

           An optional modeler-specified identifier for this
           ``RequirementDefinition`` (used, e.g., to link it to an original
           requirement text in some source document), which is the
           ``declared_short_name`` for the ``RequirementDefinition``.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=391>`__
        of the SysML specification for more details.
        """

    @req_id.setter
    def req_id(self, arg: str | None) -> None: ...

    @property
    def texts(self) -> LazyIterator[str]:
        """
        Implementation of ``text`` defined in the SysML specification.

        **Specification**:

           An optional textual statement of the requirement represented by this
           ``RequirementDefinition``, derived from the ``bodies`` of the
           ``documentation`` of the ``RequirementDefinition``.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @property
    def stakeholder_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``stakeholder_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``RequirementDefinition`` that represent
           stakeholders for th requirement.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @property
    def assumed_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``assumed_constraint`` defined in the SysML
        specification.

        **Specification**:

           The owned ``ConstraintUsages`` that represent assumptions of this
           ``RequirementDefinition``, which are the ``owned_constraints`` of the
           ``RequirementConstraintMemberships`` of the ``RequirementDefinition``
           with ``kind = assumption``.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=391>`__
        of the SysML specification for more details.
        """

    @property
    def required_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``required_constraint`` defined in the SysML
        specification.

        **Specification**:

           The owned ``ConstraintUsages`` that represent requirements of this
           ``RequirementDefinition``, derived as the ``owned_constraints`` of
           the ``RequirementConstraintMemberships`` of the
           ``RequirementDefinition`` with ``kind`` = ``requirement``.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=392>`__
        of the SysML specification for more details.
        """

    @property
    def framed_concerns(self) -> LazyIterator[ConcernUsage]:
        """
        Implementation of ``framed_concern`` defined in the SysML specification.

        **Specification**:

           The ``ConcernUsages`` framed by this ``RequirementDefinition``, which
           are the ``owned_concerns`` of all ``FramedConcernMemberships`` of the
           ``RequirementDefinition``.

        See section
        `8.3.21.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=391>`__
        of the SysML specification for more details.
        """

class RequirementUsage(ConstraintUsage):
    """
    Implementation of ``RequirementUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``RequirementUsage`` is a ``Usage`` of a ``RequirementDefinition``.

    For language description, see section
    `7.21.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=164>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=393>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::RequirementUsage'

    STD: tuple[type[RequirementUsage], ...] = (RequirementUsage,)

    if TYPE_CHECKING:
        Std = RequirementUsage

    @property
    def requirement_definition(self) -> RequirementDefinition | None: ...

    @property
    def subject_parameter(self) -> Usage | None:
        """
        Implementation of ``subject_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameter`` of this ``RequirementUsage`` that represents its
           subject.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=394>`__
        of the SysML specification for more details.
        """

    @property
    def actor_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``actor_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``RequirementUsage`` that represent actors
           involved in the requirement.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=394>`__
        of the SysML specification for more details.
        """

    @property
    def req_id(self) -> str | None:
        """
        Implementation of ``req_id`` defined in the SysML specification.

        **Specification**:

           An optional modeler-specified identifier for this
           ``RequirementUsage`` (used, e.g., to link it to an original
           requirement text in some source document), which is the
           ``declared_short_name`` for the ``RequirementUsage``.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=394>`__
        of the SysML specification for more details.
        """

    @req_id.setter
    def req_id(self, arg: str | None) -> None: ...

    @property
    def texts(self) -> LazyIterator[str]:
        """
        Implementation of ``text`` defined in the SysML specification.

        **Specification**:

           An optional textual statement of the requirement represented by this
           ``RequirementUsage``, derived from the ``bodies`` of the
           ``documentation`` of the ``RequirementUsage``.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=394>`__
        of the SysML specification for more details.
        """

    @property
    def stakeholder_parameters(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``stakeholder_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``parameters`` of this ``RequirementUsage`` that represent
           stakeholders for the requirement.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=394>`__
        of the SysML specification for more details.
        """

    @property
    def assumed_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``assumed_constraint`` defined in the SysML
        specification.

        **Specification**:

           The owned ``ConstraintUsages`` that represent assumptions of this
           ``RequirementUsage``, derived as the ``owned_constraints`` of the
           ``RequirementConstraintMemberships`` of the ``RequirementUsage`` with
           ``kind`` = ``assumption``.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=394>`__
        of the SysML specification for more details.
        """

    @property
    def required_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``required_constraint`` defined in the SysML
        specification.

        **Specification**:

           The owned ``ConstraintUsages`` that represent requirements of this
           ``RequirementUsage``, which are the ``owned_constraints`` of the
           ``RequirementConstraintMemberships`` of the ``RequirementUsage`` with
           ``kind`` = ``requirement``.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=394>`__
        of the SysML specification for more details.
        """

    @property
    def framed_concerns(self) -> LazyIterator[ConcernUsage]:
        """
        Implementation of ``framed_concern`` defined in the SysML specification.

        **Specification**:

           The ``ConcernUsages`` framed by this ``RequirementUsage``, which are
           the ``owned_concerns`` of all ``FramedConcernMemberships`` of the
           ``RequirementUsage``.

        See section
        `8.3.21.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=394>`__
        of the SysML specification for more details.
        """

class RequirementVerificationMembership(RequirementConstraintMembership):
    """
    Implementation of ``RequirementVerificationMembership`` defined in the
    SysML specification.

    **Specification**:

       A ``RequirementVerificationMembership`` is a
       ``RequirementConstraintMembership`` used in the objective of a
       ``VerificationCase`` to identify a ``RequirementUsage`` that is
       verified by the ``VerificationCase``.

    For language description, see section
    `7.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=176>`__
    of the SysML specification. For more details on the model, see section
    `8.3.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=408>`__
    of the SysML specification.
    """

    __cpp_name__: str = ...

    STD: tuple[type[RequirementVerificationMembership], ...] = (RequirementVerificationMembership,)

    if TYPE_CHECKING:
        Std = RequirementVerificationMembership

    @property
    def owned_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``owned_requirement`` defined in the SysML
        specification.

        **Specification**:

           The owned ``RequirementUsage`` that acts as the ``owned_constraint``
           for this ``RequirementVerificationMembership``. This will either be
           the ``verified_requirement``, or it will subset the
           ``verified_requirement``.

        See section
        `8.3.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=409>`__
        of the SysML specification for more details.
        """

    @property
    def verified_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``verified_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsage`` that is identified as being verified. It is
           the ``referenced_constraint`` of the
           ``RequirementVerificationMembership`` considered as a
           ``RequirementConstraintMembership``, which must be a
           ``RequirementUsage``.

        See section
        `8.3.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=409>`__
        of the SysML specification for more details.
        """

class ResultExpressionAccessor(OwnedMemberAccessor[ResultExpressionMembership, Expression]):
    @overload
    def set_member_element[M: Expression](self, element: M, name: NameID = ...) -> tuple[ResultExpressionMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Expression](self, element: M | None, name: NameID = ...) -> tuple[ResultExpressionMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: Expression](self, element: type[M]) -> tuple[ResultExpressionMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class ResultExpressionMembership(FeatureMembership):
    """
    Implementation of ``ResultExpressionMembership`` defined in the KerML
    specification.

    **Specification**:

       A ``ResultExpressionMembership`` is a ``FeatureMembership`` that
       indicates that the ``owned_result_expression`` provides the result
       values for the ``Function`` or ``Expression`` that owns it. The
       owning ``Function`` or ``Expression`` must contain a
       ``BindingConnector`` between the ``result`` ``parameter`` of the
       ``owned_result_expression`` and the ``result`` ``parameter`` of the
       owning ``Function`` or ``Expression``.

    For language description, see section
    `7.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=80>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=229>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ResultExpressionMembership'

    STD: tuple[type[ResultExpressionMembership], ...] = (ResultExpressionMembership,)

    if TYPE_CHECKING:
        Std = ResultExpressionMembership

    @property
    def owned_result_expression(self) -> Expression | None:
        """
        Implementation of ``owned_result_expression`` defined in the KerML
        specification.

        **Specification**:

           The ``Expression`` that provides the result for the owner of the
           ``ResultExpressionMembership``.

        See section
        `8.3.4.7.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=230>`__
        of the KerML specification for more details.
        """

class ReturnParameterMembership(ParameterMembership):
    """
    Implementation of ``ReturnParameterMembership`` defined in the KerML
    specification.

    **Specification**:

       A ``ReturnParameterMembership`` is a ``ParameterMembership`` that
       indicates that the ``owned_member_parameter`` is the ``result``
       ``parameter`` of a ``Function`` or ``Expression``. The ``direction``
       of the ``owned_member_parameter`` must be ``out``.

    For language description, see section
    `7.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=80>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.7.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=230>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::ReturnParameterMembership'

    STD: tuple[type[ReturnParameterMembership], ...] = (ReturnParameterMembership,)

    if TYPE_CHECKING:
        Std = ReturnParameterMembership

class SatisfactionSubjectAccessor(OwnedMemberAccessor[SubjectMembership, ReferenceUsage]):
    @overload
    def set_member_element[M: ReferenceUsage](self, element: M, name: NameID = ...) -> tuple[SubjectMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: M | None, name: NameID = ...) -> tuple[SubjectMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: ReferenceUsage](self, element: type[M]) -> tuple[SubjectMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

    @property
    def target(self) -> Feature | None:
        """The target of this satisfaction subject."""

    @overload
    def set_target[T: Feature](self, element: T, name: NameID = ...) -> tuple[Membership, T]:
        """
        Set the target to a referenced ``Feature``.

        Returns a pair of (``membership``, ``target``).
        """

    @overload
    def set_target[T: Feature](self, element: T | None, name: NameID = ...) -> tuple[Membership, T] | None:
        """
        ``set_target`` overload that will remove the target element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    def set_target_chain(self, arg: Sequence[Feature], /) -> tuple[OwningMembership, Feature]:
        """
        Set the reference to a chain of ``Features``. Replaces the previous ``target``.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is the ``Feature``
        with owned ``FeatureChainings`` to the provided ``Features`` with order preserved.
        """

class SatisfyRequirementUsage(RequirementUsage):
    """
    Implementation of ``SatisfyRequirementUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``SatisfyRequirementUsage`` is an ``AssertConstraintUsage`` that
       asserts, by default, that a satisfied ``RequirementUsage`` is true
       for a specific ``satisfying_feature``, or, if ``is_negated = true``,
       that the ``RequirementUsage`` is false. The satisfied
       ``RequirementUsage`` is related to the ``SatisfyRequirementUsage`` by
       a ``ReferenceSubsetting`` ``Relationship``.

    For language description, see section
    `7.21.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=168>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=397>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::SatisfyRequirementUsage'

    STD: tuple[type[SatisfyRequirementUsage], ...] = (SatisfyRequirementUsage,)

    if TYPE_CHECKING:
        Std = SatisfyRequirementUsage

    @property
    def satisfied_requirement(self) -> RequirementUsage | None:
        """
        Implementation of ``satisfied_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsage`` that is satisfied by the
           ``satisfying_subject`` of this ``SatisfyRequirementUsage``. It is the
           ``asserted_constraint`` of the ``SatisfyRequirementUsage`` considered
           as an ``AssertConstraintUsage``, which must be a
           ``RequirementUsage``.

        See section
        `8.3.21.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=397>`__
        of the SysML specification for more details.
        """

    @property
    def satisfying_feature(self) -> Feature | None:
        """
        Implementation of ``satisfying_feature`` defined in the SysML
        specification.

        **Specification**:

           The ``Feature`` that represents the actual subject that is asserted
           to satisfy the ``satisfied_requirement``. The ``satisfying_feature``
           is bound to the ``subject_parameter`` of the
           ``SatisfyRequirementUsage``.

        See section
        `8.3.21.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=397>`__
        of the SysML specification for more details.
        """

    @property
    def satisfaction_subject_member(self) -> SatisfactionSubjectAccessor:
        """Syside specific accessor for manipulating ``satisfaction subject``."""

    @property
    def satisfaction_subject(self) -> ReferenceUsage | None:
        """The subject as explicitly declared via ``by`` in the textual syntax."""

    @property
    def is_negated(self) -> bool:
        """
        Implementation of ``is_negated`` defined in the KerML specification.

        **Specification**:

           Whether this ``Invariant`` is asserted to be false rather than true.

        See section
        `8.3.4.7.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=228>`__
        of the KerML specification for more details.
        """

    @is_negated.setter
    def is_negated(self, arg: bool, /) -> None: ...

    @property
    def asserted_constraint(self) -> ConstraintUsage | None:
        """
        Implementation of ``asserted_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsage`` to be performed by the
           ``AssertConstraintUsage``. It is the ``reference_feature`` of the
           ``owned_reference_subsetting`` for the ``AssertConstraintUsage``, if
           there is one, and, otherwise, the ``AssertConstraintUsage`` itself.

        See section
        `8.3.20.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=382>`__
        of the SysML specification for more details.
        """

class Schedule:
    @staticmethod
    def make_empty_schedule() -> Schedule: ...

    __cpp_name__: str = 'syside::Schedule'

class ScheduleError:
    @property
    def message(self) -> str: ...

    @property
    def input(self) -> Schedule | None: ...

    __cpp_name__: str = 'syside::ScheduleError'

class ScheduleOptions:
    def __init__(self, validation_timing: ValidationTiming, cutoff: BuildState = BuildState.Validated, force_revalidation: bool = False, attach_comments: bool = False, validation_tier: DocumentTier = DocumentTier.Project) -> None: ...

    @property
    def validation_timing(self) -> ValidationTiming:
        """Which validations to run."""

    @validation_timing.setter
    def validation_timing(self, arg: ValidationTiming, /) -> None: ...

    @property
    def validation_tier(self) -> DocumentTier:
        """
        Lowest tier of documents to validate. For example, ``Projects`` will validate only project documents,
        while ``StandardLibrary`` - everything.
        """

    @validation_tier.setter
    def validation_tier(self, arg: DocumentTier, /) -> None: ...

    @property
    def cutoff(self) -> BuildState:
        """
        The last stage in the pipeline that will be executed. Any stages higher than ``cutoff`` will be ignored.
        """

    @cutoff.setter
    def cutoff(self, arg: BuildState, /) -> None: ...

    @property
    def force_revalidation(self) -> bool:
        """If true, validated documents will be validated again."""

    @force_revalidation.setter
    def force_revalidation(self, arg: bool, /) -> None: ...

    @property
    def attach_comments(self) -> bool:
        """If true, comments will be attached. Mainly useful for formatters."""

    @attach_comments.setter
    def attach_comments(self, arg: bool, /) -> None: ...

    __cpp_name__: str = 'syside::ScheduleOptions'

class Scheme(enum.Enum):
    none = 0
    """Indicates that no scheme is present"""

    Unknown = 1
    """Indicates the scheme is not a well-known scheme"""

    Ftp = 2
    """
    File Transfer Protocol (FTP) 

    FTP is a standard communication protocol used for the transfer of computer files
    from a server to a client on a computer network.
    """

    File = 3
    """
    File URI Scheme

    The File URI Scheme is typically used to retrieve files from within one's own
    computer.
    """

    Http = 4
    """
    The Hypertext Transfer Protocol URI Scheme

    URLs of this type indicate a resource which is interacted with using the HTTP
    protocol.
    """

    Https = 5
    """
    The Secure Hypertext Transfer Protocol URI Scheme

    URLs of this type indicate a resource which is interacted with using the Secure
    HTTP protocol.
    """

    Ws = 6
    """
    The WebSocket URI Scheme

    URLs of this type indicate a resource which is interacted with using the
    WebSocket protocol.
    """

    Wss = 7
    """
    The Secure WebSocket URI Scheme

    URLs of this type indicate a resource which is interacted with using the Secure
    WebSocket protocol.
    """

class SelectExpression(OperatorExpression):
    """
    Implementation of ``SelectExpression`` defined in the KerML
    specification.

    **Specification**:

       A ``SelectExpression`` is an ``OperatorExpression`` whose operator is
       ``"select"``, which resolves to the ``Function``
       ``ControlFunctions::select`` from the Kernel Functions Library.

    For language description, see section
    `7.4.9.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=86>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.8.18 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=247>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::SelectExpression'

    STD: tuple[type[SelectExpression], ...] = (SelectExpression,)

    if TYPE_CHECKING:
        Std = SelectExpression

class Sema:
    """
    Semantic resolver for SysML. This is responsible for linking references and resolving semantic rules in the pipeline.
    """

    def __init__(self) -> None: ...

    def resolve(self, documents: Sequence[SharedMutex[Document]], index: StaticIndex, stdlib: Stdlib, reporter: Callable[[Document, Diagnostic], None] = ...) -> None:
        """
        Link and resolve semantic rules for ``documents``. Any documents that have already been resolved will be skipped,
        inferred by ``build_state >= BuildState.Built``. For references to be resolved correctly, they either have to
        point to elements in unresolved ``documents``, or elements indexed in ``index``. Similarly, semantic rules depend on all the
        required elements cached by ``stdlib``.

        ``reporter`` can be used to override default behaviour of how diagnostics are emitted. By default, they are printed to
        stdout.
        """

class SemaState(enum.Enum):
    """
    Semantic resolution state of ``Elements``. Sema will use this information to discard duplicate work, e.g. when resolving elements in a group of related documents.
    """

    none = 0

    Active = 1

    Resolved = 2

    Cached = 3

class SendActionUsage(ActionUsage):
    """
    Implementation of ``SendActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``SendActionUsage`` is an ``ActionUsage`` that specifies the
       sending of a payload given by the result of its ``payload_argument``
       ``Expression`` via a ``MessageTransfer`` whose ``source`` is given by
       the result of the ``sender_argument`` ``Expression`` and whose
       ``target`` is given by the result of the ``receiver_argument``
       ``Expression``. If no ``sender_argument`` is provided, the default is
       the ``this`` context for the action. If no ``receiver_argument`` is
       given, then the receiver is to be determined by, e.g., outgoing
       ``Connections`` from the sender.

    For language description, see section
    `7.17.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=136>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=359>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::SendActionUsage'

    STD: tuple[type[SendActionUsage], ...] = (SendActionUsage,)

    if TYPE_CHECKING:
        Std = SendActionUsage

    @property
    def receiver_argument(self) -> Expression | None:
        """
        Implementation of ``receiver_argument`` defined in the SysML
        specification.

        **Specification**:

           An ``Expression`` whose result is bound to the ``receiver`` input
           parameter of this ``SendActionUsage``.

        See section
        `8.3.17.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=359>`__
        of the SysML specification for more details.
        """

    @property
    def receiver_parameter(self) -> ReferenceUsage | None:
        """
        The parameter owning the ``receiver_argument`` if the argument is a part of the declaration before braces.
        """

    @property
    def receiver_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``receiver_parameter``."""

    @property
    def payload_argument(self) -> Expression | None:
        """
        Implementation of ``payload_argument`` defined in the SysML
        specification.

        **Specification**:

           An ``Expression`` whose result is bound to the ``payload`` input
           parameter of this ``SendActionUsage``.

        See section
        `8.3.17.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=359>`__
        of the SysML specification for more details.
        """

    @property
    def payload_parameter(self) -> ReferenceUsage | None:
        """
        The parameter owning the ``payload_argument`` if the argument is a part of the declaration before braces.
        """

    @property
    def payload_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``payload_parameter``."""

    @property
    def sender_argument(self) -> Expression | None:
        """
        Implementation of ``sender_argument`` defined in the SysML
        specification.

        **Specification**:

           An ``Expression`` whose result is bound to the ``sender`` input
           parameter of this ``SendActionUsage``.

        See section
        `8.3.17.15 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=359>`__
        of the SysML specification for more details.
        """

    @property
    def sender_parameter(self) -> ReferenceUsage | None:
        """
        The parameter owning the ``sender_argument`` if the argument is a part of the declaration before braces.
        """

    @property
    def sender_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``sender_parameter``."""

class SerdeMessage(Generic[T]):
    """Message emitted during (de)serialization"""

    @property
    def context(self) -> T:
        """The context that this message applies to."""

    @property
    def severity(self) -> DiagnosticSeverity:
        """The severity of the message."""

    @property
    def message(self) -> str:
        """Message contents."""

    def __str__(self) -> str: ...

class SerdeReport(Generic[T]):
    """(De)Serialization report containing emitted messages."""

    @property
    def messages(self) -> list[SerdeMessage[T]]: ...

    def __bool__(self) -> bool:
        """Returns ``True`` if none of the messages are errors."""

    def passed(self, warnings_as_errors: bool = False) -> bool:
        """
        Check if the report has no errors. If ``warnings_as_errors`` is ``True``, also check if it contains
        no warnings.
        """

    def __str__(self) -> str: ...

class SerializationOptions:
    """
    Options for SysML model serialization. Attribute options are ordered in descending precedence.
    """

    def __init__(self, use_standard_names: bool = True, include_derived: bool = False, include_redefined: bool = False, include_default: bool = False, include_optional: bool = False, include_implied: bool = False, fail_action: FailAction = FailAction.Diagnose) -> None: ...

    @property
    def use_standard_names(self) -> bool:
        """If true, fields will be serialized using standard names"""

    @use_standard_names.setter
    def use_standard_names(self, arg: bool, /) -> None: ...

    @property
    def include_derived(self) -> bool:
        """
        If true, serialize derived attributes. Corresponds to ``includesDerived`` flag in the specification (KerML 10.3, Table 13):

            Whether derived property values are included in the model interchange files.

        **Note:** Syside does not construct all derived properties yet. Therefore, setting
        ``options.include_derived`` to ``True`` may result in a JSON that does not satisfy the schema.
        """

    @include_derived.setter
    def include_derived(self, arg: bool, /) -> None: ...

    @property
    def include_redefined(self) -> bool:
        """
        If true, serialize attributes even if they are redefined in the metamodel.
        """

    @include_redefined.setter
    def include_redefined(self, arg: bool, /) -> None: ...

    @property
    def include_default(self) -> bool:
        """If true, serialize attributes even if they match their default values."""

    @include_default.setter
    def include_default(self, arg: bool, /) -> None: ...

    @property
    def include_optional(self) -> bool:
        """
        If true, non-required attributes will be serialized even if they are null or empty.
        """

    @include_optional.setter
    def include_optional(self, arg: bool, /) -> None: ...

    @property
    def include_implied(self) -> bool:
        """
        If true, serialize implicit elements. Only for attributes that are serialized. Corresponds to ``includesImplied`` flag in the specification (KerML 10.3, Table 13):

            Whether implied relationships are included in the model interchange files.
        """

    @include_implied.setter
    def include_implied(self, arg: bool, /) -> None: ...

    @property
    def fail_action(self) -> FailAction:
        """Action to take on serialization errors."""

    @fail_action.setter
    def fail_action(self, arg: FailAction, /) -> None: ...

    @staticmethod
    def minimal() -> SerializationOptions:
        """
        Configuration that instructs the writer to produce a minimal JSON without any redundant elements.
        Examples of redundant information that is avoided using the minimal configuration are:

        +   including fields for null values;
        +   including fields whose values match the default values;
        +   including redefined fields that are duplicates of redefining fields;
        +   including derived fields that can be computed from minimal JSON (for
            example, the result value of evaluating an expression);
        +   including implied relationships.
        """

    def with_options(self, use_standard_names: bool | None = None, include_derived: bool | None = None, include_redefined: bool | None = None, include_default: bool | None = None, include_optional: bool | None = None, include_implied: bool | None = None) -> SerializationOptions:
        """Creates a copy with the specified options changed to the given ones."""

class Serializer:
    """
    Serializer for SysML models. The actual serialization output depends on used ``Writer``.
    """

    def __init__(self) -> None: ...

    @overload
    def accept(self, root: Element, writer: Writer[T], options: SerializationOptions = ...) -> SerdeReport[Element]:
        """
        Perform serialization. The serialization result will be owned by the ``writer``, this only returns the collected diagnostics.
        """

    @overload
    def accept(self, root: Element, writer: Writer[T], use_standard_names: bool = True, include_derived: bool = False, include_redefined: bool = False, include_default: bool = False, include_optional: bool = False, include_implied: bool = False, fail_action: FailAction = FailAction.Diagnose) -> SerdeReport[Element]: ...

class SexpOptions:
    def __init__(self, indent: int = 2, include_implicit: bool = True, print_references: bool = False) -> None: ...

    @property
    def indent(self) -> int: ...

    @indent.setter
    def indent(self, arg: int, /) -> None: ...

    @property
    def include_implicit(self) -> bool: ...

    @include_implicit.setter
    def include_implicit(self, arg: bool, /) -> None: ...

    @property
    def print_references(self) -> bool:
        """
        If set, references will be printed next to some non-owning relationships.
        """

    @print_references.setter
    def print_references(self, arg: bool, /) -> None: ...

    __cpp_name__: str = 'syside::sysml::SexpOptions'

class SharedMutex(Generic[U]):
    def lock(self) -> WriteLocked[U]: ...

class Specialization(Relationship):
    """
    Implementation of ``Specialization`` defined in the KerML specification.

    **Specification**:

       ``Specialization`` is a ``Relationship`` between two ``Types`` that
       requires all instances of the ``specific`` type to also be instances
       of the ``general`` Type (i.e., the set of instances of the
       ``specific`` Type is a *subset* of those of the ``general`` Type,
       which might be the same set).

    For language description, see section
    `7.3.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=53>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Specialization'

    STD: tuple[type[Specialization], ...] = (Specialization,)

    if TYPE_CHECKING:
        Std = Specialization

    CHAINABLE: bool = True

    @property
    def general(self) -> Type | None:
        """
        Implementation of ``general`` defined in the KerML specification.

        **Specification**:

           A ``Type`` with a superset of all instances of the ``specific``
           ``Type``, which might be the same set.

        See section
        `8.3.3.1.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=169>`__
        of the KerML specification for more details.
        """

    @property
    def specific(self) -> Type | None:
        """
        Implementation of ``specific`` defined in the KerML specification.

        **Specification**:

           A ``Type`` with a subset of all instances of the ``general``
           ``Type``, which might be the same set.

        See section
        `8.3.3.1.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
        of the KerML specification for more details.
        """

    @property
    def owning_type(self) -> Type | None:
        """
        Implementation of ``owning_type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` that is the ``specific`` ``Type`` of this
           ``Specialization`` and owns it as its ``owning_related_element``.

        See section
        `8.3.3.1.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=170>`__
        of the KerML specification for more details.
        """

    @property
    def children(self) -> RelationshipBody:
        """The elements enclosed by curly brackets in textual syntax."""

    @property
    def specific_target(self) -> ChainedTypeReference:
        """Syside specific accessor for manipulating the target of ``specific``."""

    @property
    def general_target(self) -> ChainedTypeReference:
        """Syside specific accessor for manipulating the target of ``general``."""

class StageTimes:
    @property
    def ast(self) -> datetime.timedelta: ...

    @ast.setter
    def ast(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def sema(self) -> datetime.timedelta: ...

    @sema.setter
    def sema(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def validate(self) -> datetime.timedelta: ...

    @validate.setter
    def validate(self, arg: datetime.timedelta | float, /) -> None: ...

    @property
    def total(self) -> datetime.timedelta: ...

    @total.setter
    def total(self, arg: datetime.timedelta | float, /) -> None: ...

    __cpp_name__: str = 'syside::StageTimes'

class StakeholderMembership(ParameterMembership):
    """
    Implementation of ``StakeholderMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``StakeholderMembership`` is a ``ParameterMembership`` that
       identifies a ``PartUsage`` as a ``stakeholder_parameter`` of a
       ``RequirementDefinition`` or ``RequirementUsage``, which specifies a
       role played by an entity with concerns framed by the ``owning_type``.

    For language description, see section
    `7.21.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=160>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=399>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::StakeholderMembership'

    STD: tuple[type[StakeholderMembership], ...] = (StakeholderMembership,)

    if TYPE_CHECKING:
        Std = StakeholderMembership

    @property
    def owned_stakeholder_parameter(self) -> PartUsage | None:
        """
        Implementation of ``owned_stakeholder_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``PartUsage`` specifying the stakeholder.

        See section
        `8.3.21.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=399>`__
        of the SysML specification for more details.
        """

class StateDefinition(ActionDefinition):
    """
    Implementation of ``StateDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``StateDefinition`` is the ``Definition`` of the Behavior of a
       system or part of a system in a certain state condition.

       A ``StateDefinition`` may be related to up to three of its
       ``owned_features`` by ``StateBehaviorMembership`` ``Relationships``,
       all of different ``kinds``, corresponding to the entry, do and exit
       actions of the ``StateDefinition``.

    For language description, see section
    `7.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=149>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=368>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::StateDefinition'

    STD: tuple[type[StateDefinition], ...] = (StateDefinition,)

    if TYPE_CHECKING:
        Std = StateDefinition

    @property
    def states(self) -> LazyIterator[StateUsage]:
        """
        Implementation of ``state`` defined in the SysML specification.

        **Specification**:

           The ``StateUsages``, which are ``actions`` in the
           ``StateDefinition``, that specify the discrete states in the behavior
           defined by the ``StateDefinition``.

        See section
        `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=369>`__
        of the SysML specification for more details.
        """

    @property
    def is_parallel(self) -> bool:
        """
        Implementation of ``is_parallel`` defined in the SysML specification.

        **Specification**:

           Whether the ``owned_states`` of this ``StateDefinition`` are to all
           be performed in parallel. If true, none of the ``owned_actions``
           (which includes ``owned_states``) may have any incoming or outgoing
           ``Transitions``. If false, only one ``owned_state`` may be performed
           at a time.

        See section
        `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=369>`__
        of the SysML specification for more details.
        """

    @is_parallel.setter
    def is_parallel(self, arg: bool, /) -> None: ...

    @property
    def entry_action(self) -> ActionUsage | None:
        """
        Implementation of ``entry_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateDefinition`` to be performed on
           entry to the state defined by the ``StateDefinition``. It is the
           owned ``ActionUsage`` related to the ``StateDefinition`` by a
           ``StateSubactionMembership`` with ``kind = entry``.

        See section
        `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=369>`__
        of the SysML specification for more details.
        """

    @property
    def do_action(self) -> ActionUsage | None:
        """
        Implementation of ``do_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateDefinition`` to be performed while
           in the state defined by the ``StateDefinition``. It is the owned
           ``ActionUsage`` related to the ``StateDefinition`` by a
           ``StateSubactionMembership`` with ``kind = do``.

        See section
        `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=368>`__
        of the SysML specification for more details.
        """

    @property
    def exit_action(self) -> ActionUsage | None:
        """
        Implementation of ``exit_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateDefinition`` to be performed on
           exit to the state defined by the ``StateDefinition``. It is the owned
           ``ActionUsage`` related to the ``StateDefinition`` by a
           ``StateSubactionMembership`` with ``kind = exit``.

        See section
        `8.3.18.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=369>`__
        of the SysML specification for more details.
        """

class StateId:
    def __init__(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __index__(self) -> int: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __hash__(self) -> int: ...

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'tree_sitter::StateId'

class StateSubactionKind(enum.Enum):
    """
    Implementation of ``StateSubactionKind`` defined in the SysML
    specification.

    **Specification**:

       A ``StateSubactionKind`` indicates whether the ``action`` of a
       StateSubactionMembership is an entry, do or exit action.

    For language description, see section
    `7.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=149>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=367>`__
    of the SysML specification.
    """

    Entry = 0

    Do = 1

    Exit = 2

class StateSubactionMembership(FeatureMembership):
    """
    Implementation of ``StateSubactionMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``StateSubactionMembership`` is a ``FeatureMembership`` for an
       entry, do or exit ``ActionUsage`` of a ``StateDefinition`` or
       ``StateUsage``.

    For language description, see section
    `7.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=149>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=368>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::StateSubactionMembership'

    STD: tuple[type[StateSubactionMembership], ...] = (StateSubactionMembership,)

    if TYPE_CHECKING:
        Std = StateSubactionMembership

    @property
    def kind(self) -> StateSubactionKind:
        """
        Implementation of ``kind`` defined in the SysML specification.

        **Specification**:

           Whether this ``StateSubactionMembership`` is for an ``entry``, ``do``
           or ``exit`` ``ActionUsage``.

        See section
        `8.3.18.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=368>`__
        of the SysML specification for more details.
        """

    @kind.setter
    def kind(self, arg: StateSubactionKind, /) -> None: ...

    @property
    def action(self) -> ActionUsage | None:
        """
        Implementation of ``action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` that is the ``owned_member_feature`` of this
           ``StateSubactionMembership``.

        See section
        `8.3.18.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=368>`__
        of the SysML specification for more details.
        """

class StateUsage(ActionUsage):
    """
    Implementation of ``StateUsage`` defined in the SysML specification.

    **Specification**:

       A ``StateUsage`` is an ``ActionUsage`` that is nominally the
       ``Usage`` of a ``StateDefinition``. However, other kinds of kernel
       ``Behaviors`` are also allowed as ``types``, to permit use of
       ``Behaviors``

       A ``StateUsage`` may be related to up to three of its
       ``owned_features`` by ``StateSubactionMembership`` ``Relationships``,
       all of different ``kinds``, corresponding to the entry, do and exit
       actions of the ``StateUsage``.

    For language description, see section
    `7.18.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=149>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=370>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::StateUsage'

    STD: tuple[type[StateUsage], ...] = (StateUsage,)

    if TYPE_CHECKING:
        Std = StateUsage

    @property
    def state_definitions(self) -> LazyIterator[StateDefinition | Behavior | ActionDefinition]:
        """
        Implementation of ``state_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Behaviors`` that are the ``types`` of this ``StateUsage``.
           Nominally, these would be ``StateDefinitions``, but kernel
           ``Behaviors`` are also allowed, to permit use of ``Behaviors`` from
           the Kernel Model Libraries.

        See section
        `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=371>`__
        of the SysML specification for more details.
        """

    @property
    def is_parallel(self) -> bool:
        """
        Implementation of ``is_parallel`` defined in the SysML specification.

        **Specification**:

           Whether the ``nested_states`` of this ``StateUsage`` are to all be
           performed in parallel. If true, none of the ``nested_actions`` (which
           include ``nested_states``) may have any incoming or outgoing
           ``Transitions``. If false, only one ``nested_state`` may be performed
           at a time.

        See section
        `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=371>`__
        of the SysML specification for more details.
        """

    @is_parallel.setter
    def is_parallel(self, arg: bool, /) -> None: ...

    @property
    def entry_action(self) -> ActionUsage | None:
        """
        Implementation of ``entry_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateUsage`` to be performed on entry
           to the state defined by the ``StateDefinition``. It is the owned
           ``ActionUsage`` related to the ``StateUsage`` by a
           ``StateSubactionMembership`` with ``kind = entry``.

        See section
        `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=371>`__
        of the SysML specification for more details.
        """

    @property
    def do_action(self) -> ActionUsage | None:
        """
        Implementation of ``do_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateUsage`` to be performed while in
           the state defined by the ``StateDefinition``. It is the owned
           ``ActionUsage`` related to the ``StateUsage`` by a
           ``StateSubactionMembership`` with ``kind = do``.

        See section
        `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=371>`__
        of the SysML specification for more details.
        """

    @property
    def exit_action(self) -> ActionUsage | None:
        """
        Implementation of ``exit_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsage`` of this ``StateUsage`` to be performed on exit to
           the state defined by the ``StateDefinition``. It is the owned
           ``ActionUsage`` related to the ``StateUsage`` by a
           ``StateSubactionMembership`` with ``kind = exit``.

        See section
        `8.3.18.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=371>`__
        of the SysML specification for more details.
        """

class StaticIndex:
    def __init__(self) -> None: ...

    @overload
    def visit(self, arg0: str, arg1: Callable[[IndexedSymbol], None], /) -> None: ...

    @overload
    def visit(self, arg0: Sequence[str], arg1: Callable[[str, IndexedSymbol], None], /) -> None: ...

    @overload
    def visit_while(self, arg0: str, arg1: Callable[[IndexedSymbol], bool], /) -> None: ...

    @overload
    def visit_while(self, arg0: Sequence[str], arg1: Callable[[str, IndexedSymbol], bool], /) -> None: ...

    def insert(self, document: Document) -> int:
        """
        Add all symbols exported by ``document`` from this index. Returns the number of symbols added.

        **NOTE**: exported symbols must first be collected into the ``document``.
        """

    def erase(self, document: Document) -> int:
        """
        Remove all symbols exported by ``document`` from this index. Returns the number of symbols erased.

        **NOTE**: exported symbols must first be collected into the ``document``, and only symbols currently exported by ``document`` will be erased.
        """

    def reserve(self, arg: int, /) -> None:
        """
        Reserve memory for this index. This can reduce the number of allocations performed when adding new symbols to this index.
        """

    def clear(self) -> None:
        """Clear this index."""

    def clone(self) -> StaticIndex:
        """
        Clone this index. Modifications to one or the other index does not affect the other.
        """

    def __len__(self) -> int:
        """The number of different symbols name in this index."""

    def __bool__(self) -> bool:
        """Returns ``True`` if this index is not empty."""

    @property
    def empty(self) -> bool:
        """Returns ``True`` if this index contains no indexed symbols."""

    __cpp_name__: str = 'syside::StaticIndex<syside::sysml::SysMLTraits>'

class Stdlib:
    """Cache of standard library elements used by sema."""

    @overload
    def __init__(self) -> None:
        """
        Initialize an empty cache. Empty cache will be populated during pipeline execution, after documents
        have been indexed.
        """

    @overload
    def __init__(self, arg: StaticIndex, /) -> None:
        """
        Initialize cache from a given index. Cache will try to find elements only in the given index.
        """

    def update(self, arg: StaticIndex, /) -> bool:
        """
        Update missing elements from the given index. Returns true if all elements have been found.
        If all elements have already been found, this does nothing.
        """

    @property
    def all_complete(self) -> bool:
        """Returns ``True`` if all cacheable elements have been found and cached."""

    @property
    def anything(self) -> Type | None:
        """Cached ``Base::Anything``."""

    @property
    def ordered_collection(self) -> Type | None:
        """Cached ``Collections::OrderedCollection``."""

    @property
    def array(self) -> Type | None:
        """Cached ``Collections::Aray``."""

    @property
    def self_reference(self) -> Feature | None:
        """Cached ``Base::Anything::self``."""

    @property
    def collection_elements(self) -> Feature | None:
        """Cached ``Collections::Collection::elements``."""

    @property
    def array_dimensions(self) -> Feature | None:
        """Cached ``Collections::Array::dimensions``."""

    @property
    def scalar_value(self) -> Type | None:
        """Cached ``ScalarValues::ScalarValue``."""

    @property
    def boolean(self) -> Type | None:
        """Cached ``ScalarValues::Boolean``."""

    @property
    def string(self) -> Type | None:
        """Cached ``ScalarValues::String``."""

    @property
    def numerical_value(self) -> Type | None:
        """Cached ``ScalarValues::NumericalValue``."""

    @property
    def number(self) -> Type | None:
        """Cached ``ScalarValues::Number``."""

    @property
    def complex(self) -> Type | None:
        """Cached ``ScalarValues::Complex``."""

    @property
    def real(self) -> Type | None:
        """Cached ``ScalarValues::Real``."""

    @property
    def rational(self) -> Type | None:
        """Cached ``ScalarValues::Rational``."""

    @property
    def integer(self) -> Type | None:
        """Cached ``ScalarValues::Integer``."""

    @property
    def natural(self) -> Type | None:
        """Cached ``ScalarValues::Natural``."""

    @property
    def positive(self) -> Type | None:
        """Cached ``ScalarValues::Positive``."""

    @property
    def metadata_annotated_element(self) -> Feature | None:
        """Cached ``Metaobjects::Metaobject::annotatedElement``."""

    @property
    def metaobject(self) -> Type | None:
        """Cached ``Metaobjects::Metaobject``."""

    @property
    def tensor_quantity_value(self) -> Type | None:
        """Cached ``Quantities::TensorQuantityValue``."""

    @property
    def tensor_measurement_reference(self) -> Type | None:
        """Cached ``MeasurementReferences::TensorMeasurementReference``."""

    @property
    def measurement_unit_conversion(self) -> Feature | None:
        """Cached ``MeasurementReferences::MeasurementUnit::unitConversion``."""

    @property
    def unit_conversion(self) -> Type | None:
        """Cached ``MeasurementReferences::UnitConversion``."""

    @property
    def unit_conversion_factor(self) -> Feature | None:
        """Cached ``MeasurementReferences::UnitConversion::conversionFactor``."""

    @property
    def unit_conversion_reference(self) -> Feature | None:
        """Cached ``MeasurementReferences::UnitConversion::referenceUnit``."""

    @property
    def unit_prefix(self) -> Type | None:
        """Cached ``MeasurementReferences::UnitPrefix``."""

    @property
    def unit_prefix_factor(self) -> Feature | None:
        """Cached ``MeasurementReferences::UnitPrefix::conversionFactor``."""

    @property
    def semantic_metadata(self) -> Type | None:
        """Cached ``Metaobjects::SemanticMetadata``."""

    @property
    def semantic_metadata_base_type(self) -> Feature | None:
        """Cached ``Metaobjects::SemanticMetadata::baseType``."""

    @property
    def metaclasses(self) -> ContainerView[Metaclass | MetadataDefinition | None]:
        """
        All cached metaclasses of metamodel from standard library packages ``KerML`` and ``SysML``.
        """

    def metaclass_for(self, arg: type[Element], /) -> Metaclass | MetadataDefinition | None:
        """Get a corresponding metaclass for model type."""

    @property
    def implicit_supertypes(self) -> ContainerView[Type | None]:
        """All cached types that are used as implicit supertypes by sema."""

    def implicit_supertype_for(self, type: type[Element], kind: ImplicitSpecializationKind) -> Type | None:
        """
        Get a corresponding implicit supertype for ``type`` and ``kind`` tuple.

        **Note:** not all combinations make sense and ``None`` will be returned in those cases.
        """

    @property
    def operator_functions(self) -> ContainerView[Function | None]:
        """
        Cached standard operator functions in the order of ``Operator`` values. Note that
        this does not include ``Operator.Metadata`` since it is only used as a pseudo-operator
        internally.
        """

    def operator_function_for(self, operator: Operator) -> Function | None:
        """
        Get a corresponding standard library operator function for ``operator``.
        """

    @property
    def literal_boolean(self) -> Type | None:
        """Cached ``ScalarValues::Boolean``."""

    @property
    def literal_string(self) -> Type | None:
        """Cached ``ScalarValues::String``."""

    @property
    def literal_rational(self) -> Type | None:
        """Cached ``ScalarValues::Rational``."""

    @property
    def literal_integer(self) -> Type | None:
        """Cached ``ScalarValues::Integer``."""

    @property
    def literal_natural(self) -> Type | None:
        """Cached ``ScalarValues::Natural``."""

    @property
    def literal_positive(self) -> Type | None:
        """Cached ``ScalarValues::Positive``."""

    __cpp_name__: str = 'syside::sysml::stdlib::Cached'

class Step(Feature):
    """
    Implementation of ``Step`` defined in the KerML specification.

    **Specification**:

       A ``Step`` is a ``Feature`` that is typed by one or more
       ``Behaviors``. ``Steps`` may be used by one ``Behavior`` to
       coordinate the performance of other ``Behaviors``, supporting a
       steady refinement of behavioral descriptions. ``Steps`` can be
       ordered in time and can be connected using ``Flows`` to specify
       things flowing between their ``parameters``.

    For language description, see section
    `7.4.7.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=79>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Step'

    STD: tuple[Union[type[Step], type[ActionUsage], type[ConstraintUsage], type[Flow], type[FlowUsage]], ...] = (Step, ActionUsage, ConstraintUsage, Flow, FlowUsage)

    if TYPE_CHECKING:
        Std = Union[Step, ActionUsage, ConstraintUsage, Flow, FlowUsage]

    @property
    def behaviors(self) -> LazyIterator[Behavior | ActionDefinition]:
        """
        Implementation of ``behavior`` defined in the KerML specification.

        **Specification**:

           The ``Behaviors`` that type this ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=220>`__
        of the KerML specification for more details.
        """

    @property
    def owned_parameters(self) -> LazyIterator[Feature]:
        """The ``parameters`` owned by this ``Step``."""

    @property
    def parameters(self) -> LazyIterator[Feature]:
        """
        Implementation of ``parameter`` defined in the KerML specification.

        **Specification**:

           The ``parameters`` of this ``Step``, which are defined as its
           ``directed_features``, whose values are passed into and/or out of a
           performance of the ``Step``.

        See section
        `8.3.4.6.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=221>`__
        of the KerML specification for more details.
        """

class Stream(LazyIterator[T]):
    def __iter__(self) -> Iterator[T]: ...

class Structure(Class):
    """
    Implementation of ``Structure`` defined in the KerML specification.

    **Specification**:

       A ``Structure`` is a ``Class`` of objects in the modeled universe
       that are primarily structural in nature. While such an object is not
       itself behavioral, it may be involved in and acted on by
       ``Behaviors``, and it may be the performer of some of them.

    For language description, see section
    `7.4.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=68>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=210>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Structure'

    STD: tuple[Union[type[Structure], type[AssociationStructure], type[ItemDefinition], type[PortDefinition]], ...] = (Structure, AssociationStructure, ItemDefinition, PortDefinition)

    if TYPE_CHECKING:
        Std = Union[Structure, AssociationStructure, ItemDefinition, PortDefinition]

class Subclassification(Specialization):
    """
    Implementation of ``Subclassification`` defined in the KerML
    specification.

    **Specification**:

       ``Subclassification`` is ``Specialization`` in which both the
       ``specific`` and ``general`` ``Types`` are ``Classifier``. This means
       all instances of the specific ``Classifier`` are also instances of
       the general ``Classifier``.

    For language description, see section
    `7.3.3.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=58>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=182>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Subclassification'

    STD: tuple[type[Subclassification], ...] = (Subclassification,)

    if TYPE_CHECKING:
        Std = Subclassification

    CHAINABLE: bool = False

    @property
    def superclassifier(self) -> Classifier | None:
        """
        Implementation of ``superclassifier`` defined in the KerML
        specification.

        **Specification**:

           The more ``general`` Classifier in this ``Subclassification``.

        See section
        `8.3.3.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=182>`__
        of the KerML specification for more details.
        """

    @property
    def subclassifier(self) -> Classifier | None:
        """
        Implementation of ``subclassifier`` defined in the KerML specification.

        **Specification**:

           The more specific ``Classifier`` in this ``Subclassification``.

        See section
        `8.3.3.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=182>`__
        of the KerML specification for more details.
        """

    @property
    def owning_classifier(self) -> Classifier | None:
        """
        Implementation of ``owning_classifier`` defined in the KerML
        specification.

        **Specification**:

           The ``Classifier`` that owns this ``Subclassification`` relationship,
           which must also be its ``subclassifier``.

        See section
        `8.3.3.2.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=182>`__
        of the KerML specification for more details.
        """

    @property
    def superclassifier_target(self) -> ClassifierReference:
        """
        Syside specific accessor for manipulating the target of ``superclassifier``.
        """

    @property
    def subclassifier_target(self) -> ClassifierReference:
        """
        Syside specific accessor for manipulating the target of ``subclassifier``.
        """

class SubjectMembership(ParameterMembership):
    """
    Implementation of ``SubjectMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``SubjectMembership`` is a ``ParameterMembership`` that indicates
       that its ``owned_subject_parameter`` is the subject of its
       ``owning_type``. The ``owning_type`` of a ``SubjectMembership`` must
       be a ``RequirementDefinition``, ``RequirementUsage``,
       ``CaseDefinition``, or ``CaseUsage``.

    For language description, see section
    `7.21.1 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=160>`__
    of the SysML specification. For more details on the model, see section
    `8.3.21.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=398>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::SubjectMembership'

    STD: tuple[type[SubjectMembership], ...] = (SubjectMembership,)

    if TYPE_CHECKING:
        Std = SubjectMembership

    @property
    def owned_subject_parameter(self) -> ReferenceUsage | None:
        """
        Implementation of ``owned_subject_parameter`` defined in the SysML
        specification.

        **Specification**:

           The ``UsageownedMemberParameter`` of this ``SubjectMembership``.

        See section
        `8.3.21.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=398>`__
        of the SysML specification for more details.
        """

class Subsetting(Specialization):
    """
    Implementation of ``Subsetting`` defined in the KerML specification.

    **Specification**:

       ``Subsetting`` is ``Specialization`` in which the ``specific`` and
       ``general`` ``Types`` are ``Features``. This means all values of the
       ``subsetting_feature`` (on instances of its domain, i.e., the
       intersection of its ``featuring_types``) are values of the
       ``subsetted_feature`` on instances of its domain. To support this the
       domain of the ``subsetting_feature`` must be the same or specialize
       (at least indirectly) the domain of the ``subsetted_feature`` (via
       ``Specialization``), and the co-domain (intersection of the
       ``types``) of the ``subsetting_feature`` must specialize the
       co-domain of the ``subsetted_feature``.

    For language description, see section
    `7.3.4.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=61>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=206>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Subsetting'

    STD: tuple[type[Subsetting], ...] = (Subsetting,)

    if TYPE_CHECKING:
        Std = Subsetting

    CHAINABLE: bool = True

    @property
    def subsetted_feature(self) -> Feature | None:
        """
        Implementation of ``subsetted_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is subsetted by the ``subsetting_feature`` of
           this ``Subsetting``.

        See section
        `8.3.3.3.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=206>`__
        of the KerML specification for more details.
        """

    @property
    def subsetting_feature(self) -> Feature | None:
        """
        Implementation of ``subsetting_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is a subset of the ``subsetted_feature`` of this
           ``Subsetting``.

        See section
        `8.3.3.3.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=206>`__
        of the KerML specification for more details.
        """

    @property
    def owning_feature(self) -> Feature | None:
        """
        Implementation of ``owning_feature`` defined in the KerML specification.

        **Specification**:

           A ``subsetting_feature`` that is also the ``owning_related_element``
           of this ``Subsetting``.

        See section
        `8.3.3.3.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=206>`__
        of the KerML specification for more details.
        """

    @property
    def subsetted_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``subsetted_feature``.
        """

    @property
    def subsetting_feature_target(self) -> ChainedFeatureReference:
        """
        Syside specific accessor for manipulating the target of ``subsetting_feature``.
        """

class Succession(Connector):
    """
    Implementation of ``Succession`` defined in the KerML specification.

    **Specification**:

       A ``Succession`` is a binary ``Connector`` that requires its
       ``related_features`` to happen separately in time.

    For language description, see section
    `7.4.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=77>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.5.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=218>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Succession'

    STD: tuple[Union[type[Succession], type[SuccessionAsUsage], type[SuccessionFlow], type[SuccessionFlowUsage]], ...] = (Succession, SuccessionAsUsage, SuccessionFlow, SuccessionFlowUsage)

    if TYPE_CHECKING:
        Std = Union[Succession, SuccessionAsUsage, SuccessionFlow, SuccessionFlowUsage]

    @property
    def transition_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        A ``Step`` that is typed by the ``Behavior``
        ``TransitionPerformances::TransitionPerformance`` (from the Kernel
        Semantic Library) that has this ``Succession`` as its
        ``transition_link``.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def guard_expression(self) -> list[Expression]:
        """
        ``Expressions`` that must evaluate to true before the
        ``transition_step`` can occur.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

class SuccessionAsUsage(ConnectorAsUsage):
    """
    Implementation of ``SuccessionAsUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``SuccessionAsUsage`` is both a ``ConnectorAsUsage`` and a
       ``Succession``.

    For language description, see section
    `7.13.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=103>`__
    of the SysML specification. For more details on the model, see section
    `8.3.13.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=333>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::SuccessionAsUsage'

    STD: tuple[type[SuccessionAsUsage], ...] = (SuccessionAsUsage,)

    if TYPE_CHECKING:
        Std = SuccessionAsUsage

    @property
    def transition_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        A ``Step`` that is typed by the ``Behavior``
        ``TransitionPerformances::TransitionPerformance`` (from the Kernel
        Semantic Library) that has this ``Succession`` as its
        ``transition_link``.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def guard_expression(self) -> list[Expression]:
        """
        ``Expressions`` that must evaluate to true before the
        ``transition_step`` can occur.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

class SuccessionFlow(Flow):
    """
    Implementation of ``SuccessionFlow`` defined in the KerML specification.

    **Specification**:

       A ``SuccessionFlow`` is a ``Flow`` that also provides temporal
       ordering. It classifies ``Transfers`` that cannot start until the
       source ``Occurrence`` has completed and that must complete before the
       target ``Occurrence`` can start.

    For language description, see section
    `7.4.10.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=91>`__
    of the KerML specification. For more details on the model, see section
    `8.3.4.9.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=253>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::SuccessionFlow'

    STD: tuple[Union[type[SuccessionFlow], type[SuccessionFlowUsage]], ...] = (SuccessionFlow, SuccessionFlowUsage)

    if TYPE_CHECKING:
        Std = Union[SuccessionFlow, SuccessionFlowUsage]

    @property
    def transition_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        A ``Step`` that is typed by the ``Behavior``
        ``TransitionPerformances::TransitionPerformance`` (from the Kernel
        Semantic Library) that has this ``Succession`` as its
        ``transition_link``.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def guard_expression(self) -> list[Expression]:
        """
        ``Expressions`` that must evaluate to true before the
        ``transition_step`` can occur.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

class SuccessionFlowUsage(FlowUsage):
    """
    Implementation of ``SuccessionFlowUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``SuccessionFlowUsage`` is a ``FlowUsage`` that is also a KerML
       ``SuccessionFlow``.

    For language description, see section
    `7.16.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=113>`__
    of the SysML specification. For more details on the model, see section
    `8.3.16.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=340>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::SuccessionFlowUsage'

    STD: tuple[type[SuccessionFlowUsage], ...] = (SuccessionFlowUsage,)

    if TYPE_CHECKING:
        Std = SuccessionFlowUsage

    @property
    def transition_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        A ``Step`` that is typed by the ``Behavior``
        ``TransitionPerformances::TransitionPerformance`` (from the Kernel
        Semantic Library) that has this ``Succession`` as its
        ``transition_link``.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def trigger_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that map incoming events to the timing of occurrences of the
        ``transition_step``. The values of ``trigger_step`` subset the list of
        acceptable events to be received by a ``Behavior`` or the object that
        performs it.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_step(self) -> Step | ActionUsage | ConstraintUsage | Flow | FlowUsage | None:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def effect_steps(self) -> list[Step | ActionUsage | ConstraintUsage | Flow | FlowUsage]:
        """
        ``Steps`` that represent occurrences that are side effects of the
        ``transition_step`` occurring.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

    @property
    def guard_expression(self) -> list[Expression]:
        """
        ``Expressions`` that must evaluate to true before the
        ``transition_step`` can occur.

        Removed in 2025-04 specification, will be removed in a future Syside release.
        """

class Symbol:
    def __init__(self, arg: int, /) -> None: ...

    def __int__(self) -> int: ...

    def __index__(self) -> int: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __hash__(self) -> int: ...

    def __le__(self, arg: object, /) -> bool:
        pass

    def __ge__(self, arg: object, /) -> bool:
        pass

    def __lt__(self, arg: object, /) -> bool:
        pass

    def __gt__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'tree_sitter::Symbol'

T = TypeVar("T")

TElement = TypeVar("TElement", bound=Element)

TNode = TypeVar("TNode", bound=AstNode)

class TargetFeatureAccessor(ChainedMemberAccessor[Membership, Feature]):
    @overload
    def set_member_element[M: Feature](self, element: M, name: NameID = ...) -> tuple[Membership, M]:
        """
        Set a new ``member_element``. ``element`` will only be referenced if the ``membership`` is ``Membership``,
        otherwise ownership constraints apply. Replaces the previous ``member_element``, which may be reused by the model
        if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: Feature](self, element: M | None, name: NameID = ...) -> tuple[Membership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

class TerminateActionUsage(ActionUsage):
    """
    Implementation of ``TerminateActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``TerminateActionUsage`` is an ``ActionUsage`` that directly or
       indirectly specializes the ``ActionDefinition`` ``TerminateAction``
       from the Systems Model Library, which causes a given
       ``terminated_occurrence`` to end during its performance. By default,
       the ``terminated_occurrence`` is the featuring instance (``that``) of
       the performance of the ``TerminateActionUsage``, generally the
       performance of its immediately containing ``ActionDefinition`` or
       ``ActionUsage``.

    For language description, see section
    `7.17.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=141>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.16 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=360>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::TerminateActionUsage'

    STD: tuple[type[TerminateActionUsage], ...] = (TerminateActionUsage,)

    if TYPE_CHECKING:
        Std = TerminateActionUsage

    @property
    def terminated_occurrence_argument(self) -> Expression | None:
        """
        Implementation of ``terminated_occurrence_argument`` defined in the
        SysML specification.

        **Specification**:

           The ``Expression`` that is the ``feature_value`` of the
           ``terminate_occurrence`` ``parameter`` of this
           ``TerminateActionUsage``.

        See section
        `8.3.17.16 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=361>`__
        of the SysML specification for more details.
        """

    @property
    def terminated_occurrence_parameter(self) -> ReferenceUsage | None:
        """The parameter owning the ``terminated_occurrence_argument``."""

    @property
    def terminated_occurrence_member(self) -> ParameterAccessor:
        """Syside specific accessor for manipulating ``terminated_occurrence``."""

class TextDocument:
    @overload
    @staticmethod
    def create_st() -> SharedMutex[TextDocument]:
        """Create an empty TextDocument for single-threaded applications"""

    @overload
    @staticmethod
    def create_st(url: Url, language: str, content: str, version: int = 0) -> SharedMutex[TextDocument]: ...

    @overload
    @staticmethod
    def create_mt() -> SharedMutex[TextDocument]:
        """Create an empty TextDocument for multi-threaded applications"""

    @overload
    @staticmethod
    def create_mt(url: Url, language: str, content: str, version: int = 0) -> SharedMutex[TextDocument]: ...

    @property
    def url(self) -> Url: ...

    @property
    def language_id(self) -> str: ...

    @property
    def version(self) -> int: ...

    @property
    def text(self) -> str: ...

    @overload
    def get_text(self, range: RangeUtf8) -> str: ...

    @overload
    def get_text(self, range: RangeUtf16) -> str: ...

    @overload
    def get_text(self, range: RangeUtf32) -> str: ...

    @overload
    def offset_at(self, position: PositionUtf8) -> int: ...

    @overload
    def offset_at(self, position: PositionUtf16) -> int: ...

    @overload
    def offset_at(self, position: PositionUtf32) -> int: ...

    def utf8_position_at(self, offset: int) -> PositionUtf8: ...

    def utf16_position_at(self, offset: int) -> PositionUtf16: ...

    def utf32_position_at(self, offset: int) -> PositionUtf32: ...

    @property
    def line_count(self) -> int: ...

    def update(self, changes: Sequence[TextDocumentEditUtf8], version: int | None = None) -> None: ...

class TextDocumentData:
    def __init__(self, url: Url, language: str, content: str, version: int = 0) -> None: ...

    @property
    def url(self) -> Url: ...

    @url.setter
    def url(self, arg: Url, /) -> None: ...

    @property
    def language(self) -> str: ...

    @language.setter
    def language(self, arg: str, /) -> None: ...

    @property
    def content(self) -> str: ...

    @content.setter
    def content(self, arg: str, /) -> None: ...

    @property
    def version(self) -> int: ...

    @version.setter
    def version(self, arg: int, /) -> None: ...

class TextDocumentEditUtf16:
    def __init__(self, text: str, range: RangeUtf16 | None = None) -> None: ...

    @property
    def text(self) -> str: ...

    @text.setter
    def text(self, arg: str, /) -> None: ...

    @property
    def range(self) -> RangeUtf16 | None: ...

    @range.setter
    def range(self, arg: RangeUtf16 | None) -> None: ...

    __cpp_name__: str = ...

class TextDocumentEditUtf32:
    def __init__(self, text: str, range: RangeUtf32 | None = None) -> None: ...

    @property
    def text(self) -> str: ...

    @text.setter
    def text(self, arg: str, /) -> None: ...

    @property
    def range(self) -> RangeUtf32 | None: ...

    @range.setter
    def range(self, arg: RangeUtf32 | None) -> None: ...

    __cpp_name__: str = ...

class TextDocumentEditUtf8:
    def __init__(self, text: str, range: RangeUtf8 | None = None) -> None: ...

    @property
    def text(self) -> str: ...

    @text.setter
    def text(self, arg: str, /) -> None: ...

    @property
    def range(self) -> RangeUtf8 | None: ...

    @range.setter
    def range(self, arg: RangeUtf8 | None) -> None: ...

    __cpp_name__: str = 'syside::py::PyTextDocumentEdit<syside::Utf8Tag>'

class TextDocumentSaveReason(enum.Enum):
    Manual = 1

    AfterDelay = 2

    FocusOut = 3

class TextDocuments:
    @staticmethod
    def create_st() -> TextDocuments:
        """Create TextDocuments for single-threaded applications"""

    @staticmethod
    def create_mt() -> TextDocuments:
        """Create TextDocuments for multi-threaded applications"""

    def __getitem__(self, url: Url) -> SharedMutex[TextDocument]: ...

    def visit_documents(self, visitor: Callable[[SharedMutex[TextDocument]], None]) -> None: ...

    def visit_urls(self, visitor: Callable[[Url], None]) -> None: ...

    def visit(self, visitor: Callable[[Url, SharedMutex[TextDocument]], None]) -> None: ...

    @overload
    def open(self, url: Url, language: str, content: str, version: int = 0) -> SharedMutex[TextDocument]: ...

    @overload
    def open(self, arg: TextDocumentData, /) -> SharedMutex[TextDocument]: ...

    def find_or_open(self, url: Url, language: str, data: Callable[[], PartialTextDocumentData]) -> tuple[SharedMutex[TextDocument], bool]:
        """
        Find an existing document, or open a new one if either `url` does not exist, or an existing document
        has a different language. The second return value is only ``True`` if a new document was opened,
        and ``False`` if an existing document was found.
        """

    def close(self, url: Url) -> SharedMutex[TextDocument] | None: ...

    def move(self, src: Url, dst: Url) -> SharedMutex[TextDocument] | None: ...

    def will_save(self, url: Url, reason: TextDocumentSaveReason) -> None: ...

    def save(self, url: Url) -> None: ...

    def will_save_wait_until(self, url: Url, reason: TextDocumentSaveReason) -> list[TextEdit]: ...

    def change_content(self, url: Url, changes: Sequence[TextDocumentEditUtf8], version: int | None = None) -> None: ...

class TextEdit:
    @property
    def range(self) -> RangeUtf8: ...

    @range.setter
    def range(self, arg: RangeUtf8, /) -> None: ...

    @property
    def new_text(self) -> str: ...

    @new_text.setter
    def new_text(self, arg: str, /) -> None: ...

class TextualRepresentation(AnnotatingElement):
    """
    Implementation of ``TextualRepresentation`` defined in the KerML
    specification.

    **Specification**:

       A ``TextualRepresentation`` is an ``AnnotatingElement`` whose
       ``body`` represents the ``represented_element`` in a given
       ``language``. The ``represented_element`` must be the ``owner`` of
       the ``TextualRepresentation``. The named ``language`` can be a
       natural language, in which case the ``body`` is an informal
       representation, or an artificial language, in which case the ``body``
       is expected to be a formal, machine-parsable representation.

       If the named ``language`` of a ``TextualRepresentation`` is
       machine-parsable, then the ``body`` text should be legal input text
       as defined for that ``language``. The interpretation of the named
       language string shall be case insensitive. The following ``language``
       names are defined to correspond to the given standard languages:

       ========= ===========================
       ``kerml`` Kernel Modeling Language
       ``ocl``   Object Constraint Language
       ``alf``   Action Language for f_u_m_l
       ========= ===========================

       Other specifications may define specific ``language`` strings, other
       than those shown above, to be used to indicate the use of languages
       from those specifications in KerML ``TextualRepresentation``.

       If the ``language`` of a ``TextualRepresentation`` is “``kerml``”,
       then the ``body`` text shall be a legal representation of the
       ``represented_element`` in the KerML textual concrete syntax. A
       conforming tool can use such a ``TextualRepresentation``
       ``Annotation`` to record the original KerML concrete syntax text from
       which an ``Element`` was parsed. In this case, it is a tool
       responsibility to ensure that the ``body`` of the
       ``TextualRepresentation`` remains correct (or the Annotation is
       removed) if the annotated ``Element`` changes other than by
       re-parsing the ``body`` text.

       An ``Element`` with a ``TextualRepresentation`` in a language other
       than KerML is essentially a semantically “opaque” ``Element``
       specified in the other language. However, a conforming KerML tool may
       interpret such an element consistently with the specification of the
       named language.

    For language description, see section
    `7.2.4.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=46>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=150>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::TextualRepresentation'

    STD: tuple[type[TextualRepresentation], ...] = (TextualRepresentation,)

    if TYPE_CHECKING:
        Std = TextualRepresentation

    @property
    def language(self) -> str:
        """
        Implementation of ``language`` defined in the KerML specification.

        **Specification**:

           The natural or artificial language in which the ``body`` text is
           written.

        See section
        `8.3.2.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=150>`__
        of the KerML specification for more details.
        """

    @language.setter
    def language(self, arg: str, /) -> None: ...

    @property
    def body(self) -> str:
        """
        Implementation of ``body`` defined in the KerML specification.

        **Specification**:

           The textual representation of the ``represented_element`` in the
           given ``language``.

        See section
        `8.3.2.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=150>`__
        of the KerML specification for more details.
        """

    @body.setter
    def body(self, arg: str, /) -> None: ...

    @property
    def represented_element(self) -> Element | None:
        """
        Implementation of ``represented_element`` defined in the KerML
        specification.

        **Specification**:

           The ``Element`` that is represented by this
           ``TextualRepresentation``.

        See section
        `8.3.2.3.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=150>`__
        of the KerML specification for more details.
        """

class TransitionFeatureKind(enum.Enum):
    """
    Implementation of ``TransitionFeatureKind`` defined in the SysML
    specification.

    **Specification**:

       A ``TransitionActionKind`` indicates whether the
       ``transition_feature`` of a ``TransitionFeatureMembership`` is a
       trigger, guard or effect.

    For language description, see section
    `7.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=150>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=373>`__
    of the SysML specification.
    """

    Trigger = 0

    Guard = 1

    Effect = 2

class TransitionFeatureMembership(FeatureMembership):
    """
    Implementation of ``TransitionFeatureMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``TransitionFeatureMembership`` is a ``FeatureMembership`` for a
       trigger, guard or effect of a ``TransitionUsage``, whose
       ``transition_feature`` is a ``AcceptActionUsage``, ``Boolean``-valued
       ``Expression`` or ``ActionUsage``, depending on its ``kind``.

    For language description, see section
    `7.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=150>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=373>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::TransitionFeatureMembership'

    STD: tuple[type[TransitionFeatureMembership], ...] = (TransitionFeatureMembership,)

    if TYPE_CHECKING:
        Std = TransitionFeatureMembership

    @property
    def kind(self) -> TransitionFeatureKind:
        """
        Implementation of ``kind`` defined in the SysML specification.

        **Specification**:

           Whether this ``TransitionFeatureMembership`` is for a ``trigger``,
           ``guard`` or ``effect``.

        See section
        `8.3.18.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=374>`__
        of the SysML specification for more details.
        """

    @property
    def transition_feature(self) -> ActionUsage | Expression | None:
        """
        Implementation of ``transition_feature`` defined in the SysML
        specification.

        **Specification**:

           The ``Step`` that is the ``owned_member_feature`` of this
           ``TransitionFeatureMembership``.

        See section
        `8.3.18.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=374>`__
        of the SysML specification for more details.
        """

class TransitionSourceAccessor(ChainedMemberAccessor[Membership, ActionUsage]):
    @overload
    def set_member_element[M: ActionUsage](self, element: M, name: NameID = ...) -> tuple[Membership, M]:
        """
        Set a new ``member_element``. ``element`` will only be referenced if the ``membership`` is ``Membership``,
        otherwise ownership constraints apply. Replaces the previous ``member_element``, which may be reused by the model
        if it was owned.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: ActionUsage](self, element: M | None, name: NameID = ...) -> tuple[Membership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    def target(self) -> ActionUsage | None:
        """
        The feature target of this source member after following owned chaining if any.
        """

class TransitionUsage(ActionUsage):
    """
    Implementation of ``TransitionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``TransitionUsage`` is an ``ActionUsage`` representing a triggered
       transition between ``ActionUsages`` or ``StateUsages``. When
       triggered by a ``trigger_action``, when its ``guard_expression`` is
       true, the ``TransitionUsage`` asserts that its ``source`` is exited,
       then its ``effect_action`` (if any) is performed, and then its
       ``target`` is entered.

       A ``TransitionUsage`` can be related to some of its
       ``owned_features`` using ``TransitionFeatureMembership``
       ``Relationships``, corresponding to the ``trigger_action``,
       ``guard_expression`` and ``effect_action`` of the
       ``TransitionUsage``.

    For language description, see section
    `7.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=150>`__
    of the SysML specification. For more details on the model, see section
    `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=375>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::TransitionUsage'

    STD: tuple[type[TransitionUsage], ...] = (TransitionUsage,)

    if TYPE_CHECKING:
        Std = TransitionUsage

    @property
    def source(self) -> ActionUsage | None:
        """
        Implementation of ``source`` defined in the SysML specification.

        **Specification**:

           The source ``ActionUsage`` of this ``TransitionUsage``, which becomes
           the ``source`` of the ``succession`` for the ``TransitionUsage``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=375>`__
        of the SysML specification for more details.
        """

    @property
    def source_member(self) -> TransitionSourceAccessor:
        """Syside specific accessor for manipulating ``source``."""

    @property
    def target(self) -> ActionUsage | None:
        """
        Implementation of ``target`` defined in the SysML specification.

        **Specification**:

           The target ``ActionUsage`` of this ``TransitionUsage``, which is the
           ``target_feature`` of the ``succession`` for the ``TransitionUsage``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=375>`__
        of the SysML specification for more details.
        """

    @property
    def trigger_action(self) -> AcceptActionUsage | None:
        """
        Implementation of ``trigger_action`` defined in the SysML specification.

        **Specification**:

           The ``AcceptActionUsages`` that define the triggers of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = trigger``, which must all be ``AcceptActionUsages``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=375>`__
        of the SysML specification for more details.
        """

    @property
    def trigger_actions(self) -> list[AcceptActionUsage]:
        """
        Implementation of ``trigger_action`` defined in the SysML specification.

        **Specification**:

           The ``AcceptActionUsages`` that define the triggers of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = trigger``, which must all be ``AcceptActionUsages``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=375>`__
        of the SysML specification for more details.
        """

    @property
    def trigger_action_member(self) -> TriggerAccessor:
        """Syside specific accessor for manipulating ``trigger_action``."""

    @property
    def guard_expression(self) -> Expression | None:
        """
        Implementation of ``guard_expression`` defined in the SysML
        specification.

        **Specification**:

           The ``Expressions`` that define the guards of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = guard``, which must all be ``Expressions``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=375>`__
        of the SysML specification for more details.
        """

    @property
    def guard_expressions(self) -> list[Expression]:
        """
        Implementation of ``guard_expression`` defined in the SysML
        specification.

        **Specification**:

           The ``Expressions`` that define the guards of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = guard``, which must all be ``Expressions``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=375>`__
        of the SysML specification for more details.
        """

    @property
    def guard_expression_member(self) -> GuardAccessor:
        """Syside specific accessor for manipulating ``guard_expression``."""

    @property
    def effect_action(self) -> ActionUsage | None:
        """
        Implementation of ``effect_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsages`` that define the effects of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = effect``, which must all be ``ActionUsages``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=375>`__
        of the SysML specification for more details.
        """

    @property
    def effect_actions(self) -> list[ActionUsage]:
        """
        Implementation of ``effect_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsages`` that define the effects of this
           ``TransitionUsage``, which are the ``owned_features`` of the
           ``TransitionUsage`` related to it by ``TransitionFeatureMemberships``
           with ``kind = effect``, which must all be ``ActionUsages``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=375>`__
        of the SysML specification for more details.
        """

    @property
    def effect_action_member(self) -> EffectAccessor:
        """Syside specific accessor for manipulating ``effect_action``."""

    @property
    def succession(self) -> SuccessionAsUsage | None:
        """
        Implementation of ``succession`` defined in the SysML specification.

        **Specification**:

           The ``Succession`` that is the ``owned_feature`` of this
           ``TransitionUsage``, which, if the ``TransitionUsage`` is triggered,
           asserts the temporal ordering of the ``source`` and ``target``.

        See section
        `8.3.18.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=375>`__
        of the SysML specification for more details.
        """

    @property
    def succession_member(self) -> OwnedSuccessionAccessor:
        """Syside specific accessor for manipulating ``succession``."""

    @property
    def transition_link_source(self) -> ReferenceUsage | None:
        """
        The first ``EmptyParameterMember`` in the concrete syntax after ``TransitionSourceMember``.
        """

    @property
    def transition_link_source_member(self) -> ReferenceParameterAccessor:
        """Syside specific accessor for manipulating ``transition_link_source``."""

    @property
    def transition_link(self) -> ReferenceUsage | None: ...

    @property
    def transition_link_member(self) -> ReferenceUsageAccessor:
        """Syside specific accessor for manipulating ``transition_link``."""

    @property
    def payload(self) -> ReferenceUsage | None: ...

    @property
    def payload_member(self) -> ReferenceParameterAccessor:
        """Syside specific accessor for manipulating ``payload``."""

class TreeDrawing(enum.Enum):
    No = 0
    """No tree is drawn"""

    Ascii = 1
    """Use ASCII symbols for drawing"""

    Unicode = 2
    """Use unicode symbols for drawing"""

class TriggerAccessor(OwnedMemberAccessor[TransitionFeatureMembership, AcceptActionUsage]):
    @overload
    def set_member_element[M: AcceptActionUsage](self, element: M, name: NameID = ...) -> tuple[TransitionFeatureMembership, M]:
        """
        Set a new *owned* ``member_element``, ownership constraints apply. Replaces the previous
        ``member_element``, which may be reused by the model. ``name_id`` has no effect since the ``element`` is always
        taken ownership of.

        Returns a pair of (``membership``, ``member_element``) where ``member_element`` is ``element``.
        """

    @overload
    def set_member_element[M: AcceptActionUsage](self, element: M | None, name: NameID = ...) -> tuple[TransitionFeatureMembership, M] | None:
        """
        ``set_member_element`` overload that will remove the member element if ``element`` is ``None``, otherwise the
        behaviour is the same.
        """

    @overload
    def set_member_element[M: AcceptActionUsage](self, element: type[M]) -> tuple[TransitionFeatureMembership, M]:
        """
        Constructs a new empty ``member_element`` with the provided type. Replaces the previous ``member_element``.
        Because a new element is always constructed, ownership constraints do not apply.

        Returns a pair of (``membership``, ``member_element``).
        """

class TriggerInvocationExpression(InvocationExpression):
    """
    Implementation of ``TriggerInvocationExpression`` defined in the SysML
    specification.

    **Specification**:

       A ``TriggerInvocationExpression`` is an ``InvocationExpression`` that
       invokes one of the trigger ``Functions`` from the Kernel Semantic
       Library ``Triggers`` package, as indicated by its ``kind``.

    For language description, see section
    `7.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=150>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.17 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=361>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::TriggerInvocationExpression'

    STD: tuple[type[TriggerInvocationExpression], ...] = (TriggerInvocationExpression,)

    if TYPE_CHECKING:
        Std = TriggerInvocationExpression

    @property
    def kind(self) -> TriggerKind:
        """
        Implementation of ``kind`` defined in the SysML specification.

        **Specification**:

           Indicates which of the ``Functions`` from the ``Triggers`` model in
           the Kernel Semantic Library is to be invoked by this
           ``TriggerInvocationExpression``.

        See section
        `8.3.17.17 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=361>`__
        of the SysML specification for more details.
        """

    @kind.setter
    def kind(self, arg: TriggerKind, /) -> None: ...

class TriggerKind(enum.Enum):
    """
    Implementation of ``TriggerKind`` defined in the SysML specification.

    **Specification**:

       ``TriggerKind`` enumerates the kinds of triggers that can be
       represented by a ``TriggerInvocationExpression``.

    For language description, see section
    `7.18.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=150>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.18 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=363>`__
    of the SysML specification.
    """

    When = 0

    At = 1

    After = 2

class Type(Namespace):
    """
    Implementation of ``Type`` defined in the KerML specification.

    **Specification**:

       A ``Type`` is a ``Namespace`` that is the most general kind of
       ``Element`` supporting the semantics of classification. A ``Type``
       may be a ``Classifier`` or a ``Feature``, defining conditions on what
       is classified by the ``Type`` (see also the description of
       ``is_sufficient``).

    For language description, see section
    `7.3.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=52>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=171>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Type'

    STD: tuple[type[Type], ...] = (Type,)

    if TYPE_CHECKING:
        Std = Type

    @property
    def is_abstract(self) -> bool:
        """
        Implementation of ``is_abstract`` defined in the KerML specification.

        **Specification**:

           Indicates whether instances of this ``Type`` must also be instances
           of at least one of its specialized ``Types``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=172>`__
        of the KerML specification for more details.
        """

    @is_abstract.setter
    def is_abstract(self, arg: bool, /) -> None: ...

    @property
    def is_abstract_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Type`` was declared as ``abstract`` in the textual syntax.
        """

    @property
    def is_sufficient(self) -> bool:
        """
        Implementation of ``is_sufficient`` defined in the KerML specification.

        **Specification**:

           Whether all things that meet the classification conditions of this
           ``Type`` must be classified by the ``Type``.

           (A ``Type`` gives conditions that must be met by whatever it
           classifies, but when ``is_sufficient`` is false, things may meet
           those conditions but still not be classified by the ``Type``. For
           example, a Type ``Car`` that is not sufficient could require
           everything it classifies to have four wheels, but not all four
           wheeled things would classify as cars. However, if the ``Type``
           ``Car`` were sufficient, it would classify all four-wheeled things.)

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=172>`__
        of the KerML specification for more details.
        """

    @is_sufficient.setter
    def is_sufficient(self, arg: bool, /) -> None: ...

    @property
    def is_sufficient_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Type`` was declared as ``sufficient`` in the textual syntax.
        """

    @property
    def is_conjugated(self) -> bool:
        """
        Implementation of ``is_conjugated`` defined in the KerML specification.

        **Specification**:

           Indicates whether this ``Type`` has an ``owned_conjugator``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=172>`__
        of the KerML specification for more details.
        """

    @property
    def owned_specializations(self) -> LazyIterator[Specialization]:
        """
        Implementation of ``owned_specialization`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Type`` that are
           ``Specializations``, for which the ``Type`` is the ``specific``
           ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=173>`__
        of the KerML specification for more details.
        """

    @property
    def owned_feature_memberships(self) -> LazyIterator[FeatureMembership]:
        """
        Implementation of ``owned_feature_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_memberships`` of this ``Type`` that are
           ``FeatureMemberships``, for which the ``Type`` is the
           ``owning_type``. Each such ``FeatureMembership`` identifies an
           ``owned_feature`` of the ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=173>`__
        of the KerML specification for more details.
        """

    @property
    def owned_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_feature`` defined in the KerML specification.

        **Specification**:

           The ``owned_member_features`` of the ``owned_feature_memberships`` of
           this ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=173>`__
        of the KerML specification for more details.
        """

    @property
    def feature_memberships(self) -> LazyIterator[FeatureMembership]:
        """
        Implementation of ``feature_membership`` defined in the KerML
        specification.

        **Specification**:

           The ``FeatureMemberships`` for ``features`` of this ``Type``, which
           include all ``owned_feature_memberships`` and those
           ``inherited_memberships`` that are ``FeatureMemberships`` (but does
           *not* include any ``imported_memberships``).

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=172>`__
        of the KerML specification for more details.
        """

    @property
    def features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``feature`` defined in the KerML specification.

        **Specification**:

           The ``owned_member_features`` of the ``feature_memberships`` of this
           ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=171>`__
        of the KerML specification for more details.
        """

    @property
    def owned_inputs(self) -> LazyIterator[Feature]:
        """The ``inputs`` that are owned by this ``Type``."""

    @property
    def inputs(self) -> LazyIterator[Feature]:
        """
        Implementation of ``input`` defined in the KerML specification.

        **Specification**:

           All ``features`` related to this ``Type`` by ``FeatureMemberships``
           that have ``direction`` ``in`` or ``inout``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=172>`__
        of the KerML specification for more details.
        """

    @property
    def owned_outputs(self) -> LazyIterator[Feature]:
        """The ``outputs`` that are owned by this ``Type``."""

    @property
    def outputs(self) -> LazyIterator[Feature]:
        """
        Implementation of ``output`` defined in the KerML specification.

        **Specification**:

           All ``features`` related to this ``Type`` by ``FeatureMemberships``
           that have ``direction`` ``out`` or ``inout``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=172>`__
        of the KerML specification for more details.
        """

    @property
    def inherited_memberships(self) -> LazyIterator[Membership]:
        """
        Implementation of ``inherited_membership`` defined in the KerML
        specification.

        **Specification**:

           All ``Memberships`` inherited by this ``Type`` via ``Specialization``
           or ``Conjugation``. These are included in the derived union for the
           ``memberships`` of the ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=172>`__
        of the KerML specification for more details.
        """

    @property
    def owned_end_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``owned_end_feature`` defined in the KerML
        specification.

        **Specification**:

           All ``end_features`` of this ``Type`` that are ``owned_features``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=173>`__
        of the KerML specification for more details.
        """

    @property
    def end_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``end_feature`` defined in the KerML specification.

        **Specification**:

           All ``features`` of this ``Type`` with ``is_end = true``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=171>`__
        of the KerML specification for more details.
        """

    @property
    def owned_conjugator(self) -> Conjugation | None:
        """
        Implementation of ``owned_conjugator`` defined in the KerML
        specification.

        **Specification**:

           A ``Conjugation`` owned by this ``Type`` for which the ``Type`` is
           the ``original_type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=173>`__
        of the KerML specification for more details.
        """

    @property
    def inherited_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``inherited_feature`` defined in the KerML
        specification.

        **Specification**:

           All the ``member_features`` of the ``inherited_memberships`` of this
           ``Type`` that are ``FeatureMemberships``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=172>`__
        of the KerML specification for more details.
        """

    @property
    def multiplicity(self) -> Multiplicity | None:
        """
        Implementation of ``multiplicity`` defined in the KerML specification.

        **Specification**:

           An ``owned_member`` of this ``Type`` that is a ``Multiplicity``,
           which constraints the cardinality of the ``Type``. If there is no
           such ``owned_member``, then the cardinality of this ``Type`` is
           constrained by all the ``Multiplicity`` constraints applicable to any
           direct supertypes.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=172>`__
        of the KerML specification for more details.
        """

    @property
    def declared_multiplicity(self) -> MultiplicityRange | None:
        """
        The owned multiplicity that is declared before the children block in the textual syntax.
        """

    @property
    def declared_multiplicity_member(self) -> OwnedMultiplicityAccessor:
        """Syside specific accessor for manipulating ``declared_multiplicity``."""

    @property
    def owned_unionings(self) -> LazyIterator[Unioning]:
        """
        Implementation of ``owned_unioning`` defined in the KerML specification.

        **Specification**:

           The ``owned_relationships`` of this ``Type`` that are ``Unionings``,
           having the ``Type`` as their ``type_unioned``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=173>`__
        of the KerML specification for more details.
        """

    @property
    def unioning_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``unioning_type`` defined in the KerML specification.

        **Specification**:

           The interpretations of a ``Type`` with ``unioning_types`` are
           asserted to be the same as those of all the ``unioning_types``
           together, which are the ``Types`` derived from the ``unioning_type``
           of the ``owned_unionings`` of this ``Type``. For example, a
           ``Classifier`` for people might be the union of ``Classifiers`` for
           all the sexes. Similarly, a feature for people’s children might be
           the union of features dividing them in the same ways as people in
           general.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=173>`__
        of the KerML specification for more details.
        """

    @property
    def owned_intersectings(self) -> LazyIterator[Intersecting]:
        """
        Implementation of ``owned_intersecting`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Type`` that are
           ``Intersectings``, have the ``Type`` as their ``type_intersected``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=173>`__
        of the KerML specification for more details.
        """

    @property
    def intersecting_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``intersecting_type`` defined in the KerML
        specification.

        **Specification**:

           The interpretations of a ``Type`` with ``intersecting_types`` are
           asserted to be those in common among the ``intersecting_types``,
           which are the ``Types`` derived from the ``intersecting_type`` of the
           ``owned_intersectings`` of this ``Type``. For example, a
           ``Classifier`` might be an intersection of ``Classifiers`` for people
           of a particular sex and of a particular nationality. Similarly, a
           feature for people’s children of a particular sex might be the
           intersection of a ``Feature`` for their children and a ``Classifier``
           for people of that sex (because the interpretations of the children
           ``Feature`` that identify those of that sex are also interpretations
           of the Classifier for that sex).

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=172>`__
        of the KerML specification for more details.
        """

    @property
    def owned_disjoinings(self) -> LazyIterator[Disjoining]:
        """
        Implementation of ``owned_disjoining`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Type`` that are
           ``Disjoinings``, for which the ``Type`` is the ``type_disjoined``
           ``Type``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=173>`__
        of the KerML specification for more details.
        """

    @property
    def disjoining_types(self) -> LazyIterator[Type]:
        """The types that related to this ``Type`` through ``owned_disjoinings``."""

    @property
    def owned_differencings(self) -> LazyIterator[Differencing]:
        """
        Implementation of ``owned_differencing`` defined in the KerML
        specification.

        **Specification**:

           The ``owned_relationships`` of this ``Type`` that are
           ``Differencings``, having this ``Type`` as their
           ``type_differenced``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=173>`__
        of the KerML specification for more details.
        """

    @property
    def differencing_types(self) -> LazyIterator[Type]:
        """
        Implementation of ``differencing_type`` defined in the KerML
        specification.

        **Specification**:

           The interpretations of a ``Type`` with ``differencing_types`` are
           asserted to be those of the first of those ``Types``, but not
           including those of the remaining ``Types``. For example, a
           ``Classifier`` might be the difference of a ``Classifier`` for people
           and another for people of a particular nationality, leaving people
           who are not of that nationality. Similarly, a feature of people might
           be the difference between a feature for their children and a
           ``Classifier`` for people of a particular sex, identifying their
           children not of that sex (because the interpretations of the children
           ``Feature`` that identify those of that sex are also interpretations
           of the ``Classifier`` for that sex).

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=171>`__
        of the KerML specification for more details.
        """

    @property
    def owned_directed_features(self) -> LazyIterator[Feature]:
        """The ``directed_features`` that are owned by this ``Type``."""

    @property
    def directed_features(self) -> LazyIterator[Feature]:
        """
        Implementation of ``directed_feature`` defined in the KerML
        specification.

        **Specification**:

           The ``features`` of this ``Type`` that have a non-null ``direction``.

        See section
        `8.3.3.1.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=171>`__
        of the KerML specification for more details.
        """

    @property
    def heritage(self) -> Heritage:
        """The specializations and conjugations owned by this ``Type``."""

    @property
    def type_relationships(self) -> TypeRelationships:
        """
        The other type, feature relationships and ``FeatureChainings`` owned by this ``Type``.
        """

    @overload
    def conforms(self, arg: Sequence[str], /) -> bool:
        """
        Returns ``True`` if this ``Type`` directly or indirectly specializes another ``Type`` while following ``FeatureChainings``.
        """

    @overload
    def conforms(self, arg: Type, /) -> bool: ...

    @overload
    def specializes(self, arg: Sequence[str], /) -> bool:
        """
        Returns ``True`` if this ``Type`` directly or indirectly specializes another ``Type`` while ignoring ``FeatureChainings``.
        """

    @overload
    def specializes(self, arg: Type, /) -> bool: ...

    def direction_of(self, arg: Feature, /) -> FeatureDirectionKind | None:
        """Returns the direction of a ``Feature`` in this ``Type``."""

class TypeFeaturing(Relationship):
    """
    Implementation of ``TypeFeaturing`` defined in the KerML specification.

    **Specification**:

       A ``TypeFeaturing`` is a ``Featuring`` ``Relationship`` in which the
       ``feature_of_type`` is the ``source`` and the ``featuring_type`` is
       the ``target``.

    For language description, see section
    `7.3.4.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=65>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.3.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=207>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::TypeFeaturing'

    STD: tuple[type[TypeFeaturing], ...] = (TypeFeaturing,)

    if TYPE_CHECKING:
        Std = TypeFeaturing

    CHAINABLE: bool = False

    @property
    def feature_of_type(self) -> Feature | None:
        """
        Implementation of ``feature_of_type`` defined in the KerML
        specification.

        **Specification**:

           The ``Feature`` that is featured by the ``featuring_type``. It is the
           ``source`` of the ``TypeFeaturing``.

        See section
        `8.3.3.3.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=207>`__
        of the KerML specification for more details.
        """

    @property
    def featuring_type(self) -> Type | None:
        """
        Implementation of ``featuring_type`` defined in the KerML specification.

        **Specification**:

           The ``Type`` that features the ``feature_of_type``. It is the
           ``target`` of the ``TypeFeaturing``.

        See section
        `8.3.3.3.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=207>`__
        of the KerML specification for more details.
        """

    @property
    def owning_feature_of_type(self) -> Feature | None:
        """
        Implementation of ``owning_feature_of_type`` defined in the KerML
        specification.

        **Specification**:

           A ``feature_of_type`` that is also the ``owning_related_element`` of
           this ``TypeFeaturing``.

        See section
        `8.3.3.3.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=207>`__
        of the KerML specification for more details.
        """

    @property
    def feature_of_type_target(self) -> FeatureReference:
        """
        Syside specific accessor for manipulating the target of ``feature_of_type``.
        """

    @property
    def featuring_type_target(self) -> TypeReference:
        """
        Syside specific accessor for manipulating the target of ``featuring_type``.
        """

class TypeGuard:
    """
    The type used in a type check expression, e.g. ``istype``, ``hastype``. The actual expression result type is
    ``ScalarValues::Boolean``.
    """

    @property
    def value(self) -> Type: ...

    @value.setter
    def value(self, arg: Type, /) -> None: ...

class TypeReference(ReferenceAccessor[Type]):
    def try_set[M: Type](self, element: M, name: NameID = ...) -> M | None:
        """
        Try changing the referenced ``element``. Returns ``None`` if this reference cannot be modified, otherwise
        returns ``element`` argument.
        """

    def set[M: Type](self, element: M, name: NameID = ...) -> M:
        """
        ``try_set`` but instead raises ``ValueError`` if this reference cannot be modified.
        """

class TypeRelationships(ChainedChildrenNodes[Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing, Type]):
    def append[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing, M: Type](self, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Append a new *owned* or *referenced* element, inferred from the relationship type and this container. Returns a
        pair of (relationship, element), only the relationship is newly constructed.
        """

    def replace[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing, M: Type](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Replace the relationship and its related element at the specified index. The relationship may be reused if its
        type matches the current relationship at that index. The related element may be *owned* or *referenced*
        depending on the relationship type and this container, see ``append`` for more details.
        """

    def insert[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing, M: Type](self, index: int, relationship: type[R], element: M, name: NameID = ...) -> tuple[R, M]:
        """
        Insert a relationship and a related element at the specified index. The related element may be *owned* or
        *referenced* depending on the relationship type and this container, see ``append`` for more details.
        """

    def append_chain[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing](self, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Append a relationship with an owned chaining. Raises ``TypeError`` if the relationship type cannot have owned
        chaining in the textual syntax.
        """

    def insert_chain[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing](self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Insert a relationship with an owned chaining at the specified index. Raises ``TypeError`` if the relationship
        type cannot have owned chaining in the textual syntax.
        """

    def replace_chain_at[R: Unioning | Intersecting | Differencing | Disjoining | FeatureChaining | FeatureInverting | TypeFeaturing](self, index: int, relationship: type[R], features: Sequence[Feature]) -> tuple[R, Feature]:
        """
        Replace the relationship and its related element at the specified index with an owned chaining. The relationship
        may be reused if its type matches the current relationship at that index. Raises ``TypeError`` if the
        relationship type cannot have owned chaining in the textual syntax.
        """

U = TypeVar("U", covariant=True)

class UnexpectedDifferentReference:
    @property
    def reference(self) -> Element | None:
        """
        Referenced element that was found, ``None`` if no matching reference could be inferred
        """

    @reference.setter
    def reference(self, arg: Element | None, /) -> None: ...

    @property
    def expected(self) -> Element:
        """Element that was expected to be referenced"""

    @expected.setter
    def expected(self, arg: Element, /) -> None: ...

    def __str__(self) -> str: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    __cpp_name__: str = 'syside::sysml::UnexpectedDifferentReference'

class Unioning(Relationship):
    """
    Implementation of ``Unioning`` defined in the KerML specification.

    **Specification**:

       ``Unioning`` is a ``Relationship`` that makes its ``unioning_type``
       one of the ``unioning_types`` of its ``type_unioned``.

    For language description, see section
    `7.3.2.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=56>`__
    of the KerML specification. For more details on the model, see section
    `8.3.3.1.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=180>`__
    of the KerML specification.
    """

    __cpp_name__: str = 'syside::sysml::Unioning'

    STD: tuple[type[Unioning], ...] = (Unioning,)

    if TYPE_CHECKING:
        Std = Unioning

    CHAINABLE: bool = True

    @property
    def type_unioned(self) -> Type | None:
        """
        Implementation of ``type_unioned`` defined in the KerML specification.

        **Specification**:

           ``Type`` with interpretations partly determined by ``unioning_type``,
           as described in ``Type::unioning_type``.

        See section
        `8.3.3.1.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=180>`__
        of the KerML specification for more details.
        """

    @property
    def unioning_type(self) -> Type | None:
        """
        Implementation of ``unioning_type`` defined in the KerML specification.

        **Specification**:

           ``Type`` that partly determines interpretations of ``type_unioned``,
           as described in ``Type::unioning_type``.

        See section
        `8.3.3.1.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=180>`__
        of the KerML specification for more details.
        """

class Url:
    """
    ``URL`` as described using the `Uniform Resource Identifier (URI) <https://datatracker.ietf.org/doc/html/rfc3986>`_ specification (RFC3986).

    Raises ``RuntimeError`` on invalid URLs, including those with unicode characters. Unicode characters must be
    percent escaped by encoding them as hex with ``%`` escape.

    See `Boost.URL <https://github.com/boostorg/url>`_ for more details.
    """

    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, arg: str, /) -> None: ...

    def __deepcopy__(self) -> Url: ...

    def __copy__(self) -> Url: ...

    def __str__(self) -> str: ...

    def __repr__(self) -> str: ...

    def clear(self) -> None: ...

    def reserve(self, arg: int, /) -> None: ...

    def __len__(self) -> int: ...

    def __bool__(self) -> bool: ...

    @property
    def has_scheme(self) -> bool: ...

    @property
    def scheme(self) -> str: ...

    @property
    def scheme_id(self) -> Scheme: ...

    @property
    def has_authority(self) -> bool: ...

    @property
    def authority(self) -> str: ...

    @property
    def encoded_authority(self) -> str: ...

    @property
    def has_userinfo(self) -> bool: ...

    @property
    def has_password(self) -> bool: ...

    @property
    def userinfo(self) -> str: ...

    @property
    def encoded_userinfo(self) -> str: ...

    @property
    def user(self) -> str: ...

    @property
    def encoded_user(self) -> str: ...

    @property
    def password(self) -> str: ...

    @property
    def encoded_password(self) -> str: ...

    @property
    def host_type(self) -> HostType: ...

    @property
    def host(self) -> str: ...

    @property
    def encoded_host(self) -> str: ...

    @property
    def host_address(self) -> str: ...

    @property
    def encoded_host_address(self) -> str: ...

    @property
    def host_ipv4_address(self) -> IPv4Address: ...

    @property
    def host_ipv6_address(self) -> IPv6Address: ...

    @property
    def host_ipvfuture(self) -> str: ...

    @property
    def host_name(self) -> str: ...

    @property
    def encoded_host_name(self) -> str: ...

    @property
    def zone_id(self) -> str: ...

    @property
    def encoded_zone_id(self) -> str: ...

    @property
    def has_port(self) -> bool: ...

    @property
    def port(self) -> str: ...

    @property
    def port_number(self) -> int: ...

    @property
    def is_path_absolute(self) -> bool: ...

    @property
    def path(self) -> str: ...

    @property
    def encoded_path(self) -> str: ...

    @property
    def has_query(self) -> bool: ...

    @property
    def query(self) -> str: ...

    @property
    def encoded_query(self) -> str: ...

    def params(self, options: EncodingOpts = ...) -> list[tuple[str, str | None]]: ...

    @property
    def encoded_params(self) -> list[tuple[str, str | None]]: ...

    @property
    def has_fragment(self) -> bool: ...

    @property
    def fragment(self) -> str: ...

    @property
    def encoded_fragment(self) -> str: ...

    @property
    def encoded_host_and_port(self) -> str: ...

    @property
    def encoded_origin(self) -> str: ...

    @property
    def encoded_resource(self) -> str: ...

    @property
    def encoded_target(self) -> str: ...

    def set_scheme(self, arg: str, /) -> Url: ...

    def set_scheme_id(self, arg: Scheme, /) -> Url: ...

    def remove_scheme(self) -> Url: ...

    def set_encoded_authority(self, arg: str, /) -> Url: ...

    def remove_authority(self) -> Url: ...

    def set_userinfo(self, arg: str, /) -> Url: ...

    def set_encoded_userinfo(self, arg: str, /) -> Url: ...

    def remove_userinfo(self) -> Url: ...

    def set_user(self, arg: str, /) -> Url: ...

    def set_encoded_user(self, arg: str, /) -> Url: ...

    def set_password(self, arg: str, /) -> Url: ...

    def set_encoded_password(self, arg: str, /) -> Url: ...

    def remove_password(self) -> Url: ...

    def set_host(self, arg: str, /) -> Url: ...

    def set_encoded_host(self, arg: str, /) -> Url: ...

    def set_host_address(self, arg: str, /) -> Url: ...

    def set_encoded_host_address(self, arg: str, /) -> Url: ...

    def set_host_ipv4(self, arg: IPv4Address, /) -> Url: ...

    def set_host_ipv6(self, arg: IPv6Address, /) -> Url: ...

    def set_host_ipvfuture(self, arg: str, /) -> Url: ...

    def set_host_name(self, arg: str, /) -> Url: ...

    def set_encoded_host_name(self, arg: str, /) -> Url: ...

    def set_port_number(self, arg: int, /) -> Url: ...

    def set_port(self, arg: str, /) -> Url: ...

    def remove_port(self) -> Url: ...

    def set_path(self, arg: str, /) -> Url: ...

    def set_encoded_path(self, arg: str, /) -> Url: ...

    def set_query(self, arg: str, /) -> Url: ...

    def set_encoded_query(self, arg: str, /) -> Url: ...

    def remove_query(self) -> Url: ...

    def remove_fragment(self) -> Url: ...

    def set_fragment(self, arg: str, /) -> Url: ...

    def set_encoded_fragment(self, arg: str, /) -> Url: ...

    def remove_origin(self) -> Url: ...

    def normalize(self) -> Url: ...

    def normalize_scheme(self) -> Url: ...

    def normalize_authority(self) -> Url: ...

    def normalize_path(self) -> Url: ...

    def normalize_query(self) -> Url: ...

    def normalize_fragment(self) -> Url: ...

    def __eq__(self, arg: object, /) -> bool:
        pass

    def __ne__(self, arg: object, /) -> bool:
        pass

    def __hash__(self) -> int: ...

    __cpp_name__: str = 'boost::urls::url'

class Usage(Feature):
    """
    Implementation of ``Usage`` defined in the SysML specification.

    **Specification**:

       A ``Usage`` is a usage of a ``Definition``.

       A ``Usage`` may have ``nested_usages`` that model ``features`` that
       apply in the context of the ``owning_usage``. A ``Usage`` may also
       have ``Definitions`` nested in it, but this has no semantic
       significance, other than the nested scoping resulting from the
       ``Usage`` being considered as a ``Namespace`` for any nested
       ``Definitions``.

       However, if a ``Usage`` has ``is_variation = true``, then it
       represents a *variation point* ``Usage``. In this case, all of its
       ``members`` must be ``variant`` ``Usages``, related to the ``Usage``
       by ``VariantMembership`` ``Relationships``. Rather than being
       ``features`` of the ``Usage``, ``variant`` ``Usages`` model different
       concrete alternatives that can be chosen to fill in for the variation
       point ``Usage``.

    For language description, see section
    `7.6 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=61>`__
    of the SysML specification. For more details on the model, see section
    `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::Usage'

    STD: tuple[type[Usage], ...] = (Usage,)

    if TYPE_CHECKING:
        Std = Usage

    @property
    def is_reference(self) -> bool:
        """
        Implementation of ``is_reference`` defined in the SysML specification.

        **Specification**:

           Whether this ``Usage`` is a referential ``Usage``, that is, it has
           ``is_composite = false``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @is_reference.setter
    def is_reference(self, arg: bool, /) -> None: ...

    @property
    def is_reference_explicitly(self) -> bool:
        """
        Returns ``True`` if this ``Usage`` was explicitly declared as ``ref`` in the textual syntax.
        """

    @property
    def is_variation(self) -> bool:
        """
        Implementation of ``is_variation`` defined in the SysML specification.

        **Specification**:

           Whether this ``Usage`` is for a variation point or not. If true, then
           all the ``memberships`` of the ``Usage`` must be
           ``VariantMemberships``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @is_variation.setter
    def is_variation(self, arg: bool, /) -> None: ...

    @property
    def may_time_vary(self) -> bool:
        """
        Implementation of ``may_time_vary`` defined in the SysML specification.

        **Specification**:

           Whether this ``Usage`` may be time varying (that is, whether it is
           featured by the snapshots of its ``owning_type``, rather than being
           featured by the ``owning_type`` itself). However, if ``is_constant``
           is also true, then the value of the ``Usage`` is nevertheless
           constant over the entire duration of an instance of its
           ``owning_type`` (that is, it has the same value on all snapshots).

           The property ``may_time_vary`` redefines the KerML property
           ``Feature::is_variable``, making it derived. The property
           ``is_constant`` is inherited from ``Feature``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def variants(self) -> LazyIterator[Usage]:
        """
        Implementation of ``variant`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` which represent the variants of this ``Usage`` as a
           variation point ``Usage``, if ``is_variation = true``. If
           ``is_variation = false``, then there must be no ``variants``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=306>`__
        of the SysML specification for more details.
        """

    @property
    def variant_memberships(self) -> LazyIterator[VariantMembership]:
        r"""
        Implementation of ``variant_membership`` defined in the SysML
        specification.

        **Specification**:

           The ``owned_memberships`` of this ``Usage`` that are
           ``VariantMemberships``. If ``is_variation = true``, then this must be
           all ``memberships`` of the ``Usage``. If ``is_variation = false``,
           then ``variant_membership``\ must be empty.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=306>`__
        of the SysML specification for more details.
        """

    @property
    def owning_definition(self) -> Definition | None:
        """
        Implementation of ``owning_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``Definition`` that owns this ``Usage`` (if any).

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def owning_usage(self) -> Usage | None:
        """
        Implementation of ``owning_usage`` defined in the SysML specification.

        **Specification**:

           The ``Usage`` in which this ``Usage`` is nested (if any).

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=306>`__
        of the SysML specification for more details.
        """

    @property
    def nested_usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``nested_usage`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that are ``owned_features`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def definitions(self) -> LazyIterator[Classifier]:
        """
        Implementation of ``definition`` defined in the SysML specification.

        **Specification**:

           The ``Classifiers`` that are the types of this ``Usage``. Nominally,
           these are ``Definitions``, but other kinds of Kernel ``Classifiers``
           are also allowed, to permit use of ``Classifiers`` from the Kernel
           Model Libraries.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``usage`` defined in the SysML specification.

        **Specification**:

           The ``Usages`` that are ``features`` of this ``Usage`` (not
           necessarily owned).

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=306>`__
        of the SysML specification for more details.
        """

    @property
    def directed_usages(self) -> LazyIterator[Usage]:
        """
        Implementation of ``directed_usage`` defined in the SysML specification.

        **Specification**:

           The ``usages`` of this ``Usage`` that are ``directed_features``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_references(self) -> LazyIterator[ReferenceUsage]:
        """
        Implementation of ``nested_reference`` defined in the SysML
        specification.

        **Specification**:

           The ``ReferenceUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_attributes(self) -> LazyIterator[AttributeUsage]:
        """
        Implementation of ``nested_attribute`` defined in the SysML
        specification.

        **Specification**:

           The code>AttributeUsages that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_enumerations(self) -> LazyIterator[EnumerationUsage]:
        """
        Implementation of ``nested_enumeration`` defined in the SysML
        specification.

        **Specification**:

           The code>EnumerationUsages that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_occurrences(self) -> LazyIterator[OccurrenceUsage]:
        """
        Implementation of ``nested_occurrence`` defined in the SysML
        specification.

        **Specification**:

           The ``OccurrenceUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_items(self) -> LazyIterator[ItemUsage]:
        """
        Implementation of ``nested_item`` defined in the SysML specification.

        **Specification**:

           The ``ItemUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_parts(self) -> LazyIterator[PartUsage | ConnectionUsage]:
        """
        Implementation of ``nested_part`` defined in the SysML specification.

        **Specification**:

           The ``PartUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_ports(self) -> LazyIterator[PortUsage]:
        """
        Implementation of ``nested_port`` defined in the SysML specification.

        **Specification**:

           The ``PortUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_connections(self) -> LazyIterator[ConnectorAsUsage]:
        """
        Implementation of ``nested_connection`` defined in the SysML
        specification.

        **Specification**:

           The ``ConnectorAsUsages`` that are ``nested_usages`` of this
           ``Usage``. Note that this list includes ``BindingConnectorAsUsages``,
           ``SuccessionAsUsages``, and ``FlowUsages`` because these are
           ``ConnectorAsUsages`` even though they are not ``ConnectionUsages``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_flows(self) -> LazyIterator[FlowUsage]:
        """
        Implementation of ``nested_flow`` defined in the SysML specification.

        **Specification**:

           The code>FlowUsages that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_interfaces(self) -> LazyIterator[InterfaceUsage]:
        """
        Implementation of ``nested_interface`` defined in the SysML
        specification.

        **Specification**:

           The ``InterfaceUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_allocations(self) -> LazyIterator[AllocationUsage]:
        """
        Implementation of ``nested_allocation`` defined in the SysML
        specification.

        **Specification**:

           The ``AllocationUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_actions(self) -> LazyIterator[ActionUsage | FlowUsage]:
        """
        Implementation of ``nested_action`` defined in the SysML specification.

        **Specification**:

           The ``ActionUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=303>`__
        of the SysML specification for more details.
        """

    @property
    def nested_states(self) -> LazyIterator[StateUsage]:
        """
        Implementation of ``nested_state`` defined in the SysML specification.

        **Specification**:

           The ``StateUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_transitions(self) -> LazyIterator[TransitionUsage]:
        """
        Implementation of ``nested_transition`` defined in the SysML
        specification.

        **Specification**:

           The ``TransitionUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_calculations(self) -> LazyIterator[CalculationUsage]:
        """
        Implementation of ``nested_calculation`` defined in the SysML
        specification.

        **Specification**:

           The ``CalculationUsage`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_constraints(self) -> LazyIterator[ConstraintUsage]:
        """
        Implementation of ``nested_constraint`` defined in the SysML
        specification.

        **Specification**:

           The ``ConstraintUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_requirements(self) -> LazyIterator[RequirementUsage]:
        """
        Implementation of ``nested_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_concerns(self) -> LazyIterator[ConcernUsage]:
        """
        Implementation of ``nested_concern`` defined in the SysML specification.

        **Specification**:

           The ``ConcernUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_cases(self) -> LazyIterator[CaseUsage]:
        """
        Implementation of ``nested_case`` defined in the SysML specification.

        **Specification**:

           The ``CaseUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_analysis_cases(self) -> LazyIterator[AnalysisCaseUsage]:
        """
        Implementation of ``nested_analysis_case`` defined in the SysML
        specification.

        **Specification**:

           The ``AnalysisCaseUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

    @property
    def nested_verification_cases(self) -> LazyIterator[VerificationCaseUsage]:
        """
        Implementation of ``nested_verification_case`` defined in the SysML
        specification.

        **Specification**:

           The ``VerificationCaseUsages`` that are ``nested_usages`` of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_use_cases(self) -> LazyIterator[UseCaseUsage]:
        """
        Implementation of ``nested_use_case`` defined in the SysML
        specification.

        **Specification**:

           The ``UseCaseUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_views(self) -> LazyIterator[ViewUsage]:
        """
        Implementation of ``nested_view`` defined in the SysML specification.

        **Specification**:

           The ``ViewUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_viewpoints(self) -> LazyIterator[ViewpointUsage]:
        """
        Implementation of ``nested_viewpoint`` defined in the SysML
        specification.

        **Specification**:

           The ``ViewpointUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_renderings(self) -> LazyIterator[RenderingUsage]:
        """
        Implementation of ``nested_rendering`` defined in the SysML
        specification.

        **Specification**:

           The ``RenderingUsages`` that are ``nested_usages`` of this ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=305>`__
        of the SysML specification for more details.
        """

    @property
    def nested_metadata(self) -> LazyIterator[MetadataUsage]:
        """
        Implementation of ``nested_metadata`` defined in the SysML
        specification.

        **Specification**:

           The ``MetadataUsages`` that are ``nested_usages`` of this of this
           ``Usage``.

        See section
        `8.3.6.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=304>`__
        of the SysML specification for more details.
        """

class UseCaseDefinition(CaseDefinition):
    """
    Implementation of ``UseCaseDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``UseCaseDefinition`` is a ``CaseDefinition`` that specifies a set
       of actions performed by its subject, in interaction with one or more
       actors external to the subject. The objective is to yield an
       observable result that is of value to one or more of the actors.

    For language description, see section
    `7.25.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=179>`__
    of the SysML specification. For more details on the model, see section
    `8.3.25.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=413>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::UseCaseDefinition'

    STD: tuple[type[UseCaseDefinition], ...] = (UseCaseDefinition,)

    if TYPE_CHECKING:
        Std = UseCaseDefinition

    @property
    def included_use_cases(self) -> LazyIterator[UseCaseUsage]:
        """
        Implementation of ``included_use_case`` defined in the SysML
        specification.

        **Specification**:

           The ``UseCaseUsages`` that are included by this
           ``UseCaseDefinition``, which are the ``use_case_includeds`` of the
           ``IncludeUseCaseUsages`` owned by this ``UseCaseDefinition``.

        See section
        `8.3.25.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=413>`__
        of the SysML specification for more details.
        """

class UseCaseUsage(CaseUsage):
    """
    Implementation of ``UseCaseUsage`` defined in the SysML specification.

    **Specification**:

       A ``UseCaseUsage`` is a ``Usage`` of a ``UseCaseDefinition``.

    For language description, see section
    `7.25.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=179>`__
    of the SysML specification. For more details on the model, see section
    `8.3.25.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=414>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::UseCaseUsage'

    STD: tuple[type[UseCaseUsage], ...] = (UseCaseUsage,)

    if TYPE_CHECKING:
        Std = UseCaseUsage

    @property
    def use_case_definition(self) -> UseCaseDefinition | None:
        """
        Implementation of ``use_case_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``UseCaseDefinition`` that is the ``definition`` of this
           ``UseCaseUsage``.

        See section
        `8.3.25.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=414>`__
        of the SysML specification for more details.
        """

    @property
    def included_use_cases(self) -> LazyIterator[UseCaseUsage]:
        """
        Implementation of ``included_use_case`` defined in the SysML
        specification.

        **Specification**:

           The ``UseCaseUsages`` that are included by this ``UseCaseUse``, which
           are the ``use_case_includeds`` of the ``IncludeUseCaseUsages`` owned
           by this ``UseCaseUsage``.

        See section
        `8.3.25.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=414>`__
        of the SysML specification for more details.
        """

class ValidationTiming(enum.Enum):
    OnType = 0

    OnSave = 1

    Manual = 2

    Never = 3

class VariantMembership(OwningMembership):
    """
    Implementation of ``VariantMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``VariantMembership`` is a ``Membership`` between a variation point
       ``Definition`` or ``Usage`` and a ``Usage`` that represents a variant
       in the context of that variation. The ``membership_owning_namespace``
       for the ``VariantMembership`` must be either a Definition or a
       ``Usage`` with ``is_variation = true``.

    For language description, see section
    `7.6.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=73>`__
    of the SysML specification. For more details on the model, see section
    `8.3.6.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=311>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::VariantMembership'

    STD: tuple[type[VariantMembership], ...] = (VariantMembership,)

    if TYPE_CHECKING:
        Std = VariantMembership

    @property
    def owned_variant_usage(self) -> Usage | None:
        """
        Implementation of ``owned_variant_usage`` defined in the SysML
        specification.

        **Specification**:

           The ``Usage`` that represents a variant in the context of the
           ``owning_variation_definition`` or ``owning_variation_usage``.

        See section
        `8.3.6.5 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=311>`__
        of the SysML specification for more details.
        """

class VerificationCaseDefinition(CaseDefinition):
    """
    Implementation of ``VerificationCaseDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``VerificationCaseDefinition`` is a ``CaseDefinition`` for the
       purpose of verification of the subject of the case against its
       requirements.

    For language description, see section
    `7.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=176>`__
    of the SysML specification. For more details on the model, see section
    `8.3.24.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=409>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::VerificationCaseDefinition'

    STD: tuple[type[VerificationCaseDefinition], ...] = (VerificationCaseDefinition,)

    if TYPE_CHECKING:
        Std = VerificationCaseDefinition

    @property
    def verified_requirements(self) -> LazyIterator[RequirementUsage]:
        """
        Implementation of ``verified_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsages`` verified by this
           ``VerificationCaseDefinition``, which are the
           ``verified_requirements`` of all
           ``RequirementVerificationMemberships`` of the
           ``objective_requirement``.

        See section
        `8.3.24.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=410>`__
        of the SysML specification for more details.
        """

class VerificationCaseUsage(CaseUsage):
    """
    Implementation of ``VerificationCaseUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``VerificationCaseUsage`` is a Usage of a
       ``VerificationCaseDefinition``.

    For language description, see section
    `7.24.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=176>`__
    of the SysML specification. For more details on the model, see section
    `8.3.24.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=410>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::VerificationCaseUsage'

    STD: tuple[type[VerificationCaseUsage], ...] = (VerificationCaseUsage,)

    if TYPE_CHECKING:
        Std = VerificationCaseUsage

    @property
    def verification_case_definition(self) -> VerificationCaseDefinition | None:
        """
        Implementation of ``verification_case_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``VerificationCase`` that is the ``definition`` of this
           ``VerificationCaseUsage``.

        See section
        `8.3.24.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=410>`__
        of the SysML specification for more details.
        """

    @property
    def verified_requirements(self) -> LazyIterator[RequirementUsage]:
        """
        Implementation of ``verified_requirement`` defined in the SysML
        specification.

        **Specification**:

           The ``RequirementUsages`` verified by this ``VerificationCaseUsage``,
           which are the ``verified_requirements`` of all
           ``RequirementVerificationMemberships`` of the
           ``objective_requirement``.

        See section
        `8.3.24.4 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=410>`__
        of the SysML specification for more details.
        """

class ViewDefinition(PartDefinition):
    """
    Implementation of ``ViewDefinition`` defined in the SysML specification.

    **Specification**:

       A ``ViewDefinition`` is a ``PartDefinition`` that specifies how a
       view artifact is constructed to satisfy a ``viewpoint``. It specifies
       a ``view_conditions`` to define the model content to be presented and
       a ``view_rendering`` to define how the model content is presented.

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=421>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ViewDefinition'

    STD: tuple[type[ViewDefinition], ...] = (ViewDefinition,)

    if TYPE_CHECKING:
        Std = ViewDefinition

    @property
    def views(self) -> LazyIterator[ViewUsage]:
        """
        Implementation of ``view`` defined in the SysML specification.

        **Specification**:

           The ``usages`` of this ``ViewDefinition`` that are ``ViewUsages``.

        See section
        `8.3.26.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=421>`__
        of the SysML specification for more details.
        """

    @property
    def satisfied_viewpoints(self) -> LazyIterator[ViewpointUsage]:
        """
        Implementation of ``satisfied_viewpoint`` defined in the SysML
        specification.

        **Specification**:

           The composite ``owned_requirements`` of this ``ViewDefinition`` that
           are ``ViewpointUsages`` for viewpoints satisfied by the
           ``ViewDefinition``.

        See section
        `8.3.26.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=421>`__
        of the SysML specification for more details.
        """

    @property
    def view_rendering(self) -> RenderingUsage | None:
        """
        Implementation of ``view_rendering`` defined in the SysML specification.

        **Specification**:

           The ``RenderingUsage`` to be used to render views defined by this
           ``ViewDefinition``, which is the ``referenced_rendering`` of the
           ``ViewRenderingMembership`` of the ``ViewDefinition``.

        See section
        `8.3.26.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=421>`__
        of the SysML specification for more details.
        """

    @property
    def owned_view_conditions(self) -> LazyIterator[ElementFilterMembership]:
        """The ``view_conditions`` owned by this ``ViewDefinition``."""

    @property
    def view_conditions(self) -> LazyIterator[ElementFilterMembership]:
        """
        Implementation of ``view_condition`` defined in the SysML specification.

        **Specification**:

           The ``Expressions`` related to this ``ViewDefinition`` by
           ``ElementFilterMemberships``, which specify conditions on
           ``Elements`` to be rendered in a view.

        See section
        `8.3.26.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=421>`__
        of the SysML specification for more details.
        """

class ViewRenderingMembership(FeatureMembership):
    """
    Implementation of ``ViewRenderingMembership`` defined in the SysML
    specification.

    **Specification**:

       A ``ViewRenderingMembership`` is a FeatureMembership that identifies
       the ``view_rendering`` of a ``ViewDefinition`` or ``ViewUsage``.

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=424>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ViewRenderingMembership'

    STD: tuple[type[ViewRenderingMembership], ...] = (ViewRenderingMembership,)

    if TYPE_CHECKING:
        Std = ViewRenderingMembership

    @property
    def owned_rendering(self) -> RenderingUsage | None:
        """
        Implementation of ``owned_rendering`` defined in the SysML
        specification.

        **Specification**:

           The owned ``RenderingUsage`` that is either itself the
           ``referenced_rendering`` or subsets the ``referenced_rendering``.

        See section
        `8.3.26.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=424>`__
        of the SysML specification for more details.
        """

    @property
    def referenced_rendering(self) -> RenderingUsage | None:
        """
        Implementation of ``referenced_rendering`` defined in the SysML
        specification.

        **Specification**:

           The ``RenderingUsage`` that is referenced through this
           ``ViewRenderingMembership``. It is the ``referenced_feature`` of the
           ``owned_reference_subsetting`` for the ``owned_rendering``, if there
           is one, and, otherwise, the ``owned_rendering`` itself.

        See section
        `8.3.26.10 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=424>`__
        of the SysML specification for more details.
        """

class ViewUsage(PartUsage):
    """
    Implementation of ``ViewUsage`` defined in the SysML specification.

    **Specification**:

       A ``ViewUsage`` is a usage of a ``ViewDefinition`` to specify the
       generation of a view of the ``members`` of a collection of
       ``exposed_namespaces``. The ``ViewUsage`` can satisfy more
       ``viewpoints`` than its definition, and it can specialize the
       ``view_rendering`` specified by its definition.

    For language description, see section
    `7.26.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=184>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=425>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ViewUsage'

    STD: tuple[type[ViewUsage], ...] = (ViewUsage,)

    if TYPE_CHECKING:
        Std = ViewUsage

    @property
    def view_definition(self) -> ViewDefinition | None:
        """
        Implementation of ``view_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``ViewDefinition`` that is the ``definition`` of this
           ``ViewUsage``.

        See section
        `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=425>`__
        of the SysML specification for more details.
        """

    @property
    def satisfied_viewpoints(self) -> LazyIterator[ViewpointUsage]:
        """
        Implementation of ``satisfied_viewpoint`` defined in the SysML
        specification.

        **Specification**:

           The ``nested_requirements`` of this ``ViewUsage`` that are
           ``ViewpointUsages`` for (additional) viewpoints satisfied by the
           ``ViewUsage``.

        See section
        `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=425>`__
        of the SysML specification for more details.
        """

    @property
    def exposed_elements(self) -> LazyIterator[Element]:
        """
        Implementation of ``exposed_element`` defined in the SysML
        specification.

        **Specification**:

           The ``Elements`` that are exposed by this ``ViewUsage``, which are
           those ``member_elements`` of the imported ``Memberships`` from all
           the ``Expose`` ``Relationships`` that meet all the owned and
           inherited ``view_conditions``.

        See section
        `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=425>`__
        of the SysML specification for more details.
        """

    @property
    def owned_view_conditions(self) -> LazyIterator[ElementFilterMembership]:
        """The ``view_conditions`` owned by this ``ViewUsage``."""

    @property
    def view_conditions(self) -> LazyIterator[ElementFilterMembership]:
        """
        Implementation of ``view_condition`` defined in the SysML specification.

        **Specification**:

           The ``Expressions`` related to this ``ViewUsage`` by
           ``ElementFilterMemberships``, which specify conditions on
           ``Elements`` to be rendered in a view.

        See section
        `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=425>`__
        of the SysML specification for more details.
        """

    @property
    def view_rendering(self) -> RenderingUsage | None:
        """
        Implementation of ``view_rendering`` defined in the SysML specification.

        **Specification**:

           The ``RenderingUsage`` to be used to render views defined by this
           ``ViewUsage``, which is the ``referenced_rendering`` of the
           ``ViewRenderingMembership`` of the ``ViewUsage``.

        See section
        `8.3.26.11 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=425>`__
        of the SysML specification for more details.
        """

class ViewpointDefinition(RequirementDefinition):
    """
    Implementation of ``ViewpointDefinition`` defined in the SysML
    specification.

    **Specification**:

       A ``ViewpointDefinition`` is a ``RequirementDefinition`` that
       specifies one or more stakeholder concerns that are to be satisfied
       by creating a view of a model.

    For language description, see section
    `7.26.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=185>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=422>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ViewpointDefinition'

    STD: tuple[type[ViewpointDefinition], ...] = (ViewpointDefinition,)

    if TYPE_CHECKING:
        Std = ViewpointDefinition

    @property
    def viewpoint_stakeholders(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``viewpoint_stakeholder`` defined in the SysML
        specification.

        **Specification**:

           The ``PartUsages`` that identify the stakeholders with concerns
           framed by this ``ViewpointDefinition``, which are the owned and
           inherited ``stakeholder_parameters`` of the ``framed_concerns`` of
           this ``ViewpointDefinition``.

        See section
        `8.3.26.8 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=422>`__
        of the SysML specification for more details.
        """

class ViewpointUsage(RequirementUsage):
    """
    Implementation of ``ViewpointUsage`` defined in the SysML specification.

    **Specification**:

       A ``ViewpointUsage`` is a ``Usage`` of a ``ViewpointDefinition``.

    For language description, see section
    `7.26.3 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=185>`__
    of the SysML specification. For more details on the model, see section
    `8.3.26.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=423>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::ViewpointUsage'

    STD: tuple[type[ViewpointUsage], ...] = (ViewpointUsage,)

    if TYPE_CHECKING:
        Std = ViewpointUsage

    @property
    def viewpoint_definition(self) -> ViewpointDefinition | None:
        """
        Implementation of ``viewpoint_definition`` defined in the SysML
        specification.

        **Specification**:

           The ``ViewpointDefinition`` that is the ``definition`` of this
           ``ViewpointUsage``.

        See section
        `8.3.26.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=423>`__
        of the SysML specification for more details.
        """

    @property
    def viewpoint_stakeholders(self) -> LazyIterator[PartUsage]:
        """
        Implementation of ``viewpoint_stakeholder`` defined in the SysML
        specification.

        **Specification**:

           The ``PartUsages`` that identify the stakeholders with concerns
           framed by this ``ViewpointUsage``, which are the owned and inherited
           ``stakeholder_parameters`` of the ``framed_concerns`` of this
           ``ViewpointUsage``.

        See section
        `8.3.26.9 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=423>`__
        of the SysML specification for more details.
        """

class VisibilityKind(enum.Enum):
    """
    Implementation of ``VisibilityKind`` defined in the KerML specification.

    **Specification**:

       ``VisibilityKind`` is an enumeration whose literals specify the
       visibility of a ``Membership`` of an ``Element`` in a ``Namespace``
       outside of that ``Namespace``. Note that “visibility” specifically
       restricts whether an ``Element`` in a ``Namespace`` may be referenced
       by name from outside the ``Namespace`` and only otherwise restricts
       access to an ``Element`` as provided by specific constraints in the
       abstract syntax (e.g., preventing the import or inheritance of
       private ``Elements``).

    For language description, see section
    `7.2.5.2 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=47>`__
    of the KerML specification. For more details on the model, see section
    `8.3.2.4.7 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/1-Kernel_Modeling_Language.pdf#page=161>`__
    of the KerML specification.
    """

    Private = 0

    Protected = 1

    Public = 2

class VisitAction(enum.Enum):
    Continue = 0

    Stop = 1

class WhileLoopActionUsage(LoopActionUsage):
    """
    Implementation of ``WhileLoopActionUsage`` defined in the SysML
    specification.

    **Specification**:

       A ``WhileLoopActionUsage`` is a ``LoopActionUsage`` that specifies
       that the ``body_action`` ``ActionUsage`` should be performed
       repeatedly while the result of the ``while_argument`` ``Expression``
       is true or until the result of the ``until_argument`` ``Expression``
       (if provided) is true. The ``while_argument`` ``Expression`` is
       evaluated before each (possible) performance of the ``body_action``,
       and the ``until_argument`` ``Expression`` is evaluated after each
       performance of the ``body_action``.

    For language description, see section
    `7.17.12 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=143>`__
    of the SysML specification. For more details on the model, see section
    `8.3.17.19 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=363>`__
    of the SysML specification.
    """

    __cpp_name__: str = 'syside::sysml::WhileLoopActionUsage'

    STD: tuple[type[WhileLoopActionUsage], ...] = (WhileLoopActionUsage,)

    if TYPE_CHECKING:
        Std = WhileLoopActionUsage

    @property
    def while_argument(self) -> Expression | None:
        """
        Implementation of ``while_argument`` defined in the SysML specification.

        **Specification**:

           The ``Expression`` whose result, if true, determines that the
           ``body_action`` should continue to be performed. It is the first
           owned ``parameter`` of the ``WhileLoopActionUsage``.

        See section
        `8.3.17.19 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=363>`__
        of the SysML specification for more details.
        """

    @property
    def while_argument_member(self) -> ExpressionParameterAccessor:
        """Syside specific accessor for manipulating ``while_argument``."""

    @property
    def until_argument(self) -> Expression | None:
        """
        Implementation of ``until_argument`` defined in the SysML specification.

        **Specification**:

           The ``Expression`` whose result, if false, determines that the
           ``body_action`` should continue to be performed. It is the (optional)
           third owned ``parameter`` of the ``WhileLoopActionUsage``.

        See section
        `8.3.17.19 <https://raw.githubusercontent.com/Systems-Modeling/SysML-v2-Release/refs/tags/2025-07/doc/2a-OMG_Systems_Modeling_Language.pdf#page=363>`__
        of the SysML specification for more details.
        """

    @property
    def until_argument_member(self) -> ExpressionParameterAccessor:
        """Syside specific accessor for manipulating ``until_argument``."""

class WriteLocked(Generic[U]):
    def __enter__(self) -> U: ...

    def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, traceback: types.TracebackType | None) -> None: ...

class Writer(Generic[T]):
    """Abstract base class for serialization writer implementations."""

def build_model(document: Document, language: ModelLanguage | None = None) -> list[Diagnostic]:
    """
    Build the AST for ``document`` from its ``text_document``. Any existing model will be cleared, and the built
    model will not have its references linked. Instead, most references will use placeholder references that
    will be replaced by actual targets in linking stage. Only ``sysml`` and ``kerml`` languages are supported.

    This is a CST -> AST stage in the pipeline.

    Raises ``ValueError`` if the ``document`` has unsupported language, or it has no associated ``text_document``.
    """

def collect_exports(document: Document) -> int:
    """
    Collect and cache symbols exported by ``document``. This must be called before the ``document`` is indexed, otherwise wrong or no symbols may be indexed. Returns the number of symbols cached.
    """

def decode_path(arg0: Url, options: EncodingOpts = ...) -> str:
    """
    Decode a filesystem path from a ``Url``. This correctly handles Windows and Posix paths using ``file://`` scheme and returns other ``Urls`` as is.
    """

def deserialize(document: Document, reader: Reader, attributes: AttributeMap) -> tuple[DeserializedModel, SerdeReport[DocumentSegment | str | Element]]:
    """
    Convenience function for deserialization. Prefer using ``Deserializer`` to avoid 
    allocations when doing repeated deserializations.
    """

def format_diagnostics(errors: Sequence[Diagnostic], context: DiagnosticContext = ..., options: DiagnosticFormatOptions = ...) -> str: ...

@overload
def make_file_url(arg0: str, options: EncodingOpts = ...) -> Url:
    """
    Construct a ``Url`` for a filesystem path with the ``file:`` scheme. This correctly handles Windows and Posix paths,
    normalizes Windows drive letters to uppercase, and percent escapes Unicode characters.
    """

@overload
def make_file_url(arg0: str | os.PathLike[AnyStr], options: EncodingOpts = ...) -> Url: ...

def make_pipeline(arg: PipelineOptions, /) -> Pipeline: ...

def pprint(arg0: Element, printer: ModelPrinter | None = None, config: PrinterConfig = ...) -> str:
    """
    Prints model subtree starting at ``root`` to textual syntax.

    **NOTE**
    This performs very little checking that the given model can be represented in textual syntax, besides checking for
    elements that are missing. This has no effect when used as a formatter on a model parsed without syntax errors but
    programmatic models are not guaranteed to be valid textual syntax. In addition, it does not check that references
    are reachable from their scopes so parsing the printed model can fail to find them again. Otherwise, clearly
    unreachable references, such as when one of their ancestors is anonymous, will raise errors.

    Only the first import from any parent namespaces that would shorten the printed reference is used. This does not
    apply to imports themselves to prevent reference resolution errors due to multiple or cyclical imports. Additionally,
    references relative to left-hand side expression result types, such as those from ``FeatureChainExpressions``, are
    assumed to be directly or indirectly accessible so only their short or regular name is printed.
    """

@overload
def sema_reset(element: Element) -> None:
    """
    Reset semantic state of ``element``. This will typically remove any implied relationships, and
    reverse a few other changes made by sema. After this completes, ``element.sema_state == SemaState.None``.
    """

@overload
def sema_reset(document: Document, reporter: Callable[[Element, UnexpectedDifferentReference], None] | None = None) -> None:
    """
    Reset semantic state of ``document``. This will call ``sema_reset`` on all owned elements, and additionally
    reset all resolved references back to unresolved state. While resetting references, if the resolved
    reference does not match the current reference, ``reporter`` will be called with the element the reference
    applies to and ``UnexpectedDifferentReference`` that was found. By default, ``reporter`` will print such errors
    to ``stderr``.

    After this completes, ``document.build_state == BuildState.Indexed``.
    """

@overload
def serialize(root: Element, writer: Writer[T], options: SerializationOptions = ...) -> SerdeReport[Element]:
    """
    Convenience function for serialization. Prefer using ``Serializer`` to avoid 
    allocations when doing repeated serializations.
    """

@overload
def serialize(root: Element, writer: Writer[T], use_standard_names: bool = True, include_derived: bool = False, include_redefined: bool = False, include_default: bool = False, include_optional: bool = False, include_implied: bool = False, fail_action: FailAction = FailAction.Diagnose) -> SerdeReport[Element]: ...

@overload
def sexp(root: Element, options: SexpOptions = ...) -> str:
    """
    Generate a minimal S-expression of owned elements rooted at ``root``, useful for debugging.
    """

@overload
def sexp(root: Element, indent: int = 2, include_implicit: bool = True, print_references: bool = False) -> str: ...

