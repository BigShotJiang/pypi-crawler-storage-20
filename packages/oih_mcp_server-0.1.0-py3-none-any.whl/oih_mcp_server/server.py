#!/usr/bin/env python3
"""
OIH MCP Server - Provides OIH analysis tools via Model Context Protocol
"""

import asyncio
import json
from datetime import datetime, timedelta
from typing import Any, Sequence
import pandas as pd
import psycopg2
from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    Resource,
    Tool,
    TextContent,
    ImageContent,
    EmbeddedResource,
    LoggingLevel
)

# Import your existing OIH functions
import sys
import os
sys.path.append(os.path.dirname(__file__))
from oih_core import (
    get_user_inputs,
    run_oih_query,
    generate_html_report,
    create_8week_trend_chart,
    get_connection
)

server = Server("oih-analyzer")

@server.list_tools()
async def handle_list_tools() -> list[Tool]:
    """List available OIH analysis tools."""
    return [
        Tool(
            name="run_oih_analysis",
            description="Run complete OIH analysis for a given week",
            inputSchema={
                "type": "object",
                "properties": {
                    "week_number": {
                        "type": "integer",
                        "description": "Week number to analyze (e.g., 1, 2, 3)"
                    },
                    "start_date": {
                        "type": "string",
                        "description": "Sunday start date in YYYY-MM-DD format"
                    },
                    "output_dir": {
                        "type": "string", 
                        "description": "Output directory for results",
                        "default": "/tmp/oih_results"
                    }
                },
                "required": ["week_number", "start_date"]
            }
        ),
        Tool(
            name="modify_html_report",
            description="Modify HTML report to add MoM change and remove recommended action cost",
            inputSchema={
                "type": "object",
                "properties": {
                    "html_file_path": {
                        "type": "string",
                        "description": "Path to the HTML file to modify"
                    },
                    "csv_file_path": {
                        "type": "string", 
                        "description": "Path to the CSV file with data"
                    }
                },
                "required": ["html_file_path", "csv_file_path"]
            }
        ),
        Tool(
            name="calculate_mom_change",
            description="Calculate Month-over-Month change from OIH data",
            inputSchema={
                "type": "object",
                "properties": {
                    "csv_file_path": {
                        "type": "string",
                        "description": "Path to the CSV file with OIH data"
                    }
                },
                "required": ["csv_file_path"]
            }
        )
    ]

@server.call_tool()
async def handle_call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""
    
    if name == "run_oih_analysis":
        return await run_oih_analysis_tool(arguments)
    elif name == "modify_html_report":
        return await modify_html_report_tool(arguments)
    elif name == "calculate_mom_change":
        return await calculate_mom_change_tool(arguments)
    else:
        raise ValueError(f"Unknown tool: {name}")

async def run_oih_analysis_tool(args: dict[str, Any]) -> list[TextContent]:
    """Run complete OIH analysis."""
    try:
        week_number = args["week_number"]
        start_date = args["start_date"]
        output_dir = args.get("output_dir", "/tmp/oih_results")
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        # Calculate dates
        current_date = datetime.strptime(start_date, '%Y-%m-%d')
        last_month_date = current_date - timedelta(weeks=4)
        yoy_date = current_date.replace(year=current_date.year - 1)
        
        last_month_start_date = last_month_date.strftime('%Y-%m-%d')
        yoy_start_date = yoy_date.strftime('%Y-%m-%d')
        
        # Run the analysis
        results = run_oih_query(start_date, last_month_start_date, yoy_start_date, week_number)
        
        if results is not None:
            # Generate file paths
            start_date_str = start_date.replace('-', '')
            csv_filename = f"OIH_Week{week_number}_F2_GLs_{start_date_str}.csv"
            html_filename = f"OIH_Week{week_number}_F2_GLs_{start_date_str}.html"
            
            csv_path = os.path.join(output_dir, csv_filename)
            html_path = os.path.join(output_dir, html_filename)
            
            # Save results
            results.to_csv(csv_path, index=False)
            
            # Generate HTML report (you'll need to adapt this)
            generate_html_report(results, None, html_path, start_date, week_number)
            
            # Calculate summary stats
            current_week_data = results[results['time_period'] == 'Current_Week']
            current_unhealthy_pct = current_week_data['below_cost_oih_cost'].sum() / current_week_data['oih_managed_cost'].sum() * 100
            
            return [TextContent(
                type="text",
                text=f"""✅ OIH Analysis Complete!

Week {week_number} Analysis for {start_date}:
- Current Week Unhealthy %: {current_unhealthy_pct:.2f}%
- Total Records: {len(results):,}
- Files Generated:
  - CSV: {csv_path}
  - HTML: {html_path}

Analysis includes Current Week, Previous Week, Last Month Week, and YoY comparisons."""
            )]
        else:
            return [TextContent(type="text", text="❌ Analysis failed - no results returned")]
            
    except Exception as e:
        return [TextContent(type="text", text=f"❌ Error running OIH analysis: {str(e)}")]

async def modify_html_report_tool(args: dict[str, Any]) -> list[TextContent]:
    """Modify HTML report to add MoM and remove recommended action cost."""
    try:
        html_path = args["html_file_path"]
        csv_path = args["csv_file_path"]
        
        # Calculate MoM change
        df = pd.read_csv(csv_path)
        current = df[df['time_period'] == 'Current_Week']
        last_month = df[df['time_period'] == 'Last_Month_Week']
        
        current_pct = current['below_cost_oih_cost'].sum() / current['oih_managed_cost'].sum() * 100
        last_month_pct = last_month['below_cost_oih_cost'].sum() / last_month['oih_managed_cost'].sum() * 100
        mom_bps = (current_pct - last_month_pct) * 100
        
        # Read and modify HTML
        with open(html_path, 'r') as f:
            html_content = f.read()
        
        # Remove recommended action cost card
        import re
        html_content = re.sub(
            r'<div class="summary-card">\s*<h3>Recommended Action Cost</h3>\s*<div class="value">\$[\d.]+[BMK]</div>\s*</div>',
            '',
            html_content,
            flags=re.DOTALL
        )
        
        # Add MoM change after WoW, before YoY
        mom_card = f'''            <div class="summary-card" style="background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);">
                <h3>MoM Change</h3>
                <div class="value">{mom_bps:+.0f} bps</div>
            </div>'''
        
        # Insert MoM card
        html_content = re.sub(
            r'(<div class="summary-card" style="background: linear-gradient\(135deg, #e74c3c 0%, #c0392b 100%\);">\s*<h3>WoW Change</h3>\s*<div class="value">[^<]+</div>\s*</div>)',
            r'\1' + mom_card,
            html_content,
            flags=re.DOTALL
        )
        
        # Write modified HTML
        with open(html_path, 'w') as f:
            f.write(html_content)
        
        return [TextContent(
            type="text",
            text=f"""✅ HTML Report Modified Successfully!

Changes made:
- Added MoM Change: {mom_bps:+.0f} bps
- Removed Recommended Action Cost card
- MoM positioned after WoW, before YoY

Modified file: {html_path}"""
        )]
        
    except Exception as e:
        return [TextContent(type="text", text=f"❌ Error modifying HTML: {str(e)}")]

async def calculate_mom_change_tool(args: dict[str, Any]) -> list[TextContent]:
    """Calculate MoM change from CSV data."""
    try:
        csv_path = args["csv_file_path"]
        
        df = pd.read_csv(csv_path)
        current = df[df['time_period'] == 'Current_Week']
        last_month = df[df['time_period'] == 'Last_Month_Week']
        
        # Calculate percentages
        current_total = current['oih_managed_cost'].sum()
        current_unhealthy = current['below_cost_oih_cost'].sum()
        current_pct = current_unhealthy / current_total * 100
        
        lm_total = last_month['oih_managed_cost'].sum()
        lm_unhealthy = last_month['below_cost_oih_cost'].sum()
        lm_pct = lm_unhealthy / lm_total * 100
        
        mom_bps = (current_pct - lm_pct) * 100
        
        return [TextContent(
            type="text",
            text=f"""📊 MoM Change Analysis:

Current Week:
- Total Cost: ${current_total/1e9:.1f}B
- Unhealthy Cost: ${current_unhealthy/1e6:.0f}M  
- Unhealthy %: {current_pct:.2f}%

Last Month Week:
- Total Cost: ${lm_total/1e9:.1f}B
- Unhealthy Cost: ${lm_unhealthy/1e6:.0f}M
- Unhealthy %: {lm_pct:.2f}%

MoM Change: {current_pct:.2f}% - {lm_pct:.2f}% = {mom_bps:+.0f} bps"""
        )]
        
    except Exception as e:
        return [TextContent(type="text", text=f"❌ Error calculating MoM change: {str(e)}")]

async def main():
    """Main entry point for the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="oih-analyzer",
                server_version="0.1.0",
                capabilities=server.get_capabilities(
                    notification_options=None,
                    experimental_capabilities=None,
                ),
            ),
        )

if __name__ == "__main__":
    asyncio.run(main())
