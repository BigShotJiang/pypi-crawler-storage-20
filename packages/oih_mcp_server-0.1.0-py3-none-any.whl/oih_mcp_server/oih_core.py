"""
Core OIH analysis functions extracted from the main script
"""

import pandas as pd
import psycopg2
from datetime import datetime, timedelta
import os

def get_connection():
    """Get database connection - you'll need to adapt this for your environment"""
    # This should be configured via environment variables or config
    return psycopg2.connect(
        host=os.getenv('REDSHIFT_HOST'),
        port=os.getenv('REDSHIFT_PORT', 5439),
        database=os.getenv('REDSHIFT_DB'),
        user=os.getenv('REDSHIFT_USER'),
        password=os.getenv('REDSHIFT_PASSWORD')
    )

def run_oih_query(current_start_date, last_month_start_date, yoy_start_date, week_number):
    """
    Run the main OIH query with actual SQL from oih_query.py
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Format dates for SQL
        current_date = current_start_date
        last_month_date = last_month_start_date  
        yoy_date = yoy_start_date
        
        query = f"""
        SELECT
            z.gl_product_group,
            z.brand_name,
            z.company_vendor_name,
            z.parent_asin,
            z.parent_asin_name,
            SUM((oih.oih_action_quantity+oih.un_action_quantity)*oih.COST) AS OIH_MANAGED_COST,
            SUM(oih.oih_action_quantity+oih.un_action_quantity) AS OIH_MANAGED_UNITS,
            SUM(oih.oih_action_quantity*oih.COST) AS OIH_RECOMMENDED_ACTION_COST,
            SUM(oih.oih_action_quantity) AS OIH_RECOMMENDED_ACTION_UNITS,
            SUM(oih.cost*(oih.oih_action_quantity - oih.cp_positive_qty)) as BELOW_COST_OIH_COST,
            SUM(oih.oih_action_quantity - oih.cp_positive_qty) as BELOW_COST_OIH_UNITS,
            SUM(oih.cp_positive_qty*oih.cost) AS ABOVE_COST_OIH_COST,
            SUM(oih.cp_positive_qty) AS ABOVE_COST_OIH_UNITS,
            CASE
                WHEN oih.exclusion_reason_code IS NULL then 'N'
                ELSE 'Y'
            END as Excluded_from_OIH_Action,
            CASE 
                WHEN OIH.RUNDATE >= '{current_date}' AND OIH.RUNDATE < '{current_date}'::date + interval '7 days' THEN 'Current_Week'
                WHEN OIH.RUNDATE >= '{current_date}'::date - interval '7 days' AND OIH.RUNDATE < '{current_date}' THEN 'Previous_Week'
                WHEN OIH.RUNDATE >= '{last_month_date}' AND OIH.RUNDATE < '{last_month_date}'::date + interval '7 days' THEN 'Last_Month_Week'
                WHEN OIH.RUNDATE >= '{yoy_date}' AND OIH.RUNDATE < '{yoy_date}'::date + interval '7 days' THEN 'YoY_Week'
                ELSE 'Other'
            END AS time_period
        FROM andes.OIH_DDL.OIH_RECOMMEND_DETAIL OIH
        LEFT JOIN andes.z_tools_analytics.z_weekly_universal_asin_attributes z
            ON z.asin = OIH.asin
        WHERE OIH.region_id = 1
          AND OIH.realm = 'USAmazon'
          AND z.gl_product_group in ('200','468','198','193','197','241','309')
          AND (
              (OIH.RUNDATE >= '{current_date}' AND OIH.RUNDATE < '{current_date}'::date + interval '7 days')
              OR (OIH.RUNDATE >= '{current_date}'::date - interval '7 days' AND OIH.RUNDATE < '{current_date}')
              OR (OIH.RUNDATE >= '{last_month_date}' AND OIH.RUNDATE < '{last_month_date}'::date + interval '7 days')
              OR (OIH.RUNDATE >= '{yoy_date}' AND OIH.RUNDATE < '{yoy_date}'::date + interval '7 days')
          )
        GROUP BY
             z.gl_product_group,
             z.brand_name,
             z.company_vendor_name,
             z.parent_asin,
             z.parent_asin_name,
             CASE
                 WHEN oih.exclusion_reason_code IS NULL then 'N'
                 ELSE 'Y'
             END,
             time_period
        """
        
        df = pd.read_sql(query, conn)
        cursor.close()
        conn.close()
        
        return df
        
    except Exception as e:
        print(f"Error running OIH query: {e}")
        return None

def generate_html_report(df, trend_data, output_path, current_start_date, week_number):
    """
    Generate HTML report - simplified version
    You'll need to copy the actual HTML generation logic from your script
    """
    
    # Calculate summary stats
    current_week_data = df[df['time_period'] == 'Current_Week']
    prev_week_data = df[df['time_period'] == 'Previous_Week']
    yoy_week_data = df[df['time_period'] == 'YoY_Week']
    
    current_unhealthy_pct = current_week_data['below_cost_oih_cost'].sum() / current_week_data['oih_managed_cost'].sum() * 100
    prev_week_unhealthy_pct = prev_week_data['below_cost_oih_cost'].sum() / prev_week_data['oih_managed_cost'].sum() * 100
    yoy_unhealthy_pct = yoy_week_data['below_cost_oih_cost'].sum() / yoy_week_data['oih_managed_cost'].sum() * 100
    
    wow_change_bps = (current_unhealthy_pct - prev_week_unhealthy_pct) * 100
    yoy_change_bps = (current_unhealthy_pct - yoy_unhealthy_pct) * 100
    
    total_managed_cost = current_week_data['oih_managed_cost'].sum()
    unhealthy_cost = current_week_data['below_cost_oih_cost'].sum()
    
    # Basic HTML template - you should copy your full template here
    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <title>OIH Analysis Report</title>
    <style>
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 10px; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); color: #333; zoom: 0.9; }}
        .container {{ max-width: 1400px; margin: 0 auto; background: white; padding: 20px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }}
        h1 {{ color: #2c5aa0; text-align: center; margin-bottom: 40px; padding-bottom: 20px; border-bottom: 3px solid #2c5aa0; }}
        .summary-grid {{ display: flex; justify-content: space-around; margin: 30px 0; padding: 25px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; color: white; box-shadow: 0 5px 15px rgba(0,0,0,0.2); }}
        .summary-card {{ text-align: center; padding: 15px; background: rgba(255,255,255,0.1); border-radius: 10px; backdrop-filter: blur(10px); }}
        .summary-card h3 {{ margin: 0 0 10px 0; font-size: 1.1em; opacity: 0.9; }}
        .summary-card .value {{ font-size: 2.5em; font-weight: bold; margin: 10px 0; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>F2 OIH Analysis Report Week of {current_start_date}</h1>
        <p style="text-align: center; color: #7f8c8d;">Generated on {datetime.now().strftime('%B %d, %Y at %I:%M %p')}</p>
        
        <h2>OIH Summary</h2>
        <div class="summary-grid">
            <div class="summary-card">
                <h3>OIH Unhealthy %</h3>
                <div class="value">{current_unhealthy_pct:.2f}%</div>
            </div>
            <div class="summary-card">
                <h3>Total Inventory Cost</h3>
                <div class="value">${total_managed_cost/1e9:.1f}B</div>
            </div>
            <div class="summary-card">
                <h3>Unhealthy Inventory Cost</h3>
                <div class="value">${unhealthy_cost/1e6:.0f}M</div>
            </div>
            <div class="summary-card" style="background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);">
                <h3>WoW Change</h3>
                <div class="value">{wow_change_bps:+.0f} bps</div>
            </div>
            <div class="summary-card" style="background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);">
                <h3>YoY Change</h3>
                <div class="value">{yoy_change_bps:+.0f} bps</div>
            </div>
        </div>
    </div>
</body>
</html>"""
    
    with open(output_path, 'w') as f:
        f.write(html_content)

def create_8week_trend_chart(trend_data):
    """Placeholder for trend chart creation"""
    return ""

def get_user_inputs():
    """Placeholder - not needed for MCP server"""
    pass
