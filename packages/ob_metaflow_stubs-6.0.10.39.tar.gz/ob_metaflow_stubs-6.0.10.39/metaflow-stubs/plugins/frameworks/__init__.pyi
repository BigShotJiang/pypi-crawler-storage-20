######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.3+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-12T19:35:09.484367                                                            #
######################################################################################################

from __future__ import annotations


from . import pytorch as pytorch

