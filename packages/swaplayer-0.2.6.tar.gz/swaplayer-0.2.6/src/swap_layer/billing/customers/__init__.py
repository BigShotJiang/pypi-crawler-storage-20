"""
Customer management subdomain.
"""
