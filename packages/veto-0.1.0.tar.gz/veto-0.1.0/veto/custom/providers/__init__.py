"""
Custom LLM provider implementations.
"""
