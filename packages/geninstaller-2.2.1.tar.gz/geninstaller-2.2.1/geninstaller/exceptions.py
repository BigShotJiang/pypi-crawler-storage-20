class GeninstallerError(Exception):
    pass