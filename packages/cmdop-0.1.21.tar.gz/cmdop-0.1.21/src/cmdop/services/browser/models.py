"""Browser models and error handling."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from cmdop.exceptions import (
    BrowserElementNotFoundError,
    BrowserError,
    BrowserNavigationError,
    BrowserSessionClosedError,
)


def raise_browser_error(error: str, operation: str, **context: Any) -> None:
    """Raise appropriate browser exception based on error message."""
    error_lower = error.lower()

    if "target closed" in error_lower or "context closed" in error_lower:
        raise BrowserSessionClosedError(error)

    if operation == "navigate":
        raise BrowserNavigationError(context.get("url", ""), error)

    if "element not found" in error_lower or "no element" in error_lower:
        raise BrowserElementNotFoundError(context.get("selector", ""), operation)

    raise BrowserError(f"{operation} failed: {error}")


class BrowserCookie(BaseModel):
    """Browser cookie."""

    name: str
    value: str
    domain: str = ""
    path: str = "/"
    secure: bool = False
    http_only: bool = False
    same_site: str = ""
    expires: int = 0


class BrowserState(BaseModel):
    """Current browser state."""

    url: str
    title: str


class ScrollInfo(BaseModel):
    """Scroll position and page dimensions."""

    scroll_x: int = 0
    scroll_y: int = 0
    page_height: int = 0
    page_width: int = 0
    viewport_height: int = 0
    viewport_width: int = 0
    at_bottom: bool = False
    at_top: bool = True


class ScrollResult(BaseModel):
    """Result of scroll operation (v2.18.0)."""

    success: bool = True
    scroll_x: int = 0
    scroll_y: int = 0
    scrolled_by: int = 0
    page_height: int = 0
    viewport_height: int = 0
    at_bottom: bool = False
    error: str | None = None


class PageInfo(BaseModel):
    """Comprehensive page information (v2.18.0)."""

    # Basic
    url: str = ""
    title: str = ""
    page_height: int = 0
    viewport_height: int = 0
    viewport_width: int = 0

    # Scroll position
    scroll_x: int = 0
    scroll_y: int = 0
    at_top: bool = True
    at_bottom: bool = False

    # Technical
    load_time_ms: int = 0
    cookies_count: int = 0
    is_https: bool = False
    has_iframes: bool = False

    # DOM complexity
    dom_nodes_raw: int = 0
    dom_nodes_cleaned: int = 0
    tokens_estimate: int = 0

    # Protection detection
    cloudflare_detected: bool = False
    captcha_detected: bool = False


class InfiniteScrollResult(BaseModel):
    """Result of infinite scroll extraction."""

    new_keys: list[str] = []
    at_bottom: bool = False
    total_seen: int = 0
    error: str | None = None
