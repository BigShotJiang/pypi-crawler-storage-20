"""Base session class with shared logic."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from cmdop.services.browser.models import BrowserCookie, BrowserState
from cmdop.services.browser.js import (
    build_async_js,
    build_fetch_js,
    build_fetch_all_js,
    build_scroll_js,
    build_scroll_to_bottom_js,
    build_get_scroll_info_js,
    build_hover_js,
    build_select_js,
    build_close_modal_js,
    build_click_all_by_text_js,
    build_press_key_js,
    parse_json_result,
)

if TYPE_CHECKING:
    from cmdop.services.browser.base.service import BaseServiceMixin


class BaseSession(ABC):
    """
    Abstract base for browser sessions.

    Subclasses must implement:
    - _execute_script(script) -> str
    - All service delegation methods (navigate, click, etc.)
    - Context manager methods (__enter__/__exit__ or __aenter__/__aexit__)
    """

    def __init__(self, service: BaseServiceMixin, session_id: str) -> None:
        self._service = service
        self._session_id = session_id

    @property
    def session_id(self) -> str:
        return self._session_id

    # === Abstract methods (sync/async differ) ===

    @abstractmethod
    def _call_service(self, method: str, *args: Any, **kwargs: Any) -> Any:
        """Call service method. Sync returns value, async returns coroutine."""
        ...

    # === Shared helpers (pure logic, no I/O) ===

    def _build_execute_js(self, code: str) -> str:
        """Build wrapped async JS code."""
        return build_async_js(code)

    def _parse_execute_js(self, result: str, raw: bool) -> dict | list | str | None:
        """Parse execute_js result."""
        if raw:
            return result
        return parse_json_result(result)

    def _build_fetch_json(self, url: str) -> str:
        """Build fetch JS for single URL."""
        return build_fetch_js(url)

    def _build_fetch_all(
        self,
        urls: dict[str, str],
        headers: dict[str, str] | None,
        credentials: bool,
    ) -> str:
        """Build fetch_all JS code."""
        return build_fetch_all_js(urls, headers, credentials)

    def _parse_fetch_all(self, result: Any) -> dict[str, Any]:
        """Ensure fetch_all returns dict."""
        return result if isinstance(result, dict) else {}

    # === Scroll helpers ===

    def _build_scroll(
        self,
        direction: str,
        amount: int,
        selector: str | None,
        smooth: bool,
        human_like: bool,
        container: str | None = None,
    ) -> str:
        """Build scroll JS."""
        return build_scroll_js(direction, amount, selector, smooth, human_like, container)

    def _build_scroll_to_bottom(self) -> str:
        """Build scroll to bottom JS."""
        return build_scroll_to_bottom_js()

    def _build_get_scroll_info(self) -> str:
        """Build get scroll info JS."""
        return build_get_scroll_info_js()

    # === Interaction helpers ===

    def _build_hover(self, selector: str) -> str:
        """Build hover JS."""
        return build_hover_js(selector)

    def _build_select(self, selector: str, value: str | None, text: str | None) -> str:
        """Build select JS."""
        return build_select_js(selector, value, text)

    def _build_close_modal(self, selectors: list[str] | None) -> str:
        """Build close modal JS."""
        return build_close_modal_js(selectors)

    def _build_click_all_by_text(self, text: str, role: str) -> str:
        """Build click all by text JS."""
        return build_click_all_by_text_js(text, role)

    def _build_press_key(self, key: str, selector: str | None) -> str:
        """Build press key JS."""
        return build_press_key_js(key, selector)
