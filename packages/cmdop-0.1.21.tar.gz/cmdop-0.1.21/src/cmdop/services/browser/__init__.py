"""Browser automation service.

Structure:
    browser/
        models.py       - Data models (BrowserCookie, BrowserState)
        js.py           - JavaScript code builders
        base/           - Base classes (BaseSession, BaseServiceMixin)
        sync/           - Sync implementation (BrowserSession, BrowserService)
        aio/            - Async implementation (AsyncBrowserSession, AsyncBrowserService)

Usage:
    # Sync
    with client.browser.create_session() as session:
        session.navigate("https://example.com")
        data = session.fetch_all(urls, headers={"Accept": "application/json"})

    # Async
    async with client.browser.create_session() as session:
        await session.navigate("https://example.com")
        data = await session.fetch_all(urls, headers={"Accept": "application/json"})
"""

from cmdop.services.browser.models import BrowserCookie, BrowserState, PageInfo, ScrollResult, raise_browser_error

# Sync
from cmdop.services.browser.sync.session import BrowserSession
from cmdop.services.browser.sync.service import BrowserService

# Async
from cmdop.services.browser.aio.session import AsyncBrowserSession
from cmdop.services.browser.aio.service import AsyncBrowserService

__all__ = [
    # Models
    "BrowserCookie",
    "BrowserState",
    "PageInfo",
    "ScrollResult",
    "raise_browser_error",
    # Sync
    "BrowserSession",
    "BrowserService",
    # Async
    "AsyncBrowserSession",
    "AsyncBrowserService",
]
