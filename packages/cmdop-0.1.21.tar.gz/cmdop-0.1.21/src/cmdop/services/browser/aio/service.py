"""Asynchronous browser service."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from cmdop.services.base import BaseService
from cmdop.services.browser.base.service import BaseServiceMixin, cookie_to_pb, pb_to_cookie
from cmdop.services.browser.models import BrowserCookie, BrowserState, PageInfo, ScrollResult, raise_browser_error

if TYPE_CHECKING:
    from cmdop.transport.base import BaseTransport


class AsyncBrowserService(BaseService, BaseServiceMixin):
    """
    Asynchronous browser service.

    Example:
        async with client.browser.create_session() as session:
            await session.navigate("https://google.com")
            await session.type("input[name='q']", "Python")
            results = await session.extract(".result-title")
    """

    def __init__(self, transport: BaseTransport) -> None:
        super().__init__(transport)
        self._stub: Any = None

    @property
    def _get_stub(self) -> Any:
        if self._stub is None:
            from cmdop._generated.service_pb2_grpc import TerminalStreamingServiceStub
            self._stub = TerminalStreamingServiceStub(self._async_channel)
        return self._stub

    # === Session Management ===

    async def create_session(
        self,
        start_url: str | None = None,
        provider: str = "camoufox",
        profile_id: str | None = None,
        headless: bool = False,
        width: int = 1280,
        height: int = 800,
    ) -> "AsyncBrowserSession":
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserCreateSessionRequest
        from cmdop.services.browser.aio.session import AsyncBrowserSession

        request = BrowserCreateSessionRequest(
            provider=provider,
            profile_id=profile_id or "",
            start_url=start_url or "",
            headless=headless,
            width=width,
            height=height,
        )
        response = await self._call_async(self._get_stub.BrowserCreateSession, request)

        if not response.success:
            raise_browser_error(response.error, "create_session")

        return AsyncBrowserSession(self, response.browser_session_id)

    async def close_session(self, session_id: str) -> None:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserCloseSessionRequest

        request = BrowserCloseSessionRequest(browser_session_id=session_id)
        response = await self._call_async(self._get_stub.BrowserCloseSession, request)

        if not response.success:
            raise RuntimeError(f"Failed to close browser session: {response.error}")

    # === Navigation & Interaction ===

    async def navigate(self, session_id: str, url: str, timeout_ms: int = 30000) -> str:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserNavigateRequest

        request = BrowserNavigateRequest(
            browser_session_id=session_id, url=url, timeout_ms=timeout_ms
        )
        response = await self._call_async(self._get_stub.BrowserNavigate, request)

        if not response.success:
            raise_browser_error(response.error, "navigate", url=url)

        return response.final_url

    async def click(
        self, session_id: str, selector: str, timeout_ms: int = 5000, move_cursor: bool = False
    ) -> None:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserClickRequest

        request = BrowserClickRequest(
            browser_session_id=session_id,
            selector=selector,
            timeout_ms=timeout_ms,
            move_cursor=move_cursor,
        )
        response = await self._call_async(self._get_stub.BrowserClick, request)

        if not response.success:
            raise_browser_error(response.error, "click", selector=selector)

    async def type(
        self,
        session_id: str,
        selector: str,
        text: str,
        human_like: bool = False,
        clear_first: bool = True,
    ) -> None:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserTypeRequest

        request = BrowserTypeRequest(
            browser_session_id=session_id,
            selector=selector,
            text=text,
            human_like=human_like,
            clear_first=clear_first,
        )
        response = await self._call_async(self._get_stub.BrowserType, request)

        if not response.success:
            raise_browser_error(response.error, "type", selector=selector)

    async def wait_for(
        self, session_id: str, selector: str, timeout_ms: int = 30000
    ) -> bool:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserWaitRequest

        request = BrowserWaitRequest(
            browser_session_id=session_id, selector=selector, timeout_ms=timeout_ms
        )
        response = await self._call_async(self._get_stub.BrowserWait, request)

        if not response.success:
            raise_browser_error(response.error, "wait_for", selector=selector)

        return response.found

    # === Extraction ===

    async def extract(
        self, session_id: str, selector: str, attr: str | None = None, limit: int = 100
    ) -> list[str]:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExtractRequest

        request = BrowserExtractRequest(
            browser_session_id=session_id,
            selector=selector,
            attribute=attr or "",
            limit=limit,
        )
        response = await self._call_async(self._get_stub.BrowserExtract, request)

        if not response.success:
            raise RuntimeError(f"Extract failed: {response.error}")

        return list(response.values)

    async def extract_regex(
        self, session_id: str, pattern: str, from_html: bool = False, limit: int = 100
    ) -> list[str]:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExtractRegexRequest

        request = BrowserExtractRegexRequest(
            browser_session_id=session_id,
            pattern=pattern,
            from_html=from_html,
            limit=limit,
        )
        response = await self._call_async(self._get_stub.BrowserExtractRegex, request)

        if not response.success:
            raise RuntimeError(f"ExtractRegex failed: {response.error}")

        return list(response.matches)

    async def get_html(self, session_id: str, selector: str | None = None) -> str:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetHTMLRequest

        request = BrowserGetHTMLRequest(
            browser_session_id=session_id, selector=selector or ""
        )
        response = await self._call_async(self._get_stub.BrowserGetHTML, request)

        if not response.success:
            raise RuntimeError(f"GetHTML failed: {response.error}")

        return response.html

    async def get_text(self, session_id: str, selector: str | None = None) -> str:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetTextRequest

        request = BrowserGetTextRequest(
            browser_session_id=session_id, selector=selector or ""
        )
        response = await self._call_async(self._get_stub.BrowserGetText, request)

        if not response.success:
            raise RuntimeError(f"GetText failed: {response.error}")

        return response.text

    # === JavaScript ===

    async def execute_script(self, session_id: str, script: str) -> str:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExecuteScriptRequest

        request = BrowserExecuteScriptRequest(
            browser_session_id=session_id, script=script
        )
        response = await self._call_async(
            self._get_stub.BrowserExecuteScript, request
        )

        if not response.success:
            raise RuntimeError(f"ExecuteScript failed: {response.error}")

        return response.result

    # === State & Cookies ===

    async def screenshot(self, session_id: str, full_page: bool = False) -> bytes:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserScreenshotRequest

        request = BrowserScreenshotRequest(
            browser_session_id=session_id, full_page=full_page
        )
        response = await self._call_async(self._get_stub.BrowserScreenshot, request)

        if not response.success:
            raise RuntimeError(f"Screenshot failed: {response.error}")

        return response.data

    async def get_state(self, session_id: str) -> BrowserState:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetStateRequest

        request = BrowserGetStateRequest(browser_session_id=session_id)
        response = await self._call_async(self._get_stub.BrowserGetState, request)

        if not response.success:
            raise RuntimeError(f"GetState failed: {response.error}")

        return BrowserState(url=response.url, title=response.title)

    async def set_cookies(
        self, session_id: str, cookies: list[BrowserCookie | dict]
    ) -> None:
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserCookie as PbCookie,
            BrowserSetCookiesRequest,
        )

        pb_cookies = [cookie_to_pb(c, PbCookie) for c in cookies]
        request = BrowserSetCookiesRequest(
            browser_session_id=session_id, cookies=pb_cookies
        )
        response = await self._call_async(self._get_stub.BrowserSetCookies, request)

        if not response.success:
            raise RuntimeError(f"SetCookies failed: {response.error}")

    async def get_cookies(
        self, session_id: str, domain: str = ""
    ) -> list[BrowserCookie]:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetCookiesRequest

        request = BrowserGetCookiesRequest(
            browser_session_id=session_id, domain=domain
        )
        response = await self._call_async(self._get_stub.BrowserGetCookies, request)

        if not response.success:
            raise RuntimeError(f"GetCookies failed: {response.error}")

        return [pb_to_cookie(c) for c in response.cookies]

    # === Parser helpers ===

    async def validate_selectors(
        self, session_id: str, item: str, fields: dict[str, str]
    ) -> dict:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserValidateSelectorsRequest

        request = BrowserValidateSelectorsRequest(
            browser_session_id=session_id,
            item=item,
            fields=fields,
        )
        response = await self._call_async(
            self._get_stub.BrowserValidateSelectors, request
        )

        if not response.success:
            raise RuntimeError(f"ValidateSelectors failed: {response.error}")

        return {
            "valid": response.valid,
            "counts": dict(response.counts),
            "samples": dict(response.samples),
            "errors": list(response.errors),
        }

    async def extract_data(
        self, session_id: str, item: str, fields_json: str, limit: int = 100
    ) -> dict:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExtractDataRequest

        request = BrowserExtractDataRequest(
            browser_session_id=session_id,
            item=item,
            fields_json=fields_json,
            limit=limit,
        )
        response = await self._call_async(self._get_stub.BrowserExtractData, request)

        if not response.success:
            raise RuntimeError(f"ExtractData failed: {response.error}")

        return {
            "items": json.loads(response.items_json) if response.items_json else [],
            "count": response.count,
        }

    # === Mouse & Scroll (v2.18.0) ===

    async def mouse_move(
        self, session_id: str, x: int, y: int, steps: int = 10
    ) -> None:
        """Move cursor to coordinates with smooth movement."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserMouseMoveRequest

        request = BrowserMouseMoveRequest(
            browser_session_id=session_id, x=x, y=y, steps=steps
        )
        response = await self._call_async(self._get_stub.BrowserMouseMove, request)

        if not response.success:
            raise RuntimeError(f"MouseMove failed: {response.error}")

    async def hover(self, session_id: str, selector: str, timeout_ms: int = 5000) -> None:
        """Hover over element by selector."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserHoverRequest

        request = BrowserHoverRequest(
            browser_session_id=session_id, selector=selector, timeout_ms=timeout_ms
        )
        response = await self._call_async(self._get_stub.BrowserHover, request)

        if not response.success:
            raise_browser_error(response.error, "hover", selector=selector)

    async def scroll(
        self,
        session_id: str,
        direction: str = "down",
        amount: int = 500,
        selector: str = "",
        smooth: bool = True,
    ) -> ScrollResult:
        """Scroll page or element into view."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserScrollRequest

        request = BrowserScrollRequest(
            browser_session_id=session_id,
            direction=direction,
            amount=amount,
            selector=selector,
            smooth=smooth,
        )
        response = await self._call_async(self._get_stub.BrowserScroll, request)

        if not response.success:
            return ScrollResult(success=False, error=response.error)

        return ScrollResult(
            success=True,
            scroll_x=response.scroll_x,
            scroll_y=response.scroll_y,
            scrolled_by=response.scrolled_by,
            page_height=response.page_height,
            viewport_height=response.viewport_height,
            at_bottom=response.at_bottom,
        )

    async def get_page_info(self, session_id: str) -> PageInfo:
        """Get comprehensive page information."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetPageInfoRequest

        request = BrowserGetPageInfoRequest(browser_session_id=session_id)
        response = await self._call_async(self._get_stub.BrowserGetPageInfo, request)

        if not response.success:
            raise RuntimeError(f"GetPageInfo failed: {response.error}")

        return PageInfo(
            url=response.url,
            title=response.title,
            page_height=response.page_height,
            viewport_height=response.viewport_height,
            viewport_width=response.viewport_width,
            scroll_x=response.scroll_x,
            scroll_y=response.scroll_y,
            at_top=response.at_top,
            at_bottom=response.at_bottom,
            load_time_ms=response.load_time_ms,
            cookies_count=response.cookies_count,
            is_https=response.is_https,
            has_iframes=response.has_iframes,
            dom_nodes_raw=response.dom_nodes_raw,
            dom_nodes_cleaned=response.dom_nodes_cleaned,
            tokens_estimate=response.tokens_estimate,
            cloudflare_detected=response.cloudflare_detected,
            captcha_detected=response.captcha_detected,
        )
