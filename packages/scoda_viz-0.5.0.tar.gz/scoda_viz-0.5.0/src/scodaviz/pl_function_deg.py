from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional, Sequence, Tuple, Literal

from scodaviz import plot_deg


# -----------------------------
# Tool-friendly configs
# -----------------------------
DEGMode = Literal["DEG", "DEG_vs_ref"]


@dataclass
class DEGComputeConfig:
    """
    Compute-side options for DEG plotting.

    Parameters
    ----------
    deg_mode :
        Which DEG result to use from adata.uns.
        - "DEG"        -> adata.uns["DEG"]
        - "DEG_vs_ref" -> adata.uns["DEG_vs_ref"]
    taxo_level :
        Obs column that defines celltype names.
        If None, inferred from adata.uns['analysis_parameters']['CCI_DEG_BASE'].
    """
    deg_mode: DEGMode = "DEG"
    taxo_level: Optional[str] = None


@dataclass
class DEGPlotConfig:
    """
    Plot & filtering options forwarded to `plot_deg`.

    Notes
    -----
    - `sort_by` controls how DEG dataframe is ranked before plotting.
    - Default 'nz_pct_score' matches your current behavior.
    """
    n_genes_to_show: int = 30
    pval_cutoff: float = 0.01
    sort_by: str = "nz_pct_score"

    figsize: Tuple[float, float] = (4, 2)
    dpi: int = 100

    text_fontsize: int = 7
    title_fontsize: int = 12
    label_fontsize: int = 10
    tick_fontsize: int = 9

    ncols: int = 5
    wspace: float = 0.2
    hspace: float = 0.5

    show_log_pv: bool = False


# -----------------------------
# Helpers
# -----------------------------
def _infer_taxo_level(adata, taxo_level: Optional[str]) -> Optional[str]:
    if taxo_level is not None:
        return taxo_level
    try:
        return adata.uns["analysis_parameters"]["CCI_DEG_BASE"]
    except Exception:
        return None


# -----------------------------
# Main function
# -----------------------------
def plot_degs(
    adata,
    *,
    target_cells: Sequence[str],
    compute_cfg: Optional[DEGComputeConfig] = None,
    plot_cfg: Optional[DEGPlotConfig] = None,
) -> Dict[str, Any]:
    """
    Plot DEG results for one or more target cell types.

    Tool-schema friendly wrapper around `scodaviz.plot_deg`.

    Expected AnnData structure
    --------------------------
    adata.uns must contain:
      - adata.uns["DEG"] or adata.uns["DEG_vs_ref"]
      - adata.uns["DEG_stat"] or adata.uns["DEG_vs_ref_stat"] (optional)

    Returns
    -------
    dict
        {
          "deg_mode": "DEG" | "DEG_vs_ref",
          "taxo_level": <str>,
          "requested_cells": [...],
          "plotted_cells": [...],
          "missing_cells": [...],
          "cells_without_deg": [...],
          "warnings": [...]
        }
    """
    compute_cfg = compute_cfg or DEGComputeConfig()
    plot_cfg = plot_cfg or DEGPlotConfig()

    warnings: list[str] = []

    deg_item = compute_cfg.deg_mode
    taxo_level = _infer_taxo_level(adata, compute_cfg.taxo_level)

    if taxo_level is None:
        warnings.append("Cannot determine taxo_level. Set compute_cfg.taxo_level explicitly.")

    if len(target_cells) == 0:
        warnings.append("No target_cells provided.")
        return {
            "deg_mode": deg_item,
            "taxo_level": taxo_level,
            "requested_cells": [],
            "plotted_cells": [],
            "missing_cells": [],
            "cells_without_deg": [],
            "warnings": warnings,
        }

    deg_dct = adata.uns.get(deg_item)
    if not isinstance(deg_dct, dict):
        warnings.append(f"adata.uns['{deg_item}'] not found or invalid.")
        return {
            "deg_mode": deg_item,
            "taxo_level": taxo_level,
            "requested_cells": list(target_cells),
            "plotted_cells": [],
            "missing_cells": list(target_cells),
            "cells_without_deg": list(target_cells),
            "warnings": warnings,
        }

    deg_stat_all = adata.uns.get(f"{deg_item}_stat", {})

    available_celltypes = (
        set(adata.obs[taxo_level].unique())
        if taxo_level in adata.obs
        else None
    )

    plotted, missing, no_deg = [], [], []

    for c in target_cells:
        if available_celltypes is not None and c not in available_celltypes:
            missing.append(c)
            warnings.append(f"Cannot identify celltype '{c}' in obs['{taxo_level}']")
            continue

        if c not in deg_dct:
            no_deg.append(c)
            warnings.append(f"No DEG result for celltype '{c}'")
            continue

        deg_df = deg_dct[c]

        # --- sorting (filtering-level option) ---
        for case in deg_df.keys():
            if plot_cfg.sort_by in deg_df[case].columns:
                deg_df[case] = deg_df[case].sort_values(plot_cfg.sort_by, ascending=False)

        deg_stat = deg_stat_all.get(c)
        print(c)
        ax = plot_deg(
            deg_df,
            n_genes_to_show=plot_cfg.n_genes_to_show,
            pval_cutoff=plot_cfg.pval_cutoff,
            figsize=plot_cfg.figsize,
            dpi=plot_cfg.dpi,
            text_fs=plot_cfg.text_fontsize,
            title_fs=plot_cfg.title_fontsize,
            label_fs=plot_cfg.label_fontsize,
            tick_fs=plot_cfg.tick_fontsize,
            ncols=plot_cfg.ncols,
            wspace=plot_cfg.wspace,
            hspace=plot_cfg.hspace,
            deg_stat_dct=deg_stat,
            show_log_pv=plot_cfg.show_log_pv,
        )

        plotted.append(c)

    return {
        "deg_mode": deg_item,
        "taxo_level": taxo_level,
        "requested_cells": list(target_cells),
        "plotted_cells": plotted,
        "missing_cells": missing,
        "cells_without_deg": no_deg,
        "warnings": warnings,
        "img_base64": ax,
        "images": ax,  
    }

