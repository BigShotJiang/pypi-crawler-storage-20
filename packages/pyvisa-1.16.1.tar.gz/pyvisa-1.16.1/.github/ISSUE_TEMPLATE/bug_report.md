---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

<!--- A clear and concise description of what the bug is -->

To Reproduce
--------------
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Output of `pyvisa-info`**
<!--- Output of the pyvisa-info command (to run in a command prompt) -->
