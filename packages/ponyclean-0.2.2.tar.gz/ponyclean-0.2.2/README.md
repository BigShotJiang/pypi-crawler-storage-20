[![PyPI version](https://badge.fury.io/py/ponyclean.svg)](https://pypi.org/project/ponyclean/)

# CClean

**CClean** — это CLI-утилита для автоматической очистки проекта от временных и мусорных файлов  
(кеши, артефакты тестов, байткод Python и т.п.).

Инструмент ориентирован на **безопасную очистку**:
- работает только внутри проекта
- поддерживает режим предварительного просмотра (`--dry-run`)
- использует как дефолтные правила, так и пользовательскую конфигурацию

---

## Возможности

- 🧹 удаление стандартных «мусорных» директорий (`__pycache__`, `.pytest_cache`, и др.)
- 📄 удаление временных файлов (`*.pyc`, `.coverage`, и т.п.)
- ⚙️ пользовательский список файлов/папок через `clean.toml`
- 🔒 защита от удаления файлов вне проекта
- 👀 режим предварительного просмотра (`--dry-run`)
- 🖥 CLI-интерфейс

### Безопасность
PonyClean никогда не удаляет:
- venv / .venv
- .git
- .ponyclean

---

## Установка

```text
При первом запуске утилита создаст data/clean_default.toml и data/clean_user.toml
в корне проекта (или в --root)
```

```bash
pip install ponyclean
```

## Запуск
```bash
cclean run
```

## Примеры
```bash
cclean run
cclean run --root /path/to/project
cclean run --dry-run
```

## Конфигурация
```yaml
data/clean_user.toml
```

## Формат
```toml
files = [
    "build",
    "dist",
    "some/temp/file.txt"
]
```

## LICENSE
MIT

## VERSION
0.2.1
