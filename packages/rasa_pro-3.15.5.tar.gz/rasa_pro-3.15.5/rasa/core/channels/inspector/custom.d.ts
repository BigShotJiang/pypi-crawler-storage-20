interface Window {
  rasaChatSessionId?: string;
}
