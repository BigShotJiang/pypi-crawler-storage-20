"""Tests for internal tools."""
