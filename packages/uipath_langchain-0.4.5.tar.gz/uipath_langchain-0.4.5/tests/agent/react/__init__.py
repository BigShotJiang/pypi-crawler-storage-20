"""Tests for ReAct agent."""
