"""Tests for backend initialization and behavior."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from build_cub._printer import ColorPrinter
    from build_cub.models._backends import CythonSettings, RawCppSettings
    from build_cub.models._build_data import BuildData


class TestBackendInitialization:
    """Tests for backend class initialization."""

    def test_cython_backend_init(self, test_build_data: BuildData, color_printer: ColorPrinter) -> None:
        """Test CythonBackend initializes correctly."""
        from build_cub.backends.cython import CythonBackend

        backend = CythonBackend(should_run=True, settings=test_build_data, printer=color_printer)
        assert backend.name == "cython"
        assert backend.should_run is True
        assert backend.settings is test_build_data

    def test_raw_cpp_backend_init(self, test_build_data: BuildData, color_printer: ColorPrinter) -> None:
        """Test RawCppBackend initializes correctly."""
        from build_cub.backends.raw_cpp import RawCppBackend

        backend = RawCppBackend(should_run=True, settings=test_build_data, printer=color_printer)
        assert backend.name == "raw_cpp"
        assert backend.should_run is True

    def test_pybind11_backend_init(self, test_build_data: BuildData, color_printer: ColorPrinter) -> None:
        """Test Pybind11Backend initializes correctly."""
        from build_cub.backends.pybind11 import Pybind11Backend

        backend = Pybind11Backend(should_run=True, settings=test_build_data, printer=color_printer)
        assert backend.name == "pybind11"
        assert backend.should_run is True

    def test_gperf_backend_init(self, test_build_data: BuildData, color_printer: ColorPrinter) -> None:
        """Test GperfBackend initializes correctly."""
        from build_cub.backends.gperf import GperfBackend

        backend = GperfBackend(should_run=True, settings=test_build_data, printer=color_printer)
        assert backend.name == "gperf"


class TestGperfDependencyVerification:
    """Tests for gperf binary dependency checking."""

    def test_gperf_disabled_when_binary_missing(self, test_toml_data: dict[str, Any]) -> None:
        """Test GperfBackend sets should_run=False when binary not found."""
        from build_cub._printer import ColorPrinter
        from build_cub.backends.gperf import GperfBackend
        from build_cub.models._build_data import BuildData

        test_toml_data["gperf"]["binary"] = "/nonexistent/path/to/gperf"

        build_data: BuildData = BuildData.model_validate(test_toml_data)
        printer = ColorPrinter()
        backend = GperfBackend(should_run=True, settings=build_data, printer=printer)

        assert backend.should_run is False


class TestBackendLocalSettings:
    """Tests for backend local_settings property."""

    def test_cython_local_settings(self, test_build_data: BuildData, color_printer: ColorPrinter) -> None:
        """Test CythonBackend.local_settings returns CythonSettings."""
        from build_cub.backends.cython import CythonBackend

        backend = CythonBackend(should_run=True, settings=test_build_data, printer=color_printer)
        local: CythonSettings = backend.local_settings
        assert local.enabled is True
        assert len(local.targets) == 2

    def test_raw_cpp_local_settings(self, test_build_data: BuildData, color_printer: ColorPrinter) -> None:
        """Test RawCppBackend.local_settings returns RawCppSettings."""
        from build_cub.backends.raw_cpp import RawCppBackend

        backend = RawCppBackend(should_run=True, settings=test_build_data, printer=color_printer)
        local: RawCppSettings = backend.local_settings
        assert local.enabled is True
        assert len(local.targets) == 1


# ruff: noqa: PLC0415
