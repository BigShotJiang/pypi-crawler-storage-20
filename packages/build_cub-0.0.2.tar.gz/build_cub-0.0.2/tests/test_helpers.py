"""Tests for helper functions in _helpers.py."""

from __future__ import annotations

from pathlib import Path

import pytest


class TestPlatformDetection:
    """Tests for platform-specific settings selection."""

    def test_compiler_args_key_matches_platform(self) -> None:
        """Test correct compiler args key is selected based on platform."""
        from build_cub._helpers import COMPILER_ARGS_KEY, IS_WINDOWS, LINK_ARGS_KEY

        if IS_WINDOWS:
            assert COMPILER_ARGS_KEY == "extra_compile_args_windows"
            assert LINK_ARGS_KEY == "extra_link_args_windows"
        else:
            assert COMPILER_ARGS_KEY == "extra_compile_args"
            assert LINK_ARGS_KEY == "extra_link_args"


class TestCompilerSettingsValidationAlias:
    """Tests for CompilerSettings platform-specific arg selection."""

    def test_picks_correct_args_via_alias(self) -> None:
        """Test CompilerSettings uses validation_alias for platform detection."""
        from build_cub.models._defaults import CompilerSettings

        data: dict[str, list[str]] = {
            "extra_compile_args": ["-O3"],
            "extra_compile_args_windows": ["/O2"],
            "extra_link_args": ["-Wl,-w"],
            "extra_link_args_windows": ["/IGNORE:4099"],
        }

        settings = CompilerSettings.model_validate(data)
        assert len(settings.extra_compile_args) > 0
        assert len(settings.extra_link_args) > 0


class TestGetFiles:
    """Tests for get_files utility function."""

    def test_finds_files_by_extension(self, tmp_path: Path) -> None:
        """Test get_files finds files matching extensions."""
        from build_cub.backends._base import get_files

        (tmp_path / "test.pyx").touch()
        (tmp_path / "other.py").touch()
        (tmp_path / "subdir").mkdir()
        (tmp_path / "subdir" / "nested.pyx").touch()

        files = get_files(tmp_path, [".pyx"])
        assert len(files) == 2
        assert all(f.suffix == ".pyx" for f in files)

    def test_finds_multiple_extensions(self, tmp_path: Path) -> None:
        """Test get_files can match multiple extensions."""
        from build_cub.backends._base import get_files

        (tmp_path / "a.so").touch()
        (tmp_path / "b.pyd").touch()
        (tmp_path / "c.txt").touch()

        files = get_files(tmp_path, [".so", ".pyd"])
        assert len(files) == 2


class TestGetParts:
    """Tests for get_parts path parsing."""

    def test_extracts_module_parts(self) -> None:
        """Test get_parts extracts module path components."""
        from build_cub._helpers import get_parts

        path = Path("src/my_project/submodule/file.pyx")
        parts: tuple[str, ...] = get_parts(path)
        assert parts == ("my_project", "submodule", "file")

    def test_strips_src_prefix(self) -> None:
        """Test get_parts removes 'src' from path."""
        from build_cub._helpers import get_parts

        path = Path("src/pkg/module.py")
        parts: tuple[str, ...] = get_parts(path)
        assert parts[0] != "src"
        assert parts == ("pkg", "module")

    def test_to_module_returns_dotted_string(self) -> None:
        """Test get_parts with to_module=True returns dotted module path."""
        from build_cub._helpers import get_parts

        path = Path("src/pkg/sub/mod.py")
        module: str = get_parts(path, to_module=True)
        assert module == "pkg.sub.mod"


class TestImmutableList:
    """Tests for ImmutableList sentinel class."""

    def test_raises_on_append(self) -> None:
        """Test ImmutableList raises on append."""
        from build_cub._helpers import ImmutableList

        immutable = ImmutableList([1, 2, 3])
        with pytest.raises(TypeError, match="immutable"):
            immutable.append(4)

    def test_raises_on_setitem(self) -> None:
        """Test ImmutableList raises on item assignment."""
        from build_cub._helpers import ImmutableList

        immutable = ImmutableList([1, 2, 3])
        with pytest.raises(TypeError, match="immutable"):
            immutable[0] = 99

    def test_raises_on_extend(self) -> None:
        """Test ImmutableList raises on extend."""
        from build_cub._helpers import ImmutableList

        immutable = ImmutableList([1, 2, 3])
        with pytest.raises(TypeError, match="immutable"):
            immutable.extend([4, 5])

    def test_bool_is_false(self) -> None:
        """Test ImmutableList is falsy (used as empty sentinel)."""
        from build_cub._helpers import EMPTY_IMMUTABLE_LIST

        assert bool(EMPTY_IMMUTABLE_LIST) is False

    def test_len_is_zero(self) -> None:
        """Test ImmutableList reports length as 0 (sentinel behavior)."""
        from build_cub._helpers import EMPTY_IMMUTABLE_LIST

        assert len(EMPTY_IMMUTABLE_LIST) == 0


# ruff: noqa: PLC0415
