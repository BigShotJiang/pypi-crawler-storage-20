"""Pytest fixtures and configuration for build_cub tests."""

from __future__ import annotations

from os import environ
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pytest

from build_cub import METADATA

from . import FIXTURES_DIR

if TYPE_CHECKING:
    from build_cub._printer import ColorPrinter
    from build_cub.models._build_data import BuildData

environ[f"{METADATA.env_variable}"] = "test"


TEST_TOML_PATH: Path = FIXTURES_DIR / "test_bear_build.toml"
MAIN_CONFIG_PATH = Path("config") / "bear_build.toml"


@pytest.fixture
def test_toml_data() -> dict[str, Any]:
    """Load the test fixture TOML as raw dict."""
    from build_cub._helpers import load_toml

    return load_toml(TEST_TOML_PATH)


@pytest.fixture
def test_build_data() -> BuildData:
    """Load the test fixture as a validated BuildData model."""
    from build_cub._helpers import load_toml
    from build_cub.models._build_data import BuildData

    return BuildData.model_validate(load_toml(TEST_TOML_PATH))


@pytest.fixture
def project_toml_data() -> dict[str, Any]:
    """Load the actual project bear_build.toml as raw dict."""
    from build_cub._helpers import load_toml

    return load_toml(MAIN_CONFIG_PATH)


@pytest.fixture
def project_build_data():
    """Load the actual project bear_build.toml as BuildData."""
    from build_cub._helpers import load_toml
    from build_cub.models._build_data import BuildData

    return BuildData.model_validate(load_toml(MAIN_CONFIG_PATH))


@pytest.fixture
def color_printer() -> ColorPrinter:
    from build_cub._printer import _print

    return _print


# ruff: noqa: PLC0415
