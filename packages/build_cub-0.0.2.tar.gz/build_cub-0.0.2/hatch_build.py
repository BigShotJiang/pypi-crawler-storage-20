"""A custom build hook that handles the build process."""

from __future__ import annotations

from functools import cached_property
from pathlib import Path
import re
from time import perf_counter
import tomllib
from typing import TYPE_CHECKING, Any, NamedTuple, Self

from dunamai import Vcs, Version as DunamaiVersion
from hatchling.builders.hooks.plugin.interface import BuildHookInterface

if TYPE_CHECKING:
    from collections.abc import Callable

# !!!!!!!!!!! THIS CODE IS REDUNDANT BEFORE BUILD_CUB IS INSTALLED !!!!!!!!!!! #


class BuildSettings(NamedTuple):
    build_settings: Path
    vcs: str
    style: str
    metadata: bool
    fallback_version: str

    @classmethod
    def load_from_file(cls, path: str) -> Self:
        """Load build settings from a TOML file."""
        import tomllib  # noqa: PLC0415

        try:
            with Path(path).open("rb") as f:
                data = tomllib.load(f)["tool"]["hatch"]["build"]["hooks"]["custom"]
                return cls(
                    build_settings=Path(data["build_settings"]),
                    vcs=data["vcs"],
                    style=data["style"],
                    metadata=data["metadata"],
                    fallback_version=data["fallback_version"],
                )
        except Exception as e:
            raise RuntimeError(f"Failed to load build settings from {path}") from e


def part_check[T](n: int, data: tuple[str, ...], expected_type: Callable[[str], T] = int) -> tuple[T, ...]:
    if len(data) != n:
        raise ValueError(f"Version string must have {n} parts: {data!r}")
    values = []
    for i, part in enumerate(data):
        try:
            values.append(expected_type(part))
        except ValueError as e:
            raise TypeError(f"Part {i} must be of type {expected_type.__name__}: {part}") from e
    return tuple(values)


class Version(NamedTuple):
    """A pydantic model to store version information."""

    major: int = 0
    minor: int = 0
    patch: int = 0

    def __bool__(self) -> bool:
        """Check if version is non-zero."""
        return any((self.major, self.minor, self.patch))

    def __str__(self) -> str:
        """Get the version as a string."""
        return f"{self.major}.{self.minor}.{self.patch}"

    @classmethod
    def from_version(cls, version: DunamaiVersion) -> Self:
        """Create a Version instance from a DunamaiVersion."""
        regex: re.Pattern[str] = re.compile(r"^(\d+)\.(\d+)\.(\d+)$")
        match: re.Match[str] | None = regex.match(version.base)
        if match:
            vals: tuple[int, ...] = part_check(n=3, data=match.groups(), expected_type=int)
            return cls(*vals)
        return cls()

    @classmethod
    def get_version(cls, build_settings: BuildSettings) -> Self:
        """Get version information from VCS or fallback."""
        try:
            return cls.from_version(DunamaiVersion.from_vcs(Vcs[build_settings.vcs.capitalize()]))
        except RuntimeError:
            return cls.from_version(DunamaiVersion(build_settings.fallback_version))


# HAS TO BE HERE FOR THE FIRST BUILD BEFORE UPLOADED TO PYPI
# IT is redundant when before build_cub is installed
class VersionBasePlugin:
    settings: BuildSettings

    @cached_property
    def load_toml(self) -> dict[str, Any]:
        """Load build configuration from a TOML file."""
        self.settings = BuildSettings.load_from_file("pyproject.toml")

        try:
            # Temporary to bootstrap until build_cub can be installed
            with Path(self.settings.build_settings).open("rb") as f:
                return next(iter(tomllib.load(f)["versioning"]["templates"]))
        except Exception as e:
            raise RuntimeError(f"Failed to load TOML file at {self.settings.build_settings}") from e

    @cached_property
    def version(self) -> Version:
        """Get the current version information."""
        return Version.get_version(self.settings)

    def get_version_data(self) -> dict[str, str]:
        """Get version data for the build process."""
        return {"version": str(self.version)}

    @property
    def output_path(self) -> Path:
        """Get the output path for the version file."""
        return Path(self.load_toml["output"])

    @property
    def content_template(self) -> str:
        """Get the content template for the version file."""
        return self.load_toml["content"]

    def render_template(self) -> None:
        """Render the template with the given variables."""
        from jinja2 import Template  # noqa: PLC0415

        template = Template(self.content_template)
        version: Version = self.version
        self.output_path.write_text(
            template.render(
                version=str(version),
                major=version.major,
                minor=version.minor,
                patch=version.patch,
            )
        )


class CustomBuildHook(VersionBasePlugin, BuildHookInterface):
    PLUGIN_NAME = "custom"

    def initialize(self, version: Any, build_data: dict[str, Any]) -> None:  # noqa: ARG002
        """Initialize the build hook."""
        start: float = perf_counter()
        self.render_template()
        end: float = perf_counter()
        elapsed: float = end - start
        print(f"Build hook completed in {elapsed:.2f} seconds.")
