- [ ] Collect all target files/exts upfront so all possible paths can be collected by one get_files call
- [ ] Add support for having the build options in pyproject.toml
- [ ] Make a new base class to suit more lightweight plugins like gperf, make them distinct from backends that need more true compilation like cython, c++, etc.
- [ ] Fallback for gperf binary stuff
- [ ] Make it so users can add their own plugins
- [ ] Make it so users can add their own backends 
    Basically we could make it easier to register plugins/backends with the system instead 
    of needing to cobble together stuff in different places. This will require a refactor of
    the config code however and might be more messy but would be more customizable and potentially
    less fragile.
- [ ] On a similar note, potentially support plugins for templating, ie, provide a way to use user defined Pydantic Classes?
- [/] Research what we would need to do in order to not require UV Dynamic Versioning (the specific module) (IN PROGRESS)
- [ ] Add pyo3 as a plugin
    This is not as straight forward as I had hoped, this requires: `maturin` or `setuptools-rust`
    ```python
    from setuptools_rust import RustExtension, Binding

    RustExtension(
        target="my_pkg.rust_lib",  # dotted module name (like Extension's name)
        path="Cargo.toml",
        binding=Binding.PyO3,
    )
    ```
    So you could create a RustBackend that:
    1. Inherits from CompileBackend (or CppBackendBase-like intermediate)
    2. Builds RustExtension objects instead of Extension
    3. Uses setuptools_rust.build_ext instead of regular build_ext

    The TOML config could look like:

    ```toml
    [rust]
    enabled = true
    targets = [
        { name = "my_pkg.fast", path = "Cargo.toml", binding = "PyO3" }
    ]
    ```
    Sources:
    - https://pypi.org/project/setuptools-rust/
    - https://setuptools-rust.readthedocs.io/en/latest/
    - https://github.com/PyO3/setuptools-rust

    ```python
    from build_cub.backends._base import BaseBackend
    class RustBackend(BaseBackend):
        def compile(self):
            import subprocess
            # Call maturin as a subprocess!
            subprocess.run([
                "maturin", "build",
                "--release",
                "--strip",
                # etc
            ])
    ```


#### Claude Review:

Item: Lightweight plugin base (gperf-style)
  Insanity Level: 🟢 Totally sane
  Notes: Already have a TODO comment in _base.py for this!
  ────────────────────────────────────────
  Item: Gperf binary fallback
  Insanity Level: 🟢 Sane
  Notes: You even have commented code showing the darwin/linux paths
  ────────────────────────────────────────
  Item: User-registered plugins
  Insanity Level: 🟡 Ambitious but doable
  Notes: Entry points would work nicely here
  ────────────────────────────────────────
  Item: User-registered backends
  Insanity Level: 🟡 Ambitious but doable
  Notes: Same pattern as plugins
  ────────────────────────────────────────
  Item: User-defined Pydantic classes for templates
  Insanity Level: 🟠 Getting spicy
  Notes: Could be powerful, also could be overengineered
  ────────────────────────────────────────
  Item: Cut uv-dynamic-versioning
  Insanity Level: 🟢 Already mostly done
  Notes: Your VersionBasePlugin in hatch_build.py is 90% there
  ────────────────────────────────────────
  Item: PyO3/Rust backend
  Insanity Level: 🟢 Very doable
  Notes: setuptools-rust fits your architecture perfectly
  The unifying theme: You're turning build-cub from a "build hook" into a pluggable build framework. That's not insane - that's ambitious in a good way.

  One thought: The user-registered plugins/backends idea is the big architectural decision. Once you support that, the rest falls into place (Rust becomes "just another registered backend"). Entry points ([project.entry-points."build_cub.backends"]) would be the clean way to do it.