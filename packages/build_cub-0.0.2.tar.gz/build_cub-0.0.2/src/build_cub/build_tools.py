"""Module defining a custom version source plugin for Hatchling using Dunamai."""

from dunamai import Vcs, Version
from hatchling.version.source.plugin.interface import VersionSourceInterface

# NOTE: WORK IN PROGRESS
# GIVE ME A BREAK ABOUT CODE IN THIS MODULE BEING UNTESTED AND INCOMPLETE


# TODO: Not ready to be used yet - needs to be integrated into build process
# Consider this a proof of concept for now
class BuildCubVersionSource(VersionSourceInterface):
    """A custom version source plugin that retrieves version information."""

    PLUGIN_NAME = "build-cub"

    def get_version_data(self) -> dict[str, str]:
        """Get version data from VCS or fallback."""
        try:
            version: Version = Version.from_vcs(Vcs.Git)
            return {"version": version.base}
        except RuntimeError:
            return {"version": "0.0.0"}  # fallback
