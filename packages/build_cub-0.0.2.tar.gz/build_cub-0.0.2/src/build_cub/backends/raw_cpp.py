"""Raw CPython API C++ compilation backend."""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from lazy_bear import lazy

from ._cpp_base import CppBackendBase

if TYPE_CHECKING:
    from build_cub._printer import ColorPrinter
    from build_cub.models._backends import RawCppSettings
    from build_cub.models._build_data import BuildData
else:
    RawCppSettings = lazy("build_cub.models._backends", "RawCppSettings")


class RawCppBackend(CppBackendBase[RawCppSettings]):
    """Raw CPython API C++ compilation backend."""

    name: str = "raw_cpp"
    _dependencies: ClassVar[list[str]] = ["setuptools"]
    _display_name: ClassVar[str] = "C++"

    def __init__(self, should_run: bool, settings: BuildData, printer: ColorPrinter) -> None:
        """Initialize the Raw C++ backend."""
        super().__init__(should_run, settings, printer)
