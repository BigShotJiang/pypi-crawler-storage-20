"""Build backends for bear-shelf.

Each backend handles a specific compilation technology:
- gperf: GNU perfect hash function generator (preprocessing)
- cython: Cython to C/C++ compilation
- raw_cpp: Raw CPython API C++ extensions
- pybind11: Pybind11 C++ bindings (not yet implemented)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from build_cub.backends._base import CompileBackend
    from build_cub.models._base import BaseBackendSettings
    from build_cub.models._build_data import BuildData

__all__ = ["run_backends"]


def run_backends(build_data: dict[str, Any], data: BuildData) -> None:
    """Run all enabled compilation backends in order.

    Order matters:
    1. gperf - generates headers that other backends may need
    2. cython - compiles .pyx files
    3. raw_cpp - compiles raw CPython API C++ files
    4. pybind11 - compiles pybind11 C++ files
    """
    from importlib import import_module

    from build_cub._printer import _print

    backend_configs: list[tuple[str, str, Any]] = [
        ("gperf", "GperfBackend", data.gperf),
        ("cython", "CythonBackend", data.cython),
        ("raw_cpp", "RawCppBackend", data.raw_cpp),
        ("pybind11", "Pybind11Backend", data.pybind11),
    ]

    if not any(settings.enabled for _, _, settings in backend_configs):
        _print.update("No compilation backends are enabled; skipping backend processing.", style="bold yellow")
        return

    for backend_name, backend_cls_name, settings in backend_configs:
        settings: BaseBackendSettings
        if not settings.enabled or not settings.targets:
            continue

        module = import_module(f"build_cub.backends.{backend_name}")
        backend_cls: type[CompileBackend] | None = getattr(module, backend_cls_name)
        if backend_cls is None:
            # TODO:  if debug: print warning about missing backend class
            continue
        backend: CompileBackend = backend_cls(should_run=True, settings=data, printer=_print)

        if backend.should_run:
            _print.update(f"Running [cyan]{backend.name}[/] backend...", style="bold cyan")
            backend.compile(build_data=build_data)


# ruff: noqa: PLC0415
