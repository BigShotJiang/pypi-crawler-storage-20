"""Pybind11 compilation backend."""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from lazy_bear import lazy

from ._cpp_base import CppBackendBase

if TYPE_CHECKING:
    from build_cub._printer import ColorPrinter
    from build_cub.models._backends import Pybind11Settings
    from build_cub.models._build_data import BuildData
else:
    Pybind11Settings = lazy("build_cub.models._backends", "Pybind11Settings")


class Pybind11Backend(CppBackendBase[Pybind11Settings]):
    """Pybind11 compilation backend."""

    name: str = "pybind11"
    _dependencies: ClassVar[list[str]] = ["pybind11", "setuptools"]
    _display_name: ClassVar[str] = "pybind11"
    _language: ClassVar[str | None] = "c++"

    def __init__(self, should_run: bool, settings: BuildData, printer: ColorPrinter) -> None:
        """Initialize the Pybind11 backend."""
        super().__init__(should_run, settings, printer)

    @property
    def extra_include_dirs(self) -> list[str]:
        """Add pybind11's include directory."""
        import pybind11

        return [pybind11.get_include()]


# ruff: noqa: PLC0415
