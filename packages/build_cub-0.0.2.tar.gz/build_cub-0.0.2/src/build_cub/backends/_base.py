"""Base class for compilation backends with shared compile() logic."""

from __future__ import annotations

from abc import ABC, abstractmethod
import sys
from typing import TYPE_CHECKING, Any, ClassVar

from lazy_bear import lazy

PYTHON_314_OR_NEWER: bool = sys.version_info >= (3, 14)

if TYPE_CHECKING:
    from collections.abc import Sequence
    from importlib.util import find_spec
    import os
    from pathlib import Path
    import shutil

    from setuptools import Distribution, Extension
    from setuptools.command.build_ext import build_ext

    from build_cub._printer import ColorPrinter
    from build_cub.models._base import BaseSettings
    from build_cub.models._build_data import BuildData
else:
    os = lazy("os")
    Path = lazy("pathlib", "Path")

    find_spec = lazy("importlib.util", "find_spec")
    Extension = lazy("setuptools", "Extension")
    Distribution = lazy("setuptools", "Distribution")
    build_ext = lazy("setuptools.command.build_ext", "build_ext")


def _copy_file(file: Path, dest: Path) -> None: ...


if PYTHON_314_OR_NEWER:

    def _314_copy_file(file: Path, dest: Path) -> None:
        file.copy_into(dest, follow_symlinks=True, preserve_metadata=True)

    _copy_file = _314_copy_file
else:
    shutil = lazy("shutil")

    def _pre_314_copy_file(file: Path, dest: Path) -> None:
        shutil.copy2(file, dest)

    _copy_file = _pre_314_copy_file


def copy_file(file: Path, dest: Path) -> None:
    """Copy a file to destination, creating parent directories if needed."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    _copy_file(file, dest)


# TODO: We should compile all file paths upfront and cache them rather than
# calling os.walk multiple times.
# That being said, os.walk is massively optimized in C so it is not a big deal
def get_files(pkg_root: Path, exts: Sequence[str]) -> list[Path]:
    """Recursively find files with specified extensions."""
    files: list[Path] = []
    for dirpath, _, filenames in os.walk(str(pkg_root)):
        for filename in filenames:
            if any(filename.endswith(e) for e in exts):
                files.append(Path(dirpath) / filename)
    return files


def has_dependency(package: str) -> bool:
    """Check if a package is available for import."""
    return find_spec(package) is not None


# TODO: Perhaps we should create one step further back Base class for "simpler"
# plugins like gperf that don't need all the CompileBackend logic?
# So the idea is that we would delineate between Backends (for true compilation)
# and Plugins where plugins can do pre/post processing but don't need all the
# complexity of compilation steps or setuptools Extension handling.
class CompileBackend[Settings_T: BaseSettings, Target_T](ABC):
    """Base class for compilation backends.

    Subclasses configure via class attributes:
        - name: Backend name matching the settings section (e.g., "cython", "pybind11")
        - _dependencies: Required packages to verify before running
        - _display_name: Human-readable name for log messages

    Subclasses MUST implement:
        - _get_targets() -> list of targets to compile
        - _get_extensions(targets) -> list[Extension] for setuptools
        - _get_target_names(targets) -> set[str] for artifact matching

    Subclasses MAY override hooks:
        - _pre_compile(extensions) -> wrap/transform extensions (e.g., cythonize)
        - _post_artifact_copy(dest) -> cleanup after each artifact copy
        - extra_include_dirs property -> add backend-specific include paths
    """

    name: str
    _dependencies: ClassVar[list[str]]
    _display_name: ClassVar[str] = "extension"
    _print: ColorPrinter
    should_run: bool
    settings: BuildData

    def __init__(self, should_run: bool, settings: BuildData, printer: ColorPrinter) -> None:
        """Initialize the backend."""
        self._print: ColorPrinter = printer
        self.should_run: bool = should_run
        self.settings: BuildData = settings
        self._cached_local_settings: Settings_T | None = None
        self._verify_dependencies()

    # -------------------------------------------------------------------------
    # Properties
    # -------------------------------------------------------------------------

    @property
    def local_settings(self) -> Settings_T:
        """Get the backend-specific settings section."""
        if self._cached_local_settings is None:
            self._cached_local_settings = getattr(self.settings, self.name)
            if self._cached_local_settings is None:
                raise RuntimeError(f"Backend settings for '{self.name}' not found in build data.")
        return self._cached_local_settings

    @property
    def extra_include_dirs(self) -> list[str]:
        """Override to add backend-specific include directories."""
        return []

    @property
    def _target_names(self) -> set[str]:
        """Extract target names for artifact matching.

        Args:
            targets: The list from _get_targets()

        Returns:
            Set of base names (e.g., {"core", "record"}) used to filter artifacts
        """
        return {t.name for t in self.local_settings.targets}

    # -------------------------------------------------------------------------
    # Static/Class utilities
    # -------------------------------------------------------------------------

    def _verify_dependencies(self) -> None:
        """Check that all required packages are available."""
        missing: list[str] = []
        for package in self._dependencies:
            if not has_dependency(package):
                missing.append(package)
        if missing:
            self.should_run = False
            self._print.warn(
                f"Missing dependencies for {self.name}: {', '.join(missing)}. Please install them to proceed."
            )

    def _get_targets(self) -> list[Target_T]:
        """Return the list of targets to compile.

        Returns:
            List of targets (Path for Cython, SourcesItem for C++ backends)
        """
        return self.local_settings.targets

    @staticmethod
    def _to_module_name(file: Path) -> str:
        """Convert a file path to a dotted module name."""
        parts: tuple[str, ...] = Path(file).with_suffix(suffix="").parts
        if parts[0] == "src":
            parts = parts[1:]
        return ".".join(parts)

    @staticmethod
    def _get_base_name(file: Path) -> str:
        """Extract base module name from compiled artifact (strips platform suffix)."""
        return file.stem.split(".")[0]

    @staticmethod
    def _get_files(pkg_root: Path, exts: Sequence[str]) -> list[Path]:
        """Recursively get files with specified extensions from pkg_root."""
        return get_files(pkg_root, exts)

    # -------------------------------------------------------------------------
    # Abstract methods - subclasses MUST implement
    # -------------------------------------------------------------------------

    @abstractmethod
    def _get_extensions(self, targets: list[Target_T]) -> list[Extension]:
        """Build Extension objects from targets.

        Args:
            targets: The list from _get_targets()

        Returns:
            List of setuptools Extension objects ready for compilation
        """

    # -------------------------------------------------------------------------
    # Hooks - subclasses MAY override
    # -------------------------------------------------------------------------

    def _pre_compile(self, extensions: list[Extension]) -> list[Extension]:
        """Hook called before compilation.

        Override to wrap or transform extensions (e.g., cythonize).
        Default implementation returns extensions unchanged.

        Args:
            extensions: List of Extension objects from _get_extensions()

        Returns:
            Transformed list of Extension objects for compilation
        """
        return extensions

    def _post_artifact_copy(self, dest: Path) -> None:  # noqa: ARG002
        """Hook called after each artifact is copied.

        Override to perform cleanup (e.g., remove Cython's .c/.cpp files).
        Default implementation does nothing.

        Args:
            dest: Path to the copied artifact
        """
        return

    # -------------------------------------------------------------------------
    # Artifact handling
    # -------------------------------------------------------------------------

    def _copy_artifacts(self, build_lib: Path, build_data: dict[str, Any], target_names: set[str]) -> list[Path]:
        """Copy compiled artifacts from build_lib to pkg_root.

        Only copies files whose stem (without platform suffix) matches one of the target_names.
        This prevents double-copying artifacts from previous backends.

        Args:
            build_lib: The setuptools build directory
            build_data: The hatch build_data dict to append artifacts to
            target_names: Set of base names (e.g. {"core", "record"}) to copy

        Returns:
            List of destination paths that were copied (for cleanup hooks)
        """
        files: list[Path] = get_files(build_lib, self.settings.lib_files)
        copied: list[Path] = []

        if "artifacts" not in build_data:
            build_data["artifacts"] = []

        for file in files:
            base_name: str = self._get_base_name(file)
            if base_name not in target_names:
                continue
            relative: Path = file.relative_to(build_lib)
            dest: Path = self.settings.pkg_root / relative
            copy_file(file, dest)
            build_data["artifacts"].append(str(dest))
            copied.append(dest)
            self._print.key_to_value("New Artifact", dest.name, indent=True)
            self._print.key_to_value(file.name, f"{dest.parent}/", indent=True)
        return copied

    # -------------------------------------------------------------------------
    # Main compilation logic
    # -------------------------------------------------------------------------

    def compile(self, *, build_data: dict[str, Any]) -> None:
        """Run compilation for this backend.

        This method orchestrates the full compilation pipeline:
        1. Get targets and validate
        2. Inject debug symbols if enabled
        3. Build extensions
        4. Apply pre-compile hook (e.g., cythonize)
        5. Run setuptools compilation
        6. Copy artifacts and run post-copy hooks
        7. Update build_data flags
        """
        if not self.should_run:
            return

        targets: list[Target_T] = self._get_targets()
        num_targets: int = len(targets)

        if num_targets == 0:
            self._print.warn(f"No {self._display_name} files configured to compile.")
            return

        extensions: list[Extension] = self._get_extensions(targets)
        extensions = self._pre_compile(extensions)

        self._print.update(
            f"Compiling [red]{num_targets}[/] {self._display_name} {'files' if num_targets > 1 else 'file'}...",
            style="cyan",
        )

        dist = Distribution({"ext_modules": extensions})
        cmd = build_ext(dist)
        cmd.ensure_finalized()
        cmd.run()

        build_lib = Path(cmd.build_lib)
        target_names: set[str] = self._target_names
        copied: list[Path] = self._copy_artifacts(build_lib, build_data, target_names)

        for dest in copied:
            self._post_artifact_copy(dest)

        self._print.success(f"{self._display_name} compilation successful!", indent=True)
        build_data["pure_python"] = False
        build_data["infer_tag"] = True
