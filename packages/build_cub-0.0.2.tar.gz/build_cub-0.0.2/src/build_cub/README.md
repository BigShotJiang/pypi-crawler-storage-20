# Build Cub

A modular build system for compiling Cython, C++, and pybind11 extensions.

## Architecture Overview

```
build_cub/
├── __init__.py
├── _helpers.py          # Shared utilities (get_files, get_parts, load_toml, platform detection)
├── _printer.py          # Rich console output formatting
├── _settings.py         # Pydantic models for shared settings (CompilerSettings, etc.)
├── _version.py          # Version extraction from VCS (dunamai)
├── load_build_toml.py   # Main config loader, BuildData model, template rendering
└── backends/
    ├── __init__.py      # Orchestrator (run_backends)
    ├── _base.py         # ABC base class for all backends
    ├── _protocol.py     # Protocol definition (for type checking)
    ├── cython.py        # Cython compilation backend
    ├── gperf.py         # GNU perfect hash generator backend
    ├── pybind11.py      # Pybind11 compilation backend
    └── raw_cpp.py       # Raw CPython API C++ backend
```

## Configuration

All build settings live in `bear_build.toml` at the project root. The config uses a **defaults + override** pattern:

- `[defaults]` - Base compiler/linker settings inherited by all backends
- `[cython]`, `[pybind11]`, `[raw_cpp]`, `[gperf]` - Backend-specific settings that can override defaults

### Key Sections

```toml
[general]
name = "build_cub"
enabled = true               # Master switch for all compilation

[defaults.settings]
extra_compile_args = [...]   # Unix/macOS compiler args
extra_compile_args_windows = [...]  # Windows compiler args
include_dirs = [...]

[cython]
enabled = true
targets = ["src/build_cub/foo.pyx", ...]  # Explicit file list
# [cython.settings] can override defaults

[pybind11]
enabled = true
targets = ["src/build_cub/_cpp/bar.cpp", ...]

[raw_cpp]
enabled = true
targets = ["src/build_cub/_cpp/baz.cpp", ...]
```

## How Backends Work

Each backend follows the same pattern:

1. **Initialization** - Receives `BuildData` config, verifies dependencies
2. **Compilation** - Uses setuptools to build extensions
3. **Artifact copying** - Copies `.so`/`.pyd` files to source tree
4. **Cleanup** - Removes intermediate files (Cython generates `.c`/`.cpp`)

### Base Class (`_base.py`)

All backends inherit from `CompileBackend` ABC which provides:

- `_verify_dependencies()` - Checks if required packages are installed
- `_copy_artifacts()` - Copies compiled files, filters by target name to avoid duplicates
- Abstract `compile()` and `_cleanup()` methods

### Settings Inheritance

The `BuildData.model_validator` handles settings inheritance:

1. Load TOML into Pydantic models
2. For each backend, check if it has custom compiler settings
3. If `backend.settings.no_custom_args` is True, replace with `defaults.settings`

This means backends only need to specify overrides (e.g., Cython doesn't need `-std=c++20`).

## Adding a New Backend

1. Create `backends/my_backend.py`:
```python
class MyBackend(CompileBackend):
    name = "my_backend"
    _dependencies = ["my_library", "setuptools"]

    def _cleanup(self, **kwargs): ...
    def compile(self, *, build_data): ...
```

2. Add settings class in `load_build_toml.py`:
```python
class MyBackendSettings(BaseBackendSettings):
    name: str = "my_backend"
    # Add any backend-specific fields
```

3. Add to `BuildData`:
```python
my_backend: MyBackendSettings = MyBackendSettings()
```

4. Add to orchestrator in `backends/__init__.py`:
```python
backend_configs = [
    ...
    (MyBackend, data.my_backend.enabled),
]
```

5. Add TOML section in `bear_build.toml`

## Platform Handling

Platform-specific compiler args are handled via Pydantic's `validation_alias`:

```python
# In _helpers.py
IS_WINDOWS = platform == "win32"
COMPILER_ARGS_KEY = "extra_compile_args_windows" if IS_WINDOWS else "extra_compile_args"

# In _settings.py
extra_compile_args: list[str] = Field(validation_alias=COMPILER_ARGS_KEY)
```

This automatically picks up the correct args based on the current platform.

## Template System

Version files are generated from Jinja2 templates defined in `[versioning.templates]`:

An example would be this how they are defined in `build_cub` but might be defined differently in other repos:

- `python` template → `src/build_cub/_internal/_version.py`
- `cpp` template → `src/build_cub/_cpp/_version.hpp`

Templates have access to: `version`, `united_data`, `schema` dicts from config.

## Testing

Tests live in `tests/test_build_cub.py` covering:

- TOML loading and validation
- Settings inheritance
- Template rendering
- Backend initialization
- Platform-specific settings
- Helper functions

Run with: `source .venv/bin/activate && pytest -- tests/test_build_cub.py`
