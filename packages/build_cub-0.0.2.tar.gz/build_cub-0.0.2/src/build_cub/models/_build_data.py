from __future__ import annotations

from functools import cached_property
from pathlib import Path
from typing import TYPE_CHECKING, Any, Self

from pydantic import BaseModel, ConfigDict, model_validator

from build_cub._helpers import load_toml

from ._backends import CythonSettings, GperfSettings, Pybind11Settings, RawCppSettings
from ._defaults import DefaultSettings, GeneralSettings
from ._templates import VersioningSettings

if TYPE_CHECKING:
    from ._base import BaseBackendSettings, BaseSettings
    from ._version import Version

ALL_BACKENDS: list[str] = ["gperf", "cython", "raw_cpp", "pybind11"]


def _get_base_backend(base_setting: BaseSettings) -> BaseBackendSettings:
    return base_setting  # type: ignore[return-value]


class BuildData(BaseModel):
    """Root model that maps to the entire bear_build.toml file."""

    general: GeneralSettings = GeneralSettings()
    defaults: DefaultSettings = DefaultSettings()

    gperf: GperfSettings = GperfSettings()
    cython: CythonSettings = CythonSettings()
    pybind11: Pybind11Settings = Pybind11Settings()
    raw_cpp: RawCppSettings = RawCppSettings()

    versioning: VersioningSettings = VersioningSettings()

    model_config = ConfigDict(extra="ignore")

    def _enable_debug_symbols(self, backend: BaseBackendSettings) -> None:
        """Enable debug symbols in all compiler settings if general.debug_symbols is True."""
        if self.general.debug_symbols:
            base_backend: BaseBackendSettings = backend  # type: ignore[assignment]
            base_backend.settings.extra_compile_args.append("-g")

    @model_validator(mode="after")
    def validate_settings(self) -> Self:
        """Post-initialization to set up compiler settings inheritance."""
        for backend_name in ALL_BACKENDS:
            backend: BaseSettings
            backend = getattr(self, backend_name)
            if not hasattr(backend, "settings"):
                continue
            if not backend.enabled:
                continue
            if not backend.has_targets:
                continue
            base_backend: BaseBackendSettings = _get_base_backend(backend)
            base_backend.settings.merge_with_defaults(self.defaults.settings)
            self._enable_debug_symbols(base_backend)
        return self

    ###########################################################################################
    # Properties
    ###########################################################################################

    @property
    def lib_files(self) -> list[str]:
        """Get the list of library files to include in build."""
        return self.defaults.output_files.lib_files

    @cached_property
    def pkg_root(self) -> Path:
        """Find package root - handles both src layout and flat layout (from sdist)."""
        src_layout = Path(f"src/{self.general.name}")
        flat_layout = Path(self.general.name)
        if src_layout.exists():
            return Path("src")
        if flat_layout.exists():
            return Path(".")
        raise FileNotFoundError(
            f"Cannot find package directory for '{self.general.name}'. "
            f"Checked: {src_layout} (src layout), {flat_layout} (flat layout)"
        )

    ###########################################################################################
    # Template Rendering
    ###########################################################################################

    @cached_property
    def template_variables(self) -> dict[str, Any]:
        """Get all variables for template rendering.

        Combines:
        - version: Auto-injected from VCS (always available)
        - User-defined variables from [versioning.variables]
        """
        variables: dict[str, Any] = {
            "version": self.general.version.model_dump(),
        }
        # Add user-defined variables
        for key, value in self.versioning.variables.items():
            if hasattr(value, "model_dump"):
                variables[key] = value.model_dump()
            else:
                variables[key] = value
        return variables

    def render_templates(self) -> list[Path]:
        """Render all templates and write to their output paths.

        Returns:
            List of output paths that were written.
        """
        if not self.versioning.has_templates:
            return []

        written: list[Path] = []
        for template in self.versioning.templates:
            if template.content and template.output:
                output_path = template.write(self.template_variables)
                written.append(output_path)
        return written

    ###########################################################################################
    # Loading
    ###########################################################################################

    @classmethod
    def load_from_file(cls, path: Path | str, version: Version) -> Self:
        """Load build configuration from a TOML file."""
        from build_cub._printer import _print  # noqa: PLC0415

        try:
            validated = cls.model_validate(load_toml(path))
            validated.general.version = version
            return validated
        except Exception as e:
            _print.error(f"Error loading build configuration from {path}: {e}")
            raise
