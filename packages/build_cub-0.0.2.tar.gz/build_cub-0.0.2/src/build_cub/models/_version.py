from __future__ import annotations

from typing import TYPE_CHECKING, Self

from dunamai import Version as DunamaiVersion
from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from collections.abc import Callable

    from uv_dynamic_versioning.schemas import UvDynamicVersioning


class Version(BaseModel):
    """A pydantic model to store version information."""

    major: int = Field(default=0)
    minor: int = Field(default=0)
    patch: int = Field(default=0)

    def __bool__(self) -> bool:
        """Check if version is non-zero."""
        return any((self.major, self.minor, self.patch))

    @classmethod
    def get_version(cls, config: UvDynamicVersioning) -> Self:
        """Get version information from VCS or fallback."""

        def part_check[T](n: int, data: tuple, expected_type: Callable[[str], T] = int) -> tuple[T, ...]:
            if len(data) != n:
                raise ValueError(f"Version string must have {n} parts: {data!r}")
            values = []
            for i, part in enumerate(data):
                try:
                    values.append(expected_type(part))
                except ValueError as e:
                    raise TypeError(f"Part {i} must be of type {expected_type.__name__}: {part}") from e
            return tuple(values)

        def from_version(version: DunamaiVersion) -> Self:
            version_str: str = version.base
            if "-" in version_str:
                version_str = version_str.split("-")[0]
            if "+" in version_str:
                version_str = version_str.split("+")[0]
            major, minor, patch = part_check(n=3, data=tuple(version_str.split(".")))
            return cls(
                major=major,
                minor=minor,
                patch=patch,
            )

        try:
            return from_version(
                DunamaiVersion.from_vcs(
                    config.vcs,
                    latest_tag=config.latest_tag,
                    strict=config.strict,
                    tag_branch=config.tag_branch,
                    tag_dir=config.tag_dir,
                    full_commit=config.full_commit,
                    ignore_untracked=config.ignore_untracked,
                    pattern=config.pattern,
                    pattern_prefix=config.pattern_prefix,
                    commit_length=config.commit_length,
                )
            )
        except RuntimeError as e:
            if config.fallback_version:
                return from_version(DunamaiVersion(config.fallback_version))
            raise RuntimeError("Failed to get version from VCS and no fallback version specified.") from e


DEFAULT_VERSION = Version()
