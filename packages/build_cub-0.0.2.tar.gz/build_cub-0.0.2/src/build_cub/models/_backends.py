"""Models for build backend settings in bear_build.toml."""

from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field

from build_cub._helpers import PreAllocatedList

from ._base import BaseBackendSettings, BaseSettings, SourcesItem


class GperfSettings(BaseSettings[Path]):
    """Maps to [gperf] section."""

    model_config = ConfigDict(extra="ignore")

    binary: str = Field(default="")
    language: str = Field(default="C++")
    options: list[str] = Field(default_factory=list)
    target_ext: str = Field(default="")

    @property
    def cmd(self) -> PreAllocatedList[str]:
        """Command snippet for subprocess."""
        return PreAllocatedList(5, "", self.binary, "-L", self.language if self.language else "ANSI-C")


class CompilerDirectives(BaseModel):
    """Maps to [cython.compiler_directives] - Cython-specific compiler options."""

    model_config = ConfigDict(extra="ignore")

    language_level: str = "3"
    embedsignature: bool = Field(default=True)
    boundscheck: bool = Field(default=False)
    wraparound: bool = Field(default=False)
    nonecheck: bool = Field(default=False)
    cdivision: bool = Field(default=True)
    initializedcheck: bool = Field(default=False)
    freethreading_compatible: bool | None = None
    overflowcheck: bool | None = None
    profile: bool | None = None
    linetrace: bool | None = None
    generate_cleanup_code: bool | None = None
    cimport_from_pyx: bool | None = None


class CythonSettings(BaseBackendSettings[Path]):
    """Maps to [cython] section."""

    name: str = "cython"
    annotate: bool = Field(default=False)
    quiet: bool = Field(default=True)
    compiler_directives: CompilerDirectives = Field(default_factory=CompilerDirectives)


class Pybind11Settings(BaseBackendSettings[SourcesItem]):
    """Maps to [pybind11] section."""

    name: str = "pybind11"


class RawCppSettings(BaseBackendSettings[SourcesItem]):
    """Maps to [raw_cpp] section."""

    name: str = "raw_cpp"


__all__ = [
    "CompilerDirectives",
    "CythonSettings",
    "GperfSettings",
    "Pybind11Settings",
    "RawCppSettings",
]
