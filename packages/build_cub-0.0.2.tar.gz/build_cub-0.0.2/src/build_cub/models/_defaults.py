from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from build_cub._helpers import COMPILER_ARGS_KEY, LINK_ARGS_KEY, get_default_output_files
from build_cub.models._version import DEFAULT_VERSION, Version


class CompilerSettings(BaseModel):
    """Maps to [defaults.settings] or [backend.settings] - compiler/linker configuration.

    Uses validation_alias to automatically pick the correct platform-specific args
    (extra_compile_args vs extra_compile_args_windows) based on IS_WINDOWS.
    """

    extra_compile_args: list[str] = Field(default_factory=list, validation_alias=COMPILER_ARGS_KEY)
    extra_link_args: list[str] = Field(default_factory=list, validation_alias=LINK_ARGS_KEY)

    include_dirs: list[str] = Field(default_factory=list)
    library_dirs: list[str] = Field(default_factory=list)
    libraries: list[str] = Field(default_factory=list)

    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    @property
    def no_custom_args(self) -> bool:
        """Check if any custom compiler or linker args are set."""
        return not bool(
            self.extra_compile_args or self.extra_link_args or self.include_dirs or self.library_dirs or self.libraries
        )

    def merge_with_defaults(self, defaults: CompilerSettings) -> None:
        """Merge this settings with defaults - only inheriting fields we didn't customize."""
        self.extra_compile_args = self.extra_compile_args or defaults.extra_compile_args
        self.extra_link_args = self.extra_link_args or defaults.extra_link_args
        self.include_dirs = self.include_dirs or defaults.include_dirs
        self.library_dirs = self.library_dirs or defaults.library_dirs
        self.libraries = self.libraries or defaults.libraries


class GeneralSettings(BaseModel):
    """Maps to [general] in bear_build.toml."""

    name: str = Field(default="")
    enabled: bool = Field(default=False)
    debug_symbols: bool = Field(default=False)
    version: Version = Field(default=DEFAULT_VERSION)


class OutputFiles(BaseModel):
    """Maps to [defaults.output_files] - what file extensions to look for after compilation."""

    lib_files: list[str] = Field(default_factory=get_default_output_files)


class DefaultSettings(BaseModel):
    """Maps to [defaults] section - base settings inherited by all backends."""

    output_files: OutputFiles = Field(default_factory=OutputFiles)
    settings: CompilerSettings = Field(default_factory=CompilerSettings)


__all__ = [
    "CompilerSettings",
    "DefaultSettings",
    "GeneralSettings",
    "OutputFiles",
]
