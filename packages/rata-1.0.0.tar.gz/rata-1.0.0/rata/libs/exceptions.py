class RecordOverlap(Exception):
    pass
