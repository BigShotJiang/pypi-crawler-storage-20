# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "limitry"
__version__ = "0.5.2"  # x-release-please-version
