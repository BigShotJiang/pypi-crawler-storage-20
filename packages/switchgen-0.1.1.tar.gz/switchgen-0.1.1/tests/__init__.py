"""SwitchGen test suite."""
