# Exorous Code

A professional AI coding agent that can execute tasks using tools and manage complex development workflows.

## Prerequisites

- **Python 3.10 or higher** is required.

## Installation

Install via PyPI:

```bash
pip install exorous
```

Alternatively, install directly from the source:

```bash
pip install .
```

Or if you are developing:

```bash
pip install -e .
```

## Usage

Start the interactive coding agent:

```bash
exorous
```

On the first run, Exorous will prompt you to:
1. Select your preferred LLM provider (OpenRouter, OpenAI, Anthropic, or Gemini).
2. Enter your API key for the selected provider.

Alternatively, run a single prompt:

```bash
exorous "Refactor the main.py file"
```
- Multi-turn conversations with tool calling
- Configurable model settings and temperature

### Built-in Tools

- File operations: read, write, edit files
- Directory operations: list directories, search with glob patterns
- Text search: grep for pattern matching
- Shell execution: run shell commands
- Web access: search and fetch web content
- Memory: store and retrieve information
- Todo: manage task lists

### Context Management

- Automatic context compression when approaching token limits
- Tool output pruning to manage context size
- Token usage tracking

### Safety and Approval

- Multiple approval policies: on-request, auto, never, yolo
- Dangerous command detection and blocking
- Path-based safety checks
- User confirmation prompts for mutating operations

### Session Management

- Save and resume sessions
- Create checkpoints
- Persistent session storage

### MCP Integration

- Connect to Model Context Protocol servers
- Use tools from MCP servers
- Support for stdio and HTTP/SSE transports

### Subagents

- Specialized subagents for specific tasks
- Built-in subagents: codebase investigator, code reviewer
- Configurable subagent definitions with custom tools and limits

### Loop Detection

- Detects repeating actions
- Prevents infinite loops in agent execution

### Hooks System

- Execute scripts before/after agent runs
- Execute scripts before/after tool calls
- Error handling hooks
- Custom commands and scripts

### Configuration

- Configurable working directory
- Tool allowlisting
- Developer and user instructions
- Shell environment policies
- MCP server configuration

### Advanced Intelligence

- **Semantic Search (RAG)**: Index the entire codebase into a local vector database (ChromaDB) for meaning-based code retrieval.
- **AST-based Chunking**: Intelligent code splitting for high-fidelity semantic search.
- **Knowledge Graph**: Full symbol map (functions, classes, imports) with cross-file relationship tracking.
- **Real-time Indexing**: Automatic background updates as you modify your code.
- **Long-Term Memory**: Persistent project-wide conventions and decisions that survive session restarts.

### User Interface

- Terminal UI with formatted output
- Command interface: /help, /config, /tools, /mcp, /stats, /save, /resume, /checkpoint, /restore
- Real-time tool call visualization
