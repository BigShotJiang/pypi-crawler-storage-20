from .protocols import SupportsMul
