"""
agcheck - Antigravity Token Usage Checker

A CLI tool to monitor your Antigravity AI usage quotas.
"""

__version__ = "1.0.0"
__author__ = "Matias Fernandez"

from .cli import main

__all__ = ["main", "__version__"]
