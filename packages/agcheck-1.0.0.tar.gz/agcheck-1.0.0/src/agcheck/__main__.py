"""Allow running the package with python -m agcheck."""
from agcheck.cli import main
import sys

if __name__ == "__main__":
    sys.exit(main())
