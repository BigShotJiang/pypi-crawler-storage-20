#!/usr/bin/env python3
"""
Antigravity Token Checker - CLI tool to check usage quotas for Antigravity
Based on CodexBar implementation: https://github.com/steipete/CodexBar
"""

import subprocess
import re
import json
import ssl
import urllib.request
import urllib.error
import sys
import time
import os
import argparse
from datetime import datetime, timezone
from typing import Optional, Tuple, List, Dict, Any
import uuid

# ANSI Colors
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    RESET = '\033[0m'


def clear_screen():
    """Clear terminal screen."""
    os.system('clear' if os.name != 'nt' else 'cls')


def detect_antigravity_process() -> Optional[Tuple[int, str, Optional[int]]]:
    """
    Detects the Antigravity language server process.
    Returns: (pid, csrf_token, extension_port) or None
    """
    try:
        result = subprocess.run(
            ['ps', '-ax', '-o', 'pid=,command='],
            capture_output=True, text=True, timeout=10
        )
        
        for line in result.stdout.splitlines():
            line = line.strip()
            if not line:
                continue
                
            parts = line.split(maxsplit=1)
            if len(parts) != 2:
                continue
                
            try:
                pid = int(parts[0])
            except ValueError:
                continue
                
            command = parts[1].lower()
            
            # Check if it's Antigravity language server
            if 'language_server_macos' not in command:
                continue
            if '--app_data_dir' not in command or 'antigravity' not in command:
                if '/antigravity/' not in command:
                    continue
            
            # Extract CSRF token
            csrf_match = re.search(r'--csrf_token[=\s]+(\S+)', parts[1], re.IGNORECASE)
            if not csrf_match:
                continue
            csrf_token = csrf_match.group(1)
            
            # Extract extension port (optional)
            port_match = re.search(r'--extension_server_port[=\s]+(\d+)', parts[1], re.IGNORECASE)
            ext_port = int(port_match.group(1)) if port_match else None
            
            return (pid, csrf_token, ext_port)
            
    except subprocess.TimeoutExpired:
        pass
    except Exception as e:
        print(f"{Colors.RED}Error detecting process: {e}{Colors.RESET}")
    
    return None


def get_listening_ports(pid: int) -> List[int]:
    """Gets all TCP listening ports for a given PID."""
    lsof_paths = ['/usr/sbin/lsof', '/usr/bin/lsof']
    lsof = None
    
    for path in lsof_paths:
        try:
            subprocess.run([path, '-v'], capture_output=True, timeout=2)
            lsof = path
            break
        except:
            continue
    
    if not lsof:
        return []
    
    try:
        result = subprocess.run(
            [lsof, '-nP', '-iTCP', '-sTCP:LISTEN', '-a', '-p', str(pid)],
            capture_output=True, text=True, timeout=10
        )
        
        ports = set()
        for match in re.finditer(r':(\d+)\s+\(LISTEN\)', result.stdout):
            ports.add(int(match.group(1)))
        
        return sorted(ports)
        
    except Exception:
        return []


def make_request(port: int, path: str, csrf_token: str, body: Dict[str, Any], use_https: bool = True, fresh: bool = False) -> Optional[bytes]:
    """Makes a request to the Antigravity language server."""
    scheme = 'https' if use_https else 'http'
    url = f"{scheme}://127.0.0.1:{port}{path}"
    
    # Add unique request ID to force fresh data
    if fresh:
        body = body.copy()
        body['requestId'] = str(uuid.uuid4())
        body['timestamp'] = int(time.time() * 1000)
    
    data = json.dumps(body).encode('utf-8')
    
    headers = {
        'Content-Type': 'application/json',
        'Content-Length': str(len(data)),
        'Connect-Protocol-Version': '1',
        'X-Codeium-Csrf-Token': csrf_token,
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'X-Request-ID': str(uuid.uuid4())
    }
    
    # Create SSL context that doesn't verify (self-signed cert)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    
    try:
        req = urllib.request.Request(url, data=data, headers=headers, method='POST')
        with urllib.request.urlopen(req, timeout=8, context=ctx if use_https else None) as response:
            return response.read()
    except Exception:
        return None


def find_working_port(ports: List[int], csrf_token: str) -> Optional[int]:
    """Finds the first port that responds to API requests."""
    test_body = {
        "context": {
            "properties": {
                "devMode": "false",
                "ide": "antigravity",
                "os": "macos"
            }
        }
    }
    
    for port in ports:
        result = make_request(
            port,
            "/exa.language_server_pb.LanguageServerService/GetUnleashData",
            csrf_token,
            test_body
        )
        if result is not None:
            return port
    
    return None


def get_user_status(port: int, csrf_token: str, fresh: bool = True) -> Optional[Dict]:
    """Fetches user status from the language server."""
    body = {
        "metadata": {
            "ideName": "antigravity",
            "extensionName": "antigravity",
            "ideVersion": "unknown",
            "locale": "en"
        }
    }
    
    # Try GetUserStatus first
    result = make_request(
        port,
        "/exa.language_server_pb.LanguageServerService/GetUserStatus",
        csrf_token,
        body,
        fresh=fresh
    )
    
    if result:
        try:
            return json.loads(result)
        except:
            pass
    
    # Fallback to GetCommandModelConfigs
    result = make_request(
        port,
        "/exa.language_server_pb.LanguageServerService/GetCommandModelConfigs",
        csrf_token,
        body,
        fresh=fresh
    )
    
    if result:
        try:
            return json.loads(result)
        except:
            pass
    
    return None


def parse_reset_time(reset_time: Optional[str]) -> Optional[datetime]:
    """Parse reset time from ISO-8601 or epoch seconds."""
    if not reset_time:
        return None
        
    try:
        return datetime.fromisoformat(reset_time.replace('Z', '+00:00'))
    except:
        pass
    
    try:
        return datetime.fromtimestamp(float(reset_time), tz=timezone.utc)
    except:
        pass
    
    return None


def time_until(dt: datetime) -> str:
    """Returns human-readable time until a given datetime."""
    now = datetime.now(timezone.utc)
    delta = dt - now
    
    if delta.total_seconds() < 0:
        return "expired"
    
    hours, remainder = divmod(int(delta.total_seconds()), 3600)
    minutes, _ = divmod(remainder, 60)
    
    if hours > 0:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"


def progress_bar(percent: float, width: int = 20) -> str:
    """Creates a visual progress bar."""
    filled = int(width * percent / 100)
    empty = width - filled
    
    if percent >= 70:
        color = Colors.GREEN
    elif percent >= 30:
        color = Colors.YELLOW
    else:
        color = Colors.RED
    
    bar = f"{color}{'█' * filled}{Colors.DIM}{'░' * empty}{Colors.RESET}"
    return f"[{bar}]"


def get_model_priority(label: str) -> int:
    """Returns priority for sorting models (lower = higher priority)."""
    lower = label.lower()
    
    # Priority order: Claude Sonnet > Claude Opus > Gemini Pro > Gemini Flash > Others
    if 'claude' in lower:
        if 'sonnet' in lower:
            if 'thinking' not in lower:
                return 1
            return 2
        if 'opus' in lower:
            return 3
        return 4
    if 'gemini' in lower:
        if 'pro' in lower:
            if 'high' in lower:
                return 5
            return 6
        if 'flash' in lower:
            return 7
        return 8
    return 10


def display_results(data: Dict, compact: bool = False) -> None:
    """Display the quota results in a nice format."""
    now = datetime.now().strftime("%H:%M:%S")
    
    if not compact:
        print()
        print(f"{Colors.BOLD}{Colors.CYAN}╔══════════════════════════════════════════════════════╗{Colors.RESET}")
        print(f"{Colors.BOLD}{Colors.CYAN}║      🚀 ANTIGRAVITY TOKEN USAGE CHECKER              ║{Colors.RESET}")
        print(f"{Colors.BOLD}{Colors.CYAN}╚══════════════════════════════════════════════════════╝{Colors.RESET}")
        print()
    
    # Account info
    user_status = data.get('userStatus', {})
    email = user_status.get('email')
    plan_status = user_status.get('planStatus', {})
    plan_info = plan_status.get('planInfo', {})
    
    plan_name = (
        plan_info.get('planDisplayName') or 
        plan_info.get('displayName') or 
        plan_info.get('productName') or 
        plan_info.get('planName') or 
        'Unknown'
    )
    
    if not compact:
        if email:
            print(f"  {Colors.BOLD}Account:{Colors.RESET} {email}")
        print(f"  {Colors.BOLD}Plan:{Colors.RESET}    {plan_name}")
        print(f"  {Colors.DIM}Updated: {now}{Colors.RESET}")
        print()
        print(f"  {Colors.DIM}{'─' * 50}{Colors.RESET}")
        print()
    else:
        print(f"\n  {Colors.DIM}[{now}] {email} ({plan_name}){Colors.RESET}")
    
    # Model quotas
    model_configs = user_status.get('cascadeModelConfigData', {}).get('clientModelConfigs', [])
    if not model_configs:
        model_configs = data.get('clientModelConfigs', [])
    
    if not model_configs:
        print(f"  {Colors.YELLOW}No quota information available{Colors.RESET}")
        return
    
    # Sort by priority
    model_configs = sorted(model_configs, key=lambda x: get_model_priority(x.get('label', '')))
    
    if not compact:
        print(f"  {Colors.BOLD}Model Quotas:{Colors.RESET}")
        print()
    
    for config in model_configs:
        label = config.get('label', 'Unknown')
        quota_info = config.get('quotaInfo', {})
        remaining = quota_info.get('remainingFraction')
        reset_time = quota_info.get('resetTime')
        
        if remaining is None:
            continue
        
        percent = remaining * 100
        used_percent = 100 - percent
        bar = progress_bar(percent)
        
        reset_str = ""
        if reset_time:
            dt = parse_reset_time(reset_time)
            if dt:
                reset_str = f" {Colors.DIM}↻ {time_until(dt)}{Colors.RESET}"
        
        if compact:
            # Compact single-line format
            short_label = label[:25].ljust(25)
            print(f"  {short_label} {bar} {percent:5.1f}%{reset_str}")
        else:
            print(f"  {Colors.BOLD}{label:35}{Colors.RESET}")
            print(f"    {bar} {percent:5.1f}% remaining | {Colors.DIM}{used_percent:.1f}% used{Colors.RESET}{reset_str}")
            print()


def watch_mode(port: int, csrf_token: str, interval: int = 5) -> None:
    """Continuously monitor quotas with live updates."""
    print(f"{Colors.DIM}Starting watch mode (refresh every {interval}s). Press Ctrl+C to exit.{Colors.RESET}")
    
    try:
        while True:
            clear_screen()
            data = get_user_status(port, csrf_token, fresh=True)
            
            if data:
                display_results(data, compact=False)
                print(f"\n  {Colors.DIM}Refreshing in {interval}s... (Ctrl+C to exit){Colors.RESET}")
            else:
                print(f"{Colors.RED}Failed to fetch data. Retrying...{Colors.RESET}")
            
            time.sleep(interval)
            
    except KeyboardInterrupt:
        print(f"\n\n{Colors.DIM}Watch mode stopped.{Colors.RESET}\n")


def main():
    parser = argparse.ArgumentParser(
        description='Check Antigravity AI usage quotas',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s              # Single check
  %(prog)s -w           # Watch mode (refresh every 5s)
  %(prog)s -w -i 10     # Watch mode with 10s interval
  %(prog)s -c           # Compact output
  %(prog)s --json       # JSON output for scripting
        """
    )
    parser.add_argument('-w', '--watch', action='store_true', help='Watch mode with live updates')
    parser.add_argument('-i', '--interval', type=int, default=5, help='Refresh interval in seconds (default: 5)')
    parser.add_argument('-c', '--compact', action='store_true', help='Compact output format')
    parser.add_argument('--json', action='store_true', help='Output raw JSON')
    
    args = parser.parse_args()
    
    if not args.json:
        print(f"\n{Colors.DIM}Detecting Antigravity process...{Colors.RESET}")
    
    # Step 1: Detect process
    process_info = detect_antigravity_process()
    if not process_info:
        if args.json:
            print(json.dumps({"error": "Antigravity not running"}))
        else:
            print(f"\n{Colors.RED}✗ Antigravity is not running.{Colors.RESET}")
            print(f"  {Colors.DIM}Please launch Antigravity and try again.{Colors.RESET}\n")
        return 1
    
    pid, csrf_token, ext_port = process_info
    if not args.json:
        print(f"{Colors.DIM}Found Antigravity (PID: {pid}){Colors.RESET}")
    
    # Step 2: Get listening ports
    if not args.json:
        print(f"{Colors.DIM}Discovering ports...{Colors.RESET}")
    ports = get_listening_ports(pid)
    
    if not ports:
        if args.json:
            print(json.dumps({"error": "No listening ports found"}))
        else:
            print(f"\n{Colors.RED}✗ No listening ports found.{Colors.RESET}")
            print(f"  {Colors.DIM}Try again in a few seconds.{Colors.RESET}\n")
        return 1
    
    # Step 3: Find working port
    if not args.json:
        print(f"{Colors.DIM}Connecting to API...{Colors.RESET}")
    working_port = find_working_port(ports, csrf_token)
    
    if not working_port:
        if args.json:
            print(json.dumps({"error": "Could not connect to API"}))
        else:
            print(f"\n{Colors.RED}✗ Could not connect to Antigravity API.{Colors.RESET}\n")
        return 1
    
    # Watch mode
    if args.watch:
        watch_mode(working_port, csrf_token, args.interval)
        return 0
    
    # Step 4: Get user status
    data = get_user_status(working_port, csrf_token, fresh=True)
    
    if not data:
        if args.json:
            print(json.dumps({"error": "Failed to fetch quota information"}))
        else:
            print(f"\n{Colors.RED}✗ Failed to fetch quota information.{Colors.RESET}\n")
        return 1
    
    # Step 5: Display results
    if args.json:
        print(json.dumps(data, indent=2))
    else:
        display_results(data, compact=args.compact)
    
    return 0


if __name__ == "__main__":
    exit(main())
