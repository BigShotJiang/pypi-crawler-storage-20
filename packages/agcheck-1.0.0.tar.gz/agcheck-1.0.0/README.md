# agcheck 🚀

[![PyPI version](https://badge.fury.io/py/agcheck.svg)](https://badge.fury.io/py/agcheck)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A simple CLI tool to check your **Antigravity AI** usage quotas directly from the terminal.

Based on [CodexBar](https://github.com/steipete/CodexBar) implementation.

## Installation

```bash
pip install agcheck
```

## Requirements

- Python 3.7+
- macOS (uses `lsof` for port detection)
- Antigravity app must be running

## Usage

```bash
# Check your current usage
agcheck

# Watch mode - live updates every 5 seconds
agcheck -w

# Watch mode with custom interval (10 seconds)
agcheck -w -i 10

# Compact output format
agcheck -c

# JSON output for scripting
agcheck --json

# Disable colors (useful for piping)
agcheck --no-color
```

## What it shows

- **Account email** and **plan name**
- **Usage quotas** for each AI model (Claude, Gemini, GPT, etc.)
- **Visual progress bars** with color coding:
  - 🟢 Green: >70% remaining
  - 🟡 Yellow: 30-70% remaining  
  - 🔴 Red: <30% remaining
- **Reset time** countdown for each model

## Example output

```
╔══════════════════════════════════════════════════════╗
║      🚀 ANTIGRAVITY TOKEN USAGE CHECKER              ║
╚══════════════════════════════════════════════════════╝

  Account: user@example.com
  Plan:    Pro
  Updated: 14:30:25

  ──────────────────────────────────────────────────

  Model Quotas:

  Claude Sonnet 4.5                  
    [████████████████░░░░]  80.0% remaining | 20.0% used ↻ 4h 25m

  Gemini 3 Flash                     
    [████████████████████] 100.0% remaining | 0.0% used ↻ 4h 26m
```

## How it works

1. Detects the Antigravity language server process
2. Extracts the CSRF token from the process command line
3. Discovers listening TCP ports using `lsof`
4. Connects to the local API (HTTPS with self-signed cert)
5. Fetches and displays quota information

## Development

```bash
# Clone the repository
git clone https://github.com/matiasfernandez/agcheck.git
cd agcheck

# Install in development mode
pip install -e .

# Run
agcheck
```

## License

MIT License - see [LICENSE](LICENSE) for details.

## Credits

- Inspired by [CodexBar](https://github.com/steipete/CodexBar) by @steipete
