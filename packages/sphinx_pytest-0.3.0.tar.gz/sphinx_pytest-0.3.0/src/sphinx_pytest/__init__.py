"""Helpful pytest fixtures for sphinx extensions."""

__version__ = "0.3.0"
