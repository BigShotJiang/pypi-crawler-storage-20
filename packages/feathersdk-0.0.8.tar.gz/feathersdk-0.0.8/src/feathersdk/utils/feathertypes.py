from typing import Union, TypedDict, Literal, Optional, Tuple, List, Dict, Any, TypeVar, Callable, ParamSpec, Generic, \
    TextIO, Type, TYPE_CHECKING, Sequence, NamedTuple, Iterable, get_origin as get_type_origin, \
    get_args as get_type_args
from typing_extensions import Self
