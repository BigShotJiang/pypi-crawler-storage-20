import time
import enum
from feathersdk.comms import CommsManager, SocketResult
from feathersdk.comms.system import get_all_physical_can_interfaces
from .robstride import RobstrideMotor, MotorMap, RobstrideRunMode, RobstrideMotorMode, RobstrideOperationCommand, \
    UnsafeCommandError, handle_robstride_motor_message
from feathersdk.utils import progressbar
from feathersdk.utils.logger import debug, info, warning
import math
from feathersdk.utils.feathertypes import List, Union, TypedDict, Optional
import threading
import asyncio
from feathersdk.utils.common import timediff, currtime


DRY_RUN = True
DISABLE_HANDS = True

INSPIRE_PROPERTIES_OFFSETS = {"force_set": 12}

INSPIRE_RIGHT_FINGERS = {
    "Gr00R": {
        "motor_id": 1496,
        "ip_address": "192.168.11.210",
        "motor_name": "Gp00R",
        "description": "Right thumb rotation finger",
    },
    "Gp01R": {
        "motor_id": 1494,
        "ip_address": "192.168.11.210",
        "motor_name": "Gp01R",
        "description": "Right thumb bending finger",
    },
    "Gp10R": {
        "motor_id": 1492,
        "ip_address": "192.168.11.210",
        "motor_name": "Gp10R",
        "description": "Right index finger",
    },
    "Gp20R": {
        "motor_id": 1490,
        "ip_address": "192.168.11.210",
        "motor_name": "Gp20R",
        "description": "Right middle finger",
    },
    "Gp30R": {
        "motor_id": 1488,
        "ip_address": "192.168.11.210",
        "motor_name": "Gp30R",
        "description": "Right ring finger",
    },
    "Gp40R": {
        "motor_id": 1486,    
        "ip_address": "192.168.11.210",
        "motor_name": "Gp40R",
        "description": "Right pinky finger",
    },
}

INSPIRE_LEFT_FINGERS = {
    "Gr00L": {
        "motor_id": 1496,
        "ip_address": "192.168.12.210",
        "motor_name": "Gp00L", 
        "description": "Left thumb rotation finger",
    },
    "Gp01L": {
        "motor_id": 1494,
        "ip_address": "192.168.12.210",
        "motor_name": "Gp01L",
        "description": "Left thumb bending finger",
    },
    "Gp10L": {
        "motor_id": 1492,
        "ip_address": "192.168.12.210",
        "motor_name": "Gp10L",
        "description": "Left index finger",
    },
    "Gp20L": {
        "motor_id": 1490,
        "ip_address": "192.168.12.210",
        "motor_name": "Gp20L",
        "description": "Left middle finger",
    },
    "Gp30L": {
        "motor_id": 1488,
        "ip_address": "192.168.12.210",
        "motor_name": "Gp30L",
        "description": "Left ring finger",
    },
    "Gp40L": {
        "motor_id": 1486,
        "ip_address": "192.168.12.210",
        "motor_name": "Gp40L",
        "description": "Left pinky finger",
    },
}

DEFAULT_MAX_FORCE = 500  # for safety purposes.

class InspireFingerJoint:

    def __init__(self, motor_id: int, ip_address: str, motor_name: str):
        self.motor_id = motor_id
        self.motor_name = motor_name
        self.ip_address = ip_address
        self.properties = {}
        self.comms = CommsManager()
        if not DISABLE_HANDS:
            self.set_max_force(DEFAULT_MAX_FORCE)

    def move_percentage(self, percentage: float):
        """
        Move the finger joint. 0% is fully closed, 100% is fully open.
        """
        # Record start time
        # start_time = currtime()
        self.comms.tcpsend_modbus(self.ip_address, 1, 255, 6, self.motor_id, int(percentage * 1000))
        time.sleep(0.01)

    def set_max_force(self, force: int):
        """
        Set the max force for the finger joint.
        """
        # Convert motor_id from bytes to int, add offset, then convert back to bytes
        force_set_id = int(self.motor_id) + INSPIRE_PROPERTIES_OFFSETS["force_set"]
        self.comms.tcpsend_modbus(self.ip_address, 1, 255, 6, force_set_id, force)
        time.sleep(0.005)


INSPIRE_RIGHT_FINGER_JOINTS_MAP = {}
INSPIRE_LEFT_FINGER_JOINTS_MAP = {}

if not DISABLE_HANDS:
    for motor_name, motor_info in INSPIRE_RIGHT_FINGERS.items():
        INSPIRE_RIGHT_FINGER_JOINTS_MAP[motor_name] = InspireFingerJoint(
            motor_info["motor_id"], motor_info["ip_address"], motor_info["motor_name"]
        )

    for motor_name, motor_info in INSPIRE_LEFT_FINGERS.items():
        INSPIRE_LEFT_FINGER_JOINTS_MAP[motor_name] = InspireFingerJoint(
            motor_info["motor_id"], motor_info["ip_address"], motor_info["motor_name"]
        )


class MotorNotFoundError(Exception):
    """Raised when attempting to access a motor that does not exist in the motors map."""
    def __init__(self, message: str, motor_name_or_id: Union[str, int]):
        super().__init__(message)
        self.motor_name_or_id = motor_name_or_id
        # For consistency with other exceptions, also provide motor_name (as string representation)
        self.motor_name = str(motor_name_or_id)


class MotorCalibrationError(Exception):
    """Raised when motor calibration fails or motor doesn't respond as expected during calibration."""
    def __init__(self, message: str, motor: RobstrideMotor):
        super().__init__(message)
        self.motor = motor
        self.motor_name = motor.motor_name


class SafeStopPolicy(enum.Enum):
    DISABLE_MOTORS = 1
    COMPLIANCE_MODE = 2


class FamilyConfig(TypedDict, total=False):
    safe_stop_policy: SafeStopPolicy


class MotorsManager:
    """
    Handles sending commands to and receiving feedback from motors.
    Handles caching the state of the motors.
    Abstractions to make it easy to work with motors.
    """

    def __init__(self) -> None:
        self.motors: MotorMap = {}
        # Create a map of motor IDs to motors for faster lookup
        self.motors_by_id: dict[int, RobstrideMotor] = {}
        self.motor_families: dict[str, MotorMap] = {}
        self.motor_families_config: dict[str, FamilyConfig] = {}
        self.motor_families_compliance_threads: dict[str, threading.Thread] = {}
        self.comms = CommsManager()
        self.comms.add_callback(lambda result: self.on_motor_message(result))

    def add_motors(self, motors_map: MotorMap, family_name: str, family_config: FamilyConfig = {}) -> None:
        self.motor_families[family_name] = motors_map
        self.motor_families_config[family_name] = family_config
        for motor_name, motor in motors_map.items():
            self.motors_by_id[motor.motor_id] = motor
            self.motors[motor_name] = motor
            motor.family_name = family_name
            motor.manager = self
    
    def find_motors(self, names: Optional[List[str]] = None, allow_not_found: bool = False, progress: bool = False) -> None:
        """Find the motors on the physical CAN interfaces.

        Args:
            names: The names of the motors to find. If not provided, find all motors in the motors map.
            allow_not_found: If True, do not raise an error if a motor is not found.
            progress: If True (and tqdm is installed), show a progress bar.
        """
        if names is None:
            names = list(self.motors.keys())

        for motor_name in progressbar(names, progress=progress):
            motor = self.motors[motor_name]
            if motor.iface is not None:
                continue

            found = False
            for attempt in range(3):
                for can_interface in get_all_physical_can_interfaces():
                    try:
                        motor.iface = can_interface
                        motor.update_property("loc_ref", None)
                        self.read_param(motor_name, "loc_ref")
                        time.sleep(0.01)

                        if motor.properties["loc_ref"].value is not None:
                            found = True
                            break
                    except Exception:
                        motor.iface = None

                if found:
                    info(f"Motor found on interface: {can_interface}, id: {motor.motor_id}")
                    break
                time.sleep(0.01)

            if not found:
                motor.iface = None
                if not allow_not_found:
                    raise MotorNotFoundError(
                        f"Warning: Could not find motor {motor_name} on any physical CAN interface [New]",
                        motor_name_or_id=motor_name,
                    )

    def stop_compliance_mode(self, family_name: str) -> None:
        family_motors = self.motor_families[family_name]
        for m in family_motors.values():
            m.compliance_mode = False
            self.disable(m.motor_name)
        # by setting it to None, trigger_compliance_mode will be called again from handle_msg from m.motor_name.
        del self.motor_families_compliance_threads[family_name]

    def compliance_mode_main(self, family_name: str) -> None:
        family_motors = self.motor_families[family_name]
        while True:
            for m in family_motors.values():
                if m.compliance_mode == False:
                    return  # exit.

                if abs(m.torque[0]) > m.compliance_mode_torque_threshold:
                    proposed_new_pos = m.last_compliance_pos + m.torque[0] * -m.compliance_mode_dx
                    if m.joint_limits is None:
                        m.last_compliance_pos = proposed_new_pos
                    elif m.joint_limits[0] <= proposed_new_pos and m.joint_limits[1] >= proposed_new_pos:
                        m.last_compliance_pos = proposed_new_pos
                # self.write does a time.sleep(0.0002) for each motor.
                self._set_target_position_in_compliance_mode(m.motor_name, m.last_compliance_pos)
                # time.sleep(0.01)

    def trigger_compliance_mode(self, family_name: str) -> None:
        # disable all motors
        family_motors = self.motor_families[family_name]
        safe_stop_policy = self.motor_families_config[family_name].get(
            "safe_stop_policy", SafeStopPolicy.COMPLIANCE_MODE
        )
        for m in family_motors.values():
            m.compliance_mode = True
            self.disable(m.motor_name)
            if safe_stop_policy == SafeStopPolicy.COMPLIANCE_MODE:
                self.set_run_mode(m.motor_name, RobstrideRunMode.Position)
                self.enable(m.motor_name)
                self._set_target_position_in_compliance_mode(m.motor_name, m.angle[0] - m.velocity[0] * 0.01)
                m.last_compliance_pos = m.angle[0] - m.velocity[0] * 0.01

        if family_name not in self.motor_families_compliance_threads:
            thread = threading.Thread(target=self.compliance_mode_main, args=(family_name,), daemon=True)
            self.motor_families_compliance_threads[family_name] = thread
            thread.start()

    def on_motor_message(self, result: SocketResult) -> None:
        """Callback to handle incoming motor messages."""
        if result.is_can():
            self.on_can_message(result)
        elif result.is_tcp():
            self.on_tcp_message(result)
        else:
            raise NotImplementedError(f"Unhandled message type: {result.result_type}")
    
    def on_can_message(self, result: SocketResult) -> None:
        """Callback to handle incoming CAN messages."""
        if not result.is_extended_can():
            debug(f"Non-extended CAN messages are not supported: {result}")
            return
        handle_robstride_motor_message(self, result)
    
    def on_tcp_message(self, result: SocketResult) -> None:
        """Callback to handle incoming TCP messages."""
        raise NotImplementedError(f"TCP message handling not implemented")

    def get_motor(self, motor_name_or_id: Union[str, int]) -> RobstrideMotor:
        if isinstance(motor_name_or_id, str):
            if motor_name_or_id not in self.motors:
                raise MotorNotFoundError(f"Motor '{motor_name_or_id}' not found in motors map", motor_name_or_id=motor_name_or_id)
            return self.motors[motor_name_or_id]
        else:
            if motor_name_or_id not in self.motors_by_id:
                raise MotorNotFoundError(f"Motor with ID {motor_name_or_id} not found in motors map", motor_name_or_id=motor_name_or_id)
            return self.motors_by_id[motor_name_or_id]

    def enable(self, motor_name_or_id: Union[str, int]):
        self.get_motor(motor_name_or_id).enable()

    def disable(self, motor_name_or_id: Union[str, int]):
        self.get_motor(motor_name_or_id).disable()

    def _disable_active_reporting(self, motor_name_or_id: Union[str, int]):
        """
        Send a command to disable active reporting, which triggers a feedback frame.
        
        This method sends a SetMotorActiveReporting command with active_flag=0 to the motor.
        While the intended purpose is to disable active reporting, this command also triggers
        the motor to send a feedback frame, which is the primary use case for this method.
        
        Note: Active reporting enable functionality was found to not work as
        documented in testing (TODO for later). This method is primarily used as a side-effect to trigger
        feedback frames rather than to actually control active reporting state.
        
        Args:
            motor_name_or_id: Motor name or ID
        """
        self.get_motor(motor_name_or_id).set_active_reporting(False)

    async def read_current_state_async(self, motor_name_or_id: Union[str, int]):
        """
        Asynchronously trigger a feedback frame from the motor and wait for fresh motor data.
        
        This method sends a command to the motor (via _disable_active_reporting) that triggers
        a feedback response. It then waits for the feedback frame to arrive and be processed,
        retrying the command if necessary.
        
        The method will retry sending the command every 100ms (10 iterations) if no feedback is
        received. After 300ms (30 iterations) with no feedback, a TimeoutError is raised to
        indicate that the motor is not responding. This ensures that stale feedback data is not
        used, as the method guarantees fresh feedback or an error.
        
        Args:
            motor_name_or_id: Name or ID of the motor
            
        Raises:
            TimeoutError: If no feedback frame is received within 300ms (after up to 3 retries)

        Note:
            This method has a side-effect of disabling active reporting, which is not the true purpose.
            Since we are not using active reporting, this is not a problem for now.
            But if we start using active reporting, we need to revisit this. There was a Motor Data
            Save command in the Robstride manual for the motor, however, that did not work as expected.
        """
        motor = self.get_motor(motor_name_or_id)
        
        # Record timestamp before triggering feedback
        update_time = currtime()
        
        # Disable active reporting to trigger a feedback frame
        self._disable_active_reporting(motor_name_or_id)
        
        # Wait for feedback frame to arrive and be processed
        # Check if temp timestamp has been updated (indicating fresh feedback received)
        await asyncio.sleep(0.001)  # Initial pause
        retry_cnt = 10  # Retry command every 10 iterations (10 * 10ms = 100ms)
        max_retry_cnt = 0
        
        # Wait for feedback to be updated (check temp timestamp as indicator)
        # temp[1] is the timestamp; -1 means no feedback received yet
        while motor.temp[1] < update_time:
            await asyncio.sleep(0.01)  # Wait 10ms between checks
            retry_cnt -= 1
            if retry_cnt <= 0:
                # Retry disabling active reporting if no feedback received
                self._disable_active_reporting(motor_name_or_id)
                retry_cnt = 10  # Reset retry counter
            max_retry_cnt += 1
            if max_retry_cnt > 30:  # Timeout after ~0.3 seconds (30 * 0.01s), allows 3 retries
                raise TimeoutError(
                    f"Failed to receive feedback from motor {motor.motor_name} within timeout (300ms). "
                    f"Motor may be disconnected or not responding."
                )

    def zero_position(self, motor_name_or_id: Union[str, int]):
        self.get_motor(motor_name_or_id).zero_position()

    def read_param_sync(self, motor_name_or_id: Union[str, bytes], param_id: Union[int, str]) -> float:
        motor = self.get_motor(motor_name_or_id)
        update_time = currtime()

        self.read_param(motor_name_or_id, param_id)
        time.sleep(0.001)
        retry_cnt = 50
        max_retry_cnt = 0
        while motor.get_property_timestamp(param_id, default=-1) < update_time:
            time.sleep(0.001)
            retry_cnt -= 1
            if retry_cnt <= 0:
                self.read_param(motor_name_or_id, param_id)    
                retry_cnt = 50
            max_retry_cnt += 1
            if max_retry_cnt > 25:
                raise TimeoutError(f"Failed to read parameter {param_id} within timeout")
        return motor.get_property_value(param_id)

    async def read_param_async(self, motor_name_or_id: Union[str, bytes], param_id: Union[int, str]) -> float:
        """
        Asynchronously reads a motor parameter, waiting for the value to be updated.
        Replaces blocking time.sleep with non-blocking asyncio.sleep.
        """

        # 1. Initial setup and parameter read
        motor = self.get_motor(motor_name_or_id)

        # The 'update_time' from the original code: get the current time before requesting the update.
        update_time = currtime()

        # Initiate the read request (assuming self.read_param is already non-blocking or schedules a background action)
        self.read_param(motor_name_or_id, param_id)

        # Initial pause and setup
        await asyncio.sleep(0.001)  # Replace the first time.sleep(0.01) with non-blocking asyncio.sleep
        retry_cnt = 5
        max_retry_cnt = 0

        # Define the maximum total time to wait for the parameter to update (e.g., 0.5 seconds, as 25 * 0.02 is 0.5s total wait)
        # The original logic used 25 iterations of the main loop. With an inner sleep of 0.01s and an outer sleep/read sequence,
        # it's best to rely on a total timeout based on currtime() rather than a fixed retry count.
        # We will stick close to the original retry/max_retry logic, but use a more explicit maximum duration for robustness.

        # 2. Asynchronous Polling Loop
        while motor.get_property_timestamp(param_id, default=-1) < update_time:

            # Replace time.sleep(0.01) with non-blocking asyncio.sleep
            await asyncio.sleep(0.001)

            retry_cnt -= 1

            if retry_cnt <= 0:
                # Re-request the parameter read
                self.read_param(motor_name_or_id, param_id)
                retry_cnt = 5

            max_retry_cnt += 1

            # Original maximum loop count check (25 * 0.02s delay approx = 0.5s total wait)
            if max_retry_cnt > 25:
                # If a TimeoutError is raised, it's better to use the time-based check below,
                # but for a direct reimplementation, we keep the original logic.
                raise TimeoutError(f"Failed to read parameter {param_id} within timeout")

        # 3. Return the updated parameter value
        return motor.get_property_value(param_id, default=-1)

    def read_param(self, motor_name_or_id: Union[str, int], param_id: Union[int, str]):
        """Read a parameter from the specified motor."""
        self.get_motor(motor_name_or_id).read_param(param_id)
        
    def set_run_mode(self, motor_name_or_id: Union[str, int], run_mode: RobstrideRunMode):
        self.get_motor(motor_name_or_id).set_run_mode(run_mode)

    def _set_target_position_in_compliance_mode(self, motor_name_or_id: Union[str, int], target_position: float) -> None:
        """Set the target position (loc_ref) for the specified motor, bypassing safety checks.
        
        This is an internal method used only by compliance mode to set target positions
        without triggering safety checks. It bypasses motor state validation and position
        safety checks that would normally prevent commands during unsafe conditions.
        
        Args:
            motor_name_or_id: Name or ID of the motor
            target_position: Target position in radians
        """
        self.get_motor(motor_name_or_id)._write_param_checked("loc_ref", target_position, force_run=True)

    def set_target_position(self, motor_name_or_id: Union[str, int], target_position: float) -> None:
        """Set the target position (loc_ref) for the specified motor.
        
        This is a convenience method that wraps write_param for setting loc_ref.
        It provides a clearer API for position control.
        
        Args:
            motor_name_or_id: Name or ID of the motor
            target_position: Target position in radians
        
        Raises:
            MotorDisabledError: If the motor is in Reset mode (disabled)
            MotorModeInconsistentError: If the motor is not in Position run mode
        """
        self.get_motor(motor_name_or_id).set_target_position(target_position)

    def set_target_velocity(self, motor_name_or_id: Union[str, int], target_velocity: float) -> None:
        """Set the target velocity (spd_ref) for the specified motor.
        
        This is a convenience method that wraps write_param for setting spd_ref.
        It provides a clearer API for velocity control.
        
        Args:
            motor_name_or_id: Name or ID of the motor
            target_velocity: Target velocity in radians per second
        
        Raises:
            MotorDisabledError: If the motor is in Reset mode (disabled)
            MotorModeInconsistentError: If the motor is not in Speed run mode
        """
        self.get_motor(motor_name_or_id).set_target_velocity(target_velocity)

    def write_param(self, motor_name_or_id: Union[str, int], param_id: Union[int, str], param_value: Union[float, int]) -> None:
        """Write a parameter value to the specified motor.

        Args:
            motor_name_or_id: Name or ID of the motor
            param_id: Parameter ID
            param_value: Parameter value
        """
        self.get_motor(motor_name_or_id).write_param(param_id, param_value)

    def operation_command(self, motor_name_or_id: Union[str, int], target_torque: float, target_angle: float, target_velocity: float, kp: float, kd: float):
        """ target_torque range (-60Nm to 60Nm)"""
        self.send_operation_commands(
            [RobstrideOperationCommand(self.get_motor(motor_name_or_id), target_torque, target_angle, target_velocity, kp, kd)]
        )

    def send_operation_commands(self, operation_commands: List[RobstrideOperationCommand]):
        for op in operation_commands:
            op.motor.operation_command(op)

    def _find_limit(
        self,
        motor_name: str,
        initial_pos: float,
        step_size: float,
        step_time: float,
        max_torque: float,
        threshold_target_distance: float,
        direction: int,  # 1 for forward, -1 for backward
        verbose: bool,
    ) -> float:
        """Helper method to find a limit (upper or lower) by moving the motor until torque limit is reached.
        
        Returns the limit position found.
        """
        motor = self.get_motor(motor_name)
        target_pos = initial_pos
        while True:
            target_pos += direction * step_size
            self.set_target_position(motor_name, target_pos)
            time.sleep(step_time)
            if verbose:
                debug("torque, angle", motor.torque[0], motor.angle[0], target_pos)
            if abs(motor.torque[0]) > max_torque:
                limit = motor.angle[0]
                if verbose:
                    debug(f"final_mech_pos (direction={direction})", motor.angle[0], target_pos)
                break
            # To avoid an infinite loop!
            target_distance = abs(target_pos - initial_pos)
            if target_distance > threshold_target_distance:
                curr_pos_from_motor = self.read_param_sync(motor_name, "mech_pos")
                if abs(curr_pos_from_motor - initial_pos) < 0.0175:  # 0.0175 in radians is 1 degree
                    help_string = f"Motor {motor_name} has not moved during calibration (current position: {curr_pos_from_motor}, initial position: {initial_pos})."
                else:
                    help_string = f"Motor {motor_name} has moved to {curr_pos_from_motor} after attempting to reach {target_pos}, but did not hit the limit. Calibration may be faulty."
                raise MotorCalibrationError(help_string, motor=motor)
        return limit

    def get_range(
        self,
        motor_name,
        step_size=0.01,
        step_time=0.01,
        max_torque=4.5,
        verbose=False,
    ):
        if step_size < 0.001:
            raise ValueError(f"Step size is too low or negative, got {step_size}, recommended value is 0.01")
        if step_time < 0.001:
            raise ValueError(f"Step time is too low or negative, got {step_time}, recommended value is 0.01")
        if max_torque < 0:
            raise ValueError(f"Max torque cannot be negative, got {max_torque}, recommended value depends on the motor's max torque")

        motor = self.get_motor(motor_name)
        expected_range = motor.expected_range
        self.set_run_mode(motor_name, RobstrideRunMode.Position)
        self.enable(motor_name)
        start_pos = self.read_param_sync(motor_name, "mech_pos")

        info(f"Moving the motor {motor_name} to one end to get the range of motion, starting from {start_pos}")
        # Find upper limit (moving forward)
        upper_limit = self._find_limit(
            motor_name=motor_name,
            initial_pos=start_pos,
            step_size=step_size,
            step_time=step_time,
            max_torque=max_torque,
            threshold_target_distance=expected_range * 2.0,
            direction=1,  # forward
            verbose=verbose,
        )
        
        info(f"Reached one end at upper_limit {upper_limit}, trying to go to the other end by setting intial target to {upper_limit - (expected_range * 0.8)} and exploring the other end")
        self.set_target_position(motor_name, upper_limit - (expected_range * 0.8))
        time.sleep(1.0)
        
        lower_limit_initial_pos = upper_limit - (expected_range * 0.8)
        # Find lower limit (moving backward)
        lower_limit = self._find_limit(
            motor_name=motor_name,
            initial_pos=lower_limit_initial_pos,
            step_size=step_size,
            step_time=step_time,
            max_torque=max_torque,
            threshold_target_distance=expected_range * 2.5,
            direction=-1,  # backward
            verbose=verbose,
        )

        middle_pos = lower_limit + ((upper_limit - lower_limit) / 2)

        info(f"Reached the other end at lower_limit {lower_limit}, trying to go to the middle position by setting target position to {middle_pos}")
        self.set_target_position(motor_name, middle_pos)
        time.sleep(2.5)

        return lower_limit, upper_limit, middle_pos, abs(upper_limit - lower_limit)


    def recover_from_power_cycle(self, motor_name: str):
        motor = self.get_motor(motor_name)
        # recovers the motor from a power cycle where the encoder is reset.
        if not motor.dual_encoder:
            raise UnsafeCommandError("Only dual encoder motors can recover from power cycle.", motor=motor)
        if motor.calibration_time is None:
            raise UnsafeCommandError("Motor does not have a calibration to recover from.", motor=motor)
        
        mech_pos = self.read_param_sync(motor_name, "mech_pos")
        if mech_pos > motor.upper_limit:
            # too high by 2 pi
            motor.upper_limit += 2 * math.pi
            motor.lower_limit += 2 * math.pi
            motor.middle_pos += 2 * math.pi
            
        if mech_pos < motor.lower_limit:
            # too low by 2 pi
            motor.upper_limit -= 2 * math.pi
            motor.lower_limit -= 2 * math.pi
            motor.middle_pos -= 2 * math.pi

    def check_motors_in_range(self, motor_names: list[str], target_angle: float = None, raise_error: bool = True) -> bool:
        """Check if motors are within valid range.
        
        Validates that motors' current positions and optionally a target angle are within
        their calibrated limits (upper_limit and lower_limit).
        
        Args:
            motor_names: List of motor names to check
            target_angle: Optional target angle to validate against limits
            raise_error: If True, raise exceptions on violations; if False, return False
            
        Returns:
            True if all motors are in range, False otherwise
            
        Raises:
            ValueError: If target_angle is out of range and raise_error is True
            Exception: If current motor position is out of range and raise_error is True
        """
        for motor_name in motor_names:
            motor = self.get_motor(motor_name)
            
            # Check target angle if provided
            if target_angle is not None:
                if target_angle > motor.upper_limit or target_angle < motor.lower_limit:
                    if raise_error:
                        raise ValueError(
                            f"{target_angle} is out of range for {motor_name}. "
                            f"Range: {motor.lower_limit} to {motor.upper_limit}"
                        )
                    return False
            
            # Check motor current angle. if not in range even with +-2*pi difference, raise error, tell user to recalibrate
            try:
                mech_pos = self.read_param_sync(motor_name, "mech_pos")
            except Exception as e:
                if raise_error:
                    raise
                warning(f"Error reading mech_pos for {motor_name}: {e} in check_motors_in_range")
                return False
            if mech_pos is not None and (mech_pos > motor.upper_limit or mech_pos < motor.lower_limit):
                if raise_error:
                    raise Exception(f"{motor_name} position {mech_pos} is outside of valid range. Please recalibrate.")
                return False
        
        return True

    def motors_in_mode(self, motor_names: list[str], mode: RobstrideMotorMode) -> bool:
        for motor_name in motor_names:
            motor = self.get_motor(motor_name)
            if motor.run_mode != mode:
                return False
        return True
        
