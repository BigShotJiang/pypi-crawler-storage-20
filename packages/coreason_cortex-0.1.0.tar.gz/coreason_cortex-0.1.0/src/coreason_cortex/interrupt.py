# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_cortex

from threading import Event


class InterruptionSignal(Exception):
    """Exception raised when an interrupt signal is received."""

    pass


class InterruptHandler:
    """
    Handles asynchronous interruption signals for the Reasoning Engine.
    Allows external entities (Economist, User) to halt execution safely.
    """

    def __init__(self) -> None:
        """Initialize the InterruptHandler with a thread-safe event."""
        self._stop_event = Event()

    def trigger(self) -> None:
        """
        Manually trigger the interrupt signal.
        This can be called by the Economist (Budget Depleted) or User (Cancellation).
        """
        self._stop_event.set()

    def reset(self) -> None:
        """Reset the interrupt signal."""
        self._stop_event.clear()

    def check_for_signal(self) -> None:
        """
        Check if the interrupt signal has been triggered.
        Raises InterruptionSignal if triggered.
        """
        if self._stop_event.is_set():
            raise InterruptionSignal("Execution halted by InterruptHandler.")
