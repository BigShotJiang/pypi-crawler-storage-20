"""
Channel position and permission monitoring - background task.
"""
import discord
import asyncio
import json
from pathlib import Path
from typing import List, Tuple, Dict, Any, Union

class ChannelPositionMonitor:
    """
    Background monitor that checks and restores channel positions, permissions,
    and missing channels every 300ms.
    """
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_dir = sdk.backup_dir
        self.enabled = False
        self._task = None
    
    def start(self):
        """Start the channel monitoring task"""
        if not self.enabled:
            self.enabled = True
            self._task = self.bot.loop.create_task(self._monitor_loop())
            print("🔍 Channel Monitor: Started (300ms checks)")
    
    def stop(self):
        """Stop the monitoring task"""
        if self.enabled and self._task:
            self.enabled = False
            self._task.cancel()
            print("🛑 Channel Monitor: Stopped")
    
    async def _monitor_loop(self):
        """Main monitoring loop - runs every 300ms"""
        await self.bot.wait_until_ready()
        
        while self.enabled and not self.bot.is_closed():
            try:
                await self._check_all_guilds()
                await asyncio.sleep(0.3)
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error in channel monitor: {e}")
                await asyncio.sleep(0.3)
    
    async def _check_all_guilds(self):
        """Check channels for all guilds"""
        for guild in self.bot.guilds:
            try:
                await self._check_guild_channels(guild)
            except Exception as e:
                print(f"Error checking channels for {guild.name}: {e}")

    async def _check_guild_channels(self, guild: discord.Guild):
        """Check and restore channel positions/permissions/missing channels"""
        try:
            # Get backup file
            backup_file = self.backup_dir / f"channels_{guild.id}.json"
            if not backup_file.exists():
                return
            
            with open(backup_file, 'r') as f:
                backup = json.load(f)
            
            # Build current snapshot {channel_id: channel_obj}
            current_channels = {c.id: c for c in guild.channels}
            
            # Iterate through BACKUP channels (the source of truth)
            for ch_data in backup["channels"]:
                channel_id = ch_data["id"]
                channel = current_channels.get(channel_id)
                
                # 1. Missing Channel Detection
                if not channel:
                    # Check if this channel is currently being processed by the ChannelHandler
                    # If so, we skip restoration for now to avoid race conditions
                    if channel_id in self.sdk.processing_channel_deletions:
                        # print(f"⏳ Skipping restoration for {channel_id} (pending verification)")
                        continue
                        
                    # Channel exists in backup but not in guild -> RESTORE IT!
                    # print(f"⚠️ Missing channel found in backup: {ch_data['name']} ({channel_id})")
                    try:
                        # Use the new restore_channel logic that accepts ID
                        await self.sdk.backup_manager.restore_channel(guild, channel_id)
                        # Slightly longer sleep on create to prevent rate limits
                        await asyncio.sleep(0.1) 
                    except Exception as e:
                        print(f"Error restoring missing channel {channel_id}: {e}")
                    continue
                
                # 2. Check Position
                if channel.position != ch_data["position"]:
                    try:
                        await channel.edit(position=ch_data["position"], reason="SecureX: Auto-restoring position")
                        # print(f"🔧 Fixed position for #{channel.name}")
                    except Exception:
                        pass
                
                # 3. Check Category
                expected_cat_id = ch_data.get("category_id")
                current_cat_id = channel.category.id if channel.category else None
                
                if expected_cat_id != current_cat_id:
                    try:
                        if expected_cat_id:
                            category = guild.get_channel(expected_cat_id)
                            if category and isinstance(category, discord.CategoryChannel):
                                await channel.edit(category=category, reason="SecureX: Auto-restoring category")
                        else:
                            # Should be None (no category)
                            await channel.edit(category=None, reason="SecureX: Auto-restoring category")
                    except Exception:
                        pass

                # 4. Check Permissions (Simplified)
                # We check if the number of overwrites matches. Deep comparison is too heavy for 300ms.
                # If they differ, we restore permissions.
                # Note: Backup might have simplified perms, so this is a heuristic.
                backup_perms = ch_data.get("permissions", {})
                if len(channel.overwrites) != len(backup_perms):
                    try:
                         await self.sdk.backup_manager.restore_channel_permissions(guild, channel.id)
                    except Exception:
                        pass
                
        except Exception as e:
            # print(f"Error checking guild {guild.id}: {e}")
            pass
