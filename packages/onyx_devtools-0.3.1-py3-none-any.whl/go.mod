module github.com/onyx-dot-app/onyx/tools/ods

go 1.24.11

require (
	github.com/sirupsen/logrus v1.9.3
	github.com/spf13/cobra v1.10.1
)

require (
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/spf13/pflag v1.0.9 // indirect
	golang.org/x/sys v0.0.0-20220715151400-c0bba94af5f8 // indirect
)
