"""
RUN - Global experiment configuration object for ML-Dash.

This module provides a global RUN object that serves as the single source
of truth for experiment metadata. Uses params-proto for configuration.

Usage:
    from ml_dash import RUN

    # Configure via environment variable
    # export ML_DASH_PREFIX="ge/myproject/experiments/exp1"

    # Or set directly
    RUN.PREFIX = "ge/myproject/experiments/exp1"

    # Use in templates
    prefix = "{RUN.PREFIX}/{RUN.name}.{RUN.id}".format(RUN=RUN)

    # With Experiment (RUN is auto-populated)
    from ml_dash import Experiment
    with Experiment(prefix=RUN.PREFIX).run as exp:
        exp.logs.info(f"Running {RUN.name}")
"""

import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Union

from params_proto import EnvVar, proto

PROJECT_ROOT_FILES = ("pyproject.toml", "requirements.txt", "setup.py", "setup.cfg")


def find_project_root(
  start: Union[str, Path] = None,
  verbose: bool = False,
) -> str:
  """Find the nearest project root by looking for common project files.

  Walks up the directory tree from `start` until it finds a directory
  containing pyproject.toml, requirements.txt, setup.py, or setup.cfg.

  Args:
      start: Starting directory or file path. Defaults to cwd.
      verbose: If True, print search progress.

  Returns:
      String path to the project root directory, or cwd if not found.
  """
  if start is None:
    start = Path.cwd()
  else:
    start = Path(start)

  if start.is_file():
    start = start.parent

  if verbose:
    print(f"Searching for project root from: {start}")

  for parent in [start, *start.parents]:
    if verbose:
      print(f"  Checking: {parent}")
    for filename in PROJECT_ROOT_FILES:
      if (parent / filename).exists():
        if verbose:
          print(f"  Found: {parent / filename}")
        return str(parent)

  if verbose:
    print(f"  No project root found, using cwd: {Path.cwd()}")
  return str(Path.cwd())


@proto.prefix
class RUN:
  """
  Global Experiment Run Configuration.

  This class is the single source of truth for experiment metadata.
  Configure it before starting an experiment, or through the Experiment
  constructor.

  Default prefix template:
      {project}/{now:%Y/%m-%d}/{path_stem}/{job_name}

  Example:
      # Set prefix via environment variable
      # export ML_DASH_PREFIX="ge/myproject/exp1"

      # Or configure directly
      from ml_dash.run import RUN

      RUN.project = "my-project"
      RUN.prefix = "{username}/{project}/{now:%Y-%m-%d}/{entry}"

  Auto-detection:
      project_root is auto-detected by searching for pyproject.toml,
      requirements.txt, setup.py, or setup.cfg in parent directories.
  """

  user: str = EnvVar @ "ML_DASH_USER" @ "USER"

  api_url: str = EnvVar @ "ML_DASH_API_URL" | "https://api.dash.ml"
  """Remote API server URL"""

  ### Experiment and project information
  project = "{user}/scratch"  # default project name

  prefix: str = (
    EnvVar @ "ML_DASH_PREFIX" | "{project}/{now:%Y/%m-%d}/{path_stem}/{job_name}"
  )
  """Full experiment path: {owner}/{project}/path.../[name]"""

  readme = None

  id: int = None
  """Unique experiment ID (snowflake, auto-generated at run start)"""

  now = datetime.now()
  """Timestamp at import time. Does not change during the session."""

  timestamp: str = None
  """Timestamp created at instantiation"""

  ### file properties
  project_root: str = None
  """Root directory for experiment hierarchy (for auto-detection)"""

  entry: Union[Path, str] = None
  """Entry point file/directory path"""

  path_stem: str = None

  job_counter: int = 1  # Default to 0. Use True to increment by 1.

  job_name: str = "{now:%H.%M.%S}/{job_counter:03d}"

  """ 
      Default to '{now:%H.%M.%S}'. use '{now:%H.%M.%S}/{job_counter:03d}'
      
      for multiple launches. You can do so by setting:

      ```python
      RUN.job_name += "/{job_counter}"

      for params in sweep:
         thunk = instr(main)
         jaynes.run(thun)
      jaynes.listen()
      ```
  """

  debug = "pydevd" in sys.modules
  "set to True automatically for pyCharm"

  def __post_init__(self):
    """
    Initialize RUN with auto-detected prefix from entry path.

    Args:
        entry: Path to entry file/directory (e.g., __file__ or directory
               containing sweep.jsonl). If not provided, uses caller's
               __file__ automatically.

    Computes prefix as relative path from project_root to entry's directory.

    Example:
        # experiments/__init__.py
        from ml_dash import RUN

        RUN.project_root = "/path/to/my-project/experiments"

        # experiments/vision/resnet/train.py
        from ml_dash import RUN

        RUN.__post_init__(entry=__file__)
        # Result: RUN.prefix = "vision/resnet", RUN.name = "resnet"
    """

    # Use provided entry or try to auto-detect from caller
    if self.entry is None:
      import inspect

      # Walk up the stack to find the actual caller (skip params_proto frames)
      frame = inspect.currentframe().f_back
      while frame:
        file_path = frame.f_globals.get("__file__", "")
        if "params_proto" not in file_path and "ml_dash/run.py" not in file_path:
          break
        frame = frame.f_back

      self.entry = frame.f_globals.get("__file__") if frame else None

    if not self.path_stem:

      def stem(path):
        return os.path.splitext(str(path))[0]

      def truncate(path, depth):
        return "/".join(str(path).split("/")[depth:])

      self.project_root = str(self.project_root or find_project_root(self.entry))
      script_root_depth = self.project_root.split("/").__len__()

      script_truncated = truncate(os.path.abspath(self.entry), depth=script_root_depth)

      self.path_stem = stem(script_truncated)

    if isinstance(RUN.job_counter, int) or isinstance(RUN.job_counter, float):
      RUN.job_counter += 1

    while "{" in self.prefix:
      data = vars(self)
      for k, v in data.items():
        if isinstance(v, str):
          setattr(self, k, v.format(**data))

    # for k, v in data.items():
    #   print(f"> {k:>30}: {v}")


if __name__ == "__main__":
  RUN.description = ""
  RUN.entry = __file__
  RUN.prefix = "you you"

  run = RUN()
  print(vars(run))
