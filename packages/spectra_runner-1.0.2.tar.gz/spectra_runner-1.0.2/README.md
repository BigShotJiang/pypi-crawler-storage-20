# Spectra Runner

Run your tests locally with Docker! 🚀

## Installation

```bash
pip install spectra-runner
```

## Quick Start

### 1. Login (one-time)

Get your token from Spectra Dashboard → Settings → Local Runner

```bash
spectra-runner login --token YOUR_TOKEN
```

### 2. Start the runner

```bash
spectra-runner start
```

That's it! The runner will connect to Spectra and wait for test jobs.

## Commands

| Command | Description |
|---------|-------------|
| `spectra-runner login --token X` | Save your authentication token |
| `spectra-runner start` | Start the runner and wait for jobs |
| `spectra-runner logout` | Remove saved token |
| `spectra-runner status` | Check if you're logged in |

## How It Works

1. You run `spectra-runner start` in your terminal
2. When you click "Run Tests" in Spectra Dashboard, the job is sent to your runner
3. Tests run in an isolated Docker container on YOUR machine
4. Results are sent back to the Dashboard

## Security

- **Transparent**: You can see every command in your terminal
- **Isolated**: Tests run in Docker with `--network=none` (no internet access)
- **Open Source**: Audit the code yourself!
- **User Control**: You decide when to run - no background services

## Requirements

- Python 3.8+
- Docker Desktop (running)

## License

MIT
