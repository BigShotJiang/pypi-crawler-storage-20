"""
Spectra Runner - Local test execution for Spectra DevMode
"""

__version__ = "1.0.2"
