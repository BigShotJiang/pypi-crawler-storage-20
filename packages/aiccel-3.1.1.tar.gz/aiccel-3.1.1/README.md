# AICCEL Framework 3.1: The Production-Grade Agentic Library

**AICCEL (AI-Accelerated Agentic Library)** is a security-first, high-performance framework for building orchestrated AI systems. Built for developers who need speed (~50ms startup), modularity, and enterprise-grade safety.

---

## 📦 Installation

AICCEL is modular. Install only what you need.

```bash
pip install aiccel             # Core (OpenAI, Gemini, Groq)
pip install aiccel[safety]     # Jailbreak Guard (Transformers)
pip install aiccel[privacy]    # PII Masking (GLiNER)
pip install aiccel[all]        # Full Security & Data Suite
```

---

## 🏗️ 1. Building High-Performance Agents

The `Agent` class handles LLM interaction, tool execution, and session memory.

```python
from aiccel import Agent, AgentConfig, GeminiProvider

provider = GeminiProvider(api_key="...", model="gemini-2.5-flash")

agent = Agent(
    provider=provider,
    name="Researcher",
    instructions="Find facts and cite sources.",
    config=AgentConfig(
        verbose=True,           # Real-time thought tracing
        safety_enabled=True,    # Active Jailbreak protection
        timeout=30.0            # Fail-safe execution
    )
)

result = agent.run("What is the current state of fusion energy?")
```

### ⚙️ Agent Parameters

| Parameter | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| **`provider`** | `LLMProvider` | ✅ | LLM backend (Gemini, OpenAI, Groq). |
| **`name`** | `str` | `"Agent"` | ID for logs and orchestration. |
| **`instructions`**| `str` | `""` | The "Soul" - System Prompt & Rules. |
| **`tools`** | `List[Tool]` | `[]` | authorized tools for the agent. |
| **`config`** | `AgentConfig` | `None` | Operational flags (Timeout, Safety). |
| **`memory`** | `Memory` | `Buffer`| Conversation history management. |

---

## 🛡️ 2. Security & Data Privacy Suite

AICCEL provides a multi-layered defense system for AI applications.

### 🕵️ PII Masking (`aiccel.privacy`)
Automatically detects and masks sensitive data before it's sent to the LLM.

```python
from aiccel.privacy import mask_text, unmask_text

result = mask_text("Contact John at 555-0123")
# Output: "Contact [PERSON_1] at [PHONE_1]"

# unmask_text(result['masked'], result['mapping']) restores the data.
```

### 🛑 Jailbreak Guard (`aiccel.safety`)
Uses a transformer model to block prompt injection attacks.
*   **Automatic**: Set `AgentConfig(safety_enabled=True)`.
*   **Manual**: `if not check_prompt(user_input): abort()`

### 📦 Pandora: Secure Data Analysis
AI-powered ETL agent with process isolation.
```python
from aiccel.pandora import Pandora
# Modes: "local" (fast), "subprocess" (secure), "service" (extreme)
pan = Pandora(provider, execution_mode="subprocess")
df = pan.do(df, "Mask names and calculate revenue growth")
```

### 🔐 Secure Vault & Encryption
FIPS-compliant encryption for your secrets.
```python
from aiccel.encryption import SecureVault
vault = SecureVault(master_password="...")
vault.store("STRIPE_KEY", "sk_test_...")
```

---

## 🎼 3. Orchestration & Workflows

### 🤝 Multi-Agent Collaboration
Manage specialist teams using the `AgentManager`.
```python
from aiccel.manager import AgentManager
manager = AgentManager(llm_provider=p, agents=[researcher, writer])
# Plan-Execute-Synthesize pipeline
response = await manager.collaborate_async("Research and write a report.")
```

### ⛓️ Workflow DAGs
Build deterministic agent pipelines.
```python
workflow = (WorkflowBuilder("gen")
    .add_agent("step1", agent1, output_key="data")
    .add_agent("step2", agent2, input_key="data")
    .chain("step1", "step2").build())
```

---

## 🧠 4. Advanced Features

*   **Neural Reranking**: Advanced semantic sorting via `NeuralReranker`.
*   **Goal Agents**: Autonomous agents that pursue complex objectives via `GoalAgent`.
*   **Observability**: Real-time tracing and structured logging built-in.
*   **MCP Support**: Native Model Context Protocol for cross-platform tools.

---

### 🔌 API Reference
*   **Providers**: `GeminiProvider`, `OpenAIProvider`, `GroqProvider`.
*   **Methods**: `agent.run()`, `agent.run_async()`, `agent.stream()`.

*Built for speed, built for safety. Built by the AICCEL Team.*