# [DeepLabXception: Deep Convolutional Neural Network model for semantic segmentation](https://aihub.qualcomm.com/models/deeplab_xception)

DeepLabXception is a semantic segmentation model supporting multiple backbones like ResNet-101 and Xception, with flexible dataset compatibility including COCO, VOC, and Cityscapes.

This is based on the implementation of DeepLabXception found [here](https://github.com/LikeLy-Journey/SegmenTron). This repository contains scripts for optimized on-device
export suitable to run on Qualcomm® devices. More details on model performance
across various devices, can be found [here](https://aihub.qualcomm.com/models/deeplab_xception).

Qualcomm AI Hub Models uses [Qualcomm AI Hub Workbench](https://workbench.aihub.qualcomm.com) to compile, profile, and evaluate this model. [Sign up](https://myaccount.qualcomm.com/signup) to run these models on a hosted Qualcomm® device.




## Example & Usage

Install the package via pip:
```bash
# NOTE: 3.10 <= PYTHON_VERSION < 3.14 is supported.
pip install qai-hub-models
```


Once installed, run the following simple CLI demo on the host machine:

```bash
python -m qai_hub_models.models.deeplab_xception.demo { --quantize w8a8 }
```
More details on the CLI tool can be found with the `--help` option. See
[demo.py](demo.py) for sample usage of the model including pre/post processing
scripts. Please refer to our [general instructions on using
models](../../../#getting-started) for more usage instructions.

## Export for on-device deployment

This package contains export scripts that produce a model optimized for
on-device deployment. This can be run as follows:

```bash
python -m qai_hub_models.models.deeplab_xception.export { --quantize w8a8 }
```
Additional options are documented with the `--help` option.


## License
* The license for the original implementation of DeepLabXception can be found
  [here](https://github.com/pytorch/vision/blob/main/LICENSE).


## References
* [Encoder-Decoder with Atrous Separable Convolution for Semantic Image Segmentation](https://arxiv.org/abs/1802.02611)
* [Source Model Implementation](https://github.com/LikeLy-Journey/SegmenTron)



## Community
* Join [our AI Hub Slack community](https://aihub.qualcomm.com/community/slack) to collaborate, post questions and learn more about on-device AI.
* For questions or feedback please [reach out to us](mailto:ai-hub-support@qti.qualcomm.com).
