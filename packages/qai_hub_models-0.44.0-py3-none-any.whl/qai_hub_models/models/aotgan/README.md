# [AOT-GAN: High resolution image in-painting on-device](https://aihub.qualcomm.com/models/aotgan)

AOT-GAN is a machine learning model that allows to erase and in-paint part of given input image.

This is based on the implementation of AOT-GAN found [here](https://github.com/researchmm/AOT-GAN-for-Inpainting). This repository contains scripts for optimized on-device
export suitable to run on Qualcomm® devices. More details on model performance
across various devices, can be found [here](https://aihub.qualcomm.com/models/aotgan).

Qualcomm AI Hub Models uses [Qualcomm AI Hub Workbench](https://workbench.aihub.qualcomm.com) to compile, profile, and evaluate this model. [Sign up](https://myaccount.qualcomm.com/signup) to run these models on a hosted Qualcomm® device.




## Example & Usage

Install the package via pip:
```bash
# NOTE: 3.10 <= PYTHON_VERSION < 3.14 is supported.
pip install qai-hub-models
```


Once installed, run the following simple CLI demo on the host machine:

```bash
python -m qai_hub_models.models.aotgan.demo
```
More details on the CLI tool can be found with the `--help` option. See
[demo.py](demo.py) for sample usage of the model including pre/post processing
scripts. Please refer to our [general instructions on using
models](../../../#getting-started) for more usage instructions.

## Export for on-device deployment

This package contains export scripts that produce a model optimized for
on-device deployment. This can be run as follows:

```bash
python -m qai_hub_models.models.aotgan.export
```
Additional options are documented with the `--help` option.


## License
* The license for the original implementation of AOT-GAN can be found
  [here](https://github.com/taki0112/AttnGAN-Tensorflow/blob/master/LICENSE).


## References
* [Aggregated Contextual Transformations for High-Resolution Image Inpainting](https://arxiv.org/abs/2104.01431)
* [Source Model Implementation](https://github.com/researchmm/AOT-GAN-for-Inpainting)



## Community
* Join [our AI Hub Slack community](https://aihub.qualcomm.com/community/slack) to collaborate, post questions and learn more about on-device AI.
* For questions or feedback please [reach out to us](mailto:ai-hub-support@qti.qualcomm.com).
