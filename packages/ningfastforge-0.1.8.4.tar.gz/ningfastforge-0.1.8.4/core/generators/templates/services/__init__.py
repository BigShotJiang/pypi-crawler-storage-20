"""Business logic service generators"""
