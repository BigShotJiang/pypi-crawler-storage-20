"""CRUD operation generators"""
