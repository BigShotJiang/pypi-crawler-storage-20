"""API routergenerategenerator"""
