from pydantic import BaseModel


class PluginManifest(BaseModel):
    name: str
    version: str