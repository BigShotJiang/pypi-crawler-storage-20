import semver
from jsonschema import Draft202012Validator as SchemaValidator
from jsonschema import SchemaError
from pydantic import BaseModel, Field, field_validator

from .models import PluginIOTypeDescriptor


class PluginSignature(BaseModel):
    plugin_api_version: str
    inputs: list[PluginIOTypeDescriptor] = Field(description="List of inputs to the plugin.")
    outputs: list[PluginIOTypeDescriptor] = Field(description="List of outputs from the plugin.")

class PluginManifest(BaseModel):
    manifest_version: str = "3"
    plugin_api_version: str = "3"
    name: str = Field(description="Human-readable name of the plugin")
    type: str = Field(description="Type of plugin, e.g. 'source', 'destination', 'transformer'")
    subtype: str = Field(description="Subtype of plugin, e.g. 'csv', 'json', 's3'")
    version: str = Field(description="Version of the plugin. Must parse as semver. e.g. '1.0.0'")
    image_name: str = Field(description="Name of the Docker image to use for the plugin")
    signature: PluginSignature = Field(description="Signature of the plugin, describing inputs and outputs.")
    settings: dict = Field(description="Settings for the plugin, as a JSON schema.")
    metadata: dict[str, str|list[str]|dict[str, str]] = Field(description="Metadata for the plugin, such as tags")
    presentation: dict = Field(description="Presentation infor for the plugin, e.g. icon, settings layout.")

    @classmethod
    @field_validator("manifest_version", "plugin_api_version")
    def validate_manifest_version(cls, v):
        if v != "3":
            raise ValueError(f"Invalid manifest version: {v}, expected 3.")
        return v

    @classmethod
    @field_validator("settings")
    def validate_settings(cls, v):
        if v:
            try:
                SchemaValidator.check_schema(v)
            except SchemaError as e:
                raise ValueError(f"Invalid settings schema: {e}")
        return v

    @classmethod
    @field_validator("version")
    def validate_version(cls, v):
        semver.VersionInfo.parse(v)
