# -*- coding: utf-8 -*-
"""
项目创建UI界面
"""
import sys
import os
from pathlib import Path
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QLabel, QLineEdit, QPushButton, 
                             QFileDialog, QMessageBox, QComboBox)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtGui import QIcon
from pyscreeps_arena.core import const
from pyscreeps_arena.ui.rs_icon import get_pixmap
from pyscreeps_arena.afters import ToConfigAfter, ToEmptyAfter, ToPrefabAfter, ToCustomAfter
from PyQt6.QtWidgets import QRadioButton, QGroupBox



class ProjectCreatorUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self._proj_name = ""
        self._proj_path = ""
        self._init_ui()
        
    def _init_ui(self):
        """初始化UI界面"""
        self.setWindowTitle("PyScreeps Arena - 项目创建器")
        self.setWindowIcon(QIcon(get_pixmap()))
        self.setFixedSize(500, 580)
        
        # 主窗口部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setSpacing(15)
        layout.setContentsMargins(30, 30, 30, 30)
        
        # 标题
        title = QLabel("PyScreeps Arena")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_font = QFont()
        title_font.setPointSize(18)
        title_font.setBold(True)
        title.setFont(title_font)
        layout.addWidget(title)
        
        # 项目信息
        info_widget = QWidget()
        info_layout = QVBoxLayout(info_widget)
        info_layout.setSpacing(8)
        
        # 版本信息
        version_label = QLabel(f"版本: {const.VERSION}")
        version_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info_layout.addWidget(version_label)
        
        # 作者信息
        author_label = QLabel(f"作者: {const.AUTHOR}")
        author_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info_layout.addWidget(author_label)
        
        # GitHub信息
        github_label = QLabel(f"GitHub: {const.GITHUB_NAME}")
        github_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info_layout.addWidget(github_label)
        
        layout.addWidget(info_widget)
        
        # 分隔线
        separator = QLabel("─" * 50)
        separator.setAlignment(Qt.AlignmentFlag.AlignCenter)
        separator.setStyleSheet("color: #ccc;")
        layout.addWidget(separator)
        
        # 项目输入区域
        input_widget = QWidget()
        input_layout = QVBoxLayout(input_widget)
        input_layout.setSpacing(12)
        
        # 项目名称输入
        name_layout = QHBoxLayout()
        name_label = QLabel("项目名称:")
        name_label.setFixedWidth(80)
        self._name_input = QLineEdit()
        self._name_input.setPlaceholderText("输入项目名称...")
        self._name_input.textChanged.connect(self._on_name_changed)
        self._name_input.returnPressed.connect(self._create_project)
        name_layout.addWidget(name_label)
        name_layout.addWidget(self._name_input)
        input_layout.addLayout(name_layout)
        
        # 项目路径输入
        path_layout = QHBoxLayout()
        path_label = QLabel("保存位置:")
        path_label.setFixedWidth(80)
        self._path_input = QLineEdit()
        self._path_input.setPlaceholderText("选择项目保存位置...")
        self._path_input.setReadOnly(True)
        # 默认桌面路径
        desktop_path = os.path.join(os.path.expanduser("~"), "Desktop")
        if os.path.exists(desktop_path):
            self._path_input.setText(desktop_path)
            self._proj_path = desktop_path
        path_layout.addWidget(path_label)
        path_layout.addWidget(self._path_input)
        
        # 浏览按钮
        browse_btn = QPushButton("浏览...")
        browse_btn.setFixedWidth(60)
        browse_btn.clicked.connect(self._browse_path)
        path_layout.addWidget(browse_btn)
        
        input_layout.addLayout(path_layout)
        layout.addWidget(input_widget)
        
        # 分隔线
        separator2 = QLabel("─" * 50)
        separator2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        separator2.setStyleSheet("color: #ccc;")
        layout.addWidget(separator2)
        
        # 配置选项区域（左右布局）
        config_container = QWidget()
        config_container_layout = QHBoxLayout(config_container)
        config_container_layout.setSpacing(20)
        
        # 左侧：语言、竞技场、难度配置
        left_config_widget = QWidget()
        left_config_layout = QVBoxLayout(left_config_widget)
        left_config_layout.setSpacing(10)
        
        # 语言选择
        lang_layout = QHBoxLayout()
        lang_label = QLabel("语 言:")
        lang_label.setFixedWidth(80)
        self._lang_combo = QComboBox()
        self._lang_combo.addItems(["中文 (cn)", "英文 (en)"])
        self._lang_combo.setCurrentIndex(0)
        lang_layout.addWidget(lang_label)
        lang_layout.addWidget(self._lang_combo)
        left_config_layout.addLayout(lang_layout)
        
        # 竞技场选择
        arena_layout = QHBoxLayout()
        arena_label = QLabel("竞技场:")
        arena_label.setFixedWidth(80)
        self._arena_combo = QComboBox()
        self._arena_combo.addItems(["灰色 (gray)", "绿色 (green)", "蓝色 (blue)", "红色 (red)"])
        self._arena_combo.setCurrentIndex(0)
        arena_layout.addWidget(arena_label)
        arena_layout.addWidget(self._arena_combo)
        left_config_layout.addLayout(arena_layout)
        
        # 难度级别选择
        level_layout = QHBoxLayout()
        level_label = QLabel("难 度:")
        level_label.setFixedWidth(80)
        self._level_combo = QComboBox()
        self._level_combo.addItems(["基础 (basic)", "高级 (advanced)"])
        self._level_combo.setCurrentIndex(0)
        level_layout.addWidget(level_label)
        level_layout.addWidget(self._level_combo)
        left_config_layout.addLayout(level_layout)
        
        config_container_layout.addWidget(left_config_widget)
        
        # 右侧：模式选择（单选框）
        right_config_widget = QWidget()
        right_config_layout = QVBoxLayout(right_config_widget)
        right_config_layout.setSpacing(8)
        
        # 模式选择标题
        # mode_title = QLabel("模式选择")
        # mode_title.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        # right_config_layout.addWidget(mode_title)
        
        # 单选按钮
        self._empty_radio = QRadioButton("空白 (Empty)")
        self._basic_radio = QRadioButton("基础 (Basic)")
        self._prefab_radio = QRadioButton("预设 (Prefab)")
        self._pi_radio = QRadioButton("预设继承 (P&&I)")
        
        # 默认选择基础模式
        self._basic_radio.setChecked(True)
        
        # 添加到布局
        right_config_layout.addWidget(self._empty_radio)
        right_config_layout.addWidget(self._basic_radio)
        right_config_layout.addWidget(self._prefab_radio)
        right_config_layout.addWidget(self._pi_radio)
        
        config_container_layout.addWidget(right_config_widget)
        
        layout.addWidget(config_container)
        
        # 按钮区域
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        # 创建按钮
        self._create_btn = QPushButton("创建项目")
        self._create_btn.setFixedSize(100, 35)
        self._create_btn.clicked.connect(self._create_project)
        self._create_btn.setEnabled(False)
        self._create_btn.setDefault(True)
        button_layout.addWidget(self._create_btn)
        
        # 取消按钮
        cancel_btn = QPushButton("取消")
        cancel_btn.setFixedSize(80, 35)
        cancel_btn.clicked.connect(self.close)
        button_layout.addWidget(cancel_btn)
        
        layout.addLayout(button_layout)
        layout.addStretch()
        
    def _on_name_changed(self, text):
        """项目名称改变时的处理"""
        self._proj_name = text.strip()
        self._create_btn.setEnabled(bool(self._proj_name and self._proj_path))
        
    def _browse_path(self):
        """浏览选择路径"""
        current_path = self._path_input.text() or os.path.expanduser("~")
        path = QFileDialog.getExistingDirectory(
            self, "选择项目保存位置", current_path
        )
        if path:
            self._path_input.setText(path)
            self._proj_path = path
            self._create_btn.setEnabled(bool(self._proj_name and self._proj_path))
            
    def _create_project(self):
        """创建项目"""
        if not self._proj_name or not self._proj_path:
            return
            
        # 构建完整路径
        full_path = os.path.join(self._proj_path, self._proj_name)
        
        # 检查路径是否已存在
        if os.path.exists(full_path):
            reply = QMessageBox.question(
                self, "路径已存在",
                f"路径 '{full_path}' 已存在。\n是否继续？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
        
        try:
            # 创建项目
            self._extract_project_template(full_path)
            
            QMessageBox.information(
                self, "成功",
                f"项目 '{self._proj_name}' 创建成功！\n路径: {full_path}"
            )
            self.close()
            
        except Exception as e:
            QMessageBox.critical(
                self, "错误",
                f"项目创建失败:\n{str(e)}"
            )
            
    def _extract_project_template(self, target_path):
        """提取项目模板"""
        # 获取当前包路径
        this_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        project_7z_path = os.path.join(this_path, 'project.7z')
        
        if not os.path.exists(project_7z_path):
            raise FileNotFoundError(f"项目模板文件不存在: {project_7z_path}")
            
        # 创建目标目录
        os.makedirs(target_path, exist_ok=True)
        
        # 解压项目模板
        import py7zr
        with py7zr.SevenZipFile(project_7z_path, mode='r') as archive:
            archive.extractall(path=target_path)
            
        print(f"[DEBUG] 项目模板已解压到: {target_path}")  # 调试输出
        
        # 获取用户选择的配置
        lang_text = self._lang_combo.currentText()
        lang = lang_text.split('(')[1].strip(')')
        
        arena_text = self._arena_combo.currentText()
        arena = arena_text.split('(')[1].strip(')')
        
        level_text = self._level_combo.currentText()
        level = level_text.split('(')[1].strip(')')
        
        # 调用配置方法
        ToConfigAfter(path=target_path, language=lang, arena=arena, level=level)
        print(f"[DEBUG] 项目配置已更新: language={lang}, arena={arena}, level={level}")  # 调试输出
        
        # 根据选择的模式执行相应的操作
        if self._empty_radio.isChecked():
            print(f"[DEBUG] 执行空白模式配置")
            ToEmptyAfter(path=target_path)
        elif self._basic_radio.isChecked():
            print(f"[DEBUG] 执行基础模式配置（不操作）")
            # 基础模式不执行任何操作
        elif self._prefab_radio.isChecked():
            print(f"[DEBUG] 执行预设模式配置")
            ToPrefabAfter(path=target_path)
        elif self._pi_radio.isChecked():
            print(f"[DEBUG] 执行预设继承模式配置")
            ToPrefabAfter(path=target_path)
            ToCustomAfter(path=target_path)


def run_project_creator():
    """运行项目创建器UI"""
    app = QApplication(sys.argv)
    window = ProjectCreatorUI()
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    run_project_creator()
