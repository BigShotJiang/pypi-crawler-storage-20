module main

fn main() {
  print("Hello from Roc!");
}