import io
from typing import Any, Union

import polars as pl
from minio import Minio

from evaluation_embedder.src.connectors import DatasetConnector
from evaluation_embedder.src.settings import MinioDatasetConnectorSettings


class MinioDatasetConnector(DatasetConnector[MinioDatasetConnectorSettings]):

    def __init__(self, config: MinioDatasetConnectorSettings):
        super().__init__(config)

    def _load(self) -> Union[pl.DataFrame, pl.LazyFrame]:
        client = Minio(
            self.config.endpoint.replace("http://", "").replace("https://", ""),
            access_key=self.config.access_key,
            secret_key=self.config.secret_key,
            secure=self.config.endpoint.startswith("https://"),
        )
        response = client.get_object(self.config.bucket, self.config.key)
        try:
            buffer = io.BytesIO(response.read())
        finally:
            response.close()
            response.release_conn()
        df = pl.read_parquet(buffer)
        return df
