from pathlib import Path
from typing import Any, Union

import polars as pl

from evaluation_embedder.src.connectors import DatasetConnector
from evaluation_embedder.src.settings import ParquetDatasetConnectorSettings


class ParquetDatasetConnector(DatasetConnector[ParquetDatasetConnectorSettings]):

    def __init__(self, config: ParquetDatasetConnectorSettings):
        super().__init__(config)

    def _load(self) -> Union[pl.DataFrame, pl.LazyFrame]:
        df = pl.scan_parquet(self.config.path) if self.config.lazy else pl.read_parquet(self.config.path)
        return df
