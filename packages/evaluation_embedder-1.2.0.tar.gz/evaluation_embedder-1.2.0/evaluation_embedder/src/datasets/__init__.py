import io
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Generic,
    Iterable,
    Iterator,
    List,
    Literal,
    Optional,
    Self,
    Tuple,
    Union,
    cast,
    overload,
)

import polars as pl
from langchain_core.documents import Document
from minio import Minio
from polars._typing import ColumnNameOrSelector, IntoExpr, IntoExprColumn

from evaluation_embedder.src.connectors.minio import MinioDatasetConnector
from evaluation_embedder.src.connectors.parquet import ParquetDatasetConnector
from evaluation_embedder.src.constants import ParquetCompression, TDataset
from evaluation_embedder.src.datasets.mixins import TextDatasetMixin
from evaluation_embedder.src.settings import (
    MinioDatasetConnectorSettings,
    ParquetDatasetConnectorSettings,
)

if TYPE_CHECKING:
    pass
_logger = logging.getLogger(__name__)


class Dataset(ABC, Generic[TDataset]):
    def __init__(self, service: TDataset):
        super().__init__()
        self.service = service
        self._polars: Optional[pl.DataFrame] = None
        self._lazy_polars: Optional[pl.LazyFrame] = None

    @classmethod
    @abstractmethod
    def from_polars(cls, df: Union[pl.DataFrame, pl.LazyFrame]) -> Self:
        raise NotImplementedError

    @abstractmethod
    def to_polars(self) -> pl.DataFrame:
        raise NotImplementedError

    @abstractmethod
    def to_lazy_polars(self) -> pl.LazyFrame:
        raise NotImplementedError

    @classmethod
    def from_parquet(
        cls,
        path: str,
        *,
        lazy: bool = True,
    ) -> "Dataset[Union[pl.DataFrame, pl.LazyFrame]]":
        conn = ParquetDatasetConnector(ParquetDatasetConnectorSettings(module_path='', path=path, lazy=lazy))
        return conn.load()

    @classmethod
    def from_minio(
        cls,
        *,
        bucket: str,
        key: str,
        endpoint: str,
        access_key: str,
        secret_key: str,
    ) -> "Dataset[Union[pl.DataFrame, pl.LazyFrame]]":
        kwargs = {
            "bucket": bucket,
            "key": key,
            "endpoint": endpoint,
            "access_key": access_key,
            "secret_key": secret_key,
        }
        config = MinioDatasetConnectorSettings(module_path='', **kwargs)
        return MinioDatasetConnector(config).load()

    def to_minio(
        self,
        *,
        bucket: str,
        key: str,
        endpoint_url: str,
        access_key: str,
        secret_key: str,
        compression: ParquetCompression = "zstd",
        row_group_size: int = 100_000,
    ) -> None:
        client = Minio(
            endpoint_url.replace("http://", "").replace("https://", ""),
            access_key=access_key,
            secret_key=secret_key,
            secure=endpoint_url.startswith("https://"),
        )
        buffer = io.BytesIO()
        self.polars.write_parquet(
            buffer,
            compression=compression,
            row_group_size=row_group_size,
        )
        buffer.seek(0)
        client.put_object(
            bucket_name=bucket,
            object_name=key,
            data=buffer,
            length=buffer.getbuffer().nbytes,
            content_type="application/octet-stream",
        )

    @property
    def polars(self) -> pl.DataFrame:
        if self._polars is None:
            self._polars = self.to_polars()
        return self._polars

    @property
    def lazy_polars(self) -> pl.LazyFrame:
        if self._lazy_polars is None:
            self._lazy_polars = self.to_lazy_polars()
        return self._lazy_polars

    @property
    def polars_shape(self) -> Tuple[int, int]:
        return self.polars.shape

    def with_columns(
        self,
        *exprs: IntoExpr | Iterable[IntoExpr],
        **named_exprs: IntoExpr,
    ) -> Self:
        df = self.polars.with_columns(*exprs, **named_exprs)
        return self.__class__.from_polars(df)

    def filter(
        self,
        *predicates: (IntoExprColumn | Iterable[IntoExprColumn] | bool | list[bool]),
        **constraints: Any,
    ) -> Self:
        return self.__class__.from_polars(self.polars.filter(*predicates, **constraints))

    def drop(
        self,
        *columns: ColumnNameOrSelector | Iterable[ColumnNameOrSelector],
        strict: bool = True,
    ) -> Self:
        return self.__class__.from_polars(self.polars.drop(*columns, strict=strict))

    def __len__(self) -> int:
        return self.polars_shape[0]

    @overload
    def iter_rows(self, *, named: Literal[False] = ..., buffer_size: int = ...) -> Iterator[Tuple[Any, ...]]: ...

    @overload
    def iter_rows(self, *, named: Literal[True], buffer_size: int = ...) -> Iterator[Dict[str, Any]]: ...

    def iter_rows(
        self, *, named: Literal[False, True] = False, buffer_size: int = 512
    ) -> Iterator[Tuple[Any, ...]] | Iterator[Dict[str, Any]]:
        df_stream = self.lazy_polars.collect(streaming=True)  # type: ignore[call-overload]
        return df_stream.iter_rows(named=named, buffer_size=buffer_size)  # type: ignore[no-any-return]


class TextDataset(Dataset[TDataset], TextDatasetMixin[TDataset], Generic[TDataset]):

    def __init__(self, service: TDataset):
        super().__init__(service)
        self._validate_schema()

    @classmethod
    def from_parquet(
        cls,
        path: str,
        *,
        lazy: bool = True,
    ) -> "TextDataset[Union[pl.DataFrame, pl.LazyFrame]]":
        conn = ParquetDatasetConnector(ParquetDatasetConnectorSettings(module_path='', path=path, lazy=lazy))
        return conn.load_text()

    @classmethod
    def from_minio(
        cls,
        *,
        bucket: str,
        key: str,
        endpoint: str,
        access_key: str,
        secret_key: str,
    ) -> "TextDataset[Union[pl.DataFrame, pl.LazyFrame]]":
        kwargs = {
            "bucket": bucket,
            "key": key,
            "endpoint": endpoint,
            "access_key": access_key,
            "secret_key": secret_key,
        }
        config = MinioDatasetConnectorSettings(module_path='', **kwargs)
        return MinioDatasetConnector(config).load_text()
