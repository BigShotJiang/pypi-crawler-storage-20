from typing import Generic, List, Optional, Union

from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    YamlConfigSettingsSource,
)

from evaluation_embedder.src.constants import (
    CONFIG_PATH,
    FAISSIndexType,
    TCDatasetConnector,
    TCEmbedder,
    TCProcessor,
    TCRetriever,
    TCScore,
    TCTextPreprocessor,
    TCTokenCounter,
    TCVectorStore,
)


class FromConfigMixinSettings(BaseSettings):
    module_path: str
    model_config = SettingsConfigDict(
        yaml_file=CONFIG_PATH,
        extra="ignore",
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            YamlConfigSettingsSource(settings_cls),
            env_settings,
            dotenv_settings,
            file_secret_settings,
        )


class DatasetConnectorSettings(FromConfigMixinSettings):
    pass


class ParquetDatasetConnectorSettings(DatasetConnectorSettings):
    path: str
    lazy: bool


class MinioDatasetConnectorSettings(DatasetConnectorSettings):
    endpoint: str
    bucket: str
    key: str
    access_key: str
    secret_key: str
    model_config = SettingsConfigDict(env_prefix='MINIO_', extra="ignore")


class EmbedderSettings(FromConfigMixinSettings):
    model_name: str


class VLLMEmbedderSettings(EmbedderSettings):
    base_url: str


class ProcessorSettings(FromConfigMixinSettings):
    pass


class NomicProcessorSettings(ProcessorSettings):
    pass


class ScoreSettings(BaseSettings):
    module_path: str


class RecallAtKScoreSettings(ScoreSettings):
    k: int


class PrecisionAtKScoreSettings(ScoreSettings):
    k: int


class HitAtKScoreSettings(ScoreSettings):
    k: int


class MRRAtKScoreSettings(ScoreSettings):
    k: int


class VectorStoreSettings(FromConfigMixinSettings):
    pass


class QdrantVectorStoreSettings(VectorStoreSettings):
    url: str
    collection_name: str


class FaissVectorStoreSettings(VectorStoreSettings):
    index_type: FAISSIndexType
    normalize: bool


class RetrieverSettings(FromConfigMixinSettings, Generic[TCEmbedder, TCVectorStore, TCProcessor]):
    embedder: TCEmbedder
    vector_store: TCVectorStore
    processor: TCProcessor


class EvaluatorSettings(FromConfigMixinSettings, Generic[TCDatasetConnector, TCRetriever, TCScore]):
    dataset_connector: TCDatasetConnector
    retriever: TCRetriever
    scores: List[TCScore]


class QdrantEvaluatorSettings(
    EvaluatorSettings[
        MinioDatasetConnectorSettings,
        RetrieverSettings[VLLMEmbedderSettings, QdrantVectorStoreSettings, NomicProcessorSettings],
        RecallAtKScoreSettings,
    ]
):
    pass


class FaissEvaluatorSettings(
    EvaluatorSettings[
        MinioDatasetConnectorSettings,
        RetrieverSettings[VLLMEmbedderSettings, FaissVectorStoreSettings, NomicProcessorSettings],
        RecallAtKScoreSettings,
    ]
):
    pass


class TextPreprocessorSettings(FromConfigMixinSettings):
    pass


class TokenCounterSettings(FromConfigMixinSettings):
    pass


class HeuristicTokenCounterSettings(TokenCounterSettings):
    chars_per_token: int


class TokenFilterSettings(TextPreprocessorSettings, Generic[TCTokenCounter]):
    token_counter: TCTokenCounter


class MinTokenFilterSettings(TokenFilterSettings[TCTokenCounter], Generic[TCTokenCounter]):
    min_tokens: int


class MaxTokenFilterSettings(TokenFilterSettings[TCTokenCounter], Generic[TCTokenCounter]):
    max_tokens: int


class QuantileTokenFilterSettings(TokenFilterSettings[TCTokenCounter], Generic[TCTokenCounter]):
    q: float


class SigmaBandTokenFilterSettings(TokenFilterSettings[TCTokenCounter], Generic[TCTokenCounter]):
    z: float


AnyTextPreprocessorSettings = Union[
    MinTokenFilterSettings[HeuristicTokenCounterSettings],
    MaxTokenFilterSettings[HeuristicTokenCounterSettings],
    QuantileTokenFilterSettings[HeuristicTokenCounterSettings],
    SigmaBandTokenFilterSettings[HeuristicTokenCounterSettings],
]


class PreprocessPipelineSettings(TextPreprocessorSettings):
    steps: List[AnyTextPreprocessorSettings]


class TextIngestionPipelineSettings(FromConfigMixinSettings, Generic[TCDatasetConnector, TCTextPreprocessor]):
    connector: TCDatasetConnector
    preprocessor: TCTextPreprocessor
