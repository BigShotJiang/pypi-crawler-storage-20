#!/usr/bin/env python3
import subprocess
import json
import os
import redshift_connector
import pandas as pd
from tabulate import tabulate
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import base64
import io
from io import BytesIO
import glob

# Configuration
CHUNK_SIZE = 1000000  # 1M rows per chunk - adjust as needed
KEEP_CHUNK_FILES = True  # Set to False to delete chunk files after combining

def cleanup_old_chunks(csv_file):
    """Remove old chunk files for this analysis"""
    base_name = csv_file.replace('.csv', '')
    chunk_pattern = f"{base_name}_chunk*.csv"
    old_chunks = glob.glob(chunk_pattern)
    
    for chunk_file in old_chunks:
        try:
            os.remove(chunk_file)
            print(f"🗑️  Removed old chunk: {os.path.basename(chunk_file)}")
        except OSError:
            pass

def get_user_inputs():
    """Get week number and start date from user"""
    print("\n" + "="*60)
    print("OIH QUERY SETUP - Please provide the following inputs:")
    print("="*60)
    
    print("\n1. WEEK NUMBER:")
    print("   Enter the week number you want to analyze (e.g., 1, 2, 3, etc.)")
    week_number = input("   Week Number: ").strip()
    
    print(f"\n2. WEEK START DATE:")
    print("   Enter the Sunday start date for Week {week_number}")
    print("   Format: YYYY-MM-DD (e.g., 2025-12-28)")
    print("   Note: This must be a Sunday")
    start_date = input("   Start Date: ").strip()
    
    # Calculate YoY date (subtract 1 year, add 1 day to account for leap year)
    current_date = datetime.strptime(start_date, '%Y-%m-%d')
    yoy_date = current_date.replace(year=current_date.year - 1) + timedelta(days=1)
    yoy_start_date = yoy_date.strftime('%Y-%m-%d')
    
    # Calculate last month's week (4 weeks prior, ensuring it's a Sunday)
    last_month_date = current_date - timedelta(weeks=4)
    last_month_start_date = last_month_date.strftime('%Y-%m-%d')
    
    print(f"\n" + "="*60)
    print("ANALYSIS PERIODS:")
    print(f"Current Period:    Week {week_number}, Start date: {start_date}")
    print(f"Last Month Period: Week {week_number}, Start date: {last_month_start_date}")
    print(f"YoY Period:        Week {week_number}, Start date: {yoy_start_date}")
    print("="*60)
    
    print(f"\n✓ Inputs collected successfully!", flush=True)
    print(f"✓ Proceeding with OIH analysis...", flush=True)
    
    return week_number, start_date, last_month_start_date, yoy_start_date

def get_connection():
    """Establish connection to Redshift using ADA credentials"""
    cmd = ['ada', 'credentials', 'print', '--profile=SDWRedshift']
    creds = json.loads(subprocess.run(cmd, check=True, capture_output=True, text=True).stdout)

    os.environ.update({
        'AWS_ACCESS_KEY_ID': creds['AccessKeyId'],
        'AWS_SECRET_ACCESS_KEY': creds['SecretAccessKey'],
        'AWS_SESSION_TOKEN': creds.get('SessionToken', ''),
        'AWS_DEFAULT_REGION': 'us-east-1'
    })

    return redshift_connector.connect(
        host='vpce-0ae5757d114c3b023-1cp3ohw5.vpce-svc-0c480afad956a834b.us-east-1.vpce.amazonaws.com',
        database='f2dw_global_03', port=5439, iam=True,
        cluster_identifier='f2dw-global-03', group_federation=True,
        application_name='oih_query', region='us-east-1'
    )

def create_gl_trend_charts(trend_data):
    """Create individual GL trend charts for appendix"""
    if trend_data is None or trend_data.empty:
        return {}
    
    # GL mapping for names
    gl_mapping = {
        193: 'Apparel',
        197: 'Jewelry', 
        198: 'Luggage',
        200: 'Sports',
        241: 'Watches',
        309: 'Shoes',
        468: 'Outdoors'
    }
    
    gl_charts = {}
    unique_gls = trend_data['gl_product_group'].unique()
    
    for gl in unique_gls:
        gl_data = trend_data[trend_data['gl_product_group'] == gl].copy()
        
        # Separate current and YoY data for this GL
        current_data = gl_data[gl_data['time_period'].str.contains('Current Week', na=False)].copy()
        yoy_data = gl_data[gl_data['time_period'].str.contains('YoY Week', na=False)].copy()
        
        if current_data.empty and yoy_data.empty:
            continue
        
        # Calculate unhealthy percentages by date
        current_data['unhealthy_pct'] = (current_data['below_cost_oih_cost'] / current_data['oih_managed_cost'] * 100).fillna(0)
        yoy_data['unhealthy_pct'] = (yoy_data['below_cost_oih_cost'] / yoy_data['oih_managed_cost'] * 100).fillna(0)
        
        current_trend = current_data.sort_values('rundate')
        yoy_trend = yoy_data.sort_values('rundate')
        
        # Create the chart
        fig, ax = plt.subplots(figsize=(10, 5))
        
        # Plot current trend
        if not current_trend.empty:
            dates = pd.to_datetime(current_trend['rundate'])
            ax.plot(dates, current_trend['unhealthy_pct'], 
                    marker='o', linewidth=2, markersize=5, color='#2c5aa0', label='Current 8 Weeks')
            # Add percentage labels on current trend points
            for date, pct in zip(dates, current_trend['unhealthy_pct']):
                ax.annotate(f'{pct:.1f}%', (date, pct), textcoords="offset points", 
                           xytext=(0,8), ha='center', fontsize=7, color='#2c5aa0')
        
        # Plot YoY trend on same x-axis dates as current
        if not yoy_trend.empty and not current_trend.empty:
            # Use current dates for x-axis, YoY data for y-axis
            dates = pd.to_datetime(current_trend['rundate'])
            ax.plot(dates, yoy_trend['unhealthy_pct'], 
                    marker='s', linewidth=2, markersize=5, color='#ff6b6b', label='YoY 8 Weeks')
            # Add percentage labels on YoY trend points
            for date, pct in zip(dates, yoy_trend['unhealthy_pct']):
                ax.annotate(f'{pct:.1f}%', (date, pct), textcoords="offset points", 
                           xytext=(0,-12), ha='center', fontsize=7, color='#ff6b6b')
        
        gl_name = gl_mapping.get(gl, f"GL{gl}")
        ax.set_title(f'{gl_name} - 8 Week Trend Comparison', fontsize=12, fontweight='bold', color='#2c5aa0')
        ax.set_ylabel('Unhealthy Rate (%)', fontsize=10)
        ax.grid(True, alpha=0.3)
        ax.legend()
        
        # Format x-axis dates - show only 8 weeks
        import matplotlib.dates as mdates
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%m/%d'))
        ax.xaxis.set_major_locator(mdates.WeekdayLocator(interval=1))
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
        
        # Format y-axis as percentage
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{y:.1f}%'))
        
        plt.tight_layout()
        
        # Convert to base64
        buffer = BytesIO()
        plt.savefig(buffer, format='png', dpi=300, bbox_inches='tight')
        buffer.seek(0)
        chart_b64 = base64.b64encode(buffer.getvalue()).decode()
        plt.close()
        
        gl_charts[gl] = chart_b64
    
    return gl_charts

def create_8week_trend_chart(trend_data):
    """Create 8-week trend comparison chart"""
    if trend_data is None or trend_data.empty:
        return None
    
    # Separate current and YoY data
    current_data = trend_data[trend_data['time_period'].str.contains('Current Week', na=False)].copy()
    yoy_data = trend_data[trend_data['time_period'].str.contains('YoY Week', na=False)].copy()
    
    if current_data.empty and yoy_data.empty:
        return None
    
    # Calculate unhealthy percentages by date
    current_data['unhealthy_pct'] = (current_data['below_cost_oih_cost'] / current_data['oih_managed_cost'] * 100).fillna(0)
    yoy_data['unhealthy_pct'] = (yoy_data['below_cost_oih_cost'] / yoy_data['oih_managed_cost'] * 100).fillna(0)
    
    # Group by date and sum across all GLs
    current_trend = current_data.groupby('rundate').agg({
        'oih_managed_cost': 'sum',
        'below_cost_oih_cost': 'sum'
    }).reset_index()
    current_trend['unhealthy_pct'] = (current_trend['below_cost_oih_cost'] / current_trend['oih_managed_cost'] * 100).fillna(0)
    current_trend = current_trend.sort_values('rundate')
    
    yoy_trend = yoy_data.groupby('rundate').agg({
        'oih_managed_cost': 'sum',
        'below_cost_oih_cost': 'sum'
    }).reset_index()
    yoy_trend['unhealthy_pct'] = (yoy_trend['below_cost_oih_cost'] / yoy_trend['oih_managed_cost'] * 100).fillna(0)
    yoy_trend = yoy_trend.sort_values('rundate')
    
    # Create the chart
    fig, ax = plt.subplots(figsize=(12, 6))
    
    # Plot current trend
    if not current_trend.empty:
        dates = pd.to_datetime(current_trend['rundate'])
        ax.plot(dates, current_trend['unhealthy_pct'], 
                marker='o', linewidth=2, markersize=6, color='#2c5aa0', label='Current 8 Weeks')
        # Add percentage labels on current trend points
        for date, pct in zip(dates, current_trend['unhealthy_pct']):
            ax.annotate(f'{pct:.1f}%', (date, pct), textcoords="offset points", 
                       xytext=(0,10), ha='center', fontsize=8, color='#2c5aa0')
    
    # Plot YoY trend on same x-axis dates as current
    if not yoy_trend.empty and not current_trend.empty:
        # Use current dates for x-axis, YoY data for y-axis
        dates = pd.to_datetime(current_trend['rundate'])
        ax.plot(dates, yoy_trend['unhealthy_pct'], 
                marker='s', linewidth=2, markersize=6, color='#ff6b6b', label='YoY 8 Weeks')
        # Add percentage labels on YoY trend points
        for date, pct in zip(dates, yoy_trend['unhealthy_pct']):
            ax.annotate(f'{pct:.1f}%', (date, pct), textcoords="offset points", 
                       xytext=(0,-15), ha='center', fontsize=8, color='#ff6b6b')
    
    ax.set_title('F2 OIH Unhealthy Rate - 8 Week Trend Comparison', fontsize=14, fontweight='bold', color='#2c5aa0')
    ax.set_ylabel('Unhealthy Rate (%)', fontsize=12)
    ax.grid(True, alpha=0.3)
    ax.legend()
    
    # Format x-axis dates - show only 8 weeks
    import matplotlib.dates as mdates
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%m/%d'))
    ax.xaxis.set_major_locator(mdates.WeekdayLocator(interval=1))
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    # Format y-axis as percentage
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{y:.1f}%'))
    
    plt.tight_layout()
    
    # Convert to base64
    buffer = BytesIO()
    plt.savefig(buffer, format='png', dpi=300, bbox_inches='tight')
    buffer.seek(0)
    chart_b64 = base64.b64encode(buffer.getvalue()).decode()
    plt.close()
    
    return chart_b64

def create_cost_comparison_chart(current_data, yoy_data):
    """Create chart comparing Current vs YoY Unhealthy Inventory"""
    current_total = float(current_data['oih_managed_cost'].sum())
    current_unhealthy = float(current_data['below_cost_oih_cost'].sum())
    
    yoy_total = float(yoy_data['oih_managed_cost'].sum())
    yoy_unhealthy = float(yoy_data['below_cost_oih_cost'].sum())
    
    current_pct = (current_unhealthy / current_total * 100) if current_total > 0 else 0
    yoy_pct = (yoy_unhealthy / yoy_total * 100) if yoy_total > 0 else 0
    
    fig, ax = plt.subplots(figsize=(10, 6))
    categories = ['Current Week %', 'YoY Week %']
    values = [current_pct, yoy_pct]
    colors = ['#e74c3c', '#3498db']
    
    bars = ax.bar(categories, values, color=colors, alpha=0.8)
    ax.set_ylabel('Unhealthy Rate (%)', fontsize=12)
    ax.set_title('OIH Unhealthy Inventory Comparison', fontsize=14, fontweight='bold')
    
    # Add value labels on bars
    for bar, value in zip(bars, values):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                f'${value:,.0f}', ha='center', va='bottom', fontweight='bold')
    
    plt.tight_layout()
    
    # Convert to base64
    buffer = BytesIO()
    plt.savefig(buffer, format='png', dpi=150, bbox_inches='tight')
    buffer.seek(0)
    chart_b64 = base64.b64encode(buffer.getvalue()).decode()
    plt.close()
    
def create_gl_analysis_chart(current_data, week_number):
    """Create GL analysis chart showing unhealthy cost and percentage"""
    
    # Group by GL and calculate metrics
    gl_analysis = current_data.groupby(['gl_product_group']).agg({
        'oih_managed_cost': 'sum',
        'below_cost_oih_cost': 'sum'
    }).reset_index()
    
    # Calculate unhealthy percentage
    gl_analysis['unhealthy_pct'] = (gl_analysis['below_cost_oih_cost'] / gl_analysis['oih_managed_cost'] * 100).fillna(0)
    
    # Sort by unhealthy cost descending
    gl_analysis = gl_analysis.sort_values('below_cost_oih_cost', ascending=False)
    
    # Create figure with secondary y-axis
    fig, ax1 = plt.subplots(figsize=(12, 8))
    ax2 = ax1.twinx()
    
    # Bar chart for unhealthy cost
    bars = ax1.bar(range(len(gl_analysis)), gl_analysis['below_cost_oih_cost'], 
                   color='#e74c3c', alpha=0.7, label='Unhealthy Cost ($)')
    
    # Line chart for unhealthy percentage
    line = ax2.plot(range(len(gl_analysis)), gl_analysis['unhealthy_pct'], 
                    color='#2c3e50', marker='o', linewidth=2, markersize=6, label='Unhealthy Rate (%)')
    
    # Customize axes
    ax1.set_ylabel('Unhealthy Cost ($)', fontsize=12, color='#e74c3c')
    ax2.set_ylabel('Unhealthy Rate (%)', fontsize=12, color='#2c3e50')
    
    # Set x-axis labels with proper GL names
    gl_mapping = {
        193: 'Apparel',
        197: 'Jewelry', 
        198: 'Luggage',
        200: 'Sports',
        241: 'Watches',
        309: 'Shoes',
        468: 'Outdoors'
    }
    
    gl_labels = [gl_mapping.get(gl, f"GL{gl}") 
                 for gl in gl_analysis['gl_product_group']]
    ax1.set_xticks(range(len(gl_analysis)))
    ax1.set_xticklabels(gl_labels, rotation=45, ha='right', fontsize=10)
    
    # Add value labels on bars
    for i, (bar, pct) in enumerate(zip(bars, gl_analysis['unhealthy_pct'])):
        height = bar.get_height()
        # Format cost in millions or billions
        if height >= 1000000000:
            cost_label = f'${height/1000000000:.1f}B'
        else:
            cost_label = f'${height/1000000:.1f}M'
        ax1.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                cost_label, ha='center', va='bottom', fontsize=9)
        ax2.text(i, pct + max(gl_analysis['unhealthy_pct'])*0.02,
                f'{pct:.1f}%', ha='center', va='bottom', fontsize=9, color='#2c3e50')
    
    # Title and legend
    plt.title(f'GL Product Groups - Week {week_number} Unhealthy Inventory Analysis', fontsize=14, fontweight='bold', pad=20)
    
    # Combine legends
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right')
    
    plt.tight_layout()
    
    # Convert to base64
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', dpi=300, bbox_inches='tight')
    buffer.seek(0)
    chart_b64 = base64.b64encode(buffer.getvalue()).decode()
    plt.close()
    
    return chart_b64

def generate_company_bridges(current_data, yoy_data, prev_data, last_month_data, worst_companies, company_brands, company_parent_asins, week_number):
    """Generate bridge analysis for worst companies"""
    bridges = []
    
    for _, company_row in worst_companies.iterrows():
        company = company_row['company_vendor_name']
        
        # Get company data for all periods
        company_current = current_data[current_data['company_vendor_name'] == company]
        company_yoy = yoy_data[yoy_data['company_vendor_name'] == company]
        company_prev = prev_data[prev_data['company_vendor_name'] == company]
        company_last_month = last_month_data[last_month_data['company_vendor_name'] == company]
        
        # Calculate company unhealthy rates
        current_unhealthy = (company_current['below_cost_oih_cost'].sum() / company_current['oih_managed_cost'].sum() * 100) if company_current['oih_managed_cost'].sum() > 0 else 0
        yoy_unhealthy = (company_yoy['below_cost_oih_cost'].sum() / company_yoy['oih_managed_cost'].sum() * 100) if company_yoy['oih_managed_cost'].sum() > 0 else 0
        prev_unhealthy = (company_prev['below_cost_oih_cost'].sum() / company_prev['oih_managed_cost'].sum() * 100) if company_prev['oih_managed_cost'].sum() > 0 else 0
        last_month_unhealthy = (company_last_month['below_cost_oih_cost'].sum() / company_last_month['oih_managed_cost'].sum() * 100) if company_last_month['oih_managed_cost'].sum() > 0 else 0
        
        # Calculate changes in basis points
        wow_change = (current_unhealthy - prev_unhealthy) * 100
        yoy_change = (current_unhealthy - yoy_unhealthy) * 100
        mom_change = (current_unhealthy - last_month_unhealthy) * 100
        
        # Get brands for this company and find top brands covering 75% of top 5 total CTC
        if company in company_brands:
            brands_df = company_brands[company].copy()
            brands_df = brands_df.sort_values('ctc_total', ascending=False)  # Sort by CTC descending first
            
            # Get top 5 brands and calculate 75% of their total CTC
            top_5_total_ctc = brands_df.head(5)['ctc_total'].sum()
            ctc_threshold = top_5_total_ctc * 0.75
            
            cumulative_ctc = 0
            selected_brands = []
            
            for _, brand_row in brands_df.iterrows():
                brand_cost = current_data[(current_data['company_vendor_name'] == company) & (current_data['brand_name'] == brand_row['brand_name'])]['oih_managed_cost'].sum()
                cumulative_ctc += brand_row['ctc_total']
                selected_brands.append({
                    'name': brand_row['brand_name'],
                    'unhealthy_rate': brand_row['unhealthy_pct_current'],
                    'yoy_ctc': brand_row['ctc_total'],
                    'managed_cost': brand_cost
                })
                if cumulative_ctc >= ctc_threshold:
                    break
        else:
            selected_brands = []
        
        # Format WoW change
        wow_text = f"better {wow_change:+.0f}bps WoW" if wow_change < 0 else f"worse {wow_change:+.0f}bps WoW"
        
        # Format MoM change
        mom_text = f"better {mom_change:+.0f}bps MoM" if mom_change < 0 else f"worse {mom_change:+.0f}bps MoM"
        
        # Format YoY change  
        yoy_text = f"better {yoy_change:+.0f}bps YoY" if yoy_change < 0 else f"worse {yoy_change:+.0f}bps YoY"
        
        # Build brand text with unhealthy rate only
        brand_texts = []
        total_mentioned_brands_unhealthy_cost = 0
        for brand in selected_brands:
            unhealthy_cost = brand['managed_cost'] * brand['unhealthy_rate'] / 100
            total_mentioned_brands_unhealthy_cost += unhealthy_cost
            brand_texts.append(f"{brand['name']} with unhealthy rate of {brand['unhealthy_rate']:.1f}% ({brand['yoy_ctc']:+.0f} YoY CTC)")
        
        # Calculate total company unhealthy cost and percentage
        company_total_unhealthy = company_current['below_cost_oih_cost'].sum()
        if total_mentioned_brands_unhealthy_cost >= 1000000000:
            total_cost_text = f"${total_mentioned_brands_unhealthy_cost/1000000000:.1f}B"
        else:
            total_cost_text = f"${total_mentioned_brands_unhealthy_cost/1000000:.1f}M"
        
        # Calculate mentioned brands percentage of company total
        if company_total_unhealthy > 0 and total_mentioned_brands_unhealthy_cost > 0:
            brands_pct = (total_mentioned_brands_unhealthy_cost / company_total_unhealthy) * 100
            brand_section = f". Major degrading brands involve " + " and ".join(brand_texts) + f" with collective unhealthy inventory cost of {total_cost_text} ({brands_pct:.0f}% of company total)" if brand_texts else ""
        else:
            brand_section = f". Major degrading brands involve " + " and ".join(brand_texts) if brand_texts else ""
        
        # Get parent ASINs for this company and find top ones covering 75% of top 5 total CTC
        parent_asin_section = ""
        if company in company_parent_asins:
            parent_asins_df = company_parent_asins[company].copy()
            parent_asins_df = parent_asins_df.sort_values('ctc_total', ascending=False)  # Sort by CTC descending
            
            # Get top 5 parent ASINs and calculate 70% of their total CTC
            top_5_total_ctc = parent_asins_df.head(5)['ctc_total'].sum()
            ctc_threshold = top_5_total_ctc * 0.70
            
            cumulative_ctc = 0
            selected_parent_asins = []
            
            for _, pasin_row in parent_asins_df.iterrows():
                cumulative_ctc += pasin_row['ctc_total']
                asin_parts = pasin_row['parent_asin_display'].split(' - ', 1)
                asin = asin_parts[0]
                parent_name = asin_parts[1] if len(asin_parts) > 1 else asin
                selected_parent_asins.append({
                    'asin': asin,
                    'parent_name': parent_name,
                    'unhealthy_rate': pasin_row['unhealthy_pct_current'],
                    'yoy_ctc': pasin_row['ctc_total'],
                    'managed_cost': pasin_row['oih_managed_cost_current']
                })
                if cumulative_ctc >= ctc_threshold:
                    break
            
            # Build parent ASIN text with inventory cost
            pasin_texts = []
            total_unhealthy_cost = 0
            for pasin in selected_parent_asins:
                unhealthy_cost = pasin['managed_cost'] * pasin['unhealthy_rate'] / 100
                total_unhealthy_cost += unhealthy_cost
                
                pasin_link = f'<a href="https://amazon.com/dp/{pasin["asin"]}" target="_blank">{pasin["parent_name"]}</a>'
                pasin_texts.append(f"{pasin_link} ({pasin['yoy_ctc']:+.0f} YoY CTC)")
            
            # Format total unhealthy cost
            if total_unhealthy_cost >= 1000000000:
                unhealthy_cost_text = f"${total_unhealthy_cost/1000000000:.1f}B"
            else:
                unhealthy_cost_text = f"${total_unhealthy_cost/1000000:.1f}M"
            
            parent_asin_section = f". Major degrading parent ASINs involve " + " and ".join(pasin_texts) + f" with collective unhealthy inventory cost of {unhealthy_cost_text}" if pasin_texts else ""
        
        # Calculate company YoY CTC
        company_yoy_ctc = 0
        if company in company_brands:
            company_yoy_ctc = company_brands[company]['ctc_total'].sum()
        
        # Generate bridge text
        bridge = f"<strong>{company}</strong> <strong>[{company_yoy_ctc:+.0f}bps YoY CTC]</strong> WK {week_number} OIH unhealthy rate was {current_unhealthy:.1f}% ({wow_text}, {mom_text}, {yoy_text}){brand_section}{parent_asin_section}."
        
        bridges.append(bridge)
    
    return bridges

def calculate_ctc_analysis(current_data, yoy_data, last_month_data):
    """Calculate CTC (Contribution to Change) analysis for companies and brands"""
    
    # Convert to float to avoid decimal issues
    current_data = current_data.copy()
    yoy_data = yoy_data.copy()
    
    current_data['oih_managed_cost'] = pd.to_numeric(current_data['oih_managed_cost'], errors='coerce').fillna(0)
    current_data['below_cost_oih_cost'] = pd.to_numeric(current_data['below_cost_oih_cost'], errors='coerce').fillna(0)
    
    yoy_data['oih_managed_cost'] = pd.to_numeric(yoy_data['oih_managed_cost'], errors='coerce').fillna(0)
    yoy_data['below_cost_oih_cost'] = pd.to_numeric(yoy_data['below_cost_oih_cost'], errors='coerce').fillna(0)
    
    # Calculate F2 totals (current and YoY)
    f2_total_current = current_data['oih_managed_cost'].sum()
    f2_oih_current = current_data['below_cost_oih_cost'].sum() / f2_total_current * 100 if f2_total_current > 0 else 0
    
    f2_total_yoy = yoy_data['oih_managed_cost'].sum()
    f2_oih_yoy = yoy_data['below_cost_oih_cost'].sum() / f2_total_yoy * 100 if f2_total_yoy > 0 else 0
    
    # Company analysis with proper CTC formulas
    company_current = current_data.groupby('company_vendor_name').agg({
        'oih_managed_cost': 'sum',
        'below_cost_oih_cost': 'sum'
    }).reset_index()
    
    company_yoy = yoy_data.groupby('company_vendor_name').agg({
        'oih_managed_cost': 'sum',
        'below_cost_oih_cost': 'sum'
    }).reset_index()
    
    # Merge current and YoY data
    company_analysis = company_current.merge(company_yoy, on='company_vendor_name', how='outer', suffixes=('_current', '_yoy')).fillna(0)
    
    company_analysis = company_analysis[
        (company_analysis['company_vendor_name'].notna()) & 
        (company_analysis['oih_managed_cost_current'] > 0)
    ]
    
    # Current period calculations
    company_analysis['current_oih'] = (company_analysis['below_cost_oih_cost_current'] / company_analysis['oih_managed_cost_current'] * 100).fillna(0)
    company_analysis['current_mix'] = (company_analysis['oih_managed_cost_current'] / f2_total_current * 100).fillna(0)
    
    # YoY period calculations
    company_analysis['yoy_oih'] = (company_analysis['below_cost_oih_cost_yoy'] / company_analysis['oih_managed_cost_yoy'] * 100).fillna(0)
    company_analysis['yoy_mix'] = (company_analysis['oih_managed_cost_yoy'] / f2_total_yoy * 100).fillna(0)
    
    # CTC calculations
    company_analysis['ctc_mix'] = (company_analysis['current_mix'] - company_analysis['yoy_mix']) * (company_analysis['yoy_oih'] - f2_oih_yoy)
    company_analysis['ctc_rate'] = company_analysis['current_mix'] * (company_analysis['current_oih'] - company_analysis['yoy_oih'])
    company_analysis['ctc_total'] = company_analysis['ctc_mix'] + company_analysis['ctc_rate']
    
    company_analysis['unhealthy_pct_current'] = company_analysis['current_oih']
    
    # Add last month data for MoM calculations
    if last_month_data is not None and not last_month_data.empty:
        last_month_data = last_month_data.copy()
        last_month_data['oih_managed_cost'] = pd.to_numeric(last_month_data['oih_managed_cost'], errors='coerce').fillna(0)
        last_month_data['below_cost_oih_cost'] = pd.to_numeric(last_month_data['below_cost_oih_cost'], errors='coerce').fillna(0)
        
        company_last_month = last_month_data.groupby('company_vendor_name').agg({
            'oih_managed_cost': 'sum',
            'below_cost_oih_cost': 'sum'
        }).reset_index()
        
        company_last_month['last_month_oih'] = (company_last_month['below_cost_oih_cost'] / company_last_month['oih_managed_cost'] * 100).fillna(0)
        
        # Merge with existing analysis
        company_analysis = company_analysis.merge(company_last_month[['company_vendor_name', 'last_month_oih']], on='company_vendor_name', how='left').fillna(0)
        
        # Calculate changes in basis points
        company_analysis['yoy_change_bps'] = (company_analysis['current_oih'] - company_analysis['yoy_oih']) * 100
        company_analysis['mom_change_bps'] = (company_analysis['current_oih'] - company_analysis['last_month_oih']) * 100
    else:
        company_analysis['yoy_change_bps'] = (company_analysis['current_oih'] - company_analysis['yoy_oih']) * 100
        company_analysis['mom_change_bps'] = 0
    
    # Get top 10 worst companies by CTC total
    worst_companies = company_analysis.nlargest(10, 'ctc_total')[['company_vendor_name', 'oih_managed_cost_current', 'unhealthy_pct_current', 'ctc_mix', 'ctc_rate', 'ctc_total', 'yoy_change_bps', 'mom_change_bps']]
    
    # Brand analysis for worst companies
    company_brands = {}
    for company in worst_companies['company_vendor_name']:
        company_brand_current = current_data[current_data['company_vendor_name'] == company].groupby('brand_name').agg({
            'oih_managed_cost': 'sum',
            'below_cost_oih_cost': 'sum'
        }).reset_index()
        
        company_brand_yoy = yoy_data[yoy_data['company_vendor_name'] == company].groupby('brand_name').agg({
            'oih_managed_cost': 'sum',
            'below_cost_oih_cost': 'sum'
        }).reset_index()
        
        # Merge current and YoY brand data
        brand_analysis = company_brand_current.merge(company_brand_yoy, on='brand_name', how='outer', suffixes=('_current', '_yoy')).fillna(0)
        
        # Calculate brand metrics
        brand_analysis['current_oih'] = (brand_analysis['below_cost_oih_cost_current'] / brand_analysis['oih_managed_cost_current'] * 100).fillna(0)
        brand_analysis['current_mix'] = (brand_analysis['oih_managed_cost_current'] / f2_total_current * 100).fillna(0)
        brand_analysis['yoy_oih'] = (brand_analysis['below_cost_oih_cost_yoy'] / brand_analysis['oih_managed_cost_yoy'] * 100).fillna(0)
        brand_analysis['yoy_mix'] = (brand_analysis['oih_managed_cost_yoy'] / f2_total_yoy * 100).fillna(0)
        
        # Brand CTC calculations
        brand_analysis['ctc_mix'] = (brand_analysis['current_mix'] - brand_analysis['yoy_mix']) * (brand_analysis['yoy_oih'] - f2_oih_yoy)
        brand_analysis['ctc_rate'] = brand_analysis['current_mix'] * (brand_analysis['current_oih'] - brand_analysis['yoy_oih'])
        brand_analysis['ctc_total'] = brand_analysis['ctc_mix'] + brand_analysis['ctc_rate']
        brand_analysis['unhealthy_pct_current'] = brand_analysis['current_oih']
        
        # Add last month data for brand MoM calculations
        if last_month_data is not None and not last_month_data.empty:
            company_brand_last_month = last_month_data[last_month_data['company_vendor_name'] == company].groupby('brand_name').agg({
                'oih_managed_cost': 'sum',
                'below_cost_oih_cost': 'sum'
            }).reset_index()
            
            company_brand_last_month['last_month_oih'] = (company_brand_last_month['below_cost_oih_cost'] / company_brand_last_month['oih_managed_cost'] * 100).fillna(0)
            
            # Merge with existing brand analysis
            brand_analysis = brand_analysis.merge(company_brand_last_month[['brand_name', 'last_month_oih']], on='brand_name', how='left').fillna(0)
            
            # Calculate brand changes in basis points
            brand_analysis['yoy_change_bps'] = (brand_analysis['current_oih'] - brand_analysis['yoy_oih']) * 100
            brand_analysis['mom_change_bps'] = (brand_analysis['current_oih'] - brand_analysis['last_month_oih']) * 100
        else:
            brand_analysis['yoy_change_bps'] = (brand_analysis['current_oih'] - brand_analysis['yoy_oih']) * 100
            brand_analysis['mom_change_bps'] = 0
        
        # Get top 5 brands by CTC total for this company
        company_brands[company] = brand_analysis.nlargest(5, 'ctc_total')[['brand_name', 'oih_managed_cost_current', 'unhealthy_pct_current', 'ctc_mix', 'ctc_rate', 'ctc_total', 'yoy_change_bps', 'mom_change_bps']]
    
    return worst_companies, company_brands

def calculate_parent_asin_analysis(current_data, yoy_data, worst_companies):
    """Calculate parent ASIN analysis for worst companies"""
    
    # Convert to float to avoid decimal issues
    current_data = current_data.copy()
    yoy_data = yoy_data.copy()
    
    current_data['oih_managed_cost'] = pd.to_numeric(current_data['oih_managed_cost'], errors='coerce').fillna(0)
    current_data['below_cost_oih_cost'] = pd.to_numeric(current_data['below_cost_oih_cost'], errors='coerce').fillna(0)
    
    yoy_data['oih_managed_cost'] = pd.to_numeric(yoy_data['oih_managed_cost'], errors='coerce').fillna(0)
    yoy_data['below_cost_oih_cost'] = pd.to_numeric(yoy_data['below_cost_oih_cost'], errors='coerce').fillna(0)
    
    # Calculate F2 totals
    f2_total_current = current_data['oih_managed_cost'].sum()
    f2_oih_current = current_data['below_cost_oih_cost'].sum() / f2_total_current * 100 if f2_total_current > 0 else 0
    
    f2_total_yoy = yoy_data['oih_managed_cost'].sum()
    f2_oih_yoy = yoy_data['below_cost_oih_cost'].sum() / f2_total_yoy * 100 if f2_total_yoy > 0 else 0
    
    # Parent ASIN analysis for worst companies
    company_parent_asins = {}
    for company in worst_companies['company_vendor_name']:
        # Create combined parent ASIN + name column
        current_data_company = current_data[current_data['company_vendor_name'] == company].copy()
        yoy_data_company = yoy_data[yoy_data['company_vendor_name'] == company].copy()
        
        current_data_company['parent_asin_display'] = current_data_company['parent_asin'].astype(str) + ' - ' + current_data_company['parent_asin_name'].astype(str)
        yoy_data_company['parent_asin_display'] = yoy_data_company['parent_asin'].astype(str) + ' - ' + yoy_data_company['parent_asin_name'].astype(str)
        
        company_pasin_current = current_data_company.groupby('parent_asin_display').agg({
            'oih_managed_cost': 'sum',
            'below_cost_oih_cost': 'sum'
        }).reset_index()
        
        company_pasin_yoy = yoy_data_company.groupby('parent_asin_display').agg({
            'oih_managed_cost': 'sum',
            'below_cost_oih_cost': 'sum'
        }).reset_index()
        
        # Merge current and YoY parent ASIN data
        pasin_analysis = company_pasin_current.merge(company_pasin_yoy, on='parent_asin_display', how='outer', suffixes=('_current', '_yoy')).fillna(0)
        
        # Calculate parent ASIN metrics
        pasin_analysis['current_oih'] = (pasin_analysis['below_cost_oih_cost_current'] / pasin_analysis['oih_managed_cost_current'] * 100).fillna(0)
        pasin_analysis['current_mix'] = (pasin_analysis['oih_managed_cost_current'] / f2_total_current * 100).fillna(0)
        pasin_analysis['yoy_oih'] = (pasin_analysis['below_cost_oih_cost_yoy'] / pasin_analysis['oih_managed_cost_yoy'] * 100).fillna(0)
        pasin_analysis['yoy_mix'] = (pasin_analysis['oih_managed_cost_yoy'] / f2_total_yoy * 100).fillna(0)
        
        # Parent ASIN CTC calculations
        pasin_analysis['ctc_mix'] = (pasin_analysis['current_mix'] - pasin_analysis['yoy_mix']) * (pasin_analysis['yoy_oih'] - f2_oih_yoy)
        pasin_analysis['ctc_rate'] = pasin_analysis['current_mix'] * (pasin_analysis['current_oih'] - pasin_analysis['yoy_oih'])
        pasin_analysis['ctc_total'] = pasin_analysis['ctc_mix'] + pasin_analysis['ctc_rate']
        pasin_analysis['unhealthy_pct_current'] = pasin_analysis['current_oih']
        
        # Get top 5 parent ASINs by CTC total for this company
        company_parent_asins[company] = pasin_analysis.nlargest(5, 'ctc_total')[['parent_asin_display', 'oih_managed_cost_current', 'unhealthy_pct_current', 'ctc_mix', 'ctc_rate', 'ctc_total']]
    
    return company_parent_asins
    company_analysis['current_pct_to_total'] = (company_analysis['oih_managed_cost'] / f2_total_current * 100).fillna(0)
    
    # YoY period calculations  
    company_analysis['yoy_oih'] = (company_analysis['yoy_below_cost_oih_cost'] / company_analysis['yoy_oih_managed_cost'] * 100).fillna(0)
    company_analysis['yoy_pct_to_total'] = (company_analysis['yoy_oih_managed_cost'] / f2_total_yoy * 100).fillna(0)
    
    # CTC formulas (converted to basis points)
    company_analysis['ctc_mix'] = (company_analysis['current_pct_to_total'] - company_analysis['yoy_pct_to_total']) * (company_analysis['yoy_oih'] - f2_oih_yoy)
    company_analysis['ctc_rate'] = (company_analysis['current_oih'] - company_analysis['yoy_oih']) * company_analysis['current_pct_to_total']
    company_analysis['ctc_total'] = company_analysis['ctc_mix'] + company_analysis['ctc_rate']
    
    # For display, use current period values
    company_analysis['unhealthy_pct_current'] = company_analysis['current_oih']
    
    # Brand analysis with proper CTC formulas
    brand_analysis = df.groupby(['brand', 'company_vendor_name']).agg({
        'oih_managed_cost': 'sum',
        'below_cost_oih_cost': 'sum',
        'yoy_oih_managed_cost': 'sum',
        'yoy_below_cost_oih_cost': 'sum'
    }).reset_index()
    
    brand_analysis = brand_analysis[
        (brand_analysis['brand'].notna()) & 
        (brand_analysis['oih_managed_cost'] > 0)
    ]
    
    # Current period calculations
    brand_analysis['current_oih'] = (brand_analysis['below_cost_oih_cost'] / brand_analysis['oih_managed_cost'] * 100).fillna(0)
    brand_analysis['current_pct_to_total'] = (brand_analysis['oih_managed_cost'] / f2_total_current * 100).fillna(0)
    
    # YoY period calculations
    brand_analysis['yoy_oih'] = (brand_analysis['yoy_below_cost_oih_cost'] / brand_analysis['yoy_oih_managed_cost'] * 100).fillna(0)
    brand_analysis['yoy_pct_to_total'] = (brand_analysis['yoy_oih_managed_cost'] / f2_total_yoy * 100).fillna(0)
    
    # CTC formulas (converted to basis points)
    brand_analysis['ctc_mix'] = (brand_analysis['current_pct_to_total'] - brand_analysis['yoy_pct_to_total']) * (brand_analysis['yoy_oih'] - f2_oih_yoy)
    brand_analysis['ctc_rate'] = (brand_analysis['current_oih'] - brand_analysis['yoy_oih']) * brand_analysis['current_pct_to_total']
    brand_analysis['ctc_total'] = brand_analysis['ctc_mix'] + brand_analysis['ctc_rate']
    
    # For display, use current period values
    brand_analysis['unhealthy_pct_current'] = brand_analysis['current_oih']
    
    worst_companies = company_analysis.nlargest(10, 'ctc_total')[['company_vendor_name', 'oih_managed_cost', 'unhealthy_pct_current', 'ctc_mix', 'ctc_rate', 'ctc_total']]
    
    # Get 3 worst brands for each of the top 10 companies
    company_brands = {}
    for company in worst_companies['company_vendor_name']:
        company_brand_data = brand_analysis[brand_analysis['company_vendor_name'] == company].nlargest(3, 'ctc_total')[['brand', 'oih_managed_cost', 'unhealthy_pct_current', 'ctc_mix', 'ctc_rate', 'ctc_total']]
        company_brands[company] = company_brand_data
    
    return worst_companies, company_brands
def generate_html_report(df, trend_data, output_path, current_start_date, week_number):
    """Generate professional HTML report from DataFrame"""
    
    # Separate data by time period
    current_week_data = df[df['time_period'] == 'Current_Week']
    prev_week_data = df[df['time_period'] == 'Previous_Week']
    last_month_week_data = df[df['time_period'] == 'Last_Month_Week']
    yoy_week_data = df[df['time_period'] == 'YoY_Week']
    
    # Calculate unhealthy percentages for each period
    current_unhealthy_pct = current_week_data['below_cost_oih_cost'].sum() / current_week_data['oih_managed_cost'].sum() * 100 if current_week_data['oih_managed_cost'].sum() > 0 else 0
    prev_week_unhealthy_pct = prev_week_data['below_cost_oih_cost'].sum() / prev_week_data['oih_managed_cost'].sum() * 100 if prev_week_data['oih_managed_cost'].sum() > 0 else 0
    yoy_unhealthy_pct = yoy_week_data['below_cost_oih_cost'].sum() / yoy_week_data['oih_managed_cost'].sum() * 100 if yoy_week_data['oih_managed_cost'].sum() > 0 else 0

    wow_change_bps = (current_unhealthy_pct - prev_week_unhealthy_pct) * 100
    yoy_change_bps = (current_unhealthy_pct - yoy_unhealthy_pct) * 100
    
    # Create 8-week trend chart
    trend_chart_b64 = create_8week_trend_chart(trend_data)
    
    # Create individual GL trend charts for appendix
    gl_trend_charts = create_gl_trend_charts(trend_data)
    
    # Create cost comparison chart
    chart_b64 = create_cost_comparison_chart(current_week_data, yoy_week_data)
    
    # Create GL analysis chart
    gl_chart_b64 = create_gl_analysis_chart(current_week_data, week_number)
    
    # Calculate CTC analysis
    worst_companies, company_brands = calculate_ctc_analysis(current_week_data, yoy_week_data, last_month_week_data)
    
    # Calculate parent ASIN analysis
    company_parent_asins = calculate_parent_asin_analysis(current_week_data, yoy_week_data, worst_companies)
    
    # Generate company bridges
    company_bridges = generate_company_bridges(current_week_data, yoy_week_data, prev_week_data, last_month_week_data, worst_companies, company_brands, company_parent_asins, week_number)
    
    # Calculate summary statistics (current week)
    total_brands = current_week_data['brand_name'].nunique()
    total_managed_cost = current_week_data['oih_managed_cost'].sum()
    total_managed_units = current_week_data['oih_managed_units'].sum()
    total_action_cost = current_week_data['oih_recommended_action_cost'].sum()
    total_action_units = current_week_data['oih_recommended_action_units'].sum()
    unhealthy_cost = current_week_data['below_cost_oih_cost'].sum()
    
    # Top categories by cost (current week)
    top_categories = current_week_data.groupby('gl_product_group')['oih_managed_cost'].sum().sort_values(ascending=False).head(10)
    top_categories = df.groupby('gl_product_group')['oih_managed_cost'].sum().sort_values(ascending=False).head(5)
    
    # Top brands by cost
    top_brands = df.groupby('brand_name')['oih_managed_cost'].sum().sort_values(ascending=False).head(10)
    
    # Exclusion analysis
    exclusion_summary = df.groupby('excluded_from_oih_action').agg({
        'oih_managed_cost': 'sum',
        'brand_name': 'nunique'
    }).reset_index()
    
    # Generate trend chart section
    trend_chart_section = ""
    if trend_chart_b64:
        trend_chart_section = f"""
        <div class="chart-container">
            <h3 style="color: #2c5aa0; margin-bottom: 15px;">8-Week Trend Comparison: Current vs YoY</h3>
            <img src="data:image/png;base64,{trend_chart_b64}" alt="8-Week Trend Chart" style="max-width: 100%; height: auto;">
        </div>"""
    
    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <title>OIH Analysis Report</title>
    <style>
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 10px; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); color: #333; zoom: 0.9; }}
        .container {{ max-width: 1400px; margin: 0 auto; background: white; padding: 20px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }}
        h1 {{ color: #2c5aa0; text-align: center; margin-bottom: 40px; padding-bottom: 20px; border-bottom: 3px solid #2c5aa0; }}
        h2 {{ color: #2c5aa0; margin-top: 30px; margin-bottom: 15px; }}
        .summary-grid {{ display: flex; justify-content: space-around; margin: 30px 0; padding: 25px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; color: white; box-shadow: 0 5px 15px rgba(0,0,0,0.2); }}
        .summary-card {{ text-align: center; padding: 15px; background: rgba(255,255,255,0.1); border-radius: 10px; backdrop-filter: blur(10px); }}
        .summary-card h3 {{ margin: 0 0 10px 0; font-size: 1.1em; opacity: 0.9; }}
        .summary-card .value {{ font-size: 2.5em; font-weight: bold; margin: 10px 0; }}
        .chart-container {{ text-align: center; margin: 30px 0; padding: 25px; background: #f8f9fa; border-radius: 10px; border-left: 5px solid #28a745; }}
        .ctc-analysis {{ background: #f0f8ff; padding: 20px; border-radius: 8px; margin: 30px 0; border-left: 5px solid #2c5aa0; }}
        .ctc-analysis h3 {{ color: #2c5aa0; margin-top: 0; font-weight: bold; font-size: 1.1em; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid #e9ecef; }}
        
        /* Tab styles */
        .tab-container {{ margin: 20px 0; }}
        .tab-buttons {{ display: flex; border-bottom: 2px solid #3498db; }}
        .tab-button {{ padding: 12px 24px; background: #ecf0f1; border: none; cursor: pointer; font-size: 16px; font-weight: 600; }}
        .tab-button.active {{ background: #3498db; color: white; }}
        .tab-content {{ display: none; }}
        .tab-content.active {{ display: block; }}
        
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background-color: #3498db; color: white; font-weight: bold; }}
        tr:nth-child(even) {{ background-color: #f2f2f2; }}
        tr:hover {{ background-color: #e8f4fd; }}
        .currency {{ text-align: right; }}
        .number {{ text-align: right; }}
        .footer {{ text-align: center; margin-top: 30px; color: #7f8c8d; font-size: 12px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>F2 OIH Analysis Report Week of {current_start_date}</h1>
        <p style="text-align: center; color: #7f8c8d;">Generated on {datetime.now().strftime('%B %d, %Y at %I:%M %p')}</p>
        
        <h2>OIH Summary</h2>
        <div class="summary-grid">
            <div class="summary-card">
                <h3>OIH Unhealthy %</h3>
                <div class="value">{current_unhealthy_pct:.2f}%</div>
            </div>
            <div class="summary-card">
                <h3>Total Inventory Cost</h3>
                <div class="value">${total_managed_cost/1000000000:.1f}B</div>
            </div>
            <div class="summary-card">
                <h3>Recommended Action Cost</h3>
                <div class="value">${total_action_cost/1000000000:.1f}B</div>
            </div>
            <div class="summary-card">
                <h3>Unhealthy Inventory Cost</h3>
                <div class="value">${unhealthy_cost/1000000:.0f}M</div>
            </div>
            <div class="summary-card" style="background: {'linear-gradient(135deg, #e74c3c 0%, #c0392b 100%)' if wow_change_bps > 0 else 'linear-gradient(135deg, #27ae60 0%, #229954 100%)'};">
                <h3>WoW Change</h3>
                <div class="value">{wow_change_bps:+.0f} bps</div>
            </div>
            <div class="summary-card" style="background: {'linear-gradient(135deg, #e74c3c 0%, #c0392b 100%)' if yoy_change_bps > 0 else 'linear-gradient(135deg, #27ae60 0%, #229954 100%)'};">
                <h3>YoY Change</h3>
                <div class="value">{yoy_change_bps:+.0f} bps</div>
            </div>
        </div>
        
        {trend_chart_section}

        <div class="chart-container">
            <img src="data:image/png;base64,{gl_chart_b64}" alt="GL Analysis Chart" style="max-width: 100%; height: auto;">
        </div>

        <div class="chart-container">
            <h2 style="
                background: linear-gradient(45deg, #2c3e50, #34495e, #1a252f, #2c3e50);
                background-size: 400% 400%;
                animation: rainbow 4s ease infinite;
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
                font-size: 42px;
                font-weight: 900;
                text-align: center;
                margin: 30px 0;
                text-transform: uppercase;
                letter-spacing: 3px;
                filter: drop-shadow(0 0 10px rgba(44, 62, 80, 0.5));
            ">F2 YoY OIH Analysis</h2>
            <style>
                @keyframes rainbow {{
                    0% {{ background-position: 0% 50%; }}
                    50% {{ background-position: 100% 50%; }}
                    100% {{ background-position: 0% 50%; }}
                }}
            </style>
        </div>

        <div class="tab-container">
            <div class="tab-buttons">
                <button class="tab-button active" onclick="showTab('company')">Company View</button>
                <button class="tab-button" onclick="showTab('brand')">Brand View</button>
                <button class="tab-button" onclick="showTab('parent_asin')">Parent ASIN View</button>
            </div>
            
            <div id="company" class="tab-content active">
                <div class="ctc-analysis">
                    <h3>CTC Analysis - Top 10 Worst Performing Companies</h3>
                    <table>
                        <tr>
                            <th style="text-align: left;">Company</th>
                            <th style="text-align: right;">Inventory Cost</th>
                            <th style="text-align: right;">Unhealthy Inventory Cost</th>
                            <th style="text-align: right;">Unhealthy %</th>
                            <th style="text-align: right;">CTC Mix</th>
                            <th style="text-align: right;">CTC Rate</th>
                            <th style="text-align: right;">CTC Total</th>
                            <th style="text-align: right;">YoY Change (bps)</th>
                            <th style="text-align: right;">MoM Change (bps)</th>
                        </tr>"""
    
    for _, row in worst_companies.iterrows():
        html_content += f"""
                        <tr>
                            <td>{row['company_vendor_name']}</td>
                            <td class='currency'>${row['oih_managed_cost_current']:,.0f}</td>
                            <td class='currency'>${row['oih_managed_cost_current'] * row['unhealthy_pct_current'] / 100:,.0f}</td>
                            <td class='number'>{row['unhealthy_pct_current']:.2f}%</td>
                            <td class='number'>{row['ctc_mix']:.0f}</td>
                            <td class='number'>{row['ctc_rate']:.0f}</td>
                            <td class='number'>{row['ctc_total']:.0f}</td>
                            <td class='number' style='color: {"red" if row["yoy_change_bps"] > 0 else "green"}'>{row['yoy_change_bps']:+.0f}</td>
                            <td class='number' style='color: {"red" if row["mom_change_bps"] > 0 else "green"}'>{row['mom_change_bps']:+.0f}</td>
                        </tr>"""
    
    html_content += """
                    </table>
                </div>
            </div>
            
            <div id="brand" class="tab-content">"""
    
    # Generate brand tables for worst companies
    for company, brands_df in company_brands.items():
        html_content += f"""
                <div class="ctc-analysis">
                    <h3>{company} - YoY 5 Worst Brands</h3>
                    <table>
                        <tr>
                            <th style="text-align: left;">Brand</th>
                            <th style="text-align: right;">Inventory Cost</th>
                            <th style="text-align: right;">Unhealthy Inventory Cost</th>
                            <th style="text-align: right;">Unhealthy %</th>
                            <th style="text-align: right;">CTC Mix</th>
                            <th style="text-align: right;">CTC Rate</th>
                            <th style="text-align: right;">CTC Total</th>
                            <th style="text-align: right;">YoY Change (bps)</th>
                            <th style="text-align: right;">MoM Change (bps)</th>
                        </tr>"""
        
        for _, row in brands_df.iterrows():
            html_content += f"""
                        <tr>
                            <td>{row['brand_name']}</td>
                            <td class='currency'>${row['oih_managed_cost_current']:,.0f}</td>
                            <td class='currency'>${row['oih_managed_cost_current'] * row['unhealthy_pct_current'] / 100:,.0f}</td>
                            <td class='number'>{row['unhealthy_pct_current']:.2f}%</td>
                            <td class='number'>{row['ctc_mix']:.0f}</td>
                            <td class='number'>{row['ctc_rate']:.0f}</td>
                            <td class='number'>{row['ctc_total']:.0f}</td>
                            <td class='number' style='color: {"red" if row["yoy_change_bps"] > 0 else "green"}'>{row['yoy_change_bps']:+.0f}</td>
                            <td class='number' style='color: {"red" if row["mom_change_bps"] > 0 else "green"}'>{row['mom_change_bps']:+.0f}</td>
                        </tr>"""
        
        html_content += """
                    </table>
                </div>"""
    
    html_content += """
            </div>
            
            <div id="parent_asin" class="tab-content">"""
    
    # Generate parent ASIN tables for worst companies
    for company, parent_asins_df in company_parent_asins.items():
        html_content += f"""
                <div class="ctc-analysis">
                    <h3>{company} - YoY 5 Worst Parent ASINs</h3>
                    <table>
                        <tr>
                            <th style="text-align: left;">Parent ASIN</th>
                            <th style="text-align: right;">Inventory Cost</th>
                            <th style="text-align: right;">Unhealthy Inventory Cost</th>
                            <th style="text-align: right;">Unhealthy %</th>
                            <th style="text-align: right;">CTC Mix</th>
                            <th style="text-align: right;">CTC Rate</th>
                            <th style="text-align: right;">CTC Total</th>
                        </tr>"""
        
        for _, row in parent_asins_df.iterrows():
            # Extract ASIN from parent_asin_display (format: "ASIN - Name")
            asin = row['parent_asin_display'].split(' - ')[0]
            asin_link = f'<a href="https://amazon.com/dp/{asin}" target="_blank">{row["parent_asin_display"]}</a>'
            
            html_content += f"""
                        <tr>
                            <td>{asin_link}</td>
                            <td class='currency'>${row['oih_managed_cost_current']:,.0f}</td>
                            <td class='currency'>${row['oih_managed_cost_current'] * row['unhealthy_pct_current'] / 100:,.0f}</td>
                            <td class='number'>{row['unhealthy_pct_current']:.2f}%</td>
                            <td class='number'>{row['ctc_mix']:.0f}</td>
                            <td class='number'>{row['ctc_rate']:.0f}</td>
                            <td class='number'>{row['ctc_total']:.0f}</td>
                        </tr>"""
        
        html_content += """
                    </table>
                </div>"""

    html_content += """
            </div>
        </div>

        <script>
        function showTab(tabName) {
            // Hide all tab contents
            var contents = document.getElementsByClassName('tab-content');
            for (var i = 0; i < contents.length; i++) {
                contents[i].classList.remove('active');
            }
            
            // Remove active class from all buttons
            var buttons = document.getElementsByClassName('tab-button');
            for (var i = 0; i < buttons.length; i++) {
                buttons[i].classList.remove('active');
            }
            
            // Show selected tab and activate button
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');
        }
        </script>

        <h2>Company Performance Bridges</h2>
        <div style="background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 20px; margin: 20px 0;">"""
    
    for i, bridge in enumerate(company_bridges, 1):
        html_content += f"""
            <p><strong>{i}.</strong> {bridge}</p>"""
    
    html_content += """
        </div>

        <div class="footer">
            <p>This report contains OIH data for GL Product Groups: 200 (Sports), 468 (Outdoors), 198 (Luggage), 193 (Apparel), 197 (Jewelry), 241 (Watches), and 309 (Shoes)</p>
            <p>Data source: Andes OIH_DDL.OIH_RECOMMEND_DETAIL</p>
        </div>
        
        {gl_appendix_section}
    </div>
</body>
</html>"""
    
    # Generate GL appendix section
    gl_appendix_section = ""
    if gl_trend_charts:
        gl_charts_html = ""
        for gl_name, chart_b64 in gl_trend_charts.items():
            gl_charts_html += f"""
            <div class="chart-container" style="margin-bottom: 40px;">
                <img src="data:image/png;base64,{chart_b64}" alt="{gl_name} Trend Chart" style="max-width: 100%; height: auto;">
            </div>"""
        
        gl_appendix_section = f"""
        <div style="page-break-before: always; margin-top: 50px;">
            <h2 style="color: #2c5aa0; border-bottom: 3px solid #2c5aa0; padding-bottom: 10px;">Appendix: Individual GL 8-Week Trends</h2>
            {gl_charts_html}
        </div>"""
    
    # Replace the appendix placeholder with actual content
    html_content = html_content.replace('{gl_appendix_section}', gl_appendix_section)
    
    with open(output_path, 'w') as f:
        f.write(html_content)
    
    return output_path

def run_8week_trend_query(current_date, yoy_date, week_number):
    """Execute 8-week trend query for GL analysis - current vs YoY"""
    
    # Create filename for 8-week trend data
    start_date_str = current_date.replace('-', '')
    csv_filename = f"OIH_Week{week_number}_F2_GLs_{start_date_str}_8WeekTrend.csv"
    csv_file = f'/home/mishrva/Downloads/OIH/{csv_filename}'
    
    # Check if CSV already exists
    if os.path.exists(csv_file):
        print(f"📁 8-week trend CSV already exists: {csv_filename}")
        return pd.read_csv(csv_file)
    
    print(f"🔍 Running 8-week trend query for GL analysis (Current vs YoY)...")
    
    # Calculate date ranges for current and YoY 8 weeks using PCSICFTI logic
    current_dt = datetime.strptime(current_date, '%Y-%m-%d')
    yoy_dt = datetime.strptime(yoy_date, '%Y-%m-%d')
    
    # Get Sunday week boundaries (like PCSICFTI script)
    def get_sunday_week_start(date):
        days_since_sunday = (date.weekday() + 1) % 7
        sunday = date - timedelta(days=days_since_sunday)
        return sunday
    
    current_sunday = get_sunday_week_start(current_dt)
    yoy_sunday = get_sunday_week_start(yoy_dt)
    
    # 8 weeks back from Sunday start dates (7 weeks back + current = 8 total)
    current_start_8weeks = current_sunday - timedelta(weeks=7)
    current_end = current_sunday + timedelta(days=6)  # End of current week (Saturday)
    
    yoy_start_8weeks = yoy_sunday - timedelta(weeks=7)  
    yoy_end = yoy_sunday + timedelta(days=6)  # End of YoY week (Saturday)
    
    current_start_str = current_start_8weeks.strftime('%Y-%m-%d')
    current_end_str = current_end.strftime('%Y-%m-%d')
    yoy_start_str = yoy_start_8weeks.strftime('%Y-%m-%d')
    yoy_end_str = yoy_end.strftime('%Y-%m-%d')
    
    query = f"""
        SELECT 
            z.gl_product_group,
            OIH.RUNDATE,
            SUM((oih.oih_action_quantity+oih.un_action_quantity)*oih.cost) AS OIH_MANAGED_COST,
            SUM((oih.oih_action_quantity - oih.cp_positive_qty)*oih.cost) AS BELOW_COST_OIH_COST,
            CASE 
                WHEN OIH.RUNDATE BETWEEN '{current_start_str}' AND '{current_end_str}' THEN 
                    CASE 
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}' AND '{current_start_str}'::date + interval '6 days' THEN 'Current Week -7'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '7 days' AND '{current_start_str}'::date + interval '13 days' THEN 'Current Week -6'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '14 days' AND '{current_start_str}'::date + interval '20 days' THEN 'Current Week -5'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '21 days' AND '{current_start_str}'::date + interval '27 days' THEN 'Current Week -4'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '28 days' AND '{current_start_str}'::date + interval '34 days' THEN 'Current Week -3'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '35 days' AND '{current_start_str}'::date + interval '41 days' THEN 'Current Week -2'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '42 days' AND '{current_start_str}'::date + interval '48 days' THEN 'Current Week -1'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '49 days' AND '{current_end_str}' THEN 'Current Week'
                        ELSE 'Current_8Weeks'
                    END
                WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}' AND '{yoy_end_str}' THEN 
                    CASE 
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}' AND '{yoy_start_str}'::date + interval '6 days' THEN 'YoY Week -7'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '7 days' AND '{yoy_start_str}'::date + interval '13 days' THEN 'YoY Week -6'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '14 days' AND '{yoy_start_str}'::date + interval '20 days' THEN 'YoY Week -5'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '21 days' AND '{yoy_start_str}'::date + interval '27 days' THEN 'YoY Week -4'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '28 days' AND '{yoy_start_str}'::date + interval '34 days' THEN 'YoY Week -3'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '35 days' AND '{yoy_start_str}'::date + interval '41 days' THEN 'YoY Week -2'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '42 days' AND '{yoy_start_str}'::date + interval '48 days' THEN 'YoY Week -1'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '49 days' AND '{yoy_end_str}' THEN 'YoY Week'
                        ELSE 'YoY_8Weeks'
                    END
                ELSE 'Other'
            END AS time_period
        FROM andes.OIH_DDL.OIH_RECOMMEND_DETAIL OIH
        LEFT JOIN andes.z_tools_analytics.z_weekly_universal_asin_attributes z
            ON z.asin = OIH.asin
        WHERE OIH.region_id = 1
          AND OIH.realm = 'USAmazon'
          AND z.gl_product_group IN (200, 468, 198, 193, 197, 241, 309)
          AND (
              (OIH.RUNDATE BETWEEN '{current_start_str}' AND '{current_end_str}')
              OR (OIH.RUNDATE BETWEEN '{yoy_start_str}' AND '{yoy_end_str}')
          )
        GROUP BY
            z.gl_product_group,
            OIH.RUNDATE,
            CASE 
                WHEN OIH.RUNDATE BETWEEN '{current_start_str}' AND '{current_end_str}' THEN 
                    CASE 
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}' AND '{current_start_str}'::date + interval '6 days' THEN 'Current Week -7'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '7 days' AND '{current_start_str}'::date + interval '13 days' THEN 'Current Week -6'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '14 days' AND '{current_start_str}'::date + interval '20 days' THEN 'Current Week -5'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '21 days' AND '{current_start_str}'::date + interval '27 days' THEN 'Current Week -4'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '28 days' AND '{current_start_str}'::date + interval '34 days' THEN 'Current Week -3'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '35 days' AND '{current_start_str}'::date + interval '41 days' THEN 'Current Week -2'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '42 days' AND '{current_start_str}'::date + interval '48 days' THEN 'Current Week -1'
                        WHEN OIH.RUNDATE BETWEEN '{current_start_str}'::date + interval '49 days' AND '{current_end_str}' THEN 'Current Week'
                        ELSE 'Current_8Weeks'
                    END
                WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}' AND '{yoy_end_str}' THEN 
                    CASE 
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}' AND '{yoy_start_str}'::date + interval '6 days' THEN 'YoY Week -7'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '7 days' AND '{yoy_start_str}'::date + interval '13 days' THEN 'YoY Week -6'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '14 days' AND '{yoy_start_str}'::date + interval '20 days' THEN 'YoY Week -5'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '21 days' AND '{yoy_start_str}'::date + interval '27 days' THEN 'YoY Week -4'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '28 days' AND '{yoy_start_str}'::date + interval '34 days' THEN 'YoY Week -3'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '35 days' AND '{yoy_start_str}'::date + interval '41 days' THEN 'YoY Week -2'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '42 days' AND '{yoy_start_str}'::date + interval '48 days' THEN 'YoY Week -1'
                        WHEN OIH.RUNDATE BETWEEN '{yoy_start_str}'::date + interval '49 days' AND '{yoy_end_str}' THEN 'YoY Week'
                        ELSE 'YoY_8Weeks'
                    END
                ELSE 'Other'
            END
        ORDER BY time_period, OIH.RUNDATE DESC, z.gl_product_group
    """
    
    try:
        conn = get_connection()
        print(f"📊 Executing 8-week trend query...")
        df = pd.read_sql(query, conn)
        conn.close()
        
        if df.empty:
            print("⚠️  No data returned from 8-week trend query")
            return None
        
        # Save to CSV
        df.to_csv(csv_file, index=False)
        print(f"✅ 8-week trend data saved: {csv_filename}")
        
        current_weeks = df[df['time_period'] == 'Current_8Weeks']['rundate'].nunique()
        yoy_weeks = df[df['time_period'] == 'YoY_8Weeks']['rundate'].nunique()
        print(f"📈 Retrieved Current: {current_weeks} weeks, YoY: {yoy_weeks} weeks")
        
        return df
        
    except Exception as e:
        print(f"❌ Error executing 8-week trend query: {str(e)}")
        return None

def run_oih_query(current_date, last_month_date, yoy_date, week_number):
    """Execute OIH query and return results"""
    
    # Create filename with week number, GL info, and start date
    start_date_str = current_date.replace('-', '')
    csv_filename = f"OIH_Week{week_number}_F2_GLs_{start_date_str}.csv"
    csv_file = f'/home/mishrva/Downloads/OIH/{csv_filename}'
    html_filename = f"OIH_Week{week_number}_F2_GLs_{start_date_str}.html"
    html_file = f'/home/mishrva/Downloads/OIH/{html_filename}'
    
    # Check if CSV already exists
    if os.path.exists(csv_file):
        print(f"✓ Loading existing data from {csv_filename}")
        df = pd.read_csv(csv_file, low_memory=False)
        print(f"✓ Data loaded, HTML report will be regenerated with trend data...")
        return df
    else:
        print(f"\n📝 Creating new analysis: {csv_filename}", flush=True)
    
    print(f"\n🔗 Connecting to Redshift database...", flush=True)
    try:
        conn = get_connection()
        cursor = conn.cursor()

        print("✓ Connected to Redshift successfully", flush=True)
        
    
        
        # Execute main OIH query with both current and YoY data
        print("🔍 Executing main OIH query (this may take a few minutes)...", flush=True)
        print("   📊 Fetching current period data...", flush=True)
        print("   📈 Fetching multi-period data (Current, Previous Week, YoY)...", flush=True)
        cursor.execute(f"""
        SELECT
            z.gl_product_group,
          
          z.brand_name,
            z.company_vendor_name,
            z.parent_asin,
            z.parent_asin_name,
            SUM((oih.oih_action_quantity+oih.un_action_quantity)*oih.COST) AS OIH_MANAGED_COST,
            SUM(oih.oih_action_quantity+oih.un_action_quantity) AS OIH_MANAGED_UNITS,
            SUM(oih.oih_action_quantity*oih.COST) AS OIH_RECOMMENDED_ACTION_COST,
            SUM(oih.oih_action_quantity) AS OIH_RECOMMENDED_ACTION_UNITS,
            SUM(oih.cost*(oih.oih_action_quantity - oih.cp_positive_qty)) as BELOW_COST_OIH_COST,
            SUM(oih.oih_action_quantity - oih.cp_positive_qty) as BELOW_COST_OIH_UNITS,
            SUM(oih.cp_positive_qty*oih.cost) AS ABOVE_COST_OIH_COST,
            SUM(oih.cp_positive_qty) AS ABOVE_COST_OIH_UNITS,
            CASE
                WHEN oih.exclusion_reason_code IS NULL then 'N'
                ELSE 'Y'
            END as Excluded_from_OIH_Action,
            CASE 
                WHEN OIH.RUNDATE >= '{current_date}' AND OIH.RUNDATE < '{current_date}'::date + interval '7 days' THEN 'Current_Week'
                WHEN OIH.RUNDATE >= '{current_date}'::date - interval '7 days' AND OIH.RUNDATE < '{current_date}' THEN 'Previous_Week'
                WHEN OIH.RUNDATE >= '{last_month_date}' AND OIH.RUNDATE < '{last_month_date}'::date + interval '7 days' THEN 'Last_Month_Week'
                WHEN OIH.RUNDATE >= '{yoy_date}' AND OIH.RUNDATE < '{yoy_date}'::date + interval '7 days' THEN 'YoY_Week'
                ELSE 'Other'
            END AS time_period
        FROM andes.OIH_DDL.OIH_RECOMMEND_DETAIL OIH
       
        LEFT JOIN andes.z_tools_analytics.z_weekly_universal_asin_attributes z
            ON z.asin = OIH.asin
        WHERE OIH.region_id = 1
          AND OIH.realm = 'USAmazon'
AND z.gl_product_group in ('200','468','198','193','197','241','309')
          AND (
              (OIH.RUNDATE >= '{current_date}' AND OIH.RUNDATE < '{current_date}'::date + interval '7 days')
              OR (OIH.RUNDATE >= '{current_date}'::date - interval '7 days' AND OIH.RUNDATE < '{current_date}')
              OR (OIH.RUNDATE >= '{last_month_date}' AND OIH.RUNDATE < '{last_month_date}'::date + interval '7 days')
              OR (OIH.RUNDATE >= '{yoy_date}' AND OIH.RUNDATE < '{yoy_date}'::date + interval '7 days')
          )
        GROUP BY
             z.gl_product_group,
          
          z.brand_name,
            z.company_vendor_name,
            
            z.parent_asin,
            z.parent_asin_name,
            CASE
                WHEN oih.exclusion_reason_code IS NULL then 'N'
                ELSE 'Y'
            END,
            time_period
        """)
        
        # Fetch results in chunks to avoid memory overload
        chunk_size = CHUNK_SIZE
        chunk_num = 1
        chunk_files = []
        columns = [desc[0] for desc in cursor.description]
        
        # Clean up old chunk files first
        cleanup_old_chunks(csv_file)
        
        print(f"📦 Processing data in chunks of {chunk_size:,} rows...")
        
        while True:
            chunk_results = cursor.fetchmany(chunk_size)
            if not chunk_results:
                break
                
            # Create DataFrame for this chunk
            chunk_df = pd.DataFrame(chunk_results, columns=columns)
            
            # Save chunk to separate CSV
            chunk_csv = csv_file.replace('.csv', f'_chunk{chunk_num}.csv')
            chunk_df.to_csv(chunk_csv, index=False)
            chunk_files.append(chunk_csv)
            print(f"✅ Chunk {chunk_num} saved: {len(chunk_df):,} rows -> {os.path.basename(chunk_csv)}")
            
            # Clear memory immediately
            del chunk_df, chunk_results
            chunk_num += 1
        
        conn.close()
        
        # Now combine chunks without loading all into memory at once
        if chunk_files:
            print(f"🔄 Combining {len(chunk_files)} chunks into final dataset...")
            
            # Read and combine chunks one by one
            combined_chunks = []
            for i, chunk_file in enumerate(chunk_files, 1):
                chunk_df = pd.read_csv(chunk_file, low_memory=False)
                combined_chunks.append(chunk_df)
                print(f"📖 Loaded chunk {i}/{len(chunk_files)} for combining...")
            
            df = pd.concat(combined_chunks, ignore_index=True)
            del combined_chunks  # Clear memory
            
            print(f"✅ Query completed! Retrieved {len(df):,} total rows in {len(chunk_files)} chunks")
            
            # Save combined CSV and generate report
            df.to_csv(csv_file, index=False)
            # Note: trend_data not available in this context, will be None
            generate_html_report(df, None, html_file, current_date, week_number)
            print(f"✅ Combined results saved: {csv_filename}")
            print(f"✅ HTML report generated: {html_filename}")
            
            # Optionally clean up chunk files
            if not KEEP_CHUNK_FILES:
                cleanup_old_chunks(csv_file)
                print("🗑️  Chunk files cleaned up")
        else:
            print("⚠️ No data retrieved from query")
            df = pd.DataFrame()
        
        return df
        
    except Exception as e:
        print(f"Error executing OIH query: {e}")
        return None

def read_andes_guide():
    """Read and display the Andes Redshift Query Guide"""
    pass  # Removed verbose guide output

if __name__ == "__main__":
    print("Starting OIH Query Execution...")
    
    # Get user inputs for week and dates
    week_number, current_start_date, last_month_start_date, yoy_start_date = get_user_inputs()
    
    # Run 8-week trend analysis FIRST (faster, GL-level only)
    print(f"\n🚀 Step 1: Running 8-week trend analysis...")
    trend_results = run_8week_trend_query(current_start_date, yoy_start_date, week_number)
    
    # Run main OIH query (slower, ASIN-level)
    print(f"\n🚀 Step 2: Running main OIH analysis...")
    results = run_oih_query(current_start_date, last_month_start_date, yoy_start_date, week_number)
    
    if results is not None:
        # Pivot data by time_period for calculations
        current_week_data = results[results['time_period'] == 'Current_Week']
        prev_week_data = results[results['time_period'] == 'Previous_Week']
        yoy_week_data = results[results['time_period'] == 'YoY_Week']
        
        # Calculate unhealthy percentages for each period
        current_unhealthy_pct = current_week_data['below_cost_oih_cost'].sum() / current_week_data['oih_managed_cost'].sum() * 100 if current_week_data['oih_managed_cost'].sum() > 0 else 0
        prev_week_unhealthy_pct = prev_week_data['below_cost_oih_cost'].sum() / prev_week_data['oih_managed_cost'].sum() * 100 if prev_week_data['oih_managed_cost'].sum() > 0 else 0
        yoy_unhealthy_pct = yoy_week_data['below_cost_oih_cost'].sum() / yoy_week_data['oih_managed_cost'].sum() * 100 if yoy_week_data['oih_managed_cost'].sum() > 0 else 0

        wow_change_bps = (current_unhealthy_pct - prev_week_unhealthy_pct) * 100
        yoy_change_bps = (current_unhealthy_pct - yoy_unhealthy_pct) * 100

        print(f"✅ Analysis complete!")
        print(f"Current Week Unhealthy %: {current_unhealthy_pct:.2f}%")
        print(f"WoW Change: {wow_change_bps:+.0f} bps | YoY Change: {yoy_change_bps:+.0f} bps")
        
        # Regenerate HTML report with trend data if available
        if trend_results is not None:
            start_date_str = current_start_date.replace('-', '')
            html_filename = f"OIH_Week{week_number}_F2_GLs_{start_date_str}.html"
            html_file = f'/home/mishrva/Downloads/OIH/{html_filename}'
            print(f"🔄 Regenerating HTML report with 8-week trend chart...")
            generate_html_report(results, trend_results, html_file, current_start_date, week_number)
            print(f"✅ Enhanced HTML report with trend chart: {html_filename}")
        
        # Automatically read and display Andes guide
        read_andes_guide()

def main():
    """Main entry point for the oih-query command"""
    # Get user inputs
    week_number, current_start_date, last_month_start_date, yoy_start_date = get_user_inputs()
    
    # Run the OIH query
    results = run_oih_query(current_start_date, last_month_start_date, yoy_start_date, week_number)
    
    if results is not None:
        print("✅ OIH Query completed successfully!")
    else:
        print("❌ OIH Query failed!")

if __name__ == "__main__":
    main()
