"""sageLLM Backend Provider 抽象。

本包提供硬件后端抽象层：
- BackendProvider 接口定义
- 能力描述符（dtype/kernel/collective）
- Mock Backend 实现
- Stream/Event/KVBlock 抽象
- BaseEngine 推理引擎接口
- MockEngine 无 GPU 依赖的测试引擎
- EngineFactory 引擎工厂
"""

from __future__ import annotations

from sagellm_backend.base import BackendProvider, Event, KVBlock, Stream
from sagellm_backend.capability import CapabilityDescriptor, DType, KernelKind
from sagellm_backend.engine import BaseEngine, EngineFactory, MockEngine
from sagellm_backend.engine.base import EngineConfig
from sagellm_backend.engine.mock import MockEngineConfig, create_mock_engine
from sagellm_backend.providers.mock import MockBackendProvider, create_mock_backend
from sagellm_backend.providers.cpu import CPUBackendProvider, create_cpu_backend

__version__ = "0.1.1.1"

# Lazy imports for optional engines
def __getattr__(name: str):
    if name == "EmbeddingEngine":
        from sagellm_backend.engine.embedding import EmbeddingEngine
        return EmbeddingEngine
    if name == "EmbeddingEngineConfig":
        from sagellm_backend.engine.embedding import EmbeddingEngineConfig
        return EmbeddingEngineConfig
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    # Version
    "__version__",
    # Provider interface
    "BackendProvider",
    "Stream",
    "Event",
    "KVBlock",
    # Capability
    "CapabilityDescriptor",
    "DType",
    "KernelKind",
    # Mock backend implementation
    "MockBackendProvider",
    "create_mock_backend",
    # CPU backend implementation
    "CPUBackendProvider",
    "create_cpu_backend",
    # Engine interface
    "BaseEngine",
    "EngineConfig",
    "EngineFactory",
    # Mock engine
    "MockEngine",
    "MockEngineConfig",
    "create_mock_engine",
    # Embedding engine (lazy-loaded)
    "EmbeddingEngine",
    "EmbeddingEngineConfig",
]
