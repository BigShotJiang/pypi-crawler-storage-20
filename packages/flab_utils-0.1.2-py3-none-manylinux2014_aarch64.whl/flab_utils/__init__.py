def main() -> None:
    print("Hello from flab-utils!")
