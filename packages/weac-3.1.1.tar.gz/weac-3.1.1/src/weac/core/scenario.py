"""
This module defines the Scenario class, which encapsulates the physical setup of the model.
"""

import logging
from collections.abc import Sequence

import numpy as np

from weac.components import ScenarioConfig, Segment, SystemType, WeakLayer
from weac.core.slab import Slab
from weac.utils.misc import decompose_to_normal_tangential

logger = logging.getLogger(__name__)


class Scenario:
    """
    Sets up the scenario on which the eigensystem is solved.

    Parameters
    ---------
    scenario_config: ScenarioConfig
    segments: List[Segment]
    weak_layer: WeakLayer
    slab: Slab

    Attributes
    ----------
    li : List[float]
        length of segment i [mm]
    ki : List[bool]
        booleans indicating foundation support for segment i
    mi : List[float]
        skier masses (kg) on boundary of segment i and i+1 [kg]

    system_type : SystemType
    phi : float
        Angle of slab in positive in counter-clockwise direction [deg]
    L : float
        Length of the model [mm]
    crack_h: float
        Height of the crack [mm]
    """

    # Inputs
    scenario_config: ScenarioConfig
    segments: list[Segment]
    weak_layer: WeakLayer
    slab: Slab

    # Attributes
    li: np.ndarray  # length of segment i [mm]
    ki: np.ndarray  # booleans indicating foundation support for segment i
    mi: np.ndarray  # skier masses (kg) on boundary of segment i and i+1 [kg]

    cum_sum_li: np.ndarray  # cumulative sum of segment lengths [mm]

    system_type: SystemType
    phi: float  # Angle in [deg]
    surface_load: float  # Surface Line-Load [N/mm]
    qw: float  # Weight Line-Load [N/mm]
    qn: float  # Total Normal Line-Load [N/mm]
    qt: float  # Total Tangential Line-Load [N/mm]
    L: float  # Length of the model [mm]
    crack_h: float  # Height of the crack [mm]
    cut_length: float  # Length of the cut [mm]

    def __init__(
        self,
        scenario_config: ScenarioConfig,
        segments: list[Segment],
        weak_layer: WeakLayer,
        slab: Slab,
    ):
        self.scenario_config = scenario_config
        self.segments = segments
        self.weak_layer = weak_layer
        self.slab = slab

        self.system_type = scenario_config.system_type
        self.phi = scenario_config.phi
        self.surface_load = scenario_config.surface_load
        self.cut_length = scenario_config.cut_length

        self._setup_scenario()
        self._calc_normal_load()
        self._calc_tangential_load()
        self._calc_crack_height()

    def refresh_from_config(self):
        """Pull changed values out of scenario_config
        and recompute derived attributes."""
        self.system_type = self.scenario_config.system_type
        self.phi = self.scenario_config.phi
        self.surface_load = self.scenario_config.surface_load
        self.cut_length = self.scenario_config.cut_length

        self._setup_scenario()
        self._calc_normal_load()
        self._calc_tangential_load()
        self._calc_crack_height()

    def get_segment_idx(
        self, x: float | Sequence[float] | np.ndarray
    ) -> int | np.ndarray:
        """
        Get the segment index for a given x-coordinate or coordinates.

        Parameters
        ----------
        x: float | Sequence[float] | np.ndarray
            A single x-coordinate or a sequence of x-coordinates.

        Returns
        -------
        int | np.ndarray
            The segment index or an array of indices.
        """
        x_arr = np.asarray(x)
        indices = np.digitize(x_arr, self.cum_sum_li)

        if np.any(x_arr > self.L):
            raise ValueError(f"Coordinate {x_arr} exceeds the slab length.")

        if x_arr.ndim == 0:
            return int(indices)

        return indices

    def _setup_scenario(self):
        self.li = np.array([seg.length for seg in self.segments])
        self.ki = np.array([seg.has_foundation for seg in self.segments])
        # masses that act *between* segments: take all but the last one
        self.mi = np.array([seg.m for seg in self.segments[:-1]])
        self.cum_sum_li = np.cumsum(self.li)

        # Add dummy segment if only one segment provided
        if len(self.li) == 1:
            self.li = np.append(self.li, 0)
            self.ki = np.append(self.ki, True)
            self.mi = np.append(self.mi, 0)

        # Calculate the total slab length
        self.L = np.sum(self.li)

    def _calc_tangential_load(self):
        """
        Total Tangential Load (Surface Load + Weight Load)

        Returns:
        --------
        qt : float
            Tangential Component of Load [N/mm]
        """
        # Surface Load & Weight Load
        qw = self.slab.qw
        qs = self.surface_load

        # Normal components of forces
        phi = self.phi
        _, qwt = decompose_to_normal_tangential(qw, phi)
        _, qst = decompose_to_normal_tangential(qs, phi)
        qt = qwt + qst
        self.qt = qt

    def _calc_normal_load(self):
        """
        Total Normal Load (Surface Load + Weight Load)

        Returns:
        --------
        qn : float
            Normal Component of Load [N/mm]
        """
        # Surface Load & Weight Load
        qw = self.slab.qw
        qs = self.surface_load

        # Normal components of forces
        phi = self.phi
        qwn, _ = decompose_to_normal_tangential(qw, phi)
        qsn, _ = decompose_to_normal_tangential(qs, phi)
        qn = qwn + qsn
        self.qn = qn

    def _calc_crack_height(self):
        """
        Crack Height: Difference between collapsed weak layer and
            Weak Layer (Winkler type) under slab load

        Example:
        if the collapse layer has a height of 5 and the non-collapsed layer
        has a height of 15 the collapse height is 10
        """
        self.crack_h = self.weak_layer.collapse_height - self.qn / self.weak_layer.kn
        if self.crack_h < 0:
            raise ValueError(
                f"Crack height is negative: {self.crack_h} decrease the surface load"
            )
