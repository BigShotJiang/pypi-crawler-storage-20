import os
import time

import io
import zipfile
import threading
import requests
from typing import Optional, Callable

from .version import __version__
from .errors import AuthError, ServerError, NetworkError
from .logger import create_logger

DEFAULT_SERVER_URL = "https://deploykit.onrender.com"
LOCK_FILE = ".deploykit.lock"


class DeployKit:
    def __init__(
        self,
        api_key: str,
        project_name: str,
        *,
        server_url: str = DEFAULT_SERVER_URL,
        interval: int = 10,
        enable_logging: bool = True,
        dry_run: bool = False,
        on_start: Optional[Callable] = None,
        on_stop: Optional[Callable] = None,
        on_update: Optional[Callable] = None,
        on_error: Optional[Callable[[Exception], None]] = None,
        on_secrets_update: Optional[Callable] = None,
    ):
        self.api_key = api_key
        self.project_name = project_name
        self.server_url = server_url.rstrip("/")
        self.interval = interval
        self.dry_run = dry_run

        self.on_start = on_start
        self.on_stop = on_stop
        self.on_update = on_update
        self.on_error = on_error
        self.on_secrets_update = on_secrets_update

        self.headers = {"X-API-Key": api_key}
        self.current_version_id = None
        self.secrets_hash = None

        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._last_ping = None

        self.logger = create_logger() if enable_logging else None

        self.session = self._create_session()

    # =============================
    # PUBLIC API
    # =============================

    def listen(self):
        if self._is_locked():
            raise RuntimeError("DeployKit already running")

        self._create_lock()

        if self.logger:
            self.logger.info(
                f"DeployKit v{__version__} started for {self.project_name}"
            )

        if self.on_start:
            self.on_start()

        self._thread = threading.Thread(
            target=self._run_loop,
            daemon=True
        )
        self._thread.start()

        try:
            while not self._stop_event.is_set():
                time.sleep(1)
        finally:
            self.stop()

    def stop(self):
        self._stop_event.set()

        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5)

        self._remove_lock()

        if self.logger:
            self.logger.info("DeployKit stopped")

        if self.on_stop:
            self.on_stop()

    def status(self):
        return {
            "project": self.project_name,
            "server": self.server_url,
            "version": __version__,
            "running": not self._stop_event.is_set(),
            "last_ping": self._last_ping,
        }

    # =============================
    # INTERNAL
    # =============================

    def _run_loop(self):
        while not self._stop_event.is_set():
            try:
                self._check_update()
                self._ping()
            except Exception as e:
                if self.logger:
                    self.logger.error(str(e))
                if self.on_error:
                    self.on_error(e)
            time.sleep(self.interval)

    def _check_update(self):
        r = self._get(f"/api/check/{self.project_name}")
        data = r.json()

        if data.get("status") != "ok":
            return

        version_id = data["version_id"]

        if self.current_version_id is None:
            self.current_version_id = version_id
            return

        if version_id != self.current_version_id:
            if self.logger:
                self.logger.info(f"New version: {data['label']}")

            if not self.dry_run:
                self._download_and_extract(data["download_url"])

            self.current_version_id = version_id

            if self.on_update:
                self.on_update()

        self._update_secrets(data.get("secrets_hash"))

    def _update_secrets(self, new_hash):
        if self.secrets_hash == new_hash:
            return

        if self.logger:
            self.logger.info("Updating secrets")

        if not self.dry_run:
            r = self._get(f"/api/env/{self.project_name}")
            with open(".env", "w") as f:
                f.write(r.text)

        self.secrets_hash = new_hash

        if self.on_secrets_update:
            self.on_secrets_update()

    def _download_and_extract(self, path):
        r = self._get(path)
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            z.extractall(".")

    def _ping(self):
        self._post(f"/api/agent/ping/{self.project_name}")
        self._last_ping = time.time()

    # =============================
    # HTTP
    # =============================

    def _create_session(self):
        session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(max_retries=5)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        return session

    def _get(self, path):
        return self._request("GET", path)

    def _post(self, path):
        return self._request("POST", path)

    def _request(self, method, path):
        try:
            r = self.session.request(
                method,
                f"{self.server_url}{path}",
                headers=self.headers,
                timeout=10
            )
        except requests.RequestException as e:
            raise NetworkError(str(e))

        if r.status_code == 401:
            raise AuthError("Invalid API key")

        if r.status_code >= 500:
            raise ServerError("DeployKit server error")

        return r

    # =============================
    # LOCK
    # =============================

    def _is_locked(self):
        return False if self.dry_run else os.path.exists(LOCK_FILE)

    def _create_lock(self):
        if self.dry_run:
            return
        with open(LOCK_FILE, "w") as f:
            f.write(str(time.time()))

    def _remove_lock(self):
        if self.dry_run:
            return
        try:
            os.remove(LOCK_FILE)
        except FileNotFoundError:
            pass
