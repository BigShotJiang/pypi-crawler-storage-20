class DeployKitError(Exception):
    """Base SDK error"""


class AuthError(DeployKitError):
    pass


class ServerError(DeployKitError):
    pass


class NetworkError(DeployKitError):
    pass
