# Sage X3 Requests Wrapper (ALPHA)

> ⚠️ **AVISO: BIBLIOTECA EM DESENVOLVIMENTO (ALPHA)** ⚠️
>
> Esta biblioteca foi publicada para uso pessoal e testes. **Não é recomendada para produção.**
> A API pode mudar drasticamente a qualquer momento sem aviso prévio. Use por sua conta e risco.

Este é um pacote Python para facilitar a interação com a API do Sage X3.

## Instalação

```bash
pip install sage_x3_requests
```

## Uso Básico

```python
from sage_x3_requests import SageX3Config, SageX3Requester

# Exemplo de configuração
config = SageX3Config(
    base_url="https://seu-sage-x3.com",
    username="user",
    password="password", # Use variáveis de ambiente na prática!
    folder="SEED"
)

# ... resto do código de implementação ...
```
