from sklearn.datasets import load_breast_cancer
from sklearn.ensemble import RandomForestClassifier
from ai_critic import AICritic

X, y = load_breast_cancer(return_X_y=True)

model = RandomForestClassifier(
    n_estimators=50,
    max_depth=3,
    random_state=42
)

critic = AICritic(model, X, y)
report = critic.evaluate()

print(report)
