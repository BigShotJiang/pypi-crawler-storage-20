# AI Critic 🧠⚖️

**AI Critic** is a fast evaluator for scikit-learn models.
It analyzes configuration, robustness, data quality and performance in minutes.

## Install

```bash
pip install ai-critic
```

## Quick Example

```python
from sklearn.datasets import load_breast_cancer
from sklearn.ensemble import RandomForestClassifier
from ai_critic import AICritic

X, y = load_breast_cancer(return_X_y=True)

model = RandomForestClassifier(n_estimators=50, max_depth=3)

critic = AICritic(model, X, y)
report = critic.evaluate()

print(report)
```

## What it evaluates

*   Model configuration sanity
*   Data consistency
*   Robustness to noise
*   Basic performance metrics

## Philosophy

Fast, modular, and brutally honest AI evaluation.

📌 README simples = mais confiança

---

## Development & Testing

To test the package locally as an end-user (mandatory for development):

In the root directory:

```bash
pip install -e .
python -c "from ai_critic import AICritic; print('OK')"
python -m pytest
```
