from ai_critic.evaluators import (
    robustness,
    config,
    data,
    performance
)

class AICritic:
    """
    Orquestrador principal da avaliação de modelos sklearn
    """

    def __init__(self, model, X, y):
        self.model = model
        self.X = X
        self.y = y

    def evaluate(self):
        report = {}

        report["config"] = config(self.model)
        report["data"] = data(self.X, self.y)
        report["performance"] = performance(
            self.model, self.X, self.y
        )
        report["robustness"] = robustness(
            self.model, self.X, self.y
        )

        return report
