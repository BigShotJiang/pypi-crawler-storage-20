def evaluate(model):
    return {
        "model_type": type(model).__name__,
        "n_params": len(model.get_params()),
        "uses_random_state": "random_state" in model.get_params()
    }
