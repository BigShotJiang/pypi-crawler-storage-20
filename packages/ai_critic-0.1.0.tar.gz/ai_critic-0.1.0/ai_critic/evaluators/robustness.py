import numpy as np
from sklearn.base import clone

def evaluate(model, X, y):
    model_1 = clone(model)
    model_2 = clone(model)

    model_1.fit(X, y)
    model_2.fit(X + np.random.normal(0, 1e-6, X.shape), y)

    score_1 = model_1.score(X, y)
    score_2 = model_2.score(X, y)

    return {
        "score_original": float(score_1),
        "score_perturbed": float(score_2),
        "delta": float(abs(score_1 - score_2))
    }
