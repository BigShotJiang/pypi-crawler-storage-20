from sklearn.model_selection import cross_val_score

def evaluate(model, X, y):
    scores = cross_val_score(
        model, X, y, cv=3, n_jobs=1
    )

    return {
        "cv_mean_score": float(scores.mean()),
        "cv_std": float(scores.std())
    }
