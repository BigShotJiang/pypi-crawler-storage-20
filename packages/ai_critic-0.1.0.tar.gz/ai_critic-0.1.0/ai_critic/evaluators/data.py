import numpy as np

def evaluate(X, y):
    return {
        "n_samples": X.shape[0],
        "n_features": X.shape[1],
        "has_nan": bool(
            np.isnan(X).any() or np.isnan(y).any()
        ),
        "class_balance": (
            dict(zip(*np.unique(y, return_counts=True)))
            if len(set(y)) < 20 else "many_classes"
        )
    }
