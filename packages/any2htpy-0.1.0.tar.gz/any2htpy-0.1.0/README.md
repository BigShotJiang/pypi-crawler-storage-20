# any2htpy

**any2htpy** is a principled converter for [htpy](https://htpy.dev) inspired by `html2htpy`, a built-in tool in htpy.

Unlike `html2htpy` any2htpy uses a feature-complete HTML parser called [justhtml](https://github.com/emilstenstrom/justhtml). 

## Features

- adheres to SVG and MathML 
- can adjust for malformed HTML
- properly keeps whitespace for preserving tags


## Usage

```sh
usage: any2htpy [-h] [--input INPUT] [--stdin] [--debug] [--fragment]

options:
  -h, --help     show this help message and exit
  --input INPUT  input as string or file
  --stdin        use stdin as input
  --debug        generate debug output
  --fragment     use htpy fragment[]
```

### input through stdin

```sh
[me@machine ] echo "<p>Hello World</p>" | uv run any2htpy --stdin --prefix htpy
htpy.p["Hello World"]
```

## Disclaimer

As an AI-skeptic, specifically regarding code and software in general, justhtml is not exactly the obvious choice or more precisely the exact opposite one. However, the heavy test-rig with thousands of tests and the use as a parser **without** introducing it as a dependency in the resulting code make it a better choice than any other native Python parser library.

## License

Licensed under the terms of the MIT License 

## Copyright

Copyright (c) 2026 Hartmut Seichter
