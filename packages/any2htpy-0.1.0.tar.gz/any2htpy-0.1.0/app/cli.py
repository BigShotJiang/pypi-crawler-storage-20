"""

any2htpy is a converter from *ml to htpy code

(c) 2026 Hartmut Seichter

"""

import logging
import sys
from argparse import ArgumentParser
from keyword import kwlist as keyword_list

from justhtml import JustHTML
from justhtml.constants import WHITESPACE_PRESERVING_ELEMENTS
from justhtml.node import SimpleDomNode, TextNode

logger = logging.getLogger(__name__)


def _sanitize_identifiers(identifier: str) -> str:
    return identifier.replace("-", "_")


def _handle_attrs(attrs: dict, use_shorthand: bool = False) -> str | None:
    if len(attrs) == 0:
        return None

    attributes = []

    for name, value in attrs.items():
        attr_name = name if name not in keyword_list else name + "_"
        attr_name = _sanitize_identifiers(attr_name)

        # seems a bug in justhtml or because the full document is not available
        attr_name = attr_name.lstrip("None:")
        match name:
            case "class":
                attr_value = [f'"{v}"' for v in value.split()]
                attributes.append(f"{attr_name}=[{','.join(attr_value)}]")
            case _:
                attributes.append(f'{attr_name}="{value}"')

    return ",".join(attributes)


def _handle_whitespace(tag: str | None, text: str) -> str | None:
    if tag and tag in WHITESPACE_PRESERVING_ELEMENTS:
        return f'"""{text}"""'
    elif len(text.strip()) == 0:
        return None
    else:
        return f'"{text}"'


def _node_to_htpy(node: SimpleDomNode, *, use_fragment: bool = True, prefix: str = ""):
    # textnodes can yield None or the string
    if isinstance(node, TextNode):
        t = _handle_whitespace(node.parent.name if node.parent else None, node.text)
        if t and len(t):
            yield t
        else:
            yield None

    # basically everything else directly transforms into a tag
    else:
        # collect subnodes
        sub_tokens = (
            [
                n
                for c in node.children
                for n in _node_to_htpy(c, use_fragment=use_fragment, prefix=prefix)
                if n
            ]
            if node.children
            else []
        )

        tag = node.name

        tag = _sanitize_identifiers(tag)

        # justhtml signifies special nodes with #
        if tag.startswith("#"):
            if "fragment" in tag:
                tag = "fragment" if use_fragment else ""
                if node.children and len(node.children) == 1:
                    tag = ""
            elif "document" in tag:
                tag = ""
            elif "comment" in tag:
                tag = "comment"
            else:
                print("startswith # ", tag)

        # deal with comments
        if tag == "comment":
            yield f'{tag}("{node.data}")'
        # ignore doctype
        elif tag == "!doctype":
            yield None
        else:
            # we strip the fragment out
            if len(sub_tokens) == 1 and tag == "fragment":
                tag = ""

            inner = "[" + (",".join(sub_tokens)) + "]" if len(sub_tokens) else ""

            # prefix
            if len(tag) and len(prefix):
                tag = f"{prefix}.{tag}"

            attrs = _handle_attrs(node.attrs) if node.attrs else None
            yield f"{tag}({attrs}){inner}" if attrs else f"{tag}{inner}"


def any2htpy(data: str, use_fragment: bool = True, use_prefix: str = "") -> str | None:
    # we need to control if it is a fragment
    doc = JustHTML(data, fragment=use_fragment)

    code_tokens = [
        t
        for t in _node_to_htpy(doc.root, use_fragment=use_fragment, prefix=use_prefix)
        if t
    ]

    res = "".join(code_tokens)

    # hack
    if res.startswith("[") and res.endswith("]"):
        res = res[1:-1]

    return res


def main():
    parser = ArgumentParser(prog="any2htpy")

    parser.add_argument("--input", help="input as string or file", type=str)
    parser.add_argument("--stdin", help="use stdin as input", action="store_true")
    parser.add_argument("--debug", help="generate debug output", action="store_true")
    parser.add_argument(
        "--prefix", help="use a prefix for the tags", type=str, default=""
    )
    parser.add_argument(
        "--fragment", help="use htpy fragment", action="store_true", default=True
    )

    args = parser.parse_args()

    if args.debug:
        logger.setLevel(logging.DEBUG)

    if args.input:
        res = any2htpy(args.input, args.fragment)
        print(res)

    elif args.stdin:
        res = any2htpy(
            sys.stdin.read(),
            use_fragment=args.fragment,
            use_prefix=args.prefix,
        )
        print(res)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
