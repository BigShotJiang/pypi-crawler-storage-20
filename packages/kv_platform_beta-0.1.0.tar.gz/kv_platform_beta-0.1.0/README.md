in the root directory 
pip install -e .
to install the sdk locally

then run the files inside the test folder