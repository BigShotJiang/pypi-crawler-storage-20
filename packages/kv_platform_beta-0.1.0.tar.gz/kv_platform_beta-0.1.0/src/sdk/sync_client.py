from sdk._http.sync import SyncHTTPClient
from sdk.resources.faq_generator import FAQGeneratorResource
from sdk.resources.documents import DocumentsResource
from sdk.resources.k_search import KnowledgeSearchResource
from sdk.resources.data_extractor import DataExtractorResource
from sdk.resources.timeline_builder import TimelineBuilderResource
from sdk.resources.generate_draft import DraftGenerator
from sdk.resources.form_filler import FormFillerResource
from sdk.resources.questionnarie_filler import QuestionnaireGenerateResource
from sdk.resources.comparison import FormatComparisonResource
from sdk.resources.text_summarizer import TextSummarizerResource


class Client:
    def __init__(
        self,
        access_key: str,
        base_url: str = "https://api.k-v.ai",
        timeout: float = 30.0,
    ):
        self._http = SyncHTTPClient(base_url, access_key, timeout)
        self.faq_generator = FAQGeneratorResource(self._http)
        self.documents = DocumentsResource(self._http)
        self.k_search = KnowledgeSearchResource(self._http)
        self.data_extractor = DataExtractorResource(self._http)
        self.timeline_builder = TimelineBuilderResource(self._http)
        self.draft_generate = DraftGenerator(self._http)
        self.form_filler = FormFillerResource(self._http)
        self.questionnaire_filler = QuestionnaireGenerateResource(self._http)
        self.comparison = FormatComparisonResource(self._http)
        self.text_summarizer = TextSummarizerResource(self._http)

    def close(self) -> None:
        self._http.close()
