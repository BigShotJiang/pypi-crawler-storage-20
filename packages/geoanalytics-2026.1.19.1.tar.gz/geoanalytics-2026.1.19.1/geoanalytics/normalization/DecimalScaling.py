# DecimalScaling Class for Normalizing Features Using Decimal Scaling Technique

# **Importing and Using the DecimalScaling Class in a Python Program**
#
#             import pandas as pd
#
#             from geoanalytics.normalization import DecimalScaling
#
#             df = pd.read_csv("input.csv")
#
#             scaler = DecimalScaling(df)
#
#             normalized_df = scaler.run()
#
#             scaler.getRuntime()
#
#             scaler.getMemoryUSS()
#
#             scaler.getMemoryRSS()
#
#             scaler.save("DecimalScaling.csv")
#

__copyright__ = """
Copyright (C)  2022 Rage Uday Kiran

     This program is free software: you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation, either version 3 of the License, or
     (at your option) any later version.

     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.

     You should have received a copy of the GNU General Public License
     along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

import time
import psutil
from tqdm import tqdm
import numpy as np
import pandas as pd

class DecimalScaling:
    """
    **About this algorithm**

    :**Description**:
        DecimalScaling is a normalization technique that transforms features by dividing them
        by powers of 10 based on the maximum absolute value. This class normalizes all feature
        columns (excluding coordinates) to scale them within a decimal range, while also tracking
        memory usage and execution time.

    :**Parameters**:
        - `dataframe` (*pd.DataFrame*): Input DataFrame containing 'x', 'y', and feature columns.

    :**Attributes**:
        - **df** (*pd.DataFrame*) -- Original DataFrame with renamed columns.
        - **normalizedDF** (*pd.DataFrame*) -- DataFrame after normalization.
        - **startTime, endTime** (*float*) -- Timestamps for runtime tracking.
        - **memoryUSS, memoryRSS** (*float*) -- Memory usage (USS and RSS) in kilobytes.

    **Execution methods**

    **Calling from a Python program**

    .. code-block:: python

            import pandas as pd

            from geoanalytics.normalization import DecimalScaling

            df = pd.read_csv("input.csv")

            scaler = DecimalScaling(df)

            normalized_df = scaler.run()

            scaler.getRuntime()

            scaler.getMemoryUSS()

            scaler.getMemoryRSS()

            scaler.save("DecimalScaling.csv")


    **Credits**

    This implementation was created by Raashika and revised by M. Charan Teja under the guidance of Professor Rage Uday Kiran.
    """
    def __init__(self, dataframe):
        """
        Initializes the DecimalScaling object with a copy of the dataframe.
        """
        self.df = dataframe.copy()
        self.df.columns = ['x', 'y'] + list(self.df.columns[2:])
        self.normalizedDF = None
        self.startTime = None
        self.endTime = None
        self.memoryUSS = None
        self.memoryRSS = None

    def getRuntime(self):
        """
        Prints the total runtime of the clustering algorithm.
        """
        print("Total Execution time of proposed Algorithm:", self.endTime - self.startTime, "seconds")

    def getMemoryUSS(self):
        """
        Prints the memory usage (USS) of the process in kilobytes.
        """
        print("Memory (USS) of proposed Algorithm in KB:", self.memoryUSS)

    def getMemoryRSS(self):
        """
        Prints the memory usage (RSS) of the process in kilobytes.
        """
        print("Memory (RSS) of proposed Algorithm in KB:", self.memoryRSS)


    def run(self):
        """
        Applies Decimal Scaling normalization to the input features.

        Returns:
            pd.DataFrame: Normalized DataFrame with 'x', 'y', and scaled features.
        """

        self.startTime = time.time()
        xy = self.df[['x', 'y']].reset_index(drop=True)
        data = self.df.drop(['x', 'y'], axis=1).reset_index(drop=True)

        maxAbs = data.abs().max().max()
        numDigits = int(np.ceil(np.log10(maxAbs)))
        divisor = 10 ** numDigits
        normalizedData = data / divisor

        self.normalizedDF = pd.concat([xy, normalizedData], axis=1)
        self.endTime = time.time()
        process = psutil.Process()
        self.memoryUSS = process.memory_full_info().uss / 1024
        self.memoryRSS = process.memory_full_info().rss / 1024

        return self.normalizedDF


    def save(self, outputFile='DecimalScaling.csv'):
        """
        Saves the Normalized DataFrame to a CSV file.
        """
        if self.normalizedDF is not None:
            try:
                self.normalizedDF.to_csv(outputFile, index=False)
                print(f"Normalized data saved to: {outputFile}")
            except Exception as e:
                print(f"Failed to save labels: {e}")
        else:
            print("No Normalized data to save. Execute run() method first")