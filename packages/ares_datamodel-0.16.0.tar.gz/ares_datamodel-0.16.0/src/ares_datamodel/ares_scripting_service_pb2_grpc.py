"""Client and server classes corresponding to protobuf-defined services."""
import grpc
import warnings
from . import ares_scripting_service_pb2 as ares__scripting__service__pb2
GRPC_GENERATED_VERSION = '1.76.0'
GRPC_VERSION = grpc.__version__
_version_not_supported = False
try:
    from grpc._utilities import first_version_is_lower
    _version_not_supported = first_version_is_lower(GRPC_VERSION, GRPC_GENERATED_VERSION)
except ImportError:
    _version_not_supported = True
if _version_not_supported:
    raise RuntimeError(f'The grpc package installed is at version {GRPC_VERSION},' + ' but the generated code in ares_scripting_service_pb2_grpc.py depends on' + f' grpcio>={GRPC_GENERATED_VERSION}.' + f' Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}' + f' or downgrade your generated code using grpcio-tools<={GRPC_VERSION}.')

class AresScriptingServiceStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.ExecuteScript = channel.unary_stream('/ares.services.AresScriptingService/ExecuteScript', request_serializer=ares__scripting__service__pb2.ScriptExecutionRequest.SerializeToString, response_deserializer=ares__scripting__service__pb2.ScriptExecutionOutput.FromString, _registered_method=True)

class AresScriptingServiceServicer(object):
    """Missing associated documentation comment in .proto file."""

    def ExecuteScript(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_AresScriptingServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'ExecuteScript': grpc.unary_stream_rpc_method_handler(servicer.ExecuteScript, request_deserializer=ares__scripting__service__pb2.ScriptExecutionRequest.FromString, response_serializer=ares__scripting__service__pb2.ScriptExecutionOutput.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ares.services.AresScriptingService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ares.services.AresScriptingService', rpc_method_handlers)

class AresScriptingService(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def ExecuteScript(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_stream(request, target, '/ares.services.AresScriptingService/ExecuteScript', ares__scripting__service__pb2.ScriptExecutionRequest.SerializeToString, ares__scripting__service__pb2.ScriptExecutionOutput.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)