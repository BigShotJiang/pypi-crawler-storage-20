"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 31, 1, '', 'ares_outcome_enum.proto')
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x17ares_outcome_enum.proto\x12\x0eares.datamodel*W\n\x07Outcome\x12\x17\n\x13UNSPECIFIED_OUTCOME\x10\x00\x12\x0b\n\x07SUCCESS\x10\x01\x12\x0b\n\x07FAILURE\x10\x02\x12\x0b\n\x07WARNING\x10\x03\x12\x0c\n\x08CANCELED\x10\x04b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'ares_outcome_enum_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_OUTCOME']._serialized_start = 43
    _globals['_OUTCOME']._serialized_end = 130