"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 31, 1, '', 'request_metadata.proto')
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x16request_metadata.proto\x12\x0eares.datamodel"i\n\x0fRequestMetadata\x12\x13\n\x0bsystem_name\x18\x01 \x01(\t\x12\x15\n\rcampaign_name\x18\x02 \x01(\t\x12\x13\n\x0bcampaign_id\x18\x03 \x01(\t\x12\x15\n\rexperiment_id\x18\x04 \x01(\tb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'request_metadata_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    DESCRIPTOR._loaded_options = None
    _globals['_REQUESTMETADATA']._serialized_start = 42
    _globals['_REQUESTMETADATA']._serialized_end = 147