"""
Aniate CLI - Terminal Intelligence Layer
Clean, minimal, bundled.
"""
import sys
import typer
from rich.console import Console
from typing import Optional, List

# Core imports
from .auth import login, logout, signup, whoami
from .commands.chat import brew_chat, delete_chat
from .commands.net import net_search
from .commands import list_intents, run_command
from .brews import save_file, fetch_file, list_files
from .brews import add_secret, get_secret, list_secrets, delete_secret

# Tool imports - bundled, no marketplace
from .brews.tools import fix, review, shell, what

console = Console()
app = typer.Typer(help="Aniate - Terminal Intelligence Layer", no_args_is_help=True)

# ============================================
# AUTH
# ============================================
app.command()(login)
app.command()(logout)
app.command()(signup)
app.command()(whoami)

# ============================================
# BREW
# ============================================
app.command(name="brew.chat")(brew_chat)
app.command(name="delete.chat")(delete_chat)
app.command(name="list")(list_intents)

# ============================================
# TOOLS - Bundled, just works
# ============================================
app.command(name="fix", context_settings={"allow_extra_args": True, "ignore_unknown_options": True})(fix)
app.command(name="review", context_settings={"allow_extra_args": True, "ignore_unknown_options": True})(review)
app.command(name="shell", context_settings={"allow_extra_args": True, "ignore_unknown_options": True})(shell)
app.command(name="what", context_settings={"allow_extra_args": True, "ignore_unknown_options": True})(what)
app.command(name="net", context_settings={"allow_extra_args": True, "ignore_unknown_options": True})(net_search)

# ============================================
# CLOUD
# ============================================
app.command(name="save")(save_file)
app.command(name="fetch")(fetch_file)
app.command(name="files")(list_files)

# ============================================
# SECRETS
# ============================================
app.command(name="secrets.add")(add_secret)
app.command(name="secret")(get_secret)
app.command(name="secrets")(list_secrets)
app.command(name="secrets.delete")(delete_secret)

# ============================================
# HIDDEN
# ============================================
app.command(name="run", hidden=True, context_settings={"allow_extra_args": True, "ignore_unknown_options": True})(run_command)

# ============================================
# HELP
# ============================================
LOGO = """
[white]                    _       _       
   __ _ _ __  (_) __ _| |_ ___
  / _` | '_ \\| |/ _` | __/ _ \\
 | (_| | | | | | (_| | ||  __/
  \\__,_|_| |_|_|\\__,_|\\__\\___|[/white]
                              
  [red]Terminal Intelligence Layer[/red]
"""

def help_command():
    """Show help."""
    console.print(LOGO)
    console.print("[dim]" + "-" * 50 + "[/dim]")
    
    console.print("\n[bold white]IDENTITY[/bold white]")
    console.print("  [white]signup[/white]                  Create account")
    console.print("  [white]login[/white]                   Authenticate")
    console.print("  [white]logout[/white]                  Clear session")
    console.print("  [white]whoami[/white]                  Current user")
    
    console.print("\n[bold white]TOOLS[/bold white]")
    console.print("  [white]fix <file>[/white]              Debug and fix code")
    console.print("  [white]review <file>[/white]           Code review")
    console.print("  [white]shell <query>[/white]           Natural language to shell")
    console.print("  [white]what <file>[/white]             Explain code")
    console.print("  [white]net <query>[/white]             Web search")
    
    console.print("\n[bold white]BREW[/bold white]")
    console.print("  [white]brew.chat <name>[/white]        Create chat assistant")
    console.print("  [white]delete.chat <name>[/white]      Remove assistant")
    console.print("  [white]list[/white]                    Show all brews")
    
    console.print("\n[bold white]CLOUD[/bold white]")
    console.print("  [white]save <file>[/white]             Upload to cloud")
    console.print("  [white]fetch <file>[/white]            Download file")
    console.print("  [white]files[/white]                   List cloud files")
    
    console.print("\n[bold white]SECRETS[/bold white]")
    console.print("  [white]secrets.add <name>[/white]      Store encrypted secret")
    console.print("  [white]secret <name>[/white]           Retrieve secret")
    console.print("  [white]secrets[/white]                 List all secrets")
    console.print("  [white]secrets.delete <name>[/white]   Remove secret")
    
    console.print("\n[bold white]CHAT[/bold white]")
    console.print("  [white]<name>[/white]                  Start chat with brew")
    console.print("  [white]<name> <query>[/white]          One-shot query")
    
    console.print("\n[dim]" + "-" * 50 + "[/dim]")
    console.print("[dim]v1.2.1  |  aniate.com[/dim]\n")

app.command(name="help")(help_command)

# ============================================
# ROUTING
# ============================================
SYSTEM_COMMANDS = [
    "login", "logout", "signup", "whoami",
    "fix", "review", "shell", "what", "net",
    "brew.chat", "delete.chat", "list",
    "save", "fetch", "files",
    "secrets.add", "secret", "secrets", "secrets.delete",
    "help", "--help"
]

def main():
    """Entry point."""
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "help":
            help_command()
            sys.exit(0)
        if cmd not in SYSTEM_COMMANDS:
            sys.argv.insert(1, "run")
    app()

if __name__ == "__main__":
    main()
