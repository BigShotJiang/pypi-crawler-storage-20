"""Tests for beacon-sdk."""
