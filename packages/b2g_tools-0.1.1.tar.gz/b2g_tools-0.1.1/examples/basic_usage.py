"""
Example: Basic B2G Usage

This example demonstrates basic B2G usage for batch grouping.
"""

import scanpy as sc
import b2g

# Load your single-cell data
# Make sure it contains raw counts (not normalized/log-transformed)
adata = sc.read_h5ad('your_data.h5ad')

print(f"Data shape: {adata.shape}")
print(f"Batches: {adata.obs['batch'].unique()}")

# Run B2G grouping (without priors)
b2g.group(
    adata,
    batch_key='batch',
    method='metacell',
    output_dir='b2g_output',
    fig_path='b2g_output/figures',
    met_path='b2g_output/metrics'
)

# Check grouping results
print("\nGrouping results:")
print(adata.obs['groups_metacell_adaptive'].value_counts())

# Continue with standard scanpy workflow
print("\nPerforming standard preprocessing...")
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)
sc.pp.highly_variable_genes(adata, n_top_genes=2000)
sc.pp.pca(adata, n_comps=30, use_highly_variable=True)

# Use B2G groups for batch correction with Harmony
print("\nApplying Harmony batch correction...")
sc.external.pp.harmony_integrate(adata, key='groups_metacell_adaptive')

# Continue with downstream analysis
sc.pp.neighbors(adata, use_rep='X_pca_harmony')
sc.tl.umap(adata)
sc.tl.leiden(adata)

# Visualize
sc.pl.umap(adata, color=['groups_metacell_adaptive', 'batch', 'leiden'])

print("\nDone!")
