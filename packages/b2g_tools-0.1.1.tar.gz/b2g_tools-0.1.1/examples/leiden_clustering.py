"""
Example: B2G Usage with Leiden Clustering

This example demonstrates B2G usage with Leiden clustering instead of metacell.
"""

import scanpy as sc
import b2g

# Load your single-cell data
# Note: Leiden method doesn't require raw counts
adata = sc.read_h5ad('your_data.h5ad')

print(f"Data shape: {adata.shape}")
print(f"Batches: {adata.obs['batch'].unique()}")

# Run B2G with Leiden clustering
b2g.group(
    adata,
    batch_key='batch',
    method='leiden',  # Use Leiden instead of metacell
    leiden_resolution=1.5,  # Adjust resolution as needed
    additional_features=[
        {'column': 'cell_type', 'description': 'Cell type annotation'}
    ],
    min_priors=1,
    max_priors=2,
    output_dir='b2g_leiden_output',
    fig_path='b2g_leiden_output/figures',
    met_path='b2g_leiden_output/metrics'
)

# Check grouping results
print("\nGrouping results:")
print(adata.obs['groups_leiden_adaptive'].value_counts())

# Continue with standard preprocessing
# (can start from normalized data since Leiden doesn't need raw counts)
if 'log1p' not in adata.uns_keys():
    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)

sc.pp.highly_variable_genes(adata, n_top_genes=2000)
sc.pp.pca(adata, n_comps=30, use_highly_variable=True)

# Apply batch correction
sc.external.pp.harmony_integrate(adata, key='groups_leiden_adaptive')

# Downstream analysis
sc.pp.neighbors(adata, use_rep='X_pca_harmony')
sc.tl.umap(adata)
sc.tl.leiden(adata)

# Visualize
sc.pl.umap(adata, color=['groups_leiden_adaptive', 'batch', 'leiden', 'cell_type'])

print("\nDone!")
