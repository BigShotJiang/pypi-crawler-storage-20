"""
Example: B2G Usage with Biological Priors

This example demonstrates B2G usage with biological prior knowledge.
"""

import scanpy as sc
import b2g

# Load your single-cell data
adata = sc.read_h5ad('your_data.h5ad')

print(f"Data shape: {adata.shape}")
print(f"Batches: {adata.obs['donor_id'].unique()}")
print(f"Disease states: {adata.obs['disease'].unique()}")
print(f"Sex: {adata.obs['sex'].unique()}")

# Run B2G with biological priors
# B2G will automatically select the most informative priors using PERMANOVA
b2g.group(
    adata,
    batch_key='donor_id',
    additional_features=[
        {'column': 'disease', 'description': 'Disease status'},
        {'column': 'sex', 'description': 'Biological sex'},
        {'column': 'age_group', 'description': 'Age category'},
        {'column': 'tissue', 'description': 'Tissue type'}
    ],
    method='metacell',
    target_metacell_size=48,
    min_priors=1,
    max_priors=3,
    gap_threshold=0.1,
    output_dir='b2g_output_with_priors',
    fig_path='b2g_output_with_priors/figures',
    met_path='b2g_output_with_priors/metrics'
)

# Check grouping results
print("\nGrouping results:")
print(adata.obs['groups_metacell_adaptive'].value_counts())

# Examine which priors were selected
# Check the prior_selection_log.csv in the metrics directory
import pandas as pd
prior_log = pd.read_csv('b2g_output_with_priors/metrics/prior_selection_log.csv')
print("\nPrior selection results:")
print(prior_log[['prior', 'final_score', 'decision']])

# Continue with standard analysis
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)
sc.pp.highly_variable_genes(adata, n_top_genes=2000)
sc.pp.pca(adata, n_comps=50, use_highly_variable=True)

# Apply batch correction
sc.external.pp.harmony_integrate(adata, key='groups_metacell_adaptive', max_iter_harmony=20)

# Downstream analysis
sc.pp.neighbors(adata, use_rep='X_pca_harmony')
sc.tl.umap(adata)
sc.tl.leiden(adata, resolution=1.0)

# Visualization
sc.pl.umap(adata, color=['groups_metacell_adaptive', 'donor_id', 'disease', 'leiden'])

print("\nDone!")
