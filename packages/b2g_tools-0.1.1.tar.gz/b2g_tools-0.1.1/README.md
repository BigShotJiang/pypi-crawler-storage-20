# B2G: Batch-to-Group


**B2G** (Batch-to-Group) is an intelligent batch grouping tool for single-cell RNA-seq data that combines metacell/Leiden clustering with PERMANOVA-based prior selection.

## Features

- **Adaptive Prior Selection**: Automatically selects informative biological priors using PERMANOVA
- **Flexible Clustering**: Supports both metacell and Leiden clustering methods
- **Batch Effect Mitigation**: Groups batches intelligently to minimize confounding effects
- **Seamless Integration**: Works directly with Scanpy/AnnData workflows
- **Comprehensive Visualization**: Generates dendrograms and evaluation plots

## Installation

### From PyPI (recommended)

```bash
pip install b2g_tools
```

### From Source

```bash
git clone https://github.com/lyotvincent/b2g.git
cd b2g
pip install -e .
```

### Environment Setup with Conda (alternative)

```bash
# Create environment with all dependencies
conda create -n b2g python=3.10 scanpy scikit-learn scikit-bio leidenalg -c conda-forge -c bioconda -y
conda activate b2g

# Install pip-only packages
pip install metacells dynamicTreeCut b2g_tools
```

## Quick Start

### Basic Usage (No Prior Knowledge)

```python
import scanpy as sc
import b2g

# Load your data (with raw counts)
adata = sc.read_h5ad('your_data.h5ad')

# Run B2G grouping
b2g.group(adata, batch_key='batch')

# The grouping result is now in adata.obs['groups_metacell_adaptive']
print(adata.obs['groups_metacell_adaptive'].value_counts())

# Continue with your standard scanpy workflow
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)
sc.pp.highly_variable_genes(adata, n_top_genes=2000)
sc.pp.pca(adata, n_comps=30)

# Use the grouping for batch correction
sc.external.pp.harmony_integrate(adata, key='groups_metacell_adaptive')
```

### Usage with Biological Priors

```python
import scanpy as sc
import b2g

adata = sc.read_h5ad('your_data.h5ad')

# Run B2G with biological priors
b2g.group(
    adata,
    batch_key='donor_id',
    additional_features=[
        {'column': 'disease', 'description': 'Disease status'},
        {'column': 'sex', 'description': 'Biological sex'},
        {'column': 'age_group', 'description': 'Age category'}
    ],
    method='metacell',  # or 'leiden'
    min_priors=1,
    max_priors=3,
    output_dir='b2g_results',
    fig_path='b2g_results/figures',
    met_path='b2g_results/metrics'
)

# Grouping saved in adata.obs['groups_metacell_adaptive']
print(adata.obs['groups_metacell_adaptive'].value_counts())
```

### Using Leiden Clustering Instead of Metacell

```python
b2g.group(
    adata,
    batch_key='batch',
    method='leiden',
    leiden_resolution=1.5,
    additional_features=[
        {'column': 'cell_type', 'description': 'Cell type annotation'}
    ]
)
```

## Parameters

### Main Function: `b2g.group()`

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `adata` | AnnData | Required | AnnData object with raw counts |
| `batch_key` | str | `'batch'` | Column name in `.obs` for batches |
| `method` | str | `'metacell'` | Clustering method: `'metacell'` or `'leiden'` |
| `additional_features` | list | `None` | Biological priors (see format below) |
| `target_metacell_size` | int | `48` | Target metacell size (metacell method only) |
| `leiden_resolution` | float | `1.0` | Leiden resolution (leiden method only) |
| `min_priors` | int | `1` | Minimum priors to select |
| `max_priors` | int | `None` | Maximum priors to select |
| `gap_threshold` | float | `0.1` | Minimum score threshold for filtering |
| `output_dir` | str | `None` | Output directory path |
| `fig_path` | str | `None` | Figures directory path |
| `met_path` | str | `None` | Metrics directory path |
| `key_added` | str | `None` | Column name for grouping results |
| `copy` | bool | `False` | Return a copy of AnnData |

### Additional Features Format

```python
additional_features = [
    {'column': 'column_name_in_obs', 'description': 'Human readable description'},
    # ... more features
]
```

## Input Requirements

- **Data Format**: AnnData object compatible with Scanpy
- **Count Matrix**: Raw UMI counts (integers) required for metacell method
  - Should be in `adata.X` or `adata.raw.X`
  - Not normalized, log-transformed, or scaled
- **Batch Column**: Categorical column in `adata.obs` identifying batches
- **Prior Columns** (optional): Categorical columns in `adata.obs` for biological priors

## Output

### In AnnData Object

- `adata.obs[key_added]`: Batch group assignments (e.g., 'G1', 'G2', 'G3')
- Additional columns created during processing (e.g., `metacell`, `prior_group`)

### Output Files (if paths specified)

```
output_dir/
├── figures/
│   ├── dendrogram.png              # Hierarchical clustering dendrogram
│   ├── prior_selection_results.png # Prior evaluation visualization
│   └── alpha_optimization.png      # Alpha parameter optimization
└── metrics/
    ├── prior_selection_log.csv     # Detailed prior selection log
    ├── alpha_optimization.csv      # Alpha evaluation results
    └── clustering_results/
        ├── distance_matrix_square.npy
        ├── distance_matrix_condensed.npy
        └── linkage_matrix_Z.npy
```

## Advanced Usage

### Custom Configuration

```python
from b2g import AnalysisConfig, group_batches

# Create custom configuration
config = AnalysisConfig()
config.clustering_method = 'metacell'
config.b2g_metacell_params['target_metacell_size'] = 64
config.b2g_min_priors = 2
config.b2g_max_priors = 4
config.leiden_params['resolution'] = 2.0

# Run with custom config
adata = group_batches(adata, config, key_added='custom_groups')
```

### Integration with Batch Correction Methods

```python
import scanpy as sc
import b2g

# Step 1: Load data
adata = sc.read_h5ad('data.h5ad')

# Step 2: Run B2G grouping
b2g.group(adata, batch_key='batch_id', method='metacell')

# Step 3: Standard preprocessing
sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)
sc.pp.highly_variable_genes(adata, n_top_genes=2000)
sc.pp.pca(adata, n_comps=50)

# Step 4: Use B2G groups for batch correction
# With Harmony
sc.external.pp.harmony_integrate(adata, key='groups_metacell_adaptive')

# With Scanorama
import scanorama
adata_list = [adata[adata.obs['groups_metacell_adaptive'] == g].copy() 
              for g in adata.obs['groups_metacell_adaptive'].unique()]
scanorama.integrate_scanpy(adata_list)

# With Combat
import scanpy.external as sce
sce.pp.combat(adata, key='groups_metacell_adaptive')
```

## How It Works

1. **Prior Selection**: Evaluates biological priors using PERMANOVA to identify informative features
2. **Clustering**: Builds metacells or Leiden clusters, optionally grouped by selected priors
3. **Feature Extraction**: Creates batch-feature matrix from clustering results
4. **Distance Calculation**: Computes weighted distances between batches
5. **Hierarchical Clustering**: Groups batches based on their feature similarity
6. **Dynamic Tree Cutting**: Automatically determines optimal batch groups

