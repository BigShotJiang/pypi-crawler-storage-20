# Ask AI 
## Features
* Uses ChatGPT to answer users questions
* Powered by groq module
* You can use ask function to use this library
## Usage
```python
# Import the ask function from your package
from ask_ai import ask

# Use the ask function to send a query to AI
response = ask("Hello, what is your name?")
print(response)
```