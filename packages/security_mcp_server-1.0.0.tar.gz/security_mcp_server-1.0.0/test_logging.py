#!/usr/bin/env python3
"""
Test script for loguru logging migration
"""
import sys
from loguru import logger

# Configure logger similar to security_mcp.py
logger.remove()
logger.add(
    sys.stderr,
    format="<green>[🔥 SecurityAI MCP]</green> <cyan>{time:YYYY-MM-DD HH:mm:ss}</cyan> <level>[{level}]</level> <level>{message}</level>",
    level="INFO",
    colorize=True,
    backtrace=True,
    diagnose=True
)

def test_logging_levels():
    """Test all logging levels"""
    print("\n" + "="*60)
    print("Testing Loguru Logging Levels")
    print("="*60 + "\n")
    
    logger.debug("🔍 This is a DEBUG message (should not appear in INFO mode)")
    logger.info("✅ This is an INFO message")
    logger.success("🎉 This is a SUCCESS message")
    logger.warning("⚠️  This is a WARNING message")
    logger.error("❌ This is an ERROR message")
    logger.critical("🔥 This is a CRITICAL message")
    
    print("\n" + "="*60)

def test_formatted_messages():
    """Test formatted messages"""
    print("\n" + "="*60)
    print("Testing Formatted Messages")
    print("="*60 + "\n")
    
    target = "192.168.1.1"
    port = 8888
    
    logger.info(f"🔗 Connecting to: {target}:{port}")
    logger.success(f"✅ Connection established to {target}")
    logger.warning(f"⚠️  Timeout connecting to {target}")
    logger.error(f"❌ Failed to connect to {target}")
    
    print("\n" + "="*60)

def test_exception_logging():
    """Test exception logging"""
    print("\n" + "="*60)
    print("Testing Exception Logging")
    print("="*60 + "\n")
    
    try:
        result = 1 / 0
    except Exception as e:
        logger.exception("💥 Exception occurred during calculation")
    
    print("\n" + "="*60)

def test_debug_mode():
    """Test debug mode"""
    print("\n" + "="*60)
    print("Testing Debug Mode")
    print("="*60 + "\n")
    
    # Reconfigure for debug mode
    logger.remove()
    logger.add(
        sys.stderr,
        format="<green>[🔥 SecurityAI MCP]</green> <cyan>{time:YYYY-MM-DD HH:mm:ss}</cyan> <level>[{level}]</level> <level>{message}</level>",
        level="DEBUG",
        colorize=True,
        backtrace=True,
        diagnose=True
    )
    
    logger.debug("🔍 Debug mode is now enabled")
    logger.info("✅ This is an INFO message in debug mode")
    
    print("\n" + "="*60)

def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("🔥 Loguru Logging Migration Test Suite")
    print("="*60)
    
    test_logging_levels()
    test_formatted_messages()
    test_exception_logging()
    test_debug_mode()
    
    print("\n" + "="*60)
    print("✅ All logging tests completed!")
    print("="*60 + "\n")

if __name__ == "__main__":
    main()
