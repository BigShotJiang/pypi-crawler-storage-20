# security AI MCP Server

🔥 Advanced Security Testing and Automation Framework with 70+ Tools

## Overview

security AI MCP Server is a comprehensive Model Context Protocol (MCP) server that provides AI agents with access to 70+ professional security testing tools. Perfect for bug bounty hunting, CTF competitions, penetration testing, and security research.

## Features

- 🎯 **70+ Security Tools**: Nmap, Nuclei, Metasploit, SQLMap, and more
- ☁️ **Cloud Security**: AWS/Azure/GCP security assessment tools
- 🐳 **Container Security**: Docker, Kubernetes security scanning
- 🔧 **Binary Analysis**: Ghidra, Radare2, GDB, Pwntools
- 🌐 **Web Security**: Directory fuzzing, vulnerability scanning
- 🔐 **Password Cracking**: Hashcat, John the Ripper, Hydra
- 🚀 **FastMCP Integration**: Seamless AI agent communication

## Installation

```bash
pip install security-ai-mcp
```

### With Binary Analysis Tools

```bash
pip install security-ai-mcp[binary]
```

### Development Installation

```bash
pip install security-ai-mcp[dev]
```

## Quick Start

### As MCP Server

```bash
security-mcp --server http://127.0.0.1:8888
```

### Configuration

Add to your MCP client configuration:

```json
{
  "mcpServers": {
    "security-ai-mcp": {
      "command": "security-mcp",
      "args": ["--server", "http://127.0.0.1:8888"]
    }
  }
}
```

## Tool Categories

### Network Scanning
- Nmap (basic & advanced)
- Rustscan
- Masscan
- AutoRecon

### Web Application Security
- Nuclei
- Gobuster
- FFuf
- SQLMap
- Nikto
- WPScan

### Cloud Security
- Prowler (AWS/Azure/GCP)
- Trivy
- Scout Suite
- Kube-hunter
- Checkov

### Binary Analysis
- Ghidra
- Radare2
- GDB with PEDA
- Pwntools
- Angr

### Password Cracking
- Hashcat
- John the Ripper
- Hydra

## Requirements

- Python 3.10+
- Security tools installed on the target system
- security AI API Server (for tool execution)

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Disclaimer

This tool is for authorized security testing only. Always obtain proper authorization before testing any systems you don't own.
