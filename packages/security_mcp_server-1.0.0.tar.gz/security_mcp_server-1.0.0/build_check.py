#!/usr/bin/env python3
"""
Build verification script for security-ai-mcp package
"""
import sys
import tomli
from pathlib import Path

def check_pyproject():
    """Verify pyproject.toml is valid"""
    print("🔍 Checking pyproject.toml...")
    
    try:
        with open("pyproject.toml", "rb") as f:
            config = tomli.load(f)
        
        # Check required fields
        required_fields = {
            "project": ["name", "version", "description", "dependencies"],
            "build-system": ["requires", "build-backend"],
        }
        
        for section, fields in required_fields.items():
            if section not in config:
                print(f"❌ Missing section: [{section}]")
                return False
            
            for field in fields:
                if field not in config[section]:
                    print(f"❌ Missing field: {section}.{field}")
                    return False
        
        print(f"✅ Package name: {config['project']['name']}")
        print(f"✅ Version: {config['project']['version']}")
        print(f"✅ Python requirement: {config['project']['requires-python']}")
        print(f"✅ Dependencies: {len(config['project']['dependencies'])} packages")
        
        # Check for version conflicts in dependencies
        dependencies = config['project']['dependencies']
        flask_deps = [dep for dep in dependencies if dep.startswith('flask')]
        if flask_deps:
            flask_constraint = flask_deps[0]
            print(f"✅ Flask constraint: {flask_constraint}")
            
            # Check if Flask is pinned to 2.x (to avoid werkzeug conflicts)
            if "flask>=2.3.0,<3.0.0" in flask_constraint:
                print("✅ Flask pinned to 2.x (avoids werkzeug conflicts)")
            elif "flask>=3.0.0" in flask_constraint:
                print("⚠️  Flask 3.x may have werkzeug conflicts with openapi-core")
        
        # Check scripts
        if "scripts" in config["project"]:
            print(f"✅ Entry points: {list(config['project']['scripts'].keys())}")
        
        # Check modules
        if "setuptools" in config.get("tool", {}):
            py_modules = config["tool"]["setuptools"].get("py-modules", [])
            print(f"✅ Python modules: {py_modules}")
            
            # Verify modules exist
            for module in py_modules:
                module_file = Path(f"{module}.py")
                if not module_file.exists():
                    print(f"❌ Module file not found: {module_file}")
                    return False
                print(f"   ✓ Found: {module_file}")
        
        print("\n✅ pyproject.toml is valid!")
        return True
        
    except Exception as e:
        print(f"❌ Error reading pyproject.toml: {e}")
        return False

def check_required_files():
    """Check if all required files exist"""
    print("\n🔍 Checking required files...")
    
    required_files = [
        "pyproject.toml",
        "README.md",
        "LICENSE",
        "security_mcp.py",
    ]
    
    all_exist = True
    for file in required_files:
        if Path(file).exists():
            print(f"✅ {file}")
        else:
            print(f"❌ Missing: {file}")
            all_exist = False
    
    return all_exist

def check_dependency_compatibility():
    """Check for known dependency conflicts"""
    print("\n🔍 Checking dependency compatibility...")
    
    try:
        # Run the dependency test script
        import subprocess
        result = subprocess.run([sys.executable, "test_dependencies.py"], 
                              capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            print("✅ Dependency compatibility test passed")
            return True
        else:
            print("❌ Dependency compatibility test failed")
            print("Output:", result.stdout)
            print("Errors:", result.stderr)
            return False
            
    except FileNotFoundError:
        print("⚠️  test_dependencies.py not found, skipping compatibility test")
        return True
    except subprocess.TimeoutExpired:
        print("⚠️  Dependency test timed out")
        return True
    except Exception as e:
        print(f"⚠️  Could not run dependency test: {e}")
        return True

def main():
    print("=" * 60)
    print("Security AI MCP - Build Verification")
    print("=" * 60)
    
    checks = [
        check_required_files(),
        check_pyproject(),
        check_dependency_compatibility(),
    ]
    
    if all(checks):
        print("\n" + "=" * 60)
        print("✅ All checks passed! Ready to build.")
        print("=" * 60)
        print("\nRun: python3 -m build")
        print("Or: pip install -e .")
        return 0
    else:
        print("\n" + "=" * 60)
        print("❌ Some checks failed. Please fix the issues above.")
        print("=" * 60)
        return 1

if __name__ == "__main__":
    try:
        import tomli
    except ImportError:
        print("❌ tomli not installed. Installing...")
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "tomli"])
        import tomli
    
    sys.exit(main())