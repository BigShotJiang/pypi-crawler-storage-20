#!/usr/bin/env python3
"""
Dependency compatibility test script
"""
import sys
import importlib.util

def test_import(module_name, package_name=None):
    """Test if a module can be imported"""
    try:
        if package_name:
            spec = importlib.util.find_spec(module_name, package_name)
        else:
            spec = importlib.util.find_spec(module_name)
        
        if spec is None:
            return False, f"Module {module_name} not found"
        
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return True, module
    except Exception as e:
        return False, str(e)

def check_version_compatibility():
    """Check version compatibility of key packages"""
    print("🔍 Checking dependency compatibility...")
    print("=" * 50)
    
    # Test core imports
    tests = [
        ("flask", "Flask"),
        ("werkzeug", "Werkzeug"), 
        ("requests", "Requests"),
        ("psutil", "psutil"),
        ("loguru", "Loguru"),
        ("fastmcp", "FastMCP"),
    ]
    
    results = {}
    
    for module, display_name in tests:
        success, result = test_import(module)
        if success:
            try:
                version = getattr(result, '__version__', 'Unknown')
                print(f"✅ {display_name}: {version}")
                results[module] = {'status': 'success', 'version': version, 'module': result}
            except:
                print(f"✅ {display_name}: Imported (version unknown)")
                results[module] = {'status': 'success', 'version': 'Unknown', 'module': result}
        else:
            print(f"❌ {display_name}: {result}")
            results[module] = {'status': 'failed', 'error': result}
    
    return results

def check_werkzeug_flask_compatibility(results):
    """Check specific Flask/Werkzeug compatibility"""
    print("\n🔧 Checking Flask/Werkzeug compatibility...")
    print("=" * 50)
    
    if 'flask' not in results or 'werkzeug' not in results:
        print("❌ Cannot check compatibility - Flask or Werkzeug not available")
        return False
    
    if results['flask']['status'] != 'success' or results['werkzeug']['status'] != 'success':
        print("❌ Cannot check compatibility - Import failures")
        return False
    
    flask_version = results['flask']['version']
    werkzeug_version = results['werkzeug']['version']
    
    print(f"Flask version: {flask_version}")
    print(f"Werkzeug version: {werkzeug_version}")
    
    # Try to create a Flask app to test compatibility
    try:
        flask_module = results['flask']['module']
        app = flask_module.Flask(__name__)
        
        @app.route('/test')
        def test_route():
            return 'OK'
        
        print("✅ Flask app creation successful")
        print("✅ Route registration successful")
        return True
        
    except Exception as e:
        print(f"❌ Flask/Werkzeug compatibility issue: {e}")
        return False

def check_openapi_core_conflict():
    """Check if openapi-core is installed and conflicts"""
    print("\n🔍 Checking openapi-core conflicts...")
    print("=" * 50)
    
    success, result = test_import('openapi_core')
    if not success:
        print("ℹ️  openapi-core not installed (no conflict)")
        return True
    
    try:
        version = getattr(result, '__version__', 'Unknown')
        print(f"📦 openapi-core version: {version}")
        
        # Check werkzeug version
        werkzeug_success, werkzeug_result = test_import('werkzeug')
        if werkzeug_success:
            werkzeug_version = getattr(werkzeug_result, '__version__', 'Unknown')
            print(f"📦 werkzeug version: {werkzeug_version}")
            
            # Parse versions for comparison
            try:
                from packaging import version as pkg_version
                werkzeug_ver = pkg_version.parse(werkzeug_version)
                
                # openapi-core 0.19.5 requires werkzeug<3.1.2
                if werkzeug_ver >= pkg_version.parse("3.1.2"):
                    print("❌ Potential conflict: werkzeug>=3.1.2 with openapi-core")
                    return False
                else:
                    print("✅ No werkzeug/openapi-core conflict detected")
                    return True
            except ImportError:
                print("⚠️  Cannot parse versions (packaging not available)")
                return True
        else:
            print("❌ Cannot check werkzeug version")
            return False
            
    except Exception as e:
        print(f"❌ Error checking openapi-core: {e}")
        return False

def test_security_mcp_import():
    """Test security_mcp import"""
    print("\n🔍 Testing security_mcp import...")
    print("=" * 50)
    
    try:
        from security_mcp import logger
        logger.info("✅ security_mcp import successful")
        return True
    except Exception as e:
        print(f"❌ security_mcp import failed: {e}")
        return False

def main():
    """Run all compatibility tests"""
    print("🧪 Dependency Compatibility Test Suite")
    print("=" * 50)
    print(f"Python version: {sys.version}")
    print()
    
    # Run tests
    results = check_version_compatibility()
    flask_werkzeug_ok = check_werkzeug_flask_compatibility(results)
    openapi_ok = check_openapi_core_conflict()
    security_mcp_ok = test_security_mcp_import()
    
    # Summary
    print("\n📊 Test Summary")
    print("=" * 50)
    
    all_imports_ok = all(r['status'] == 'success' for r in results.values())
    
    print(f"Core imports: {'✅ PASS' if all_imports_ok else '❌ FAIL'}")
    print(f"Flask/Werkzeug compatibility: {'✅ PASS' if flask_werkzeug_ok else '❌ FAIL'}")
    print(f"openapi-core conflicts: {'✅ PASS' if openapi_ok else '❌ FAIL'}")
    print(f"security_mcp import: {'✅ PASS' if security_mcp_ok else '❌ FAIL'}")
    
    overall_status = all([all_imports_ok, flask_werkzeug_ok, openapi_ok, security_mcp_ok])
    
    print(f"\n🎯 Overall Status: {'✅ ALL TESTS PASSED' if overall_status else '❌ SOME TESTS FAILED'}")
    
    if not overall_status:
        print("\n💡 Troubleshooting:")
        print("1. Run: pip install --force-reinstall security-ai-mcp")
        print("2. Or see: VERSION_CONFLICT_FIX.md")
    
    return 0 if overall_status else 1

if __name__ == "__main__":
    sys.exit(main())