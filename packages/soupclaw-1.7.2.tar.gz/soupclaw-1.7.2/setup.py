from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="soupclaw",
    version="1.7.2",
    author="Callum",
    author_email="callumdev2292@gmail.com",
    description="Discord Clipboard System",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/callummill/soupclaw",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Utilities",
    ],
    python_requires=">=3.7",
    keywords="discord, clipboard, utility, productivity",
    project_urls={
        "Bug Reports": "https://github.com/callummill/soupclaw/issues",
        "Source": "https://github.com/callummill/soupclaw",
    },
)