# SoupClaw - Discord Clipboard System

A clipboard utility for Discord that allows you to copy and paste message content.

## Features
- Copy Discord message content to clipboard
- Paste clipboard content
- Persistent storage of clipboard items
- Simple API for integration

## Installation
```bash
pip install soupclaw