"""
Advanced rate limiter using token bucket algorithm.
Prevents hitting Discord's rate limits.
"""
import asyncio
import time
from typing import Dict, Optional
from datetime import datetime, timedelta


class RateLimiter:
    """
    Token bucket rate limiter for Discord API calls.
    Ensures we never exceed Discord's rate limits.
    """
    
    def __init__(self, calls_per_second: float = 2.0, burst: int = 5):
        """
        Args:
            calls_per_second: Sustained rate limit (Discord allows ~2-5 per second)
            burst: Maximum burst size (allows brief spikes)
        """
        self.rate = calls_per_second
        self.burst = burst
        self.tokens = burst
        self.last_update = time.monotonic()
        self._lock = asyncio.Lock()
    
    async def acquire(self, tokens: int = 1):
        """Wait until we can make an API call without hitting rate limits"""
        async with self._lock:
            while True:
                now = time.monotonic()
                elapsed = now - self.last_update
                
                # Add tokens based on elapsed time
                self.tokens = min(self.burst, self.tokens + elapsed * self.rate)
                self.last_update = now
                
                if self.tokens >= tokens:
                    self.tokens -= tokens
                    return
                
                # Wait for enough tokens
                wait_time = (tokens - self.tokens) / self.rate
                await asyncio.sleep(wait_time)


class PerGuildRateLimiter:
    """Rate limiter that tracks limits per guild"""
    
    def __init__(self, calls_per_second: float = 2.0):
        self.limiters: Dict[int, RateLimiter] = {}
        self.calls_per_second = calls_per_second
        self._cleanup_task = None
    
    def get_limiter(self, guild_id: int) -> RateLimiter:
        """Get or create rate limiter for a guild"""
        if guild_id not in self.limiters:
            self.limiters[guild_id] = RateLimiter(self.calls_per_second)
        return self.limiters[guild_id]
    
    async def acquire(self, guild_id: int, tokens: int = 1):
        """Acquire permission to make API call for a specific guild"""
        limiter = self.get_limiter(guild_id)
        await limiter.acquire(tokens)
    
    def cleanup_old_limiters(self):
        """Remove limiters for guilds we haven't seen in a while"""
        # Keep implementation simple - limiters are lightweight
        pass


class GlobalRateLimiter:
    """Global rate limiter across all guilds"""
    
    def __init__(self, global_calls_per_second: float = 50.0):
        self.limiter = RateLimiter(global_calls_per_second, burst=100)
    
    async def acquire(self, tokens: int = 1):
        """Acquire from global rate limit pool"""
        await self.limiter.acquire(tokens)


class RetryHandler:
    """Handle retries with exponential backoff for rate limit errors"""
    
    @staticmethod
    async def execute_with_retry(coro, max_retries: int = 3):
        """
        Execute coroutine with exponential backoff on rate limit errors.
        
        Args:
            coro: Coroutine to execute
            max_retries: Maximum number of retries
            
        Returns:
            Result of the coroutine
        """
        import discord
        
        for attempt in range(max_retries):
            try:
                return await coro
            except discord.HTTPException as e:
                if e.status == 429:  # Rate limited
                    retry_after = getattr(e, 'retry_after', 2 ** attempt)
                    print(f"⚠️ Rate limited! Retrying after {retry_after}s (attempt {attempt + 1}/{max_retries})")
                    await asyncio.sleep(retry_after)
                else:
                    raise
            except Exception as e:
                # Don't retry on other errors
                raise
        
        raise Exception(f"Failed after {max_retries} retries")
