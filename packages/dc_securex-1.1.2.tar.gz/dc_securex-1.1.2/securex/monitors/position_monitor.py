"""
Continuous position and permission monitoring.
Optimized with rate limiting and caching for maximum performance.

⚠️ WARNING: This will make significant API calls. Use with caution!
"""
import discord
import asyncio
import json
import time
from typing import Dict, List, Optional, Set, Tuple
from pathlib import Path
from datetime import datetime, timedelta
from ..utils.rate_limiter import PerGuildRateLimiter, GlobalRateLimiter, RetryHandler


class PositionMonitor:
    """
    Monitors and restores channel/role positions and permissions.
    Runs background tasks every 5 seconds.
    """
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_manager = sdk.backup_manager
        self.backup_dir = sdk.backup_dir
        self.whitelist = sdk.whitelist
        
        # Configuration
        self.check_interval = 5  # seconds
        self.enabled = False
        
        # Task references
        self._position_task = None
        self._permission_task = None
        
        # Rate limiting (OPTIMIZED)
        self._per_guild_limiter = PerGuildRateLimiter(calls_per_second=2.5)
        self._global_limiter = GlobalRateLimiter(global_calls_per_second=40.0)
        self._last_position_fix: Dict[int, datetime] = {}
        self._fix_cooldown = 10  # Don't fix same item within 10 seconds
        
        # Backup caching (avoid repeated file reads)
        self._backup_cache: Dict[int, Dict] = {
            'roles': {},      # {guild_id: {data, timestamp}}
            'channels': {}    # {guild_id: {data, timestamp}}
        }
        self._cache_ttl = 30  # Cache for 30 seconds
        
        # Performance tracking
        self._stats = {
            'checks': 0,
            'fixes': 0,
            'api_calls': 0,
            'cache_hits': 0
        }
    
    def start(self):
        """Start all monitoring tasks"""
        if self.enabled:
            return
        
        self.enabled = True
        print("🔍 SecureX Position Monitor: Starting...")
        
        # Start background tasks
        self._position_task = self.bot.loop.create_task(self._monitor_positions())
        self._permission_task = self.bot.loop.create_task(self._monitor_permissions())
    
    def _get_cached_backup(self, backup_type: str, guild_id: int) -> Optional[Dict]:
        """Get backup data from cache or file system"""
        cache_key = guild_id
        cache = self._backup_cache[backup_type]
        
        # Check cache
        if cache_key in cache:
            cached_data, timestamp = cache[cache_key]
            age = (datetime.utcnow() - timestamp).total_seconds()
            
            if age < self._cache_ttl:
                self._stats['cache_hits'] += 1
                return cached_data
        
        # Cache miss - load from file
        backup_file = self.backup_dir / f"{backup_type}_{guild_id}.json"
        if not backup_file.exists():
            return None
        
        try:
            with open(backup_file, 'r') as f:
                data = json.load(f)
            
            # Update cache
            cache[cache_key] = (data, datetime.utcnow())
            return data
        except Exception as e:
            print(f"Error loading backup: {e}")
            return None
    
    def _invalidate_cache(self, guild_id: int):
        """Invalidate cache for a guild (call after backup creation)"""
        for cache_type in self._backup_cache:
            if guild_id in self._backup_cache[cache_type]:
                del self._backup_cache[cache_type][guild_id]
    
    def stop(self):
        """Stop all monitoring tasks"""
        self.enabled = False
        
        if self._position_task:
            self._position_task.cancel()
        if self._permission_task:
            self._permission_task.cancel()
        
        print("🛑 SecureX Position Monitor: Stopped")
    
    async def _monitor_positions(self):
        """Background task to check positions every 5 seconds (OPTIMIZED)"""
        await self.bot.wait_until_ready()
        
        while self.enabled and not self.bot.is_closed():
            try:
                start_time = time.time()
                
                # Process all guilds in parallel for speed
                tasks = []
                for guild in self.bot.guilds:
                    tasks.append(self._check_guild_positions(guild))
                
                # Execute in parallel (limited concurrency)
                if tasks:
                    # Process in batches of 3 guilds at a time to avoid overwhelming
                    batch_size = 3
                    for i in range(0, len(tasks), batch_size):
                        batch = tasks[i:i + batch_size]
                        await asyncio.gather(*batch, return_exceptions=True)
                
                # Log performance
                elapsed = time.time() - start_time
                self._stats['checks'] += 1
                
                if self._stats['checks'] % 10 == 0:  # Every 10 checks
                    print(f"📊 Position Monitor Stats: {self._stats['fixes']} fixes, "
                          f"{self._stats['api_calls']} API calls, "
                          f"{self._stats['cache_hits']} cache hits, "
                          f"Last check: {elapsed:.2f}s, "
                          f"Efficiency: {self._stats['fixes']}/{self._stats['api_calls']} fixes per call")
                
                # Wait before next check
                await asyncio.sleep(max(0, self.check_interval - elapsed))
                
            except Exception as e:
                print(f"Error in position monitor: {e}")
                await asyncio.sleep(self.check_interval)
    
    async def _check_guild_positions(self, guild: discord.Guild):
        """Check both role and channel positions for a guild"""
        try:
            await self._check_role_positions(guild)
            await self._check_channel_positions(guild)
        except Exception as e:
            print(f"Error checking positions for {guild.name}: {e}")
    
    async def _check_role_positions(self, guild: discord.Guild):
        """Check and restore role positions using BULK endpoint (OPTIMIZED)"""
        try:
            # Use cached backup
            backup = self._get_cached_backup('roles', guild.id)
            if not backup:
                return
            
            # Create position map from backup
            backup_positions = {
                role_data['id']: role_data['position'] 
                for role_data in backup['roles']
            }
            
            # Collect ALL mismatched roles (don't check cooldown yet!)
            role_position_pairs = []
            mismatched_roles = []
            
            for role in guild.roles:
                if role.id in backup_positions:
                    expected_pos = backup_positions[role.id]
                    if role.position != expected_pos:
                        role_position_pairs.append((role, expected_pos))
                        mismatched_roles.append({
                            'role': role,
                            'expected': expected_pos,
                            'current': role.position
                        })
            
            if not role_position_pairs:
                return  # Nothing to fix
            
            # NOW check cooldown (after we know there are changes)
            if self._is_on_cooldown(guild.id, f"role_bulk"):
                print(f"⏱️ Bulk role position restore on cooldown for {guild.name}, skipping")
                return
            
            # Use Discord's BULK endpoint to update all positions in ONE API call
            print(f"🔧 Restoring {len(role_position_pairs)} role positions in {guild.name} using bulk endpoint")
            
            try:
                # Acquire rate limits
                await self._per_guild_limiter.acquire(guild.id)
                await self._global_limiter.acquire()
                
                # Build payload for bulk update
                # Format: list of {"id": role_id, "position": new_position}
                positions_payload = [
                    {"id": role.id, "position": expected_pos}
                    for role, expected_pos in role_position_pairs
                ]
                
                # Use Discord's bulk role positions endpoint
                await RetryHandler.execute_with_retry(
                    guild.edit_role_positions(positions=positions_payload, reason="SecureX: Bulk position restore")
                )
                
                # Set cooldown for bulk operation
                self._set_cooldown(guild.id, f"role_bulk")
                self._stats['fixes'] += len(role_position_pairs)
                self._stats['api_calls'] += 1  # Only 1 API call for all roles!
                
                print(f"✅ Successfully restored {len(role_position_pairs)} role positions in {guild.name}")
                
            except discord.Forbidden as e:
                print(f"⚠️ Missing permissions to modify role positions: {e}")
            except Exception as e:
                print(f"Error in bulk role position restore: {e}")
                # Fallback to individual updates if bulk fails
                await self._fallback_individual_role_updates(guild, role_position_pairs)
        
        except Exception as e:
            print(f"Error checking role positions: {e}")
    
    async def _fallback_individual_role_updates(self, guild: discord.Guild, role_position_pairs: list):
        """Fallback: Update roles individually if bulk update fails"""
        print(f"⚠️ Falling back to individual role updates for {len(role_position_pairs)} roles")
        
        for role, expected_pos in role_position_pairs:
            try:
                await self._per_guild_limiter.acquire(guild.id)
                await role.edit(position=expected_pos, reason="SecureX: Position restore (fallback)")
                self._stats['api_calls'] += 1
                await asyncio.sleep(0.5)  # Small delay between individual updates
            except Exception as e:
                print(f"Error updating {role.name}: {e}")
    
    async def _check_channel_positions(self, guild: discord.Guild):
        """Check and restore channel positions from backup (OPTIMIZED)"""
        try:
            # Use cached backup
            backup = self._get_cached_backup('channels', guild.id)
            if not backup:
                return
            
            # Create position map
            backup_positions = {
                ch_data['id']: ch_data['position']
                for ch_data in backup['channels']
            }
            
            # Find changes
            changes_needed = []
            for channel in guild.channels:
                if channel.id in backup_positions:
                    expected_pos = backup_positions[channel.id]
                    if channel.position != expected_pos:
                        if not self._is_on_cooldown(guild.id, f"channel_{channel.id}"):
                            changes_needed.append((channel, expected_pos))
            
            if not changes_needed:
                return
            
            # Apply fixes with rate limiting
            print(f"🔧 Fixing {len(changes_needed)} channel positions in {guild.name}")
            
            for channel, expected_pos in changes_needed:
                try:
                    await self._per_guild_limiter.acquire(guild.id)
                    await self._global_limiter.acquire()
                    
                    await RetryHandler.execute_with_retry(
                        channel.edit(position=expected_pos, reason="SecureX: Restoring position")
                    )
                    
                    self._set_cooldown(guild.id, f"channel_{channel.id}")
                    self._stats['fixes'] += 1
                    self._stats['api_calls'] += 1
                    
                except Exception as e:
                    print(f"Error fixing channel position: {e}")
        
        except Exception as e:
            print(f"Error checking channel positions: {e}")
    
    async def _monitor_permissions(self):
        """Background task to monitor channel permissions every 5 seconds (OPTIMIZED)"""
        await self.bot.wait_until_ready()
        
        while self.enabled and not self.bot.is_closed():
            try:
                # Process guilds in parallel
                tasks = []
                for guild in self.bot.guilds:
                    tasks.append(self._check_channel_permissions(guild))
                
                # Execute in batches
                if tasks:
                    batch_size = 3
                    for i in range(0, len(tasks), batch_size):
                        batch = tasks[i:i + batch_size]
                        await asyncio.gather(*batch, return_exceptions=True)
                
                await asyncio.sleep(self.check_interval)
                
            except Exception as e:
                print(f"Error in permission monitor: {e}")
                await asyncio.sleep(self.check_interval)
    
    async def _check_channel_permissions(self, guild: discord.Guild):
        """Check and restore channel permissions from backup (OPTIMIZED)"""
        try:
            # Use cached backup
            backup = self._get_cached_backup('channels', guild.id)
            if not backup:
                return
            
            # Create permission map
            backup_perms = {
                ch_data['id']: ch_data.get('permissions', {})
                for ch_data in backup['channels']
            }
            
            # Process channels - only check those with expected permissions
            for channel in guild.channels:
                if channel.id not in backup_perms:
                    continue
                
                expected_perms = backup_perms[channel.id]
                if not expected_perms:  # Skip if no permissions expected
                    continue
                
                # Build current permissions map
                current_perms = {
                    str(target.id): {
                        'type': 'role' if isinstance(target, discord.Role) else 'member',
                        'allow': overwrite.pair()[0].value,
                        'deny': overwrite.pair()[1].value
                    }
                    for target, overwrite in channel.overwrites.items()
                }
                
                # Quick check - if counts match and all keys present, likely unchanged
                if len(current_perms) == len(expected_perms):
                    if all(tid in expected_perms for tid in current_perms):
                        continue  # Skip detailed check
                
                # Check for unauthorized additions
                for target_id in current_perms:
                    if target_id not in expected_perms:
                        if not self._is_on_cooldown(guild.id, f"perm_{channel.id}_{target_id}"):
                            await self._remove_unauthorized_permission(guild, channel, target_id)
                            self._set_cooldown(guild.id, f"perm_{channel.id}_{target_id}")
                
                # Check for missing permissions
                for target_id, perm_data in expected_perms.items():
                    if target_id not in current_perms:
                        if not self._is_on_cooldown(guild.id, f"perm_{channel.id}_{target_id}"):
                            await self._restore_missing_permission(guild, channel, target_id, perm_data)
                            self._set_cooldown(guild.id, f"perm_{channel.id}_{target_id}")
        
        except Exception as e:
            print(f"Error checking channel permissions: {e}")
    
    async def _remove_unauthorized_permission(self, guild: discord.Guild, channel: discord.abc.GuildChannel, target_id: str):
        """Remove permission that wasn't in backup (RATE LIMITED)"""
        try:
            target_id_int = int(target_id)
            target = guild.get_role(target_id_int) or guild.get_member(target_id_int)
            
            if target:
                # Check if authorized (with rate limit)
                await self._per_guild_limiter.acquire(guild.id)
                self._stats['api_calls'] += 1
                
                async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.overwrite_create):
                    if hasattr(entry, 'extra') and hasattr(entry.extra, 'id'):
                        if entry.extra.id == channel.id:
                            if await self.whitelist.is_whitelisted(guild.id, entry.user.id):
                                return
                
                # Remove with rate limiting
                await self._per_guild_limiter.acquire(guild.id)
                await self._global_limiter.acquire()
                
                await RetryHandler.execute_with_retry(
                    channel.set_permissions(target, overwrite=None, reason="SecureX: Removing unauthorized permission")
                )
                
                print(f"🔧 Removed unauthorized permission for {target} in {channel.name}")
                self._stats['fixes'] += 1
                self._stats['api_calls'] += 1
                
        except Exception as e:
            print(f"Error removing unauthorized permission: {e}")
    
    async def _restore_missing_permission(self, guild: discord.Guild, channel: discord.abc.GuildChannel, target_id: str, perm_data: dict):
        """Restore permission that was removed (RATE LIMITED)"""
        try:
            target_id_int = int(target_id)
            target = guild.get_role(target_id_int) if perm_data['type'] == 'role' else guild.get_member(target_id_int)
            
            if target:
                # Acquire rate limits
                await self._per_guild_limiter.acquire(guild.id)
                await self._global_limiter.acquire()
                
                # Restore permission
                overwrite = discord.PermissionOverwrite.from_pair(
                    discord.Permissions(perm_data['allow']),
                    discord.Permissions(perm_data['deny'])
                )
                
                await RetryHandler.execute_with_retry(
                    channel.set_permissions(target, overwrite=overwrite, reason="SecureX: Restoring removed permission")
                )
                
                print(f"🔧 Restored permission for {target} in {channel.name}")
                self._stats['fixes'] += 1
                self._stats['api_calls'] += 1
            else:
                print(f"⚠️ Cannot restore permission - target {target_id} not found")
                
        except Exception as e:
            print(f"Error restoring missing permission: {e}")
    
    async def restore_category_children(self, guild: discord.Guild, category_id: int):
        """
        When category is deleted and restored, pull back all its children.
        Called from ChannelHandler when category is restored.
        """
        try:
            backup_file = self.backup_dir / f"channels_{guild.id}.json"
            if not backup_file.exists():
                return
            
            with open(backup_file, 'r') as f:
                backup = json.load(f)
            
            # Find the restored category
            category = guild.get_channel(category_id)
            if not category or not isinstance(category, discord.CategoryChannel):
                return
            
            # Find all channels that belonged to this category
            child_channels = [
                ch_data for ch_data in backup['channels']
                if ch_data.get('category_id') == category_id
            ]
            
            print(f"🔧 Restoring {len(child_channels)} children for category {category.name}")
            
            for ch_data in child_channels:
                # Check if channel exists in server
                existing_channel = guild.get_channel(ch_data['id'])
                
                if existing_channel:
                    # Channel exists - pull it back into category
                    if existing_channel.category_id != category_id:
                        await existing_channel.edit(
                            category=category,
                            position=ch_data['position'],
                            reason="SecureX: Restoring to original category"
                        )
                        print(f"  ↳ Moved {existing_channel.name} back to {category.name}")
                else:
                    # Channel doesn't exist - recreate it
                    await self._recreate_channel_in_category(guild, category, ch_data)
                
                await asyncio.sleep(1)  # Rate limit
        
        except Exception as e:
            print(f"Error restoring category children: {e}")
    
    async def _recreate_channel_in_category(self, guild: discord.Guild, category: discord.CategoryChannel, ch_data: dict):
        """Recreate a channel and add it to category"""
        try:
            channel_type = ch_data['type']
            new_channel = None
            
            if 'text' in channel_type.lower():
                text_props = ch_data.get('text_properties', {})
                new_channel = await guild.create_text_channel(
                    name=ch_data['name'],
                    category=category,
                    position=ch_data['position'],
                    topic=text_props.get('topic'),
                    slowmode_delay=text_props.get('slowmode_delay', 0),
                    nsfw=text_props.get('nsfw', False),
                    reason="SecureX: Recreating category child channel"
                )
            elif 'voice' in channel_type.lower():
                voice_props = ch_data.get('voice_properties', {})
                new_channel = await guild.create_voice_channel(
                    name=ch_data['name'],
                    category=category,
                    position=ch_data['position'],
                    bitrate=voice_props.get('bitrate', 64000),
                    user_limit=voice_props.get('user_limit', 0),
                    reason="SecureX: Recreating category child channel"
                )
            elif 'stage' in channel_type.lower():
                stage_props = ch_data.get('stage_properties', {})
                new_channel = await guild.create_stage_channel(
                    name=ch_data['name'],
                    category=category,
                    position=ch_data['position'],
                    bitrate=stage_props.get('bitrate', 64000),
                    reason="SecureX: Recreating category child channel"
                )
            
            if new_channel:
                print(f"  ↳ Recreated {new_channel.name} in {category.name}")
                
                # Restore permissions
                if ch_data.get('permissions'):
                    for target_id, perm_data in ch_data['permissions'].items():
                        try:
                            target_id_int = int(target_id)
                            target = guild.get_role(target_id_int) if perm_data['type'] == 'role' else guild.get_member(target_id_int)
                            
                            if target:
                                overwrite = discord.PermissionOverwrite.from_pair(
                                    discord.Permissions(perm_data['allow']),
                                    discord.Permissions(perm_data['deny'])
                                )
                                await new_channel.set_permissions(target, overwrite=overwrite)
                                await asyncio.sleep(0.5)
                        except Exception as e:
                            print(f"Error restoring permission: {e}")
        
        except Exception as e:
            print(f"Error recreating channel in category: {e}")
    
    def _is_on_cooldown(self, guild_id: int, item_key: str) -> bool:
        """Check if item is on cooldown"""
        key = f"{guild_id}_{item_key}"
        if key in self._last_position_fix:
            elapsed = (datetime.utcnow() - self._last_position_fix[key]).total_seconds()
            return elapsed < self._fix_cooldown
        return False
    
    def _set_cooldown(self, guild_id: int, item_key: str):
        """Set cooldown for item"""
        key = f"{guild_id}_{item_key}"
        self._last_position_fix[key] = datetime.utcnow()
