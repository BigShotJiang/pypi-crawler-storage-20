"""
Complete backup and restoration manager.
Extracted from cogs/antinuke.py backup logic.
"""
import discord
import json
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, List
from ..models import BackupInfo, RestoreResult


class BackupManager:
    """Manages server backups and restoration"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_dir = sdk.backup_dir
        self.backup_dir.mkdir(parents=True, exist_ok=True)
    
    async def create_backup(self, guild_id: int) -> BackupInfo:
        """Create complete backup for a guild"""
        try:
            guild = self.bot.get_guild(guild_id)
            if not guild:
                return BackupInfo(
                    guild_id=guild_id,
                    timestamp=datetime.utcnow(),
                    channel_count=0,
                    role_count=0,
                    backup_path="",
                    success=False
                )
            
            # Backup channels
            channel_count = await self._backup_channels(guild)
            
            # Backup roles
            role_count = await self._backup_roles(guild)
            
            backup_info = BackupInfo(
                guild_id=guild_id,
                timestamp=datetime.utcnow(),
                channel_count=channel_count,
                role_count=role_count,
                backup_path=str(self.backup_dir),
                success=True
            )
            
            # Trigger callback
            await self.sdk._trigger_callbacks('backup_completed', backup_info)
            
            return backup_info
            
        except Exception as e:
            print(f"Error creating backup: {e}")
            return BackupInfo(
                guild_id=guild_id,
                timestamp=datetime.utcnow(),
                channel_count=0,
                role_count=0,
                backup_path="",
                success=False
            )
    
    async def _backup_channels(self, guild: discord.Guild) -> int:
        """Backup all channels"""
        backup_data = {
            "guild_id": guild.id,
            "timestamp": datetime.utcnow().isoformat(),
            "channels": []
        }
        
        for channel in guild.channels:
            channel_data = {
                "id": channel.id,
                "name": channel.name,
                "type": str(channel.type),
                "position": channel.position,
                "category_id": channel.category.id if channel.category else None,
                "permissions": {}
            }
            
            # Store permissions
            for target, overwrite in channel.overwrites.items():
                target_id = str(target.id)
                channel_data["permissions"][target_id] = {
                    "type": "role" if isinstance(target, discord.Role) else "member",
                    "allow": overwrite.pair()[0].value,
                    "deny": overwrite.pair()[1].value
                }
            
            # Type-specific properties
            if isinstance(channel, discord.TextChannel):
                channel_data["text_properties"] = {
                    "topic": channel.topic,
                    "slowmode_delay": channel.slowmode_delay,
                    "nsfw": channel.nsfw
                }
            elif isinstance(channel, discord.VoiceChannel):
                channel_data["voice_properties"] = {
                    "bitrate": channel.bitrate,
                    "user_limit": channel.user_limit
                }
            elif isinstance(channel, discord.StageChannel):
                channel_data["stage_properties"] = {
                    "bitrate": channel.bitrate
                }
            
            backup_data["channels"].append(channel_data)
        
        # Save to file
        backup_file = self.backup_dir / f"channels_{guild.id}.json"
        with open(backup_file, 'w') as f:
            json.dump(backup_data, f, indent=2)
        
        return len(backup_data["channels"])
    
    async def _backup_roles(self, guild: discord.Guild) -> int:
        """Backup all roles"""
        backup_data = {
            "guild_id": guild.id,
            "timestamp": datetime.utcnow().isoformat(),
            "roles": []
        }
        
        for role in guild.roles:
            if role.is_default():  # Skip @everyone
                continue
            
            role_data = {
                "id": role.id,
                "name": role.name,
                "permissions": role.permissions.value,
                "color": role.color.value,
                "hoist": role.hoist,
                "mentionable": role.mentionable,
                "position": role.position
            }
            
            backup_data["roles"].append(role_data)
        
        # Save to file
        backup_file = self.backup_dir / f"roles_{guild.id}.json"
        with open(backup_file, 'w') as f:
            json.dump(backup_data, f, indent=2)
        
        return len(backup_data["roles"])
    
    async def restore_channel(self, guild: discord.Guild, channel: discord.abc.GuildChannel) -> bool:
        """Restore a deleted channel from backup"""
        try:
            backup_file = self.backup_dir / f"channels_{guild.id}.json"
            if not backup_file.exists():
                return False
            
            with open(backup_file, 'r') as f:
                backup = json.load(f)
            
            # Find channel in backup
            ch_data = None
            for data in backup["channels"]:
                if data["id"] == channel.id:
                    ch_data = data
                    break
            
            if not ch_data:
                return False
            
            # Get category
            category = None
            if ch_data.get("category_id"):
                category = guild.get_channel(ch_data["category_id"])
            
            # Recreate channel based on type
            new_channel = None
            channel_type = ch_data["type"]
            
            if "text" in channel_type.lower():
                text_props = ch_data.get("text_properties", {})
                new_channel = await guild.create_text_channel(
                    name=ch_data["name"],
                    category=category,
                    position=ch_data["position"],
                    topic=text_props.get("topic"),
                    slowmode_delay=text_props.get("slowmode_delay", 0),
                    nsfw=text_props.get("nsfw", False),
                    reason="SecureX: Restoring deleted channel"
                )
            elif "voice" in channel_type.lower():
                voice_props = ch_data.get("voice_properties", {})
                new_channel = await guild.create_voice_channel(
                    name=ch_data["name"],
                    category=category,
                    position=ch_data["position"],
                    bitrate=voice_props.get("bitrate", 64000),
                    user_limit=voice_props.get("user_limit", 0),
                    reason="SecureX: Restoring deleted channel"
                )
            elif "category" in channel_type.lower():
                new_channel = await guild.create_category(
                    name=ch_data["name"],
                    position=ch_data["position"],
                    reason="SecureX: Restoring deleted category"
                )
            elif "stage" in channel_type.lower():
                stage_props = ch_data.get("stage_properties", {})
                new_channel = await guild.create_stage_channel(
                    name=ch_data["name"],
                    category=category,
                    position=ch_data["position"],
                    bitrate=stage_props.get("bitrate", 64000),
                    reason="SecureX: Restoring deleted channel"
                )
            
            if not new_channel:
                return False
            
            # Restore permissions
            if ch_data.get("permissions"):
                for target_id, perm_data in ch_data["permissions"].items():
                    try:
                        target_id = int(target_id)
                        target = guild.get_role(target_id) if perm_data["type"] == "role" else guild.get_member(target_id)
                        
                        if target:
                            overwrite = discord.PermissionOverwrite.from_pair(
                                discord.Permissions(perm_data["allow"]),
                                discord.Permissions(perm_data["deny"])
                            )
                            await new_channel.set_permissions(target, overwrite=overwrite)
                    except Exception as e:
                        print(f"Error restoring permission: {e}")
            
            return True
            
        except Exception as e:
            print(f"Error restoring channel: {e}")
            return False
    
    async def restore_channel_permissions(self, guild: discord.Guild, channel_id: int) -> bool:
        """Restore channel permissions from backup"""
        try:
            backup_file = self.backup_dir / f"channels_{guild.id}.json"
            if not backup_file.exists():
                return False
            
            with open(backup_file, 'r') as f:
                backup = json.load(f)
            
            # Find channel
            ch_data = None
            for data in backup["channels"]:
                if data["id"] == channel_id:
                    ch_data = data
                    break
            
            if not ch_data:
                return False
            
            channel = guild.get_channel(channel_id)
            if not channel:
                return False
            
            # Restore permissions
            if ch_data.get("permissions"):
                for target_id, perm_data in ch_data["permissions"].items():
                    try:
                        target_id = int(target_id)
                        target = guild.get_role(target_id) if perm_data["type"] == "role" else guild.get_member(target_id)
                        
                        if target:
                            overwrite = discord.PermissionOverwrite.from_pair(
                                discord.Permissions(perm_data["allow"]),
                                discord.Permissions(perm_data["deny"])
                            )
                            await channel.set_permissions(target, overwrite=overwrite)
                    except Exception:
                        pass
            
            return True
            
        except Exception as e:
            print(f"Error restoring channel permissions: {e}")
            return False
    
    async def restore_role(self, guild: discord.Guild, role_id: int) -> bool:
        """Restore a deleted role from backup"""
        try:
            backup_file = self.backup_dir / f"roles_{guild.id}.json"
            if not backup_file.exists():
                return False
            
            with open(backup_file, 'r') as f:
                backup = json.load(f)
            
            # Find role in backup
            for role_data in backup["roles"]:
                if role_data["id"] == role_id:
                    # Recreate role
                    new_role = await guild.create_role(
                        name=role_data["name"],
                        permissions=discord.Permissions(role_data["permissions"]),
                        color=discord.Color(role_data["color"]),
                        hoist=role_data["hoist"],
                        mentionable=role_data["mentionable"],
                        reason="SecureX: Restoring deleted role"
                    )
                    
                    # Set position
                    await new_role.edit(position=role_data["position"])
                    
                    return True
            
            return False
            
        except Exception as e:
            print(f"Error restoring role: {e}")
            return False
    
    async def restore_role_permissions(self, guild: discord.Guild, role_id: int) -> bool:
        """Restore role permissions from backup"""
        try:
            backup_file = self.backup_dir / f"roles_{guild.id}.json"
            if not backup_file.exists():
                return False
            
            with open(backup_file, 'r') as f:
                backup = json.load(f)
            
            # Find role
            for role_data in backup["roles"]:
                if role_data["id"] == role_id:
                    role = guild.get_role(role_id)
                    if not role:
                        return False
                    
                    # Restore permissions and position
                    await role.edit(
                        permissions=discord.Permissions(role_data["permissions"]),
                        position=role_data["position"],
                        reason="SecureX: Restoring role permissions"
                    )
                    
                    return True
            
            return False
            
        except Exception as e:
            print(f"Error restoring role permissions: {e}")
            return False
    
    def start_auto_backup(self, interval_minutes: int = 30):
        """Start automatic backup task"""
        async def auto_backup_task():
            await self.bot.wait_until_ready()
            while not self.bot.is_closed():
                try:
                    # Backup all guilds
                    for guild in self.bot.guilds:
                        await self.create_backup(guild.id)
                    
                    # Wait for next backup
                    await asyncio.sleep(interval_minutes * 60)
                except Exception as e:
                    print(f"Error in auto backup: {e}")
                    await asyncio.sleep(60)  # Wait 1 min on error
        
        # Start background task
        self.bot.loop.create_task(auto_backup_task())
