
import matplotlib.pyplot as plt
import numpy as np

def draw_benzene():
    ang = np.linspace(0,2*np.pi,7)
    plt.plot(np.cos(ang), np.sin(ang),'k')
    plt.axis('equal'); plt.axis('off')
    plt.show()

def draw_reaction():
    plt.text(0.1,0.5,"A → B",fontsize=20)
    plt.axis('off')
    plt.show()
