
import matplotlib.pyplot as plt
import numpy as np

def plot_equation(eq):
    x = np.linspace(-10,10,400)
    y = eval(eq)
    plt.plot(x,y)
    plt.axhline(0); plt.axvline(0)
    plt.show()

def draw_triangle():
    plt.plot([0,1,0.5,0],[0,0,1,0])
    plt.axis('off')
    plt.show()
