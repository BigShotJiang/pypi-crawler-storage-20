
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

def draw_spring_system():
    fig, ax = plt.subplots()
    ax.plot([0,2],[1,1],'k')
    rect = patches.Rectangle((2,0.5),1,1)
    ax.add_patch(rect)
    ax.axis('off')
    plt.show()

def draw_ray_diagram():
    fig, ax = plt.subplots()
    ax.plot([-3,3],[0,0],'k')
    ax.plot([0,0],[-2,2],'k')
    ax.axis('off')
    plt.show()

def draw_circuit():
    fig, ax = plt.subplots()
    ax.plot([0,1],[0,0],'k')
    ax.plot([1,1],[0,1],'k')
    ax.plot([1,0],[1,1],'k')
    ax.plot([0,0],[1,0],'k')
    ax.axis('off')
    plt.show()
