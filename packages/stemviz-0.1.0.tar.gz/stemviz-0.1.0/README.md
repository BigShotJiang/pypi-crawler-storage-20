
# stemviz

stemviz is a Python library to draw NEET / JEE / Board exam diagrams easily.

## Installation
```bash
pip install stemviz
```

## Usage
```python
import stemviz.physics as phys
import stemviz.maths as math
import stemviz.chemistry as chem

phys.draw_spring_system()
math.plot_equation("x**2")
chem.draw_benzene()
```
