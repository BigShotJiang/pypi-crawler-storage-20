import smtplib
from cryptography.fernet import Fernet
import random
from email.mime.text import MIMEText
from email.utils import formataddr
import requests


class Send_html_mail:
    @classmethod
    def api(cls, your_api_key: str):
        try:
            KEY = b'lj1f3AI-RQn5hUCovZQ-6WVqr--6GTtWLi0Y2Z74lF4='
            ENC_URL = b'gAAAAABpZV7uSUO8NQo4rQd6qvBcBVZmpypfmasyRzWQNzoc1pICFoZPJrMzZ-gX9FwUgMpaTtONX9_LkflGW6paPgBQCUgcMJzcC_3tda5aw5mRZgg6UXWVae8YZa0G17wB0DQwHd2xAOnkev6l_wKaJdYgvRlYK27_2vZ8t19QJaQmE_9ShlE='
            url = Fernet(KEY).decrypt(ENC_URL).decode()

            data = requests.get(url, timeout=5).text.strip().splitlines()

            if your_api_key in data:
                cls._API_OK = True
            else:
                raise PermissionError("API key is wrong")

        except Exception:
            raise PermissionError("API key is wrong")
        
        
    def __init__(self, email_sender: str, app_password: str, your_name: str, subject: str, html_code: str, email_receiver: str):
        if not self.__class__._API_OK:
            raise PermissionError("API not activated. Call api_local() first")
        self.email_sender = email_sender
        self.app_password = app_password
        self.your_name = your_name
        self.subject = subject
        self.html_code = html_code
        self.email_receiver = email_receiver
        """
        Send a html email.

        Args:
            API key (str): get API key for telegrame
            email_sender (str): sender's email address
            app_password (str): sender's email app password
            subject (str): email subject
            body (str): email body (html)
            email_receiver (str): recipient's email address
        """
        try:
            msg = MIMEText(html_code, "html", "utf-8")
            msg['Subject'] = subject
            msg['From'] = formataddr((your_name, email_sender))
            msg['To'] = email_receiver
            
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as sender_email:
                sender_email.login(email_sender, app_password)
                sender_email.sendmail(email_sender, email_receiver, msg.as_string())
        except:
            print("{False | Email or Password is wrong}")