import requests
from typing import Dict, Any, Optional

class USDAFASClient:
    """
    Client for the USDA FAS Open Data API.
    """
    BASE_URL = "https://api.fas.usda.gov"

    def __init__(self, api_key: str):
        """
        Initialize the client with an API key.

        Args:
            api_key (str): The API key for authentication.
        """
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({
            "X-Api-Key": self.api_key,
            "Accept": "application/json"
        })

    def _make_request(self, method: str, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Any:
        """
        Internal method to make requests to the API.

        Args:
            method (str): HTTP method (GET, POST, etc.)
            endpoint (str): API endpoint (e.g., /api/esr/regions)
            params (Optional[Dict[str, Any]]): Query parameters.

        Returns:
            Any: The JSON response from the API.

        Raises:
            requests.HTTPError: If the request fails.
        """
        url = f"{self.BASE_URL}{endpoint}"
        response = self.session.request(method, url, params=params)
        response.raise_for_status()
        return response.json()
