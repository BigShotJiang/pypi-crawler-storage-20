# USDA FAS SDK

A Python SDK for the USDA FAS Open Data API.
This SDK provides access to Export Sales Reporting (ESR), Global Agricultural Trade System (GATS), and Production, Supply and Distribution (PSD) data.

## Features

- **Authentication**: Easy API Key integration.
- **Easy Query**: `USDAFASEasyClient` automatically normalizes data, replacing opaque codes (like Country Code `2010`) with readable names (e.g., `MEXICO`).
- **Full Coverage**: Supports all endpoints defined in the USDA FAS Swagger specification.

## Installation

```bash
pip install usda-fas-sdk
```

## Usage

### Basic Initialization

```python
from usda_fas import USDAFASClient

client = USDAFASClient(api_key="YOUR_API_KEY")
```

### Normalized Data (Easy Query)

The `USDAFASEasyClient` is the recommended way to interact with the API if you want human-readable results.

```python
from usda_fas import USDAFASEasyClient
import json

# Initialize with your API Key
client = USDAFASEasyClient(api_key="YOUR_API_KEY")

# Fetch normalized export data
# This automatically fetches reference data and joins it with the result
data = client.get_esr_exports_normalized(commodity_code=101, market_year=2024)

if data:
    # Print the first record
    print(json.dumps(data[0], indent=2))
```

**Output:**
```json
{
  "commodityCode": 101,
  "countryCode": 2010,
  "weeklyExports": 32338,
  "accumulatedExports": 32338,
  "outstandingSales": 178501,
  "grossNewSales": 36240,
  "currentMYNetSales": 754,
  "unitId": 1,
  "weekEndingDate": "2023-06-01T00:00:00",
  "countryName": "MEXICO  ",
  "commodityName": "Wheat - HRW"
}
```

## Requirements

- Python 3.6+
- `requests`

## License

MIT
