"""Data models for PromptCanvas SDK."""

from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime


@dataclass
class Prompt:
    """Prompt data returned from the API."""
    
    slug: str
    """Unique slug identifier."""
    
    name: str
    """Human-readable name."""
    
    content: str
    """The prompt content/template."""
    
    version: int
    """Version number."""
    
    stage: str = "production"
    """Current stage (always 'production' for SDK fetches)."""
    
    variables: List[str] = field(default_factory=list)
    """Variable placeholders in the template."""
    
    category: str = ""
    """Category for organization."""
    
    tags: List[str] = field(default_factory=list)
    """Tags for filtering."""
    
    updated_at: str = ""
    """Last update timestamp."""
    
    etag: str = ""
    """ETag for caching."""

    @classmethod
    def from_dict(cls, data: dict) -> "Prompt":
        """Create Prompt from API response dictionary."""
        return cls(
            slug=data.get("slug", ""),
            name=data.get("name", ""),
            content=data.get("content", ""),
            version=data.get("version", 0),
            stage=data.get("stage", "production"),
            variables=data.get("variables", []),
            category=data.get("category", ""),
            tags=data.get("tags", []),
            updated_at=data.get("updated_at", data.get("updatedAt", "")),
            etag=data.get("etag", ""),
        )


@dataclass
class PromptMeta:
    """Prompt metadata for listing."""
    
    slug: str
    name: str
    category: str
    has_production: bool

    @classmethod
    def from_dict(cls, data: dict) -> "PromptMeta":
        return cls(
            slug=data.get("slug", ""),
            name=data.get("name", ""),
            category=data.get("category", ""),
            has_production=data.get("has_production", data.get("hasProduction", False)),
        )


@dataclass
class SlugSuggestion:
    """Suggestion result for autocomplete."""
    
    slug: str
    name: str
    has_production: bool

    @classmethod
    def from_dict(cls, data: dict) -> "SlugSuggestion":
        return cls(
            slug=data.get("slug", ""),
            name=data.get("name", ""),
            has_production=data.get("has_production", data.get("hasProduction", False)),
        )


@dataclass
class CacheStats:
    """Cache statistics."""
    
    hits: int
    """Number of cache hits."""
    
    misses: int
    """Number of cache misses."""
    
    hit_rate: float
    """Cache hit rate (0-1)."""
    
    size: int
    """Current number of cached entries."""
    
    max_size: int
    """Maximum cache size."""


@dataclass
class BatchResult:
    """Result of batch fetch operation."""
    
    prompts: List[Prompt]
    """Successfully fetched prompts."""
    
    errors: List[dict]
    """List of {slug, error} for failed fetches."""


@dataclass
class ListResult:
    """Result of list operation with pagination."""
    
    prompts: List[PromptMeta]
    """List of prompt metadata."""
    
    total: int
    """Total count of prompts."""


@dataclass
class CachedPrompt:
    """Internal cache entry."""
    
    prompt: Prompt
    fetched_at: float
    expires_at: float
