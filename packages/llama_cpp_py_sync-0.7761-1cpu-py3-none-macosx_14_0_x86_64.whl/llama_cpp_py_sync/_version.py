"""Version information for llama-cpp-py-sync."""

__version__ = "0.7761"
__llama_cpp_commit__ = "a89002f07"
__llama_cpp_tag__ = "b7761"
