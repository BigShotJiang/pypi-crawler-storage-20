"""CLI entry point for Agent XS."""

import click

from agent_xs import __version__
from agent_xs.commands.init_project import init_project
from agent_xs.commands.serve import serve
from agent_xs.commands.auto_write import auto_write as auto
from agent_xs.commands.status import status
from agent_xs.commands.info import info


@click.group()
@click.version_option(version=__version__, prog_name="xs")
def main():
    """XS - Novel writing CLI tool with Claude Code plugin."""
    pass


main.add_command(init_project, name="init")
main.add_command(serve)
main.add_command(auto)
main.add_command(status)
main.add_command(info)


if __name__ == "__main__":
    main()
