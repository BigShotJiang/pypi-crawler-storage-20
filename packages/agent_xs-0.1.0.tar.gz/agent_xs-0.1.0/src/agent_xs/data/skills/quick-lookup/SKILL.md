---
name: 快速查阅知识库
description: This skill should be used when the user asks to "查看角色", "列出物品", "搜索场景", "查找事件", "show characters", "list items", "search locations", "查看系统数据", "列出自定义分类", or needs to quickly browse or search the knowledge base (标准分类 + 自定义分类) with concise or detailed views.
version: 0.2.0
---

# 快速查阅知识库

## 概述

提供快速查阅和搜索小说知识库的工具，支持列出文件名、查看元数据、显示完整信息和关键词搜索。支持标准分类（角色/物品/场景/事件）和自定义分类。通过 Python 脚本实现高效的信息检索。

## 使用场景

- 快速浏览所有角色/物品/场景/事件列表
- 查看指定条目的元数据或完整信息
- 搜索包含特定关键词的信息
- 检查知识库的整体状态
- **查看自定义分类**（如系统数据、科技设定等）

## 核心功能

### 0. 查看所有分类（新增）

快速查看当前项目有哪些分类（标准 + 自定义）。

**使用方法**：
```bash
# 列出所有分类
uv run ./.claude/skills/quick-lookup/scripts/list_info.py --all
```

**输出示例**：
```
知识库分类概览：

标准分类：
- 角色: 5 个条目
- 物品: 3 个条目
- 场景: 4 个条目
- 事件: 2 个条目

自定义分类：
- 系统数据: 3 个条目 (目录)
- 功法体系: 1 个条目 (单文件)
```

### 1. 列出所有文件名（默认）

快速查看某个类型下有哪些条目。

**使用方法**：
```bash
# 使用 uv run 执行脚本
uv run ./.claude/skills/quick-lookup/scripts/list_info.py [类型]

# 标准分类示例
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 物品

# 自定义分类示例
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 系统数据
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 功法体系
```

**输出示例**：
```
找到 5 个角色:

- 张三
- 李四
- 王五
- 赵六
- 孙七
```

**支持的类型**：
- **标准分类**：`角色`、`物品`、`场景`、`事件`
- **自定义分类**：根据 `现有信息/信息结构.md` 中定义的分类名称

### 2. 查看指定条目的元数据

显示指定条目的 YAML frontmatter（不包含 Markdown 正文）。

**使用方法**：
```bash
# 使用 uv run 执行脚本，使用 --brief 参数
uv run ./.claude/skills/quick-lookup/scripts/list_info.py [类型] [名称...] --brief

# 标准分类示例
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色 张三 --brief
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色 张三 李四 --brief

# 自定义分类示例
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 系统数据 技能树 --brief
```

**输出示例**：
```
=== 角色: 张三 ===
name: 张三
status: alive
role: 主角
first_appearance: 1
last_updated: 5
age: 25
gender: 男
cultivation_level: 筑基期
faction: 云霄宗

=== 角色: 李四 ===
name: 李四
status: alive
role: 配角
...
```

### 3. 查看指定条目的完整信息

显示指定条目的完整内容（包含 YAML 元数据和 Markdown 正文）。

**使用方法**：
```bash
# 使用 uv run 执行脚本，使用 --detail 参数
uv run ./.claude/skills/quick-lookup/scripts/list_info.py [类型] [名称...] --detail

# 标准分类示例
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色 张三 --detail

# 自定义分类示例
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 系统数据 属性面板 --detail
```

**输出示例**：
```
================================================================================
角色: 张三
================================================================================
---
name: 张三
status: alive
role: 主角
...
---

## 外貌特征
身高一米八，体型修长...

## 性格特点
性格沉稳，做事谨慎...

[完整内容]
```

**重要**：`--brief` 和 `--detail` 参数只能在指定具体名称时使用。如果没有指定名称，会报错。

### 4. 搜索知识库

在整个知识库中搜索包含指定关键词的所有条目（包括自定义分类）。

**使用方法**：
```bash
# 使用 uv run 执行脚本
uv run ./.claude/skills/quick-lookup/scripts/search_info.py [关键词]

# 示例：搜索所有包含"玄天剑"的信息
uv run ./.claude/skills/quick-lookup/scripts/search_info.py 玄天剑

# 示例：搜索所有包含"技能"的信息（会搜索自定义分类）
uv run ./.claude/skills/quick-lookup/scripts/search_info.py 技能

# 忽略大小写搜索
uv run ./.claude/skills/quick-lookup/scripts/search_info.py -i keyword
```

**输出示例**：
```
搜索关键词: 技能
找到 4 个匹配结果：

[角色] 张三 (现有信息/角色/张三.md)
  第5章: 获得新技能「剑气纵横」

[系统数据] 技能树 (现有信息/系统数据/技能树.md)
  ## 主动技能
  - 剑气纵横 Lv.1

[事件] 宗门大比 (现有信息/事件/宗门大比.md)
  张三展示新技能，震惊全场...
```

## 技术实现

### 脚本说明

所有脚本位于 `./.claude/skills/quick-lookup/scripts/` 目录：

1. **list_info.py** - 列出条目或查看详情（主脚本）
   - 参数：`<类型> [名称...]`
   - 选项：
     - `--brief` - 显示元数据
     - `--detail` - 显示完整信息
     - `--all` - 显示所有分类概览
   - 默认：列出所有文件名
   - 支持同时查看多个条目
   - **自动识别自定义分类**：读取 `现有信息/信息结构.md` 获取分类列表

2. **search_info.py** - 搜索知识库
   - 参数：`<关键词>`
   - 选项：`-i` - 忽略大小写
   - 功能：在所有文件中搜索关键词，显示匹配的上下文
   - **搜索范围包括自定义分类**

### 运行要求

**重要**: 所有脚本必须使用 `uv run` 命令执行，以确保正确的 Python 环境：

```bash
# 正确方式
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色

# 错误方式（不要使用）
python ./.claude/skills/quick-lookup/scripts/list_info.py 角色
```

### 目录结构

```
skills/quick-lookup/
├── SKILL.md                    # 本文件
├── README.md                   # 快速开始指南
├── EXAMPLES.md                 # 详细使用示例
└── scripts/
    ├── list_info.py            # 列出/查看信息（主脚本）
    └── search_info.py          # 搜索知识库
```

## 自定义分类支持

脚本会自动读取 `现有信息/信息结构.md` 来获取自定义分类信息：

1. **目录结构分类**：如 `系统数据/`，包含多个 `.md` 文件
2. **单文件结构分类**：如 `功法体系.md`，单个文件

使用时，直接用分类名作为类型参数即可：

```bash
# 目录结构分类
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 系统数据
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 系统数据 技能树 --detail

# 单文件结构分类
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 功法体系 --detail
```

## 最佳实践

1. **编写草稿前**：先用 `--all` 查看所有分类概览，了解知识库结构
2. **需要快速检查**：使用 `--brief` 查看元数据，不用读取完整内容
3. **定稿审阅时**：使用搜索功能检查前后一致性
4. **深入了解时**：使用 `--detail` 查看完整档案
5. **检查自定义分类**：使用分类名直接查看，确保信息同步

## 使用限制

- `--brief` 和 `--detail` 参数只能在指定具体名称时使用
- 不能同时使用 `--brief` 和 `--detail`
- 脚本假设当前工作目录包含 `现有信息/` 文件夹
- 搜索功能默认区分大小写，使用 `-i` 忽略大小写
- 自定义分类需要先在 `信息结构.md` 中定义才能被识别

## 相关资源

- **信息结构定义**: `现有信息/信息结构.md`
- **知识库管理指南**: `skills/novel-writing/references/knowledge-base-guide.md`
- **角色档案模板**: `skills/novel-writing/templates/character.md`
- **物品档案模板**: `skills/novel-writing/templates/item.md`
- **场景档案模板**: `skills/novel-writing/templates/scene.md`
- **事件档案模板**: `skills/novel-writing/templates/event.md`
