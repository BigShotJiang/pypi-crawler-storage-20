# 快速查阅知识库 Skill

快速查阅和搜索小说知识库的工具集。

## 快速开始

### 1. 列出所有角色文件名（默认）

```bash
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色
```

### 2. 查看指定角色的元数据

```bash
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色 张三 --brief
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色 张三 李四 --brief
```

### 3. 查看指定角色的完整信息

```bash
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色 张三 --detail
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色 张三 李四 --detail
```

### 4. 搜索关键词

```bash
uv run ./.claude/skills/quick-lookup/scripts/search_info.py 玄天剑
```

## 脚本说明

### list_info.py

列出知识库信息的主脚本。

**参数**:
- `<类型>`: 角色/物品/场景/事件
- `[名称...]`: (可选) 要查看的条目名称
- `--brief`: 显示 YAML 元数据（仅在指定名称时可用）
- `--detail`: 显示完整信息（仅在指定名称时可用）

**用法**:
```bash
# 默认：列出所有文件名
uv run list_info.py 角色

# 检查指定文件是否存在
uv run list_info.py 角色 张三 李四

# 显示元数据
uv run list_info.py 角色 张三 --brief

# 显示完整信息
uv run list_info.py 角色 张三 --detail
```

### search_info.py

在整个知识库中搜索关键词。

**参数**:
- `<关键词>`: 要搜索的关键词

**用法**:
```bash
uv run search_info.py 玄天剑
uv run search_info.py 云霄宗
```

## 重要提示

1. **使用 uv run**: 所有脚本必须使用 `uv run` 命令执行
2. **工作目录**: 脚本假设当前工作目录包含 `现有信息/` 文件夹
3. **参数限制**: `--brief` 和 `--detail` 只能在指定具体名称时使用
4. **文件编码**: 所有文件使用 UTF-8 编码

## 使用场景

### 编写草稿前

快速浏览所有角色：

```bash
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色
```

查看重点角色状态：

```bash
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色 张三 李四 --brief
```

### 定稿审阅时

搜索相关内容，检查一致性：

```bash
uv run ./.claude/skills/quick-lookup/scripts/search_info.py 云霄宗
```

### 需要详细信息时

查看完整档案：

```bash
uv run ./.claude/skills/quick-lookup/scripts/list_info.py 角色 张三 --detail
```

## 目录结构

```
skills/quick-lookup/
├── SKILL.md                    # Skill 主文档
├── README.md                   # 本文件
├── EXAMPLES.md                 # 详细使用示例
└── scripts/
    ├── list_info.py            # 列出/查看信息（主脚本）
    └── search_info.py          # 搜索知识库
```

## 更多信息

- 详细使用示例：`EXAMPLES.md`
- 完整功能说明：`SKILL.md`
