"""Web application for viewing novel content."""

from agent_xs.web.app import create_app

__all__ = ["create_app"]
