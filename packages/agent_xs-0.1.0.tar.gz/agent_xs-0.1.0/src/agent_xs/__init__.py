"""Agent XS - CLI tool for novel writing with Claude Code plugin."""

__version__ = "0.1.0"
