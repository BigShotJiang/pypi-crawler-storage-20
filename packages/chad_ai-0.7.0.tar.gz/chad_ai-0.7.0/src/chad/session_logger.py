from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Iterable


import re


def _parse_positive_int(value: str | None, default: int | None) -> int | None:
    """Parse a positive integer environment value."""
    if not value:
        return default
    try:
        parsed = int(value)
        return parsed if parsed > 0 else default
    except ValueError:
        return default


# Pattern to match base64 data URLs in img tags
_BASE64_IMG_PATTERN = re.compile(
    r'(<img[^>]*src=")data:image/[a-z]+;base64,[A-Za-z0-9+/=]+("[^>]*>)',
    re.IGNORECASE
)


def _strip_base64_images(content: str) -> str:
    """Replace base64 image data URLs with placeholder text.

    This reduces session log file sizes dramatically while preserving structure.
    """
    return _BASE64_IMG_PATTERN.sub(r'\1[base64 image data stripped]\2', content)


def _strip_base64_from_chat(chat_history: list) -> list:
    """Strip base64 image data from chat history entries."""
    cleaned = []
    for entry in chat_history:
        if isinstance(entry, dict):
            new_entry = entry.copy()
            if "content" in new_entry and isinstance(new_entry["content"], str):
                new_entry["content"] = _strip_base64_images(new_entry["content"])
            cleaned.append(new_entry)
        else:
            cleaned.append(entry)
    return cleaned


class SessionLogger:
    """Create and update per-session log files."""

    def __init__(self, base_dir: Path | None = None, max_logs: int | None = None) -> None:
        env_dir = os.environ.get("CHAD_SESSION_LOG_DIR")
        resolved_dir = Path(base_dir) if base_dir else Path(env_dir) if env_dir else (
                Path(tempfile.gettempdir()) / "chad")
        resolved_dir.mkdir(parents=True, exist_ok=True)

        env_max = _parse_positive_int(os.environ.get("CHAD_SESSION_LOG_MAX_FILES"), 1000)
        self.base_dir = resolved_dir
        self.max_logs = max_logs if max_logs is not None else env_max

        self._prune_logs()

    def precreate_log(self) -> Path:
        """Pre-create an empty session log file and return its path.

        The file will be populated later when the task actually starts.
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        filename = f"chad_session_{timestamp}.json"
        filepath = self.base_dir / filename

        session_data = {
            "timestamp": datetime.now().isoformat(),
            "status": "pending",
            "task_description": None,
            "project_path": None,
            "conversation": [],
            "verification_attempts": [],
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(session_data, f, indent=2)

        self._prune_logs()
        return filepath

    def initialize_log(
        self,
        filepath: Path,
        *,
        task_description: str,
        project_path: str,
        coding_account: str,
        coding_provider: str,
    ) -> None:
        """Initialize a pre-created log file with task details."""
        session_data = {
            "timestamp": datetime.now().isoformat(),
            "task_description": task_description,
            "project_path": project_path,
            "coding": {
                "account": coding_account,
                "provider": coding_provider,
            },
            "status": "running",
            "success": None,
            "completion_reason": None,
            "conversation": [],
            "verification_attempts": [],
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(session_data, f, indent=2)

    def create_log(
        self,
        *,
        task_description: str,
        project_path: str,
        coding_account: str,
        coding_provider: str,
    ) -> Path:
        """Create a new session log and return its path."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        filename = f"chad_session_{timestamp}.json"
        filepath = self.base_dir / filename

        session_data = {
            "timestamp": datetime.now().isoformat(),
            "task_description": task_description,
            "project_path": project_path,
            "coding": {
                "account": coding_account,
                "provider": coding_provider,
            },
            "status": "running",
            "success": None,
            "completion_reason": None,
            "conversation": [],
            "verification_attempts": [],
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(session_data, f, indent=2)

        self._prune_logs()
        return filepath

    def update_log(
        self,
        filepath: Path,
        chat_history: Iterable,
        *,
        streaming_transcript: str | None = None,
        streaming_history: list[tuple[str, str] | tuple[str, str, str]] | None = None,
        success: bool | None = None,
        completion_reason: str | None = None,
        status: str = "running",
        verification_attempts: list | None = None,
        final_status: str | None = None,
        last_event: dict | None = None,
    ) -> None:
        """Update an existing session log with new data.

        Args:
            filepath: Path to the session log file
            chat_history: Structured chat messages (for backward compatibility)
            streaming_transcript: Full streaming output from the session (flat text)
            streaming_history: Structured streaming output as (ai_name, chunk[, timestamp]) tuples
            success: Whether the task succeeded
            completion_reason: Why the task ended
            status: Current status (running, completed, failed)
            final_status: Final task status text to surface failures
            last_event: Optional diagnostics for the last provider event/command
        """
        try:
            with open(filepath, encoding="utf-8") as f:
                session_data = json.load(f)

            # Strip base64 image data to keep log files small
            session_data["conversation"] = _strip_base64_from_chat(list(chat_history))
            session_data["status"] = status
            session_data["last_updated"] = datetime.now().isoformat()
            if verification_attempts is not None:
                session_data["verification_attempts"] = verification_attempts

            # Store structured streaming history with AI names preserved
            if streaming_history is not None:
                session_data["streaming_history"] = []
                transcript_parts = []
                for entry in streaming_history:
                    timestamp = datetime.now().isoformat()
                    agent = ""
                    content = ""
                    if isinstance(entry, tuple):
                        if len(entry) == 3:
                            agent, content, timestamp = entry
                        elif len(entry) >= 2:
                            agent, content = entry[0], entry[1]
                    elif isinstance(entry, dict):
                        agent = entry.get("agent", "")
                        content = entry.get("content", "")
                        timestamp = entry.get("timestamp", timestamp)
                    # Strip base64 from streaming content
                    content = _strip_base64_images(content) if content else ""
                    session_data["streaming_history"].append(
                        {"agent": agent, "content": content, "timestamp": timestamp}
                    )
                    if content:
                        transcript_parts.append(content)
                # Also create flat transcript for backward compatibility
                session_data["streaming_transcript"] = "".join(transcript_parts)
            elif streaming_transcript is not None:
                session_data["streaming_transcript"] = _strip_base64_images(streaming_transcript)

            if success is not None:
                session_data["success"] = success
            if completion_reason is not None:
                session_data["completion_reason"] = completion_reason
            if final_status is not None:
                session_data["final_status"] = final_status
            if last_event is not None:
                session_data["last_event"] = last_event

            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(session_data, f, indent=2)
        except Exception:
            # Logging failures shouldn't break the task flow.
            pass

    def _prune_logs(self) -> None:
        """Trim old session logs to keep the directory small."""
        limit = self.max_logs
        if limit is None or limit <= 0:
            return

        try:
            entries = [
                (entry.stat().st_mtime, entry)
                for entry in self.base_dir.iterdir()
                if entry.is_file()
                and entry.name.startswith("chad_session_")
                and entry.name.endswith(".json")
            ]
        except FileNotFoundError:
            return

        if len(entries) <= limit:
            return

        entries.sort(key=lambda item: item[0], reverse=True)
        for _, path_obj in entries[limit:]:
            try:
                path_obj.unlink(missing_ok=True)
            except Exception:
                continue
