from funpaybotengine import Bot


bot = Bot(golden_key='')


async def main():
    result = await bot.get_offer_page(32539900)
    print(result)


if __name__ == '__main__':
    import asyncio
    asyncio.run(main())