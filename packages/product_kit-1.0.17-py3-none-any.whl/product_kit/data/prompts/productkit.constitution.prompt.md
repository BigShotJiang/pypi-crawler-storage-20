---
agent: productkit.constitution
---
