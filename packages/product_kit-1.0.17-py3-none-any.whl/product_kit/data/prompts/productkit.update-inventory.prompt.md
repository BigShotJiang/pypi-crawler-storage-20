---
agent: productkit.update-inventory
---
