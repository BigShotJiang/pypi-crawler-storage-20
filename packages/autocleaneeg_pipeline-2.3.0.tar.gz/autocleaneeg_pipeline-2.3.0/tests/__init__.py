"""AutoClean EEG test package."""
