"""Refinance calculator package exports."""

from __future__ import annotations

__all__ = []

__version__ = "v0.9.1"

__description__ = """
Root package for the refinance calculator application.
"""
