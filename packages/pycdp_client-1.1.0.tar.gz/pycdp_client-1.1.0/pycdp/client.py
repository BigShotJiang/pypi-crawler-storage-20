# -*- coding: utf-8 -*-
"""
pycdp - Chrome DevTools Protocol 客户端

使用示例:
    from pycdp.client import CDP
    from DrissionPage import Chromium
    
    cdp = CDP(port=9222)
    page = Chromium(cdp).latest_tab
    
    page.get("https://example.com")
    
    result = cdp.request(
        'https://api.example.com/data',
        'POST',
        body={'key': 'value'},
        token_key='ACCESS_TOKEN',
        extra={'userType': 'USER'}
    )
    print(result)
"""
import json
import requests
import websocket


class CDP:
    """CDP 客户端
    
    Args:
        port: Chrome 调试端口，默认 9222
    
    使用方式:
        cdp = CDP(port=9222)
        page = Chromium(cdp.options).latest_tab
    """
    
    def __init__(self, port: int = None):
        self._port = port or 9222
        self._options = None
        self._ws = None
        self._id = 0
    
    @property
    def options(self):
        """返回 ChromiumOptions 实例，用于传给 Chromium（延迟导入）"""
        if self._options is None:
            from DrissionPage import ChromiumOptions
            self._options = ChromiumOptions()
            self._options.set_local_port(self._port)
            self._options.set_argument('--remote-allow-origins=*')
        return self._options
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()
    
    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
    
    @property
    def port(self) -> int:
        return self._port
    
    @port.setter
    def port(self, value: int):
        """设置端口（会关闭现有连接）"""
        if self._ws:
            self._ws.close()
            self._ws = None
        self._port = value
        if self._options is not None:
            self._options.set_local_port(value)
    
    def _get_ws(self, tab_index: int = 0):
        if self._ws is None:
            try:
                pages = requests.get(f'http://127.0.0.1:{self._port}/json', timeout=5).json()
                if not pages:
                    raise Exception('没有可用的页面')
                if tab_index >= len(pages):
                    raise Exception(f'Tab {tab_index} 不存在，共 {len(pages)} 个')
                self._ws = websocket.create_connection(pages[tab_index]['webSocketDebuggerUrl'], timeout=30)
            except websocket.WebSocketException:
                self._ws = None
                raise
            except Exception as e:
                raise Exception(f'CDP 连接失败: {e}')
        return self._ws
    
    def reconnect(self, tab_index: int = 0):
        """重新连接（切换 tab 或连接断开时使用）
        
        Args:
            tab_index: 要连接的 tab 索引，默认 0
            
        Returns:
            WebSocket 连接对象
            
        示例:
            # 切换到第二个 tab
            cdp.reconnect(tab_index=1)
            
            # 连接断开后重连
            cdp.reconnect()
        """
        if self._ws:
            try:
                self._ws.close()
            except:
                pass
            self._ws = None
        return self._get_ws(tab_index)
    
    def run(self, js: str, wait: bool = False):
        """执行 JavaScript 代码
        
        Args:
            js: 要执行的 JavaScript 代码
            wait: 是否等待 Promise 完成，默认 False
            
        Returns:
            JavaScript 执行结果
            
        示例:
            # 获取页面标题
            title = cdp.run('document.title')
            
            # 执行异步代码
            data = cdp.run('fetch("/api").then(r=>r.json())', wait=True)
        """
        ws = self._get_ws()
        self._id += 1
        ws.send(json.dumps({
            'id': self._id,
            'method': 'Runtime.evaluate',
            'params': {'expression': js, 'returnByValue': True, 'awaitPromise': wait}
        }))
        r = json.loads(ws.recv())
        if 'error' in r:
            raise Exception(r['error'].get('message', str(r['error'])))
        return r.get('result', {}).get('result', {}).get('value')
    
    def request(self, url: str, method: str = 'GET', body: dict = None, headers: dict = None, token_key: str = None, extra: dict = None) -> dict:
        """在浏览器上下文中发送 HTTP 请求（绕过反爬）
        
        Args:
            url: 请求 URL
            method: HTTP 方法，默认 'GET'
            body: 请求体（会自动 JSON 序列化）
            headers: 请求头
            token_key: localStorage 中的 token 键名，自动添加 Authorization 头
            extra: 额外的请求头（会合并到 headers）
            
        Returns:
            dict: 包含 status、data、headers 的响应对象，出错时返回 {error: message}
            
        示例:
            # GET 请求
            result = cdp.request('https://api.example.com/users')
            
            # POST 请求带 token
            result = cdp.request(
                'https://api.example.com/data',
                'POST',
                body={'key': 'value'},
                token_key='ACCESS_TOKEN'
            )
        """
        h = headers or {}
        if body is not None and 'Content-Type' not in h:
            h['Content-Type'] = 'application/json'
        
        # 使用 JSON 传参避免 XSS 风险
        params = json.dumps({
            'url': url,
            'method': method,
            'body': body,
            'headers': h,
            'extra': extra or {},
            'token_key': token_key
        })
        
        js = f'''(async()=>{{
            try{{
                let p={params};
                let h=Object.assign({{}},p.headers,p.extra);
                if(p.token_key){{let tk=localStorage.getItem(p.token_key);if(tk)h.Authorization="Bearer "+tk;}}
                let opt={{method:p.method,headers:h,credentials:"include"}};
                if(p.body!==null)opt.body=JSON.stringify(p.body);
                let r=await fetch(p.url,opt);
                let txt=await r.text();
                let d;try{{d=JSON.parse(txt)}}catch{{d=txt}}
                return {{status:r.status,data:d,headers:Object.fromEntries(r.headers)}};
            }}catch(e){{return {{error:e.message}}}}
        }})()'''
        return self.run(js, wait=True)
    
    def get(self, url: str, headers: dict = None, token_key: str = None, extra: dict = None) -> dict:
        """发送 GET 请求
        
        Args:
            url: 请求 URL
            headers: 请求头
            token_key: localStorage 中的 token 键名
            extra: 额外的请求头
            
        Returns:
            dict: 响应对象 {status, data, headers}
            
        示例:
            result = cdp.get('https://api.example.com/users')
            print(result['data'])
        """
        return self.request(url, 'GET', headers=headers, token_key=token_key, extra=extra)
    
    def post(self, url: str, body: dict = None, headers: dict = None, token_key: str = None, extra: dict = None) -> dict:
        """发送 POST 请求
        
        Args:
            url: 请求 URL
            body: 请求体
            headers: 请求头
            token_key: localStorage 中的 token 键名
            extra: 额外的请求头
            
        Returns:
            dict: 响应对象 {status, data, headers}
            
        示例:
            result = cdp.post('https://api.example.com/users', body={'name': 'test'})
        """
        return self.request(url, 'POST', body, headers=headers, token_key=token_key, extra=extra)
    
    def put(self, url: str, body: dict = None, headers: dict = None, token_key: str = None, extra: dict = None) -> dict:
        """发送 PUT 请求
        
        Args:
            url: 请求 URL
            body: 请求体
            headers: 请求头
            token_key: localStorage 中的 token 键名
            extra: 额外的请求头
            
        Returns:
            dict: 响应对象 {status, data, headers}
            
        示例:
            result = cdp.put('https://api.example.com/users/1', body={'name': 'updated'})
        """
        return self.request(url, 'PUT', body, headers=headers, token_key=token_key, extra=extra)
    
    def delete(self, url: str, headers: dict = None, token_key: str = None, extra: dict = None) -> dict:
        """发送 DELETE 请求
        
        Args:
            url: 请求 URL
            headers: 请求头
            token_key: localStorage 中的 token 键名
            extra: 额外的请求头
            
        Returns:
            dict: 响应对象 {status, data, headers}
            
        示例:
            result = cdp.delete('https://api.example.com/users/1')
        """
        return self.request(url, 'DELETE', headers=headers, token_key=token_key, extra=extra)
    
    def storage(self, key: str, value: str = None, storage: str = 'localStorage') -> str:
        """获取或设置浏览器存储
        
        Args:
            key: 存储键名
            value: 要设置的值，为 None 时表示获取
            storage: 存储类型，'localStorage' 或 'sessionStorage'
            
        Returns:
            获取时返回存储的值，设置时返回 None
            
        示例:
            # 获取 token
            token = cdp.storage('ACCESS_TOKEN')
            
            # 设置值
            cdp.storage('myKey', 'myValue')
            
            # 使用 sessionStorage
            cdp.storage('tempData', 'value', storage='sessionStorage')
        """
        if value is None:
            return self.run(f'{storage}.getItem("{key}")')
        return self.run(f'{storage}.setItem("{key}",{json.dumps(value)})')
    
    def cookies(self, name: str = None) -> str:
        """获取页面 cookies
        
        Args:
            name: cookie 名称，为 None 时返回所有 cookies
            
        Returns:
            指定 cookie 的值，或所有 cookies 字符串
            
        示例:
            # 获取所有 cookies
            all_cookies = cdp.cookies()
            
            # 获取指定 cookie
            session_id = cdp.cookies('sessionId')
        """
        if name:
            return self.run(f'document.cookie.split("; ").find(c=>c.startsWith("{name}="))?.split("=")[1]')
        return self.run('document.cookie')
    
    def inject(self, js: str) -> str:
        """页面加载前注入脚本（每个新文档都会执行）
        
        Args:
            js: 要注入的 JavaScript 代码
            
        Returns:
            identifier: 脚本标识符，可用于移除
            
        示例:
            # 注入脚本修改 navigator.webdriver
            cdp.inject('Object.defineProperty(navigator,"webdriver",{get:()=>false})')
        """
        ws = self._get_ws()
        self._id += 1
        ws.send(json.dumps({
            'id': self._id,
            'method': 'Page.addScriptToEvaluateOnNewDocument',
            'params': {'source': js}
        }))
        r = json.loads(ws.recv())
        if 'error' in r:
            raise Exception(r['error'].get('message', str(r['error'])))
        return r.get('result', {}).get('identifier')
    
    def call(self, func: str, *args) -> any:
        """调用页面函数
        
        Args:
            func: 函数名（支持链式调用如 'window.app.getData'）
            *args: 函数参数
            
        Returns:
            函数返回值
            
        示例:
            cdp.call('JSON.stringify', {'key': 'value'})
            cdp.call('window.app.login', 'user', 'pass')
        """
        args_js = ','.join(json.dumps(arg) for arg in args)
        return self.run(f'{func}({args_js})', wait=True)
    
    def hook(self, target: str, callback: str = None) -> None:
        """Hook JS 函数，拦截调用并记录参数
        
        Args:
            target: 要 Hook 的函数路径（如 'XMLHttpRequest.prototype.open'）
            callback: 可选的回调函数名，接收 (funcName, args) 参数
            
        示例:
            # Hook fetch，记录所有请求
            cdp.hook('window.fetch')
            
            # Hook 并自定义处理
            cdp.run('window.onHook = (name, args) => console.log(name, args)')
            cdp.hook('JSON.parse', 'window.onHook')
        """
        cb = callback or 'null'
        js = f'''(function(){{
            let t="{target}",p=t.split("."),f=p.pop(),o=p.reduce((a,k)=>a[k],window);
            let orig=o[f];
            o[f]=function(...args){{
                if({cb}){cb}("{target}",args);
                console.log("[Hook]","{target}",args);
                return orig.apply(this,args);
            }};
            o[f]._original=orig;
        }})()'''
        self.run(js)
    
    def unhook(self, target: str) -> None:
        """移除 Hook，恢复原始函数
        
        Args:
            target: 要移除 Hook 的函数路径
            
        示例:
            cdp.hook('window.fetch')
            # ... 使用后移除
            cdp.unhook('window.fetch')
        """
        js = f'''(function(){{
            let t="{target}",p=t.split("."),f=p.pop(),o=p.reduce((a,k)=>a[k],window);
            if(o[f]._original)o[f]=o[f]._original;
        }})()'''
        self.run(js)
    
    def getvar(self, path: str) -> any:
        """获取页面 JS 变量值（重命名避免与 HTTP GET 冲突）
        
        Args:
            path: 变量路径（如 'window.app.config' 或 'app.token'）
            
        Returns:
            变量值
            
        示例:
            config = cdp.getvar('window.app.config')
            token = cdp.getvar('app.userInfo.token')
        """
        return self.run(f'JSON.parse(JSON.stringify({path}))')
    
    def setvar(self, path: str, value: any) -> None:
        """设置页面 JS 变量值
        
        Args:
            path: 变量路径
            value: 要设置的值
            
        示例:
            cdp.set('window.DEBUG', True)
            cdp.set('app.config.apiUrl', 'https://api.example.com')
        """
        self.run(f'{path}={json.dumps(value)}')
    
    def override(self, target: str, impl: str) -> None:
        """覆盖 JS 函数实现
        
        Args:
            target: 要覆盖的函数路径
            impl: 新的函数实现（JS 代码）
            
        示例:
            # 固定 Date
            cdp.override('Date.now', '()=>1234567890000')
            
            # 固定随机数
            cdp.override('Math.random', '()=>0.5')
            
            # 修改 JSON.parse 添加日志
            cdp.override('JSON.parse', '(s)=>{console.log(s);return JSON.parse._orig(s)}')
        """
        js = f'''(function(){{
            let t="{target}",p=t.split("."),f=p.pop(),o=p.reduce((a,k)=>a[k],window);
            if(!o[f]._orig)o[f]._orig=o[f];
            o[f]={impl};
        }})()'''
        self.run(js)
    
    def restore(self, target: str) -> None:
        """恢复被 override 覆盖的函数
        
        Args:
            target: 要恢复的函数路径
            
        示例:
            cdp.override('Math.random', '()=>0.5')
            # ... 使用后恢复
            cdp.restore('Math.random')
        """
        js = f'''(function(){{
            let t="{target}",p=t.split("."),f=p.pop(),o=p.reduce((a,k)=>a[k],window);
            if(o[f]._orig)o[f]=o[f]._orig;
        }})()'''
        self.run(js)
    
    def close(self) -> None:
        """关闭 WebSocket 连接
        
        示例:
            cdp = CDP(port=9222)
            # ... 使用完毕
            cdp.close()
            
            # 或使用 with 语句自动关闭
            with CDP(port=9222) as cdp:
                cdp.run('document.title')
        """
        if self._ws:
            self._ws.close()
            self._ws = None