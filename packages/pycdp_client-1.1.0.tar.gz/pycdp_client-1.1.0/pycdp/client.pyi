# -*- coding: utf-8 -*-
"""pycdp 类型存根文件"""
from typing import Any, Dict, Optional


class CDP:
    """CDP 客户端
    
    Args:
        port: Chrome 调试端口，默认 9222
    
    示例:
        cdp = CDP(port=9222)
        page = Chromium(cdp.options).latest_tab
    """
    
    def __init__(self, port: int = 9222) -> None: ...
    
    @property
    def options(self) -> Any:
        """返回 ChromiumOptions 实例，用于传给 Chromium（延迟导入）"""
        ...
    
    @property
    def port(self) -> int:
        """当前端口号"""
        ...
    
    @port.setter
    def port(self, value: int) -> None:
        """设置端口（会关闭现有连接）"""
        ...
    
    def reconnect(self, tab_index: int = 0) -> Any:
        """重新连接（切换 tab 或连接断开时使用）
        
        Args:
            tab_index: 要连接的 tab 索引，默认 0
            
        Returns:
            WebSocket 连接对象
            
        示例:
            cdp.reconnect(tab_index=1)  # 切换到第二个 tab
        """
        ...
    
    def run(self, js: str, wait: bool = False) -> Any:
        """执行 JavaScript 代码
        
        Args:
            js: 要执行的 JavaScript 代码
            wait: 是否等待 Promise 完成，默认 False
            
        Returns:
            JavaScript 执行结果
            
        示例:
            title = cdp.run('document.title')
            data = cdp.run('fetch("/api").then(r=>r.json())', wait=True)
        """
        ...
    
    def request(self, url: str, method: str = 'GET', body: Optional[Dict] = None, headers: Optional[Dict] = None, token_key: Optional[str] = None, extra: Optional[Dict] = None) -> Dict[str, Any]:
        """在浏览器上下文中发送 HTTP 请求（绕过反爬）
        
        Args:
            url: 请求 URL
            method: HTTP 方法，默认 'GET'
            body: 请求体（会自动 JSON 序列化）
            headers: 请求头
            token_key: localStorage 中的 token 键名，自动添加 Authorization 头
            extra: 额外的请求头（会合并到 headers）
            
        Returns:
            dict: 包含 status、data、headers 的响应对象
        """
        ...
    
    def get(self, url: str, headers: Optional[Dict] = None, token_key: Optional[str] = None, extra: Optional[Dict] = None) -> Dict[str, Any]:
        """发送 GET 请求
        
        Args:
            url: 请求 URL
            headers: 请求头
            token_key: localStorage 中的 token 键名
            extra: 额外的请求头
            
        Returns:
            dict: 响应对象 {status, data, headers}
        """
        ...
    
    def post(self, url: str, body: Optional[Dict] = None, headers: Optional[Dict] = None, token_key: Optional[str] = None, extra: Optional[Dict] = None) -> Dict[str, Any]:
        """发送 POST 请求
        
        Args:
            url: 请求 URL
            body: 请求体
            headers: 请求头
            token_key: localStorage 中的 token 键名
            extra: 额外的请求头
            
        Returns:
            dict: 响应对象 {status, data, headers}
        """
        ...
    
    def put(self, url: str, body: Optional[Dict] = None, headers: Optional[Dict] = None, token_key: Optional[str] = None, extra: Optional[Dict] = None) -> Dict[str, Any]:
        """发送 PUT 请求
        
        Args:
            url: 请求 URL
            body: 请求体
            headers: 请求头
            token_key: localStorage 中的 token 键名
            extra: 额外的请求头
            
        Returns:
            dict: 响应对象 {status, data, headers}
        """
        ...
    
    def delete(self, url: str, headers: Optional[Dict] = None, token_key: Optional[str] = None, extra: Optional[Dict] = None) -> Dict[str, Any]:
        """发送 DELETE 请求
        
        Args:
            url: 请求 URL
            headers: 请求头
            token_key: localStorage 中的 token 键名
            extra: 额外的请求头
            
        Returns:
            dict: 响应对象 {status, data, headers}
        """
        ...
    
    def storage(self, key: str, value: Optional[str] = None, storage: str = 'localStorage') -> Optional[str]:
        """获取或设置浏览器存储
        
        Args:
            key: 存储键名
            value: 要设置的值，为 None 时表示获取
            storage: 存储类型，'localStorage' 或 'sessionStorage'
            
        Returns:
            获取时返回存储的值，设置时返回 None
            
        示例:
            token = cdp.storage('ACCESS_TOKEN')
            cdp.storage('myKey', 'myValue')
        """
        ...
    
    def cookies(self, name: Optional[str] = None) -> Optional[str]:
        """获取页面 cookies
        
        Args:
            name: cookie 名称，为 None 时返回所有 cookies
            
        Returns:
            指定 cookie 的值，或所有 cookies 字符串
        """
        ...
    
    def inject(self, js: str) -> str:
        """页面加载前注入脚本（每个新文档都会执行）
        
        Args:
            js: 要注入的 JavaScript 代码
            
        Returns:
            identifier: 脚本标识符，可用于移除
            
        示例:
            cdp.inject('Object.defineProperty(navigator,"webdriver",{get:()=>false})')
        """
        ...
    
    def call(self, func: str, *args: Any) -> Any:
        """调用页面函数
        
        Args:
            func: 函数名（支持链式调用如 'window.app.getData'）
            *args: 函数参数
            
        Returns:
            函数返回值
            
        示例:
            cdp.call('JSON.stringify', {'key': 'value'})
        """
        ...
    
    def hook(self, target: str, callback: Optional[str] = None) -> None:
        """Hook JS 函数，拦截调用并记录参数
        
        Args:
            target: 要 Hook 的函数路径（如 'XMLHttpRequest.prototype.open'）
            callback: 可选的回调函数名，接收 (funcName, args) 参数
            
        示例:
            cdp.hook('window.fetch')
            cdp.hook('JSON.parse', 'window.onHook')
        """
        ...
    
    def unhook(self, target: str) -> None:
        """移除 Hook，恢复原始函数
        
        Args:
            target: 要移除 Hook 的函数路径
        """
        ...
    
    def getvar(self, path: str) -> Any:
        """获取页面 JS 变量值
        
        Args:
            path: 变量路径（如 'window.app.config' 或 'app.token'）
            
        Returns:
            变量值
            
        示例:
            config = cdp.getvar('window.app.config')
        """
        ...
    
    def setvar(self, path: str, value: Any) -> None:
        """设置页面 JS 变量值
        
        Args:
            path: 变量路径
            value: 要设置的值
            
        示例:
            cdp.setvar('window.DEBUG', True)
        """
        ...
    
    def override(self, target: str, impl: str) -> None:
        """覆盖 JS 函数实现
        
        Args:
            target: 要覆盖的函数路径
            impl: 新的函数实现（JS 代码）
            
        示例:
            cdp.override('Date.now', '()=>1234567890000')
            cdp.override('Math.random', '()=>0.5')
        """
        ...
    
    def restore(self, target: str) -> None:
        """恢复被 override 覆盖的函数
        
        Args:
            target: 要恢复的函数路径
            
        示例:
            cdp.override('Date.now', '()=>1234567890000')
            cdp.restore('Date.now')  # 恢复原始 Date.now
        """
        ...
    
    def close(self) -> None:
        """关闭 WebSocket 连接
        
        示例:
            cdp.close()
            # 或使用 with 语句自动关闭
            with CDP(port=9222) as cdp:
                cdp.run('document.title')
        """
        ...