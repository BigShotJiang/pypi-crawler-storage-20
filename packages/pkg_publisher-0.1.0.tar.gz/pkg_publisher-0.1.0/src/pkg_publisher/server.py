from __future__ import annotations

from typing import Annotated, Optional, Dict, Any
from mcp.server.fastmcp import FastMCP
from .service import (
    PackageBuildService,
    PackagePublishService,
    PackageValidateService,
    PackageInfoService,
    AsyncPackageService,
    get_version,
    setup_logging,
    __version__,
)
from pydantic import Field

ProjectPathStr = Annotated[
    Optional[str],
    Field(
        description="项目路径（可选，默认为当前目录）",
        default=None,
        max_length=1000,
    ),
]

PackagePathStr = Annotated[
    Optional[str],
    Field(
        description="包文件路径（可选，默认为 dist/*）",
        default=None,
        max_length=1000,
    ),
]

RepositoryStr = Annotated[
    str,
    Field(
        description="仓库名称 (pypi 或 testpypi)，默认 pypi",
        pattern="^(pypi|testpypi)$",
    ),
]

PackageNameStr = Annotated[
    str,
    Field(
        description="包名",
        min_length=1,
        max_length=100,
    ),
]

VersionStr = Annotated[
    Optional[str],
    Field(
        description="版本号（可选）",
        default=None,
        max_length=50,
    ),
]

SkipExistingBool = Annotated[
    bool,
    Field(
        description="是否跳过已存在的版本，默认 False",
        default=False,
    ),
]

CleanBool = Annotated[
    bool,
    Field(
        description="是否清理旧的构建产物，默认 True",
        default=True,
    ),
]

app = FastMCP("pkg-publisher")

_build_service: Optional[PackageBuildService] = None
_publish_service: Optional[PackagePublishService] = None
_validate_service: Optional[PackageValidateService] = None
_info_service: Optional[PackageInfoService] = None
_async_service: Optional[AsyncPackageService] = None


def init_service() -> None:
    global _build_service, _publish_service, _validate_service, _info_service, _async_service
    _build_service = PackageBuildService()
    _publish_service = PackagePublishService()
    _validate_service = PackageValidateService()
    _info_service = PackageInfoService()
    _async_service = AsyncPackageService()


def _build_svc() -> PackageBuildService:
    if _build_service is None:
        raise RuntimeError(
            "Build service not initialized. Call init_service() before running the server."
        )
    return _build_service


def _publish_svc() -> PackagePublishService:
    if _publish_service is None:
        raise RuntimeError(
            "Publish service not initialized. Call init_service() before running the server."
        )
    return _publish_service


def _validate_svc() -> PackageValidateService:
    if _validate_service is None:
        raise RuntimeError(
            "Validate service not initialized. Call init_service() before running the server."
        )
    return _validate_service


def _info_svc() -> PackageInfoService:
    if _info_service is None:
        raise RuntimeError(
            "Info service not initialized. Call init_service() before running the server."
        )
    return _info_service


def _async_svc() -> AsyncPackageService:
    if _async_service is None:
        raise RuntimeError(
            "Async service not initialized. Call init_service() before running the server."
        )
    return _async_service


@app.tool(
    name="build_package",
    description=(
        "构建 Python 包，生成 .whl 和 .tar.gz 文件。"
        "执行 python -m build 命令，返回构建产物路径列表。"
    ),
    annotations={
        "title": "包构建器",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
def build_package(
    project_path: ProjectPathStr = None,
    clean: CleanBool = True,
) -> Dict[str, Any]:
    """
    构建 Python 包

    Args:
        project_path: 项目路径（可选，默认为当前目录）
        clean: 是否清理旧的构建产物，默认 True

    Returns:
        包含构建结果的字典
    """
    try:
        result = _build_svc().build_package(project_path, clean)
        return result
    except Exception as e:
        return {"success": False, "error": str(e), "dist_files": []}


@app.tool(
    name="publish_package",
    description=(
        "发布 Python 包到 PyPI。"
        "从环境变量 PYPI_API_TOKEN 或 TEST_PYPI_API_TOKEN 读取 API Token。"
        "执行 twine upload 命令，返回发布状态。"
    ),
    annotations={
        "title": "包发布器",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
def publish_package(
    package_path: PackagePathStr = None,
    repository: RepositoryStr = "pypi",
    skip_existing: SkipExistingBool = False,
    project_path: ProjectPathStr = None,
) -> Dict[str, Any]:
    """
    发布 Python 包到 PyPI

    Args:
        package_path: 包文件路径（可选，默认为 dist/*）
        repository: 仓库名称 (pypi 或 testpypi)，默认 pypi
        skip_existing: 是否跳过已存在的版本，默认 False
        project_path: 项目路径，用于查找 dist 目录

    Returns:
        包含发布结果的字典
    """
    try:
        result = _publish_svc().publish_package(
            package_path, repository, skip_existing, project_path
        )
        return result
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "repository": repository,
            "package_files": [],
        }


@app.tool(
    name="build_package_async",
    description=(
        "异步构建 Python 包，立即返回 token。包将在后台构建，可通过 query_task_status 查询结果。"
    ),
    annotations={
        "title": "异步包构建器",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
def build_package_async(
    project_path: ProjectPathStr = None,
    clean: CleanBool = True,
) -> Dict[str, Any]:
    """
    异步构建 Python 包

    Args:
        project_path: 项目路径（可选，默认为当前目录）
        clean: 是否清理旧的构建产物，默认 True

    Returns:
        包含token和状态信息的字典
    """
    try:
        token = _async_svc().build_package_async(project_path, clean)
        return {"token": token, "status": "pending", "task_type": "build_package", "message": "submitted"}
    except Exception as e:
        return {"error": str(e)}


@app.tool(
    name="publish_package_async",
    description=(
        "异步发布 Python 包到 PyPI，立即返回 token。包将在后台发布，可通过 query_task_status 查询结果。"
    ),
    annotations={
        "title": "异步包发布器",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
def publish_package_async(
    package_path: PackagePathStr = None,
    repository: RepositoryStr = "pypi",
    skip_existing: SkipExistingBool = False,
    project_path: ProjectPathStr = None,
) -> Dict[str, Any]:
    """
    异步发布 Python 包到 PyPI

    Args:
        package_path: 包文件路径（可选，默认为 dist/*）
        repository: 仓库名称 (pypi 或 testpypi)，默认 pypi
        skip_existing: 是否跳过已存在的版本，默认 False
        project_path: 项目路径，用于查找 dist 目录

    Returns:
        包含token和状态信息的字典
    """
    try:
        token = _async_svc().publish_package_async(
            package_path, repository, skip_existing, project_path
        )
        return {"token": token, "status": "pending", "task_type": "publish_package", "message": "submitted"}
    except Exception as e:
        return {"error": str(e)}


@app.tool(
    name="query_task_status",
    description="查询异步任务执行状态和结果。返回任务的当前状态、退出码、输出等信息。",
    annotations={
        "title": "任务状态查询器",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
def query_task_status(token: str) -> Dict[str, Any]:
    """
    查询异步任务执行状态和结果

    Args:
        token: 任务 token (GUID 字符串)

    Returns:
        包含任务状态和结果的字典
    """
    try:
        result = _async_svc().query_task_status(token)
        return result
    except Exception as e:
        return {"error": str(e)}


@app.tool(
    name="validate_package",
    description=(
        "验证 Python 包是否符合 PyPI 规范。"
        "执行 twine check 命令，返回验证结果。"
    ),
    annotations={
        "title": "包验证器",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
def validate_package(package_path: str) -> Dict[str, Any]:
    """
    验证 Python 包

    Args:
        package_path: 包文件路径

    Returns:
        包含验证结果的字典
    """
    try:
        result = _validate_svc().validate_package(package_path)
        return result
    except Exception as e:
        return {"success": False, "error": str(e), "package_path": package_path}


@app.tool(
    name="get_package_info",
    description=(
        "查询 PyPI 上的包信息。"
        "返回版本列表、发布时间、下载量等信息。"
    ),
    annotations={
        "title": "包信息查询器",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
def get_package_info(
    package_name: PackageNameStr,
    version: VersionStr = None,
    repository: RepositoryStr = "pypi",
) -> Dict[str, Any]:
    """
    获取 Python 包信息

    Args:
        package_name: 包名
        version: 版本号（可选）
        repository: 仓库名称 (pypi 或 testpypi)，默认 pypi

    Returns:
        包含包信息的字典
    """
    try:
        result = _info_svc().get_package_info(package_name, version, repository)
        return result
    except Exception as e:
        return {"success": False, "error": str(e), "package_name": package_name}


@app.tool(
    name="get_version",
    description="获取 pkg-publisher 版本号。",
    annotations={
        "title": "版本查询器",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
def get_version_tool() -> Dict[str, str]:
    """
    获取 pkg-publisher 版本号

    Returns:
        包含版本号的字典
    """
    try:
        version = get_version()
        return {"version": version}
    except Exception as e:
        return {"error": str(e)}