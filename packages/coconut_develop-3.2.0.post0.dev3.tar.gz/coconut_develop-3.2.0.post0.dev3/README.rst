|logo| Coconut
==============

..
    <insert toctree here>

.. |logo| image:: https://github.com/evhub/coconut/raw/gh-pages/favicon-32x32.png

.. image:: https://opencollective.com/coconut/backers/badge.svg
    :alt: Backers on Open Collective
    :target: #backers
.. image:: https://opencollective.com/coconut/sponsors/badge.svg
    :alt: Sponsors on Open Collective
    :target: #sponsors
.. image:: https://badges.gitter.im/evhub/coconut.svg
    :alt: Join the chat at https://gitter.im/evhub/coconut
    :target: https://gitter.im/evhub/coconut?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge

Coconut (`coconut-lang.org`__) is a variant of Python_ that **adds on top of Python syntax** new features for simple, elegant, Pythonic **functional programming**.

__ Coconut_
.. _Coconut: http://coconut-lang.org/

Coconut is developed on GitHub_ and hosted on PyPI_. Installing Coconut is as easy as opening a command prompt and entering::

    pip install coconut

To help you get started, check out these links for more information about Coconut:

- Tutorial_: If you're new to Coconut, a good place to start is Coconut's **tutorial**.
- Documentation_: If you're looking for info about a specific feature, check out Coconut's **documentation**.
- `Online Interpreter`_: If you want to try Coconut in your browser, check out Coconut's **online interpreter**.
- FAQ_: If you have general questions about Coconut—like who Coconut is built for and whether or not you should use it—Coconut's frequently asked questions are often the best place to start.
- `Create a New Issue <https://github.com/evhub/coconut/issues/new>`_: If you're having a problem with Coconut, creating a new issue detailing the problem will allow it to be addressed as soon as possible. Creating a new issue is also absolutely welcome as a way to ask any questions you might have about Coconut.
- Releases_: Want to know what's been added in recent Coconut versions? Check out the release log for all the new features and fixes.

.. _Python: https://www.python.org/
.. _PyPI: https://pypi.python.org/pypi/coconut
.. _Tutorial: http://coconut.readthedocs.io/en/latest/HELP.html
.. _Documentation: http://coconut.readthedocs.io/en/latest/DOCS.html
.. _`Online Interpreter`: https://cs121-team-panda.github.io/coconut-interpreter
.. _FAQ: http://coconut.readthedocs.io/en/latest/FAQ.html
.. _GitHub: https://github.com/evhub/coconut
.. _Releases: https://github.com/evhub/coconut/releases

Credits
+++++++

Contributors
------------

This project exists thanks to all the people who contribute! `Become a contributor`__.

.. image:: https://opencollective.com/coconut/contributors.svg?width=890&button=false
    :target: https://github.com/evhub/coconut/graphs/contributors

__ Contributor_
.. _Contributor: http://coconut.readthedocs.io/en/develop/CONTRIBUTING.html

Backers
-------

Thank you to all our backers! `Become a backer`__.

.. image:: https://opencollective.com/coconut/backers.svg?width=890
    :target: https://opencollective.com/coconut#backers

__ Backer_
.. _Backer: https://opencollective.com/coconut#backer

Sponsors
--------

Support Coconut by becoming a sponsor. Your logo will show up here with a link to your website. `Become a sponsor`__.

.. image:: https://opencollective.com/XX/sponsor/0/avatar.svg
    :target: https://opencollective.com/coconut/sponsor/0/website

__ Sponsor_
.. _Sponsor: https://opencollective.com/coconut#sponsor
