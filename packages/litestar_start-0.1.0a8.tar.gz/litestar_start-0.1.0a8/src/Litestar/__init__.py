"""Litestar framework generator."""
