from .config import GeneticBaseConfig
