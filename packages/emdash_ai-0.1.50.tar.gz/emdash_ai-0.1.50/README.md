# emdash-ai

Graph-based coding intelligence system - The 'Senior Engineer' Context Engine

## Quick Install

```bash
curl -sSL "https://gist.githubusercontent.com/mendyEdri/fded37baab4a556cb13920ab79d2bab9/raw/install.sh?$(date +%s)" | bash
```

This creates an isolated installation at `~/.emdash` and adds the `em` command to your PATH.

### Update / Reinstall

```bash
# Update to latest version (run same command again)
curl -sSL "https://gist.githubusercontent.com/mendyEdri/fded37baab4a556cb13920ab79d2bab9/raw/install.sh?$(date +%s)" | bash

# Force fresh reinstall
curl -sSL "https://gist.githubusercontent.com/mendyEdri/fded37baab4a556cb13920ab79d2bab9/raw/install.sh?$(date +%s)" | bash -s -- --reinstall

# Install with graph database support
curl -sSL "https://gist.githubusercontent.com/mendyEdri/fded37baab4a556cb13920ab79d2bab9/raw/install.sh?$(date +%s)" | bash -s -- --with-graph
```

## Alternative Installation

Using pip (requires Python 3.10+):
```bash
pip install emdash-ai
```

With graph database support (optional):
```bash
pip install 'emdash-ai[graph]'
```

## Usage

```bash
em              # Start the AI coding agent
emdash index    # Index your codebase
emdash agent    # Start the AI agent (alternative)
```

## Slash Commands

Once inside the agent REPL, use these slash commands:

### Mode Switching

| Command | Description |
|---------|-------------|
| `/plan` | Switch to plan mode (explore codebase, create plans) |
| `/code` | Switch to code mode (execute file changes) |
| `/mode` | Show current operating mode |

### Generation & Research

| Command | Description |
|---------|-------------|
| `/projectmd` | Generate PROJECT.md describing your codebase architecture |
| `/pr [url]` | Review a pull request (e.g., `/pr 123` or `/pr https://github.com/org/repo/pull/123`) |
| `/research [goal]` | Deep research on a topic (e.g., `/research How does auth work?`) |

### Status & Context

| Command | Description |
|---------|-------------|
| `/status` | Show index and PROJECT.md status |
| `/context` | Show current context frame (tokens, reranked items) |
| `/compact` | Compact message history using LLM summarization |
| `/spec` | Show current specification from plan mode |

### Todo Management

| Command | Description |
|---------|-------------|
| `/todos` | Show current agent todo list |
| `/todo-add [title]` | Add a todo item for the agent |

### Session Management

| Command | Description |
|---------|-------------|
| `/session` | Interactive session menu |
| `/session save [name]` | Save current session |
| `/session load [name]` | Load a saved session |
| `/session list` | List all saved sessions |
| `/session delete [name]` | Delete a session |
| `/reset` | Reset session state |

### Configuration

| Command | Description |
|---------|-------------|
| `/agents` | Manage agents (create, show, edit, delete) |
| `/rules` | Manage rules that guide agent behavior |
| `/skills` | Manage reusable skills |
| `/hooks` | Manage event hooks (triggers on tool_start, session_end, etc.) |
| `/mcp` | Manage MCP servers |
| `/registry` | Browse and install community skills, rules, agents, and verifiers |
| `/setup` | Interactive setup wizard |

### Verification

| Command | Description |
|---------|-------------|
| `/verify` | Run verification checks on current work |
| `/verify-loop [task]` | Run task in loop until all verifications pass |

### Authentication & Diagnostics

| Command | Description |
|---------|-------------|
| `/auth` | GitHub authentication (login, logout, status) |
| `/doctor` | Check environment and diagnose issues |

### Help & Exit

| Command | Description |
|---------|-------------|
| `/help` | Show available commands |
| `/quit` | Exit the agent (also `/exit`, `/q`) |

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+Space` | Auto-complete commands |
| `Alt+Enter` | Multi-line input |
| `Ctrl+V` | Paste image from clipboard |
| `@filename` | Reference a file in your prompt |

## Features

- Graph-based code analysis
- Semantic code search
- AI-powered code exploration
- MCP server integration
- Session persistence
- Custom agents, rules, and skills
- Event hooks for automation
- Verification loops

## Configuration

Configuration files are stored in `.emdash/` in your project root:

```
.emdash/
├── agents/       # Custom agent definitions
├── rules/        # Coding rules and guidelines
├── skills/       # Reusable skills
├── sessions/     # Saved sessions
└── hooks.json    # Event hooks configuration
```

Global config at `~/.config/emdash/`:
```
~/.config/emdash/
├── mcp.json      # MCP server configuration
└── config.json   # Global settings
```

## Uninstall

```bash
rm -rf ~/.emdash ~/.local/bin/em ~/.local/bin/emdash
```
