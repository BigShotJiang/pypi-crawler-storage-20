# Proteo Suite

**Advanced Proteomics Analysis Suite for Medical Outcomes Prediction**

`proteo_suite` is a Python library designed for advanced mass spectrometry signal processing and machine learning analysis to predict medical outcomes from proteomics data.

## Features

- **Advanced Signal Processing**: Wavelet transforms, spectral analysis, peak enhancement.
- **Machine Learning**: Ensembles (XGBoost, LightGBM, CatBoost), Deep Learning (Transformers, CNNs).
- **Survival Analysis**: Kaplan-Meier, risk stratification.
- **Statistical Validation**: Bootstrap confidence intervals, calibration analysis, comprehensive reporting.

## Installation

### Option 1: Install from PyPI (Recommended)

```bash
pip install proteo-suite-json9112
```

### Option 2: Install from Private GitHub (Alternative)

```bash
pip install git+https://github.com/YOUR_USERNAME/proteo_suite.git
```

### Option 2: Install Locally

For development or local use:

```bash
pip install .
```

## Usage

### Enhanced Pipeline

```python
from proteo_suite import EnhancedProteomicsPipeline

# Initialize
pipeline = EnhancedProteomicsPipeline()

# Run analysis
results = pipeline.run_analysis(
    data_file="path/to/data.csv",
    outcome_columns=['Pneumonitis', 'Grade_3_or_above']
)
```

### Comprehensive Validation

```python
from proteo_suite import ComprehensiveValidator

validator = ComprehensiveValidator()
validator.validate_model(y_true, y_scores, model_name="MyModel")
```

### Advanced Analyzer (Full Stack)

```python
from proteo_suite import AdvancedProteomicsAnalyzer

analyzer = AdvancedProteomicsAnalyzer(data_path="data.csv")
analyzer.run_complete_analysis()
```

## Dependencies

- numpy, pandas, scipy, scikit-learn
- xgboost, lightgbm, catboost
- lifelines
- torch (optional, for deep learning)
- matplotlib, seaborn
