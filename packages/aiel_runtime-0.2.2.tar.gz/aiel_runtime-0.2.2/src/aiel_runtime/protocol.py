from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional
from uuid import uuid4
import time

from pydantic import BaseModel, Field, ConfigDict


# ---------------------------
# Context (Lambda-like "context")
# ---------------------------

@dataclass
class Context:
    request_id: str
    trace_id: Optional[str] = None
    deadline_ms: Optional[int] = None
    snapshot_id: Optional[str] = None

    _logs: List[Dict[str, Any]] = field(default_factory=list)

    def log(self, event: str, **fields: Any) -> None:
        self._logs.append(
            {
                "ts_ms": int(time.time() * 1000),
                "event": event,
                "fields": fields,
            }
        )

    def logs(self) -> List[Dict[str, Any]]:
        return list(self._logs)

    def time_remaining_ms(self) -> Optional[int]:
        if self.deadline_ms is None:
            return None
        now = int(time.time() * 1000)
        return max(0, self.deadline_ms - now)


# ---------------------------
# Request / Response Models
# ---------------------------

class Capabilities(BaseModel):
    """
    In-process enforcement can only be partial.
    We can reliably enforce import restrictions and (optionally) deny network libs by blocking 'socket'.
    """
    model_config = ConfigDict(extra="forbid")

    network: bool = False
    subprocess: bool = False
    ctypes: bool = False
    signal: bool = False
    resource: bool = False


class InvokeMeta(BaseModel):
    model_config = ConfigDict(extra="forbid")

    request_id: str = Field(default_factory=lambda: str(uuid4()))
    trace_id: Optional[str] = None
    idempotency_key: Optional[str] = None

    timeout_ms: int = 30_000  # default 30s (Lambda-ish)
    capabilities: Capabilities = Field(default_factory=Capabilities)


class RunnerRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    action: Literal["describe", "invoke"]

    # Invoke fields
    kind: Optional[Literal["tool", "agent", "flow"]] = None
    handler: Optional[str] = None
    event: Optional[Dict[str, Any]] = None
    meta: Optional[InvokeMeta] = None


class ErrorInfo(BaseModel):
    model_config = ConfigDict(extra="forbid")

    code: str
    message: str
    details: Optional[Dict[str, Any]] = None


class ResponseMeta(BaseModel):
    model_config = ConfigDict(extra="forbid")

    request_id: str
    trace_id: Optional[str] = None
    duration_ms: int
    cold_start: bool
    snapshot_id: Optional[str] = None

    sdk_version: Optional[str] = None
    runtime_version: Optional[str] = None
    logs: List[Dict[str, Any]] = Field(default_factory=list)


class RunnerResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")

    ok: bool
    result: Optional[Any] = None
    error: Optional[ErrorInfo] = None
    meta: ResponseMeta
