from __future__ import annotations

import asyncio
import inspect
import time
from typing import Any, Dict, Optional

from aiel_sdk import get_registry

from .protocol import Context


class TimeoutError(RuntimeError):
    pass


def _ensure_dict(x: Any, what: str) -> Dict[str, Any]:
    if x is None:
        return {}
    if not isinstance(x, dict):
        raise TypeError(f"{what} must be an object (dict). Got: {type(x).__name__}")
    return x


async def _run_with_timeout(coro: asyncio.Future, timeout_ms: int) -> Any:
    try:
        return await asyncio.wait_for(coro, timeout=timeout_ms / 1000.0)
    except asyncio.TimeoutError:
        raise TimeoutError(f"Invocation timed out after {timeout_ms}ms")


async def _call_fn(ctx: Context, fn, arg: Dict[str, Any], *, timeout_ms: int) -> Any:
    """
    Enforce timeouts even for sync functions by running them in a thread.
    (Still not perfect for CPU-bound infinite loops, which is why process/container isolation matters.)
    """
    if inspect.iscoroutinefunction(fn):
        return await _run_with_timeout(fn(ctx, arg), timeout_ms)

    # Sync -> run in a thread so timeouts can interrupt waiting
    async def _thread_call():
        return await asyncio.to_thread(fn, ctx, arg)

    return await _run_with_timeout(_thread_call(), timeout_ms)


async def invoke(kind: str, handler: str, event: Optional[dict], ctx: Context, timeout_ms: int) -> Any:
    reg = get_registry()
    event_dict = _ensure_dict(event, "event")

    if kind == "tool":
        exp = reg.tools.get(handler)
        if not exp:
            raise KeyError(f"Tool not found: {handler}")
        return await _call_fn(ctx, exp.fn, event_dict, timeout_ms=timeout_ms)

    if kind == "agent":
        exp = reg.agents.get(handler)
        if not exp:
            raise KeyError(f"Agent not found: {handler}")
        out = await _call_fn(ctx, exp.fn, event_dict, timeout_ms=timeout_ms)
        if not isinstance(out, dict):
            raise TypeError("Agent must return a dict state.")
        return out

    if kind == "flow":
        exp = reg.flows.get(handler)
        if not exp:
            raise KeyError(f"Flow not found: {handler}")
        out = await _call_fn(ctx, exp.fn, event_dict, timeout_ms=timeout_ms)
        if not isinstance(out, dict):
            raise TypeError("Flow must return a dict state.")
        return out

    raise KeyError(f"Unsupported kind: {kind}")
