import pathlib
import tomllib
import os


def load_config():

    # 1. Look in the current working directory as a last resort (for local development)
    cwd_config_path = 'autobus.toml'
    if os.path.exists(cwd_config_path):
        path = pathlib.Path(cwd_config_path)
        with path.open(mode="rb") as fp:
            config = tomllib.load(fp)
            return config

    # 2. Look in the user's home directory: ~/.autobus/autobus.toml
    home_dir_config_path = os.path.join(os.path.expanduser("~"), '.autobus', 'autobus.toml')
    if os.path.exists(home_dir_config_path):
        path = pathlib.Path(home_dir_config_path)
        with path.open(mode="rb") as fp:
            config = tomllib.load(fp)
            return config

    # 3. Use default in the config module
    print("Warning: No configuration file found in working directory or ~/.autobus/autobus.toml. Using defaults.")
    path = pathlib.Path(__file__).parent / "autobus.toml"
    with path.open(mode="rb") as fp:
        config = tomllib.load(fp)
        return config


config = load_config()
