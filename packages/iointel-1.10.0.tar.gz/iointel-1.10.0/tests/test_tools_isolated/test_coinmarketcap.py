import datetime
import pytest

from iointel.src.agent_methods.tools.coinmarketcap import CoinMarketCap


@pytest.fixture
def cmc():
    return CoinMarketCap()


def test_listing_coins(cmc):
    assert cmc.listing_coins()


def test_get_coin_info(cmc):
    assert cmc.get_coin_info(symbol=["BTC"])


def test_get_coin_price(cmc):
    assert cmc.get_coin_quotes(symbol=["BTC"])


def test_get_coin_historical_price(cmc):
    assert cmc.get_coin_quotes_historical(
        symbol=["BTC"],
        time_end=datetime.datetime.now() - datetime.timedelta(days=1),
        count=1,
    )
