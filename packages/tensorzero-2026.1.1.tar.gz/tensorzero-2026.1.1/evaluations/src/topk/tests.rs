use super::*;
use crate::DatapointVariantError;
use crate::DatapointVariantResult;
use crate::betting_confidence_sequences::{WealthProcessGridPoints, WealthProcesses};
use crate::types::EvaluationVariant;
use serde_json::{Value, json};
use std::sync::Arc;
use tensorzero_core::client::Input;
use tensorzero_core::endpoints::datasets::{ChatInferenceDatapoint, Datapoint};
use tensorzero_core::endpoints::inference::{ChatInferenceResponse, InferenceResponse};
use tensorzero_core::evaluations::{EvaluationConfig, InferenceEvaluationConfig};
use tensorzero_core::inference::types::{ContentBlockChatOutput, Text, Usage};
use tensorzero_core::tool::DynamicToolParams;

// ============================================================================
// Test Helpers
// ============================================================================

/// Helper to create a confidence sequence with specified bounds (for testing stopping conditions)
fn mock_cs_with_bounds(
    name: &str,
    cs_lower: f64,
    cs_upper: f64,
) -> (String, MeanBettingConfidenceSequence) {
    (
        name.to_string(),
        MeanBettingConfidenceSequence {
            name: name.to_string(),
            mean_regularized: (cs_lower + cs_upper) / 2.0,
            variance_regularized: 0.1,
            count: 100,
            mean_est: (cs_lower + cs_upper) / 2.0,
            cs_lower,
            cs_upper,
            alpha: 0.05,
            wealth: WealthProcesses {
                grid: WealthProcessGridPoints::Resolution(101),
                wealth_upper: vec![1.0; 101],
                wealth_lower: vec![1.0; 101],
            },
        },
    )
}

fn default_params_with_variants(variant_names: Vec<&str>) -> TopKTaskParams {
    // Create a minimal dummy evaluation config for unit tests
    let evaluation_config = EvaluationConfig::Inference(InferenceEvaluationConfig {
        evaluators: HashMap::new(),
        function_name: "test_function".to_string(),
        description: None,
    });
    TopKTaskParams {
        evaluation_name: "eval".to_string(),
        dataset_name: "dataset".to_string(),
        variant_names: variant_names.into_iter().map(|s| s.to_string()).collect(),
        k_min: 2,
        k_max: 3,
        epsilon: None,
        max_datapoints: None,
        batch_size: Some(1),
        variant_failure_threshold: 0.05,
        evaluator_failure_threshold: 0.05,
        concurrency: 1,
        inference_cache: CacheEnabledMode::On,
        evaluation_config,
        function_configs: HashMap::new(),
        scoring_function: ScoringFunctionType::AverageEvaluatorScore,
    }
}

fn empty_progress(variant_names: &[&str]) -> TopKProgress {
    TopKProgress {
        variant_status: variant_names
            .iter()
            .map(|name| ((*name).to_string(), VariantStatus::Active))
            .collect(),
        variant_performance: variant_names
            .iter()
            .map(|name| {
                let (_, cs) = mock_cs_with_bounds(name, 0.4, 0.6);
                ((*name).to_string(), cs)
            })
            .collect(),
        variant_failures: HashMap::new(),
        evaluator_failures: HashMap::new(),
        num_datapoints_processed: 0,
        batch_index: 0,
    }
}

/// Helper to create a fresh confidence sequence with no observations (for testing updates)
fn mock_fresh_cs(name: &str) -> MeanBettingConfidenceSequence {
    MeanBettingConfidenceSequence::new(name.to_string(), 101, 0.05)
}

/// Helper to create a mock DatapointVariantResult for testing.
/// Takes a variant name and evaluation results (evaluator_name -> value).
fn mock_success(
    datapoint_id: Uuid,
    variant_name: &str,
    eval_results: HashMap<String, Result<Option<Value>>>,
) -> BatchItemResult {
    // Create a minimal ChatInferenceDatapoint
    let datapoint = Datapoint::Chat(ChatInferenceDatapoint {
        dataset_name: "test_dataset".to_string(),
        function_name: "test_function".to_string(),
        id: datapoint_id,
        episode_id: None,
        input: Input::default(),
        output: None,
        tool_params: DynamicToolParams::default(),
        tags: None,
        auxiliary: String::new(),
        source_inference_id: None,
        staled_at: None,
        updated_at: "2024-01-01T00:00:00Z".to_string(),
        is_deleted: false,
        is_custom: false,
        name: None,
    });

    // Create a minimal InferenceResponse
    let inference_response = InferenceResponse::Chat(ChatInferenceResponse {
        inference_id: Uuid::now_v7(),
        episode_id: Uuid::now_v7(),
        variant_name: variant_name.to_string(),
        content: vec![ContentBlockChatOutput::Text(Text {
            text: "test output".to_string(),
        })],
        usage: Usage {
            input_tokens: Some(0),
            output_tokens: Some(0),
        },
        raw_usage: None,
        original_response: None,
        finish_reason: None,
    });

    BatchItemResult::Success(Box::new(DatapointVariantResult {
        datapoint: Arc::new(datapoint),
        variant: Arc::new(EvaluationVariant::Name(variant_name.to_string())),
        inference_response: Arc::new(inference_response),
        evaluation_result: eval_results,
    }))
}

/// A simple scoring function that extracts each variant's first evaluator value as its score
struct FirstEvaluatorScore;

impl ScoringFunction for FirstEvaluatorScore {
    fn score(&self, evaluations: &HashMap<String, &EvaluationResult>) -> HashMap<String, f64> {
        let mut scores = HashMap::new();
        for (variant_name, eval_result) in evaluations {
            // Return the first Ok(Some(value)) we find, converted to f64
            for result in eval_result.values() {
                if let Ok(Some(value)) = result
                    && let Some(num) = value.as_f64()
                {
                    scores.insert(variant_name.clone(), num);
                    break;
                }
            }
        }
        scores
    }
}

// ============================================================================
// Tests for compute_updates
// ============================================================================

/// Test that compute_updates handles empty results gracefully (no changes to CS maps).
#[test]
fn test_compute_updates_empty_results() {
    let scoring_fn = FirstEvaluatorScore;
    let mut variant_performance: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_bounds("test_variant", 0.3, 0.7)]
            .into_iter()
            .collect();
    let mut variant_failures: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_bounds("test_variant", 0.1, 0.4)]
            .into_iter()
            .collect();
    let mut evaluator_failures: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_bounds("evaluator1", 0.05, 0.2)]
            .into_iter()
            .collect();

    // Empty results should not change any confidence sequences
    let results_by_datapoint: BatchResultsByDatapoint = HashMap::new();
    let result = compute_updates(
        &results_by_datapoint,
        &scoring_fn,
        &mut variant_performance,
        &mut variant_failures,
        &mut evaluator_failures,
        None, // No hedge weight rebalancing
    );

    assert!(result.is_ok());

    // Verify variant_performance is completely unchanged
    let vp = &variant_performance["test_variant"];
    assert_eq!(vp.name, "test_variant");
    assert_eq!(vp.mean_regularized, 0.5); // (0.3 + 0.7) / 2
    assert_eq!(vp.variance_regularized, 0.1);
    assert_eq!(vp.count, 100);
    assert_eq!(vp.mean_est, 0.5);
    assert_eq!(vp.cs_lower, 0.3);
    assert_eq!(vp.cs_upper, 0.7);
    assert_eq!(vp.alpha, 0.05);
    assert_eq!(vp.wealth.wealth_upper, vec![1.0; 101]);
    assert_eq!(vp.wealth.wealth_lower, vec![1.0; 101]);

    // Verify variant_failures is completely unchanged
    let vf = &variant_failures["test_variant"];
    assert_eq!(vf.name, "test_variant");
    assert_eq!(vf.mean_regularized, 0.25); // (0.1 + 0.4) / 2
    assert_eq!(vf.variance_regularized, 0.1);
    assert_eq!(vf.count, 100);
    assert_eq!(vf.mean_est, 0.25);
    assert_eq!(vf.cs_lower, 0.1);
    assert_eq!(vf.cs_upper, 0.4);
    assert_eq!(vf.alpha, 0.05);
    assert_eq!(vf.wealth.wealth_upper, vec![1.0; 101]);
    assert_eq!(vf.wealth.wealth_lower, vec![1.0; 101]);

    // Verify evaluator_failures is completely unchanged
    let ef = &evaluator_failures["evaluator1"];
    assert_eq!(ef.name, "evaluator1");
    assert_eq!(ef.mean_regularized, 0.125); // (0.05 + 0.2) / 2
    assert_eq!(ef.variance_regularized, 0.1);
    assert_eq!(ef.count, 100);
    assert_eq!(ef.mean_est, 0.125);
    assert_eq!(ef.cs_lower, 0.05);
    assert_eq!(ef.cs_upper, 0.2);
    assert_eq!(ef.alpha, 0.05);
    assert_eq!(ef.wealth.wealth_upper, vec![1.0; 101]);
    assert_eq!(ef.wealth.wealth_lower, vec![1.0; 101]);
}

/// Test that variant-level errors (BatchItemResult::Error) update failure CS but not performance/evaluator CS.
#[test]
fn test_compute_updates_variant_failures() {
    let scoring_fn = FirstEvaluatorScore;
    let mut variant_performance: HashMap<String, MeanBettingConfidenceSequence> =
        [("test_variant".to_string(), mock_fresh_cs("test_variant"))]
            .into_iter()
            .collect();
    let mut variant_failures: HashMap<String, MeanBettingConfidenceSequence> =
        [("test_variant".to_string(), mock_fresh_cs("test_variant"))]
            .into_iter()
            .collect();
    let mut evaluator_failures: HashMap<String, MeanBettingConfidenceSequence> =
        [("evaluator1".to_string(), mock_fresh_cs("evaluator1"))]
            .into_iter()
            .collect();

    // Create two errors for two different datapoints
    let datapoint_id_1 = Uuid::now_v7();
    let datapoint_id_2 = Uuid::now_v7();

    // Structure: datapoint_id -> variant_name -> result
    let results_by_datapoint: BatchResultsByDatapoint = [
        (
            datapoint_id_1,
            [(
                "test_variant".to_string(),
                BatchItemResult::Error(DatapointVariantError {
                    datapoint_id: datapoint_id_1,
                    variant: None,
                    message: "test error 1".to_string(),
                }),
            )]
            .into_iter()
            .collect(),
        ),
        (
            datapoint_id_2,
            [(
                "test_variant".to_string(),
                BatchItemResult::Error(DatapointVariantError {
                    datapoint_id: datapoint_id_2,
                    variant: None,
                    message: "test error 2".to_string(),
                }),
            )]
            .into_iter()
            .collect(),
        ),
    ]
    .into_iter()
    .collect();

    let result = compute_updates(
        &results_by_datapoint,
        &scoring_fn,
        &mut variant_performance,
        &mut variant_failures,
        &mut evaluator_failures,
        None, // No hedge weight rebalancing
    );

    assert!(result.is_ok());
    // variant_failures should have 2 observations (both 1.0 = failure)
    assert_eq!(variant_failures["test_variant"].count, 2);
    // Performance should not be updated since there were no successes
    assert_eq!(variant_performance["test_variant"].count, 0);
    // evaluator_failures should not be updated (variant failed before evaluation ran)
    assert_eq!(evaluator_failures["evaluator1"].count, 0);
}

/// Test that results for variants not in the CS maps are silently ignored.
#[test]
fn test_compute_updates_missing_variant_in_map() {
    let scoring_fn = FirstEvaluatorScore;
    // Don't include "test_variant" in confidence sequence maps - should handle gracefully
    let mut variant_performance: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();
    let mut variant_failures: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();
    let mut evaluator_failures: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

    let datapoint_id = Uuid::now_v7();
    let results_by_datapoint: BatchResultsByDatapoint = [(
        datapoint_id,
        [(
            "test_variant".to_string(),
            BatchItemResult::Error(DatapointVariantError {
                datapoint_id,
                variant: None,
                message: "test error".to_string(),
            }),
        )]
        .into_iter()
        .collect(),
    )]
    .into_iter()
    .collect();

    // Should not panic, just skip updates for missing variants
    let result = compute_updates(
        &results_by_datapoint,
        &scoring_fn,
        &mut variant_performance,
        &mut variant_failures,
        &mut evaluator_failures,
        None, // No hedge weight rebalancing
    );

    assert!(result.is_ok());
    // No maps should be modified since variant wasn't in any of them
    assert!(variant_performance.is_empty());
    assert!(variant_failures.is_empty());
    assert!(evaluator_failures.is_empty());
}

/// Test that successful evaluations update performance and evaluator CS correctly.
#[test]
fn test_compute_updates_successful_evaluations() {
    let scoring_fn = FirstEvaluatorScore;
    let mut variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        ("variant_a".to_string(), mock_fresh_cs("variant_a")),
        ("variant_b".to_string(), mock_fresh_cs("variant_b")),
    ]
    .into_iter()
    .collect();
    let mut variant_failures: HashMap<String, MeanBettingConfidenceSequence> = [
        ("variant_a".to_string(), mock_fresh_cs("variant_a")),
        ("variant_b".to_string(), mock_fresh_cs("variant_b")),
    ]
    .into_iter()
    .collect();
    let mut evaluator_failures: HashMap<String, MeanBettingConfidenceSequence> =
        [("evaluator1".to_string(), mock_fresh_cs("evaluator1"))]
            .into_iter()
            .collect();

    let datapoint_id = Uuid::now_v7();

    // Both variants succeed with different scores
    let results_by_datapoint: BatchResultsByDatapoint = [(
        datapoint_id,
        [
            (
                "variant_a".to_string(),
                mock_success(
                    datapoint_id,
                    "variant_a",
                    [("evaluator1".to_string(), Ok(Some(json!(0.8))))]
                        .into_iter()
                        .collect(),
                ),
            ),
            (
                "variant_b".to_string(),
                mock_success(
                    datapoint_id,
                    "variant_b",
                    [("evaluator1".to_string(), Ok(Some(json!(0.6))))]
                        .into_iter()
                        .collect(),
                ),
            ),
        ]
        .into_iter()
        .collect(),
    )]
    .into_iter()
    .collect();

    let result = compute_updates(
        &results_by_datapoint,
        &scoring_fn,
        &mut variant_performance,
        &mut variant_failures,
        &mut evaluator_failures,
        None, // No hedge weight rebalancing
    );

    assert!(result.is_ok());

    // ===============================================
    // Check variant_a performance (observation = 0.8)
    // ===============================================
    // Starting from fresh CS (count=0, mean_reg=0.5, var_reg=0.25)
    // After one observation x=0.8:
    //   mean_regularized = (0.5 * 1 + 0.8) / 2 = 0.65
    //   variance_regularized = (0.25 * 1 + (0.8 - 0.65)^2) / 2 = (0.25 + 0.0225) / 2 = 0.13625
    //   mean_est = 0.8 (single observation)
    let vp_a = &variant_performance["variant_a"];
    assert_eq!(vp_a.count, 1);
    assert!((vp_a.mean_regularized - 0.65).abs() < 1e-10);
    assert!((vp_a.variance_regularized - 0.13625).abs() < 1e-10);
    assert!((vp_a.mean_est - 0.8).abs() < 1e-10);

    // ===============================================
    // Check variant_b performance (observation = 0.6)
    // ===============================================
    // After one observation x=0.6:
    //   mean_regularized = (0.5 * 1 + 0.6) / 2 = 0.55
    //   variance_regularized = (0.25 * 1 + (0.6 - 0.55)^2) / 2 = (0.25 + 0.0025) / 2 = 0.12625
    //   mean_est = 0.6 (single observation)
    let vp_b = &variant_performance["variant_b"];
    assert_eq!(vp_b.count, 1);
    assert!((vp_b.mean_regularized - 0.55).abs() < 1e-10);
    assert!((vp_b.variance_regularized - 0.12625).abs() < 1e-10);
    assert!((vp_b.mean_est - 0.6).abs() < 1e-10);

    // ===============================================================
    // Check variant failures (both get observation = 0.0 for success)
    // ===============================================================
    // After one observation x=0.0:
    //   mean_regularized = (0.5 * 1 + 0.0) / 2 = 0.25
    //   variance_regularized = (0.25 * 1 + (0.0 - 0.25)^2) / 2 = (0.25 + 0.0625) / 2 = 0.15625
    //   mean_est = 0.0
    let vf_a = &variant_failures["variant_a"];
    assert_eq!(vf_a.count, 1);
    assert!((vf_a.mean_regularized - 0.25).abs() < 1e-10);
    assert!((vf_a.variance_regularized - 0.15625).abs() < 1e-10);
    assert!((vf_a.mean_est - 0.0).abs() < 1e-10);

    let vf_b = &variant_failures["variant_b"];
    assert_eq!(vf_b.count, 1);
    assert!((vf_b.mean_regularized - 0.25).abs() < 1e-10);
    assert!((vf_b.variance_regularized - 0.15625).abs() < 1e-10);
    assert!((vf_b.mean_est - 0.0).abs() < 1e-10);

    // ==================================================
    // Check evaluator failures (two observations of 0.0)
    // ==================================================
    // After two observations x1=0.0, x2=0.0:
    //   After x1=0.0: mean_reg1 = 0.25, var_reg1 = 0.15625 (same as above)
    //   After x2=0.0:
    //     mean_regularized = (0.25 * 2 + 0.0) / 3 = 0.5 / 3 = 0.16666...
    //     variance_regularized = (0.15625 * 2 + (0.0 - 0.16666...)^2) / 3
    //                          = (0.3125 + 0.02777...) / 3 = 0.34027... / 3 = 0.11342...
    //   mean_est = (0.0 + 0.0) / 2 = 0.0
    let ef = &evaluator_failures["evaluator1"];
    assert_eq!(ef.count, 2);
    assert!((ef.mean_regularized - 1.0 / 6.0).abs() < 1e-10);
    // var_reg = (0.15625 * 2 + (0 - 1/6)^2) / 3 = (0.3125 + 1/36) / 3 = (0.3125 + 0.02777...) / 3
    let expected_var = (0.3125 + (1.0_f64 / 6.0).powi(2)) / 3.0;
    assert!((ef.variance_regularized - expected_var).abs() < 1e-10);
    assert!((ef.mean_est - 0.0).abs() < 1e-10);
}

/// Test that evaluator errors within successful inferences update evaluator failure CS.
#[test]
fn test_compute_updates_evaluator_failures() {
    let scoring_fn = FirstEvaluatorScore;
    let mut variant_performance: HashMap<String, MeanBettingConfidenceSequence> =
        [("test_variant".to_string(), mock_fresh_cs("test_variant"))]
            .into_iter()
            .collect();
    let mut variant_failures: HashMap<String, MeanBettingConfidenceSequence> =
        [("test_variant".to_string(), mock_fresh_cs("test_variant"))]
            .into_iter()
            .collect();
    let mut evaluator_failures: HashMap<String, MeanBettingConfidenceSequence> = [
        ("evaluator1".to_string(), mock_fresh_cs("evaluator1")),
        ("evaluator2".to_string(), mock_fresh_cs("evaluator2")),
    ]
    .into_iter()
    .collect();

    let datapoint_id = Uuid::now_v7();

    // Variant succeeds but one evaluator fails
    let results_by_datapoint: BatchResultsByDatapoint = [(
        datapoint_id,
        [(
            "test_variant".to_string(),
            mock_success(
                datapoint_id,
                "test_variant",
                [
                    ("evaluator1".to_string(), Ok(Some(json!(0.7)))),
                    (
                        "evaluator2".to_string(),
                        Err(anyhow::anyhow!("evaluator error")),
                    ),
                ]
                .into_iter()
                .collect(),
            ),
        )]
        .into_iter()
        .collect(),
    )]
    .into_iter()
    .collect();

    let result = compute_updates(
        &results_by_datapoint,
        &scoring_fn,
        &mut variant_performance,
        &mut variant_failures,
        &mut evaluator_failures,
        None, // No hedge weight rebalancing
    );

    assert!(result.is_ok());
    // Variant succeeded so variant_failures should have 1 observation (0.0)
    assert_eq!(variant_failures["test_variant"].count, 1);
    // Performance should be updated (scoring function uses first successful evaluator)
    assert_eq!(variant_performance["test_variant"].count, 1);
    // evaluator1 succeeded, evaluator2 failed
    assert_eq!(evaluator_failures["evaluator1"].count, 1);
    assert_eq!(evaluator_failures["evaluator2"].count, 1);
}

/// Test mixed scenario: one variant succeeds, one fails - verify correct CS updates for each.
#[test]
fn test_compute_updates_mixed_success_and_failure() {
    let scoring_fn = FirstEvaluatorScore;
    let mut variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        ("variant_a".to_string(), mock_fresh_cs("variant_a")),
        ("variant_b".to_string(), mock_fresh_cs("variant_b")),
    ]
    .into_iter()
    .collect();
    let mut variant_failures: HashMap<String, MeanBettingConfidenceSequence> = [
        ("variant_a".to_string(), mock_fresh_cs("variant_a")),
        ("variant_b".to_string(), mock_fresh_cs("variant_b")),
    ]
    .into_iter()
    .collect();
    let mut evaluator_failures: HashMap<String, MeanBettingConfidenceSequence> =
        [("evaluator1".to_string(), mock_fresh_cs("evaluator1"))]
            .into_iter()
            .collect();

    let datapoint_id = Uuid::now_v7();

    // variant_a succeeds, variant_b fails
    let results_by_datapoint: BatchResultsByDatapoint = [(
        datapoint_id,
        [
            (
                "variant_a".to_string(),
                mock_success(
                    datapoint_id,
                    "variant_a",
                    [("evaluator1".to_string(), Ok(Some(json!(0.9))))]
                        .into_iter()
                        .collect(),
                ),
            ),
            (
                "variant_b".to_string(),
                BatchItemResult::Error(DatapointVariantError {
                    datapoint_id,
                    variant: None,
                    message: "variant error".to_string(),
                }),
            ),
        ]
        .into_iter()
        .collect(),
    )]
    .into_iter()
    .collect();

    let result = compute_updates(
        &results_by_datapoint,
        &scoring_fn,
        &mut variant_performance,
        &mut variant_failures,
        &mut evaluator_failures,
        None, // No hedge weight rebalancing
    );

    assert!(result.is_ok());
    // variant_a succeeded: performance and failures updated
    assert_eq!(variant_performance["variant_a"].count, 1);
    assert_eq!(variant_failures["variant_a"].count, 1);
    // variant_b failed: only failures updated (count as failure), no performance
    assert_eq!(variant_performance["variant_b"].count, 0);
    assert_eq!(variant_failures["variant_b"].count, 1);
    // evaluator only ran for variant_a
    assert_eq!(evaluator_failures["evaluator1"].count, 1);
}

// ============================================================================
// Tests for check_topk_stopping
// ============================================================================

/// Test that empty input returns no stopping (graceful handling).
#[test]
fn test_check_topk_stopping_empty() {
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();
    let result = check_topk_stopping(&variant_performance, None, 1, 1, None).unwrap();
    assert!(!result.stopped);
    assert!(result.k.is_none());
    assert!(result.top_variants.is_empty());
}

/// Test that k_min=0 returns an error.
#[test]
fn test_check_topk_stopping_k_min_zero_errors() {
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_bounds("a", 0.5, 0.7)].into_iter().collect();

    let result = check_topk_stopping(&variant_performance, None, 0, 1, None);
    assert!(result.is_err());
    assert!(
        result
            .unwrap_err()
            .to_string()
            .contains("k_min must be > 0")
    );
}

/// Test that k_max < k_min returns an error.
#[test]
fn test_check_topk_stopping_k_max_less_than_k_min_errors() {
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_bounds("a", 0.5, 0.7)].into_iter().collect();

    let result = check_topk_stopping(&variant_performance, None, 2, 1, None);
    assert!(result.is_err());
    assert!(result.unwrap_err().to_string().contains("k_max"));
}

/// Test that k_min > num_variants returns no stopping (graceful handling).
#[test]
fn test_check_topk_stopping_k_min_exceeds_num_variants() {
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_bounds("a", 0.5, 0.7)].into_iter().collect();

    let result = check_topk_stopping(&variant_performance, None, 5, 5, None).unwrap();
    assert!(!result.stopped);
    assert!(result.k.is_none());
    assert!(result.top_variants.is_empty());
}

/// Test that negative epsilon returns an error.
#[test]
fn test_check_topk_stopping_negative_epsilon_errors() {
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.7, 0.9),
        mock_cs_with_bounds("b", 0.3, 0.5),
    ]
    .into_iter()
    .collect();

    let result = check_topk_stopping(&variant_performance, None, 1, 1, Some(-0.1));
    assert!(result.is_err());
    assert!(result.unwrap_err().to_string().contains("epsilon"));
}

/// Test top-1 identification when one variant clearly dominates all others.
#[test]
fn test_check_topk_stopping_clear_winner() {
    // Variant A: [0.7, 0.9] - clearly better
    // Variant B: [0.3, 0.5] - clearly worse
    // Variant C: [0.2, 0.4] - clearly worse
    // A's lower bound (0.7) exceeds B's upper (0.5) and C's upper (0.4)
    // So A beats 2 variants, which is >= (3 - 1) = 2, so top-1 is identified
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.7, 0.9),
        mock_cs_with_bounds("b", 0.3, 0.5),
        mock_cs_with_bounds("c", 0.2, 0.4),
    ]
    .into_iter()
    .collect();

    let result = check_topk_stopping(&variant_performance, None, 1, 1, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(1));
    assert_eq!(result.top_variants.len(), 1);
    assert!(result.top_variants.contains(&"a".to_string()));
}

/// Test top-2 identification when two variants clearly beat a third.
#[test]
fn test_check_topk_stopping_top2() {
    // Variant A: [0.7, 0.9] - in top 2
    // Variant B: [0.6, 0.8] - in top 2
    // Variant C: [0.2, 0.4] - clearly worse
    // A's lower (0.7) > C's upper (0.4), so A beats 1
    // B's lower (0.6) > C's upper (0.4), so B beats 1
    // For top-2, each needs to beat >= (3 - 2) = 1 variant
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.7, 0.9),
        mock_cs_with_bounds("b", 0.6, 0.8),
        mock_cs_with_bounds("c", 0.2, 0.4),
    ]
    .into_iter()
    .collect();

    let result = check_topk_stopping(&variant_performance, None, 2, 2, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(2));
    assert_eq!(result.top_variants.len(), 2);
    assert!(result.top_variants.contains(&"a".to_string()));
    assert!(result.top_variants.contains(&"b".to_string()));
}

/// Test that overlapping confidence intervals prevent top-1 identification.
#[test]
fn test_check_topk_stopping_overlapping_intervals_no_stop() {
    // All intervals overlap significantly - can't distinguish
    // Variant A: [0.4, 0.7]
    // Variant B: [0.45, 0.65]
    // Variant C: [0.5, 0.6]
    // No lower bound exceeds any upper bound, so no one "beats" anyone
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.4, 0.7),
        mock_cs_with_bounds("b", 0.45, 0.65),
        mock_cs_with_bounds("c", 0.5, 0.6),
    ]
    .into_iter()
    .collect();

    let result = check_topk_stopping(&variant_performance, None, 1, 1, None).unwrap();
    assert!(!result.stopped);
    assert!(result.k.is_none());
}

/// Test that the largest viable k is returned when checking a range.
#[test]
fn test_check_topk_stopping_k_range() {
    // Variant A: [0.8, 0.9] - beats B and C
    // Variant B: [0.5, 0.7] - beats C only
    // Variant C: [0.2, 0.4] - beats no one
    // A beats 2 (both B and C's uppers are below 0.8)
    // B beats 1 (C's upper 0.4 < B's lower 0.5)
    // C beats 0
    //
    // For k=1: need to beat >= 2. Only A qualifies. Top-1 found.
    // For k=2: need to beat >= 1. A and B qualify. Top-2 found.
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.8, 0.9),
        mock_cs_with_bounds("b", 0.5, 0.7),
        mock_cs_with_bounds("c", 0.2, 0.4),
    ]
    .into_iter()
    .collect();

    // When k_min=1, k_max=2, should return k=2 (largest k that works)
    let result = check_topk_stopping(&variant_performance, None, 1, 2, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(2));
    assert_eq!(result.top_variants.len(), 2);

    // When k_min=1, k_max=1, should return k=1
    let result = check_topk_stopping(&variant_performance, None, 1, 1, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(1));
    assert_eq!(result.top_variants.len(), 1);
    assert!(result.top_variants.contains(&"a".to_string()));
}

/// Test that a single variant is trivially identified as top-1.
#[test]
fn test_check_topk_single_variant() {
    // Single variant - should be identified as top-1
    // It needs to beat >= (1 - 1) = 0 variants, which it does trivially
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_bounds("a", 0.5, 0.7)].into_iter().collect();

    let result = check_topk_stopping(&variant_performance, None, 1, 1, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(1));
    assert_eq!(result.top_variants, vec!["a".to_string()]);
}

/// Test that check_topk wrapper correctly calls check_topk_stopping with k_min = k_max.
#[test]
fn test_check_topk_wrapper() {
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.7, 0.9),
        mock_cs_with_bounds("b", 0.3, 0.5),
        mock_cs_with_bounds("c", 0.2, 0.4),
    ]
    .into_iter()
    .collect();

    let result = check_topk(&variant_performance, None, 1, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(1));
}

/// Test that epsilon tolerance enables top-1 stopping for nearly-separated intervals.
#[test]
fn test_check_topk_stopping_epsilon_enables_stopping() {
    // Variant A: [0.48, 0.7] - lower bound just below B's upper
    // Variant B: [0.3, 0.5] - upper bound at 0.5
    // Variant C: [0.2, 0.4] - clearly worse
    //
    // Without epsilon: A's lower (0.48) < B's upper (0.5), so A doesn't beat B
    // A only beats C (0.48 > 0.4), so num_beaten = 1
    // For top-1, need to beat >= 2, so no stopping
    //
    // With epsilon = 0.05: A beats B if 0.5 - 0.05 < 0.48, i.e., 0.45 < 0.48 ✓
    // A now beats both B and C, so top-1 is identified
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.48, 0.7),
        mock_cs_with_bounds("b", 0.3, 0.5),
        mock_cs_with_bounds("c", 0.2, 0.4),
    ]
    .into_iter()
    .collect();

    // Without epsilon, can't identify top-1
    let result = check_topk_stopping(&variant_performance, None, 1, 1, None).unwrap();
    assert!(!result.stopped);

    // With epsilon = 0.05, top-1 is identified
    let result = check_topk_stopping(&variant_performance, None, 1, 1, Some(0.05)).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(1));
    assert!(result.top_variants.contains(&"a".to_string()));
}

/// Test that epsilon tolerance enables identifying a larger top-k set.
#[test]
fn test_check_topk_stopping_epsilon_enables_larger_k() {
    // Variant A: [0.7, 0.9] - clearly best
    // Variant B: [0.48, 0.65] - B's lower (0.48) just below C's upper (0.5)
    // Variant C: [0.3, 0.5] - middle
    // Variant D: [0.1, 0.3] - clearly worst
    //
    // Without epsilon:
    // A beats 3 (all uppers < 0.7)
    // B beats 1 (only D's upper 0.3 < 0.48)
    // C beats 1 (only D's upper 0.3 < 0.3? No, 0.3 is not < 0.3)
    // Actually C's lower is 0.3, D's upper is 0.3, so C beats 0 (0.3 is not < 0.3)
    // For top-2, need to beat >= 2. Only A qualifies.
    //
    // With epsilon = 0.05:
    // B beats C if 0.5 - 0.05 < 0.48, i.e., 0.45 < 0.48 ✓
    // B beats D if 0.3 - 0.05 < 0.48, i.e., 0.25 < 0.48 ✓
    // So B now beats 2, qualifying for top-2
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.7, 0.9),
        mock_cs_with_bounds("b", 0.48, 0.65),
        mock_cs_with_bounds("c", 0.3, 0.5),
        mock_cs_with_bounds("d", 0.1, 0.3),
    ]
    .into_iter()
    .collect();

    // Without epsilon, can identify top-1 but not top-2
    let result = check_topk_stopping(&variant_performance, None, 1, 1, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(1));

    let result = check_topk_stopping(&variant_performance, None, 2, 2, None).unwrap();
    assert!(!result.stopped);

    // With epsilon = 0.05, can identify top-2
    let result = check_topk_stopping(&variant_performance, None, 2, 2, Some(0.05)).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(2));
    assert!(result.top_variants.contains(&"a".to_string()));
    assert!(result.top_variants.contains(&"b".to_string()));
}

/// Test that epsilon=0.0 behaves identically to epsilon=None.
#[test]
fn test_check_topk_stopping_epsilon_zero_same_as_none() {
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.7, 0.9),
        mock_cs_with_bounds("b", 0.3, 0.5),
        mock_cs_with_bounds("c", 0.2, 0.4),
    ]
    .into_iter()
    .collect();

    let result_none = check_topk_stopping(&variant_performance, None, 1, 2, None).unwrap();
    let result_zero = check_topk_stopping(&variant_performance, None, 1, 2, Some(0.0)).unwrap();

    assert_eq!(result_none.stopped, result_zero.stopped);
    assert_eq!(result_none.k, result_zero.k);
    // Note: top_variants order might differ, so just check same elements
    assert_eq!(
        result_none.top_variants.len(),
        result_zero.top_variants.len()
    );
}

/// Test that a very large epsilon makes all variants beat all others.
#[test]
fn test_check_topk_stopping_large_epsilon_all_beat_all() {
    // With a very large epsilon, every variant "beats" every other variant
    // (since ub - epsilon will be negative for any reasonable upper bound)
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.1, 0.2),
        mock_cs_with_bounds("b", 0.3, 0.4),
        mock_cs_with_bounds("c", 0.5, 0.6),
    ]
    .into_iter()
    .collect();

    // With epsilon = 1.0, all variants beat the other 2 variants
    // (a variant never counts itself as beaten)
    // For top-1, need >= 2. All qualify, so we get a top-3 (largest k checked first)
    let result = check_topk_stopping(&variant_performance, None, 1, 3, Some(1.0)).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(3));
    assert_eq!(result.top_variants.len(), 3);
}

/// Test that a variant never counts itself as beaten.
#[test]
fn test_check_topk_stopping_variant_does_not_beat_itself() {
    // With 2 variants and large epsilon, each variant beats the other but not itself.
    // So each variant beats exactly 1 other variant.
    // For top-1: need to beat >= 1. Both qualify.
    // For top-2: need to beat >= 0. Both qualify.
    // The key point: with epsilon=1.0, if variants counted themselves, they'd each
    // beat 2 variants and top-1 would be identified. But they shouldn't count themselves.
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.1, 0.2),
        mock_cs_with_bounds("b", 0.3, 0.4),
    ]
    .into_iter()
    .collect();

    // With epsilon = 1.0, each variant beats exactly 1 other (not itself)
    // For top-1, need to beat >= 1. Both qualify, so we get top-2.
    let result = check_topk_stopping(&variant_performance, None, 1, 2, Some(1.0)).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(2));
    assert_eq!(result.top_variants.len(), 2);

    // If variants incorrectly counted themselves, each would beat 2 variants,
    // and top-1 would be viable (need >= 1 beaten). Verify top-1 does NOT
    // incorrectly select just one variant.
    let result = check_topk_stopping(&variant_performance, None, 1, 1, Some(1.0)).unwrap();
    // Both variants beat exactly 1 other, so top-1 requires beating >= 1, which both do.
    // Since both qualify but we can only pick 1, this should still stop with k=1.
    // The important thing is the count is 1 (not 2).
    assert!(result.stopped);
    assert_eq!(result.k, Some(1));
}

/// Test that k_max caps the returned k, even when larger k values are viable.
#[test]
fn test_check_topk_stopping_returns_largest_viable_k() {
    // Variant A: [0.8, 0.95] - beats all 4 others
    // Variant B: [0.7, 0.85] - beats C, D, E (3 others)
    // Variant C: [0.5, 0.65] - beats D, E (2 others)
    // Variant D: [0.3, 0.45] - beats E (1 other)
    // Variant E: [0.1, 0.25] - beats none
    //
    // For top-1: need to beat >= 4. Only A qualifies.
    // For top-2: need to beat >= 3. A and B qualify.
    // For top-3: need to beat >= 2. A, B, C qualify.
    // For top-4: need to beat >= 1. A, B, C, D qualify.
    // For top-5: need to beat >= 0. All qualify.
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.8, 0.95),
        mock_cs_with_bounds("b", 0.7, 0.85),
        mock_cs_with_bounds("c", 0.5, 0.65),
        mock_cs_with_bounds("d", 0.3, 0.45),
        mock_cs_with_bounds("e", 0.1, 0.25),
    ]
    .into_iter()
    .collect();

    // k_min=1, k_max=5: should return k=5 (largest viable)
    let result = check_topk_stopping(&variant_performance, None, 1, 5, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(5));
    assert_eq!(result.top_variants.len(), 5);

    // k_min=1, k_max=3: should return k=3 (largest viable within range)
    let result = check_topk_stopping(&variant_performance, None, 1, 3, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(3));
    assert_eq!(result.top_variants.len(), 3);
    assert!(result.top_variants.contains(&"a".to_string()));
    assert!(result.top_variants.contains(&"b".to_string()));
    assert!(result.top_variants.contains(&"c".to_string()));

    // k_min=1, k_max=2: should return k=2
    let result = check_topk_stopping(&variant_performance, None, 1, 2, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(2));
    assert_eq!(result.top_variants.len(), 2);
    assert!(result.top_variants.contains(&"a".to_string()));
    assert!(result.top_variants.contains(&"b".to_string()));

    // k_min=2, k_max=4: should return k=4 (largest viable within range)
    let result = check_topk_stopping(&variant_performance, None, 2, 4, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(4));
    assert_eq!(result.top_variants.len(), 4);
}

/// Test that no stopping occurs when no k in the range is viable.
#[test]
fn test_check_topk_stopping_k_range_no_viable_k() {
    // Variant A: [0.4, 0.7]
    // Variant B: [0.35, 0.65]
    // Variant C: [0.3, 0.6]
    // All intervals overlap significantly - no one beats anyone
    //
    // For any k < 3, we need variants to beat others, but none do.
    // Only k=3 works (need to beat >= 0).
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.4, 0.7),
        mock_cs_with_bounds("b", 0.35, 0.65),
        mock_cs_with_bounds("c", 0.3, 0.6),
    ]
    .into_iter()
    .collect();

    // k_min=1, k_max=2: neither k=1 nor k=2 is viable, so no stopping
    let result = check_topk_stopping(&variant_performance, None, 1, 2, None).unwrap();
    assert!(!result.stopped);
    assert!(result.k.is_none());

    // k_min=1, k_max=3: k=3 is viable (all variants beat >= 0 others)
    let result = check_topk_stopping(&variant_performance, None, 1, 3, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(3));

    // k_min=3, k_max=3: k=3 is viable
    let result = check_topk_stopping(&variant_performance, None, 3, 3, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(3));
}

/// Test a "gap" scenario where k=1 and k=3 are viable but k=2 is not.
#[test]
fn test_check_topk_stopping_k_range_partial_viability() {
    // Variant A: [0.7, 0.9] - beats B and C
    // Variant B: [0.4, 0.6] - beats no one (C's upper 0.55 > B's lower 0.4)
    // Variant C: [0.35, 0.55] - beats no one
    //
    // A beats 2 (both uppers < 0.7)
    // B beats 0
    // C beats 0
    //
    // For top-1: need >= 2. Only A qualifies. ✓
    // For top-2: need >= 1. Only A qualifies (1 variant). ✗
    // For top-3: need >= 0. All qualify. ✓
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.7, 0.9),
        mock_cs_with_bounds("b", 0.4, 0.6),
        mock_cs_with_bounds("c", 0.35, 0.55),
    ]
    .into_iter()
    .collect();

    // k_min=1, k_max=3: k=3 is largest viable
    let result = check_topk_stopping(&variant_performance, None, 1, 3, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(3));

    // k_min=1, k_max=2: only k=1 is viable (k=2 fails)
    let result = check_topk_stopping(&variant_performance, None, 1, 2, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(1));
    assert_eq!(result.top_variants, vec!["a".to_string()]);

    // k_min=2, k_max=2: k=2 is not viable, no stopping
    let result = check_topk_stopping(&variant_performance, None, 2, 2, None).unwrap();
    assert!(!result.stopped);

    // k_min=2, k_max=3: k=3 is viable
    let result = check_topk_stopping(&variant_performance, None, 2, 3, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(3));
}

/// Test tiebreaking by mean_est when num_beaten is equal.
#[test]
fn test_check_topk_stopping_tiebreak_by_mean_est() {
    // With large epsilon, all variants beat all others (num_beaten = 2 for each)
    // Tiebreaker should be mean_est descending
    // Note: mock_cs_with_bounds sets mean_est = (cs_lower + cs_upper) / 2
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.1, 0.3), // mean_est = 0.2
        mock_cs_with_bounds("b", 0.4, 0.6), // mean_est = 0.5
        mock_cs_with_bounds("c", 0.7, 0.9), // mean_est = 0.8
    ]
    .into_iter()
    .collect();

    // With epsilon = 1.0, all beat all others
    // For top-1, should return "c" (highest mean_est)
    let result = check_topk_stopping(&variant_performance, None, 1, 1, Some(1.0)).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(1));
    assert_eq!(result.top_variants.len(), 1);
    assert!(result.top_variants.contains(&"c".to_string()));

    // For top-2, should return "c" and "b" (top two by mean_est)
    let result = check_topk_stopping(&variant_performance, None, 2, 2, Some(1.0)).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(2));
    assert_eq!(result.top_variants.len(), 2);
    assert!(result.top_variants.contains(&"c".to_string()));
    assert!(result.top_variants.contains(&"b".to_string()));
}

/// Test tiebreaking by cs_lower when mean_est is equal.
#[test]
fn test_check_topk_stopping_tiebreak_by_cs_lower() {
    // Create variants with same mean_est but different cs_lower
    // mean_est = (cs_lower + cs_upper) / 2, so we need to adjust both bounds
    let mut variant_performance: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

    // All have mean_est = 0.5, but different cs_lower
    let (name_a, mut cs_a) = mock_cs_with_bounds("a", 0.3, 0.7); // mean_est = 0.5, cs_lower = 0.3
    cs_a.mean_est = 0.5;
    variant_performance.insert(name_a, cs_a);

    let (name_b, mut cs_b) = mock_cs_with_bounds("b", 0.4, 0.6); // mean_est = 0.5, cs_lower = 0.4
    cs_b.mean_est = 0.5;
    variant_performance.insert(name_b, cs_b);

    let (name_c, mut cs_c) = mock_cs_with_bounds("c", 0.2, 0.8); // mean_est = 0.5, cs_lower = 0.2
    cs_c.mean_est = 0.5;
    variant_performance.insert(name_c, cs_c);

    // With epsilon = 1.0, all beat all others
    // For top-1, should return "b" (highest cs_lower since mean_est is tied)
    let result = check_topk_stopping(&variant_performance, None, 1, 1, Some(1.0)).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(1));
    assert_eq!(result.top_variants.len(), 1);
    assert!(result.top_variants.contains(&"b".to_string()));
}

/// Test that identical variants at the k boundary cause an enlarged result set.
#[test]
fn test_check_topk_stopping_ties_at_boundary_enlarges_set() {
    // Create 4 variants: one clear winner, then 3 identical variants
    let mut variant_performance: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

    // Clear winner
    let (name_a, cs_a) = mock_cs_with_bounds("a", 0.8, 0.9);
    variant_performance.insert(name_a, cs_a);

    // Three identical variants (same bounds, same mean_est)
    let (name_b, cs_b) = mock_cs_with_bounds("b", 0.4, 0.6);
    variant_performance.insert(name_b, cs_b);

    let (name_c, cs_c) = mock_cs_with_bounds("c", 0.4, 0.6);
    variant_performance.insert(name_c, cs_c);

    let (name_d, cs_d) = mock_cs_with_bounds("d", 0.4, 0.6);
    variant_performance.insert(name_d, cs_d);

    // With epsilon = 1.0, all beat all others (num_beaten = 3 each)
    // For top-2: "a" is clearly first, but b/c/d are tied for second
    // Should return all 4 variants (enlarged set)
    let result = check_topk_stopping(&variant_performance, None, 2, 2, Some(1.0)).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(2));
    assert_eq!(result.top_variants.len(), 4); // Enlarged due to ties
    assert!(result.top_variants.contains(&"a".to_string()));
    assert!(result.top_variants.contains(&"b".to_string()));
    assert!(result.top_variants.contains(&"c".to_string()));
    assert!(result.top_variants.contains(&"d".to_string()));
}

/// Test that non-identical variants at the k boundary do NOT enlarge the set.
#[test]
fn test_check_topk_stopping_no_ties_at_boundary() {
    // Create 4 variants with distinct mean_est values
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.7, 0.9), // mean_est = 0.8
        mock_cs_with_bounds("b", 0.5, 0.7), // mean_est = 0.6
        mock_cs_with_bounds("c", 0.3, 0.5), // mean_est = 0.4
        mock_cs_with_bounds("d", 0.1, 0.3), // mean_est = 0.2
    ]
    .into_iter()
    .collect();

    // With epsilon = 1.0, all beat all others
    // For top-2, should return exactly 2 variants (a and b by mean_est)
    let result = check_topk_stopping(&variant_performance, None, 2, 2, Some(1.0)).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(2));
    assert_eq!(result.top_variants.len(), 2); // No enlargement
    assert!(result.top_variants.contains(&"a".to_string()));
    assert!(result.top_variants.contains(&"b".to_string()));
}

/// Test identical variants (all have same bounds).
#[test]
fn test_check_topk_stopping_all_identical_variants() {
    // All variants have identical confidence sequences
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.4, 0.6),
        mock_cs_with_bounds("b", 0.4, 0.6),
        mock_cs_with_bounds("c", 0.4, 0.6),
    ]
    .into_iter()
    .collect();

    // With epsilon = 0, no one beats anyone (intervals are identical)
    // Only k=3 is viable (need to beat >= 0)
    let result = check_topk_stopping(&variant_performance, None, 1, 3, None).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(3));
    assert_eq!(result.top_variants.len(), 3);

    // With epsilon = 1.0, all beat all others, but for top-1, all are tied
    // Should return all 3 (enlarged set)
    let result = check_topk_stopping(&variant_performance, None, 1, 1, Some(1.0)).unwrap();
    assert!(result.stopped);
    assert_eq!(result.k, Some(1));
    assert_eq!(result.top_variants.len(), 3); // All tied
}

/// Test that check_topk_stopping filters out failed variants.
///
/// Without filtering, variant "a" (failed) would be in top-1 since it has the
/// highest confidence bounds. With filtering, only "b" (the best non-failed variant)
/// should be returned.
#[test]
fn test_check_topk_stopping_filters_failed_variants() {
    // "a" has the best bounds but is Failed
    // "b" is Active and should be the top-1 after filtering
    // "c" is Active but has worse bounds than "b"
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("a", 0.8, 0.95), // Best bounds, but will be Failed
        mock_cs_with_bounds("b", 0.6, 0.75), // Second best, Active
        mock_cs_with_bounds("c", 0.3, 0.5),  // Worst, Active
    ]
    .into_iter()
    .collect();

    let variant_status: HashMap<String, VariantStatus> = [
        ("a".to_string(), VariantStatus::Failed),
        ("b".to_string(), VariantStatus::Active),
        ("c".to_string(), VariantStatus::Active),
    ]
    .into_iter()
    .collect();

    // Without filtering (variant_status = None), "a" would be top-1
    let result_unfiltered = check_topk_stopping(&variant_performance, None, 1, 1, None).unwrap();
    assert!(result_unfiltered.stopped);
    assert_eq!(result_unfiltered.top_variants, vec!["a".to_string()]);

    // With filtering, "a" is excluded and "b" becomes top-1
    let result_filtered =
        check_topk_stopping(&variant_performance, Some(&variant_status), 1, 1, None).unwrap();
    assert!(result_filtered.stopped);
    assert_eq!(result_filtered.top_variants, vec!["b".to_string()]);
}

// ============================================================================
// Tests for update_variant_statuses
// ============================================================================

/// Test that already-stopped variants (non-Active) are skipped and not modified.
#[test]
fn test_update_variant_statuses_skips_non_active() {
    let mut variant_status: HashMap<String, VariantStatus> = [
        ("active".to_string(), VariantStatus::Active),
        ("stopped".to_string(), VariantStatus::Stopped),
        ("failed".to_string(), VariantStatus::Failed),
    ]
    .into_iter()
    .collect();

    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("active", 0.5, 0.7),
        mock_cs_with_bounds("stopped", 0.5, 0.7),
        mock_cs_with_bounds("failed", 0.5, 0.7),
    ]
    .into_iter()
    .collect();

    let variant_failures: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

    let params = VariantStatusParams {
        k_min: 1,
        k_max: 1,
        epsilon: 0.0,
        variant_failure_threshold: 1.0, // Disabled
    };
    update_variant_statuses(
        &mut variant_status,
        &variant_performance,
        &variant_failures,
        &params,
    );

    // Non-active variants should remain unchanged
    assert_eq!(variant_status["stopped"], VariantStatus::Stopped);
    assert_eq!(variant_status["failed"], VariantStatus::Failed);
    // Active variant should still be active (no early stopping with single variant logic)
    assert_eq!(variant_status["active"], VariantStatus::Active);
}

/// Test that variants are marked as Failed when failure rate exceeds threshold.
#[test]
fn test_update_variant_statuses_marks_failed() {
    let mut variant_status: HashMap<String, VariantStatus> = [
        ("high_failure".to_string(), VariantStatus::Active),
        ("low_failure".to_string(), VariantStatus::Active),
    ]
    .into_iter()
    .collect();

    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("high_failure", 0.5, 0.7),
        mock_cs_with_bounds("low_failure", 0.5, 0.7),
    ]
    .into_iter()
    .collect();

    // high_failure has cs_lower = 0.1 (above 0.05 threshold)
    // low_failure has cs_lower = 0.02 (below 0.05 threshold)
    let variant_failures: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("high_failure", 0.1, 0.2), // cs_lower = 0.1 > 0.05
        mock_cs_with_bounds("low_failure", 0.02, 0.04), // cs_lower = 0.02 < 0.05
    ]
    .into_iter()
    .collect();

    let params = VariantStatusParams {
        k_min: 1,
        k_max: 1,
        epsilon: 0.0,
        variant_failure_threshold: 0.05,
    };
    update_variant_statuses(
        &mut variant_status,
        &variant_performance,
        &variant_failures,
        &params,
    );

    assert_eq!(variant_status["high_failure"], VariantStatus::Failed);
    // "low_failure" is the only non-failed variant, so it gets early stopping
    assert_eq!(variant_status["low_failure"], VariantStatus::Stopped);
}

/// Test early stopping when variant is confidently excluded from top-k.
///
/// A variant gets stopped when its upper bound is below k_max others' lower bounds,
/// meaning it cannot be in the top k_max.
#[test]
fn test_update_variant_statuses_early_stopping_exclusion() {
    let mut variant_status: HashMap<String, VariantStatus> = [
        ("good_a".to_string(), VariantStatus::Active),
        ("good_b".to_string(), VariantStatus::Active),
        ("bad".to_string(), VariantStatus::Active),
    ]
    .into_iter()
    .collect();

    // "bad" has upper bound 0.4, while "good_a" and "good_b" have lower bounds 0.5 and 0.6
    // So 2 variants are definitely better than "bad"
    // With k_max=2, "bad" cannot be in top-2 and should be stopped (excluded from top-k)
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("good_a", 0.5, 0.7), // cs_lower = 0.5 > bad's cs_upper
        mock_cs_with_bounds("good_b", 0.6, 0.8), // cs_lower = 0.6 > bad's cs_upper
        mock_cs_with_bounds("bad", 0.2, 0.4),    // cs_upper = 0.4 < both others' cs_lower
    ]
    .into_iter()
    .collect();

    let variant_failures: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

    let params = VariantStatusParams {
        k_min: 1,
        k_max: 2,
        epsilon: 0.05, // Non-zero epsilon; intervals are well-separated so doesn't affect outcome
        variant_failure_threshold: 1.0, // Disabled
    };
    update_variant_statuses(
        &mut variant_status,
        &variant_performance,
        &variant_failures,
        &params,
    );

    // "bad" should be stopped because 2 variants are definitely better
    // and k_max = 2, so "bad" cannot be in top-2
    assert_eq!(variant_status["bad"], VariantStatus::Stopped);
    // good_a and good_b should still be active (neither meets early stopping criteria)
    assert_eq!(variant_status["good_a"], VariantStatus::Active);
    assert_eq!(variant_status["good_b"], VariantStatus::Active);
}

/// Test that early stopping does NOT happen when fewer than k_max variants are definitely better.
#[test]
fn test_update_variant_statuses_no_early_stopping_when_uncertain() {
    let mut variant_status: HashMap<String, VariantStatus> = [
        ("good".to_string(), VariantStatus::Active),
        ("uncertain".to_string(), VariantStatus::Active),
        ("bad".to_string(), VariantStatus::Active),
    ]
    .into_iter()
    .collect();

    // "bad" has upper bound 0.4
    // Only "good" (cs_lower = 0.5) is definitely better
    // "uncertain" overlaps with "bad"
    // With k_max=2, we need 2 variants definitely better to stop "bad" (exclude from top-k)
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("good", 0.5, 0.7), // definitely better than bad
        mock_cs_with_bounds("uncertain", 0.3, 0.6), // overlaps with bad
        mock_cs_with_bounds("bad", 0.2, 0.4),
    ]
    .into_iter()
    .collect();

    let variant_failures: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

    let params = VariantStatusParams {
        k_min: 1,
        k_max: 2,
        epsilon: 0.0,
        variant_failure_threshold: 1.0, // Disabled
    };
    update_variant_statuses(
        &mut variant_status,
        &variant_performance,
        &variant_failures,
        &params,
    );

    assert_eq!(variant_status["bad"], VariantStatus::Active);
    assert_eq!(variant_status["good"], VariantStatus::Active);
    assert_eq!(variant_status["uncertain"], VariantStatus::Active);
}

/// Test that failure check takes priority over early stopping.
///
/// Even if a variant has great performance, if its failure rate exceeds the threshold,
/// it should be marked as Failed (not Stopped).
#[test]
fn test_update_variant_statuses_failure_takes_priority() {
    let mut variant_status: HashMap<String, VariantStatus> = [
        ("best_but_failing".to_string(), VariantStatus::Active),
        ("healthy".to_string(), VariantStatus::Active),
    ]
    .into_iter()
    .collect();

    // "best_but_failing" has the best performance bounds
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("best_but_failing", 0.7, 0.9),
        mock_cs_with_bounds("healthy", 0.3, 0.5),
    ]
    .into_iter()
    .collect();

    // "best_but_failing" has high failure rate
    let variant_failures: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("best_but_failing", 0.1, 0.2), // cs_lower = 0.1 > 0.05 threshold
        mock_cs_with_bounds("healthy", 0.02, 0.04),        // cs_lower = 0.02 < 0.05 threshold
    ]
    .into_iter()
    .collect();

    let params = VariantStatusParams {
        k_min: 1,
        k_max: 1,
        epsilon: 0.0,
        variant_failure_threshold: 0.05,
    };
    update_variant_statuses(
        &mut variant_status,
        &variant_performance,
        &variant_failures,
        &params,
    );

    // "best_but_failing" should be Failed despite having best performance
    assert_eq!(variant_status["best_but_failing"], VariantStatus::Failed);
    // "healthy" is the only non-failed variant, so it gets early stopping
    assert_eq!(variant_status["healthy"], VariantStatus::Stopped);
}

/// Test that update_variant_statuses filters out failed variants when computing early stopping.
///
/// Scenario: 4 variants with k_min=1, k_max=2
/// - "good_a" and "good_b" are clearly better than "bad_a" and "bad_b"
/// - "good_a" and "good_b" have overlapping bounds (indistinguishable)
/// - "bad_a" and "bad_b" have overlapping bounds (indistinguishable)
///
/// Without any failures:
/// - "good_a" and "good_b" stay Active (neither can prove it beats the other)
/// - "bad_a" and "bad_b" get Stopped (excluded from top-k: 2 variants are definitely better, k_max=2)
///
/// Then "good_a" fails:
/// - "good_b" gets Stopped (included in top-k: beats 2 others, needs >= 2 for k_min=1)
/// - "bad_a" and "bad_b" stay Active (only 1 non-failed variant is better, need 2 for exclusion)
#[test]
fn test_update_variant_statuses_filters_failed_variants() {
    // Setup: 4 variants, 2 good (distinguishable from bad), 2 bad (indistinguishable from each other)
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_bounds("good_a", 0.7, 0.9),
        mock_cs_with_bounds("good_b", 0.6, 0.8),
        mock_cs_with_bounds("bad_a", 0.2, 0.4),
        mock_cs_with_bounds("bad_b", 0.25, 0.45),
    ]
    .into_iter()
    .collect();

    let variant_failures: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

    let params = VariantStatusParams {
        k_min: 1,
        k_max: 2,
        epsilon: 0.0,
        variant_failure_threshold: 1.0, // Disabled
    };

    // Test 1: No failures - good variants stay Active, bad variants get Stopped (excluded from top-k)
    let mut variant_status: HashMap<String, VariantStatus> = [
        ("good_a".to_string(), VariantStatus::Active),
        ("good_b".to_string(), VariantStatus::Active),
        ("bad_a".to_string(), VariantStatus::Active),
        ("bad_b".to_string(), VariantStatus::Active),
    ]
    .into_iter()
    .collect();

    update_variant_statuses(
        &mut variant_status,
        &variant_performance,
        &variant_failures,
        &params,
    );

    // Good variants stay Active (neither beats the other for early stopping)
    assert_eq!(variant_status["good_a"], VariantStatus::Active);
    assert_eq!(variant_status["good_b"], VariantStatus::Active);
    // Bad variants get Stopped (2 variants are definitely better, k_max=2)
    assert_eq!(variant_status["bad_a"], VariantStatus::Stopped);
    assert_eq!(variant_status["bad_b"], VariantStatus::Stopped);

    // Test 2: good_a fails - good_b gets Stopped, bad variants stay Active
    let mut variant_status: HashMap<String, VariantStatus> = [
        ("good_a".to_string(), VariantStatus::Failed),
        ("good_b".to_string(), VariantStatus::Active),
        ("bad_a".to_string(), VariantStatus::Active),
        ("bad_b".to_string(), VariantStatus::Active),
    ]
    .into_iter()
    .collect();

    update_variant_statuses(
        &mut variant_status,
        &variant_performance,
        &variant_failures,
        &params,
    );

    // good_a stays Failed
    assert_eq!(variant_status["good_a"], VariantStatus::Failed);
    // good_b gets Stopped: beats 2 others (bad_a, bad_b), needs >= (3 - 1) = 2
    assert_eq!(variant_status["good_b"], VariantStatus::Stopped);
    // Bad variants stay Active: only 1 non-failed variant (good_b) is better, need 2 for early stopping
    assert_eq!(variant_status["bad_a"], VariantStatus::Active);
    assert_eq!(variant_status["bad_b"], VariantStatus::Active);
}

/// Test that failure check doesn't trigger when disabled or when failure CS is missing.
///
/// Two sub-cases:
/// 1. Failure threshold disabled (set to 1.0) - failure check never triggers
/// 2. Missing failure CS - failure check doesn't apply
#[test]
fn test_update_variant_statuses_failure_check_skipped() {
    // === Sub-case 1: Failure threshold disabled ===
    {
        let mut variant_status: HashMap<String, VariantStatus> =
            [("high_failure".to_string(), VariantStatus::Active)]
                .into_iter()
                .collect();

        let variant_performance: HashMap<String, MeanBettingConfidenceSequence> =
            [mock_cs_with_bounds("high_failure", 0.5, 0.7)]
                .into_iter()
                .collect();

        // High failure rate (cs_lower = 0.5), but threshold is disabled
        let variant_failures: HashMap<String, MeanBettingConfidenceSequence> =
            [mock_cs_with_bounds("high_failure", 0.5, 0.7)] // cs_lower = 0.5
                .into_iter()
                .collect();

        let params = VariantStatusParams {
            k_min: 1,
            k_max: 1,
            epsilon: 0.0,
            variant_failure_threshold: 1.0, // Disabled - failure rate can never exceed 1.0
        };
        update_variant_statuses(
            &mut variant_status,
            &variant_performance,
            &variant_failures,
            &params,
        );

        // With threshold disabled (1.0), failure check never triggers.
        // Single variant with k_min=1 triggers early stopping (beats >= 0 others).
        assert_eq!(variant_status["high_failure"], VariantStatus::Stopped);
    }

    // === Sub-case 2: Missing failure CS ===
    {
        let mut variant_status: HashMap<String, VariantStatus> =
            [("variant".to_string(), VariantStatus::Active)]
                .into_iter()
                .collect();

        let variant_performance: HashMap<String, MeanBettingConfidenceSequence> =
            [mock_cs_with_bounds("variant", 0.5, 0.7)]
                .into_iter()
                .collect();

        // No failure CS for "variant"
        let variant_failures: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

        let params = VariantStatusParams {
            k_min: 1,
            k_max: 1,
            epsilon: 0.0,
            variant_failure_threshold: 0.05,
        };
        update_variant_statuses(
            &mut variant_status,
            &variant_performance,
            &variant_failures,
            &params,
        );

        // Without failure CS, failure check doesn't apply.
        // Single variant with k_min=1 triggers early stopping
        assert_eq!(variant_status["variant"], VariantStatus::Stopped);
    }
}

/// Test that variants not in variant_failures map are not marked as failed.
#[test]
fn test_update_variant_statuses_missing_failure_cs() {
    let mut variant_status: HashMap<String, VariantStatus> =
        [("variant".to_string(), VariantStatus::Active)]
            .into_iter()
            .collect();

    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_bounds("variant", 0.5, 0.7)]
            .into_iter()
            .collect();

    // No failure CS for "variant"
    let variant_failures: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

    let params = VariantStatusParams {
        k_min: 1,
        k_max: 1,
        epsilon: 0.0,
        variant_failure_threshold: 0.05,
    };
    update_variant_statuses(
        &mut variant_status,
        &variant_performance,
        &variant_failures,
        &params,
    );

    // Without failure CS, failure check doesn't apply.
    // Single variant with k_min=1 triggers inclusion
    assert_eq!(variant_status["variant"], VariantStatus::Stopped);
}

/// Test that variants not in variant_performance map don't cause errors in early stopping.
#[test]
fn test_update_variant_statuses_missing_performance_cs() {
    let mut variant_status: HashMap<String, VariantStatus> =
        [("variant".to_string(), VariantStatus::Active)]
            .into_iter()
            .collect();

    // No performance CS for "variant"
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();
    let variant_failures: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

    let params = VariantStatusParams {
        k_min: 1,
        k_max: 1,
        epsilon: 0.0,
        variant_failure_threshold: 1.0, // Disabled
    };
    update_variant_statuses(
        &mut variant_status,
        &variant_performance,
        &variant_failures,
        &params,
    );

    // Without performance CS, early stopping check doesn't apply
    assert_eq!(variant_status["variant"], VariantStatus::Active);
}

/// Test that epsilon tolerance enables early stopping for nearly-separated intervals.
///
/// Two sub-cases:
/// 1. Epsilon enables stopping for poor performance (variant's upper bound nearly below others' lower bounds)
/// 2. Epsilon enables stopping for good performance (variant's lower bound nearly above others' upper bounds)
#[test]
fn test_update_variant_statuses_epsilon_enables_stopping() {
    // === Sub-case 1: Epsilon enables stopping for poor performance ===
    // "worst" has upper bound 0.505, "best" has lower bound 0.595, "mid" has lower bound 0.5
    // Without epsilon: 0.505 < 0.5 is false, so "worst" doesn't get stopped
    // With epsilon = 0.01: 0.505 < 0.5 + 0.01 = 0.51 is true, so stopping triggers
    {
        let mut variant_status: HashMap<String, VariantStatus> = [
            ("best".to_string(), VariantStatus::Active),
            ("mid".to_string(), VariantStatus::Active),
            ("worst".to_string(), VariantStatus::Active),
        ]
        .into_iter()
        .collect();

        let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
            mock_cs_with_bounds("best", 0.595, 0.7),
            mock_cs_with_bounds("mid", 0.5, 0.6),
            mock_cs_with_bounds("worst", 0.3, 0.505),
        ]
        .into_iter()
        .collect();

        let variant_failures: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

        // Without epsilon, "worst" and "mid" both stay Active, "best" gets early stopping
        let params_no_epsilon = VariantStatusParams {
            k_min: 2,
            k_max: 2,
            epsilon: 0.0,
            variant_failure_threshold: 1.0, // Disabled
        };
        update_variant_statuses(
            &mut variant_status,
            &variant_performance,
            &variant_failures,
            &params_no_epsilon,
        );

        assert_eq!(variant_status["worst"], VariantStatus::Active);
        assert_eq!(variant_status["mid"], VariantStatus::Active);
        assert_eq!(variant_status["best"], VariantStatus::Stopped);

        // Reset for epsilon test
        *variant_status.get_mut("best").unwrap() = VariantStatus::Active;

        // With epsilon = 0.01, "worst" should be stopped
        let params_with_epsilon = VariantStatusParams {
            k_min: 2,
            k_max: 2,
            epsilon: 0.01,
            variant_failure_threshold: 1.0, // Disabled
        };
        update_variant_statuses(
            &mut variant_status,
            &variant_performance,
            &variant_failures,
            &params_with_epsilon,
        );

        assert_eq!(variant_status["worst"], VariantStatus::Stopped);
        assert_eq!(variant_status["mid"], VariantStatus::Stopped);
        assert_eq!(variant_status["best"], VariantStatus::Stopped);
    }

    // === Sub-case 2: Epsilon enables stopping for good performance ===
    // "best" has lower bound 0.499, "worst" has upper bound 0.5
    // Without epsilon: 0.499 > 0.5 is false, so "best" doesn't beat "worst"
    // With epsilon = 0.01: 0.499 > 0.5 - 0.01 = 0.49 is true, so "best" beats "worst"
    {
        let mut variant_status: HashMap<String, VariantStatus> = [
            ("best".to_string(), VariantStatus::Active),
            ("worst".to_string(), VariantStatus::Active),
        ]
        .into_iter()
        .collect();

        let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
            mock_cs_with_bounds("best", 0.499, 0.7),
            mock_cs_with_bounds("worst", 0.3, 0.5),
        ]
        .into_iter()
        .collect();

        let variant_failures: HashMap<String, MeanBettingConfidenceSequence> = HashMap::new();

        // Without epsilon, "best" stays Active (0.499 is not > 0.5)
        let params_no_epsilon = VariantStatusParams {
            k_min: 1,
            k_max: 1,
            epsilon: 0.0,
            variant_failure_threshold: 1.0, // Disabled
        };
        update_variant_statuses(
            &mut variant_status,
            &variant_performance,
            &variant_failures,
            &params_no_epsilon,
        );

        assert_eq!(variant_status["best"], VariantStatus::Active);
        assert_eq!(variant_status["worst"], VariantStatus::Active);

        // Reset for epsilon test
        *variant_status.get_mut("best").unwrap() = VariantStatus::Active;
        *variant_status.get_mut("worst").unwrap() = VariantStatus::Active;

        // With epsilon = 0.01, both should get stopped
        let params_with_epsilon = VariantStatusParams {
            k_min: 1,
            k_max: 1,
            epsilon: 0.01,
            variant_failure_threshold: 1.0, // Disabled
        };
        update_variant_statuses(
            &mut variant_status,
            &variant_performance,
            &variant_failures,
            &params_with_epsilon,
        );

        assert_eq!(variant_status["best"], VariantStatus::Stopped);
        assert_eq!(variant_status["worst"], VariantStatus::Stopped);
    }
}

// ============================================================================
// Tests for check_global_stopping
// ============================================================================

#[test]
fn test_check_global_stopping_none_when_running() {
    let names = vec!["a", "b", "c", "d", "e"];
    let params = default_params_with_variants(names.clone());
    let progress = empty_progress(&names);
    // With five variants all sharing overlapping CS intervals, none can prove it beats two others,
    // so check_global_stopping should report that we're still running.
    let reason = check_global_stopping(&progress, &params);
    assert!(reason.is_none());
}

#[test]
// Check that the top-k stopping condition triggers and takes precedence over evaluator and variant failures
fn test_check_global_stopping_prefers_topk() {
    let variant_names = vec!["a", "b", "c", "d"];
    let params = default_params_with_variants(variant_names.clone());
    let mut progress = empty_progress(&variant_names);
    progress.variant_status = [
        ("a".to_string(), VariantStatus::Active),
        ("b".to_string(), VariantStatus::Active),
        ("c".to_string(), VariantStatus::Failed),
        ("d".to_string(), VariantStatus::Failed),
    ]
    .into_iter()
    .collect();
    progress.variant_performance = [
        mock_cs_with_bounds("a", 0.7, 0.9),
        mock_cs_with_bounds("b", 0.6, 0.8),
        mock_cs_with_bounds("c", 0.3, 0.5),
        mock_cs_with_bounds("d", 0.2, 0.4),
    ]
    .into_iter()
    .collect();
    progress.evaluator_failures = [("eval1".to_string(), mock_cs_with_bounds("eval1", 0.3, 0.4))]
        .into_iter()
        .map(|(name, (_, cs))| (name, cs))
        .collect();

    // Variants "a" and "b" both beat the remaining two variants, so the algorithm should stop with
    // k=2 before considering evaluator failures or the too-many-variant-failures condition.
    let reason = check_global_stopping(&progress, &params);
    match reason {
        Some(GlobalStoppingReason::TopKFound { k, top_variants }) => {
            assert_eq!(k, 2);
            assert_eq!(top_variants, vec!["a".to_string(), "b".to_string()]);
        }
        other => panic!("expected TopKFound, got {other:?}"),
    }
}

/// Test that check_global_stopping filters out failed variants when checking TopKFound.
///
/// This test verifies that a failed variant with the best performance doesn't
/// incorrectly trigger TopKFound. Instead, the algorithm should only consider
/// non-failed variants.
#[test]
fn test_check_global_stopping_filters_failed_variants() {
    let variant_names = vec!["a", "b", "c"];
    let mut params = default_params_with_variants(variant_names.clone());
    params.k_min = 1;
    params.k_max = 1;

    let mut progress = empty_progress(&variant_names);

    // "a" has the best bounds but is Failed
    // "b" is Active and clearly beats "c", so top-1 should be found among non-failed
    progress.variant_performance = [
        mock_cs_with_bounds("a", 0.9, 0.99), // Best bounds, but Failed
        mock_cs_with_bounds("b", 0.7, 0.8),  // Second best, Active - beats "c"
        mock_cs_with_bounds("c", 0.3, 0.5),  // Worst, Active
    ]
    .into_iter()
    .collect();

    progress.variant_status = [
        ("a".to_string(), VariantStatus::Failed),
        ("b".to_string(), VariantStatus::Active),
        ("c".to_string(), VariantStatus::Active),
    ]
    .into_iter()
    .collect();

    // Should find top-1 as "b" (not "a" which is failed)
    let reason = check_global_stopping(&progress, &params);
    match reason {
        Some(GlobalStoppingReason::TopKFound { k, top_variants }) => {
            assert_eq!(k, 1);
            assert_eq!(top_variants, vec!["b".to_string()]);
        }
        other => panic!("expected TopKFound with variant 'b', got {other:?}"),
    }
}

#[test]
// Check that the evaluator failure condition triggers and takes precedence over variant failures
fn test_check_global_stopping_evaluators_failed() {
    let variant_names = vec!["a", "b", "c", "d"];
    let params = default_params_with_variants(variant_names.clone());
    // params uses default evaluator_failure_threshold = 0.05
    let mut progress = empty_progress(&variant_names);
    progress.variant_status = [
        ("a".to_string(), VariantStatus::Failed),
        ("b".to_string(), VariantStatus::Failed),
        ("c".to_string(), VariantStatus::Failed),
        ("d".to_string(), VariantStatus::Active),
    ]
    .into_iter()
    .collect();
    progress.evaluator_failures = [
        (
            "eval_one".to_string(),
            mock_cs_with_bounds("eval_one", 0.1, 0.15), // cs_lower = 0.1 > 0.05
        ),
        (
            "eval_two".to_string(),
            mock_cs_with_bounds("eval_two", 0.2, 0.3), // cs_lower = 0.2 > 0.05
        ),
    ]
    .into_iter()
    .map(|(name, (_, cs))| (name, cs))
    .collect();
    progress.variant_performance = variant_names
        .iter()
        .map(|name| {
            let (_, cs) = mock_cs_with_bounds(name, 0.4, 0.6);
            ((*name).to_string(), cs)
        })
        .collect();

    // Both evaluator failure rates exceed 0.05, so EvaluatorsFailed should win even though too many
    // variants have also failed.
    let reason = check_global_stopping(&progress, &params);
    match reason {
        Some(GlobalStoppingReason::EvaluatorsFailed { evaluator_names }) => {
            let mut names = evaluator_names.clone();
            names.sort();
            assert_eq!(names, vec!["eval_one".to_string(), "eval_two".to_string()]);
        }
        other => panic!("expected EvaluatorsFailed, got {other:?}"),
    }
}

#[test]
// Check that the too-many-variant-failures condition triggers
fn test_check_global_stopping_too_many_variant_failures() {
    let variant_names = vec!["a", "b", "c", "d"];
    let mut params = default_params_with_variants(variant_names.clone());
    params.k_min = 2;
    let mut progress = empty_progress(&variant_names);
    progress.variant_status = [
        ("a".to_string(), VariantStatus::Failed),
        ("b".to_string(), VariantStatus::Failed),
        ("c".to_string(), VariantStatus::Failed),
        ("d".to_string(), VariantStatus::Active),
    ]
    .into_iter()
    .collect();
    progress.variant_performance = variant_names
        .iter()
        .map(|name| {
            let (_, cs) = mock_cs_with_bounds(name, 0.4, 0.6);
            ((*name).to_string(), cs)
        })
        .collect();

    // With k_min=2 and three variants failed, only one remains active, triggering
    // TooManyVariantsFailed (3 > 4 - k_min).
    let reason = check_global_stopping(&progress, &params);
    match reason {
        Some(GlobalStoppingReason::TooManyVariantsFailed { num_failed }) => {
            assert_eq!(num_failed, 3);
        }
        other => panic!("expected TooManyVariantsFailed, got {other:?}"),
    }
}

// ============================================================================
// Tests for hedge weight functions
// ============================================================================

/// Helper to create a confidence sequence with specified count and mean_est.
fn mock_cs_with_count_and_mean(
    name: &str,
    count: u64,
    mean_est: f64,
) -> (String, MeanBettingConfidenceSequence) {
    (
        name.to_string(),
        MeanBettingConfidenceSequence {
            name: name.to_string(),
            mean_regularized: mean_est,
            variance_regularized: 0.1,
            count,
            mean_est,
            cs_lower: mean_est - 0.1,
            cs_upper: mean_est + 0.1,
            alpha: 0.05,
            wealth: WealthProcesses {
                grid: WealthProcessGridPoints::Resolution(101),
                wealth_upper: vec![1.0; 101],
                wealth_lower: vec![1.0; 101],
            },
        },
    )
}

/// Test get_rank_based_hedge_weight assigns correct weights based on rank relative to k_min/k_max.
#[test]
fn test_get_rank_based_hedge_weight() {
    // k_min = 2, k_max = 4: rank < 2 gets 0.8, rank >= 4 gets 0.2, else 0.5
    assert_eq!(get_rank_based_hedge_weight(0, 2, 4), 0.8);
    assert_eq!(get_rank_based_hedge_weight(1, 2, 4), 0.8);
    assert_eq!(get_rank_based_hedge_weight(2, 2, 4), 0.5);
    assert_eq!(get_rank_based_hedge_weight(3, 2, 4), 0.5);
    assert_eq!(get_rank_based_hedge_weight(4, 2, 4), 0.2);
    assert_eq!(get_rank_based_hedge_weight(5, 2, 4), 0.2);
    assert_eq!(get_rank_based_hedge_weight(10, 2, 4), 0.2);

    // k_min = k_max = 2: rank < 2 gets 0.8, rank >= 2 gets 0.2, no middle
    assert_eq!(get_rank_based_hedge_weight(1, 2, 2), 0.8);
    assert_eq!(get_rank_based_hedge_weight(2, 2, 2), 0.2);
}

/// Test that compute_hedge_weights returns None when any variant is below MIN_SAMPLES_FOR_REBALANCING.
#[test]
fn test_compute_hedge_weights_threshold() {
    // Below threshold: returns None
    let below_threshold: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_count_and_mean("a", 19, 0.8),
        mock_cs_with_count_and_mean("b", 19, 0.6),
    ]
    .into_iter()
    .collect();
    assert_eq!(compute_hedge_weights(&below_threshold, 1, 2), None);

    // At threshold: returns weights (k_min=1, k_max=2: rank < 1 gets 0.8, rank >= 2 gets 0.2)
    let at_threshold: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_count_and_mean("a", 20, 0.8), // Rank 0 (< k_min)
        mock_cs_with_count_and_mean("b", 20, 0.6), // Rank 1 (middle)
    ]
    .into_iter()
    .collect();
    let weights = compute_hedge_weights(&at_threshold, 1, 2).unwrap();
    assert_eq!(weights["a"], 0.8);
    assert_eq!(weights["b"], 0.5);

    // Mixed counts with one below threshold: returns None
    let mixed: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_count_and_mean("a", 100, 0.8),
        mock_cs_with_count_and_mean("b", 19, 0.6), // Below threshold
    ]
    .into_iter()
    .collect();
    assert_eq!(compute_hedge_weights(&mixed, 1, 2), None);
}

/// Test that compute_hedge_weights ranks variants by mean and assigns correct weights.
#[test]
fn test_compute_hedge_weights_ranking_and_weights() {
    let variant_performance: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_count_and_mean("v1", 30, 0.9), // Rank 0
        mock_cs_with_count_and_mean("v2", 30, 0.8), // Rank 1
        mock_cs_with_count_and_mean("v3", 30, 0.7), // Rank 2
        mock_cs_with_count_and_mean("v4", 30, 0.6), // Rank 3
        mock_cs_with_count_and_mean("v5", 30, 0.5), // Rank 4
    ]
    .into_iter()
    .collect();

    // k_min = 2, k_max = 3: rank < 2 gets 0.8, rank >= 3 gets 0.2, else 0.5
    let weights = compute_hedge_weights(&variant_performance, 2, 3).unwrap();
    assert_eq!(weights["v1"], 0.8); // rank 0
    assert_eq!(weights["v2"], 0.8); // rank 1
    assert_eq!(weights["v3"], 0.5); // rank 2
    assert_eq!(weights["v4"], 0.2); // rank 3
    assert_eq!(weights["v5"], 0.2); // rank 4

    // Test tied means: tied variants get adjacent ranks
    let tied: HashMap<String, MeanBettingConfidenceSequence> = [
        mock_cs_with_count_and_mean("a", 25, 0.7),
        mock_cs_with_count_and_mean("b", 25, 0.7), // Tied with a
        mock_cs_with_count_and_mean("c", 25, 0.5),
    ]
    .into_iter()
    .collect();
    // k_min=1, k_max=2: rank < 1 gets 0.8, rank >= 2 gets 0.2, else 0.5
    let weights = compute_hedge_weights(&tied, 1, 2).unwrap();
    assert_eq!(weights["c"], 0.2); // rank 2 (>= k_max)
    // a and b are tied at ranks 0 and 1: rank 0 gets 0.8, rank 1 gets 0.5
    let ab_weights: Vec<f64> = vec![weights["a"], weights["b"]];
    assert!(ab_weights.contains(&0.8) && ab_weights.contains(&0.5));
}

// ----------------------------------------------------------------------------
// compute_updates with hedge_weights tests
// ----------------------------------------------------------------------------

/// Test that passing hedge_weights to compute_updates affects the CS differently than None.
#[test]
fn test_compute_updates_with_hedge_weights_affects_cs() {
    // Create identical fresh CSes (not mock ones with preset values)
    let mut variant_performance_no_hedge: HashMap<String, MeanBettingConfidenceSequence> = [(
        "variant".to_string(),
        MeanBettingConfidenceSequence::new("variant".to_string(), 101, 0.05),
    )]
    .into_iter()
    .collect();

    let mut variant_performance_with_hedge: HashMap<String, MeanBettingConfidenceSequence> = [(
        "variant".to_string(),
        MeanBettingConfidenceSequence::new("variant".to_string(), 101, 0.05),
    )]
    .into_iter()
    .collect();

    let mut variant_failures_no_hedge: HashMap<String, MeanBettingConfidenceSequence> = [(
        "variant".to_string(),
        MeanBettingConfidenceSequence::new("variant".to_string(), 101, 0.05),
    )]
    .into_iter()
    .collect();

    let mut variant_failures_with_hedge: HashMap<String, MeanBettingConfidenceSequence> = [(
        "variant".to_string(),
        MeanBettingConfidenceSequence::new("variant".to_string(), 101, 0.05),
    )]
    .into_iter()
    .collect();

    let mut evaluator_failures_no_hedge: HashMap<String, MeanBettingConfidenceSequence> =
        HashMap::new();
    let mut evaluator_failures_with_hedge: HashMap<String, MeanBettingConfidenceSequence> =
        HashMap::new();

    let scoring_fn = AverageEvaluatorScore;

    // Create multiple batches with consistent high scores (0.8)
    // We need enough observations for the hedge weight to make a visible difference
    for _ in 0..20 {
        let datapoint_id = uuid::Uuid::now_v7();
        let results_by_datapoint: BatchResultsByDatapoint = [(
            datapoint_id,
            [(
                "variant".to_string(),
                mock_success(
                    datapoint_id,
                    "variant",
                    [("eval1".to_string(), Ok(Some(json!(0.8))))]
                        .into_iter()
                        .collect(),
                ),
            )]
            .into_iter()
            .collect(),
        )]
        .into_iter()
        .collect();

        // Apply update without hedge weights
        compute_updates(
            &results_by_datapoint,
            &scoring_fn,
            &mut variant_performance_no_hedge,
            &mut variant_failures_no_hedge,
            &mut evaluator_failures_no_hedge,
            None,
        )
        .unwrap();

        // Apply update with hedge weight 0.8 (spend more inferential power on lower bound)
        let hedge_weights: HashMap<String, f64> =
            [("variant".to_string(), 0.8)].into_iter().collect();
        compute_updates(
            &results_by_datapoint,
            &scoring_fn,
            &mut variant_performance_with_hedge,
            &mut variant_failures_with_hedge,
            &mut evaluator_failures_with_hedge,
            Some(&hedge_weights),
        )
        .unwrap();
    }

    // Both should have been updated with 20 observations
    assert_eq!(variant_performance_no_hedge["variant"].count, 20);
    assert_eq!(variant_performance_with_hedge["variant"].count, 20);

    // The underlying wealth processes should be identical (hedge weight doesn't affect them)
    let cs_no_hedge = &variant_performance_no_hedge["variant"];
    let cs_with_hedge = &variant_performance_with_hedge["variant"];

    assert_eq!(
        cs_no_hedge.wealth.wealth_upper, cs_with_hedge.wealth.wealth_upper,
        "wealth_upper should be identical regardless of hedge weight"
    );
    assert_eq!(
        cs_no_hedge.wealth.wealth_lower, cs_with_hedge.wealth.wealth_lower,
        "wealth_lower should be identical regardless of hedge weight"
    );

    // With weight 0.8 emphasizing the positive wealth process, lower bound should be
    // higher (tighter), and upper bound should also be higher (looser)
    assert!(
        cs_with_hedge.cs_lower > cs_no_hedge.cs_lower,
        "With hedge weight 0.8, lower bound ({}) should be > the lower bound with hedge weight 0.5 ({})",
        cs_with_hedge.cs_lower,
        cs_no_hedge.cs_lower
    );
    assert!(
        cs_with_hedge.cs_upper > cs_no_hedge.cs_upper,
        "With hedge weight 0.8, upper bound ({}) should be > the upper bound with hedge weight 0.5 ({})",
        cs_with_hedge.cs_lower,
        cs_no_hedge.cs_lower
    );
}

/// Test that hedge_weights only affects variant_performance, not failures.
#[test]
fn test_compute_updates_hedge_weights_only_applied_to_performance() {
    // Create initial states
    let mut variant_performance: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_count_and_mean("variant", 0, 0.5)]
            .into_iter()
            .collect();

    let mut variant_failures_with_hedge: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_count_and_mean("variant", 0, 0.5)]
            .into_iter()
            .collect();

    let mut variant_failures_no_hedge: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_count_and_mean("variant", 0, 0.5)]
            .into_iter()
            .collect();

    let mut evaluator_failures_with_hedge: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_count_and_mean("eval1", 0, 0.5)]
            .into_iter()
            .collect();

    let mut evaluator_failures_no_hedge: HashMap<String, MeanBettingConfidenceSequence> =
        [mock_cs_with_count_and_mean("eval1", 0, 0.5)]
            .into_iter()
            .collect();

    let scoring_fn = AverageEvaluatorScore;

    // Create a batch with successful evaluation
    let datapoint_id = uuid::Uuid::now_v7();
    let results_by_datapoint: BatchResultsByDatapoint = [(
        datapoint_id,
        [(
            "variant".to_string(),
            mock_success(
                datapoint_id,
                "variant",
                [("eval1".to_string(), Ok(Some(json!(0.8))))]
                    .into_iter()
                    .collect(),
            ),
        )]
        .into_iter()
        .collect(),
    )]
    .into_iter()
    .collect();

    // Apply with extreme hedge weight
    let hedge_weights: HashMap<String, f64> = [("variant".to_string(), 0.2)].into_iter().collect();

    compute_updates(
        &results_by_datapoint,
        &scoring_fn,
        &mut variant_performance.clone(),
        &mut variant_failures_with_hedge,
        &mut evaluator_failures_with_hedge,
        Some(&hedge_weights),
    )
    .unwrap();

    compute_updates(
        &results_by_datapoint,
        &scoring_fn,
        &mut variant_performance,
        &mut variant_failures_no_hedge,
        &mut evaluator_failures_no_hedge,
        None,
    )
    .unwrap();

    // variant_failures should be identical regardless of hedge_weights
    // (hedge_weights is only applied to performance, not failures)
    assert_eq!(
        variant_failures_with_hedge["variant"].cs_lower,
        variant_failures_no_hedge["variant"].cs_lower,
        "variant_failures cs_lower should be the same regardless of hedge_weights"
    );
    assert_eq!(
        variant_failures_with_hedge["variant"].cs_upper,
        variant_failures_no_hedge["variant"].cs_upper,
        "variant_failures cs_upper should be the same regardless of hedge_weights"
    );

    // evaluator_failures should be identical regardless of hedge_weights
    assert_eq!(
        evaluator_failures_with_hedge["eval1"].cs_lower,
        evaluator_failures_no_hedge["eval1"].cs_lower,
        "evaluator_failures cs_lower should be the same regardless of hedge_weights"
    );
    assert_eq!(
        evaluator_failures_with_hedge["eval1"].cs_upper,
        evaluator_failures_no_hedge["eval1"].cs_upper,
        "evaluator_failures cs_upper should be the same regardless of hedge_weights"
    );
}
