"""add Vehicle and FuelLog models

Revision ID: 8627a80874a6
Revises: ed827c515edb
Create Date: 2017-07-01 09:21:51.583666

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '8627a80874a6'
down_revision = 'ed827c515edb'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'vehicles',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('name', sa.String(length=254), nullable=True),
        sa.Column('is_active', sa.Boolean(), nullable=True),
        sa.PrimaryKeyConstraint('id', name=op.f('pk_vehicles')),
        mysql_engine='InnoDB'
    )
    op.create_table(
        'fuellog',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('date', sa.Date(), nullable=True),
        sa.Column('vehicle_id', sa.Integer(), nullable=True),
        sa.Column('odometer_miles', sa.Integer(), nullable=True),
        sa.Column('reported_miles', sa.SmallInteger(), nullable=True),
        sa.Column('calculated_miles', sa.SmallInteger(), nullable=True),
        sa.Column('level_before', sa.SmallInteger(), nullable=True),
        sa.Column('level_after', sa.SmallInteger(), nullable=True),
        sa.Column('fill_location', sa.String(length=254), nullable=True),
        sa.Column(
            'cost_per_gallon',
            sa.Numeric(precision=10, scale=4),
            nullable=True
        ),
        sa.Column(
            'total_cost',
            sa.Numeric(precision=10, scale=4),
            nullable=True
        ),
        sa.Column(
            'gallons',
            sa.Numeric(precision=10, scale=4),
            nullable=True
        ),
        sa.Column(
            'reported_mpg',
            sa.Numeric(precision=10, scale=4),
            nullable=True
        ),
        sa.Column(
            'calculated_mpg',
            sa.Numeric(precision=10, scale=4),
            nullable=True
        ),
        sa.Column('notes', sa.String(length=254), nullable=True),
        sa.ForeignKeyConstraint(
            ['vehicle_id'],
            ['vehicles.id'],
            name=op.f('fk_fuellog_vehicle_id_vehicles')
        ),
        sa.PrimaryKeyConstraint('id', name=op.f('pk_fuellog')),
        mysql_engine='InnoDB'
    )


def downgrade():
    op.drop_table('fuellog')
    op.drop_table('vehicles')
