class AttributeShadowingError(AttributeError):
    pass
