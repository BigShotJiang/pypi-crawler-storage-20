class AliasError(AttributeError):
    pass
