class AnnotationError(AttributeError):
    pass
