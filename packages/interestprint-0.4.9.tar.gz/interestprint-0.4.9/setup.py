from setuptools import setup
# 你的 Markdown 格式长描述（不变）
long_description = """# InterestPrint 趣味打印库
作者: 袁窦涵
邮箱: w111251@outlook.com

## 功能介绍
一款支持跨平台彩色打印、趣味喵喵环绕打印的 Python 工具库，轻量无第三方依赖，开箱即用。

## 函数说明
### ColorfulPrint
带颜色的终端打印函数，支持 Windows/Linux/macOS 三大主流系统，可选字体颜色、加粗效果。
- 参数：`*text`（打印内容，支持多参数传入）、`color`（字体颜色，默认值：white）、`bold`（是否加粗，默认值：False）、`end`（结尾字符，默认值：`\n`）、`sep`（多参数分隔符，默认值：空格）
- 支持颜色：black/red/green/yellow/blue/purple/cyan/white
### FrontBackPrint
可设置前后缀的打印
- 参数：`*text` 要打印的内容（可变参数）、`front`: 前缀（默认^）、`back`: 后缀（\EQUALTOFRONT的意思是前后缀相同）、`end` 结尾字符，默认换行、`sep` 多个参数的分隔符，默认空格
### MeowPrint
带猫咪表情（🐱）环绕的趣味打印函数，可自定义前后喵表情数量、是否显示前后表情。
- 参数：`*text`（打印内容，支持多参数传入）、`meow_count`（喵表情数量，默认值：1）、`end`（结尾字符，默认值：`\n`）、`sep`（多参数分隔符，默认值：空格）、`front`（是否前置喵表情，默认值：True）、`back`（是否后置喵表情，默认值：True）

### BgColorfulPrint
带背景颜色的终端打印函数，支持 Windows/Linux/macOS 三大主流系统，默认白色字体，可选背景颜色、加粗效果。
- 参数：`*text`（打印内容，支持多参数传入）、`bg_color`（背景颜色，默认值：black）、`end`（结尾字符，默认值：`\n`）、`sep`（多参数分隔符，默认值：空格）、`bold`（是否加粗，默认值：False）
- 支持背景颜色：black/red/green/yellow/blue/purple/cyan/white

### FgAndBgColorfulPrint
同时设置前景色（字体色）和背景色的终端打印函数，支持 Windows/Linux/macOS 三大主流系统，灵活搭配字体色与背景色。
- 参数：`*text`（打印内容，支持多参数传入）、`fg_color`（前景色/字体色，默认值：white）、`bg_color`（背景颜色，默认值：black）、`end`（结尾字符，默认值：`\n`）、`sep`（多参数分隔符，默认值：空格）
- 支持颜色：black/red/green/yellow/blue/purple/cyan/white

### FgColorfulPrint
`ColorfulPrint` 的别名（Alias），功能与 `ColorfulPrint` 完全一致，语义更直观（Fg 对应 Foreground，前景色/字体色）。
### PrintThenClear
打印后清屏函数，支持自定义显示时间。
- 参数：`*text`（打印内容，支持多参数传入）、`show_time`（显示时间，单位秒，默认值：3）、`color`（字体颜色，默认值：white）、`bold`（是否加粗，默认值：False）、`end`（结尾字符，默认值：`\n`）、`sep`（多参数分隔符，默认值：空格）
### DisableMeowPrint
禁用 MeowPrint 函数。
### EnableMeowPrint
启用 MeowPrint 函数。
### MeowPrint
带猫咪表情（🐱）环绕的趣味打印函数，可自定义前后喵表情数量、是否显示前后表情。
- 参数：`*text`（打印内容，支持多参数传入）、`meow_count`（喵表情数量，默认值：1）、`end`（结尾字符，默认值：`\n`）、`sep`（多参数分隔符，默认值：空格）、`front`（是否前置喵表情，默认值：True）、`back`（是否后置喵表情，默认值：True）
### colorful_input
带颜色的终端输入函数，支持 Windows/Linux/macOS 三大主流系统，可选字体颜色、加粗效果。
- 参数：`prompt`（输入提示信息，默认值：空字符串）、`color`（字体颜色，默认值：white）、`bold`（是否加粗，默认值：False）
- 支持颜色：black/red/green/yellow/blue/purple/cyan/white
"""

setup(
    name="InterestPrint",
    version="0.4.9",
    author="袁窦涵",
    author_email="w111251@outlook.com",
    description="支持各种趣味打印的 Python 工具库",
    long_description=long_description,
    long_description_content_type="text/markdown",
    py_modules=["InterestPrint"],
    install_requires=[],
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Utilities",
    ],
    license="MIT",
)