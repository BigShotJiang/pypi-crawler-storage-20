"""integration tests for familiar cli."""
from __future__ import annotations

import subprocess
import sys


class TestConjureIntegration:
    """integration tests for conjure command."""

    def test_conjure_creates_claude_md(self, tmp_path):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjure", "claude", "python", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "wrote instructions for claude" in result.stdout

        claude_md = tmp_path / "CLAUDE.md"
        assert claude_md.exists()
        content = claude_md.read_text()
        assert "python" in content.lower()

    def test_conjure_creates_agents_md(self, tmp_path):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjure", "codex", "rust", "sec", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0

        agents_md = tmp_path / "AGENTS.md"
        assert agents_md.exists()
        content = agents_md.read_text()
        assert "rust" in content.lower()
        assert "sec" in content.lower()

    def test_conjure_persists_config(self, tmp_path):
        subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjure", "claude", "python", "infra", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )

        config_file = tmp_path / ".familiar" / "claude.json"
        assert config_file.exists()
        import json
        config = json.loads(config_file.read_text())
        assert config["conjurings"] == ["python", "infra"]

    def test_conjure_unknown_profile_fails(self, tmp_path):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjure", "claude", "nonexistent", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode != 0
        assert "unknown template" in result.stderr


class TestInvokeIntegration:
    """integration tests for invoke command (without actually running agents)."""

    def test_invoke_unknown_invocation_fails(self, tmp_path):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "invoke", "claude", "nonexistent", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode != 0
        assert "unknown invocation" in result.stderr

    def test_invoke_invalid_kv_fails(self, tmp_path):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "invoke", "claude", "explain", "--kv", "invalid", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode != 0
        assert "invalid argument" in result.stderr

    def test_error_includes_hint(self, tmp_path):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "invoke", "claude", "nonexistent", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode != 0
        assert "hint:" in result.stderr


class TestHelpIntegration:
    """integration tests for help output."""

    def test_main_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "conjure" in result.stdout
        assert "invoke" in result.stdout
        assert "examples:" in result.stdout

    def test_conjure_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjure", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "conjurings" in result.stdout

    def test_invoke_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "invoke", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "invocation" in result.stdout
        assert "--headless" in result.stdout

    def test_list_help(self):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "list", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "conjurings" in result.stdout
        assert "invocations" in result.stdout


class TestListIntegration:
    """integration tests for list command."""

    def test_list_both(self):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "list"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "conjurings:" in result.stdout
        assert "invocations:" in result.stdout
        assert "core" in result.stdout
        assert "explain" in result.stdout

    def test_list_conjurings(self):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "list", "conjurings"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "core" in result.stdout
        assert "python" in result.stdout
        assert "rust" in result.stdout

    def test_list_invocations(self):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "list", "invocations"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "explain" in result.stdout
        assert "refactor" in result.stdout

    def test_list_conjurings_verbose(self):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "list", "conjurings", "-v"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        # verbose includes description after colon
        assert ":" in result.stdout

    def test_list_with_local_override(self, tmp_path):
        templates = tmp_path / ".familiar" / "templates"
        templates.mkdir(parents=True)
        (templates / "custom.md").write_text("# my custom profile")

        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "list", "conjurings", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "custom (local)" in result.stdout


class TestConjuringsIntegration:
    """integration tests for conjurings command."""

    def test_conjurings_show_empty(self, tmp_path):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjurings", "show", "claude", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "no conjurings saved" in result.stdout

    def test_conjurings_set_and_show(self, tmp_path):
        # set
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjurings", "set", "claude", "rust", "sec", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "saved conjurings" in result.stdout

        # show
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjurings", "show", "claude", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "rust" in result.stdout
        assert "sec" in result.stdout

    def test_conjurings_reset(self, tmp_path):
        # set first
        subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjurings", "set", "claude", "rust", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )

        # reset
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjurings", "reset", "claude", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "reset conjurings" in result.stdout

        # verify empty
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjurings", "show", "claude", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert "no conjurings saved" in result.stdout

    def test_conjurings_set_invalid(self, tmp_path):
        result = subprocess.run(
            [sys.executable, "-m", "familiar.cli", "conjurings", "set", "claude", "nonexistent", "--into", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode != 0
        assert "unknown conjuring" in result.stderr
