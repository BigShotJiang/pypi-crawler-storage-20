"""Tests for terminal wrapper."""
