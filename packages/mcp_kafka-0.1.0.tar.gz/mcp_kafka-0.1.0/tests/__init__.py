"""Tests for MCP Kafka."""
