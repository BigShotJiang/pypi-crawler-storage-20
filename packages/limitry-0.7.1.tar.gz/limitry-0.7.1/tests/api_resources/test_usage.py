# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from limitry import Limitry, AsyncLimitry
from tests.utils import assert_matches_type
from limitry.types import (
    UsageListResponse,
    UsageCheckResponse,
    UsageRecordResponse,
    UsageGetSummaryResponse,
    UsageRecordBatchResponse,
    UsageGetBreakdownResponse,
    UsageGetTimeseriesResponse,
)
from limitry._utils import parse_datetime

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestUsage:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: Limitry) -> None:
        usage = client.usage.list()
        assert_matches_type(UsageListResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Limitry) -> None:
        usage = client.usage.list(
            cursor="cursor",
            customer_id="customerId",
            event_type="eventType",
            limit=1,
            model="model",
        )
        assert_matches_type(UsageListResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Limitry) -> None:
        response = client.usage.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = response.parse()
        assert_matches_type(UsageListResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Limitry) -> None:
        with client.usage.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = response.parse()
            assert_matches_type(UsageListResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_check(self, client: Limitry) -> None:
        usage = client.usage.check(
            customer_id="x",
        )
        assert_matches_type(UsageCheckResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_check_with_all_params(self, client: Limitry) -> None:
        usage = client.usage.check(
            customer_id="x",
            event_type="eventType",
            model="model",
            provider="provider",
        )
        assert_matches_type(UsageCheckResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_check(self, client: Limitry) -> None:
        response = client.usage.with_raw_response.check(
            customer_id="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = response.parse()
        assert_matches_type(UsageCheckResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_check(self, client: Limitry) -> None:
        with client.usage.with_streaming_response.check(
            customer_id="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = response.parse()
            assert_matches_type(UsageCheckResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_breakdown(self, client: Limitry) -> None:
        usage = client.usage.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="model",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(UsageGetBreakdownResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_breakdown_with_all_params(self, client: Limitry) -> None:
        usage = client.usage.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="model",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
            model="model",
            provider="provider",
        )
        assert_matches_type(UsageGetBreakdownResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_breakdown(self, client: Limitry) -> None:
        response = client.usage.with_raw_response.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="model",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = response.parse()
        assert_matches_type(UsageGetBreakdownResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_breakdown(self, client: Limitry) -> None:
        with client.usage.with_streaming_response.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="model",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = response.parse()
            assert_matches_type(UsageGetBreakdownResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_summary(self, client: Limitry) -> None:
        usage = client.usage.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(UsageGetSummaryResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_summary_with_all_params(self, client: Limitry) -> None:
        usage = client.usage.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
            model="model",
            provider="provider",
        )
        assert_matches_type(UsageGetSummaryResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_summary(self, client: Limitry) -> None:
        response = client.usage.with_raw_response.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = response.parse()
        assert_matches_type(UsageGetSummaryResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_summary(self, client: Limitry) -> None:
        with client.usage.with_streaming_response.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = response.parse()
            assert_matches_type(UsageGetSummaryResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_timeseries(self, client: Limitry) -> None:
        usage = client.usage.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(UsageGetTimeseriesResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_timeseries_with_all_params(self, client: Limitry) -> None:
        usage = client.usage.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
            model="model",
            provider="provider",
        )
        assert_matches_type(UsageGetTimeseriesResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_timeseries(self, client: Limitry) -> None:
        response = client.usage.with_raw_response.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = response.parse()
        assert_matches_type(UsageGetTimeseriesResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_timeseries(self, client: Limitry) -> None:
        with client.usage.with_streaming_response.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = response.parse()
            assert_matches_type(UsageGetTimeseriesResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_record(self, client: Limitry) -> None:
        usage = client.usage.record(
            customer_id="x",
            event_type="x",
        )
        assert_matches_type(UsageRecordResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_record_with_all_params(self, client: Limitry) -> None:
        usage = client.usage.record(
            customer_id="x",
            event_type="x",
            cost_cents=0,
            input_tokens=0,
            latency_ms=0,
            model="model",
            output_tokens=0,
            properties={"foo": "bar"},
            provider="provider",
            timestamp=parse_datetime("2019-12-27T18:11:19.117Z"),
            total_tokens=0,
        )
        assert_matches_type(UsageRecordResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_record(self, client: Limitry) -> None:
        response = client.usage.with_raw_response.record(
            customer_id="x",
            event_type="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = response.parse()
        assert_matches_type(UsageRecordResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_record(self, client: Limitry) -> None:
        with client.usage.with_streaming_response.record(
            customer_id="x",
            event_type="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = response.parse()
            assert_matches_type(UsageRecordResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_record_batch(self, client: Limitry) -> None:
        usage = client.usage.record_batch(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        )
        assert_matches_type(UsageRecordBatchResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_record_batch(self, client: Limitry) -> None:
        response = client.usage.with_raw_response.record_batch(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = response.parse()
        assert_matches_type(UsageRecordBatchResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_record_batch(self, client: Limitry) -> None:
        with client.usage.with_streaming_response.record_batch(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = response.parse()
            assert_matches_type(UsageRecordBatchResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncUsage:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.list()
        assert_matches_type(UsageListResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.list(
            cursor="cursor",
            customer_id="customerId",
            event_type="eventType",
            limit=1,
            model="model",
        )
        assert_matches_type(UsageListResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLimitry) -> None:
        response = await async_client.usage.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = await response.parse()
        assert_matches_type(UsageListResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLimitry) -> None:
        async with async_client.usage.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = await response.parse()
            assert_matches_type(UsageListResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_check(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.check(
            customer_id="x",
        )
        assert_matches_type(UsageCheckResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_check_with_all_params(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.check(
            customer_id="x",
            event_type="eventType",
            model="model",
            provider="provider",
        )
        assert_matches_type(UsageCheckResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_check(self, async_client: AsyncLimitry) -> None:
        response = await async_client.usage.with_raw_response.check(
            customer_id="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = await response.parse()
        assert_matches_type(UsageCheckResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_check(self, async_client: AsyncLimitry) -> None:
        async with async_client.usage.with_streaming_response.check(
            customer_id="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = await response.parse()
            assert_matches_type(UsageCheckResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_breakdown(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="model",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(UsageGetBreakdownResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_breakdown_with_all_params(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="model",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
            model="model",
            provider="provider",
        )
        assert_matches_type(UsageGetBreakdownResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_breakdown(self, async_client: AsyncLimitry) -> None:
        response = await async_client.usage.with_raw_response.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="model",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = await response.parse()
        assert_matches_type(UsageGetBreakdownResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_breakdown(self, async_client: AsyncLimitry) -> None:
        async with async_client.usage.with_streaming_response.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="model",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = await response.parse()
            assert_matches_type(UsageGetBreakdownResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_summary(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(UsageGetSummaryResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_summary_with_all_params(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
            model="model",
            provider="provider",
        )
        assert_matches_type(UsageGetSummaryResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_summary(self, async_client: AsyncLimitry) -> None:
        response = await async_client.usage.with_raw_response.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = await response.parse()
        assert_matches_type(UsageGetSummaryResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_summary(self, async_client: AsyncLimitry) -> None:
        async with async_client.usage.with_streaming_response.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = await response.parse()
            assert_matches_type(UsageGetSummaryResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_timeseries(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(UsageGetTimeseriesResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_timeseries_with_all_params(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
            model="model",
            provider="provider",
        )
        assert_matches_type(UsageGetTimeseriesResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_timeseries(self, async_client: AsyncLimitry) -> None:
        response = await async_client.usage.with_raw_response.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = await response.parse()
        assert_matches_type(UsageGetTimeseriesResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_timeseries(self, async_client: AsyncLimitry) -> None:
        async with async_client.usage.with_streaming_response.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = await response.parse()
            assert_matches_type(UsageGetTimeseriesResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_record(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.record(
            customer_id="x",
            event_type="x",
        )
        assert_matches_type(UsageRecordResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_record_with_all_params(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.record(
            customer_id="x",
            event_type="x",
            cost_cents=0,
            input_tokens=0,
            latency_ms=0,
            model="model",
            output_tokens=0,
            properties={"foo": "bar"},
            provider="provider",
            timestamp=parse_datetime("2019-12-27T18:11:19.117Z"),
            total_tokens=0,
        )
        assert_matches_type(UsageRecordResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_record(self, async_client: AsyncLimitry) -> None:
        response = await async_client.usage.with_raw_response.record(
            customer_id="x",
            event_type="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = await response.parse()
        assert_matches_type(UsageRecordResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_record(self, async_client: AsyncLimitry) -> None:
        async with async_client.usage.with_streaming_response.record(
            customer_id="x",
            event_type="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = await response.parse()
            assert_matches_type(UsageRecordResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_record_batch(self, async_client: AsyncLimitry) -> None:
        usage = await async_client.usage.record_batch(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        )
        assert_matches_type(UsageRecordBatchResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_record_batch(self, async_client: AsyncLimitry) -> None:
        response = await async_client.usage.with_raw_response.record_batch(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        usage = await response.parse()
        assert_matches_type(UsageRecordBatchResponse, usage, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_record_batch(self, async_client: AsyncLimitry) -> None:
        async with async_client.usage.with_streaming_response.record_batch(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            usage = await response.parse()
            assert_matches_type(UsageRecordBatchResponse, usage, path=["response"])

        assert cast(Any, response.is_closed) is True
