# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional
from datetime import datetime
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["UsageRecordParams"]


class UsageRecordParams(TypedDict, total=False):
    customer_id: Required[Annotated[str, PropertyInfo(alias="customerId")]]
    """Customer ID that generated the usage"""

    event_type: Required[Annotated[str, PropertyInfo(alias="eventType")]]
    """Type of event (e.g., "chat_completion", "embedding")"""

    cost_cents: Annotated[float, PropertyInfo(alias="costCents")]
    """Cost in cents"""

    input_tokens: Annotated[int, PropertyInfo(alias="inputTokens")]
    """Number of input/prompt tokens"""

    latency_ms: Annotated[int, PropertyInfo(alias="latencyMs")]
    """Latency in milliseconds"""

    model: str
    """Model used (e.g., "gpt-4", "claude-3")"""

    output_tokens: Annotated[int, PropertyInfo(alias="outputTokens")]
    """Number of output/completion tokens"""

    properties: Dict[str, Optional[object]]
    """Additional custom properties"""

    provider: str
    """Provider (e.g., "openai", "anthropic")"""

    timestamp: Annotated[Union[str, datetime], PropertyInfo(format="iso8601")]
    """Event timestamp (defaults to now)"""

    total_tokens: Annotated[int, PropertyInfo(alias="totalTokens")]
    """Total tokens (if not providing input/output separately)"""
