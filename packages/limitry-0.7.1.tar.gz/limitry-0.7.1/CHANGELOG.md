# Changelog

## 0.7.1 (2026-01-17)

Full Changelog: [v0.7.0...v0.7.1](https://github.com/limitry/limitry-python/compare/v0.7.0...v0.7.1)

### Chores

* remove custom code ([a14638e](https://github.com/limitry/limitry-python/commit/a14638ec1a7f8c4e44548612af751acb92291653))

## 0.7.0 (2026-01-17)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/limitry/limitry-python/compare/v0.6.0...v0.7.0)

### Features

* **api:** api update ([e6e169a](https://github.com/limitry/limitry-python/commit/e6e169a3d174a0dd5758fb9c31f12a372b9ab241))
* **api:** manual updates ([75d031a](https://github.com/limitry/limitry-python/commit/75d031a4af36ae759f90cd10a0a009507b86aa12))
* **api:** manual updates ([9f6aaff](https://github.com/limitry/limitry-python/commit/9f6aaff514d87bd10a145bffd420e661c1294231))


### Chores

* remove custom code ([2759f10](https://github.com/limitry/limitry-python/commit/2759f1035cb8a469a782f6fec33adeab4193e6b1))

## 0.6.0 (2026-01-17)

Full Changelog: [v0.5.2...v0.6.0](https://github.com/limitry/limitry-python/compare/v0.5.2...v0.6.0)

### Features

* **api:** manual updates ([43a56c2](https://github.com/limitry/limitry-python/commit/43a56c26a6bad63b8e98f90d43172b954a7951d3))

## 0.5.2 (2026-01-17)

Full Changelog: [v0.5.1...v0.5.2](https://github.com/limitry/limitry-python/compare/v0.5.1...v0.5.2)

### Chores

* **internal:** update `actions/checkout` version ([04b4d09](https://github.com/limitry/limitry-python/commit/04b4d09220cfb2465bafd30e6675f221357b0d9b))

## 0.5.1 (2026-01-16)

Full Changelog: [v0.5.0...v0.5.1](https://github.com/limitry/limitry-python/compare/v0.5.0...v0.5.1)

### Features

* **api:** api update ([e59b70a](https://github.com/limitry/limitry-python/commit/e59b70aa2eef0f64f0e3894aeba5f5f0c8781c73))
* **api:** manual updates ([22fcb80](https://github.com/limitry/limitry-python/commit/22fcb80784814f35e25556b0b4830eb0db1e69e1))
* **api:** manual updates ([dd5bff4](https://github.com/limitry/limitry-python/commit/dd5bff43590c5aa236f7443fe49d0e5c7baa43fa))
* **api:** manual updates ([8c38473](https://github.com/limitry/limitry-python/commit/8c3847348441d902f1d17a344124ace4542a9d0d))
* **client:** add support for binary request streaming ([10b2e53](https://github.com/limitry/limitry-python/commit/10b2e5387306634b807117565de99b6817d9a2f2))

## 0.5.0 (2026-01-13)

Full Changelog: [v0.0.1...v0.5.0](https://github.com/limitry/limitry-python/compare/v0.0.1...v0.5.0)

### Features

* **api:** api update ([3027e08](https://github.com/limitry/limitry-python/commit/3027e0838b6df14088ff349415646945115dd7b2))


### Chores

* update SDK settings ([1d966b3](https://github.com/limitry/limitry-python/commit/1d966b397373ed46446f604a87cf45c85ad7ff7a))
* update SDK settings ([b920646](https://github.com/limitry/limitry-python/commit/b920646632c0cbf2b139972488eda88837e050f2))
