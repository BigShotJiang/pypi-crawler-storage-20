# Projects

Types:

```python
from limitry.types import PaginationCursor, Project
```

Methods:

- <code title="get /projects/current">client.projects.<a href="./src/limitry/resources/projects.py">retrieve_current</a>() -> <a href="./src/limitry/types/project.py">Project</a></code>

# Usage

Types:

```python
from limitry.types import (
    UsageListResponse,
    UsageCheckResponse,
    UsageGetBreakdownResponse,
    UsageGetSummaryResponse,
    UsageGetTimeseriesResponse,
    UsageRecordResponse,
    UsageRecordBatchResponse,
)
```

Methods:

- <code title="get /usage">client.usage.<a href="./src/limitry/resources/usage.py">list</a>(\*\*<a href="src/limitry/types/usage_list_params.py">params</a>) -> <a href="./src/limitry/types/usage_list_response.py">UsageListResponse</a></code>
- <code title="post /usage/check">client.usage.<a href="./src/limitry/resources/usage.py">check</a>(\*\*<a href="src/limitry/types/usage_check_params.py">params</a>) -> <a href="./src/limitry/types/usage_check_response.py">UsageCheckResponse</a></code>
- <code title="get /usage/breakdown">client.usage.<a href="./src/limitry/resources/usage.py">get_breakdown</a>(\*\*<a href="src/limitry/types/usage_get_breakdown_params.py">params</a>) -> <a href="./src/limitry/types/usage_get_breakdown_response.py">UsageGetBreakdownResponse</a></code>
- <code title="get /usage/summary">client.usage.<a href="./src/limitry/resources/usage.py">get_summary</a>(\*\*<a href="src/limitry/types/usage_get_summary_params.py">params</a>) -> <a href="./src/limitry/types/usage_get_summary_response.py">UsageGetSummaryResponse</a></code>
- <code title="get /usage/timeseries">client.usage.<a href="./src/limitry/resources/usage.py">get_timeseries</a>(\*\*<a href="src/limitry/types/usage_get_timeseries_params.py">params</a>) -> <a href="./src/limitry/types/usage_get_timeseries_response.py">UsageGetTimeseriesResponse</a></code>
- <code title="post /usage/record">client.usage.<a href="./src/limitry/resources/usage.py">record</a>(\*\*<a href="src/limitry/types/usage_record_params.py">params</a>) -> <a href="./src/limitry/types/usage_record_response.py">UsageRecordResponse</a></code>
- <code title="post /usage/batch">client.usage.<a href="./src/limitry/resources/usage.py">record_batch</a>(\*\*<a href="src/limitry/types/usage_record_batch_params.py">params</a>) -> <a href="./src/limitry/types/usage_record_batch_response.py">UsageRecordBatchResponse</a></code>

# Customers

Types:

```python
from limitry.types import CustomerRetrieveUsageResponse
```

Methods:

- <code title="get /customers/{customerId}/usage">client.customers.<a href="./src/limitry/resources/customers.py">retrieve_usage</a>(customer_id, \*\*<a href="src/limitry/types/customer_retrieve_usage_params.py">params</a>) -> <a href="./src/limitry/types/customer_retrieve_usage_response.py">CustomerRetrieveUsageResponse</a></code>

# Quotas

Types:

```python
from limitry.types import Quota, QuotaListResponse, QuotaDeleteResponse, QuotaCheckResponse
```

Methods:

- <code title="post /quotas">client.quotas.<a href="./src/limitry/resources/quotas.py">create</a>(\*\*<a href="src/limitry/types/quota_create_params.py">params</a>) -> <a href="./src/limitry/types/quota.py">Quota</a></code>
- <code title="get /quotas/{id}">client.quotas.<a href="./src/limitry/resources/quotas.py">retrieve</a>(id) -> <a href="./src/limitry/types/quota.py">Quota</a></code>
- <code title="put /quotas/{id}">client.quotas.<a href="./src/limitry/resources/quotas.py">update</a>(id, \*\*<a href="src/limitry/types/quota_update_params.py">params</a>) -> <a href="./src/limitry/types/quota.py">Quota</a></code>
- <code title="get /quotas">client.quotas.<a href="./src/limitry/resources/quotas.py">list</a>(\*\*<a href="src/limitry/types/quota_list_params.py">params</a>) -> <a href="./src/limitry/types/quota_list_response.py">QuotaListResponse</a></code>
- <code title="delete /quotas/{id}">client.quotas.<a href="./src/limitry/resources/quotas.py">delete</a>(id) -> <a href="./src/limitry/types/quota_delete_response.py">QuotaDeleteResponse</a></code>
- <code title="post /quotas/check">client.quotas.<a href="./src/limitry/resources/quotas.py">check</a>(\*\*<a href="src/limitry/types/quota_check_params.py">params</a>) -> <a href="./src/limitry/types/quota_check_response.py">QuotaCheckResponse</a></code>

# RateLimits

Types:

```python
from limitry.types import (
    RateLimit,
    RateLimitListResponse,
    RateLimitDeleteResponse,
    RateLimitCheckResponse,
)
```

Methods:

- <code title="post /rate-limits">client.rate_limits.<a href="./src/limitry/resources/rate_limits.py">create</a>(\*\*<a href="src/limitry/types/rate_limit_create_params.py">params</a>) -> <a href="./src/limitry/types/rate_limit.py">RateLimit</a></code>
- <code title="get /rate-limits/{id}">client.rate_limits.<a href="./src/limitry/resources/rate_limits.py">retrieve</a>(id) -> <a href="./src/limitry/types/rate_limit.py">RateLimit</a></code>
- <code title="put /rate-limits/{id}">client.rate_limits.<a href="./src/limitry/resources/rate_limits.py">update</a>(id, \*\*<a href="src/limitry/types/rate_limit_update_params.py">params</a>) -> <a href="./src/limitry/types/rate_limit.py">RateLimit</a></code>
- <code title="get /rate-limits">client.rate_limits.<a href="./src/limitry/resources/rate_limits.py">list</a>(\*\*<a href="src/limitry/types/rate_limit_list_params.py">params</a>) -> <a href="./src/limitry/types/rate_limit_list_response.py">RateLimitListResponse</a></code>
- <code title="delete /rate-limits/{id}">client.rate_limits.<a href="./src/limitry/resources/rate_limits.py">delete</a>(id) -> <a href="./src/limitry/types/rate_limit_delete_response.py">RateLimitDeleteResponse</a></code>
- <code title="post /rate-limits/check">client.rate_limits.<a href="./src/limitry/resources/rate_limits.py">check</a>(\*\*<a href="src/limitry/types/rate_limit_check_params.py">params</a>) -> <a href="./src/limitry/types/rate_limit_check_response.py">RateLimitCheckResponse</a></code>

# ClientTokens

Types:

```python
from limitry.types import ClientTokenCreateResponse
```

Methods:

- <code title="post /client-tokens">client.client_tokens.<a href="./src/limitry/resources/client_tokens.py">create</a>(\*\*<a href="src/limitry/types/client_token_create_params.py">params</a>) -> <a href="./src/limitry/types/client_token_create_response.py">ClientTokenCreateResponse</a></code>
- <code title="delete /client-tokens/{id}">client.client_tokens.<a href="./src/limitry/resources/client_tokens.py">revoke</a>(id) -> None</code>
