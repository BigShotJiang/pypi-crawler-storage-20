# 📋 Dir2Clip

**Dir2Clip** is a Python CLI tool designed to streamline the process of sharing code context with Large Language Models (LLMs) like ChatGPT, Claude, and Gemini. 

It recursively scans a directory, intelligently filters files, formats their contents into a single structured string, and copies the result directly to your clipboard—ready to paste.

## ✨ Features

- **🚀 Instant Clipboard Copy**: No manual selecting or copying. One command and you're ready to paste.
- **🌲 Recursive Scanning**: Traverses your project structure to capture all relevant files.
- **🚫 Smart Filtering**:
  - Automatically ignores binary files (images, compiled code, etc.).
  - Skips standard noise like `.git`, `venv`, `node_modules`, `__pycache__`.
- **📏 Context Limit Protection**: 
  - Prevents clipboard overflow for browser-based LLMs.
  - Defaults to 100,000 characters (configurable).
  - Adds a clear warning footer if content is truncated.
- **📝 LLM-Friendly Formatting**: 
  - Wraps file contents in Markdown code blocks.
  - Clearly labels each file with `### FILE: path/to/file.ext` for optimal model understanding.

## 🛠️ Installation

1. **Clone the repository** (or download the script):
   ```bash
   git clone https://github.com/yourusername/Dir2Clip.git
   cd Dir2Clip
   ```

2. **Set up a virtual environment** (recommended):
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
   *(This tool primarily relies on `pyperclip` for clipboard access.)*

   **Linux Users:** You may need a system clipboard utility:
   ```bash
   sudo apt-get install xclip  # or xsel
   ```

## 📖 Usage

Run the script from your terminal:

```bash
# Scan current directory
python dir2clip.py

# Scan a specific directory
python dir2clip.py /path/to/project

# Set a custom character limit (e.g., for models with smaller context windows)
python dir2clip.py --max-len 20000
```

### Output Example

When you paste into your LLM, it will look like this:

```text
### FILE: src/main.py
```
import os
print("Hello World")
```

### FILE: README.md
```
# My Project
...
```
```

## ⚙️ Configuration

You can customize the `IGNORE_DIRS` list inside `dir2clip.py` to exclude additional folders:

```python
IGNORE_DIRS = {'.git', 'venv', 'node_modules', 'dist', 'build', ...}
```

## 📄 License

MIT