#  BSD 3-Clause License
#
#  Copyright (c) 2019, Elasticsearch BV
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions are met:
#
#  * Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.
#
#  * Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
#  * Neither the name of the copyright holder nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
#  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
#  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
#  DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
#  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
#  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
#  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
#  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
#  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


import logging

from django.http import HttpRequest
from django.template.base import Node

from atatus.utils.stacks import get_frame_info

try:
    from django.template.base import Template
except ImportError:

    class Template(object):
        pass


def iterate_with_template_sources(
    frames,
    with_locals=True,
    library_frame_context_lines=None,
    in_app_frame_context_lines=None,
    include_paths_re=None,
    exclude_paths_re=None,
    locals_processor_func=None,
):
    template = None
    for f in frames:
        try:
            frame, lineno = f
        except ValueError:
            # TODO how can we possibly get anything besides a (frame, lineno) tuple here???
            logging.getLogger("atatus").error("Malformed list of frames. Frames may be missing in Kibana.")
            break
        f_code = getattr(frame, "f_code", None)
        if f_code:
            function_name = frame.f_code.co_name
            if function_name == "render":
                renderer = getattr(frame, "f_locals", {}).get("self")
                if renderer and isinstance(renderer, Node):
                    if getattr(renderer, "token", None) is not None:
                        if hasattr(renderer, "source"):
                            # up to Django 1.8
                            yield {"lineno": renderer.token.lineno, "filename": renderer.source[0].name}
                        else:
                            template = {"lineno": renderer.token.lineno}
                # Django 1.9 doesn't have the origin on the Node instance,
                # so we have to get it a bit further down the stack from the
                # Template instance
                elif renderer and isinstance(renderer, Template):
                    if template and getattr(renderer, "origin", None):
                        template["filename"] = renderer.origin.name
                        yield template
                        template = None

        yield get_frame_info(
            frame,
            lineno,
            library_frame_context_lines=library_frame_context_lines,
            in_app_frame_context_lines=in_app_frame_context_lines,
            with_locals=with_locals,
            include_paths_re=include_paths_re,
            exclude_paths_re=exclude_paths_re,
            locals_processor_func=locals_processor_func,
        )


def get_raw_uri(request: HttpRequest) -> str:
    """
    Return an absolute URI from variables available in this request. Skip
    allowed hosts protection, so may return insecure URI.

    Re-implementation of Request.get_raw_uri that was removed with Django 4.0.

    :param request: a Request object
    :return: the URL
    """
    return "{scheme}://{host}{path}".format(
        scheme=request.scheme,
        host=request._get_raw_host(),
        path=request.get_full_path(),
    )
