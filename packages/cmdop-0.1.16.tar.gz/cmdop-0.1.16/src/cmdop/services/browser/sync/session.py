"""Synchronous browser session."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from cmdop.services.browser.base.session import BaseSession
from cmdop.services.browser.models import BrowserCookie, BrowserState
from cmdop.services.browser.js import parse_json_result

if TYPE_CHECKING:
    from cmdop.services.browser.sync.service import BrowserService


class BrowserSession(BaseSession):
    """
    Synchronous browser session with fluent API.

    Usage:
        with client.browser.create_session() as session:
            session.navigate("https://example.com")
            session.click("button.submit")
            data = session.fetch_all(urls)  # credentials + accept header by default
    """

    _service: BrowserService

    def _call_service(self, method: str, *args: Any, **kwargs: Any) -> Any:
        """Call service method synchronously."""
        return getattr(self._service, method)(self._session_id, *args, **kwargs)

    # === Navigation & Interaction ===

    def navigate(self, url: str, timeout_ms: int = 30000) -> str:
        """Navigate to URL. Returns final URL."""
        return self._service.navigate(self._session_id, url, timeout_ms)

    def click(self, selector: str, timeout_ms: int = 5000) -> None:
        """Click element by CSS selector."""
        self._service.click(self._session_id, selector, timeout_ms)

    def type(
        self,
        selector: str,
        text: str,
        human_like: bool = False,
        clear_first: bool = True,
    ) -> None:
        """Type text into element."""
        self._service.type(self._session_id, selector, text, human_like, clear_first)

    def wait_for(self, selector: str, timeout_ms: int = 30000) -> bool:
        """Wait for element to appear."""
        return self._service.wait_for(self._session_id, selector, timeout_ms)

    # === Extraction ===

    def extract(
        self, selector: str, attr: str | None = None, limit: int = 100
    ) -> list[str]:
        """Extract text/attributes from elements."""
        return self._service.extract(self._session_id, selector, attr, limit)

    def extract_regex(
        self, pattern: str, from_html: bool = False, limit: int = 100
    ) -> list[str]:
        """Extract data using regex pattern."""
        return self._service.extract_regex(self._session_id, pattern, from_html, limit)

    def get_html(self, selector: str | None = None) -> str:
        """Get page HTML."""
        return self._service.get_html(self._session_id, selector)

    def get_text(self, selector: str | None = None) -> str:
        """Get page text content."""
        return self._service.get_text(self._session_id, selector)

    # === JavaScript Execution ===

    def execute_script(self, script: str) -> str:
        """Execute JavaScript (raw, no wrapper)."""
        return self._service.execute_script(self._session_id, script)

    def execute_js(self, code: str, raw: bool = False) -> dict | list | str | None:
        """
        Execute async JavaScript with auto-wrap.

        Code is wrapped in async IIFE with try/catch and JSON serialization.

        Args:
            code: JS code to execute (can use await)
            raw: If True, return raw JSON string. Default False (parse to dict/list).

        Example:
            result = session.execute_js('''
                const resp = await fetch('/api/data');
                return await resp.json();
            ''')
        """
        js = self._build_execute_js(code)
        result = self.execute_script(js)
        return self._parse_execute_js(result, raw)

    def fetch_json(self, url: str) -> dict | list | None:
        """Fetch JSON from URL using JS fetch()."""
        js = self._build_fetch_json(url)
        result = self.execute_script(js)
        return parse_json_result(result)

    def fetch_all(
        self,
        urls: dict[str, str],
        headers: dict[str, str] | None = None,
        credentials: bool = False,
    ) -> dict[str, Any]:
        """
        Fetch multiple URLs in parallel.

        Args:
            urls: Dict of {id: url} to fetch
            headers: Optional headers (accept: application/json by default)
            credentials: Include credentials/cookies (default False, may break CORS)

        Returns:
            Dict of {id: {data: ..., error: ...}}
        """
        if not urls:
            return {}
        js = self._build_fetch_all(urls, headers, credentials)
        result = self.execute_js(js)
        return self._parse_fetch_all(result)

    # === State & Cookies ===

    def screenshot(self, full_page: bool = False) -> bytes:
        """Take screenshot."""
        return self._service.screenshot(self._session_id, full_page)

    def get_state(self) -> BrowserState:
        """Get current browser state."""
        return self._service.get_state(self._session_id)

    def set_cookies(self, cookies: list[BrowserCookie | dict]) -> None:
        """Set browser cookies."""
        self._service.set_cookies(self._session_id, cookies)

    def get_cookies(self, domain: str = "") -> list[BrowserCookie]:
        """Get browser cookies."""
        return self._service.get_cookies(self._session_id, domain)

    # === Parser helpers ===

    def validate_selectors(self, item: str, fields: dict[str, str]) -> dict:
        """Validate CSS selectors on page."""
        return self._service.validate_selectors(self._session_id, item, fields)

    def extract_data(self, item: str, fields_json: str, limit: int = 100) -> dict:
        """Extract structured data from page."""
        return self._service.extract_data(self._session_id, item, fields_json, limit)

    # === Context Manager ===

    def close(self) -> None:
        """Close browser session."""
        self._service.close_session(self._session_id)

    def __enter__(self) -> "BrowserSession":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
