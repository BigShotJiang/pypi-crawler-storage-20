"""Hooks system for customizing Promethian agent behavior.

Hooks allow users to intercept and modify agent behavior at key points
without modifying core code.

Example hooks.json:
{
    "hooks": [
        {
            "event": "pre_tool_use",
            "tool": "bash",
            "script": "~/.promethian/hooks/validate_bash.py"
        },
        {
            "event": "session_start",
            "script": "~/.promethian/hooks/inject_context.py"
        }
    ]
}
"""

from promethian.hooks.types import (
    HookEvent,
    HookConfig,
    HookResult,
    HookContext,
)
from promethian.hooks.loader import (
    load_hooks,
    get_hooks_for_event,
)
from promethian.hooks.executor import (
    HookExecutor,
    execute_hooks,
)

__all__ = [
    "HookEvent",
    "HookConfig",
    "HookResult",
    "HookContext",
    "load_hooks",
    "get_hooks_for_event",
    "HookExecutor",
    "execute_hooks",
]
