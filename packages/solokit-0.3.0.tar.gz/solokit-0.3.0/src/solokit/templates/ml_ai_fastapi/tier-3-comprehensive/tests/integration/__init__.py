"""
Integration tests package
"""
