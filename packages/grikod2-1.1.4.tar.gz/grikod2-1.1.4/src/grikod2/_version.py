# _version.py

__version__ = "1.1.4"
__license__ = "MIT"
__description__ = "Binary to Gray code conversion package for efficient data encoding."
__author__ = "Mehmet Keçeci"
__url__ = "https://github.com/KuantumBS/grikod2"
__docs__ = "https://kuantumbs.github.io/grikod2"  # Opsiyonel: Dokümantasyon linki
__dependencies__ = ["python>=3.10"]  # Diğer bağımlılıkları da ekleyebilirsiniz
