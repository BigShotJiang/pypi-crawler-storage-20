# -*- coding:utf-8 -*-
"""
Created on 2016/5/10
@author: lijc210@163.com
Desc: PostgreSQL 连接池客户端，内部使用 with 上下文管理器自动管理连接
支持普通查询和流式查询两种独立的连接池
使用 psycopg3 (psycopg) 内置连接池
"""

import psycopg
from psycopg_pool import ConnectionPool


class PostgresClient:
    def __init__(
        self,
        conn_dict,
        cursor_factory="dict",
        min_size=2,
        max_size=10,
        max_idle=300,
        max_lifetime=1800,
        num_workers=3,
    ):
        """
        PostgreSQL 连接池客户端（使用 psycopg3 内置连接池）

        :param conn_dict: 连接配置字典，包含 host, user, password, dbname, port
        :param cursor_factory: 游标类型，dict/普通
        :param min_size: 普通连接池最小连接数
        :param max_size: 普通连接池最大连接数
        :param max_idle: 连接最大空闲时间（秒）
        :param max_lifetime: 连接最大生命周期（秒）
        :param num_workers: 连接池工作线程数
        """
        self.host = conn_dict["host"]
        self.user = conn_dict["user"]
        self.password = conn_dict["passwd"]
        self.dbname = conn_dict["db"]
        self.port = conn_dict["port"]
        self.cursor_factory = cursor_factory

        # 普通连接池配置参数
        self.min_size = min_size
        self.max_size = max_size
        self.max_idle = max_idle
        self.max_lifetime = max_lifetime
        self.num_workers = num_workers

        # 流式连接池配置参数
        self.stream_min_size = 1
        self.stream_max_size = 1

        # 普通连接池对象（懒加载，首次使用时创建）
        self._normal_pool = None

        # 流式连接池对象（懒加载，首次使用时创建）
        self._stream_pool = None

    def _get_row_factory(self):
        """根据配置获取行工厂类型"""
        if self.cursor_factory == "dict":
            return psycopg.rows.dict_row
        else:
            return psycopg.rows.tuple_row

    def _get_connection_params(self):
        """获取连接参数"""
        return {
            "host": self.host,
            "user": self.user,
            "password": self.password,
            "dbname": self.dbname,
            "port": self.port,
            "autocommit": True,
            "row_factory": self._get_row_factory(),
        }

    def _get_or_create_normal_pool(self):
        """获取或创建普通连接池（懒加载）"""
        if self._normal_pool is None:
            # 创建普通连接池
            self._normal_pool = ConnectionPool(
                conninfo=(
                    f"host={self.host} user={self.user} password={self.password} dbname={self.dbname} port={self.port}"
                ),
                min_size=self.min_size,
                max_size=self.max_size,
                max_idle=self.max_idle,
                max_lifetime=self.max_lifetime,
                num_workers=self.num_workers,
                open=False,
                kwargs={"autocommit": True, "row_factory": self._get_row_factory()},
            )
            # 打开连接池
            self._normal_pool.open()
        return self._normal_pool

    def _get_or_create_stream_pool(self):
        """获取或创建流式连接池（懒加载）"""
        if self._stream_pool is None:
            # 创建流式连接池
            self._stream_pool = ConnectionPool(
                conninfo=(
                    f"host={self.host} user={self.user} password={self.password} dbname={self.dbname} port={self.port}"
                ),
                min_size=self.stream_min_size,
                max_size=self.stream_max_size,
                max_idle=self.max_idle,
                max_lifetime=self.max_lifetime,
                num_workers=1,
                open=False,
                kwargs={"autocommit": False, "row_factory": self._get_row_factory()},
            )
            # 打开连接池
            self._stream_pool.open()
        return self._stream_pool

    def get_connection(self, pool_type="normal"):
        """
        从指定类型的连接池获取一个连接

        :param pool_type: 连接池类型，normal/stream
        :return: 连接对象
        """
        if pool_type == "stream":
            pool = self._get_or_create_stream_pool()
        else:
            pool = self._get_or_create_normal_pool()
        return pool.connection()

    def fetchone(self, sql):
        """
        查询单条记录
        :param sql: SQL 语句
        :return: 单条记录
        """
        with self.get_connection("normal") as conn:
            with conn.cursor() as cursor:
                cursor.execute(sql)
                result = cursor.fetchone()
                return result

    def fetchmany(self, sql, batch_size=100):
        """
        分批获取所有数据，每批返回一次

        :param sql: SQL 语句
        :param batch_size: 每批的数量，默认 100
        :return: 生成器，每次返回一批数据
        """
        with self.get_connection("normal") as conn:
            with conn.cursor() as cursor:
                cursor.execute(sql)
                while True:
                    batch = cursor.fetchmany(batch_size)
                    if not batch:
                        break
                    yield batch

    def fetchall(self, sql):
        """
        查询所有记录
        :param sql: SQL 语句
        :return: 所有记录列表
        """
        with self.get_connection("normal") as conn:
            with conn.cursor() as cursor:
                cursor.execute(sql)
                results = cursor.fetchall()
                return results

    def fetch_iter(self, sql, batch_size=1000):
        """
        流式查询，需要返回大数量时使用
        使用服务端游标逐批获取数据，避免内存溢出
        :param sql: SQL 语句
        :param batch_size: 每批获取的记录数，默认 1000
        :return: 生成器，可以迭代获取每条记录
        """
        with self.get_connection("stream") as conn:
            with conn.cursor(name="stream_cursor") as cursor:
                cursor.itersize = batch_size
                cursor.execute(sql)
                for row in cursor:
                    yield row

    def execute(self, sql, extend=False):
        """
        执行 SQL 语句（insert/update/delete 等）
        :param sql: SQL 语句
        :param extend: 是否扩展语句超时时间（PostgreSQL 特有）
        :return: 受影响的行数
        """
        with self.get_connection("normal") as conn:
            with conn.cursor() as cursor:
                try:
                    if extend:
                        cursor.execute("SET statement_timeout TO 0")
                    result = cursor.execute(sql)
                    return result
                except Exception as e:
                    conn.rollback()
                    raise e

    def executemany(self, sql, sqlDataList):
        """
        批量执行 SQL 语句
        :param sql: SQL 语句
        :param sqlDataList: 数据列表，如 [['a','b','c'], ['d','f','e']]
        :return: 受影响的行数
        """
        with self.get_connection("normal") as conn:
            with conn.cursor() as cursor:
                try:
                    result = cursor.executemany(sql, sqlDataList)
                    return result
                except Exception as e:
                    conn.rollback()
                    raise e

    def execute_isolation(self, sql):
        """
        在自动提交模式下执行 SQL 语句（PostgreSQL 特有）
        :param sql: SQL 语句
        :return: None
        """
        with self.get_connection("normal") as conn:
            with conn.cursor() as cursor:
                try:
                    # 临时设置隔离级别为 0（自动提交）
                    conn.execute("SET AUTOCOMMIT ON")
                    cursor.execute(sql)
                    conn.execute("SET AUTOCOMMIT OFF")
                except Exception as e:
                    conn.rollback()
                    raise e

    # 兼容旧版 API
    def query(self, sql):
        """
        查询所有记录（兼容旧版 API）
        :param sql: SQL 语句
        :return: 所有记录列表
        """
        return self.fetchall(sql)

    def close(self):
        """关闭所有连接池"""
        if self._normal_pool:
            self._normal_pool.close()
        if self._stream_pool:
            self._stream_pool.close()

    def __enter__(self):
        """支持上下文管理器"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出时关闭连接池"""
        self.close()


if __name__ == "__main__":
    conn_dict = {
        "host": "10.230.141.173",
        "user": "form_reader",
        "passwd": "xxxxxxxxxxxx",
        "db": "data",
        "port": 5432,
    }
    pg_client = PostgresClient(conn_dict, cursor_factory="dict")

    # 查询单条记录
    sql = "select ip_num,city from config.xxxxx limit 1"
    result = pg_client.fetchone(sql)
    print("fetchone:", result)

    # 分批获取数据
    total_count = 0
    for batch in pg_client.fetchmany("select ip_num,city from config.xxxxx limit 25", batch_size=5):
        print("当前批次数量:", len(batch))
        total_count += len(batch)
    print("fetchmany total:", total_count)

    # 查询所有记录
    sql = "select ip_num,city from config.xxxxx limit 10"
    results = pg_client.fetchall(sql)
    print("fetchall count:", len(results))

    # 流式查询
    count = 0
    for row in pg_client.fetch_iter("select ip_num,city from config.xxxxx limit 10"):
        count += 1
    print("fetch_iter:", count)

    # 执行 SQL
    pg_client.execute("create table if not exists test_pg_client(id serial, name varchar(50))")
    pg_client.execute("delete from test_pg_client")
    pg_client.execute("insert into test_pg_client(name) values('test1')")

    # 批量执行
    pg_client.executemany("insert into test_pg_client(name) values(%s)", [["test2"], ["test3"], ["test4"]])

    # 关闭连接池
    pg_client.close()
