# jcutils - Python 多功能工具库

**简介**
一个高效封装的 Python 工具库，集成大数据生态、数据库连接、云服务 API 及常用开发工具，助力快速开发与运维自动化。

---

## 🔧 **核心功能**

### 1. **数据库与大数据连接**
- **OLAP/OLTP 连接**
  - `clickhouse_client.py` / `presto_client.py`：高性能查询支持
  - `mysql_client.py` / `mssql_client.py`：连接池管理（`_pool.py`）
  - `hive_client.py` / `hbase_client.py`：大数据生态集成
- **云数据服务**
  - `dataworks_client.py`：阿里云DataWorks交互
  - `maxcompute_client.py`：MaxCompute（ODPS）操作

### 2. **消息与存储中间件**
- `kafka_client.py` / `pykafka_client.py`：Kafka 生产消费封装
- `redis_client.py`：Redis 连接与常用操作
- `hdfs_client.py` / `s3_client.py`：分布式文件系统操作

### 3. **企业服务集成**
- **微信生态**
  - `work_weixin_*.py`：企业微信消息推送、API 调用
  - `weixin_offiaccount.py`：公众号开发工具
- **钉钉**
  - `dingtalk.py` / `dingtalkoapi.py`：机器人通知与OA接口

### 4. **开发工具集**
- **效率工具**
  - `try_except_.py`：增强异常处理
  - `run_*_time.py`：代码性能监控装饰器
- **数据处理**
  - `date_encoder.py` / `relative_time.py`：时间格式化与计算
  - `tabulate_utils.py`：表格数据美化输出

---

## 🚀 **快速开始**

### 安装
```bash
pip install jcutils
```

### 使用示例
**1. 查询 ClickHouse**
```python
from jcutils.client.clickhouse_client import ClickHouseClient
client = ClickHouseClient(host="localhost", user="default")
print(client.execute("SELECT * FROM system.tables"))
```

**2. 发送企业微信消息**
```python
from jcutils.client.clientwork_weixin_bot import WeixinBot
bot = WeixinBot(webhook_url="YOUR_WEBHOOK")
bot.send_text("Alert: 服务器CPU负载超过90%")
```

**3. 性能监控**
```python
from jcutils.client.run_func_time import timeit

@timeit
def slow_function():
    import time
    time.sleep(2)

slow_function()  # 输出: [timeit] slow_function cost: 2.003s
```

---

## 🌟 **优势**
- **开箱即用**：统一接口设计，降低学习成本
- **生产级代码**：内置连接池、异常重试、日志记录
- **模块化**：按需引用，无冗余依赖

---

## 🤝 **贡献与反馈**
欢迎提交 Issue 或 PR！
- 需求建议：`https://github.com/lijc210/jcutils/issues`
- 代码贡献：Fork + Pull Request

---

## 📜 **License**
MIT
