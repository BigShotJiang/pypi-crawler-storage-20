import os
from pathlib import Path

import toml
from dotenv import load_dotenv

load_dotenv()  # 默认读取当前工作目录下的 .env

config_path = os.getenv("CONFIG_PATH")

if not config_path:
    config_path = "config/config.toml"

path = Path(config_path).expanduser().resolve()

with open(path, "r") as f:
    config = toml.load(f)
    # print(config)

    mysql_db1 = config["mysql"]["db1"]
    pg_db1 = config["postgres"]["db1"]
