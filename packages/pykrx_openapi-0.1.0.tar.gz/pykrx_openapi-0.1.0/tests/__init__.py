"""Tests for pykrx-openapi."""
