from concurrent.futures import ThreadPoolExecutor
import copy
import inspect
import re
import threading
import traceback
from typing import Iterable, TypeVar, cast
from prompt_toolkit.completion import CompleteEvent, Completer, Completion, NestedCompleter, WordCompleter
from prompt_toolkit.document import Document

from adam.utils import debug, debug_complete, log2, log_timing
from adam.utils_repl.appendable_completer import AppendableCompleter

import nest_asyncio
nest_asyncio.apply()

import asyncio

__all__ = [
    "ReplCompleter",
]

T = TypeVar('T')

def merge_completions(dict1, dict2):
    if isinstance(dict1, dict):
        target = dict1.copy()
    else:
        target = copy.copy(dict1)

    try:
        for key, value in dict2.items():
            if key in target:
                debug_complete(f'[{key}] {type(dict2)} is being merged to {type(target[key])} completions')
                if isinstance(value, dict):
                    if isinstance(target[key], dict):
                        target[key] = merge_completions(target[key], value)
                    elif isinstance(target[key], AppendableCompleter):
                        cast(AppendableCompleter, target[key]).append_completions(key, value)
                elif isinstance(value, AppendableCompleter):
                    if isinstance(target[key], dict):
                        cast(AppendableCompleter, value).append_completions(key, target[key])
                        target[key] = value
                    else:
                        log2(f'* {key} of {type(value)} is overriding existing {type(target[key])} completions')
                else:
                    target[key] = value
            else:
                target[key] = value

    except Exception as e:
        traceback.print_exc()

    return target

class ReplCompleter(NestedCompleter):
    def get_completions(
        self, document: Document, complete_event: CompleteEvent
    ) -> Iterable[Completion]:
        # Split document.
        text = document.text_before_cursor.lstrip()
        stripped_len = len(document.text_before_cursor) - len(text)

        # If there is a space, check for the first term, and use a
        # subcompleter.
        if " " in text:
            first_term = text.split()[0]
            completer = self.options.get(first_term)

            # If we have a sub completer, use this for the completions.
            if completer is not None:
                remaining_text = text[len(first_term) :].lstrip()
                move_cursor = len(text) - len(remaining_text) + stripped_len

                new_document = Document(
                    remaining_text,
                    cursor_position=document.cursor_position - move_cursor,
                )

                for c in completer.get_completions(new_document, complete_event):
                    yield c

        # No space in the input: behave exactly like `WordCompleter`.
        else:
            completer = WordCompleter(
                # Allow dot in the middle or a word
                list(self.options.keys()), ignore_case=self.ignore_case, pattern=re.compile(r"([a-zA-Z0-9_\.\@\&]+|[^a-zA-Z0-9_\.\@\&\s]+)")
            )
            for c in completer.get_completions(document, complete_event):
                yield c

lock = threading.Lock()
in_queue = set()

def preload(action: callable, log_key: str = None):
    with lock:
        if not LazyNestedCompleter.loop:
            LazyNestedCompleter.loop = asyncio.new_event_loop()
            LazyNestedCompleter.async_exec = ThreadPoolExecutor(max_workers=6, thread_name_prefix='async')
            LazyNestedCompleter.loop.set_default_executor(LazyNestedCompleter.async_exec)

        # some lib does not handle asyncio loop properly, as sync exec submit does not work, use another async loop
        async def a():
            try:
                arg_needed = len(action.__code__.co_varnames)

                if log_key:
                    with log_timing(log_key):
                        r = action(None) if arg_needed else action()
                else:
                    r = action(None) if arg_needed else action()
                if inspect.isawaitable(r):
                    await r

                in_queue.remove(log_key)
            except Exception as e:
                log2('preloading error', e, inspect.getsourcelines(action)[0][0])
                traceback.print_exc()

        if log_key not in in_queue:
            in_queue.add(log_key)
            LazyNestedCompleter.async_exec.submit(lambda: LazyNestedCompleter.loop.run_until_complete(a()))

class LazyNestedCompleter(NestedCompleter):
    loop: asyncio.AbstractEventLoop = None
    async_exec: ThreadPoolExecutor = None

    def __init__(self, name: str, options_lambda: callable, ignore_case: bool = True, auto: str = 'lazy') -> None:
        super().__init__(None, ignore_case)
        self.options_lambda = options_lambda
        if auto == 'lazy':
            preload(options_lambda, log_key=name)

    def __repr__(self) -> str:
        return "LazyNestedCompleter(%r, ignore_case=%r)" % (self.options, self.ignore_case)

    def get_completions(
        self, document: Document, complete_event: CompleteEvent
    ) -> Iterable[Completion]:
        if not self.options:
            self.options = self.options_lambda()

        # Split document.
        text = document.text_before_cursor.lstrip()
        stripped_len = len(document.text_before_cursor) - len(text)

        # If there is a space, check for the first term, and use a
        # subcompleter.
        if " " in text:
            first_term = text.split()[0]
            completer = self.options.get(first_term)

            # If we have a sub completer, use this for the completions.
            if completer is not None:
                remaining_text = text[len(first_term) :].lstrip()
                move_cursor = len(text) - len(remaining_text) + stripped_len

                new_document = Document(
                    remaining_text,
                    cursor_position=document.cursor_position - move_cursor,
                )

                for c in completer.get_completions(new_document, complete_event):
                    yield c

        # No space in the input: behave exactly like `WordCompleter`.
        else:
            completer = WordCompleter(
                list(self.options.keys()), ignore_case=self.ignore_case
            )
            for c in completer.get_completions(document, complete_event):
                yield c