"""
Member protection handler (bot/ban/kick protection).
"""
import discord
import asyncio
from ..models import ThreatEvent


class MemberHandler:
    """Handles member-related protection"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_member_join(self, member: discord.Member):
        """Detect and ban unauthorized/unverified bot additions"""
        try:
            if not member.bot:
                return  # Only check bots
            
            guild = member.guild
            await asyncio.sleep(1)
            
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.bot_add):
                if entry.target.id == member.id:
                    is_verified = member.public_flags.verified_bot
                    is_allowed = await self._is_authorized(guild, entry.user.id)
                    
                    should_ban = not is_verified or not is_allowed
                    
                    if should_ban:
                        await member.ban(reason="SecureX: Unauthorized/unverified bot")
                        
                        threat = ThreatEvent(
                            type="bot_join",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=member.id,
                            target_name=member.name,
                            prevented=True,
                            restored=False,
                            details={"verified": is_verified}
                        )
                        
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in member_join handler: {e}")
    
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        """Detect and revert unauthorized bans"""
        try:
            await asyncio.sleep(0.5)
            
            async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.ban):
                if entry.target.id == user.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        # Ban attacker
                        await guild.ban(entry.user, reason="SecureX: Unauthorized ban action")
                        # Unban victim
                        await guild.unban(user, reason="SecureX: Restoring banned member")
                        
                        threat = ThreatEvent(
                            type="member_ban",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=user.id,
                            target_name=str(user),
                            prevented=True,
                            restored=True,
                            details={"victim": str(user)}
                        )
                        
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in member_ban handler: {e}")
    
    async def on_member_remove(self, member: discord.Member):
        """Detect and punish unauthorized kicks"""
        try:
            guild = member.guild
            await asyncio.sleep(0.5)
            
            async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.kick):
                if entry.target.id == member.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        # Ban attacker
                        await guild.ban(entry.user, reason="SecureX: Unauthorized kick action")
                        
                        threat = ThreatEvent(
                            type="member_kick",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=member.id,
                            target_name=str(member),
                            prevented=True,
                            restored=False,
                            details={"victim": str(member)}
                        )
                        
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in member_remove handler: {e}")
