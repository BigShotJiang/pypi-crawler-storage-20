"""
Role protection handler for SecureX SDK.
"""
import discord
import asyncio
from datetime import datetime, timedelta
from ..models import ThreatEvent


class RoleHandler:
    """Handles role protection logic"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_manager = sdk.backup_manager
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_role_create(self, role: discord.Role):
        """Detect and punish unauthorized role creation immediately"""
        try:
            guild = role.guild
            await asyncio.sleep(0.5)  # Brief delay for audit log
            
            # Check audit log for this specific role creation
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.role_create):
                if entry.target.id == role.id:
                    # Check if authorized
                    if not await self._is_authorized(guild, entry.user.id):
                        print(f"🚨 Unauthorized role creation by {entry.user.name}: {role.name}")
                        
                        # Punish immediately
                        punishment_action = await self.sdk.punisher.punish(
                            guild=guild,
                            user=entry.user,
                            violation_type="role_create",
                            details=f"Created role: {role.name}",
                            sdk=self.sdk
                        )
                        print(f"✅ Punished {entry.user.name}: {punishment_action}")
                        
                        # Delete the spam role
                        try:
                            await role.delete(reason="SecureX: Unauthorized role creation")
                            print(f"🗑️ Deleted unauthorized role: {role.name}")
                        except discord.errors.NotFound:
                            pass
                        except Exception as e:
                            print(f"Error deleting role: {e}")
                        
                        # Create threat event
                        threat = ThreatEvent(
                            type="role_create",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=role.id,
                            target_name=role.name,
                            prevented=True,
                            restored=False,
                            punishment_action=punishment_action
                        )
                        
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
                    
        except Exception as e:
            print(f"Error in role_create handler: {e}")
    
    async def on_role_delete(self, role: discord.Role):
        """Detect and restore unauthorized role deletion"""
        try:
            guild = role.guild
            await asyncio.sleep(1)
            
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.role_delete):
                if entry.target.id == role.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        # Restore role from backup
                        restored = await self.backup_manager.restore_role(guild, role.id)
                        
                        threat = ThreatEvent(
                            type="role_delete",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=role.id,
                            target_name=role.name,
                            prevented=True,
                            restored=restored
                        )
                        
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in role_delete handler: {e}")
    
    async def on_role_update(self, before: discord.Role, after: discord.Role):
        """Detect unauthorized role permission/position changes"""
        try:
            # Only check if position or permissions changed
            if before.position == after.position and before.permissions == after.permissions:
                return
            
            guild = after.guild
            await asyncio.sleep(0.3)
            
            async for entry in guild.audit_logs(limit=3, oldest_first=False):
                if entry.action == discord.AuditLogAction.role_update:
                    if entry.target.id == after.id:
                        if not await self._is_authorized(guild, entry.user.id):
                            # Restore role to backup state
                            restored = await self.backup_manager.restore_role_permissions(guild, after.id)
                            
                            threat = ThreatEvent(
                                type="role_update",
                                guild_id=guild.id,
                                actor_id=entry.user.id,
                                target_id=after.id,
                                target_name=after.name,
                                prevented=True,
                                restored=restored,
                                details={"changed": "permissions/position"}
                            )
                            
                            await self.sdk._trigger_callbacks('threat_detected', threat)
                        break
        except Exception as e:
            print(f"Error in role_update handler: {e}")
