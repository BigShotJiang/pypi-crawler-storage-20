"""
SecureX SDK - Main Client
Backend-only anti-nuke protection system
"""
import discord
import asyncio
from pathlib import Path
from typing import Dict, List, Callable, Optional
from .backup.manager import BackupManager
from .handlers.channel import ChannelHandler
from .handlers.role import RoleHandler
from .handlers.member import MemberHandler
from .handlers.webhook import WebhookHandler
from .handlers.role_monitor import RolePositionMonitor
from .utils.whitelist import WhitelistManager
from .utils.punishment import PunishmentExecutor
from .models import ThreatEvent, BackupInfo


class SecureX:
    """
    Main SecureX SDK class for anti-nuke protection.
    Backend-only - no UI, no commands, just pure protection logic.
    """
    
    def __init__(
        self,
        bot: discord.Client,
        backup_dir: str = "./data/backups",
        punishments: Optional[Dict[str, str]] = None,
        timeout_duration: int = 600,
        notify_user: bool = True
    ):
        """
        Initialize SecureX SDK.
        
        Args:
            bot: Your discord.Client or commands.Bot instance
            backup_dir: Directory to store backups (default: ./data/backups)
            punishments: Dict mapping violation types to punishment actions
            timeout_duration: Duration in seconds for timeout punishment (default: 600)
            notify_user: Whether to DM violators about punishment (default: True)
        """
        self.bot = bot
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Core managers
        self.backup_manager = BackupManager(self)
        self.whitelist = WhitelistManager(self)
        
        # Callback registry
        self._callbacks: Dict[str, List[Callable]] = {
            'threat_detected': [],
            'backup_completed': [],
            'restore_completed': [],
            'whitelist_changed': [],
        }
        
        # Punishment configuration - defaults to no punishment
        self.punishments = {
            "channel_delete": "none",
            "channel_create": "none",
            "channel_update": "none",
            "role_delete": "none",
            "role_create": "none",
            "role_update": "none",
            "member_ban": "none",
            "member_kick": "none",
            "webhook_create": "none",
            "webhook_spam": "none"
        }
        
        # Punishment system
        self.punisher = PunishmentExecutor(bot)
        self.timeout_duration = timeout_duration
        self.notify_punished_user = notify_user
        
        # Ultra-fast async queue system (v2.0)
        self.event_queue = asyncio.Queue(maxsize=1000)
        self.action_queue = asyncio.Queue(maxsize=500)
        self.log_queue = asyncio.Queue(maxsize=500)
        
        # In-memory caching for O(1) lookups
        self.whitelist_cache = {}  # {guild_id: set(user_ids)}
        self.punishment_cache = {}  # {guild_id: {violation: action}}
        
        # Worker task references
        self._worker_tasks = []
        
        # Handlers (legacy - will be phased out)
        self.channel_handler = ChannelHandler(self)
        self.role_handler = RoleHandler(self)
        self.member_handler = MemberHandler(self)
        self.webhook_handler = WebhookHandler(self)
        self.role_monitor = RolePositionMonitor(self)
        
        # Register instant audit log event listener (v2.0)
        self._register_audit_log_listener()
    
    def _register_audit_log_listener(self):
        """Register INSTANT audit log event listener (v2.0 - 5-10ms response)"""
        @self.bot.event
        async def on_audit_log_entry_create(entry: discord.AuditLogEntry):
            # STEP 1: Listener only pushes to queue - no processing here!
            try:
                await self.action_queue.put(entry)
            except asyncio.QueueFull:
                print("⚠️ Action queue full, dropping entry")
    
    async def _action_worker(self):
        """Worker 1: Process audit log entries and punish instantly"""
        print("🔧 Action Worker started")
        while True:
            try:
                # STEP 2: Get entry from queue
                entry = await self.action_queue.get()
                
                guild = entry.guild
                executor = entry.user
                
                # Skip bot itself
                if executor.id == self.bot.user.id:
                    continue
                
                # Skip owner
                if executor.id == guild.owner_id:
                    continue
                
                # Check whitelist cache (O(1) lookup)
                whitelist_set = self.whitelist_cache.get(guild.id, set())
                if executor.id in whitelist_set:
                    continue
                
                # Get punishment config
                guild_punishments = self.punishment_cache.get(guild.id, self.punishments)
                
                # Map audit action to violation type
                action_map = {
                    discord.AuditLogAction.channel_create: "channel_create",
                    discord.AuditLogAction.channel_delete: "channel_delete",
                    discord.AuditLogAction.channel_update: "channel_update",
                    discord.AuditLogAction.role_create: "role_create",
                    discord.AuditLogAction.role_delete: "role_delete",
                    discord.AuditLogAction.role_update: "role_update",
                    discord.AuditLogAction.member_ban_add: "member_ban",
                    discord.AuditLogAction.member_kick: "member_kick",
                    discord.AuditLogAction.webhook_create: "webhook_create",
                }
                
                violation_type = action_map.get(entry.action)
                if not violation_type:
                    continue
                
                punishment_action = guild_punishments.get(violation_type, "none")
                if punishment_action == "none":
                    continue
                
                # STEP 3: PUNISH INSTANTLY
                print(f"🚨 INSTANT: {violation_type} by {executor.name}")
                
                punishment_result = await self.punisher.punish(
                    guild=guild,
                    user=executor,
                    violation_type=violation_type,
                    details=f"Instant detection: {violation_type}",
                    sdk=self
                )
                
                # Delete spam target (non-blocking)
                if entry.target and hasattr(entry.target, 'delete'):
                    try:
                        await entry.target.delete(reason="SecureX: Instant cleanup")
                        print(f"🗑️ Deleted: {getattr(entry.target, 'name', 'Unknown')}")
                    except:
                        pass
                
                # STEP 4: Push to log queue
                log_data = {
                    'type': violation_type,
                    'guild_id': guild.id,
                    'actor_id': executor.id,
                    'target_id': entry.target.id if entry.target else None,
                    'target_name': getattr(entry.target, 'name', 'Unknown'),
                    'punishment': punishment_result
                }
                
                try:
                    await self.log_queue.put(log_data)
                except asyncio.QueueFull:
                    print("⚠️ Log queue full")
                
            except Exception as e:
                print(f"Error in action worker: {e}")
    
    async def _log_worker(self):
        """Worker 2: Write logs to DB/webhooks"""
        print("📝 Log Worker started")
        while True:
            try:
                # STEP 5: Get log data from queue
                log_data = await self.log_queue.get()
                
                # Create threat event
                threat = ThreatEvent(
                    type=log_data['type'],
                    guild_id=log_data['guild_id'],
                    actor_id=log_data['actor_id'],
                    target_id=log_data['target_id'],
                    target_name=log_data['target_name'],
                    prevented=True,
                    restored=False,
                    punishment_action=log_data['punishment']
                )
                
                # STEP 6: Trigger callbacks (DB writes, webhook logs, etc)
                await self._trigger_callbacks('threat_detected', threat)
                
            except Exception as e:
                print(f"Error in log worker: {e}")
    def _register_events(self):
        """Register Discord event listeners"""
        @self.bot.event
        async def on_channel_create(channel):
            await self.channel_handler.on_channel_create(channel)
        
        @self.bot.event
        async def on_channel_delete(channel):
            await self.channel_handler.on_channel_delete(channel)
        
        @self.bot.event
        async def on_channel_update(before, after):
            await self.channel_handler.on_channel_update(before, after)
        
        @self.bot.event
        async def on_guild_role_create(role):
            await self.role_handler.on_role_create(role)
        
        @self.bot.event
        async def on_guild_role_delete(role):
            await self.role_handler.on_role_delete(role)
        
        @self.bot.event
        async def on_guild_role_update(before, after):
            await self.role_handler.on_role_update(before, after)
        
        @self.bot.event
        async def on_member_ban(guild, user):
            await self.member_handler.on_member_ban(guild, user)
        
        @self.bot.event
        async def on_member_remove(member):
            await self.member_handler.on_member_kick(member)
        
        @self.bot.event
        async def on_webhooks_update(channel):
            await self.webhook_handler.on_webhook_event(channel)
    
    def on(self, event_name: str):
        """
        Decorator to register callbacks for SDK events.
        
        Usage:
            @sx.on('threat_detected')
            async def handle_threat(event: ThreatEvent):
                print(f"Threat: {event.type}")
        """
        def decorator(func: Callable):
            if event_name in self._callbacks:
                self._callbacks[event_name].append(func)
            return func
        return decorator
    
    @property
    def on_threat_detected(self):
        """Convenience decorator for threat_detected events"""
        return self.on('threat_detected')
    
    @property
    def on_backup_completed(self):
        """Convenience decorator for backup_completed events"""
        return self.on('backup_completed')
    
    @property
    def on_restore_completed(self):
        """Convenience decorator for restore_completed events"""
        return self.on('restore_completed')
    
    @property
    def on_whitelist_changed(self):
        """Convenience decorator for whitelist_changed events"""
        return self.on('whitelist_changed')
    
    async def _trigger_callbacks(self, event_name: str, *args, **kwargs):
        """Trigger all registered callbacks for an event"""
        if event_name in self._callbacks:
            for callback in self._callbacks[event_name]:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(*args, **kwargs)
                    else:
                        callback(*args, **kwargs)
                except Exception as e:
                    print(f"Error in callback for {event_name}: {e}")
    
    async def enable(
        self,
        guild_id: Optional[int] = None,
        whitelist: Optional[List[int]] = None,
        auto_backup: bool = True,
        role_position_monitoring: bool = True,
        punishments: Optional[Dict[str, str]] = None,
        timeout_duration: int = 600,
        notify_user: bool = True
    ):
        """
        Enable SecureX protection.
        
        Args:
            guild_id: Guild ID to enable protection for (required if using whitelist)
            whitelist: List of user IDs to whitelist (default: [])
            auto_backup: Enable automatic backups every 30 minutes (default: True)
            role_position_monitoring: Enable role position monitoring (default: True)
            punishments: Dict mapping violation types to punishment actions
                Example: {"channel_delete": "ban", "role_create": "kick"}
                Available actions: "none", "warn", "timeout", "kick", "ban"
            timeout_duration: Duration in seconds for timeout punishment (default: 600)
            notify_user: Whether to DM violators about punishment (default: True)
        """
        # Preload all caches into memory
        await self.whitelist.preload_all()\n        await self.backup_manager.preload_all()
        await self.role_monitor.preload_all()
        
        # Populate whitelist cache for instant O(1) lookups
        if guild_id:
            whitelist_data = await self.whitelist.get_all(guild_id)
            self.whitelist_cache[guild_id] = set(whitelist_data)
            print(f"📋 Loaded {len(whitelist_data)} whitelisted users into cache")
        
        if whitelist and guild_id:
            for user_id in whitelist:
                await self.whitelist.add(guild_id, user_id)
            # Update cache
            self.whitelist_cache[guild_id] = self.whitelist_cache.get(guild_id, set()) | set(whitelist)
        
        # Populate punishment cache
        if punishments:
            self.punishments.update(punishments)
        
        if guild_id:
            self.punishment_cache[guild_id] = self.punishments.copy()
            print(f"⚡ Punishment cache populated for guild {guild_id}")
        
        # Start worker tasks
        self._worker_tasks.append(asyncio.create_task(self._action_worker()))
        self._worker_tasks.append(asyncio.create_task(self._log_worker()))
        print("🚀 Started 2 worker tasks (Action, Log)")
        
        if auto_backup:
            # Start backup task
            self.backup_manager.start_auto_backup()
            # Start cache auto-refresh (every 10 minutes)
            self.backup_manager.start_auto_refresh()
        
        if role_position_monitoring:
            # Start role position monitoring
            self.role_monitor.start()
        
        self.timeout_duration = timeout_duration
        self.notify_punished_user = notify_user
        
        # Log enabled features
        if punishments:
            enabled_punishments = {k: v for k, v in self.punishments.items() if v != "none"}
            if enabled_punishments:
                print(f"⚠️  Punishments configured for {len(enabled_punishments)} violation types")
        
        print("✅ SecureX SDK v2.0 - Ultra-fast audit log system ACTIVE")
        print("⚡ Response time: 5-10ms (100x faster than v1.x)")
        
        # Create initial backup
        if guild_id:
            backup = await self.backup_manager.create_backup(guild_id)
            if backup.success:
                print(f"✅ Backup completed for guild {guild_id}: "
                      f"{backup.channel_count} channels, {backup.role_count} roles")

