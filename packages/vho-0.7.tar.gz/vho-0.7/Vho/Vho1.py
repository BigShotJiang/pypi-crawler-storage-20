import torch
import random
import os
import imageio
from diffusers import (
    StableDiffusionPipeline,
    AnimateDiffPipeline,
    DPMSolverMultistepScheduler,
    MotionAdapter
)
from deep_translator import GoogleTranslator

# ==================================================
# DEVICE
# ==================================================
device = "cuda" if torch.cuda.is_available() else "cpu"
dtype = torch.float16 if device == "cuda" else torch.float32

FIXED_OUTPUT_FILE = "vho1.png"

# ==================================================
# PROMPT MAP
# ==================================================
TR_STYLE_MAP = {
    "gerçekçi": "realistic",
    "sinematik": "cinematic lighting",
    "anime": "anime style",
    "çizgi film": "cartoon style",
    "karanlık": "dark dramatic mood",
    "neon": "neon cyberpunk lighting",
    "portre": "portrait photography",
    "detaylı": "highly detailed",
    "fantastik": "fantasy art",
    "bilim kurgu": "science fiction",
    "minimal": "minimalist composition"
}

QUALITY_LOCK = (
    "masterpiece, ultra high quality, professional photography, "
    "sharp focus, perfect lighting, high detail, clean composition"
)

NEGATIVE_LOCK = (
    "worst quality, low quality, lowres, blurry, jpeg artifacts, "
    "bad anatomy, bad proportions, extra fingers, missing fingers, "
    "extra limbs, fused fingers, malformed hands, "
    "deformed face, asymmetrical face, cross eye, lazy eye, "
    "distorted body, mutated, ugly"
)

translator = GoogleTranslator(source="tr", target="en")

# ==================================================
# PROMPT BUILDER (AYNI)
# ==================================================
def _build_prompt(prompt_tr: str) -> str:
    translated = translator.translate(prompt_tr)
    prompt_lower = prompt_tr.lower()

    styles = []
    for tr, en in TR_STYLE_MAP.items():
        if tr in prompt_lower:
            styles.append(en)

    parts = [translated]
    if styles:
        parts.append(", ".join(styles))
    parts.append(QUALITY_LOCK)

    return ", ".join(parts)

# ==================================================
# IMAGE PIPELINE (ANA KODUN AYNISI)
# ==================================================
_image_pipe = StableDiffusionPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    torch_dtype=dtype,
    safety_checker=None
).to(device)

_image_pipe.scheduler = DPMSolverMultistepScheduler.from_config(
    _image_pipe.scheduler.config
)
_image_pipe.enable_attention_slicing()

# ==================================================
# VIDEO PIPELINE (AnimateDiff – 24 FRAME SABİT)
# ==================================================
_motion_adapter = MotionAdapter.from_pretrained(
    "guoyww/animatediff-motion-adapter-v1-5",
    torch_dtype=dtype
)

_video_pipe = AnimateDiffPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    motion_adapter=_motion_adapter,
    torch_dtype=dtype,
    safety_checker=None
).to(device)

_video_pipe.scheduler = DPMSolverMultistepScheduler.from_config(
    _video_pipe.scheduler.config
)
_video_pipe.enable_attention_slicing()

# ==================================================
# IMAGE FUNCTION (HİÇ BOZULMADI)
# ==================================================
def create_text(
    prompt: str,
    kalite: float = 7.5,
    cfg: float = 7.5,
    steps: int | None = None,
    seed: int | None = None,
    filename: str | None = None
) -> str:

    final_prompt = _build_prompt(prompt)

    if steps is None:
        steps = int(20 + (kalite * 2))

    if seed is None:
        seed = random.randint(0, 999999999)

    generator = torch.Generator(device=device).manual_seed(seed)

    image = _image_pipe(
        prompt=final_prompt,
        negative_prompt=NEGATIVE_LOCK,
        num_inference_steps=steps,
        guidance_scale=float(cfg),
        generator=generator
    ).images[0]

    filename = FIXED_OUTPUT_FILE

    if os.path.exists(filename):
        os.remove(filename)

    image.save(filename)
    return os.path.abspath(filename)

# ==================================================
# VIDEO FUNCTION (STABİL – HATASIZ)
# ==================================================
def create_video(
    prompt: str,
    fps: int = 8,                  # süre = 24 / fps
    kalite: float = 7.5,
    cfg: float = 7.5,
    seed: int | None = None,
    filename: str = "vho1.mp4"
) -> str:

    NUM_FRAMES = 24  # AnimateDiff ZORUNLU SABİT

    final_prompt = _build_prompt(prompt)

    if seed is None:
        seed = random.randint(0, 999999999)

    generator = torch.Generator(device=device).manual_seed(seed)
    steps = int(20 + (kalite * 2))

    frames = _video_pipe(
        prompt=final_prompt,
        negative_prompt=NEGATIVE_LOCK,
        num_frames=NUM_FRAMES,
        num_inference_steps=steps,
        guidance_scale=float(cfg),
        generator=generator
    ).frames[0]

    imageio.mimsave(
        filename,
        frames,
        fps=fps,
        codec="libx264",
        quality=8
    )

    return os.path.abspath(filename)