"""Registry for managing loaded skills per user session."""

from pathlib import Path

import frontmatter
from podkit import SessionProxy, get_docker_session
from podkit.core.models import ContainerConfig, Mount

from aixtools.context import SessionIdTuple
from aixtools.logging.logging_config import get_logger
from aixtools.server import get_session_id_tuple
from aixtools.server.path import WORKSPACES_ROOT_DIR
from aixtools.skills.model import ActivateSkillResult, Skill, SkillException, SkillResult, SkillSummary

logger = get_logger(__name__)

SKILL_FILE_NAME = "SKILL.md"
SKILLS_WORKSPACE_DIR = "skills"
METADATA_SANDBOX_IMAGE = "sandbox_image"
SKILL_CONTAINER_PATH = "/skills"


class SkillRegistry:
    """Registry for managing skills loaded from SKILL.md files."""

    def __init__(self, skills_folder: Path | None = None):
        self._skills: dict[str, Skill] = {}
        self._skill_sources: dict[str, Path] = {}
        self._session_proxies: dict[str, SessionProxy] = {}
        if skills_folder:
            self._load_skills_from_folder(skills_folder)

    def activate_skill(self, skill_name: str) -> ActivateSkillResult:
        """Activate a skill by loading its definition and returning instructions.

        Note: Containers are created lazily when skill_exec is first called.
        """
        skill = self._skills.get(skill_name)
        if not skill:
            return ActivateSkillResult(success=False, message=f"Skill '{skill_name}' not found.")
        logger.info("Activated skill: %s", skill_name)
        return ActivateSkillResult(
            success=True,
            skill=SkillResult(**skill.model_dump(exclude={"metadata"})),
        )

    def get_session_proxy(self, skill_name: str) -> SessionProxy | None:
        """Get session proxy for skill's container in current session."""
        return self._session_proxies.get(skill_name)

    def get_skill_source_path(self, skill_name: str) -> Path | None:
        """Get the source path for a skill."""
        return self._skill_sources.get(skill_name)

    def ensure_sandbox(self, skill_name: str) -> SessionProxy:
        """Ensure sandbox container exists for this skill and session, creating if needed.

        Raises:
            Exception: If skill not found or container creation fails
        """
        if skill_name in self._session_proxies:
            logger.debug("Reusing existing sandbox for skill: %s", skill_name)
            return self._session_proxies[skill_name]

        skill = self._skills.get(skill_name)
        if not skill:
            raise SkillException(f"Skill '{skill_name}' not found.")

        (user_id, session_id) = get_session_id_tuple()
        session_proxy = self._start_sandbox((user_id, session_id), skill)
        self._session_proxies[skill.name] = session_proxy
        logger.info(
            "Started sandbox for skill: %s, image: %s, user: %s, session: %s",
            skill.name,
            skill.metadata.get(METADATA_SANDBOX_IMAGE),
            user_id,
            session_id,
        )

        return session_proxy

    def _start_sandbox(self, ctx: SessionIdTuple, skill: Skill) -> SessionProxy:
        """Start sandbox container for the skill if sandbox_image is configured."""
        source_path = self._skill_sources.get(skill.name)
        if not source_path:
            raise SkillException(f"Skill '{skill.name}' not found.")

        sandbox_image = skill.metadata.get(METADATA_SANDBOX_IMAGE)
        if not sandbox_image:
            raise SkillException(f"No sandbox_image configured for skill: {skill.name}")

        user_id, session_id = ctx
        config = ContainerConfig(
            image=sandbox_image,
            container_lifetime_seconds=300,
            volumes=[
                Mount(source=source_path, target=Path(SKILL_CONTAINER_PATH) / skill.name, read_only=True),
            ],
        )

        return get_docker_session(
            user_id=user_id,
            session_id=session_id,
            workspace=WORKSPACES_ROOT_DIR,
            workspace_host=WORKSPACES_ROOT_DIR,
            config=config,
        )

    def get_skill(self, name: str) -> Skill | None:
        """Get a skill by its name."""
        return self._skills.get(name)

    def list_skills(self) -> list[SkillSummary]:
        """Return list of available skills with name and description."""
        return [SkillSummary(name=skill.name, description=skill.description) for skill in self._skills.values()]

    def load_skill(self, path: Path) -> Skill | None:
        """Load a skill compatible with anthropic skills specs: https://agentskills.io/specification"""
        try:
            skill_file = path / SKILL_FILE_NAME
            skill_meta_data = frontmatter.load(str(skill_file))
            instructions = skill_meta_data.content.strip()

            # Extract metadata from nested 'metadata' section in frontmatter
            raw_metadata = skill_meta_data.metadata.get("metadata", {})
            metadata = {k: str(v) for k, v in raw_metadata.items()} if isinstance(raw_metadata, dict) else {}

            skill = Skill(
                name=str(skill_meta_data["name"]),
                description=str(skill_meta_data["description"]),
                instructions=instructions,
                metadata=metadata,
            )
            self._skills[skill.name] = skill
            self._skill_sources[skill.name] = path
            logger.info("Loaded skill: %s from %s", skill.name, path)
            return skill
        except Exception as e:  # pylint: disable=broad-exception-caught
            logger.error("Failed to load skill from %s: %s", path, e)
            return None

    def _load_skills_from_folder(self, folder: Path) -> list[Skill]:
        """Load all skills from a folder containing skill subdirectories."""
        loaded_skills = []
        if not folder.exists():
            logger.warning("Skills folder does not exist: %s", folder)
            return loaded_skills
        for skill_dir in folder.iterdir():
            if skill_dir.is_dir() and (skill_dir / SKILL_FILE_NAME).exists():
                skill = self.load_skill(skill_dir)
                if skill:
                    loaded_skills.append(skill)
        return loaded_skills
