"""CLI command tests."""
