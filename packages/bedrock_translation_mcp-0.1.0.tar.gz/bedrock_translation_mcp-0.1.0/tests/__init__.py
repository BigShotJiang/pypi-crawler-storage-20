"""Tests for Translation Power"""
