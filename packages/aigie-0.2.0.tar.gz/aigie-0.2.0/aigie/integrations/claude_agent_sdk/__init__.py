"""
Claude Agent SDK integration for Aigie.

This module provides automatic tracing for the official Anthropic Claude Agent SDK,
capturing query execution, tool usage, and conversation sessions.

Usage:
    # Manual handler usage
    from aigie.integrations.claude_agent_sdk import ClaudeAgentSDKHandler

    handler = ClaudeAgentSDKHandler(trace_name="my-agent")
    # ... use with claude_agent_sdk

    # Auto-instrumentation
    from aigie.integrations.claude_agent_sdk import patch_claude_agent_sdk
    patch_claude_agent_sdk()  # Patches query(), ClaudeSDKClient, etc.
"""

from .handler import ClaudeAgentSDKHandler
from .auto_instrument import (
    patch_claude_agent_sdk,
    unpatch_claude_agent_sdk,
    is_claude_agent_sdk_patched,
)
from .config import ClaudeAgentSDKConfig
from .cost_tracking import calculate_claude_cost, CLAUDE_MODEL_PRICING

__all__ = [
    "ClaudeAgentSDKHandler",
    "ClaudeAgentSDKConfig",
    "patch_claude_agent_sdk",
    "unpatch_claude_agent_sdk",
    "is_claude_agent_sdk_patched",
    "calculate_claude_cost",
    "CLAUDE_MODEL_PRICING",
]
