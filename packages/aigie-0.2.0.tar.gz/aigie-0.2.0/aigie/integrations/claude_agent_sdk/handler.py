"""
Claude Agent SDK callback handler for Aigie SDK.

Provides automatic tracing for Claude Agent SDK query execution,
tool usage, and conversation sessions.
"""

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from ...buffer import EventType
from .cost_tracking import calculate_claude_cost


class ClaudeAgentSDKHandler:
    """
    Claude Agent SDK handler for Aigie tracing.

    Automatically traces Claude Agent SDK executions including:
    - Query execution (stateless)
    - Client sessions (stateful)
    - Tool use with PreToolUse/PostToolUse hooks
    - Message streaming and costs
    - Token usage tracking

    Example:
        >>> from claude_agent_sdk import query
        >>> from aigie.integrations.claude_agent_sdk import ClaudeAgentSDKHandler
        >>>
        >>> handler = ClaudeAgentSDKHandler(
        ...     trace_name='research-agent',
        ...     metadata={'project': 'analysis'}
        ... )
        >>>
        >>> # Manual usage
        >>> await handler.handle_query_start("What is the capital of France?", {})
        >>> # ... execute query
        >>> await handler.handle_query_end(query_id, messages, result_message)
    """

    def __init__(
        self,
        trace_name: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        capture_tool_results: bool = True,
        capture_messages: bool = True,
    ):
        """
        Initialize Claude Agent SDK handler.

        Args:
            trace_name: Name for the trace
            metadata: Additional metadata to attach
            tags: Tags to apply to trace and spans
            user_id: User ID for the trace
            session_id: Session ID for the trace
            capture_tool_results: Whether to capture tool results
            capture_messages: Whether to capture message content
        """
        self.trace_name = trace_name
        self.metadata = metadata or {}
        self.tags = tags or []
        self.user_id = user_id
        self.session_id = session_id
        self.capture_tool_results = capture_tool_results
        self.capture_messages = capture_messages

        # State tracking
        self.trace_id: Optional[str] = None
        self.query_span_id: Optional[str] = None
        self.session_span_id: Optional[str] = None
        self.tool_map: Dict[str, Dict[str, Any]] = {}  # tool_use_id -> {spanId, startTime}
        self.turn_map: Dict[str, Dict[str, Any]] = {}  # turn_id -> {spanId, startTime}

        # Current context for parent relationships
        self._current_query_span_id: Optional[str] = None
        self._current_turn_span_id: Optional[str] = None
        self._aigie = None
        self._trace_context: Optional[Any] = None

        # Statistics
        self.total_turns = 0
        self.total_tool_calls = 0
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_cache_read_tokens = 0
        self.total_cache_creation_tokens = 0
        self.total_cost = 0.0

    def _get_aigie(self):
        """Lazy load Aigie client."""
        if self._aigie is None:
            from ...client import get_aigie
            self._aigie = get_aigie()
        return self._aigie

    def set_trace_context(self, trace_context: Any) -> None:
        """Set an existing trace context to use."""
        self._trace_context = trace_context
        if hasattr(trace_context, 'id'):
            self.trace_id = str(trace_context.id)

    async def handle_query_start(
        self,
        prompt: str,
        options: Dict[str, Any],
        model: Optional[str] = None,
    ) -> str:
        """
        Called when a query() call starts.

        Args:
            prompt: The prompt being sent
            options: Query options (tools, system_prompt, etc.)
            model: The model being used

        Returns:
            The query ID for tracking
        """
        aigie = self._get_aigie()
        if not aigie or not aigie._initialized:
            return ""

        # Generate trace ID if not set
        if not self.trace_id:
            if self._trace_context and hasattr(self._trace_context, 'id'):
                self.trace_id = str(self._trace_context.id)
            else:
                self.trace_id = str(uuid.uuid4())

        # Build trace name
        trace_name = self.trace_name or f"Claude Query"

        # Extract tool names if present
        tools = options.get('tools', [])
        tool_names = []
        if tools:
            for t in tools[:10]:
                if hasattr(t, 'name'):
                    tool_names.append(t.name)
                elif isinstance(t, dict) and 'name' in t:
                    tool_names.append(t['name'])

        # Build metadata
        trace_metadata = {
            **self.metadata,
            'model': model or options.get('model', 'claude-sonnet-4-20250514'),
            'tool_count': len(tools),
            'tool_names': tool_names[:10],
            'framework': 'claude_agent_sdk',
            'max_tokens': options.get('max_tokens'),
            'max_turns': options.get('max_turns'),
        }

        # Only create trace if we don't have a trace context
        if not self._trace_context:
            trace_data = {
                'id': self.trace_id,
                'name': trace_name,
                'type': 'agent',
                'input': {
                    'prompt': prompt[:2000] if self.capture_messages else '[redacted]',
                    'model': trace_metadata['model'],
                    'tool_count': len(tools),
                },
                'status': 'pending',
                'tags': [*self.tags, 'claude_agent_sdk'],
                'metadata': trace_metadata,
                'start_time': datetime.now().isoformat(),
                'created_at': datetime.now().isoformat(),
            }

            if self.user_id:
                trace_data['user_id'] = self.user_id
            if self.session_id:
                trace_data['session_id'] = self.session_id

            # Send trace via buffer
            if aigie._buffer:
                await aigie._buffer.add(EventType.TRACE_CREATE, trace_data)

        # Create query span
        self.query_span_id = str(uuid.uuid4())
        query_span_data = {
            'id': self.query_span_id,
            'trace_id': self.trace_id,
            'name': f'query:{trace_metadata["model"]}',
            'type': 'llm',
            'input': {
                'prompt': prompt[:2000] if self.capture_messages else '[redacted]',
                'model': trace_metadata['model'],
                'tools': tool_names,
                'system_prompt': options.get('system_prompt', '')[:500] if self.capture_messages else None,
            },
            'status': 'pending',
            'tags': self.tags or [],
            'metadata': trace_metadata,
            'model': trace_metadata['model'],
            'start_time': datetime.now().isoformat(),
            'created_at': datetime.now().isoformat(),
        }

        self._current_query_span_id = self.query_span_id

        if aigie._buffer:
            await aigie._buffer.add(EventType.SPAN_CREATE, query_span_data)

        return self.query_span_id

    async def handle_query_end(
        self,
        query_id: str,
        messages: List[Any],
        result_message: Any,
        error: Optional[str] = None,
    ) -> None:
        """
        Called when a query() call completes.

        Args:
            query_id: Query ID from handle_query_start
            messages: List of messages from the conversation
            result_message: The ResultMessage with final output and costs
            error: Error message if query failed
        """
        aigie = self._get_aigie()
        if not aigie or not aigie._initialized or not self.trace_id:
            return

        end_time = datetime.now()
        success = error is None

        # Extract usage and cost from ResultMessage
        usage = {}
        cost = 0.0
        model = None

        if result_message:
            if hasattr(result_message, 'usage'):
                usage_obj = result_message.usage
                usage = {
                    'input_tokens': getattr(usage_obj, 'input_tokens', 0),
                    'output_tokens': getattr(usage_obj, 'output_tokens', 0),
                    'cache_read_input_tokens': getattr(usage_obj, 'cache_read_input_tokens', 0),
                    'cache_creation_input_tokens': getattr(usage_obj, 'cache_creation_input_tokens', 0),
                }
                # Update totals
                self.total_input_tokens += usage.get('input_tokens', 0)
                self.total_output_tokens += usage.get('output_tokens', 0)
                self.total_cache_read_tokens += usage.get('cache_read_input_tokens', 0)
                self.total_cache_creation_tokens += usage.get('cache_creation_input_tokens', 0)

            if hasattr(result_message, 'total_cost_usd'):
                cost = result_message.total_cost_usd or 0.0
            elif hasattr(result_message, 'model'):
                # Calculate cost from usage
                model = result_message.model
                cost = calculate_claude_cost(model, usage)

            self.total_cost += cost

            if hasattr(result_message, 'model'):
                model = result_message.model

        # Extract final output
        output = None
        if messages and self.capture_messages:
            last_message = messages[-1] if messages else None
            if last_message:
                if hasattr(last_message, 'content'):
                    content = last_message.content
                    if isinstance(content, str):
                        output = content[:2000]
                    elif isinstance(content, list):
                        # Extract text blocks
                        text_parts = []
                        for block in content:
                            if hasattr(block, 'text'):
                                text_parts.append(block.text)
                            elif isinstance(block, dict) and 'text' in block:
                                text_parts.append(block['text'])
                        output = '\n'.join(text_parts)[:2000]

        # Update query span
        if self.query_span_id:
            query_update = {
                'id': self.query_span_id,
                'status': 'success' if success else 'failed',
                'output': {
                    'response': output,
                    'message_count': len(messages),
                    'usage': usage,
                    'cost': cost,
                },
                'end_time': end_time.isoformat(),
                'prompt_tokens': usage.get('input_tokens', 0),
                'completion_tokens': usage.get('output_tokens', 0),
                'total_tokens': usage.get('input_tokens', 0) + usage.get('output_tokens', 0),
            }

            if cost > 0:
                query_update['total_cost'] = cost
            if error:
                query_update['error'] = error
                query_update['error_message'] = error

            if aigie._buffer:
                await aigie._buffer.add(EventType.SPAN_UPDATE, query_update)

        # Update trace
        update_data = {
            'id': self.trace_id,
            'status': 'success' if success else 'failed',
            'output': {
                'response': output,
                'message_count': len(messages),
                'total_tokens': self.total_input_tokens + self.total_output_tokens,
                'total_cost': self.total_cost,
                'tool_calls': self.total_tool_calls,
            },
            'end_time': end_time.isoformat(),
        }

        if error:
            update_data['error'] = error
            update_data['error_message'] = error

        if aigie._buffer:
            await aigie._buffer.add(EventType.TRACE_UPDATE, update_data)

    async def handle_tool_use_start(
        self,
        tool_name: str,
        tool_input: Dict[str, Any],
        tool_use_id: str,
    ) -> str:
        """
        Called when a tool use starts (PreToolUse hook).

        Args:
            tool_name: Name of the tool being called
            tool_input: Input arguments to the tool
            tool_use_id: Unique ID for this tool use

        Returns:
            The span ID for this tool call
        """
        aigie = self._get_aigie()
        if not aigie or not aigie._initialized or not self.trace_id:
            return ""

        self.total_tool_calls += 1
        span_id = str(uuid.uuid4())
        start_time = datetime.now()

        # Get parent span ID
        parent_id = self._current_turn_span_id or self._current_query_span_id

        self.tool_map[tool_use_id] = {
            'spanId': span_id,
            'startTime': start_time,
            'toolName': tool_name,
        }

        # Serialize tool input
        input_data = {}
        if self.capture_tool_results:
            input_data = {k: str(v)[:500] for k, v in tool_input.items()} if tool_input else {}

        span_data = {
            'id': span_id,
            'trace_id': self.trace_id,
            'parent_id': parent_id,
            'name': f'tool:{tool_name}',
            'type': 'tool',
            'input': input_data,
            'status': 'pending',
            'tags': self.tags or [],
            'metadata': {
                'toolName': tool_name,
                'toolUseId': tool_use_id,
                'framework': 'claude_agent_sdk',
            },
            'start_time': start_time.isoformat(),
            'created_at': start_time.isoformat(),
        }

        if aigie._buffer:
            await aigie._buffer.add(EventType.SPAN_CREATE, span_data)

        return span_id

    async def handle_tool_use_end(
        self,
        tool_use_id: str,
        result: Any,
        is_error: bool = False,
    ) -> None:
        """
        Called when a tool use completes (PostToolUse hook).

        Args:
            tool_use_id: Unique ID for this tool use
            result: Result from the tool execution
            is_error: Whether the tool execution failed
        """
        aigie = self._get_aigie()
        if not aigie or not aigie._initialized:
            return

        tool_data = self.tool_map.get(tool_use_id)
        if not tool_data:
            return

        end_time = datetime.now()
        duration = (end_time - tool_data['startTime']).total_seconds()

        output_data = {}
        if self.capture_tool_results:
            if isinstance(result, str):
                output_data['result'] = result[:1000]
            elif hasattr(result, 'model_dump'):
                output_data['result'] = str(result.model_dump())[:1000]
            else:
                output_data['result'] = str(result)[:1000]
        output_data['is_error'] = is_error

        update_data = {
            'id': tool_data['spanId'],
            'output': output_data,
            'status': 'failed' if is_error else 'success',
            'end_time': end_time.isoformat(),
            'duration_ns': int(duration * 1_000_000_000),
        }

        if is_error:
            update_data['error'] = str(result)[:500]
            update_data['error_message'] = str(result)[:500]

        if aigie._buffer:
            await aigie._buffer.add(EventType.SPAN_UPDATE, update_data)

        del self.tool_map[tool_use_id]

    async def handle_session_start(
        self,
        client: Any,
        options: Dict[str, Any],
    ) -> str:
        """
        Called when a ClaudeSDKClient session starts.

        Args:
            client: The ClaudeSDKClient instance
            options: Session options

        Returns:
            The session ID for tracking
        """
        aigie = self._get_aigie()
        if not aigie or not aigie._initialized:
            return ""

        # Generate trace ID if not set
        if not self.trace_id:
            self.trace_id = str(uuid.uuid4())

        trace_name = self.trace_name or "Claude Session"

        # Build metadata
        trace_metadata = {
            **self.metadata,
            'framework': 'claude_agent_sdk',
            'session_type': 'stateful',
            'model': options.get('model', 'claude-sonnet-4-20250514'),
        }

        # Create trace
        trace_data = {
            'id': self.trace_id,
            'name': trace_name,
            'type': 'agent',
            'input': {
                'session_type': 'stateful',
                'model': trace_metadata['model'],
            },
            'status': 'pending',
            'tags': [*self.tags, 'claude_agent_sdk', 'session'],
            'metadata': trace_metadata,
            'start_time': datetime.now().isoformat(),
            'created_at': datetime.now().isoformat(),
        }

        if self.user_id:
            trace_data['user_id'] = self.user_id
        if self.session_id:
            trace_data['session_id'] = self.session_id

        if aigie._buffer:
            await aigie._buffer.add(EventType.TRACE_CREATE, trace_data)

        # Create session span
        self.session_span_id = str(uuid.uuid4())
        session_span_data = {
            'id': self.session_span_id,
            'trace_id': self.trace_id,
            'name': 'session',
            'type': 'chain',
            'input': {'session_type': 'stateful'},
            'status': 'pending',
            'tags': self.tags or [],
            'metadata': trace_metadata,
            'start_time': datetime.now().isoformat(),
            'created_at': datetime.now().isoformat(),
        }

        if aigie._buffer:
            await aigie._buffer.add(EventType.SPAN_CREATE, session_span_data)

        return self.trace_id

    async def handle_session_end(
        self,
        turn_count: int,
        total_cost: float,
        error: Optional[str] = None,
    ) -> None:
        """
        Called when a ClaudeSDKClient session ends.

        Args:
            turn_count: Number of conversation turns
            total_cost: Total cost in USD
            error: Error message if session failed
        """
        aigie = self._get_aigie()
        if not aigie or not aigie._initialized or not self.trace_id:
            return

        end_time = datetime.now()
        success = error is None

        # Update session span
        if self.session_span_id:
            session_update = {
                'id': self.session_span_id,
                'status': 'success' if success else 'failed',
                'output': {
                    'turn_count': turn_count,
                    'total_cost': total_cost,
                    'total_tool_calls': self.total_tool_calls,
                },
                'end_time': end_time.isoformat(),
            }

            if error:
                session_update['error'] = error
                session_update['error_message'] = error

            if aigie._buffer:
                await aigie._buffer.add(EventType.SPAN_UPDATE, session_update)

        # Update trace
        update_data = {
            'id': self.trace_id,
            'status': 'success' if success else 'failed',
            'output': {
                'turn_count': turn_count,
                'total_cost': total_cost,
                'total_tokens': self.total_input_tokens + self.total_output_tokens,
                'total_tool_calls': self.total_tool_calls,
            },
            'end_time': end_time.isoformat(),
        }

        if error:
            update_data['error'] = error
            update_data['error_message'] = error

        if aigie._buffer:
            await aigie._buffer.add(EventType.TRACE_UPDATE, update_data)

    async def handle_turn_start(
        self,
        turn_id: str,
        user_message: str,
        turn_number: int,
    ) -> str:
        """
        Called when a conversation turn starts.

        Args:
            turn_id: Unique turn identifier
            user_message: The user's message
            turn_number: Turn number in the conversation

        Returns:
            The span ID for this turn
        """
        aigie = self._get_aigie()
        if not aigie or not aigie._initialized or not self.trace_id:
            return ""

        self.total_turns += 1
        span_id = str(uuid.uuid4())
        start_time = datetime.now()

        # Get parent span ID
        parent_id = self.session_span_id or self.query_span_id

        self.turn_map[turn_id] = {
            'spanId': span_id,
            'startTime': start_time,
            'turnNumber': turn_number,
        }

        span_data = {
            'id': span_id,
            'trace_id': self.trace_id,
            'parent_id': parent_id,
            'name': f'turn:{turn_number}',
            'type': 'chain',
            'input': {
                'user_message': user_message[:1000] if self.capture_messages else '[redacted]',
                'turn_number': turn_number,
            },
            'status': 'pending',
            'tags': self.tags or [],
            'metadata': {
                'turnId': turn_id,
                'turnNumber': turn_number,
                'framework': 'claude_agent_sdk',
            },
            'start_time': start_time.isoformat(),
            'created_at': start_time.isoformat(),
        }

        self._current_turn_span_id = span_id

        if aigie._buffer:
            await aigie._buffer.add(EventType.SPAN_CREATE, span_data)

        return span_id

    async def handle_turn_end(
        self,
        turn_id: str,
        assistant_message: str,
        usage: Optional[Dict[str, int]] = None,
        cost: float = 0.0,
    ) -> None:
        """
        Called when a conversation turn completes.

        Args:
            turn_id: Unique turn identifier
            assistant_message: The assistant's response
            usage: Token usage for this turn
            cost: Cost for this turn
        """
        aigie = self._get_aigie()
        if not aigie or not aigie._initialized:
            return

        turn_data = self.turn_map.get(turn_id)
        if not turn_data:
            return

        end_time = datetime.now()
        duration = (end_time - turn_data['startTime']).total_seconds()

        # Update totals
        if usage:
            self.total_input_tokens += usage.get('input_tokens', 0)
            self.total_output_tokens += usage.get('output_tokens', 0)
        self.total_cost += cost

        update_data = {
            'id': turn_data['spanId'],
            'output': {
                'assistant_message': assistant_message[:1000] if self.capture_messages else '[redacted]',
            },
            'status': 'success',
            'end_time': end_time.isoformat(),
            'duration_ns': int(duration * 1_000_000_000),
        }

        if usage:
            update_data['prompt_tokens'] = usage.get('input_tokens', 0)
            update_data['completion_tokens'] = usage.get('output_tokens', 0)
            update_data['total_tokens'] = usage.get('input_tokens', 0) + usage.get('output_tokens', 0)

        if cost > 0:
            update_data['total_cost'] = cost

        if aigie._buffer:
            await aigie._buffer.add(EventType.SPAN_UPDATE, update_data)

        del self.turn_map[turn_id]
        self._current_turn_span_id = None

    async def handle_turn_error(self, turn_id: str, error: str) -> None:
        """Called when a turn encounters an error."""
        aigie = self._get_aigie()
        if not aigie or not aigie._initialized:
            return

        turn_data = self.turn_map.get(turn_id)
        if not turn_data:
            return

        end_time = datetime.now()
        duration = (end_time - turn_data['startTime']).total_seconds()

        update_data = {
            'id': turn_data['spanId'],
            'status': 'failed',
            'error': error,
            'error_message': error,
            'end_time': end_time.isoformat(),
            'duration_ns': int(duration * 1_000_000_000),
        }

        if aigie._buffer:
            await aigie._buffer.add(EventType.SPAN_UPDATE, update_data)

        del self.turn_map[turn_id]
        self._current_turn_span_id = None

    async def handle_message(
        self,
        message_type: str,
        content: Any,
        role: str = "assistant",
    ) -> None:
        """
        Called for each message in the stream.

        Args:
            message_type: Type of message (AssistantMessage, ToolUseBlock, etc.)
            content: Message content
            role: Message role (user, assistant, tool)
        """
        # This can be used for detailed message tracking if needed
        pass

    def __repr__(self) -> str:
        return (
            f"ClaudeAgentSDKHandler("
            f"trace_id={self.trace_id}, "
            f"turns={self.total_turns}, "
            f"tool_calls={self.total_tool_calls}, "
            f"tokens={self.total_input_tokens + self.total_output_tokens}, "
            f"cost=${self.total_cost:.4f})"
        )
