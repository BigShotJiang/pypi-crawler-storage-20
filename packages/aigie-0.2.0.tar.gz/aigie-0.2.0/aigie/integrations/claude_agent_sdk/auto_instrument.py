"""
Claude Agent SDK auto-instrumentation.

Automatically patches Claude Agent SDK functions to create traces and inject handlers.
"""

import functools
import logging
from typing import Any, Dict, Optional, Set

logger = logging.getLogger(__name__)

_patched_functions: Set[str] = set()
_original_functions: Dict[str, Any] = {}


def patch_claude_agent_sdk() -> bool:
    """
    Patch Claude Agent SDK functions for auto-instrumentation.

    This patches:
    - claude_agent_sdk.query() for stateless queries
    - ClaudeSDKClient.query() for stateful client queries
    - ClaudeSDKClient.connect() for WebSocket connections

    Returns:
        True if patching was successful (or already patched)
    """
    success = True
    success = _patch_query_function() and success
    success = _patch_client_query() and success
    success = _patch_client_connect() and success
    return success


def unpatch_claude_agent_sdk() -> None:
    """Remove Claude Agent SDK patches (for testing)."""
    global _patched_functions, _original_functions

    try:
        import claude_agent_sdk

        if 'query' in _original_functions:
            claude_agent_sdk.query = _original_functions['query']

        if 'ClaudeSDKClient.query' in _original_functions:
            from claude_agent_sdk import ClaudeSDKClient
            ClaudeSDKClient.query = _original_functions['ClaudeSDKClient.query']

        if 'ClaudeSDKClient.connect' in _original_functions:
            from claude_agent_sdk import ClaudeSDKClient
            ClaudeSDKClient.connect = _original_functions['ClaudeSDKClient.connect']

    except ImportError:
        pass

    _patched_functions.clear()
    _original_functions.clear()


def is_claude_agent_sdk_patched() -> bool:
    """Check if Claude Agent SDK has been patched."""
    return len(_patched_functions) > 0


def _patch_query_function() -> bool:
    """Patch the standalone query() function."""
    try:
        import claude_agent_sdk

        if 'query' in _patched_functions:
            return True

        original_query = claude_agent_sdk.query
        _original_functions['query'] = original_query

        @functools.wraps(original_query)
        async def traced_query(
            prompt: str,
            *args,
            **kwargs
        ):
            """Traced version of claude_agent_sdk.query()."""
            from ...client import get_aigie
            from .handler import ClaudeAgentSDKHandler
            from .config import ClaudeAgentSDKConfig

            aigie = get_aigie()
            config = ClaudeAgentSDKConfig.from_env()

            if aigie and aigie._initialized and config.enabled:
                handler = ClaudeAgentSDKHandler(
                    trace_name=f"Claude Query",
                    metadata={'prompt_preview': prompt[:100]},
                    capture_tool_results=config.capture_tool_results,
                    capture_messages=config.capture_messages,
                )
                handler._aigie = aigie

                # Extract model from kwargs
                model = kwargs.get('model', 'claude-sonnet-4-20250514')

                # Build options from kwargs
                options = {
                    'model': model,
                    'tools': kwargs.get('tools', []),
                    'system_prompt': kwargs.get('system_prompt', ''),
                    'max_tokens': kwargs.get('max_tokens'),
                    'max_turns': kwargs.get('max_turns'),
                }

                query_id = await handler.handle_query_start(prompt, options, model)

                # Collect messages from the generator
                messages = []
                result_message = None
                error_msg = None

                try:
                    async for message in original_query(prompt, *args, **kwargs):
                        messages.append(message)

                        # Track tool usage
                        if hasattr(message, 'content') and isinstance(message.content, list):
                            for block in message.content:
                                if hasattr(block, 'type') and block.type == 'tool_use':
                                    tool_use_id = getattr(block, 'id', str(len(handler.tool_map)))
                                    tool_name = getattr(block, 'name', 'unknown')
                                    tool_input = getattr(block, 'input', {})
                                    await handler.handle_tool_use_start(
                                        tool_name, tool_input, tool_use_id
                                    )
                                elif hasattr(block, 'type') and block.type == 'tool_result':
                                    tool_use_id = getattr(block, 'tool_use_id', '')
                                    content = getattr(block, 'content', '')
                                    is_error = getattr(block, 'is_error', False)
                                    if tool_use_id in handler.tool_map:
                                        await handler.handle_tool_use_end(
                                            tool_use_id, content, is_error
                                        )

                        # Check for ResultMessage (final message with usage/cost)
                        if hasattr(message, 'usage') or hasattr(message, 'total_cost_usd'):
                            result_message = message

                        yield message

                except Exception as e:
                    error_msg = str(e)
                    raise
                finally:
                    await handler.handle_query_end(
                        query_id, messages, result_message, error_msg
                    )

            else:
                # No tracing, just yield through
                async for message in original_query(prompt, *args, **kwargs):
                    yield message

        claude_agent_sdk.query = traced_query
        _patched_functions.add('query')

        logger.debug("Patched claude_agent_sdk.query for auto-instrumentation")
        return True

    except ImportError:
        logger.debug("claude_agent_sdk not installed, skipping query patch")
        return True  # Not an error if not installed
    except Exception as e:
        logger.warning(f"Failed to patch claude_agent_sdk.query: {e}")
        return False


def _patch_client_query() -> bool:
    """Patch ClaudeSDKClient.query() method."""
    try:
        from claude_agent_sdk import ClaudeSDKClient

        if 'ClaudeSDKClient.query' in _patched_functions:
            return True

        original_query = ClaudeSDKClient.query
        _original_functions['ClaudeSDKClient.query'] = original_query

        @functools.wraps(original_query)
        async def traced_client_query(self, prompt: str, *args, **kwargs):
            """Traced version of ClaudeSDKClient.query()."""
            from ...client import get_aigie
            from .handler import ClaudeAgentSDKHandler
            from .config import ClaudeAgentSDKConfig

            aigie = get_aigie()
            config = ClaudeAgentSDKConfig.from_env()

            if aigie and aigie._initialized and config.enabled:
                # Get or create handler
                handler = getattr(self, '_aigie_handler', None)
                if handler is None:
                    handler = ClaudeAgentSDKHandler(
                        trace_name="Claude Client Query",
                        capture_tool_results=config.capture_tool_results,
                        capture_messages=config.capture_messages,
                    )
                    handler._aigie = aigie
                    self._aigie_handler = handler

                # Get model from client config
                model = getattr(self, 'model', 'claude-sonnet-4-20250514')

                options = {
                    'model': model,
                    'tools': getattr(self, 'tools', []),
                }

                query_id = await handler.handle_query_start(prompt, options, model)

                messages = []
                result_message = None
                error_msg = None

                try:
                    async for message in original_query(self, prompt, *args, **kwargs):
                        messages.append(message)

                        # Track tool usage
                        if hasattr(message, 'content') and isinstance(message.content, list):
                            for block in message.content:
                                if hasattr(block, 'type') and block.type == 'tool_use':
                                    tool_use_id = getattr(block, 'id', str(len(handler.tool_map)))
                                    tool_name = getattr(block, 'name', 'unknown')
                                    tool_input = getattr(block, 'input', {})
                                    await handler.handle_tool_use_start(
                                        tool_name, tool_input, tool_use_id
                                    )
                                elif hasattr(block, 'type') and block.type == 'tool_result':
                                    tool_use_id = getattr(block, 'tool_use_id', '')
                                    content = getattr(block, 'content', '')
                                    is_error = getattr(block, 'is_error', False)
                                    if tool_use_id in handler.tool_map:
                                        await handler.handle_tool_use_end(
                                            tool_use_id, content, is_error
                                        )

                        if hasattr(message, 'usage') or hasattr(message, 'total_cost_usd'):
                            result_message = message

                        yield message

                except Exception as e:
                    error_msg = str(e)
                    raise
                finally:
                    await handler.handle_query_end(
                        query_id, messages, result_message, error_msg
                    )
            else:
                async for message in original_query(self, prompt, *args, **kwargs):
                    yield message

        ClaudeSDKClient.query = traced_client_query
        _patched_functions.add('ClaudeSDKClient.query')

        logger.debug("Patched ClaudeSDKClient.query for auto-instrumentation")
        return True

    except ImportError:
        logger.debug("claude_agent_sdk not installed, skipping client query patch")
        return True
    except Exception as e:
        logger.warning(f"Failed to patch ClaudeSDKClient.query: {e}")
        return False


def _patch_client_connect() -> bool:
    """Patch ClaudeSDKClient.connect() for WebSocket sessions."""
    try:
        from claude_agent_sdk import ClaudeSDKClient

        if 'ClaudeSDKClient.connect' in _patched_functions:
            return True

        # Check if connect method exists (may not exist in all versions)
        if not hasattr(ClaudeSDKClient, 'connect'):
            logger.debug("ClaudeSDKClient.connect not found, skipping patch")
            return True

        original_connect = ClaudeSDKClient.connect
        _original_functions['ClaudeSDKClient.connect'] = original_connect

        @functools.wraps(original_connect)
        async def traced_connect(self, *args, **kwargs):
            """Traced version of ClaudeSDKClient.connect()."""
            from ...client import get_aigie
            from .handler import ClaudeAgentSDKHandler
            from .config import ClaudeAgentSDKConfig

            aigie = get_aigie()
            config = ClaudeAgentSDKConfig.from_env()

            if aigie and aigie._initialized and config.enabled:
                handler = ClaudeAgentSDKHandler(
                    trace_name="Claude WebSocket Session",
                    capture_tool_results=config.capture_tool_results,
                    capture_messages=config.capture_messages,
                )
                handler._aigie = aigie
                self._aigie_handler = handler

                options = {
                    'model': getattr(self, 'model', 'claude-sonnet-4-20250514'),
                }

                await handler.handle_session_start(self, options)

                try:
                    result = await original_connect(self, *args, **kwargs)
                    return result
                except Exception as e:
                    await handler.handle_session_end(
                        handler.total_turns,
                        handler.total_cost,
                        str(e)
                    )
                    raise
            else:
                return await original_connect(self, *args, **kwargs)

        ClaudeSDKClient.connect = traced_connect
        _patched_functions.add('ClaudeSDKClient.connect')

        logger.debug("Patched ClaudeSDKClient.connect for auto-instrumentation")
        return True

    except ImportError:
        logger.debug("claude_agent_sdk not installed, skipping connect patch")
        return True
    except Exception as e:
        logger.warning(f"Failed to patch ClaudeSDKClient.connect: {e}")
        return False


def _patch_hooks() -> bool:
    """
    Patch hook registration for tool use tracking.

    This patches the hook system to automatically track:
    - PreToolUse: Called before a tool is executed
    - PostToolUse: Called after a tool execution completes
    - UserPromptSubmit: Called when user submits a prompt
    """
    # Hook patching is optional and depends on the SDK version
    # The main tracing happens through query/client patching
    return True
