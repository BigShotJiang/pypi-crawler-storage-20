"""
Channel protection handler for SecureX SDK.
Extracts logic from events/antinuke/on_guild_channel_*.py
"""
import discord
import asyncio
from typing import Optional
from datetime import datetime

from ..models import ThreatEvent


class ChannelHandler:
    """Handles channel protection logic"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_manager = sdk.backup_manager
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized (owner or whitelisted)"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True  # Bot is always authorized
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_channel_create(self, channel: discord.abc.GuildChannel):
        """Detect unauthorized channel creation"""
        try:
            guild = channel.guild
            await asyncio.sleep(1)
            
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_create):
                if entry.target.id ==channel.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        # Delete unauthorized channel
                        await channel.delete(reason="SecureX: Unauthorized channel creation")
                        
                        # Create threat event (no UI)
                        threat = ThreatEvent(
                            type="channel_create",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=channel.id,
                            target_name=channel.name,
                            prevented=True,
                            restored=False
                        )
                        
                        # Trigger callback - developer handles UI
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in channel_create handler: {e}")
    
    async def on_channel_delete(self, channel: discord.abc.GuildChannel):
        """Detect and restore unauthorized channel deletion"""
        try:
            guild = channel.guild
            is_category = isinstance(channel, discord.CategoryChannel)
            await asyncio.sleep(1)
            
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete):
                if entry.target.id == channel.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        # Store old ID before restoration (for finding children)
                        old_category_id = channel.id if is_category else None
                        
                        # Restore channel
                        restored = await self.backup_manager.restore_channel(guild, channel)
                        
                        # If category was restored, restore all its children
                        if restored and is_category and old_category_id:
                            # Get the newly created category
                            # Try to find it by name since ID changed
                            new_category = None
                            for cat in guild.categories:
                                if cat.name == channel.name:
                                    new_category = cat
                                    break
                            
                            if new_category:
                                # Pass OLD category ID to find children in backup, 
                                # and NEW category to set as parent
                                await self.backup_manager.restore_category_children(
                                    guild, 
                                    old_category_id=old_category_id,
                                    new_category=new_category
                                )
                        
                        # Punish violator
                        punishment_action = await self.sdk.punisher.punish(
                            guild=guild,
                            user=entry.user,
                            violation_type="channel_delete",
                            details=f"Deleted #{channel.name}"
                        )
                        
                        # Create threat event
                        threat = ThreatEvent(
                            type="channel_delete",
                            guild_id=guild.id,
                            actor_id=entry.user.id,
                            target_id=channel.id,
                            target_name=channel.name,
                            prevented=True,
                            restored=restored,
                            details={"is_category": is_category},
                            punishment_action=punishment_action
                        )
                        
                        # Trigger callback
                        await self.sdk._trigger_callbacks('threat_detected', threat)
                    break
        except Exception as e:
            print(f"Error in channel_delete handler: {e}")
    
    async def on_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel):
        """Detect unauthorized channel permission/position changes"""
        try:
            # Only check if permissions or position changed
            if before.overwrites == after.overwrites and before.position == after.position:
                return
            
            guild = after.guild
            await asyncio.sleep(0.3)
            
            async for entry in guild.audit_logs(limit=3, oldest_first=False):
                if entry.action in [discord.AuditLogAction.overwrite_update, discord.AuditLogAction.channel_update]:
                    if hasattr(entry.target, 'id') and entry.target.id == after.id:
                        if not await self._is_authorized(guild, entry.user.id):
                            # Restore channel permissions
                            restored = await self.backup_manager.restore_channel_permissions(guild, after.id)
                            
                            # Create threat event
                            threat = ThreatEvent(
                                type="channel_update",
                                guild_id=guild.id,
                                actor_id=entry.user.id,
                                target_id=after.id,
                                target_name=after.name,
                                prevented=True,
                                restored=restored,
                                details={"changed": "permissions/position"}
                            )
                            
                            # Trigger callback
                            await self.sdk._trigger_callbacks('threat_detected', threat)
                        break
        except Exception as e:
            print(f"Error in channel_update handler: {e}")
