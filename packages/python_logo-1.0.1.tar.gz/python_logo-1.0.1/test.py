import python_logo as logo

# Installation and testing:
# pip install -e .
# python test.py
if __name__ == "__main__":
    logo.python()
    logo.snake()
