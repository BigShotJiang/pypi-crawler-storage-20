# 📦 Py项目发布流程

## 🎯 一. 准备工作

### 1.1 注册PyPI账号

- 访问 https://pypi.org/ 注册账号
- 验证邮箱地址
- 在账户设置中创建API Token（用于上传认证）

### 1.2 安装必要工具

```bash
pip install build twine
```

<br/>

## 📁 二. 项目与配置

### 2.1 项目结构

```bash
python_logo/
├── python_logo/          # 源代码包
├── setup.py              # 项目配置（传统方式）
├── pyproject.toml        # 现代化配置（推荐）
├── README.md             # 项目说明
├── LICENSE               # 许可证文件
├── MANIFEST.in			  # 打包清单
└── test.py               # 测试脚本
```

### 2.2 配置文件

_python_logo/setup.py_

```python
# python_logo/setup.py
from setuptools import setup, find_packages

setup(
    name="python_logo",
    version="1.0.0",
    packages=find_packages(),
    description="A Python ASCII art logo package",
    author="Hollson",
    author_email="hollson@qq.com",
    url="https://github.com/Hollson/python-logo",
    license="MIT",
    python_requires=">=3.6",
)
```

### 2.3 打包清单

_python_logo/MANIFEST.in_

```shell
include README.md
include LICENSE
include RELEASE.md
include test.py
```



<br/>

## 🏗️ 三. 打包与发布

### 3.1 构建与验证

- **构建打包**

```bash
# 清理旧构建文件
rm -rf build/ dist/ *.egg-info/

# 构建分发包(成功后会在dist目录下生成两个文件)
# python_logo-1.0.0.tar.gz  			（源码包）
# python_logo-1.0.0-py3-none-any.whl （wheel包，推荐安装格式）
python -m build
```

- **验证包内容**

```bash
# 检查wheel包 (查看Wheel包的内部文件结构)
python -m zipfile -l dist/python_logo-1.0.0-py3-none-any.whl

# 检查源码包(不解压)
tar -tzf dist/python_logo-1.0.0.tar.gz
```

### 3.2 本地测试安装

- 在发布前先本地测试：

```bash
# 安装到本地环境测试
pip install dist/python_logo-1.0.0-py3-none-any.whl

# 或者使用源码包
pip install dist/python_logo-1.0.0.tar.gz

# 测试功能
python test.py
pip show python_logo
```

### 3.3 发布到PyPI

- **使用twine上传**
```bash
twine upload dist/*

# 🔔 提示：系统会提示输入用户名和密码：
#  - Username: __token__
#  - Password: 你的PyPI API Token（从账户设置中获取）
```

- **成功示例输出**
```
Uploading distributions to https://upload.pypi.org/legacy/
Uploading python_logo-1.0.0-py3-none-any.whl
100% ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 5.6/5.6 kB • 00:01 • ?
Uploading python_logo-1.0.0.tar.gz
100% ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 5.6/5.6 kB • 00:00 • ?

View at:
https://pypi.org/project/python_logo/1.0.0/
```

<br/>

## 📚 相关资源

- [PyPI官方文档](https://packaging.python.org/)
- [Python打包用户指南](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
- [setuptools文档](https://setuptools.pypa.io/)
- [twine文档](https://twine.readthedocs.io/)