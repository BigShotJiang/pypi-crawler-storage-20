"""
   DIRAC.Configuration.Agent
"""
