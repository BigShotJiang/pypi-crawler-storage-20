class ElementNotFound(Exception):
    pass
