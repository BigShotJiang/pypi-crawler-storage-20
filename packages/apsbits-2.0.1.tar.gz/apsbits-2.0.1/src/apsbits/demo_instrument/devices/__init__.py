"""Ophyd-style devices."""
