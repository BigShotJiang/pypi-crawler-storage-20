"""
Aribot Security Platform SDK by Aristiun & Ayurak

Threat modeling, compliance, and cloud security APIs.

Usage:
    from aribot import Aribot

    client = Aribot(api_key="your_api_key")

    # Upload and analyze diagram
    result = client.threat_modeling.analyze_diagram("architecture.png")

    # Run compliance scan
    scan = client.compliance.scan(diagram_id, standards=["ISO27001", "SOC2"])

    # Cloud security scan
    findings = client.cloud.scan(project_id)
"""

from .client import Aribot
from .exceptions import (
    AribotError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    NotFoundError,
    ServerError
)

__version__ = "1.0.0"
__all__ = [
    "Aribot",
    "AribotError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "NotFoundError",
    "ServerError"
]
