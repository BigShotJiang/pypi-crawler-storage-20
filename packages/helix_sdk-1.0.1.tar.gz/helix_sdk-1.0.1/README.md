# PROJECT-HELIX

## 🧬 The New Backbone for AI Data

**HELIX** is a semantic compression system that converts media into compact blueprints (.hlx) storing only identity-critical information. Unlike traditional compression (JPEG, MP4), HELIX separates "High Entropy" (faces, text, unique features) from "Low Entropy" (sky, walls, noise).

> "Store the instructions for regeneration, not the pixels themselves."

## 🏆 Gemini Hackathon Competition Build v1.0

### Two Killer Features

| Feature | Description | Target |
|---------|-------------|--------|
| 📱 **Cross-Platform** | HLX files are valid JPEGs viewable by ANY app | Adoption |
| 🧠 **HELIX SDK** | 10x dataset compression for AI training | Enterprise |

## 🚀 Quick Start

### Prerequisites
- Python 3.10+
- Node.js 18+
- Gemini API Key

### Installation

```bash
# Clone
git clone https://github.com/DB0SZ1/PROJECT-HELIX.git
cd PROJECT-HELIX

# Backend
pip install -r requirements.txt

# Frontend
cd ui/helix-app
npm install
```

### Environment Setup
Create `.env` file:
```
GEMINI_API_KEY=your_api_key_here
```

### Run

```bash
# Terminal 1: Backend
python -m uvicorn src.api.server:app --port 8001 --reload

# Terminal 2: Frontend
cd ui/helix-app
npm run dev
```

Visit `http://localhost:3000`

## 📱 Cross-Platform Compatibility (HLX v2)

HELIX v2 files are **valid JPEGs** that any app can display!

```
┌─────────────────────────────┐
│  JPEG Image Data            │  ← Any app sees this
│  (FF D8 ... FF D9)          │
├─────────────────────────────┤
│  HELIX_DATA_START           │  ← Our marker
├─────────────────────────────┤
│  Encrypted Blueprint        │  ← Only HELIX can read
└─────────────────────────────┘
```

### API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/encode/v2` | POST | Encode image to cross-platform HLX |
| `/api/hlx/preview` | POST | Extract JPEG preview from HLX v2 |
| `/api/hlx/format-info` | GET | Get format version details |

## 📦 HELIX SDK for AI Training

Compress your training data 10x while maintaining quality:

```python
from helix_sdk import HelixDataset, HelixLoader, BatchCompressor

# Compress your dataset (one-time)
compressor = BatchCompressor(workers=8)
stats = compressor.compress_directory(
    input_dir="/data/imagenet/train/",   # 150GB
    output_dir="/data/imagenet_hlx/"     # ~15GB
)
print(f"Saved {stats.space_saved_percent}%!")

# Use in training (PyTorch compatible)
dataset = HelixDataset("/data/imagenet_hlx/", target_resolution="512p")
loader = HelixLoader(dataset, batch_size=64, num_workers=4)

for batch in loader:
    model.train(batch)
```

### SDK Benefits
- 📦 10x dataset compression
- 🚀 PyTorch/TensorFlow compatible
- 🔄 On-demand materialization at any resolution
- ♾️ Infinite variant generation (free augmentation)
- 🔍 Semantic search across dataset

## 🔌 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Health check with feature status |
| `/api/encode` | POST | Encode image to HLX |
| `/api/encode/v2` | POST | Encode to cross-platform HLX |
| `/api/materialize` | POST | Reconstruct image from HLX |
| `/api/sdk/info` | GET | SDK documentation |

## 🏗️ Architecture

```
Project-HELIX/
├── src/
│   ├── api/           # FastAPI server
│   ├── core/          # Pipeline, Materializer, Codec
│   ├── extractors/    # Gemini anchor extraction
│   └── schema/        # Blueprint data structures
├── helix_sdk/         # AI Training SDK
│   ├── dataset.py     # HelixDataset
│   ├── loader.py      # PyTorch DataLoader
│   └── compressor.py  # Batch compression
└── ui/helix-app/      # Next.js frontend
```

## 📊 Benchmark Results

| Metric | Value |
|--------|-------|
| Compression Ratio | 10-20x |
| Identity Match (SSIM) | 98.7% |
| Materialization Time | ~3s |

## 🛡️ Security

- AES-256-GCM encryption for blueprints
- HMAC-SHA256 tamper detection
- Secure key derivation

## 📄 License

MIT License - See LICENSE file

## 👥 Team

Built for the Gemini Hackathon 2026

---

*HELIX: Your memories, compressed for the future.*
