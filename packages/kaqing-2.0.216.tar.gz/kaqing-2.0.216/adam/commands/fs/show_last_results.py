import os
from adam.utils import log_dir, tabulize
from adam.utils_local import find_local_files

from adam.utils_async_job import AsyncJobs
from version import __version__
from adam.commands.command import Command
from adam.repl_state import ReplState

class ShowLastResults(Command):
    COMMAND = 'show results'

    # the singleton pattern
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, 'instance'): cls.instance = super(ShowLastResults, cls).__new__(cls)

        return cls.instance

    def __init__(self, successor: Command=None):
        super().__init__(successor)

    def command(self):
        return ShowLastResults.COMMAND

    def run(self, cmd: str, state: ReplState):
        if not self.args(cmd):
            return super().run(cmd, state)

        logs: list[str] = find_local_files(f'{log_dir()}/{AsyncJobs.last_id}.*.log')

        # /tmp/qing-db/q/logs/16145959.repair-0.stdout.log
        # /tmp/qing-db/q/logs/16145959.repair-0.log

        logs_by_n = {}
        for l0 in logs:
            size = os.path.getsize(l0)
            l = l0.replace(f'{log_dir()}/{AsyncJobs.last_id}.', '')
            if l.endswith('.stdout.log'):
                n = l.replace('.stdout.log', '')
                key = 'out'
            else:
                n = l.replace('.log', '')
                key = 'err'

            if n not in logs_by_n:
                logs_by_n[n] = {'file': l0.replace('.stdout.log', '.log')}

            logs_by_n[n][key] = size

        # def get_n(l):
        #     return l.replace('.stdout.log', '').replace('.log', '')
        tabulize(sorted(logs_by_n.keys()), fn=lambda n: f"{n}\t{logs_by_n[n]['out']}\t{logs_by_n[n]['err']}\t{logs_by_n[n]['file']}", header='pod\tstdout\tstderr\tfile', separator='\t')

        return state

    def completion(self, state: ReplState):
        return super().completion(state)

    def help(self, _: ReplState):
        return f'{ShowLastResults.COMMAND}\t show results of last command'