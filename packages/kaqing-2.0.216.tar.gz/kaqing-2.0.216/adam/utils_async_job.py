from datetime import datetime

class AsyncJobs:
    last_id: str

    def new_id(dt: datetime = None):
        if not dt:
            dt = datetime.now()

        id = dt.strftime("%d%H%M%S")
        AsyncJobs.last_id = id

        return id

