## TokToon

TokToon is a lightweight Python library designed to reduce Large Language Model (LLM)
prompt token size without losing structure or intent.

It converts verbose text and JSON inputs into compact, schema-aware, and LLM-friendly
formats—helping developers reduce token usage, improve latency, and lower API costs.

TokToon is deterministic, easy to integrate, and works with any LLM or agent framework.

---

### Key Features

- 🔥 **JSON Squasher**
  - Converts nested JSON into a compact, schema-based format
  - Preserves structure while removing unnecessary syntax
  - Ideal for passing structured data to LLMs

- 🎚️ **Lossless and Lossy Modes**
  - Lossless mode preserves all fields and values
  - Lossy mode enables aggressive compression for maximum token savings

- 🧠 **LLM-Friendly Output**
  - Schema-first representation improves model reasoning
  - Avoids heavy brackets, repetition, and verbosity

- 🐍 **Lightweight & Dependency-Free**
  - No model or API dependencies
  - Safe for production environments

---

### Example

#### Input JSON
```json
{
  "friends": ["ana", "luis", "sam"],
  "hikes": [
    { "id": 1, "name": "Blue Lake Trail", "distanceKm": 7.5 },
    { "id": 2, "name": "Ridge Overlook", "distanceKm": 9.2 }
  ]
}
