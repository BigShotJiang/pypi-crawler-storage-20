"""Tests for authentication module."""
