"""Tests for core modules."""
