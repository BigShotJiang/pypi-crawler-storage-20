"""Output and console handling."""
