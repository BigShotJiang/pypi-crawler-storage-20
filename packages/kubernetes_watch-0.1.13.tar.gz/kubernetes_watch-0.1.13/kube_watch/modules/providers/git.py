import os
import shutil
import time
import subprocess
import tempfile
from pathlib import Path

import jwt
import requests
from git import Repo

from prefect import get_run_logger

logger = get_run_logger()


def is_ssh_clone(git_method: str) -> bool:
    """ Determine if the git clone method is SSH based on the provided method string. """
    result = git_method.lower() == 'ssh'
    logger.info(f"Checking if git method '{git_method}' is SSH: {result}")
    return result

def is_pat_clone(git_method: str) -> bool:
    """ Determine if the git clone method is PAT based on the provided method string. """
    result = git_method.lower() == 'pat'
    logger.info(f"Checking if git method '{git_method}' is PAT: {result}")
    return result

def is_gh_apps_clone(git_method: str) -> bool:
    """ Determine if the git clone method is GitHub App based on the provided method string. """
    result = git_method.lower() == 'apps'
    logger.info(f"Checking if git method '{git_method}' is GitHub Apps: {result}")
    return result


def clone_repo_pat(git_pat, git_url, clone_base_path):
    """ Clone a Git repository using a Personal Access Token (PAT) for authentication."""
    logger.info(f"Starting PAT-based git clone for URL: {git_url}")
    logger.info(f"Clone base path: {clone_base_path}")
    
    # Retrieve environment variables
    access_token = git_pat # os.environ.get('GIT_PAT')
    repo_url = git_url # os.environ.get('GIT_URL')
    
    if not access_token or not repo_url:
        logger.error("Missing required parameters: git_pat or git_url")
        raise ValueError("Environment variables GIT_PAT or GIT_URL are not set")

    # Correctly format the URL with the PAT
    logger.info("Formatting URL with PAT authentication")
    if 'https://' in repo_url:
        # Splitting the URL and inserting the PAT
        parts = repo_url.split('https://', 1)
        repo_url = f'https://{access_token}@{parts[1]}'
        logger.info("Successfully formatted URL with PAT")
    else:
        logger.error(f"Invalid URL format: {repo_url}. Must begin with https://")
        raise ValueError("URL must begin with https:// for PAT authentication")

    # Directory where the repo will be cloned
    repo_path = os.path.join(clone_base_path, 'manifest-repo')
    logger.info(f"Target repository path: {repo_path}")

    # Clone the repository
    if not os.path.exists(repo_path):
        logger.info(f"Cloning repository into {repo_path}")
        repo = Repo.clone_from(repo_url, repo_path)
        logger.info("Repository cloned successfully.")
    else:
        logger.info(f"Repository already exists at {repo_path}")


def clone_repo_ssh(
    git_url: str,
    clone_base_path: str,
    repo_dir_name: str = "manifest-repo",
    depth: int = 1,
    ssh_key_env: str = "GIT_SSH_PRIVATE_KEY",
    known_hosts_env: str = "GIT_SSH_KNOWN_HOSTS",
) -> Path:
    """
    Clone/update a repo via SSH using key + known_hosts from env vars.
    - GIT_SSH_PRIVATE_KEY: full private key (BEGIN/END ...)
    - GIT_SSH_KNOWN_HOSTS: lines from `ssh-keyscan github.com`
    """
    logger.info(f"Starting SSH-based git clone for URL: {git_url}")
    logger.info(f"Clone base path: {clone_base_path}, repo directory: {repo_dir_name}")
    logger.info(f"Clone depth: {depth}")
    
    if not git_url.startswith("git@"):
        logger.error(f"Invalid SSH URL format: {git_url}")
        raise ValueError("git_url must be an SSH URL like 'git@github.com:org/repo.git'")

    logger.info(f"Reading SSH credentials from environment variables: {ssh_key_env}, {known_hosts_env}")
    priv_key = os.environ.get(ssh_key_env)
    kh_data  = os.environ.get(known_hosts_env)
    if not priv_key:
        logger.error(f"Missing SSH private key environment variable: {ssh_key_env}")
        raise ValueError(f"Missing env var {ssh_key_env}")
    if not kh_data:
        logger.error(f"Missing SSH known hosts environment variable: {known_hosts_env}")
        raise ValueError(f"Missing env var {known_hosts_env}")

    base = Path(clone_base_path).expanduser().resolve()
    base.mkdir(parents=True, exist_ok=True)
    repo_path = base / repo_dir_name
    logger.info(f"Target repository path: {repo_path}")

    tmpdir = Path(tempfile.mkdtemp(prefix="git_ssh_"))
    key_path = tmpdir / "id_rsa"
    kh_path  = tmpdir / "known_hosts"
    logger.info(f"Created temporary directory for SSH keys: {tmpdir}")

    try:
        key_path.write_text(priv_key, encoding="utf-8")
        kh_path.write_text(kh_data, encoding="utf-8")
        try:
            os.chmod(key_path, 0o600)
        except PermissionError:
            pass  # ignore on platforms where chmod doesn't apply

        # Note: no StrictModes here
        ssh_cmd = (
            f"ssh -i {key_path} -o IdentitiesOnly=yes "
            f"-o UserKnownHostsFile={kh_path} "
            f"-o StrictHostKeyChecking=yes"
        )

        env = os.environ.copy()
        env["GIT_SSH_COMMAND"] = ssh_cmd

        if not repo_path.exists():
            logger.info(f"Repository doesn't exist, performing fresh clone")
            cmd = ["git", "clone"]
            if depth and depth > 0:
                cmd += ["--depth", str(depth)]
            cmd += [git_url, str(repo_path)]
            logger.info(f"Executing git clone command: {' '.join(cmd[:-1])} <repo_path>")
            subprocess.check_call(cmd, env=env)
            logger.info("Git clone completed successfully")
        else:
            logger.info(f"Repository already exists at {repo_path}, updating existing repo")
            if not (repo_path / ".git").exists():
                logger.error(f"Path exists but is not a git repository: {repo_path}")
                raise RuntimeError(f"Path exists but is not a git repo: {repo_path}")
            logger.info("Updating remote URL")
            subprocess.check_call(["git", "remote", "set-url", "origin", git_url], cwd=repo_path, env=env)
            logger.info("Fetching latest changes")
            subprocess.check_call(["git", "fetch", "--all", "--prune"], cwd=repo_path, env=env)
            logger.info("Pulling latest changes")
            subprocess.check_call(["git", "pull", "--ff-only", "origin"], cwd=repo_path, env=env)
            logger.info("Repository update completed successfully")

        logger.info(f"SSH clone operation completed, returning path: {repo_path}")
        return repo_path

    finally:
        try:
            shutil.rmtree(tmpdir)
        except Exception:
            pass



def _ghapp_installation_token(app_id: str, installation_id: str, private_key_pem: str) -> str:
    """Create an App-signed JWT and exchange it for a short-lived installation token (~1h)."""
    logger.info(f"Creating GitHub App installation token for app_id: {app_id}, installation_id: {installation_id}")
    
    now = int(time.time())
    payload = {"iat": now - 60, "exp": now + 9 * 60, "iss": app_id}  # JWT max 10m
    app_jwt = jwt.encode(payload, private_key_pem, algorithm="RS256")
    logger.info("JWT token created successfully")

    headers = {"Authorization": f"Bearer {app_jwt}", "Accept": "application/vnd.github+json"}
    logger.info("Requesting installation access token from GitHub API")
    resp = requests.post(
        f"https://api.github.com/app/installations/{installation_id}/access_tokens",
        headers=headers,
        timeout=20,
    )
    resp.raise_for_status()
    logger.info("Installation access token retrieved successfully")
    return resp.json()["token"]  # valid ~1 hour


def _to_https_url(git_url: str) -> str:
    """
    Accepts either SSH ('git@github.com:org/repo.git') or HTTPS.
    Returns HTTPS form required for GitHub App tokens:
      'https://github.com/org/repo.git'
    """
    logger.info(f"Converting git URL to HTTPS format: {git_url}")
    
    if git_url.startswith("git@github.com:"):
        org_repo = git_url.split("git@github.com:", 1)[1]
        https_url = f"https://github.com/{org_repo}"
        logger.info(f"Converted SSH URL to HTTPS: {https_url}")
        return https_url
    if git_url.startswith("https://"):
        logger.info("URL is already in HTTPS format")
        return git_url
    
    logger.error(f"Invalid git URL format: {git_url}")
    raise ValueError("git_url must be an SSH url for github.com or an https:// URL")


def clone_repo_github_app(
    git_url: str,
    clone_base_path: str,
    repo_dir_name: str = "manifest-repo",
    depth: int = 1,
    app_id_env: str = "GITHUB_APP_ID",
    installation_id_env: str = "GITHUB_INSTALLATION_ID",
    private_key_env: str = "GITHUB_APP_PRIVATE_KEY",
) -> Path:
    """
    Clone/update a repo using a GitHub App installation token (HTTPS).

    Env vars required:
      - GITHUB_APP_ID              : the App ID (numeric string)
      - GITHUB_INSTALLATION_ID     : the installation ID (numeric string)
      - GITHUB_APP_PRIVATE_KEY     : the App private key PEM (BEGIN/END ...)

    Notes:
      - Token is minted on the fly and embedded in the clone URL:
          https://x-access-token:<token>@github.com/org/repo.git
      - No SSH keys / known_hosts needed.
    """
    logger.info(f"Starting GitHub App-based git clone for URL: {git_url}")
    logger.info(f"Clone base path: {clone_base_path}, repo directory: {repo_dir_name}")
    logger.info(f"Clone depth: {depth}")
    
    logger.info(f"Reading GitHub App credentials from environment variables: {app_id_env}, {installation_id_env}, {private_key_env}")
    app_id = os.environ.get(app_id_env)
    inst_id = os.environ.get(installation_id_env)
    pem     = os.environ.get(private_key_env)

    if not app_id or not inst_id or not pem:
        logger.error(f"Missing GitHub App environment variables. Required: {app_id_env}, {installation_id_env}, {private_key_env}")
        raise ValueError(f"Missing one of env vars: {app_id_env}, {installation_id_env}, {private_key_env}")

    https_url = _to_https_url(git_url)
    logger.info("Obtaining GitHub App installation token")
    token = _ghapp_installation_token(app_id, inst_id, pem)

    # Build an authenticated URL (avoids credential helpers)
    authed_url = f"https://x-access-token:{token}@{https_url.split('https://',1)[1]}"
    logger.info("Successfully created authenticated URL with installation token")

    base = Path(clone_base_path).expanduser().resolve()
    base.mkdir(parents=True, exist_ok=True)
    repo_path = base / repo_dir_name
    logger.info(f"Target repository path: {repo_path}")

    # Ensure git won't prompt for creds in CI
    env = os.environ.copy()
    env.setdefault("GIT_TERMINAL_PROMPT", "0")
    env.setdefault("GCM_INTERACTIVE", "Never")  # in case Git Credential Manager is present

    if not repo_path.exists():
        logger.info(f"Repository doesn't exist, performing fresh clone")
        cmd = ["git", "clone"]
        if depth and depth > 0:
            cmd += ["--depth", str(depth)]
        cmd += [authed_url, str(repo_path)]
        logger.info(f"Executing git clone command with GitHub App authentication")
        subprocess.check_call(cmd, env=env)
        logger.info("Git clone completed successfully")
    else:
        logger.info(f"Repository already exists at {repo_path}, updating existing repo")
        if not (repo_path / ".git").exists():
            logger.error(f"Path exists but is not a git repository: {repo_path}")
            raise RuntimeError(f"Path exists but is not a git repo: {repo_path}")
        # Refresh remote URL & pull default branch
        logger.info("Updating remote URL with new GitHub App token")
        subprocess.check_call(["git", "remote", "set-url", "origin", authed_url], cwd=repo_path, env=env)
        logger.info("Fetching latest changes")
        subprocess.check_call(["git", "fetch", "--all", "--prune"], cwd=repo_path, env=env)
        logger.info("Pulling latest changes")
        subprocess.check_call(["git", "pull", "--ff-only", "origin"], cwd=repo_path, env=env)
        logger.info("Repository update completed successfully")

    logger.info(f"GitHub App clone operation completed, returning path: {repo_path}")
    return repo_path



def generate_github_creds(
        app_id_env: str = "GITHUB_APP_ID",
        installation_id_env: str = "GITHUB_INSTALLATION_ID",
        private_key_env: str = "GITHUB_APP_PRIVATE_KEY",
    ):
    """
    Generate GitHub credentials using a GitHub App installation token.
    """
    app_id = os.environ.get(app_id_env)
    installation_id = os.environ.get(installation_id_env)
    private_key = os.environ.get(private_key_env)

    if not app_id or not installation_id or not private_key:
        logger.error("Missing GitHub App environment variables.")
        raise ValueError(f"Missing one of env vars: {app_id_env}, {installation_id_env}, {private_key_env}")
    
    token = _ghapp_installation_token(app_id, installation_id, private_key)

    return {
        "username": "x-access-token",
        "password": token
    }
