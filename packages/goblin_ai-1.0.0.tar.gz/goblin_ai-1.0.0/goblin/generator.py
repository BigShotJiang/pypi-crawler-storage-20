"""
Goblin Core Generator - Advanced Image Generation with Full Parameter Support
"""
import asyncio
import random
import base64
from typing import Optional, Literal, Any
from dataclasses import dataclass, field

import cloudscraper

from .models import MODELS, get_model, get_model_defaults, get_model_styles, list_models
from .parameters import (
    build_prompt, get_resolution, get_style, get_quality, get_lighting,
    get_camera, get_composition, get_expression,
    STYLES, QUALITY_PRESETS, LIGHTING_PRESETS, CAMERA_PRESETS,
    COMPOSITION_PRESETS, EXPRESSION_PRESETS, RESOLUTIONS, AVAILABLE_OPTIONS
)


@dataclass
class GenerateRequest:
    """Image generation request with all parameters"""
    prompt: str
    negative_prompt: str = ""
    model: str = "goblin-sd"

    # Basic parameters
    shape: str = "square"
    seed: int = -1
    guidance_scale: Optional[float] = None  # None = use model default

    # Style parameters
    style: str = "default"
    quality: str = "standard"

    # Advanced parameters
    lighting: str = "auto"
    camera: str = "auto"
    composition: str = "auto"
    expression: str = "auto"

    # Extra options
    style_strength: float = 1.0
    remove_background: bool = False

    # Model-specific extras (passed through)
    extras: dict = field(default_factory=dict)


class Goblin:
    """
    Goblin Image Generator

    Free AI image generation with 34 models and comprehensive parameter support.

    Usage:
        async with Goblin() as goblin:
            # Simple generation
            image = await goblin.generate("a beautiful sunset")

            # With style and quality
            image = await goblin.generate(
                "a warrior princess",
                model="goblin-anime",
                style="ghibli",
                quality="ultra",
                lighting="golden-hour"
            )

            # With photography parameters
            image = await goblin.generate(
                "professional headshot",
                model="goblin-portrait",
                camera="portrait-85mm",
                lighting="studio",
                expression="confident"
            )

            # Get all available options
            options = goblin.available_options
    """

    _E = "aW1hZ2UtZ2VuZXJhdGlvbi5wZXJjaGFuY2Uub3Jn"
    _P = "L2FwaS8="

    def __init__(self):
        self._s = None
        self._k = None

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, *args):
        await self.close()

    @property
    def _b(self):
        return f"https://{base64.b64decode(self._E).decode()}{base64.b64decode(self._P).decode()}"

    async def start(self):
        """Initialize the generator"""
        self._s = cloudscraper.create_scraper()

    async def close(self):
        """Cleanup resources"""
        self._s = None
        self._k = None

    def _gk(self):
        """Get authentication key"""
        r = self._s.get(f"{self._b}verifyUser?thread=0&__cacheBust={random.random()}")
        d = r.json()
        if d.get("userKey"):
            self._k = d["userKey"]
            return self._k
        raise Exception("Authentication failed")

    @property
    def models(self) -> dict:
        """Get available models with their parameters"""
        return list_models()

    @property
    def available_options(self) -> dict:
        """Get all available parameter options"""
        return AVAILABLE_OPTIONS

    def get_model(self, model_id: str) -> dict:
        """Get detailed model info including supported parameters"""
        return get_model(model_id)

    def get_model_styles(self, model_id: str) -> list:
        """Get styles supported by a specific model"""
        return get_model_styles(model_id)

    def _build_final_prompt(
        self,
        base_prompt: str,
        base_negative: str,
        style: str,
        quality: str,
        lighting: str,
        camera: str,
        composition: str,
        expression: str,
    ) -> tuple[str, str]:
        """Build the final prompt with all modifiers"""
        enhanced_prompt, enhanced_negative = build_prompt(
            base_prompt,
            style=style,
            quality=quality,
            lighting=lighting,
            camera=camera,
            composition=composition,
            expression=expression
        )

        # Merge user's negative prompt
        if base_negative:
            enhanced_negative = f"{base_negative}, {enhanced_negative}" if enhanced_negative else base_negative

        return enhanced_prompt, enhanced_negative

    async def generate(
        self,
        prompt: str,
        negative_prompt: str = "",
        model: str = "goblin-sd",
        shape: str = "square",
        seed: int = -1,
        guidance_scale: Optional[float] = None,
        style: str = "default",
        quality: str = "standard",
        lighting: str = "auto",
        camera: str = "auto",
        composition: str = "auto",
        expression: str = "auto",
        style_strength: float = 1.0,
        remove_background: bool = False,
        return_bytes: bool = True,
        **extras
    ) -> bytes | dict:
        """
        Generate an image with full parameter support.

        Args:
            prompt: Text description of the image
            negative_prompt: Things to avoid in the image
            model: Model ID (use .models to see all 34 models)
            shape: Image shape (square, portrait, landscape, square-lg, etc.)
            seed: Seed for reproducibility (-1 for random)
            guidance_scale: How closely to follow prompt (None = use model default)
            style: Art style preset (cinematic, anime, photo, etc.)
            quality: Quality preset (standard, high, ultra, maximum)
            lighting: Lighting preset (natural, studio, golden-hour, neon, etc.)
            camera: Camera preset for realistic models (portrait-85mm, wide-35mm, etc.)
            composition: Shot composition (closeup, medium, full-body, wide, etc.)
            expression: Character expression (happy, serious, mysterious, etc.)
            style_strength: How strongly to apply the style (0.0-1.0)
            remove_background: Attempt to generate transparent PNG
            return_bytes: If True returns image bytes, else returns metadata dict
            **extras: Additional model-specific parameters

        Returns:
            Image bytes (JPEG) or dict with image_id and metadata
        """
        if not self._s:
            await self.start()

        # Get model config
        m = get_model(model)
        if not m:
            raise ValueError(f"Unknown model: {model}. Use .models to see available models.")

        # Get model defaults
        defaults = get_model_defaults(model)

        # Apply model defaults if not specified
        if guidance_scale is None:
            guidance_scale = defaults.get("guidance_scale", 7.0)
        if style == "default" and "style" in defaults:
            style = defaults["style"]
        if quality == "standard" and "quality" in defaults:
            quality = defaults["quality"]

        # Build enhanced prompt with all modifiers
        final_prompt, final_negative = self._build_final_prompt(
            prompt, negative_prompt,
            style, quality, lighting, camera, composition, expression
        )

        # Get resolution
        res = get_resolution(shape)

        # Channel from model
        ch = m["channel"]

        for attempt in range(3):
            try:
                if not self._k or attempt > 0:
                    self._gk()

                url = f"{self._b}generate?userKey={self._k}&requestId=gen{random.randint(0,2**30)}&__cacheBust={random.random()}"

                body = {
                    "generatorName": "ai-image-generator",
                    "channel": ch,
                    "subChannel": "public",
                    "prompt": final_prompt,
                    "negativePrompt": final_negative,
                    "seed": seed,
                    "resolution": res,
                    "guidanceScale": guidance_scale
                }

                # Add remove background if requested
                if remove_background:
                    body["removeBackground"] = True

                r = self._s.post(url, json=body)
                d = r.json()

                if d.get("imageId"):
                    if not return_bytes:
                        return {
                            "image_id": d["imageId"],
                            "seed": d.get("seed"),
                            "model": model,
                            "prompt": final_prompt,
                            "negative_prompt": final_negative,
                            "resolution": res,
                            "guidance_scale": guidance_scale,
                            "style": style,
                            "quality": quality,
                        }

                    # Download image
                    img_url = f"{self._b}downloadTemporaryImage?imageId={d['imageId']}"
                    img_r = self._s.get(img_url)
                    if img_r.status_code == 200:
                        return img_r.content
                    raise Exception("Failed to download image")

                status = d.get("status", "")
                if status == "waiting_for_prev_request_to_finish":
                    await asyncio.sleep(2)
                    continue
                elif "invalid" in status.lower() or "failed" in status.lower():
                    self._k = None
                    continue
                else:
                    raise Exception(f"Generation failed: {d}")

            except Exception as e:
                self._k = None
                if attempt < 2:
                    await asyncio.sleep(1)
                    continue
                raise

        raise Exception("Generation failed after retries")

    async def generate_base64(self, prompt: str, **kwargs) -> str:
        """Generate image and return as base64 string"""
        img_bytes = await self.generate(prompt, **kwargs)
        return base64.b64encode(img_bytes).decode()

    async def generate_from_request(self, request: GenerateRequest) -> bytes | dict:
        """Generate from a GenerateRequest dataclass"""
        return await self.generate(
            prompt=request.prompt,
            negative_prompt=request.negative_prompt,
            model=request.model,
            shape=request.shape,
            seed=request.seed,
            guidance_scale=request.guidance_scale,
            style=request.style,
            quality=request.quality,
            lighting=request.lighting,
            camera=request.camera,
            composition=request.composition,
            expression=request.expression,
            style_strength=request.style_strength,
            remove_background=request.remove_background,
            **request.extras
        )

    # === Convenience methods for specific use cases ===

    async def generate_photo(
        self,
        prompt: str,
        camera: str = "portrait-85mm",
        lighting: str = "natural",
        **kwargs
    ) -> bytes:
        """Generate a realistic photo with photography presets"""
        return await self.generate(
            prompt,
            model=kwargs.pop("model", "goblin-photo"),
            camera=camera,
            lighting=lighting,
            quality="ultra",
            **kwargs
        )

    async def generate_anime(
        self,
        prompt: str,
        style: str = "anime",
        expression: str = "auto",
        **kwargs
    ) -> bytes:
        """Generate anime-style art"""
        return await self.generate(
            prompt,
            model=kwargs.pop("model", "goblin-anime"),
            style=style,
            expression=expression,
            **kwargs
        )

    async def generate_portrait(
        self,
        prompt: str,
        expression: str = "neutral",
        **kwargs
    ) -> bytes:
        """Generate a portrait"""
        return await self.generate(
            prompt,
            model=kwargs.pop("model", "goblin-portrait"),
            composition="closeup",
            expression=expression,
            quality="ultra",
            **kwargs
        )

    async def generate_concept_art(
        self,
        prompt: str,
        **kwargs
    ) -> bytes:
        """Generate professional concept art"""
        return await self.generate(
            prompt,
            model=kwargs.pop("model", "goblin-concept"),
            style="concept-art",
            quality="ultra",
            **kwargs
        )

    async def generate_cinematic(
        self,
        prompt: str,
        **kwargs
    ) -> bytes:
        """Generate cinematic-style image"""
        return await self.generate(
            prompt,
            style="cinematic",
            lighting="cinematic",
            quality="ultra",
            **kwargs
        )
