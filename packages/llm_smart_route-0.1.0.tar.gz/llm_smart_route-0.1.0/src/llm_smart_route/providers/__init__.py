"""
llm_smart_router.providers
--------------------------

供應商適配器模組

提供 get_provider() 工廠函數,用於根據供應商名稱取得對應的 Provider 實例。
"""

from .base import BaseProvider
from .anthropic import AnthropicProvider
from .google import GoogleProvider
from .openai import OpenAIProvider
from .alibaba import AlibabaProvider
from .mistral import MistralProvider
from ..exceptions import ProviderNotSupportedError


def get_provider(provider: str) -> BaseProvider:
    """
    根據供應商名稱返回對應的 Provider 實例
    
    支援的供應商別名:
    - "claude" / "anthropic" -> AnthropicProvider
    - "gemini" / "google" -> GoogleProvider
    - "openai" / "gpt" -> OpenAIProvider
    - "qwen" / "alibaba" -> AlibabaProvider
    - "mistral" -> MistralProvider
    
    Args:
        provider: 供應商名稱 (不區分大小寫)
    
    Returns:
        對應的 Provider 實例
    
    Raises:
        ProviderNotSupportedError: 當指定的供應商不在支援清單中時拋出
    
    Examples:
        >>> provider = get_provider("claude")
        >>> isinstance(provider, AnthropicProvider)
        True
        >>> provider = get_provider("gemini")
        >>> isinstance(provider, GoogleProvider)
        True
    """
    # 供應商映射表
    providers = {
        "claude": AnthropicProvider,
        "anthropic": AnthropicProvider,
        "gemini": GoogleProvider,
        "google": GoogleProvider,
        "openai": OpenAIProvider,
        "gpt": OpenAIProvider,
        "qwen": AlibabaProvider,
        "alibaba": AlibabaProvider,
        "mistral": MistralProvider,
    }
    
    # 正規化供應商名稱 (轉小寫)
    provider_key = provider.lower().strip()
    
    if provider_key not in providers:
        supported = ", ".join(sorted(set(providers.keys())))
        raise ProviderNotSupportedError(
            f"不支援的供應商: {provider}。支援的供應商: {supported}"
        )
    
    return providers[provider_key]()


__all__ = [
    "BaseProvider",
    "AnthropicProvider",
    "GoogleProvider",
    "OpenAIProvider",
    "AlibabaProvider",
    "MistralProvider",
    "get_provider",
]
