"""
llm_smart_router.providers.google
---------------------------------

Gemini (Google) 供應商適配器

實作 Google Gemini 的模型查詢與替換邏輯。
支援 Gemini 系列模型,包含 Flash, Flash-Lite, Pro 階層。
"""

import re
from typing import List, Dict
from .base import BaseProvider
from ..exceptions import ProviderAPIError


class GoogleProvider(BaseProvider):
    """
    Google (Gemini) 供應商適配器
    
    API: genai.Client().models.list() (使用官方 google-genai SDK)
    命名規範: gemini-{version}-{tier}[-{tag}]
    範例: gemini-2.5-flash-latest, gemini-2.5-pro
    
    階層分類:
    - Flash-Lite: 最快速、最經濟
    - Flash: 平衡速度與品質
    - Pro: 最強大模型
    
    特殊標籤:
    - latest: 最新版本
    - stable: 穩定版本
    """
    
    async def list_models(self) -> List[str]:
        """
        查詢 Google Gemini 可用模型清單
        
        使用 google-genai SDK 查詢所有支援 generateContent 的模型。
        注意: 此方法需要環境變數 GOOGLE_API_KEY。
        
        Returns:
            模型名稱列表 (已移除 "models/" 前綴)
        
        Raises:
            ProviderAPIError: 當 API 查詢失敗或 SDK 未安裝時拋出
        """
        try:
            # 動態 import, 避免強制依賴
            from google import genai
            import os
            
            api_key = os.environ.get("GOOGLE_API_KEY")
            if not api_key:
                raise ProviderAPIError("請設定 GOOGLE_API_KEY 以使用 Gemini 服務")
                
            client = genai.Client(api_key=api_key)
            models = client.models.list()
            
            # 過濾並清理模型名稱 (返回所有 gemini 開頭的模型)
            return [
                m.name.replace("models/", "") 
                for m in models 
                if m.name.startswith("models/gemini")
            ]
        except ImportError:
            raise ProviderAPIError(
                "請安裝 google-genai: pip install llm-smart-route[gemini]"
            )
        except Exception as e:
            raise ProviderAPIError(f"查詢 Gemini 模型清單失敗: {e}")
    
    def _extract_family(self, model_name: str) -> Dict[str, str]:
        """
        提取 Gemini 模型的家族特徵
        
        從模型名稱中識別階層 (flash/flash-lite/pro) 與基礎名稱 (gemini)。
        
        Args:
            model_name: 模型名稱
        
        Returns:
            家族特徵字典,包含 "base" 與 "tier"
        
        Examples:
            >>> _extract_family("gemini-2.5-flash-latest")
            {"base": "gemini", "tier": "flash"}
            >>> _extract_family("gemini-2.5-flash-lite")
            {"base": "gemini", "tier": "flash-lite"}
            >>> _extract_family("gemini-2.5-pro")
            {"base": "gemini", "tier": "pro"}
        """
        model_lower = model_name.lower()
        
        # 識別階層 (注意順序,先檢查 flash-lite)
        if "flash" in model_lower:
            tier = "flash-lite" if "lite" in model_lower else "flash"
        elif "pro" in model_lower:
            tier = "pro"
        else:
            tier = "unknown"
        
        return {
            "base": "gemini",
            "tier": tier
        }
    
    def _select_latest(self, candidates: List[str]) -> str:
        """
        從 Gemini 候選模型中選擇最新版本
        
        選擇策略:
        1. 優先選擇帶 "latest" 標籤的模型
        2. 其次選擇帶 "stable" 標籤的模型
        3. 再其次選擇有實驗日期的模型
        4. 最後按版本號排序 (如 2.5 > 2.0)
        
        Args:
            candidates: 候選模型列表
        
        Returns:
            最新版本的模型名稱
        """
        # 優先級 1: latest 標籤
        latest_models = [m for m in candidates if "latest" in m.lower()]
        if latest_models:
            return latest_models[0]
        
        # 優先級 2: stable 標籤
        stable_models = [m for m in candidates if "stable" in m.lower()]
        if stable_models:
            return stable_models[0]
        
        # 優先級 3: 實驗日期標籤 (如 "exp-1234")
        dated_models = [m for m in candidates if "exp-" in m.lower() or re.search(r'\d{4}', m)]
        if dated_models:
            # 按日期排序
            def extract_date(m):
                match = re.search(r'exp-(\d+)|(\d{4})', m)
                return int(match.group(1) or match.group(2)) if match else 0
            return max(dated_models, key=extract_date)
        
        # 優先級 4: 按版本號排序
        return max(candidates, key=self._extract_version_number)
    
    def _extract_version_number(self, model_name: str) -> float:
        """
        提取 Gemini 版本號
        
        Args:
            model_name: 模型名稱
        
        Returns:
            版本號 (如 2.5),無法解析時返回 0.0
        
        Examples:
            >>> _extract_version_number("gemini-2.5-flash")
            2.5
            >>> _extract_version_number("gemini-2-pro")
            2.0
        """
        match = re.search(r'gemini-(\d+\.?\d*)', model_name.lower())
        return float(match.group(1)) if match else 0.0
