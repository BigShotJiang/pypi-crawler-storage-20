"""
llm_smart_router.providers.alibaba
----------------------------------

Qwen (Alibaba Cloud) 供應商適配器

實作 Alibaba Cloud Qwen 的模型查詢與替換邏輯。
支援 Qwen 系列模型,包含 Turbo, Flash, Plus, Max 階層。
"""

import re
from typing import List, Dict
from .base import BaseProvider
from ..exceptions import ProviderAPIError


class AlibabaProvider(BaseProvider):
    """
    Alibaba Cloud (Qwen) 供應商適配器
    
    API: DashScope API
    命名規範: qwen[-{version}]-{tier}
    範例: qwen-turbo, qwen-plus, qwen3-omni
    
    階層分類:
    - Turbo/Flash: 快速輕量級
    - Plus: 平衡型
    - Max: 最強大模型
    
    特殊變體:
    - VL: 視覺語言模型
    - Omni: 多模態模型
    - Coder: 程式碼專用模型
    """
    
    API_BASE = "https://dashscope.aliyuncs.com/api/v1"
    
    async def list_models(self) -> List[str]:
        """
        查詢 Qwen 可用模型清單
        
        使用 DashScope API 查詢可用模型。
        注意: 需要使用者設定 DASHSCOPE_API_KEY 環境變數。
        
        Returns:
            模型名稱列表
        
        Raises:
            ProviderAPIError: 當 API 查詢失敗或 SDK 未安裝時拋出
        """
        try:
            import os
            
            api_key = os.environ.get("DASHSCOPE_API_KEY")
            if not api_key:
                raise ProviderAPIError("請設定 DASHSCOPE_API_KEY 環境變數")
            
            # 直接呼叫 API
            response = await self.client.get(
                f"{self.API_BASE}/models",
                headers={"Authorization": f"Bearer {api_key}"}
            )
            response.raise_for_status()
            data = response.json()
            return [m["model_id"] for m in data.get("data", [])]
        except Exception as e:
            raise ProviderAPIError(f"查詢 Qwen 模型清單失敗: {e}")
    
    def _extract_family(self, model_name: str) -> Dict[str, str]:
        """
        提取 Qwen 模型的家族特徵
        
        從模型名稱中識別階層與版本。
        
        Args:
            model_name: 模型名稱
        
        Returns:
            家族特徵字典,包含 "base" 與 "tier"
        
        Examples:
            >>> _extract_family("qwen-turbo")
            {"base": "qwen", "tier": "turbo"}
            >>> _extract_family("qwen-plus")
            {"base": "qwen", "tier": "plus"}
            >>> _extract_family("qwen3-omni")
            {"base": "qwen", "tier": "omni"}
        """
        model_lower = model_name.lower()
        
        # 識別階層
        tiers = ["turbo", "flash", "plus", "max", "omni", "vl", "coder"]
        tier = "unknown"
        for t in tiers:
            if t in model_lower:
                tier = t
                break
        
        return {
            "base": "qwen",
            "tier": tier
        }
    
    def _select_latest(self, candidates: List[str]) -> str:
        """
        從 Qwen 候選模型中選擇最新版本
        
        選擇策略:
        1. 提取 Qwen 版本號 (如 qwen3 > qwen2)
        2. 按版本號排序
        3. 選擇版本號最高的模型
        
        Args:
            candidates: 候選模型列表
        
        Returns:
            最新版本的模型名稱
        """
        def version_key(model: str):
            """生成排序鍵值"""
            # 提取 Qwen 版本號 (如 qwen3, qwen2)
            match = re.search(r'qwen(\d+)', model.lower())
            return int(match.group(1)) if match else 0
        
        return max(candidates, key=version_key)
