"""
llm_smart_router.exceptions
---------------------------

自訂異常類別

此模組定義 LLM Smart Router 使用的所有異常類別,
用於處理模型替換過程中可能發生的各種錯誤情況。
"""


class LLMRouterException(Exception):
    """
    LLM Router 基礎異常類別
    
    所有 llm_smart_router 相關異常的父類別
    """
    pass


class ModelReplacementError(LLMRouterException):
    """
    模型替換失敗異常
    
    當無法為失效模型找到合適的替代模型時拋出此異常。
    這通常表示:
    1. 供應商沒有提供同家族的其他模型
    2. 所有候選模型也已失效
    3. 關鍵字匹配與編輯距離都無法找到相似模型
    """
    pass


class ProviderNotSupportedError(LLMRouterException):
    """
    不支援的供應商異常
    
    當使用者指定的 provider 參數不在支援清單中時拋出。
    
    支援的供應商: claude, gemini, openai, qwen, mistral
    """
    pass


class ProviderAPIError(LLMRouterException):
    """
    供應商 API 查詢失敗異常
    
    當查詢供應商的模型清單 API 失敗時拋出。
    可能原因:
    1. API Key 無效或過期
    2. 網路連線問題
    3. 供應商 API 暫時不可用
    4. API 端點變更
    """
    pass
