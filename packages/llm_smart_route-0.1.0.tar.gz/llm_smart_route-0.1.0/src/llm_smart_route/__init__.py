"""
llm_smart_router
----------------

輕量級 LLM 模型追蹤與自動替換 Decorator

這個套件提供 @smart_model 裝飾器,幫助開發者自動處理 LLM 模型失效問題。
當模型被供應商棄用或更新時,自動偵測並切換到同家族的最新版本。

基本使用:
    >>> from llm_smart_router import smart_model
    >>> 
    >>> @smart_model(provider="claude", model="claude-3-5-haiku")
    ... def ask_claude(model: str, question: str):
    ...     return anthropic.messages.create(model=model, ...)

支援的供應商:
    - Claude (Anthropic): provider="claude" 或 "anthropic"
    - Gemini (Google): provider="gemini" 或 "google"
    - GPT (OpenAI): provider="openai" 或 "gpt"
    - Qwen (Alibaba): provider="qwen" 或 "alibaba"
    - Mistral AI: provider="mistral"
"""

from .decorator import smart_model
from .exceptions import (
    LLMRouterException,
    ModelReplacementError,
    ProviderNotSupportedError,
    ProviderAPIError,
)
from .cache import (
    get_cache, 
    ModelCache, 
    get_replacement_cache, 
    ReplacementCache,
    configure_cache
)
from .providers import get_provider, BaseProvider
from .notification import (
    create_slack_notifier,
    create_line_notifier,
    create_console_notifier
)

__version__ = "0.1.0"
__author__ = "YuChieh Chiu"

__all__ = [
    # 主要介面
    "smart_model",
    
    # 異常
    "LLMRouterException",
    "ModelReplacementError",
    "ProviderNotSupportedError",
    "ProviderAPIError",
    
    # 快取與持久化
    "get_cache",
    "ModelCache",
    "get_replacement_cache",
    "ReplacementCache",
    "configure_cache",
    
    # 通知
    "create_slack_notifier",
    "create_line_notifier",
    "create_console_notifier",
    
    # 適配器
    "get_provider",
    "BaseProvider",
]
