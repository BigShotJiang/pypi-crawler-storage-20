# 更新日誌 (Changelog)

本專案的所有重大變更都將記錄在此文件中。

## [0.1.0] - 2026-01-15

### 新增 (Added)
- `llm-smart-route` 首次發布。
- 新增 `@smart_model` Decorator，實現 LLM 路由的自我修復機制。
- 支援多種 AI 供應商：Anthropic, Google Gemini, OpenAI, Alibaba (Qwen), Mistral。
- 基於模型能力的自動 fallback 機制。
- 實作持久化快取 (Persistence caching) 以優化路由效能。
- 整合 Slack 與 Line 通知功能。
