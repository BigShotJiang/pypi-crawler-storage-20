"""
rotalabs-verify - Verified code synthesis with CE2P hypothesis

https://rotalabs.ai
"""

__version__ = "0.0.1"
