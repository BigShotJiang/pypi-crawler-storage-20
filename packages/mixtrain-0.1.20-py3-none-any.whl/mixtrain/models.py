"""Model reference system for convenient model access.

This module provides a Model proxy class that makes it easy to reference
and interact with models in a workspace.

Example:
    >>> from mixtrain import get_model
    >>> model = get_model("my-model")
    >>> result = model.run({"text": "Hello world"})
    >>> print(result.video.url)  # Typed access to outputs
"""

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Dict, List, Optional

from .client import MixClient
from .helpers import validate_resource_name
from .result import ModelResult

logger = logging.getLogger(__name__)


class Model:
    """Proxy class for convenient model access and operations.

    This class wraps MixClient model operations and provides a clean,
    object-oriented interface for working with models.

    Args:
        name: Name of the model
        client: Optional MixClient instance (creates new one if not provided)

    Attributes:
        name: Model name
        client: MixClient instance for API operations

    Example:
        >>> model = Model("sentiment-analyzer")
        >>> result = model.run({"text": "Great product!"})
        >>> print(model.metadata)
        >>> print(model.runs)
    """

    def __init__(self, name: str, client: Optional[MixClient] = None):
        """Initialize Model proxy.

        Args:
            name: Name of the model
            client: Optional MixClient instance (creates new one if not provided)

        Raises:
            ValueError: If name is invalid (must be lowercase alphanumeric with hyphens/underscores)
        """
        validate_resource_name(name, "model")
        self.name = name
        self.client = client or MixClient()
        self._metadata: Optional[Dict[str, Any]] = None
        self._runs_cache: Optional[List[Dict[str, Any]]] = None

    def submit(
        self,
        inputs: Optional[Dict[str, Any]] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Submit model inference asynchronously. Returns run info immediately.

        This starts a model run and returns immediately without waiting for completion.
        Use this when you want to manage the run lifecycle yourself or run multiple
        models in parallel.

        Args:
            inputs: Input data for the model
            config: Optional configuration overrides

        Returns:
            Run info including run_number and status

        Example:
            >>> model = Model("sentiment-analyzer")
            >>> run_info = model.submit({"text": "Great product!"})
            >>> print(f"Started run #{run_info['run_number']}")
            >>> # Later, check status:
            >>> run = model.get_run(run_info['run_number'])
        """
        return self.client.run_model(self.name, inputs=inputs, config=config)

    def run(
        self,
        inputs: Optional[Dict[str, Any]] = None,
        config: Optional[Dict[str, Any]] = None,
        timeout: int = 300,
    ) -> ModelResult:
        """Run model inference synchronously. Blocks until completion.

        This submits a model run and polls until it completes. Use this when you
        want a simple blocking call that returns the outputs directly.

        For long-running models, uses polling with exponential backoff to avoid
        HTTP connection timeout issues.

        Args:
            inputs: Input data for the model
            config: Optional configuration overrides
            timeout: Maximum seconds to wait for completion (default: 300)

        Returns:
            ModelResult with typed accessors for outputs (video, image, audio, text)

        Raises:
            TimeoutError: If model doesn't complete within timeout
            ValueError: If run submission fails

        Example:
            >>> model = Model("hunyuan-video")
            >>> result = model.run({"prompt": "A cat playing piano"})
            >>> print(result.video.url)  # Typed access
            >>> print(result.status)     # "completed"
        """
        import time

        # Submit the run
        run_info = self.submit(inputs=inputs, config=config)
        run_number = run_info.get("run_number")
        if not run_number:
            raise ValueError(f"Failed to start model run: {run_info}")

        # Poll for completion with error handling
        start_time = time.time()
        poll_interval = 0.5
        consecutive_errors = 0
        max_consecutive_errors = 5
        last_known_run: Optional[Dict[str, Any]] = None

        while time.time() - start_time < timeout:
            try:
                run = self.get_run(run_number)
                last_known_run = run
                consecutive_errors = 0  # Reset on success

                if run["status"] in ["completed", "failed", "cancelled"]:
                    return ModelResult(run)
            except Exception as e:
                consecutive_errors += 1
                logger.warning(
                    f"Failed to fetch run status (attempt {consecutive_errors}): {e}"
                )
                if consecutive_errors >= max_consecutive_errors:
                    # Return last known state or raise with context
                    if last_known_run:
                        logger.error(
                            f"Too many errors, returning last known state for run {run_number}"
                        )
                        last_known_run["_polling_error"] = str(e)
                        return ModelResult(last_known_run)
                    raise RuntimeError(
                        f"Failed to poll model run {run_number} after {max_consecutive_errors} attempts: {e}"
                    ) from e

            time.sleep(poll_interval)
            # Exponential backoff up to 5s
            poll_interval = min(poll_interval * 1.5, 5)

        raise TimeoutError(f"Model run {run_number} did not complete within {timeout}s")

    def run_batch(
        self,
        inputs_list: List[Dict[str, Any]],
        config: Optional[Dict[str, Any]] = None,
        max_workers: int = 10,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> List[ModelResult]:
        """Run model inference on multiple inputs in parallel.

        Args:
            inputs_list: List of input dictionaries
            config: Optional configuration overrides applied to all runs
            max_workers: Maximum number of parallel workers (default: 10)
            progress_callback: Optional callback(completed, total) for progress updates

        Returns:
            List of ModelResult objects (in same order as inputs)

        Example:
            >>> model = Model("hunyuan-video")
            >>> results = model.run_batch([
            ...     {"prompt": "A cat"},
            ...     {"prompt": "A dog"}
            ... ])
            >>> for r in results:
            ...     print(r.video.url)
        """
        if not inputs_list:
            return []

        results: List[Optional[Dict[str, Any]]] = [None] * len(inputs_list)
        completed = 0

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_idx = {
                executor.submit(self.run, inputs, config): idx
                for idx, inputs in enumerate(inputs_list)
            }
            for future in as_completed(future_to_idx):
                idx = future_to_idx[future]
                results[idx] = future.result()
                completed += 1
                if progress_callback:
                    progress_callback(completed, len(inputs_list))

        return results  # type: ignore

    @property
    def metadata(self) -> Dict[str, Any]:
        """Get model metadata (cached after first access).

        Returns:
            Model details including name, source, description, etc.

        Example:
            >>> model = Model("my-model")
            >>> print(model.metadata["source"])
            >>> print(model.metadata["description"])
        """
        if self._metadata is None:
            self._metadata = self.client.get_model(self.name)
        return self._metadata

    @property
    def spec(self) -> Optional[Dict[str, Any]]:
        """Get model specification.

        Returns:
            Model spec dictionary or None
        """
        return self.metadata.get("spec")

    @property
    def source(self) -> str:
        """Get model source (native, fal, modal, openai, anthropic, etc.).

        Returns:
            Model source string
        """
        return self.metadata.get("source", "")

    @property
    def description(self) -> str:
        """Get model description.

        Returns:
            Model description string
        """
        return self.metadata.get("description", "")

    @property
    def runs(self) -> List[Dict[str, Any]]:
        """Get recent model runs (cached).

        Returns:
            List of model runs

        Example:
            >>> model = Model("my-model")
            >>> for run in model.runs:
            ...     print(f"Run #{run['run_number']}: {run['status']}")
        """
        if self._runs_cache is None:
            response = self.client.list_model_runs(self.name)
            self._runs_cache = response.get("runs", [])
        return self._runs_cache

    def get_runs(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get model runs with optional limit.

        Args:
            limit: Maximum number of runs to return

        Returns:
            List of model runs

        Example:
            >>> model = Model("my-model")
            >>> recent_runs = model.get_runs(limit=5)
        """
        response = self.client.list_model_runs(self.name)
        runs = response.get("runs", [])
        if limit:
            runs = runs[:limit]
        return runs

    def get_run(self, run_number: int) -> Dict[str, Any]:
        """Get details of a specific model run.

        Args:
            run_number: Run number

        Returns:
            Run details

        Example:
            >>> model = Model("my-model")
            >>> run = model.get_run(5)
            >>> print(run["status"])
        """
        return self.client.get_model_run(self.name, run_number)

    def update_run(
        self,
        run_number: int,
        status: Optional[str] = None,
        outputs: Optional[Any] = None,
        error: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Update a model run's status and outputs.

        Args:
            run_number: Run number to update
            status: New status (e.g., "running", "completed", "failed")
            outputs: Output data from the model run
            error: Error message if run failed

        Returns:
            Updated run details

        Example:
            >>> model = Model("my-model")
            >>> model.update_run(5, status="completed", outputs={"result": "success"})
        """
        return self.client.update_model_run_status(
            self.name, run_number, status=status, outputs=outputs, error=error
        )

    def get_logs(self, run_number: Optional[int] = None) -> str:
        """Get logs for a model run.

        Args:
            run_number: Optional run number (defaults to latest run)

        Returns:
            Log content as string

        Example:
            >>> model = Model("my-model")
            >>> logs = model.get_logs()  # Latest run
            >>> print(logs)
        """
        logs_data = self.client.get_model_run_logs(self.name, run_number)
        return logs_data.get("logs", "")

    def get_code(self) -> str:
        """Get model source code (for native models).

        Returns:
            Model code as string

        Example:
            >>> model = Model("my-model")
            >>> code = model.get_code()
            >>> print(code)
        """
        code_data = self.client.get_model_code(self.name)
        return code_data.get("code", "")

    def update_code(self, code: str) -> Dict[str, Any]:
        """Update model source code (for native models).

        Args:
            code: New code content

        Returns:
            Update result

        Example:
            >>> model = Model("my-model")
            >>> model.update_code("def run():\\n    return {'result': 'success'}")
        """
        return self.client.update_model_code(self.name, code)

    def list_files(self) -> List[Dict[str, Any]]:
        """List files in the model.

        Returns:
            List of files

        Example:
            >>> model = Model("my-model")
            >>> files = model.list_files()
            >>> for file in files:
            ...     print(file["path"])
        """
        response = self.client.list_model_files(self.name)
        return response.get("files", [])

    def get_file(self, file_path: str) -> str:
        """Get content of a specific model file.

        Args:
            file_path: Path to file within model

        Returns:
            File content as string

        Example:
            >>> model = Model("my-model")
            >>> content = model.get_file("requirements.txt")
        """
        response = self.client.get_model_file(self.name, file_path)
        return response.get("content", "")

    def update(
        self, name: Optional[str] = None, description: Optional[str] = None
    ) -> Dict[str, Any]:
        """Update model metadata.

        Args:
            name: Optional new name
            description: Optional new description

        Returns:
            Updated model data

        Example:
            >>> model = Model("my-model")
            >>> model.update(description="Updated description")
        """
        result = self.client.update_model(self.name, name=name, description=description)
        # Update local name if changed
        if name:
            self.name = name
        # Clear metadata cache
        self._metadata = None
        return result

    def delete(self) -> Dict[str, Any]:
        """Delete the model.

        Returns:
            Deletion result

        Example:
            >>> model = Model("my-model")
            >>> model.delete()
        """
        return self.client.delete_model(self.name)

    def refresh(self):
        """Clear cached data and force refresh on next access.

        Example:
            >>> model = Model("my-model")
            >>> model.refresh()
            >>> print(model.metadata)  # Will fetch fresh data
        """
        self._metadata = None
        self._runs_cache = None

    def __repr__(self) -> str:
        """String representation of the Model."""
        return f"Model(name='{self.name}', source='{self.source}')"

    def __str__(self) -> str:
        """Human-readable string representation."""
        return f"Model: {self.name} ({self.source})"

    @staticmethod
    def batch(
        models: List[str],
        inputs_list: List[Dict[str, Any]],
        config: Optional[Dict[str, Any]] = None,
        client: Optional[MixClient] = None,
        max_workers: int = 10,
        progress_callback: Optional[Callable[[int, int], None]] = None,
        timeout: int = 600,
        filter_failures: bool = False,
    ) -> "BatchResult":
        """Run same inputs across multiple models in parallel.

        Uses an efficient two-phase approach:
        1. Submit all runs in parallel (fast)
        2. Single polling loop checks all pending runs (reduces API load)

        Args:
            models: List of model names to run
            inputs_list: List of input dictionaries (same for all models)
            config: Optional configuration overrides applied to all runs
            client: Optional MixClient instance
            max_workers: Maximum number of parallel workers for submission (default: 10)
            progress_callback: Optional callback(completed, total) for progress updates
            timeout: Maximum seconds to wait for all runs to complete (default: 600)
            filter_failures: If True, only include results where ALL models succeeded.

        Returns:
            BatchResult with .inputs, .to_dict(), .to_pandas() methods.

        Example:
            >>> result = Model.batch(
            ...     ["flux", "stable-diffusion"],
            ...     [{"prompt": "a cat"}, {"prompt": "a dog"}]
            ... )
            >>> df = result.to_pandas()  # Auto-converts to DataFrame

            >>> # With filter_failures to handle timeouts gracefully:
            >>> result = Model.batch(
            ...     ["flux", "stable-diffusion"],
            ...     [{"prompt": "a cat"}, {"prompt": "a dog"}],
            ...     filter_failures=True
            ... )
            >>> print(f"Succeeded: {len(result)}/{len(inputs_list)}")
            >>> df = result.to_pandas()
        """
        from .result import BatchResult
        import time

        if client is None:
            client = MixClient()

        # Total tasks = models * inputs
        total_tasks = len(models) * len(inputs_list)
        results: Dict[str, List[Optional[Dict[str, Any]]]] = {
            model: [None] * len(inputs_list) for model in models
        }

        # Phase 1: Submit all runs in parallel
        # Track pending runs as (model_name, idx, run_number)
        pending_runs: List[tuple] = []
        model_instances: Dict[str, Model] = {}

        def submit_single(model_name: str, idx: int, inputs: Dict[str, Any]) -> tuple:
            """Submit a single model run and return run info."""
            try:
                if model_name not in model_instances:
                    model_instances[model_name] = Model(model_name, client=client)
                model = model_instances[model_name]
                run_info = model.submit(inputs=inputs, config=config)
                run_number = run_info.get("run_number")
                if not run_number:
                    return (model_name, idx, None, f"Failed to start run: {run_info}")
                return (model_name, idx, run_number, None)
            except Exception as e:
                return (model_name, idx, None, str(e))

        logger.info(f"Submitting {total_tasks} runs...")
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = []
            for model_name in models:
                for idx, inputs in enumerate(inputs_list):
                    future = executor.submit(submit_single, model_name, idx, inputs)
                    futures.append(future)

            for future in as_completed(futures):
                model_name, idx, run_number, error = future.result()
                if error:
                    logger.warning(
                        f"Model {model_name} submission failed for input {idx}: {error}"
                    )
                    results[model_name][idx] = {"error": error, "status": "failed"}
                else:
                    pending_runs.append((model_name, idx, run_number))

        logger.info(f"Submitted {len(pending_runs)} runs, polling for completion...")

        # Phase 2: Single polling loop for all pending runs
        start_time = time.time()
        poll_interval = 1.0
        completed = total_tasks - len(pending_runs)  # Count already failed submissions

        if progress_callback and completed > 0:
            progress_callback(completed, total_tasks)

        while pending_runs and (time.time() - start_time) < timeout:
            still_pending = []

            for model_name, idx, run_number in pending_runs:
                try:
                    model = model_instances[model_name]
                    run = model.get_run(run_number)

                    if run["status"] in ["completed", "failed", "cancelled"]:
                        results[model_name][idx] = run
                        completed += 1
                        if progress_callback:
                            progress_callback(completed, total_tasks)
                    else:
                        still_pending.append((model_name, idx, run_number))
                except Exception as e:
                    logger.warning(f"Error polling {model_name} run {run_number}: {e}")
                    still_pending.append((model_name, idx, run_number))

            pending_runs = still_pending

            if pending_runs:
                time.sleep(poll_interval)
                # Increase poll interval up to 5s
                poll_interval = min(poll_interval * 1.2, 5.0)

        # Handle timeouts
        for model_name, idx, run_number in pending_runs:
            results[model_name][idx] = {
                "error": f"Timeout waiting for run {run_number}",
                "status": "timeout",
                "run_number": run_number,
            }
            completed += 1
            if progress_callback:
                progress_callback(completed, total_tasks)

        # Wrap all results in ModelResult
        wrapped_results: Dict[str, List[ModelResult]] = {}
        for model_name, run_list in results.items():
            wrapped_results[model_name] = [
                ModelResult(run) for run in run_list if run is not None
            ]

        # Filter failures if requested
        if filter_failures:
            from .result import RunStatus

            # Find indices where ALL models succeeded
            valid_indices = []
            for i in range(len(inputs_list)):
                all_success = all(
                    wrapped_results[model][i].status == RunStatus.COMPLETED
                    for model in models
                )
                if all_success:
                    valid_indices.append(i)

            # Log filtered count
            filtered_count = len(inputs_list) - len(valid_indices)
            if filtered_count > 0:
                logger.info(
                    f"Filtered out {filtered_count}/{len(inputs_list)} inputs due to failures"
                )

            # Filter results and inputs
            filtered_results: Dict[str, List[ModelResult]] = {}
            for model_name in models:
                filtered_results[model_name] = [
                    wrapped_results[model_name][i] for i in valid_indices
                ]
            filtered_inputs = [inputs_list[i] for i in valid_indices]

            return BatchResult(inputs=filtered_inputs, _results=filtered_results)

        # Return all results (default behavior)
        return BatchResult(inputs=inputs_list, _results=wrapped_results)


def get_model(name: str, client: Optional[MixClient] = None) -> Model:
    """Get a model reference by name.

    This is the primary way to access models in a workspace.

    Args:
        name: Model name
        client: Optional MixClient instance

    Returns:
        Model proxy instance

    Example:
        >>> from mixtrain import get_model
        >>> model = get_model("sentiment-analyzer")
        >>> result = model.run({"text": "Great!"})
    """
    return Model(name, client=client)


def list_models(
    provider: Optional[str] = None, client: Optional[MixClient] = None
) -> List[Model]:
    """List all models in the workspace.

    Args:
        provider: Optional filter by provider type
        client: Optional MixClient instance

    Returns:
        List of Model instances

    Example:
        >>> from mixtrain import list_models
        >>> models = list_models()
        >>> for model in models:
        ...     print(model.name)
    """
    if client is None:
        client = MixClient()

    response = client.list_models(provider=provider)
    models_data = response.get("models", [])

    return [Model(m["name"], client=client) for m in models_data]
