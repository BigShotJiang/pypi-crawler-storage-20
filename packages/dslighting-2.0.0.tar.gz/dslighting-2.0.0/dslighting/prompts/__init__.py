"""
DSLighting 2.0 - Prompts Layer

This layer provides prompt engineering components:
- PromptBuilder: Fluent API for building prompts
- Template functions: Standard prompt templates
- Guidelines: Common prompt guidelines
"""

from .builder import PromptBuilder
from .base import (
    create_prompt_template,
    get_common_guidelines,
)

# Re-export template functions
from .templates import (
    create_modeling_prompt,
    create_eda_prompt,
    create_debug_prompt,
)

__all__ = [
    "PromptBuilder",
    "create_prompt_template",
    "get_common_guidelines",
    "create_modeling_prompt",
    "create_eda_prompt",
    "create_debug_prompt",
]
