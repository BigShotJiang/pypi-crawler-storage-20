"""
DSLighting 2.0 - Prompts Layer

This layer provides prompt engineering components:
- PromptBuilder: Fluent API for building prompts
- StructuredPromptBuilder: Dict-based prompt builder (推荐)
- Template functions: Standard prompt templates
- Guidelines: Common prompt guidelines
"""

from .builder import PromptBuilder
from .structured_builder import (
    StructuredPromptBuilder,
    PromptTemplate,
    truncate_output,
    format_code_block,
    create_structured_prompt,
)
from .base import (
    create_prompt_template,
    get_common_guidelines,
)

# Re-export template functions
try:
    from .templates import (
        create_modeling_prompt,
        create_eda_prompt,
        create_debug_prompt,
    )
    _has_templates = True
except ImportError:
    _has_templates = False

__all__ = [
    # Fluent API
    "PromptBuilder",

    # Structured API (推荐)
    "StructuredPromptBuilder",
    "PromptTemplate",
    "truncate_output",
    "format_code_block",
    "create_structured_prompt",

    # Base functions
    "create_prompt_template",
    "get_common_guidelines",
]

# Add templates if available
if _has_templates:
    __all__.extend([
        "create_modeling_prompt",
        "create_eda_prompt",
        "create_debug_prompt",
    ])
