"""
DSLighting 2.0 - Operators Layer

This layer provides atomic, reusable capability units.

Operators are organized into categories:
- LLM Operators: Language model operations (generate, plan, review, summarize)
- Code Operators: Code execution operations
- Data Operators: Data science operations (analysis, features, modeling, evaluation)
- Orchestration Operators: Composition patterns (Pipeline, Parallel, Conditional)
"""

# Base operator class
try:
    from dsat.operators.base import Operator
except ImportError:
    Operator = None

# LLM Operators
try:
    from dsat.operators.llm.generate import GenerateCodeAndPlanOperator
    from dsat.operators.llm.plan import PlanOperator
    from dsat.operators.llm.review import ReviewOperator
    from dsat.operators.llm.summarize import SummarizeOperator
except ImportError:
    GenerateCodeAndPlanOperator = None
    PlanOperator = None
    ReviewOperator = None
    SummarizeOperator = None

# Code Operators
try:
    from dsat.operators.code.execute import ExecuteAndTestOperator
except ImportError:
    ExecuteAndTestOperator = None

# Re-export orchestration operators
from .orchestration import Pipeline, Parallel, Conditional

# Custom Operators (用户自定义)
try:
    from .custom import *  # 导入所有自定义 operators
except ImportError:
    # 如果没有自定义 operators，忽略
    pass

__all__ = [
    # Base
    "Operator",
    # LLM Operators
    "GenerateCodeAndPlanOperator",
    "PlanOperator",
    "ReviewOperator",
    "SummarizeOperator",
    # Code Operators
    "ExecuteAndTestOperator",
    # Orchestration
    "Pipeline",
    "Parallel",
    "Conditional",
]
