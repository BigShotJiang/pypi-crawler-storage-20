def task():
    raise Exception
