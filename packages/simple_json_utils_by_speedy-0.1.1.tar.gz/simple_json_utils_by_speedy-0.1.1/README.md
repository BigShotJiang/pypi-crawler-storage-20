# SimpleJsonUtils
**Simple tools for operations on small, uncomplicated JSON files.**

This library is created for students and their small projects that use JSON files.
Strong side of those tools is that they are very simple to use
You can use it for bigger projects, but remember: **This is NOT designed for large or complex data structures.**



# Features

- **Read and parse JSON files**
- **Append dictionaries to JSON files**
- **Overwrite existing JSON files**
- **Edit values in JSON dictionaries**
- **Add key-value pairs**
- **Remove dictionaries from JSON files**
- **Check existence of keys or values**
- **Get max/min values for numeric fields**
- **Normalize JSON files from dict to list format**
- **Create empty JSON files of type list or dict**

## Author
- Marcin 'Speedy' Kotowski
Contact:
- Discord: d2slasher
- Gmail: marcin.kotowski2k09@gmail.com
