"""TUI module for Kata."""
