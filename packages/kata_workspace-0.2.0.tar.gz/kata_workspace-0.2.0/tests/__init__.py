"""Tests for Kata."""
