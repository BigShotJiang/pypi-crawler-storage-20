# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License"). You
# may not use this file except in compliance with the License. A copy of
# the License is located at
#
#     http://aws.amazon.com/apache2.0/
#
# or in the "license" file accompanying this file. This file is
# distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF
# ANY KIND, either express or implied. See the License for the specific
# language governing permissions and limitations under the License.
"""
DEPRECATED: This module has been moved to sagemaker.core.remote_function

This is a backward compatibility shim. Please update your imports to:
    from sagemaker.core.remote_function import ...
"""
from __future__ import absolute_import

import warnings

# Backward compatibility: re-export from core
from sagemaker.core.remote_function.client import remote, RemoteExecutor  # noqa: F401
from sagemaker.core.remote_function.checkpoint_location import CheckpointLocation  # noqa: F401
from sagemaker.core.remote_function.custom_file_filter import CustomFileFilter  # noqa: F401
from sagemaker.core.remote_function.spark_config import SparkConfig  # noqa: F401

warnings.warn(
    "sagemaker.train.remote_function has been moved to sagemaker.core.remote_function. "
    "Please update your imports. This shim will be removed in a future version.",
    DeprecationWarning,
    stacklevel=2
)
