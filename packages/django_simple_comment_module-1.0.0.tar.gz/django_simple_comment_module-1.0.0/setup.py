#!/usr/bin/env python
from setuptools import setup, find_packages
import os


# Безопасное чтение README.md
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), "README.md")
    if os.path.exists(readme_path):
        try:
            with open(readme_path, "r", encoding="utf-8") as fh:
                return fh.read()
        except Exception:
            return "Django Simple Comment Module"
    return "Django Simple Comment Module"


# Безопасное чтение requirements.txt
def read_requirements():
    req_path = os.path.join(os.path.dirname(__file__), "requirements.txt")
    if os.path.exists(req_path):
        try:
            with open(req_path, "r", encoding="utf-8") as fh:
                return [
                    line.strip()
                    for line in fh
                    if line.strip() and not line.startswith("#")
                ]
        except Exception:
            pass
    # Возвращаем зависимости по умолчанию если файла нет
    return ["Django>=3.2,<5.0"]


# Безопасное получение версии
def get_version():
    try:
        init_path = os.path.join(
            os.path.dirname(__file__), "django_simple_ratings", "__init__.py"
        )

        # Проверяем существует ли файл
        if not os.path.exists(init_path):
            print(f"Warning: {init_path} not found, using default version")
            return "1.0.0"

        with open(init_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("__version__"):
                    # Извлекаем версию
                    version = line.split("=")[1].strip().strip('"').strip("'")
                    return version if version else "1.0.0"
    except Exception as e:
        print(f"Warning: Could not read version: {e}")

    return "1.0.0"


# Используем безопасные функции
long_description = read_readme()
requirements = read_requirements()
version = get_version()

setup(
    name="django-simple-comment-module",
    version=version,
    author="a.glazyrin",
    author_email="railot116@gmail.com",
    description="Простая система комментариев с рейтингом для Django",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/glazyrinae/django-simple-comment-module",
    project_urls={
        "Bug Tracker": "https://github.com/glazyrinae/django-simple-comment-module/issues",
        "Documentation": "https://github.com/glazyrinae/django-simple-comment-module/wiki",
        "Source Code": "https://github.com/glazyrinae/django-simple-comment-module",
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Web Environment",
        "Framework :: Django",
        "Framework :: Django :: 3.2",
        "Framework :: Django :: 4.0",
        "Framework :: Django :: 4.1",
        "Framework :: Django :: 4.2",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Internet :: WWW/HTTP",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords=[
        "django",
        "ratings",
        "comments",
        "reviews",
        "stars",
        "feedback",
        "django-app",
        "django-package",
    ],
    packages=find_packages(exclude=["tests", "tests.*"]),
    include_package_data=True,
    zip_safe=False,
    python_requires=">=3.7",
    install_requires=requirements,
    # Опциональные зависимости
    extras_require={
        "dev": [
            "black>=23.0",
            "flake8>=6.0",
            "isort>=5.12",
            "pytest>=7.0",
            "pytest-django>=4.5",
            "coverage>=7.0",
            "sphinx>=7.0",
            "twine>=4.0",
        ],
        "test": [
            "pytest>=7.0",
            "pytest-django>=4.5",
            "coverage>=7.0",
        ],
        "docs": [
            "sphinx>=7.0",
            "sphinx-rtd-theme>=1.0",
        ],
    },
    # Скрипты для командной строки
    entry_points={
        "console_scripts": [
            # Можно добавить CLI утилиты
        ],
    },
)
