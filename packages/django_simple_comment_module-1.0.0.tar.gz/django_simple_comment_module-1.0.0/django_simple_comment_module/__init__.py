"""
Django Simple Comment Module - Простая система комментариев с рейтингом для Django.
"""

__version__ = "1.0.0"
__author__ = "a.glazyrin"
__email__ = "railot116@gmail.com"
__license__ = "MIT"
__url__ = "https://github.com/glazyrinae/django-simple-comment-module"
