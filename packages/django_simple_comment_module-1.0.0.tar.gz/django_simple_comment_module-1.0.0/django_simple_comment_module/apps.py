from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class SimpleRatingsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_simple_comment_module"
    verbose_name = _("Модуль комментариев с рейтингом")

    def ready(self):
        # Импортируем сигналы
        try:
            from . import signals  # noqa: F401
        except ImportError:
            pass
