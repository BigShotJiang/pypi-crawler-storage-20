# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from keystoneauth1.extras._saml2 import v3

_V3_SAML2_AVAILABLE = v3._SAML2_AVAILABLE
_V3_ADFS_AVAILABLE = v3._ADFS_AVAILABLE

V3Saml2Password = v3.Saml2Password
V3ADFSPassword = v3.ADFSPassword


__all__ = ('V3Saml2Password', 'V3ADFSPassword')
