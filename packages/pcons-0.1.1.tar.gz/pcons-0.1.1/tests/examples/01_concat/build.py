#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Build script for the concat example.

This example demonstrates how to create and use a custom tool
that concatenates multiple text files into one.
"""

import os
from pathlib import Path

from pcons.core.builder import CommandBuilder
from pcons.core.project import Project
from pcons.generators.ninja import NinjaGenerator
from pcons.tools.tool import BaseTool

# =============================================================================
# Custom Tool Definition
# =============================================================================


class ConcatTool(BaseTool):
    """A custom tool that concatenates text files.

    This demonstrates how users can create their own tools
    without modifying pcons source code.
    """

    def __init__(self) -> None:
        super().__init__("concat")

    def default_vars(self) -> dict[str, object]:
        return {
            "cmd": "cat",
            "flags": [],
            "bundlecmd": "$concat.cmd $concat.flags $$in > $$out",
        }

    def builders(self) -> dict[str, object]:
        return {
            "Bundle": CommandBuilder(
                "Bundle",
                "concat",
                "bundlecmd",
                src_suffixes=[".txt"],
                target_suffixes=[".txt", ".bundle"],
                single_source=False,
            ),
        }


# =============================================================================
# Build Script
# =============================================================================

# Directories
build_dir = Path(os.environ.get("PCONS_BUILD_DIR", "build"))
src_dir = Path(__file__).parent / "src"

# Create project
project = Project("concat_example", build_dir=build_dir)

# Create environment and add our custom tool
env = project.Environment()
concat_tool = ConcatTool()
concat_tool.setup(env)

# Define the build: combine all txt files into one
env.concat.Bundle(
    build_dir / "combined.txt",
    [
        src_dir / "header.txt",
        src_dir / "content.txt",
        src_dir / "footer.txt",
    ],
)

# Generate ninja build file
generator = NinjaGenerator()
generator.generate(project, build_dir)

print(f"Generated {build_dir / 'build.ninja'}")
