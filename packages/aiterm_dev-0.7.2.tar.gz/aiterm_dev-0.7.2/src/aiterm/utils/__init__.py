"""Utility functions for aiterm."""
