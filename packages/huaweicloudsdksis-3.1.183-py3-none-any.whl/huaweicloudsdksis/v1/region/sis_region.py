# coding: utf-8

from huaweicloudsdkcore.region.region import Region
from huaweicloudsdkcore.region.provider import RegionProviderChain

class SisRegion:
    _PROVIDER = RegionProviderChain.get_default_region_provider_chain("SIS")

    CN_NORTH_4 = Region("cn-north-4",
                        "https://sis-ext.cn-north-4.myhuaweicloud.com")
    CN_EAST_3 = Region("cn-east-3",
                        "https://sis-ext.cn-east-3.myhuaweicloud.com")
    AP_SOUTHEAST_3 = Region("ap-southeast-3",
                        "https://sis-ext.ap-southeast-3.myhuaweicloud.com")
    ME_EAST_1 = Region("me-east-1",
                        "https://sis-ext.me-east-1.myhuaweicloud.com")

    static_fields = {
        "cn-north-4": CN_NORTH_4,
        "cn-east-3": CN_EAST_3,
        "ap-southeast-3": AP_SOUTHEAST_3,
        "me-east-1": ME_EAST_1,
    }

    @classmethod
    def value_of(cls, region_id, static_fields=None):
        if not region_id:
            raise KeyError("Unexpected empty parameter: region_id")

        fields = static_fields or cls.static_fields

        region = cls._PROVIDER.get_region(region_id)
        if region:
            return region

        if region_id in fields:
            return fields.get(region_id)

        raise KeyError("region_id '%s' is not in the following supported regions of service 'Sis': [%s]" % (
            region_id, ", ".join(sorted(fields.keys()))))
