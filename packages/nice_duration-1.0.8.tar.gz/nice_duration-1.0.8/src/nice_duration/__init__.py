from .nice_duration import duration_string, _keep_specified_zeroes
