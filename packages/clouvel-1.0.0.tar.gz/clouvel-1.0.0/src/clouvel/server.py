# -*- coding: utf-8 -*-
"""
Clouvel MCP Server v1.0.0
바이브코딩 프로세스를 강제하는 MCP 서버

통합 버전: Free + Pro (라이선스로 기능 잠금 해제)
"""

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .analytics import log_tool_call, get_stats, format_stats
from .license import activate_license, verify_license, get_license_age_days, PREMIUM_UNLOCK_DAYS
from .tools import (
    # core
    can_code, scan_docs, analyze_docs, init_docs, REQUIRED_DOCS,
    # docs
    get_prd_template, write_prd_section, get_prd_guide, get_verify_checklist, get_setup_guide,
    # setup
    init_clouvel, setup_cli,
    # rules (v0.5)
    init_rules, get_rule, add_rule,
    # verify (v0.5)
    verify, gate, handoff,
    # planning (v0.6)
    init_planning, save_finding, refresh_goals, update_progress,
    # agents (v0.7)
    spawn_explore, spawn_librarian,
    # hooks (v0.8)
    hook_design, hook_verify,
    # === Pro (라이선스 필요) ===
    # shovel
    install_shovel, sync_commands,
    # errors
    log_error, analyze_error, watch_logs, check_logs, add_prevention_rule, get_error_summary,
    # context
    recover_context, setup_auto_recovery, check_auto_recovery_status,
    # team
    team_invite, team_members, team_remove, team_settings, team_toggle_role,
    sync_team_errors, get_team_rules, apply_team_rules, sync_project_context, get_project_context,
)

server = Server("clouvel")


# ============================================================
# Tool Definitions (Free + Pro 통합)
# ============================================================

TOOL_DEFINITIONS = [
    # === Core Tools ===
    Tool(
        name="can_code",
        description="코드 작성 전 반드시 호출. 문서 상태 확인 후 코딩 가능 여부 판단.",
        inputSchema={
            "type": "object",
            "properties": {"path": {"type": "string", "description": "프로젝트 docs 폴더 경로"}},
            "required": ["path"]
        }
    ),
    Tool(
        name="scan_docs",
        description="프로젝트 docs 폴더 스캔. 파일 목록 반환.",
        inputSchema={
            "type": "object",
            "properties": {"path": {"type": "string", "description": "docs 폴더 경로"}},
            "required": ["path"]
        }
    ),
    Tool(
        name="analyze_docs",
        description="docs 폴더 분석. 필수 문서 체크.",
        inputSchema={
            "type": "object",
            "properties": {"path": {"type": "string", "description": "docs 폴더 경로"}},
            "required": ["path"]
        }
    ),
    Tool(
        name="init_docs",
        description="docs 폴더 초기화 + 템플릿 생성.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "project_name": {"type": "string", "description": "프로젝트 이름"}
            },
            "required": ["path", "project_name"]
        }
    ),

    # === Docs Tools ===
    Tool(
        name="get_prd_template",
        description="PRD 템플릿 생성.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_name": {"type": "string", "description": "프로젝트 이름"},
                "output_path": {"type": "string", "description": "출력 경로"}
            },
            "required": ["project_name", "output_path"]
        }
    ),
    Tool(
        name="write_prd_section",
        description="PRD 섹션별 작성 가이드.",
        inputSchema={
            "type": "object",
            "properties": {
                "section": {"type": "string", "enum": ["summary", "principles", "input_spec", "output_spec", "errors", "state_machine", "api_endpoints", "db_schema"]},
                "content": {"type": "string", "description": "섹션 내용"}
            },
            "required": ["section"]
        }
    ),
    Tool(name="get_prd_guide", description="PRD 작성 가이드.", inputSchema={"type": "object", "properties": {}}),
    Tool(name="get_verify_checklist", description="검증 체크리스트.", inputSchema={"type": "object", "properties": {}}),
    Tool(
        name="get_setup_guide",
        description="설치/설정 가이드.",
        inputSchema={
            "type": "object",
            "properties": {"platform": {"type": "string", "enum": ["desktop", "code", "vscode", "cursor", "all"]}}
        }
    ),
    Tool(
        name="get_analytics",
        description="도구 사용량 통계.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 경로"},
                "days": {"type": "integer", "description": "조회 기간 (기본: 30일)"}
            }
        }
    ),

    # === Setup Tools ===
    Tool(
        name="init_clouvel",
        description="Clouvel 온보딩. 플랫폼 선택 후 맞춤 설정.",
        inputSchema={
            "type": "object",
            "properties": {"platform": {"type": "string", "enum": ["desktop", "vscode", "cli", "ask"]}}
        }
    ),
    Tool(
        name="setup_cli",
        description="CLI 환경 설정. hooks, CLAUDE.md, pre-commit 생성.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "level": {"type": "string", "enum": ["remind", "strict", "full"]}
            },
            "required": ["path"]
        }
    ),

    # === Rules Tools (v0.5) ===
    Tool(
        name="init_rules",
        description="v0.5: 규칙 모듈화 초기화.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "template": {"type": "string", "enum": ["web", "api", "fullstack", "minimal"]}
            },
            "required": ["path"]
        }
    ),
    Tool(
        name="get_rule",
        description="v0.5: 경로 기반 규칙 로딩.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "파일 경로"},
                "context": {"type": "string", "enum": ["coding", "review", "debug", "test"]}
            },
            "required": ["path"]
        }
    ),
    Tool(
        name="add_rule",
        description="v0.5: 새 규칙 추가.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "rule_type": {"type": "string", "enum": ["never", "always", "prefer"]},
                "content": {"type": "string", "description": "규칙 내용"},
                "category": {"type": "string", "enum": ["api", "frontend", "database", "security", "general"]}
            },
            "required": ["path", "rule_type", "content"]
        }
    ),

    # === Verify Tools (v0.5) ===
    Tool(
        name="verify",
        description="v0.5: Context Bias 제거 검증.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "검증 대상 경로"},
                "scope": {"type": "string", "enum": ["file", "feature", "full"]},
                "checklist": {"type": "array", "items": {"type": "string"}}
            },
            "required": ["path"]
        }
    ),
    Tool(
        name="gate",
        description="v0.5: lint → test → build 자동화.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "steps": {"type": "array", "items": {"type": "string"}},
                "fix": {"type": "boolean"}
            },
            "required": ["path"]
        }
    ),
    Tool(
        name="handoff",
        description="v0.5: 의도 기록.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "feature": {"type": "string", "description": "완료한 기능"},
                "decisions": {"type": "string"},
                "warnings": {"type": "string"},
                "next_steps": {"type": "string"}
            },
            "required": ["path", "feature"]
        }
    ),

    # === Planning Tools (v0.6) ===
    Tool(
        name="init_planning",
        description="v0.6: 영속적 컨텍스트 초기화.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "task": {"type": "string", "description": "현재 작업"},
                "goals": {"type": "array", "items": {"type": "string"}}
            },
            "required": ["path", "task"]
        }
    ),
    Tool(
        name="save_finding",
        description="v0.6: 조사 결과 저장.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "topic": {"type": "string"},
                "question": {"type": "string"},
                "findings": {"type": "string"},
                "source": {"type": "string"},
                "conclusion": {"type": "string"}
            },
            "required": ["path", "topic", "findings"]
        }
    ),
    Tool(
        name="refresh_goals",
        description="v0.6: 목표 리마인드.",
        inputSchema={
            "type": "object",
            "properties": {"path": {"type": "string", "description": "프로젝트 루트 경로"}},
            "required": ["path"]
        }
    ),
    Tool(
        name="update_progress",
        description="v0.6: 진행 상황 업데이트.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "completed": {"type": "array", "items": {"type": "string"}},
                "in_progress": {"type": "string"},
                "blockers": {"type": "array", "items": {"type": "string"}},
                "next": {"type": "string"}
            },
            "required": ["path"]
        }
    ),

    # === Agent Tools (v0.7) ===
    Tool(
        name="spawn_explore",
        description="v0.7: 탐색 전문 에이전트.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "query": {"type": "string", "description": "탐색 질문"},
                "scope": {"type": "string", "enum": ["file", "folder", "project", "deep"]},
                "save_findings": {"type": "boolean"}
            },
            "required": ["path", "query"]
        }
    ),
    Tool(
        name="spawn_librarian",
        description="v0.7: 라이브러리언 에이전트.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "topic": {"type": "string", "description": "조사 주제"},
                "type": {"type": "string", "enum": ["library", "api", "migration", "best_practice"]},
                "depth": {"type": "string", "enum": ["quick", "standard", "thorough"]}
            },
            "required": ["path", "topic"]
        }
    ),

    # === Hook Tools (v0.8) ===
    Tool(
        name="hook_design",
        description="v0.8: 설계 훅 생성.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "trigger": {"type": "string", "enum": ["pre_code", "pre_feature", "pre_refactor", "pre_api"]},
                "checks": {"type": "array", "items": {"type": "string"}},
                "block_on_fail": {"type": "boolean"}
            },
            "required": ["path", "trigger"]
        }
    ),
    Tool(
        name="hook_verify",
        description="v0.8: 검증 훅 생성.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "trigger": {"type": "string", "enum": ["post_code", "post_feature", "pre_commit", "pre_push"]},
                "steps": {"type": "array", "items": {"type": "string"}},
                "parallel": {"type": "boolean"},
                "continue_on_error": {"type": "boolean"}
            },
            "required": ["path", "trigger"]
        }
    ),

    # === Pro: License ===
    Tool(
        name="activate_license",
        description="Clouvel Pro 라이선스 활성화.",
        inputSchema={
            "type": "object",
            "properties": {
                "license_key": {"type": "string", "description": "라이선스 키 (CLOUVEL-TIER-CODE)"}
            },
            "required": ["license_key"]
        }
    ),
    Tool(
        name="check_license",
        description="현재 라이선스 상태 확인.",
        inputSchema={"type": "object", "properties": {}}
    ),

    # === Pro: Shovel ===
    Tool(
        name="install_shovel",
        description="Pro: Shovel .claude/ 구조 자동 설치. 라이선스 필요.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "project_type": {"type": "string", "enum": ["web", "api", "desktop", "fullstack"]},
                "force": {"type": "boolean", "description": "기존 폴더 덮어쓰기"}
            },
            "required": ["path"]
        }
    ),
    Tool(
        name="sync_commands",
        description="Pro: Shovel 커맨드 동기화.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "mode": {"type": "string", "enum": ["merge", "overwrite"]}
            },
            "required": ["path"]
        }
    ),

    # === Pro: Error Learning ===
    Tool(
        name="log_error",
        description="Pro: 에러 로깅 및 자동 분류.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "error_text": {"type": "string", "description": "에러 메시지"},
                "context": {"type": "string", "description": "에러 발생 상황"},
                "source": {"type": "string", "enum": ["terminal", "log", "browser", "manual"]}
            },
            "required": ["path", "error_text"]
        }
    ),
    Tool(
        name="analyze_error",
        description="Pro: 에러 상세 분석 및 히스토리.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "error_text": {"type": "string", "description": "분석할 에러"},
                "include_history": {"type": "boolean"}
            },
            "required": ["path"]
        }
    ),
    Tool(
        name="watch_logs",
        description="Pro: 로그 파일 모니터링 설정.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "log_paths": {"type": "array", "items": {"type": "string"}},
                "patterns": {"type": "array", "items": {"type": "string"}}
            },
            "required": ["path"]
        }
    ),
    Tool(
        name="check_logs",
        description="Pro: 로그 파일 스캔.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"}
            },
            "required": ["path"]
        }
    ),
    Tool(
        name="add_prevention_rule",
        description="Pro: 에러 방지 규칙 추가.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "error_type": {"type": "string"},
                "rule": {"type": "string"},
                "scope": {"type": "string", "enum": ["project", "file", "function"]}
            },
            "required": ["path", "error_type", "rule"]
        }
    ),
    Tool(
        name="get_error_summary",
        description="Pro: 에러 요약 리포트.",
        inputSchema={
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "프로젝트 루트 경로"},
                "days": {"type": "integer"}
            },
            "required": ["path"]
        }
    ),

    # === Pro: Context Recovery ===
    Tool(
        name="recover_context",
        description="Pro: 컨텍스트 압축 후 프로젝트 상태 자동 복구. 세션 시작 시 자동 호출 권장.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string", "description": "프로젝트 경로 (기본: cwd)"},
                "depth": {
                    "type": "string",
                    "enum": ["minimal", "normal", "full"],
                    "description": "복구 깊이: minimal(current+plan), normal(+git+rules), full(+prd+recent files)"
                }
            }
        }
    ),
    Tool(
        name="setup_auto_recovery",
        description="Pro: 자동 컨텍스트 복구 설정. PreCompact + SessionStart hook 설치.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string", "description": "프로젝트 경로 (기본: cwd)"}
            }
        }
    ),
    Tool(
        name="check_auto_recovery_status",
        description="Pro: 자동 복구 설정 상태 확인.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string", "description": "프로젝트 경로 (기본: cwd)"}
            }
        }
    ),

    # === Team (Team/Enterprise 라이선스 필요) ===
    Tool(
        name="team_invite",
        description="Team: 팀원 초대. Team/Enterprise 라이선스 필요.",
        inputSchema={
            "type": "object",
            "properties": {
                "email": {"type": "string", "description": "초대할 이메일"},
                "role": {"type": "string", "enum": ["admin", "member"], "description": "역할"}
            },
            "required": ["email"]
        }
    ),
    Tool(
        name="team_members",
        description="Team: 팀원 목록 조회.",
        inputSchema={"type": "object", "properties": {}}
    ),
    Tool(
        name="team_remove",
        description="Team: 팀원 제거.",
        inputSchema={
            "type": "object",
            "properties": {
                "email": {"type": "string", "description": "제거할 이메일"}
            },
            "required": ["email"]
        }
    ),
    Tool(
        name="team_settings",
        description="Team: C-Level 역할 설정 조회.",
        inputSchema={"type": "object", "properties": {}}
    ),
    Tool(
        name="team_toggle_role",
        description="Team: C-Level 역할 활성화/비활성화.",
        inputSchema={
            "type": "object",
            "properties": {
                "cto": {"type": "boolean", "description": "CTO 모드"},
                "cdo": {"type": "boolean", "description": "CDO 모드"},
                "cpo": {"type": "boolean", "description": "CPO 모드"},
                "cfo": {"type": "boolean", "description": "CFO 모드"},
                "cmo": {"type": "boolean", "description": "CMO 모드"}
            }
        }
    ),
    Tool(
        name="sync_team_errors",
        description="Team: 로컬 에러 패턴을 팀에 동기화.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string", "description": "프로젝트 경로"}
            },
            "required": ["project_path"]
        }
    ),
    Tool(
        name="get_team_rules",
        description="Team: 팀 NEVER/ALWAYS 규칙 조회.",
        inputSchema={"type": "object", "properties": {}}
    ),
    Tool(
        name="apply_team_rules",
        description="Team: 팀 규칙을 로컬 CLAUDE.md에 적용.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string", "description": "프로젝트 경로"}
            },
            "required": ["project_path"]
        }
    ),
    Tool(
        name="sync_project_context",
        description="Team: 프로젝트 컨텍스트를 팀에 동기화.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_path": {"type": "string", "description": "프로젝트 경로"},
                "project_id": {"type": "string", "description": "프로젝트 ID (선택)"}
            },
            "required": ["project_path"]
        }
    ),
    Tool(
        name="get_project_context",
        description="Team: 팀 프로젝트 컨텍스트 조회.",
        inputSchema={
            "type": "object",
            "properties": {
                "project_id": {"type": "string", "description": "프로젝트 ID"}
            },
            "required": ["project_id"]
        }
    ),
]


@server.list_tools()
async def list_tools() -> list[Tool]:
    return TOOL_DEFINITIONS


# ============================================================
# Tool Handlers
# ============================================================

TOOL_HANDLERS = {
    # Core
    "can_code": lambda args: can_code(args.get("path", "")),
    "scan_docs": lambda args: scan_docs(args.get("path", "")),
    "analyze_docs": lambda args: analyze_docs(args.get("path", "")),
    "init_docs": lambda args: init_docs(args.get("path", ""), args.get("project_name", "")),

    # Docs
    "get_prd_template": lambda args: get_prd_template(args.get("project_name", ""), args.get("output_path", "")),
    "write_prd_section": lambda args: write_prd_section(args.get("section", ""), args.get("content", "")),
    "get_prd_guide": lambda args: get_prd_guide(),
    "get_verify_checklist": lambda args: get_verify_checklist(),
    "get_setup_guide": lambda args: get_setup_guide(args.get("platform", "all")),

    # Setup
    "init_clouvel": lambda args: init_clouvel(args.get("platform", "ask")),
    "setup_cli": lambda args: setup_cli(args.get("path", ""), args.get("level", "remind")),

    # Rules (v0.5)
    "init_rules": lambda args: init_rules(args.get("path", ""), args.get("template", "minimal")),
    "get_rule": lambda args: get_rule(args.get("path", ""), args.get("context", "coding")),
    "add_rule": lambda args: add_rule(args.get("path", ""), args.get("rule_type", "always"), args.get("content", ""), args.get("category", "general")),

    # Verify (v0.5)
    "verify": lambda args: verify(args.get("path", ""), args.get("scope", "file"), args.get("checklist", [])),
    "gate": lambda args: gate(args.get("path", ""), args.get("steps", ["lint", "test", "build"]), args.get("fix", False)),
    "handoff": lambda args: handoff(args.get("path", ""), args.get("feature", ""), args.get("decisions", ""), args.get("warnings", ""), args.get("next_steps", "")),

    # Planning (v0.6)
    "init_planning": lambda args: init_planning(args.get("path", ""), args.get("task", ""), args.get("goals", [])),
    "save_finding": lambda args: save_finding(args.get("path", ""), args.get("topic", ""), args.get("question", ""), args.get("findings", ""), args.get("source", ""), args.get("conclusion", "")),
    "refresh_goals": lambda args: refresh_goals(args.get("path", "")),
    "update_progress": lambda args: update_progress(args.get("path", ""), args.get("completed", []), args.get("in_progress", ""), args.get("blockers", []), args.get("next", "")),

    # Agents (v0.7)
    "spawn_explore": lambda args: spawn_explore(args.get("path", ""), args.get("query", ""), args.get("scope", "project"), args.get("save_findings", True)),
    "spawn_librarian": lambda args: spawn_librarian(args.get("path", ""), args.get("topic", ""), args.get("type", "library"), args.get("depth", "standard")),

    # Hooks (v0.8)
    "hook_design": lambda args: hook_design(args.get("path", ""), args.get("trigger", "pre_code"), args.get("checks", []), args.get("block_on_fail", True)),
    "hook_verify": lambda args: hook_verify(args.get("path", ""), args.get("trigger", "post_code"), args.get("steps", ["lint", "test", "build"]), args.get("parallel", False), args.get("continue_on_error", False)),

    # === Pro: License ===
    "activate_license": lambda args: activate_license(args.get("license_key", "")),
    "check_license": lambda args: _check_license(),

    # === Pro: Shovel ===
    "install_shovel": lambda args: install_shovel(
        args.get("path", ""),
        args.get("project_type", "web"),
        args.get("force", False)
    ),
    "sync_commands": lambda args: sync_commands(
        args.get("path", ""),
        args.get("mode", "merge")
    ),

    # === Pro: Error Learning ===
    "log_error": lambda args: log_error(
        args.get("path", ""),
        args.get("error_text", ""),
        args.get("context", ""),
        args.get("source", "terminal")
    ),
    "analyze_error": lambda args: analyze_error(
        args.get("path", ""),
        args.get("error_text", ""),
        args.get("include_history", True)
    ),
    "watch_logs": lambda args: watch_logs(
        args.get("path", ""),
        args.get("log_paths"),
        args.get("patterns")
    ),
    "check_logs": lambda args: check_logs(args.get("path", "")),
    "add_prevention_rule": lambda args: add_prevention_rule(
        args.get("path", ""),
        args.get("error_type", ""),
        args.get("rule", ""),
        args.get("scope", "project")
    ),
    "get_error_summary": lambda args: get_error_summary(
        args.get("path", ""),
        args.get("days", 30)
    ),

    # === Pro: Context Recovery ===
    "recover_context": lambda args: recover_context(
        args.get("project_path"),
        args.get("depth", "normal")
    ),
    "setup_auto_recovery": lambda args: setup_auto_recovery(
        args.get("project_path")
    ),
    "check_auto_recovery_status": lambda args: check_auto_recovery_status(
        args.get("project_path")
    ),

    # === Team (Team/Enterprise only) ===
    "team_invite": lambda args: team_invite(
        args.get("email", ""),
        args.get("role", "member")
    ),
    "team_members": lambda args: team_members(),
    "team_remove": lambda args: team_remove(args.get("email", "")),
    "team_settings": lambda args: team_settings(),
    "team_toggle_role": lambda args: team_toggle_role(
        args.get("cto"),
        args.get("cdo"),
        args.get("cpo"),
        args.get("cfo"),
        args.get("cmo")
    ),
    "sync_team_errors": lambda args: sync_team_errors(args.get("project_path", "")),
    "get_team_rules": lambda args: get_team_rules(),
    "apply_team_rules": lambda args: apply_team_rules(args.get("project_path", "")),
    "sync_project_context": lambda args: sync_project_context(
        args.get("project_path", ""),
        args.get("project_id")
    ),
    "get_project_context": lambda args: get_project_context(args.get("project_id", "")),
}


async def _check_license() -> list[TextContent]:
    """라이선스 상태 확인"""
    result = verify_license()

    if result["valid"]:
        tier = result["tier_info"]
        age_days = get_license_age_days()
        remaining = PREMIUM_UNLOCK_DAYS - age_days
        premium_unlocked = remaining <= 0

        # Team/Enterprise tier check
        tier_name = tier.get("name", "").lower()
        is_team_tier = "team" in tier_name or "enterprise" in tier_name

        team_features = ""
        if is_team_tier:
            team_features = """

## Team 전용 기능
- `team_invite` - 팀원 초대
- `team_members` - 팀원 목록
- `team_remove` - 팀원 제거
- `team_settings` - C-Level 설정 조회
- `team_toggle_role` - CTO/CDO/CPO/CFO/CMO 모드 토글
- `sync_team_errors` - 에러 패턴 팀 동기화
- `get_team_rules` - 팀 NEVER/ALWAYS 규칙
- `apply_team_rules` - 팀 규칙 로컬 적용
- `sync_project_context` - 프로젝트 컨텍스트 동기화
- `get_project_context` - 프로젝트 컨텍스트 조회"""

        if premium_unlocked:
            lock_status = "🔓 **프리미엄 잠금 해제됨**"
            available_features = f"""
## 사용 가능한 기능 (전체)
- `install_shovel` - Shovel 설치
- `sync_commands` - 커맨드 동기화
- `log_error` - 에러 기록
- `analyze_error` - 에러 분석
- `watch_logs` - 로그 감시
- `check_logs` - 로그 체크
- `add_prevention_rule` - 방지 규칙
- `get_error_summary` - 에러 요약
- `recover_context` - 컨텍스트 복구
- `setup_auto_recovery` - 자동 복구 설정{team_features}"""
        else:
            lock_status = f"⏳ **프리미엄 잠금 중** ({remaining}일 남음)"
            available_features = f"""
## 지금 사용 가능한 기능
- `watch_logs` - 로그 감시 설정
- `check_logs` - 로그 체크{team_features}

## {remaining}일 후 사용 가능 (프리미엄)
- `install_shovel` - Shovel 설치
- `sync_commands` - 커맨드 동기화
- `log_error` - 에러 기록
- `analyze_error` - 에러 분석
- `add_prevention_rule` - 방지 규칙
- `get_error_summary` - 에러 요약
- `recover_context` - 컨텍스트 복구
- `setup_auto_recovery` - 자동 복구 설정"""

        return [TextContent(type="text", text=f"""
# ✅ 라이선스 활성화됨

- **티어**: {tier['name']}
- **인원**: {tier['seats'] if tier['seats'] > 0 else '무제한'}명
- **활성화 경과**: {age_days}일
- {lock_status}
{available_features}
""")]

    return [TextContent(type="text", text=f"""
# ❌ 라이선스 없음

{result['message']}

## Pro 기능 구매

https://whitening-sinabro.github.io/clouvel/

라이선스 키를 받으시면 `activate_license` 도구로 활성화하세요.
""")]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    # Analytics 기록
    project_path = arguments.get("path", None)
    if name != "get_analytics":
        try:
            log_tool_call(name, success=True, project_path=project_path)
        except Exception:
            pass

    # get_analytics 특별 처리
    if name == "get_analytics":
        return await _get_analytics(arguments.get("path", None), arguments.get("days", 30))

    # 핸들러 실행
    handler = TOOL_HANDLERS.get(name)
    if handler:
        return await handler(arguments)

    return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def _get_analytics(path: str, days: int) -> list[TextContent]:
    """도구 사용량 통계"""
    stats = get_stats(days=days, project_path=path)
    return [TextContent(type="text", text=format_stats(stats))]


# ============================================================
# Server Entry Points
# ============================================================

async def run_server():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def _run_setup(global_only: bool = False) -> str:
    """B0: clouvel setup - 강제 호출 메커니즘 설치"""
    import subprocess
    import os
    from pathlib import Path

    results = []

    # 1. 글로벌 CLAUDE.md에 규칙 추가
    if os.name == 'nt':  # Windows
        claude_dir = Path.home() / ".claude"
    else:  # Mac/Linux
        claude_dir = Path.home() / ".claude"

    claude_dir.mkdir(parents=True, exist_ok=True)
    claude_md_path = claude_dir / "CLAUDE.md"

    clouvel_rule = """
## Clouvel 규칙 (자동 생성)

**코드 작성 전 반드시 clouvel의 `can_code` 도구 호출 필수.**

- 코드를 작성(Edit/Write)하기 전에 항상 `can_code` 도구를 먼저 호출하세요
- path 인자로 프로젝트의 docs 폴더 경로를 전달하세요
- BLOCK이 뜨면 코드 작성 금지, 사용자에게 문서 작성 안내
- PASS가 뜨면 코딩 진행 가능
- WARN은 권장 사항, 진행 가능하지만 권장 문서 추가 안내

"""

    marker = "## Clouvel 규칙"

    if claude_md_path.exists():
        content = claude_md_path.read_text(encoding='utf-8')
        if marker in content:
            results.append("[OK] 글로벌 CLAUDE.md: 이미 Clouvel 규칙 있음")
        else:
            # 기존 내용 끝에 추가
            new_content = content.rstrip() + "\n\n---\n" + clouvel_rule
            claude_md_path.write_text(new_content, encoding='utf-8')
            results.append(f"[OK] 글로벌 CLAUDE.md: 규칙 추가됨 ({claude_md_path})")
    else:
        # 새로 생성
        initial_content = f"# Claude Code 글로벌 설정\n\n> 자동 생성됨 by clouvel setup\n\n---\n{clouvel_rule}"
        claude_md_path.write_text(initial_content, encoding='utf-8')
        results.append(f"[OK] 글로벌 CLAUDE.md: 생성됨 ({claude_md_path})")

    # 2. MCP 서버 등록 (global_only가 아닐 때만)
    if not global_only:
        try:
            # 먼저 기존 등록 확인
            check_result = subprocess.run(
                ["claude", "mcp", "list"],
                capture_output=True,
                text=True,
                timeout=10
            )

            if "clouvel" in check_result.stdout:
                results.append("[OK] MCP 서버: 이미 등록됨")
            else:
                # 등록
                add_result = subprocess.run(
                    ["claude", "mcp", "add", "clouvel", "-s", "user", "--", "clouvel"],
                    capture_output=True,
                    text=True,
                    timeout=30
                )

                if add_result.returncode == 0:
                    results.append("[OK] MCP 서버: 등록 완료")
                else:
                    results.append(f"[WARN] MCP 서버: 등록 실패 - {add_result.stderr.strip()}")
                    results.append("   수동 등록: claude mcp add clouvel -s user -- clouvel")
        except FileNotFoundError:
            results.append("[WARN] MCP 서버: claude 명령어 없음")
            results.append("   Claude Code 설치 후 다시 실행하세요")
        except subprocess.TimeoutExpired:
            results.append("[WARN] MCP 서버: 타임아웃")
            results.append("   수동 등록: claude mcp add clouvel -s user -- clouvel")
        except Exception as e:
            results.append(f"[WARN] MCP 서버: 오류 - {str(e)}")
            results.append("   수동 등록: claude mcp add clouvel -s user -- clouvel")

    # 결과 출력
    output = """
================================================================
                    Clouvel Setup 완료
================================================================

"""
    output += "\n".join(results)
    output += """

----------------------------------------------------------------

## 작동 방식

1. Claude Code 실행
2. "로그인 기능 만들어줘" 요청
3. Claude가 자동으로 can_code 먼저 호출
4. PRD 없으면 → [BLOCK] BLOCK (코딩 금지)
5. PRD 있으면 → [OK] PASS (코딩 진행)

## 테스트

```bash
# PRD 없는 폴더에서 테스트
mkdir test-project && cd test-project
claude
> "코드 짜줘"
# → BLOCK 메시지 확인
```

----------------------------------------------------------------
"""

    return output


def main():
    import sys
    import asyncio
    import argparse
    from pathlib import Path

    parser = argparse.ArgumentParser(description="Clouvel - 바이브코딩 프로세스 강제 도구")
    subparsers = parser.add_subparsers(dest="command")

    # init 명령
    init_parser = subparsers.add_parser("init", help="프로젝트 초기화")
    init_parser.add_argument("-p", "--path", default=".", help="프로젝트 경로")
    init_parser.add_argument("-l", "--level", choices=["remind", "strict", "full"], default="strict")

    # setup 명령 (B0)
    setup_parser = subparsers.add_parser("setup", help="Clouvel 강제 호출 메커니즘 설치 (글로벌)")
    setup_parser.add_argument("--global-only", action="store_true", help="CLAUDE.md만 설정 (MCP 등록 제외)")

    args = parser.parse_args()

    if args.command == "init":
        from .tools.setup import setup_cli as sync_setup
        import asyncio
        result = asyncio.run(sync_setup(args.path, args.level))
        print(result[0].text)
    elif args.command == "setup":
        result = _run_setup(global_only=args.global_only if hasattr(args, 'global_only') else False)
        print(result)
    else:
        asyncio.run(run_server())


if __name__ == "__main__":
    main()
