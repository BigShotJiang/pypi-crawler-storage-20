# Clouvel Tools Package
# 모듈별로 도구 구현을 분리
# v1.0: Free + Pro 통합

from .core import (
    can_code,
    scan_docs,
    analyze_docs,
    init_docs,
    REQUIRED_DOCS,
)

from .docs import (
    get_prd_template,
    write_prd_section,
    get_prd_guide,
    get_verify_checklist,
    get_setup_guide,
)

from .setup import (
    init_clouvel,
    setup_cli,
)

from .rules import (
    init_rules,
    get_rule,
    add_rule,
)

from .verify import (
    verify,
    gate,
    handoff,
)

from .planning import (
    init_planning,
    save_finding,
    refresh_goals,
    update_progress,
)

from .agents import (
    spawn_explore,
    spawn_librarian,
)

from .hooks import (
    hook_design,
    hook_verify,
    # Auto Recovery (Pro)
    setup_auto_recovery,
    check_auto_recovery_status,
)

# === Pro 기능 (라이선스 필요) ===
from .shovel import (
    install_shovel,
    sync_commands,
)

from .errors import (
    log_error,
    analyze_error,
    watch_logs,
    check_logs,
    add_prevention_rule,
    get_error_summary,
)

from .context import (
    recover_context,
)

from .team import (
    team_invite,
    team_members,
    team_remove,
    team_settings,
    team_toggle_role,
    sync_team_errors,
    get_team_rules,
    apply_team_rules,
    sync_project_context,
    get_project_context,
)


__all__ = [
    # core
    "can_code", "scan_docs", "analyze_docs", "init_docs", "REQUIRED_DOCS",
    # docs
    "get_prd_template", "write_prd_section", "get_prd_guide", "get_verify_checklist", "get_setup_guide",
    # setup
    "init_clouvel", "setup_cli",
    # rules (v0.5)
    "init_rules", "get_rule", "add_rule",
    # verify (v0.5)
    "verify", "gate", "handoff",
    # planning (v0.6)
    "init_planning", "save_finding", "refresh_goals", "update_progress",
    # agents (v0.7)
    "spawn_explore", "spawn_librarian",
    # hooks (v0.8)
    "hook_design", "hook_verify",
    # === Pro (라이선스 필요) ===
    # shovel
    "install_shovel", "sync_commands",
    # errors
    "log_error", "analyze_error", "watch_logs", "check_logs", "add_prevention_rule", "get_error_summary",
    # context
    "recover_context", "setup_auto_recovery", "check_auto_recovery_status",
    # team
    "team_invite", "team_members", "team_remove", "team_settings", "team_toggle_role",
    "sync_team_errors", "get_team_rules", "apply_team_rules", "sync_project_context", "get_project_context",
]
