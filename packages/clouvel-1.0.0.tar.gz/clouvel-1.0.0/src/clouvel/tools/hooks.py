# -*- coding: utf-8 -*-
"""Hook tools (v0.8): hook_design, hook_verify + Auto Recovery (Pro)"""

import json
from pathlib import Path
from datetime import datetime
from mcp.types import TextContent

from ..license import require_license


async def hook_design(path: str, trigger: str, checks: list, block_on_fail: bool) -> list[TextContent]:
    """설계 훅 - 코드 작성 전 자동 체크포인트"""
    project_path = Path(path)

    if not project_path.exists():
        return [TextContent(type="text", text=f"❌ 경로가 존재하지 않습니다: {path}")]

    # 트리거별 기본 체크 항목
    default_checks = {
        "pre_code": ["prd_exists", "architecture_review", "scope_defined"],
        "pre_feature": ["feature_in_prd", "api_spec_exists", "db_schema_ready"],
        "pre_refactor": ["test_coverage", "backup_exists", "rollback_plan"],
        "pre_api": ["api_spec_complete", "auth_defined", "error_codes_listed"]
    }

    # 체크 항목 설정 (사용자 지정 또는 기본값)
    active_checks = checks if checks else default_checks.get(trigger, [])

    # 훅 설정 파일 생성
    hooks_dir = project_path / ".claude" / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)

    hook_config = {
        "name": f"design_{trigger}",
        "trigger": trigger,
        "checks": active_checks,
        "block_on_fail": block_on_fail,
        "created": datetime.now().isoformat()
    }

    hook_file = hooks_dir / f"{trigger}.json"
    hook_file.write_text(json.dumps(hook_config, indent=2, ensure_ascii=False), encoding='utf-8')

    # 체크리스트 생성
    checklist_md = "\n".join(f"- [ ] {check}" for check in active_checks)

    return [TextContent(type="text", text=f"""# 설계 훅 생성 완료

## 훅 설정

| 항목 | 값 |
|------|-----|
| 트리거 | `{trigger}` |
| 실패 시 차단 | {'예' if block_on_fail else '아니오'} |
| 체크 항목 | {len(active_checks)}개 |

## 체크리스트

{checklist_md}

## 저장 위치

`{hook_file}`

---

## 사용법

이 훅은 **{trigger}** 시점에 자동 트리거됩니다.

```
# 훅 실행 예시
Claude가 코드 작성 전:
1. can_code 확인
2. {trigger} 훅 체크리스트 확인
3. 모든 체크 통과 시 진행
```

**{'체크 실패 시 코드 작성이 차단됩니다.' if block_on_fail else '체크 실패해도 경고만 출력합니다.'}**
""")]


async def hook_verify(path: str, trigger: str, steps: list, parallel: bool, continue_on_error: bool) -> list[TextContent]:
    """검증 훅 - 코드 완료 후 자동 검증 체크포인트"""
    project_path = Path(path)

    if not project_path.exists():
        return [TextContent(type="text", text=f"❌ 경로가 존재하지 않습니다: {path}")]

    # 트리거별 기본 단계
    default_steps = {
        "post_code": ["lint", "type_check"],
        "post_feature": ["lint", "test", "build"],
        "pre_commit": ["lint", "test", "security_scan"],
        "pre_push": ["lint", "test", "build", "integration_test"]
    }

    # 단계 설정 (사용자 지정 또는 기본값)
    active_steps = steps if steps else default_steps.get(trigger, ["lint", "test", "build"])

    # 단계별 명령어 매핑
    step_commands = {
        "lint": {"cmd": "npm run lint || pylint . || ruff check .", "desc": "코드 스타일 검사"},
        "type_check": {"cmd": "tsc --noEmit || mypy .", "desc": "타입 검사"},
        "test": {"cmd": "npm test || pytest || go test ./...", "desc": "테스트 실행"},
        "build": {"cmd": "npm run build || python -m build || go build", "desc": "빌드"},
        "security_scan": {"cmd": "npm audit || safety check || gosec ./...", "desc": "보안 스캔"},
        "integration_test": {"cmd": "npm run test:e2e || pytest tests/e2e", "desc": "통합 테스트"}
    }

    # 훅 설정 파일 생성
    hooks_dir = project_path / ".claude" / "hooks"
    hooks_dir.mkdir(parents=True, exist_ok=True)

    hook_config = {
        "name": f"verify_{trigger}",
        "trigger": trigger,
        "steps": active_steps,
        "parallel": parallel,
        "continue_on_error": continue_on_error,
        "created": datetime.now().isoformat()
    }

    hook_file = hooks_dir / f"{trigger}.json"
    hook_file.write_text(json.dumps(hook_config, indent=2, ensure_ascii=False), encoding='utf-8')

    # 단계 목록 생성
    steps_md = ""
    for i, step in enumerate(active_steps, 1):
        info = step_commands.get(step, {"cmd": step, "desc": "사용자 정의"})
        steps_md += f"{i}. **{step}**: {info['desc']}\n   ```\n   {info['cmd']}\n   ```\n\n"

    execution_mode = "병렬 (동시 실행)" if parallel else "순차 (하나씩 실행)"
    error_handling = "계속 진행" if continue_on_error else "즉시 중단"

    return [TextContent(type="text", text=f"""# 검증 훅 생성 완료

## 훅 설정

| 항목 | 값 |
|------|-----|
| 트리거 | `{trigger}` |
| 실행 모드 | {execution_mode} |
| 에러 처리 | {error_handling} |
| 단계 수 | {len(active_steps)}개 |

## 검증 단계

{steps_md}

## 저장 위치

`{hook_file}`

---

## 실행 흐름

```
{trigger} 트리거 발생
    |
    v
{'병렬 실행' if parallel else '순차 실행'}
{' -> '.join(active_steps)}
    |
    v
결과 리포트 생성
```

**트리거 시점: {trigger}**
""")]


# ============================================================
# Auto Recovery Hooks (Pro)
# ============================================================

# Hook 스크립트 내용 (임베디드)
SAVE_STATE_SCRIPT = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PreCompact Hook: 컨텍스트 압축 전 상태 저장"""

import json
import sys
import os
from pathlib import Path
from datetime import datetime

# Windows UTF-8 설정
if sys.platform == "win32":
    sys.stdin.reconfigure(encoding='utf-8')

def main():
    try:
        input_data = json.load(sys.stdin)
    except json.JSONDecodeError:
        sys.exit(1)

    project_dir = os.environ.get("CLAUDE_PROJECT_DIR", ".")
    project_path = Path(project_dir)

    # 상태 수집
    state = {
        "timestamp": datetime.now().isoformat(),
        "trigger": input_data.get("trigger", "unknown"),
        "session_id": input_data.get("session_id", "")
    }

    # current.md 읽기
    current_md = project_path / ".claude" / "status" / "current.md"
    if current_md.exists():
        try:
            state["current_md"] = current_md.read_text(encoding="utf-8")[:3000]
        except:
            pass

    # 활성 PLAN 찾기
    plans_dir = project_path / ".claude" / "plans"
    if plans_dir.exists():
        for f in plans_dir.glob("PLAN-*.md"):
            try:
                content = f.read_text(encoding="utf-8")
                if "LOCKED" in content or "IN_PROGRESS" in content or "진행 중" in content:
                    state["active_plan"] = f.name
                    state["plan_content"] = content[:2000]
                    break
            except:
                continue

    # CLAUDE.md 핵심 규칙
    claude_md = project_path / "CLAUDE.md"
    if claude_md.exists():
        try:
            content = claude_md.read_text(encoding="utf-8")
            # NEVER/ALWAYS 추출
            import re
            rules = []
            for match in re.findall(r"NEVER[:\\s]+([^\\n]+)", content, re.IGNORECASE)[:5]:
                rules.append(f"NEVER: {match.strip()}")
            for match in re.findall(r"ALWAYS[:\\s]+([^\\n]+)", content, re.IGNORECASE)[:5]:
                rules.append(f"ALWAYS: {match.strip()}")
            if rules:
                state["rules"] = rules
        except:
            pass

    # Git 브랜치
    git_head = project_path / ".git" / "HEAD"
    if git_head.exists():
        try:
            head_content = git_head.read_text(encoding="utf-8").strip()
            if head_content.startswith("ref: refs/heads/"):
                state["git_branch"] = head_content.replace("ref: refs/heads/", "")
        except:
            pass

    # 저장
    state_dir = project_path / ".claude" / "status"
    state_dir.mkdir(parents=True, exist_ok=True)
    state_file = state_dir / "session-state.json"

    try:
        state_file.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    except:
        pass

    sys.exit(0)

if __name__ == "__main__":
    main()
'''

RECOVER_CONTEXT_SCRIPT = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SessionStart Hook: 컨텍스트 압축 후 자동 복구"""

import json
import sys
import os
from pathlib import Path

# Windows UTF-8 stdout 설정
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stdin.reconfigure(encoding='utf-8')

def main():
    try:
        input_data = json.load(sys.stdin)
    except json.JSONDecodeError:
        # 입력 없으면 빈 컨텍스트
        output = {"hookSpecificOutput": {"hookEventName": "SessionStart", "additionalContext": ""}}
        print(json.dumps(output))
        sys.exit(0)

    source = input_data.get("source", "startup")
    project_dir = os.environ.get("CLAUDE_PROJECT_DIR", ".")
    project_path = Path(project_dir)

    # startup이면 복구 불필요 (새 세션)
    if source == "startup":
        output = {"hookSpecificOutput": {"hookEventName": "SessionStart", "additionalContext": ""}}
        print(json.dumps(output))
        sys.exit(0)

    # compact, resume일 때만 복구
    state_file = project_path / ".claude" / "status" / "session-state.json"

    if not state_file.exists():
        output = {"hookSpecificOutput": {"hookEventName": "SessionStart", "additionalContext": ""}}
        print(json.dumps(output))
        sys.exit(0)

    try:
        state = json.loads(state_file.read_text(encoding="utf-8"))
    except:
        output = {"hookSpecificOutput": {"hookEventName": "SessionStart", "additionalContext": ""}}
        print(json.dumps(output))
        sys.exit(0)

    # 복구 컨텍스트 생성
    parts = []
    parts.append("# Context Recovery (Auto-injected)")
    parts.append("")
    parts.append(f"> **Source**: {source}")
    parts.append(f"> **Saved at**: {state.get('timestamp', 'unknown')}")

    if state.get("git_branch"):
        parts.append(f"> **Branch**: {state['git_branch']}")

    # 활성 계획
    if state.get("active_plan"):
        parts.append("")
        parts.append(f"## Active Plan: {state['active_plan']}")
        parts.append("")
        parts.append("```markdown")
        # 처음 50줄만
        plan_lines = state.get("plan_content", "").split("\\n")[:50]
        parts.append("\\n".join(plan_lines))
        parts.append("```")

    # 현재 상태 요약
    if state.get("current_md"):
        parts.append("")
        parts.append("## Current Status (from current.md)")
        parts.append("")
        # 처음 40줄만
        current_lines = state["current_md"].split("\\n")[:40]
        parts.append("\\n".join(current_lines))

    # 핵심 규칙
    if state.get("rules"):
        parts.append("")
        parts.append("## Key Rules")
        for rule in state["rules"]:
            parts.append(f"- {rule}")

    parts.append("")
    parts.append("---")
    parts.append("**Continue where you left off.**")

    context = "\\n".join(parts)

    output = {
        "hookSpecificOutput": {
            "hookEventName": "SessionStart",
            "additionalContext": context
        }
    }

    print(json.dumps(output, ensure_ascii=False))
    sys.exit(0)

if __name__ == "__main__":
    main()
'''

# Hook 설정 템플릿
HOOKS_SETTINGS = {
    "PreCompact": [
        {
            "hooks": [
                {
                    "type": "command",
                    "command": "python \"$CLAUDE_PROJECT_DIR/.claude/hooks/save-state.py\"",
                    "timeout": 10
                }
            ]
        }
    ],
    "SessionStart": [
        {
            "hooks": [
                {
                    "type": "command",
                    "command": "python \"$CLAUDE_PROJECT_DIR/.claude/hooks/recover-context.py\"",
                    "timeout": 10
                }
            ]
        }
    ]
}


@require_license
async def setup_auto_recovery(
    project_path: str = None
) -> list[TextContent]:
    """
    자동 컨텍스트 복구 설정.

    PreCompact + SessionStart hook을 설치하여:
    - 컨텍스트 압축 전 상태 자동 저장
    - 압축 후 세션 시작 시 자동 복구 + 주입

    Args:
        project_path: 프로젝트 경로 (기본: 현재 디렉토리)
    """
    # 경로 설정
    if project_path:
        path = Path(project_path)
    else:
        path = Path.cwd()

    if not path.exists():
        return [TextContent(type="text", text=f"# Error\n\nProject path not found: `{path}`")]

    claude_dir = path / ".claude"
    hooks_dir = claude_dir / "hooks"
    status_dir = claude_dir / "status"

    # 디렉토리 생성
    hooks_dir.mkdir(parents=True, exist_ok=True)
    status_dir.mkdir(parents=True, exist_ok=True)

    # Hook 스크립트 설치
    save_state_path = hooks_dir / "save-state.py"
    recover_context_path = hooks_dir / "recover-context.py"

    save_state_path.write_text(SAVE_STATE_SCRIPT, encoding="utf-8")
    recover_context_path.write_text(RECOVER_CONTEXT_SCRIPT, encoding="utf-8")

    # settings.json 업데이트
    settings_path = claude_dir / "settings.json"

    settings = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
        except:
            settings = {}

    # hooks 섹션 병합
    if "hooks" not in settings:
        settings["hooks"] = {}

    settings["hooks"]["PreCompact"] = HOOKS_SETTINGS["PreCompact"]
    settings["hooks"]["SessionStart"] = HOOKS_SETTINGS["SessionStart"]

    settings_path.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")

    return [TextContent(type="text", text=f"""
# Auto Recovery Setup Complete

## Installed Files

| File | Purpose |
|------|---------|
| `.claude/hooks/save-state.py` | PreCompact: Save state before compaction |
| `.claude/hooks/recover-context.py` | SessionStart: Restore state after compaction |
| `.claude/settings.json` | Hook configuration |

## How It Works

```
Context Compaction Triggered
        │
        ▼
┌─────────────────────────────┐
│ PreCompact Hook             │
│ → Save current.md           │
│ → Save active PLAN          │
│ → Save git branch           │
│ → Save key rules            │
└─────────────────────────────┘
        │
        ▼
   [Compaction]
        │
        ▼
┌─────────────────────────────┐
│ SessionStart Hook           │
│ (source: "compact")         │
│ → Read saved state          │
│ → Inject as additionalContext│
│ → Claude knows the context  │
└─────────────────────────────┘
        │
        ▼
Claude continues seamlessly
```

## Saved State Location

`{status_dir / "session-state.json"}`

## Verification

The next time context compaction happens:
1. State will be saved automatically
2. Context will be restored automatically
3. No user intervention needed

**This is the core paid feature of Clouvel Pro.**
""")]


async def check_auto_recovery_status(
    project_path: str = None
) -> list[TextContent]:
    """자동 복구 설정 상태 확인"""
    if project_path:
        path = Path(project_path)
    else:
        path = Path.cwd()

    claude_dir = path / ".claude"
    hooks_dir = claude_dir / "hooks"
    settings_path = claude_dir / "settings.json"
    state_path = claude_dir / "status" / "session-state.json"

    results = []
    results.append("# Auto Recovery Status\n")

    # Hook 스크립트 확인
    save_state = hooks_dir / "save-state.py"
    recover_context = hooks_dir / "recover-context.py"

    results.append("## Hook Scripts")
    results.append(f"- `save-state.py`: {'Installed' if save_state.exists() else 'Missing'}")
    results.append(f"- `recover-context.py`: {'Installed' if recover_context.exists() else 'Missing'}")

    # 설정 확인
    results.append("\n## Settings")
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
            hooks = settings.get("hooks", {})

            pre_compact = "PreCompact" in hooks
            session_start = "SessionStart" in hooks

            results.append(f"- PreCompact hook: {'Configured' if pre_compact else 'Not configured'}")
            results.append(f"- SessionStart hook: {'Configured' if session_start else 'Not configured'}")
        except:
            results.append("- Error reading settings.json")
    else:
        results.append("- settings.json not found")

    # 저장된 상태 확인
    results.append("\n## Last Saved State")
    if state_path.exists():
        try:
            state = json.loads(state_path.read_text(encoding="utf-8"))
            results.append(f"- Timestamp: {state.get('timestamp', 'unknown')}")
            results.append(f"- Trigger: {state.get('trigger', 'unknown')}")
            results.append(f"- Active Plan: {state.get('active_plan', 'None')}")
            results.append(f"- Git Branch: {state.get('git_branch', 'unknown')}")
        except:
            results.append("- Error reading state file")
    else:
        results.append("- No saved state yet (will be created on first compaction)")

    # 전체 상태
    all_good = (
        save_state.exists() and
        recover_context.exists() and
        settings_path.exists()
    )

    results.append("\n## Overall")
    if all_good:
        results.append("**Status: READY**")
        results.append("\nAuto recovery is properly configured.")
    else:
        results.append("**Status: NOT CONFIGURED**")
        results.append("\nRun `setup_auto_recovery` to enable auto recovery.")

    return [TextContent(type="text", text="\n".join(results))]
