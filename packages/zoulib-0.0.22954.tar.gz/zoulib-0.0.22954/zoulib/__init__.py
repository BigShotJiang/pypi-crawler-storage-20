__version__ = "0.0.2295"
from .yttik import getlink
