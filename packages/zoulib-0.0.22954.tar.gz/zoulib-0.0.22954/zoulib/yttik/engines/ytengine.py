import os
import shutil
import yt_dlp
from zoulib.yttik.engines.base import BaseEngine
from zoulib.yttik.exceptions import RuntimeMissingError, DownloadFailedError

class YTDLPEngine(BaseEngine):
    def __init__(self, url: str):
        self.url = url
        self.info = None
        self._check_runtime()
        self.download_dir = os.path.join(os.path.expanduser("~"), "Downloads", "yttik")
        os.makedirs(self.download_dir, exist_ok=True)

    def _check_runtime(self):
        if not shutil.which("node"):
            raise RuntimeMissingError("Node.js is required for YouTube downloads.")
        if not shutil.which("ffmpeg"):
            print("⚠ ffmpeg не найден, звук может быть некорректен. Установите ffmpeg: https://ffmpeg.org/")

    def get_info(self):
        with yt_dlp.YoutubeDL({"quiet": True, "skip_download": True}) as ydl:
            self.info = ydl.extract_info(self.url, download=False)
        formats = self.info.get("formats", [])
        resolutions = sorted(
            set(
                f.get("format_note") if f.get("format_note") else (str(f.get("height")) + "p" if f.get("height") else None)
                for f in formats
                if f.get("ext") == "mp4"
            ),
            key=lambda x: int(x.replace("p", "")) if x else 0
        )
        return {
            "title": self.info.get("title"),
            "author": self.info.get("uploader"),
            "duration": self.info.get("duration"),
            "resolutions": resolutions
        }

    def download(self):
        if not self.info:
            self.get_info()
        options = {
            "outtmpl": os.path.join(self.download_dir, "%(title)s.%(ext)s"),
            "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best",
            "merge_output_format": "mp4",
            "noplaylist": True,
            "quiet": False
        }
        with yt_dlp.YoutubeDL(options) as ydl:
            try:
                ydl.download([self.url])
            except yt_dlp.utils.DownloadError as e:
                raise DownloadFailedError("Видео недоступно или ошибка при скачивании.") from e
            except Exception as e:
                raise DownloadFailedError(f"Неизвестная ошибка: {e}") from e
