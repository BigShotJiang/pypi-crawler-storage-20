from .api import getlink
