_program = "snipit"
__version__ = "1.7"
