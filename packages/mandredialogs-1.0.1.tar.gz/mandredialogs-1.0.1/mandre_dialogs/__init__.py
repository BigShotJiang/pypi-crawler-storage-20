
from java import dynamic_proxy, jint
from android.widget import LinearLayout, TextView, ScrollView, FrameLayout
from android.view import Gravity, View
from android.text import InputType
from android.graphics.drawable import GradientDrawable, ColorDrawable
from android.util import TypedValue
from org.telegram.ui.ActionBar import AlertDialog, Theme
from org.telegram.messenger import AndroidUtilities

# Импорт утилит MandreLib
try:
    from client_utils import get_last_fragment
    from android_utils import run_on_ui_thread, log, OnClickListener
    from hook_utils import find_class
except ImportError:
    def get_last_fragment(): return None
    def run_on_ui_thread(f): f()
    def log(t): print(t)
    def find_class(n): return None
    OnClickListener = None

# --- ВНУТРЕННИЕ УТИЛИТЫ ---

def _dp(val):
    return AndroidUtilities.dp(val)

def _get_color(key):
    return Theme.getColor(key)

def _create_md3_background(context):
    """Создает фон в стиле Material You (Surface Container High)"""
    bg = GradientDrawable()
    bg.setCornerRadius(_dp(28))
    # Цвет фона диалога (обычно чуть светлее/темнее основного фона)
    bg.setColor(_get_color(Theme.key_dialogBackground))
    return bg

def _create_button(context, text, color_key, on_click, dialog_ref):
    """Создает текстовую кнопку MD3"""
    btn_frame = FrameLayout(context)
    
    # Фон при нажатии (Ripple)
    btn_frame.setBackground(Theme.createSimpleSelectorRoundRectDrawable(
        _dp(20), 0, _get_color(Theme.key_listSelector)
    ))
    
    tv = TextView(context)
    tv.setText(text)
    tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14)
    tv.setTypeface(AndroidUtilities.bold())
    tv.setTextColor(_get_color(color_key))
    tv.setGravity(Gravity.CENTER)
    tv.setPadding(_dp(12), _dp(10), _dp(12), _dp(10))
    
    btn_frame.addView(tv, -2, -2)
    btn_frame.setPadding(_dp(4), 0, _dp(4), 0)
    
    def wrapper(v):
        if dialog_ref[0]: dialog_ref[0].dismiss()
        if on_click: on_click()
        
    btn_frame.setOnClickListener(OnClickListener(wrapper))
    return btn_frame

class MandreDialogs:
    """
    Библиотека для создания диалогов с кастомной версткой под MD3.
    """

    @staticmethod
    def _base_builder(context, title, message, custom_view=None):
        """Строит корневой Layout диалога"""
        root = LinearLayout(context)
        root.setOrientation(1)
        root.setBackground(_create_md3_background(context))
        root.setPadding(_dp(24), _dp(24), _dp(24), _dp(24))
        
        # Заголовок
        if title:
            tv_title = TextView(context)
            tv_title.setText(title)
            tv_title.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 24)
            tv_title.setTextColor(_get_color(Theme.key_dialogTextBlack))
            # Icon symbol font support? No, assume bold text
            # tv_title.setTypeface(AndroidUtilities.bold()) 
            root.addView(tv_title)
            
            # Отступ после заголовка
            margin_view = View(context)
            root.addView(margin_view, -1, _dp(16))

        # Контент (Сообщение или кастом)
        if message:
            scroll = ScrollView(context)
            tv_msg = TextView(context)
            tv_msg.setText(message)
            tv_msg.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14)
            tv_msg.setTextColor(_get_color(Theme.key_dialogTextGray2))
            tv_msg.setLineSpacing(_dp(2), 1.0)
            scroll.addView(tv_msg)
            root.addView(scroll, -1, -2) # Wrap content height
            
        if custom_view:
            root.addView(custom_view, -1, -2)

        # Отступ перед кнопками
        spacer = View(context)
        root.addView(spacer, -1, _dp(24))

        return root

    @staticmethod
    def alert(title: str, message: str, button_text: str = "OK", on_click=None):
        def _show():
            frag = get_last_fragment()
            if not frag: return
            ctx = frag.getContext()

            # Ссылка на диалог для закрытия из кнопки
            dialog_ref = [None] 

            # Строим UI
            root = MandreDialogs._base_builder(ctx, title, message)
            
            # Кнопки (справа)
            buttons = LinearLayout(ctx)
            buttons.setGravity(Gravity.RIGHT)
            
            btn = _create_button(ctx, button_text, Theme.key_dialogTextLink, on_click, dialog_ref)
            buttons.addView(btn)
            
            root.addView(buttons, -1, -2)

            # Создаем и показываем
            builder = AlertDialog.Builder(ctx)
            builder.setView(root)
            dialog = builder.create()
            
            # Убираем стандартный фон AlertDialog, чтобы было видно наши скругления
            dialog.getWindow().setBackgroundDrawable(ColorDrawable(0))
            
            dialog_ref[0] = dialog
            dialog.show()

        run_on_ui_thread(_show)

    @staticmethod
    def confirm(title: str, message: str, 
                positive_text: str = "Да", negative_text: str = "Нет", 
                on_positive=None, on_negative=None):
        def _show():
            frag = get_last_fragment()
            if not frag: return
            ctx = frag.getContext()
            dialog_ref = [None]

            root = MandreDialogs._base_builder(ctx, title, message)
            
            buttons = LinearLayout(ctx)
            buttons.setGravity(Gravity.RIGHT)
            
            # Кнопка отмены (серая или красная?)
            btn_neg = _create_button(ctx, negative_text, Theme.key_dialogTextRed, on_negative, dialog_ref)
            buttons.addView(btn_neg)
            
            # Отступ между кнопками
            space = View(ctx)
            buttons.addView(space, _dp(8), 1)
            
            # Кнопка действия
            btn_pos = _create_button(ctx, positive_text, Theme.key_dialogTextLink, on_positive, dialog_ref)
            buttons.addView(btn_pos)
            
            root.addView(buttons, -1, -2)

            builder = AlertDialog.Builder(ctx)
            builder.setView(root)
            dialog = builder.create()
            dialog.getWindow().setBackgroundDrawable(ColorDrawable(0))
            dialog_ref[0] = dialog
            dialog.show()

        run_on_ui_thread(_show)

    @staticmethod
    def input(title: str, hint: str = "", prefill: str = "", 
              button_text: str = "Готово", 
              on_result=None, is_number: bool = False):
        def _show():
            frag = get_last_fragment()
            if not frag: return
            ctx = frag.getContext()
            dialog_ref = [None]

            # Поле ввода (Android EditText)
            from android.widget import EditText
            et = EditText(ctx)
            et.setText(prefill)
            et.setHint(hint)
            et.setTextColor(_get_color(Theme.key_dialogTextBlack))
            et.setHintTextColor(_get_color(Theme.key_dialogTextHint))
            et.setBackground(Theme.createEditTextDrawable(ctx, False)) # Линия снизу
            et.setPadding(0, _dp(10), 0, _dp(10))
            
            if is_number:
                et.setInputType(InputType.TYPE_CLASS_NUMBER)

            # Строим UI с полем ввода вместо сообщения
            root = MandreDialogs._base_builder(ctx, title, None, custom_view=et)
            
            buttons = LinearLayout(ctx)
            buttons.setGravity(Gravity.RIGHT)
            
            btn_cancel = _create_button(ctx, "Отмена", Theme.key_dialogTextGray2, None, dialog_ref)
            
            def handle_ok():
                if on_result: on_result(str(et.getText()))
                
            btn_ok = _create_button(ctx, button_text, Theme.key_dialogTextLink, handle_ok, dialog_ref)
            
            buttons.addView(btn_cancel)
            buttons.addView(View(ctx), _dp(8), 1)
            buttons.addView(btn_ok)
            root.addView(buttons, -1, -2)

            builder = AlertDialog.Builder(ctx)
            builder.setView(root)
            dialog = builder.create()
            dialog.getWindow().setBackgroundDrawable(ColorDrawable(0))
            dialog.getWindow().setSoftInputMode(4) # VISIBLE
            dialog_ref[0] = dialog
            dialog.show()
            et.requestFocus()

        run_on_ui_thread(_show)

    @staticmethod
    def single_choice(title: str, items: list, on_select=None):
        """
        MD3 Radio Button list mockup.
        """
        def _show():
            frag = get_last_fragment()
            if not frag: return
            ctx = frag.getContext()
            dialog_ref = [None]

            list_container = LinearLayout(ctx)
            list_container.setOrientation(1)
            
            for i, item_text in enumerate(items):
                row = FrameLayout(ctx)
                row.setBackground(Theme.createSelectorDrawable(_get_color(Theme.key_listSelector), 2))
                
                tv = TextView(ctx)
                tv.setText(item_text)
                tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16)
                tv.setTextColor(_get_color(Theme.key_dialogTextBlack))
                tv.setPadding(_dp(12), _dp(12), _dp(12), _dp(12))
                row.addView(tv, -1, -2)
                
                def make_click(idx):
                    return lambda v: (dialog_ref[0].dismiss(), on_select(idx) if on_select else None)
                
                row.setOnClickListener(OnClickListener(make_click(i)))
                list_container.addView(row)

            root = MandreDialogs._base_builder(ctx, title, None, custom_view=list_container)
            
            buttons = LinearLayout(ctx)
            buttons.setGravity(Gravity.RIGHT)
            btn_cancel = _create_button(ctx, "Отмена", Theme.key_dialogTextLink, None, dialog_ref)
            buttons.addView(btn_cancel)
            root.addView(buttons, -1, -2)

            builder = AlertDialog.Builder(ctx)
            builder.setView(root)
            dialog = builder.create()
            dialog.getWindow().setBackgroundDrawable(ColorDrawable(0))
            dialog_ref[0] = dialog
            dialog.show()

        run_on_ui_thread(_show)
