
from setuptools import setup, find_packages

setup(
    name="MandreDialogs",
    version="1.0.1",
    author="@swagnonher",
    description="True MD3 Dialogs for MandreLib (Custom View Implementation)",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Android",
    ],
    python_requires='>=3.6',
)
