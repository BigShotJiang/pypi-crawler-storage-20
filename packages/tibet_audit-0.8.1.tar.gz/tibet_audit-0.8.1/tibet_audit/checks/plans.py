"""Plan Registry checks for scan coverage."""

from pathlib import Path
from typing import Optional, List

from .base import BaseCheck, CheckResult, Status, Severity

try:
    import requests
except ImportError:  # Optional dependency
    requests = None


def _default_plans_url() -> str:
    return "http://localhost:8000/kmbit/plans"


def _load_plan_registry() -> tuple[Optional[List[dict]], Optional[str]]:
    """Load plans from the Plan Registry endpoint."""
    if not requests:
        return None, "requests-not-installed"
    url = _default_plans_url()
    try:
        resp = requests.get(url, timeout=1.5)
        if resp.status_code != 200:
            return None, f"http-{resp.status_code}"
        data = resp.json()
        if isinstance(data, dict):
            return data.get("plans") or data.get("items") or [], None
        if isinstance(data, list):
            return data, None
        return None, "unexpected-json"
    except Exception as exc:
        return None, str(exc)


def _plan_paths(plans: List[dict]) -> List[Path]:
    paths = []
    for plan in plans:
        if not isinstance(plan, dict):
            continue
        for key in ("path", "root", "scan_path", "dir", "directory"):
            value = plan.get(key)
            if value:
                try:
                    paths.append(Path(value).resolve())
                except Exception:
                    pass
                break
    return paths


class PlanRegistryCheck(BaseCheck):
    check_id = "PLAN-001"
    name = "Plan Registry Coverage"
    description = "Check if scanned directory is registered in Plan Registry"
    severity = Severity.MEDIUM
    category = "plans"
    score_weight = 8

    def run(self, context: dict) -> CheckResult:
        plans, error = _load_plan_registry()
        if plans is None:
            status = Status.SKIPPED if error == "requests-not-installed" else Status.WARNING
            message = "Plan Registry unavailable" if status == Status.WARNING else "requests not installed"
            return CheckResult(
                check_id=self.check_id,
                name=self.name,
                status=status,
                severity=self.severity,
                category=self.category,
                message=message,
                recommendation="Expose Plan Registry at /kmbit/plans or install requests.",
                score_impact=self.score_weight,
            )

        scan_path = Path(context["scan_path"]).resolve()
        for plan_path in _plan_paths(plans):
            try:
                if scan_path == plan_path or scan_path.is_relative_to(plan_path):
                    return CheckResult(
                        check_id=self.check_id,
                        name=self.name,
                        status=Status.PASSED,
                        severity=self.severity,
                        category=self.category,
                        message=f"Plan registered for {plan_path}",
                        score_impact=self.score_weight,
                    )
            except Exception:
                continue

        return CheckResult(
            check_id=self.check_id,
            name=self.name,
            status=Status.WARNING,
            severity=self.severity,
            category=self.category,
            message="No plan registered for scan path.",
            recommendation="Register a plan or create plans/<name>.md and sync to registry.",
            score_impact=self.score_weight,
        )


PLANS_CHECKS = [PlanRegistryCheck()]

