# UCP Audit Profile (Humotica)

Version: 0.1

## Purpose
Define the UCP readiness profile for `tibet-audit`, including Humotica
sovereignty requirements and Matrix safety gating, without exposing
internal AETHER implementation details.

## Profile Name
`ucp`

Run:
```
audit-tool scan --profile ucp
```

## Category Mapping
The `ucp` profile maps to these categories:
- ucp
- jis
- sovereignty
- provider

## Scope
1) UCP discovery + namespace compliance
2) Capability coverage and schema references
3) JIS identity + TIBET provenance
4) Transport and policy documentation
5) Matrix safety gate (content-type allowlist + FIR/A thresholds)

## Checks (UCP category)
- UCP-001: Manifest exists and is valid JSON
- UCP-002: Required discovery fields present
- UCP-003: Namespace + spec/schema origin compliance
- UCP-004: Humotica fields (jis.identity, tibet.audit, aether.policy)
- UCP-005: Matrix policy artifacts exist
- UCP-006: Matrix allowlist + FIR/A thresholds documented
- UCP-007: TIBET token schema for commerce events documented
- UCP-008: Capability spec/schema references present

## Trust Thresholds
- FIR/A >= 0.7: auto-accept
- FIR/A 0.3–0.7: human review
- FIR/A < 0.3: block

## Probing Policy
Default: schema-only (no live calls).

Optional live probing (explicit opt-in):
- `--live` enables read-only probes
- Only GET endpoints (discovery/status); no mutation
- Rate-limit + short timeout (e.g., 2s, max 3 endpoints)
- Allowlist required for domains/hosts
- No PII or auth headers unless explicit `--auth`
- All probes emit a TIBET AUDIT token
- Fail-safe: errors become WARNING (never hard FAIL)
- Cache live results for a short window to reduce load

## Evidence Sources
- `/.well-known/ucp` (or local manifest file)
- Policy docs (matrix/ucp/commerce)
- TIBET schema documentation

## Notes
- The profile is designed to audit readiness without revealing internal
  AETHER routing logic.
- All checks are surface-level and policy-driven.
