class UnfoldError(Exception):
    pass
