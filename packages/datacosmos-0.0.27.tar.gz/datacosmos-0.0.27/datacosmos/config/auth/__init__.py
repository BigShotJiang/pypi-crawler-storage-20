"""Configuration authentication related things."""
