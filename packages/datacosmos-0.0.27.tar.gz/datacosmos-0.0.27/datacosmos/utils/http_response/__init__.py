"""Validates an API response."""
