"""Constants for STAC."""
