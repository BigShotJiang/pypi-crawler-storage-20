"""
SecureX Anti-Nuke SDK
Backend-only Discord anti-nuke protection.
Developers provide their own UI.
"""

__version__ = "1.0.0"
__author__ = "SecureX Team"

# Auto-enable high-performance event loop if available
# winuvloop automatically installs the right loop for each platform:
#   - uvloop on Linux/Mac  
#   - winloop on Windows
try:
    import winuvloop
    winuvloop.install()  # This sets the event loop policy automatically
except ImportError:
    # winuvloop not installed, fall back to default event loop
    pass

from .client import SecureX
from .models import ThreatEvent, BackupInfo, RestoreResult

__all__ = [
    "SecureX",
    "ThreatEvent",
    "BackupInfo", 
    "RestoreResult",
]
