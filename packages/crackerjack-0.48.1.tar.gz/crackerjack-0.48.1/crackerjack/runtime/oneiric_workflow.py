from __future__ import annotations

import inspect
import typing as t
from dataclasses import dataclass

from oneiric.core.config import OneiricSettings, resolver_settings_from_config
from oneiric.core.lifecycle import LifecycleManager
from oneiric.core.resolution import Candidate, Resolver
from oneiric.runtime.orchestrator import RuntimeOrchestrator

if t.TYPE_CHECKING:
    from crackerjack.core.phase_coordinator import PhaseCoordinator


@dataclass(frozen=True)
class OneiricWorkflowRuntime:
    resolver: Resolver
    lifecycle: LifecycleManager
    orchestrator: RuntimeOrchestrator

    @property
    def workflow_bridge(self):
        return self.orchestrator.workflow_bridge

    @property
    def task_bridge(self):
        return self.orchestrator.task_bridge


class _PhaseTask:
    def __init__(self, name: str, runner: t.Callable[[], t.Any]) -> None:
        self._name = name
        self._runner = runner

    async def run(self, payload: dict[str, t.Any] | None = None) -> t.Any:
        result = self._runner()
        if inspect.isawaitable(result):
            result = await result
        if result is False:
            msg = f"workflow-task-failed: {self._name}"
            raise RuntimeError(msg)
        return result


def build_oneiric_runtime() -> OneiricWorkflowRuntime:
    oneiric_settings = OneiricSettings()
    oneiric_settings.app.name = "crackerjack"
    oneiric_settings.profile.watchers_enabled = False
    oneiric_settings.profile.remote_enabled = False
    oneiric_settings.remote.enabled = False

    import os

    debug_mode = os.environ.get("CRACKERJACK_DEBUG") == "1"

    if not debug_mode:
        oneiric_settings.logging.emit_json = False
        oneiric_settings.logging.level = "WARNING"
    else:
        oneiric_settings.logging.emit_json = True
        oneiric_settings.logging.level = "DEBUG"
    oneiric_settings.remote.refresh_interval = None

    oneiric_settings.logging.level = "WARNING" if not debug_mode else "DEBUG"
    oneiric_settings.logging.emit_json = debug_mode

    oneiric_settings.app.debug = debug_mode

    from oneiric.core.logging import configure_logging

    configure_logging(oneiric_settings.logging)

    resolver = Resolver(settings=resolver_settings_from_config(oneiric_settings))
    lifecycle = LifecycleManager(resolver)
    orchestrator = RuntimeOrchestrator(
        oneiric_settings,
        resolver,
        lifecycle,
        secrets=_build_secrets_hook(oneiric_settings, lifecycle),
        health_path=None,
    )
    return OneiricWorkflowRuntime(
        resolver=resolver,
        lifecycle=lifecycle,
        orchestrator=orchestrator,
    )


def _build_secrets_hook(
    oneiric_settings: OneiricSettings,
    lifecycle: LifecycleManager,
) -> t.Any:
    from oneiric.core.config import SecretsHook

    return SecretsHook(lifecycle, oneiric_settings.secrets)


def register_crackerjack_workflow(
    runtime: OneiricWorkflowRuntime,
    *,
    phases: PhaseCoordinator,
    options: t.Any,
) -> None:
    _register_tasks(runtime, phases, options)
    _register_workflow(runtime, options)
    runtime.workflow_bridge.refresh_dags()


def _register_tasks(
    runtime: OneiricWorkflowRuntime,
    phases: PhaseCoordinator,
    options: t.Any,
) -> None:
    task_factories = {
        "config_cleanup": lambda: _PhaseTask(
            "config_cleanup",
            lambda: phases.run_config_cleanup_phase(options),
        ),
        "configuration": lambda: _PhaseTask(
            "configuration",
            lambda: phases.run_configuration_phase(options),
        ),
        "cleaning": lambda: _PhaseTask(
            "cleaning",
            lambda: phases.run_cleaning_phase(options),
        ),
        "fast_hooks": lambda: _PhaseTask(
            "fast_hooks",
            lambda: phases.run_fast_hooks_only(options),
        ),
        "tests": lambda: _PhaseTask("tests", lambda: phases.run_testing_phase(options)),
        "documentation_cleanup": lambda: _PhaseTask(
            "documentation_cleanup",
            lambda: phases.run_documentation_cleanup_phase(options),
        ),
        "git_cleanup": lambda: _PhaseTask(
            "git_cleanup",
            lambda: phases.run_git_cleanup_phase(options),
        ),
        "doc_updates": lambda: _PhaseTask(
            "doc_updates",
            lambda: phases.run_doc_update_phase(options),
        ),
        "comprehensive_hooks": lambda: _PhaseTask(
            "comprehensive_hooks",
            lambda: phases.run_comprehensive_hooks_only(options),
        ),
        "publishing": lambda: _PhaseTask(
            "publishing",
            lambda: phases.run_publishing_phase(options),
        ),
        "commit": lambda: _PhaseTask(
            "commit",
            lambda: phases.run_commit_phase(options),
        ),
    }

    for key, factory in task_factories.items():
        runtime.resolver.register(
            Candidate(
                domain="task",
                key=key,
                provider="crackerjack",
                factory=factory,
                metadata={"package": "crackerjack"},
            ),
        )


def _register_workflow(runtime: OneiricWorkflowRuntime, options: t.Any) -> None:
    dag_nodes = _build_dag_nodes(options)
    runtime.resolver.register(
        Candidate(
            domain="workflow",
            key="crackerjack",
            provider="crackerjack",
            factory=object,
            metadata={"dag": {"nodes": dag_nodes}},
        ),
    )


def _build_dag_nodes(options: t.Any) -> list[dict[str, t.Any]]:
    """Build workflow DAG nodes with optional parallel execution.

    When enable_parallel_phases is True, tests and comprehensive_hooks
    run in parallel for improved performance (20-30% faster).
    """
    steps = _build_workflow_steps(options)
    enable_parallel = getattr(options, "enable_parallel_phases", False)
    return _build_nodes_with_dependencies(steps, enable_parallel)


def _build_workflow_steps(options: t.Any) -> list[str]:
    """Build the ordered list of workflow steps."""
    steps: list[str] = []

    if _should_run_config_cleanup(options):
        steps.append("config_cleanup")

    if not getattr(options, "no_config_updates", False):
        steps.append("configuration")

    if _should_clean(options):
        steps.append("cleaning")

    # Documentation cleanup BEFORE fast hooks so markdown tools fix links first
    if _should_run_documentation_cleanup(options):
        steps.append("documentation_cleanup")

    if _should_run_fast_hooks(options):
        steps.append("fast_hooks")

    # Add tests and comprehensive hooks (parallel or sequential)
    if _should_run_tests(options) and _should_run_comprehensive_hooks(options):
        enable_parallel = getattr(options, "enable_parallel_phases", False)
        if enable_parallel:
            steps.extend(("tests", "comprehensive_hooks"))
        else:
            steps.extend(("tests", "comprehensive_hooks"))
    elif _should_run_tests(options):
        steps.append("tests")
    elif _should_run_comprehensive_hooks(options):
        steps.append("comprehensive_hooks")

    if _should_run_git_cleanup(options):
        steps.append("git_cleanup")

    if _should_run_doc_updates(options):
        steps.append("doc_updates")

    steps.extend(("publishing", "commit"))
    return steps


def _build_nodes_with_dependencies(
    steps: list[str], enable_parallel: bool
) -> list[dict[str, t.Any]]:
    """Build DAG nodes with proper dependency chains."""
    nodes: list[dict[str, t.Any]] = []
    previous: str | None = None
    parallel_start_index: int | None = None
    parallel_predecessor: str | None = None

    for idx, step in enumerate(steps):
        node: dict[str, t.Any] = {"id": step, "task": step}

        if enable_parallel:
            node = _handle_parallel_step(
                node, step, previous, parallel_start_index, parallel_predecessor
            )
            # Update parallel tracking state
            if step in ("tests", "comprehensive_hooks"):
                if parallel_start_index is None:
                    parallel_start_index = idx
                    parallel_predecessor = previous
            else:
                parallel_start_index = None
                parallel_predecessor = None
        else:
            # Sequential mode - every task depends on previous
            if previous:
                node["depends_on"] = [previous]

        nodes.append(node)
        previous = step

    return nodes


def _handle_parallel_step(
    node: dict[str, t.Any],
    step: str,
    previous: str | None,
    parallel_start_index: int | None,
    parallel_predecessor: str | None,
) -> dict[str, t.Any]:
    """Handle dependency assignment for parallel workflow steps."""
    if step in ("tests", "comprehensive_hooks"):
        if parallel_start_index is None:
            # First parallel task - depends on previous sequential task
            if previous:
                node["depends_on"] = [previous]
        elif parallel_predecessor is not None:
            # Second parallel task - also depends on previous sequential task
            node["depends_on"] = [parallel_predecessor]
    else:
        # Sequential task - depends on the last task
        if previous:
            node["depends_on"] = [previous]

    return node


def _should_clean(options: t.Any) -> bool:
    return bool(
        getattr(options, "strip_code", False) or getattr(options, "clean", False),
    )


def _should_run_config_cleanup(_options: t.Any) -> bool:
    # TODO: Revert this temporary fix after config_cleanup debugging
    return False


def _should_run_tests(options: t.Any) -> bool:
    return bool(
        getattr(options, "run_tests", False)
        or getattr(options, "test", False)
        or getattr(options, "xcode_tests", False)
    )


def _should_run_fast_hooks(options: t.Any) -> bool:
    if getattr(options, "skip_hooks", False):
        return False
    return not getattr(options, "comp", False)


def _should_run_comprehensive_hooks(options: t.Any) -> bool:
    if getattr(options, "skip_hooks", False):
        return False
    if getattr(options, "fast", False):
        return False
    return not getattr(options, "fast_iteration", False)


def _should_run_documentation_cleanup(options: t.Any) -> bool:
    return bool(getattr(options, "cleanup_docs", False))


def _should_run_git_cleanup(options: t.Any) -> bool:
    return bool(getattr(options, "cleanup_git", False))


def _should_run_doc_updates(options: t.Any) -> bool:
    return bool(getattr(options, "update_docs", False))
