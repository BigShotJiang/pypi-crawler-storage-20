"""CLI interface for Question Extractor."""
from __future__ import annotations


import subprocess
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.prompt import Confirm

from question_extractor.config import Config
from question_extractor.pipeline import Pipeline

app = typer.Typer(
    name="question-extractor",
    help="Extract and deduplicate customer questions from text data.",
    add_completion=False,
)
console = Console()


@app.command()
def run(
    input_file: Path = typer.Argument(
        ...,
        help="Path to input CSV file",
        exists=True,
        dir_okay=False,
    ),
    output_dir: Path = typer.Option(
        Path("output"),
        "--output-dir", "-o",
        help="Output directory for results",
    ),
    text_column: str = typer.Option(
        "text",
        "--text-col", "-t",
        help="Name of column containing text to process",
    ),
    id_column: str = typer.Option(
        "row_id",
        "--id-col", "-i",
        help="Name of column containing unique row identifier",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key", "-k",
        envvar="OPENAI_API_KEY",
        help="OpenAI API key (or set OPENAI_API_KEY env var)",
    ),
    fuzzy_threshold: float = typer.Option(
        0.75,
        "--fuzzy-threshold",
        help="Similarity threshold for fuzzy matching (0-1)",
    ),
    semantic_threshold: float = typer.Option(
        0.7,
        "--semantic-threshold",
        help="Distance threshold for semantic clustering",
    ),
    skip_confirm: bool = typer.Option(
        False,
        "--yes", "-y",
        help="Skip cost estimation confirmation",
    ),
) -> None:
    """Run the full question extraction pipeline.

    This command processes a CSV file containing text data (e.g., call center
    transcripts) and extracts, deduplicates, and analyzes customer questions.

    Example:
        question-extractor run data.csv --text-col transcript --id-col call_id
    """
    # Build config
    config = Config(
        openai_api_key=api_key or "",
        text_column=text_column,
        id_column=id_column,
        output_dir=output_dir,
        fuzzy_threshold=fuzzy_threshold,
        semantic_distance_threshold=semantic_threshold,
    )

    if not config.openai_api_key:
        console.print("[red]Error: OpenAI API key not provided.[/red]")
        console.print("Set OPENAI_API_KEY environment variable or use --api-key option.")
        raise typer.Exit(1)

    # Initialize pipeline
    pipeline = Pipeline(config)

    # Get cost estimate
    if not skip_confirm:
        console.print("\n[bold blue]Estimating cost and time...[/bold blue]\n")
        estimate = pipeline.estimate(input_path=input_file)
        console.print(estimate.format_summary())

        if not Confirm.ask("\nProceed with processing?"):
            console.print("Aborted.")
            raise typer.Exit(0)

    # Run pipeline
    console.print("\n[bold blue]Starting pipeline...[/bold blue]\n")
    result = pipeline.run(input_path=input_file, output_dir=output_dir)

    console.print(f"\n[green]Done! Output saved to {output_dir}[/green]")


@app.command()
def estimate(
    input_file: Path = typer.Argument(
        ...,
        help="Path to input CSV file",
        exists=True,
        dir_okay=False,
    ),
    text_column: str = typer.Option(
        "text",
        "--text-col", "-t",
        help="Name of column containing text to process",
    ),
    id_column: str = typer.Option(
        "row_id",
        "--id-col", "-i",
        help="Name of column containing unique row identifier",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key", "-k",
        envvar="OPENAI_API_KEY",
        help="OpenAI API key (or set OPENAI_API_KEY env var)",
    ),
    sample_size: int = typer.Option(
        100,
        "--sample-size", "-n",
        help="Number of rows to sample for estimation",
    ),
) -> None:
    """Estimate cost and time without running the pipeline.

    This command samples rows from the input file and estimates the API costs
    and processing time for the full pipeline.

    Example:
        question-extractor estimate data.csv --text-col transcript
    """
    config = Config(
        openai_api_key=api_key or "",
        text_column=text_column,
        id_column=id_column,
    )

    if not config.openai_api_key:
        console.print("[red]Error: OpenAI API key not provided.[/red]")
        console.print("Set OPENAI_API_KEY environment variable or use --api-key option.")
        raise typer.Exit(1)

    pipeline = Pipeline(config)

    console.print("\n[bold blue]Estimating cost and time...[/bold blue]\n")
    estimate = pipeline.estimate(input_path=input_file, sample_size=sample_size)
    console.print(estimate.format_summary())


@app.command()
def serve(
    output_dir: Path = typer.Argument(
        Path("output"),
        help="Output directory containing pipeline results",
    ),
    port: int = typer.Option(
        8501,
        "--port", "-p",
        help="Port to run Streamlit server on",
    ),
) -> None:
    """Launch the Streamlit dashboard to explore results.

    This command starts a Streamlit server to visualize and explore the
    processed question data.

    Example:
        question-extractor serve output/
    """
    app_path = output_dir / "app.py"

    if not app_path.exists():
        console.print(f"[red]Error: Streamlit app not found at {app_path}[/red]")
        console.print("Run the pipeline first to generate the dashboard.")
        raise typer.Exit(1)

    console.print(f"[bold blue]Launching Streamlit dashboard on port {port}...[/bold blue]")
    console.print(f"Open http://localhost:{port} in your browser\n")

    # Launch Streamlit
    subprocess.run(
        [sys.executable, "-m", "streamlit", "run", str(app_path), "--server.port", str(port)],
        check=True,
    )


@app.command()
def version() -> None:
    """Show the version number."""
    from question_extractor import __version__
    console.print(f"question-extractor version {__version__}")


if __name__ == "__main__":
    app()
