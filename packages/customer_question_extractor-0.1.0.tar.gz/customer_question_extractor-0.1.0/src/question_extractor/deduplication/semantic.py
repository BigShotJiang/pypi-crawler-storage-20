"""Semantic clustering for question deduplication using embeddings."""
from __future__ import annotations


import logging
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.cluster import AgglomerativeClustering

from question_extractor.config import Config
from question_extractor.utils.embeddings import EmbeddingsClient

logger = logging.getLogger(__name__)


class SemanticClusterer:
    """Cluster questions semantically using embeddings."""

    def __init__(
        self,
        config: Config,
        embeddings_client: Optional[EmbeddingsClient] = None,
    ):
        self.config = config
        self.embeddings = embeddings_client or EmbeddingsClient(config)

    def _filter_top_questions(
        self,
        df: pd.DataFrame,
        question_column: str,
        id_column: str,
        percentile: Optional[float] = None,
    ) -> pd.DataFrame:
        """Filter to top questions by row_id volume.

        Args:
            df: Input DataFrame
            question_column: Column containing questions
            id_column: Row ID column
            percentile: Percentile of questions to keep (defaults to config)

        Returns:
            Filtered DataFrame with top questions
        """
        percentile = percentile or self.config.top_questions_percentile

        # Count unique row_ids per question
        question_counts = (
            df.groupby(question_column)[id_column]
            .nunique()
            .reset_index()
            .rename(columns={id_column: "row_count"})
        )

        # Calculate threshold for top percentile
        threshold = question_counts["row_count"].quantile(1 - percentile)

        # Filter to questions above threshold
        top_questions = question_counts[question_counts["row_count"] >= threshold][
            question_column
        ].tolist()

        logger.info(
            f"Filtered to {len(top_questions)} questions "
            f"(top {percentile*100:.0f}% by row volume, threshold: {threshold})"
        )

        return df[df[question_column].isin(top_questions)]

    def cluster(
        self,
        questions: list[str],
        distance_threshold: Optional[float] = None,
        linkage: Optional[str] = None,
        metric: Optional[str] = None,
    ) -> dict[int, list[str]]:
        """Cluster questions semantically.

        Args:
            questions: List of questions to cluster
            distance_threshold: Clustering distance threshold (defaults to config)
            linkage: Linkage method (defaults to config)
            metric: Distance metric (defaults to config)

        Returns:
            Dictionary mapping cluster ID to list of questions
        """
        if not questions:
            return {}

        distance_threshold = distance_threshold or self.config.semantic_distance_threshold
        linkage = linkage or self.config.clustering_linkage
        metric = metric or self.config.clustering_metric

        # Get embeddings
        logger.info(f"Generating embeddings for {len(questions)} questions")
        embeddings = self.embeddings.get_embeddings_batch(questions)

        # Normalize embeddings
        embeddings_normalized = self.embeddings.normalize_embeddings(embeddings)

        # Perform clustering
        logger.info(
            f"Clustering with distance_threshold={distance_threshold}, "
            f"linkage={linkage}, metric={metric}"
        )
        clustering = AgglomerativeClustering(
            n_clusters=None,
            distance_threshold=distance_threshold,
            linkage=linkage,
            metric=metric,
        )
        labels = clustering.fit_predict(embeddings_normalized)

        # Group questions by cluster
        clusters: dict[int, list[str]] = {}
        for question, label in zip(questions, labels):
            cluster_id = int(label)
            if cluster_id not in clusters:
                clusters[cluster_id] = []
            clusters[cluster_id].append(question)

        logger.info(f"Created {len(clusters)} semantic clusters")
        return clusters

    def cluster_dataframe(
        self,
        df: pd.DataFrame,
        question_column: str = "fuzzy_representative",
        output_column: str = "semantic_cluster_id",
        id_column: Optional[str] = None,
        filter_top: bool = True,
    ) -> tuple[pd.DataFrame, dict[int, list[str]]]:
        """Cluster questions in a DataFrame.

        Args:
            df: Input DataFrame
            question_column: Column containing questions to cluster
            output_column: Column for cluster IDs
            id_column: Row ID column (defaults to config)
            filter_top: Whether to filter to top questions by volume

        Returns:
            Tuple of (DataFrame with cluster IDs, cluster dictionary)
        """
        id_column = id_column or self.config.id_column

        if question_column not in df.columns:
            raise ValueError(f"Column '{question_column}' not found in DataFrame")

        df = df.copy()

        # Get questions to cluster
        if filter_top:
            df_filtered = self._filter_top_questions(df, question_column, id_column)
            questions_to_cluster = df_filtered[question_column].unique().tolist()
        else:
            questions_to_cluster = df[question_column].dropna().unique().tolist()

        if not questions_to_cluster:
            df[output_column] = None
            return df, {}

        # Perform clustering
        clusters = self.cluster(questions_to_cluster)

        # Create mapping from question to cluster ID
        question_to_cluster = {}
        for cluster_id, questions in clusters.items():
            for question in questions:
                question_to_cluster[question] = cluster_id

        # Apply mapping (questions not clustered get None)
        df[output_column] = df[question_column].map(question_to_cluster)

        return df, clusters

    def get_cluster_stats(
        self,
        df: pd.DataFrame,
        cluster_column: str = "semantic_cluster_id",
        question_column: str = "fuzzy_representative",
    ) -> dict:
        """Get statistics about semantic clustering.

        Args:
            df: DataFrame with clustering applied
            cluster_column: Cluster ID column
            question_column: Question column

        Returns:
            Dictionary with clustering statistics
        """
        clustered = df[df[cluster_column].notna()]
        unclustered = df[df[cluster_column].isna()]

        cluster_sizes = clustered.groupby(cluster_column)[question_column].nunique()

        return {
            "total_questions": df[question_column].nunique(),
            "clustered_questions": clustered[question_column].nunique(),
            "unclustered_questions": unclustered[question_column].nunique(),
            "num_clusters": clustered[cluster_column].nunique(),
            "avg_cluster_size": float(cluster_sizes.mean()) if len(cluster_sizes) > 0 else 0,
            "max_cluster_size": int(cluster_sizes.max()) if len(cluster_sizes) > 0 else 0,
            "min_cluster_size": int(cluster_sizes.min()) if len(cluster_sizes) > 0 else 0,
        }
