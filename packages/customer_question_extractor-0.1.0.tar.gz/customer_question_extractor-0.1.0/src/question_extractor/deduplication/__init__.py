"""Deduplication modules for Question Extractor."""

from question_extractor.deduplication.fuzzy import FuzzyMatcher
from question_extractor.deduplication.semantic import SemanticClusterer
from question_extractor.deduplication.consolidator import QuestionConsolidator

__all__ = ["FuzzyMatcher", "SemanticClusterer", "QuestionConsolidator"]
