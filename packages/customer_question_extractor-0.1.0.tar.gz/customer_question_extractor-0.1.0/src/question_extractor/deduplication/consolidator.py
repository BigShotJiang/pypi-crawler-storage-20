"""LLM-based question consolidation for semantic clusters."""
from __future__ import annotations


import asyncio
import logging
from typing import Optional

import pandas as pd

from question_extractor.config import Config
from question_extractor.utils.llm import LLMClient

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are an expert at consolidating similar customer questions into a single representative question.
Your task is to create one clear, concise question that captures the core intent of all the questions in the group.

Rules:
1. The representative question should be clear and professional
2. Capture the common intent across all questions
3. Use simple, direct language
4. Output ONLY the representative question, nothing else"""

USER_PROMPT_TEMPLATE = """Create a single representative question that captures the core intent of these similar questions:

{questions}

Representative question:"""


class QuestionConsolidator:
    """Consolidate semantic clusters into representative questions using LLM."""

    def __init__(self, config: Config, llm_client: Optional[LLMClient] = None):
        self.config = config
        self.llm = llm_client or LLMClient(config)

    def consolidate(self, questions: list[str]) -> str:
        """Consolidate a group of similar questions into one representative.

        Args:
            questions: List of similar questions

        Returns:
            Single representative question
        """
        if not questions:
            return ""

        if len(questions) == 1:
            return questions[0]

        # Format questions for prompt
        questions_text = "\n".join(f"- {q}" for q in questions[:20])  # Limit to 20

        prompt = USER_PROMPT_TEMPLATE.format(questions=questions_text)
        response = self.llm.complete(
            prompt=prompt,
            system_prompt=SYSTEM_PROMPT,
            max_tokens=256,
            temperature=0.3,
        )

        return response.strip()

    async def consolidate_async(self, questions: list[str]) -> str:
        """Consolidate questions asynchronously.

        Args:
            questions: List of similar questions

        Returns:
            Single representative question
        """
        if not questions:
            return ""

        if len(questions) == 1:
            return questions[0]

        questions_text = "\n".join(f"- {q}" for q in questions[:20])
        prompt = USER_PROMPT_TEMPLATE.format(questions=questions_text)

        response = await self.llm.complete_async(
            prompt=prompt,
            system_prompt=SYSTEM_PROMPT,
            max_tokens=256,
            temperature=0.3,
        )

        return response.strip()

    async def consolidate_clusters(
        self,
        clusters: dict[int, list[str]],
    ) -> dict[int, str]:
        """Consolidate all clusters into representative questions.

        Args:
            clusters: Dictionary mapping cluster ID to list of questions

        Returns:
            Dictionary mapping cluster ID to representative question
        """
        if not clusters:
            return {}

        logger.info(f"Consolidating {len(clusters)} clusters")

        # Process clusters concurrently
        async def process_cluster(
            cluster_id: int, questions: list[str]
        ) -> tuple[int, str]:
            representative = await self.consolidate_async(questions)
            return cluster_id, representative

        tasks = [
            process_cluster(cid, questions) for cid, questions in clusters.items()
        ]
        results = await asyncio.gather(*tasks)

        return dict(results)

    def consolidate_dataframe(
        self,
        df: pd.DataFrame,
        clusters: dict[int, list[str]],
        cluster_column: str = "semantic_cluster_id",
        question_column: str = "fuzzy_representative",
        output_column: str = "semantic_cluster",
    ) -> pd.DataFrame:
        """Apply cluster consolidation to a DataFrame.

        Args:
            df: Input DataFrame
            clusters: Dictionary mapping cluster ID to list of questions
            cluster_column: Column with cluster IDs
            question_column: Column with original questions
            output_column: Column for consolidated questions

        Returns:
            DataFrame with consolidated question column
        """
        df = df.copy()

        # Consolidate clusters
        cluster_representatives = asyncio.run(self.consolidate_clusters(clusters))

        # Create mapping from cluster ID to representative
        cluster_to_rep = {
            cid: rep for cid, rep in cluster_representatives.items() if rep
        }

        # Apply mapping
        # For clustered questions: use the cluster representative
        # For unclustered questions: fall back to fuzzy representative or original
        def get_semantic_cluster(row):
            cluster_id = row[cluster_column]
            if pd.notna(cluster_id):
                return cluster_to_rep.get(int(cluster_id), row[question_column])
            return row[question_column]

        df[output_column] = df.apply(get_semantic_cluster, axis=1)

        logger.info(
            f"Applied {len(cluster_representatives)} cluster representatives to DataFrame"
        )

        return df

    def get_consolidation_stats(
        self,
        df: pd.DataFrame,
        semantic_column: str = "semantic_cluster",
        fuzzy_column: str = "fuzzy_representative",
        original_column: str = "question",
    ) -> dict:
        """Get statistics about consolidation.

        Args:
            df: DataFrame with consolidation applied
            semantic_column: Semantic cluster column
            fuzzy_column: Fuzzy representative column
            original_column: Original question column

        Returns:
            Dictionary with consolidation statistics
        """
        original_unique = df[original_column].nunique()
        fuzzy_unique = df[fuzzy_column].nunique()
        semantic_unique = df[semantic_column].nunique()

        return {
            "original_unique_questions": original_unique,
            "after_fuzzy_dedup": fuzzy_unique,
            "after_semantic_clustering": semantic_unique,
            "total_reduction_rate": 1 - (semantic_unique / original_unique)
            if original_unique > 0
            else 0,
            "fuzzy_reduction_rate": 1 - (fuzzy_unique / original_unique)
            if original_unique > 0
            else 0,
            "semantic_reduction_rate": 1 - (semantic_unique / fuzzy_unique)
            if fuzzy_unique > 0
            else 0,
        }
