"""Fuzzy string matching for question deduplication using RapidFuzz."""
from __future__ import annotations


import logging
from collections import defaultdict
from typing import Optional

import pandas as pd
from rapidfuzz import fuzz, process

from question_extractor.config import Config

logger = logging.getLogger(__name__)


class FuzzyMatcher:
    """Deduplicate questions using fuzzy string matching."""

    def __init__(self, config: Config):
        self.config = config
        self.threshold = config.fuzzy_threshold * 100  # RapidFuzz uses 0-100 scale

    def find_similar(
        self,
        query: str,
        candidates: list[str],
        threshold: Optional[float] = None,
    ) -> list[tuple[str, float]]:
        """Find all candidates similar to the query.

        Args:
            query: Question to match
            candidates: List of candidate questions
            threshold: Similarity threshold (0-100), defaults to config

        Returns:
            List of (candidate, score) tuples above threshold
        """
        threshold = threshold or self.threshold

        if not query or not candidates:
            return []

        results = process.extract(
            query,
            candidates,
            scorer=fuzz.token_set_ratio,
            limit=None,
            score_cutoff=threshold,
        )

        return [(match, score / 100) for match, score, _ in results]

    def group_similar(
        self,
        questions: list[str],
        threshold: Optional[float] = None,
    ) -> dict[str, list[str]]:
        """Group similar questions together.

        Args:
            questions: List of questions to group
            threshold: Similarity threshold (0-100), defaults to config

        Returns:
            Dictionary mapping representative question to list of similar questions
        """
        threshold = threshold or self.threshold

        if not questions:
            return {}

        # Track which questions have been assigned to a group
        assigned = set()
        groups: dict[str, list[str]] = {}

        # Sort questions by length (longer questions often more specific)
        sorted_questions = sorted(questions, key=len, reverse=True)

        for question in sorted_questions:
            if question in assigned:
                continue

            # Find all unassigned questions similar to this one
            unassigned = [q for q in sorted_questions if q not in assigned]
            similar = self.find_similar(question, unassigned, threshold)

            # Create group with this question as representative
            group_members = [question]
            assigned.add(question)

            for similar_q, _ in similar:
                if similar_q not in assigned and similar_q != question:
                    group_members.append(similar_q)
                    assigned.add(similar_q)

            groups[question] = group_members

        return groups

    def deduplicate_dataframe(
        self,
        df: pd.DataFrame,
        question_column: str = "question",
        output_column: str = "fuzzy_representative",
        id_column: Optional[str] = None,
    ) -> pd.DataFrame:
        """Deduplicate questions in a DataFrame using fuzzy matching.

        Args:
            df: Input DataFrame
            question_column: Column containing questions
            output_column: Column for representative questions
            id_column: Row ID column (defaults to config)

        Returns:
            DataFrame with fuzzy representative column added
        """
        id_column = id_column or self.config.id_column

        if question_column not in df.columns:
            raise ValueError(f"Column '{question_column}' not found in DataFrame")

        df = df.copy()

        # Get unique questions
        unique_questions = df[question_column].dropna().unique().tolist()
        logger.info(f"Grouping {len(unique_questions)} unique questions with fuzzy matching")

        # Group similar questions
        groups = self.group_similar(unique_questions)

        # Create mapping from question to representative
        question_to_rep = {}
        for representative, members in groups.items():
            for member in members:
                question_to_rep[member] = representative

        # Apply mapping
        df[output_column] = df[question_column].map(question_to_rep)

        # Log statistics
        num_groups = len(groups)
        logger.info(
            f"Reduced {len(unique_questions)} questions to {num_groups} groups "
            f"({100 * (1 - num_groups/len(unique_questions)):.1f}% reduction)"
        )

        return df

    def get_dedup_stats(
        self,
        df: pd.DataFrame,
        question_column: str = "question",
        representative_column: str = "fuzzy_representative",
    ) -> dict:
        """Get statistics about fuzzy deduplication.

        Args:
            df: DataFrame with deduplication applied
            question_column: Original question column
            representative_column: Representative question column

        Returns:
            Dictionary with deduplication statistics
        """
        original_unique = df[question_column].nunique()
        deduped_unique = df[representative_column].nunique()

        # Get group sizes
        group_sizes = df.groupby(representative_column)[question_column].nunique()

        return {
            "original_unique_questions": original_unique,
            "deduplicated_unique_questions": deduped_unique,
            "reduction_rate": 1 - (deduped_unique / original_unique) if original_unique > 0 else 0,
            "avg_group_size": float(group_sizes.mean()),
            "max_group_size": int(group_sizes.max()),
            "singleton_groups": int((group_sizes == 1).sum()),
        }
