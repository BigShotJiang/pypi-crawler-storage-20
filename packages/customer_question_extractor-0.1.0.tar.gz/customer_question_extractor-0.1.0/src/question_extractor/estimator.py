"""Cost and time estimation for the question extraction pipeline."""
from __future__ import annotations


import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import pandas as pd

from question_extractor.config import Config
from question_extractor.utils.io import count_csv_rows, sample_csv_rows
from question_extractor.utils.llm import LLMClient

logger = logging.getLogger(__name__)


@dataclass
class CostEstimate:
    """Detailed cost estimate for pipeline execution."""

    # Row counts
    total_rows: int = 0
    sample_size: int = 0

    # Token estimates
    summarization_input_tokens: int = 0
    summarization_output_tokens: int = 0
    extraction_input_tokens: int = 0
    extraction_output_tokens: int = 0
    consolidation_input_tokens: int = 0
    consolidation_output_tokens: int = 0
    embedding_tokens: int = 0

    # Cost estimates (USD)
    summarization_cost: float = 0.0
    extraction_cost: float = 0.0
    consolidation_cost: float = 0.0
    embedding_cost: float = 0.0
    total_cost: float = 0.0

    # Time estimates (minutes)
    summarization_time: float = 0.0
    extraction_time: float = 0.0
    embedding_time: float = 0.0
    clustering_time: float = 0.0
    consolidation_time: float = 0.0
    total_time: float = 0.0

    # Breakdown details
    breakdown: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "total_rows": self.total_rows,
            "sample_size": self.sample_size,
            "tokens": {
                "summarization": {
                    "input": self.summarization_input_tokens,
                    "output": self.summarization_output_tokens,
                },
                "extraction": {
                    "input": self.extraction_input_tokens,
                    "output": self.extraction_output_tokens,
                },
                "consolidation": {
                    "input": self.consolidation_input_tokens,
                    "output": self.consolidation_output_tokens,
                },
                "embedding": self.embedding_tokens,
            },
            "costs": {
                "summarization": self.summarization_cost,
                "extraction": self.extraction_cost,
                "consolidation": self.consolidation_cost,
                "embedding": self.embedding_cost,
                "total": self.total_cost,
            },
            "time_minutes": {
                "summarization": self.summarization_time,
                "extraction": self.extraction_time,
                "embedding": self.embedding_time,
                "clustering": self.clustering_time,
                "consolidation": self.consolidation_time,
                "total": self.total_time,
            },
            "breakdown": self.breakdown,
        }

    def format_summary(self) -> str:
        """Format a human-readable summary."""
        lines = [
            "=" * 50,
            "COST AND TIME ESTIMATE",
            "=" * 50,
            "",
            f"Total rows to process: {self.total_rows:,}",
            f"Sample size for estimation: {self.sample_size:,}",
            "",
            "ESTIMATED COSTS (USD)",
            "-" * 30,
            f"  Summarization:    ${self.summarization_cost:.2f}",
            f"  Question Extract: ${self.extraction_cost:.2f}",
            f"  Embeddings:       ${self.embedding_cost:.2f}",
            f"  Consolidation:    ${self.consolidation_cost:.2f}",
            f"  TOTAL:            ${self.total_cost:.2f}",
            "",
            "ESTIMATED TIME",
            "-" * 30,
            f"  Summarization:    {self.summarization_time:.1f} min",
            f"  Question Extract: {self.extraction_time:.1f} min",
            f"  Embeddings:       {self.embedding_time:.1f} min",
            f"  Clustering:       {self.clustering_time:.1f} min",
            f"  Consolidation:    {self.consolidation_time:.1f} min",
            f"  TOTAL:            {self.total_time:.1f} min ({self.total_time/60:.1f} hrs)",
            "",
            "=" * 50,
        ]
        return "\n".join(lines)


class Estimator:
    """Estimate cost and time for pipeline execution."""

    # Rate limits and timing constants
    TOKENS_PER_MINUTE = 150000  # Conservative TPM estimate
    EMBEDDINGS_PER_MINUTE = 3000  # Embedding rate
    QUESTIONS_PER_ROW_ESTIMATE = 2.5  # Average questions extracted per row
    CLUSTER_RATIO = 0.15  # Estimated ratio of clusters to unique questions

    def __init__(self, config: Config, llm_client: Optional[LLMClient] = None):
        self.config = config
        self.llm = llm_client or LLMClient(config)

    def estimate_from_file(
        self,
        file_path: Path | str,
        sample_size: int = 100,
    ) -> CostEstimate:
        """Estimate cost and time from a CSV file.

        Args:
            file_path: Path to input CSV
            sample_size: Number of rows to sample for estimation

        Returns:
            CostEstimate with detailed breakdown
        """
        file_path = Path(file_path)

        # Count total rows
        total_rows = count_csv_rows(file_path)
        logger.info(f"Total rows in file: {total_rows:,}")

        # Sample rows for estimation
        sample_df = sample_csv_rows(file_path, n=sample_size)
        actual_sample_size = len(sample_df)

        # Estimate tokens from sample
        text_column = self.config.text_column
        if text_column not in sample_df.columns:
            raise ValueError(f"Text column '{text_column}' not found in CSV")

        sample_texts = sample_df[text_column].fillna("").tolist()

        return self.estimate_from_texts(sample_texts, total_rows)

    def estimate_from_dataframe(
        self,
        df: pd.DataFrame,
        sample_size: int = 100,
    ) -> CostEstimate:
        """Estimate cost and time from a DataFrame.

        Args:
            df: Input DataFrame
            sample_size: Number of rows to sample for estimation

        Returns:
            CostEstimate with detailed breakdown
        """
        total_rows = len(df)
        text_column = self.config.text_column

        if text_column not in df.columns:
            raise ValueError(f"Text column '{text_column}' not found in DataFrame")

        # Sample if needed
        if total_rows > sample_size:
            sample_df = df.sample(n=sample_size, random_state=42)
        else:
            sample_df = df

        sample_texts = sample_df[text_column].fillna("").tolist()

        return self.estimate_from_texts(sample_texts, total_rows)

    def estimate_from_texts(
        self,
        sample_texts: list[str],
        total_rows: int,
    ) -> CostEstimate:
        """Estimate cost and time from sample texts.

        Args:
            sample_texts: Sample of texts to analyze
            total_rows: Total number of rows to process

        Returns:
            CostEstimate with detailed breakdown
        """
        estimate = CostEstimate()
        estimate.total_rows = total_rows
        estimate.sample_size = len(sample_texts)

        # Calculate average tokens per text
        sample_tokens = [self.llm.count_tokens(t) for t in sample_texts if t]
        avg_tokens = sum(sample_tokens) / len(sample_tokens) if sample_tokens else 100

        # Scale factor
        scale = total_rows / len(sample_texts) if sample_texts else 1

        # === SUMMARIZATION ===
        estimate.summarization_input_tokens = int(avg_tokens * total_rows)
        estimate.summarization_output_tokens = int(avg_tokens * 0.5 * total_rows)

        estimate.summarization_cost = self._calculate_llm_cost(
            estimate.summarization_input_tokens,
            estimate.summarization_output_tokens,
        )
        estimate.summarization_time = self._calculate_llm_time(
            estimate.summarization_input_tokens + estimate.summarization_output_tokens
        )

        # === QUESTION EXTRACTION ===
        # Input is the summarized text (shorter)
        summarized_tokens = int(avg_tokens * 0.5)
        estimate.extraction_input_tokens = int(summarized_tokens * total_rows)
        estimate.extraction_output_tokens = int(avg_tokens * 0.2 * total_rows)

        estimate.extraction_cost = self._calculate_llm_cost(
            estimate.extraction_input_tokens,
            estimate.extraction_output_tokens,
        )
        estimate.extraction_time = self._calculate_llm_time(
            estimate.extraction_input_tokens + estimate.extraction_output_tokens
        )

        # === EMBEDDINGS ===
        # Estimate unique questions after fuzzy dedup
        estimated_questions = int(total_rows * self.QUESTIONS_PER_ROW_ESTIMATE)
        unique_after_fuzzy = int(estimated_questions * 0.4)  # ~60% reduction from fuzzy

        # Top 75% for semantic clustering
        questions_to_embed = int(unique_after_fuzzy * self.config.top_questions_percentile)
        avg_question_tokens = 20  # Questions are short

        estimate.embedding_tokens = questions_to_embed * avg_question_tokens
        estimate.embedding_cost = (
            estimate.embedding_tokens / 1_000_000
        ) * self.config.embedding_price
        estimate.embedding_time = questions_to_embed / self.EMBEDDINGS_PER_MINUTE

        # === CLUSTERING ===
        # O(n^2) for agglomerative clustering, but relatively fast
        estimate.clustering_time = (questions_to_embed / 10000) * 2  # ~2 min per 10k

        # === CONSOLIDATION ===
        estimated_clusters = int(questions_to_embed * self.CLUSTER_RATIO)
        avg_questions_per_cluster = 5
        consolidation_input = estimated_clusters * avg_questions_per_cluster * avg_question_tokens

        estimate.consolidation_input_tokens = consolidation_input
        estimate.consolidation_output_tokens = estimated_clusters * avg_question_tokens

        estimate.consolidation_cost = self._calculate_llm_cost(
            estimate.consolidation_input_tokens,
            estimate.consolidation_output_tokens,
        )
        estimate.consolidation_time = self._calculate_llm_time(
            estimate.consolidation_input_tokens + estimate.consolidation_output_tokens
        )

        # === TOTALS ===
        estimate.total_cost = (
            estimate.summarization_cost
            + estimate.extraction_cost
            + estimate.embedding_cost
            + estimate.consolidation_cost
        )

        estimate.total_time = (
            estimate.summarization_time
            + estimate.extraction_time
            + estimate.embedding_time
            + estimate.clustering_time
            + estimate.consolidation_time
        )

        # Store breakdown
        estimate.breakdown = {
            "avg_tokens_per_text": avg_tokens,
            "estimated_total_questions": estimated_questions,
            "estimated_unique_after_fuzzy": unique_after_fuzzy,
            "questions_to_embed": questions_to_embed,
            "estimated_clusters": estimated_clusters,
        }

        return estimate

    def _calculate_llm_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Calculate LLM API cost."""
        input_cost = (input_tokens / 1_000_000) * self.config.gpt4o_input_price
        output_cost = (output_tokens / 1_000_000) * self.config.gpt4o_output_price
        return input_cost + output_cost

    def _calculate_llm_time(self, total_tokens: int) -> float:
        """Calculate estimated time in minutes for LLM processing."""
        return total_tokens / self.TOKENS_PER_MINUTE
