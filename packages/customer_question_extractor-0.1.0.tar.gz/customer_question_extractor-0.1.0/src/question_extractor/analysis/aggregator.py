"""Data aggregation for analysis and reporting."""
from __future__ import annotations


import logging
from typing import Optional

import pandas as pd

from question_extractor.config import Config

logger = logging.getLogger(__name__)


class DataAggregator:
    """Aggregate processed data for analysis."""

    def __init__(self, config: Config):
        self.config = config

    def get_question_frequency(
        self,
        df: pd.DataFrame,
        question_column: str = "semantic_cluster",
        id_column: Optional[str] = None,
        top_n: int = 50,
    ) -> pd.DataFrame:
        """Get question frequency distribution.

        Args:
            df: Processed DataFrame
            question_column: Column with deduplicated questions
            id_column: Row ID column (defaults to config)
            top_n: Number of top questions to return

        Returns:
            DataFrame with question frequencies
        """
        id_column = id_column or self.config.id_column

        freq = (
            df.groupby(question_column)
            .agg(
                row_count=(id_column, "nunique"),
                total_mentions=(question_column, "count"),
            )
            .reset_index()
            .sort_values("row_count", ascending=False)
            .head(top_n)
        )

        freq["percentage"] = (freq["row_count"] / df[id_column].nunique() * 100).round(2)

        return freq

    def get_category_distribution(
        self,
        df: pd.DataFrame,
        question_column: str = "semantic_cluster",
        id_column: Optional[str] = None,
    ) -> dict:
        """Get distribution statistics.

        Args:
            df: Processed DataFrame
            question_column: Column with deduplicated questions
            id_column: Row ID column (defaults to config)

        Returns:
            Dictionary with distribution statistics
        """
        id_column = id_column or self.config.id_column

        questions_per_row = df.groupby(id_column)[question_column].nunique()

        return {
            "total_unique_questions": df[question_column].nunique(),
            "total_rows": df[id_column].nunique(),
            "total_question_mentions": len(df),
            "avg_questions_per_row": float(questions_per_row.mean()),
            "median_questions_per_row": float(questions_per_row.median()),
            "max_questions_per_row": int(questions_per_row.max()),
            "rows_with_single_question": int((questions_per_row == 1).sum()),
            "rows_with_multiple_questions": int((questions_per_row > 1).sum()),
        }

    def get_aggregation_summary(
        self,
        df: pd.DataFrame,
        question_column: str = "semantic_cluster",
        id_column: Optional[str] = None,
        top_n: int = 20,
    ) -> str:
        """Get a text summary of aggregations for LLM analysis.

        Args:
            df: Processed DataFrame
            question_column: Column with deduplicated questions
            id_column: Row ID column (defaults to config)
            top_n: Number of top questions to include

        Returns:
            Formatted text summary
        """
        id_column = id_column or self.config.id_column

        # Get frequency data
        freq_df = self.get_question_frequency(df, question_column, id_column, top_n)
        dist_stats = self.get_category_distribution(df, question_column, id_column)

        # Build summary
        lines = [
            "# Customer Question Analysis Summary",
            "",
            "## Overview Statistics",
            f"- Total conversations analyzed: {dist_stats['total_rows']:,}",
            f"- Total unique questions identified: {dist_stats['total_unique_questions']:,}",
            f"- Total question mentions: {dist_stats['total_question_mentions']:,}",
            f"- Average questions per conversation: {dist_stats['avg_questions_per_row']:.2f}",
            "",
            "## Top Customer Questions (by frequency)",
            "",
        ]

        for _, row in freq_df.iterrows():
            lines.append(
                f"- **{row[question_column]}** "
                f"({row['row_count']:,} conversations, {row['percentage']:.1f}%)"
            )

        lines.extend([
            "",
            "## Question Distribution",
            f"- Conversations with single question: {dist_stats['rows_with_single_question']:,}",
            f"- Conversations with multiple questions: {dist_stats['rows_with_multiple_questions']:,}",
            f"- Maximum questions in one conversation: {dist_stats['max_questions_per_row']}",
        ])

        return "\n".join(lines)

    def prepare_llm_input(
        self,
        df: pd.DataFrame,
        question_column: str = "semantic_cluster",
        id_column: Optional[str] = None,
        max_questions: int = 100,
    ) -> str:
        """Prepare aggregated data for LLM analysis.

        Args:
            df: Processed DataFrame
            question_column: Column with deduplicated questions
            id_column: Row ID column (defaults to config)
            max_questions: Maximum questions to include

        Returns:
            Formatted input for LLM analysis
        """
        return self.get_aggregation_summary(df, question_column, id_column, max_questions)
