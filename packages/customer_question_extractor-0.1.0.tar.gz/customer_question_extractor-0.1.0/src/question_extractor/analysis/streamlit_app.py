"""Streamlit dashboard for exploring question extraction results."""
from __future__ import annotations


from pathlib import Path
from typing import Optional

STREAMLIT_APP_CODE = '''
import streamlit as st
import pandas as pd
from pathlib import Path

# Page config
st.set_page_config(
    page_title="Question Extractor Dashboard",
    page_icon="📊",
    layout="wide",
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        margin-bottom: 1rem;
    }
    .stat-card {
        background-color: #f0f2f6;
        border-radius: 10px;
        padding: 1rem;
        text-align: center;
    }
    .stat-value {
        font-size: 2rem;
        font-weight: bold;
        color: #1f77b4;
    }
    .stat-label {
        font-size: 0.9rem;
        color: #666;
    }
</style>
""", unsafe_allow_html=True)


def load_data(output_dir: str) -> tuple[pd.DataFrame, str, str]:
    """Load processed data and reports."""
    output_path = Path(output_dir)

    # Load clean.csv
    clean_csv = output_path / "clean.csv"
    if clean_csv.exists():
        df = pd.read_csv(clean_csv)
    else:
        df = pd.DataFrame()

    # Load analysis.md
    analysis_md = output_path / "analysis.md"
    analysis_content = ""
    if analysis_md.exists():
        analysis_content = analysis_md.read_text()

    # Load cleansing.md
    cleansing_md = output_path / "cleansing.md"
    cleansing_content = ""
    if cleansing_md.exists():
        cleansing_content = cleansing_md.read_text()

    return df, analysis_content, cleansing_content


def main():
    st.markdown('<p class="main-header">📊 Question Extractor Dashboard</p>', unsafe_allow_html=True)

    # Sidebar for configuration
    with st.sidebar:
        st.header("⚙️ Configuration")
        output_dir = st.text_input(
            "Output Directory",
            value="output",
            help="Path to the directory containing processed output files"
        )

        if st.button("🔄 Reload Data"):
            st.cache_data.clear()

    # Load data
    try:
        df, analysis_content, cleansing_content = load_data(output_dir)
    except Exception as e:
        st.error(f"Error loading data: {e}")
        st.info("Make sure you've run the question extractor pipeline first.")
        return

    if df.empty:
        st.warning("No data found. Please run the pipeline first or check the output directory.")
        return

    # Tab navigation
    tab1, tab2, tab3, tab4 = st.tabs([
        "📈 Overview",
        "🔍 Question Explorer",
        "📋 Analysis Report",
        "🧹 Cleansing Report"
    ])

    # Tab 1: Overview
    with tab1:
        st.header("Overview Statistics")

        # Key metrics
        col1, col2, col3, col4 = st.columns(4)

        id_col = df.columns[0]  # Assume first column is ID
        question_col = "semantic_cluster" if "semantic_cluster" in df.columns else "question"

        with col1:
            st.metric("Total Rows", f"{df[id_col].nunique():,}")

        with col2:
            st.metric("Unique Questions", f"{df[question_col].nunique():,}")

        with col3:
            avg_q = len(df) / df[id_col].nunique() if df[id_col].nunique() > 0 else 0
            st.metric("Avg Questions/Row", f"{avg_q:.1f}")

        with col4:
            st.metric("Total Mentions", f"{len(df):,}")

        st.divider()

        # Question frequency chart
        st.subheader("Top Questions by Frequency")

        freq_df = (
            df.groupby(question_col)[id_col]
            .nunique()
            .reset_index()
            .rename(columns={id_col: "count"})
            .sort_values("count", ascending=False)
            .head(20)
        )

        st.bar_chart(freq_df.set_index(question_col)["count"])

        # Frequency table
        st.subheader("Question Frequency Table")
        freq_df["percentage"] = (freq_df["count"] / df[id_col].nunique() * 100).round(1)
        freq_df.columns = ["Question", "Row Count", "Percentage (%)"]
        st.dataframe(freq_df, use_container_width=True, hide_index=True)

    # Tab 2: Question Explorer
    with tab2:
        st.header("Question Explorer")

        # Search
        search_query = st.text_input("🔍 Search questions", placeholder="Enter keywords...")

        # Filters
        col1, col2 = st.columns(2)

        with col1:
            min_count = st.slider(
                "Minimum occurrences",
                min_value=1,
                max_value=int(df[question_col].value_counts().max()),
                value=1
            )

        # Apply filters
        question_counts = df[question_col].value_counts()
        filtered_questions = question_counts[question_counts >= min_count].index.tolist()

        if search_query:
            filtered_questions = [
                q for q in filtered_questions
                if search_query.lower() in str(q).lower()
            ]

        st.write(f"Showing {len(filtered_questions)} questions")

        # Question selector
        if filtered_questions:
            selected_question = st.selectbox(
                "Select a question to explore",
                options=filtered_questions,
                format_func=lambda x: f"{x} ({question_counts[x]} occurrences)"
            )

            if selected_question:
                st.subheader(f"📝 {selected_question}")

                # Show related original questions if available
                question_df = df[df[question_col] == selected_question]

                st.write(f"**Appears in {question_df[id_col].nunique()} conversations**")

                # Show mappings if original question column exists
                if "question" in df.columns and question_col != "question":
                    original_questions = question_df["question"].unique()
                    with st.expander(f"View {len(original_questions)} original question variants"):
                        for q in original_questions[:50]:
                            st.write(f"• {q}")
                        if len(original_questions) > 50:
                            st.write(f"... and {len(original_questions) - 50} more")

                # Show sample rows
                with st.expander("View sample conversation IDs"):
                    sample_ids = question_df[id_col].head(20).tolist()
                    st.write(sample_ids)

    # Tab 3: Analysis Report
    with tab3:
        st.header("Analysis Report")
        if analysis_content:
            st.markdown(analysis_content)
        else:
            st.info("Analysis report not found. Run the pipeline to generate it.")

    # Tab 4: Cleansing Report
    with tab4:
        st.header("Data Cleansing Report")
        if cleansing_content:
            st.markdown(cleansing_content)
        else:
            st.info("Cleansing report not found. Run the pipeline to generate it.")

    # Footer
    st.divider()
    st.caption("Generated by Question Extractor")


if __name__ == "__main__":
    main()
'''


def generate_streamlit_app(output_dir: Optional[Path] = None) -> Path:
    """Generate a Streamlit app file for exploring results.

    Args:
        output_dir: Directory to save the app file

    Returns:
        Path to the generated app file
    """
    if output_dir is None:
        output_dir = Path("output")

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    app_path = output_dir / "app.py"
    app_path.write_text(STREAMLIT_APP_CODE)

    return app_path


def get_launch_command(app_path: Path) -> str:
    """Get the command to launch the Streamlit app.

    Args:
        app_path: Path to the Streamlit app file

    Returns:
        Command string to launch the app
    """
    return f"streamlit run {app_path}"
