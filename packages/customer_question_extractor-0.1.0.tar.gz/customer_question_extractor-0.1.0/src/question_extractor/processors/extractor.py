"""Question and topic extraction from summarized text."""
from __future__ import annotations


import asyncio
import json
import logging
import re
from typing import Optional

import pandas as pd
from rich.progress import Progress, TaskID

from question_extractor.config import Config
from question_extractor.utils.llm import LLMClient

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are an expert at identifying customer questions and concerns from service conversations.
Your task is to extract all distinct questions, concerns, or requests the customer is making.

Rules:
1. Extract each unique question or concern as a separate item
2. Rephrase implicit questions as explicit questions
3. Combine redundant questions that ask the same thing
4. Ignore agent responses, focus only on customer needs
5. Output valid JSON array format

Example output:
["How do I reset my password?", "Why was I charged twice?", "Can I get a refund?"]

If no questions found, output: []"""

USER_PROMPT_TEMPLATE = """Extract all customer questions and concerns from this conversation:

---
{text}
---

Output as a JSON array of questions:"""


class QuestionExtractor:
    """Extracts distinct questions and topics from text."""

    def __init__(self, config: Config, llm_client: Optional[LLMClient] = None):
        self.config = config
        self.llm = llm_client or LLMClient(config)

    def _parse_questions(self, response: str) -> list[str]:
        """Parse LLM response into list of questions.

        Args:
            response: Raw LLM response

        Returns:
            List of extracted questions
        """
        if not response:
            return []

        # Try to extract JSON array from response
        try:
            # Look for JSON array pattern
            match = re.search(r'\[.*\]', response, re.DOTALL)
            if match:
                questions = json.loads(match.group())
                if isinstance(questions, list):
                    return [q.strip() for q in questions if isinstance(q, str) and q.strip()]
        except json.JSONDecodeError:
            pass

        # Fallback: try to parse as newline-separated questions
        lines = response.strip().split('\n')
        questions = []
        for line in lines:
            # Remove common prefixes like "- ", "1. ", "* "
            cleaned = re.sub(r'^[\d\.\-\*\s]+', '', line).strip()
            if cleaned and not cleaned.startswith('[') and not cleaned.startswith(']'):
                questions.append(cleaned)

        return questions

    def extract(self, text: str) -> list[str]:
        """Extract questions from a single text.

        Args:
            text: Text to extract questions from

        Returns:
            List of extracted questions
        """
        if not text or not text.strip():
            return []

        prompt = USER_PROMPT_TEMPLATE.format(text=text)
        response = self.llm.complete(
            prompt=prompt,
            system_prompt=SYSTEM_PROMPT,
            max_tokens=512,
            temperature=0.3,
        )
        return self._parse_questions(response)

    async def extract_async(self, text: str) -> list[str]:
        """Extract questions from a single text asynchronously.

        Args:
            text: Text to extract questions from

        Returns:
            List of extracted questions
        """
        if not text or not text.strip():
            return []

        prompt = USER_PROMPT_TEMPLATE.format(text=text)
        response = await self.llm.complete_async(
            prompt=prompt,
            system_prompt=SYSTEM_PROMPT,
            max_tokens=512,
            temperature=0.3,
        )
        return self._parse_questions(response)

    async def extract_batch(
        self,
        texts: list[str],
        progress: Optional[Progress] = None,
        task_id: Optional[TaskID] = None,
    ) -> list[list[str]]:
        """Extract questions from multiple texts concurrently.

        Args:
            texts: List of texts to process
            progress: Optional Rich progress bar
            task_id: Optional task ID for progress tracking

        Returns:
            List of question lists (one per input text)
        """
        prompts = [
            USER_PROMPT_TEMPLATE.format(text=text) if text and text.strip() else ""
            for text in texts
        ]

        # Filter out empty prompts
        non_empty = [(i, p) for i, p in enumerate(prompts) if p]
        if not non_empty:
            return [[]] * len(texts)

        non_empty_prompts = [p for _, p in non_empty]
        responses = await self.llm.batch_complete(
            prompts=non_empty_prompts,
            system_prompt=SYSTEM_PROMPT,
            max_tokens=512,
            temperature=0.3,
        )

        # Reconstruct full results list
        full_results: list[list[str]] = [[]] * len(texts)
        for (original_idx, _), response in zip(non_empty, responses):
            full_results[original_idx] = self._parse_questions(response)

        if progress and task_id is not None:
            progress.update(task_id, advance=len(texts))

        return full_results

    def extract_from_dataframe(
        self,
        df: pd.DataFrame,
        text_column: Optional[str] = None,
        output_column: str = "questions_extracted",
    ) -> pd.DataFrame:
        """Extract questions from all texts in a DataFrame.

        Args:
            df: Input DataFrame
            text_column: Column containing text (defaults to config)
            output_column: Name for output column

        Returns:
            DataFrame with added questions column (lists)
        """
        text_column = text_column or self.config.text_column

        if text_column not in df.columns:
            raise ValueError(f"Column '{text_column}' not found in DataFrame")

        df = df.copy()
        texts = df[text_column].fillna("").tolist()

        # Process in batches using async
        questions_lists = asyncio.run(self.extract_batch(texts))
        df[output_column] = questions_lists

        return df

    def estimate_tokens(self, texts: list[str]) -> dict[str, int]:
        """Estimate token usage for question extraction.

        Args:
            texts: List of texts to estimate

        Returns:
            Dictionary with token estimates
        """
        input_tokens = sum(self.llm.count_tokens(text) for text in texts if text)
        # Estimate output tokens ~20% of input (questions are shorter than full text)
        estimated_output_tokens = int(input_tokens * 0.2)

        return {
            "input_tokens": input_tokens,
            "estimated_output_tokens": estimated_output_tokens,
            "total_estimated_tokens": input_tokens + estimated_output_tokens,
        }
