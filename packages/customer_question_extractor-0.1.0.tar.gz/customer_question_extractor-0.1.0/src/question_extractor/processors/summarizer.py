"""Text summarization to remove fillers and extract key content."""
from __future__ import annotations


import asyncio
import logging
from typing import Optional

import pandas as pd
from rich.progress import Progress, TaskID

from question_extractor.config import Config
from question_extractor.utils.llm import LLMClient

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are a text processing assistant that cleans and summarizes customer service conversations.
Your task is to:
1. Remove filler words, hesitations, and verbal tics (um, uh, like, you know, etc.)
2. Remove pleasantries and small talk that don't contain substantive information
3. Preserve all customer questions, concerns, and requests
4. Maintain the original meaning and intent
5. Output a clean, concise version of the text

Only output the cleaned text, no explanations or commentary."""

USER_PROMPT_TEMPLATE = """Clean and summarize the following customer service text, removing fillers and extracting key content:

---
{text}
---

Output only the cleaned, summarized text:"""


class Summarizer:
    """Summarizes text by removing fillers and extracting key content."""

    def __init__(self, config: Config, llm_client: Optional[LLMClient] = None):
        self.config = config
        self.llm = llm_client or LLMClient(config)

    def summarize(self, text: str) -> str:
        """Summarize a single text string.

        Args:
            text: Raw text to summarize

        Returns:
            Cleaned, summarized text
        """
        if not text or not text.strip():
            return ""

        prompt = USER_PROMPT_TEMPLATE.format(text=text)
        return self.llm.complete(
            prompt=prompt,
            system_prompt=SYSTEM_PROMPT,
            max_tokens=1024,
            temperature=0.3,
        )

    async def summarize_async(self, text: str) -> str:
        """Summarize a single text string asynchronously.

        Args:
            text: Raw text to summarize

        Returns:
            Cleaned, summarized text
        """
        if not text or not text.strip():
            return ""

        prompt = USER_PROMPT_TEMPLATE.format(text=text)
        return await self.llm.complete_async(
            prompt=prompt,
            system_prompt=SYSTEM_PROMPT,
            max_tokens=1024,
            temperature=0.3,
        )

    async def summarize_batch(
        self,
        texts: list[str],
        progress: Optional[Progress] = None,
        task_id: Optional[TaskID] = None,
    ) -> list[str]:
        """Summarize multiple texts concurrently.

        Args:
            texts: List of texts to summarize
            progress: Optional Rich progress bar
            task_id: Optional task ID for progress tracking

        Returns:
            List of summarized texts
        """
        prompts = [
            USER_PROMPT_TEMPLATE.format(text=text) if text and text.strip() else ""
            for text in texts
        ]

        # Filter out empty prompts but track their indices
        non_empty = [(i, p) for i, p in enumerate(prompts) if p]
        if not non_empty:
            return [""] * len(texts)

        non_empty_prompts = [p for _, p in non_empty]
        results = await self.llm.batch_complete(
            prompts=non_empty_prompts,
            system_prompt=SYSTEM_PROMPT,
            max_tokens=1024,
            temperature=0.3,
        )

        # Reconstruct full results list
        full_results = [""] * len(texts)
        for (original_idx, _), result in zip(non_empty, results):
            full_results[original_idx] = result

        if progress and task_id is not None:
            progress.update(task_id, advance=len(texts))

        return full_results

    def summarize_dataframe(
        self,
        df: pd.DataFrame,
        text_column: Optional[str] = None,
        output_column: str = "text_summarized",
    ) -> pd.DataFrame:
        """Summarize all texts in a DataFrame.

        Args:
            df: Input DataFrame
            text_column: Column containing text (defaults to config)
            output_column: Name for output column

        Returns:
            DataFrame with added summary column
        """
        text_column = text_column or self.config.text_column

        if text_column not in df.columns:
            raise ValueError(f"Column '{text_column}' not found in DataFrame")

        df = df.copy()
        texts = df[text_column].fillna("").tolist()

        # Process in batches using async
        summaries = asyncio.run(self.summarize_batch(texts))
        df[output_column] = summaries

        return df

    def estimate_tokens(self, texts: list[str]) -> dict[str, int]:
        """Estimate token usage for summarization.

        Args:
            texts: List of texts to estimate

        Returns:
            Dictionary with token estimates
        """
        input_tokens = sum(self.llm.count_tokens(text) for text in texts if text)
        # Estimate output tokens as ~50% of input (summarization reduces text)
        estimated_output_tokens = int(input_tokens * 0.5)

        return {
            "input_tokens": input_tokens,
            "estimated_output_tokens": estimated_output_tokens,
            "total_estimated_tokens": input_tokens + estimated_output_tokens,
        }
