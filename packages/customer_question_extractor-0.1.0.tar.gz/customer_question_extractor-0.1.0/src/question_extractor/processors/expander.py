"""Table expansion to row_id and question_id level."""
from __future__ import annotations


import logging
from typing import Optional

import pandas as pd

from question_extractor.config import Config

logger = logging.getLogger(__name__)


class TableExpander:
    """Expands DataFrame from row level to row_id + question_id level."""

    def __init__(self, config: Config):
        self.config = config

    def expand(
        self,
        df: pd.DataFrame,
        id_column: Optional[str] = None,
        questions_column: str = "questions_extracted",
        output_question_col: str = "question",
        output_question_id_col: str = "question_id",
    ) -> pd.DataFrame:
        """Expand DataFrame so each question is its own row.

        Args:
            df: Input DataFrame with questions as lists
            id_column: Row ID column (defaults to config)
            questions_column: Column containing question lists
            output_question_col: Name for expanded question column
            output_question_id_col: Name for question ID column

        Returns:
            Expanded DataFrame with one row per question
        """
        id_column = id_column or self.config.id_column

        if id_column not in df.columns:
            raise ValueError(f"ID column '{id_column}' not found in DataFrame")
        if questions_column not in df.columns:
            raise ValueError(f"Questions column '{questions_column}' not found in DataFrame")

        # Explode the questions column
        df_expanded = df.explode(questions_column).reset_index(drop=True)
        df_expanded = df_expanded.rename(columns={questions_column: output_question_col})

        # Remove rows with empty/null questions
        df_expanded = df_expanded[
            df_expanded[output_question_col].notna()
            & (df_expanded[output_question_col] != "")
        ].reset_index(drop=True)

        # Add question_id within each row_id
        df_expanded[output_question_id_col] = df_expanded.groupby(id_column).cumcount() + 1

        # Reorder columns to put IDs first
        id_cols = [id_column, output_question_id_col]
        other_cols = [c for c in df_expanded.columns if c not in id_cols]
        df_expanded = df_expanded[id_cols + other_cols]

        logger.info(
            f"Expanded {len(df)} rows to {len(df_expanded)} question rows"
        )

        return df_expanded

    def get_expansion_stats(
        self,
        df_original: pd.DataFrame,
        df_expanded: pd.DataFrame,
        id_column: Optional[str] = None,
    ) -> dict:
        """Get statistics about the expansion.

        Args:
            df_original: Original DataFrame before expansion
            df_expanded: Expanded DataFrame
            id_column: Row ID column

        Returns:
            Dictionary with expansion statistics
        """
        id_column = id_column or self.config.id_column

        original_rows = len(df_original)
        expanded_rows = len(df_expanded)
        unique_row_ids = df_expanded[id_column].nunique()

        questions_per_row = df_expanded.groupby(id_column).size()

        return {
            "original_rows": original_rows,
            "expanded_rows": expanded_rows,
            "unique_row_ids": unique_row_ids,
            "rows_with_questions": unique_row_ids,
            "rows_without_questions": original_rows - unique_row_ids,
            "questions_per_row_mean": float(questions_per_row.mean()),
            "questions_per_row_median": float(questions_per_row.median()),
            "questions_per_row_max": int(questions_per_row.max()),
            "questions_per_row_min": int(questions_per_row.min()),
            "expansion_ratio": expanded_rows / original_rows if original_rows > 0 else 0,
        }
