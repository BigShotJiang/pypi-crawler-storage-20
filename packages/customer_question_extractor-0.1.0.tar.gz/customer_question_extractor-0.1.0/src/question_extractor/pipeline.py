"""Main pipeline orchestration for Question Extractor."""
from __future__ import annotations


import asyncio
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import pandas as pd
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

from question_extractor.config import Config
from question_extractor.estimator import Estimator, CostEstimate
from question_extractor.processors import Summarizer, QuestionExtractor, TableExpander
from question_extractor.deduplication import FuzzyMatcher, SemanticClusterer, QuestionConsolidator
from question_extractor.analysis import DataAggregator, ReportGenerator
from question_extractor.analysis.streamlit_app import generate_streamlit_app
from question_extractor.utils.llm import LLMClient
from question_extractor.utils.embeddings import EmbeddingsClient
from question_extractor.utils.io import read_csv_full, write_csv

logger = logging.getLogger(__name__)
console = Console()


@dataclass
class PipelineStats:
    """Statistics collected during pipeline execution."""

    input_rows: int = 0
    rows_with_text: int = 0
    questions_extracted: int = 0
    unique_questions_before: int = 0
    after_fuzzy: int = 0
    after_semantic: int = 0
    final_unique: int = 0
    fuzzy_reduction_rate: float = 0.0
    semantic_reduction_rate: float = 0.0
    questions_clustered: int = 0
    clusters_created: int = 0
    avg_questions_per_row: float = 0.0
    rows_no_questions: int = 0
    processing_time: float = 0.0
    errors: list = field(default_factory=list)

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "input_rows": self.input_rows,
            "rows_with_text": self.rows_with_text,
            "questions_extracted": self.questions_extracted,
            "unique_questions_before": self.unique_questions_before,
            "after_fuzzy": self.after_fuzzy,
            "after_semantic": self.after_semantic,
            "final_unique": self.final_unique,
            "fuzzy_reduction_rate": self.fuzzy_reduction_rate,
            "semantic_reduction_rate": self.semantic_reduction_rate,
            "questions_clustered": self.questions_clustered,
            "clusters_created": self.clusters_created,
            "avg_questions_per_row": self.avg_questions_per_row,
            "rows_no_questions": self.rows_no_questions,
            "processing_time": self.processing_time,
            "errors": self.errors,
        }


@dataclass
class PipelineResult:
    """Result of pipeline execution."""

    df: pd.DataFrame
    stats: PipelineStats
    output_paths: dict[str, Path] = field(default_factory=dict)


class Pipeline:
    """Main pipeline for question extraction and deduplication."""

    def __init__(self, config: Optional[Config] = None):
        """Initialize the pipeline.

        Args:
            config: Configuration settings (creates default if not provided)
        """
        self.config = config or Config()

        # Initialize shared clients
        self.llm = LLMClient(self.config)
        self.embeddings = EmbeddingsClient(self.config)

        # Initialize components
        self.estimator = Estimator(self.config, self.llm)
        self.summarizer = Summarizer(self.config, self.llm)
        self.extractor = QuestionExtractor(self.config, self.llm)
        self.expander = TableExpander(self.config)
        self.fuzzy = FuzzyMatcher(self.config)
        self.semantic = SemanticClusterer(self.config, self.embeddings)
        self.consolidator = QuestionConsolidator(self.config, self.llm)
        self.aggregator = DataAggregator(self.config)
        self.reporter = ReportGenerator(self.config, self.llm, self.aggregator)

    def estimate(
        self,
        input_path: Optional[Path | str] = None,
        df: Optional[pd.DataFrame] = None,
        sample_size: int = 100,
    ) -> CostEstimate:
        """Estimate cost and time for processing.

        Args:
            input_path: Path to input CSV file
            df: Input DataFrame (alternative to input_path)
            sample_size: Number of rows to sample for estimation

        Returns:
            CostEstimate with detailed breakdown
        """
        if input_path:
            return self.estimator.estimate_from_file(Path(input_path), sample_size)
        elif df is not None:
            return self.estimator.estimate_from_dataframe(df, sample_size)
        else:
            raise ValueError("Either input_path or df must be provided")

    def run(
        self,
        input_path: Optional[Path | str] = None,
        df: Optional[pd.DataFrame] = None,
        output_dir: Optional[Path | str] = None,
        skip_estimate: bool = False,
    ) -> PipelineResult:
        """Run the full pipeline.

        Args:
            input_path: Path to input CSV file
            df: Input DataFrame (alternative to input_path)
            output_dir: Output directory (defaults to config)
            skip_estimate: Skip cost estimation prompt

        Returns:
            PipelineResult with processed data and statistics
        """
        start_time = time.time()
        stats = PipelineStats()

        # Set output directory
        if output_dir:
            self.config.output_dir = Path(output_dir)

        # Load data
        console.print("[bold blue]Loading data...[/bold blue]")
        if input_path:
            df = read_csv_full(Path(input_path))
        elif df is None:
            raise ValueError("Either input_path or df must be provided")

        stats.input_rows = len(df)
        stats.rows_with_text = df[self.config.text_column].notna().sum()

        console.print(f"Loaded {stats.input_rows:,} rows ({stats.rows_with_text:,} with text)")

        # Run pipeline steps
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            # Step 1: Summarization
            task = progress.add_task("[cyan]Summarizing text...", total=stats.input_rows)
            df = self.summarizer.summarize_dataframe(df, output_column="text_summarized")
            progress.update(task, completed=stats.input_rows)

            # Step 2: Question extraction
            task = progress.add_task("[cyan]Extracting questions...", total=stats.input_rows)
            df = self.extractor.extract_from_dataframe(
                df, text_column="text_summarized", output_column="questions_extracted"
            )
            progress.update(task, completed=stats.input_rows)

            # Step 3: Table expansion
            task = progress.add_task("[cyan]Expanding table...", total=1)
            df_expanded = self.expander.expand(df)
            stats.questions_extracted = len(df_expanded)
            stats.unique_questions_before = df_expanded["question"].nunique()
            stats.avg_questions_per_row = stats.questions_extracted / stats.input_rows
            stats.rows_no_questions = stats.input_rows - df_expanded[self.config.id_column].nunique()
            progress.update(task, completed=1)

            # Step 4: Fuzzy deduplication
            task = progress.add_task("[cyan]Fuzzy deduplication...", total=1)
            df_expanded = self.fuzzy.deduplicate_dataframe(df_expanded)
            stats.after_fuzzy = df_expanded["fuzzy_representative"].nunique()
            stats.fuzzy_reduction_rate = 1 - (stats.after_fuzzy / stats.unique_questions_before)
            progress.update(task, completed=1)

            # Step 5: Semantic clustering
            task = progress.add_task("[cyan]Semantic clustering...", total=1)
            df_expanded, clusters = self.semantic.cluster_dataframe(df_expanded)
            stats.questions_clustered = df_expanded["semantic_cluster_id"].notna().sum()
            stats.clusters_created = len(clusters)
            progress.update(task, completed=1)

            # Step 6: LLM consolidation
            task = progress.add_task("[cyan]Consolidating clusters...", total=1)
            df_expanded = self.consolidator.consolidate_dataframe(df_expanded, clusters)
            stats.after_semantic = df_expanded["semantic_cluster"].nunique()
            stats.final_unique = stats.after_semantic
            stats.semantic_reduction_rate = 1 - (stats.after_semantic / stats.after_fuzzy)
            progress.update(task, completed=1)

        # Calculate processing time
        stats.processing_time = (time.time() - start_time) / 60  # minutes

        # Save outputs
        console.print("\n[bold blue]Saving outputs...[/bold blue]")
        output_paths = self._save_outputs(df_expanded, stats)

        result = PipelineResult(
            df=df_expanded,
            stats=stats,
            output_paths=output_paths,
        )

        # Print summary
        self._print_summary(stats)

        return result

    def _save_outputs(
        self,
        df: pd.DataFrame,
        stats: PipelineStats,
    ) -> dict[str, Path]:
        """Save all output files.

        Args:
            df: Processed DataFrame
            stats: Processing statistics

        Returns:
            Dictionary mapping output type to file path
        """
        output_dir = self.config.output_dir
        output_dir.mkdir(parents=True, exist_ok=True)

        paths = {}

        # Save clean.csv
        clean_csv_path = output_dir / "clean.csv"
        output_columns = [
            self.config.id_column,
            "question_id",
            "question",
            "fuzzy_representative",
            "semantic_cluster",
        ]
        available_columns = [c for c in output_columns if c in df.columns]
        write_csv(df[available_columns], clean_csv_path)
        paths["clean_csv"] = clean_csv_path

        # Generate reports
        report_paths = self.reporter.save_reports(df, stats.to_dict(), output_dir)
        paths.update(report_paths)

        # Generate Streamlit app
        app_path = generate_streamlit_app(output_dir)
        paths["streamlit_app"] = app_path

        return paths

    def _print_summary(self, stats: PipelineStats) -> None:
        """Print processing summary.

        Args:
            stats: Processing statistics
        """
        console.print("\n" + "=" * 50)
        console.print("[bold green]PROCESSING COMPLETE[/bold green]")
        console.print("=" * 50)
        console.print(f"\n[bold]Input:[/bold] {stats.input_rows:,} rows")
        console.print(f"[bold]Questions extracted:[/bold] {stats.questions_extracted:,}")
        console.print(f"[bold]Unique questions:[/bold] {stats.unique_questions_before:,}")
        console.print(f"[bold]After fuzzy dedup:[/bold] {stats.after_fuzzy:,} ({stats.fuzzy_reduction_rate*100:.1f}% reduction)")
        console.print(f"[bold]After semantic clustering:[/bold] {stats.final_unique:,} ({stats.semantic_reduction_rate*100:.1f}% additional reduction)")
        console.print(f"\n[bold]Processing time:[/bold] {stats.processing_time:.1f} minutes")
        console.print(f"\n[bold]Output directory:[/bold] {self.config.output_dir}")
        console.print("\nTo view the dashboard, run:")
        console.print(f"  [cyan]streamlit run {self.config.output_dir}/app.py[/cyan]")
