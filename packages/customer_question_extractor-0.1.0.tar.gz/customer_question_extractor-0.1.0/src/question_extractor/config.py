"""Configuration management for Question Extractor."""
from __future__ import annotations


from pathlib import Path
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Config(BaseSettings):
    """Configuration settings for the question extraction pipeline."""

    model_config = SettingsConfigDict(
        env_prefix="QE_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # OpenAI settings
    openai_api_key: str = Field(default="", description="OpenAI API key")
    llm_model: str = Field(default="gpt-5-mini", description="LLM model for text processing")
    embedding_model: str = Field(
        default="text-embedding-3-small", description="Model for generating embeddings"
    )

    # Column configuration
    text_column: str = Field(default="text", description="Column containing text to process")
    id_column: str = Field(default="row_id", description="Column containing unique row identifier")

    # Processing settings
    batch_size: int = Field(default=50, description="Batch size for LLM calls")
    max_concurrent_requests: int = Field(default=5, description="Max concurrent API requests")
    chunk_size: int = Field(default=10000, description="Chunk size for reading large CSVs")

    # Deduplication thresholds
    fuzzy_threshold: float = Field(
        default=0.75, ge=0.0, le=1.0, description="RapidFuzz similarity threshold"
    )
    semantic_distance_threshold: float = Field(
        default=0.7, ge=0.0, le=2.0, description="Agglomerative clustering distance threshold"
    )
    top_questions_percentile: float = Field(
        default=0.75,
        ge=0.0,
        le=1.0,
        description="Percentile of questions by volume to include in semantic clustering",
    )

    # Clustering settings
    clustering_linkage: str = Field(
        default="average", description="Linkage method for agglomerative clustering"
    )
    clustering_metric: str = Field(
        default="euclidean", description="Distance metric for clustering"
    )

    # Output settings
    output_dir: Path = Field(default=Path("output"), description="Directory for output files")

    # Cost estimation (prices per 1M tokens as of 2024)
    gpt4o_input_price: float = Field(default=2.50, description="GPT-4o input price per 1M tokens")
    gpt4o_output_price: float = Field(default=10.00, description="GPT-4o output price per 1M tokens")
    embedding_price: float = Field(
        default=0.02, description="Embedding price per 1M tokens"
    )

    def get_output_path(self, filename: str) -> Path:
        """Get full path for an output file."""
        self.output_dir.mkdir(parents=True, exist_ok=True)
        return self.output_dir / filename
