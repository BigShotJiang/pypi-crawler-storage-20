"""Question Extractor - Extract and deduplicate customer questions from text data."""

from question_extractor.config import Config
from question_extractor.pipeline import Pipeline

__version__ = "0.1.0"
__all__ = ["Config", "Pipeline", "__version__"]
