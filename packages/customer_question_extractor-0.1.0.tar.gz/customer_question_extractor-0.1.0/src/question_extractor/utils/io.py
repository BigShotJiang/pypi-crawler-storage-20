"""I/O utilities for reading and writing files."""
from __future__ import annotations


import logging
from pathlib import Path
from typing import Iterator, Optional

import pandas as pd

logger = logging.getLogger(__name__)


def read_csv_chunked(
    file_path: Path | str,
    chunk_size: int = 10000,
    usecols: Optional[list[str]] = None,
    dtype: Optional[dict] = None,
) -> Iterator[pd.DataFrame]:
    """Read a CSV file in chunks for memory-efficient processing.

    Args:
        file_path: Path to the CSV file
        chunk_size: Number of rows per chunk
        usecols: Columns to read (None for all)
        dtype: Column data types

    Yields:
        DataFrame chunks
    """
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    logger.info(f"Reading CSV in chunks of {chunk_size}: {file_path}")

    with pd.read_csv(
        file_path,
        chunksize=chunk_size,
        usecols=usecols,
        dtype=dtype,
        low_memory=True,
    ) as reader:
        for i, chunk in enumerate(reader):
            logger.debug(f"Read chunk {i + 1} with {len(chunk)} rows")
            yield chunk


def read_csv_full(
    file_path: Path | str,
    usecols: Optional[list[str]] = None,
    dtype: Optional[dict] = None,
) -> pd.DataFrame:
    """Read an entire CSV file into memory.

    Args:
        file_path: Path to the CSV file
        usecols: Columns to read (None for all)
        dtype: Column data types

    Returns:
        DataFrame with all data
    """
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    logger.info(f"Reading full CSV: {file_path}")
    df = pd.read_csv(file_path, usecols=usecols, dtype=dtype)
    logger.info(f"Loaded {len(df)} rows")
    return df


def count_csv_rows(file_path: Path | str) -> int:
    """Count the number of rows in a CSV file efficiently.

    Args:
        file_path: Path to the CSV file

    Returns:
        Number of data rows (excluding header)
    """
    file_path = Path(file_path)
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    # Count lines efficiently without loading entire file
    with open(file_path, "rb") as f:
        count = sum(1 for _ in f)
    return max(0, count - 1)  # Subtract header row


def sample_csv_rows(
    file_path: Path | str,
    n: int = 100,
    random_state: int = 42,
) -> pd.DataFrame:
    """Sample rows from a CSV file.

    Args:
        file_path: Path to the CSV file
        n: Number of rows to sample
        random_state: Random seed for reproducibility

    Returns:
        DataFrame with sampled rows
    """
    file_path = Path(file_path)
    total_rows = count_csv_rows(file_path)

    if total_rows <= n:
        return read_csv_full(file_path)

    # Read full file and sample
    df = read_csv_full(file_path)
    return df.sample(n=min(n, len(df)), random_state=random_state)


def write_csv(
    df: pd.DataFrame,
    file_path: Path | str,
    index: bool = False,
) -> None:
    """Write a DataFrame to a CSV file.

    Args:
        df: DataFrame to write
        file_path: Output path
        index: Whether to include row index
    """
    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)

    df.to_csv(file_path, index=index)
    logger.info(f"Wrote {len(df)} rows to {file_path}")


def write_markdown(
    content: str,
    file_path: Path | str,
) -> None:
    """Write markdown content to a file.

    Args:
        content: Markdown content
        file_path: Output path
    """
    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)

    with open(file_path, "w") as f:
        f.write(content)
    logger.info(f"Wrote markdown to {file_path}")


def write_html(
    content: str,
    file_path: Path | str,
) -> None:
    """Write HTML content to a file.

    Args:
        content: HTML content
        file_path: Output path
    """
    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)

    with open(file_path, "w") as f:
        f.write(content)
    logger.info(f"Wrote HTML to {file_path}")
