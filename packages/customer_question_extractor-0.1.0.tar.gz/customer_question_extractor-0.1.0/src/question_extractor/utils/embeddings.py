"""OpenAI embeddings wrapper with caching support."""
from __future__ import annotations


import asyncio
import hashlib
import json
import logging
from pathlib import Path
from typing import Optional

import numpy as np
from openai import AsyncOpenAI, OpenAI

from question_extractor.config import Config

logger = logging.getLogger(__name__)


class EmbeddingsClient:
    """Client for generating and caching OpenAI embeddings."""

    def __init__(self, config: Config, cache_dir: Optional[Path] = None):
        self.config = config
        self.client = OpenAI(api_key=config.openai_api_key)
        self.async_client = AsyncOpenAI(api_key=config.openai_api_key)
        self.cache_dir = cache_dir or config.output_dir / ".embedding_cache"
        self._cache: dict[str, list[float]] = {}

    def _get_cache_key(self, text: str) -> str:
        """Generate a cache key for a text string."""
        return hashlib.md5(text.encode()).hexdigest()

    def _load_cache(self) -> None:
        """Load embeddings cache from disk."""
        cache_file = self.cache_dir / "embeddings_cache.json"
        if cache_file.exists():
            try:
                with open(cache_file) as f:
                    self._cache = json.load(f)
                logger.info(f"Loaded {len(self._cache)} cached embeddings")
            except Exception as e:
                logger.warning(f"Failed to load cache: {e}")
                self._cache = {}

    def _save_cache(self) -> None:
        """Save embeddings cache to disk."""
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = self.cache_dir / "embeddings_cache.json"
        try:
            with open(cache_file, "w") as f:
                json.dump(self._cache, f)
            logger.info(f"Saved {len(self._cache)} embeddings to cache")
        except Exception as e:
            logger.warning(f"Failed to save cache: {e}")

    def get_embedding(self, text: str, use_cache: bool = True) -> list[float]:
        """Get embedding for a single text string."""
        if use_cache:
            cache_key = self._get_cache_key(text)
            if cache_key in self._cache:
                return self._cache[cache_key]

        response = self.client.embeddings.create(
            model=self.config.embedding_model,
            input=text,
        )
        embedding = response.data[0].embedding

        if use_cache:
            self._cache[cache_key] = embedding

        return embedding

    async def get_embedding_async(self, text: str, use_cache: bool = True) -> list[float]:
        """Get embedding for a single text string asynchronously."""
        if use_cache:
            cache_key = self._get_cache_key(text)
            if cache_key in self._cache:
                return self._cache[cache_key]

        response = await self.async_client.embeddings.create(
            model=self.config.embedding_model,
            input=text,
        )
        embedding = response.data[0].embedding

        if use_cache:
            self._cache[cache_key] = embedding

        return embedding

    def get_embeddings_batch(
        self, texts: list[str], use_cache: bool = True, batch_size: int = 100
    ) -> np.ndarray:
        """Get embeddings for multiple texts with batching."""
        if not texts:
            return np.array([])

        embeddings = []
        texts_to_fetch: list[tuple[int, str]] = []

        # Check cache first
        for i, text in enumerate(texts):
            if use_cache:
                cache_key = self._get_cache_key(text)
                if cache_key in self._cache:
                    embeddings.append((i, self._cache[cache_key]))
                    continue
            texts_to_fetch.append((i, text))

        # Fetch missing embeddings in batches
        for batch_start in range(0, len(texts_to_fetch), batch_size):
            batch = texts_to_fetch[batch_start : batch_start + batch_size]
            batch_texts = [t[1] for t in batch]

            try:
                response = self.client.embeddings.create(
                    model=self.config.embedding_model,
                    input=batch_texts,
                )
                for j, emb_data in enumerate(response.data):
                    idx = batch[j][0]
                    text = batch[j][1]
                    embedding = emb_data.embedding

                    if use_cache:
                        cache_key = self._get_cache_key(text)
                        self._cache[cache_key] = embedding

                    embeddings.append((idx, embedding))

            except Exception as e:
                logger.error(f"Error fetching embeddings batch: {e}")
                # Return empty embeddings for failed texts
                for idx, _ in batch:
                    embeddings.append((idx, [0.0] * 1536))

        # Sort by original index and extract embeddings
        embeddings.sort(key=lambda x: x[0])
        return np.array([e[1] for e in embeddings])

    async def get_embeddings_batch_async(
        self,
        texts: list[str],
        use_cache: bool = True,
        max_concurrent: int = 5,
    ) -> np.ndarray:
        """Get embeddings for multiple texts asynchronously."""
        if not texts:
            return np.array([])

        results: dict[int, list[float]] = {}
        texts_to_fetch: list[tuple[int, str]] = []

        # Check cache first
        for i, text in enumerate(texts):
            if use_cache:
                cache_key = self._get_cache_key(text)
                if cache_key in self._cache:
                    results[i] = self._cache[cache_key]
                    continue
            texts_to_fetch.append((i, text))

        # Fetch missing embeddings concurrently
        semaphore = asyncio.Semaphore(max_concurrent)

        async def fetch_single(idx: int, text: str) -> tuple[int, list[float]]:
            async with semaphore:
                try:
                    embedding = await self.get_embedding_async(text, use_cache=use_cache)
                    return idx, embedding
                except Exception as e:
                    logger.error(f"Error fetching embedding: {e}")
                    return idx, [0.0] * 1536

        tasks = [fetch_single(idx, text) for idx, text in texts_to_fetch]
        fetched = await asyncio.gather(*tasks)

        for idx, embedding in fetched:
            results[idx] = embedding

        # Sort by index and return as numpy array
        sorted_results = [results[i] for i in range(len(texts))]
        return np.array(sorted_results)

    def normalize_embeddings(self, embeddings: np.ndarray) -> np.ndarray:
        """Normalize embeddings to unit vectors."""
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1, norms)
        return embeddings / norms

    def estimate_cost(self, num_texts: int, avg_tokens_per_text: int = 50) -> dict[str, float]:
        """Estimate cost for embedding a number of texts."""
        total_tokens = num_texts * avg_tokens_per_text
        cost = (total_tokens / 1_000_000) * self.config.embedding_price
        return {
            "num_texts": num_texts,
            "estimated_tokens": total_tokens,
            "estimated_cost": cost,
        }
