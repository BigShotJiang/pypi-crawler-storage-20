"""OpenAI LLM wrapper with retry logic and batch processing."""
from __future__ import annotations


import asyncio
import logging
from typing import Optional

from openai import AsyncOpenAI, OpenAI
import tiktoken

from question_extractor.config import Config

logger = logging.getLogger(__name__)


class LLMClient:
    """Client for interacting with OpenAI LLM models."""

    def __init__(self, config: Config):
        self.config = config
        self.client = OpenAI(api_key=config.openai_api_key)
        self.async_client = AsyncOpenAI(api_key=config.openai_api_key)
        self._encoder: Optional[tiktoken.Encoding] = None

    @property
    def encoder(self) -> tiktoken.Encoding:
        """Lazy load the tokenizer."""
        if self._encoder is None:
            try:
                self._encoder = tiktoken.encoding_for_model(self.config.llm_model)
            except KeyError:
                self._encoder = tiktoken.get_encoding("cl100k_base")
        return self._encoder

    def count_tokens(self, text: str) -> int:
        """Count tokens in a text string."""
        return len(self.encoder.encode(text))

    def complete(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 1024,
        temperature: float = 0.3,
    ) -> str:
        """Make a synchronous completion request."""
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        response = self.client.chat.completions.create(
            model=self.config.llm_model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return response.choices[0].message.content or ""

    async def complete_async(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 1024,
        temperature: float = 0.3,
    ) -> str:
        """Make an asynchronous completion request."""
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        response = await self.async_client.chat.completions.create(
            model=self.config.llm_model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
        )
        return response.choices[0].message.content or ""

    async def batch_complete(
        self,
        prompts: list[str],
        system_prompt: Optional[str] = None,
        max_tokens: int = 1024,
        temperature: float = 0.3,
        max_concurrent: Optional[int] = None,
    ) -> list[str]:
        """Process multiple prompts concurrently with rate limiting."""
        max_concurrent = max_concurrent or self.config.max_concurrent_requests
        semaphore = asyncio.Semaphore(max_concurrent)

        async def process_with_semaphore(prompt: str) -> str:
            async with semaphore:
                try:
                    return await self.complete_async(
                        prompt=prompt,
                        system_prompt=system_prompt,
                        max_tokens=max_tokens,
                        temperature=temperature,
                    )
                except Exception as e:
                    logger.error(f"Error processing prompt: {e}")
                    return ""

        tasks = [process_with_semaphore(prompt) for prompt in prompts]
        return await asyncio.gather(*tasks)

    def estimate_cost(
        self, input_tokens: int, output_tokens: int
    ) -> dict[str, float]:
        """Estimate cost for a given number of tokens."""
        input_cost = (input_tokens / 1_000_000) * self.config.gpt4o_input_price
        output_cost = (output_tokens / 1_000_000) * self.config.gpt4o_output_price
        return {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "input_cost": input_cost,
            "output_cost": output_cost,
            "total_cost": input_cost + output_cost,
        }
