# Publishing to PyPI

## Prerequisites

1. Create accounts on:
   - [PyPI](https://pypi.org/account/register/) (production)
   - [TestPyPI](https://test.pypi.org/account/register/) (testing)

2. Create API tokens:
   - Go to Account Settings > API tokens
   - Create a token scoped to "Entire account" (first time) or this specific project

3. Install build tools:
   ```bash
   pip install build twine
   ```

## Building the Package

```bash
# Clean previous builds
rm -rf dist/ build/

# Build source distribution and wheel
python -m build

# Verify the build
twine check dist/*
```

## Publishing

### Test on TestPyPI First (Recommended)

```bash
# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Test installation from TestPyPI
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ question-extractor
```

### Publish to Production PyPI

```bash
# Upload to PyPI
twine upload dist/*
```

When prompted:
- Username: `__token__`
- Password: Your API token (including the `pypi-` prefix)

## Alternative: Using .pypirc

Create `~/.pypirc` for stored credentials:

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR_TOKEN_HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR_TEST_TOKEN_HERE
```

Then upload without prompts:
```bash
twine upload --repository testpypi dist/*  # TestPyPI
twine upload dist/*                         # Production PyPI
```

## Version Bumping

Before each release:

1. Update version in `src/question_extractor/__init__.py`
2. Update version in `pyproject.toml`
3. Add release notes to `CHANGELOG.md`
4. Commit changes and tag the release:
   ```bash
   git add .
   git commit -m "Release v0.1.0"
   git tag v0.1.0
   git push origin main --tags
   ```

## Verifying the Release

After publishing:

```bash
# Install from PyPI
pip install question-extractor

# Verify version
python -c "import question_extractor; print(question_extractor.__version__)"

# Test CLI
question-extractor --help
```
