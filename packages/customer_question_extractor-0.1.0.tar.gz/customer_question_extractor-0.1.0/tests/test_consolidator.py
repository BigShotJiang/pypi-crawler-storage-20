"""Tests for question consolidator module."""

import pandas as pd
import pytest
from unittest.mock import MagicMock, patch, AsyncMock

from question_extractor.deduplication.consolidator import QuestionConsolidator


class TestQuestionConsolidator:
    """Tests for QuestionConsolidator class."""

    def test_consolidate_single_question(self, sample_config):
        """Test consolidation with single question returns as-is."""
        consolidator = QuestionConsolidator(sample_config)

        result = consolidator.consolidate(["How do I reset my password?"])

        assert result == "How do I reset my password?"

    def test_consolidate_empty(self, sample_config):
        """Test consolidation with empty list."""
        consolidator = QuestionConsolidator(sample_config)

        result = consolidator.consolidate([])

        assert result == ""

    def test_consolidate_multiple(self, sample_config, mock_llm_client):
        """Test consolidation with multiple questions."""
        consolidator = QuestionConsolidator(sample_config)

        # Mock the LLM response
        mock_response = MagicMock()
        mock_response.choices = [
            MagicMock(message=MagicMock(content="How do I reset my password?"))
        ]
        consolidator.llm.client.chat.completions.create.return_value = mock_response

        questions = [
            "How do I reset my password?",
            "Password reset help needed",
            "Can you help me reset my password?",
        ]

        result = consolidator.consolidate(questions)

        assert "password" in result.lower()

    def test_get_consolidation_stats(self, sample_config):
        """Test consolidation statistics."""
        consolidator = QuestionConsolidator(sample_config)

        df = pd.DataFrame({
            "question": ["Q1", "Q2", "Q3", "Q1", "Q2"],
            "fuzzy_representative": ["R1", "R1", "R2", "R1", "R1"],
            "semantic_cluster": ["C1", "C1", "C1", "C1", "C1"],
        })

        stats = consolidator.get_consolidation_stats(df)

        assert stats["original_unique_questions"] == 3
        assert stats["after_fuzzy_dedup"] == 2
        assert stats["after_semantic_clustering"] == 1
        assert stats["total_reduction_rate"] > 0

    def test_consolidate_dataframe(self, sample_config, mock_llm_client):
        """Test DataFrame consolidation."""
        consolidator = QuestionConsolidator(sample_config)

        df = pd.DataFrame({
            "row_id": [1, 2, 3],
            "fuzzy_representative": ["Q1", "Q2", "Q3"],
            "semantic_cluster_id": [0, 0, None],
        })

        clusters = {
            0: ["Q1", "Q2"],
        }

        # Mock async consolidation
        with patch.object(
            consolidator,
            "consolidate_clusters",
            return_value={0: "Consolidated Question"}
        ):
            import asyncio
            with patch("asyncio.run", return_value={0: "Consolidated Question"}):
                result_df = consolidator.consolidate_dataframe(df, clusters)

        assert "semantic_cluster" in result_df.columns
