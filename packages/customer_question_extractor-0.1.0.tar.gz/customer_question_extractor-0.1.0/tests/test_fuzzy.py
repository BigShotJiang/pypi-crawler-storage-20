"""Tests for fuzzy deduplication module."""

import pandas as pd
import pytest

from question_extractor.deduplication.fuzzy import FuzzyMatcher


class TestFuzzyMatcher:
    """Tests for FuzzyMatcher class."""

    def test_find_similar_basic(self, sample_config):
        """Test basic similarity matching."""
        matcher = FuzzyMatcher(sample_config)

        query = "How do I reset my password?"
        candidates = [
            "How can I reset my password?",
            "What is the refund policy?",
            "Password reset help needed",
        ]

        results = matcher.find_similar(query, candidates, threshold=70)

        assert len(results) >= 1
        # First result should be the most similar
        assert "password" in results[0][0].lower()

    def test_find_similar_empty(self, sample_config):
        """Test with empty inputs."""
        matcher = FuzzyMatcher(sample_config)

        assert matcher.find_similar("", ["test"]) == []
        assert matcher.find_similar("test", []) == []

    def test_group_similar(self, sample_config):
        """Test grouping similar questions."""
        matcher = FuzzyMatcher(sample_config)

        questions = [
            "How do I reset my password?",
            "How can I reset my password?",
            "Password reset help",
            "What is the refund policy?",
            "How do I get a refund?",
        ]

        groups = matcher.group_similar(questions)

        # Should have fewer groups than original questions
        assert len(groups) < len(questions)
        # Each group should have at least one member
        for members in groups.values():
            assert len(members) >= 1

    def test_deduplicate_dataframe(self, sample_config, expanded_df):
        """Test DataFrame deduplication."""
        matcher = FuzzyMatcher(sample_config)

        result_df = matcher.deduplicate_dataframe(
            expanded_df,
            question_column="question",
            output_column="fuzzy_representative",
        )

        assert "fuzzy_representative" in result_df.columns
        assert len(result_df) == len(expanded_df)
        # Should have fewer unique representatives than original questions
        assert result_df["fuzzy_representative"].nunique() <= result_df["question"].nunique()

    def test_get_dedup_stats(self, sample_config, expanded_df):
        """Test deduplication statistics."""
        matcher = FuzzyMatcher(sample_config)

        result_df = matcher.deduplicate_dataframe(
            expanded_df,
            question_column="question",
            output_column="fuzzy_representative",
        )

        stats = matcher.get_dedup_stats(
            result_df,
            question_column="question",
            representative_column="fuzzy_representative",
        )

        assert "original_unique_questions" in stats
        assert "deduplicated_unique_questions" in stats
        assert "reduction_rate" in stats
        assert 0 <= stats["reduction_rate"] <= 1
