"""Tests for cost/time estimator module."""

import pandas as pd
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from question_extractor.estimator import Estimator, CostEstimate


class TestCostEstimate:
    """Tests for CostEstimate dataclass."""

    def test_to_dict(self):
        """Test conversion to dictionary."""
        estimate = CostEstimate(
            total_rows=1000,
            total_cost=5.50,
            total_time=30.0,
        )

        result = estimate.to_dict()

        assert result["total_rows"] == 1000
        assert result["costs"]["total"] == 5.50
        assert result["time_minutes"]["total"] == 30.0

    def test_format_summary(self):
        """Test formatted summary output."""
        estimate = CostEstimate(
            total_rows=1000,
            sample_size=100,
            summarization_cost=1.00,
            extraction_cost=0.50,
            embedding_cost=0.05,
            consolidation_cost=0.10,
            total_cost=1.65,
            summarization_time=10.0,
            extraction_time=5.0,
            embedding_time=2.0,
            clustering_time=1.0,
            consolidation_time=2.0,
            total_time=20.0,
        )

        summary = estimate.format_summary()

        assert "1,000" in summary  # Total rows
        assert "$1.65" in summary  # Total cost
        assert "20.0 min" in summary  # Total time


class TestEstimator:
    """Tests for Estimator class."""

    def test_estimate_from_texts(self, sample_config, mock_llm_client):
        """Test estimation from sample texts."""
        estimator = Estimator(sample_config)

        sample_texts = [
            "How do I reset my password?",
            "I was charged twice on my credit card.",
            "Can you help me with a refund?",
        ]

        estimate = estimator.estimate_from_texts(sample_texts, total_rows=1000)

        assert estimate.total_rows == 1000
        assert estimate.sample_size == 3
        assert estimate.total_cost > 0
        assert estimate.total_time > 0

    def test_estimate_from_dataframe(self, sample_config, sample_df, mock_llm_client):
        """Test estimation from DataFrame."""
        estimator = Estimator(sample_config)

        estimate = estimator.estimate_from_dataframe(sample_df, sample_size=5)

        assert estimate.total_rows == len(sample_df)
        assert estimate.total_cost > 0

    def test_estimate_from_file(self, sample_config, sample_data_path, mock_llm_client):
        """Test estimation from file."""
        estimator = Estimator(sample_config)

        estimate = estimator.estimate_from_file(sample_data_path, sample_size=10)

        assert estimate.total_rows == 20  # Sample data has 20 rows
        assert estimate.total_cost > 0

    def test_calculate_llm_cost(self, sample_config):
        """Test LLM cost calculation."""
        estimator = Estimator(sample_config)

        cost = estimator._calculate_llm_cost(
            input_tokens=1_000_000,
            output_tokens=500_000,
        )

        # GPT-4o: $2.50/1M input, $10/1M output
        expected_input = 1.0 * sample_config.gpt4o_input_price
        expected_output = 0.5 * sample_config.gpt4o_output_price
        assert abs(cost - (expected_input + expected_output)) < 0.01

    def test_calculate_llm_time(self, sample_config):
        """Test LLM time calculation."""
        estimator = Estimator(sample_config)

        time_minutes = estimator._calculate_llm_time(total_tokens=150_000)

        # Should be 1 minute at 150k TPM rate
        assert abs(time_minutes - 1.0) < 0.01
