"""Pytest fixtures for Question Extractor tests."""

from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pandas as pd
import pytest

from question_extractor.config import Config


@pytest.fixture
def sample_config() -> Config:
    """Create a sample configuration for testing."""
    return Config(
        openai_api_key="test-api-key",
        text_column="text",
        id_column="row_id",
        fuzzy_threshold=0.75,
        semantic_distance_threshold=0.7,
        output_dir=Path("test_output"),
    )


@pytest.fixture
def sample_df() -> pd.DataFrame:
    """Create a sample DataFrame for testing."""
    return pd.DataFrame({
        "row_id": [1, 2, 3, 4, 5],
        "text": [
            "How do I reset my password? I forgot it.",
            "I was charged twice on my credit card.",
            "Can you help me reset my password please?",
            "Why was I billed two times this month?",
            "What is the refund policy?",
        ],
    })


@pytest.fixture
def expanded_df() -> pd.DataFrame:
    """Create an expanded DataFrame with extracted questions."""
    return pd.DataFrame({
        "row_id": [1, 1, 2, 3, 4, 5],
        "question_id": [1, 2, 1, 1, 1, 1],
        "question": [
            "How do I reset my password?",
            "Why did I forget my password?",
            "Why was I charged twice?",
            "How can I reset my password?",
            "Why was I billed two times?",
            "What is the refund policy?",
        ],
    })


@pytest.fixture
def sample_data_path() -> Path:
    """Path to sample data CSV."""
    return Path(__file__).parent / "fixtures" / "sample_data.csv"


@pytest.fixture
def mock_llm_client():
    """Create a mock LLM client."""
    with patch("question_extractor.utils.llm.OpenAI") as mock_openai, \
         patch("question_extractor.utils.llm.AsyncOpenAI") as mock_async_openai:

        # Mock synchronous client
        mock_response = MagicMock()
        mock_response.choices = [MagicMock(message=MagicMock(content="Mocked response"))]
        mock_openai.return_value.chat.completions.create.return_value = mock_response

        # Mock async client
        async_mock_response = MagicMock()
        async_mock_response.choices = [MagicMock(message=MagicMock(content="Mocked response"))]
        mock_async_openai.return_value.chat.completions.create = AsyncMock(
            return_value=async_mock_response
        )

        yield mock_openai, mock_async_openai


@pytest.fixture
def mock_embeddings_client():
    """Create a mock embeddings client."""
    with patch("question_extractor.utils.embeddings.OpenAI") as mock_openai, \
         patch("question_extractor.utils.embeddings.AsyncOpenAI") as mock_async_openai:

        # Mock embedding response
        mock_embedding = MagicMock()
        mock_embedding.embedding = [0.1] * 1536  # Standard embedding size
        mock_response = MagicMock()
        mock_response.data = [mock_embedding]

        mock_openai.return_value.embeddings.create.return_value = mock_response
        mock_async_openai.return_value.embeddings.create = AsyncMock(return_value=mock_response)

        yield mock_openai, mock_async_openai
