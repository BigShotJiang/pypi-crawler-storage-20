"""Tests for summarizer module."""

import pandas as pd
import pytest
from unittest.mock import MagicMock, patch

from question_extractor.processors.summarizer import Summarizer


class TestSummarizer:
    """Tests for Summarizer class."""

    def test_summarize_sync(self, sample_config, mock_llm_client):
        """Test synchronous summarization."""
        summarizer = Summarizer(sample_config)

        # Mock the LLM response
        mock_response = MagicMock()
        mock_response.choices = [
            MagicMock(message=MagicMock(content="Customer asking about password reset."))
        ]
        summarizer.llm.client.chat.completions.create.return_value = mock_response

        result = summarizer.summarize(
            "Um, like, I was wondering, you know, how do I reset my password?"
        )

        assert result == "Customer asking about password reset."
        summarizer.llm.client.chat.completions.create.assert_called_once()

    def test_summarize_empty_text(self, sample_config):
        """Test summarization with empty text."""
        summarizer = Summarizer(sample_config)

        assert summarizer.summarize("") == ""
        assert summarizer.summarize("   ") == ""

    def test_summarize_dataframe(self, sample_config, sample_df, mock_llm_client):
        """Test DataFrame summarization."""
        summarizer = Summarizer(sample_config)

        # Mock the LLM response
        mock_response = MagicMock()
        mock_response.choices = [
            MagicMock(message=MagicMock(content="Summarized text"))
        ]
        summarizer.llm.client.chat.completions.create.return_value = mock_response

        # Mock batch processing
        with patch.object(
            summarizer,
            "summarize_batch",
            return_value=["Summary 1", "Summary 2", "Summary 3", "Summary 4", "Summary 5"]
        ):
            import asyncio
            with patch("asyncio.run", side_effect=lambda x: ["Summary"] * len(sample_df)):
                result_df = summarizer.summarize_dataframe(sample_df)

        assert "text_summarized" in result_df.columns
        assert len(result_df) == len(sample_df)

    def test_estimate_tokens(self, sample_config, mock_llm_client):
        """Test token estimation."""
        summarizer = Summarizer(sample_config)

        texts = [
            "How do I reset my password?",
            "I was charged twice on my credit card.",
        ]

        estimate = summarizer.estimate_tokens(texts)

        assert "input_tokens" in estimate
        assert "estimated_output_tokens" in estimate
        assert "total_estimated_tokens" in estimate
        assert estimate["input_tokens"] > 0
