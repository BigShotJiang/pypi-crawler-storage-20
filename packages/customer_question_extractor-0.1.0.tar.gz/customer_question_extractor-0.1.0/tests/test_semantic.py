"""Tests for semantic clustering module."""

import numpy as np
import pandas as pd
import pytest
from unittest.mock import MagicMock, patch

from question_extractor.deduplication.semantic import SemanticClusterer


class TestSemanticClusterer:
    """Tests for SemanticClusterer class."""

    def test_cluster_basic(self, sample_config, mock_embeddings_client):
        """Test basic clustering functionality."""
        clusterer = SemanticClusterer(sample_config)

        # Mock embeddings to return distinct vectors for different question types
        with patch.object(
            clusterer.embeddings,
            "get_embeddings_batch",
            return_value=np.array([
                [1.0, 0.0, 0.0],  # password questions
                [0.9, 0.1, 0.0],
                [0.0, 1.0, 0.0],  # billing questions
                [0.1, 0.9, 0.0],
                [0.0, 0.0, 1.0],  # other
            ])
        ):
            with patch.object(
                clusterer.embeddings,
                "normalize_embeddings",
                side_effect=lambda x: x / np.linalg.norm(x, axis=1, keepdims=True)
            ):
                questions = [
                    "How do I reset my password?",
                    "Password reset help",
                    "Why was I charged twice?",
                    "Double billing issue",
                    "What is the refund policy?",
                ]

                clusters = clusterer.cluster(questions, distance_threshold=0.5)

                assert len(clusters) > 0
                # All questions should be assigned
                total_questions = sum(len(q) for q in clusters.values())
                assert total_questions == len(questions)

    def test_filter_top_questions(self, sample_config):
        """Test filtering top questions by volume."""
        clusterer = SemanticClusterer(sample_config)

        df = pd.DataFrame({
            "row_id": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            "question": [
                "Question A", "Question A", "Question A", "Question A",
                "Question B", "Question B", "Question B",
                "Question C", "Question C",
                "Question D",
            ],
        })

        # Top 75% should include A and B (higher volume)
        filtered = clusterer._filter_top_questions(
            df, "question", "row_id", percentile=0.5
        )

        filtered_questions = filtered["question"].unique()
        assert "Question A" in filtered_questions
        assert "Question B" in filtered_questions

    def test_get_cluster_stats(self, sample_config):
        """Test cluster statistics."""
        clusterer = SemanticClusterer(sample_config)

        df = pd.DataFrame({
            "question": ["Q1", "Q2", "Q3", "Q4", "Q5"],
            "semantic_cluster_id": [0, 0, 1, 1, None],
        })

        stats = clusterer.get_cluster_stats(df)

        assert stats["total_questions"] == 5
        assert stats["clustered_questions"] == 4
        assert stats["unclustered_questions"] == 1
        assert stats["num_clusters"] == 2
