"""Tests for main pipeline module."""

import pandas as pd
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

from question_extractor.pipeline import Pipeline, PipelineStats, PipelineResult
from question_extractor.config import Config


class TestPipelineStats:
    """Tests for PipelineStats dataclass."""

    def test_to_dict(self):
        """Test conversion to dictionary."""
        stats = PipelineStats(
            input_rows=1000,
            questions_extracted=2500,
            final_unique=150,
        )

        result = stats.to_dict()

        assert result["input_rows"] == 1000
        assert result["questions_extracted"] == 2500
        assert result["final_unique"] == 150


class TestPipeline:
    """Tests for Pipeline class."""

    def test_init(self, sample_config):
        """Test pipeline initialization."""
        pipeline = Pipeline(sample_config)

        assert pipeline.config == sample_config
        assert pipeline.summarizer is not None
        assert pipeline.extractor is not None
        assert pipeline.fuzzy is not None
        assert pipeline.semantic is not None

    def test_init_default_config(self):
        """Test pipeline with default config."""
        with patch.dict("os.environ", {"QE_OPENAI_API_KEY": "test-key"}):
            pipeline = Pipeline()
            assert pipeline.config is not None

    def test_estimate(self, sample_config, sample_df, mock_llm_client):
        """Test cost estimation."""
        pipeline = Pipeline(sample_config)

        estimate = pipeline.estimate(df=sample_df)

        assert estimate.total_rows == len(sample_df)
        assert estimate.total_cost >= 0

    @pytest.mark.skip(reason="Full pipeline test requires extensive mocking")
    def test_run_full_pipeline(self, sample_config, sample_df, mock_llm_client, tmp_path):
        """Test full pipeline execution."""
        sample_config.output_dir = tmp_path
        pipeline = Pipeline(sample_config)

        # This would require extensive mocking of all async operations
        # Skipped for basic test suite
        pass


class TestPipelineResult:
    """Tests for PipelineResult dataclass."""

    def test_result_creation(self, sample_df):
        """Test result creation."""
        stats = PipelineStats(input_rows=100)
        result = PipelineResult(
            df=sample_df,
            stats=stats,
            output_paths={"clean_csv": Path("output/clean.csv")},
        )

        assert len(result.df) == len(sample_df)
        assert result.stats.input_rows == 100
        assert "clean_csv" in result.output_paths
