"""Tests for question extractor module."""

import pytest
from unittest.mock import patch, AsyncMock, MagicMock

from question_extractor.processors.extractor import QuestionExtractor


class TestQuestionExtractor:
    """Tests for QuestionExtractor class."""

    def test_parse_questions_json(self, sample_config):
        """Test parsing JSON array response."""
        extractor = QuestionExtractor(sample_config)

        response = '["How do I reset my password?", "What is the refund policy?"]'
        questions = extractor._parse_questions(response)

        assert len(questions) == 2
        assert "How do I reset my password?" in questions
        assert "What is the refund policy?" in questions

    def test_parse_questions_with_extra_text(self, sample_config):
        """Test parsing response with extra text around JSON."""
        extractor = QuestionExtractor(sample_config)

        response = """Here are the questions:
        ["How do I reset my password?", "What is the refund policy?"]
        These are the main concerns."""
        questions = extractor._parse_questions(response)

        assert len(questions) == 2

    def test_parse_questions_fallback(self, sample_config):
        """Test fallback parsing for non-JSON response."""
        extractor = QuestionExtractor(sample_config)

        response = """- How do I reset my password?
        - What is the refund policy?"""
        questions = extractor._parse_questions(response)

        assert len(questions) == 2

    def test_parse_questions_empty(self, sample_config):
        """Test parsing empty response."""
        extractor = QuestionExtractor(sample_config)

        assert extractor._parse_questions("") == []
        assert extractor._parse_questions("[]") == []

    def test_extract_sync(self, sample_config, mock_llm_client):
        """Test synchronous extraction."""
        extractor = QuestionExtractor(sample_config)

        # Mock the LLM response
        mock_response = MagicMock()
        mock_response.choices = [
            MagicMock(message=MagicMock(content='["How do I reset my password?"]'))
        ]
        extractor.llm.client.chat.completions.create.return_value = mock_response

        questions = extractor.extract("I need to reset my password")

        assert len(questions) == 1
        assert "password" in questions[0].lower()

    def test_extract_empty_text(self, sample_config):
        """Test extraction with empty text."""
        extractor = QuestionExtractor(sample_config)

        assert extractor.extract("") == []
        assert extractor.extract("   ") == []

    def test_estimate_tokens(self, sample_config, mock_llm_client):
        """Test token estimation."""
        extractor = QuestionExtractor(sample_config)

        texts = [
            "How do I reset my password?",
            "I was charged twice on my credit card.",
        ]

        estimate = extractor.estimate_tokens(texts)

        assert "input_tokens" in estimate
        assert "estimated_output_tokens" in estimate
        assert estimate["input_tokens"] > 0
