# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2024-01-12

### Added
- Initial release
- Text summarization to remove fillers and extract key content
- Question extraction using GPT-4o
- Two-tier deduplication with fuzzy matching (RapidFuzz) and semantic clustering (OpenAI embeddings)
- Cost estimation before running pipeline
- CLI interface with `question-extractor` command
- Python API with `Config` and `Pipeline` classes
- Auto-generated markdown and HTML analysis reports
- Interactive Streamlit dashboard for exploring results
