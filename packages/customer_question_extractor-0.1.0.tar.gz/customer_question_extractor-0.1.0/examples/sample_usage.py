"""Example usage of the Question Extractor package."""

import os
from pathlib import Path

from question_extractor import Config, Pipeline


def main():
    """Run a sample question extraction pipeline."""
    # Configure the pipeline
    config = Config(
        openai_api_key=os.getenv("OPENAI_API_KEY", ""),
        text_column="text",
        id_column="row_id",
        output_dir=Path("example_output"),
        fuzzy_threshold=0.75,
        semantic_distance_threshold=0.7,
    )

    # Initialize pipeline
    pipeline = Pipeline(config)

    # Path to sample data
    sample_data = Path(__file__).parent.parent / "tests" / "fixtures" / "sample_data.csv"

    # Get cost estimate first
    print("Estimating cost and time...")
    estimate = pipeline.estimate(input_path=sample_data)
    print(estimate.format_summary())

    # Ask for confirmation
    response = input("\nProceed with processing? (y/n): ")
    if response.lower() != "y":
        print("Aborted.")
        return

    # Run the pipeline
    print("\nRunning pipeline...")
    result = pipeline.run(input_path=sample_data)

    # Print results
    print(f"\nProcessed {result.stats.input_rows} rows")
    print(f"Extracted {result.stats.questions_extracted} questions")
    print(f"Final unique questions: {result.stats.final_unique}")
    print(f"\nOutput saved to: {config.output_dir}")

    # Show sample of results
    print("\nSample of extracted questions:")
    for _, row in result.df.head(10).iterrows():
        print(f"  - {row['semantic_cluster']}")


if __name__ == "__main__":
    main()
