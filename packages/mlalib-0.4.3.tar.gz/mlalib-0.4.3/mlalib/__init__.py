"""
For the love of exploring intelligence.
"""

__version__ = "0.4.3"
__author__ = "MLA"
