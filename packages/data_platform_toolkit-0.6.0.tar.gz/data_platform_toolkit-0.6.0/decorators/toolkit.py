import logging
import sys
from typing import Any, Optional, Union

from decorators.logging import StructuredLoggerAdapter, _LOGGER_NAME

__all__ = ["configure_toolkit", "get_logger"]

_LOGGER_DEFAULT_STRUCTURED_MESSAGES = True


def get_logger() -> Union[logging.Logger, StructuredLoggerAdapter]:
    """
    Return the module-level logger configured for decorators.

    :returns: Structured adapter if structured messages are enabled, otherwise
              the raw ``logging.Logger`` bound to ``_LOGGER_NAME``.
    :rtype: Union[logging.Logger, StructuredLoggerAdapter]
    """
    logger = logging.getLogger(_LOGGER_NAME)
    if _LOGGER_DEFAULT_STRUCTURED_MESSAGES:
        return StructuredLoggerAdapter(logger)
    
    return logger


def configure_toolkit(
    *,
    logger_level: int = logging.INFO,
    logger_stream: Optional[Any] = None,
    logger_structured_messages: bool = True,
):
    """
    Configure the toolkit. This function should be called once at the start of
    your application.

    :keyword int logger_level: Logging level applied to the shared logger.
    :keyword IO logger_stream: Optional stream used by the default handler;
                               defaults to ``sys.stdout``.
    :keyword bool logger_structured_messages: Toggle returning
        :class:`decorators.logging.StructuredLoggerAdapter` from
        :func:`get_logger`.
    """
    global _LOGGER_DEFAULT_STRUCTURED_MESSAGES

    _LOGGER_DEFAULT_STRUCTURED_MESSAGES = logger_structured_messages

    logger = logging.getLogger(_LOGGER_NAME)
    if not logger.handlers:
        handler = logging.StreamHandler(logger_stream or sys.stdout)
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(handler)

    logger.setLevel(logger_level)
    logger.propagate = False
