import argparse
import inspect
import logging
import sys
from typing import Any, Callable, Dict, Optional, Sequence, Union

from decorators._utils import (
    _add_boolean_argument,
    _normalise_cli_name,
    _serialise_call,
    _resolve_type,
    _stringify_result,
)
from decorators.logging import _LOGGER_NAME, log_invocation


class CLIRegistry:
    """
    Registry that turns regular callables into CLI sub-commands.

    It keeps track of registered names, wires structured logging and
    provides a lightweight dispatcher that mirrors ``argparse``'s error
    handling semantics.

    :ivar _commands: Mapping of command names to their wrapped callables.
    :ivar _logger: Shared structured logger used by registered commands.
    """

    def __init__(self):
        self._commands: Dict[str, Callable[..., Any]] = {}
        self._logger = logging.getLogger(_LOGGER_NAME)

    def command(self, name: Optional[str] = None, *, log: bool = True) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """
        Register a callable as a CLI command.

        :param name: Optional explicit name; falls back to a normalised function name.
        :param log: When ``True`` the callable is wrapped with structured logging.
        :returns: A decorator that registers the provided callable.
        :raises ValueError: If the command name is already registered.
        """

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            command_name = name or _normalise_cli_name(func.__name__)
            if command_name in self._commands:
                raise ValueError(f"Command '{command_name}' is already registered.")

            wrapped = log_invocation(func, name=command_name, logger=self._logger) if log else func
            self._commands[command_name] = wrapped
            return wrapped

        return decorator

    def run(self, argv: Optional[Sequence[str]] = None) -> int:
        """
        Parse command-line arguments and execute the matching command.

        Supports an optional ``--dry-run`` flag that prints the planned call
        instead of executing it. Mirrors ``argparse`` exit codes so callers
        can embed the registry inside larger scripts.

        :param argv: Sequence of arguments; defaults to ``sys.argv[1:]``.
        :returns: Zero on success or the non-zero exit code from parsing/execution.
        """
        args = list(argv if argv is not None else sys.argv[1:])

        # Support top-level --dry-run before command name
        dry_run = False
        if args and args[0] == "--dry-run":
            dry_run = True
            args.pop(0)

        if not args:
            if dry_run:
                # Show a structured preview of available commands
                preview = {
                    "event": "dry_run",
                    "function": None,
                    "available": sorted(self._commands.keys()),
                }
                print(_stringify_result(preview))
                return 0
            self._print_help(sys.stdout)
            return 0

        if args and args[0] in ("--help", "-h"):
            self._print_help(sys.stdout)
            return 0

        command_name = args.pop(0)
        command = self._commands.get(command_name)
        if command is None:
            print(f"Unknown command '{command_name}'.")
            self._print_help(sys.stderr)
            return 1

        parser = self._build_parser(command_name, command)
        try:
            namespace = parser.parse_args(args)
        except SystemExit as se:
            # Capture argparse's default behavior (exit code 2) and return it
            # instead of terminating the interpreter from within the library.
            try:
                return int(se.code)  # type: ignore[arg-type]
            except Exception:
                return 2
        call_args = vars(namespace)

        if dry_run:
            # Print a structured preview of the intended call and skip execution
            preview = {
                "event": "dry_run",
                "function": command_name,
                "call": _serialise_call((), call_args),
            }
            print(_stringify_result(preview))
            return 0

        try:
            result = command(**call_args)
        except Exception:
            # The structured decorator already logs rich error details. For
            # commands registered with log=False, we still indicate failure
            # via non-zero exit code without re-raising here.
            return 1

        if result is not None:
            print(_stringify_result(result))
        return 0

    def __call__(self, argv: Optional[Sequence[str]] = None) -> int:
        return self.run(argv)

    def _build_parser(self, command_name: str, func: Callable[..., Any]) -> argparse.ArgumentParser:
        parser = argparse.ArgumentParser(
            prog=f"{command_name}",
            description=inspect.getdoc(func),
        )
        signature = inspect.signature(func)
        for parameter in signature.parameters.values():
            self._add_argument(parser, parameter)

        return parser

    @staticmethod
    def _add_argument(parser: argparse.ArgumentParser, parameter: inspect.Parameter) -> None:
        if parameter.kind not in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY):
            raise TypeError(f"Unsupported parameter kind for CLI conversion: {parameter.kind!r}")

        param_type = _resolve_type(parameter)
        arg_name = _normalise_cli_name(parameter.name)

        if param_type is bool:
            _add_boolean_argument(parser, parameter)
            return

        if parameter.default is inspect._empty:
            parser.add_argument(parameter.name, type=param_type)
        else:
            parser.add_argument(
                f"--{arg_name}",
                dest=parameter.name,
                type=param_type,
                default=parameter.default,
            )

    def _print_help(self, stream: Any) -> None:
        if not self._commands:
            print("No commands registered.", file=stream)
            return

        for index, name in enumerate(sorted(self._commands)):
            parser = self._build_parser(name, self._commands[name])
            help_text = parser.format_help()
            print(help_text.rstrip(), file=stream)
            if index != len(self._commands) - 1:
                print(file=stream)
