import argparse
import inspect
import json
import os
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional, Tuple, Union, get_args, get_origin


def _normalise_cli_name(name: str) -> str:
    return name.replace("_", "-")

_META_FILES = (
    "ci_commit_sha",
    "ci_project_name",
    "ci_project_url",
    "ci_commit_timestamp",
)


def _locate_meta_dir() -> Optional[Path]:
    current = Path.cwd().resolve()
    for directory in [current, *current.parents]:
        candidate = directory / ".meta"
        if candidate.is_dir():
            return candidate
    return None

def _read_ci_metadata(meta_dir: Optional[Path]) -> Dict[str, str]:
    if meta_dir is None:
        return {}
    metadata: Dict[str, str] = {}
    for filename in _META_FILES:
        path = meta_dir / filename
        if not path.is_file():
            continue
        try:
            raw_value = path.read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if not raw_value:
            continue
        if "=" in raw_value:
            _, _, raw_value = raw_value.partition("=")
        metadata[filename] = raw_value
    return metadata

def _uuid7() -> uuid.UUID:
    # 48 бит: timestamp в миллисекундах
    ts_ms = int(time.time() * 1000)
    time_high = (ts_ms >> 16) & 0xFFFF_FFFF
    time_low  = ts_ms & 0xFFFF

    # 12 бит rand_a
    rand_a = int.from_bytes(os.urandom(2), 'big') & 0x0FFF

    # 62 бита rand_b
    rand_b = int.from_bytes(os.urandom(8), 'big') & ((1 << 62) - 1)

    # Сборка 128 бит по спецификации UUIDv7:
    # [0..47]=ts_ms, [48..51]=version(7), [52..63]=rand_a,
    # [64..65]=variant(10), [66..127]=rand_b
    value = (ts_ms << 80)                           \
          | (0x7 << 76)                             \
          | (rand_a << 64)                          \
          | (0b10 << 62)                            \
          | rand_b

    return uuid.UUID(int=value)


_META_DIR = _locate_meta_dir()
_CACHED_CI_METADATA = _read_ci_metadata(_META_DIR)
_INVOCATION_ID = str(_uuid7())


def _ci_metadata() -> Dict[str, str]:
    return dict(_CACHED_CI_METADATA)

def _invocation_id() -> str:
    return _INVOCATION_ID


def _add_boolean_argument(parser: argparse.ArgumentParser, parameter: inspect.Parameter) -> None:
    arg_name = _normalise_cli_name(parameter.name)
    group = parser.add_mutually_exclusive_group(required=False)
    group.add_argument(f"--{arg_name}", dest=parameter.name, action="store_true", help=f"Enable {parameter.name}")
    group.add_argument(f"--no-{arg_name}", dest=parameter.name, action="store_false", help=f"Disable {parameter.name}")
    default = parameter.default if parameter.default is not inspect._empty else False
    parser.set_defaults(**{parameter.name: bool(default)})


def _serialise_call(args: Tuple[Any, ...], kwargs: Dict[str, Any]) -> Dict[str, Any]:
    if not kwargs and not args:
        return {}

    serialised: Dict[str, Any] = {}
    if args:
        serialised["args"] = [_serialise_value(value) for value in args]
    if kwargs:
        serialised["kwargs"] = {key: _serialise_value(value) for key, value in kwargs.items()}
    return serialised


def _serialise_value(value: Any) -> Any:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, (list, tuple, set)):
        return [_serialise_value(item) for item in value]
    if isinstance(value, Mapping):
        return {str(key): _serialise_value(val) for key, val in value.items()}
    return repr(value)


def _round_duration(value: float) -> float:
    return round(value, 6)


def _stringify_result(result: Any) -> str:
    if isinstance(result, (str, int, float)):
        return str(result)
    try:
        return json.dumps(_serialise_value(result))
    except TypeError:
        return repr(result)


def _resolve_type(parameter: inspect.Parameter) -> type:
    annotation = parameter.annotation
    if annotation is inspect._empty:
        annotation = None
    else:
        origin = get_origin(annotation)
        if origin is Union:
            args = [arg for arg in get_args(annotation) if arg is not type(None)]  # noqa: E721 - NoneType check
            if len(args) == 1:
                annotation = args[0]
        elif origin is list:  # unsupported container for CLI input
            annotation = None

    candidate_types: Iterable[type] = (
        [annotation] if isinstance(annotation, type) else []
    )

    if parameter.default is not inspect._empty:
        candidate_types = list(candidate_types) + [type(parameter.default)]

    for candidate in candidate_types:
        if candidate in (str, int, float, bool):
            return candidate

    return str
