import json
import logging
import time
from datetime import datetime, timezone
from functools import wraps
from typing import Any, Callable, Dict, Mapping, Optional, Tuple, Union

from decorators._utils import _ci_metadata, _invocation_id, _round_duration, _serialise_call, _serialise_value

_LOGGER_NAME = "data_platform_toolkit"


def _json_fallback(value: Any) -> Any:
    return _serialise_value(value)


def _current_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _augment_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    enriched: Dict[str, Any] = {**payload, "timestamp": _current_timestamp(), "invocation_id": _invocation_id()}
    metadata = _ci_metadata()
    if metadata:
        enriched.setdefault("meta", metadata)
    return enriched


def _log_json(logger: logging.Logger, level: int, event: str, **payload: Any) -> None:
    message = _augment_payload({"event": event, **payload})
    logger.log(level, json.dumps(message, default=_json_fallback))


class StructuredLoggerAdapter(logging.LoggerAdapter):
    """
    Logger adapter that serialises structured payloads as JSON.

    It ensures consistent enrichment (timestamp, invocation id, CI metadata)
    before handing the final string off to the wrapped logger.

    :param logger: Underlying logger used to emit the JSON string.
    :param default_event: Fallback event name when the incoming message is not a mapping.
    """

    def __init__(self, logger: logging.Logger, *, default_event: str = "log"):
        super().__init__(logger, {})
        self._default_event = default_event

    def process(self, msg: Any, kwargs: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
        payload = msg if isinstance(msg, Mapping) else {"event": self._default_event, "message": str(msg)}
        merged_payload = dict(payload)

        processed_kwargs = dict(kwargs)
        extra = processed_kwargs.pop("extra", None)
        if extra:
            merged_payload.update(extra)

        enriched_payload = _augment_payload(merged_payload)
        return json.dumps(enriched_payload, default=_json_fallback), processed_kwargs


def log_invocation(func: Optional[Callable[..., Any]] = None, *, name: Optional[str] = None, logger: Optional[logging.Logger] = None) -> Callable[..., Any]:
    """
    Decorator that emits JSON logs for function start, success and error.

    :param func: Callable being wrapped; when omitted the decorator can be configured.
    :param name: Logical name to record in log entries; defaults to ``func.__name__``.
    :param logger: Logger instance to use; falls back to ``_LOGGER_NAME``.
    :returns: Callable that preserves the original signature while adding logging.
    """

    if func is None:
        return lambda fn: log_invocation(fn, name=name, logger=logger)

    logical_name = name or func.__name__
    active_logger = logger or logging.getLogger(_LOGGER_NAME)

    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start = time.perf_counter()
        _log_json(active_logger, logging.INFO, "start", function=logical_name, call=_serialise_call(args, kwargs))
        try:
            result = func(*args, **kwargs)
        except Exception as exc:  # pragma: no cover - best effort logging
            duration = time.perf_counter() - start
            _log_json(
                active_logger,
                logging.ERROR,
                "error",
                message=repr(exc),
                function=logical_name,
                duration=_round_duration(duration),
                call=_serialise_call(args, kwargs),
            )
            raise

        duration = time.perf_counter() - start
        _log_json(
            active_logger,
            logging.INFO,
            "success",
            message=_serialise_value(result),
            function=logical_name,
            duration=_round_duration(duration),
        )
        return result

    return wrapper
