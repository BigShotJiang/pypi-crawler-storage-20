"""
Utilities for turning Python callables into CLI commands with structured logging.

The central piece is :class:`CLIRegistry`, which collects decorated functions and
exposes a small `argparse`-based runner. Decorated callables emit structured JSON
log lines that describe the invocation lifecycle (start, success, failure).
"""

from __future__ import annotations

from decorators.toolkit import configure_toolkit, get_logger
from decorators.registry import CLIRegistry, log_invocation

cli = CLIRegistry()
configure_toolkit()
logger = get_logger()


__all__ = ["cli", "logger", "log_invocation"]
