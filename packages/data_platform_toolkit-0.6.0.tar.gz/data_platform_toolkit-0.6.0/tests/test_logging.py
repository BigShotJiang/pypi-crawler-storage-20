import io
import json
import logging
import unittest
from typing import Any, Dict, Tuple

from decorators.logging import _LOGGER_NAME, StructuredLoggerAdapter, _json_fallback, log_invocation
from decorators.toolkit import configure_toolkit, get_logger


def _reset_package_logger() -> None:
    logger = logging.getLogger(_LOGGER_NAME)
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    logger.setLevel(logging.NOTSET)
    logger.propagate = True


def _make_stream_logger(name: str = "test-logger") -> Tuple[logging.Logger, io.StringIO]:
    stream = io.StringIO()
    logger = logging.getLogger(name)
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        handler.close()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    return logger, stream


class TestLogging(unittest.TestCase):
    def setUp(self) -> None:
        _reset_package_logger()

    def tearDown(self) -> None:
        _reset_package_logger()

    def test_configure_toolkit_returns_adapter_for_structured_messages(self) -> None:
        configure_toolkit(logger_structured_messages=True)
        logger = get_logger()
        self.assertIsInstance(logger, StructuredLoggerAdapter)

        base_logger = logging.getLogger(_LOGGER_NAME)
        self.assertEqual(len(base_logger.handlers), 1)

    def test_configure_toolkit_reuses_existing_handler(self) -> None:
        configure_toolkit()
        base_logger = logging.getLogger(_LOGGER_NAME)
        first_handlers = list(base_logger.handlers)

        configure_toolkit()
        second_handlers = list(logging.getLogger(_LOGGER_NAME).handlers)

        self.assertEqual(second_handlers, first_handlers)

    def test_get_logger_uses_configured_defaults(self) -> None:
        stream = io.StringIO()
        configure_toolkit(logger_stream=stream, logger_structured_messages=True)

        logger = get_logger()
        self.assertIsInstance(logger, StructuredLoggerAdapter)

        logger.info("ready")
        payload = json.loads(stream.getvalue().strip())

        self.assertEqual(payload["event"], "log")
        self.assertEqual(payload["message"], "ready")
        self.assertNotIn("function", payload)

    def test_structured_decorator_emits_json_payloads(self) -> None:
        logger, stream = _make_stream_logger("structured-test")

        @log_invocation(name="custom-name", logger=logger)
        def add(a: int, b: int, *, flag: bool = False) -> int:
            self.assertTrue(flag)
            return a + b

        result = add(1, 2, flag=True)
        self.assertEqual(result, 3)

        lines = [line for line in stream.getvalue().strip().splitlines() if line]
        self.assertEqual(len(lines), 2)

        first_event = json.loads(lines[0])
        second_event = json.loads(lines[1])

        self.assertEqual(first_event["event"], "start")
        self.assertEqual(first_event["function"], "custom-name")
        self.assertEqual(first_event["call"], {"args": [1, 2], "kwargs": {"flag": True}})

        self.assertEqual(second_event["event"], "success")
        self.assertEqual(second_event["function"], "custom-name")
        self.assertEqual(second_event["message"], 3)
        self.assertIsInstance(second_event["duration"], float)
        self.assertEqual(first_event["invocation_id"], second_event["invocation_id"])
        self.assertTrue(first_event["timestamp"].endswith("Z"))

    def test_structured_logs_errors_and_reraises(self) -> None:
        logger, stream = _make_stream_logger("structured-error-test")

        @log_invocation(logger=logger)
        def boom() -> None:
            raise RuntimeError("fail")

        with self.assertRaises(RuntimeError):
            boom()

        lines = [line for line in stream.getvalue().strip().splitlines() if line]
        self.assertEqual(len(lines), 2)

        start_event = json.loads(lines[0])
        error_event = json.loads(lines[1])

        self.assertEqual(start_event["event"], "start")
        self.assertEqual(error_event["event"], "error")
        self.assertIn("RuntimeError('fail')", error_event["message"])
        self.assertIn("duration", error_event)
        self.assertEqual(error_event["function"], "boom")

    def test_structured_logger_adapter_promotes_plain_messages(self) -> None:
        base_logger, stream = _make_stream_logger("adapter-test")
        adapter = StructuredLoggerAdapter(base_logger, default_event="note")

        adapter.info("hello world", extra={"stage": "demo"})
        payload = json.loads(stream.getvalue())

        self.assertEqual(payload["event"], "note")
        self.assertEqual(payload["message"], "hello world")
        self.assertEqual(payload["stage"], "demo")

    def test_json_fallback_delegates_to_serialiser(self) -> None:
        class Marker:
            def __repr__(self) -> str:
                return "<Marker>"

        payload: Dict[str, Any] = {"custom": Marker()}
        self.assertEqual(_json_fallback(payload["custom"]), "<Marker>")


if __name__ == "__main__":
    unittest.main()
