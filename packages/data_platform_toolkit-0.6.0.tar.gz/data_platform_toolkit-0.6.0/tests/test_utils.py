import argparse
import inspect
import json
import unittest
from typing import Optional

from decorators._utils import (
    _add_boolean_argument,
    _normalise_cli_name,
    _resolve_type,
    _round_duration,
    _serialise_call,
    _serialise_value,
    _stringify_result,
)


class TestUtils(unittest.TestCase):
    def test_normalise_cli_name_replaces_underscores(self) -> None:
        self.assertEqual(_normalise_cli_name("make_report"), "make-report")

    def test_serialise_value_handles_nested_collections(self) -> None:
        data = {"numbers": [1, 2], "labels": ("x", "y"), "flags": {True, False}, 2: "value"}
        serialised = _serialise_value(data)

        self.assertEqual(serialised["numbers"], [1, 2])
        self.assertEqual(serialised["labels"], ["x", "y"])
        self.assertEqual(set(serialised["flags"]), {True, False})
        self.assertEqual(serialised["2"], "value")

    def test_serialise_value_falls_back_to_repr_for_unknown_types(self) -> None:
        class Marker:
            pass

        instance = Marker()
        self.assertEqual(_serialise_value(instance), repr(instance))

    def test_serialise_call_returns_empty_dict_for_no_arguments(self) -> None:
        self.assertEqual(_serialise_call((), {}), {})

    def test_serialise_call_handles_args_and_kwargs(self) -> None:
        result = _serialise_call((1, "two"), {"flag": True})
        self.assertEqual(result["args"], [1, "two"])
        self.assertEqual(result["kwargs"], {"flag": True})

    def test_add_boolean_argument_accepts_enable_and_disable_forms(self) -> None:
        parser = argparse.ArgumentParser()
        parameter = inspect.signature(lambda verbose=False: None).parameters["verbose"]

        _add_boolean_argument(parser, parameter)

        self.assertIs(parser.parse_args([]).verbose, False)
        self.assertIs(parser.parse_args(["--verbose"]).verbose, True)
        self.assertIs(parser.parse_args(["--no-verbose"]).verbose, False)

    def test_resolve_type_prefers_supported_annotations(self) -> None:
        cases = [
            (lambda value: None, str),
            (lambda flag=True: None, bool),
            (lambda count=5: None, int),
        ]
        for func, expected in cases:
            with self.subTest(expected=expected):
                parameter = next(iter(inspect.signature(func).parameters.values()))
                self.assertIs(_resolve_type(parameter), expected)

    def test_resolve_type_unwraps_optional_annotations(self) -> None:
        def sample(name: Optional[int]) -> None:
            return None

        parameter = inspect.signature(sample).parameters["name"]
        self.assertIs(_resolve_type(parameter), int)

    def test_resolve_type_ignores_list_annotation(self) -> None:
        def sample(items: list[int]) -> None:  # type: ignore[list-item]
            return None

        parameter = inspect.signature(sample).parameters["items"]
        self.assertIs(_resolve_type(parameter), str)

    def test_round_duration_limits_precision(self) -> None:
        self.assertEqual(_round_duration(1.23456789), 1.234568)

    def test_stringify_result_serialises_mappings_to_json(self) -> None:
        payload = {"alpha": 1, "beta": [2, 3]}
        text = _stringify_result(payload)
        self.assertEqual(text, json.dumps({"alpha": 1, "beta": [2, 3]}))


if __name__ == "__main__":
    unittest.main()
