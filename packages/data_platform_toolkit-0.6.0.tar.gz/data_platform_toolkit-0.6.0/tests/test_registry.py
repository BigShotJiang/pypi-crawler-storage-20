import contextlib
import json
import io
import unittest

from decorators.registry import CLIRegistry


class TestCLIRegistry(unittest.TestCase):
    def test_command_registration_rejects_duplicates(self) -> None:
        registry = CLIRegistry()

        @registry.command()
        def greet() -> None:
            return None

        with self.assertRaises(ValueError):

            @registry.command()
            def greet() -> None:
                return None

    def test_run_invokes_command_and_prints_return_value(self) -> None:
        registry = CLIRegistry()

        @registry.command()
        def say_hi() -> str:
            return "hello"

        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            exit_code = registry.run(["say-hi"])

        self.assertEqual(exit_code, 0)
        self.assertEqual(buffer.getvalue().strip(), "hello")

    def test_run_without_arguments_shows_command_help(self) -> None:
        registry = CLIRegistry()

        @registry.command()
        def greet() -> None:
            return None

        out_buffer = io.StringIO()
        with contextlib.redirect_stdout(out_buffer):
            exit_code = registry.run([])

        self.assertEqual(exit_code, 0)
        output = out_buffer.getvalue()
        self.assertIn("usage: greet", output)
        self.assertIn("-h, --help", output)

    def test_run_unknown_command_reports_error(self) -> None:
        registry = CLIRegistry()

        @registry.command()
        def ping() -> None:
            return None

        out_buffer = io.StringIO()
        err_buffer = io.StringIO()
        with contextlib.redirect_stdout(out_buffer), contextlib.redirect_stderr(err_buffer):
            exit_code = registry.run(["pong"])

        self.assertEqual(exit_code, 1)
        self.assertIn("Unknown command 'pong'.", out_buffer.getvalue())

        error_output = err_buffer.getvalue()
        self.assertIn("usage: ping", error_output)
        self.assertIn("-h, --help", error_output)

    def test_boolean_flag_argument_support(self) -> None:
        registry = CLIRegistry()

        @registry.command()
        def toggle(verbose: bool = False) -> bool:
            return verbose

        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            exit_code = registry.run(["toggle", "--verbose"])
        self.assertEqual(exit_code, 0)
        self.assertEqual(buffer.getvalue().strip(), "True")

        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            exit_code = registry.run(["toggle", "--no-verbose"])
        self.assertEqual(exit_code, 0)
        self.assertEqual(buffer.getvalue().strip(), "False")

    def test_dry_run_prints_preview_and_skips_execution(self) -> None:
        registry = CLIRegistry()
        called: list[str] = []

        @registry.command()
        def compute(x: int, y: int = 10, verbose: bool = False) -> int:
            # If this gets executed, the test should fail by side-effect
            called.append("executed")
            return x + y if verbose else x - y

        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            exit_code = registry.run(["--dry-run", "compute", "5", "--y", "7", "--verbose"])

        self.assertEqual(exit_code, 0)
        # Function must not be called
        self.assertEqual(called, [])

        # Output must be a valid JSON preview with dry_run event
        payload = buffer.getvalue().strip()
        self.assertTrue(payload)
        data = json.loads(payload)
        self.assertEqual(data.get("event"), "dry_run")
        self.assertEqual(data.get("function"), "compute")
        self.assertEqual(data.get("call", {}).get("kwargs"), {"x": 5, "y": 7, "verbose": True})

    def test_top_level_dry_run_without_command_lists_available(self) -> None:
        registry = CLIRegistry()

        @registry.command()
        def a() -> None:
            return None

        @registry.command()
        def b() -> None:
            return None

        buffer = io.StringIO()
        with contextlib.redirect_stdout(buffer):
            exit_code = registry.run(["--dry-run"])

        self.assertEqual(exit_code, 0)
        payload = buffer.getvalue().strip()
        data = json.loads(payload)
        self.assertEqual(data.get("event"), "dry_run")
        self.assertIsNone(data.get("function"))
        self.assertEqual(sorted(data.get("available", [])), ["a", "b"])


if __name__ == "__main__":
    unittest.main()
