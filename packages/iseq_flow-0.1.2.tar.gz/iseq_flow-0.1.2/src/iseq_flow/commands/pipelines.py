"""Pipeline commands for iseq-flow CLI."""

import asyncio

import click

from iseq_flow.api import APIError, ComputeAPIClient


@click.group()
def pipelines():
    """Manage pipelines."""
    pass


@pipelines.command("list")
def list_pipelines():
    """List available pipelines."""

    async def _list():
        client = ComputeAPIClient()
        try:
            pipelines_list = await client.list_pipelines()

            if not pipelines_list:
                click.echo("No pipelines found.")
                return

            # Print header
            click.echo(f"{'SLUG':<25} {'NAME':<25} {'MODE':<20} {'ACTIVE'}")
            click.echo("-" * 80)

            for p in pipelines_list:
                active = "Yes" if p.is_active else "No"
                click.echo(f"{p.slug:<25} {p.name:<25} {p.execution_mode:<20} {active}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_list())


@pipelines.command("info")
@click.argument("slug")
def pipeline_info(slug: str):
    """Get details about a pipeline.

    SLUG is the pipeline identifier (e.g., 'nextflow-minimal').
    """

    async def _info():
        client = ComputeAPIClient()
        try:
            p = await client.get_pipeline(slug)

            click.echo(f"Pipeline: {p.name}")
            click.echo(f"  Slug: {p.slug}")
            click.echo(f"  ID: {p.id}")
            click.echo(f"  Description: {p.description or 'N/A'}")
            click.echo(f"  Source Type: {p.source_type}")
            click.echo(f"  Execution Mode: {p.execution_mode}")
            click.echo(f"  Default Profile: {p.default_profile}")
            click.echo(f"  Active: {'Yes' if p.is_active else 'No'}")

        except APIError as e:
            click.echo(f"Error: {e}", err=True)
            raise SystemExit(1)

    asyncio.run(_info())
