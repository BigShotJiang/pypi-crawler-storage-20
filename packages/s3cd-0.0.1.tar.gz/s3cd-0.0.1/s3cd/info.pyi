from _typeshed import Incomplete

GITLAB_CI_VARS: Incomplete

def generate_info_json(source_dir: str, target_path: str, bucket: str, endpoint: str, region: str, addressing_style: str) -> str: ...
