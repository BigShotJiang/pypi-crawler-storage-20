from _typeshed import Incomplete
from s3cd.config import S3Config as S3Config
from s3cd.info import generate_info_json as generate_info_json

class S3Operations:
    config: Incomplete
    verbose: Incomplete
    s3_client: Incomplete
    def __init__(self, config: S3Config, verbose: bool = False) -> None: ...
    def upload(self, bucket: str, target: str, source_dir: str) -> None: ...
    def copy(self, from_bucket: str, from_target: str, to_bucket: str, to_target: str) -> None: ...
