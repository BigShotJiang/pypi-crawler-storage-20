import os
import sys
from dataclasses import dataclass
from typing import Optional
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None

@dataclass
class Config:
    """配置类，用于管理ylbot的环境变量和常量"""
    
    # 历史记录相关配置
    MAX_SINGLE_CHAR: int = 1000  # 单条最大字符数
    MAX_USER_RECORD_COUNT: int = 50  # 每个user允许的最多条数
    MAX_HISTORY_CONTENT_CHAR: int = 4000  # 历史记录content字段允许的最大字符数之和
    CLEAR_CYCLE: int = 7  # 定期清理用户记录的周期，单位是天
    HISTORY_ALGORITHM: str = "normal"  # 历史记录算法: "fair" (公平算法) 或 "normal" (普通算法)
    
    # 状态管理相关配置
    STATUS_CLEANUP_INTERVAL: int = 3600  # 状态清理间隔，单位秒
    
    # 自动回复相关配置
    AUTO_ANSWER_TIMEOUT: int = 10  # 自动回复超时时间，单位秒
    
    # LLM相关配置
    LLM_API_KEY: Optional[str] = None
    LLM_BASE_URL: Optional[str] = None
    LLM_MODEL: str = "deepseek-chat"
    
    # 数据库配置
    REDIS_URL: Optional[str] = None
    DATABASE_URL: Optional[str] = None
    
    def __init__(self, **kwargs):
        """初始化配置，优先从.env文件加载，然后从环境变量，最后使用默认值"""
        # 检查并加载.env文件
        self._setup_env_file()
        
        # 历史记录配置
        self.MAX_SINGLE_CHAR = int(os.getenv("MAX_SINGLE_CHAR", self.MAX_SINGLE_CHAR))
        self.MAX_USER_RECORD_COUNT = int(os.getenv("MAX_USER_RECORD_COUNT", self.MAX_USER_RECORD_COUNT))
        self.MAX_HISTORY_CONTENT_CHAR = int(os.getenv("MAX_HISTORY_CONTENT_CHAR", self.MAX_HISTORY_CONTENT_CHAR))
        self.CLEAR_CYCLE = int(os.getenv("CLEAR_CYCLE", self.CLEAR_CYCLE))
        self.HISTORY_ALGORITHM = os.getenv("HISTORY_ALGORITHM", self.HISTORY_ALGORITHM)
        
        # 状态管理配置
        self.STATUS_CLEANUP_INTERVAL = int(os.getenv("STATUS_CLEANUP_INTERVAL", self.STATUS_CLEANUP_INTERVAL))
        
        # 自动回复配置
        self.AUTO_ANSWER_TIMEOUT = int(os.getenv("AUTO_ANSWER_TIMEOUT", self.AUTO_ANSWER_TIMEOUT))
        
        # LLM配置
        self.LLM_API_KEY = os.getenv("LLM_API_KEY", self.LLM_API_KEY)
        self.LLM_BASE_URL = os.getenv("LLM_BASE_URL", self.LLM_BASE_URL)
        self.LLM_MODEL = os.getenv("LLM_MODEL", self.LLM_MODEL)
        
        # 数据库配置
        self.REDIS_URL = os.getenv("REDIS_URL", self.REDIS_URL)
        self.DATABASE_URL = os.getenv("DATABASE_URL", self.DATABASE_URL)
        
        # 覆盖传入的参数
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        
        # 验证HISTORY_ALGORITHM的有效性
        if self.HISTORY_ALGORITHM not in ["fair", "normal"]:
            raise ValueError(f"HISTORY_ALGORITHM must be 'fair' or 'normal', got '{self.HISTORY_ALGORITHM}'")
    
    def _setup_env_file(self):
        """检查并创建.env文件（如果不存在），然后加载它"""
        env_path = Path.cwd() / '.env'
        example_env_path = Path(__file__).parent.parent / '.env.example'
        
        # 如果不存在.env文件，尝试创建
        if not env_path.exists():
            try:
                # 如果存在.env.example，则复制它
                if example_env_path.exists():
                    with open(example_env_path, 'r', encoding='utf-8') as src:
                        content = src.read()
                    with open(env_path, 'w', encoding='utf-8') as dst:
                        dst.write(content)
                    print(f"已创建 .env 文件，请根据实际情况修改配置。文件路径: {env_path}")
                else:
                    # 创建一个基本的.env文件
                    basic_env_content = """# ylbot 环境变量配置文件
# 历史记录配置
MAX_SINGLE_CHAR=1000
MAX_USER_RECORD_COUNT=50
MAX_HISTORY_CONTENT_CHAR=4000
CLEAR_CYCLE=7
HISTORY_ALGORITHM=normal

# 状态管理配置
STATUS_CLEANUP_INTERVAL=3600

# 自动回复配置
AUTO_ANSWER_TIMEOUT=10

# LLM配置
LLM_API_KEY=ollama
LLM_BASE_URL=http://localhost:11434/v1
LLM_MODEL=qwen3:latest

# Redis配置
REDIS_URL=redis://localhost:6379/0
"""
                    with open(env_path, 'w', encoding='utf-8') as f:
                        f.write(basic_env_content)
                    print(f"已创建基本的 .env 文件，请根据实际情况修改配置。文件路径: {env_path}")
            except Exception as e:
                print(f"警告: 无法创建 .env 文件: {e}", file=sys.stderr)
                print("将继续使用环境变量或默认值。", file=sys.stderr)
        
        # 加载.env文件
        if load_dotenv is not None:
            load_dotenv(env_path, override=True)
        else:
            print("警告: 未安装 python-dotenv，将仅使用系统环境变量。", file=sys.stderr)
    
    @classmethod
    def from_env(cls) -> "Config":
        """从环境变量（包含.env文件）创建配置实例"""
        return cls()
