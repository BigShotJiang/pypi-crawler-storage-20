import click
import os
import pathlib
import subprocess
from .utils import print_banner, get_db_url
from .templates import (
    get_main_py, 
    get_db_base, 
    get_api_router, 
    get_testmike_files,
    get_alembic_env_py
)

@click.group()
def main():
    """CLI de FastMike para proyectos FastAPI Enterprise."""
    pass

@main.command()
@click.option('--name', default='fastapi-project', help='Nombre del proyecto')
def init(name):
    """Inicializa un nuevo proyecto con la estructura profesional de Mike."""
    print_banner()
    
    # 1. Crear Estructura de Carpetas
    folders = [
        "app/api/v1/endpoints", "app/core", "app/crud", "app/db",
        "app/models", "app/schemas", "app/services", "app/admin",
        "tests/api", "tests/crud", "TESTMIKE"
    ]
    
    click.echo("📁 Creando estructura de directorios...")
    for folder in folders:
        path = pathlib.Path(folder)
        path.mkdir(parents=True, exist_ok=True)
        (path / "__init__.py").touch()
    
    # 2. Obtener URL de DB y Generar Archivos Base
    db_url = get_db_url()
    
    click.echo("📝 Generando archivos base...")
    with open("app/main.py", "w", encoding="utf-8") as f: 
        f.write(get_main_py(name))
    
    with open("app/db/base_class.py", "w", encoding="utf-8") as f: 
        f.write(get_db_base())
        
    with open("app/api/v1/api.py", "w", encoding="utf-8") as f: 
        f.write(get_api_router())

    # 3. Generar Suite TESTMIKE
    click.echo("🧪 Generando suite de pruebas rápidas TESTMIKE...")
    tests = get_testmike_files(db_url)
    for filename, content in tests.items():
        with open(f"TESTMIKE/{filename}", "w", encoding="utf-8") as f:
            f.write(content)

    # 4. Configurar Alembic
    click.echo("⚙️ Configurando Alembic...")
    try:
        if not os.path.exists("alembic.ini"):
            subprocess.run(["alembic", "init", "alembic"], capture_output=True)
            
        # Modificar alembic.ini
        with open("alembic.ini", "r") as f: lines = f.readlines()
        with open("alembic.ini", "w") as f:
            for line in lines:
                if line.startswith("sqlalchemy.url"):
                    f.write(f"sqlalchemy.url = {db_url}\n")
                else: f.write(line)
        
        # Sobreescribir env.py para auto-detección
        with open("alembic/env.py", "w", encoding="utf-8") as f:
            f.write(get_alembic_env_py())
            
    except Exception as e:
        click.secho(f"⚠️ Error configurando Alembic: {e}", fg="yellow")

    # 5. Extras (Docker & .env)
    with open(".env", "w") as f:
        f.write(f"PROJECT_NAME={name}\nDATABASE_URL={db_url}\n")
    
    click.secho(f"\n🚀 Proyecto '{name}' listo para despegar!", fg='green', bold=True)
    click.echo("Usa 'pip install -r requirements.txt' y luego 'uvicorn app.main:app --reload'")
