def get_main_py(project_name):
    return f"""from fastapi import FastAPI
from app.api.v1.api import api_router

app = FastAPI(title="{project_name}")
app.include_router(api_router, prefix="/api/v1")

@app.get("/")
def read_root():
    return {{"message": "Welcome to {project_name}", "mike": "cardona076"}}
"""

def get_api_router():
    return "from fastapi import APIRouter\napi_router = APIRouter()"

def get_db_base():
    return """from sqlalchemy.ext.declarative import as_declarative, declared_attr
from typing import Any

@as_declarative()
class Base:
    id: Any
    __name__: str
    @declared_attr
    def __tablename__(cls) -> str:
        return cls.__name__.lower()
"""

def get_testmike_files(db_url):
    return {
        "db_check.py": f"import sqlalchemy; print('Checking {db_url}')",
        "security_auth.py": "import secrets; print(f'Token: {secrets.token_urlsafe(32)}')",
        # ... (puedes añadir los otros 3 aquí siguiendo el mismo formato)
    }

def get_alembic_env_py():
    return """# Contenido de env.py para detección automática de modelos
from app.db.base_class import Base
target_metadata = Base.metadata
# ... (resto de la lógica de alembic)
"""
