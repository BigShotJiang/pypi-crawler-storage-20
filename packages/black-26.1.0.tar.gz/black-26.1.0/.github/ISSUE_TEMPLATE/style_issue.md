---
name: Code style issue
about: Help us improve the Black code style
title: ""
labels: "T: style"
assignees: ""
---

**Describe the style change**

<!-- A clear and concise description of how the style can be
improved. -->

**Examples in the current _Black_ style**

<!-- Think of some short code snippets that show
how the current _Black_ style is not great: -->

```python
def f():
    """This code should be formatted as per the current Black style"""
    pass
```

**Desired style**

<!-- How do you think _Black_ should format the above snippets: -->

```python
def f(
    ):
    """This code can be formatted however you suggest!"""
    pass
```

**Additional context**

<!-- Add any other context about the problem here. -->
