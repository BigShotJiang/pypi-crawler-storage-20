class ModelNotBakedError(RuntimeError):
    pass