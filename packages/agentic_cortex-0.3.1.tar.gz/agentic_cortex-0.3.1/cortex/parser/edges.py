"""Edge extraction for building call graphs.

This module extracts CALLS edges by finding function/method calls in the AST
and resolving them to symbol IDs where possible.

Current scope (MVP):
- Same-file function calls: local_func() → file_path::::local_func
- Same-class method calls: self.method() → file_path::ClassName::method

Future enhancements:
- Import resolution: imported_func() → other_file.py::::imported_func
- Cross-file class method calls
"""

from typing import List, Set, Tuple, Optional
from tree_sitter import Node

from cortex.types import Symbol, Edge
from cortex.parser.extraction import get_node_text


def extract_edges(
    root: Node,
    source: str,
    file_path: str,
    symbols: List[Symbol],
) -> List[Edge]:
    """Extract CALLS edges from parsed AST.

    Finds function/method calls and resolves them to known symbols.

    Args:
        root: Root AST node (module)
        source: Full source code string
        file_path: File path for symbol ID generation
        symbols: List of symbols already extracted from this file

    Returns:
        List of Edge objects representing CALLS relationships
    """
    # Build lookup tables for resolution
    # Simple function names in this file
    file_functions: Set[str] = set()
    # Class method names: {class_name: {method_name}}
    class_methods: dict[str, Set[str]] = {}

    for sym in symbols:
        if sym.kind == "function":
            # Extract just the function name from ID
            name = sym.id.split("::")[-1]
            file_functions.add(name)
        elif sym.kind == "method":
            # Extract class name and method name from ID
            # Format: file_path::ClassName::method_name
            parts = sym.id.split("::")
            if len(parts) >= 3:
                class_name = parts[-2]
                method_name = parts[-1]
                if class_name not in class_methods:
                    class_methods[class_name] = set()
                class_methods[class_name].add(method_name)

    edges: List[Edge] = []

    # Traverse AST to find all function/method definitions and their calls
    _extract_calls_from_node(
        root, source, file_path, "", None, file_functions, class_methods, edges
    )

    return edges


def _extract_calls_from_node(
    node: Node,
    source: str,
    file_path: str,
    scope_chain: str,
    current_class: Optional[str],
    file_functions: Set[str],
    class_methods: dict[str, Set[str]],
    edges: List[Edge],
) -> None:
    """Recursively extract calls from AST nodes.

    Args:
        node: Current AST node
        source: Full source code string
        file_path: File path for symbol IDs
        scope_chain: Current scope chain for caller ID
        current_class: Name of current class (for self.method resolution)
        file_functions: Set of function names in this file
        class_methods: Dict of class name -> method names
        edges: List to append edges to
    """
    node_type = node.type

    if node_type == "function_definition":
        # Extract function name and update scope
        func_name = _get_identifier_name(node, source)
        if func_name:
            # Determine caller ID based on scope
            if current_class:
                caller_id = f"{file_path}::{current_class}::{func_name}"
            else:
                caller_id = f"{file_path}::::{func_name}"

            # Process function body for calls
            for child in node.children:
                if child.type == "block":
                    _extract_calls_from_block(
                        child,
                        source,
                        file_path,
                        caller_id,
                        current_class,
                        file_functions,
                        class_methods,
                        edges,
                    )
        return  # Don't recurse further - we handled the block

    elif node_type == "class_definition":
        # Extract class name and update context
        class_name = _get_identifier_name(node, source)
        if class_name:
            # Recurse into class body with new context
            for child in node.children:
                if child.type == "block":
                    _extract_calls_from_node(
                        child,
                        source,
                        file_path,
                        scope_chain,
                        class_name,  # Set current class
                        file_functions,
                        class_methods,
                        edges,
                    )
        return

    # Recurse into children
    for child in node.children:
        _extract_calls_from_node(
            child,
            source,
            file_path,
            scope_chain,
            current_class,
            file_functions,
            class_methods,
            edges,
        )


def _extract_calls_from_block(
    block: Node,
    source: str,
    file_path: str,
    caller_id: str,
    current_class: Optional[str],
    file_functions: Set[str],
    class_methods: dict[str, Set[str]],
    edges: List[Edge],
) -> None:
    """Extract calls from a function/method block.

    Args:
        block: Block node containing function body
        source: Full source code string
        file_path: File path for symbol IDs
        caller_id: Symbol ID of the calling function/method
        current_class: Current class name (for self.method resolution)
        file_functions: Set of function names in this file
        class_methods: Dict of class name -> method names
        edges: List to append edges to
    """
    _find_calls_recursive(
        block,
        source,
        file_path,
        caller_id,
        current_class,
        file_functions,
        class_methods,
        edges,
    )


def _find_calls_recursive(
    node: Node,
    source: str,
    file_path: str,
    caller_id: str,
    current_class: Optional[str],
    file_functions: Set[str],
    class_methods: dict[str, Set[str]],
    edges: List[Edge],
) -> None:
    """Recursively find call nodes and create edges.

    Args:
        node: Current AST node
        source: Full source code string
        file_path: File path for symbol IDs
        caller_id: Symbol ID of the calling function/method
        current_class: Current class name (for self.method resolution)
        file_functions: Set of function names in this file
        class_methods: Dict of class name -> method names
        edges: List to append edges to
    """
    if node.type == "call":
        # Found a call - try to resolve it
        target_id = _resolve_call(
            node, source, file_path, current_class, file_functions, class_methods
        )
        if target_id:
            edges.append(Edge(source_id=caller_id, target_id=target_id, type="CALLS"))

    # Recurse into children (but not into nested function definitions)
    for child in node.children:
        if child.type not in ("function_definition", "class_definition"):
            _find_calls_recursive(
                child,
                source,
                file_path,
                caller_id,
                current_class,
                file_functions,
                class_methods,
                edges,
            )


def _resolve_call(
    call_node: Node,
    source: str,
    file_path: str,
    current_class: Optional[str],
    file_functions: Set[str],
    class_methods: dict[str, Set[str]],
) -> Optional[str]:
    """Resolve a call node to a target symbol ID.

    Args:
        call_node: Call AST node
        source: Full source code string
        file_path: File path for symbol IDs
        current_class: Current class name
        file_functions: Set of function names in this file
        class_methods: Dict of class name -> method names

    Returns:
        Target symbol ID if resolvable, None otherwise
    """
    # Get the function part of the call
    func_node = None
    for child in call_node.children:
        if child.type in ("identifier", "attribute"):
            func_node = child
            break

    if func_node is None:
        return None

    if func_node.type == "identifier":
        # Simple function call: func_name()
        func_name = get_node_text(func_node, source)
        if func_name in file_functions:
            return f"{file_path}::::{func_name}"

    elif func_node.type == "attribute":
        # Attribute call: obj.method() or self.method()
        func_text = get_node_text(func_node, source)

        # Check for self.method() pattern
        if func_text.startswith("self.") and current_class:
            method_name = func_text[5:]  # Remove "self."
            # Check if this method exists in current class
            if current_class in class_methods and method_name in class_methods[current_class]:
                return f"{file_path}::{current_class}::{method_name}"

    return None


def _get_identifier_name(node: Node, source: str) -> Optional[str]:
    """Get the identifier name from a function/class definition node."""
    for child in node.children:
        if child.type == "identifier":
            return get_node_text(child, source)
    return None
