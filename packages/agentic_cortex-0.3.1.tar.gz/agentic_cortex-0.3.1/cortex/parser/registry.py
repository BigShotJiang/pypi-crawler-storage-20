"""Language registry for loading and managing language-specific parsers from YAML definitions.

This module implements the LanguageRegistry class that loads YAML language definitions,
matches file extensions to languages, and returns configured parser instances.
"""

import yaml
from pathlib import Path
from typing import Dict, Optional, List
from dataclasses import dataclass

from tree_sitter import Language, Parser as TSParser
import tree_sitter_python as tspython
import tree_sitter_typescript as tstypescript

from cortex.parser.extraction import (
    get_node_text,
    extract_identifier_name,
    extract_signature,
    extract_body_text,
    extract_docstring,
    calculate_checksum,
)


@dataclass
class LanguageConfig:
    """Configuration for a language parser loaded from YAML."""

    language_id: str
    grammar_name: str
    extensions: List[str]
    queries: Dict[str, Dict[str, str]]


class GenericParser:
    """Generic parser that uses Tree-sitter queries from YAML configuration."""

    def __init__(self, config: LanguageConfig, language: Language):
        """Initialize parser with language configuration.

        Args:
            config: Language configuration from YAML
            language: Tree-sitter Language object
        """
        self.language_id = config.language_id
        self.grammar_name = config.grammar_name
        self.queries = config.queries
        self.config = config
        self.parser = TSParser(language)

    def parse(self, source: str, file_path: str = "") -> List:
        """Parse source code and extract symbols.

        Uses Tree-sitter queries from YAML config to extract functions and classes.

        Args:
            source: Source code to parse
            file_path: File path for symbol ID generation

        Returns:
            List of extracted symbols
        """
        # Parse with Tree-sitter
        tree = self.parser.parse(bytes(source, "utf8"))
        root = tree.root_node

        symbols = []

        # Extract functions using query from config
        if "functions" in self.queries:
            # Note: Query string available in self.queries["functions"]["query"]
            # for future full query compilation. For now, use basic node traversal.
            self._extract_functions(root, source, file_path, "", symbols)

        # Extract classes using query from config
        if "classes" in self.queries:
            # Extract class definitions
            self._extract_classes(root, source, file_path, "", symbols)

        # Extract module-level constants (Python-specific for now)
        if self.language_id == "python":
            self._extract_constants(root, source, file_path, symbols)

        return symbols

    def _extract_functions(self, node, source: str, file_path: str, scope_chain: str, symbols: List) -> None:
        """Extract function definitions from AST using shared utilities."""
        from cortex.types import Symbol
        from cortex.symbols.id import generate_symbol_id

        node_type = getattr(node, "type", getattr(node, "kind", None))

        if node_type == "function_definition":
            name = extract_identifier_name(node, source)
            if name:
                signature = extract_signature(node, source, "def")
                body_text = extract_body_text(node, source)
                checksum = calculate_checksum(body_text)
                docstring = extract_docstring(node, source)

                symbol_id = generate_symbol_id(file_path, scope_chain, name)
                kind = "method" if scope_chain else "function"

                symbols.append(Symbol(
                    id=symbol_id,
                    file_path=file_path,
                    kind=kind,
                    signature=signature,
                    docstring=docstring,
                    start_line=node.start_point[0] + 1,
                    end_line=node.end_point[0] + 1,
                    checksum=checksum,
                ))

        elif node_type == "class_definition":
            # Skip class bodies - methods are extracted by _extract_classes
            return

        # Recurse into children
        for child in node.children:
            self._extract_functions(child, source, file_path, scope_chain, symbols)

    def _extract_classes(self, node, source: str, file_path: str, scope_chain: str, symbols: List) -> None:
        """Extract class definitions from AST using shared utilities."""
        from cortex.types import Symbol
        from cortex.symbols.id import generate_symbol_id

        node_type = getattr(node, "type", getattr(node, "kind", None))

        if node_type == "class_definition":
            name = extract_identifier_name(node, source)
            if name:
                signature = extract_signature(node, source, "class")
                body_text = extract_body_text(node, source)
                checksum = calculate_checksum(body_text)
                docstring = extract_docstring(node, source)

                symbol_id = generate_symbol_id(file_path, scope_chain, name)

                symbols.append(Symbol(
                    id=symbol_id,
                    file_path=file_path,
                    kind="class",
                    signature=signature,
                    docstring=docstring,
                    start_line=node.start_point[0] + 1,
                    end_line=node.end_point[0] + 1,
                    checksum=checksum,
                ))

                # Extract methods inside class with updated scope chain
                new_scope = f"{scope_chain}::{name}" if scope_chain else name
                for child in node.children:
                    if child.type == "block":
                        self._extract_functions(child, source, file_path, new_scope, symbols)
                return  # Don't recurse further - we handled the class body

        # Recurse into children
        for child in node.children:
            self._extract_classes(child, source, file_path, scope_chain, symbols)

    def _extract_constants(self, root, source: str, file_path: str, symbols: List) -> None:
        """Extract module-level constant assignments from AST.

        Captures module-level assignments like:
        - ANIMAL_VARIANTS = {...}
        - MAX_SIZE: int = 100
        - MyType = Dict[str, int]

        Only processes direct children of module node (not nested assignments).

        Args:
            root: Root node (module)
            source: Full source code string
            file_path: File path for symbol IDs
            symbols: List to append extracted symbols to
        """
        from cortex.types import Symbol
        from cortex.symbols.id import generate_symbol_id

        # Only process direct children of module
        if root.type != "module":
            return

        for child in root.children:
            if child.type != "expression_statement":
                continue

            # Look for assignment within expression_statement
            for subchild in child.children:
                if subchild.type != "assignment":
                    continue

                # Extract variable name
                name = None
                for part in subchild.children:
                    if part.type == "identifier":
                        name = get_node_text(part, source)
                        break

                if not name:
                    continue

                # Skip private variables (single underscore) but keep dunder and constants
                if name.startswith("_") and not name.startswith("__"):
                    continue

                # Build signature showing the assignment
                full_text = get_node_text(subchild, source)

                # Truncate long values in signature
                if len(full_text) > 80:
                    eq_pos = full_text.find("=")
                    if eq_pos > 0:
                        lhs = full_text[:eq_pos + 1].strip()
                        rhs = full_text[eq_pos + 1:].strip()
                        if rhs.startswith("{"):
                            signature = f"{lhs} {{...}}"
                        elif rhs.startswith("["):
                            signature = f"{lhs} [...]"
                        elif rhs.startswith("("):
                            signature = f"{lhs} (...)"
                        else:
                            signature = f"{lhs} ..."
                    else:
                        signature = full_text[:77] + "..."
                else:
                    signature = full_text

                checksum = calculate_checksum(full_text)
                symbol_id = generate_symbol_id(file_path, "", name)

                symbols.append(Symbol(
                    id=symbol_id,
                    file_path=file_path,
                    kind="constant",
                    signature=signature,
                    docstring=None,
                    start_line=subchild.start_point[0] + 1,
                    end_line=subchild.end_point[0] + 1,
                    checksum=checksum,
                ))


class LanguageRegistry:
    """Registry for loading and managing language-specific parsers.

    Loads YAML language definitions from a directory, validates schemas,
    and provides parsers matched to file extensions.
    """

    def __init__(self, languages_dir: Path):
        """Initialize registry with languages directory.

        Args:
            languages_dir: Path to directory containing language YAML files
        """
        self.languages_dir = Path(languages_dir)
        self._configs: Dict[str, LanguageConfig] = {}
        self._extension_map: Dict[str, str] = {}  # extension -> language_id
        self._parsers: Dict[str, GenericParser] = {}
        self._loaded = False

    def load_languages(self) -> List[str]:
        """Load all language YAML files from the languages directory.

        Returns:
            List of loaded language IDs

        Raises:
            ValueError: If YAML validation fails
            yaml.YAMLError: If YAML is malformed
        """
        if not self.languages_dir.exists():
            raise ValueError(f"Languages directory does not exist: {self.languages_dir}")

        language_ids = []

        # Load all .yaml files
        for yaml_file in self.languages_dir.glob("*.yaml"):
            try:
                with open(yaml_file, "r") as f:
                    data = yaml.safe_load(f)
            except yaml.YAMLError as e:
                raise yaml.YAMLError(f"Malformed YAML in {yaml_file}: {e}") from e

            if data is None:
                continue

            # Validate required fields
            if "language_id" not in data:
                raise ValueError(f"Missing 'language_id' in {yaml_file}")
            if "grammar_name" not in data:
                raise ValueError(f"Missing 'grammar_name' in {yaml_file}")
            if "extensions" not in data:
                raise ValueError(f"Missing 'extensions' in {yaml_file}")
            if "queries" not in data:
                raise ValueError(f"Missing 'queries' in {yaml_file}")

            language_id = data["language_id"]
            grammar_name = data["grammar_name"]
            extensions = data["extensions"]
            queries = data["queries"]

            # Store configuration
            config = LanguageConfig(
                language_id=language_id,
                grammar_name=grammar_name,
                extensions=extensions,
                queries=queries,
            )
            self._configs[language_id] = config

            # Build extension map
            for ext in extensions:
                self._extension_map[ext] = language_id

            language_ids.append(language_id)

        self._loaded = True
        return language_ids

    def get_parser_for_file(self, file_path: str) -> Optional[GenericParser]:
        """Get parser for a file based on its extension.

        Args:
            file_path: File path (e.g., "src/main.py")

        Returns:
            Configured parser instance or None if no matching language
        """
        if not self._loaded:
            self.load_languages()

        file_path_obj = Path(file_path)
        extension = file_path_obj.suffix

        if extension not in self._extension_map:
            return None

        language_id = self._extension_map[extension]
        return self.get_parser(language_id)

    def get_parser(self, language_id: str) -> GenericParser:
        """Get configured parser instance for a language.

        Args:
            language_id: Language identifier (e.g., "python")

        Returns:
            Configured parser instance

        Raises:
            KeyError: If language_id not found
        """
        if not self._loaded:
            self.load_languages()

        if language_id not in self._configs:
            raise KeyError(f"Unknown language: {language_id}")

        # Return cached parser if available
        if language_id in self._parsers:
            return self._parsers[language_id]

        # Create parser instance
        config = self._configs[language_id]

        # Load Tree-sitter language
        if config.grammar_name == "tree-sitter-python":
            language = Language(tspython.language())
        elif config.grammar_name == "tree-sitter-typescript":
            # tree-sitter-typescript provides both typescript and tsx
            # Use TSX parser for both .ts and .tsx since TSX is a superset
            language = Language(tstypescript.language_tsx())
        else:
            raise ValueError(
                f"Unsupported grammar: {config.grammar_name}. "
                "Install the corresponding tree-sitter grammar package."
            )

        parser = GenericParser(config, language)
        self._parsers[language_id] = parser

        return parser
