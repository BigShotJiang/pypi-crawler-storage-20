"""CLI command for 'cortex reindex'."""

import sys
import sqlite3
import fnmatch
from pathlib import Path

from cortex.config import find_cortex_root, load_config, get_db_paths
from cortex.parser.registry import LanguageRegistry
from cortex.watcher.sync import sync_file, sync_edges


def _scan_codebase(project_root: Path, config, db_path: Path) -> None:
    """Scan codebase and parse files to extract symbols.

    Args:
        project_root: Project root directory
        config: Config object with file patterns
        db_path: Path to SQLite database
    """
    # Initialize language registry from .cortex/languages/
    languages_dir = project_root / ".cortex" / "languages"

    # Ensure languages directory exists and has files
    if not languages_dir.exists() or not list(languages_dir.glob("*.yaml")):
        # Copy language files from package if missing
        import shutil

        package_languages_dir = Path(__file__).parent.parent.parent / "data" / "languages"
        if package_languages_dir.exists():
            languages_dir.mkdir(parents=True, exist_ok=True)
            for yaml_file in package_languages_dir.glob("*.yaml"):
                dest_file = languages_dir / yaml_file.name
                if not dest_file.exists():
                    shutil.copy2(yaml_file, dest_file)

    registry = LanguageRegistry(languages_dir)
    try:
        registry.load_languages()
    except ValueError:
        # No language files - can't parse anything
        return

    # Get database connection
    conn = sqlite3.connect(str(db_path), check_same_thread=False)

    # Find all files matching include/exclude patterns
    files_to_scan = []
    for root_pattern in config.project.roots:
        # Resolve root pattern relative to project root
        if root_pattern == ".":
            root_dir = project_root
        else:
            root_dir = project_root / root_pattern

        if not root_dir.exists():
            continue

        # Walk directory tree
        for file_path in root_dir.rglob("*"):
            if not file_path.is_file():
                continue

            # Convert to relative path from project_root
            try:
                rel_path = file_path.relative_to(project_root)
            except ValueError:
                continue

            rel_path_str = str(rel_path)

            # Check include patterns
            matched_include = False
            for include_pattern in config.files.include:
                if fnmatch.fnmatch(rel_path_str, include_pattern) or fnmatch.fnmatch(
                    str(file_path), include_pattern
                ):
                    matched_include = True
                    break

            if not matched_include:
                continue

            # Check exclude patterns
            matched_exclude = False
            for exclude_pattern in config.files.exclude:
                if fnmatch.fnmatch(rel_path_str, exclude_pattern) or fnmatch.fnmatch(
                    str(file_path), exclude_pattern
                ):
                    matched_exclude = True
                    break

            if matched_exclude:
                continue

            files_to_scan.append((file_path, rel_path_str))

    # Parse each file and sync to database
    for file_path, rel_path_str in files_to_scan:
        # Get parser for this file
        parser = registry.get_parser_for_file(rel_path_str)
        if parser is None:
            continue

        # Read file content
        try:
            source = file_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            # Skip files that can't be read
            continue

        # Parse file
        try:
            symbols = parser.parse(source, rel_path_str)
        except (ValueError, RuntimeError):
            # Skip files that can't be parsed
            continue

        # Sync to database
        if symbols:
            sync_file(conn, rel_path_str, symbols)

            # Extract and sync edges (Python files only for now)
            if rel_path_str.endswith(".py"):
                try:
                    edges = _extract_edges_from_source(source, rel_path_str, symbols)
                    if edges:
                        sync_edges(conn, rel_path_str, edges)
                except (ValueError, RuntimeError):
                    # Skip edge extraction if it fails
                    pass

    conn.close()


def _extract_edges_from_source(source: str, file_path: str, symbols) -> list:
    """Extract CALLS edges from Python source code.

    Args:
        source: Python source code
        file_path: File path for symbol IDs
        symbols: List of symbols already extracted from this file

    Returns:
        List of Edge objects
    """
    import tree_sitter_python as tspython
    from tree_sitter import Language, Parser
    from cortex.parser.edges import extract_edges

    # Parse AST
    language = Language(tspython.language())
    parser = Parser(language)
    tree = parser.parse(bytes(source, "utf8"))

    # Extract edges
    return extract_edges(tree.root_node, source, file_path, symbols)


def _relink_memory_anchors(conn: sqlite3.Connection, lancedb_path: Path) -> None:
    """Attempt to re-link memory anchors to new symbol IDs.

    This is a best-effort attempt. If symbol IDs changed, we try to match
    by file path and symbol name to re-link memories.

    Args:
        conn: SQLite database connection
        lancedb_path: Path to LanceDB directory
    """
    try:
        from cortex.db import initialize_lancedb

        # Open vector store
        vector_store = initialize_lancedb(str(lancedb_path))

        # Get all vectors with their anchor_symbol_ids
        try:
            _ = vector_store.to_table()
            # For now, we'll leave anchor_symbol_ids as-is
            # In a full implementation, we'd:
            # 1. Extract old symbol IDs from anchor_symbol_id
            # 2. Try to find matching new symbol IDs by parsing the ID
            # 3. Update anchor_symbol_id if a match is found
            # This is complex and would require parsing symbol IDs and matching
            # For now, we preserve the anchors as-is (they may become orphaned)
            pass
        except (AttributeError, OSError):
            # Vector store is empty or not accessible
            pass
    except (ImportError, OSError):
        # LanceDB not available - skip re-linking
        pass


def reindex_command(project_root: Path) -> None:
    """Reindex the codebase.

    Truncates Tier 1 & 2 tables (symbols, edges), preserves Tier 3 (vector store),
    re-parses all files matching config patterns, and attempts to re-link memory anchors.

    Args:
        project_root: Path to project root directory (or any subdirectory)
    """
    # Find .cortex/ directory (walk up tree if needed)
    try:
        cortex_dir = find_cortex_root(project_root)
    except FileNotFoundError:
        print("Error: Could not find .cortex/ directory. Run 'cortex init' first.", file=sys.stderr)
        sys.exit(1)

    # Load config
    try:
        config = load_config(cortex_dir)
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: Failed to load config: {e}", file=sys.stderr)
        sys.exit(1)

    # Get database paths from config
    sqlite_path, lancedb_path = get_db_paths(config, cortex_dir)

    # Connect to SQLite database (initialize if needed)
    from cortex.db import create_schema

    conn = sqlite3.connect(str(sqlite_path), check_same_thread=False)
    cursor = conn.cursor()

    # Drop and recreate tables to ensure full schema (in case test created minimal tables)
    cursor.execute("DROP TABLE IF EXISTS symbol_search")
    cursor.execute("DROP TABLE IF EXISTS symbols_fts")  # Legacy table name cleanup
    cursor.execute("DROP TABLE IF EXISTS edges")
    cursor.execute("DROP TABLE IF EXISTS symbols")

    # Recreate schema with full structure
    create_schema(conn)

    conn.commit()
    conn.close()

    # Get actual project root (parent of .cortex/)
    actual_project_root = cortex_dir.parent

    # Re-parse all files matching config patterns
    _scan_codebase(actual_project_root, config, sqlite_path)

    # Attempt to re-link memory anchors
    # Note: This is a best-effort operation
    conn = sqlite3.connect(str(sqlite_path), check_same_thread=False)
    _relink_memory_anchors(conn, lancedb_path)
    conn.close()
