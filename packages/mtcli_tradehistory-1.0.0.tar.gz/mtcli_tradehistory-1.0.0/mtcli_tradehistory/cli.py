# mtcli_tradehistory/cli.py

import click
from datetime import datetime
from .controller import TradeHistoryController
from .view import TradeHistoryView
from .conf import SYMBOL


@click.command()
@click.version_option(package_name="mtcli-tradehistory")
@click.option(
    "--date",
    "-d",
    default=None,
    help="Data do pregão YYYY-MM-DD (padrao: hoje).",
)
@click.option(
    "--symbol",
    "-s",
    default=SYMBOL,
    show_default=True,
    help="Código do ativo.",
)
def tradehistory(date: str | None, symbol: str | None):
    """
    Exibe o histórico de negócios executados no pregão.
    """

    if date is None:
        date_obj = datetime.now()
    else:
        date_obj = datetime.strptime(date, "%Y-%m-%d")

    controller = TradeHistoryController()
    view = TradeHistoryView()

    trades = controller.load_trades(date_obj, symbol)
    view.render(trades)
