# mtcli_tradehistory/view.py

from typing import List
from .model import TradeDeal


class TradeHistoryView:
    """
    View responsável pela exibição textual do histórico
    de negócios no terminal.
    """

    def render(self, trades: List[TradeDeal]):
        if not trades:
            print("Nenhum trade encontrado no pregão.")
            return

        print("-" * 72)
        print("HISTÓRICO DE NEGÓCIOS DO PREGÃO")
        print("Horário exibido: horário local (convertido do servidor)")
        print("-" * 72)

        for t in trades:
            print(
                f"{t.time:%H:%M:%S} | "
                f"{t.symbol:<6} | "
                f"{t.deal_type:<4} | "
                f"Preço {t.price:.2f} | "
                f"Vol {t.volume:.2f} | "
                f"P&L {t.profit:.2f} | "
                f"Pos {t.position_id}"
            )
