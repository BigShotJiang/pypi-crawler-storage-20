# mtcli_tradehistory/model.py

from datetime import datetime, timedelta, timezone
from typing import List, Optional
import MetaTrader5 as mt5

from .conf import SERVER_TZ_OFFSET


class TradeDeal:
    """Representa um negócio (deal) executado no MetaTrader 5."""

    def __init__(
        self,
        time: datetime,
        symbol: str,
        deal_type: str,
        price: float,
        volume: float,
        profit: float,
        position_id: int,
    ):
        self.time = time
        self.symbol = symbol
        self.deal_type = deal_type
        self.price = price
        self.volume = volume
        self.profit = profit
        self.position_id = position_id


class TradeHistoryModel:
    """
    Acessa o histórico de negócios (deals) do MetaTrader 5.

    IMPORTANTE:
    - d.time está no horário do SERVIDOR
    - o fuso do servidor é configurado via SERVER_TZ_OFFSET
    - nenhuma conversão automática de SO é aplicada
    """

    def __init__(self):
        if not mt5.initialize():
            raise RuntimeError("Falha ao inicializar MetaTrader5")

        self.server_tz = timezone(
            timedelta(hours=SERVER_TZ_OFFSET)
        )

    def get_deals(
        self,
        date: datetime,
        symbol: Optional[str] = None,
    ) -> List[TradeDeal]:

        start = datetime(date.year, date.month, date.day)
        end = start + timedelta(days=1)

        deals = mt5.history_deals_get(start, end)
        if deals is None:
            return []

        result: List[TradeDeal] = []

        for d in deals:
            if symbol and d.symbol != symbol:
                continue

            deal_type = (
                "BUY" if d.type == mt5.DEAL_TYPE_BUY else "SELL"
            )

            # ✅ AGORA FUNCIONA:
            # o horário exibido respeita SERVER_TZ_OFFSET
            deal_time = datetime.fromtimestamp(
                d.time,
                tz=self.server_tz,
            )

            result.append(
                TradeDeal(
                    time=deal_time,
                    symbol=d.symbol,
                    deal_type=deal_type,
                    price=d.price,
                    volume=d.volume,
                    profit=d.profit,
                    position_id=d.position_id,
                )
            )

        return result
