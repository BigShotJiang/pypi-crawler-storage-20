# mtcli_tradehistory/controller.py

from datetime import datetime
from .model import TradeHistoryModel, TradeDeal


class TradeHistoryController:
    """
    Controlador responsável por carregar e ordenar
    os trades do pregão.
    """

    def __init__(self):
        self.model = TradeHistoryModel()

    def load_trades(
        self,
        date: datetime,
        symbol: str | None = None,
    ) -> list[TradeDeal]:
        trades = self.model.get_deals(date, symbol)
        trades.sort(key=lambda x: x.time)
        return trades
