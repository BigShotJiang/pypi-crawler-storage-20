# mtcli_tradehistory/conf.py

import os
from mtcli.conf import config

"""
Configurações do plugin mtcli-tradehistory.

SERVER_TZ_OFFSET:
    Fuso horário do SERVIDOR do MetaTrader 5 em horas.
    Exemplos:
      UTC+0  -> 0
      UTC+3  -> 3
      UTC-3  -> -3

Este valor é essencial para alinhar os horários exibidos
com o gráfico e o Times & Trades do MT5.
"""

SYMBOL = os.getenv(
    "SYMBOL",
    config["DEFAULT"].get("symbol", fallback="WIN$N"),
)

DIGITOS = int(
    os.getenv(
        "DIGITOS",
        config["DEFAULT"].getint("digitos", fallback=2),
    )
)

SERVER_TZ_OFFSET = int(
    os.getenv(
        "SERVER_TZ_OFFSET",
        config["DEFAULT"].getint("server_tz_offset", fallback=0),
    )
)
