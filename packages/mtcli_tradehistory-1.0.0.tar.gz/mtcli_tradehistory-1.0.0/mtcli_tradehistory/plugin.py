from .cli import tradehistory


def register(cli):
    cli.add_command(tradehistory, name="th")
