# QuantumDLearning

A framework for quantum machine learning that integrates the latest research results in quantum computing and deep learning.

## Installation

### From PyPI

```bash
pip install quantumdlearning
```

### From Source

```bash
git clone https://github.com/quantumdlearning/quantumdlearning.git
cd quantumdlearning
pip install -e .
```

## Quick Start

```python
import quantumdlearning
import torch

# Create a quantum circuit
circuit = quantumdlearning.QubitCircuit(num_qubits=2)

# Add quantum gates
circuit.add_gate("H", [0])
circuit.add_gate("CNOT", [0, 1])

# Run the circuit
result = circuit.run()
print(result)
```

## Features

- **Quantum Circuits**: Support for qubit circuits, distributed circuits, and photonic circuits
- **Quantum Gates**: Comprehensive library of quantum gates (Pauli, rotation, CNOT, etc.)
- **Quantum Neural Networks**: Advanced QNN models including quantum transformers
- **Quantum Optimizers**: Various quantum optimization algorithms
- **Quantum Layers**: Different types of quantum layers
- **Mathematical Tools**: Rich set of quantum mathematical functions
- **Photonic Quantum Computing**: Support for continuous-variable quantum computing
- **Measurement-Based Quantum Computing**: Support for MBQC
- **Distributed Quantum Computing**: Support for distributed quantum systems

## Documentation

For detailed documentation, please visit [QuantumDLearning Documentation](https://github.com/quantumdlearning/quantumdlearning/wiki).

## Examples

See the `examples/` directory for more examples.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Citation

If you use QuantumDLearning in your research, please cite:

```bibtex
@software{quantumdlearning,
  title={QuantumDLearning: A Framework for Quantum Machine Learning},
  author={QuantumDLearning Team},
  year={2024},
  url={https://github.com/quantumdlearning/quantumdlearning}
}
```

## Contact

For questions and support, please open an issue on GitHub or contact us at quantumdlearning@example.com.
