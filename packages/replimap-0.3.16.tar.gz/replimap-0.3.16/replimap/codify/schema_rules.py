"""
Schema Rule Loader - Load and cache mapping rules from YAML.

Single Source of Truth for all AWS → Terraform mappings.
This module loads rules from schema_rules.yaml and provides
methods to query them for field filtering, renaming, and typing.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)


@dataclass
class BlockConfig:
    """Configuration for a block field."""

    name: str
    block_type: str = "block"  # block, set, list
    sort_keys: list[str] | None = None
    keep_empty: bool = False


@dataclass
class FlattenConfig:
    """Configuration for structure flattening."""

    source: str
    target: str  # "__root__" for root level
    mapping: dict[str, str] = field(default_factory=dict)


@dataclass
class ResourceRules:
    """Rules for a specific Terraform resource type."""

    renames: dict[str, str] = field(default_factory=dict)
    ignores: set[str] = field(default_factory=set)
    keep: set[str] = field(default_factory=set)  # Whitelist override
    types: dict[str, str] = field(default_factory=dict)
    blocks: dict[str, BlockConfig] = field(default_factory=dict)
    defaults: dict[str, Any] = field(default_factory=dict)
    secrets: set[str] = field(default_factory=set)
    flatten: list[FlattenConfig] = field(default_factory=list)


@dataclass
class GlobalRules:
    """Global rules applied to all resources."""

    readonly_patterns: list[re.Pattern] = field(default_factory=list)
    json_patterns: list[re.Pattern] = field(default_factory=list)
    prune_empty: bool = True
    prune_values: list[Any] = field(default_factory=lambda: ["", [], {}, None])


class SchemaRuleLoader:
    """Load and provide access to schema mapping rules."""

    _instance: SchemaRuleLoader | None = None
    _rules_cache: dict[str, ResourceRules] = {}
    _global_rules: GlobalRules | None = None
    _loaded: bool = False

    def __new__(cls) -> SchemaRuleLoader:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        if not self._loaded:
            self._load_rules()
            SchemaRuleLoader._loaded = True

    def _load_rules(self) -> None:
        """Load rules from YAML file."""
        yaml_path = Path(__file__).parent.parent / "data" / "schema_rules.yaml"

        if not yaml_path.exists():
            logger.warning(f"Schema rules file not found: {yaml_path}")
            self._global_rules = GlobalRules()
            return

        with open(yaml_path) as f:
            data = yaml.safe_load(f)

        if not data:
            logger.warning("Schema rules file is empty")
            self._global_rules = GlobalRules()
            return

        # Load global rules
        global_data = data.get("global", {})
        prune_config = global_data.get("prune_empty", {})

        self._global_rules = GlobalRules(
            readonly_patterns=[
                re.compile(p, re.IGNORECASE)
                for p in global_data.get("readonly_patterns", [])
            ],
            json_patterns=[
                re.compile(p, re.IGNORECASE)
                for p in global_data.get("json_patterns", [])
            ],
            prune_empty=(
                prune_config.get("enabled", True)
                if isinstance(prune_config, dict)
                else True
            ),
            prune_values=(
                prune_config.get("values", ["", [], {}, None])
                if isinstance(prune_config, dict)
                else ["", [], {}, None]
            ),
        )

        # Load resource-specific rules
        for resource_type, rules_data in data.get("resources", {}).items():
            if not rules_data:
                continue

            # Parse block configurations
            blocks = {}
            for block_item in rules_data.get("blocks", []):
                if isinstance(block_item, str):
                    blocks[block_item] = BlockConfig(name=block_item)
                elif isinstance(block_item, dict):
                    for name, config in block_item.items():
                        if config is None:
                            blocks[name] = BlockConfig(name=name)
                        else:
                            blocks[name] = BlockConfig(
                                name=name,
                                block_type=config.get("type", "block"),
                                sort_keys=config.get("sort_by"),
                                keep_empty=config.get("keep_empty", False),
                            )

            # Parse flatten configurations
            flatten_configs = []
            for source, config in rules_data.get("flatten", {}).items():
                if config and isinstance(config, dict):
                    flatten_configs.append(
                        FlattenConfig(
                            source=source,
                            target=config.get("target", "__root__"),
                            mapping=config.get("mapping", {}),
                        )
                    )
                elif config and isinstance(config, str):
                    # Simple format: source: target
                    flatten_configs.append(
                        FlattenConfig(
                            source=source,
                            target=config,
                            mapping={},
                        )
                    )

            self._rules_cache[resource_type] = ResourceRules(
                renames=rules_data.get("renames", {}),
                ignores=set(rules_data.get("ignores", [])),
                keep=set(rules_data.get("keep", [])),
                types=rules_data.get("types", {}),
                blocks=blocks,
                defaults=rules_data.get("defaults", {}),
                secrets=set(rules_data.get("secrets", [])),
                flatten=flatten_configs,
            )

        # Validate defaults match types
        self._validate_defaults()

        logger.info(f"Loaded schema rules for {len(self._rules_cache)} resources")

    def _validate_defaults(self) -> None:
        """Validate that default values match their declared types."""
        for resource_type, rules in self._rules_cache.items():
            for field_name, default_value in rules.defaults.items():
                declared_type = rules.types.get(field_name)
                if declared_type == "int" and not isinstance(default_value, int):
                    logger.warning(
                        f"[{resource_type}] Default for {field_name} should be int, "
                        f"got {type(default_value).__name__}"
                    )
                elif declared_type == "bool" and not isinstance(default_value, bool):
                    logger.warning(
                        f"[{resource_type}] Default for {field_name} should be bool, "
                        f"got {type(default_value).__name__}"
                    )

    def get_rules(self, resource_type: str) -> ResourceRules:
        """Get rules for a specific resource type."""
        return self._rules_cache.get(resource_type, ResourceRules())

    def get_global_rules(self) -> GlobalRules:
        """Get global rules."""
        return self._global_rules or GlobalRules()

    def should_remove_field(
        self,
        field_name: str,
        resource_rules: ResourceRules,
    ) -> bool:
        """
        Check if a field should be removed.

        Priority:
        1. Explicit keep (whitelist) → KEEP
        2. Explicit ignore → REMOVE
        3. Global pattern match → REMOVE
        4. Otherwise → KEEP
        """
        snake_name = self._to_snake_case(field_name)

        # Priority 1: Whitelist override
        if field_name in resource_rules.keep or snake_name in resource_rules.keep:
            return False

        # Priority 2: Explicit ignore
        if field_name in resource_rules.ignores or snake_name in resource_rules.ignores:
            return True

        # Priority 3: Global patterns
        global_rules = self.get_global_rules()
        if any(p.match(snake_name) for p in global_rules.readonly_patterns):
            return True

        return False

    def is_json_field(self, field_name: str, resource_rules: ResourceRules) -> bool:
        """Check if field should be JSON encoded."""
        # Check resource-specific types
        if resource_rules.types.get(field_name) == "json":
            return True
        snake_name = self._to_snake_case(field_name)
        if resource_rules.types.get(snake_name) == "json":
            return True

        # Check global patterns
        return any(p.match(snake_name) for p in self.get_global_rules().json_patterns)

    def reload(self) -> None:
        """Reload rules from YAML (useful for testing)."""
        self._rules_cache.clear()
        SchemaRuleLoader._loaded = False
        self._load_rules()
        SchemaRuleLoader._loaded = True

    @staticmethod
    def _to_snake_case(name: str) -> str:
        """Convert CamelCase to snake_case."""
        s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
        return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()
