"""
Secrets to Variable Transformer - Extract secrets with BIDIRECTIONAL binding.

CRITICAL: This transformer must do TWO things:
1. Create Variable definitions in variables.tf
2. UPDATE the resource attribute to reference the variable

WRONG (one-way):
  variables.tf:  variable "db_password" { ... }
  rds.tf:        password = "actual-password"  # NOT UPDATED!

RIGHT (bidirectional):
  variables.tf:  variable "db_password" { ... }
  rds.tf:        password = var.db_password    # CORRECTLY REFERENCED
"""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING, Any

from .base import BaseCodifyTransformer

if TYPE_CHECKING:
    from replimap.core.unified_storage import GraphEngineAdapter

logger = logging.getLogger(__name__)


# Patterns for identifying sensitive field names
SENSITIVE_PATTERNS = [
    r"password",
    r"secret",
    r"api[_-]?key",
    r"auth[_-]?token",
    r"access[_-]?key",
    r"private[_-]?key",
    r"credential",
    r"master_password",
    r"admin_password",
    r"db_password",
    r"connection[_-]?string",
    r"secret[_-]?key",
]

# Compiled patterns for efficiency
SENSITIVE_REGEX = [re.compile(p, re.IGNORECASE) for p in SENSITIVE_PATTERNS]


class SecretsToVariableTransformer(BaseCodifyTransformer):
    """
    Extract sensitive values to Terraform variables.

    Scans resource configurations for fields that look like secrets
    (passwords, API keys, tokens, etc.) and:
    1. Creates variable definitions for each secret
    2. Replaces the actual value with a variable reference

    This ensures secrets are never hardcoded in generated Terraform code.
    """

    name = "SecretsToVariableTransformer"

    def __init__(self, extract_secrets: bool = True) -> None:
        """
        Initialize the transformer.

        Args:
            extract_secrets: Whether to extract secrets to variables
        """
        self.extract_secrets = extract_secrets
        self.extracted_variables: list[dict[str, Any]] = []
        self._secrets_extracted = 0

    def transform(self, graph: GraphEngineAdapter) -> GraphEngineAdapter:
        """
        Extract secrets to variables and update references.

        Args:
            graph: The graph to transform

        Returns:
            The transformed graph
        """
        if not self.extract_secrets:
            logger.debug("SecretsToVariableTransformer: extraction disabled")
            return graph

        self.extracted_variables = []
        self._secrets_extracted = 0

        for resource in graph.iter_resources():
            self._scan_config(resource.config, resource)

        # Store extracted variables in graph metadata
        graph.set_metadata("codify_variables", self.extracted_variables)

        if self._secrets_extracted > 0:
            logger.info(
                f"SecretsToVariableTransformer: extracted {self._secrets_extracted} secrets"
            )

        return graph

    def _scan_config(
        self,
        config: dict[str, Any],
        resource: Any,
        path: str = "",
    ) -> None:
        """
        Recursively scan config for sensitive values.

        Args:
            config: Configuration dictionary to scan
            resource: Parent resource for naming
            path: Current path in config for nested fields
        """
        if not isinstance(config, dict):
            return

        for key, value in list(config.items()):
            current_path = f"{path}.{key}" if path else key

            if isinstance(value, str) and self._is_sensitive_key(key):
                # Skip if value is already a variable reference
                if value.startswith("${var.") or value.startswith("var."):
                    continue

                # Skip empty values
                if not value.strip():
                    continue

                # Generate variable name
                var_name = self._generate_variable_name(resource, key)

                # Create variable definition
                self.extracted_variables.append(
                    {
                        "name": var_name,
                        "sensitive": True,
                        "type": "string",
                        "description": (
                            f"Sensitive value for "
                            f"{resource.resource_type}.{resource.terraform_name}.{key}"
                        ),
                        "original_path": current_path,
                        "resource_id": resource.id,
                    }
                )

                # CRITICAL: Update the actual value to reference the variable
                config[key] = f"${{var.{var_name}}}"
                self._secrets_extracted += 1
                logger.debug(f"Extracted secret: {current_path} -> var.{var_name}")

            elif isinstance(value, dict):
                self._scan_config(value, resource, current_path)

            elif isinstance(value, list):
                for i, item in enumerate(value):
                    if isinstance(item, dict):
                        self._scan_config(item, resource, f"{current_path}[{i}]")

    def _is_sensitive_key(self, key: str) -> bool:
        """Check if a field name indicates sensitive data."""
        return any(pattern.search(key) for pattern in SENSITIVE_REGEX)

    def _generate_variable_name(self, resource: Any, field_name: str) -> str:
        """Generate a unique variable name for a secret."""
        # Sanitize resource name
        resource_name = self._sanitize_name(resource.terraform_name)
        field = self._sanitize_name(field_name)

        return f"{resource_name}_{field}"

    def _sanitize_name(self, name: str) -> str:
        """Sanitize a name for use as a Terraform variable name."""
        result = ""
        for char in name:
            if char.isalnum() or char == "_":
                result += char
            else:
                result += "_"
        # Remove consecutive underscores
        while "__" in result:
            result = result.replace("__", "_")
        return result.strip("_").lower()

    @property
    def secrets_extracted(self) -> int:
        """Return the number of secrets extracted."""
        return self._secrets_extracted
