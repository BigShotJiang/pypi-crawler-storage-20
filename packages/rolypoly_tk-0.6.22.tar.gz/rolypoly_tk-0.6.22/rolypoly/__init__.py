"""rolypoly: RNA virus analysis toolkit"""

__version__ = "0.6.22"
__name__ = "rolypoly-tk"
