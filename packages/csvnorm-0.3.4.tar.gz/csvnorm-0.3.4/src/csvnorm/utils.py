"""Utility functions for csvnorm."""

import logging
import re
from pathlib import Path
from urllib.parse import urlparse

from rich.logging import RichHandler


def to_snake_case(name: str) -> str:
    """Convert filename to clean snake_case.

    Replicates the bash logic:
    tr '[:upper:]' '[:lower:]' |
    sed -E 's/[^a-z0-9]+/_/g' |
    sed -E 's/_+/_/g' |
    sed -E 's/^_|_$//g'
    """
    # Remove .csv extension if present
    if name.lower().endswith(".csv"):
        name = name[:-4]

    # Convert to lowercase
    name = name.lower()

    # Replace non-alphanumeric with underscore
    name = re.sub(r"[^a-z0-9]+", "_", name)

    # Collapse multiple underscores
    name = re.sub(r"_+", "_", name)

    # Remove leading/trailing underscores
    name = name.strip("_")

    return name


def setup_logger(verbose: bool = False) -> logging.Logger:
    """Setup and return a logger instance with rich formatting.

    Args:
        verbose: If True, set log level to DEBUG, else INFO.
    """
    logger = logging.getLogger("csvnorm")

    if not logger.handlers:
        handler = RichHandler(
            show_time=False, show_path=verbose, markup=True, rich_tracebacks=True
        )
        logger.addHandler(handler)

    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    return logger


def validate_delimiter(delimiter: str) -> None:
    """Validate that delimiter is a single character.

    Raises:
        ValueError: If delimiter is not exactly one character.
    """
    if len(delimiter) != 1:
        raise ValueError("--delimiter must be a single character")


def ensure_output_dir(output_dir: Path) -> None:
    """Create output directory if it doesn't exist."""
    output_dir.mkdir(parents=True, exist_ok=True)


def is_url(input_str: str) -> bool:
    """Check if input string is an HTTP/HTTPS URL.

    Args:
        input_str: String to check.

    Returns:
        True if input is HTTP/HTTPS URL, False otherwise.
    """
    try:
        result = urlparse(input_str)
        return result.scheme in ("http", "https") and bool(result.netloc)
    except Exception:
        return False


def validate_url(url: str) -> None:
    """Validate URL has HTTP/HTTPS protocol.

    Args:
        url: URL to validate.

    Raises:
        ValueError: If URL protocol is not HTTP/HTTPS.
    """
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"Only HTTP/HTTPS URLs are supported. Got: {parsed.scheme}://")


def extract_filename_from_url(url: str) -> str:
    """Extract and normalize filename from URL.

    Args:
        url: URL to extract filename from.

    Returns:
        Normalized snake_case filename without extension.
    """
    from urllib.parse import unquote

    parsed = urlparse(url)
    # Get last path segment, ignore query/fragment
    path = parsed.path.rstrip("/")
    filename = path.split("/")[-1] if path else "data"

    # Decode URL encoding (%20 -> space, etc.)
    filename = unquote(filename)

    # Remove extension if present
    if filename.lower().endswith(".csv"):
        filename = filename[:-4]

    # Apply snake_case normalization
    return to_snake_case(filename) if filename else "data"
