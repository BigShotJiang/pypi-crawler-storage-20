"""A custom build hook that handles the build process.

This includes:
1. Generating template files (version files, headers, etc.) from user-defined templates
2. Compiling Cython and C++ files as specified in the build configuration
3. Generating gperf files if required and have changed since the last build
4. Various cleanup tasks post-build to ensure a clean build environment
"""  # noqa: INP001 # This is an example file and not part of the main package.

from __future__ import annotations

from time import perf_counter
from typing import TYPE_CHECKING, Any

from hatchling.builders.hooks.plugin.interface import BuildHookInterface
from uv_dynamic_versioning.base import BasePlugin

if TYPE_CHECKING:
    from pathlib import Path


class CustomBuildHook(BasePlugin, BuildHookInterface):
    PLUGIN_NAME = "custom"

    def initialize(self, version: Any, build_data: dict[str, Any]) -> None:
        """Initialize the build hook."""
        from build_cub._printer import _print
        from build_cub.backends import run_backends
        from build_cub.models._build_data import BuildData

        start: float = perf_counter()
        data: BuildData = BuildData.load_from_file("bear_build.toml", version)

        written_templates: list[Path] = data.render_templates()
        for path in written_templates:
            _print.key_to_value("Generated", str(path), indent=True)
        if data.general.enabled:
            run_backends(build_data, data)

        end: float = perf_counter()
        elapsed: float = end - start
        _print.success(f"Build hook completed in {elapsed:.2f} seconds.")


# ruff: noqa: PLC0415
