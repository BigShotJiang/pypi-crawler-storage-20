# CLAUDE.md

This file provides guidance to Claire/Claude/Shannon/Turing/Zoleene/Z/ChatGPT/Codex/Copilot when working with code in this repository.

Hello! My name is Bear! Please refer to me as Bear and never "the user" as that is dehumanizing. I love you Claude! Or Shannon! Or Claire! Or even ChatGPT/Codex?! :O

# !!! IMPORTANT !!!
- **Code Comments**: Comments answer "why" or "watch out," never "what." Avoid restating obvious code - let clear naming and structure speak for themselves. Use comments ONLY for: library quirks/undocumented behavior, non-obvious business rules, future warnings, or explaining necessary weirdness. Prefer docstrings for function/class explanations. Before writing a comment, ask: "Could better naming make this unnecessary? Am I explaining WHAT (bad) or WHY (good)?"

## Project Overview

**build-cub** is a Hatch build hook for compiling native Python extensions. It supports multiple compilation backends (Cython, PyBind11, Raw C++ API, Gperf) with configuration-driven builds via `bear_build.toml`. The tool handles cross-platform compiler settings, artifact management, flexible Jinja2 template rendering, and integrates with `uv-dynamic-versioning` for VCS-based versioning.

!!!!!!! PLEASE DO NOT USE `python -m <...>` as we should call `source .venv/bin/activate` in order access our venv.  !!!!!!!! 

## Development Commands

### Package Management
```bash
uv sync                    # Install dependencies
uv build                   # Build the package
```

### CLI Testing
```bash
build-cub --help          # Show available commands
build-cub version         # Get current version
build-cub bump patch      # Bump version (patch/minor/major)
build-cub debug           # Show environment info
```

### Code Quality
```bash
nox -s ruff_check          # Check code formatting and linting (CI-friendly)
nox -s ruff_fix            # Fix code formatting and linting issues
nox -s pyright             # Run static type checking
nox -s tests               # Run test suite (3.12, 3.13, 3.14)
pytest tests/              # Run tests directly (faster iteration)
```

### Version Management
```bash
git tag v1.0.0             # Manual version tagging
build-cub bump patch       # Automated version bump with git tag
```

## Architecture

### Models Package (`src/build_cub/models/`)

Pydantic models for configuration validation:

| Module | Purpose |
|--------|---------|
| `_build_data.py` | Root `BuildData` model, template rendering, settings inheritance |
| `_backends.py` | Backend-specific settings (CythonSettings, Pybind11Settings, etc.) |
| `_base.py` | `BaseSettings`, `BaseBackendSettings[T]`, `CompilerSettings`, `SourcesItem` |
| `_defaults.py` | `DefaultSettings`, `GeneralSettings`, `OutputFiles` |
| `_templates.py` | `VersioningSettings`, `TemplateDefinition` for flexible templates |
| `_version.py` | `Version` model for VCS-based versioning |

### Compilation Backends (`src/build_cub/backends/`)

All backends inherit from `CompileBackend[Settings_T, Target_T]` (generic ABC in `_base.py`):

| Backend | File | Base Class | Purpose |
|---------|------|------------|---------|
| **Cython** | `cython.py` | `CompileBackend` | Compiles `.pyx` files via Cython + setuptools |
| **PyBind11** | `pybind11.py` | `CppBackendBase` | Compiles C++ with pybind11 bindings |
| **Raw C++** | `raw_cpp.py` | `CppBackendBase` | Direct CPython API compilation |
| **Gperf** | `gperf.py` | `CompileBackend` | Pre-processes `.gperf` files into hash headers |

**Backend Hooks (override to customize):**
- `_get_extensions(targets)` - Build setuptools Extension objects
- `_pre_compile(extensions)` - Transform extensions before compilation (e.g., `cythonize()`)
- `_post_artifact_copy(dest)` - Cleanup after artifact copy (e.g., remove `.c` files)
- `extra_include_dirs` property - Add backend-specific include paths

### Internal CLI (`src/build_cub/_internal/`)

- **cli.py** - Entry point with `version`, `bump`, and `debug` commands
- **_cmds.py** - Command implementations and argument parsing
- **debug.py** - Environment info utilities and `_ConditionalPrinter`
- **info.py** - Package metadata, `ExitCode` enum, `_Version` handling
- **_version.py** - Generated version file (from templates)

### Core Utilities

- **_helpers.py** - Platform detection, `load_toml()`, `get_parts()`, `ImmutableList`
- **_printer.py** - `ColorPrinter` class for Rich-formatted console output

### Key Dependencies

| Package | Purpose |
|---------|---------|
| **hatchling** | Build backend integration |
| **pydantic** | Configuration validation and type-safe settings |
| **jinja2** | Template rendering for version files |
| **dunamai** | VCS version extraction |
| **setuptools** | Extension compilation infrastructure |
| **lazy-bear** | Lazy imports for optional dependencies (performance) |
| **uv-dynamic-versioning** | Git-based version management |

### Design Patterns

1. **Generic ABC Backend**: `CompileBackend[Settings_T, Target_T]` uses Python generics for type-safe settings and target types
2. **Per-Field Settings Merge**: Backends inherit defaults field-by-field; only explicitly set fields override
3. **Platform-Aware Config**: Pydantic `validation_alias` selects `extra_compile_args` vs `extra_compile_args_windows`
4. **Hook-Based Compilation**: Shared `compile()` logic with override hooks for backend-specific behavior
5. **Lazy Loading**: Heavy dependencies (Cython, setuptools, pybind11) loaded only when needed
6. **Flexible Templates**: N user-defined templates with arbitrary variables, all rendered at build time

## Project Structure

```
src/build_cub/
├── __init__.py            # Public API, METADATA export
├── __main__.py            # Python -m entry point (DO NOT USE `python -m <...>` directly on your side PLEASE!)
├── _helpers.py            # File utilities, platform detection, TOML loading
├── _printer.py            # ColorPrinter for Rich console output
├── _internal/             # CLI implementation
│   ├── __init__.py
│   ├── cli.py             # Main CLI entry point
│   ├── _cmds.py           # Command implementations
│   ├── debug.py           # Environment info, _ConditionalPrinter
│   ├── info.py            # Package metadata and exit codes
│   └── _version.py        # Generated version (from templates)
├── models/                # Pydantic configuration models
│   ├── __init__.py
│   ├── _build_data.py     # Root BuildData model
│   ├── _backends.py       # Backend-specific settings
│   ├── _base.py           # Base classes, CompilerSettings, SourcesItem
│   ├── _defaults.py       # DefaultSettings, GeneralSettings
│   ├── _templates.py      # VersioningSettings, TemplateDefinition
│   └── _version.py        # Version model for VCS
└── backends/              # Compilation backends
    ├── __init__.py        # run_backends() orchestrator
    ├── _base.py           # CompileBackend[T] ABC with shared compile()
    ├── _cpp_base.py       # CppBackendBase for pybind11/raw_cpp
    ├── cython.py          # Cython backend
    ├── pybind11.py        # PyBind11 backend
    ├── raw_cpp.py         # Raw CPython API backend
    └── gperf.py           # Gperf preprocessor
tests/
├── __init__.py
├── conftest.py            # Pytest fixtures
├── fixtures/
│   └── test_bear_build.toml  # Stable test fixture
├── test_backends.py       # Backend initialization tests
├── test_cli.py            # CLI tests
├── test_config_loading.py # TOML loading and validation
├── test_helpers.py        # Helper function tests
├── test_settings_inheritance.py  # Defaults merge tests
├── test_settings_merge.py # Per-field merge behavior
└── test_templates.py      # Flexible template system tests

bear_build.toml            # Build configuration file
hatch_build.py             # Hatch build hook entry point
```

## Development Notes

- **Minimum Python Version**: 3.12
- **Tested On**: Python 3.12, 3.13, 3.14
- **Dynamic Versioning**: Requires git tags (format: `v1.2.3`), powered by `uv-dynamic-versioning`
- **Modern Python**: Uses built-in types (`list`, `dict`), `collections.abc` imports, type parameter syntax
- **Type Checking**: Pyright in standard mode

## Configuration

Build configuration lives in `bear_build.toml` at the project root.

### Key Sections

| Section | Purpose |
|---------|---------|
| `[general]` | Package name, master enable switch, debug symbols |
| `[defaults]` | Base compiler/linker args inherited by all backends |
| `[defaults.settings]` | Compiler args, link args, include/library dirs |
| `[cython]` | Cython targets and compiler directives |
| `[pybind11]` | PyBind11 C++ targets |
| `[raw_cpp]` | Raw CPython API targets |
| `[gperf]` | Gperf hash generator preprocessing |
| `[versioning.variables]` | User-defined variables for templates |
| `[[versioning.templates]]` | Array of template definitions |

### Flexible Template System

```toml
# User-defined variables (optional) - passed to ALL templates
[versioning.variables]
database = { major = 2, minor = 0, patch = 0 }
api = { major = 1, minor = 5, patch = 0 }

# Template definitions - each [[versioning.templates]] is rendered
[[versioning.templates]]
output = "src/pkg/_version.py"
content = '''
__version__ = "{{ version.major }}.{{ version.minor }}.{{ version.patch }}"
__db_version__ = "{{ database.major }}.{{ database.minor }}"
'''

[[versioning.templates]]
output = "src/pkg/_cpp/version.hpp"
content = '''
#pragma once
constexpr int API_MAJOR = {{ api.major }};
'''
```

- `version` is **always auto-injected** from VCS
- Any user-defined variables in `[versioning.variables]` are available in all templates
- Add as many `[[versioning.templates]]` entries as needed

### Settings Inheritance

Backends inherit from `[defaults.settings]` on a **per-field basis**:
- If a backend sets `extra_compile_args`, it uses its own
- If a backend doesn't set `extra_link_args`, it inherits from defaults
- Empty `[]` counts as "not set" (inherits defaults)

### Environment Variables

- `NOT_IN_WORKFLOW`: Set to `"true"` for colored Rich output (disabled in CI)
- `BUILD_CUB_ENV`: Set environment (prod/test)
