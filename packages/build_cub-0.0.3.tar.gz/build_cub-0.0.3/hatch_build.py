"""A custom build hook that handles the build process."""

from __future__ import annotations

from typing import Any

from hatchling.builders.hooks.plugin.interface import BuildHookInterface

# from build_cub.plugins import VersionBasePlugin


class CustomBuildHook(BuildHookInterface):
    PLUGIN_NAME = "custom"
    version_name = "python_version"

    def initialize(self, version: Any, build_data: dict[str, Any]) -> None:
        """Initialize the build hook."""
        # from time import perf_counter

        # from build_cub._printer import _print
        # from build_cub.backends import run_backends
        # from build_cub.models._build_data import BuildData

        # start: float = perf_counter()
        # self._build_data = BuildData.load_from_file(self._build_config.config_path, self.version)

        # written_templates: list[Path] = self._build_data.render_templates()
        # for path in written_templates:
        #     _print.key_to_value("Generated", str(path), indent=True)
        # if self._build_data.general.enabled:
        #     run_backends(build_data, self._build_data)

        # end: float = perf_counter()
        # elapsed: float = end - start
        # _print.success(f"Build hook completed in {elapsed:.2f} seconds.")
