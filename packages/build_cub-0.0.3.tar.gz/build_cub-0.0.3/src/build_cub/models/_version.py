from __future__ import annotations

from pathlib import Path  # noqa: TC003
import re
from typing import TYPE_CHECKING, Any, Self

from dunamai import Vcs, Version as DunamaiVersion
from pydantic import BaseModel

if TYPE_CHECKING:
    from collections.abc import Callable


class BuildConfig(BaseModel):
    """Build configuration settings loaded from bear_build.toml."""

    config_path: Path
    vcs: str
    style: str
    metadata: bool
    fallback_version: str

    @classmethod
    def load_from_file(cls, path: Path) -> Self:
        """Load build settings from a TOML file."""
        from functools import reduce
        from operator import getitem
        import tomllib

        from build_cub._helpers import PATH_TO_REDUCE

        try:
            with path.open("rb") as f:
                data: dict[str, Any] = reduce(getitem, PATH_TO_REDUCE, tomllib.load(f))
                return cls.model_validate(data)
        except Exception as e:
            raise RuntimeError(f"Failed to load build settings from {path}") from e


def part_check[T](n: int, data: tuple[str, ...], expected_type: Callable[[str], T] = int) -> tuple[T, ...]:
    if len(data) != n:
        raise ValueError(f"Version string must have {n} parts: {data!r}")
    values = []
    for i, part in enumerate(data):
        try:
            values.append(expected_type(part))
        except ValueError as e:
            raise TypeError(f"Part {i} must be of type {expected_type.__name__}: {part}") from e
    return tuple(values)


class Version(BaseModel):
    """A pydantic model to store version information."""

    major: int = 0
    minor: int = 0
    patch: int = 0

    def __bool__(self) -> bool:
        """Check if version is non-zero."""
        return any((self.major, self.minor, self.patch))

    def __str__(self) -> str:
        """Get the version as a string."""
        return f"{self.major}.{self.minor}.{self.patch}"

    @classmethod
    def from_version(cls, version: DunamaiVersion) -> Self:
        """Create a Version instance from a DunamaiVersion."""
        regex: re.Pattern[str] = re.compile(r"^(\d+)\.(\d+)\.(\d+)$")
        match: re.Match[str] | None = regex.match(version.base)
        if match:
            vals: tuple[int, ...] = part_check(n=3, data=match.groups(), expected_type=int)
            return cls(major=vals[0], minor=vals[1], patch=vals[2])
        return cls()

    @classmethod
    def get_version(cls, build_settings: BuildConfig) -> Self:
        """Get version information from VCS or fallback."""
        try:
            return cls.from_version(DunamaiVersion.from_vcs(Vcs[build_settings.vcs.capitalize()]))
        except RuntimeError:
            return cls.from_version(DunamaiVersion(build_settings.fallback_version))


DEFAULT_VERSION = Version()

# ruff: noqa: PLC0415
