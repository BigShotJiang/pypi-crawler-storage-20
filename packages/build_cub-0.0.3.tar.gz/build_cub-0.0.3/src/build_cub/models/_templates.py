"""Models for [versioning] section in bear_build.toml.

Supports flexible template rendering with user-defined variables.
All variables are passed to all templates, allowing maximum flexibility.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from jinja2 import Template
from pydantic import BaseModel, Field


class VersionNumbers(BaseModel):
    """Simple major.minor.patch version - used for user-defined version variables."""

    major: int = 0
    minor: int = 0
    patch: int = 0


class TemplateDefinition(BaseModel):
    """A single template definition with output path and content.

    Used in [[versioning.templates]] array of tables.
    """

    name: str = Field(default="", description="Optional name for the template")
    output: str = Field(description="Output file path for the rendered template")
    content: str = Field(default="", description="Jinja2 template content")

    def render(self, variables: dict[str, Any]) -> str:
        """Render this template with the provided variables."""
        return Template(self.content).render(**variables)

    def write(self, variables: dict[str, Any]) -> Path:
        """Render and write template to output path. Returns the output path."""
        project_root: Path = Path.cwd().resolve()
        output_path: Path = Path(self.output).resolve()
        if not str(output_path).startswith(str(project_root)):
            raise ValueError(f"Template output path {output_path} is outside the project root {project_root}")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(self.render(variables))
        return output_path


class VersioningSettings(BaseModel):
    """Maps to [versioning] section.

    Supports flexible template system:
    - variables: User-defined dicts passed to all templates (version is auto-injected)
    - templates: List of TemplateDefinition with output path and content

    Example TOML:
        [versioning.variables]
        database = { major = 2, minor = 0, patch = 0 }

        [[versioning.templates]]
        output = "src/pkg/_version.py"
        content = '''
        __version__ = "{{ version.major }}.{{ version.minor }}.{{ version.patch }}"
        __db_version__ = "{{ database.major }}.{{ database.minor }}"
        '''
    """

    variables: dict[str, Any] = Field(default_factory=dict)  # User-defined variables - all get passed to all templates
    templates: list[TemplateDefinition] = Field(default_factory=list)

    # Legacy fields for backwards compatibility (deprecated)
    # TODO: Remove these after migration
    output: str = Field(default="", description="Use templates list instead", deprecated=True)
    cpp_output: str = Field(default="", description="Use templates list instead", deprecated=True)
    versions: dict[str, VersionNumbers] = Field(
        default_factory=dict, description="Use variables instead", deprecated=True
    )

    @property
    def has_templates(self) -> bool:
        """Check if any templates are defined."""
        return bool(self.templates)

    def get_by_name(self, name: str) -> TemplateDefinition:
        """Get a template by its name."""
        for template in self.templates:
            if template.name == name:
                return template
        raise ValueError(f"Template with name '{name}' not found.")


__all__ = ["TemplateDefinition", "VersionNumbers", "VersioningSettings"]
