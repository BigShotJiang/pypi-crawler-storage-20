"""Module defining a custom version source plugin for Hatchling using Dunamai.

NOTE: WORK IN PROGRESS
GIVE ME A BREAK ABOUT CODE IN THIS MODULE BEING UNTESTED AND INCOMPLETE
"""

from functools import cached_property

from hatchling.plugin import hookimpl
from hatchling.version.source.plugin.interface import VersionSourceInterface

from build_cub._helpers import PYPROJECT_TOML
from build_cub.models._version import BuildConfig, Version


class BaseCustomBuildHook:
    """Base class for custom build hooks."""

    _build_config: BuildConfig

    def __init__(self, root: str, config: dict) -> None:  # noqa: ARG002
        """Initialize the VersionBasePlugin."""
        # self.root = root
        # self.config = config
        self._build_config = BuildConfig.load_from_file(PYPROJECT_TOML)
        self._build_data = None

    @cached_property
    def version(self) -> Version:
        """Get the current version information."""
        return Version.get_version(self._build_config)


class DynamicVersioningSrc(BaseCustomBuildHook, VersionSourceInterface):
    """A custom version source plugin for Hatchling using Dunamai."""

    PLUGIN_NAME = "build-cub"

    def get_version_data(self) -> dict[str, str]:
        """Get version data for the build process."""
        return {"version": str(self.version)}


@hookimpl
def hatch_register_version_source() -> type[DynamicVersioningSrc]:
    """Register the custom version source plugin."""
    return DynamicVersioningSrc
