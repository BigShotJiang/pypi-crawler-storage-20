"""A backend for processing GNU gperf files.

Gperf is a perfect hash function generator used to create efficient lookup tables.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, Literal

from lazy_bear import lazy

from build_cub._helpers import EMPTY_IMMUTABLE_LIST

from ._base import CompileBackend

if TYPE_CHECKING:
    import subprocess

    from build_cub._printer import ColorPrinter
    from build_cub.models._backends import GperfSettings
    from build_cub.models._build_data import BuildData
else:
    GperfSettings = lazy("build_cub.models._backends", "GperfSettings")
    subprocess = lazy("subprocess")

GPERF_EXT: list[str] = [".gperf"]
type Extensions = Literal[".h", ".hpp"]


def which(cmd: str) -> str | None:
    """Locate a command in the system PATH."""
    from shutil import which as shutil_which  # noqa: PLC0415

    return shutil_which(cmd)


class GperfBackend(CompileBackend[GperfSettings, Path]):
    """GNU perfect hash function generator backend."""

    name: str = "gperf"
    _local_settings: type[GperfSettings]
    _dependencies: ClassVar[list[str]] = EMPTY_IMMUTABLE_LIST

    def __init__(self, should_run: bool, settings: BuildData, printer: ColorPrinter) -> None:
        """Initialize the Gperf backend."""
        super().__init__(should_run, settings, printer)

    def _verify_dependencies(self) -> None:
        binary: str = self.settings.gperf.binary
        if which(binary) is None:
            # TODO: Potentially we should setup our own fallback, but in my experience that might not be a good idea?
            # the default gperf in MacOS for example is fairly old compared to the latest release.
            # Example from my own system:
            # which -a gperf:
            #  /opt/homebrew/bin/gperf
            #  /usr/bin/gperf
            # So we could do:
            # if platform == "darwin":
            #     # try homebrew path first
            #     # then try /usr/bin/gperf
            # if platform == "linux":
            #     # try /usr/bin/gperf
            #     # then try /usr/local/bin/gperf
            # if platform == "windows":
            #    # what are you doing here buddy? :)
            self.should_run = False
            self._print.warn(
                f"Missing dependency for Gperf backend: {binary}. Please install it to proceed.",
            )

    def _cleanup(self, **kwargs) -> None:
        """Remove #line directives and 'register' keyword from gperf output."""
        header_file: Path = kwargs.get("header_file", "")
        if not header_file:
            return
        new_lines: list[str] = [line for line in header_file.read_text().splitlines() if not line.startswith("#line")]
        output: str = "\n".join(new_lines) + "\n"
        header_file.write_text(output.replace("register ", ""))

    def _pre_check(self, gperf_files: list[Path], ext: str) -> list[Path]:
        """Pre-compilation check for .gperf files."""
        files_to_keep = []
        for gperf_file in gperf_files:
            expected_header: Path = gperf_file.with_suffix(ext)
            if expected_header.exists():
                if gperf_file.stat().st_mtime < expected_header.stat().st_mtime:
                    self._print.key_to_value(f"Skipping {gperf_file.name}", "(up to date)", indent=True)
                else:
                    files_to_keep.append(gperf_file)
                    expected_header.unlink()
        return files_to_keep

    def _get_extensions(self, targets: list[Path]) -> list[Any]:  # noqa: ARG002
        """Return empty list; Gperf does not use setuptools Extensions."""
        return []

    def compile(self, *, build_data: dict[str, Any]) -> None:  # noqa: ARG002
        """Process .gperf files to generate header files."""
        if not self.should_run:
            return

        gperf_files: list[Path] = self._get_files(self.settings.pkg_root, exts=GPERF_EXT)

        if not gperf_files:
            self._print.warn("No .gperf files found to process.", indent=True)
            return

        cmd: list[str] = self.local_settings.cmd
        gperf_files = self._pre_check(gperf_files=gperf_files, ext=self.local_settings.target_ext)
        for gperf_file in gperf_files:
            header_file: Path = gperf_file.with_suffix(suffix=self.local_settings.target_ext)
            cmd[3] = str(gperf_file)
            cmd[4] = f"--output-file={header_file}"

            subprocess.run(cmd, check=True)

            if header_file.exists():
                self._print.key_to_value(f"Generated {gperf_file.name}", header_file.name, indent=True)
                self._cleanup(header_file=header_file)
            cmd[3] = ""
            cmd[4] = ""
