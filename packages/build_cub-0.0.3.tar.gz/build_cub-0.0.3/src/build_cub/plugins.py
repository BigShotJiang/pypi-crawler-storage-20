"""A custom version source plugin for Hatchling using Dunamai."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from build_cub._helpers import PYPROJECT_TOML

from .hooks import BaseCustomBuildHook
from .models._version import BuildConfig, Version

if TYPE_CHECKING:
    from .models._build_data import BuildData
    from .models._templates import TemplateDefinition


class VersionBasePlugin(BaseCustomBuildHook):
    """A custom version source plugin for Hatchling using Dunamai."""

    _build_data: BuildData | None
    _version: TemplateDefinition
    version_name: str

    def __init__(self, *args, **kwargs) -> None:  # noqa: ARG002
        """Initialize the VersionBasePlugin."""
        self._build_config = BuildConfig.load_from_file(PYPROJECT_TOML)
        self._build_data = None

    @property
    def build_data(self) -> BuildData:
        """Get the build data, loading it if necessary."""
        if self._build_data is None:
            raise RuntimeError("Build data has not been set.")
        return self._build_data

    @build_data.setter
    def build_data(self, value: BuildData) -> None:
        """Set the build data."""
        self._build_data = value

    def load(self) -> None:
        """Load the version template definition."""
        if self.build_data.versioning.has_templates:
            self._version = self.build_data.versioning.get_by_name(self.version_name)

    @property
    def output_path(self) -> Path:
        """Get the output path for the version file."""
        return Path(self._version.output)

    @property
    def content_template(self) -> str:
        """Get the content template for the version file."""
        return self._version.content

    def render_template(self) -> None:
        """Render the template with the given variables."""
        from jinja2 import Template  # noqa: PLC0415

        template = Template(self.content_template)
        version: Version = self.version
        self.output_path.write_text(
            template.render(
                version=str(version),
                major=version.major,
                minor=version.minor,
                patch=version.patch,
            )
        )


__all__ = ["VersionBasePlugin"]
