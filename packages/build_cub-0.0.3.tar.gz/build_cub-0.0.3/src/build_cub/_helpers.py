from __future__ import annotations

from pathlib import Path
from sys import platform
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Final, Literal, NoReturn, overload

if TYPE_CHECKING:
    from collections.abc import Callable


IS_WINDOWS: bool = platform == "win32"
IMMUTABLE_DEFAULT_DICT: MappingProxyType = MappingProxyType({})
type CompileArgs = Literal["extra_compile_args", "extra_compile_args_windows"]
type LinkArgs = Literal["extra_link_args", "extra_link_args_windows"]
DEFAULT_OUTPUT: list[str] = [".so", ".pyd"]
COMPILER_ARGS_KEY: CompileArgs = "extra_compile_args_windows" if IS_WINDOWS else "extra_compile_args"
LINK_ARGS_KEY: LinkArgs = "extra_link_args_windows" if IS_WINDOWS else "extra_link_args"
PATH_TO_REDUCE: Final = ("tool", "hatch", "build", "hooks", "custom")


# TODO: Make locating this more dynamic with fallbacks
PYPROJECT_TOML = Path("pyproject.toml")


def NOOP_FUNCTION(*args: Any, **kwargs: Any) -> None:  # noqa: N802
    """A no-operation function that does nothing."""


def get_default_output_files() -> list[str]:
    """Get default output file extensions."""
    return DEFAULT_OUTPUT


type TomlData = dict[str, Any]
SENTINEL = object()


def _immutable(self, *args, **kwargs) -> NoReturn:  # noqa: ANN001, ARG001
    raise TypeError("This list is immutable and cannot be modified.")


class ImmutableList[T](list):
    """An immutable list that prevents modification."""

    __setitem__: Callable[..., NoReturn] = _immutable
    __delitem__: Callable[..., NoReturn] = _immutable
    append: Callable[..., NoReturn] = _immutable
    extend: Callable[..., NoReturn] = _immutable
    insert: Callable[..., NoReturn] = _immutable
    remove: Callable[..., NoReturn] = _immutable
    pop: Callable[..., NoReturn] = _immutable
    clear: Callable[..., NoReturn] = _immutable

    @property
    def __sentinel__(self) -> bool:
        return super().__len__() == 1 and self[0] is SENTINEL

    def __len__(self) -> int:
        if self.__sentinel__:
            return 0
        return super().__len__()

    def __bool__(self) -> bool:
        if self.__sentinel__:
            return False
        return super().__len__() > 0

    def __hash__(self) -> int:  # pyright: ignore[reportIncompatibleVariableOverride]
        if self.__sentinel__:
            return hash("EmptyImmutableList")
        return hash(tuple(self))

    def __eq__(self, other: object) -> bool:
        if self.__sentinel__:
            return other == []
        if not isinstance(other, list):
            return False
        return list(self) == other

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)


EMPTY_IMMUTABLE_LIST = ImmutableList([SENTINEL])


@overload
def get_parts(file: Path | str, to_module: Literal[True]) -> str: ...


@overload
def get_parts(file: Path | str, to_module: Literal[False] = False) -> tuple[str, ...]: ...


def get_parts(file: Path | str, to_module: bool = False) -> tuple[str, ...] | str:
    parts: tuple[str, ...] = Path(file).with_suffix(suffix="").parts
    if parts[0] == "src":
        parts = parts[1:]
    if to_module:
        return ".".join(parts)
    return parts


def load_toml(path: Path | str = "bear_build.toml") -> TomlData:
    """Load and parse a TOML file.

    Caller needs to handle exceptions.
    """
    import tomllib  # noqa: PLC0415

    with Path(path).open("rb") as f:
        return tomllib.load(f)
