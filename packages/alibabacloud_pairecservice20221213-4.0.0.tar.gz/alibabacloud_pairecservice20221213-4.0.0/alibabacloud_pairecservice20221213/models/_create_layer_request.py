# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class CreateLayerRequest(DaraModel):
    def __init__(
        self,
        description: str = None,
        instance_id: str = None,
        laboratory_id: str = None,
        name: str = None,
    ):
        # This parameter is required.
        self.description = description
        # This parameter is required.
        self.instance_id = instance_id
        # This parameter is required.
        self.laboratory_id = laboratory_id
        # This parameter is required.
        self.name = name

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.description is not None:
            result['Description'] = self.description

        if self.instance_id is not None:
            result['InstanceId'] = self.instance_id

        if self.laboratory_id is not None:
            result['LaboratoryId'] = self.laboratory_id

        if self.name is not None:
            result['Name'] = self.name

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Description') is not None:
            self.description = m.get('Description')

        if m.get('InstanceId') is not None:
            self.instance_id = m.get('InstanceId')

        if m.get('LaboratoryId') is not None:
            self.laboratory_id = m.get('LaboratoryId')

        if m.get('Name') is not None:
            self.name = m.get('Name')

        return self

