# Welcome to slub_finclookup

This documentation provides an overview of the transformation and lookup modules used in the SLUB/finc environment.

For a quick overview, please refer to the [README](../README.md).

## Main Features
- **Modern Python 3.12** support.
- **Optimized Lookups** using module-level constants.
- **Easy Integration** into data processing pipelines.

Check the [API Reference](api.md) for detailed function documentation.
