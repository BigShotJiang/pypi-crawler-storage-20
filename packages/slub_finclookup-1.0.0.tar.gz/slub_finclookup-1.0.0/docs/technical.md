# Technische Dokumentation: slub_finclookup

Dieses Dokument enthält technische Details zur Implementierung und Architektur des Pakets.

## Architektur
Das Paket folgt dem modernen `src/`-Layout, um eine klare Trennung zwischen Quellcode und Konfiguration zu gewährleisten.

### Schlüsselkomponenten
- **Mappings**: Einzelne Module in `src/slub_finclookup/`, die jeweils eine `lookup`-Funktion bereitstellen.
- **Konstanten**: Große Mapping-Tabellen (Dictionaries) sind als Modul-Konstanten definiert. Dies verhindert, dass diese bei jedem Funktionsaufruf neu im Speicher initialisiert werden müssen (Performance-Optimierung).

## Design-Entscheidungen

### Python 3.12 Migration
- Entfernung von Python 2 Encoding-Headern (`# -*- coding: UTF-8 -*-`).
- Nutzung von Type Hints (`value: str -> str`) zur Verbesserung der Wartbarkeit und IDE-Unterstützung.
- Unterstützung von Unicode als Standard (kein manuelles Encoding/Decoding mehr nötig).

### Namensgebung
Das Paket wurde von `python_lookups` in `slub_finclookup` umbenannt, um Namenskollisionen auf PyPI zu vermeiden und den Bezug zur finc-Umgebung der SLUB zu verdeutlichen.

### Behandlung von Spezialfällen
In `fincclass_txtF_mv_2_finc_class_facet.py` wurde ein doppelter Schlüssel im ursprünglichen Script identifiziert (`politicalscience-administration-military`). Dieser wurde konsolidiert, wobei der letzte Wert des ursprünglichen Python-2-Scripts beibehalten wurde, um die Logik nicht zu brechen.

## Dokumentation

### API-Dokumentation
Für die automatische Generierung von API-Dokumentationen werden folgende Werkzeuge empfohlen:
- **MkDocs** mit **mkdocstrings**: Empfolene Wahl für moderne, Markdown-basierte Dokumentationsseiten.
- **pdoc**: Für schnelle, konfigurationsfreie HTML-Dokumentation direkt aus den Docstrings.
- **Sphinx**: Der klassische Standard für komplexe Projekte.

Der Code verwendet den Google-Style für Docstrings, um die Kompatibilität mit diesen Tools zu gewährleisten.
