# Projektplan: slub_finclookup

Dieses Dokument beschreibt den Plan zur Modernisierung und Paketierung der SLUB-Mapping-Skripte.

## Status Quo
- [x] Projektstruktur auf `src/`-Layout umgestellt.
- [x] Paketname auf `slub_finclookup` festgelegt.
- [x] Alle Mapping-Skripte nach Python 3.12 portiert.
- [x] Effizienzsteigerung durch Auslagerung von Dictionaries in Modul-Konstanten.
- [x] `pyproject.toml` für die Paketierung mit `uv` konfiguriert.

## Nächste Schritte
- [x] Erstellung einer umfassenden `README.md`.
- [x] Einrichtung einer detaillierten technischen Dokumentation in `docs/technical.md`.
- [x] Einrichtung eines neuen Git-Repositorys (Remote-Wechsel).
- [x] Konfiguration von MkDocs für API-Dokumentation.
- [ ] Validierung der Paketierung (`uv build`).
- [ ] Vorbereitung für die Veröffentlichung auf PyPI.

## Meilensteine
- [x] Modernisierung: Alle Legacy-Skripte sind refaktorisiert. (Abgeschlossen)
- [x] Dokumentation: Der Zweck und die Nutzung des Pakets sind klar beschrieben. (Abgeschlossen)
- [ ] Qualitätssicherung: Tests stellen die Korrektheit der Mappings sicher. (In Arbeit)
- [ ] Distribution: Das Paket ist bereit für die Installation via `pip`.
