import pytest
from slub_finclookup.DBIS_Fachgebiete_2_finc_class_facet import lookup as dbis_lookup
from slub_finclookup.language2code_2_languageName import lookup as lang2_lookup
from slub_finclookup.ddc_2_finc_class_facet import lookup as ddc_lookup
from slub_finclookup.fincclass_txtF_mv_2_finc_class_facet import (
    lookup as class_facet_lookup,
)


def test_dbis_mapping():
    assert dbis_lookup("Allgemein / Fachübergreifend") == "Allgemeines"
    assert dbis_lookup("Geographie") == "Geographie"


def test_language_mapping():
    assert lang2_lookup("de") == "German"
    assert lang2_lookup("en") == "English"
    with pytest.raises(KeyError):
        lang2_lookup("invalid")


def test_ddc_regex_mapping():
    # Test for natural science (50x)
    assert "Allgemeine Naturwissenschaft" in ddc_lookup("501")
    # Test for multiple matches
    result = ddc_lookup("501")
    assert "Allgemeine Naturwissenschaft" in result
    # Test normalization (removing leading _;_)
    assert not ddc_lookup("501").startswith("_;_")


def test_finc_class_facet_fallback():
    # Test existing key
    assert class_facet_lookup("science") == "Allgemeine Naturwissenschaft"
    # Test non-existing key (should return None according to implementation)
    assert class_facet_lookup("non-existent-key") is None


def test_fotothek_large_mapping():
    from slub_finclookup.fotothekSubject_2_finc_class_facet import lookup as foto_lookup

    assert foto_lookup("Abguss") == "Kunst und Kunstgeschichte"
    assert foto_lookup("Zyklus") == "Kunst und Kunstgeschichte"
