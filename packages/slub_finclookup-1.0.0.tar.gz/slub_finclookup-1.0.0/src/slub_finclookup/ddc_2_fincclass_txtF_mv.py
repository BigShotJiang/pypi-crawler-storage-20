"""
Lookup module: DDC (Dewey Decimal Classification) -> fincclass_txtF_mv.

Derived from Fincclass.toml.
"""

import re


def lookup(value: str) -> str:
    """
    Look up fincclass_txtF_mv values based on DDC values using regex matching.

    Returns a concatenated string of facets separated by '_;_'.
    """
    fc = ""
    if re.findall(r"^(63[0-9]|71[02-9]).*", value):
        fc = fc + "_;_agriculture"
    if re.findall(r"^93[0-9].*", value):
        fc = fc + "_;_archeology"
    if re.findall(r"^7[12][0-9].*", value):
        fc = fc + "_;_architecture"
    if re.findall(r"^(028|070|302).*", value):
        fc = fc + "_;_communication-studies"
    if re.findall(r"^(3[38]|65)[0-9].*", value):
        fc = fc + "_;_economics"
    if re.findall(r"^(613|636.8|64[0-9]).*", value):
        fc = fc + "_;_economics-home"
    if re.findall(r"^37[0-9].*", value):
        fc = fc + "_;_education"
    if re.findall(r"^624.*", value):
        fc = fc + "_;_engineering-civil"
    if re.findall(r"^621.*", value):
        fc = fc + "_;_engineering-electrical"
    if re.findall(r"^(621\.48|333\.79).*", value):
        fc = fc + "_;_engineering-energy"
    if re.findall(r"^621\.8.*", value):
        fc = fc + "_;_engineering-mechanical"
    if re.findall(r"^660.*", value):
        fc = fc + "_;_engineering-process"
    if re.findall(r"^(38[05-8]|629\.04).*", value):
        fc = fc + "_;_engineering-transport"
    if re.findall(r"^62[78].*", value):
        fc = fc + "_;_engineering-water"
    if re.findall(r"^3[09][0-9].*", value):
        fc = fc + "_;_ethnology"
    if re.findall(r"^7[03-6][0-9].*", value):
        fc = fc + "_;_finearts"
    if re.findall(r"^0[135-8].*", value):
        fc = fc + "_;_general"
    if re.findall(r"^(91[0-9]|71[01]).*", value):
        fc = fc + "_;_geography"
    if re.findall(r"^(9[02-9]|27)[0-9].*", value):
        fc = fc + "_;_history"
    if re.findall(r"^((0(02|70|(9[0-9])))|(6(76|86))).*", value):
        fc = fc + "_;_information-bookscience"
    if re.findall(r"^0(0[0-3]|[67]).*", value):
        fc = fc + "_;_information-knowledge"
    if re.findall(r"^0(0(1|3)|[2][0-9]).*", value):
        fc = fc + "_;_information-library-systems"
    if re.findall(r"^34[0-9].*", value):
        fc = fc + "_;_law"
    if re.findall(r"^61[0-9].*", value):
        fc = fc + "_;_medicine"
    if re.findall(r"^636\.089.*", value):
        fc = fc + "_;_medicine-veterinary"
    if re.findall(r"^551\.[56].*", value):
        fc = fc + "_;_meteorology-climatology"
    if re.findall(r"^622.*", value):
        fc = fc + "_;_mining-metallurgy"
    if re.findall(r"^78[0-9]\.*", value):
        fc = fc + "_;_music"
    if re.findall(r"^615\.*", value):
        fc = fc + "_;_pharmacology"
    if re.findall(r"^(4[019][0-9]|8[09][0-9]).*", value):
        fc = fc + "_;_philology"
    if re.findall(r"^(42[0-9]|8[12][0-9]).*", value):
        fc = fc + "_;_philology-english"
    if re.findall(r"^[48]3[0-9].*", value):
        fc = fc + "_;_philology-germanicscandinavian"
    if re.findall(r"^[48][78][0-9].*", value):
        fc = fc + "_;_philology-greeklatin"
    if re.findall(r"^[48][4-7][0-9].*", value):
        fc = fc + "_;_philology-romanic"
    if re.findall(r"^[48]91\.8", value):
        fc = fc + "_;_philology-slavic"
    if re.findall(r"^(1[0-46-9]|21)[0-9].*", value):
        fc = fc + "_;_philosophy"
    if re.findall(r"^77[0-9].*", value):
        fc = fc + "_;_photography"
    if re.findall(r"^3[25][0-9].*", value):
        fc = fc + "_;_politicalscience-administration-military"
    if re.findall(r"^1([35][0-9]|00).*", value):
        fc = fc + "_;_psychology"
    if re.findall(r"^79[03-9].*", value):
        fc = fc + "_;_recreation"
    if re.findall(r"^2[0-9]{2}.*", value):
        fc = fc + "_;_religion"
    if re.findall(r"^50[0-9].*", value):
        fc = fc + "_;_science"
    if re.findall(r"^5[7-9][0-9].*", value):
        fc = fc + "_;_science-biology"
    if re.findall(r"^(54|66)[0-9].*", value):
        fc = fc + "_;_science-chemistry"
    if re.findall(r"^00[456].*", value):
        fc = fc + "_;_science-computerscience"
    if re.findall(r"^(333\.[7-9]|363\.7|577|628).*", value):
        fc = fc + "_;_science-environmental"
    if re.findall(r"^526\.1*", value):
        fc = fc + "_;_science-geodesy"
    if re.findall(r"^5[56][0-9].*", value):
        fc = fc + "_;_science-geology"
    if re.findall(r"^(333\.9|551\.4[6-8]|553\.7).*", value):
        fc = fc + "_;_science-hydrology"
    if re.findall(r"^620\.1.*", value):
        fc = fc + "_;_science-materials"
    if re.findall(r"^51[0-9].*", value):
        fc = fc + "_;_science-mathematics"
    if re.findall(r"^5[23][0-9].*", value):
        fc = fc + "_;_science-physics"
    if re.findall(r"^3[016][0-9].*", value):
        fc = fc + "_;_socialsciences"
    if re.findall(r"^6[02789][0-9].*", value):
        fc = fc + "_;_technology"
    if re.findall(r"^79[12].*", value):
        fc = fc + "_;_theatre-dance-film"

    # Remove leading delimiter
    fc = re.sub(r"^_;_", "", fc)

    return fc
