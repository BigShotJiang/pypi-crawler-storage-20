"""
Lookup module: ICS (International Classification for Standards) -> fincclass_txtF_mv.
"""

import re


def lookup(value: str) -> str:
    """
    Look up fincclass_txtF_mv based on ICS values using regex matching.

    Returns a concatenated string of facets separated by '_;_'.
    """
    fc = ""
    if re.findall(r"^(01\.040\.07|07)", value):
        fc = fc + "_;_science"
    if re.findall(r"^(01\.(0[247]0$|040\.01|080)|01$|03.240|99)", value):
        fc = fc + "_;_general"
    if re.findall(r"^(01\.100\.30)", value):
        fc = fc + "_;_architecture"
    if re.findall(r"^(01\.(040\.9[13]|100\.30)|35\.240\.10|91|93)", value):
        fc = fc + "_;_engineering-civil"
    if re.findall(r"^(01\.040\.7[37]|7[37])", value):
        fc = fc + "_;_mining-metallurgy"
    if re.findall(r"^07\.(08|10)0", value):
        fc = fc + "_;_science-biology"
    if re.findall(r"^(01\.040\.7[15]|07\.030|37\.040\.30|71)", value):
        fc = fc + "_;_science-chemistry"
    if re.findall(
        r"^(01\.(040\.(29|31)|080\.40|100\.25)|97\.(0[3468]0|1[02]0|200)|(13\.(260|320)|29|31))",
        value,
    ):
        fc = fc + "_;_engineering-electrical"
    if re.findall(r"^(01\.040\.27|27)", value):
        fc = fc + "_;_engineering-energy"
    if re.findall(r"^37\.(04|10)0", value):
        fc = fc + "_;_photography"
    if re.findall(r"^07\.040", value):
        fc = fc + "_;_geography"
    if re.findall(r"^(07\.060|13\.080|75)", value):
        fc = fc + "_;_science-geology"
    if re.findall(
        r"^((01\.040\.[69]7)|07\.100\.30|13\.120|67|97\.([01][0-9]0|145)|97$)", value
    ):
        fc = fc + "_;_economics-home"
    if re.findall(r"^(07\.(060|100\.20)|13\.060)", value):
        fc = fc + "_;_science-hydrology"
    if re.findall(r"^(01\.(040\.3[35]|080\.50|100\.27)|37\.080|3[35])", value):
        fc = fc + "_;_science-computerscience"
    if re.findall(r"^(01\.140(\.[14]0|$))", value):
        fc = fc + "_;_information-bookscience"
    if re.findall(r"^(01\.140(\.20|$))", value):
        fc = fc + "_;_information-library-systems"
    if re.findall(r"^97\.195", value):
        fc = fc + "_;_finearts"
    if re.findall(r"^(01\.040\.65|65)", value):
        fc = fc + "_;_agriculture"
    if re.findall(
        r"^(01\.(040\.25|080\.30|100\.20)|(13\.110|2[135]|55.200|59\.1[24]0|61\.080))",
        value,
    ):
        fc = fc + "_;_engineering-mechanical"
    if re.findall(r"^(01\.040\.07|07$|07\.020)", value):
        fc = fc + "_;_science-mathematics"
    if re.findall(
        r"^(01\.040\.1[13]|07\.100\.10|11\.(0[2468]|1[0468]|20)0|35\.240\.80)", value
    ):
        fc = fc + "_;_medicine"
    if re.findall(r"^(01\.040\.17|17|07\.060)", value):
        fc = fc + "_;_meteorology-climatology"
    if re.findall(r"^97\.200\.20", value):
        fc = fc + "_;_music"
    if re.findall(r"^03\.180", value):
        fc = fc + "_;_education"
    if re.findall(r"^11\.120", value):
        fc = fc + "_;_pharmacology"
    if re.findall(r"^(01\.0(40\.17|60|75)|07\.0[34]0|17|37\.020)", value):
        fc = fc + "_;_science-physics"
    if re.findall(r"^(01\.040\.(03|95)|95)", value):
        fc = fc + "_;_politicalscience-administration-military"
    if re.findall(r"^03\.160", value):
        fc = fc + "_;_law"
    if re.findall(r"^(01\.040\.03|03\.(020|100\.30))", value):
        fc = fc + "_;_socialsciences"
    if re.findall(r"^(01\.040\.97|03\.200|97\.(200\.[345]|22)0|97$)", value):
        fc = fc + "_;_recreation"
    if re.findall(
        r"^(01\.(040\.(1[19]|2[13]|3[3579]|53|67)|080|1[012]0)|13\.(1[028]|2[02348]|3[014])0|19|3[3579]|53)",
        value,
    ):
        fc = fc + "_;_technology"
    if re.findall(r"^(37\.060|97\.200\.(01|10|99))", value):
        fc = fc + "_;_theatre-dance-film"
    if re.findall(r"^(01\.(040\.13)|13\.(0[234]|1[46])0)", value):
        fc = fc + "_;_science-environmental"
    if re.findall(
        r"^(01\.040\.(59|61|7[159]|8[1357])|03\.100\.50|55\.(0[2468]0|1[02346]0)|(59|6[17]|7[15]))",
        value,
    ):
        fc = fc + "_;_engineering-process"
    if re.findall(r"^(01\.040\.(03|4[3579]|55)|(03\.220|4[3579])|49|55\.180)", value):
        fc = fc + "_;_engineering-transport"
    if re.findall(r"^07\.040", value):
        fc = fc + "_;_science-geodesy"
    if re.findall(r"^11\.220", value):
        fc = fc + "_;_medicine-veterinary"
    if re.findall(r"^(79|8[1357])", value):
        fc = fc + "_;_science-materials"
    if re.findall(r"^(01\.(040\.03|140\.30)|03\.(0[468]0|1[024]0)|55\.2[23]0)", value):
        fc = fc + "_;_economics"
    fc = re.sub(r"^_;_", "", fc)

    return fc
