"""
Lookup module: KNM (Classification for Norms/Media?) -> finc class facet.
"""

KNM_TO_FINC_CLASS_FACET = {
    "Architecture": "Technik",
    "Arts and Media": "Kunst und Kunstgeschichte",
    "Information Technology": "Informatik",
    "Life Sciences": "Biologie",
    "Chemistry": "Chemie und Pharmazie",
    "Earth Sciences": "Geologie und Paläontologie_;_Geographie",
    "Economics/Social Sciences": "Wirtschaftswissenschaften_;_Soziologie",
    "Educational Science": "Pädagogik",
    "Environmental Sciences/Ecology": "Land- und Forstwirtschaft, Gartenbau, Fischereiwirtschaft, Hauswirtschaft",
    "Ethnology": "Ethnologie (Volks- und Völkerkunde)_;_Klassische Archäologie",
    "History": "Geschichte",
    "Information Science": "Allgemeines",
    "Law": "Rechtswissenschaft",
    "Linguistics": "Allgemeine und vergleichende Sprach- und Literaturwissenschaft, Indogermanistik, Außereuropäische Sprachen und Literaturen",
    "Literature Studies": "Allgemeine und vergleichende Sprach- und Literaturwissenschaft, Indogermanistik, Außereuropäische Sprachen und Literaturen",
    "Mathematics": "Mathematik",
    "Medicine": "Medizin",
    "Philosophy": "Philosophie",
    "Physics": "Physik",
    "Psychology": "Psychologie",
    "Engineering": "Technik",
    "Sports Science": "Sport",
    "Study of Religions": "Theologie und Religionswissenschaft",
    "Other": "Allgemeines",
}


def lookup(value: str) -> str:
    """
    Look up finc class facet for a given KNM notation.

    Args:
        value: The KNM notation string.

    Returns:
        The mapped finc class facet.
    """
    return KNM_TO_FINC_CLASS_FACET[value]
