"""
Lookup module: finc class facet -> fincclass_txtF_mv.

Transitional solution for Fotothek.
"""

FINC_CLASS_FACET_TO_FINCCLASS_TXTF_MV = {
    "Allgemeine Naturwissenschaft": "science",
    "Allgemeine und vergleichende Sprach- und Literaturwissenschaft, Indogermanistik, Außereuropäische Sprachen und Literaturen": "philology",
    "Allgemeines": "general",
    "Anglistik, Amerikanistik": "philology-english",
    "Biologie": "science-biology",
    "Byzantinistik": "philology-greeklatin",
    "Chemie und Pharmazie": "science-chemistry_;_pharmacology",
    "Ethnologie (Volks- und Völkerkunde)": "ethnology",
    "Geographie": "geography",
    "Geologie und Paläontologie": "science-geology",
    "Germanistik, Niederlandistik, Skandinavistik": "philology-germanicscandinavian",
    "Geschichte": "history",
    "Informatik": "science-computerscience",
    "Klassische Archäologie": "archeology",
    "Klassische Philologie": "philology-greeklatin",
    "Kunst und Kunstgeschichte": "finearts",
    "Land- und Forstwirtschaft, Gartenbau, Fischereiwirtschaft, Hauswirtschaft": "agriculture_;_economics-home",
    "Mathematik": "science-mathematics",
    "Medizin": "medicine_;_medicine-veterinary",
    "Militärwissenschaft": "politicalscience-administration-military",
    "Mittellateinische Philologie": "philology-greeklatin",
    "Musikwissenschaft": "music",
    "Neugriechische Philologie": "philology-greeklatin",
    "Neulateinische Philologie": "philology-greeklatin",
    "Pädagogik": "education",
    "Philosophie": "philosophy",
    "Physik": "science-physics",
    "Politologie": "politicalscience-administration-military",
    "Psychologie": "psychology",
    "Rechtswissenschaft": "law",
    "Romanistik": "philology-romanic",
    "Slawistik": "philology-slavic",
    "Soziologie": "socialsciences",
    "Sport": "recreation",
    "Technik": "technology",
    "Theologie und Religionswissenschaft": "religion",
    "Wirtschaftswissenschaften": "economics",
}


def lookup(value: str) -> str:
    """
    Look up fincclass_txtF_mv for a given finc class facet.

    Args:
        value: The finc class facet string.

    Returns:
        The mapped value.
    """
    return FINC_CLASS_FACET_TO_FINCCLASS_TXTF_MV[value]
