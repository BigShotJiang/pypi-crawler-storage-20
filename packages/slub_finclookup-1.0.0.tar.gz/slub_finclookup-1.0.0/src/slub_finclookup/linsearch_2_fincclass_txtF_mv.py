"""
Lookup module: linsearch notation -> fincclass_txtF_mv.
"""

LINSEARCH_TO_FINCCLASS_TXTF_MV = {
    "arc": "architecture",
    "che": "science-chemistry",
    "inf": "science-computerscience",
    "mat": "science-mathematics",
    "phy": "science-physics",
    "tec": "technology",
    "fer": "science-materials",
    "mas": "engineering-mechanical",
    "elt": "engineering-electrical",
    "ver": "engineering-transport",
    "bau": "engineering-civil",
    "ber": "mining-metallurgy",
    "cet": "engineering-process_;_science-environmental",
    "med": "medicine",
    "bio": "science-biology",
    "pae": "education",
    "hor": "agriculture",
    "geo": "science-geology_;_science-hydrology_;_geography",
    "his": "history",
    "lin": "philology",
    "lit": "philology",
    "phi": "philosophy",
    "jur": "law",
    "rel": "religion",
    "sow": "socialsciences",
    "spo": "recreation",
    "oek": "economics",
}


def lookup(value: str) -> str:
    """
    Look up fincclass_txtF_mv for a given linsearch notation.

    Args:
        value: The linsearch notation.

    Returns:
        The mapped value.
    """
    return LINSEARCH_TO_FINCCLASS_TXTF_MV[value]
