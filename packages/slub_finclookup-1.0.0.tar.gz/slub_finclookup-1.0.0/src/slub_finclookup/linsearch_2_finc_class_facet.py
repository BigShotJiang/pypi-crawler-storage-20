"""
Lookup module: linsearch notation -> finc class facet.
"""

LINSEARCH_TO_FINC_CLASS_FACET = {
    "arc": "Technik",
    "che": "Chemie und Pharmazie",
    "inf": "Informatik",
    "mat": "Mathematik",
    "phy": "Physik",
    "tec": "Technik",
    "fer": "Technik",
    "mas": "Technik",
    "elt": "Technik",
    "ver": "Technik",
    "bau": "Technik",
    "ber": "Technik",
    "cet": "Technik",
    "med": "Technik",
    "bio": "Biologie",
    "pae": "Pädagogik",
    "hor": "Land- und Forstwirtschaft, Gartenbau, Fischereiwirtschaft, Hauswirtschaft",
    "geo": "Geologie und Paläontologie_;_Geographie",
    "his": "Geschichte",
    "lin": "Allgemeine und vergleichende Sprach- und Literaturwissenschaft, Indogermanistik, Außereuropäische Sprachen und Literaturen",
    "lit": "Allgemeine und vergleichende Sprach- und Literaturwissenschaft, Indogermanistik, Außereuropäische Sprachen und Literaturen",
    "phi": "Philosophie",
    "jur": "Rechtswissenschaft",
    "rel": "Theologie und Religionswissenschaft",
    "sow": "Soziologie",
    "spo": "Sport",
    "oek": "Wirtschaftswissenschaften",
}


def lookup(value: str) -> str:
    """
    Look up finc class facet for a given linsearch notation.

    Args:
        value: The linsearch notation string.

    Returns:
        The mapped finc class facet.
    """
    return LINSEARCH_TO_FINC_CLASS_FACET[value]
