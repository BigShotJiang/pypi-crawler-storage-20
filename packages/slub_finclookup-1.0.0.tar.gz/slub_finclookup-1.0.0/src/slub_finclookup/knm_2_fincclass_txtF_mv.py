"""
Lookup module: KNM notation -> fincclass_txtF_mv.
"""

KNM_TO_FINCCLASS_TXTF_MV = {
    "Architecture": "architecture",
    "Arts and Media": "finearts_;_communication-studies",
    "Information Technology": "science-computerscience",
    "Life Sciences": "science-biology",
    "Chemistry": "science-chemistry",
    "Earth Sciences": "science-geology_;_geography",
    "Economics/Social Sciences": "economics_;_socialsciences",
    "Educational Science": "education",
    "Environmental Sciences/Ecology": "science-environmental",
    "Ethnology": "ethnology",
    "History": "history",
    "Information Science": "information-bookscience_;_information-library-systems_;_information-knowledge",
    "Law": "law",
    "Linguistics": "philology",
    "Literature Studies": "philology",
    "Mathematics": "science-mathematics",
    "Medicine": "medicine",
    "Philosophy": "philosophy",
    "Physics": "science-physics",
    "Psychology": "psychology",
    "Engineering": "technology",
    "Sports Science": "recreation",
    "Study of Religions": "religion",
    "Other": "general",
}


def lookup(value: str) -> str:
    """
    Look up fincclass_txtF_mv for a given KNM notation.

    Args:
        value: The KNM notation string.

    Returns:
        The mapped value.
    """
    return KNM_TO_FINCCLASS_TXTF_MV[value]
