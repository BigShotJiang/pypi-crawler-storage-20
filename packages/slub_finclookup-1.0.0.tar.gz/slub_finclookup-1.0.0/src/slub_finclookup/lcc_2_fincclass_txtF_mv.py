"""
Lookup module: LCC (Library of Congress Classification) -> fincclass_txtF_mv.

Derived from Fincclass.toml.
"""

import re


def lookup(value: str) -> str:
    """
    Look up fincclass_txtF_mv based on LCC values using regex matching.

    Returns a concatenated string of facets separated by '_;_'.
    """
    fc = ""
    if re.findall(r"^CC.*", value):
        fc = fc + "_;_archeology"
    if re.findall(r"^G[FNRT].*", value):
        fc = fc + "_;_ethnology"
    if re.findall(r"^(C[0-9]*$|C[BDEJNRST].*|[DEF].*)", value):
        fc = fc + "_;_history"
    if re.findall(r"^Z(([4-8]|[4-9]\d|[1-5]\d{2}|6[0-5]\d)(\..*)?|)$", value):
        fc = fc + "_;_information-bookscience"
    if re.findall(r"^(Z.*|CD (9[0-9]{2}|[1-4][0-9]{3}))(\..*|\b)", value):
        fc = fc + "_;_information-library-systems"
    if re.findall(r"^(B[0-9]*$|B[CDHJ].*)", value):
        fc = fc + "_;_philosophy"
    if re.findall(r"^P(8[7-9]|9[0-9])(\..*|\b)", value):
        fc = fc + "_;_communication-studies"
    if re.findall(r"^B[LMPQRSTVX].*", value):
        fc = fc + "_;_religion"
    if re.findall(r"^(P[0-9]*$|P[BHJKLMNZ].*)", value):
        fc = fc + "_;_philology"
    if re.findall(r"^PA.*", value):
        fc = fc + "_;_philology-greeklatin"
    if re.findall(r"^P[DFT].*", value):
        fc = fc + "_;_philology-germanicscandinavian"
    if re.findall(r"^P[ERS].*", value):
        fc = fc + "_;_philology-english"
    if re.findall(r"^P[CQ].*", value):
        fc = fc + "_;_philology-romanic"
    if re.findall(r"^PG.*", value):
        fc = fc + "_;_philology-slavic"
    if re.findall(r"^TR.*", value):
        fc = fc + "_;_photography"
    if re.findall(r"^N.*", value):
        fc = fc + "_;_finearts"
    if re.findall(r"^M.*", value):
        fc = fc + "_;_music"
    if re.findall(r"^R.*", value):
        fc = fc + "_;_medicine"
    if re.findall(r"^R[MS].*", value):
        fc = fc + "_;_pharmacology"
    if re.findall(r"^SF.*", value):
        fc = fc + "_;_medicine-veterinary"
    if re.findall(r"^Q[HKLMPR].*", value):
        fc = fc + "_;_science-biology"
    if re.findall(r"^QD.*", value):
        fc = fc + "_;_science-chemistry"
    if re.findall(r"^(G[ABCEF].*|G[0-9]*$)", value):
        fc = fc + "_;_geography"
    if re.findall(r"^QE.*", value):
        fc = fc + "_;_science-geology"
    if re.findall(r"^QA.*", value):
        fc = fc + "_;_science-mathematics"
    if re.findall(r"^QC(8[5-9][0-9]|9[0-9]{2})(\..*|\b)", value):
        fc = fc + "_;_meteorology-climatology"
    if re.findall(r"^Q[BC].*", value):
        fc = fc + "_;_science-physics"
    if re.findall(r"^Q[0-9]*$", value):
        fc = fc + "_;_science"
    if re.findall(r"^K.*", value):
        fc = fc + "_;_law"
    if re.findall(r"^L.*", value):
        fc = fc + "_;_education"
    if re.findall(r"^BF.*", value):
        fc = fc + "_;_psychology"
    if re.findall(r"^GV.*", value):
        fc = fc + "_;_recreation"
    if re.findall(r"^NA.*", value):
        fc = fc + "_;_architecture"
    if re.findall(r"^TA.*", value):
        fc = fc + "_;_engineering-civil"
    if re.findall(r"TA(5[0-9]{2}|6[0-2][0-9]).*", value):
        fc = fc + "_;_science-geodesy"
    if re.findall(r"^TN.*", value):
        fc = fc + "_;_mining-metallurgy"
    if re.findall(r"^TK.*", value):
        fc = fc + "_;_engineering-electrical"
    if re.findall(r"^(TK 9[0-4][0-9]{2}|QC 7[7-9][0-9])(\..*|\b)", value):
        fc = fc + "_;_engineering-energy"
    if re.findall(r"^QA7[56]\.[5-9][0-9]*", value):
        fc = fc + "_;_science-computerscience"
    if re.findall(r"^T.*", value):
        fc = fc + "_;_technology"
    if re.findall(r"^(TL|TA1([01]\d{2}|2[0-7]\d|280)).*", value):
        fc = fc + "_;_engineering-transport"
    if re.findall(r"^(TP\d*|TA3(49|5\d))(\..*|\b)", value):
        fc = fc + "_;_engineering-process"
    if re.findall(r"^S.*", value):
        fc = fc + "_;_agriculture"
    if re.findall(r"^TA4[0-9]{2}(\..*|\b)", value):
        fc = fc + "_;_science-materials"
    if re.findall(r"^TJ.*", value):
        fc = fc + "_;_engineering-mechanical"
    if re.findall(r"^(GE|TD).*", value):
        fc = fc + "_;_science-environmental"
    if re.findall(
        r"^(GB(6[5-9][0-9]|[7-9][0-9]{2}|[12][0-9]{3})*(\..*|\b)|GC.*)", value
    ):
        fc = fc + "_;_science-hydrology"
    if re.findall(r"TD([2-6][0-9]{2}|7[0-7][0-9]|780)(\..*|\b)|TC.*", value):
        fc = fc + "_;_engineering-water"
    if re.findall(r"^([JUV]|HJ).*", value):
        fc = fc + "_;_politicalscience-administration-military"
    if re.findall(r"^(H[0-9]*$|H[AMNQSTVX].*)", value):
        fc = fc + "_;_socialsciences"
    if re.findall(r"^H[BCDEFGJ].*", value):
        fc = fc + "_;_economics"
    if re.findall(r"^A[A-Y].*", value):
        fc = fc + "_;_general"
    if re.findall(
        r"^T(P(3(6[89]|[7-9][0-9])|4([0-4][0-9]|5[0-6]))|X[0-9]{3})(\..*|\b)", value
    ):
        fc = fc + "_;_economics-home"
    if re.findall(r"^AZ.*", value):
        fc = fc + "_;_information-knowledge"
    fc = re.sub(r"^_;_", "", fc)

    return fc
