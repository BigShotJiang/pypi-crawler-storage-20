"""
Lookup module: DBIS Subject (Fachgebiete) -> finc class facet.

This module provides a mapping from granular DBIS subject headings to
broader finc class facets used for categorization in the search index.
"""

# Mapping dictionary moved to module level for efficiency
FACHGEBIETE_TO_FINC_CLASS_FACET = {
    "Allgemein / Fachübergreifend": "Allgemeines",
    "Allgemeine und vergleichende Sprach- und Literaturwissenschaft": "Allgemeine und vergleichende Sprach- und Literaturwissenschaft, Indogermanistik, Außereuropäische Sprachen und Literaturen",
    "Anglistik, Amerikanistik": "Anglistik, Amerikanistik",
    "Archäologie": "Klassische Archäologie",
    "Architektur, Bauingenieur- und Vermessungswesen": "Technik_;_Kunst und Kunstgeschichte",
    "Biologie": "Biologie",
    "Chemie": "Chemie und Pharmazie",
    "Elektrotechnik, Mess- und Regelungstechnik": "Technik",
    "Energie, Umweltschutz, Kerntechnik": "Technik",
    "Ethnologie (Volks- und Völkerkunde)": "Ethnologie (Volks- und Völkerkunde)",
    "Geographie": "Geographie",
    "Geowissenschaften": "Geologie und Paläontologie",
    "Germanistik, Niederländische Philologie, Skandinavistik": "Germanistik, Niederlandistik, Skandinavistik",
    "Geschichte": "Geschichte",
    "Informatik": "Informatik",
    "Informations-, Buch- und Bibliothekswesen, Handschriftenkunde": "Allgemeines",
    "Klassische Philologie": "Klassische Philologie",
    "Kunst ab 1945, Fotografie": "Kunst und Kunstgeschichte",
    "Kunstgeschichte": "Kunst und Kunstgeschichte",
    "Land- und Forstwirtschaft, Gartenbau, Fischereiwirtschaft, Hauswirtschaft, Ernährung": "Land- und Forstwirtschaft, Gartenbau, Fischereiwirtschaft, Hauswirtschaft",
    "Maschinenwesen, Werkstoffwissenschaften, Fertigungstechnik, Bergbau und Hüttenwesen, Verkehrstechnik, Feinwerktechnik": "Technik",
    "Mathematik": "Mathematik",
    "Medien- und Kommunikationswissenschaften, Publizistik, Film- und Theaterwissenschaft": "Allgemeines",
    "Medizin": "Medizin",
    "Musikwissenschaft": "Musikwissenschaft",
    "Naturwissenschaft allgemein": "Allgemeine Naturwissenschaft",
    "Pädagogik": "Pädagogik",
    "Pharmazie": "Chemie und Pharmazie",
    "Philosophie": "Philosophie",
    "Physik": "Physik",
    "Politologie": "Politologie",
    "Psychologie": "Psychologie",
    "Rechtswissenschaft": "Rechtswissenschaft",
    "Romanistik": "Romanistik",
    "Slavistik": "Slawistik",
    "Soziologie": "Soziologie",
    "Sport": "Sport",
    "Technik allgemein": "Technik",
    "Theologie und Religionswissenschaft": "Theologie und Religionswissenschaft",
    "Verfahrenstechnik, Biotechnologie, Lebensmitteltechnologie": "Technik_;_Biologie",
    "Wasserwesen, Wasserwirtschaft, Abwasserbehandlung, Hydrologie, Meteorologie": "Geographie",
    "Wirtschaftswissenschaften": "Wirtschaftswissenschaften",
    "Wissenschaftskunde, Forschungs-, Hochschul-, Museumswesen": "Allgemeines",
}


def lookup(value: str) -> str:
    """
    Look up the finc class facet for a given DBIS subject.

    Args:
        value: The DBIS subject string.

    Returns:
        The corresponding finc class facet.

    Raises:
        KeyError: If the subject is not found.
    """
    return FACHGEBIETE_TO_FINC_CLASS_FACET[value]
