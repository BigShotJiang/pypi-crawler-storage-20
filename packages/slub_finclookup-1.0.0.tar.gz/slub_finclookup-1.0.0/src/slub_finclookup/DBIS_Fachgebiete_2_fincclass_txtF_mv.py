"""
Lookup module: DBIS Subject (Fachgebiete) -> fincclass_txtF_mv.

This module maps DBIS subjects to the 'fincclass_txtF_mv' field usage.
"""

FACHGEBIETE_TO_FINCCLASS_TXTF_MV = {
    "Allgemein / Fachübergreifend": "general",
    "Allgemeine und vergleichende Sprach- und Literaturwissenschaft": "philology",
    "Anglistik, Amerikanistik": "philology-english",
    "Archäologie": "archeology",
    "Architektur, Bauingenieur- und Vermessungswesen": "architecture_;_engineering-civil_;_science-geodesy",
    "Biologie": "science-biology",
    "Chemie": "science-chemistry",
    "Elektrotechnik, Mess- und Regelungstechnik": "engineering-electrical",
    "Energie, Umweltschutz, Kerntechnik": "engineering-energy_;_science-environmental",
    "Ethnologie (Volks- und Völkerkunde)": "ethnology",
    "Geographie": "geography",
    "Geowissenschaften": "science-geology",
    "Germanistik, Niederländische Philologie, Skandinavistik": "philology-germanicscandinavian",
    "Geschichte": "history",
    "Informatik": "science-computerscience",
    "Informations-, Buch- und Bibliothekswesen, Handschriftenkunde": "information-bookscience_;_information-library-systems",
    "Klassische Philologie": "philology-greeklatin",
    "Kunst ab 1945, Fotografie": "finearts_;_photography",
    "Kunstgeschichte": "finearts",
    "Land- und Forstwirtschaft, Gartenbau, Fischereiwirtschaft, Hauswirtschaft, Ernährung": "agriculture_;_economics-home",
    "Maschinenwesen, Werkstoffwissenschaften, Fertigungstechnik, Bergbau und Hüttenwesen, Verkehrstechnik, Feinwerktechnik": "engineering-mechanical_;_science-materials_;_mining-metallurgy_;_engineering-transport",
    "Mathematik": "science-mathematics",
    "Medien- und Kommunikationswissenschaften, Publizistik, Film- und Theaterwissenschaft": "communication-studies_;_theatre-dance-film",
    "Medizin": "medicine_;_medicine-veterinary",
    "Musikwissenschaft": "music",
    "Naturwissenschaft allgemein": "science",
    "Pädagogik": "education",
    "Pharmazie": "pharmacology",
    "Philosophie": "philosophy",
    "Physik": "science-physics",
    "Politologie": "politicalscience-administration-military",
    "Psychologie": "psychology",
    "Rechtswissenschaft": "law",
    "Romanistik": "philology-romanic",
    "Slavistik": "philology-slavic",
    "Soziologie": "socialsciences",
    "Sport": "recreation",
    "Technik allgemein": "technology",
    "Theologie und Religionswissenschaft": "religion",
    "Verfahrenstechnik, Biotechnologie, Lebensmitteltechnologie": "engineering-process",
    "Wasserwesen, Wasserwirtschaft, Abwasserbehandlung, Hydrologie, Meteorologie": "engineering-water_;_science-hydrology_;_meteorology-climatology",
    "Wirtschaftswissenschaften": "economics",
    "Wissenschaftskunde, Forschungs-, Hochschul-, Museumswesen": "information-knowledge",
}


def lookup(value: str) -> str:
    """
    Look up the fincclass_txtF_mv value for a given DBIS subject.

    Args:
        value: The DBIS subject string.

    Returns:
        The mapped value.

    Raises:
        KeyError: If the subject is not found.
    """
    return FACHGEBIETE_TO_FINCCLASS_TXTF_MV[value]
