"""
Lookup module: DDC (Dewey Decimal Classification) -> finc class facet.

Derived from finc_class.bsh.
"""

import re


def lookup(value: str) -> str:
    """
    Look up finc class facets based on DDC values using regex matching.

    Returns a concatenated string of facets separated by '_;_'.
    """
    fc = ""
    # 5 series
    if re.findall(r"^50[0-9].*", value):
        fc = fc + "_;_Allgemeine Naturwissenschaft"
    if re.findall(r"^0(0[0-3789]|[1-9][0-9])", value):
        fc = fc + "_;_Allgemeines"
    if re.findall(r"^(4[019]|8[09])[0-9].*", value):
        fc = (
            fc
            + "_;_Allgemeine und vergleichende Sprach- und Literaturwissenschaft, Indogermanistik, Außereuropäische Sprachen und Literaturen"
        )
    if re.findall(r"^(42|8[12])[0-9].*", value):
        fc = fc + "_;_Anglistik, Amerikanistik"
    if re.findall(r"^5[7-9][0-9].*", value):
        fc = fc + "_;_Biologie"
    if re.findall(r"^(54|66)[0-9].*", value):
        fc = fc + "_;_Chemie und Pharmazie"
    if re.findall(r"^39[0-9].*", value):
        fc = fc + "_;_Ethnologie (Volks- und Völkerkunde)"
    if re.findall(r"^(55[0-9]|91[0-9]|900).*", value):
        fc = fc + "_;_Geographie"
    if re.findall(r"^5[56][0-9].*", value):
        fc = fc + "_;_Geologie und Paläontologie"
    if re.findall(r"^[48]3[0-9].*", value):
        fc = fc + "_;_Germanistik, Niederlandistik, Skandinavistik"
    if re.findall(r"^(27|9[0-9])[0-9].*", value):
        fc = fc + "_;_Geschichte"
    if re.findall(r"^00[456].*", value):
        fc = fc + "_;_Informatik"
    if re.findall(r"^93[0-9].*", value):
        fc = fc + "_;_Klassische Archäologie"
    if re.findall(r"^(4|8)[78][0-9].*", value):
        fc = fc + "_;_Klassische Philologie"
    if re.findall(r"^7[02-7][0-9].*", value):
        fc = fc + "_;_Kunst und Kunstgeschichte"
    if re.findall(r"^(6[34]|71)[0-9].*", value):
        fc = (
            fc
            + "_;_Land- und Forstwirtschaft, Gartenbau, Fischereiwirtschaft, Hauswirtschaft"
        )
    if re.findall(r"^51[0-9].*", value):
        fc = fc + "_;_Mathematik"
    if re.findall(r"^61[0-9].*", value):
        fc = fc + "_;_Medizin"
    if re.findall(r"^35[0-9].*", value):
        fc = fc + "_;_Militärwissenschaft"
    if re.findall(r"^78[0-9].*", value):
        fc = fc + "_;_Musikwissenschaft"
    if re.findall(r"^(4|8)8[0-9].*", value):
        fc = fc + "_;_Neugriechische Philologie"
    if re.findall(r"^(4|8)7[0-9].*", value):
        fc = fc + "_;_Neulateinische Philologie"
    if re.findall(r"^37[0-9].*", value):
        fc = fc + "_;_Pädagogik"
    if re.findall(r"^(1[0-46-9]|21)[0-9].*", value):
        fc = fc + "_;_Philosophie"
    if re.findall(r"^5[23][0-9].*", value):
        fc = fc + "_;_Physik"
    if re.findall(r"^32[0-9].*", value):
        fc = fc + "_;_Politologie"
    if re.findall(r"^1([35][0-9]|00).*", value):
        fc = fc + "_;_Psychologie"
    if re.findall(r"^34[0-9].*", value):
        fc = fc + "_;_Rechtswissenschaft"
    if re.findall(r"^[48][456][0-9].*", value):
        fc = fc + "_;_Romanistik"
    if re.findall(r"^3[016][0-9].*", value):
        fc = fc + "_;_Soziologie"
    if re.findall(r"^79[0-9].*", value):
        fc = fc + "_;_Sport"
    if re.findall(r"^(6[027-9]|7[27])[0-9].*", value):
        fc = fc + "_;_Technik"
    if re.findall(r"^2[0-9][0-9].*", value):
        fc = fc + "_;_Theologie und Religionswissenschaft"
    if re.findall(r"^(3[38]|65)[0-9].*", value):
        fc = fc + "_;_Wirtschaftswissenschaften"

    # Remove leading delimiter
    fc = re.sub(r"^_;_", "", fc)

    return fc
