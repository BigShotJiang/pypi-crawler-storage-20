"""
Lookup module: ICS (International Classification for Standards) -> finc class facet.
"""

import re


def lookup(value: str) -> str:
    """
    Look up finc class facet based on ICS values using regex matching.

    Returns a concatenated string of facets separated by '_;_'.
    """
    fc = ""
    if re.findall(r"^0(1\.0(60|75)|7)", value):
        fc = fc + "_;_Allgemeine Naturwissenschaften"
    if re.findall(r"^(01\.(0[2478]|1[24])|03|13\.(0[2346]|1)|99)", value):
        fc = fc + "_;_Allgemeines"
    if re.findall(r"^07\.(08|10)", value):
        fc = fc + "_;_Biologie"
    if re.findall(r"^(07\.03|11\.12|71)", value):
        fc = fc + "_;_Chemie und Pharmazie"
    if re.findall(r"^0(3\.20|7\.0[46])", value):
        fc = fc + "_;_Geographie"
    if re.findall(r"^(07\.06|13\.08|7[357])", value):
        fc = fc + "_;_Geologie und Paläontologie"
    if re.findall(r"^3(5|7\.08)", value):
        fc = fc + "_;_Informatik"
    if re.findall(r"^97\.195", value):
        fc = fc + "_;_Kunst und Kunstgeschichte"
    if re.findall(r"^(6[57]|97\.(0[23468]0|1[023456789]0|145))", value):
        fc = (
            fc
            + "_;_Land- und Forstwirtschaft, Gartenbau, Fischereiwirtschaft, Hauswirtschaft"
        )
    if re.findall(r"^07\.020", value):
        fc = fc + "_;_Mathematik"
    if re.findall(r"^11", value):
        fc = fc + "_;_Medizin"
    if re.findall(r"^95", value):
        fc = fc + "_;_Militärwissenschaft"
    if re.findall(r"^03\.180", value):
        fc = fc + "_;_Pädagogik"
    if re.findall(r"^(07\.0[34]|17)", value):
        fc = fc + "_;_Physik"
    if re.findall(r"^03\.1[46]", value):
        fc = fc + "_;_Rechtswissenschaft"
    if re.findall(r"^03\.020", value):
        fc = fc + "_;_Soziologie"
    if re.findall(r"^(03\.200|97.220)", value):
        fc = fc + "_;_Sport"
    if re.findall(
        r"^(01\.1[012]|03\.2[24]|07\.040|1[1379]|2[13579]|3[1359]|37\.(0[2468]|100)|4[3579]|5[359]|6[17]|7[13579]|8[1357]|9[13]|97\.(0[23468]|1[023456789]|2[02]))",
        value,
    ):
        fc = fc + "_;_Technik"
    if re.findall(r"^03\.(0[468]|1[0246])", value):
        fc = fc + "_;_Wirtschaftswissenschaften"
    fc = re.sub(r"^_;_", "", fc)

    return fc
