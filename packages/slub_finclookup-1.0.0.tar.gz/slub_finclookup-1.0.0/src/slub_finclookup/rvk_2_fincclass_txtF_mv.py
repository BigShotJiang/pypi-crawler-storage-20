"""
Lookup module: RVK (Regensburger Verbundklassifikation) -> fincclass_txtF_mv.

Derived from Fincclass.toml.
"""

import re


def lookup(value: str) -> str:
    """
    Look up fincclass_txtF_mv based on RVK values using regex matching.

    Returns a concatenated string of facets separated by '_;_'.
    """
    fc = ""
    if re.findall(
        r"(LD [1-2][0-9]+)|(L[E-G] [0-9]+)|(FB 4([0-2][0-9]+|3[01][0-9]|320))", value
    ):
        fc = fc + "_;_archeology"
    if re.findall(r"L[A-C] [0-9]+", value):
        fc = fc + "_;_ethnology"
    if re.findall(r"N[A-Z] [0-9]+", value):
        fc = fc + "_;_history"
    if re.findall(
        r"^(AN ((1[4-9])|[2-4]))|(AM ((1[0-8])|(2[0-9])|(3[0-4])))|L(H 72|K 86)", value
    ):
        fc = fc + "_;_information-bookscience"
    if re.findall(
        r"A(K 14|L 12)3[0-9][0-9]|AN 1[0-3|5-9]|AN [5-9]|BO 13(65|70)|GZ [0-9]94[0-8]|ND [1-4][0-9]{3}|PS 3890|PN 981\.?852|ZH 6215",
        value,
    ):
        fc = fc + "_;_information-library-systems"
    if re.findall(r"A[KL] [0-9]+", value):
        fc = fc + "_;_information-knowledge"
    if re.findall(r"C[A-K] [0-9]+", value):
        fc = fc + "_;_philosophy"
    if re.findall(r"AP [0-9]+", value):
        fc = fc + "_;_communication-studies"
    if re.findall(r"B[A-Z] [0-9]+", value):
        fc = fc + "_;_religion"
    if re.findall(r"E[A-Z] [0-9]+", value):
        fc = fc + "_;_philology"
    if re.findall(r"F[A-Z] [0-9]+", value):
        fc = fc + "_;_philology-greeklatin"
    if re.findall(r"G[A-Z] [0-9]+", value):
        fc = fc + "_;_philology-germanicscandinavian"
    if re.findall(r"H[A-Z] [0-9]+", value):
        fc = fc + "_;_philology-english"
    if re.findall(r"(I[A-Z]|FP) [0-9]+", value):
        fc = fc + "_;_philology-romanic"
    if re.findall(r"K[A-Z] [0-9]+", value):
        fc = fc + "_;_philology-slavic"
    if re.findall(
        r"AP 9([0-8][0-9]+|90[0-9]+)|GZ [0-9]84[0-9]|LH (67325|70190)|WC 3500|ZH 3780",
        value,
    ):
        fc = fc + "_;_photography"
    if re.findall(r"(LD [3-7]|L[H-O] |LC 9[0-4])[0-9]+", value):
        fc = fc + "_;_finearts"
    if re.findall(r"(LD (8[7-9]|9)|L[P-Y] )[0-9]+", value):
        fc = fc + "_;_music"
    if re.findall(r"(AP ([4-7]|8[0-7]|88[0-4]))[0-9]+", value):
        fc = fc + "_;_theatre-dance-film"
    if re.findall(r"(W[W-X]|X[A-WYZ]|Y[A-V]|MT) [0-9]+", value):
        fc = fc + "_;_medicine"
    if re.findall(r"V[AO-Z] [0-9]+", value):
        fc = fc + "_;_pharmacology"
    if re.findall(r"XX [0-9]+", value):
        fc = fc + "_;_medicine-veterinary"
    if re.findall(r"W[A-Z] [0-9]+", value):
        fc = fc + "_;_science-biology"
    if re.findall(r"V[A-N] [0-9]+", value):
        fc = fc + "_;_science-chemistry"
    if re.findall(r"R[A-Z] [0-9]+", value):
        fc = fc + "_;_geography"
    if re.findall(r"T[E-Z] [0-9]+", value):
        fc = fc + "_;_science-geology"
    if re.findall(r"S[A-P] [0-9]+", value):
        fc = fc + "_;_science-mathematics"
    if re.findall(
        r"R[B-Z] \d{2}4([2-5]\d|6[0-2])|YU 1200|UB (1064|1485|2[04]85|5280)|UT [5-9][0-9]{3}'",
        value,
    ):
        fc = fc + "_;_meteorology-climatology"
    if re.findall(r"U[A-Z] [0-9]+", value):
        fc = fc + "_;_science-physics"
    if re.findall(r"T[A-D] [0-9]+", value):
        fc = fc + "_;_science"
    if re.findall(r"P[A-Z] [0-9]+", value):
        fc = fc + "_;_law"
    if re.findall(r"D[A-Z] [0-9]+", value):
        fc = fc + "_;_education"
    if re.findall(r"C[L-Z] [0-9]+", value):
        fc = fc + "_;_psychology"
    if re.findall(r"Z[X-Y] [0-9]+", value):
        fc = fc + "_;_recreation"
    if re.findall(r"ZH [0-9]+|LD 8[0-6][0-9]+", value):
        fc = fc + "_;_architecture"
    if re.findall(r"ZI+", value):
        fc = fc + "_;_engineering-civil"
    if re.findall(r"R[B-Z] [1-9]{2}112|ZI 9[0-9]+|ZK 32[0-9]+", value):
        fc = fc + "_;_science-geodesy"
    if re.findall(r"ZK [0-9]+", value):
        fc = fc + "_;_mining-metallurgy"
    if re.findall(r"ZN [0-9]+", value):
        fc = fc + "_;_engineering-electrical"
    if re.findall(r"ZP [0-9]+", value):
        fc = fc + "_;_engineering-energy"
    if re.findall(r"S[Q-U] [0-9]+", value):
        fc = fc + "_;_science-computerscience"
    if re.findall(r"Z[G-S] [0-9]+", value):
        fc = fc + "_;_technology"
    if re.findall(r"ZO [0-9]+", value):
        fc = fc + "_;_engineering-transport"
    if re.findall(r"ZQ 9910|VN 7[0-3][0-9]+", value):
        fc = fc + "_;_engineering-process"
    if re.findall(r"Z([A-D] [0-9]|E [1-3]).*", value):
        fc = fc + "_;_agriculture"
    if re.findall(r"ZM [0-9]+", value):
        fc = fc + "_;_science-materials"
    if re.findall(r"ZL [0-9]+", value):
        fc = fc + "_;_engineering-mechanical"
    if re.findall(r"(QT |W[IK] |AR |VN 9)[0-9]+", value):
        fc = fc + "_;_science-environmental"
    if re.findall(
        r"TG 1164|TI 8[0-3][0-9]{2}|AR 22[0-9]{3}|WC 5400|WI 4[4-9][0-9]{2}|ZI 6[78][0-9]{2}|R[B-Z] \d{2}(34[5-9]|3[5-9]\d|40\d|41[0-7])'",
        value,
    ):
        fc = fc + "_;_science-hydrology"
    if re.findall(r"ZI 6[7-9][0-9]{2}", value):
        fc = fc + "_;_engineering-water"
    if re.findall(r"(M[A-LXZ]|JF|HJ) [0-9]+", value):
        fc = fc + "_;_politicalscience-administration-military"
    if re.findall(r"(DS|QX|M[N-S]) [0-9]+", value):
        fc = fc + "_;_socialsciences"
    if re.findall(r"Q[A-Z] [0-9]+", value):
        fc = fc + "_;_economics"
    if re.findall(r"A[A-FHV-YZ] [0-9]+", value):
        fc = fc + "_;_general"
    if re.findall(
        r"(VN 8([0-6]|70)|(VS 965)|(VT 525)|YT ([2-6]|7[0-8])|ZE [4-8]).*", value
    ):
        fc = fc + "_;_economics-home"
    fc = re.sub(r"^_;_", "", fc)

    return fc
