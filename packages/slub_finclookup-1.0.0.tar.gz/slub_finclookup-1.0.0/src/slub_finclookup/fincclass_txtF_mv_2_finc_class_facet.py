"""
Lookup module: fincclass_txtF_mv -> finc class facet.
"""

FINCCLASS_TXTF_MV_TO_FINC_CLASS_FACET = {
    "science": "Allgemeine Naturwissenschaft",
    "philology": "Allgemeine und vergleichende Sprach- und Literaturwissenschaft, Indogermanistik, Außereuropäische Sprachen und Literaturen",
    "general": "Allgemeines",
    "philology-english": "Anglistik, Amerikanistik",
    "science-biology": "Biologie",
    "science-chemistry": "Chemie und Pharmazie",
    "pharmacology": "Chemie und Pharmazie",
    "ethnology": "Ethnologie (Volks- und Völkerkunde)",
    "geography": "Geographie",
    "science-geology": "Geologie und Paläontologie",
    "philology-germanicscandinavian": "Germanistik, Niederlandistik, Skandinavistik",
    "history": "Geschichte",
    "science-computerscience": "Informatik",
    "archeology": "Klassische Archäologie",
    "philology-greeklatin": "Klassische Philologie",
    "finearts": "Kunst und Kunstgeschichte",
    "agriculture": "Land- und Forstwirtschaft, Gartenbau, Fischereiwirtschaft, Hauswirtschaft",
    "economics-home": "Land- und Forstwirtschaft, Gartenbau, Fischereiwirtschaft, Hauswirtschaft",
    "science-mathematics": "Mathematik",
    "medicine": "Medizin",
    "medicine-veterinary": "Medizin",
    "politicalscience-administration-military": "Militärwissenschaft",
    "music": "Musikwissenschaft",
    "education": "Pädagogik",
    "philosophy": "Philosophie",
    "science-physics": "Physik",
    # Duplicate key in original: 'politicalscience-administration-military': 'Politologie'
    # Keeping latest or correcting based on context? Original had it twice.
    # "politicalscience-administration-military": "Militärwissenschaft" (Line 27)
    # "politicalscience-administration-military": "Politologie" (Line 32)
    # The dictionary definition in Python will overwrite the first one with the second.
    # So 'Politologie' wins in the original code. I will explicitely define it as 'Politologie' here
    # but note the collision.
    "politicalscience-administration-military": "Politologie",
    "psychology": "Psychologie",
    "law": "Rechtswissenschaft",
    "philology-romanic": "Romanistik",
    "philology-slavic": "Slawistik",
    "socialsciences": "Soziologie",
    "recreation": "Sport",
    "technology": "Technik",
    "religion": "Theologie und Religionswissenschaft",
    "economics": "Wirtschaftswissenschaften",
}


def lookup(value: str) -> str | None:
    """
    Look up finc class facet for a given fincclass_txtF_mv.

    Returns:
        The mapped value or None if not found (preserving original behavior).
    """
    return FINCCLASS_TXTF_MV_TO_FINC_CLASS_FACET.get(value)
