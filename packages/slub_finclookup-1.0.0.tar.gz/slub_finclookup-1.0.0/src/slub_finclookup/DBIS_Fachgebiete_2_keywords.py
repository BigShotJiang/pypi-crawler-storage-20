"""
Lookup module: DBIS Subject (Fachgebiete) -> Keywords.

This module provides a mapping from DBIS subject headings to simplified keywords.
"""

FACHGEBIETE_TO_KEYWORDS = {
    "Allgemeine und vergleichende Sprach- und Literaturwissenschaft": "Sprach- und Literaturwissenschaft",
    "Anglistik, Amerikanistik": "Anglistik / Amerikanistik",
    "Archäologie": "Archäologie",
    "Architektur, Bauingenieur- und Vermessungswesen": "Architektur",
    "Biologie": "Biologie",
    "Chemie": "Chemie",
    "Elektrotechnik, Mess- und Regelungstechnik": "Elektrotechnik",
    "Energie, Umweltschutz, Kerntechnik": "Energie / Umweltschutz",
    "Ethnologie (Volks- und Völkerkunde)": "Ethnologie",
    "Geographie": "Geographie",
    "Geowissenschaften": "Geowissenschaften",
    "Germanistik, Niederländische Philologie, Skandinavistik": "Germanistik / Niederländische Philologie / Skandinavistik",
    "Geschichte": "Geschichte",
    "Informatik": "Informatik",
    "Informations-, Buch- und Bibliothekswesen, Handschriftenkunde": "Buch- und Bibliothekswesen /Handschriftenkunde",
    "Klassische Philologie": "Klassische Philologie",
    "Kunstgeschichte": "Kunstgeschichte",
    "Land- und Forstwirtschaft, Gartenbau, Fischereiwirtschaft, Hauswirtschaft, Ernährung": "Land- und Forstwirtschaft",
    "Maschinenwesen, Werkstoffwissenschaften, Fertigungstechnik, Bergbau und Hüttenwesen, Verkehrstechnik, Feinwerktechnik": "Technik",
    "Mathematik": "Mathematik",
    "Medien- und Kommunikationswissenschaften, Publizistik, Film- und Theaterwissenschaft": "Medien / Kommunikation / Publizistik / Film / Theater",
    "Medizin": "Medizin",
    "Musikwissenschaft": "Musikwissenschaft",
    "Naturwissenschaft allgemein": "Naturwissenschaft",
    "Pädagogik": "Pädagogik",
    "Pharmazie": "Pharmazie",
    "Philosophie": "Philosophie",
    "Physik": "Physik",
    "Politologie": "Politologie",
    "Psychologie": "Psychologie",
    "Rechtswissenschaft": "Rechtswissenschaft",
    "Romanistik": "Romanistik",
    "Slavistik": "Slavistik",
    "Soziologie": "Soziologie",
    "Sport": "Sport",
    "Technik allgemein": "Technik",
    "Theologie und Religionswissenschaft": "Theologie / Religionswissenschaft",
    "Verfahrenstechnik, Biotechnologie, Lebensmitteltechnologie": "Biotechnologie",
    "Wirtschaftswissenschaften": "Wirtschaftswissenschaften",
    "Wissenschaftskunde, Forschungs-, Hochschul-, Museumswesen": "Wissenschaftskunde / Museumswesen",
}


def lookup(value: str) -> str:
    """
    Look up the keyword for a given DBIS subject.

    Args:
        value: The DBIS subject string.

    Returns:
        The simplified keyword.

    Raises:
        KeyError: If the subject is not found.
    """
    return FACHGEBIETE_TO_KEYWORDS[value]
