# slub_finclookup

[![Python 3.12](https://img.shields.io/badge/python-3.12-blue.svg)](https://www.python.org/downloads/release/python-3120/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Ein modernes Python-Paket zur Transformation von Bibliotheksmetadaten und Klassifikationen für das finc-Projekt der SLUB Dresden.

## Warum dieses Paket?

In der bibliothekarischen Datenverarbeitung müssen häufig verschiedene Klassifikationssysteme (wie DDC, LCC, RVK oder lokale Fachgebiete) in ein einheitliches Format für Suchindizes (wie Solr) überführt werden. 

`slub_finclookup` bündelt diese historisch gewachsenen Mapping-Logiken in einem stabilen, performanten und gut dokumentierten Paket. Es bietet:
- **Präzision**: Exakte Abbildungen von Schlagworten und Notationen auf finc-Kategorien.
- **Performance**: Optimierte Datenstrukturen für schnelle Lookups auch bei sehr großen Tabellen (z.B. Fotothek).
- **Modernität**: Volle Kompatibilität mit Python 3.12 und einfache Integration in moderne Pipelines.

## Installation

```bash
pip install slub_finclookup
```

(Oder über `uv`):
```bash
uv add slub_finclookup
```

## Nutzung

Jedes Modul enthält eine `lookup`-Funktion, die einen Eingabewert auf das entsprechende finc-Facet abbildet.

### Beispiel: DBIS Fachgebiete
```python
from slub_finclookup.DBIS_Fachgebiete_2_finc_class_facet import lookup

result = lookup('Allgemein / Fachübergreifend')
print(result)  # Ausgabe: 'Allgemeines'
```

### Beispiel: Sprachentransformation
```python
from slub_finclookup.language2code_2_languageName import lookup

name = lookup('de')
print(name)  # Ausgabe: 'German'
```

## Enthaltene Mappings

Das Paket beinhaltet Transformationen für:
- **DBIS**: Fachgebiete zu finc Facets und Keywords.
- **Klassifikationen**: DDC, LCC, RVK, KNM, ICS.
- **Sprachen**: ISO 639-1 und 639-2 zu Klarnamen.
- **Fotothek**: Spezielle Schlagwort-Mappings für Bilddaten.

## Entwicklung und Beiträge

Projektplanung und technische Details finden Sie in den Dateien [plan.md](plan.md) und [docs/technical.md](docs/technical.md).

Dieses Projekt wird mit `uv` verwaltet. Um lokal zu entwickeln:

```bash
git clone https://git.slub-dresden.de/metadata/processing/slub_finclookup.git
cd slub_finclookup
uv sync
```

## Lizenz

Dieses Paket ist unter der MIT-Lizenz veröffentlicht.
