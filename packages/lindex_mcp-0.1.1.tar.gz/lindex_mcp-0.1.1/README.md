# Lindex

A powerful code context engine for AI assistants. Provides semantic code search and intelligent context retrieval using AST-aware chunking and vector embeddings.

## Features

- **AST-aware chunking** - Respects code structure (functions, classes, methods)
- **Semantic search** - Find code by meaning, not just keywords
- **Code Graph** - Symbol table, call graph, dependency analysis
- **Intelligent Context Assembly** - Expands results with dependencies and call chains
- **Real-time indexing** - Watches for file changes and updates automatically
- **MCP integration** - Works with any MCP-compatible AI tool
- **17 Languages** - Python, JS/TS, Go, Java, Rust, C/C++, C#, PHP, Ruby, and more

## Quick Start

### Install from PyPI

```bash
pip install lindex-mcp
```

### Configure MCP

Add to your MCP server configuration file:

```json
{
  "mcpServers": {
    "lindex": {
      "command": "uvx",
      "args": ["lindex-mcp", "serve"],
      "env": {
        "SILICONFLOW_API_KEY": "your-api-key"
      }
    }
  }
}
```

Or if installed via pip:

```json
{
  "mcpServers": {
    "lindex": {
      "command": "lindex",
      "args": ["serve"],
      "env": {
        "SILICONFLOW_API_KEY": "your-api-key"
      }
    }
  }
}
```

### Embedding Providers

Lindex supports multiple embedding providers:

| Provider | Model | Cost |
|----------|-------|------|
| **SiliconFlow** (Recommended) | Qwen3-Embedding-8B | ¥0.28/M tokens |
| Voyage AI | voyage-code-3 | $0.06/M tokens |
| OpenAI | text-embedding-3-small | $0.02/M tokens |
| Ollama | nomic-embed-text | Free (local) |

Set your API key as environment variable or in MCP configuration:
```bash
# SiliconFlow (recommended)
export SILICONFLOW_API_KEY=your-key

# Or Voyage
export VOYAGE_API_KEY=your-key

# Or OpenAI
export OPENAI_API_KEY=your-key
```

## Usage

### With AI Tools (MCP)

1. AI calls `init_workspace` with your project path
2. Lindex indexes all code files in background
3. AI uses `search_code` or `get_context` to find relevant code

### Available MCP Tools

| Tool | Description |
|------|-------------|
| `init_workspace` | Initialize and index a project |
| `search_code` | Semantic search for code |
| `get_context` | Intelligent context assembly with deps & call chains |
| `get_symbol` | Get info about a function/class/method |
| `get_callers` | Find all functions that call a given function |
| `get_dependencies` | Get file dependencies (imports) |
| `get_index_status` | Check indexing progress |
| `reindex` | Trigger incremental reindex |

### CLI Usage

```bash
# Index current directory
lindex index

# Search indexed code
lindex search "authentication logic"

# Run as MCP server
lindex serve
```

## Supported Languages

| Language | Extensions |
|----------|------------|
| Python | `.py`, `.pyw` |
| JavaScript | `.js`, `.mjs`, `.cjs`, `.jsx` |
| TypeScript | `.ts`, `.tsx`, `.mts` |
| Go | `.go` |
| Java | `.java` |
| Rust | `.rs` |
| C | `.c`, `.h` |
| C++ | `.cpp`, `.cc`, `.cxx`, `.hpp`, `.hxx` |
| C# | `.cs` |
| PHP | `.php` |
| Ruby | `.rb`, `.rake` |
| HTML | `.html`, `.htm`, `.vue`, `.svelte` |
| CSS | `.css`, `.scss`, `.less` |
| JSON | `.json` |
| YAML | `.yaml`, `.yml` |
| Bash | `.sh`, `.bash`, `.zsh` |
| Markdown | `.md`, `.mdx` |

## How It Works

1. **Parsing** - Uses tree-sitter to parse code into AST
2. **Chunking** - Splits code at semantic boundaries (functions, classes)
3. **Embedding** - Generates vector embeddings for each chunk
4. **Graph** - Builds symbol table and call graph
5. **Search** - Hybrid search: vector similarity + BM25 + graph traversal
6. **Context** - Assembles intelligent context with dependencies

## License

MIT
