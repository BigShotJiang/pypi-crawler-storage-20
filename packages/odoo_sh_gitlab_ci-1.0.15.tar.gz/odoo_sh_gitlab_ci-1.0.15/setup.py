from pathlib import Path
from setuptools import setup, find_packages

BASE_DIR = Path(__file__).parent

README = (BASE_DIR / "README.md").read_text(encoding="utf-8")

setup(
    name="odoo_sh_gitlab_ci",
    version="1.0.15",
    description="Simplify and automate Odoo.sh deployment using GitLab and GitHub.",
    long_description=README,
    long_description_content_type="text/markdown",
    author="Jarsa",
    author_email="info@jarsa.com",
    url="https://git.jarsa.com/Jarsa/odoo-sh-gitlab-ci",
    packages=find_packages(exclude=("tests*",)),
    include_package_data=True,
    python_requires=">=3.9",
    entry_points={
        "console_scripts": [
            "odoo_sh_deploy=odoo_sh_gitlab_ci.deploy:main",
        ],
    },
    license="AGPL-3.0-only",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3 :: Only",
        "License :: OSI Approved :: GNU Affero General Public License v3",
        "Operating System :: OS Independent",
    ],
)
