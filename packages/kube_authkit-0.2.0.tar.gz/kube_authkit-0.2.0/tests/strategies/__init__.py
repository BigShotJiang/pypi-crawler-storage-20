"""Tests for authentication strategies."""
