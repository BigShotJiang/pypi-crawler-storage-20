from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("scalefree")
except PackageNotFoundError:
    __version__ = "0.0.0"

from .vmoments import vprofile, ScaleFreeRunner, ScaleFreeResult

__all__ = ["vprofile", "ScaleFreeRunner", "ScaleFreeResult", "__version__"]
