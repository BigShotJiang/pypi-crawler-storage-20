"""Tests for TerryAnn Core."""
