.. _spkg_bzip2:

bzip2: High-quality data compressor
===================================

Description
-----------

bzip2 is a freely available, patent free, high-quality data compressor.

It typically compresses files to within 10% to 15% of the best available
techniques (the PPM family of statistical compressors), whilst being
around twice as fast at compression and six times faster at
decompression.

License
-------

BSD-style


Upstream Contact
----------------

-  Website http://bzip.org/
-  Author: Julian Seward <julian@bzip.org>

Special Update/Build Instructions
---------------------------------

This package must not be bzip2 compressed, so create it using ::

    tar c bzip2-1.0.6 | gzip --best >bzip2-1.0.6.spkg

The build system has been autotoolized based on a patch by the Suse folk
at
http://ftp.uni-kl.de/pub/linux/suse/people/sbrabec/bzip2/for_downstream/bzip2-1.0.6-autoconfiscated.patch

See patches/autotools and spkg-src for details.


Type
----

standard


Dependencies
------------

- :ref:`spkg_pkgconf`

Version Information
-------------------

package-version.txt::

    1.0.6-20150304.p0

See https://repology.org/project/bzip2/versions

Installation commands
---------------------

.. tab:: Sage distribution:

   .. CODE-BLOCK:: bash

       $ sage -i bzip2

.. tab:: Alpine:

   .. CODE-BLOCK:: bash

       $ apk add bzip2

.. tab:: conda-forge:

   .. CODE-BLOCK:: bash

       $ conda install bzip2

.. tab:: Debian/Ubuntu:

   .. CODE-BLOCK:: bash

       $ sudo apt-get install libbz2-dev bzip2

.. tab:: Fedora/Redhat/CentOS:

   .. CODE-BLOCK:: bash

       $ sudo dnf install bzip2 bzip2-devel

.. tab:: Homebrew:

   .. CODE-BLOCK:: bash

       $ brew install bzip2

.. tab:: mingw-w64:

   .. CODE-BLOCK:: bash

       $ sudo pacman -S ${MINGW_PACKAGE_PREFIX}-bzip2

.. tab:: openSUSE:

   .. CODE-BLOCK:: bash

       $ sudo zypper install bzip2 pkgconfig\(bzip2\)

.. tab:: Slackware:

   .. CODE-BLOCK:: bash

       $ sudo slackpkg install bzip2

.. tab:: Void Linux:

   .. CODE-BLOCK:: bash

       $ sudo xbps-install bzip2-devel


If the system package is installed, ``./configure`` will check if it can be used.
