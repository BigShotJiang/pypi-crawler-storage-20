import{b as e,r as o}from"./Dmjk6UaI.js";function t(...r){return e+o(r[0],r[1])}export{t as r};
