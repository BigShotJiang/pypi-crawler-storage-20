class InvalidSolutionFolderError(Exception):
    pass
