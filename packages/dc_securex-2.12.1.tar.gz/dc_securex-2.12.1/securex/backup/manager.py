"""
Complete backup and restoration manager.
Extracted from cogs/antinuke.py backup logic.
"""
import discord
import json
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, List, Union
from ..models import BackupInfo, RestoreResult


class BackupManager:
    """Manages server backups and restoration"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_dir = sdk.backup_dir
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # In-memory backup cache for instant restoration
        self._channel_cache: Dict[int, Dict] = {}  # {guild_id: channel_backup_data}
        self._role_cache: Dict[int, Dict] = {}     # {guild_id: role_backup_data}
        self._cache_loaded = False
        self._refresh_task = None
        self._guild_locks: Dict[int, asyncio.Lock] = {}

    def _get_guild_lock(self, guild_id: int) -> asyncio.Lock:
        """Get or create an async lock for a specific guild"""
        if guild_id not in self._guild_locks:
            self._guild_locks[guild_id] = asyncio.Lock()
        return self._guild_locks[guild_id]
    
    async def create_backup(self, guild_id: int) -> BackupInfo:
        """Create complete backup for a guild"""
        try:
            guild = self.bot.get_guild(guild_id)
            if not guild:
                return BackupInfo(
                    guild_id=guild_id,
                    timestamp=datetime.utcnow(),
                    channel_count=0,
                    role_count=0,
                    backup_path="",
                    success=False
                )
            
            # Backup channels
            channel_count = await self._backup_channels(guild)
            
            # Backup roles
            role_count = await self._backup_roles(guild)
            
            backup_info = BackupInfo(
                guild_id=guild_id,
                timestamp=datetime.utcnow(),
                channel_count=channel_count,
                role_count=role_count,
                backup_path=str(self.backup_dir),
                success=True
            )
            
            # Update cache after backup
            await self._update_guild_cache(guild_id)
            
            # Trigger callback
            await self.sdk._trigger_callbacks('backup_completed', backup_info)
            
            return backup_info
            
        except Exception as e:
            print(f"Error creating backup: {e}")
            return BackupInfo(
                guild_id=guild_id,
                timestamp=datetime.utcnow(),
                channel_count=0,
                role_count=0,
                backup_path="",
                success=False
            )
    
    async def _backup_channels(self, guild: discord.Guild) -> int:
        """Backup all channels"""
        backup_data = {
            "guild_id": guild.id,
            "timestamp": datetime.utcnow().isoformat(),
            "channels": []
        }
        
        for channel in guild.channels:
            channel_data = {
                "id": channel.id,
                "name": channel.name,
                "type": str(channel.type),
                "position": channel.position,
                "category_id": channel.category.id if channel.category else None,
                "permissions": {}
            }
            
            # Store permissions
            for target, overwrite in channel.overwrites.items():
                target_id = str(target.id)
                channel_data["permissions"][target_id] = {
                    "type": "role" if isinstance(target, discord.Role) else "member",
                    "allow": overwrite.pair()[0].value,
                    "deny": overwrite.pair()[1].value
                }
            
            # Type-specific properties
            if isinstance(channel, discord.TextChannel):
                channel_data["text_properties"] = {
                    "topic": channel.topic,
                    "slowmode_delay": channel.slowmode_delay,
                    "nsfw": channel.nsfw
                }
            elif isinstance(channel, discord.VoiceChannel):
                channel_data["voice_properties"] = {
                    "bitrate": channel.bitrate,
                    "user_limit": channel.user_limit
                }
            elif isinstance(channel, discord.StageChannel):
                channel_data["stage_properties"] = {
                    "bitrate": channel.bitrate
                }
            
            backup_data["channels"].append(channel_data)
        
        # Save to file
        backup_file = self.backup_dir / f"channels_{guild.id}.json"
        with open(backup_file, 'w') as f:
            json.dump(backup_data, f, indent=2)
        
        return len(backup_data["channels"])
    
    async def _backup_roles(self, guild: discord.Guild) -> int:
        """Backup all roles using fetch_roles() for correct ordering"""
        backup_data = {
            "guild_id": guild.id,
            "timestamp": datetime.utcnow().isoformat(),
            "roles": []
        }
        
        
        for role in guild.roles:
            if role.is_default():  # Skip @everyone
                continue
            
            role_data = {
                "id": role.id,
                "name": role.name,
                "permissions": role.permissions.value,
                "color": role.color.value,
                "hoist": role.hoist,
                "mentionable": role.mentionable,
                "position": role.position
            }
            
            backup_data["roles"].append(role_data)
        
        # Save to file
        backup_file = self.backup_dir / f"roles_{guild.id}.json"
        with open(backup_file, 'w') as f:
            json.dump(backup_data, f, indent=2)
        
        return len(backup_data["roles"])
    
    async def restore_category_children(self, guild: discord.Guild, old_category_id: int, new_category: discord.CategoryChannel):
        """
        Restore all child channels that belonged to a category.
        Called after a category is restored to recreate its children.
        
        Args:
            guild: The guild containing the category
            old_category_id: The ID of the deleted category (from backup)
            new_category: The newly created category object (to set as parent)
        """
        try:
            backup_file = self.backup_dir / f"channels_{guild.id}.json"
            if not backup_file.exists():
                print(f"No channel backup found for guild {guild.id}")
                return
            
            with open(backup_file, 'r') as f:
                backup = json.load(f)
            
            # Find all channels that belonged to the OLD category ID
            child_channels = [
                ch for ch in backup["channels"]
                if ch.get("category_id") == old_category_id
            ]
            
            if not child_channels:
                print(f"No child channels found for category {new_category.name} (old ID: {old_category_id})")
                return
            
            # Sort by position to maintain order - Discord will auto-assign positions 0, 1, 2, etc.
            child_channels = sorted(child_channels, key=lambda x: x.get("position", 0))
            
            print(f"Restoring {len(child_channels)} child channels for category: {new_category.name}")
            print(f"   Creating in sorted order (positions: {[ch.get('position') for ch in child_channels]})")
            
            # Recreate each child channel
            for ch_data in child_channels:
                try:
                    # Check if channel already exists
                    existing = guild.get_channel(ch_data["id"])
                    if existing:
                        # Channel exists - check if it's in the right category
                        if existing.category != new_category:
                            # Move it to the restored category
                            await existing.edit(category=new_category, reason="SecureX: Move orphaned channel to restored category")
                            print(f"✅ Moved existing channel to category: {existing.name}")
                        else:
                            print(f"Channel {ch_data['name']} already in correct category, skipping")
                        continue
                    
                    # Determine channel type
                    channel_type_str = ch_data["type"]
                    
                    # Prepare permission overwrites
                    overwrites = {}
                    for target_id, perm_data in ch_data.get("permissions", {}).items():
                        try:
                            target_id = int(target_id)
                            if perm_data["type"] == "role":
                                target = guild.get_role(target_id)
                            else:
                                target = guild.get_member(target_id)
                            
                            if target:
                                overwrites[target] = discord.PermissionOverwrite.from_pair(
                                    discord.Permissions(perm_data["allow"]),
                                    discord.Permissions(perm_data["deny"])
                                )
                        except Exception as e:
                            print(f"Error preparing permissions for {target_id}: {e}")
                    
                    # Create channel based on type (WITHOUT position parameter - let Discord auto-assign)
                    new_channel = None
                    
                    if "text" in channel_type_str.lower():
                        # Text channel
                        props = ch_data.get("text_properties", {})
                        new_channel = await guild.create_text_channel(
                            name=ch_data["name"],
                            category=new_category,
                            topic=props.get("topic"),
                            slowmode_delay=props.get("slowmode_delay", 0),
                            nsfw=props.get("nsfw", False),
                            overwrites=overwrites,
                            reason="SecureX: Restore category child"
                        )
                    
                    elif "voice" in channel_type_str.lower():
                        # Voice channel
                        props = ch_data.get("voice_properties", {})
                        new_channel = await guild.create_voice_channel(
                            name=ch_data["name"],
                            category=new_category,
                            bitrate=props.get("bitrate", 64000),
                            user_limit=props.get("user_limit", 0),
                            overwrites=overwrites,
                            reason="SecureX: Restore category child"
                        )
                    
                    elif "stage" in channel_type_str.lower():
                        # Stage channel
                        props = ch_data.get("stage_properties", {})
                        new_channel = await guild.create_stage_channel(
                            name=ch_data["name"],
                            category=new_category,
                            overwrites=overwrites,
                            reason="SecureX: Restore category child"
                        )
                    
                    if new_channel:
                        print(f"✅ Restored child channel: {new_channel.name} (auto-position: {new_channel.position})")
                    
                    # Small delay to avoid rate limits
                    await asyncio.sleep(0.3)
                    
                except Exception as e:
                    print(f"Error restoring child channel {ch_data.get('name')}: {e}")
            
            print(f"✅ Finished restoring children for category: {new_category.name}")
            
        except Exception as e:
            print(f"Error in restore_category_children: {e}")
 
    def start_auto_backup(self, interval_minutes: int = 30):
        """Start automatic backup task"""
        async def auto_backup_task():
            await self.bot.wait_until_ready()
            while not self.bot.is_closed():
                try:
                    # Backup all guilds
                    for guild in self.bot.guilds:
                        await self.create_backup(guild.id)
                    
                    # Wait for next backup
                    await asyncio.sleep(interval_minutes * 60)
                except Exception as e:
                    print(f"Error in auto backup: {e}")
                    await asyncio.sleep(60)  # Wait 1 min on error
        
        # Start background task
        self.bot.loop.create_task(auto_backup_task())

    #restore category children

    async def restore_channel(self, guild: discord.Guild, channel: discord.abc.GuildChannel) -> bool:
        """Restore a deleted channel from backup"""
        try:
            print(f"🛠️ [Debug] Attempting to restore channel: {channel.name} ({channel.id})")
            # Get backup from cache (instant) or fallback to file
            backup = self._channel_cache.get(guild.id)
            if not backup:
                print(f"📂 [Debug] Cache miss for guild {guild.id}. Loading from file...")
                # Cache miss - load from file and cache it
                backup_file = self.backup_dir / f"channels_{guild.id}.json"
                if not backup_file.exists():
                    print(f"❌ [Debug] Backup file not found: {backup_file}")
                    return False
                
                with open(backup_file, 'r') as f:
                    backup = json.load(f)
                    self._channel_cache[guild.id] = backup  # Cache for next time
            
            # Find channel in backup
            ch_data = None
            channel_index = None
            for i, data in enumerate(backup["channels"]):
                if data["id"] == channel.id:
                    ch_data = data
                    channel_index = i
                    break
            
            if not ch_data:
                print(f"❌ [Debug] Channel ID {channel.id} not found in backup data.")
                return False
            
            print(f"📦 [Debug] Found channel data in backup. Type: {ch_data['type']}")
            
            # Get category
            category = None
            if ch_data.get("category_id"):
                category = guild.get_channel(ch_data["category_id"])
            
            # Recreate channel based on type (without position - will set later)
            new_channel = None
            channel_type = ch_data["type"]
            
            if "text" in channel_type.lower():
                text_props = ch_data.get("text_properties", {})
                new_channel = await guild.create_text_channel(
                    name=ch_data["name"],
                    category=category,
                    topic=text_props.get("topic"),
                    slowmode_delay=text_props.get("slowmode_delay", 0),
                    nsfw=text_props.get("nsfw", False),
                    reason="SecureX: Restoring deleted channel"
                )
            elif "voice" in channel_type.lower():
                voice_props = ch_data.get("voice_properties", {})
                new_channel = await guild.create_voice_channel(
                    name=ch_data["name"],
                    category=category,
                    bitrate=voice_props.get("bitrate", 64000),
                    user_limit=voice_props.get("user_limit", 0),
                    reason="SecureX: Restoring deleted channel"
                )
            elif "category" in channel_type.lower():
                new_channel = await guild.create_category(
                    name=ch_data["name"],
                    reason="SecureX: Restoring deleted category"
                )
            elif "stage" in channel_type.lower():
                stage_props = ch_data.get("stage_properties", {})
                new_channel = await guild.create_stage_channel(
                    name=ch_data["name"],
                    category=category,
                    bitrate=stage_props.get("bitrate", 64000),
                    reason="SecureX: Restoring deleted channel"
                )
            
            if not new_channel:
                return False
            
            # Set position from backup
            target_position = ch_data.get("order_index", ch_data["position"])
            
            # Set position
            try:
                await new_channel.edit(position=target_position)
                print(f"✅ Restored channel: {new_channel.name} ({channel_type}) at order_index {target_position}")
            except discord.Forbidden:
                print(f"⚠️ Cannot set position for {new_channel.name}")
            except Exception as e:
                print(f"⚠️ Failed to set position for {new_channel.name}: {e}")
            
            # Restore permissions
            if ch_data.get("permissions"):
                for target_id, perm_data in ch_data["permissions"].items():
                    try:
                        target_id = int(target_id)
                        target = guild.get_role(target_id) if perm_data["type"] == "role" else guild.get_member(target_id)
                        
                        if target:
                            overwrite = discord.PermissionOverwrite.from_pair(
                                discord.Permissions(perm_data["allow"]),
                                discord.Permissions(perm_data["deny"])
                            )
                            await new_channel.set_permissions(target, overwrite=overwrite)
                    except Exception as e:
                        print(f"Error restoring permission: {e}")
            
            # UPDATE CACHE: Replace old ID with new ID so next deletion works
            if guild.id in self._channel_cache and channel_index is not None:
                self._channel_cache[guild.id]["channels"][channel_index]["id"] = new_channel.id
                
                # Persist to file so cache reload doesn't lose the new ID
                backup_file = self.backup_dir / f"channels_{guild.id}.json"
                with open(backup_file, 'w') as f:
                    json.dump(self._channel_cache[guild.id], f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Error restoring channel: {e}")
            return False
    
    async def restore_channel_permissions(self, guild: discord.Guild, channel_id: int) -> bool:
        """Restore channel permissions from backup"""
        try:
            backup_file = self.backup_dir / f"channels_{guild.id}.json"
            if not backup_file.exists():
                return False
            
            with open(backup_file, 'r') as f:
                backup = json.load(f)
            
            # Find channel
            ch_data = None
            for data in backup["channels"]:
                if data["id"] == channel_id:
                    ch_data = data
                    break
            
            if not ch_data:
                return False
            
            channel = guild.get_channel(channel_id)
            if not channel:
                return False
            
            # Restore permissions
            if ch_data.get("permissions"):
                for target_id, perm_data in ch_data["permissions"].items():
                    try:
                        target_id = int(target_id)
                        target = guild.get_role(target_id) if perm_data["type"] == "role" else guild.get_member(target_id)
                        
                        if target:
                            overwrite = discord.PermissionOverwrite.from_pair(
                                discord.Permissions(perm_data["allow"]),
                                discord.Permissions(perm_data["deny"])
                            )
                            await channel.set_permissions(target, overwrite=overwrite)
                    except Exception:
                        pass
            
            return True
            
        except Exception as e:
            print(f"Error restoring channel permissions: {e}")
            return False
    
    async def restore_role(self, guild: discord.Guild, role_id: int) -> bool:
        """Restore a deleted role from backup"""
        try:
            # Get backup from cache (instant) or fallback to file
            backup = self._role_cache.get(guild.id)
            if not backup:
                # Cache miss - load from file and cache it
                backup_file = self.backup_dir / f"roles_{guild.id}.json"
                if not backup_file.exists():
                    return False
                
                with open(backup_file, 'r') as f:
                    backup = json.load(f)
                    self._role_cache[guild.id] = backup  # Cache for next time
            
            # Find role in backup and get its order_index
            target_role_data = None
            role_index = None
            for i, role_data in enumerate(backup["roles"]):
                if role_data["id"] == role_id:
                    target_role_data = role_data
                    role_index = i
                    break
            
            if not target_role_data:
                return False
                
            # Recreate role
            new_role = await guild.create_role(
                name=target_role_data["name"],
                permissions=discord.Permissions(target_role_data["permissions"]),
                color=discord.Color(target_role_data["color"]),
                hoist=target_role_data["hoist"],
                mentionable=target_role_data["mentionable"],
                reason="SecureX: Restoring deleted role"
            )
            
            # Set position directly from backup
            try:
                await guild.edit_role_positions(positions={new_role: target_role_data["position"]})
                print(f"✅ Restored role: {new_role.name} at position {target_role_data['position']}")
            except discord.Forbidden:
                print(f"⚠️ Cannot set position for {new_role.name} - bot hierarchy too low")
            except Exception as e:
                print(f"⚠️ Failed to set position for {new_role.name}: {e}")
            
            # UPDATE CACHE: Replace old ID with new ID so next deletion works
            if guild.id in self._role_cache and role_index is not None:
                # Update the role data in cache with new ID
                self._role_cache[guild.id]["roles"][role_index]["id"] = new_role.id
                
                # Persist to file so cache reload doesn't lose the new ID
                backup_file = self.backup_dir / f"roles_{guild.id}.json"
                with open(backup_file, 'w') as f:
                    json.dump(self._role_cache[guild.id], f, indent=2)
            
            return True
            
            return False
            
        except Exception as e:
            print(f"Error restoring role: {e}")
            return False
    
    async def restore_role_permissions(self, guild: discord.Guild, role_id: int) -> bool:
        """Restore role permissions from backup"""
        try:
            backup_file = self.backup_dir / f"roles_{guild.id}.json"
            if not backup_file.exists():
                return False
            
            with open(backup_file, 'r') as f:
                backup = json.load(f)
            
            # Find role
            for role_data in backup["roles"]:
                if role_data["id"] == role_id:
                    role = guild.get_role(role_id)
                    if not role:
                        return False
                    
                    # Restore permissions and position
                    await role.edit(
                        permissions=discord.Permissions(role_data["permissions"]),
                        position=role_data["position"],
                        reason="SecureX: Restoring role permissions"
                    )
                    
                    return True
            
            return False
            
        except Exception as e:
            print(f"Error restoring role permissions: {e}")
            return False
    
    async def restore_category_children(self, guild: discord.Guild, old_category_id: int, new_category: discord.CategoryChannel):
        """
        Restore all child channels that belonged to a category.
        Called after a category is restored to recreate its children.
        
        Args:
            guild: The guild containing the category
            old_category_id: The ID of the deleted category (from backup)
            new_category: The newly created category object (to set as parent)
        """
        try:
            backup_file = self.backup_dir / f"channels_{guild.id}.json"
            if not backup_file.exists():
                print(f"No channel backup found for guild {guild.id}")
                return
            
            with open(backup_file, 'r') as f:
                backup = json.load(f)
            
            # Find all channels that belonged to the OLD category ID
            child_channels = [
                ch for ch in backup["channels"]
                if ch.get("category_id") == old_category_id
            ]
            
            if not child_channels:
                print(f"No child channels found for category {new_category.name} (old ID: {old_category_id})")
                return
            
            # Sort by position to maintain order - Discord will auto-assign positions 0, 1, 2, etc.
            child_channels = sorted(child_channels, key=lambda x: x.get("position", 0))
            
            print(f"Restoring {len(child_channels)} child channels for category: {new_category.name}")
            print(f"   Creating in sorted order (positions: {[ch.get('position') for ch in child_channels]})")
            
            # Recreate each child channel
            for ch_data in child_channels:
                try:
                    # Check if channel already exists
                    existing = guild.get_channel(ch_data["id"])
                    if existing:
                        # Channel exists - check if it's in the right category
                        if existing.category != new_category:
                            # Move it to the restored category
                            await existing.edit(category=new_category, reason="SecureX: Move orphaned channel to restored category")
                            print(f"✅ Moved existing channel to category: {existing.name}")
                        else:
                            print(f"Channel {ch_data['name']} already in correct category, skipping")
                        continue
                    
                    # Determine channel type
                    channel_type_str = ch_data["type"]
                    
                    # Prepare permission overwrites
                    overwrites = {}
                    for target_id, perm_data in ch_data.get("permissions", {}).items():
                        try:
                            target_id = int(target_id)
                            if perm_data["type"] == "role":
                                target = guild.get_role(target_id)
                            else:
                                target = guild.get_member(target_id)
                            
                            if target:
                                overwrites[target] = discord.PermissionOverwrite.from_pair(
                                    discord.Permissions(perm_data["allow"]),
                                    discord.Permissions(perm_data["deny"])
                                )
                        except Exception as e:
                            print(f"Error preparing permissions for {target_id}: {e}")
                    
                    # Create channel based on type (WITHOUT position parameter - let Discord auto-assign)
                    new_channel = None
                    
                    if "text" in channel_type_str.lower():
                        # Text channel
                        props = ch_data.get("text_properties", {})
                        new_channel = await guild.create_text_channel(
                            name=ch_data["name"],
                            category=new_category,
                            topic=props.get("topic"),
                            slowmode_delay=props.get("slowmode_delay", 0),
                            nsfw=props.get("nsfw", False),
                            overwrites=overwrites,
                            reason="SecureX: Restore category child"
                        )
                    
                    elif "voice" in channel_type_str.lower():
                        # Voice channel
                        props = ch_data.get("voice_properties", {})
                        new_channel = await guild.create_voice_channel(
                            name=ch_data["name"],
                            category=new_category,
                            bitrate=props.get("bitrate", 64000),
                            user_limit=props.get("user_limit", 0),
                            overwrites=overwrites,
                            reason="SecureX: Restore category child"
                        )
                    
                    elif "stage" in channel_type_str.lower():
                        # Stage channel
                        props = ch_data.get("stage_properties", {})
                        new_channel = await guild.create_stage_channel(
                            name=ch_data["name"],
                            category=new_category,
                            overwrites=overwrites,
                            reason="SecureX: Restore category child"
                        )
                    
                    if new_channel:
                        print(f"✅ Restored child channel: {new_channel.name} (auto-position: {new_channel.position})")
                    
                    # Small delay to avoid rate limits
                    await asyncio.sleep(0.3)
                    
                except Exception as e:
                    print(f"Error restoring child channel {ch_data.get('name')}: {e}")
            
            print(f"✅ Finished restoring children for category: {new_category.name}")
            
        except Exception as e:
            print(f"Error in restore_category_children: {e}")
  


    # Cache Management Methods
    
    async def preload_all(self):
        """
        Preload ALL backups into memory on startup.
        Call this in enable() to warm the cache.
        """
        if self._cache_loaded:
            return
        
        print("🔄 Preloading backups into cache...")
        channel_count = 0
        role_count = 0
        
        # Load all channel backups
        for file_path in self.backup_dir.glob("channels_*.json"):
            try:
                guild_id = int(file_path.stem.replace("channels_", ""))
                with open(file_path, 'r') as f:
                    self._channel_cache[guild_id] = json.load(f)
                channel_count += 1
            except Exception as e:
                print(f"Error loading channel backup {file_path}: {e}")
        
        # Load all role backups
        for file_path in self.backup_dir.glob("roles_*.json"):
            try:
                guild_id = int(file_path.stem.replace("roles_", ""))
                with open(file_path, 'r') as f:
                    self._role_cache[guild_id] = json.load(f)
                role_count += 1
            except Exception as e:
                print(f"Error loading role backup {file_path}: {e}")
        
        self._cache_loaded = True
        print(f"✅ Cached {channel_count} channel backups and {role_count} role backups")
    
    async def _update_guild_cache(self, guild_id: int):
        """Update cache for a specific guild after backup"""
        try:
            # Load channel backup into cache
            channel_file = self.backup_dir / f"channels_{guild_id}.json"
            if channel_file.exists():
                with open(channel_file, 'r') as f:
                    self._channel_cache[guild_id] = json.load(f)
            
            # Load role backup into cache
            role_file = self.backup_dir / f"roles_{guild_id}.json"
            if role_file.exists():
                with open(role_file, 'r') as f:
                    self._role_cache[guild_id] = json.load(f)
        except Exception as e:
            print(f"Error updating cache for guild {guild_id}: {e}")
    
        """Start background task to refresh cache every 10 minutes"""
        if self._refresh_task is None:
            self._refresh_task = asyncio.create_task(self._auto_refresh_loop())
            print("🔄 Started backup cache auto-refresh (every 10 minutes)")
    
    async def _auto_refresh_loop(self):
        """Background task: refresh cache every 10 minutes"""
        while True:
            try:
                await asyncio.sleep(600)  # 10 minutes
                
                print("🔄 Refreshing backup cache...")
                
                # Refresh cache for all guilds
                for guild in self.bot.guilds:
                    await self._update_guild_cache(guild.id)
                    await asyncio.sleep(0.1)  # Small delay between guilds
                
                print("✅ Backup cache refreshed")
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error in auto-refresh loop: {e}")
    
    def start_auto_refresh(self):
        """Start background cache refresh task"""
        if self._refresh_task is None or self._refresh_task.done():
            self._refresh_task = asyncio.create_task(self._auto_refresh_loop())
    
    def stop_auto_refresh(self):
        """Stop the auto-refresh task"""
        if self._refresh_task:
            self._refresh_task.cancel()
            self._refresh_task = None
            print("⏹️ Stopped backup cache auto-refresh")
