"""Checker implementations for sentinel."""
