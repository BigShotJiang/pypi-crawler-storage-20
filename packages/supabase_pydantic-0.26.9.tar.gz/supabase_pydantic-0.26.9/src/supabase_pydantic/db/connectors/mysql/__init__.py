"""MySQL connector package."""
