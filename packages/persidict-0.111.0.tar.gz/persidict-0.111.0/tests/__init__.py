"""Test package for persidict."""
