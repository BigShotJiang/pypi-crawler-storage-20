"""
Channel protection handler for SecureX SDK.
"""
import discord
import asyncio
from datetime import datetime, timedelta
from ..models import ThreatEvent


class ChannelHandler:
    """Handles channel protection logic"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.backup_manager = sdk.backup_manager
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized (owner or whitelisted)"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True  # Bot is always authorized
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_channel_create(self, channel: discord.abc.GuildChannel):
        """Delete unauthorized channel creations (punishment handled by audit log worker)"""
        try:
            guild = channel.guild
            await asyncio.sleep(0.5)
            
            # Check audit log for this specific channel creation
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_create):
                if entry.target.id == channel.id:
                    # Check if authorized
                    if not await self._is_authorized(guild, entry.user.id):
                        print(f"🗑️ Deleting unauthorized channel: #{channel.name}")
                        
                        # Delete the spam channel only
                        try:
                            await channel.delete(reason="SecureX: Cleanup")
                            print(f"✅ Deleted channel: #{channel.name}")
                        except discord.errors.NotFound:
                            pass
                        except Exception as e:
                            print(f"Error deleting channel: {e}")
                    break
                    
        except Exception as e:
            print(f"Error in channel_create handler: {e}")

    
    async def on_channel_delete(self, channel: discord.abc.GuildChannel):
        """Detect and restore unauthorized channel deletion"""
        try:
            guild = channel.guild
            await asyncio.sleep(1)
            
            async for entry in guild.audit_logs(limit=1, action=discord.AuditLogAction.channel_delete):
                if entry.target.id == channel.id:
                    if not await self._is_authorized(guild, entry.user.id):
                        print(f"🔄 Restoring deleted channel: {channel.name}")
                        
                        # Restore the channel
                        new_channel = await self.backup_manager.restore_channel(guild, channel)
                        
                        if new_channel:
                            print(f"✅ Restored: {new_channel.name}")
                            
                            # If this was a category, restore its children too
                            if isinstance(channel, discord.CategoryChannel):
                                await self.backup_manager.restore_category_children(
                                    guild, channel.id, new_channel.id
                                )
                    break
        except Exception as e:
            print(f"Error in channel_delete handler: {e}")
    
    async def on_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel):
        """Detect unauthorized channel updates"""
        try:
            # Only check permission or position changes
            if (before.overwrites == after.overwrites and 
                before.position == after.position):
                return
            
            guild = after.guild
            await asyncio.sleep(0.5)
            
            async for entry in guild.audit_logs(limit=3, oldest_first=False):
                if entry.action == discord.AuditLogAction.channel_update:
                    if entry.target and entry.target.id == after.id:
                        # Check if changes were unauthorized 
                        if not await self._is_authorized(guild, entry.user.id):
                            # Restore channel permissions
                            restored = await self.backup_manager.restore_channel_permissions(guild, after.id)
                            
                            # Create threat event
                            threat = ThreatEvent(
                                type="channel_update",
                                guild_id=guild.id,
                                actor_id=entry.user.id,
                                target_id=after.id,
                                target_name=after.name,
                                prevented=True,
                                restored=restored,
                                details={"changed": "permissions/position"}
                            )
                            
                            # Trigger callback
                            await self.sdk._trigger_callbacks('threat_detected', threat)
                        break
        except Exception as e:
            print(f"Error in channel_update handler: {e}")
