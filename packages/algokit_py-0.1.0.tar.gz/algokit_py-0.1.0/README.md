# algokit-py

A lightweight Python algorithms library with clean, well-documented implementations.

## Features
- Linear Search
- Binary Search

## Usage

```python
from algokit_py.search import linear_search, binary_search

print(linear_search([1, 2, 3], 2))
print(binary_search([1, 2, 3], 2))
```


We will improve this later.

---

## STEP 6: Local Install Test (Very Important)

From **project root**:

```powershell
pip install -e .
```

Then test:

```powershell
python -c "from algokit_py.search import binary_search; print(binary_search([1,2,3], 2))"
```

You must see:
```python
1
```