"""
algokit_py - A minimal Python algorithms library
"""

from algokit_py.search import binary_search, linear_search

__version__ = "0.1.0"
__all__ = ["binary_search", "linear_search"]
