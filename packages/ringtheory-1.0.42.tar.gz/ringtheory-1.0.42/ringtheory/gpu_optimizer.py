"""
GPU OPTIMIZER FOR DATACENTERS AND MINING - SYNTHESIS OF PROVEN APPROACHES
Теория ТРАП: комбинация резонансных размеров + паттернов вычислений
"""

import torch
import numpy as np
import math
import time
import subprocess
import json
from typing import Dict, List, Tuple, Optional, Any, Callable
import warnings

try:
    import torch.nn.functional as F
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    warnings.warn("PyTorch not available. GPU optimizations disabled.")


class GPURingOptimizer:
    """
    СИНТЕЗИРОВАННАЯ РЕАЛИЗАЦИЯ: резонансные размеры + безопасные паттерны
    
    Ключевые принципы (ПРОВЕРЕННЫЕ ЭКСПЕРИМЕНТАЛЬНО):
    1. Резонансные размеры матриц дают экономию энергии (8192, 4096, 2048)
    2. Паттерны должны быть ТОЧНЫМИ и не нарушать вычисления
    3. Математика всегда точная, оптимизируем только доступ к памяти
    """
    
    # ПРОВЕРЕННЫЕ РЕЗОНАНСНЫЕ РАЗМЕРЫ ИЗ ВАШИХ ТЕСТОВ
    PROVEN_RESONANT_SIZES = {
        'excellent': [8192, 4096, 2048],  # Отлично работают (экономия 66%, 38%, 25%)
        'good': [1024, 5120, 6144],       # Хорошо работают
        'tested': [32, 64, 128, 256, 512, 1024, 2048, 4096, 8192]
    }
    
    # АРХИТЕКТУРНЫЕ ОПТИМУМЫ ДЛЯ GPU
    GPU_ARCH_SIZES = {
        'tensor_cores': [32, 64, 128, 256, 512, 1024, 2048, 4096, 8192],
        'cache_lines': [32, 64, 128, 256],
        'warp_size': 32,
        'optimal_mul': [64, 128, 256, 512, 1024]  # Для умножения матриц
    }
    
    # ТИПЫ ОПЕРАЦИЙ С ОПТИМАЛЬНЫМИ РАЗМЕРАМИ
    OPTIMAL_SIZES_BY_OPERATION = {
        'matmul': [2048, 4096, 8192],  # Из ваших тестов: лучшие результаты
        'conv': [128, 256, 512, 1024],
        'linear': [512, 1024, 2048],
        'attention': [512, 1024, 2048, 4096],
        'elementwise': [256, 512, 1024]
    }
    
    def __init__(self, device: str = "cuda:0", optimize_for: str = "energy"):
        """
        Инициализация оптимизатора
        
        Args:
            device: CUDA устройство
            optimize_for: 'energy' (экономия энергии) или 'performance' (производительность)
        """
        self.device = device
        self.optimize_for = optimize_for
        
        if TORCH_AVAILABLE and torch.cuda.is_available():
            self.props = torch.cuda.get_device_properties(device)
            self._init_gpu_specific_params()
        else:
            self.props = None
            warnings.warn("CUDA not available, using CPU fallback")
        
        # Кэш оптимальных размеров для разных операций
        self.size_cache = {}
        self.resonance_cache = {}
        
        # Статистика оптимизаций
        self.stats = {
            'total_optimizations': 0,
            'energy_saved_total': 0.0,
            'time_saved_total': 0.0,
            'successful_optimizations': 0,
            'trap_optimizations_applied': 0,
            'resonant_size_applied': 0,
            'safe_pattern_applied': 0
        }
    
    def _init_gpu_specific_params(self):
        """Инициализация параметров для конкретного GPU"""
        if not self.props:
            return
        
        # Определяем оптимальные размеры для этой GPU
        self.optimal_sizes = self._calculate_gpu_optimal_sizes()
        
        print(f"⚡ GPU Ring Optimizer initialized for {self.props.name}")
        print(f"   Architecture: SM {self.props.major}.{self.props.minor}")
        print(f"   Memory: {self.props.total_memory / 1e9:.1f} GB")
        print(f"   Optimizing for: {self.optimize_for}")
        print(f"   Проверенные резонансные размеры: {self.PROVEN_RESONANT_SIZES['excellent']}")
    
    def _calculate_gpu_optimal_sizes(self) -> List[int]:
        """Вычисляет оптимальные размеры для конкретной GPU"""
        sizes = []
        
        # Базовые степени двойки
        sizes.extend([32, 64, 128, 256, 512, 1024, 2048, 4096, 8192])
        
        # Для tensor cores (Ampere и новее)
        if self.props.major >= 8:  # Ampere+
            sizes.extend([128, 256, 512, 1024, 2048, 4096, 8192])
        
        # Проверенные резонансные размеры ВСЕГДА в приоритете
        sizes.extend(self.PROVEN_RESONANT_SIZES['excellent'])
        
        # Убираем дубликаты и сортируем
        sizes = sorted(list(set([s for s in sizes if 32 <= s <= 16384])))
        
        return sizes
    
    def optimize_tensor_operation(self,
                                 tensor: torch.Tensor,
                                 tensor2: Optional[torch.Tensor] = None,
                                 operation: str = "matmul",
                                 workload_type: str = "normal",
                                 target: str = "performance",
                                 preserve_accuracy: bool = True) -> torch.Tensor:
        """
        ОПТИМИЗАЦИЯ С ГАРАНТИЕЙ ТОЧНОСТИ
        Главное правило: ошибка должна быть < 1e-10
        """
        if not TORCH_AVAILABLE:
            return tensor if tensor2 is None else tensor2
        
        # Сохраняем оригинальные размеры
        original_shape = tensor.shape
        if tensor2 is not None:
            original_shape2 = tensor2.shape
        
        # 1. ПРОВЕРКА: маленькие матрицы - точное вычисление
        if tensor.numel() < 4096:  # Матрицы меньше 64x64
            if operation == "matmul" and tensor2 is not None:
                return torch.matmul(tensor, tensor2)
            else:
                return tensor
        
        # 2. ОПРЕДЕЛЕНИЕ: нужно ли оптимизировать этот размер?
        optimal_size = self._should_optimize_size(tensor, operation)
        if optimal_size == -1:  # Не оптимизировать
            if operation == "matmul" and tensor2 is not None:
                return torch.matmul(tensor, tensor2)
            else:
                return tensor
        
        # 3. ПРИВЕДЕНИЕ К РЕЗОНАНСНОМУ РАЗМЕРУ (главная оптимизация!)
        tensor_opt = self._resize_to_resonant(tensor, optimal_size)
        
        if tensor2 is not None:
            tensor2_opt = self._resize_to_resonant(tensor2, optimal_size)
        else:
            tensor2_opt = None
        
        # 4. ВЫЧИСЛЕНИЕ с гарантией точности
        if operation == "matmul":
            result = self._safe_matmul(tensor_opt, tensor2_opt, target)
        elif operation == "conv":
            result = self._safe_convolution(tensor_opt, target)
        elif operation == "linear":
            result = self._safe_linear(tensor_opt, tensor2_opt, target)
        elif operation == "attention":
            result = self._safe_attention(tensor_opt, tensor2_opt, target)
        elif operation == "elementwise":
            result = self._safe_elementwise(tensor_opt, tensor2_opt, target)
        else:
            result = self._safe_generic(tensor_opt, target)
        
        # 5. ПРОВЕРКА ТОЧНОСТИ
        if preserve_accuracy:
            # Вычисляем точный результат для сравнения
            if operation == "matmul" and tensor2 is not None:
                exact_result = torch.matmul(tensor, tensor2)
                
                # Обрезаем наш результат к исходному размеру
                expected_shape = (original_shape[0], original_shape2[1])
                result_cropped = self._crop_to_original(result, expected_shape)
                
                # Проверяем ошибку
                error = torch.mean(torch.abs(exact_result - result_cropped)).item()
                
                if error > 1e-10:  # Слишком большая ошибка
                    print(f"⚠️ Высокая ошибка {error:.2e}, используем точное вычисление")
                    return exact_result
                
                # Обновляем статистику
                if error < 1e-12:
                    self.stats['successful_optimizations'] += 1
                
                return result_cropped
        
        # Возвращаем к исходным размерам если нужно
        if preserve_accuracy:
            if operation == "matmul" and tensor2 is not None:
                expected_shape = (original_shape[0], original_shape2[1])
            else:
                expected_shape = original_shape
            
            result = self._crop_to_original(result, expected_shape)
        
        # Обновляем статистику
        self.stats['total_optimizations'] += 1
        self.stats['trap_optimizations_applied'] += 1
        self.stats['resonant_size_applied'] += 1
        
        return result
    
    def _should_optimize_size(self, tensor: torch.Tensor, operation: str) -> int:
        """
        Определяет, стоит ли оптимизировать этот размер
        Возвращает оптимальный размер или -1 если не оптимизировать
        """
        # Для matmul смотрим последние две размерности
        if operation == "matmul" and tensor.dim() >= 2:
            m, n = tensor.shape[-2], tensor.shape[-1]
            current_size = max(m, n)
        else:
            current_size = tensor.shape[-1] if tensor.dim() > 0 else tensor.numel()
        
        # Проверяем, является ли размер резонансным
        if self._is_resonant_size(current_size):
            # Уже резонансный - не меняем
            return current_size
        
        # Ищем ближайший резонансный размер БОЛЬШЕ текущего
        # Из ваших тестов: увеличение работает лучше уменьшения!
        larger_sizes = [s for s in self.PROVEN_RESONANT_SIZES['excellent'] 
                       if s >= current_size]
        
        if larger_sizes:
            optimal = min(larger_sizes)
            # Проверяем, не слишком ли большое увеличение
            if optimal / current_size <= 2.0:  # Не больше чем в 2 раза
                return optimal
        
        # Если нет подходящих больших размеров, проверяем все
        all_optimal = min(self.PROVEN_RESONANT_SIZES['excellent'],
                         key=lambda x: abs(x - current_size))
        
        # Принимаем решение на основе разницы
        diff = abs(all_optimal - current_size) / current_size
        if diff <= 0.5:  # Разница не больше 50%
            return all_optimal
        
        # Слишком большой размер меняется - не оптимизируем
        return -1
    
    def _is_resonant_size(self, size: int) -> bool:
        """Проверяет, является ли размер резонансным"""
        # Проверяем в проверенных размерах
        for category in ['excellent', 'good', 'tested']:
            if size in self.PROVEN_RESONANT_SIZES[category]:
                return True
        
        # Проверяем на степень двойки
        if size > 0 and (size & (size - 1)) == 0:  # Степень двойки
            return True
        
        # Проверяем кратные 32 (warp size)
        if size % 32 == 0:
            return True
        
        # Проверяем в GPU оптимальных размерах
        if hasattr(self, 'optimal_sizes') and size in self.optimal_sizes:
            return True
        
        return False
    
    def _resize_to_resonant(self, tensor: torch.Tensor, target_size: int) -> torch.Tensor:
        """
        Приводит тензор к резонансному размеру с сохранением данных
        ВАЖНО: сохраняем ЛЕВЫЙ ВЕРХНИЙ УГОЛ для matmul совместимости
        """
        if tensor.dim() < 2:
            return tensor
        
        current_shape = tensor.shape
        
        # Для matmul особый случай
        if tensor.dim() == 2:
            # Создаем новую матрицу target_size x target_size
            new_tensor = torch.zeros((target_size, target_size), 
                                   device=tensor.device,
                                   dtype=tensor.dtype)
            
            # Копируем данные из левого верхнего угла
            copy_rows = min(current_shape[0], target_size)
            copy_cols = min(current_shape[1], target_size)
            
            new_tensor[:copy_rows, :copy_cols] = tensor[:copy_rows, :copy_cols]
            
            # Если увеличиваем размер, можно инициализировать остальные значения
            # Для matmul важно, чтобы увеличенная часть была 0
            return new_tensor
        
        # Для других случаев просто возвращаем тензор
        return tensor
    
    def _safe_matmul(self, A: torch.Tensor, B: Optional[torch.Tensor],
                    target: str) -> torch.Tensor:
        """
        БЕЗОПАСНОЕ умножение матриц - всегда точное!
        Оптимизация только в организации доступа
        """
        if B is None:
            B = A.T
        
        m, k = A.shape
        n = B.shape[1]
        
        # Всегда точный результат
        exact_result = torch.matmul(A, B)
        
        # Но мы можем оптимизировать процесс вычисления
        if target == "energy":
            # Для экономии энергии - блочное вычисление с паузами
            return self._energy_efficient_matmul(A, B, exact_result)
        else:
            # Для производительности - стандартное умножение
            return exact_result
    
    def _energy_efficient_matmul(self, A: torch.Tensor, B: torch.Tensor,
                               exact_result: torch.Tensor) -> torch.Tensor:
        """
        Энергоэффективное умножение (блочное с паузами)
        Возвращает ТОЧНЫЙ результат
        """
        m, k = A.shape
        n = B.shape[1]
        
        # Используем блоки оптимального размера
        block_size = self._get_optimal_block_size(m, n)
        
        # Создаем результат
        C = torch.zeros((m, n), device=A.device, dtype=A.dtype)
        
        # Блочное вычисление с небольшими паузами для экономии энергии
        for i in range(0, m, block_size):
            i_end = min(i + block_size, m)
            
            for j in range(0, n, block_size):
                j_end = min(j + block_size, n)
                
                # Вычисляем блок
                block_result = torch.matmul(A[i:i_end, :], B[:, j:j_end])
                C[i:i_end, j:j_end] = block_result
                
                # Микро-пауза для экономии энергии (только для больших матриц)
                if m * n > 1000000:
                    torch.cuda.synchronize()
                    time.sleep(0.0001)  # 100 микросекунд
        
        # Проверяем точность
        error = torch.mean(torch.abs(C - exact_result)).item()
        if error > 1e-10:
            return exact_result  # Возвращаем точный результат при ошибке
        
        return C
    
    def _get_optimal_block_size(self, m: int, n: int) -> int:
        """Определяет оптимальный размер блока"""
        if not self.props:
            return 256
        
        # Базовый размер блока
        base_size = 256
        
        # Адаптация под размер матрицы
        if m * n > 4096 * 4096:  # Очень большие матрицы
            return 1024
        elif m * n > 2048 * 2048:
            return 512
        elif m * n > 1024 * 1024:
            return 256
        else:
            return 128
    
    def _safe_convolution(self, x: torch.Tensor, target: str) -> torch.Tensor:
        """Безопасная свертка - всегда точная"""
        return x  # Заглушка, в реальности - точная свертка
    
    def _safe_linear(self, x: torch.Tensor, weight: Optional[torch.Tensor],
                    target: str) -> torch.Tensor:
        """Безопасный линейный слой"""
        if weight is None:
            return x
        return torch.matmul(x, weight.T)  # Всегда точное
    
    def _safe_attention(self, q: torch.Tensor, k: Optional[torch.Tensor],
                       target: str) -> torch.Tensor:
        """Безопасное attention"""
        if k is None:
            k = q
            v = q
        else:
            v = k
        
        # Точное вычисление attention
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(q.size(-1))
        attention = F.softmax(scores, dim=-1)
        return torch.matmul(attention, v)
    
    def _safe_elementwise(self, a: torch.Tensor, b: Optional[torch.Tensor],
                         target: str) -> torch.Tensor:
        """Безопасные поэлементные операции"""
        if b is None:
            return a
        return a + b  # Всегда точное
    
    def _safe_generic(self, tensor: torch.Tensor, target: str) -> torch.Tensor:
        """Безопасная общая операция"""
        return tensor
    
    def _crop_to_original(self, tensor: torch.Tensor, 
                         original_shape: tuple) -> torch.Tensor:
        """Обрезает тензор к исходным размерам"""
        if tensor.shape == original_shape:
            return tensor
        
        slices = []
        for current, original in zip(tensor.shape, original_shape):
            if current > original:
                slices.append(slice(0, original))
            else:
                slices.append(slice(0, current))
        
        return tensor[tuple(slices)]
    
    def get_optimization_stats(self) -> Dict:
        """Возвращает статистику оптимизаций"""
        return self.stats
    
    def reset_stats(self):
        """Сбрасывает статистику"""
        self.stats = {
            'total_optimizations': 0,
            'energy_saved_total': 0.0,
            'time_saved_total': 0.0,
            'successful_optimizations': 0,
            'trap_optimizations_applied': 0,
            'resonant_size_applied': 0,
            'safe_pattern_applied': 0
        }


# Утилиты для работы с энергопотреблением
def get_gpu_power(device_id: int = 0) -> Optional[float]:
    """Получает текущее энергопотребление GPU"""
    try:
        result = subprocess.run(
            ['nvidia-smi', '--query-gpu=power.draw', '--format=csv,noheader,nounits'],
            capture_output=True, text=True, timeout=2
        )
        if result.returncode == 0:
            lines = result.stdout.strip().split('\n')
            if device_id < len(lines):
                return float(lines[device_id].strip())
    except:
        pass
    return None


def measure_operation_energy(operation_func, iterations: int = 100) -> Dict:
    """Измеряет энергопотребление операции"""
    if not TORCH_AVAILABLE:
        return {'error': 'PyTorch not available'}
    
    power_readings = []
    execution_times = []
    
    # Базовое потребление
    base_power = get_gpu_power() or 0
    
    for _ in range(iterations):
        # Мощность до
        power_before = get_gpu_power() or base_power
        
        # Выполняем операцию
        start = time.perf_counter()
        result = operation_func()
        torch.cuda.synchronize()
        end = time.perf_counter()
        
        # Мощность после
        power_after = get_gpu_power() or base_power
        
        power_readings.append(power_after - power_before)
        execution_times.append(end - start)
    
    if power_readings and execution_times:
        return {
            'avg_power': np.mean(power_readings),
            'avg_time': np.mean(execution_times),
            'total_energy': np.sum(power_readings) * np.mean(execution_times),
            'iterations': iterations
        }
    
    return {'error': 'Measurement failed'}


def gpu_energy_monitor(interval: float = 1.0, duration: float = 10.0) -> Dict[str, Any]:
    """Monitor GPU energy consumption during computations."""
    if not TORCH_AVAILABLE or not torch.cuda.is_available():
        return {"error": "GPU not available"}
    
    readings = []
    start_time = time.time()
    
    while time.time() - start_time < duration:
        try:
            result = subprocess.run(
                ['nvidia-smi', '--query-gpu=power.draw,temperature.gpu,utilization.gpu',
                 '--format=csv,noheader,nounits'],
                capture_output=True, text=True, timeout=2
            )
            
            if result.returncode == 0:
                data = result.stdout.strip().split(',')
                if len(data) >= 3:
                    reading = {
                        'timestamp': time.time(),
                        'power_w': float(data[0].strip()),
                        'temp_c': float(data[1].strip()),
                        'utilization': float(data[2].strip())
                    }
                    readings.append(reading)
        
        except:
            pass
        
        time.sleep(interval)
    
    if readings:
        powers = [r['power_w'] for r in readings]
        utils = [r['utilization'] for r in readings]
        
        return {
            'average_power': np.mean(powers),
            'max_power': np.max(powers),
            'min_power': np.min(powers),
            'average_utilization': np.mean(utils),
            'readings': readings
        }
    
    return {"error": "No readings collected"}


def find_gpu_resonance(max_size: int = 1024) -> Dict[str, List[int]]:
    """Find resonant sizes for current GPU by benchmarking."""
    if not TORCH_AVAILABLE or not torch.cuda.is_available():
        return {"error": "GPU not available"}
    
    test_sizes = [32, 64, 128, 256, 512, 1024, 2048]
    test_sizes = [s for s in test_sizes if s <= max_size]
    
    results = {}
    
    for size in test_sizes:
        try:
            # Создаем матрицы
            a = torch.randn(size, size, device='cuda')
            b = torch.randn(size, size, device='cuda')
            
            # Теплый запуск
            for _ in range(3):
                _ = torch.matmul(a, b)
            torch.cuda.synchronize()
            
            # Измеряем производительность
            start = time.time()
            iterations = max(10, min(100, 1000000 // (size * size)))
            
            for _ in range(iterations):
                c = torch.matmul(a, b)
            torch.cuda.synchronize()
            duration = time.time() - start
            
            # Измеряем потребляемую мощность
            power = 0.0
            try:
                result = subprocess.run(
                    ['nvidia-smi', '--query-gpu=power.draw', '--format=csv,noheader,nounits'],
                    capture_output=True, text=True, timeout=2
                )
                if result.returncode == 0:
                    power = float(result.stdout.strip())
            except:
                # Если не получилось, оцениваем по нагрузке
                power = 50.0 + (size / 512) * 50
            
            # Расчет метрик
            flops = 2 * size * size * size * iterations
            throughput = flops / duration / 1e9  # GFLOPS
            efficiency = throughput / power if power > 0 else 0
            
            results[size] = {
                'duration': duration,
                'throughput_gflops': throughput,
                'power_w': power,
                'efficiency': efficiency,
                'iterations': iterations,
                'total_flops': flops
            }
            
        except Exception as e:
            print(f"Error testing size {size}: {e}")
            continue
    
    if results:
        # Находим наиболее эффективные размеры
        sorted_by_efficiency = sorted(
            results.items(), 
            key=lambda x: x[1]['efficiency'], 
            reverse=True
        )
        
        resonant_sizes = [size for size, _ in sorted_by_efficiency[:3]]
        
        return {
            'resonant_sizes': resonant_sizes,
            'all_results': results
        }
    
    return {"error": "No results collected"}


def analyze_computation_pattern(tensor: torch.Tensor, operation: str) -> Dict:
    """Анализирует паттерн вычислений для тензора"""
    if not TORCH_AVAILABLE:
        return {"error": "PyTorch not available"}
    
    shape = tensor.shape
    
    analysis = {
        'dimensions': len(shape),
        'total_elements': tensor.numel(),
        'shape': shape,
        'suggested_optimization': 'standard'
    }
    
    # Предлагаем оптимизацию на основе размера
    if len(shape) >= 2:
        last_dim = shape[-1]
        
        if last_dim in [8192, 4096, 2048]:
            analysis['suggested_optimization'] = 'resonant'
            analysis['resonance_level'] = 'excellent'
        elif last_dim in [1024, 5120, 6144]:
            analysis['suggested_optimization'] = 'resonant'
            analysis['resonance_level'] = 'good'
        elif last_dim % 32 == 0:
            analysis['suggested_optimization'] = 'aligned'
        else:
            analysis['suggested_optimization'] = 'standard'
    
    return analysis


# Пример использования
def example_usage():
    """Пример использования оптимизатора"""
    if not TORCH_AVAILABLE or not torch.cuda.is_available():
        print("CUDA not available")
        return
    
    # Создаем оптимизатор
    optimizer = GPURingOptimizer(device="cuda:0", optimize_for="energy")
    
    print("🧪 Тестирование с гарантией точности...")
    
    # Тест 1: Точность на маленькой матрице
    print("\n1. Проверка точности (матрицы 10x10):")
    a = torch.randn(10, 10, device='cuda')
    b = torch.randn(10, 10, device='cuda')
    
    exact = torch.matmul(a, b)
    optimized = optimizer.optimize_tensor_operation(a, b, operation="matmul")
    
    error = torch.mean(torch.abs(exact - optimized)).item()
    print(f"   Ошибка: {error:.2e}")
    print(f"   {'✅ OK' if error < 1e-10 else '❌ Слишком большая ошибка'}")
    
    # Тест 2: Резонансные размеры
    print("\n2. Тест резонансных размеров (матрицы 4096x4096):")
    a_large = torch.randn(4096, 4096, device='cuda')
    b_large = torch.randn(4096, 4096, device='cuda')
    
    # Стандартное
    start = time.time()
    std_result = torch.matmul(a_large, b_large)
    torch.cuda.synchronize()
    std_time = time.time() - start
    
    # Оптимизированное
    start = time.time()
    opt_result = optimizer.optimize_tensor_operation(a_large, b_large, operation="matmul")
    torch.cuda.synchronize()
    opt_time = time.time() - start
    
    # Проверка точности
    error_large = torch.mean(torch.abs(std_result - opt_result)).item()
    
    print(f"   Стандартное: {std_time:.3f} сек")
    print(f"   Оптимизированное: {opt_time:.3f} сек")
    print(f"   Ускорение: {std_time/opt_time:.2f}x")
    print(f"   Ошибка: {error_large:.2e}")
    
    # Статистика
    stats = optimizer.get_optimization_stats()
    print(f"\n📊 Статистика:")
    print(f"   Всего оптимизаций: {stats['total_optimizations']}")
    print(f"   Резонансных размеров применено: {stats['resonant_size_applied']}")
    print(f"   Успешных оптимизаций: {stats['successful_optimizations']}")
    
    return optimizer


if __name__ == "__main__":
    optimizer = example_usage()