# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 0.5.0 - 2026-01-16

### Added

- `Cite2Urn` class to represent and manipulate CITE2 URNs.
- Methods for parsing, validating, and formatting CITE2 URNs.
- Unit tests for all functionalities of the `Cite2Urn` class.

## 0.4.1 - 2026-01-15

Addresses a gap in validation logic for instantiating the `CtsUrn` class.

### Fixed

- Added validation to ensure that neither `exemplar` nor `version` can be set when higher elements of the work hierarchy are `None`.

## 0.4.0 - 2026-01-15

Non-breaking additions to the `CtsUrn` class.

### Added

- `drop_passage` method to create a new `CtsUrn` without the passage component.
- `set_passage` method to create a new `CtsUrn` with a specified passage component.
- `drop_version` method to create a new `CtsUrn` without the version component.
- `set_version` method to create a new `CtsUrn` with a specified version component.
- `drop_exemplar` method to create a new `CtsUrn` without the exemplar component.
- `set_exemplar` method to create a new `CtsUrn` with a specified exemplar component.

## 0.3.0 - 2026-01-15

Breaking changes to the `CtsUrn` class.

### Added

- `passage_contains` method to check if one passage is contained within another. Replaces the previous `passage_similar` method.
- `work_contains` method to check if one passage is contained within another. Replaces the previous `work_similar` method.
- `contains` method to check if one passage is contained within another. Replaces the previous `urn_similar` method.

### Changed

- Updated unit tests to reflect the new containment methods and removal of the old similarity methods.


### Removed

- `passage_similar`, `work_similar`, and `urn_similar` methods from `CtsUrn` class as they have been replaced by the new containment methods.



## 0.2.0 - 2026-01-14

Breaking changes to the `CtsUrn` class.

### Added

- `__str__` method implemented for `CtsUrn` class to provide a string representation of the URN.

### Changed

- Updated unit tests to reflect the addition of the `__str__` method and deletion of `to_string` method.

### Removed

- `to_string` method from `CtsUrn` class as it is redundant with the new `__str__` method.


## 0.1.0 - 2026-01-13 

Initial release.

### Added

- `CtsUrn` class to represent and manipulate CTS URNs.
- Methods for parsing, validating, and formatting CTS URNs.
- Unit tests for all functionalities of the `CtsUrn` class.




[0.2.0]: https://github.com/username/project/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/username/project/releases/tag/v0.0.1
