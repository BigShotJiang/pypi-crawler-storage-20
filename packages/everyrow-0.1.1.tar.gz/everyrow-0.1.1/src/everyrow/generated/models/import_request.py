from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.import_request_token_data import ImportRequestTokenData


T = TypeVar("T", bound="ImportRequest")


@_attrs_define
class ImportRequest:
    """
    Attributes:
        session_id (str):
        token_data (ImportRequestTokenData):
        sheets_url (str):
    """

    session_id: str
    token_data: ImportRequestTokenData
    sheets_url: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        session_id = self.session_id

        token_data = self.token_data.to_dict()

        sheets_url = self.sheets_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "session_id": session_id,
                "token_data": token_data,
                "sheets_url": sheets_url,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.import_request_token_data import ImportRequestTokenData

        d = dict(src_dict)
        session_id = d.pop("session_id")

        token_data = ImportRequestTokenData.from_dict(d.pop("token_data"))

        sheets_url = d.pop("sheets_url")

        import_request = cls(
            session_id=session_id,
            token_data=token_data,
            sheets_url=sheets_url,
        )

        import_request.additional_properties = d
        return import_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
