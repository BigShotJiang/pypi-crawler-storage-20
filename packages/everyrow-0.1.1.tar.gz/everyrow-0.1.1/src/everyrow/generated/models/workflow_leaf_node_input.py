from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="WorkflowLeafNodeInput")


@_attrs_define
class WorkflowLeafNodeInput:
    """
    Attributes:
        workflow_task_id (UUID):
        input_artifact_id (UUID):
    """

    workflow_task_id: UUID
    input_artifact_id: UUID
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        workflow_task_id = str(self.workflow_task_id)

        input_artifact_id = str(self.input_artifact_id)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "workflow_task_id": workflow_task_id,
                "input_artifact_id": input_artifact_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        workflow_task_id = UUID(d.pop("workflow_task_id"))

        input_artifact_id = UUID(d.pop("input_artifact_id"))

        workflow_leaf_node_input = cls(
            workflow_task_id=workflow_task_id,
            input_artifact_id=input_artifact_id,
        )

        workflow_leaf_node_input.additional_properties = d
        return workflow_leaf_node_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
