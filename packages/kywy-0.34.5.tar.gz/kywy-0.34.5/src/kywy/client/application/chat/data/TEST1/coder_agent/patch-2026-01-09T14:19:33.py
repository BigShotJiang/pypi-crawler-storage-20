# -- METRICS SECTION: start

model.create_metric(
    name='trade_notional_value',
    formula="""
    "quantity" * "price"
    """,
)

model.create_metric(
    name='risk_utilization_pct',
    formula="""
    ("avg_var" / "desk_limit") * 100
    """,
)

model.create_metric(
    name='is_risk_warning',
    formula="""
    CASE 
        WHEN ("avg_var" / "desk_limit") * 100 >= "Risk Utilization Threshold" THEN 1.0
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='is_risk_breach',
    formula="""
    CASE 
        WHEN "total_breach_days" > 0 THEN 1.0
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='pnl_var_efficiency',
    formula="""
    CASE 
        WHEN "avg_var" > 0 THEN "total_pnl" / "avg_var"
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='price_effect_pct',
    formula="""
    CASE 
        WHEN "total_pnl" <> 0 THEN ("total_price_effect" / "total_pnl") * 100
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='unexplained_pnl_pct',
    formula="""
    CASE 
        WHEN "total_pnl" <> 0 THEN ("total_unexplained_pnl" / "total_pnl") * 100
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='is_large_loss',
    formula="""
    CASE 
        WHEN "total_pnl" <= "PnL Threshold for Alerts" THEN 1.0
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='price_vs_market',
    formula="""
    "price" - "avg_market_price"
    """,
)

model.create_metric(
    name='stressed_var',
    formula="""
    "avg_var" * "Stress Scenario Multiplier"
    """,
)

model.create_metric(
    name='stressed_risk_utilization_pct',
    formula="""
    ("avg_var" * "Stress Scenario Multiplier" / "desk_limit") * 100
    """,
)

model.create_metric(
    name='is_stressed_breach',
    formula="""
    CASE 
        WHEN ("avg_var" * "Stress Scenario Multiplier") >= "desk_limit" THEN 1.0
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='exposure_to_var_ratio',
    formula="""
    CASE 
        WHEN "avg_var" > 0 THEN "avg_exposure" / ("avg_var" / 1000000)
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='stress_to_var_ratio',
    formula="""
    CASE 
        WHEN "avg_var" > 0 THEN ABS("avg_stress_pnl") / "avg_var"
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='is_physical_trade',
    formula="""
    CASE 
        WHEN "instrument_type" = 'Physical' THEN 1.0
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='is_paper_trade',
    formula="""
    CASE 
        WHEN "instrument_type" IN ('Futures', 'Swap', 'Option') THEN 1.0
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='is_large_trade',
    formula="""
    CASE 
        WHEN ("quantity" * "price") >= "Minimum Trade Size USD" THEN 1.0
        ELSE 0.0
    END
    """,
)

model.create_metric(
    name='market_volatility_level',
    formula="""
    CASE 
        WHEN "avg_market_volatility" >= 35.0 THEN 'High'
        WHEN "avg_market_volatility" >= 25.0 THEN 'Medium'
        ELSE 'Low'
    END
    """,
)

model.create_metric(
    name='risk_status',
    formula="""
    CASE 
        WHEN "total_breach_days" > 0 THEN 'Breach'
        WHEN ("avg_var" / "desk_limit") * 100 >= "Risk Utilization Threshold" THEN 'Warning'
        ELSE 'Normal'
    END
    """,
)

model.create_metric(
    name='commodity_type',
    formula="""
    CASE 
        WHEN "commodity" LIKE 'Crude%' THEN 'Crude Oil'
        WHEN "commodity" LIKE 'Gas%' THEN 'Natural Gas'
        WHEN "commodity" LIKE 'LNG%' THEN 'LNG'
        WHEN "commodity" IN ('Gasoline_RBOB', 'Diesel_Gasoil') THEN 'Refined Products'
        ELSE 'Other'
    END
    """,
)

# -- METRICS SECTION: end
