# -- RELATIONSHIPS SECTION: start

pnl_relationship = model.create_relationship(
    name='PnL Attribution',
    dataset=pnl_attribution_dataset,
    link={'trade_id': 'trade_id'}
)

pnl_relationship.add_column(
    name='daily_pnl',
    aggregation='SUM',
    new_column_name='total_pnl',
)

pnl_relationship.add_column(
    name='price_effect',
    aggregation='SUM',
    new_column_name='total_price_effect',
)

pnl_relationship.add_column(
    name='volume_effect',
    aggregation='SUM',
    new_column_name='total_volume_effect',
)

pnl_relationship.add_column(
    name='fx_effect',
    aggregation='SUM',
    new_column_name='total_fx_effect',
)

pnl_relationship.add_column(
    name='basis_effect',
    aggregation='SUM',
    new_column_name='total_basis_effect',
)

pnl_relationship.add_column(
    name='unexplained_pnl',
    aggregation='SUM',
    new_column_name='total_unexplained_pnl',
)

pnl_relationship.add_column(
    name='daily_pnl',
    aggregation='COUNT',
    new_column_name='pnl_days_count',
)

market_prices_relationship = model.create_relationship(
    name='Market Prices',
    dataset=market_prices_dataset,
    link={'commodity': 'commodity', 'region': 'region'}
)

market_prices_relationship.add_column(
    name='price',
    aggregation='AVERAGE',
    new_column_name='avg_market_price',
)

market_prices_relationship.add_column(
    name='volatility',
    aggregation='AVERAGE',
    new_column_name='avg_market_volatility',
)

market_prices_relationship.add_column(
    name='price',
    aggregation='MIN',
    new_column_name='min_market_price',
)

market_prices_relationship.add_column(
    name='price',
    aggregation='MAX',
    new_column_name='max_market_price',
)

risk_metrics_relationship = model.create_relationship(
    name='Risk Metrics',
    dataset=risk_metrics_dataset,
    link={'desk': 'desk'}
)

risk_metrics_relationship.add_column(
    name='var_amount',
    aggregation='AVERAGE',
    new_column_name='avg_var',
)

risk_metrics_relationship.add_column(
    name='stress_pnl',
    aggregation='AVERAGE',
    new_column_name='avg_stress_pnl',
)

risk_metrics_relationship.add_column(
    name='exposure',
    aggregation='AVERAGE',
    new_column_name='avg_exposure',
)

risk_metrics_relationship.add_column(
    name='limit_amount',
    aggregation='FIRST',
    new_column_name='desk_limit',
)

risk_metrics_relationship.add_column(
    name='limit_breach_flag',
    aggregation='SUM',
    new_column_name='total_breach_days',
)

risk_metrics_relationship.add_column(
    name='var_amount',
    aggregation='MAX',
    new_column_name='max_var',
)

# -- RELATIONSHIPS SECTION: end
