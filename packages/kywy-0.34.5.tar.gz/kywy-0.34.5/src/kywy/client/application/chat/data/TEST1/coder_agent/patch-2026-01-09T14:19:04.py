# -- VARIABLES SECTION: start

model.create_variable(
    name='Risk Utilization Threshold',
    kawa_type='decimal',
    initial_value=80.0,
)

model.create_variable(
    name='Analysis Start Date',
    kawa_type='date',
    initial_value=date(2024, 1, 2),
)

model.create_variable(
    name='Analysis End Date',
    kawa_type='date',
    initial_value=date(2024, 1, 31),
)

model.create_variable(
    name='Minimum Trade Size USD',
    kawa_type='decimal',
    initial_value=1000000.0,
)

model.create_variable(
    name='Stress Scenario Multiplier',
    kawa_type='decimal',
    initial_value=1.15,
)

model.create_variable(
    name='PnL Threshold for Alerts',
    kawa_type='decimal',
    initial_value=-50000.0,
)

# -- VARIABLES SECTION: end
