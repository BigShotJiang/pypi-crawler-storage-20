from kywy.client.kawa_client import KawaClient
from kywy.client.kawa_decorators import kawa_tool
from datetime import datetime, date, timedelta
import pandas as pd
import numpy as np
from faker import Faker

kawa = KawaClient.load_client_from_environment()

app = kawa.app(
    application_name='Global Energy Trading Performance & Risk Intelligence',
    sidebar_color='#1a1a2e',
)

# -- DATA SECTION: start

@kawa_tool(
    outputs={
        'trade_id': str,
        'trade_date': date,
        'commodity': str,
        'instrument_type': str,
        'desk': str,
        'region': str,
        'counterparty': str,
        'trader_id': str,
        'quantity': float,
        'price': float,
        'currency': str,
        'delivery_location': str,
        'delivery_month': str
    }
)
def trades_generator():
    fake = Faker()
    
    commodities = ['Crude_WTI', 'Crude_Brent', 'Gas_HenryHub', 'Gas_TTF', 'LNG_JKM', 'Gasoline_RBOB', 'Diesel_Gasoil']
    instrument_types = ['Physical', 'Futures', 'Swap', 'Option']
    instrument_weights = [0.40, 0.35, 0.20, 0.05]
    
    desks = ['Houston_Crude', 'London_Crude', 'Singapore_Crude', 'Houston_Gas', 'London_Gas', 'Tokyo_LNG', 'NewYork_Refining']
    regions = ['Americas', 'Europe', 'Asia', 'MiddleEast']
    counterparties = ['Shell', 'BP', 'Vitol', 'Trafigura', 'TotalEnergies', 'Chevron', 'ExxonMobil', 'Glencore', 'Gunvor', 'Koch']
    currencies = ['USD', 'EUR', 'GBP', 'JPY', 'SGD']
    
    desk_to_region = {
        'Houston_Crude': 'Americas',
        'London_Crude': 'Europe',
        'Singapore_Crude': 'Asia',
        'Houston_Gas': 'Americas',
        'London_Gas': 'Europe',
        'Tokyo_LNG': 'Asia',
        'NewYork_Refining': 'Americas'
    }
    
    desk_to_commodities = {
        'Houston_Crude': ['Crude_WTI'],
        'London_Crude': ['Crude_Brent', 'Diesel_Gasoil'],
        'Singapore_Crude': ['Crude_Brent'],
        'Houston_Gas': ['Gas_HenryHub'],
        'London_Gas': ['Gas_TTF'],
        'Tokyo_LNG': ['LNG_JKM'],
        'NewYork_Refining': ['Gasoline_RBOB', 'Diesel_Gasoil']
    }
    
    commodity_to_location = {
        'Crude_WTI': ['Cushing_OK'],
        'Crude_Brent': ['Rotterdam', 'Singapore'],
        'Gas_HenryHub': ['HenryHub_LA'],
        'Gas_TTF': ['Rotterdam'],
        'LNG_JKM': ['Tokyo_Bay', 'Singapore'],
        'Gasoline_RBOB': ['NewYork_Harbor'],
        'Diesel_Gasoil': ['Rotterdam', 'Singapore']
    }
    
    price_ranges = {
        'Crude_WTI': (70.0, 72.5),
        'Crude_Brent': (76.0, 78.0),
        'Gas_HenryHub': (2.70, 2.90),
        'Gas_TTF': (9.0, 9.6),
        'LNG_JKM': (13.3, 14.2),
        'Gasoline_RBOB': (2.00, 2.15),
        'Diesel_Gasoil': (710.0, 730.0)
    }
    
    quantity_ranges = {
        'Crude_WTI': (250000, 1000000),
        'Crude_Brent': (250000, 1000000),
        'Gas_HenryHub': (8000000, 15000000),
        'Gas_TTF': (10000000, 16000000),
        'LNG_JKM': (45000, 75000),
        'Gasoline_RBOB': (80000, 200000),
        'Diesel_Gasoil': (150000, 250000)
    }
    
    data = []
    start_date = date(2024, 1, 2)
    
    trader_ids = [f'TRD_{i:03d}' for i in range(1, 51)]
    
    for i in range(250):
        trade_id = f'TRD_{i+1:05d}'
        
        days_offset = np.random.randint(0, 20)
        trade_date = start_date + timedelta(days=days_offset)
        if trade_date.weekday() >= 5:
            trade_date = trade_date + timedelta(days=(7 - trade_date.weekday()))
        
        desk = np.random.choice(desks)
        region = desk_to_region[desk]
        commodity = np.random.choice(desk_to_commodities[desk])
        instrument_type = np.random.choice(instrument_types, p=instrument_weights)
        
        counterparty = np.random.choice(counterparties)
        trader_id = np.random.choice(trader_ids)
        
        price_min, price_max = price_ranges[commodity]
        price = np.random.uniform(price_min, price_max)
        price = round(price + np.random.normal(0, (price_max - price_min) * 0.02), 2)
        
        qty_min, qty_max = quantity_ranges[commodity]
        quantity = np.random.uniform(qty_min, qty_max)
        if np.random.random() < 0.1:
            quantity *= np.random.uniform(1.5, 2.5)
        quantity = round(quantity, 0)
        
        currency = 'USD'
        if desk == 'London_Gas':
            currency = 'EUR'
        elif np.random.random() < 0.05:
            currency = np.random.choice(['GBP', 'JPY', 'SGD'])
        
        delivery_location = np.random.choice(commodity_to_location[commodity])
        
        delivery_month_offset = np.random.choice([1, 2], p=[0.7, 0.3])
        delivery_month = (trade_date.replace(day=1) + timedelta(days=32 * delivery_month_offset)).strftime('%Y-%m')
        
        data.append([
            trade_id, trade_date, commodity, instrument_type, desk, region,
            counterparty, trader_id, quantity, price, currency,
            delivery_location, delivery_month
        ])
    
    df = pd.DataFrame(data, columns=[
        'trade_id', 'trade_date', 'commodity', 'instrument_type', 'desk', 'region',
        'counterparty', 'trader_id', 'quantity', 'price', 'currency',
        'delivery_location', 'delivery_month'
    ])
    
    return df


trades_dataset = app.create_dataset(
    name='Trades',
    generator=trades_generator,
)


@kawa_tool(
    outputs={
        'date': date,
        'commodity': str,
        'region': str,
        'benchmark': str,
        'price': float,
        'volatility': float
    }
)
def market_prices_generator():
    commodities_config = [
        ('Crude_WTI', 'Americas', 'NYMEX_CL_Front', 71.0, 0.5, 22.5),
        ('Crude_Brent', 'Europe', 'ICE_Brent_Front', 76.8, 0.5, 21.8),
        ('Gas_HenryHub', 'Americas', 'NYMEX_NG_Front', 2.80, 0.05, 35.5),
        ('Gas_TTF', 'Europe', 'ICE_TTF_Front', 9.30, 0.15, 42.0),
        ('LNG_JKM', 'Asia', 'Platts_JKM', 13.65, 0.20, 28.8),
        ('Gasoline_RBOB', 'Americas', 'NYMEX_RBOB_Front', 2.06, 0.03, 26.5),
        ('Diesel_Gasoil', 'Europe', 'ICE_Gasoil_Front', 718.0, 5.0, 24.2)
    ]
    
    data = []
    start_date = date(2024, 1, 2)
    num_days = 20
    
    for commodity, region, benchmark, base_price, daily_vol, base_volatility in commodities_config:
        price = base_price
        volatility = base_volatility
        
        for day_offset in range(num_days):
            current_date = start_date + timedelta(days=day_offset)
            
            if current_date.weekday() < 5:
                price_change = np.random.normal(0, daily_vol)
                price = price + price_change
                
                volatility = base_volatility + np.random.uniform(-2.0, 2.0)
                volatility = max(15.0, min(50.0, volatility))
                
                data.append([
                    current_date,
                    commodity,
                    region,
                    benchmark,
                    round(price, 2),
                    round(volatility, 1)
                ])
    
    df = pd.DataFrame(data, columns=[
        'date', 'commodity', 'region', 'benchmark', 'price', 'volatility'
    ])
    
    return df


market_prices_dataset = app.create_dataset(
    name='Market Prices',
    generator=market_prices_generator,
)


@kawa_tool(
    outputs={
        'trade_id': str,
        'date': date,
        'daily_pnl': float,
        'price_effect': float,
        'volume_effect': float,
        'fx_effect': float,
        'basis_effect': float,
        'unexplained_pnl': float
    }
)
def pnl_attribution_generator():
    fake = Faker()
    
    trades_df = pd.DataFrame([
        ['TRD_00001', date(2024, 1, 2), 'Crude_WTI', 500000, 71.25],
        ['TRD_00002', date(2024, 1, 2), 'Crude_Brent', 1000000, 76.80],
        ['TRD_00003', date(2024, 1, 3), 'Gas_HenryHub', 10000000, 2.85],
        ['TRD_00004', date(2024, 1, 3), 'LNG_JKM', 70000, 13.50],
        ['TRD_00005', date(2024, 1, 4), 'Gas_TTF', 15000000, 9.20],
        ['TRD_00006', date(2024, 1, 4), 'Crude_WTI', 250000, 72.00],
        ['TRD_00007', date(2024, 1, 5), 'Gasoline_RBOB', 100000, 2.05],
        ['TRD_00008', date(2024, 1, 5), 'Crude_Brent', 750000, 77.50],
        ['TRD_00009', date(2024, 1, 8), 'Diesel_Gasoil', 200000, 720.00],
        ['TRD_00010', date(2024, 1, 8), 'LNG_JKM', 50000, 13.75],
    ], columns=['trade_id', 'trade_date', 'commodity', 'quantity', 'entry_price'])
    
    data = []
    
    for _, trade in trades_df.iterrows():
        trade_id = trade['trade_id']
        trade_date = trade['trade_date']
        commodity = trade['commodity']
        quantity = trade['quantity']
        entry_price = trade['entry_price']
        
        num_days = np.random.randint(5, 15)
        
        for day_offset in range(1, num_days + 1):
            pnl_date = trade_date + timedelta(days=day_offset)
            
            if pnl_date.weekday() >= 5:
                continue
            
            price_change = np.random.normal(0, 0.015) * entry_price
            
            if commodity.startswith('Crude'):
                price_effect = price_change * quantity
            elif commodity.startswith('Gas'):
                price_effect = price_change * quantity * 0.001
            elif commodity.startswith('LNG'):
                price_effect = price_change * quantity * 0.15
            else:
                price_effect = price_change * quantity * 0.8
            
            volume_effect = 0.0
            if np.random.random() < 0.05:
                volume_effect = np.random.uniform(-0.02, 0.02) * abs(price_effect)
            
            fx_effect = 0.0
            if np.random.random() < 0.15:
                fx_effect = np.random.uniform(-0.08, 0.08) * abs(price_effect)
            
            basis_effect = np.random.uniform(-0.015, 0.015) * abs(price_effect)
            
            daily_pnl = price_effect + volume_effect + fx_effect + basis_effect
            
            unexplained_pnl = np.random.uniform(-0.025, 0.025) * abs(daily_pnl)
            daily_pnl += unexplained_pnl
            
            data.append([
                trade_id,
                pnl_date,
                round(daily_pnl, 2),
                round(price_effect, 2),
                round(volume_effect, 2),
                round(fx_effect, 2),
                round(basis_effect, 2),
                round(unexplained_pnl, 2)
            ])
    
    df = pd.DataFrame(data, columns=[
        'trade_id', 'date', 'daily_pnl', 'price_effect', 'volume_effect',
        'fx_effect', 'basis_effect', 'unexplained_pnl'
    ])
    
    return df


pnl_attribution_dataset = app.create_dataset(
    name='P&L Attribution',
    generator=pnl_attribution_generator,
)


@kawa_tool(
    outputs={
        'desk': str,
        'date': date,
        'var_amount': float,
        'stress_pnl': float,
        'exposure': float,
        'limit_amount': float,
        'limit_breach_flag': float
    }
)
def risk_metrics_generator():
    desks = ['Houston_Crude', 'London_Crude', 'Singapore_Crude', 'Houston_Gas', 'London_Gas', 'Tokyo_LNG', 'NewYork_Refining']
    
    desk_config = {
        'Houston_Crude': {'base_var': 1280000, 'limit': 1500000, 'base_exposure': 87.5},
        'London_Crude': {'base_var': 1850000, 'limit': 2000000, 'base_exposure': 128.0},
        'Singapore_Crude': {'base_var': 1000000, 'limit': 1200000, 'base_exposure': 67.5},
        'Houston_Gas': {'base_var': 700000, 'limit': 800000, 'base_exposure': 48.5},
        'London_Gas': {'base_var': 1150000, 'limit': 1200000, 'base_exposure': 76.8},
        'Tokyo_LNG': {'base_var': 820000, 'limit': 1000000, 'base_exposure': 56.2},
        'NewYork_Refining': {'base_var': 440000, 'limit': 500000, 'base_exposure': 30.5}
    }
    
    data = []
    start_date = date(2024, 1, 2)
    num_days = 20
    
    for desk in desks:
        config = desk_config[desk]
        base_var = config['base_var']
        limit_amount = config['limit']
        base_exposure = config['base_exposure']
        
        var_amount = base_var
        exposure = base_exposure
        
        for day_offset in range(num_days):
            current_date = start_date + timedelta(days=day_offset)
            
            if current_date.weekday() >= 5:
                continue
            
            var_change = np.random.normal(0, base_var * 0.05)
            var_amount = var_amount + var_change
            var_amount = max(base_var * 0.5, min(base_var * 1.5, var_amount))
            
            exposure_change = np.random.normal(0, base_exposure * 0.04)
            exposure = exposure + exposure_change
            exposure = max(base_exposure * 0.6, min(base_exposure * 1.4, exposure))
            
            if np.random.random() < 0.03 or (desk == 'London_Gas' and day_offset >= 6):
                var_amount = limit_amount * np.random.uniform(1.02, 1.12)
            
            stress_pnl = -var_amount * np.random.uniform(2.0, 2.6)
            
            limit_breach_flag = 1.0 if var_amount >= limit_amount else 0.0
            
            data.append([
                desk,
                current_date,
                round(var_amount, 0),
                round(stress_pnl, 0),
                round(exposure, 1),
                round(limit_amount, 0),
                limit_breach_flag
            ])
    
    df = pd.DataFrame(data, columns=[
        'desk', 'date', 'var_amount', 'stress_pnl', 'exposure', 'limit_amount', 'limit_breach_flag'
    ])
    
    return df


risk_metrics_dataset = app.create_dataset(
    name='Risk Metrics',
    generator=risk_metrics_generator,
)

model = app.create_model(
    dataset=trades_dataset,
)

# -- DATA SECTION: end

# -- RELATIONSHIPS SECTION: start

# -- RELATIONSHIPS SECTION: end

# -- VARIABLES SECTION: start

# -- VARIABLES SECTION: end

# -- METRICS SECTION: start

# -- METRICS SECTION: end

# -- DASHBOARD SECTION: start

# -- DASHBOARD SECTION: end

app.publish()
