#!/usr/bin/env python3
from __future__ import annotations

import os
import shutil
import tempfile

from flask import Flask, request, send_file, jsonify
from gevent.lock import Semaphore  # gevent-friendly semaphore

from .downloader import validate_environment, download_video

app = Flask(__name__)

# Base directory for per-request temp folders.
# Each request downloads into its own subdir and the entire subdir is deleted
# once the HTTP response is fully closed.
BASE_DOWNLOAD_DIR = os.environ.get("YTPDL_DOWNLOAD_DIR", "/tmp/ytp-dl")
os.makedirs(BASE_DOWNLOAD_DIR, exist_ok=True)

# Concurrency cap (process-wide). With Gunicorn -w 1, this is an instance-wide cap.
MAX_CONCURRENT = int(os.environ.get("YTPDL_MAX_CONCURRENT", "1"))
_sem = Semaphore(MAX_CONCURRENT)


@app.route('/api/download', methods=['POST'])
def handle_download():
    if not _sem.acquire(blocking=False):
        # Busy: fail fast so the client can retry with backoff
        return jsonify(error="Server busy, try again later"), 503

    job_dir = None

    try:
        data = request.get_json(force=True)
        url = data.get("url")
        resolution = data.get("resolution")
        extension = data.get("extension")

        if not url:
            _sem.release()
            return jsonify(error="Missing 'url'"), 400

        # Isolate each download (and any .part/.ytdl/etc) into a unique dir.
        job_dir = tempfile.mkdtemp(prefix="ytpdl_", dir=BASE_DOWNLOAD_DIR)

        filename = download_video(
            url=url,
            resolution=resolution,
            extension=extension,
            out_dir=job_dir,
        )

        if not (filename and os.path.exists(filename)):
            raise RuntimeError("Download failed")

        response = send_file(filename, as_attachment=True)

        # Critical fix: delete artifacts only after the response is fully sent.
        def _cleanup() -> None:
            try:
                if job_dir:
                    shutil.rmtree(job_dir, ignore_errors=True)
            finally:
                # Hold the semaphore until streaming is done (limits disk usage).
                _sem.release()

        response.call_on_close(_cleanup)
        return response

    except RuntimeError as e:
        # No streaming response will be returned; clean up immediately.
        if job_dir:
            shutil.rmtree(job_dir, ignore_errors=True)
        _sem.release()

        msg = str(e)
        if "Mullvad not logged in" in msg:
            return jsonify(error=msg), 503
        return jsonify(error=f"Download failed: {msg}"), 500

    except Exception as e:
        if job_dir:
            shutil.rmtree(job_dir, ignore_errors=True)
        _sem.release()
        return jsonify(error=f"Download failed: {str(e)}"), 500


@app.route('/healthz', methods=['GET'])
def healthz():
    # Quick health endpoint
    return jsonify(ok=True, in_use=(MAX_CONCURRENT - _sem.counter), capacity=MAX_CONCURRENT), 200


def main():
    validate_environment()
    print("Starting ytp-dl API server...")
    app.run(host='0.0.0.0', port=5000)


if __name__ == "__main__":
    main()
