"""
Demo script to test different spot size calculation strategies.

Compare:
1. Current fixed default (150)
2. Squidpy formula (120000 / n_cells)
3. Scanpy metadata-based approach
"""

import matplotlib.pyplot as plt
import numpy as np
import scanpy as sc


def calculate_spot_size_squidpy_formula(n_cells: int) -> float:
    """Squidpy's fallback formula."""
    return 120000 / n_cells


def calculate_spot_size_from_metadata(adata) -> float | None:
    """Try to get spot size from spatial metadata (scanpy/squidpy approach)."""
    if "spatial" not in adata.uns:
        return None

    spatial_data = adata.uns["spatial"]
    if not spatial_data:
        return None

    # Get first library_id
    library_id = list(spatial_data.keys())[0]

    if "scalefactors" in spatial_data[library_id]:
        scalefactors = spatial_data[library_id]["scalefactors"]
        if "spot_diameter_fullres" in scalefactors:
            return scalefactors["spot_diameter_fullres"]

    return None


def auto_spot_size(adata, user_spot_size: float | None = None) -> float:
    """
    Auto-calculate spot size following scanpy/squidpy conventions.

    Priority:
    1. User-specified value (if provided)
    2. Metadata-based (spot_diameter_fullres)
    3. Adaptive formula based on cell count
    """
    if user_spot_size is not None:
        return user_spot_size

    # Try metadata first
    metadata_size = calculate_spot_size_from_metadata(adata)
    if metadata_size is not None:
        print(f"  Using metadata spot_diameter_fullres: {metadata_size:.1f}")
        return metadata_size

    # Fallback: adaptive formula
    n_cells = adata.n_obs
    adaptive_size = 120000 / n_cells
    print(f"  Using adaptive formula (120000/{n_cells}): {adaptive_size:.1f}")
    return adaptive_size


def test_with_visium_data():
    """Test with real Visium data that has spatial metadata."""
    print("\n" + "="*60)
    print("Test 1: Visium data with spatial metadata")
    print("="*60)

    # Load Visium data
    data_path = "/Users/apple/Research/ChatSpatial/code/data/processed_datasets/visium/mouse_brain_coronal_v1.h5ad"
    try:
        adata = sc.read_h5ad(data_path)
        print(f"Loaded: {adata.n_obs} spots × {adata.n_vars} genes")

        # Check spatial metadata
        if "spatial" in adata.uns:
            print(f"Spatial libraries: {list(adata.uns['spatial'].keys())}")
            for lib_id, lib_data in adata.uns["spatial"].items():
                if "scalefactors" in lib_data:
                    print(f"  Scalefactors: {lib_data['scalefactors']}")

        # Calculate sizes
        print("\nSpot size calculations:")
        print(f"  Current default (fixed): 150")
        print(f"  Squidpy formula: {calculate_spot_size_squidpy_formula(adata.n_obs):.1f}")

        auto_size = auto_spot_size(adata)
        print(f"  Auto-calculated: {auto_size:.1f}")

        # Create comparison plot
        fig, axes = plt.subplots(1, 4, figsize=(20, 5))

        sizes = [150, 80, 50, auto_size]
        titles = ["Fixed=150 (current)", "Fixed=80", "Fixed=50", f"Auto={auto_size:.0f}"]

        # Get spatial coordinates
        spatial_key = "spatial"
        if spatial_key in adata.obsm:
            coords = adata.obsm[spatial_key]
        else:
            print("No spatial coordinates found!")
            return

        # Get a gene for coloring
        gene = adata.var_names[0]
        if hasattr(adata.X, 'toarray'):
            values = adata[:, gene].X.toarray().flatten()
        else:
            values = adata[:, gene].X.flatten()

        for ax, size, title in zip(axes, sizes, titles):
            scatter = ax.scatter(
                coords[:, 0], coords[:, 1],
                c=values, s=size, cmap="viridis", alpha=0.8
            )
            ax.set_title(title, fontsize=12)
            ax.set_aspect("equal")
            ax.invert_yaxis()
            ax.set_xlabel("X")
            ax.set_ylabel("Y")
            plt.colorbar(scatter, ax=ax, shrink=0.5)

        plt.suptitle(f"Spot Size Comparison - Visium ({adata.n_obs} spots)", fontsize=14)
        plt.tight_layout()
        plt.savefig("/Users/apple/Research/ChatSpatial/code/tests/spot_size_comparison_visium.png", dpi=150)
        print(f"\nSaved: spot_size_comparison_visium.png")
        plt.close()

    except Exception as e:
        print(f"Error: {e}")


def test_with_scrna_data():
    """Test with scRNA-seq data (no spatial metadata)."""
    print("\n" + "="*60)
    print("Test 2: DentateGyrus data (no spatial metadata, has UMAP)")
    print("="*60)

    data_path = "/Users/apple/Research/ChatSpatial/code/data/DentateGyrus/10X43_1.h5ad"
    try:
        adata = sc.read_h5ad(data_path)
        print(f"Loaded: {adata.n_obs} cells × {adata.n_vars} genes")

        # Check for spatial metadata
        has_spatial_meta = "spatial" in adata.uns and bool(adata.uns["spatial"])
        print(f"Has spatial metadata: {has_spatial_meta}")

        # Calculate sizes
        print("\nSpot size calculations:")
        print(f"  Current default (fixed): 150")
        squidpy_size = calculate_spot_size_squidpy_formula(adata.n_obs)
        print(f"  Squidpy formula (120000/{adata.n_obs}): {squidpy_size:.1f}")

        auto_size = auto_spot_size(adata)

        # Use UMAP for visualization
        if "X_umap" not in adata.obsm:
            print("No UMAP found, computing...")
            sc.pp.neighbors(adata)
            sc.tl.umap(adata)

        coords = adata.obsm["X_umap"]

        # Create comparison plot
        fig, axes = plt.subplots(1, 4, figsize=(20, 5))

        sizes = [150, 80, 50, auto_size]
        titles = ["Fixed=150 (current)", "Fixed=80", "Fixed=50", f"Auto={auto_size:.0f}"]

        # Color by clusters
        if "clusters" in adata.obs:
            from matplotlib.colors import ListedColormap
            clusters = adata.obs["clusters"].astype("category")
            colors = clusters.cat.codes
            cmap = "tab20"
        else:
            colors = np.zeros(adata.n_obs)
            cmap = "viridis"

        for ax, size, title in zip(axes, sizes, titles):
            scatter = ax.scatter(
                coords[:, 0], coords[:, 1],
                c=colors, s=size, cmap=cmap, alpha=0.8
            )
            ax.set_title(title, fontsize=12)
            ax.set_aspect("equal")
            ax.set_xlabel("UMAP1")
            ax.set_ylabel("UMAP2")

        plt.suptitle(f"Spot Size Comparison - DentateGyrus ({adata.n_obs} cells)", fontsize=14)
        plt.tight_layout()
        plt.savefig("/Users/apple/Research/ChatSpatial/code/tests/spot_size_comparison_umap.png", dpi=150)
        print(f"\nSaved: spot_size_comparison_umap.png")
        plt.close()

    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()


def test_formula_across_sizes():
    """Show how the formula scales across different dataset sizes."""
    print("\n" + "="*60)
    print("Test 3: Formula behavior across dataset sizes")
    print("="*60)

    cell_counts = [500, 1000, 2000, 3000, 5000, 10000, 20000, 50000, 100000]

    print(f"\n{'Cells':<10} {'Squidpy (120k/n)':<20} {'Current (150)':<15}")
    print("-" * 45)

    for n in cell_counts:
        squidpy = 120000 / n
        print(f"{n:<10} {squidpy:<20.1f} {150:<15}")

    # Plot the formula
    fig, ax = plt.subplots(figsize=(10, 6))

    n_range = np.linspace(500, 100000, 200)
    squidpy_sizes = 120000 / n_range

    ax.plot(n_range, squidpy_sizes, 'b-', linewidth=2, label='Squidpy: 120000/n')
    ax.axhline(y=150, color='r', linestyle='--', linewidth=2, label='Current default: 150')
    ax.axhline(y=50, color='g', linestyle=':', linewidth=2, label='Suggested: 50')

    # Mark common dataset sizes
    common_sizes = [2000, 3000, 5000, 10000]
    for n in common_sizes:
        size = 120000 / n
        ax.scatter([n], [size], s=100, zorder=5)
        ax.annotate(f'{n} cells\n→ {size:.0f}', (n, size),
                   textcoords="offset points", xytext=(10, 10), fontsize=9)

    ax.set_xlabel('Number of cells/spots', fontsize=12)
    ax.set_ylabel('Spot size (s parameter)', fontsize=12)
    ax.set_title('Adaptive Spot Size Formula Comparison', fontsize=14)
    ax.legend(fontsize=10)
    ax.set_xlim(0, 50000)
    ax.set_ylim(0, 300)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig("/Users/apple/Research/ChatSpatial/code/tests/spot_size_formula_comparison.png", dpi=150)
    print(f"\nSaved: spot_size_formula_comparison.png")
    plt.close()


if __name__ == "__main__":
    print("="*60)
    print("Spot Size Calculation Strategy Demo")
    print("="*60)

    test_formula_across_sizes()
    test_with_visium_data()
    test_with_scrna_data()

    print("\n" + "="*60)
    print("Summary")
    print("="*60)
    print("""
Findings:
1. Current fixed default (150) is too large for most datasets
2. Squidpy's adaptive formula (120000/n_cells) scales well:
   - 2000 spots → 60
   - 3000 spots → 40
   - 5000 spots → 24
   - 10000 spots → 12

Recommended approach:
1. First try: metadata (spot_diameter_fullres from 10x Visium)
2. Fallback: adaptive formula (120000/n_cells)
3. Always allow user override
""")
