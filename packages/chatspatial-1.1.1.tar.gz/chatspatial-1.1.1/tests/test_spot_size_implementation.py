"""
Final implementation test for adaptive spot size calculation.

This test validates the proposed auto_spot_size function that will be
integrated into ChatSpatial's visualization module.
"""

import matplotlib.pyplot as plt
import numpy as np
import scanpy as sc
from typing import Optional
import anndata as ad


def auto_spot_size(
    adata: ad.AnnData,
    user_spot_size: Optional[float] = None,
    basis: str = "spatial",
) -> float:
    """
    Calculate optimal spot size for visualization.

    Follows scanpy/squidpy conventions:
    1. User-specified value takes highest priority
    2. For spatial data with metadata: use spot_diameter_fullres * scale_factor
    3. Fallback: adaptive formula 120000 / n_cells

    Args:
        adata: AnnData object
        user_spot_size: User-specified spot size (takes priority if provided)
        basis: Embedding basis ("spatial", "umap", etc.)

    Returns:
        Calculated spot size for matplotlib scatter's s parameter
    """
    # Priority 1: User-specified value
    if user_spot_size is not None:
        return user_spot_size

    # Priority 2: For spatial basis, try to get from metadata
    if basis == "spatial" and "spatial" in adata.uns:
        spatial_data = adata.uns["spatial"]
        if spatial_data:
            # Get first library_id
            library_id = list(spatial_data.keys())[0]
            lib_data = spatial_data[library_id]

            if "scalefactors" in lib_data:
                scalefactors = lib_data["scalefactors"]

                # Get spot diameter
                spot_diameter = scalefactors.get("spot_diameter_fullres")
                if spot_diameter:
                    # Get scale factor (prefer hires, fallback to lowres)
                    scale_factor = scalefactors.get(
                        "tissue_hires_scalef",
                        scalefactors.get("tissue_lowres_scalef", 1.0)
                    )

                    # Calculate: similar to scanpy but for scatter s parameter
                    # scanpy uses radius, we need area for scatter
                    # s = (diameter * scale_factor)^2 / 4 * adjustment_factor
                    # Using a factor of 0.5 to match typical visual expectations
                    calculated_size = (spot_diameter * scale_factor * 0.5) ** 2
                    return max(calculated_size, 5.0)  # minimum size of 5

    # Priority 3: Adaptive formula based on cell count
    n_cells = adata.n_obs
    adaptive_size = 120000 / n_cells

    # Clamp to reasonable range
    return max(min(adaptive_size, 200.0), 5.0)


def test_implementation():
    """Test the auto_spot_size implementation with real data."""
    print("="*60)
    print("Testing auto_spot_size Implementation")
    print("="*60)

    # Test 1: Visium data with metadata
    print("\n--- Test 1: Visium with spatial metadata ---")
    visium_path = "/Users/apple/Research/ChatSpatial/code/data/processed_datasets/visium/mouse_brain_coronal_v1.h5ad"
    try:
        adata_visium = sc.read_h5ad(visium_path)
        print(f"Loaded: {adata_visium.n_obs} spots")

        size_spatial = auto_spot_size(adata_visium, basis="spatial")
        size_umap = auto_spot_size(adata_visium, basis="umap")
        size_user = auto_spot_size(adata_visium, user_spot_size=50.0)

        print(f"  basis='spatial' (metadata): {size_spatial:.1f}")
        print(f"  basis='umap' (formula): {size_umap:.1f}")
        print(f"  user_spot_size=50: {size_user:.1f}")

        # Create visual comparison
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))

        coords = adata_visium.obsm["spatial"]
        gene = adata_visium.var_names[0]
        if hasattr(adata_visium.X, 'toarray'):
            values = adata_visium[:, gene].X.toarray().flatten()
        else:
            values = adata_visium[:, gene].X.flatten()

        test_cases = [
            (150, "Current default (150)"),
            (size_spatial, f"Auto spatial ({size_spatial:.0f})"),
            (size_umap, f"Auto formula ({size_umap:.0f})"),
        ]

        for ax, (size, title) in zip(axes, test_cases):
            scatter = ax.scatter(coords[:, 0], coords[:, 1], c=values, s=size,
                                 cmap="viridis", alpha=0.8)
            ax.set_title(title, fontsize=12)
            ax.set_aspect("equal")
            ax.invert_yaxis()
            plt.colorbar(scatter, ax=ax, shrink=0.5)

        plt.suptitle(f"Visium Spot Size Test ({adata_visium.n_obs} spots)", fontsize=14)
        plt.tight_layout()
        plt.savefig("/Users/apple/Research/ChatSpatial/code/tests/spot_size_final_visium.png", dpi=150)
        print("  Saved: spot_size_final_visium.png")
        plt.close()

    except Exception as e:
        print(f"  Error: {e}")

    # Test 2: Data without spatial metadata
    print("\n--- Test 2: DentateGyrus (no spatial metadata) ---")
    dg_path = "/Users/apple/Research/ChatSpatial/code/data/DentateGyrus/10X43_1.h5ad"
    try:
        adata_dg = sc.read_h5ad(dg_path)
        print(f"Loaded: {adata_dg.n_obs} cells")

        size_spatial = auto_spot_size(adata_dg, basis="spatial")
        size_umap = auto_spot_size(adata_dg, basis="umap")

        print(f"  basis='spatial' (formula, no metadata): {size_spatial:.1f}")
        print(f"  basis='umap' (formula): {size_umap:.1f}")

        # Ensure UMAP exists
        if "X_umap" not in adata_dg.obsm:
            sc.pp.neighbors(adata_dg)
            sc.tl.umap(adata_dg)

        coords = adata_dg.obsm["X_umap"]

        fig, axes = plt.subplots(1, 3, figsize=(15, 5))

        test_cases = [
            (150, "Current default (150)"),
            (size_umap, f"Auto formula ({size_umap:.0f})"),
            (50, "Fixed 50"),
        ]

        colors = adata_dg.obs["clusters"].astype("category").cat.codes if "clusters" in adata_dg.obs else np.zeros(adata_dg.n_obs)

        for ax, (size, title) in zip(axes, test_cases):
            ax.scatter(coords[:, 0], coords[:, 1], c=colors, s=size,
                      cmap="tab20", alpha=0.8)
            ax.set_title(title, fontsize=12)
            ax.set_aspect("equal")

        plt.suptitle(f"UMAP Spot Size Test ({adata_dg.n_obs} cells)", fontsize=14)
        plt.tight_layout()
        plt.savefig("/Users/apple/Research/ChatSpatial/code/tests/spot_size_final_umap.png", dpi=150)
        print("  Saved: spot_size_final_umap.png")
        plt.close()

    except Exception as e:
        print(f"  Error: {e}")
        import traceback
        traceback.print_exc()

    # Test 3: Various dataset sizes
    print("\n--- Test 3: Formula scaling ---")
    print(f"{'n_cells':<10} {'Current':<10} {'Auto':<10}")
    print("-" * 30)
    for n in [500, 1000, 2000, 3000, 5000, 10000, 50000]:
        auto = 120000 / n
        auto_clamped = max(min(auto, 200.0), 5.0)
        print(f"{n:<10} {150:<10} {auto_clamped:<10.1f}")


if __name__ == "__main__":
    test_implementation()

    print("\n" + "="*60)
    print("Conclusion")
    print("="*60)
    print("""
The auto_spot_size function provides:

1. User override: Always respected when provided
2. Metadata-based: For spatial data with 10x Visium metadata
3. Adaptive formula: 120000/n_cells (clamped to 5-200)

This matches scanpy/squidpy conventions while providing
sensible defaults for all data types.
""")
