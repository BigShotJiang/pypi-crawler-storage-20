"""
DSLighting 2.0 - User-Facing API Layer

This is the top layer that users interact with directly.

Components:
- Agent: High-level agent interface
- AgentResult: Result object from agent execution
- DataLoader: Data loading utilities
- Convenience functions: run_agent, load_data, setup
"""

from .agent import Agent, AgentResult
from .data_loader import DataLoader, LoadedData
from .convenience import run_agent, load_data, setup

__all__ = [
    "Agent",
    "AgentResult",
    "DataLoader",
    "LoadedData",
    "run_agent",
    "load_data",
    "setup",
]
