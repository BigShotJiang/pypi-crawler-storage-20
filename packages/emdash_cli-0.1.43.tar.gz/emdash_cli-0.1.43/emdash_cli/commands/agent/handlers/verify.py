"""Handler for /verify command - run verification checks."""

import subprocess
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from emdash_core.agent.verifier import VerifierManager, VerificationReport

console = Console()


def get_git_diff() -> str:
    """Get git diff of staged and unstaged changes."""
    try:
        result = subprocess.run(
            ["git", "diff", "HEAD"],
            capture_output=True,
            text=True,
            cwd=Path.cwd(),
        )
        return result.stdout
    except Exception:
        return ""


def get_changed_files() -> list[str]:
    """Get list of changed files."""
    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD"],
            capture_output=True,
            text=True,
            cwd=Path.cwd(),
        )
        return [f.strip() for f in result.stdout.strip().split("\n") if f.strip()]
    except Exception:
        return []


def display_report(report: VerificationReport) -> None:
    """Display verification report."""
    # Create results table
    table = Table(show_header=True, header_style="bold")
    table.add_column("Status", width=6)
    table.add_column("Verifier", style="cyan")
    table.add_column("Duration", justify="right")
    table.add_column("Details")

    for result in report.results:
        status = "[green]PASS[/green]" if result.passed else "[red]FAIL[/red]"
        duration = f"{result.duration:.1f}s"

        # Build details
        if result.passed:
            details = "[dim]OK[/dim]"
        elif result.issues:
            details = result.issues[0][:50]
            if len(result.issues) > 1:
                details += f" (+{len(result.issues) - 1} more)"
        else:
            details = result.output[:50] if result.output else "Failed"

        table.add_row(status, result.name, duration, details)

    console.print(table)
    console.print()

    # Show summary
    if report.all_passed:
        console.print(f"[bold green]✓ {report.summary}[/bold green]")
    else:
        console.print(f"[bold red]✗ {report.summary}[/bold red]")

        # Show detailed failures
        for result in report.get_failures():
            console.print()
            console.print(Panel(
                result.output[:1000] if result.output else "No output",
                title=f"[red]{result.name}[/red]",
                border_style="red",
            ))


def build_retry_prompt(original_task: str, report: VerificationReport) -> str:
    """Build a retry prompt that includes failure information."""
    failures = report.get_failures()

    failure_text = "\n".join([
        f"- **{r.name}**: {', '.join(r.issues[:3]) if r.issues else r.output[:100]}"
        for r in failures
    ])

    return f"""Continue working on this task. Previous attempt had verification failures:

{failure_text}

Original task: {original_task}

Fix the issues and complete the task."""


def prompt_retry_menu() -> str:
    """Prompt user for action after failed verification.

    Returns:
        One of: 'retry', 'approve', 'stop'
    """
    from prompt_toolkit import PromptSession

    console.print()
    console.print("[bold]What would you like to do?[/bold]")
    console.print("  [cyan]r[/cyan] Retry - feed failures back to agent")
    console.print("  [green]a[/green] Approve - accept despite failures")
    console.print("  [red]s[/red] Stop - end the loop")
    console.print()

    try:
        ps = PromptSession()
        choice = ps.prompt("Choice [r/a/s]: ").strip().lower()

        if choice in ('r', 'retry'):
            return 'retry'
        elif choice in ('a', 'approve'):
            return 'approve'
        else:
            return 'stop'
    except (KeyboardInterrupt, EOFError):
        return 'stop'


def handle_verify(args: str) -> None:
    """Handle /verify command - run verification checks."""
    console.print()

    manager = VerifierManager(Path.cwd())

    if not manager.verifiers:
        console.print("[yellow]No verifiers configured.[/yellow]")
        console.print()
        console.print("[dim]Create .emdash/verifiers.json to add verifiers:[/dim]")
        console.print()
        example = '''{
  "verifiers": [
    {"type": "command", "name": "tests", "command": "npm test"},
    {"type": "command", "name": "lint", "command": "npm run lint"},
    {"type": "llm", "name": "review", "prompt": "Review for bugs and issues", "model": "haiku"}
  ],
  "max_retries": 3
}'''
        console.print(f"[dim]{example}[/dim]")
        console.print()
        return

    console.print(f"[bold]Running {len(manager.verifiers)} verifier(s)...[/bold]")
    console.print()

    # Build context
    context = {
        "git_diff": get_git_diff(),
        "files_changed": get_changed_files(),
    }

    # Run verifiers
    report = manager.run_all(context)

    # Display results
    display_report(report)
    console.print()


def run_verification(goal: str | None = None) -> tuple[VerificationReport, bool]:
    """Run verification and return report.

    Args:
        goal: Optional goal/task being verified

    Returns:
        Tuple of (report, should_continue_loop)
        should_continue_loop is True if user wants to retry
    """
    manager = VerifierManager(Path.cwd())

    if not manager.verifiers:
        console.print("[yellow]No verifiers configured. Skipping verification.[/yellow]")
        return VerificationReport(results=[], all_passed=True, summary="No verifiers"), False

    console.print()
    console.print(f"[bold cyan]Running {len(manager.verifiers)} verifier(s)...[/bold cyan]")
    console.print()

    # Build context
    context = {
        "goal": goal,
        "git_diff": get_git_diff(),
        "files_changed": get_changed_files(),
    }

    # Run verifiers
    report = manager.run_all(context)

    # Display results
    display_report(report)

    return report, not report.all_passed


def handle_verify_loop(
    task: str,
    run_task_fn,
    max_retries: int = 3,
) -> bool:
    """Run a task in a verification loop.

    Args:
        task: The task to run
        run_task_fn: Function to run the task (takes task string, returns None)
        max_retries: Maximum number of retry attempts

    Returns:
        True if completed successfully, False if stopped
    """
    manager = VerifierManager(Path.cwd())
    config = manager.get_config()
    max_retries = config.get("max_retries", max_retries)

    if not manager.verifiers:
        console.print("[yellow]No verifiers configured.[/yellow]")
        console.print("[dim]Configure .emdash/verifiers.json to use verify-loop[/dim]")
        console.print()
        console.print("[dim]Running task without verification...[/dim]")
        run_task_fn(task)
        return True

    current_task = task
    retry_count = 0

    while retry_count <= max_retries:
        # Show attempt header
        console.print()
        console.print(f"[bold cyan]━━━ Attempt {retry_count + 1}/{max_retries + 1} ━━━[/bold cyan]")
        console.print()

        # Run the task
        run_task_fn(current_task)

        # Run verification
        report, has_failures = run_verification(task)

        if not has_failures:
            console.print()
            console.print("[bold green]✓ All verifications passed! Task complete.[/bold green]")
            console.print()
            return True

        # Failed - ask user what to do
        choice = prompt_retry_menu()

        if choice == 'retry':
            retry_count += 1
            if retry_count > max_retries:
                console.print()
                console.print(f"[red]Max retries ({max_retries}) reached.[/red]")
                return False
            # Build retry prompt with failure context
            current_task = build_retry_prompt(task, report)
            console.print()
            console.print("[dim]Retrying with failure context...[/dim]")

        elif choice == 'approve':
            console.print()
            console.print("[yellow]Approved with failing verifications.[/yellow]")
            return True

        else:  # stop
            console.print()
            console.print("[red]Stopped by user.[/red]")
            return False

    return False
