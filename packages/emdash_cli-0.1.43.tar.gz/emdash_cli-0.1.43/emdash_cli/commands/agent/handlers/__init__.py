"""Slash command handlers for the agent CLI."""

from .agents import handle_agents
from .sessions import handle_session
from .todos import handle_todos, handle_todo_add
from .hooks import handle_hooks
from .rules import handle_rules
from .skills import handle_skills
from .mcp import handle_mcp
from .auth import handle_auth
from .doctor import handle_doctor
from .verify import handle_verify, handle_verify_loop
from .misc import (
    handle_status,
    handle_pr,
    handle_projectmd,
    handle_research,
    handle_context,
)

__all__ = [
    "handle_agents",
    "handle_session",
    "handle_todos",
    "handle_todo_add",
    "handle_hooks",
    "handle_rules",
    "handle_skills",
    "handle_mcp",
    "handle_auth",
    "handle_doctor",
    "handle_verify",
    "handle_verify_loop",
    "handle_status",
    "handle_pr",
    "handle_projectmd",
    "handle_research",
    "handle_context",
]
