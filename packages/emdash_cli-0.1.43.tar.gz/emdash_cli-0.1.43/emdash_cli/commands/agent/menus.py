"""Interactive menus for the agent CLI.

Contains all prompt_toolkit-based interactive menus.
"""

from pathlib import Path

from rich.console import Console

console = Console()


def get_clarification_response(clarification: dict) -> str | None:
    """Get user response for clarification with interactive selection.

    Args:
        clarification: Dict with question, context, and options

    Returns:
        User's selected option or typed response, or None if cancelled
    """
    from prompt_toolkit import Application, PromptSession
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import Layout, HSplit, Window, FormattedTextControl
    from prompt_toolkit.styles import Style

    options = clarification.get("options", [])

    if not options:
        # No options, just get free-form input
        session = PromptSession()
        try:
            return session.prompt("response > ").strip() or None
        except (KeyboardInterrupt, EOFError):
            return None

    selected_index = [0]
    result = [None]

    # Key bindings
    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def move_up(event):
        selected_index[0] = (selected_index[0] - 1) % len(options)

    @kb.add("down")
    @kb.add("j")
    def move_down(event):
        selected_index[0] = (selected_index[0] + 1) % len(options)

    @kb.add("enter")
    def select(event):
        result[0] = options[selected_index[0]]
        event.app.exit()

    # Number key shortcuts (1-9)
    for i in range(min(9, len(options))):
        @kb.add(str(i + 1))
        def select_by_number(event, idx=i):
            result[0] = options[idx]
            event.app.exit()

    @kb.add("c-c")
    @kb.add("escape")
    def cancel(event):
        result[0] = None
        event.app.exit()

    @kb.add("o")  # 'o' for Other - custom input
    def other_input(event):
        result[0] = "OTHER_INPUT"
        event.app.exit()

    def get_formatted_options():
        lines = []
        for i, opt in enumerate(options):
            if i == selected_index[0]:
                lines.append(("class:selected", f"  ❯ [{i+1}] {opt}\n"))
            else:
                lines.append(("class:option", f"    [{i+1}] {opt}\n"))
        lines.append(("class:hint", "\n↑/↓ to move, Enter to select, 1-9 for quick select, o for other"))
        return lines

    # Style
    style = Style.from_dict({
        "selected": "#00cc66 bold",
        "option": "#888888",
        "hint": "#888888 italic",
    })

    # Calculate height based on options
    height = len(options) + 2  # options + hint line + padding

    # Layout
    layout = Layout(
        HSplit([
            Window(
                FormattedTextControl(get_formatted_options),
                height=height,
            ),
        ])
    )

    # Application
    app = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
    )

    console.print()

    try:
        app.run()
    except (KeyboardInterrupt, EOFError):
        return None

    # Handle "other" option - get custom input
    if result[0] == "OTHER_INPUT":
        session = PromptSession()
        console.print()
        try:
            return session.prompt("response > ").strip() or None
        except (KeyboardInterrupt, EOFError):
            return None

    # Check if selected option is an "other/explain" type that needs text input
    if result[0]:
        lower_result = result[0].lower()
        needs_input = any(phrase in lower_result for phrase in [
            "something else",
            "other",
            "i'll explain",
            "i will explain",
            "let me explain",
            "custom",
            "none of the above",
        ])
        if needs_input:
            session = PromptSession()
            console.print()
            console.print("[dim]Please explain:[/dim]")
            try:
                custom_input = session.prompt("response > ").strip()
                if custom_input:
                    return custom_input
            except (KeyboardInterrupt, EOFError):
                return None

    return result[0]


def show_plan_approval_menu() -> tuple[str, str]:
    """Show plan approval menu with simple approve/feedback options.

    Returns:
        Tuple of (choice, user_feedback) where user_feedback is only set for 'feedback'
    """
    from prompt_toolkit import Application, PromptSession
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import Layout, HSplit, Window, FormattedTextControl
    from prompt_toolkit.styles import Style

    options = [
        ("approve", "Approve and start implementation"),
        ("feedback", "Provide feedback on the plan"),
    ]

    selected_index = [0]  # Use list to allow mutation in closure
    result = [None]

    # Key bindings
    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def move_up(event):
        selected_index[0] = (selected_index[0] - 1) % len(options)

    @kb.add("down")
    @kb.add("j")
    def move_down(event):
        selected_index[0] = (selected_index[0] + 1) % len(options)

    @kb.add("enter")
    def select(event):
        result[0] = options[selected_index[0]][0]
        event.app.exit()

    @kb.add("1")
    @kb.add("y")
    def select_approve(event):
        result[0] = "approve"
        event.app.exit()

    @kb.add("2")
    @kb.add("n")
    def select_feedback(event):
        result[0] = "feedback"
        event.app.exit()

    @kb.add("c-c")
    @kb.add("q")
    @kb.add("escape")
    def cancel(event):
        result[0] = "feedback"
        event.app.exit()

    def get_formatted_options():
        lines = [("class:title", "Approve this plan?\n\n")]
        for i, (key, desc) in enumerate(options):
            if i == selected_index[0]:
                lines.append(("class:selected", f"  ❯ {key:8} "))
                lines.append(("class:selected-desc", f"- {desc}\n"))
            else:
                lines.append(("class:option", f"    {key:8} "))
                lines.append(("class:desc", f"- {desc}\n"))
        lines.append(("class:hint", "\n↑/↓ to move, Enter to select, y/n for quick select"))
        return lines

    # Style
    style = Style.from_dict({
        "title": "#00ccff bold",
        "selected": "#00cc66 bold",
        "selected-desc": "#00cc66",
        "option": "#888888",
        "desc": "#666666",
        "hint": "#888888 italic",
    })

    # Layout
    layout = Layout(
        HSplit([
            Window(
                FormattedTextControl(get_formatted_options),
                height=6,
            ),
        ])
    )

    # Application
    app = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
    )

    console.print()

    try:
        app.run()
    except (KeyboardInterrupt, EOFError):
        result[0] = "feedback"

    choice = result[0] or "feedback"

    # Get feedback if feedback was chosen
    user_feedback = ""
    if choice == "feedback":
        console.print()
        console.print("[dim]What changes would you like?[/dim]")
        try:
            session = PromptSession()
            user_feedback = session.prompt("feedback > ").strip()
        except (KeyboardInterrupt, EOFError):
            return "feedback", ""

    return choice, user_feedback


def show_agents_interactive_menu() -> tuple[str, str]:
    """Show interactive agents menu.

    Returns:
        Tuple of (action, agent_name) where action is one of:
        - 'view': View agent details
        - 'create': Create new agent
        - 'delete': Delete agent
        - 'edit': Edit agent file
        - 'cancel': User cancelled
    """
    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import Layout, HSplit, Window, FormattedTextControl
    from prompt_toolkit.styles import Style
    from emdash_core.agent.toolkits import list_agent_types, get_custom_agent

    # Get all agents
    all_agents = list_agent_types(Path.cwd())
    builtin = ["Explore", "Plan"]
    custom = [a for a in all_agents if a not in builtin]

    # Build menu items: each is (name, description, is_builtin, is_action)
    menu_items = []

    # Add built-in agents
    menu_items.append(("Explore", "Fast codebase exploration (read-only)", True, False))
    menu_items.append(("Plan", "Design implementation plans", True, False))

    # Add custom agents
    for name in custom:
        agent = get_custom_agent(name, Path.cwd())
        desc = agent.description if agent else "Custom agent"
        menu_items.append((name, desc, False, False))

    # Add action items at the bottom
    menu_items.append(("+ Create New Agent", "Create a new custom agent", False, True))

    selected_index = [0]
    result = [("cancel", "")]

    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def move_up(event):
        selected_index[0] = (selected_index[0] - 1) % len(menu_items)

    @kb.add("down")
    @kb.add("j")
    def move_down(event):
        selected_index[0] = (selected_index[0] + 1) % len(menu_items)

    @kb.add("enter")
    def select(event):
        item = menu_items[selected_index[0]]
        name, desc, is_builtin, is_action = item
        if is_action:
            if "Create" in name:
                result[0] = ("create", "")
        else:
            result[0] = ("view", name)
        event.app.exit()

    @kb.add("d")
    def delete_agent(event):
        item = menu_items[selected_index[0]]
        name, desc, is_builtin, is_action = item
        if not is_builtin and not is_action:
            result[0] = ("delete", name)
            event.app.exit()

    @kb.add("e")
    def edit_agent(event):
        item = menu_items[selected_index[0]]
        name, desc, is_builtin, is_action = item
        if not is_builtin and not is_action:
            result[0] = ("edit", name)
            event.app.exit()

    @kb.add("n")
    def new_agent(event):
        result[0] = ("create", "")
        event.app.exit()

    @kb.add("c-c")
    @kb.add("escape")
    @kb.add("q")
    def cancel(event):
        result[0] = ("cancel", "")
        event.app.exit()

    def get_formatted_menu():
        lines = [("class:title", "Agents\n\n")]

        for i, (name, desc, is_builtin, is_action) in enumerate(menu_items):
            is_selected = i == selected_index[0]
            prefix = "❯ " if is_selected else "  "

            if is_action:
                # Action item (like Create New)
                if is_selected:
                    lines.append(("class:action-selected", f"{prefix}{name}\n"))
                else:
                    lines.append(("class:action", f"{prefix}{name}\n"))
            elif is_builtin:
                # Built-in agent
                if is_selected:
                    lines.append(("class:builtin-selected", f"{prefix}{name}"))
                    lines.append(("class:desc-selected", f" - {desc}\n"))
                else:
                    lines.append(("class:builtin", f"{prefix}{name}"))
                    lines.append(("class:desc", f" - {desc}\n"))
            else:
                # Custom agent
                if is_selected:
                    lines.append(("class:custom-selected", f"{prefix}{name}"))
                    lines.append(("class:desc-selected", f" - {desc}\n"))
                else:
                    lines.append(("class:custom", f"{prefix}{name}"))
                    lines.append(("class:desc", f" - {desc}\n"))

        lines.append(("class:hint", "\n↑/↓ navigate • Enter view • n new • e edit • d delete • q quit"))
        return lines

    style = Style.from_dict({
        "title": "#00ccff bold",
        "builtin": "#888888",
        "builtin-selected": "#00cc66 bold",
        "custom": "#00ccff",
        "custom-selected": "#00cc66 bold",
        "action": "#ffcc00",
        "action-selected": "#ffcc00 bold",
        "desc": "#666666",
        "desc-selected": "#00cc66",
        "hint": "#888888 italic",
    })

    height = len(menu_items) + 4  # items + title + hint + padding

    layout = Layout(
        HSplit([
            Window(
                FormattedTextControl(get_formatted_menu),
                height=height,
            ),
        ])
    )

    app = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
    )

    console.print()

    try:
        app.run()
    except (KeyboardInterrupt, EOFError):
        result[0] = ("cancel", "")

    return result[0]


def prompt_agent_name() -> str:
    """Prompt user for new agent name."""
    from prompt_toolkit import PromptSession

    console.print()
    console.print("[bold]Create New Agent[/bold]")
    console.print("[dim]Enter a name for your agent (e.g., code-reviewer, bug-finder)[/dim]")

    try:
        session = PromptSession()
        name = session.prompt("Agent name > ").strip()
        return name.lower().replace(" ", "-") if name else ""
    except (KeyboardInterrupt, EOFError):
        return ""


def confirm_delete(agent_name: str) -> bool:
    """Confirm agent deletion."""
    from prompt_toolkit import PromptSession

    console.print()
    console.print(f"[yellow]Delete agent '{agent_name}'?[/yellow]")
    console.print("[dim]This will remove the agent file. Type 'yes' to confirm.[/dim]")

    try:
        session = PromptSession()
        response = session.prompt("Confirm > ").strip().lower()
        return response in ("yes", "y")
    except (KeyboardInterrupt, EOFError):
        return False


def show_sessions_interactive_menu(sessions: list, active_session: str | None) -> tuple[str, str]:
    """Show interactive sessions menu.

    Args:
        sessions: List of SessionInfo objects
        active_session: Name of currently active session

    Returns:
        Tuple of (action, session_name) where action is one of:
        - 'load': Load the session
        - 'delete': Delete the session
        - 'cancel': User cancelled
    """
    from prompt_toolkit import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import Layout, HSplit, Window, FormattedTextControl
    from prompt_toolkit.styles import Style

    if not sessions:
        return ("cancel", "")

    # Build menu items: (name, summary, mode, message_count, updated_at, is_active)
    menu_items = []
    for s in sessions:
        is_active = active_session == s.name
        menu_items.append((s.name, s.summary or "", s.mode, s.message_count, s.updated_at, is_active))

    selected_index = [0]
    result = [("cancel", "")]

    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def move_up(event):
        selected_index[0] = (selected_index[0] - 1) % len(menu_items)

    @kb.add("down")
    @kb.add("j")
    def move_down(event):
        selected_index[0] = (selected_index[0] + 1) % len(menu_items)

    @kb.add("enter")
    def select(event):
        item = menu_items[selected_index[0]]
        result[0] = ("load", item[0])
        event.app.exit()

    @kb.add("d")
    def delete_session(event):
        item = menu_items[selected_index[0]]
        result[0] = ("delete", item[0])
        event.app.exit()

    @kb.add("c-c")
    @kb.add("escape")
    @kb.add("q")
    def cancel(event):
        result[0] = ("cancel", "")
        event.app.exit()

    def get_formatted_menu():
        lines = [("class:title", "Sessions\n\n")]

        for i, (name, summary, mode, msg_count, updated, is_active) in enumerate(menu_items):
            is_selected = i == selected_index[0]
            prefix = "❯ " if is_selected else "  "
            active_marker = " *" if is_active else ""

            if is_selected:
                lines.append(("class:name-selected", f"{prefix}{name}{active_marker}"))
                lines.append(("class:mode-selected", f" [{mode}]"))
                lines.append(("class:info-selected", f" {msg_count} msgs\n"))
                if summary:
                    truncated = summary[:50] + "..." if len(summary) > 50 else summary
                    lines.append(("class:summary-selected", f"    {truncated}\n"))
            else:
                lines.append(("class:name", f"{prefix}{name}{active_marker}"))
                lines.append(("class:mode", f" [{mode}]"))
                lines.append(("class:info", f" {msg_count} msgs\n"))
                if summary:
                    truncated = summary[:50] + "..." if len(summary) > 50 else summary
                    lines.append(("class:summary", f"    {truncated}\n"))

        lines.append(("class:hint", "\n↑/↓ navigate • Enter load • d delete • q quit"))
        return lines

    style = Style.from_dict({
        "title": "#00ccff bold",
        "name": "#00ccff",
        "name-selected": "#00cc66 bold",
        "mode": "#888888",
        "mode-selected": "#00cc66",
        "info": "#666666",
        "info-selected": "#00cc66",
        "summary": "#555555 italic",
        "summary-selected": "#00cc66 italic",
        "hint": "#444444 italic",
    })

    height = len(menu_items) * 2 + 4  # items (with summaries) + title + hint + padding

    layout = Layout(
        HSplit([
            Window(
                FormattedTextControl(get_formatted_menu),
                height=height,
            ),
        ])
    )

    app = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
    )

    console.print()

    try:
        app.run()
    except (KeyboardInterrupt, EOFError):
        result[0] = ("cancel", "")

    return result[0]


def confirm_session_delete(session_name: str) -> bool:
    """Confirm session deletion."""
    from prompt_toolkit import PromptSession

    console.print()
    console.print(f"[yellow]Delete session '{session_name}'?[/yellow]")
    console.print("[dim]Type 'yes' to confirm.[/dim]")

    try:
        session = PromptSession()
        response = session.prompt("Confirm > ").strip().lower()
        return response in ("yes", "y")
    except (KeyboardInterrupt, EOFError):
        return False


def show_plan_mode_approval_menu() -> tuple[str, str]:
    """Show plan mode entry approval menu.

    Returns:
        Tuple of (choice, feedback) where feedback is only set for 'reject'
    """
    from prompt_toolkit import Application, PromptSession
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout import Layout, HSplit, Window, FormattedTextControl
    from prompt_toolkit.styles import Style

    options = [
        ("approve", "Enter plan mode and explore"),
        ("reject", "Skip planning, proceed directly"),
    ]

    selected_index = [0]
    result = [None]

    kb = KeyBindings()

    @kb.add("up")
    @kb.add("k")
    def move_up(event):
        selected_index[0] = (selected_index[0] - 1) % len(options)

    @kb.add("down")
    @kb.add("j")
    def move_down(event):
        selected_index[0] = (selected_index[0] + 1) % len(options)

    @kb.add("enter")
    def select(event):
        result[0] = options[selected_index[0]][0]
        event.app.exit()

    @kb.add("1")
    @kb.add("y")
    def select_approve(event):
        result[0] = "approve"
        event.app.exit()

    @kb.add("2")
    @kb.add("n")
    def select_reject(event):
        result[0] = "reject"
        event.app.exit()

    @kb.add("c-c")
    @kb.add("q")
    @kb.add("escape")
    def cancel(event):
        result[0] = "reject"
        event.app.exit()

    def get_formatted_options():
        lines = [("class:title", "Enter plan mode?\n\n")]
        for i, (key, desc) in enumerate(options):
            if i == selected_index[0]:
                lines.append(("class:selected", f"  ❯ {key:8} "))
                lines.append(("class:selected-desc", f"- {desc}\n"))
            else:
                lines.append(("class:option", f"    {key:8} "))
                lines.append(("class:desc", f"- {desc}\n"))
        lines.append(("class:hint", "\n↑/↓ to move, Enter to select, y/n for quick select"))
        return lines

    style = Style.from_dict({
        "title": "#ffcc00 bold",
        "selected": "#00cc66 bold",
        "selected-desc": "#00cc66",
        "option": "#888888",
        "desc": "#666666",
        "hint": "#888888 italic",
    })

    layout = Layout(
        HSplit([
            Window(
                FormattedTextControl(get_formatted_options),
                height=6,
            ),
        ])
    )

    app = Application(
        layout=layout,
        key_bindings=kb,
        style=style,
        full_screen=False,
    )

    console.print()

    try:
        app.run()
    except (KeyboardInterrupt, EOFError):
        result[0] = "reject"

    choice = result[0] or "reject"

    feedback = ""
    if choice == "reject":
        console.print()
        console.print("[dim]Reason for skipping plan mode (optional):[/dim]")
        try:
            session = PromptSession()
            feedback = session.prompt("feedback > ").strip()
        except (KeyboardInterrupt, EOFError):
            return "reject", ""

    return choice, feedback
