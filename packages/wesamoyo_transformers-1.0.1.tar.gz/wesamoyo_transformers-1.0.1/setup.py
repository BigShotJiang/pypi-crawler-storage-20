from setuptools import setup, find_packages

setup(
    name="wesamoyo-transformers",  
    version="1.0.1",
    author="Houndtid Labs",
    author_email="houndtidai@gmail.com",
    description="Wesamoyo Transformer Architecture SDK",
    packages=["wesamoyo"], 
    install_requires=[
        "transformers>=4.40.0",
        "torch>=2.4.1",
        "safetensors>=0.4.5"
    ],
    python_requires=">=3.8",
)
