"""
Kimimaro: TEASAR derived skeletonization for 3D densely labeled images.

Kimimaro is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Kimimaro is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Kimimaro.  If not, see <https://www.gnu.org/licenses/>.
"""

from .intake import skeletonize, DimensionError, synapses_to_targets, connect_points
from .post import postprocess, join_close_components
from .utility import (
	extract_skeleton_from_binary_image,
	cross_sectional_area, 
	cross_sectional_area_single,
	oversegment,
)
