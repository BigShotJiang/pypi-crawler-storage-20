"""Plato Worlds - typed world definitions for agent execution.

Usage:
    from plato.worlds import BaseWorld, RunConfig, Agent, Secret, AgentConfig, register_world
    from typing import Annotated

    class CodeWorldConfig(RunConfig):
        # World-specific fields
        repository_url: str
        prompt: str

        # Agents (typed)
        coder: Annotated[AgentConfig, Agent(description="Coding agent")]

        # Secrets (typed)
        git_token: Annotated[str | None, Secret(description="GitHub token")] = None

    @register_world("code")
    class CodeWorld(BaseWorld[CodeWorldConfig]):
        name = "code"
        description = "Run coding agents"

        async def reset(self) -> Observation:
            # Fully typed access
            url = self.config.repository_url
            agent = self.config.coder
            token = self.config.git_token

        async def step(self) -> StepResult:
            ...
"""

from plato.worlds.base import (
    BaseWorld,
    ConfigT,
    Observation,
    StepResult,
    get_registered_worlds,
    get_world,
    register_world,
)
from plato.worlds.config import Agent, AgentConfig, RunConfig, Secret
from plato.worlds.runner import run_world

__all__ = [
    # Base
    "BaseWorld",
    "ConfigT",
    "Observation",
    "StepResult",
    "register_world",
    "get_registered_worlds",
    "get_world",
    # Config
    "RunConfig",
    "AgentConfig",
    "Agent",
    "Secret",
    # Runner
    "run_world",
]
