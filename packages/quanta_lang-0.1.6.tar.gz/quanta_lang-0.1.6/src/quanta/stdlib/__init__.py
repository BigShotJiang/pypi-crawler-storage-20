"""Standard library module"""
