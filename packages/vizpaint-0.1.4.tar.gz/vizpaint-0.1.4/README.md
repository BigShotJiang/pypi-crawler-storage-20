# vizpaint

[![PyPI version](https://img.shields.io/pypi/v/vizpaint.svg)](https://pypi.org/project/vizpaint/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python Versions](https://img.shields.io/pypi/pyversions/vizpaint.svg)](https://pypi.org/project/vizpaint/)

**vizpaint** 是一个强大、易用的 Python 数据可视化库。它基于 Matplotlib 构建，集成了从经典的 2D 图表到令人惊艳的 3D 图形在内的数十种绘图功能，旨在通过极简的 API 让数据可视化变得既简单又专业。

## ✨ 核心特性

*   **丰富的图表类型**：一站式提供柱状图、饼图、散点图、雷达图、玫瑰图、热力图、3D曲面图、3D散点图等十多种专业图表。
*   **极简的 API 设计**：大部分复杂图表只需一行核心代码即可生成，大幅降低学习与使用成本。
*   **深度的定制能力**：从颜色、标签到视角、光照，提供近乎所有可视化元素的参数控制，满足从探索到出版的全流程需求。
*   **卓越的 3D 支持**：内置多种 3D 绘图函数，并支持交互式视角调整，轻松创建三维数据可视化。
*   **无缝的生态集成**：完美兼容 `NumPy` 数组和 `Pandas` `DataFrame`，流畅融入你的数据分析工作流。

## 📦 安装

* 通过 pip 一键安装：

```bash
pip install vizpaint
```
## ⚠️警告
* 该项目准备存档
* 推荐替代方案：
`NumPy`，`matplotlib`


## 英文文档（English document）
vizpaint is a powerful and user-friendly Python data visualization library. Built upon Matplotlib, it integrates dozens of plotting functions, ranging from classic 2D charts to stunning 3D graphics. It aims to make data visualization simple and professional through a minimalist API.
## ✨ Core Features
* **Rich chart types**: Provides a one-stop solution for over ten professional chart types, including bar charts, pie charts, scatter plots, radar charts, rose charts, heat maps, 3D surface charts, and 3D scatter plots.
* **Minimalist API design**: Most complex charts can be generated with just one line of core code, significantly reducing the cost of learning and usage.
* **Deep customization capability**: Provides parameter control for nearly all visualization elements, from color and label to perspective and lighting, meeting the full-process needs from exploration to publication.
* **Excellent 3D support**: Equipped with a variety of built-in 3D drawing functions and supporting interactive perspective adjustment, it facilitates the creation of 3D data visualization with ease.
* **Seamless ecological integration**: Perfectly compatible with `NumPy` arrays and `Pandas` `DataFrame`, seamlessly integrating into your data analysis workflow.
## 📦 Installation
One-click installation via pip:
```bash
pip install vizpaint
```
## ⚠️ Warning: 
* This project is being prepared for archiving
* Recommended alternative solution:
`NumPy`，`matplotlib`
