<div align="center">

# pykit-dev

### Minimalist, Type-Safe DevOps Library for Python

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Code Style: Ruff](https://img.shields.io/badge/code%20style-ruff-000000.svg)](https://github.com/astral-sh/ruff)
[![Type Checked](https://img.shields.io/badge/mypy-checked-blue)](https://mypy-lang.org/)

<p align="center">
  <b>Standardize your daily DevOps scripts with a clean, unified API.</b><br>
  Built for professionals who need reliability, structured logging, and zero-boilerplate.
</p>

</div>

---

## ⚡ Features

- **🛡️ Robust Runner**: Execute shell commands with built-in retries, timeouts, and safe result handling.
- **⚙️ Environment Manager**: Strict validation, type casting (int, bool, float), and precedence handling (System > .env > Default).
- **💓 Health Checks**: One-line checks for HTTP endpoints, TCP ports, and system processes.
- **📝 Unified Logger**: Professional JSON/Text logging out-of-the-box, ready for Splunk/Datadog.
- **📐 Type Safe**: 100% typed code base compatible with MyPy and VSCode Pylance.

## 🚀 Installation

```bash
pip install pykit-dev
```

## 📚 Quick Start

### 1. Command Execution (Runner)

Execute commands confidently with retry logic and detailed results.

```python
from pykit_dev.runner import run, CommandExecutionError

try:
    # Run with automatic retries and timeout
    result = run("curl https://api.example.com", retry=2, timeout=5)

    print(f"Status: {result.exit_code}")
    print(f"Output: {result.stdout}")

except CommandExecutionError as e:
    print(f"Failed after retries: {e}")
```

### 2. Environment Management (Env)

Forget manual `os.getenv` casting and checking.

```python
from pykit_dev.env import env

# Load from .env file (optional)
env.load(".env")

# Type-safe retrieval
db_url = env.require("DATABASE_URL")             # Raises error if missing
debug = env.get("DEBUG", default=False, cast=bool) # Returns True/False, not "true"
max_conn = env.get("MAX_CONN", default=10, cast=int)
```

### 3. Health Checks

Verify dependencies before starting your application.

```python
from pykit_dev.health import health, HealthCheckFailed

try:
    health.http("https://api.github.com")
    health.tcp("localhost", 5432)
    health.process(1234) # Check by PID
    print("✅ System Healthy")

except HealthCheckFailed as e:
    print(f"❌ Health Check Failed: {e}")
```

### 4. Professional Logging

```python
from pykit_dev.core.logger import logger

logger.info("Deployment started", {"env": "production"})
# Output: {"timestamp": "...", "level": "INFO", "message": "Deployment started", "extra": {"env": "production"}}
```

## 🛠️ Utilities

```python
from pykit_dev.utils import start_timer, slugify

timer = start_timer()
# ... task ...
print(f"Elapsed: {timer.stop()}s")
```

## 🤝 Contributing

Contributions are welcome! Please ensure all code passes `mypy` and `pytest`.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

Distributed under the MIT License. See `LICENSE` for more information.

---

<div align="center">
  Maintained by <a href="https://github.com/F9-o">@F9-o</a>
</div>
