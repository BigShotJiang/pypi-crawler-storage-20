from pathlib import Path
from typing import Dict
from pykit_dev.core.logger import logger
from pykit_dev.core.types import PathLike
import dotenv

def load_dotenv(path: PathLike = ".env", override: bool = False) -> Dict[str, str]:
    """
    Load environment variables using python-dotenv.
    """
    file_path = Path(path)
    if not file_path.exists():
        logger.debug(f".env file not found at {file_path}")
        return {}

    logger.info(f"Loading environment from {file_path}")
    
    # python-dotenv load_dotenv returns True/False
    # but we want to return the values if possible?
    # Actually standard usage is just load into os.environ.
    # But for our API return dict, dotenv.dotenv_values is better.
    
    loaded = dotenv.dotenv_values(file_path)
    
    if override:
        dotenv.load_dotenv(file_path, override=True)
    else:
        dotenv.load_dotenv(file_path)
        
    # Convert to Dict[str, str] and filter None
    return {k: v for k, v in loaded.items() if v is not None}
