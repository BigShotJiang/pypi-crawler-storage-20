import os
from typing import Type, TypeVar, Optional, Any, Union
from pykit_dev.exceptions.env import VariableNotFoundError
from pykit_dev.env.validator import validate_type

T = TypeVar("T")

def get(
    key: str,
    default: Any = None,
    cast: Optional[Type[T]] = None,
    required: bool = False
) -> Union[T, str, None]:
    """
    Get an environment variable with optional casting and validation.
    
    Priority:
    1. System Environment Variable
    2. Default value
    
    Args:
        key: The environment variable name.
        default: Default value if not found.
        cast: Type to cast the value to (int, bool, float, str).
        required: If True, raise VariableNotFoundError if not found and no default.
    """
    value = os.environ.get(key)
    
    if value is None:
        if required and default is None:
            raise VariableNotFoundError(key)
        return default # type: ignore[no-any-return]
        
    if cast:
        # validate_type returns T, which is compatible
        return validate_type(key, value, cast)
        
    return value
    
def require(key: str, cast: Optional[Type[T]] = None) -> Union[T, str]:
    """Shortcut for get(..., required=True)"""
    return get(key, required=True, cast=cast)  # type: ignore[return-value]
