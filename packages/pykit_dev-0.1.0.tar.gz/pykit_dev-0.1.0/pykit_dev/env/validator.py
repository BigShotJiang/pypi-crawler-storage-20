from typing import Any, Type,  TypeVar, Optional
from pykit_dev.exceptions.env import VariableValidationError

T = TypeVar("T")

def validate_type(name: str, value: str, output_type: Type[T]) -> T:
    """
    Casts a string environment value to the specified type.
    """
    try:
        if output_type == bool:
            # Handle common boolean string representations
            lower_val = value.lower()
            if lower_val in ('true', '1', 'yes', 'on'):
                return True # type: ignore
            if lower_val in ('false', '0', 'no', 'off'):
                return False # type: ignore
            raise ValueError(f"Invalid boolean value: {value}")
            
        if output_type == int:
            return int(value) # type: ignore
            
        if output_type == float:
            return float(value) # type: ignore
            
        if output_type == str:
            return value # type: ignore
            
        # Fallback for other types via constructor if possible
        return output_type(value) # type: ignore
        
    except ValueError as e:
        raise VariableValidationError(name, output_type.__name__, value) from e
