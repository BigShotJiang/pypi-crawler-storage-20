from typing import Any, Optional, Type, TypeVar, Union, Dict
from pathlib import Path
from pykit_dev.env import resolver, loader
from pykit_dev.core.types import PathLike

T = TypeVar("T")

class EnvManager:
    """
    Facade for environment management.
    """
    def get(
        self,
        key: str,
        default: Any = None,
        cast: Optional[Type[T]] = None,
        required: bool = False
    ) -> Union[T, str, None]:
        return resolver.get(key, default=default, cast=cast, required=required)

    def require(self, key: str, cast: Optional[Type[T]] = None) -> Union[T, str]:
        return resolver.require(key, cast=cast)

    def load(self, path: PathLike = ".env", override: bool = False) -> Dict[str, str]:
        """Load environment variables from a file."""
        return loader.load_dotenv(path, override=override)

# Singleton instance
env = EnvManager()
