from pydantic import BaseModel, Field

class PyKitConfig(BaseModel):
    """
    Global configuration for pykit-dev library.
    """
    log_level: str = Field(default="INFO", description="Global logging level")
    log_format: str = Field(default="json", description="json or text")
    
    # Execution defaults
    default_timeout: int = Field(default=300, description="Default command timeout in seconds")
    
    model_config = {"frozen": True}

# Global Instance
_config = PyKitConfig()

def get_config() -> PyKitConfig:
    return _config

def configure(new_config: PyKitConfig) -> None:
    global _config
    _config = new_config
