from pathlib import Path
from typing import Union, Dict, Any, List

# Common Type Aliases
PathLike = Union[str, Path]
StrDict = Dict[str, str]
AnyDict = Dict[str, Any]
CommandArgs = Union[str, List[str]]
