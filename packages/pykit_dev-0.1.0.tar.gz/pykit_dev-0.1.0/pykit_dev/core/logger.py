import logging
import json
import sys
from typing import Any, Dict
from pykit_dev.core.config import get_config

class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_data: Dict[str, Any] = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "message": record.getMessage(),
            "module": record.module,
        }
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_data)

def setup_logger(name: str = "pykit_dev") -> logging.Logger:
    config = get_config()
    logger = logging.getLogger(name)
    logger.setLevel(config.log_level.upper())
    
    # Avoid adding multiple handlers if already configured
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        
        if config.log_format.lower() == "json":
            json_formatter = JSONFormatter()
            handler.setFormatter(json_formatter)
        else:
            formatter = logging.Formatter(
                "[%(asctime)s] [%(levelname)s] [%(module)s] %(message)s"
            )
            handler.setFormatter(formatter)
        
        logger.addHandler(handler)
        
    return logger

# Default logger
logger = setup_logger()
