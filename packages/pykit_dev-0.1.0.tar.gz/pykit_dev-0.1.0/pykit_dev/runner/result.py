from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class CommandResult:
    """Represents the result of a command execution."""
    stdout: str
    stderr: str
    exit_code: int
    duration: float
    command: str

    @property
    def is_success(self) -> bool:
        return self.exit_code == 0
    
    def ensure_success(self) -> 'CommandResult':
        """Raises CommandExecutionError if exit_code != 0"""
        if not self.is_success:
            from pykit_dev.exceptions.runner import CommandExecutionError
            raise CommandExecutionError(self.command, self.exit_code, self.stderr)
        return self
