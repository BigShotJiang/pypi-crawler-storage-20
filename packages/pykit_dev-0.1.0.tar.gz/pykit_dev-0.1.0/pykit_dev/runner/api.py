from typing import Optional, Union, List
import time
from pykit_dev.core.types import CommandArgs, StrDict
from pykit_dev.runner.command import Command
from pykit_dev.runner.result import CommandResult
from pykit_dev.core.logger import logger
from pykit_dev.exceptions.runner import RunnerError

def run(
    cmd: CommandArgs,
    cwd: Optional[str] = None,
    env: Optional[StrDict] = None,
    timeout: Optional[int] = None,
    check: bool = False,
    retry: int = 0
) -> CommandResult:
    """
    Execute a command with optional retry logic.

    Args:
        cmd: Command string or list.
        cwd: Working directory.
        env: Environment variables.
        timeout: Timeout in seconds.
        check: If True, raise exception on failure.
        retry: Number of retries on failure.
    """
    attempt = 0
    while True:
        try:
            return Command.run(cmd, cwd=cwd, env=env, timeout=timeout, check=check)
        except Exception as e:
            if attempt < retry:
                attempt += 1
                delay = 1.0 * (2 ** (attempt - 1)) # Simple exponential backoff: 1s, 2s, 4s...
                logger.warning(
                    f"Command failed (attempt {attempt}/{retry}). Retrying in {delay}s... Error: {e}"
                )
                time.sleep(delay)
                continue
            raise e
