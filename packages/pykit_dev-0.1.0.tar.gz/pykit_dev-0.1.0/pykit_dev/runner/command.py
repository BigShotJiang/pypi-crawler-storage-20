import subprocess
import time
import shlex
from typing import Union, List, Optional
from pykit_dev.core.config import get_config
from pykit_dev.core.logger import logger
from pykit_dev.core.types import CommandArgs, StrDict
from pykit_dev.runner.result import CommandResult
from pykit_dev.exceptions.runner import CommandTimeoutError

class Command:
    @staticmethod
    def run(
        cmd: CommandArgs,
        cwd: Optional[str] = None,
        env: Optional[StrDict] = None,
        timeout: Optional[int] = None,
        check: bool = False,
        capture_output: bool = True
    ) -> CommandResult:
        """
        Execute a subprocess command.
        
        Args:
            cmd: Command string or list of arguments.
            cwd: Working directory.
            env: Environment variables.
            timeout: Timeout in seconds (defaults to config).
            check: If True, raise exception on non-zero exit code.
            capture_output: If True, capture stdout/stderr.
        """
        config = get_config()
        timeout = timeout or config.default_timeout

        if isinstance(cmd, str):
            args = shlex.split(cmd)
            cmd_str = cmd
        else:
            args = cmd
            cmd_str = " ".join(args)

        logger.debug(f"Running command: {cmd_str}")
        start_time = time.time()
        
        try:
            # On Windows, shell=True is often needed for internal commands,
            # but for a library, default to False for security/predictability
            # unless explicitly handled. Keeping it False for now.
            # Using subprocess.run for simplicity and safety.
            process = subprocess.run(
                args,
                cwd=cwd,
                env=env,
                capture_output=capture_output,
                text=True,
                timeout=timeout,
                check=False # We handle checking manually
            )
            
            duration = time.time() - start_time
            
            result = CommandResult(
                stdout=process.stdout or "",
                stderr=process.stderr or "",
                exit_code=process.returncode,
                duration=duration,
                command=cmd_str
            )
            
            logger.debug(f"Command '{cmd_str}' finished with exit code {result.exit_code} in {duration:.2f}s")
            
            if check:
                result.ensure_success()
                
            return result
            
        except subprocess.TimeoutExpired:
            logger.error(f"Command '{cmd_str}' timed out after {timeout}s")
            raise CommandTimeoutError(cmd_str, timeout)
            
        except Exception as e:
            logger.error(f"Command execution failed: {e}")
            raise
