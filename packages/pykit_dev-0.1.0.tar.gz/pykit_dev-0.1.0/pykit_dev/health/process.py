import subprocess
import os
from pykit_dev.exceptions.health import HealthCheckFailed

def check_process_exists(pid: int) -> bool:
    """Check if a process exists by PID."""
    if os.name == 'nt':
        # Windows
        try:
            # OpenProcess with PROCESS_QUERY_LIMITED_INFORMATION (0x1000)
            # This is complex in pure python without pywin32. 
            # Simple fallback: use tasklist
            output = subprocess.check_output(
                ["tasklist", "/fi", f"PID eq {pid}", "/nh"], 
                text=True
            )
            return str(pid) in output
        except subprocess.CalledProcessError:
            return False
    else:
        # Poxis
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False

def ensure_process_exists(pid: int) -> None:
    """Raise HealthCheckFailed if process does not exist."""
    if not check_process_exists(pid):
        raise HealthCheckFailed("process_exists", f"Process with PID {pid} not found")
