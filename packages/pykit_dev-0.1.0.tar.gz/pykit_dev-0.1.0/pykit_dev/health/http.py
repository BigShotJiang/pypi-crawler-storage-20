import requests
from typing import Dict, Optional
from pykit_dev.exceptions.health import HealthCheckFailed

def ensure_http_endpoint(
    url: str,
    method: str = "GET",
    headers: Optional[Dict[str, str]] = None,
    timeout: int = 10,
    expected_status: int = 200
) -> None:
    """
    Check HTTP endpoint using requests, raise HealthCheckFailed otherwise.
    """
    try:
        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            timeout=timeout
        )
        if response.status_code != expected_status:
             raise HealthCheckFailed(
                "http_endpoint",
                f"Endpoint {url} check failed. Expected {expected_status}, got {response.status_code}"
            )
    except requests.RequestException as e:
        raise HealthCheckFailed("http_endpoint", f"Connection failed to {url}: {e}")
