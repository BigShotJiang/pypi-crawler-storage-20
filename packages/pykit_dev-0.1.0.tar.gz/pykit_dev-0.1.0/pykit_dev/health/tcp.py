import socket
from pykit_dev.exceptions.health import HealthCheckFailed

def check_tcp_port(host: str, port: int, timeout: int = 5) -> bool:
    """
    Check if a TCP port is open.
    """
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False

def ensure_tcp_port(host: str, port: int, timeout: int = 5) -> None:
    """
    Check if a TCP port is open, raise HealthCheckFailed otherwise.
    """
    if not check_tcp_port(host, port, timeout):
        raise HealthCheckFailed(
            "tcp_port", 
            f"Could not connect to {host}:{port} within {timeout}s"
        )
