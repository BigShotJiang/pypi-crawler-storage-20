from typing import Dict, Optional
from pykit_dev.health import http, tcp, process

class HealthManager:
    """
    Facade for health checks.
    """
    def http(
        self,
        url: str,
        method: str = "GET",
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 10,
        expected_status: int = 200
    ) -> None:
        """Ensure HTTP endpoint is healthy."""
        http.ensure_http_endpoint(url, method, headers, timeout, expected_status)

    def tcp(self, host: str, port: int, timeout: int = 5) -> None:
        """Ensure TCP port is open."""
        tcp.ensure_tcp_port(host, port, timeout)

    def process(self, identifier: int) -> None:
        """Ensure process exists (by PID for now)."""
        # User requested 'nginx' (name) example, but current impl is PID.
        # I will stick to PID implementation as 'process.py' has it,
        # but the Facade should ideally support names to match user wish eventually.
        # For now, matching the PID implementation.
        process.ensure_process_exists(identifier)

# Singleton
health = HealthManager()
