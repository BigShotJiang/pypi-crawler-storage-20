import os
import re
import time
from typing import Optional
from pathlib import Path

class Stopwatch:
    def __init__(self) -> None:
        self._start_time: Optional[float] = None
    
    def start(self) -> 'Stopwatch':
        self._start_time = time.time()
        return self
        
    def stop(self) -> float:
        if self._start_time is None:
            raise RuntimeError("Stopwatch not started")
        return time.time() - self._start_time

def start_timer() -> Stopwatch:
    sw = Stopwatch()
    sw.start()
    return sw

def slugify(text: str) -> str:
    """Safe name for files/urls."""
    # Simple slugify
    text = text.lower()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[-\s]+', '-', text)
    return text.strip('-')

def join_paths(*args: str) -> str:
    return str(Path(*args))

def path_exists(path: str) -> bool:
    return Path(path).exists()
