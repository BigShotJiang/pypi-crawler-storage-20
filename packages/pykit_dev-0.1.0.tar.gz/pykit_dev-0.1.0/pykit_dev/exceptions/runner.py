from .base import PyKitError

class RunnerError(PyKitError):
    """Base class for runner module errors."""
    pass

class CommandExecutionError(RunnerError):
    """Raised when a command fails to execute or returns a non-zero exit code."""
    def __init__(self, command: str, exit_code: int, stderr: str):
        self.command = command
        self.exit_code = exit_code
        self.stderr = stderr
        super().__init__(f"Command '{command}' failed with exit code {exit_code}: {stderr}")

class CommandTimeoutError(RunnerError):
    """Raised when a command times out."""
    def __init__(self, command: str, timeout: int):
        super().__init__(f"Command '{command}' timed out after {timeout} seconds")
