from .base import PyKitError

class EnvError(PyKitError):
    """Base class for env module errors."""
    pass

class VariableNotFoundError(EnvError):
    """Raised when a required environment variable is missing."""
    def __init__(self, var_name: str):
        super().__init__(f"Environment variable '{var_name}' not found")

class VariableValidationError(EnvError):
    """Raised when an environment variable fails validation."""
    def __init__(self, var_name: str, expected_type: str, value: str):
        super().__init__(f"Value '{value}' for '{var_name}' is not of type {expected_type}")
