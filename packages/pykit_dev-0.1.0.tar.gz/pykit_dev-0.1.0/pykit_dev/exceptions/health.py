from .base import PyKitError

class HealthError(PyKitError):
    """Base class for health module errors."""
    pass

class HealthCheckFailed(HealthError):
    """Raised when a specific health check fails."""
    def __init__(self, check_name: str, reason: str):
        super().__init__(f"Health check '{check_name}' failed: {reason}")
