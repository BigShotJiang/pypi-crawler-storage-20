from typing import Optional

class PyKitError(Exception):
    """Base exception for all pykit-dev errors."""
    def __init__(self, message: str, original_error: Optional[Exception] = None):
        super().__init__(message)
        self.original_error = original_error
