import pytest
import os
from pykit_dev.core.config import get_config
from pykit_dev.core.logger import logger
from pykit_dev.runner.command import Command
from pykit_dev.runner.result import CommandResult
from pykit_dev.exceptions.runner import CommandExecutionError

def test_config_singleton():
    cfg1 = get_config()
    cfg2 = get_config()
    assert cfg1 is cfg2

def test_logger_creation():
    assert logger.name == "pykit_dev"

def test_command_echo():
    res = Command.run(["python", "-c", "print('hello')"], capture_output=True)
    assert res.exit_code == 0
    assert "hello" in res.stdout.strip().replace("\r\n", "\n")
    assert res.is_success

def test_command_failure():
    # Attempting to run a non-existent command
    with pytest.raises(Exception):
         Command.run("nonexistent_command_xyz_123")

def test_command_check_ensure_success():
    # If we run a command that exits with 1 (like 'exit 1' in shell, but cross platform is tricky)
    # Using python to simulate exit 1
    cmd = ["python", "-c", "import sys; sys.exit(1)"]
    res = Command.run(cmd, check=False)
    assert res.exit_code == 1
    assert not res.is_success
    
    with pytest.raises(CommandExecutionError):
        res.ensure_success()

