import pytest
import os
from pykit_dev.env import resolver, loader, validator
from pykit_dev.exceptions.env import VariableNotFoundError, VariableValidationError

def test_env_loader(tmp_path):
    env_file = tmp_path / ".env"
    env_file.write_text('TEST_KEY="test_value"\nINT_KEY=42')
    
    loader.load_dotenv(env_file, override=True)
    assert os.environ["TEST_KEY"] == "test_value"
    assert os.environ["INT_KEY"] == "42"

def test_resolver_get():
    os.environ["MY_VAR"] = "100"
    val = resolver.get("MY_VAR", cast=int)
    assert val == 100
    
    # Validation error
    os.environ["BAD_INT"] = "abc"
    with pytest.raises(VariableValidationError):
        resolver.get("BAD_INT", cast=int)

def test_resolver_require():
    if "MISSING_VAR" in os.environ:
        del os.environ["MISSING_VAR"]
        
    with pytest.raises(VariableNotFoundError):
        resolver.require("MISSING_VAR")
