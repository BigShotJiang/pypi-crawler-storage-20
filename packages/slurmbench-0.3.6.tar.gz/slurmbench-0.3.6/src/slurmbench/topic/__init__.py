"""Topics abstract module."""
