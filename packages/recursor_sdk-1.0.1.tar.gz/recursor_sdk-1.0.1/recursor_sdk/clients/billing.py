from typing import Any, Dict, List, Optional

class BillingClientMixin:
    """Mixin for Billing & Usage operations"""

    def get_usage(self) -> Dict[str, Any]:
        """Get current usage statistics"""
        return self._get("/client/billing/usage")

    def get_usage_history(self, days: int = 30, resource_type: Optional[str] = None) -> Dict[str, Any]:
        """Get usage history"""
        params = {"days": days}
        if resource_type:
            params["resource_type"] = resource_type
        return self._get("/client/billing/usage/history", params)

    def list_billing_plans(self) -> List[Dict[str, Any]]:
        """List available billing plans"""
        data = self._get("/client/billing/plans")
        return data.get("plans", []) if isinstance(data, dict) else []

    def get_subscription(self) -> Dict[str, Any]:
        """Get current subscription"""
        return self._get("/client/billing/subscription")
