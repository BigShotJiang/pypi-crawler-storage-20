from typing import Any, Dict

class ActivityLogClientMixin:
    """Mixin for Activity Log operations"""

    def list_activity_logs(self, page: int = 1, page_size: int = 50) -> Dict[str, Any]:
        """List activity logs"""
        return self._get("/client/activity", {"page": page, "page_size": page_size})

    def export_activity_logs(self) -> bytes:
        """Export activity logs as CSV"""
        # Direct client access needed for binary content
        resp = self._client.get(self._url("/client/activity/export"), headers=self._headers)
        resp.raise_for_status()
        return resp.content
