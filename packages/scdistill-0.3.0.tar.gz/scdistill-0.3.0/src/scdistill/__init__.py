"""scDistill: 2-Phase batch correction via knowledge distillation.

scDistill corrects batch effects in scRNA-seq data while preserving
biological variation (e.g., age effects, treatment effects).

Architecture (2-Phase):
    Phase 1: X → Encoder → Z,  Loss = ||Z - Z*||
    Phase 2: Z* → Decoder → X_corrected → Encoder(fixed) → Z',  Loss = ||Z' - Z*||

Where Z* is the teacher's (e.g., Harmony) batch-corrected embeddings.

Quick Start
-----------
>>> from scdistill import Distiller
>>>
>>> model = Distiller(adata, batch_key='batch')
>>> model.train()
>>> Z = model.get_latent_representation()
>>> X_corrected = model.get_corrected_expression()

With Covariate Protection
-------------------------
>>> model = Distiller(adata, batch_key='batch', covariate_key='condition')
>>> model.train()

Using Different Teachers
------------------------
>>> model = Distiller(adata, batch_key='batch', teacher='combat')
>>> model.train()
"""

from .distiller import Distiller
from .nn import Encoder, Decoder
from . import teachers

__version__ = "0.8.0"
__all__ = [
    "Distiller",
    "Encoder",
    "Decoder",
    "teachers",
]
