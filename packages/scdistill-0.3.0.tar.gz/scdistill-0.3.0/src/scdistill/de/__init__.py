"""Differential Expression module for scDistill.

Provides two DE analysis methods using trained encoder/decoder models:

1. **pseudobulk** (default): Sample-level pseudobulk DE analysis with proper
   statistical testing. Recommended for most use cases.

2. **bayesian**: Bayesian MC Dropout DE with uncertainty quantification.

Example
-------
>>> # Using Distiller's wrapper (recommended)
>>> de_results = model.differential_expression(
...     groupby="condition",
...     group1="treated",
...     group2="control",
...     sample_key="patient_id",
... )

>>> # Direct API with config objects
>>> from scdistill.de import differential_expression, PseudobulkConfig
>>> results = differential_expression(
...     idx1=treated_idx,
...     idx2=control_idx,
...     gene_names=genes,
...     encoder=model.encoder,
...     decoder=model.decoder,
...     X_input=X_input,
...     sample_labels=samples,
...     how=PseudobulkConfig(method='deseq2'),
... )
"""

from .differential_expression import (
    differential_expression,
    PseudobulkConfig,
    BayesianConfig,
)

__all__ = [
    'differential_expression',
    'PseudobulkConfig',
    'BayesianConfig',
]
