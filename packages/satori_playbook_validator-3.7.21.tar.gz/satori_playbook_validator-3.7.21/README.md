# satori-playbook-validator


