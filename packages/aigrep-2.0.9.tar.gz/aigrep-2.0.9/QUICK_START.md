# Быстрый старт

**Версия:** 0.7.0

Краткое руководство для быстрого начала работы с obsidian-kb.

> **Для детальной информации:** См. [INSTALLATION.md](INSTALLATION.md), [CONFIGURATION.md](CONFIGURATION.md), [USAGE.md](USAGE.md), [MCP_INTEGRATION.md](MCP_INTEGRATION.md)

## 📦 Установка

> **⚠️ Важно:** obsidian-kb работает только в виртуальном окружении Python. Используйте `uv` для управления зависимостями.

### 1. Установите obsidian-kb

#### Вариант A: Установка из исходников (рекомендуется)

```bash
# Установите uv (если не установлен)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Клонируйте репозиторий
git clone https://github.com/mdemyanov/obsidian-kb.git
cd obsidian-kb

# uv автоматически создаст виртуальное окружение и установит зависимости
uv sync
```

После установки используйте команды через `uv run`:
```bash
uv run obsidian-kb --help
```

#### Вариант B: Установка через PyPI в виртуальное окружение

```bash
# Создайте виртуальное окружение
python3 -m venv .venv

# Активируйте его
source .venv/bin/activate  # macOS/Linux
# или
.venv\Scripts\activate     # Windows

# Установите через uv (рекомендуется)
uv pip install obsidian-kb
```

После активации виртуального окружения используйте команды напрямую:
```bash
obsidian-kb --help
```

> **📖 Подробнее о виртуальных окружениях:** См. [INSTALLATION.md](INSTALLATION.md#1-установка-python)

### 2. Установите и настройте Ollama

**macOS:**
```bash
brew install ollama
brew services start ollama
ollama pull nomic-embed-text
```

**Проверка:**
```bash
ollama list
# Должна быть видна модель nomic-embed-text
```

> Подробнее: [INSTALLATION.md](INSTALLATION.md#2-установка-ollama)

## 🚀 Первые шаги

### 1. Настройте конфигурацию vault'ов

Создайте файл `~/.obsidian-kb/vaults.json`:

```json
{
  "vaults": [
    {
      "name": "my-vault",
      "path": "/path/to/your/obsidian/vault"
    }
  ]
}
```

**Важно:** Замените `/path/to/your/obsidian/vault` на реальный путь к вашему Obsidian vault'у.

### 2. Проиндексируйте vault

```bash
obsidian-kb index-all
```

Эта команда проиндексирует все vault'ы из конфигурации.

### 3. Проверьте статус

```bash
# Список проиндексированных vault'ов
obsidian-kb list-vaults

# Статистика конкретного vault'а
obsidian-kb stats --vault my-vault

# Проверка системы
obsidian-kb doctor
```

### 4. Настройте Claude Desktop (опционально)

Для интеграции с Claude Desktop:

```bash
# Показать конфигурацию
obsidian-kb claude-config

# Применить автоматически
obsidian-kb claude-config --apply
```

После этого перезапустите Claude Desktop.

> Подробнее: [CLAUDE_DESKTOP_SETUP.md](CLAUDE_DESKTOP_SETUP.md)

## 🔍 Использование

### Поиск через CLI

```bash
# Простой поиск
obsidian-kb search --vault my-vault --query "ваш запрос"

# Гибридный поиск (рекомендуется)
obsidian-kb search --vault my-vault --query "ваш запрос" --type hybrid

# Расширенный поиск с фильтрами
obsidian-kb search --vault my-vault --query "Python tags:python created:>2024-01-01"
```

### Использование в Claude Desktop

После настройки Claude Desktop, вы можете использовать инструменты:

- `list_vaults` — список всех проиндексированных vault'ов
- `search_vault("my-vault", "ваш запрос")` — поиск в vault'е
- `vault_stats("my-vault")` — статистика vault'а
- `add_vault_to_config("/path/to/vault", "my-vault")` — добавить vault в конфигурацию (можно просто попросить Claude добавить текущую директорию)
- `check_vault_in_config(vault_path="/path/to/vault")` — проверить, есть ли vault в конфигурации
- `list_configured_vaults()` — список всех настроенных vault'ов из конфигурации
- `reindex_vault("my-vault")` — полная переиндексация vault'а (можно указать путь или использовать путь из конфига)
- `delete_vault("my-vault")` — удалить vault из индекса (файлы не затрагиваются)

## 🔄 Обновление obsidian-kb

После публикации новой версии на PyPI, обновите пакет:

```bash
# Убедитесь, что виртуальное окружение активировано
source .venv/bin/activate

# Обновите через uv
uv pip install --upgrade obsidian-kb

# Проверить версию
obsidian-kb version
```

## 🔄 Автоматическое обновление индекса

Для автоматического отслеживания изменений:

```bash
# Отслеживать все vault'ы
obsidian-kb watch

# Отслеживать конкретный vault
obsidian-kb watch --vault my-vault
```

## ❓ Помощь

```bash
# Справка по командам
obsidian-kb --help

# Справка по конкретной команде
obsidian-kb search --help

# Диагностика проблем
obsidian-kb doctor
```

## 📚 Дополнительная документация

- [INSTALLATION.md](INSTALLATION.md) — установка и настройка
- [CONFIGURATION.md](CONFIGURATION.md) — конфигурация
- [USAGE.md](USAGE.md) — использование CLI и MCP
- [MCP_INTEGRATION.md](MCP_INTEGRATION.md) — интеграция с агентами
- [ADVANCED_SEARCH.md](ADVANCED_SEARCH.md) — расширенный поиск
- [TROUBLESHOOTING.md](TROUBLESHOOTING.md) — решение проблем

## 🐛 Проблемы?

См. [TROUBLESHOOTING.md](TROUBLESHOOTING.md) для решения типичных проблем.

---

**Удачи! 🚀**

