# PLAN.md

Tracks remaining work items. Completed items are deleted; only outstanding work appears here.

## 1. Outstanding Work

### 1.1 Native tools posture finish (post‑unification)

Goal: resolve the remaining `.local/tool_report.md` frictions now that local tools
are already unified as FunctionTools and provider‑level tool parallelism is disabled.

Outcome targets:

- **Machine-first tool surfaces:** all tool failures are typed, path-safe, and
  truncation is unambiguous (no in-band partial markers).
- **Delegation is policy-safe:** `agent_run_report` is small by default, and delegate
  tool availability is explicit and inherits parent policy.

#### 1.1.1 Design + documentation (lands before runtime changes)

- Update `ARCH.md`:
  - `shell` truncation semantics (no in-band markers; explicit metadata fields).
  - `apply_patch` error vocabulary + path redaction rules (no absolute paths).
  - Delegation contracts (`agent_run_report` detail levels + policy inheritance).
  - Read-only ergonomics updates (`tree` `.git` filter, `rg`/`fd` counts, `bat`
    limit_reason, `stat` modified semantics).

#### 1.1.2 Implementation

- `shell` hardening:
  - Remove in-band truncation markers.
  - Emit explicit truncation metadata per command (`stdout_truncated`,
    `stderr_truncated`, `limit_reason`) and aggregate in the tool envelope.
- `apply_patch` hardening:
  - Replace string-only “failed” outputs with typed tool errors when appropriate.
  - Redact absolute paths from error messages; include relative path + stable reason.
- Delegation hardening:
  - Add a typed report “detail level” to `agent_run_report`, defaulting to summary.
  - Omit `reasoning.encrypted_content` by default.
  - Enforce explicit delegate bundles + policy inheritance.
- Read-only ergonomics:
  - `tree`: add `.git` filtering control when `include_hidden=true`.
  - `rg` / `fd`: include total counts alongside first-page results.
  - `bat`: add `limit_reason` distinguishing line vs char limits.
  - `stat`: clarify `modified` semantics for directories.

#### 1.1.3 Validation

- Add contract tests for:
  - `shell` truncation metadata + absence of in-band markers at tiny budgets.
  - `apply_patch` typed failures and absolute-path redaction.
  - `fn:parallel` allowlist enforcement, determinism, ordering, and clamping.
  - Delegation defaults (summary mode excludes `reasoning.encrypted_content`).
  - Read-only ergonomics (new count/limit fields + `.git` filtering behavior).
- Run gates: `uv run devtools/gate.py` once after final changes.

### 1.2 DEFERRED: Lifecycle spec alignment

- Refine `.local/lifecycle.md` and align runtime + `ARCH.md` lifecycle contracts.
  - Reason: the tools posture overhaul is higher leverage and unblocks safer agent
    iteration across providers.

## 2. Future Enhancements

Reserved for user-approved feature work. Items are added only after explicit approval in VISION.md.
