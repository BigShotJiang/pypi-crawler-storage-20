"""Native parallel FunctionTool for safe read-only tool fanout."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import TYPE_CHECKING, Final

from agents.tool import FunctionTool
from agents.tool_context import ToolContext

from agenterm.core.errors import AgentermError, OperationCancelledError, ValidationError
from agenterm.core.json_codec import (
    as_str,
    dumps_compact,
    parse_json_object,
    require_json_object,
    require_json_value,
)
from agenterm.core.tool_output_envelope import (
    FunctionToolOutputEnvelope,
    ToolOutputError,
    parse_function_tool_output_envelope,
)
from agenterm.engine.cli_tools.shared import (
    INVALID_INPUT_KIND,
    TOOL_ERROR_KIND,
    error_output,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_parallel

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agenterm.config.tools_policy import ParallelToolConfig
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_ALLOWED_TOOLS: Final[tuple[str, ...]] = ("rg", "fd", "bat", "tree", "stat")

_PARALLEL_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Run multiple read-only tools concurrently.",
    "properties": {
        "calls": {
            "type": "array",
            "minItems": 1,
            "description": "Ordered list of tool calls to execute.",
            "items": {
                "type": "object",
                "properties": {
                    "tool": {
                        "type": "string",
                        "description": "Tool name (rg|fd|bat|tree|stat).",
                    },
                    "arguments": {
                        "type": "string",
                        "description": "JSON-encoded tool arguments object.",
                    },
                },
                "required": ["tool", "arguments"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["calls"],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class _ParallelCall:
    index: int
    tool_name: str
    arguments: dict[str, JSONValue]
    tool: FunctionTool


def _invalid_input(
    message: str,
    *,
    details: Mapping[str, JSONValue] | None = None,
) -> str:
    return error_output(
        "parallel",
        kind=INVALID_INPUT_KIND,
        message=message,
        details=dict(details) if details is not None else None,
    )


def _parse_parallel_payload(
    raw: str,
    *,
    max_calls: int,
    tools: Mapping[str, FunctionTool],
) -> tuple[list[_ParallelCall] | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    error: str | None = None
    calls: list[_ParallelCall] | None = None
    if payload is None:
        error = _invalid_input("Invalid parallel payload.")
    elif set(payload) - {"calls"}:
        error = _invalid_input("parallel payload contains unknown keys.")
    else:
        calls_raw = payload.get("calls")
        if not isinstance(calls_raw, list) or not calls_raw:
            error = _invalid_input("parallel.calls must be a non-empty list.")
        elif len(calls_raw) > max_calls:
            error = _invalid_input(
                "parallel.calls exceeds max_calls.",
                details={"max_calls": max_calls},
            )
        else:
            calls = []
            for idx, entry in enumerate(calls_raw):
                call, call_error = _parse_call_entry(entry, idx=idx, tools=tools)
                if call_error is not None:
                    error = call_error
                    break
                if call is None:
                    error = _invalid_input("Invalid parallel.calls entry.")
                    break
                calls.append(call)
    return calls, error


def _parse_call_entry(
    entry: JSONValue,
    *,
    idx: int,
    tools: Mapping[str, FunctionTool],
) -> tuple[_ParallelCall | None, str | None]:
    call: _ParallelCall | None = None
    error: str | None = None
    if not isinstance(entry, dict):
        error = _invalid_input(
            "parallel.calls entries must be objects.",
            details={"index": idx},
        )
    elif set(entry) - {"tool", "arguments"}:
        error = _invalid_input(
            "parallel.calls entry contains unknown keys.",
            details={"index": idx},
        )
    else:
        tool_name = as_str(entry.get("tool"))
        if not tool_name:
            error = _invalid_input(
                "parallel.calls tool must be a non-empty string.",
                details={"index": idx},
            )
        elif tool_name not in _ALLOWED_TOOLS:
            error = _invalid_input(
                "parallel.calls tool is not allowed.",
                details={"index": idx, "tool": tool_name},
            )
        else:
            tool = tools.get(tool_name)
            if tool is None:
                error = _invalid_input(
                    "parallel.calls tool is not available.",
                    details={"index": idx, "tool": tool_name},
                )
            else:
                raw_args = entry.get("arguments")
                arguments: dict[str, JSONValue] | None = None
                if isinstance(raw_args, str):
                    parsed = parse_json_object(raw_args)
                    arguments = parsed if parsed is not None else None
                if arguments is None:
                    error = _invalid_input(
                        "parallel.calls arguments must be a JSON object string.",
                        details={
                            "index": idx,
                            "tool": tool_name,
                        },
                    )
                else:
                    call = _ParallelCall(
                        index=idx,
                        tool_name=tool_name,
                        arguments=arguments,
                        tool=tool,
                    )
    return call, error


def _normalize_subtool_output(
    *,
    tool_name: str,
    output: JSONValue,
) -> FunctionToolOutputEnvelope:
    if isinstance(output, str):
        parsed = parse_function_tool_output_envelope(output)
        if parsed is not None:
            return parsed
        return FunctionToolOutputEnvelope(
            tool=tool_name,
            ok=True,
            payload={"text": output},
        )
    try:
        value = require_json_value(
            value=output,
            context=f"parallel.output.{tool_name}",
        )
    except ValidationError as exc:
        return FunctionToolOutputEnvelope(
            tool=tool_name,
            ok=False,
            payload={},
            error=ToolOutputError(
                kind=TOOL_ERROR_KIND,
                message=str(exc),
                details={},
            ),
        )
    return FunctionToolOutputEnvelope(
        tool=tool_name,
        ok=True,
        payload={"result": value},
    )


async def _run_call(
    ctx: ToolContext[ToolRuntimeContext],
    *,
    call: _ParallelCall,
    call_id: str,
    semaphore: asyncio.Semaphore,
) -> FunctionToolOutputEnvelope:
    cancel_token = ctx.context.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    async with semaphore:
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        args_json = dumps_compact(
            require_json_object(
                value=call.arguments,
                context=f"parallel.arguments.{call.tool_name}",
            ),
            ensure_ascii=True,
            context=f"parallel.arguments.{call.tool_name}",
        )
        tool_ctx = ToolContext(
            context=ctx.context,
            usage=ctx.usage,
            tool_name=call.tool_name,
            tool_call_id=call_id,
            tool_arguments=args_json,
            tool_call=None,
        )
        try:
            output = await call.tool.on_invoke_tool(tool_ctx, args_json)
        except OperationCancelledError:
            raise
        except AgentermError as exc:
            return FunctionToolOutputEnvelope(
                tool=call.tool_name,
                ok=False,
                payload={},
                error=ToolOutputError(
                    kind=TOOL_ERROR_KIND,
                    message=str(exc),
                    details={},
                ),
            )
        return _normalize_subtool_output(tool_name=call.tool_name, output=output)


def build_parallel_tool(
    cfg: ParallelToolConfig | None,
    *,
    tools: Mapping[str, FunctionTool],
) -> FunctionTool | None:
    """Build the parallel FunctionTool when configured."""
    if cfg is None:
        return None
    validate_strict_schema("parallel", _PARALLEL_SCHEMA)
    allowed_tools = {
        name: tool for name, tool in tools.items() if name in _ALLOWED_TOOLS
    }

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        cancel_token = ctx.context.cancel_token
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        calls, error = _parse_parallel_payload(
            raw,
            max_calls=cfg.max_calls,
            tools=allowed_tools,
        )
        if error is not None or calls is None:
            return error or _invalid_input("Invalid parallel payload.")

        concurrency = max(1, int(cfg.max_concurrency))
        semaphore = asyncio.Semaphore(concurrency)
        tasks: list[asyncio.Task[FunctionToolOutputEnvelope]] = []
        for call in calls:
            call_id = f"{ctx.tool_call_id}:{call.index}"
            tasks.append(
                asyncio.create_task(
                    _run_call(ctx, call=call, call_id=call_id, semaphore=semaphore)
                )
            )
        try:
            results = await asyncio.gather(*tasks)
        except OperationCancelledError:
            for task in tasks:
                task.cancel()
            raise

        output_calls: list[JSONValue] = []
        ok_count = 0
        for call, result in zip(calls, results, strict=True):
            if result.ok:
                ok_count += 1
            output_calls.append(
                {
                    "tool": call.tool_name,
                    "call_id": f"{ctx.tool_call_id}:{call.index}",
                    "arguments": dict(call.arguments),
                    "output": result.to_json(),
                }
            )
        payload: dict[str, JSONValue] = {
            "calls": output_calls,
            "summary": {
                "requested": len(output_calls),
                "ok": ok_count,
                "failed": len(output_calls) - ok_count,
            },
        }
        return FunctionToolOutputEnvelope(
            tool="parallel",
            ok=True,
            payload=payload,
        ).to_json_string()

    return FunctionTool(
        name="parallel",
        description=describe_parallel(),
        params_json_schema=_PARALLEL_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_parallel_tool",)
