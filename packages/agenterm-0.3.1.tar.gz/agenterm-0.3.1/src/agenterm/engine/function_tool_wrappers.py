"""Portable FunctionTool wrappers for local tool executors."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

from agents.editor import ApplyPatchOperation, ApplyPatchResult
from agents.tool import (
    FunctionTool,
    ShellActionRequest,
    ShellCallData,
    ShellCommandRequest,
    ShellResult,
)

from agenterm.core.errors import AgentermError
from agenterm.core.json_codec import as_str, parse_json_object
from agenterm.core.platform import is_macos
from agenterm.core.tool_output_envelope import (
    FunctionToolOutputEnvelope,
    ToolOutputError,
)
from agenterm.engine.apply_patch_editor import WorkspaceEditor
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.shell_executor import run_shell_sandboxed
from agenterm.engine.tool_descriptions import describe_apply_patch, describe_shell

if TYPE_CHECKING:
    from collections.abc import Mapping
    from pathlib import Path

    from agents.editor import ApplyPatchOperationType
    from agents.tool_context import ToolContext

    from agenterm.config.tool_models import ApplyPatchToolConfig, ShellToolConfig
    from agenterm.core.approvals import PatchApprovalManager, ShellApprovalManager
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_INVALID_INPUT_KIND = "invalid_input"
_TOOL_ERROR_KIND = "tool_error"

_SHELL_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Shell execution parameters (sandboxed).",
    "properties": {
        "commands": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 1,
            "description": "Shell commands to run sequentially.",
        },
        "description": {
            "type": ["string", "null"],
            "description": "Approval/audit label shown to the user.",
        },
        "cwd": {
            "type": ["string", "null"],
            "description": "Workspace-relative working directory override.",
        },
        "timeout_ms": {
            "type": ["integer", "null"],
            "minimum": 0,
            "description": "Per-command timeout in milliseconds (null uses config).",
        },
        "max_output_length": {
            "type": ["integer", "null"],
            "minimum": 0,
            "description": "Max stdout+stderr chars per command (null uses config).",
        },
    },
    "required": ["commands"],
    "additionalProperties": False,
}

_APPLY_PATCH_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "ApplyPatch operation parameters.",
    "properties": {
        "description": {
            "type": ["string", "null"],
            "description": "Approval/audit label shown to the user.",
        },
        "operation": {
            "type": "object",
            "description": "Patch operation to apply in the workspace.",
            "properties": {
                "type": {
                    "type": "string",
                    "enum": ["create_file", "update_file", "delete_file"],
                    "description": "Operation kind.",
                },
                "path": {
                    "type": "string",
                    "description": "Workspace-relative file path.",
                },
                "diff": {
                    "type": ["string", "null"],
                    "description": (
                        "V4A diff; required for create/update, omit for delete."
                    ),
                },
            },
            "required": ["type", "path"],
            "additionalProperties": False,
        },
    },
    "required": ["operation"],
    "additionalProperties": False,
}


def _error_output(
    tool: str,
    *,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
) -> str:
    err = ToolOutputError(
        kind=kind,
        message=message,
        details=dict(details) if details is not None else {},
    )
    env = FunctionToolOutputEnvelope(
        tool=tool,
        ok=False,
        payload={},
        error=err,
    )
    return env.to_json_string()


def _parse_commands(payload: Mapping[str, JSONValue]) -> list[str] | None:
    commands_raw = payload.get("commands")
    if not isinstance(commands_raw, list) or not commands_raw:
        return None
    commands: list[str] = []
    for item in commands_raw:
        if not isinstance(item, str):
            return None
        cmd = item.strip()
        if not cmd:
            return None
        commands.append(cmd)
    return commands


def _parse_optional_nonneg_int(
    value: JSONValue | None,
) -> int | None | Literal["invalid"]:
    if value is None:
        return None
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        return "invalid"
    return int(value)


def _parse_patch_op_type(value: JSONValue | None) -> ApplyPatchOperationType | None:
    if value == "create_file":
        return "create_file"
    if value == "update_file":
        return "update_file"
    if value == "delete_file":
        return "delete_file"
    return None


def _parse_patch_path(value: JSONValue | None) -> str | None:
    if not isinstance(value, str):
        return None
    path = value.strip()
    return path if path else None


def _parse_apply_patch_operation(
    payload: Mapping[str, JSONValue],
) -> tuple[ApplyPatchOperationType, str, str | None] | None:
    op_raw = payload.get("operation")
    if not isinstance(op_raw, dict):
        return None
    allowed = {"type", "path", "diff"}
    unknown = {str(k) for k in op_raw if str(k) not in allowed}
    if unknown:
        return None
    op_type = _parse_patch_op_type(op_raw.get("type"))
    path = _parse_patch_path(op_raw.get("path"))
    if op_type is None or path is None:
        return None
    diff_raw = op_raw.get("diff")
    diff: str | None = None
    if op_type in {"create_file", "update_file"}:
        if not isinstance(diff_raw, str):
            return None
        diff = diff_raw
    elif diff_raw is not None:
        return None
    return op_type, path, diff


def _shell_payload(
    raw: str,
) -> tuple[list[str], int | None, int | None, str | None, str | None] | None:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None
    allowed = {"commands", "description", "cwd", "timeout_ms", "max_output_length"}
    unknown = {str(k) for k in payload if str(k) not in allowed}
    if unknown:
        return None
    commands = _parse_commands(payload)
    if commands is None:
        return None
    description = None
    desc_raw = as_str(payload.get("description"))
    if isinstance(desc_raw, str):
        desc_clean = desc_raw.strip()
        description = desc_clean if desc_clean else None
    cwd = None
    cwd_raw = as_str(payload.get("cwd"))
    if isinstance(cwd_raw, str):
        cwd_clean = cwd_raw.strip()
        cwd = cwd_clean if cwd_clean else None
    timeout_ms = _parse_optional_nonneg_int(payload.get("timeout_ms"))
    if timeout_ms == "invalid":
        return None
    max_output_length = _parse_optional_nonneg_int(payload.get("max_output_length"))
    if max_output_length == "invalid":
        return None
    return commands, timeout_ms, max_output_length, description, cwd


def _apply_patch_payload(
    raw: str,
) -> tuple[ApplyPatchOperationType, str, str | None] | None:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None
    if set(payload) - {"operation", "description"}:
        return None
    desc_raw = payload.get("description")
    if desc_raw is not None and not isinstance(desc_raw, str):
        return None
    parsed = _parse_apply_patch_operation(payload)
    if parsed is None:
        return None
    op_type, path, diff = parsed
    return op_type, path, diff


def _shell_payload_from_result(
    *,
    commands: list[str],
    result: ShellResult,
) -> dict[str, JSONValue]:
    outputs: list[JSONValue] = [
        {
            "command": item.command or "",
            "stdout": item.stdout,
            "stderr": item.stderr,
            "outcome": {
                "type": item.outcome.type,
                "exit_code": item.outcome.exit_code,
            },
            "truncated": bool(
                isinstance(item.provider_data, dict)
                and item.provider_data.get("truncated") is True
            ),
        }
        for item in result.output
    ]
    provider = dict(result.provider_data or {})
    working_directory = provider.get("working_directory")
    if not isinstance(working_directory, str):
        working_directory = None
    return {
        "commands": list(commands),
        "outputs": outputs,
        "max_output_length": result.max_output_length,
        "working_directory": working_directory,
    }


def _apply_patch_payload_from_result(
    *,
    op_type: ApplyPatchOperationType,
    path: str,
    result: ApplyPatchResult | str | None,
) -> dict[str, JSONValue]:
    status: str | None = None
    output: str | None = None
    if isinstance(result, ApplyPatchResult):
        status = result.status
        output = result.output
    elif isinstance(result, str):
        status = "completed"
        output = result
    return {
        "operation": {"type": op_type, "path": path},
        "status": status,
        "output": output,
    }


def build_shell_function_tool(
    cfg: ShellToolConfig | None,
    *,
    workspace_root: Path,
    approvals: ShellApprovalManager,
) -> FunctionTool | None:
    """Build a portable FunctionTool wrapper for the local shell executor."""
    if not is_macos():
        return None
    if cfg is None:
        return None
    validate_strict_schema("shell", _SHELL_SCHEMA)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        cancel_token = ctx.context.cancel_token
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        parsed = _shell_payload(raw)
        if parsed is None:
            return _error_output(
                "shell",
                kind=_INVALID_INPUT_KIND,
                message="Invalid shell payload.",
            )
        commands, timeout_ms, max_output_length, description, cwd = parsed
        data = ShellCallData(
            call_id=ctx.tool_call_id,
            action=ShellActionRequest(
                commands=commands,
                timeout_ms=timeout_ms,
                max_output_length=max_output_length,
            ),
            raw={
                "description": description,
                "cwd": cwd,
            },
        )
        request = ShellCommandRequest(ctx_wrapper=ctx, data=data)
        try:
            result = await run_shell_sandboxed(
                request,
                tool_cfg=cfg,
                workspace_root=workspace_root,
                approvals=approvals,
                cancel_token=cancel_token,
            )
        except AgentermError as exc:
            return _error_output(
                "shell",
                kind=_TOOL_ERROR_KIND,
                message=str(exc),
            )
        payload = _shell_payload_from_result(commands=commands, result=result)
        return FunctionToolOutputEnvelope(
            tool="shell",
            ok=True,
            payload=payload,
        ).to_json_string()

    return FunctionTool(
        name="shell",
        description=describe_shell(),
        params_json_schema=_SHELL_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


def build_apply_patch_function_tool(
    cfg: ApplyPatchToolConfig | None,
    *,
    workspace_root: Path,
    approvals: PatchApprovalManager,
) -> FunctionTool | None:
    """Build a portable FunctionTool wrapper for apply_patch."""
    if cfg is None:
        return None
    validate_strict_schema("apply_patch", _APPLY_PATCH_SCHEMA)
    editor = WorkspaceEditor(workspace_root, approvals)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        cancel_token = ctx.context.cancel_token
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        parsed = _apply_patch_payload(raw)
        if parsed is None:
            return _error_output(
                "apply_patch",
                kind=_INVALID_INPUT_KIND,
                message="Invalid apply_patch payload.",
            )
        op_type, path, diff = parsed
        operation = ApplyPatchOperation(
            type=op_type,
            path=path,
            diff=diff,
            ctx_wrapper=ctx,
        )
        try:
            if op_type == "create_file":
                result = await editor.create_file(operation)
            elif op_type == "update_file":
                result = await editor.update_file(operation)
            else:
                result = await editor.delete_file(operation)
        except AgentermError as exc:
            return _error_output(
                "apply_patch",
                kind=_TOOL_ERROR_KIND,
                message=str(exc),
            )
        payload = _apply_patch_payload_from_result(
            op_type=op_type,
            path=path,
            result=result,
        )
        return FunctionToolOutputEnvelope(
            tool="apply_patch",
            ok=True,
            payload=payload,
        ).to_json_string()

    return FunctionTool(
        name="apply_patch",
        description=describe_apply_patch(),
        params_json_schema=_APPLY_PATCH_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_apply_patch_function_tool", "build_shell_function_tool")
