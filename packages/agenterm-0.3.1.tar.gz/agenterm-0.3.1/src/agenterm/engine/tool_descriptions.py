"""Unified, model-facing tool descriptions for built-in tools."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ToolDescriptionParts:
    """Template parts for a model-facing tool description."""

    purpose: str
    inputs: str
    defaults: str
    behavior: str
    outputs: str
    errors: str


def render_tool_description(parts: ToolDescriptionParts) -> str:
    """Render a consistent multi-line tool description."""
    lines = [
        f"Purpose: {parts.purpose}",
        f"Inputs: {parts.inputs}",
        f"Defaults: {parts.defaults}",
        f"Behavior: {parts.behavior}",
        f"Outputs: {parts.outputs}",
        f"Errors: {parts.errors}",
    ]
    return "\n".join(lines)


def describe_rg() -> str:
    """Return the model-facing rg description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Search workspace text with ripgrep.",
            inputs=(
                "pattern (required), paths, literal, case_sensitive, smart_case, "
                "before, after, context, include_hidden, no_ignore, glob, result_mode, "
                "offset, limit, max_line_chars."
            ),
            defaults="Optional fields use schema defaults; paths default to ['.'].",
            behavior=(
                "Workspace-relative paths only; deterministic ordering; paged results; "
                "honors ignore files unless no_ignore is true."
            ),
            outputs="matches/files/counts plus page and coverage.",
            errors=(
                "invalid_input for bad payload/paths; tool_error for command failures."
            ),
        )
    )


def describe_fd() -> str:
    """Return the model-facing fd description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Find files and directories under the workspace.",
            inputs=(
                "pattern (null matches all), paths, max_depth, mode, type, "
                "include_hidden, no_ignore, exclude, offset, limit."
            ),
            defaults="Optional fields use schema defaults; paths default to ['.'].",
            behavior="Workspace-relative paths only; results are unique and sorted.",
            outputs="matches plus page and coverage.",
            errors=(
                "invalid_input for bad payload/paths; tool_error for command failures."
            ),
        )
    )


def describe_bat() -> str:
    """Return the model-facing bat description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Preview file contents with line numbers.",
            inputs="path (required), start_line, limit_lines, max_chars.",
            defaults=(
                "start_line defaults to 1; limit_lines/max_chars use schema defaults."
            ),
            behavior="Workspace-relative file paths only; bounded output.",
            outputs="lines, total_lines, chars, and page cursor.",
            errors="invalid_input for bad payload/path; tool_error for read failures.",
        )
    )


def describe_tree() -> str:
    """Return the model-facing tree description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Render a directory tree with structured nodes.",
            inputs=(
                "path, depth, pattern_glob, match_dirs, include_hidden, "
                "dirs_only, gitignore."
            ),
            defaults="path defaults to '.'; depth and flags use schema defaults.",
            behavior="Workspace-relative paths only; bounded traversal depth.",
            outputs="tree string, nodes list, and stats counts.",
            errors=(
                "invalid_input for bad payload/paths; tool_error for command failures."
            ),
        )
    )


def describe_stat() -> str:
    """Return the model-facing stat description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Return file or directory metadata.",
            inputs="paths (required), include_lines.",
            defaults="include_lines defaults to true.",
            behavior="Workspace-relative paths only; directories include totals.",
            outputs="results array with per-path metadata.",
            errors="invalid_input for bad payload/paths; not_found for missing paths.",
        )
    )


def describe_shell() -> str:
    """Return the model-facing shell description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Run shell commands in a macOS Seatbelt sandbox.",
            inputs=(
                "commands (required), cwd, timeout_ms, max_output_length, description."
            ),
            defaults=(
                "cwd defaults to workspace root; timeouts/limits use tool defaults."
            ),
            behavior=(
                "Commands run sequentially, stop on error/timeout, require "
                "approval; do not edit files (use apply_patch)."
            ),
            outputs=(
                "commands, outputs (stdout/stderr/outcome), working_directory, "
                "max_output_length."
            ),
            errors="invalid_input for bad payload; tool_error for executor failures.",
        )
    )


def describe_apply_patch() -> str:
    """Return the model-facing apply_patch description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Apply V4A diffs to workspace files.",
            inputs="operation {type, path, diff}, description.",
            defaults="diff required for create/update; omit for delete.",
            behavior=(
                "Use for file edits; workspace-relative paths only; requires approval."
            ),
            outputs="operation, status, output message.",
            errors="invalid_input for bad payload; tool_error for editor failures.",
        )
    )


def describe_parallel() -> str:
    """Return the model-facing parallel description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Run multiple read-only tools concurrently.",
            inputs="calls[{tool, arguments}] where arguments is JSON-encoded.",
            defaults=(
                "calls required; fanout and concurrency are capped by tool config."
            ),
            behavior=(
                "Output order matches input order; only rg/fd/bat/tree/stat allowed."
            ),
            outputs="calls[{tool, call_id, arguments, output}] plus summary counts.",
            errors="invalid_input for bad payload or unsupported tools.",
        )
    )


def describe_update_plan() -> str:
    """Return the model-facing update_plan description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Update the plan shown to the user.",
            inputs="steps (full list), explanation, allow_empty.",
            defaults="allow_empty defaults to false unless set.",
            behavior="Enforces one in_progress step; requires active session/branch.",
            outputs=(
                "plan_state, steps, explanation, revision, plan_created_at, "
                "plan_updated_at."
            ),
            errors=(
                "invalid_input for validation issues; tool_error on storage failure."
            ),
        )
    )


def describe_get_plan() -> str:
    """Return the model-facing get_plan description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Fetch the current plan snapshot.",
            inputs="empty object.",
            defaults="none.",
            behavior="Requires active session/branch.",
            outputs=(
                "plan_state, steps, explanation, revision, plan_created_at, "
                "plan_updated_at."
            ),
            errors=(
                "invalid_input if payload is not empty; tool_error on storage failure."
            ),
        )
    )


def describe_agent_run() -> str:
    """Return the model-facing agent_run description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Run a one-shot delegated agent.",
            inputs="model, instructions, input.",
            defaults="delegate tool bundle comes from config.",
            behavior="Runs a bounded sub-agent and returns a summary plus report id.",
            outputs=(
                "summary, report_id, response_id, tool_counts, truncated, warnings."
            ),
            errors="tool_error for run failures.",
        )
    )


def describe_agent_run_report() -> str:
    """Return the model-facing agent_run_report description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Fetch a stored agent_run report by report_id.",
            inputs="report_id (required).",
            defaults="none.",
            behavior="Loads report from the local store.",
            outputs="report_id and full report payload.",
            errors=(
                "invalid_input for bad payload; not_found when missing; "
                "tool_error on load."
            ),
        )
    )


def describe_steward() -> str:
    """Return the model-facing steward description."""
    return render_tool_description(
        ToolDescriptionParts(
            purpose="Create a Steward snapshot or compaction branch.",
            inputs=(
                "JSON string object: task ('snapshot'|'compaction'), optional "
                "turn_range, model, instructions, schema_version."
            ),
            defaults="schema_version defaults to 1; optional fields use tool defaults.",
            behavior=(
                "Requires active session; compaction falls back to snapshot on failure."
            ),
            outputs=(
                "schema_version, task_id, kind, session_id, branch_id, "
                "snapshot_branch_id, response_id, model, status."
            ),
            errors="invalid_input for bad payload; tool_error for execution failures.",
        )
    )


__all__ = (
    "ToolDescriptionParts",
    "describe_agent_run",
    "describe_agent_run_report",
    "describe_apply_patch",
    "describe_bat",
    "describe_fd",
    "describe_get_plan",
    "describe_parallel",
    "describe_rg",
    "describe_shell",
    "describe_stat",
    "describe_steward",
    "describe_tree",
    "describe_update_plan",
    "render_tool_description",
)
