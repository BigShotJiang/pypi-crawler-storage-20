"""Built-in get_plan tool for plan retrieval."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.core.errors import ToolExecutionError
from agenterm.core.json_codec import parse_json_object
from agenterm.core.tool_output_envelope import (
    FunctionToolOutputEnvelope,
    ToolOutputError,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_get_plan
from agenterm.store.async_db import AsyncStore
from agenterm.store.plan.repo import get_plan_series

if TYPE_CHECKING:
    from agents.tool_context import ToolContext

    from agenterm.config.model import GetPlanToolConfig
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_GET_PLAN_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "No parameters; send an empty object.",
    "properties": {},
    "additionalProperties": False,
}

_INVALID_MESSAGE = "Invalid get_plan payload."
_INVALID_INPUT_KIND = "invalid_input"


def _error_output(message: str) -> str:
    err = ToolOutputError(
        kind=_INVALID_INPUT_KIND,
        message=message,
        details={"reason": "invalid_payload"},
    )
    env = FunctionToolOutputEnvelope(
        tool="get_plan",
        ok=False,
        payload={},
        error=err,
    )
    return env.to_json_string()


def build_get_plan_tool(
    cfg: GetPlanToolConfig | None,
) -> FunctionTool | None:
    """Build the get_plan tool when configured."""
    if cfg is None:
        return None

    validate_strict_schema("get_plan", _GET_PLAN_SCHEMA)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        cancel_token = ctx.context.cancel_token
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        payload = parse_json_object(raw) if raw else {}
        if payload is None or payload:
            return _error_output(_INVALID_MESSAGE)
        session_id = ctx.context.session_id
        branch_id = ctx.context.branch_id
        if not session_id or not branch_id:
            msg = "get_plan requires a session id and branch id"
            raise ToolExecutionError(msg)
        series = await get_plan_series(
            store=AsyncStore(ctx.context.db_path),
            session_id=session_id,
            branch_id=branch_id,
        )
        payload_out = series.to_json()
        env = FunctionToolOutputEnvelope(
            tool="get_plan",
            ok=True,
            payload=payload_out,
        )
        return env.to_json_string()

    return FunctionTool(
        name="get_plan",
        description=describe_get_plan(),
        params_json_schema=_GET_PLAN_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_get_plan_tool",)
