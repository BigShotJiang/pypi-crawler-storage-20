"""Local agent_run_report tool for retrieving stored agent_run reports."""

from __future__ import annotations

from typing import TYPE_CHECKING

from agents.tool import FunctionTool

from agenterm.artifacts.agent_run import load_agent_run_report
from agenterm.core.errors import AgentermError
from agenterm.core.json_codec import as_str, parse_json_object
from agenterm.core.tool_output_envelope import (
    FunctionToolOutputEnvelope,
    ToolOutputError,
)
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_agent_run_report
from agenterm.store.async_db import AsyncStore

if TYPE_CHECKING:
    from collections.abc import Mapping

    from agents.tool_context import ToolContext

    from agenterm.config.tools_policy import AgentRunReportToolConfig
    from agenterm.core.json_types import JSONValue
    from agenterm.core.plan import ToolRuntimeContext

_INVALID_INPUT_KIND = "invalid_input"
_NOT_FOUND_KIND = "not_found"
_TOOL_ERROR_KIND = "tool_error"

_AGENT_RUN_REPORT_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Lookup parameters for a stored agent_run report.",
    "properties": {
        "report_id": {
            "type": "string",
            "description": "Report ID returned by agent_run.",
        },
    },
    "required": ["report_id"],
    "additionalProperties": False,
}


def _error_output(
    *,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
) -> str:
    err = ToolOutputError(
        kind=kind,
        message=message,
        details=dict(details) if details is not None else {},
    )
    env = FunctionToolOutputEnvelope(
        tool="agent_run_report",
        ok=False,
        payload={},
        error=err,
    )
    return env.to_json_string()


def _parse_report_id(raw: str) -> tuple[str | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None, "invalid_payload"
    if set(payload) - {"report_id"}:
        return None, "invalid_payload"
    report_id = as_str(payload.get("report_id"))
    if report_id is None or not report_id.strip():
        return None, "missing_report_id"
    return report_id, None


def build_agent_run_report_tool(
    cfg: AgentRunReportToolConfig | None,
) -> FunctionTool | None:
    """Build the agent_run_report tool when configured."""
    if cfg is None:
        return None
    validate_strict_schema("agent_run_report", _AGENT_RUN_REPORT_SCHEMA)

    async def _invoke(ctx: ToolContext[ToolRuntimeContext], raw: str) -> str:
        cancel_token = ctx.context.cancel_token
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        report_id, error = _parse_report_id(raw)
        if error is not None or report_id is None:
            if error == "missing_report_id":
                return _error_output(
                    kind=_INVALID_INPUT_KIND,
                    message="agent_run_report requires report_id.",
                    details={"field": "report_id", "reason": "missing_field"},
                )
            return _error_output(
                kind=_INVALID_INPUT_KIND,
                message="Invalid agent_run_report payload.",
                details={"reason": "invalid_payload"},
            )
        try:
            report = await load_agent_run_report(
                store=AsyncStore(ctx.context.db_path),
                artifact_id=report_id,
            )
        except AgentermError as exc:
            return _error_output(
                kind=_TOOL_ERROR_KIND,
                message=str(exc),
                details={"reason": "report_load_failed"},
            )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        if report is None:
            return _error_output(
                kind=_NOT_FOUND_KIND,
                message="agent_run_report not found.",
                details={
                    "field": "report_id",
                    "reason": "not_found",
                    "report_id": report_id,
                },
            )
        payload: dict[str, JSONValue] = {
            "report_id": report_id,
            "report": report,
        }
        env = FunctionToolOutputEnvelope(
            tool="agent_run_report",
            ok=True,
            payload=payload,
        )
        return env.to_json_string()

    return FunctionTool(
        name="agent_run_report",
        description=describe_agent_run_report(),
        params_json_schema=_AGENT_RUN_REPORT_SCHEMA,
        on_invoke_tool=_invoke,
        strict_json_schema=True,
    )


__all__ = ("build_agent_run_report_tool",)
