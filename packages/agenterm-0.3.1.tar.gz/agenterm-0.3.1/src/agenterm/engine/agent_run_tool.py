"""Ephemeral agent_run tool (agent-as-tool delegation)."""

from __future__ import annotations

from dataclasses import dataclass, replace
from functools import partial
from typing import TYPE_CHECKING

from agents.exceptions import MaxTurnsExceeded
from agents.tool import FunctionTool

from agenterm.artifacts.agent_run import persist_agent_run_report
from agenterm.core.approvals import ApprovalsContext
from agenterm.core.errors import AgentermError, ConfigError, ValidationError
from agenterm.core.json_codec import as_str, parse_json_object
from agenterm.core.plan import ToolRuntimeContext
from agenterm.core.retry import retry_async
from agenterm.core.tool_output_envelope import (
    FunctionToolOutputEnvelope,
    ToolOutputError,
)
from agenterm.engine.agent_run_report_payload import build_agent_run_report_payload
from agenterm.engine.agent_run_schema import AGENT_RUN_REPORT_SCHEMA
from agenterm.engine.delegate_bundle import delegate_bundle_specs
from agenterm.engine.run import RunExecOptions, run_once
from agenterm.engine.schema_validation import validate_strict_schema
from agenterm.engine.tool_descriptions import describe_agent_run
from agenterm.store.async_db import AsyncStore
from agenterm.workflow.run.retry_policy import (
    provider_retry_decision,
    provider_retry_exceptions,
    retry_policy_from_config,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Mapping, Sequence
    from pathlib import Path

    from agents.agent import Agent
    from agents.result import RunResultBase
    from agents.tool_context import ToolContext

    from agenterm.config.model import AppConfig
    from agenterm.core.cancellation import CancelToken
    from agenterm.core.json_types import JSONValue
    from agenterm.core.toolspec import ToolSpec

_INVALID_INPUT_KIND = "invalid_input"
_TOOL_ERROR_KIND = "tool_error"
_UNSUPPORTED_INCLUDE = "reasoning.encrypted_content"

_AGENT_RUN_SCHEMA: dict[str, JSONValue] = {
    "type": "object",
    "description": "Delegated one-shot agent invocation parameters.",
    "properties": {
        "model": {
            "type": "string",
            "description": "Model ID for the delegated agent.",
        },
        "instructions": {
            "type": "string",
            "description": "Full instructions for the delegated agent.",
        },
        "input": {
            "type": "string",
            "description": "User input for the delegated agent.",
        },
    },
    "required": ["model", "instructions", "input"],
    "additionalProperties": False,
}


@dataclass(frozen=True)
class AgentRunArgs:
    """Parsed agent_run arguments."""

    model: str
    instructions: str
    input_text: str


@dataclass(frozen=True)
class AgentRunInvocation:
    """Resolved agent_run invocation inputs."""

    args: AgentRunArgs
    ctx_runtime: ToolRuntimeContext
    cfg_run: AppConfig
    selected: list[ToolSpec]
    cancel_token: CancelToken | None


def _error_output(
    *,
    kind: str,
    message: str,
    details: Mapping[str, JSONValue] | None = None,
) -> str:
    err = ToolOutputError(
        kind=kind,
        message=message,
        details=dict(details) if details is not None else {},
    )
    env = FunctionToolOutputEnvelope(
        tool="agent_run",
        ok=False,
        payload={},
        error=err,
    )
    return env.to_json_string()


def _map_agent_run_error(message: str) -> tuple[str, dict[str, JSONValue] | None]:
    lowered = message.lower()
    if "encrypted content is not supported" in lowered:
        return (
            "Model does not support reasoning.encrypted_content. Choose a model that "
            "supports encrypted reasoning or adjust the Responses include set.",
            {"reason": "unsupported_include", "field": "include"},
        )
    return message, None


def _is_unsupported_include_error(message: str) -> bool:
    return "encrypted content is not supported" in message.lower()


def _drop_unsupported_includes(
    includes: tuple[str, ...],
) -> tuple[tuple[str, ...], list[str]]:
    if _UNSUPPORTED_INCLUDE not in includes:
        return includes, []
    filtered = tuple(item for item in includes if item != _UNSUPPORTED_INCLUDE)
    warning = f"Dropped response include {_UNSUPPORTED_INCLUDE} (unsupported by model)."
    return filtered, [warning]


def _tools_available(specs: Sequence[ToolSpec]) -> list[str]:
    return sorted({spec.key for spec in specs})


def _parse_required_str(
    payload: Mapping[str, JSONValue],
    *,
    key: str,
) -> str | None:
    raw = as_str(payload.get(key))
    if raw is None:
        return None
    if not raw.strip():
        return None
    return raw


def _parse_agent_run_payload(
    raw: str,
) -> tuple[AgentRunArgs | None, str | None]:
    payload = parse_json_object(raw) if raw else None
    if payload is None:
        return None, _error_output(
            kind=_INVALID_INPUT_KIND, message="Invalid agent_run payload."
        )
    if set(payload) != {"model", "instructions", "input"}:
        return None, _error_output(
            kind=_INVALID_INPUT_KIND, message="Invalid agent_run payload."
        )
    model_raw = _parse_required_str(payload, key="model")
    instructions = _parse_required_str(payload, key="instructions")
    input_text = _parse_required_str(payload, key="input")
    if model_raw is None or instructions is None or input_text is None:
        return None, _error_output(
            kind=_INVALID_INPUT_KIND,
            message="agent_run requires model, instructions, and input strings.",
        )
    model_id = model_raw.strip()
    if not model_id:
        return None, _error_output(
            kind=_INVALID_INPUT_KIND,
            message="agent_run requires a non-empty model.",
        )
    return (
        AgentRunArgs(
            model=model_id,
            instructions=instructions,
            input_text=input_text,
        ),
        None,
    )


def _resolve_agent_run_invocation(
    ctx: ToolContext[ToolRuntimeContext | None],
    raw: str,
    *,
    cfg: AppConfig,
) -> tuple[AgentRunInvocation | None, str | None]:
    args, error = _parse_agent_run_payload(raw)
    if error is not None:
        return None, error
    if args is None:
        return None, _error_output(
            kind=_INVALID_INPUT_KIND,
            message="Invalid agent_run payload.",
        )
    ctx_runtime = ctx.context
    if not isinstance(ctx_runtime, ToolRuntimeContext):
        return None, _error_output(
            kind=_TOOL_ERROR_KIND,
            message="agent_run requires ToolRuntimeContext.",
        )
    cancel_token = ctx_runtime.cancel_token
    if cancel_token is not None:
        cancel_token.raise_if_cancelled()
    agent_cfg = replace(
        cfg.agent,
        name="agent_run",
        model=args.model,
        instructions=args.instructions,
        path=None,
        source=None,
        explicit=True,
    )
    cfg_run = replace(cfg, agent=agent_cfg)
    selected, error = _resolve_agent_run_selection(cfg_run, model_id=args.model)
    if error is not None:
        return None, error
    if selected is None:
        return None, _error_output(
            kind=_TOOL_ERROR_KIND,
            message="agent_run could not resolve delegate tool selection.",
        )
    return (
        AgentRunInvocation(
            args=args,
            ctx_runtime=ctx_runtime,
            cfg_run=cfg_run,
            selected=selected,
            cancel_token=cancel_token,
        ),
        None,
    )


def _resolve_agent_run_selection(
    cfg_run: AppConfig,
    *,
    model_id: str,
) -> tuple[list[ToolSpec] | None, str | None]:
    try:
        return list(delegate_bundle_specs(cfg_run, model_id=model_id)), None
    except ValidationError as exc:
        return None, _error_output(kind=_INVALID_INPUT_KIND, message=str(exc))
    except ConfigError as exc:
        return None, _error_output(kind=_TOOL_ERROR_KIND, message=str(exc))


async def _run_agent_once(
    agent: Agent,
    args: AgentRunArgs,
    cfg_run: AppConfig,
    *,
    response_include: tuple[str, ...] | None,
) -> RunResultBase:
    return await run_once(
        agent,
        args.input_text,
        opts=RunExecOptions(
            cfg=cfg_run,
            workflow_name="agenterm agent_run",
            session=None,
            background=False,
            tool_context=None,
            model_id=args.model,
            max_turns=cfg_run.agent.max_turns,
            response_include=response_include,
        ),
    )


async def _run_agent_with_include_fallback(
    agent: Agent,
    args: AgentRunArgs,
    cfg_run: AppConfig,
    *,
    warnings: list[str],
) -> RunResultBase:
    try:
        return await _run_agent_once(agent, args, cfg_run, response_include=None)
    except AgentermError as exc:
        if not _is_unsupported_include_error(str(exc)):
            raise
        include_raw = cfg_run.to_model_settings().response_include or []
        include_base = tuple(str(item) for item in include_raw)
        include_override, warn = _drop_unsupported_includes(include_base)
        if include_override == include_base:
            raise
        warnings.extend(warn)
        return await _run_agent_once(
            agent, args, cfg_run, response_include=include_override
        )


async def _invoke_agent_run(
    ctx: ToolContext[ToolRuntimeContext | None],
    raw: str,
    *,
    cfg: AppConfig,
    workspace_root: Path,
    agent_builder: Callable[..., Agent],
) -> str:
    invocation, error = _resolve_agent_run_invocation(ctx, raw, cfg=cfg)
    if error is not None:
        return error
    if invocation is None:
        return _error_output(
            kind=_INVALID_INPUT_KIND,
            message="Invalid agent_run payload.",
        )
    args = invocation.args
    ctx_runtime = invocation.ctx_runtime
    cfg_run = invocation.cfg_run
    selected = invocation.selected
    cancel_token = invocation.cancel_token
    tools_available = _tools_available(selected)
    warnings: list[str] = []

    approvals = ApprovalsContext(mode="auto")
    try:
        agent = agent_builder(
            cfg_run,
            selected_tools=selected,
            approvals=approvals,
            workspace_root=workspace_root,
            mcp_servers=None,
        )
        policy = retry_policy_from_config(cfg_run.retries.provider)

        result = await retry_async(
            partial(
                _run_agent_with_include_fallback,
                agent=agent,
                args=args,
                cfg_run=cfg_run,
                warnings=warnings,
            ),
            policy=policy,
            retry_on=provider_retry_exceptions(),
            classify=provider_retry_decision,
        )
        if cancel_token is not None:
            cancel_token.raise_if_cancelled()
        report = build_agent_run_report_payload(
            tool_call_id=ctx.tool_call_id,
            trace_id=ctx_runtime.trace_id,
            model=args.model,
            instructions=args.instructions,
            input_text=args.input_text,
            result=result,
            tools_available=tools_available,
            warnings=warnings,
        )
        record = await persist_agent_run_report(
            store=AsyncStore(ctx_runtime.db_path),
            session_id=ctx_runtime.session_id,
            source_id=ctx.tool_call_id,
            payload=report,
        )
    except MaxTurnsExceeded as exc:
        return _error_output(
            kind=_TOOL_ERROR_KIND,
            message=str(exc),
            details={"reason": "max_turns_exceeded"},
        )
    except AgentermError as exc:
        mapped_message, details = _map_agent_run_error(str(exc))
        return _error_output(
            kind=_TOOL_ERROR_KIND,
            message=mapped_message,
            details=details,
        )

    summary = as_str(report.get("output_text")) or ""
    payload_out: dict[str, JSONValue] = {
        "summary": summary,
        "report_id": record.artifact_id,
        "response_id": report.get("response_id"),
        "tool_counts": report.get("tool_counts", {}),
        "truncated": report.get("truncated", False),
        "warnings": report.get("warnings", []),
    }
    env = FunctionToolOutputEnvelope(tool="agent_run", ok=True, payload=payload_out)
    return env.to_json_string()


def build_agent_run_tool(
    cfg: AppConfig,
    *,
    workspace_root: Path,
    agent_builder: Callable[..., Agent],
) -> FunctionTool | None:
    """Build the agent_run tool when configured."""
    if cfg.tools.agent_run is None:
        return None
    validate_strict_schema("agent_run", _AGENT_RUN_SCHEMA)

    return FunctionTool(
        name="agent_run",
        description=describe_agent_run(),
        params_json_schema=_AGENT_RUN_SCHEMA,
        on_invoke_tool=partial(
            _invoke_agent_run,
            cfg=cfg,
            workspace_root=workspace_root,
            agent_builder=agent_builder,
        ),
        strict_json_schema=True,
    )


__all__ = ("AGENT_RUN_REPORT_SCHEMA", "build_agent_run_tool")
