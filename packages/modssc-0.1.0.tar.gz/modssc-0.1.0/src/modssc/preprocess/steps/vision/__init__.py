"""Vision preprocessing steps."""
