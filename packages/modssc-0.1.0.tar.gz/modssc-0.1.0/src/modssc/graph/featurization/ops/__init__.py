"""Featurization operators."""
