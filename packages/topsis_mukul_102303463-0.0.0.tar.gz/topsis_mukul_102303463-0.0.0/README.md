# TOPSIS

**Author:** Mukul Ghai 
**Roll Number:** 102303463

---

## Overview

**TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)** is a
multi-criteria decision-making (MCDM) method developed in the 1980s.  
It ranks alternatives based on their relative closeness to the ideal best and
ideal worst solutions.

This package provides a command-line implementation of the TOPSIS algorithm and
supports CSV input files.

---

## Installation

Install the package using pip:

pip install Topsis-Mukul-102303463

---

## Command Line Usage

After installation, run the following command in the current working directory:

**topsis <InputDataFile> <Weights> <Impacts> <ResultFileName>**

### Example

topsis data.csv "1,2,1,1" "+,-,-,+" result.csv

---

## Input Requirements

- Input file must contain **three or more columns**
- **First column** must contain alternative names (non-numeric)
- **Second to last columns** must contain **numeric values only**
- Number of **weights**, **impacts**, and **criteria columns** must be equal
- Impacts must be:
  - `+` for benefit criteria
  - `-` for cost criteria
- Weights and impacts must be **comma-separated**
- Weights need not be normalized (handled internally)

---

## Input File Format (data.csv)

Each row represents an alternative, and each column (except the first) represents
a decision criterion such as Correlation, R², RMSE, Accuracy, etc.

Example:

| Model | Corr | Rseq | RMSE | Accuracy |
|------:|-----:|-----:|-----:|---------:|
| M1 | 0.79 | 0.62 | 1.25 | 60.89 |
| M2 | 0.66 | 0.44 | 2.89 | 63.07 |
| M3 | 0.56 | 0.31 | 1.57 | 62.87 |
| M4 | 0.82 | 0.67 | 2.68 | 70.19 |
| M5 | 0.75 | 0.56 | 1.30 | 80.39 |


---

## Output File Format (result.csv)

For weights "1,2,1,1" and impacts "+,-,-,+", the output file will contain two
additional columns: **Topsis Score** and **Rank**.

## Example Output

| Model | Corr | Rseq | RMSE | Accuracy | Topsis Score | Rank |
|------:|-----:|-----:|-----:|---------:|-------------:|-----:|
| M1 | 0.79 | 0.62 | 1.25 | 60.89 | 0.423744391359611 | 4 |
| M2 | 0.66 | 0.44 | 2.89 | 63.07 | 0.467426368298297 | 3 |
| M3 | 0.56 | 0.31 | 1.57 | 62.87 | 0.760230957034903 | 1 |
| M4 | 0.82 | 0.67 | 2.68 | 70.19 | 0.207772533881566 | 5 |
| M5 | 0.75 | 0.56 | 1.30 | 80.39 | 0.504864457803718 | 2 |


---

## Description of Output

- **Topsis Score**: Relative closeness of the alternative to the ideal solution  
- **Rank**: Rank based on TOPSIS score (1 = best alternative)

---

## License

This project is developed for academic purposes.
