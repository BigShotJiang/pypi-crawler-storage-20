"""Interaction JavaScript builders for browser automation."""

from __future__ import annotations

import json


def build_hover_js(selector: str) -> str:
    """Build JS to hover over element."""
    return f"""
    (function() {{
        const el = document.querySelector("{selector}");
        if (!el) return JSON.stringify({{ success: false, error: 'Element not found' }});

        const event = new MouseEvent('mouseover', {{
            bubbles: true,
            cancelable: true,
            view: window
        }});
        el.dispatchEvent(event);

        return JSON.stringify({{ success: true }});
    }})()
    """


def build_select_js(selector: str, value: str | None = None, text: str | None = None) -> str:
    """
    Build JS to select option from dropdown.

    Args:
        selector: CSS selector for <select> element
        value: Option value to select
        text: Option text to select (if value not provided)
    """
    if value is not None:
        select_code = f'select.value = "{value}";'
    elif text is not None:
        select_code = f'''
        const option = Array.from(select.options).find(o => o.text === "{text}");
        if (option) select.value = option.value;
        '''
    else:
        return 'JSON.stringify({ success: false, error: "Need value or text" })'

    return f"""
    (function() {{
        const select = document.querySelector("{selector}");
        if (!select) return JSON.stringify({{ success: false, error: 'Select not found' }});

        {select_code}

        // Trigger change event
        select.dispatchEvent(new Event('change', {{ bubbles: true }}));

        return JSON.stringify({{
            success: true,
            selected_value: select.value,
            selected_text: select.options[select.selectedIndex]?.text
        }});
    }})()
    """


def build_close_modal_js(
    selectors: list[str] | None = None,
) -> str:
    """
    Build JS to close modal dialogs.

    Args:
        selectors: Custom selectors to try. Default tries common patterns.
    """
    default_selectors = [
        '[aria-label="Close"]',
        '[aria-label="Dismiss"]',
        'button[class*="close"]',
        'button[class*="dismiss"]',
        '[data-testid="close"]',
        '.modal-close',
        '.dialog-close',
        'button:has(svg[class*="close"])',
        'div[role="dialog"] button:first-child',
    ]
    all_selectors = selectors or default_selectors
    selectors_json = json.dumps(all_selectors)

    return f"""
    (function() {{
        const selectors = {selectors_json};

        for (const sel of selectors) {{
            try {{
                const el = document.querySelector(sel);
                if (el && el.offsetParent !== null) {{
                    el.click();
                    return JSON.stringify({{ success: true, selector: sel }});
                }}
            }} catch(e) {{
                // Skip invalid selectors
            }}
        }}

        // Try pressing Escape
        document.dispatchEvent(new KeyboardEvent('keydown', {{ key: 'Escape', code: 'Escape' }}));

        return JSON.stringify({{ success: false, error: 'No modal close button found' }});
    }})()
    """


def build_click_all_by_text_js(text: str, role: str = "button") -> str:
    """
    Build JS to click all elements containing specific text.

    Args:
        text: Text to match (case-insensitive)
        role: Element role to filter (default: "button")

    Returns:
        JS code that returns { clicked: number }
    """
    return f"""
    (function() {{
        const elements = document.querySelectorAll('[role="{role}"]');
        let clicked = 0;
        const targetText = "{text}".toLowerCase();
        elements.forEach(el => {{
            const elText = el.textContent.trim().toLowerCase();
            if (elText === targetText || elText.includes(targetText)) {{
                el.click();
                clicked++;
            }}
        }});
        return JSON.stringify({{ clicked: clicked }});
    }})()
    """
