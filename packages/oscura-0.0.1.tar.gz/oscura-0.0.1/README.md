# Oscura

**Unified hardware reverse engineering framework. Revealing what's hidden in every signal.**

## Status

⚠️ **This is a placeholder package.** Full release coming soon.

Oscura is a hardware reverse engineering framework for security researchers, right-to-repair advocates, defense analysts, and commercial intelligence teams.

## Vision

From oscilloscope captures to complete system understanding:

- **Unknown protocol discovery** - Automatic protocol inference and state machine extraction
- **System replication** - Reverse engineer proprietary devices for understanding and repair
- **Security analysis** - Vulnerability discovery, CRC/checksum recovery, exploitation
- **Signal analysis** - IEEE-compliant measurements, comprehensive protocol decoding (16+ protocols)

## Coming Soon

Watch for updates at:
- GitHub: https://github.com/lair-click-bats/tracekit
- PyPI: https://pypi.org/project/oscura/

## Current Package

This is the **TraceKit** framework in transition to **Oscura**. The rename will happen in the coming release.

For the current stable version, install:
```bash
pip install tracekit
```

## License

MIT License - Copyright (c) 2026 TraceKit Contributors
