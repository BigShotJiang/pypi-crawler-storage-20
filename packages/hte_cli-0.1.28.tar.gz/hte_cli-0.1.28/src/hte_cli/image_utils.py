"""Docker image utilities for pre-pulling compose images."""

import logging
import subprocess
from collections.abc import Callable

import yaml

logger = logging.getLogger(__name__)


def extract_images_from_compose(compose_yaml: str) -> list[str]:
    """
    Extract Docker image names from a compose.yaml string.

    Args:
        compose_yaml: Docker Compose YAML content

    Returns:
        List of image names (e.g., ["jackpayne123/nyuctf-agent:v2", "ctf-game:latest"])
    """
    try:
        compose_data = yaml.safe_load(compose_yaml)
        if not compose_data or "services" not in compose_data:
            return []

        images = []
        for service_name, service_config in compose_data.get("services", {}).items():
            if isinstance(service_config, dict) and "image" in service_config:
                images.append(service_config["image"])
        return images
    except yaml.YAMLError as e:
        logger.warning(f"Failed to parse compose.yaml: {e}")
        return []


def check_image_exists_locally(image: str) -> bool:
    """
    Check if a Docker image exists locally.

    Args:
        image: Image name (e.g., "jackpayne123/nyuctf-agent:v2")

    Returns:
        True if image exists locally, False otherwise
    """
    try:
        result = subprocess.run(
            ["docker", "image", "inspect", image],
            capture_output=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def pull_image_with_progress(
    image: str,
    on_progress: Callable[[str, str], None] | None = None,
    on_complete: Callable[[str, bool], None] | None = None,
) -> bool:
    """
    Pull a Docker image with progress callbacks.

    Args:
        image: Image name to pull
        on_progress: Callback(image, status_line) called for each line of output
        on_complete: Callback(image, success) called when pull completes

    Returns:
        True if pull succeeded, False otherwise
    """
    try:
        process = subprocess.Popen(
            ["docker", "pull", image],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )

        # Stream output line by line
        for line in iter(process.stdout.readline, ""):
            line = line.strip()
            if line and on_progress:
                on_progress(image, line)

        process.wait()
        success = process.returncode == 0

        if on_complete:
            on_complete(image, success)

        return success

    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        logger.error(f"Failed to pull {image}: {e}")
        if on_complete:
            on_complete(image, False)
        return False


def prepull_compose_images(
    compose_yaml: str,
    on_image_start: Callable[[str, int, int], None] | None = None,
    on_image_progress: Callable[[str, str], None] | None = None,
    on_image_complete: Callable[[str, bool, str], None] | None = None,
) -> tuple[int, int]:
    """
    Pre-pull all images from a compose.yaml file.

    Args:
        compose_yaml: Docker Compose YAML content
        on_image_start: Callback(image, current_idx, total) when starting an image
        on_image_progress: Callback(image, status_line) for pull progress
        on_image_complete: Callback(image, success, reason) when image completes

    Returns:
        Tuple of (images_pulled, images_failed)
    """
    images = extract_images_from_compose(compose_yaml)
    if not images:
        return (0, 0)

    pulled = 0
    failed = 0

    for idx, image in enumerate(images):
        # Check if already cached
        if check_image_exists_locally(image):
            if on_image_complete:
                on_image_complete(image, True, "cached")
            pulled += 1
            continue

        # Need to pull
        if on_image_start:
            on_image_start(image, idx + 1, len(images))

        success = pull_image_with_progress(
            image,
            on_progress=on_image_progress,
        )

        if success:
            if on_image_complete:
                on_image_complete(image, True, "pulled")
            pulled += 1
        else:
            if on_image_complete:
                on_image_complete(image, False, "failed")
            failed += 1

    return (pulled, failed)
