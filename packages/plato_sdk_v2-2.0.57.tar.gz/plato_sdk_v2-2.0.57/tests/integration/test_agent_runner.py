"""Integration tests for Agent + Runner + World flow.

Tests the complete end-to-end flow without requiring OpenHands.
Uses a simple test agent that runs a basic command in a Docker container.

Run with:
    pytest tests/integration/test_agent_runner.py -v -s
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING

import pytest
from plato.agent.base import Agent
from plato.agent.types import AgentConfig
from plato.runner import RunnerConfig, SimpleRunner

from plato.world.base import World
from plato.world.config import EnvSpec, WorldConfig
from plato.world.types import Observation, StepResult

if TYPE_CHECKING:
    pass


# =============================================================================
# Test Agent - Simple Docker-based agent
# =============================================================================


class SimpleTestAgent(Agent):
    """Simple agent that runs a shell command in Docker."""

    @property
    def image(self) -> str:
        return "python:3.11-slim"

    @property
    def name(self) -> str:
        return "SimpleTestAgent"

    def build_command(self, prompt: str) -> list[str]:
        # Simple command that echoes the prompt and exits
        return ["python", "-c", f"print('Agent received: {prompt[:50]}'); print('SUCCESS')"]


class EchoAgent(Agent):
    """Agent that echoes environment variables."""

    @property
    def image(self) -> str:
        return "python:3.11-slim"

    @property
    def name(self) -> str:
        return "EchoAgent"

    def build_command(self, prompt: str) -> list[str]:
        # Print all env vars that start with certain prefixes
        return [
            "python",
            "-c",
            "import os; [print(f'{k}={v}') for k,v in sorted(os.environ.items()) if k.startswith(('SIMULATION', 'SPREE', 'FIREFLY'))]",
        ]


# =============================================================================
# Test World - Minimal world for testing
# =============================================================================


class MockWorld(World):
    """Minimal world for testing without Plato session."""

    def __init__(self, config: WorldConfig, skip_session: bool = True):
        super().__init__(config)
        self._skip_session = skip_session
        self._balance = 1000.0

    async def reset(self) -> Observation:
        """Override to skip Plato session creation for basic tests."""
        if self._skip_session:
            # Skip Plato session, just initialize state
            self._current_step = 0
            self._current_date = datetime.fromisoformat(self.config.start_date)
            self._done = False
            self._initialized = True  # Track that reset was called
            self._connect_urls = {
                "spree": "http://mock-spree.local:3000",
                "firefly": "http://mock-firefly.local:8080",
            }
            return await self._on_reset()
        else:
            return await super().reset()

    async def step(self) -> StepResult:
        """Override to skip session check for mock world."""
        if self._skip_session:
            # Skip session check for mock world
            if not getattr(self, "_initialized", False):
                raise RuntimeError("World not initialized. Call reset() first.")

            self._current_step += 1

            # Advance simulation date
            if self._current_date is not None:
                self._current_date += timedelta(days=1)

            # Call subclass hook for custom step logic
            result = await self._on_step()

            # Update done status
            if result.done:
                self._done = True

            # Log to storage (like base class does)
            if self.storage:
                self.storage.log_step(self._current_step, result)

            return result
        else:
            return await super().step()

    async def _on_reset(self) -> Observation:
        return Observation(
            step=0,
            date=self.config.start_date,
            data={"balance": self._balance, "status": "initialized"},
        )

    async def _on_step(self) -> StepResult:
        import random

        reward = random.uniform(-100, 200)
        self._balance += reward

        return StepResult(
            observation=Observation(
                step=self._current_step,
                date=self.current_date,
                data={"balance": self._balance},
            ),
            reward=reward,
            done=self._current_step >= self.config.num_steps,
        )

    def get_prompt(self) -> str:
        return f"Step {self._current_step}: Current balance is ${self._balance:.2f}. Make a decision."


# =============================================================================
# Tests
# =============================================================================


class TestSimpleAgentRunner:
    """Test basic agent-runner flow without Plato session."""

    @pytest.fixture
    def world_config(self) -> WorldConfig:
        return WorldConfig(
            name="test-world",
            envs=[
                EnvSpec(alias="spree", simulator="spree"),
                EnvSpec(alias="firefly", simulator="firefly"),
            ],
            num_steps=2,
            start_date="2024-01-01",
        )

    @pytest.fixture
    def test_world(self, world_config: WorldConfig) -> MockWorld:
        return MockWorld(world_config, skip_session=True)

    @pytest.fixture
    def test_agent(self) -> SimpleTestAgent:
        return SimpleTestAgent(AgentConfig(model="test-model"))

    @pytest.mark.asyncio
    async def test_agent_take_turn(self, test_agent: SimpleTestAgent, temp_workspace: Path):
        """Test agent.take_turn() runs command in Docker."""
        from plato.runtime import DockerRuntime, DockerRuntimeConfig

        runtime = DockerRuntime(
            name="test-runtime",
            image=test_agent.image,
            config=DockerRuntimeConfig(workspace_base=temp_workspace),
        )

        try:
            result = await test_agent.take_turn(
                prompt="Hello, test!",
                runtime=runtime,
                env_vars={"TEST_VAR": "test_value"},
            )

            assert result.success, f"Agent failed: {result.error}"
            assert len(result.events) >= 2  # start + end events
            assert result.elapsed_seconds > 0
            assert "SUCCESS" in (result.final_message or "")
        finally:
            runtime.cleanup()

    @pytest.mark.asyncio
    async def test_runner_basic_flow(self, test_world: MockWorld, test_agent: SimpleTestAgent, temp_workspace: Path):
        """Test Runner executes agent turns and world steps."""
        from plato.runtime import DockerRuntimeConfig

        # Patch DockerRuntimeConfig to use temp workspace
        original_init = DockerRuntimeConfig.__init__

        def patched_init(self, **kwargs):
            kwargs.setdefault("workspace_base", temp_workspace)
            original_init(self, **kwargs)

        DockerRuntimeConfig.__init__ = patched_init

        try:
            runner = SimpleRunner(
                agents=test_agent,
                world=test_world,
                config=RunnerConfig(save_to_storage=False, cleanup_workspaces=True),
            )

            result = await runner.run()

            assert result.success, f"Run failed: {result.error}"
            assert result.num_steps == 2
            assert result.run_id is not None
        finally:
            DockerRuntimeConfig.__init__ = original_init

    @pytest.mark.asyncio
    async def test_env_vars_passed_to_agent(self, test_world: MockWorld, temp_workspace: Path):
        """Test that world env vars are passed to agent."""
        from plato.runtime import DockerRuntime, DockerRuntimeConfig

        agent = EchoAgent(AgentConfig(model="test-model"))
        runtime = DockerRuntime(
            name="test-runtime",
            image=agent.image,
            config=DockerRuntimeConfig(workspace_base=temp_workspace),
        )

        # Reset world to get env vars
        await test_world.reset()
        env_vars = test_world.get_env_vars()

        try:
            result = await agent.take_turn(
                prompt="List env vars",
                runtime=runtime,
                env_vars=env_vars,
            )

            assert result.success, f"Agent failed: {result.error}"
            output = result.final_message or ""

            # Check env vars were passed
            assert "SPREE_BASE_URL" in output
            assert "FIREFLY_BASE_URL" in output
            assert "SIMULATION_DATE" in output
        finally:
            runtime.cleanup()
            await test_world.close()


class TestRunnerWithStorage:
    """Test Runner with RolloutStorage persistence."""

    @pytest.fixture
    def world_config(self) -> WorldConfig:
        return WorldConfig(
            name="storage-test-world",
            envs=[EnvSpec(alias="spree", simulator="spree")],
            num_steps=2,
            start_date="2024-01-01",
        )

    @pytest.mark.asyncio
    async def test_storage_captures_events(
        self,
        world_config: WorldConfig,
        temp_db_path: Path,
        temp_workspace: Path,
    ):
        """Test that storage captures steps and events during run."""
        from plato.runtime import DockerRuntimeConfig
        from plato.storage import RolloutStorage

        world = MockWorld(world_config, skip_session=True)
        agent = SimpleTestAgent(AgentConfig(model="test-model"))

        # Patch DockerRuntimeConfig to use temp workspace
        original_init = DockerRuntimeConfig.__init__

        def patched_init(self, **kwargs):
            kwargs.setdefault("workspace_base", temp_workspace)
            original_init(self, **kwargs)

        DockerRuntimeConfig.__init__ = patched_init

        try:
            # Create storage first with temp DB path
            storage = RolloutStorage(
                run_id=f"test-{uuid.uuid4().hex[:8]}",
                agent_type=agent.name,
                model=agent.config.model,
                world_name=world.config.name,
                db_path=temp_db_path,
            )

            # Inject storage into world
            world.storage = storage

            runner = SimpleRunner(
                agents=agent,
                world=world,
                # Set save_to_storage=False so runner doesn't create its own
                config=RunnerConfig(save_to_storage=False, cleanup_workspaces=True),
            )

            # Manually set the runner's storage reference
            runner._storage = storage

            result = await runner.run()

            assert result.success, f"Run failed: {result.error}"

            # Finalize storage
            storage.finalize(success=result.success, error=result.error)

            # Verify storage contents
            trajectory = storage.get_trajectory()

            assert trajectory["run"] is not None
            assert trajectory["run"]["status"] == "completed"
            assert trajectory["run"]["num_steps"] == 2
            assert len(trajectory["steps"]) >= 1  # At least reset step
            assert trajectory["total_events"] >= 2  # At least start/end per turn

        finally:
            DockerRuntimeConfig.__init__ = original_init
            storage.close()


class TestMultipleAgents:
    """Test Runner with multiple agents."""

    @pytest.fixture
    def world_config(self) -> WorldConfig:
        return WorldConfig(
            name="multi-agent-world",
            envs=[EnvSpec(alias="spree", simulator="spree")],
            num_steps=1,
            start_date="2024-01-01",
        )

    @pytest.mark.asyncio
    async def test_multiple_agents_per_step(self, world_config: WorldConfig, temp_workspace: Path):
        """Test that multiple agents can run per step."""
        from plato.runtime import DockerRuntimeConfig

        world = MockWorld(world_config, skip_session=True)
        agent1 = SimpleTestAgent(AgentConfig(model="model-1"))
        agent2 = SimpleTestAgent(AgentConfig(model="model-2"))

        # Patch DockerRuntimeConfig
        original_init = DockerRuntimeConfig.__init__

        def patched_init(self, **kwargs):
            kwargs.setdefault("workspace_base", temp_workspace)
            original_init(self, **kwargs)

        DockerRuntimeConfig.__init__ = patched_init

        try:
            runner = SimpleRunner(
                agents=[agent1, agent2],
                world=world,
                config=RunnerConfig(save_to_storage=False, cleanup_workspaces=True),
            )

            result = await runner.run()

            assert result.success, f"Run failed: {result.error}"
            assert result.num_steps == 1
        finally:
            DockerRuntimeConfig.__init__ = original_init
