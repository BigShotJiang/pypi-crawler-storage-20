"""End-to-end integration test for browser agents with World/Runner.

This test runs complete scenarios:
1. BrowserAgent with test model (no API keys needed)
2. BrowserAgent with Plato espocrm simulator
3. Real browser agents (Claude/Gemini) with Plato simulator

Requirements:
- Docker running
- For Plato tests: PLATO_API_KEY environment variable
- For real agents: ANTHROPIC_API_KEY or GEMINI_API_KEY

Run with:
    # Basic tests (no API keys needed, just Docker)
    pytest tests/integration/test_e2e_browser_agent.py::TestE2EBrowserAgentBasic -v -s

    # With Plato session
    export PLATO_API_KEY=your-key
    pytest tests/integration/test_e2e_browser_agent.py::TestE2EBrowserAgentWithPlato -v -s
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest

# Check requirements
HAS_PLATO_KEY = bool(os.environ.get("PLATO_API_KEY"))
HAS_ANTHROPIC_KEY = bool(os.environ.get("ANTHROPIC_API_KEY"))
HAS_GEMINI_KEY = bool(os.environ.get("GEMINI_API_KEY"))


def is_docker_available() -> bool:
    """Check if Docker is available."""
    try:
        result = subprocess.run(["docker", "info"], capture_output=True, timeout=10)
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


HAS_DOCKER = is_docker_available()


# Docker image paths (Dockerfile is now in browser/ not docker/)
BROWSER_DIR = Path(__file__).parent.parent.parent / "plato" / "agent" / "browser"
TEST_IMAGE_NAME = "plato-browser-agent-test:latest"


# Build the image once for all tests in this module
@pytest.fixture(scope="module")
def browser_agent_image() -> str:
    """Build the browser agent Docker image."""
    if not HAS_DOCKER:
        pytest.skip("Docker not available")

    print(f"\nBuilding browser agent image from {BROWSER_DIR}...")
    result = subprocess.run(
        ["docker", "build", "-t", TEST_IMAGE_NAME, "-f", str(BROWSER_DIR / "Dockerfile"), str(BROWSER_DIR)],
        capture_output=True,
        text=True,
        timeout=600,
    )

    if result.returncode != 0:
        pytest.fail(f"Failed to build Docker image: {result.stderr}")

    return TEST_IMAGE_NAME


class MockWorld:
    """Mock World that doesn't require Plato session.

    Used for basic testing of browser agents without Plato API key.
    """

    def __init__(self, name: str, url: str, num_steps: int = 1):
        self.name = name
        self.url = url
        self.num_steps = num_steps
        self._current_step = 0
        self._storage = None

        # Mock config object
        class MockConfig:
            def __init__(self, name, num_steps):
                self.name = name
                self.num_steps = num_steps
                self.start_date = "2024-01-01"

        self.config = MockConfig(name, num_steps)

    async def reset(self):
        """Reset the mock world."""
        from plato.world.types import Observation

        self._current_step = 0
        return Observation(step=0, date="2024-01-01", data={"url": self.url})

    async def step(self):
        """Step the mock world."""
        from plato.world.types import Observation, StepResult

        self._current_step += 1
        return StepResult(
            observation=Observation(
                step=self._current_step,
                date="2024-01-01",
                data={"status": "completed"},
            ),
            reward=1.0,
            done=self._current_step >= self.num_steps,
        )

    def get_env_vars(self) -> dict[str, str]:
        """Return env vars with the URL."""
        return {
            f"{self.name.upper().replace('-', '_')}_BASE_URL": self.url,
            "SIMULATION_DATE": "2024-01-01",
            "SIMULATION_STEP": str(self._current_step),
        }

    def get_connect_urls(self) -> dict[str, str]:
        """Return connect URLs."""
        return {self.name: self.url}

    def get_prompt(self) -> str:
        """Return prompt for agent."""
        return f"Navigate to {self.url} and take a screenshot."

    async def close(self):
        """Close the mock world."""
        pass


class TestE2EBrowserAgentLocal:
    """E2E tests for browser agent with local runtime (no Docker needed)."""

    @pytest.mark.asyncio
    async def test_browser_agent_local_runtime(self, temp_db_path: Path):
        """Test browser agent with local runtime mode.

        This test runs the agent directly in the current process without Docker.
        Requires Playwright to be installed locally.
        """
        import importlib.util

        if importlib.util.find_spec("playwright") is None:
            pytest.skip("Playwright not installed")

        from plato.agent.browser import BrowserAgent, BrowserAgentConfig
        from plato.storage import RolloutStorage

        world = MockWorld(name="test", url="https://example.com", num_steps=1)
        agent = BrowserAgent(
            BrowserAgentConfig(
                model="test",
                runtime="local",  # Use local runtime
                headless=True,
                timeout_seconds=60,
            )
        )

        storage = RolloutStorage(
            run_id="local-browser-e2e",
            agent_type=agent.name,
            model="test",
            world_name=world.config.name,
            db_path=temp_db_path,
        )

        try:
            print(f"\n{'=' * 60}")
            print("E2E Test: Browser Agent with Local Runtime")
            print(f"{'=' * 60}")

            # Reset world to get env vars
            await world.reset()
            env_vars = world.get_env_vars()
            prompt = world.get_prompt()

            print(f"URL: {world.url}")
            print(f"Prompt: {prompt}")

            # Run agent directly (no Docker runtime needed for local mode)
            result = await agent.take_turn(
                prompt=prompt,
                runtime=None,  # Not needed for local runtime
                env_vars=env_vars,
                storage=storage,
            )

            print(f"\n{'=' * 60}")
            print("Results")
            print(f"{'=' * 60}")
            print(f"Success: {result.success}")
            print(f"Elapsed: {result.elapsed_seconds:.2f}s")

            if result.error:
                print(f"Error: {result.error}")

            if result.final_message:
                print(f"Final message: {result.final_message[:200]}")

            # Check events
            events = storage.get_events()
            print(f"\nEvents captured: {len(events)}")
            for event in events[:10]:
                content = event.get("content") or ""
                print(f"  [{event['event_type']}] {content[:50] if content else 'N/A'}")

            # Verify
            assert len(events) > 0, "No events captured"
            event_types = [e["event_type"] for e in events]
            assert "turn_start" in event_types, "Missing turn_start event"
            assert "turn_end" in event_types, "Missing turn_end event"

            # Check that runtime is "local" in events
            start_event = next(e for e in events if e["event_type"] == "turn_start")
            assert start_event["data"].get("runtime") == "local"

        finally:
            storage.close()

    @pytest.mark.asyncio
    async def test_browser_agent_local_runtime_google(self, temp_db_path: Path):
        """Test browser agent with local runtime navigating to Google."""
        import importlib.util

        if importlib.util.find_spec("playwright") is None:
            pytest.skip("Playwright not installed")

        from plato.agent.browser import BrowserAgent, BrowserAgentConfig
        from plato.storage import RolloutStorage

        agent = BrowserAgent(
            BrowserAgentConfig(
                model="test",
                runtime="local",
                headless=True,
                start_url="https://www.google.com",
            )
        )

        storage = RolloutStorage(
            run_id="local-google-e2e",
            agent_type=agent.name,
            model="test",
            world_name="google",
            db_path=temp_db_path,
        )

        try:
            print("\nRunning browser agent locally against Google...")

            result = await agent.take_turn(
                prompt="Take a screenshot of Google",
                runtime=None,
                storage=storage,
            )

            print(f"Success: {result.success}")
            events = storage.get_events()
            print(f"Events: {len(events)}")

            # Check for screenshot event
            has_screenshot = any("screenshot" in str(e).lower() for e in events)
            print(f"Has screenshot event: {has_screenshot}")

            assert len(events) > 0

        finally:
            storage.close()


@pytest.mark.skipif(not HAS_DOCKER, reason="Docker not available")
class TestE2EBrowserAgentBasic:
    """E2E tests for browser agent without Plato session."""

    @pytest.mark.asyncio
    async def test_browser_agent_with_mock_world(
        self, browser_agent_image: str, temp_workspace: Path, temp_db_path: Path
    ):
        """Test browser agent with a mock world that provides a URL.

        This test:
        1. Creates a MockWorld that returns example.com as the URL
        2. Uses BrowserAgent with test model to navigate and screenshot
        3. Verifies events are captured in storage
        """
        from plato.agent.browser import BrowserAgent, BrowserAgentConfig
        from plato.runner import RunnerConfig, SimpleRunner
        from plato.storage import RolloutStorage

        world = MockWorld(name="test", url="https://example.com", num_steps=1)
        agent = BrowserAgent(
            BrowserAgentConfig(
                model="test",  # Use test model (no API key needed)
                timeout_seconds=120,
                docker_image=TEST_IMAGE_NAME,  # Use locally built image
            )
        )

        # Create storage
        storage = RolloutStorage(
            run_id="test-browser-e2e",
            agent_type=agent.name,
            model="test",
            world_name=world.config.name,
            db_path=temp_db_path,
        )

        try:
            runner = SimpleRunner(
                agents=agent,
                world=world,  # type: ignore
                config=RunnerConfig(save_to_storage=False, cleanup_workspaces=True),
            )
            runner._storage = storage
            world._storage = storage

            print(f"\n{'=' * 60}")
            print("E2E Test: Browser Agent with Mock World")
            print(f"{'=' * 60}")
            print(f"Run ID: {runner.run_id}")
            print(f"URL: {world.url}")

            result = await runner.run()

            print(f"\n{'=' * 60}")
            print("Results")
            print(f"{'=' * 60}")
            print(f"Success: {result.success}")
            print(f"Steps: {result.num_steps}")
            print(f"Reward: {result.total_reward}")

            if result.error:
                print(f"Error: {result.error}")

            # Check events
            events = storage.get_events()
            print(f"\nEvents captured: {len(events)}")
            for event in events[:10]:
                content = event.get("content") or ""
                print(f"  [{event['event_type']}] {content[:50] if content else 'N/A'}")

            # Verify
            assert len(events) > 0, "No events captured"
            event_types = [e["event_type"] for e in events]
            assert "turn_start" in event_types, "Missing turn_start event"
            assert "turn_end" in event_types, "Missing turn_end event"

        finally:
            storage.close()

    @pytest.mark.asyncio
    async def test_browser_agent_with_google(self, browser_agent_image: str, temp_workspace: Path, temp_db_path: Path):
        """Test browser agent navigating to Google."""
        from plato.agent.browser import BrowserAgent, BrowserAgentConfig
        from plato.runner import RunnerConfig, SimpleRunner
        from plato.storage import RolloutStorage

        world = MockWorld(name="google", url="https://www.google.com", num_steps=1)
        agent = BrowserAgent(
            BrowserAgentConfig(
                model="test",  # Use test model
                timeout_seconds=120,
                docker_image=TEST_IMAGE_NAME,
            )
        )

        storage = RolloutStorage(
            run_id="google-e2e",
            agent_type=agent.name,
            model="test",
            world_name="google-test",
            db_path=temp_db_path,
        )

        try:
            runner = SimpleRunner(
                agents=agent,
                world=world,  # type: ignore
                config=RunnerConfig(save_to_storage=False),
            )
            runner._storage = storage
            world._storage = storage

            print("\nRunning browser agent against Google...")
            result = await runner.run()

            print(f"Success: {result.success}")
            events = storage.get_events()
            print(f"Events: {len(events)}")

            # Check for screenshot event
            has_screenshot = any("screenshot" in str(e).lower() for e in events)
            print(f"Has screenshot event: {has_screenshot}")

            assert result.num_steps == 1
            assert len(events) > 0

        finally:
            storage.close()


@pytest.mark.skipif(not HAS_DOCKER, reason="Docker not available")
@pytest.mark.skipif(not HAS_PLATO_KEY, reason="PLATO_API_KEY not set")
class TestE2EBrowserAgentWithPlato:
    """E2E tests for browser agent with real Plato session."""

    @pytest.mark.asyncio
    async def test_browser_agent_with_espocrm(self, browser_agent_image: str, temp_workspace: Path, temp_db_path: Path):
        """Test browser agent with real espocrm Plato session.

        This test:
        1. Creates a Plato session with espocrm
        2. Uses BrowserAgent with test model to navigate to espocrm and screenshot
        3. Verifies the agent can see the espocrm login page
        """
        from plato.agent.browser import BrowserAgent, BrowserAgentConfig
        from plato.runner import RunnerConfig, SimpleRunner
        from plato.storage import RolloutStorage

        from plato.world.base import World
        from plato.world.config import EnvSpec, WorldConfig
        from plato.world.types import Observation, StepResult

        class EspoCRMBrowserWorld(World):
            """World with espocrm for browser testing."""

            async def _on_reset(self) -> Observation:
                return Observation(
                    step=0,
                    date=self.config.start_date,
                    data={"simulator": "espocrm"},
                )

            async def _on_step(self) -> StepResult:
                return StepResult(
                    observation=Observation(
                        step=self._current_step,
                        date=self.current_date,
                        data={"status": "completed"},
                    ),
                    reward=1.0,
                    done=True,
                )

            def get_prompt(self) -> str:
                urls = self.get_connect_urls()
                espocrm_url = urls.get("espocrm", "unknown")
                return f"Navigate to {espocrm_url} and take a screenshot of the EspoCRM login page."

        world_config = WorldConfig(
            name="espocrm-browser-test",
            envs=[EnvSpec(alias="espocrm", simulator="espocrm")],
            num_steps=1,
            start_date="2024-01-01",
        )

        world = EspoCRMBrowserWorld(world_config)
        agent = BrowserAgent(
            BrowserAgentConfig(
                model="test",  # Use test model
                timeout_seconds=180,
                docker_image=TEST_IMAGE_NAME,
            )
        )

        storage = RolloutStorage(
            run_id="espocrm-browser-e2e",
            agent_type=agent.name,
            model="test",
            world_name=world.config.name,
            db_path=temp_db_path,
        )

        try:
            runner = SimpleRunner(
                agents=agent,
                world=world,
                config=RunnerConfig(save_to_storage=False),
            )
            runner._storage = storage
            world._storage = storage

            print(f"\n{'=' * 60}")
            print("E2E Test: Browser Agent with EspoCRM")
            print(f"{'=' * 60}")
            print(f"Run ID: {runner.run_id}")

            result = await runner.run()

            print(f"\n{'=' * 60}")
            print("Results")
            print(f"{'=' * 60}")
            print(f"Success: {result.success}")
            print(f"Steps: {result.num_steps}")

            if result.error:
                print(f"Error: {result.error}")

            # Check events
            events = storage.get_events()
            print(f"\nEvents captured: {len(events)}")

            # Look for espocrm URL in events
            espocrm_found = any("espocrm" in str(e).lower() for e in events)
            print(f"EspoCRM referenced: {espocrm_found}")

            # Check trajectory
            trajectory = storage.get_trajectory()
            print(f"Total events in trajectory: {trajectory['total_events']}")

            assert len(events) > 0, "No events captured"
            assert result.num_steps == 1

        finally:
            storage.close()

    @pytest.mark.asyncio
    async def test_world_provides_espocrm_url(self, temp_db_path: Path):
        """Test that World correctly provides espocrm URL to browser agent."""
        from plato.world.base import World
        from plato.world.config import EnvSpec, WorldConfig
        from plato.world.types import Observation, StepResult

        class TestWorld(World):
            async def _on_reset(self) -> Observation:
                return Observation(step=0, date=self.config.start_date, data={})

            async def _on_step(self) -> StepResult:
                return StepResult(
                    observation=Observation(step=self._current_step, date=self.current_date, data={}),
                    reward=0,
                    done=True,
                )

            def get_prompt(self) -> str:
                return "test"

        world = TestWorld(
            WorldConfig(
                name="url-test",
                envs=[EnvSpec(alias="espocrm", simulator="espocrm")],
                num_steps=1,
                start_date="2024-01-01",
            )
        )

        try:
            # Reset to create Plato session
            await world.reset()

            # Get URLs
            urls = world.get_connect_urls()
            env_vars = world.get_env_vars()

            print(f"\nConnect URLs: {urls}")
            print(f"Env vars: {env_vars}")

            assert "espocrm" in urls, "espocrm not in connect URLs"
            assert urls["espocrm"].startswith("http"), "Invalid espocrm URL"
            assert "ESPOCRM_BASE_URL" in env_vars, "ESPOCRM_BASE_URL not in env vars"

        finally:
            await world.close()


@pytest.mark.skipif(not HAS_DOCKER, reason="Docker not available")
@pytest.mark.skipif(not HAS_PLATO_KEY, reason="PLATO_API_KEY not set")
@pytest.mark.skipif(not HAS_GEMINI_KEY, reason="GEMINI_API_KEY not set")
class TestE2ERealBrowserAgent:
    """E2E tests with real browser agents (Gemini)."""

    @pytest.mark.asyncio
    async def test_gemini_browser_agent_with_espocrm(
        self, browser_agent_image: str, temp_workspace: Path, temp_db_path: Path
    ):
        """Test Gemini browser agent with espocrm.

        This is a full E2E test with a real AI model controlling the browser.
        """
        from plato.agent.browser import BrowserAgent, BrowserAgentConfig
        from plato.runner import RunnerConfig, SimpleRunner
        from plato.storage import RolloutStorage

        from plato.world.base import World
        from plato.world.config import EnvSpec, WorldConfig
        from plato.world.types import Observation, StepResult

        class EspoCRMWorld(World):
            """World with espocrm for Gemini agent."""

            async def _on_reset(self) -> Observation:
                return Observation(
                    step=0,
                    date=self.config.start_date,
                    data={"simulator": "espocrm"},
                )

            async def _on_step(self) -> StepResult:
                return StepResult(
                    observation=Observation(
                        step=self._current_step,
                        date=self.current_date,
                        data={},
                    ),
                    reward=1.0,
                    done=True,
                )

            def get_prompt(self) -> str:
                urls = self.get_connect_urls()
                espocrm_url = urls.get("espocrm", "unknown")
                return f"""You are a browser automation agent.

Navigate to the EspoCRM application at: {espocrm_url}

Your task:
1. Navigate to the URL
2. Take a screenshot of the login page
3. Report what you see on the page

Be concise in your response.
"""

        world_config = WorldConfig(
            name="espocrm-gemini-test",
            envs=[EnvSpec(alias="espocrm", simulator="espocrm")],
            num_steps=1,
            start_date="2024-01-01",
        )

        world = EspoCRMWorld(world_config)
        # Use BrowserAgent with gemini model
        agent = BrowserAgent(
            BrowserAgentConfig(
                model="gemini-2.0-flash",  # Use Gemini model
                timeout_seconds=300,
                docker_image=TEST_IMAGE_NAME,  # Use locally built image
            )
        )

        storage = RolloutStorage(
            run_id="espocrm-gemini-e2e",
            agent_type=agent.name,
            model=agent.config.model,
            world_name=world.config.name,
            db_path=temp_db_path,
        )

        try:
            runner = SimpleRunner(
                agents=agent,
                world=world,
                config=RunnerConfig(save_to_storage=False),
            )
            runner._storage = storage
            world._storage = storage

            print(f"\n{'=' * 60}")
            print("E2E Test: Gemini Browser Agent with EspoCRM")
            print(f"{'=' * 60}")
            print(f"Run ID: {runner.run_id}")
            print(f"Model: {agent.config.model}")

            result = await runner.run()

            print(f"\n{'=' * 60}")
            print("Results")
            print(f"{'=' * 60}")
            print(f"Success: {result.success}")
            print(f"Steps: {result.num_steps}")

            if result.error:
                print(f"Error: {result.error}")

            # Check events
            events = storage.get_events()
            print(f"\nEvents captured: {len(events)}")
            for event in events[:15]:
                content = event.get("content", "")
                if content:
                    content = content[:80] + "..." if len(content) > 80 else content
                print(f"  [{event['event_type']}] {content}")

            trajectory = storage.get_trajectory()
            print(f"\nTrajectory total events: {trajectory['total_events']}")

            assert len(events) > 0, "No events captured"

        finally:
            storage.close()
