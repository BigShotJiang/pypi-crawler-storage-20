"""Integration tests for AgentRunner Chronos callbacks.

Tests that the AgentRunner automatically pushes logs and uploads artifacts
to a Chronos server when chronos_server and session_id are provided.

These tests require:
- Docker installed and running
- GCR authentication for the agent images

Run with:
    RUN_HARBOR_TESTS=1 GEMINI_API_KEY=... pytest tests/integration/test_chronos_callback.py -v -s
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import subprocess
import tempfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread

import pytest


def _cleanup_docker_dir(path: str) -> None:
    """Clean up directory that may contain root-owned files from Docker."""
    try:
        shutil.rmtree(path)
    except PermissionError:
        subprocess.run(["sudo", "rm", "-rf", path], check=False)


class MockChronosHandler(BaseHTTPRequestHandler):
    """HTTP handler that captures Chronos callbacks."""

    # Class-level storage for received requests
    received_requests: list[dict] = []

    def log_message(self, format, *args):
        """Suppress HTTP server logs."""
        pass

    def do_POST(self):
        """Handle POST requests."""
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)

        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            data = {"raw": body.decode()}

        # Store the request
        MockChronosHandler.received_requests.append(
            {
                "path": self.path,
                "data": data,
            }
        )

        # Send success response
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()

        # Return appropriate response based on endpoint
        if self.path == "/api/callback/logs":
            response = {"success": True, "count": len(data.get("logs", []))}
        elif self.path == "/api/callback/artifacts":
            response = {"success": True, "logs_url": "s3://test-bucket/logs.zip"}
        elif self.path == "/api/callback/status":
            response = {"success": True, "count": 1}
        else:
            response = {"success": True}

        self.wfile.write(json.dumps(response).encode())


@pytest.fixture
def mock_chronos_server():
    """Start a mock Chronos HTTP server."""
    # Clear any previous requests
    MockChronosHandler.received_requests = []

    # Find a free port
    server = HTTPServer(("127.0.0.1", 0), MockChronosHandler)
    port = server.server_address[1]

    # Run server in background thread
    thread = Thread(target=server.serve_forever)
    thread.daemon = True
    thread.start()

    yield f"http://127.0.0.1:{port}"

    # Shutdown
    server.shutdown()


@pytest.fixture
def temp_workspace():
    """Create a temporary workspace directory."""
    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, "test.py")
    with open(test_file, "w") as f:
        f.write("# Test file\nprint('hello')\n")
    yield tmpdir
    _cleanup_docker_dir(tmpdir)


@pytest.fixture
def temp_logs_dir():
    """Create a temporary logs directory."""
    tmpdir = tempfile.mkdtemp()
    yield tmpdir
    _cleanup_docker_dir(tmpdir)


@pytest.fixture
def openhands_image():
    """OpenHands ECR image."""
    return "383806609161.dkr.ecr.us-west-1.amazonaws.com/agents/plato/openhands:1.0.7"


@pytest.fixture
def openhands_config():
    """OpenHands agent config."""
    return {"model_name": "gemini/gemini-3-flash-preview"}


@pytest.fixture
def secrets():
    """Secrets from environment."""
    gemini_key = os.environ.get("GEMINI_API_KEY", "")
    if gemini_key:
        return {"gemini_api_key": gemini_key}

    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if anthropic_key:
        return {"anthropic_api_key": anthropic_key}

    pytest.skip("GEMINI_API_KEY or ANTHROPIC_API_KEY not set")
    return {}


class TestChronosCallback:
    """Test AgentRunner Chronos callback integration."""

    @pytest.mark.skipif(
        os.environ.get("RUN_HARBOR_TESTS") != "1",
        reason="Set RUN_HARBOR_TESTS=1 to run harbor integration tests",
    )
    @pytest.mark.asyncio
    async def test_agent_runner_with_chronos_callbacks(
        self,
        mock_chronos_server: str,
        temp_workspace: str,
        temp_logs_dir: str,
        openhands_image: str,
        openhands_config: dict,
        secrets: dict,
    ):
        """Test that AgentRunner automatically sends callbacks to Chronos."""
        from plato.agents import AgentRunner

        session_id = "test-session-123"
        instruction = "Create a file called hello.txt with 'hello' in it."

        output_lines = []
        result = AgentRunner.run(
            image=openhands_image,
            config=openhands_config,
            secrets=secrets,
            instruction=instruction,
            workspace=temp_workspace,
            logs_dir=temp_logs_dir,
            pull=False,  # Assume image is already pulled
            chronos_server=mock_chronos_server,
            session_id=session_id,
        )

        async for line in result:
            print(line)
            output_lines.append(line)

        # Give a moment for final callbacks to complete
        await asyncio.sleep(0.5)

        # Verify callbacks were received
        requests = MockChronosHandler.received_requests
        print(f"\nReceived {len(requests)} callback requests:")
        for req in requests:
            print(f"  {req['path']}: {list(req['data'].keys())}")

        # Should have received at least:
        # 1. Start log
        # 2. Some log batches during execution
        # 3. Completion log
        # 4. Artifacts upload
        assert len(requests) >= 2, f"Expected at least 2 requests, got {len(requests)}"

        # Check for logs callback
        logs_requests = [r for r in requests if r["path"] == "/api/callback/logs"]
        assert len(logs_requests) >= 1, "Expected at least one logs callback"

        # Verify session_id is correct in all requests
        for req in requests:
            assert req["data"].get("session_id") == session_id, (
                f"Expected session_id={session_id}, got {req['data'].get('session_id')}"
            )

        # Check for artifacts callback
        artifacts_requests = [r for r in requests if r["path"] == "/api/callback/artifacts"]
        assert len(artifacts_requests) == 1, "Expected exactly one artifacts callback"

        # Verify artifacts contain trajectory or logs
        artifacts_data = artifacts_requests[0]["data"]
        assert "logs_base64" in artifacts_data or "trajectory" in artifacts_data, (
            "Expected logs_base64 or trajectory in artifacts"
        )

        # If logs were provided, verify they're base64 encoded
        if artifacts_data.get("logs_base64"):
            import base64

            # Should be valid base64
            try:
                decoded = base64.b64decode(artifacts_data["logs_base64"])
                assert len(decoded) > 0, "Expected non-empty logs zip"
                print(f"\nLogs zip size: {len(decoded)} bytes")
            except Exception as e:
                pytest.fail(f"Invalid base64 logs data: {e}")


class TestChronosCallbackUnit:
    """Unit tests for ChronosCallback class."""

    def test_callback_disabled_without_server(self):
        """Test that callback is disabled when no server is provided."""
        from plato.agents import ChronosCallback

        callback = ChronosCallback(chronos_server="", session_id="test")
        assert not callback.enabled

    def test_callback_disabled_without_session(self):
        """Test that callback is disabled when no session_id is provided."""
        from plato.agents import ChronosCallback

        callback = ChronosCallback(chronos_server="http://example.com", session_id="")
        assert not callback.enabled

    def test_callback_enabled_with_both(self):
        """Test that callback is enabled when both are provided."""
        from plato.agents import ChronosCallback

        callback = ChronosCallback(
            chronos_server="http://example.com",
            session_id="test-123",
        )
        assert callback.enabled

    def test_find_trajectory_not_found(self):
        """Test find_trajectory returns None when no trajectory exists."""
        from plato.agents import ChronosCallback

        callback = ChronosCallback(chronos_server="http://x", session_id="y")

        with tempfile.TemporaryDirectory() as tmpdir:
            result = callback.find_trajectory(tmpdir)
            assert result is None

    def test_find_trajectory_found(self):
        """Test find_trajectory finds trajectory.json."""
        from plato.agents import ChronosCallback

        callback = ChronosCallback(chronos_server="http://x", session_id="y")

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create trajectory file
            trajectory = {"steps": [{"action": "test"}]}
            traj_file = os.path.join(tmpdir, "trajectory.json")
            with open(traj_file, "w") as f:
                json.dump(trajectory, f)

            result = callback.find_trajectory(tmpdir)
            assert result == trajectory

    def test_zip_logs_dir(self):
        """Test zip_logs_dir creates valid zip."""
        import io
        import zipfile

        from plato.agents import ChronosCallback

        callback = ChronosCallback(chronos_server="http://x", session_id="y")

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create some files
            with open(os.path.join(tmpdir, "test.log"), "w") as f:
                f.write("test log content")
            os.makedirs(os.path.join(tmpdir, "subdir"))
            with open(os.path.join(tmpdir, "subdir", "nested.log"), "w") as f:
                f.write("nested content")

            # Zip it
            zip_bytes = callback.zip_logs_dir(tmpdir)

            # Verify it's a valid zip
            zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
            names = zf.namelist()
            assert "test.log" in names
            assert "subdir/nested.log" in names or "subdir\\nested.log" in names
