"""Integration tests for World + Plato Session.

Tests the World class with real Plato sessions to verify:
- Session creation and environment provisioning
- Environment variable passing (connect URLs)
- Date advancement
- Session cleanup

Run with:
    pytest tests/integration/test_world_session.py -v -s

Requires:
    - PLATO_API_KEY environment variable
"""

from __future__ import annotations

import os

import pytest

from plato.world.base import World
from plato.world.config import EnvSpec, WorldConfig
from plato.world.types import Observation, StepResult

# Skip if no API key
pytestmark = pytest.mark.skipif(
    not os.environ.get("PLATO_API_KEY"),
    reason="PLATO_API_KEY not set",
)


class SimpleTestWorld(World):
    """Simple world implementation for testing."""

    async def _on_reset(self) -> Observation:
        return Observation(
            step=0,
            date=self.config.start_date,
            data={"initialized": True},
        )

    async def _on_step(self) -> StepResult:
        return StepResult(
            observation=Observation(
                step=self._current_step,
                date=self.current_date,
                data={"step": self._current_step},
            ),
            reward=1.0,
            done=self._current_step >= self.config.num_steps,
        )

    def get_prompt(self) -> str:
        return f"Step {self._current_step}"


class TestWorldWithPlatoSession:
    """Test World with real Plato session."""

    @pytest.mark.asyncio
    async def test_world_creates_session(self):
        """Test that World.reset() creates a Plato session."""
        config = WorldConfig(
            name="session-test",
            envs=[EnvSpec(alias="espocrm", simulator="espocrm")],
            num_steps=1,
            start_date="2024-01-01",
            session_timeout=300,
        )

        world = SimpleTestWorld(config)

        try:
            obs = await world.reset()

            # Session should be created
            assert world.session is not None
            assert world.session.session_id is not None

            # Check observation
            assert obs.step == 0
            assert obs.date == "2024-01-01"
            assert obs.data["initialized"] is True

            print(f"\nSession created: {world.session.session_id}")
            print(f"Initial observation: {obs}")

        finally:
            await world.close()

    @pytest.mark.asyncio
    async def test_world_provides_connect_urls(self):
        """Test that World provides connect URLs as env vars."""
        config = WorldConfig(
            name="url-test",
            envs=[
                EnvSpec(alias="espocrm", simulator="espocrm"),
            ],
            num_steps=1,
            start_date="2024-01-01",
            session_timeout=300,
        )

        world = SimpleTestWorld(config)

        try:
            await world.reset()

            # Get env vars
            env_vars = world.get_env_vars()

            # Should have URL for espocrm
            assert "ESPOCRM_BASE_URL" in env_vars
            assert env_vars["ESPOCRM_BASE_URL"].startswith("http")

            # Should have simulation date
            assert env_vars["SIMULATION_DATE"] == "2024-01-01"
            assert env_vars["SIMULATION_STEP"] == "0"

            print("\nEnvironment variables:")
            for k, v in sorted(env_vars.items()):
                print(f"  {k}={v}")

        finally:
            await world.close()

    @pytest.mark.asyncio
    async def test_world_step_advances_date(self):
        """Test that World.step() advances the simulation date."""
        config = WorldConfig(
            name="date-test",
            envs=[EnvSpec(alias="espocrm", simulator="espocrm")],
            num_steps=3,
            start_date="2024-01-01",
            session_timeout=300,
        )

        world = SimpleTestWorld(config)

        try:
            await world.reset()
            assert world.current_date == "2024-01-01"

            # Step 1
            result1 = await world.step()
            assert world.current_date == "2024-01-02"
            assert result1.observation.step == 1

            # Step 2
            result2 = await world.step()
            assert world.current_date == "2024-01-03"
            assert result2.observation.step == 2

            # Step 3 (should be done)
            result3 = await world.step()
            assert world.current_date == "2024-01-04"
            assert result3.done is True

            print("\nDate progression:")
            print("  Start: 2024-01-01")
            print("  After step 1: 2024-01-02")
            print("  After step 2: 2024-01-03")
            print("  After step 3: 2024-01-04 (done)")

        finally:
            await world.close()

    @pytest.mark.asyncio
    async def test_world_multiple_environments(self):
        """Test World with multiple environments (using same simulator with different aliases)."""
        config = WorldConfig(
            name="multi-env-test",
            envs=[
                EnvSpec(alias="crm", simulator="espocrm"),
                EnvSpec(alias="crm2", simulator="espocrm"),
            ],
            num_steps=1,
            start_date="2024-01-01",
            session_timeout=300,
        )

        world = SimpleTestWorld(config)

        try:
            await world.reset()

            # Should have URLs for both
            urls = world.get_connect_urls()
            assert "crm" in urls
            assert "crm2" in urls

            env_vars = world.get_env_vars()
            assert "CRM_BASE_URL" in env_vars
            assert "CRM2_BASE_URL" in env_vars

            print("\nMultiple environment URLs:")
            for alias, url in urls.items():
                print(f"  {alias}: {url}")

        finally:
            await world.close()

    @pytest.mark.asyncio
    async def test_world_context_manager(self):
        """Test World as async context manager."""
        config = WorldConfig(
            name="context-test",
            envs=[EnvSpec(alias="espocrm", simulator="espocrm")],
            num_steps=1,
            start_date="2024-01-01",
            session_timeout=300,
        )

        async with SimpleTestWorld(config) as world:
            await world.reset()
            assert world.session is not None

            result = await world.step()
            assert result.done is True

        # Session should be closed
        assert world.session is None

    @pytest.mark.asyncio
    async def test_world_error_before_reset(self):
        """Test that step() raises error if called before reset()."""
        config = WorldConfig(
            name="error-test",
            envs=[EnvSpec(alias="espocrm", simulator="espocrm")],
            num_steps=1,
            start_date="2024-01-01",
        )

        world = SimpleTestWorld(config)

        with pytest.raises(RuntimeError, match="not initialized"):
            await world.step()


class TestWorldWithStorage:
    """Test World with RolloutStorage."""

    @pytest.mark.asyncio
    async def test_world_logs_to_storage(self, temp_db_path):
        """Test that World logs steps to storage."""
        from plato.storage import RolloutStorage

        config = WorldConfig(
            name="storage-test",
            envs=[EnvSpec(alias="espocrm", simulator="espocrm")],
            num_steps=2,
            start_date="2024-01-01",
            session_timeout=300,
        )

        storage = RolloutStorage(
            run_id="world-storage-test",
            agent_type="test",
            model="test",
            world_name=config.name,
            db_path=temp_db_path,
        )

        world = SimpleTestWorld(config, storage=storage)

        try:
            await world.reset()
            await world.step()
            await world.step()

            # Check storage has steps
            steps = storage.get_steps()
            assert len(steps) >= 2

            print(f"\nStored {len(steps)} steps:")
            for step in steps:
                print(f"  Step {step['step_number']}: reward={step['reward']}, done={step['done']}")

        finally:
            await world.close()
            storage.finalize(success=True)
            storage.close()
