"""Integration tests for OpenHandsAgent with real OpenHands SDK.

These tests require:
- OpenHands SDK installed (pip install openhands-ai)
- Docker running
- ANTHROPIC_API_KEY or OPENAI_API_KEY environment variable
- PLATO_API_KEY for tests with Plato session

Run with:
    pytest tests/integration/test_openhands_agent.py -v -s

For quick smoke test (no Plato session):
    pytest tests/integration/test_openhands_agent.py::TestOpenHandsAgentBasic -v -s
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    pass


# Check if OpenHands is available
import importlib.util

HAS_OPENHANDS = importlib.util.find_spec("openhands") is not None

# Check for API keys
HAS_ANTHROPIC_KEY = bool(os.environ.get("ANTHROPIC_API_KEY"))
HAS_OPENAI_KEY = bool(os.environ.get("OPENAI_API_KEY"))
HAS_LLM_KEY = HAS_ANTHROPIC_KEY or HAS_OPENAI_KEY


@pytest.mark.skipif(not HAS_OPENHANDS, reason="OpenHands SDK not installed")
@pytest.mark.skipif(not HAS_LLM_KEY, reason="No LLM API key (ANTHROPIC_API_KEY or OPENAI_API_KEY)")
class TestOpenHandsAgentBasic:
    """Basic OpenHands agent tests without Plato session."""

    @pytest.fixture
    def model(self) -> str:
        """Get model based on available API key."""
        if HAS_ANTHROPIC_KEY:
            return "anthropic/claude-sonnet-4-20250514"
        elif HAS_OPENAI_KEY:
            return "openai/gpt-4o-mini"
        else:
            pytest.skip("No API key available")

    @pytest.mark.asyncio
    async def test_openhands_agent_simple_task(self, model: str, temp_workspace: Path):
        """Test OpenHands agent can complete a simple task."""
        from plato.agent import OpenHandsAgent, OpenHandsConfig
        from plato.runtime import DockerRuntime, DockerRuntimeConfig

        agent = OpenHandsAgent(
            OpenHandsConfig(
                model=model,
                max_iterations=10,
                timeout_seconds=120,
            )
        )

        runtime = DockerRuntime(
            name="openhands-test",
            image=agent.image,
            config=DockerRuntimeConfig(workspace_base=temp_workspace),
        )

        try:
            result = await agent.take_turn(
                prompt="Create a file called hello.txt with the content 'Hello, World!'",
                runtime=runtime,
                env_vars={},
            )

            # Check result
            assert result.elapsed_seconds > 0
            assert len(result.events) > 0

            # Log events for debugging
            print(f"\nAgent completed in {result.elapsed_seconds:.1f}s")
            print(f"Success: {result.success}")
            print(f"Events captured: {len(result.events)}")
            for event in result.events[:10]:
                print(f"  - {event.event_type}: {event.content[:80] if event.content else 'N/A'}")

            if result.error:
                print(f"Error: {result.error}")

        finally:
            runtime.cleanup()

    @pytest.mark.asyncio
    async def test_openhands_events_stream_to_storage(self, model: str, temp_workspace: Path, temp_db_path: Path):
        """Test that OpenHands events are streamed to storage in real-time."""
        from plato.agent import OpenHandsAgent, OpenHandsConfig
        from plato.runtime import DockerRuntime, DockerRuntimeConfig
        from plato.storage import RolloutStorage

        agent = OpenHandsAgent(
            OpenHandsConfig(
                model=model,
                max_iterations=5,
                timeout_seconds=60,
            )
        )

        runtime = DockerRuntime(
            name="openhands-storage-test",
            image=agent.image,
            config=DockerRuntimeConfig(workspace_base=temp_workspace),
        )

        storage = RolloutStorage(
            run_id="openhands-storage-test",
            agent_type=agent.name,
            model=model,
            world_name="test-world",
            db_path=temp_db_path,
        )

        try:
            result = await agent.take_turn(
                prompt="Print 'Hello' to the console",
                runtime=runtime,
                env_vars={},
                storage=storage,
            )

            # Check storage captured events
            events = storage.get_events()
            print(f"\nStored {len(events)} events to database")

            # Events should have been streamed
            assert len(events) > 0, "No events were stored"

            # Check event structure
            for event in events[:5]:
                assert "event_type" in event
                assert "timestamp" in event
                assert "source" in event
                print(f"  - {event['event_type']} from {event['source']}")

        finally:
            runtime.cleanup()
            storage.finalize(success=result.success if result else False)
            storage.close()


@pytest.mark.skipif(not HAS_OPENHANDS, reason="OpenHands SDK not installed")
@pytest.mark.skipif(not HAS_LLM_KEY, reason="No LLM API key")
@pytest.mark.skipif(not os.environ.get("PLATO_API_KEY"), reason="PLATO_API_KEY not set")
class TestOpenHandsWithPlatoSession:
    """OpenHands agent tests with real Plato session."""

    @pytest.fixture
    def model(self) -> str:
        if HAS_ANTHROPIC_KEY:
            return "anthropic/claude-sonnet-4-20250514"
        elif HAS_OPENAI_KEY:
            return "openai/gpt-4o-mini"
        else:
            pytest.skip("No API key available")

    @pytest.mark.asyncio
    async def test_openhands_with_plato_world(self, model: str, temp_workspace: Path, temp_db_path: Path):
        """Test OpenHands agent running against real Plato simulator."""
        from plato.agent import OpenHandsAgent, OpenHandsConfig
        from plato.runner import RunnerConfig, SimpleRunner
        from plato.storage import RolloutStorage

        from plato.world.base import World
        from plato.world.config import EnvSpec, WorldConfig
        from plato.world.types import Observation, StepResult

        # Create a real world with Plato session
        class IntegrationTestWorld(World):
            async def _on_reset(self) -> Observation:
                return Observation(
                    step=0,
                    date=self.config.start_date,
                    data={"status": "ready"},
                )

            async def _on_step(self) -> StepResult:
                return StepResult(
                    observation=Observation(
                        step=self._current_step,
                        date=self.current_date,
                        data={"status": "stepped"},
                    ),
                    reward=0.0,
                    done=self._current_step >= self.config.num_steps,
                )

            def get_prompt(self) -> str:
                urls = self.get_connect_urls()
                url_list = "\n".join(f"  - {k}: {v}" for k, v in urls.items())
                return f"""You have access to the following services:
{url_list}

Task: List the files in your current directory using bash.
"""

        world_config = WorldConfig(
            name="openhands-integration-test",
            envs=[EnvSpec(alias="spree", simulator="spree:staging-latest")],
            num_steps=1,
            start_date="2024-01-01",
        )

        world = IntegrationTestWorld(world_config)
        agent = OpenHandsAgent(
            OpenHandsConfig(
                model=model,
                max_iterations=10,
                timeout_seconds=180,
            )
        )

        from plato.runtime import DockerRuntimeConfig

        # Patch workspace
        original_init = DockerRuntimeConfig.__init__

        def patched_init(self, **kwargs):
            kwargs.setdefault("workspace_base", temp_workspace)
            original_init(self, **kwargs)

        DockerRuntimeConfig.__init__ = patched_init

        try:
            runner = SimpleRunner(
                agents=agent,
                world=world,
                config=RunnerConfig(save_to_storage=True, cleanup_workspaces=True),
            )

            # Use custom storage path
            runner._storage = RolloutStorage(
                run_id=runner.run_id,
                agent_type=agent.name,
                model=model,
                world_name=world.config.name,
                db_path=temp_db_path,
            )
            world._storage = runner._storage

            result = await runner.run()

            print(f"\nRun completed: {result.run_id}")
            print(f"Success: {result.success}")
            print(f"Steps: {result.num_steps}")
            print(f"Total reward: {result.total_reward}")

            if result.error:
                print(f"Error: {result.error}")

            # Check trajectory
            trajectory = runner._storage.get_trajectory()
            print(f"Total events captured: {trajectory['total_events']}")

        finally:
            DockerRuntimeConfig.__init__ = original_init
            if runner._storage:
                runner._storage.close()


@pytest.mark.skipif(not HAS_OPENHANDS, reason="OpenHands SDK not installed")
class TestOpenHandsConfig:
    """Test OpenHands configuration options."""

    def test_config_defaults(self):
        """Test default configuration values."""
        from plato.agent import OpenHandsConfig

        config = OpenHandsConfig(model="anthropic/claude-sonnet-4-20250514")

        assert config.model == "anthropic/claude-sonnet-4-20250514"
        assert config.max_iterations == 100
        assert config.timeout_seconds == 600
        assert config.agent_cls == "CodeActAgent"
        assert config.auto_continue is True
        assert config.runtime_type == "docker"
        assert config.enable_browser is False

    def test_config_custom_values(self):
        """Test custom configuration values."""
        from plato.agent import OpenHandsConfig

        config = OpenHandsConfig(
            model="openai/gpt-4o",
            max_iterations=50,
            timeout_seconds=300,
            agent_cls="BrowsingAgent",
            enable_browser=True,
        )

        assert config.model == "openai/gpt-4o"
        assert config.max_iterations == 50
        assert config.timeout_seconds == 300
        assert config.agent_cls == "BrowsingAgent"
        assert config.enable_browser is True

    def test_dev_mode_config(self):
        """Test dev mode with local code path."""
        from plato.agent import OpenHandsAgent, OpenHandsConfig

        config = OpenHandsConfig(
            model="anthropic/claude-sonnet-4-20250514",
            local_code_path="/tmp/fake-openhands",
        )

        agent = OpenHandsAgent(config)

        assert agent.local_code_path == "/tmp/fake-openhands"
        assert agent.code_mount_path == "/app/openhands"
