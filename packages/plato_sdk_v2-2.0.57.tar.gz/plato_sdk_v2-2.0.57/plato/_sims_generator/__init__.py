"""OpenAPI SDK Generator for Plato.

This module provides tools to generate Python SDKs from OpenAPI specifications.

Usage:
    from plato.sims.generator import parse_openapi, PythonGenerator, OAuthConfig

    api = parse_openapi(spec_dict)
    generator = PythonGenerator(
        api,
        output_path,
        spec=spec_dict,
        package_name="spree",
        env_prefix="SPREE",
        oauth_config=OAuthConfig(
            client_id="...",
            client_secret="...",
            token_endpoint="/spree_oauth/token",
            scope="admin",
        ),
    )
    generator.generate()

Or via CLI:
    uv run python -m plato.sims.generator.cli --path spec.yaml --output ./output --package mypackage
"""

from .parser import API, Endpoint, Schema, Type, parse_openapi
from .python import AuthConfig, BasicAuthConfig, BearerTokenConfig, OAuthConfig, PythonGenerator, SessionAuthConfig

__all__ = [
    "API",
    "Endpoint",
    "Schema",
    "Type",
    "parse_openapi",
    "PythonGenerator",
    "AuthConfig",
    "OAuthConfig",
    "BearerTokenConfig",
    "BasicAuthConfig",
    "SessionAuthConfig",
]
