"""Project Management CLI commands for Plato simulator workflow."""

import asyncio
import json
import os
import shutil
import tempfile
from pathlib import Path

import httpx
import typer
from playwright.async_api import async_playwright
from rich.table import Table

from plato._generated.api.v1.env import get_simulator_by_name, get_simulators
from plato._generated.api.v1.simulator import (
    add_simulator_review,
    update_simulator_status,
    update_tag,
)
from plato._generated.api.v2.sessions import state as sessions_state
from plato._generated.models import (
    AddReviewRequest,
    Outcome,
    ReviewType,
    UpdateStatusRequest,
    UpdateTagRequest,
)
from plato.v1.cli.utils import (
    console,
    handle_async,
    read_plato_config,
    require_api_key,
    require_plato_config_field,
    require_sandbox_field,
    require_sandbox_state,
)
from plato.v2.async_.client import AsyncPlato
from plato.v2.types import Env

# =============================================================================
# APP STRUCTURE
# =============================================================================

pm_app = typer.Typer(help="Project management for simulator workflow")
list_app = typer.Typer(help="List simulators pending review")
review_app = typer.Typer(help="Review simulator artifacts")
submit_app = typer.Typer(help="Submit simulator artifacts for review")

pm_app.add_typer(list_app, name="list")
pm_app.add_typer(review_app, name="review")
pm_app.add_typer(submit_app, name="submit")


# =============================================================================
# SHARED HELPERS
# =============================================================================


def _get_base_url() -> str:
    """Get base URL with /api suffix stripped."""
    base_url = os.getenv("PLATO_BASE_URL", "https://plato.so")
    if base_url.endswith("/api"):
        base_url = base_url[:-4]
    return base_url.rstrip("/")


def validate_status_transition(current_status: str, expected_status: str, command_name: str):
    """Validate that current status matches expected status for the command."""
    if current_status != expected_status:
        console.print(f"[red]❌ Invalid status for {command_name}[/red]")
        console.print(f"\n[yellow]Current status:[/yellow]  {current_status}")
        console.print(f"[yellow]Expected status:[/yellow] {expected_status}")
        console.print(f"\n[yellow]Cannot run {command_name} from status '{current_status}'[/yellow]")
        raise typer.Exit(1)


# =============================================================================
# LIST COMMANDS
# =============================================================================


def _list_pending_reviews(review_type: str):
    """Shared logic for listing pending reviews."""
    api_key = require_api_key()

    target_status = "env_review_requested" if review_type == "base" else "data_review_requested"

    async def _list_reviews():
        base_url = _get_base_url()

        async with httpx.AsyncClient(base_url=base_url, timeout=60.0) as client:
            simulators = await get_simulators.asyncio(
                client=client,
                x_api_key=api_key,
            )

            # Filter by target status
            pending_review = []
            for sim in simulators:
                config = sim.get("config", {}) if isinstance(sim, dict) else getattr(sim, "config", {})
                status = config.get("status", "not_started") if isinstance(config, dict) else "not_started"
                if status == target_status:
                    pending_review.append(sim)

            if not pending_review:
                console.print(f"[yellow]No simulators pending {review_type} review (status: {target_status})[/yellow]")
                return

            # Build table
            table = Table(title=f"Simulators Pending {review_type.title()} Review")
            table.add_column("Name", style="cyan", no_wrap=True)
            table.add_column("Notes", style="white", max_width=40)
            artifact_col_name = "base_artifact_id" if review_type == "base" else "data_artifact_id"
            table.add_column(artifact_col_name, style="green", no_wrap=True)

            for sim in pending_review:
                if isinstance(sim, dict):
                    name = sim.get("name", "N/A")
                    config = sim.get("config", {})
                else:
                    name = getattr(sim, "name", "N/A")
                    config = getattr(sim, "config", {})

                notes = config.get("notes", "") if isinstance(config, dict) else ""
                notes = notes or "-"
                artifact_key = "base_artifact_id" if review_type == "base" else "data_artifact_id"
                artifact_id = config.get(artifact_key, "") if isinstance(config, dict) else ""
                artifact_id = artifact_id or "-"

                table.add_row(name, notes, artifact_id)

            console.print(table)
            console.print(f"\n[cyan]Total: {len(pending_review)} simulator(s) pending {review_type} review[/cyan]")

    handle_async(_list_reviews())


@list_app.command(name="base")
def list_base():
    """
    List simulators pending base/environment review.

    Shows all simulators with status: env_review_requested

    Example:
        plato pm list base
    """
    _list_pending_reviews("base")


@list_app.command(name="data")
def list_data():
    """
    List simulators pending data review.

    Shows all simulators with status: data_review_requested

    Example:
        plato pm list data
    """
    _list_pending_reviews("data")


# =============================================================================
# REVIEW COMMANDS
# =============================================================================


@review_app.command(name="base")
def review_base(
    simulator: str = typer.Option(None, "--simulator", "-s", help="Simulator name"),
    artifact: str = typer.Option(None, "--artifact", "-a", help="Artifact ID (uses base_artifact_id if not provided)"),
):
    """
    Review base/environment artifact session (reviewer testing the environment).

    Opens simulator with artifact in browser for manual testing.
    At the end, prompts to pass (→ env_approved) or reject (→ env_in_progress).

    Requires simulator status: env_review_requested

    Example:
        plato pm review base --simulator espocrm
        plato pm review base -s espocrm -a abc123
    """
    api_key = require_api_key()

    # Track if simulator was provided via CLI arg
    simulator_provided_via_arg = simulator is not None

    # Use arg or prompt for simulator name
    simulator_name = simulator
    if not simulator_name:
        simulator_name = typer.prompt("Enter simulator name").strip()
    if not simulator_name:
        console.print("[red]❌ Simulator name is required[/red]")
        raise typer.Exit(1)

    # Artifact ID: use arg, or prompt only if simulator was NOT provided via arg
    artifact_id_input = artifact or ""
    if not artifact_id_input and not simulator_provided_via_arg:
        artifact_id_input = typer.prompt(
            "Enter artifact ID (or press Enter to use base_artifact_id)", default=""
        ).strip()

    async def _review_base():
        base_url = _get_base_url()
        plato = AsyncPlato(api_key=api_key, base_url=base_url)
        session = None
        playwright = None
        browser = None
        login_result = None

        try:
            http_client = plato._http

            # Get simulator by name
            sim = await get_simulator_by_name.asyncio(
                client=http_client,
                name=simulator_name,
                x_api_key=api_key,
            )
            simulator_id = sim.id
            current_config = sim.config or {}
            current_status = current_config.get("status", "not_started")

            console.print(f"[cyan]Current status:[/cyan] {current_status}")

            # Use provided artifact ID or fall back to base_artifact_id from config
            artifact_id = artifact_id_input if artifact_id_input else current_config.get("base_artifact_id")
            if not artifact_id:
                console.print("[red]❌ No artifact ID provided and simulator has no base_artifact_id set[/red]")
                raise typer.Exit(1)

            console.print(f"[cyan]Using artifact:[/cyan] {artifact_id}")

            # Try to create session with environment from artifact
            try:
                console.print(f"[cyan]Creating {simulator_name} environment with artifact {artifact_id}...[/cyan]")
                session = await plato.sessions.create(
                    envs=[Env.artifact(artifact_id)],
                    timeout=300,
                )
                console.print(f"[green]✅ Session created: {session.session_id}[/green]")

                # Reset
                console.print("[cyan]Resetting environment...[/cyan]")
                await session.reset()
                console.print("[green]✅ Environment reset complete![/green]")

                # Get public URL
                public_urls = await session.get_public_url()
                first_alias = session.envs[0].alias if session.envs else None
                public_url = public_urls.get(first_alias) if first_alias else None
                if not public_url and public_urls:
                    public_url = list(public_urls.values())[0]
                console.print(f"[cyan]Public URL:[/cyan] {public_url}")

                # Launch Playwright browser and login
                console.print("[cyan]Launching browser and logging in...[/cyan]")
                playwright = await async_playwright().start()
                browser = await playwright.chromium.launch(headless=False)

                try:
                    login_result = await session.login(browser, dataset="base")
                    page = list(login_result.pages.values())[0] if login_result.pages else None
                    console.print("[green]✅ Logged into environment[/green]")
                except Exception as e:
                    console.print(f"[yellow]⚠️  Login error: {e}[/yellow]")
                    page = await browser.new_page()
                    if public_url:
                        await page.goto(public_url)

                console.print("\n" + "=" * 60)
                console.print("[bold green]Environment Review Session Active[/bold green]")
                console.print("=" * 60)
                console.print("[bold]Commands:[/bold]")
                console.print("  - 'state' or 's': Show environment state and mutations")
                console.print("  - 'finish' or 'f': Exit loop and submit review outcome")
                console.print("=" * 60)

                # Show recent env review if available
                reviews = current_config.get("reviews", [])
                env_reviews = [r for r in reviews if r.get("review_type") == "env"]
                if env_reviews:
                    env_reviews.sort(key=lambda r: r.get("timestamp_iso", ""), reverse=True)
                    recent_review = env_reviews[0]
                    outcome = recent_review.get("outcome", "unknown")
                    timestamp = recent_review.get("timestamp_iso", "")[:10]
                    console.print()
                    if outcome == "reject":
                        console.print(f"[bold red]📋 Most Recent Base Review: REJECTED[/bold red] ({timestamp})")
                    else:
                        console.print(f"[bold green]📋 Most Recent Base Review: PASSED[/bold green] ({timestamp})")
                    comments = recent_review.get("comments")
                    if comments:
                        console.print(f"[yellow]Reviewer Comments:[/yellow] {comments}")

                console.print()

                # Interactive loop
                while True:
                    try:
                        command = input("Enter command: ").strip().lower()

                        if command in ["finish", "f"]:
                            console.print("\n[yellow]Finishing review...[/yellow]")
                            break
                        elif command in ["state", "s"]:
                            console.print("\n[cyan]Getting environment state with mutations...[/cyan]")
                            try:
                                # Call API directly with merge_mutations=True to include mutations
                                state_response = await sessions_state.asyncio(
                                    client=http_client,
                                    session_id=session.session_id,
                                    merge_mutations=True,
                                    x_api_key=api_key,
                                )
                                if state_response and state_response.results:
                                    for jid, result in state_response.results.items():
                                        state_data = result.state if hasattr(result, "state") else result
                                        if isinstance(state_data, dict):
                                            mutations = state_data.pop("mutations", [])
                                            console.print(f"\n[bold cyan]Job {jid}:[/bold cyan]")
                                            console.print("\n[bold]State:[/bold]")
                                            console.print(json.dumps(state_data, indent=2, default=str))
                                            if mutations:
                                                console.print(f"\n[bold]Mutations ({len(mutations)}):[/bold]")
                                                console.print(json.dumps(mutations, indent=2, default=str))
                                            else:
                                                console.print("\n[yellow]No mutations recorded[/yellow]")
                                        else:
                                            console.print(f"\n[bold cyan]Job {jid}:[/bold cyan]")
                                            console.print(json.dumps(state_data, indent=2, default=str))
                                else:
                                    console.print("[yellow]No state data available[/yellow]")
                                console.print()
                            except Exception as e:
                                console.print(f"[red]❌ Error getting state: {e}[/red]")
                        else:
                            console.print("[yellow]Unknown command. Use 'state' or 'finish'[/yellow]")

                    except KeyboardInterrupt:
                        console.print("\n[yellow]Interrupted! Finishing review...[/yellow]")
                        break

            except Exception as env_error:
                console.print(f"[yellow]⚠️  Environment creation failed: {env_error}[/yellow]")
                console.print("[yellow]You can still submit a review without testing the environment.[/yellow]")

            # Prompt for outcome
            console.print("\n[bold]Choose outcome:[/bold]")
            console.print("  1. pass")
            console.print("  2. reject")
            console.print("  3. skip (no status update)")
            outcome_choice = typer.prompt("Choice [1/2/3]").strip()

            if outcome_choice == "1":
                outcome = "pass"
            elif outcome_choice == "2":
                outcome = "reject"
            elif outcome_choice == "3":
                console.print("[yellow]Review session ended without status update[/yellow]")
                return
            else:
                console.print("[red]❌ Invalid choice. Aborting.[/red]")
                raise typer.Exit(1)

            # Validate status BEFORE submitting outcome
            if outcome == "pass":
                validate_status_transition(current_status, "env_review_requested", "review base pass")
                new_status = "env_approved"
            else:
                validate_status_transition(current_status, "env_review_requested", "review base reject")
                new_status = "env_in_progress"

            # Update status
            await update_simulator_status.asyncio(
                client=http_client,
                simulator_id=simulator_id,
                body=UpdateStatusRequest(status=new_status),
                x_api_key=api_key,
            )

            # Add review if rejecting
            if outcome == "reject":
                comments = ""
                while not comments:
                    comments = typer.prompt("Comments (required for reject)").strip()
                    if not comments:
                        console.print("[yellow]Comments are required when rejecting. Please provide feedback.[/yellow]")

                await add_simulator_review.asyncio(
                    client=http_client,
                    simulator_id=simulator_id,
                    body=AddReviewRequest(
                        review_type=ReviewType.env,
                        outcome=Outcome.reject,
                        artifact_id=artifact_id,
                        comments=comments,
                    ),
                    x_api_key=api_key,
                )

            console.print(f"[green]✅ Review submitted: {outcome}[/green]")
            console.print(f"[cyan]Status:[/cyan] {current_status} → {new_status}")

            # If passed, automatically tag artifact as prod-latest
            if outcome == "pass":
                console.print("\n[cyan]Tagging artifact as prod-latest...[/cyan]")
                try:
                    await update_tag.asyncio(
                        client=http_client,
                        body=UpdateTagRequest(
                            simulator_name=simulator_name,
                            artifact_id=artifact_id,
                            tag_name="prod-latest",
                            dataset="base",
                        ),
                        x_api_key=api_key,
                    )
                    console.print(f"[green]✅ Tagged {artifact_id[:8]}... as prod-latest[/green]")
                except Exception as e:
                    console.print(f"[yellow]⚠️  Could not tag as prod-latest: {e}[/yellow]")

        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"[red]❌ Error during review session: {e}[/red]")
            raise

        finally:
            # Cleanup
            try:
                if login_result and login_result.context:
                    await login_result.context.close()
                if browser:
                    await browser.close()
                if playwright:
                    await playwright.stop()
            except Exception as e:
                console.print(f"[yellow]⚠️  Browser cleanup error: {e}[/yellow]")

            if session:
                try:
                    console.print("[cyan]Shutting down session...[/cyan]")
                    await session.close()
                    console.print("[green]✅ Session shut down[/green]")
                except Exception as e:
                    console.print(f"[yellow]⚠️  Session cleanup error: {e}[/yellow]")

            try:
                await plato.close()
            except Exception as e:
                console.print(f"[yellow]⚠️  Client cleanup error: {e}[/yellow]")

    handle_async(_review_base())


@review_app.command(name="data")
def review_data(
    simulator: str = typer.Option(
        None, "--simulator", "-s", help="Simulator name (navigates to {simulator}.web.plato.so)"
    ),
):
    """
    Launch browser with EnvGen Recorder extension for data review.

    Opens Chrome with the extension installed. If --simulator is provided,
    navigates to {simulator}.web.plato.so and auto-loads the sim in the extension.
    Otherwise navigates to sims.plato.so.

    When done, simply close the browser to exit.

    Example:
        plato pm review data
        plato pm review data -s fathom
    """
    api_key = require_api_key()

    # Determine target URL based on simulator
    if simulator:
        target_url = f"https://{simulator}.web.plato.so"
        console.print(f"[cyan]Simulator:[/cyan] {simulator}")
    else:
        target_url = "https://sims.plato.so"

    # If simulator provided, fetch and show recent data reviews
    recent_review = None
    if simulator:

        async def _fetch_recent_review():
            base_url = _get_base_url()
            async with httpx.AsyncClient(base_url=base_url, timeout=60.0) as client:
                try:
                    sim = await get_simulator_by_name.asyncio(
                        client=client,
                        name=simulator,
                        x_api_key=api_key,
                    )
                    config = sim.config or {}
                    reviews = config.get("reviews", [])
                    # Find most recent data review
                    data_reviews = [r for r in reviews if r.get("review_type") == "data"]
                    if data_reviews:
                        # Sort by timestamp (most recent first)
                        data_reviews.sort(key=lambda r: r.get("timestamp_iso", ""), reverse=True)
                        return data_reviews[0]
                except Exception as e:
                    console.print(f"[yellow]⚠️  Could not fetch recent reviews: {e}[/yellow]")
                return None

        recent_review = handle_async(_fetch_recent_review())

    # Find Chrome extension source
    package_dir = Path(__file__).resolve().parent.parent  # v1/
    is_installed = "site-packages" in str(package_dir)

    if is_installed:
        extension_source_path = package_dir / "extensions" / "envgen-recorder"
    else:
        repo_root = package_dir.parent.parent.parent  # plato-client/
        extension_source_path = repo_root / "extensions" / "envgen-recorder"

    # Fallback to env var
    if not extension_source_path.exists():
        plato_client_dir_env = os.getenv("PLATO_CLIENT_DIR")
        if plato_client_dir_env:
            env_path = Path(plato_client_dir_env) / "extensions" / "envgen-recorder"
            if env_path.exists():
                extension_source_path = env_path

    if not extension_source_path.exists():
        console.print("[red]❌ EnvGen Recorder extension not found[/red]")
        console.print(f"\n[yellow]Expected location:[/yellow] {extension_source_path}")
        raise typer.Exit(1)

    # Copy extension to temp directory
    temp_ext_dir = Path(tempfile.mkdtemp(prefix="plato-extension-"))
    extension_path = temp_ext_dir / "envgen-recorder"

    console.print("[cyan]Copying extension to temp directory...[/cyan]")
    shutil.copytree(extension_source_path, extension_path, dirs_exist_ok=False)
    console.print(f"[green]✅ Extension copied to: {extension_path}[/green]")

    async def _review_data():
        playwright = None
        browser = None

        try:
            user_data_dir = Path.home() / ".plato" / "chrome-data"
            user_data_dir.mkdir(parents=True, exist_ok=True)

            console.print("[cyan]Launching Chrome with EnvGen Recorder extension...[/cyan]")

            playwright = await async_playwright().start()

            browser = await playwright.chromium.launch_persistent_context(
                str(user_data_dir),
                headless=False,
                args=[
                    f"--disable-extensions-except={extension_path}",
                    f"--load-extension={extension_path}",
                ],
            )

            # Wait for extension to load
            await asyncio.sleep(2)

            # Find extension ID via CDP
            extension_id = None
            temp_page = await browser.new_page()
            try:
                cdp = await temp_page.context.new_cdp_session(temp_page)
                targets_result = await cdp.send("Target.getTargets")
                for target_info in targets_result.get("targetInfos", []):
                    ext_url = target_info.get("url", "")
                    if "chrome-extension://" in ext_url:
                        parts = ext_url.replace("chrome-extension://", "").split("/")
                        if parts:
                            extension_id = parts[0]
                            break
            except Exception as e:
                console.print(f"[yellow]⚠️  CDP query failed: {e}[/yellow]")
            finally:
                await temp_page.close()

            if extension_id:
                console.print("[green]✅ Extension loaded[/green]")
            else:
                console.print("[yellow]⚠️  Could not find extension ID. Please set API key manually.[/yellow]")

            # Step 1: Navigate to target URL first
            console.print(f"[cyan]Navigating to {target_url}...[/cyan]")
            main_page = await browser.new_page()
            await main_page.goto(target_url, wait_until="domcontentloaded")
            console.print(f"[green]✅ Loaded: {target_url}[/green]")

            # Step 2: Use options page to set API key
            if extension_id:
                options_page = await browser.new_page()
                try:
                    await options_page.goto(
                        f"chrome-extension://{extension_id}/options.html",
                        wait_until="domcontentloaded",
                        timeout=5000,
                    )

                    # Set API key
                    await options_page.fill("#platoApiKey", api_key)
                    save_button = options_page.locator('button:has-text("Save")')
                    if await save_button.count() > 0:
                        await save_button.click()
                        await asyncio.sleep(0.3)
                    console.print("[green]✅ API key saved[/green]")

                except Exception as e:
                    console.print(f"[yellow]⚠️  Could not set up extension: {e}[/yellow]")
                finally:
                    await options_page.close()

            # Bring main page to front
            await main_page.bring_to_front()

            console.print()
            console.print("[bold]Instructions:[/bold]")
            console.print("  1. Click the EnvGen Recorder extension icon to open the sidebar")
            if simulator:
                console.print(f"  2. Click 'Configure Session' and enter '{simulator}' as the simulator name")
            else:
                console.print("  2. Click 'Configure Session' and enter a simulator name")
            console.print("  3. Use the extension to record and submit reviews")
            console.print("  4. When done, press Control-C to exit")

            # Show recent review if available
            if recent_review:
                console.print()
                console.print("=" * 60)
                outcome = recent_review.get("outcome", "unknown")
                timestamp = recent_review.get("timestamp_iso", "")[:10]  # Just the date
                if outcome == "reject":
                    console.print(f"[bold red]📋 Most Recent Data Review: REJECTED[/bold red] ({timestamp})")
                else:
                    console.print(f"[bold green]📋 Most Recent Data Review: PASSED[/bold green] ({timestamp})")

                comments = recent_review.get("comments")
                if comments:
                    console.print("\n[yellow]Reviewer Comments:[/yellow]")
                    console.print(f"  {comments}")
                console.print("=" * 60)

            console.print()
            console.print("[bold]Press Control-C when done[/bold]")

            try:
                await asyncio.Event().wait()
            except KeyboardInterrupt:
                console.print("\n[yellow]Interrupted by user[/yellow]")
            except Exception:
                pass

            console.print("\n[green]✅ Browser closed. Review session ended.[/green]")

        except Exception as e:
            console.print(f"[red]❌ Error during review session: {e}[/red]")
            raise

        finally:
            try:
                if browser:
                    await browser.close()
                if playwright:
                    await playwright.stop()
                if temp_ext_dir.exists():
                    shutil.rmtree(temp_ext_dir, ignore_errors=True)
            except Exception as e:
                console.print(f"[yellow]⚠️  Browser cleanup error: {e}[/yellow]")

    handle_async(_review_data())


# =============================================================================
# SUBMIT COMMANDS
# =============================================================================


@submit_app.command(name="base")
def submit_base():
    """
    Submit base/environment artifact for review after snapshot.

    Worker submits base artifact for review after creating a snapshot.
    Requires status: env_in_progress
    Transitions to: env_review_requested

    Example:
        plato pm submit base
    """
    api_key = require_api_key()

    # Get sandbox state
    sandbox_data = require_sandbox_state()
    artifact_id = require_sandbox_field(
        sandbox_data, "artifact_id", "The sandbox must have an artifact_id to request review"
    )
    plato_config_path = require_sandbox_field(sandbox_data, "plato_config_path")

    # Read plato-config.yml to get simulator name
    plato_config = read_plato_config(plato_config_path)
    simulator_name = require_plato_config_field(plato_config, "service")

    async def _submit_base():
        base_url = _get_base_url()

        async with httpx.AsyncClient(base_url=base_url, timeout=60.0) as client:
            # Get simulator by name
            sim = await get_simulator_by_name.asyncio(
                client=client,
                name=simulator_name,
                x_api_key=api_key,
            )
            simulator_id = sim.id
            current_config = sim.config or {}
            current_status = current_config.get("status", "not_started")

            # Validate status transition
            validate_status_transition(current_status, "env_in_progress", "submit base")

            # Show info and submit
            console.print(f"[cyan]Simulator:[/cyan]      {simulator_name}")
            console.print(f"[cyan]Artifact ID:[/cyan]    {artifact_id}")
            console.print(f"[cyan]Current Status:[/cyan] {current_status}")
            console.print()

            # Update simulator status
            await update_simulator_status.asyncio(
                client=client,
                simulator_id=simulator_id,
                body=UpdateStatusRequest(status="env_review_requested"),
                x_api_key=api_key,
            )

            # Set base_artifact_id via tag update
            try:
                await update_tag.asyncio(
                    client=client,
                    body=UpdateTagRequest(
                        simulator_name=simulator_name,
                        artifact_id=artifact_id,
                        tag_name="base-pending-review",
                        dataset="base",
                    ),
                    x_api_key=api_key,
                )
            except Exception as e:
                console.print(f"[yellow]⚠️  Could not set artifact tag: {e}[/yellow]")

            console.print("[green]✅ Environment review requested successfully![/green]")
            console.print(f"[cyan]Status:[/cyan] {current_status} → env_review_requested")
            console.print(f"[cyan]Base Artifact:[/cyan] {artifact_id}")

    handle_async(_submit_base())


@submit_app.command(name="data")
def submit_data(
    simulator: str = typer.Option(None, "--simulator", "-s", help="Simulator name"),
    artifact: str = typer.Option(None, "--artifact", "-a", help="Artifact ID (required)"),
):
    """
    Submit data artifact for review after data generation.

    Worker manually specifies artifact ID for data review.
    Requires status: data_in_progress
    Transitions to: data_review_requested

    Example:
        plato pm submit data --simulator espocrm --artifact abc123
        plato pm submit data -s espocrm -a abc123
    """
    api_key = require_api_key()

    # Use arg or prompt for simulator name
    simulator_name = simulator
    if not simulator_name:
        simulator_name = typer.prompt("Enter simulator name").strip()
    if not simulator_name:
        console.print("[red]❌ Simulator name is required[/red]")
        raise typer.Exit(1)

    # Artifact ID is required
    artifact_id = artifact
    if not artifact_id:
        artifact_id = typer.prompt("Enter artifact ID").strip()
    if not artifact_id:
        console.print("[red]❌ Artifact ID is required[/red]")
        raise typer.Exit(1)

    async def _submit_data():
        base_url = _get_base_url()

        async with httpx.AsyncClient(base_url=base_url, timeout=60.0) as client:
            # Get simulator by name
            sim = await get_simulator_by_name.asyncio(
                client=client,
                name=simulator_name,
                x_api_key=api_key,
            )
            simulator_id = sim.id
            current_config = sim.config or {}
            current_status = current_config.get("status", "not_started")

            # Validate status transition
            validate_status_transition(current_status, "data_in_progress", "submit data")

            # Show info and submit
            console.print(f"[cyan]Simulator:[/cyan]      {simulator_name}")
            console.print(f"[cyan]Artifact ID:[/cyan]    {artifact_id}")
            console.print(f"[cyan]Current Status:[/cyan] {current_status}")
            console.print()

            # Update simulator status
            await update_simulator_status.asyncio(
                client=client,
                simulator_id=simulator_id,
                body=UpdateStatusRequest(status="data_review_requested"),
                x_api_key=api_key,
            )

            # Set data_artifact_id via tag update
            try:
                await update_tag.asyncio(
                    client=client,
                    body=UpdateTagRequest(
                        simulator_name=simulator_name,
                        artifact_id=artifact_id,
                        tag_name="data-pending-review",
                        dataset="base",
                    ),
                    x_api_key=api_key,
                )
            except Exception as e:
                console.print(f"[yellow]⚠️  Could not set artifact tag: {e}[/yellow]")

            console.print("[green]✅ Data review requested successfully![/green]")
            console.print(f"[cyan]Status:[/cyan] {current_status} → data_review_requested")
            console.print(f"[cyan]Data Artifact:[/cyan] {artifact_id}")

    handle_async(_submit_data())
