"""Sandbox CLI commands for Plato."""

import base64
import io
import json
import logging
import os
import shutil
import subprocess
import tarfile
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import typer
import yaml
from playwright.async_api import async_playwright
from rich.logging import RichHandler

from plato._generated.api.v1.gitea import (
    create_simulator_repository,
    get_accessible_simulators,
    get_gitea_credentials,
    get_simulator_repository,
)
from plato._generated.api.v1.sandbox import setup_sandbox, start_worker
from plato._generated.api.v2.jobs import get_flows as jobs_get_flows
from plato._generated.api.v2.jobs import state as jobs_state
from plato._generated.api.v2.sessions import (
    close as sessions_close,
)
from plato._generated.api.v2.sessions import (
    execute as sessions_execute,
)
from plato._generated.api.v2.sessions import (
    get_public_url as sessions_get_public_url,
)
from plato._generated.api.v2.sessions import (
    get_session_details,
)
from plato._generated.api.v2.sessions import (
    snapshot as sessions_snapshot,
)
from plato._generated.api.v2.sessions import (
    state as sessions_state,
)
from plato._generated.models import (
    AppSchemasBuildModelsSimConfigCompute,
    AppSchemasBuildModelsSimConfigDataset,
    AppSchemasBuildModelsSimConfigMetadata,
    CreateCheckpointRequest,
    ExecuteCommandRequest,
    Flow,
    SetupSandboxRequest,
    VMManagementRequest,
)
from plato.v1.cli.ssh import setup_ssh_for_sandbox
from plato.v1.cli.utils import (
    SANDBOX_FILE,
    console,
    get_http_client,
    handle_async,
    read_plato_config,
    remove_sandbox_state,
    require_api_key,
    require_sandbox_field,
    require_sandbox_state,
    save_sandbox_state,
)
from plato.v2.async_.flow_executor import FlowExecutor
from plato.v2.sync.client import Plato as PlatoV2
from plato.v2.types import Env, SimConfigCompute

sandbox_app = typer.Typer(help="Manage sandboxes for simulator development")


def format_public_url_with_router_target(public_url: str | None, service_name: str | None) -> str | None:
    """Format public URL with _plato_router_target parameter for browser access.

    Args:
        public_url: The base public URL (e.g., https://job-id.sims.plato.so)
        service_name: The service/simulator name (e.g., docuseal)

    Returns:
        URL with _plato_router_target parameter appended, or original URL if service is None
    """
    if not public_url or not service_name:
        return public_url

    target_param = f"_plato_router_target={service_name}.web.plato.so"
    if "?" in public_url:
        return f"{public_url}&{target_param}"
    else:
        return f"{public_url}?{target_param}"


@sandbox_app.command(name="start")
def sandbox_start(
    # Mode flags
    from_config: bool = typer.Option(False, "--from-config", "-c", help="Use plato-config.yml in current directory"),
    simulator: str = typer.Option(
        None,
        "--simulator",
        "-s",
        help="Simulator name (e.g., espocrm, espocrm:staging)",
    ),
    artifact_id: str = typer.Option(None, "--artifact-id", "-a", help="Specific artifact ID"),
    blank: bool = typer.Option(False, "--blank", "-b", help="Create blank VM"),
    # Config mode options
    dataset: str = typer.Option(None, "--dataset", "-d", help="Dataset from config or simulator"),
    # Artifact mode options
    tag: str = typer.Option("latest", "--tag", "-t", help="Artifact tag"),
    # Blank VM options
    service: str = typer.Option(None, "--service", help="Service name (required for blank VM)"),
    cpus: int = typer.Option(2, "--cpus", help="Number of CPUs (blank VM)"),
    memory: int = typer.Option(1024, "--memory", help="Memory in MB (blank VM)"),
    disk: int = typer.Option(10240, "--disk", help="Disk in MB (blank VM)"),
    # Common options
    timeout: int = typer.Option(300, "--timeout", help="Timeout for VM ready (seconds)"),
    no_reset: bool = typer.Option(False, "--no-reset", help="Skip initial reset after ready"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """
    Start a sandbox environment.

    Three modes available:

    1. FROM CONFIG: Use plato-config.yml in current directory
       plato sandbox start --from-config
       plato sandbox start --from-config --dataset base

    2. FROM ARTIFACT: Use simulator name or artifact ID
       plato sandbox start --simulator espocrm
       plato sandbox start --simulator espocrm:staging
       plato sandbox start --artifact-id art_abc123

    3. BLANK VM: Create fresh VM with custom specs
       plato sandbox start --blank --service myapp
       plato sandbox start --blank --service myapp --cpus 4 --memory 2048
    """
    api_key = require_api_key()

    # Validate mode selection - exactly one must be specified
    modes_selected = sum([from_config, simulator is not None, artifact_id is not None, blank])
    if modes_selected == 0:
        console.print("[red]Must specify one mode: --from-config, --simulator, --artifact-id, or --blank[/red]")
        raise typer.Exit(1)
    if modes_selected > 1:
        console.print("[red]Only one mode can be specified[/red]")
        raise typer.Exit(1)

    # Validate mode-specific options
    if blank and not service:
        console.print("[red]--service is required for blank VM mode[/red]")
        raise typer.Exit(1)

    # Build environment configuration
    env_config = None
    mode = None
    state_extras = {}
    full_dataset_config_dict = None  # For setup_sandbox call in --from-config mode
    config_path = None
    sim_name = None
    dataset_name = None

    if from_config:
        # MODE 1: From plato-config.yml - creates a BLANK VM with specs from config
        mode = "config"
        config_path = Path.cwd() / "plato-config.yml"
        if not config_path.exists():
            config_path = Path.cwd() / "plato-config.yaml"
        if not config_path.exists():
            console.print("[red]plato-config.yml not found in current directory[/red]")
            raise typer.Exit(1)

        with open(config_path) as f:
            plato_config = yaml.safe_load(f)

        sim_name = plato_config.get("service")
        if not sim_name:
            console.print("[red]plato-config.yml missing 'service' field[/red]")
            raise typer.Exit(1)

        # Get dataset (default to "base")
        dataset_name = dataset or "base"
        datasets = plato_config.get("datasets", {})
        if dataset_name not in datasets:
            console.print(f"[red]Dataset '{dataset_name}' not found in plato-config.yml[/red]")
            console.print(f"[yellow]Available datasets: {list(datasets.keys())}[/yellow]")
            raise typer.Exit(1)

        full_dataset_config_dict = datasets[dataset_name]

        # Extract compute specs from config
        compute_config = full_dataset_config_dict.get("compute", {})
        config_cpus = compute_config.get("cpus", 2)
        config_memory = compute_config.get("memory", 2048)
        config_disk = compute_config.get("disk", 10240)

        # Create blank VM with specs from config
        sim_config = SimConfigCompute(cpus=config_cpus, memory=config_memory, disk=config_disk)
        env_config = Env.resource(sim_name, sim_config)
        state_extras = {
            "plato_config_path": str(config_path),
            "service": sim_name,
            "dataset": dataset_name,
            "cpus": config_cpus,
            "memory": config_memory,
            "disk": config_disk,
        }
        if not json_output:
            console.print(f"[cyan]Using plato-config.yml: {config_path}[/cyan]")
            console.print(f"[cyan]Service: {sim_name}, Dataset: {dataset_name}[/cyan]")
            console.print(f"[cyan]Specs: {config_cpus} CPUs, {config_memory}MB RAM, {config_disk}MB disk[/cyan]")

    elif simulator:
        # MODE 2a: From simulator name
        mode = "artifact"
        # Default dataset to "base" if not provided
        effective_dataset = dataset or "base"
        env_config = Env.simulator(simulator, tag=tag, dataset=effective_dataset)
        # Extract sim_name from simulator (e.g., "docuseal:prod-latest" -> "docuseal")
        sim_name = simulator.split(":")[0] if ":" in simulator else simulator
        state_extras = {"simulator": simulator, "tag": tag, "dataset": effective_dataset, "service": sim_name}
        if not json_output:
            console.print(f"[cyan]Starting from simulator: {simulator}:{tag}[/cyan]")

    elif artifact_id:
        # MODE 2b: From artifact ID
        mode = "artifact"
        env_config = Env.artifact(artifact_id)
        # Default dataset to "base" for artifact mode
        state_extras = {"artifact_id": artifact_id, "dataset": "base"}
        if not json_output:
            console.print(f"[cyan]Starting from artifact: {artifact_id}[/cyan]")

    elif blank:
        # MODE 3: Blank VM
        mode = "blank"
        sim_config = SimConfigCompute(cpus=cpus, memory=memory, disk=disk)
        env_config = Env.resource(service, sim_config)
        state_extras = {
            "service": service,
            "cpus": cpus,
            "memory": memory,
            "disk": disk,
        }
        if not json_output:
            console.print(f"[cyan]Creating blank VM for service: {service}[/cyan]")
            console.print(f"[cyan]Specs: {cpus} CPUs, {memory}MB RAM, {disk}MB disk[/cyan]")

    # Create session using v2 SDK
    if not json_output:
        console.print("[cyan]Creating sandbox...[/cyan]")

    try:
        plato = PlatoV2(api_key=api_key)
        session = plato.sessions.create(envs=[env_config] if env_config else None, timeout=timeout)

        # Get session info
        session_id = session.session_id
        job_id = session.envs[0].job_id if session.envs else None

        # Get public URL
        public_url = None
        try:
            with get_http_client() as client:
                url_response = sessions_get_public_url.sync(
                    client=client,
                    session_id=session_id,
                    x_api_key=api_key,
                )
                if url_response and url_response.results:
                    for jid, result in url_response.results.items():
                        public_url = result.url if hasattr(result, "url") else str(result)
                        break
        except Exception as e:
            if not json_output:
                console.print(f"[yellow]Could not get public URL: {e}[/yellow]")

        # Reset environment unless --no-reset
        if not no_reset:
            if not json_output:
                console.print("[cyan]Resetting environment...[/cyan]")
            session.reset()

        # Setup sandbox for --from-config mode (clone git repo, configure worker)
        ssh_host = None
        ssh_config_path = None
        ssh_private_key_path = None
        if mode == "config" and full_dataset_config_dict and job_id:
            if not json_output:
                console.print("[cyan]Setting up sandbox (SSH keys, git clone, worker config)...[/cyan]")
            try:
                # Step 1: Generate SSH key pair and create SSH config (like Go hub does)
                if not json_output:
                    console.print("[cyan]  Generating SSH key pair...[/cyan]")

                base_url = os.getenv("PLATO_BASE_URL", "https://plato.so")
                ssh_info = setup_ssh_for_sandbox(base_url, job_id, username="plato")
                ssh_host = ssh_info["ssh_host"]
                ssh_config_path = ssh_info["config_path"]
                ssh_private_key_path = ssh_info["private_key_path"]
                ssh_public_key = ssh_info["public_key"]

                if not json_output:
                    console.print(f"[cyan]  SSH config: {ssh_config_path}[/cyan]")

                # Step 2: Build the full dataset config from plato-config.yml
                compute_dict = full_dataset_config_dict.get("compute", {})
                metadata_dict = full_dataset_config_dict.get("metadata", {})
                services_dict = full_dataset_config_dict.get("services")
                listeners_dict = full_dataset_config_dict.get("listeners")

                # Build compute config
                compute_obj = AppSchemasBuildModelsSimConfigCompute(
                    cpus=compute_dict.get("cpus", 2),
                    memory=compute_dict.get("memory", 2048),
                    disk=compute_dict.get("disk", 10240),
                    app_port=compute_dict.get("app_port", 80),
                    plato_messaging_port=compute_dict.get("plato_messaging_port", 7000),
                )

                # Build metadata config
                metadata_obj = AppSchemasBuildModelsSimConfigMetadata(
                    name=metadata_dict.get("name", sim_name),
                    description=metadata_dict.get("description", ""),
                    source_code_url=metadata_dict.get("source_code_url"),
                    start_url=metadata_dict.get("start_url", "blank"),
                    license=metadata_dict.get("license"),
                    variables=metadata_dict.get("variables"),
                    flows_path=metadata_dict.get("flows_path"),
                )

                # Build the full dataset config object
                dataset_config_obj = AppSchemasBuildModelsSimConfigDataset(
                    compute=compute_obj,
                    metadata=metadata_obj,
                    services=services_dict,
                    listeners=listeners_dict,
                )

                # Step 3: Build setup request WITH SSH public key
                setup_request = SetupSandboxRequest(
                    service=sim_name,
                    dataset=dataset_name or "",
                    plato_dataset_config=dataset_config_obj,
                    ssh_public_key=ssh_public_key,  # Pass the generated public key
                )

                # Step 4: Call setup_sandbox API
                if not json_output:
                    console.print("[cyan]  Calling setup-sandbox API...[/cyan]")

                with get_http_client() as client:
                    _setup_response = setup_sandbox.sync(
                        client=client,
                        public_id=job_id,
                        body=setup_request,
                        x_api_key=api_key,
                    )

                if not json_output:
                    console.print("[green]Sandbox setup complete![/green]")
                    console.print(f"  [cyan]SSH:[/cyan] ssh -F {ssh_config_path} {ssh_host}")

            except Exception as e:
                if not json_output:
                    console.print(f"[yellow]Warning: Setup sandbox failed: {e}[/yellow]")
                    console.print("[yellow]You may need to run 'plato sandbox start-worker' manually[/yellow]")

        # Start background heartbeat process to keep session alive
        heartbeat_pid = _start_heartbeat_process(session_id, api_key)
        if not json_output and heartbeat_pid:
            console.print(f"[cyan]Started heartbeat process (PID: {heartbeat_pid})[/cyan]")

        # Build the full URL with router target for browser access
        display_url = format_public_url_with_router_target(public_url, sim_name)

        # Save state
        state = {
            "session_id": session_id,
            "job_id": job_id,
            "public_url": public_url,
            "url": display_url,  # Full URL with _plato_router_target for flow execution
            "mode": mode,
            "created_at": datetime.now(timezone.utc).isoformat(),
            **state_extras,
        }
        # Add SSH info if available from setup_sandbox
        if ssh_host:
            state["ssh_host"] = ssh_host
        if ssh_config_path:
            state["ssh_config_path"] = ssh_config_path
        if ssh_private_key_path:
            state["ssh_private_key_path"] = ssh_private_key_path
        # Add heartbeat PID
        if heartbeat_pid:
            state["heartbeat_pid"] = heartbeat_pid
        save_sandbox_state(state)

        # Close the plato client (heartbeat process keeps session alive)
        plato.close()

        # Output
        if json_output:
            output = {
                "session_id": session_id,
                "job_id": job_id,
                "public_url": public_url,
            }
            if ssh_host:
                output["ssh_host"] = ssh_host
            if ssh_config_path:
                output["ssh_config_path"] = ssh_config_path
                output["ssh_command"] = f"ssh -F {ssh_config_path} {ssh_host}"
            console.print(json.dumps(output))
        else:
            console.print("\n[green]Sandbox started successfully![/green]")
            console.print(f"  [cyan]Session ID:[/cyan]  {session_id}")
            console.print(f"  [cyan]Job ID:[/cyan]      {job_id}")
            if public_url:
                display_url = format_public_url_with_router_target(public_url, sim_name)
                console.print(f"  [cyan]Public URL:[/cyan]  {display_url}")
            if ssh_host and ssh_config_path:
                console.print(f"  [cyan]SSH:[/cyan]         ssh -F {ssh_config_path} {ssh_host}")
            console.print(f"\n[dim]State saved to {SANDBOX_FILE}[/dim]")

    except Exception as e:
        if json_output:
            console.print(json.dumps({"error": str(e)}))
        else:
            console.print(f"[red]Failed to start sandbox: {e}[/red]")
        raise typer.Exit(1) from e


@sandbox_app.command(name="snapshot")
def sandbox_snapshot(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """
    Create a snapshot of the current sandbox state.

    Examples:
        plato sandbox snapshot
        plato sandbox snapshot --json
    """
    api_key = require_api_key()
    state = require_sandbox_state()
    session_id = require_sandbox_field(state, "session_id")

    if not json_output:
        console.print("[cyan]Creating snapshot...[/cyan]")

    try:
        with get_http_client() as client:
            response = sessions_snapshot.sync(
                client=client,
                session_id=session_id,
                body=CreateCheckpointRequest(),
                x_api_key=api_key,
            )

            # Extract artifact ID from response
            artifact_id = None
            if response and response.results:
                for job_id, result in response.results.items():
                    artifact_id = result.artifact_id if hasattr(result, "artifact_id") else None
                    break

            if json_output:
                console.print(json.dumps({"artifact_id": artifact_id}))
            else:
                console.print("\n[green]Snapshot created successfully![/green]")
                console.print(f"  [cyan]Artifact ID:[/cyan] {artifact_id}")

    except Exception as e:
        if json_output:
            console.print(json.dumps({"error": str(e)}))
        else:
            console.print(f"[red]Failed to create snapshot: {e}[/red]")
        raise typer.Exit(1) from e


@sandbox_app.command(name="stop")
def sandbox_stop():
    """
    Stop and destroy the sandbox.

    Examples:
        plato sandbox stop
    """
    api_key = require_api_key()
    state = require_sandbox_state()
    session_id = require_sandbox_field(state, "session_id")

    console.print("[cyan]Stopping sandbox...[/cyan]")

    try:
        # Stop heartbeat process first
        heartbeat_pid = state.get("heartbeat_pid")
        if heartbeat_pid:
            if _stop_heartbeat_process(heartbeat_pid):
                console.print(f"[dim]Stopped heartbeat process (PID: {heartbeat_pid})[/dim]")
            else:
                console.print(f"[yellow]Could not stop heartbeat process (PID: {heartbeat_pid})[/yellow]")

        with get_http_client() as client:
            sessions_close.sync(
                client=client,
                session_id=session_id,
                x_api_key=api_key,
            )

        # Clean up SSH config and key files (like Go hub does)
        ssh_config_path = state.get("ssh_config_path")
        ssh_private_key_path = state.get("ssh_private_key_path")

        if ssh_config_path:
            config_file = Path(ssh_config_path)
            if config_file.exists():
                config_file.unlink()
                console.print(f"[dim]Removed {ssh_config_path}[/dim]")

        if ssh_private_key_path:
            private_key_file = Path(ssh_private_key_path)
            public_key_file = Path(ssh_private_key_path + ".pub")
            if private_key_file.exists():
                private_key_file.unlink()
            if public_key_file.exists():
                public_key_file.unlink()
            console.print("[dim]Removed SSH keys[/dim]")

        remove_sandbox_state()
        console.print("[green]Sandbox stopped successfully.[/green]")
        console.print(f"[dim]Removed {SANDBOX_FILE}[/dim]")

    except Exception as e:
        console.print(f"[red]Failed to stop sandbox: {e}[/red]")
        raise typer.Exit(1) from e


@sandbox_app.command(name="status")
def sandbox_status(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """
    Show current sandbox status and info.

    Examples:
        plato sandbox status
        plato sandbox status --json
    """
    state = require_sandbox_state()

    # Check VM status via API
    api_key = require_api_key()
    session_id = state.get("session_id")
    vm_status = "unknown"
    vm_status_reason = None
    vm_running = False

    if session_id:
        try:
            with get_http_client() as client:
                details = get_session_details.sync(
                    client=client,
                    session_id=session_id,
                    x_api_key=api_key,
                )
                # Check session status from response - try different possible locations
                if details:
                    # Try top-level status first
                    vm_status = details.get("status")
                    vm_status_reason = details.get("status_reason") or details.get("error") or details.get("message")
                    # Try jobs array (each job has its own status)
                    if not vm_status and "jobs" in details:
                        jobs = details.get("jobs", [])
                        if jobs and len(jobs) > 0:
                            # Get status from first job
                            first_job = jobs[0] if isinstance(jobs, list) else list(jobs.values())[0]
                            if isinstance(first_job, dict):
                                vm_status = first_job.get("status")
                                vm_status_reason = (
                                    first_job.get("status_reason") or first_job.get("error") or first_job.get("message")
                                )
                    # Try envs array
                    if not vm_status and "envs" in details:
                        envs = details.get("envs", [])
                        if envs and len(envs) > 0:
                            first_env = envs[0]
                            if isinstance(first_env, dict):
                                vm_status = first_env.get("status")
                                vm_status_reason = (
                                    first_env.get("status_reason") or first_env.get("error") or first_env.get("message")
                                )
                    # Default if nothing found
                    if not vm_status:
                        vm_status = "active" if details else "unknown"
                    # Common status values: "running", "stopped", "terminated", "pending", "active"
                    vm_running = vm_status.lower() in ("running", "active", "ready", "healthy")
        except Exception:
            vm_status = "unreachable"
            vm_running = False

    if json_output:
        output = {**state, "vm_status": vm_status, "vm_status_reason": vm_status_reason, "vm_running": vm_running}
        console.print(json.dumps(output))
    else:
        console.print("\n[bold]Sandbox Status[/bold]")
        console.print(f"  [cyan]Session ID:[/cyan]  {state.get('session_id')}")
        console.print(f"  [cyan]Job ID:[/cyan]      {state.get('job_id')}")
        console.print(f"  [cyan]Mode:[/cyan]        {state.get('mode')}")

        # Show VM status with color
        if vm_running:
            console.print(f"  [cyan]VM Status:[/cyan]   [green]{vm_status}[/green]")
        elif vm_status == "unreachable":
            console.print(f"  [cyan]VM Status:[/cyan]   [yellow]{vm_status}[/yellow]")
        else:
            console.print(f"  [cyan]VM Status:[/cyan]   [red]{vm_status}[/red]")

        # Show failure reason if available
        if vm_status_reason:
            console.print(f"  [cyan]Reason:[/cyan]      [red]{vm_status_reason}[/red]")

        if state.get("simulator"):
            console.print(f"  [cyan]Simulator:[/cyan]   {state.get('simulator')}")
        if state.get("service"):
            console.print(f"  [cyan]Service:[/cyan]     {state.get('service')}")
        if state.get("public_url"):
            # Get service name, extracting from simulator if needed (e.g., "docuseal:prod-latest" -> "docuseal")
            service_name = state.get("service")
            if not service_name:
                simulator = state.get("simulator")
                if simulator:
                    service_name = simulator.split(":")[0] if ":" in simulator else simulator
            display_url = format_public_url_with_router_target(state.get("public_url"), service_name)
            console.print(f"  [cyan]Public URL:[/cyan]  {display_url}")
        if state.get("created_at"):
            console.print(f"  [cyan]Created:[/cyan]     {state.get('created_at')}")

        # Display SSH command if available
        ssh_host = state.get("ssh_host")
        ssh_config_path = state.get("ssh_config_path")
        if ssh_host and ssh_config_path:
            console.print(f"  [cyan]SSH:[/cyan]         ssh -F {ssh_config_path} {ssh_host}")

        # Display heartbeat status
        heartbeat_pid = state.get("heartbeat_pid")
        if heartbeat_pid:
            # Check if process is still running
            try:
                os.kill(heartbeat_pid, 0)  # Signal 0 just checks if process exists
                console.print(f"  [cyan]Heartbeat:[/cyan]   [green]running[/green] (PID: {heartbeat_pid})")
            except ProcessLookupError:
                console.print(f"  [cyan]Heartbeat:[/cyan]   [red]stopped[/red] (PID: {heartbeat_pid} not found)")


@sandbox_app.command(name="start-worker")
def sandbox_start_worker(
    service: str = typer.Option(
        None,
        "--service",
        "-s",
        help="Service name (uses sandbox service if not specified)",
    ),
    dataset: str = typer.Option("base", "--dataset", "-d", help="Dataset name"),
    config_path: Path | None = typer.Option(None, "--config-path", help="Path to plato-config.yml (required)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """
    Start/configure the Plato worker in the sandbox (for blank VMs).

    This is needed after creating a blank VM to configure the worker
    with the correct service and dataset settings.

    Requires a plato-config.yml file with dataset configuration.

    Examples:
        plato sandbox start-worker --config-path ./plato-config.yml
        plato sandbox start-worker --config-path ./plato-config.yml --dataset base
        plato sandbox start-worker -s myapp -d base --config-path ./plato-config.yml
    """
    api_key = require_api_key()
    state = require_sandbox_state()
    job_id = state.get("job_id")

    if not job_id:
        console.print("[red].sandbox.yaml missing job_id[/red]")
        raise typer.Exit(1)

    # Use service from state if not provided
    if not service and state.get("service"):
        service = str(state.get("service"))
    if not service:
        console.print("[red]--service is required (or must be set in .sandbox.yaml)[/red]")
        raise typer.Exit(1)

    # Config path is required for start-worker
    if not config_path:
        # Try to find plato-config.yml in current directory
        config_path = Path.cwd() / "plato-config.yml"
        if not config_path.exists():
            config_path = Path.cwd() / "plato-config.yaml"
        if not config_path.exists():
            console.print("[red]--config-path is required or plato-config.yml must exist in current directory[/red]")
            raise typer.Exit(1)
        config_path = Path(config_path)

    config_file = Path(config_path)
    if not config_file.exists():
        console.print(f"[red]Config file not found: {config_file}[/red]")
        raise typer.Exit(1)

    with open(config_file) as f:
        plato_config = yaml.safe_load(f)

    # Extract dataset config
    datasets = plato_config.get("datasets", {})
    if dataset not in datasets:
        console.print(f"[red]Dataset '{dataset}' not found in {config_path}[/red]")
        console.print(f"[yellow]Available datasets: {list(datasets.keys())}[/yellow]")
        raise typer.Exit(1)

    dataset_config_dict = datasets[dataset]

    if not json_output:
        console.print(f"[cyan]Starting worker for service: {service}, dataset: {dataset}[/cyan]")

    try:
        with get_http_client() as client:
            # Extract compute and metadata from config, with defaults
            compute_dict = dataset_config_dict.get("compute", {})
            metadata_dict = dataset_config_dict.get("metadata", {})

            compute = AppSchemasBuildModelsSimConfigCompute(**compute_dict)
            metadata = AppSchemasBuildModelsSimConfigMetadata(**metadata_dict)

            # Also get services and listeners from config
            services_dict = dataset_config_dict.get("services")
            listeners_dict = dataset_config_dict.get("listeners")

            dataset_config = AppSchemasBuildModelsSimConfigDataset(
                compute=compute,
                metadata=metadata,
                services=services_dict,
                listeners=listeners_dict,
            )

            request = VMManagementRequest(
                service=service,
                dataset=dataset,
                plato_dataset_config=dataset_config,
            )

            response = start_worker.sync(
                client=client,
                public_id=job_id,
                body=request,
                x_api_key=api_key,
            )

            if json_output:
                console.print(
                    json.dumps(
                        {
                            "status": response.status if hasattr(response, "status") else "ok",
                            "correlation_id": response.correlation_id if hasattr(response, "correlation_id") else None,
                        }
                    )
                )
            else:
                console.print("[green]Worker started successfully![/green]")

    except Exception as e:
        if json_output:
            console.print(json.dumps({"error": str(e)}))
        else:
            console.print(f"[red]Failed to start worker: {e}[/red]")
        raise typer.Exit(1) from e


@sandbox_app.command(name="sync")
def sandbox_sync(
    path: str = typer.Argument(".", help="Local path to sync (default: current directory)"),
    remote_path: str = typer.Option(
        None,
        "--remote-path",
        "-r",
        help="Remote path (default: /home/plato/worktree/<service>)",
    ),
    timeout: int = typer.Option(120, "--timeout", "-t", help="Command timeout in seconds"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """
    Sync local code to the sandbox (pure Python, no rsync needed).

    Creates a tar archive of the local directory, uploads it via the
    execute API, and extracts it on the remote sandbox.

    Examples:
        plato sandbox sync
        plato sandbox sync ./src
        plato sandbox sync --remote-path /home/plato/custom/path
    """
    api_key = require_api_key()
    state = require_sandbox_state()
    session_id = require_sandbox_field(state, "session_id")

    # Get service name for default remote path
    service = state.get("service")
    plato_config_path = state.get("plato_config_path")

    # If service not in state, try to get from plato-config.yml
    if not service and plato_config_path:
        try:
            with open(plato_config_path) as f:
                plato_config = yaml.safe_load(f)
                service = plato_config.get("service")
        except Exception:
            pass  # Optional fallback, continue silently

    # Determine remote path
    if not remote_path:
        if service:
            remote_path = f"/home/plato/worktree/{service}"
        else:
            console.print(
                "[red]Cannot determine remote path. Use --remote-path or ensure .sandbox.yaml has 'service'[/red]"
            )
            raise typer.Exit(1)

    # Resolve local path
    local_path = Path(path).resolve()
    if not local_path.exists():
        console.print(f"[red]Local path not found: {local_path}[/red]")
        raise typer.Exit(1)

    if not json_output:
        console.print(f"[cyan]Local path:[/cyan]  {local_path}")
        console.print(f"[cyan]Remote path:[/cyan] {remote_path}")

    # Patterns to exclude
    exclude_patterns = [
        "__pycache__",
        "*.pyc",
        ".git",
        ".venv",
        "venv",
        "node_modules",
        ".sandbox.yaml",
        "*.egg-info",
        ".pytest_cache",
        ".mypy_cache",
        ".DS_Store",
        "*.swp",
        "*.swo",
    ]

    def should_exclude(file_path: Path, base_path: Path) -> bool:
        """Check if a file should be excluded from the archive."""
        rel_path = file_path.relative_to(base_path)

        for pattern in exclude_patterns:
            # Check each part of the path
            for part in rel_path.parts:
                if pattern.startswith("*"):
                    # Wildcard pattern like *.pyc
                    if part.endswith(pattern[1:]):
                        return True
                elif part == pattern:
                    return True
        return False

    if not json_output:
        console.print("[cyan]Creating archive...[/cyan]")

    try:
        # Create tar archive in memory
        tar_buffer = io.BytesIO()
        file_count = 0

        with tarfile.open(fileobj=tar_buffer, mode="w:gz") as tar:
            if local_path.is_file():
                # Single file
                tar.add(local_path, arcname=local_path.name)
                file_count = 1
            else:
                # Directory - walk and add files
                for file_path in local_path.rglob("*"):
                    if file_path.is_file() and not should_exclude(file_path, local_path):
                        arcname = file_path.relative_to(local_path)
                        tar.add(file_path, arcname=str(arcname))
                        file_count += 1

        tar_data = tar_buffer.getvalue()
        tar_size = len(tar_data)

        if not json_output:
            console.print(f"[cyan]Archive size:[/cyan] {tar_size:,} bytes ({file_count} files)")

        # Base64 encode
        tar_b64 = base64.b64encode(tar_data).decode("ascii")

        if not json_output:
            console.print("[cyan]Uploading and extracting...[/cyan]")

        # Execute command to decode and extract on remote
        chunk_size = 50000  # Base64 chars per chunk

        with get_http_client() as client:
            # First, ensure remote directory exists and clean it
            prep_cmd = f"mkdir -p {remote_path} && rm -rf {remote_path}/*"
            prep_request = ExecuteCommandRequest(command=prep_cmd, timeout=30)
            sessions_execute.sync(
                client=client,
                session_id=session_id,
                body=prep_request,
                x_api_key=api_key,
            )

            # Write base64 data to a temp file on remote in chunks
            temp_file = f"/tmp/sync_{session_id[:8]}.tar.gz.b64"

            # Clear temp file first
            clear_cmd = f"rm -f {temp_file}"
            clear_request = ExecuteCommandRequest(command=clear_cmd, timeout=10)
            sessions_execute.sync(
                client=client,
                session_id=session_id,
                body=clear_request,
                x_api_key=api_key,
            )

            # Write chunks
            for i in range(0, len(tar_b64), chunk_size):
                chunk = tar_b64[i : i + chunk_size]
                # Use printf to append chunk (handles special chars better than echo)
                write_cmd = f"printf '%s' '{chunk}' >> {temp_file}"
                write_request = ExecuteCommandRequest(command=write_cmd, timeout=30)
                sessions_execute.sync(
                    client=client,
                    session_id=session_id,
                    body=write_request,
                    x_api_key=api_key,
                )

            # Decode and extract
            extract_cmd = f"base64 -d {temp_file} | tar -xzf - -C {remote_path} && rm -f {temp_file}"
            extract_request = ExecuteCommandRequest(command=extract_cmd, timeout=timeout)
            response = sessions_execute.sync(
                client=client,
                session_id=session_id,
                body=extract_request,
                x_api_key=api_key,
            )

            # Check result
            stderr = ""
            exit_code = 0
            if response and response.results:
                for job_id, result in response.results.items():
                    stderr = result.stderr or ""
                    exit_code = result.exit_code if hasattr(result, "exit_code") else 0
                    break

            if exit_code != 0:
                if json_output:
                    console.print(
                        json.dumps(
                            {
                                "error": f"Extract failed: {stderr}",
                                "exit_code": exit_code,
                            }
                        )
                    )
                else:
                    console.print(f"[red]Sync failed: {stderr}[/red]")
                raise typer.Exit(exit_code)

        if json_output:
            console.print(
                json.dumps(
                    {
                        "status": "ok",
                        "files": file_count,
                        "bytes": tar_size,
                        "remote_path": remote_path,
                    }
                )
            )
        else:
            console.print(f"\n[green]Successfully synced {file_count} files to {remote_path}[/green]")

    except typer.Exit:
        raise
    except Exception as e:
        if json_output:
            console.print(json.dumps({"error": str(e)}))
        else:
            console.print(f"[red]Sync failed: {e}[/red]")
        raise typer.Exit(1) from e


# Set up Rich logging handler for FlowExecutor
logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    handlers=[RichHandler(console=console, show_time=False, show_path=False)],
)
_flow_logger = logging.getLogger("plato.flow")


@sandbox_app.command(name="flow")
def sandbox_flow(
    flow_name: str = typer.Option("login", "--flow-name", "-f", help="Name of the flow to execute"),
):
    """
    Execute a test flow against a simulator environment.

    Reads .sandbox.yaml to get the URL. Uses "login" as default flow name.

    Flow source priority:
    1. Local plato-config.yml (development workflow)
    2. Flows from API based on artifact (artifact/simulator mode)

    Example:
        plato sandbox flow
        plato sandbox flow --flow-name login
    """
    api_key = require_api_key()
    sandbox_data = require_sandbox_state()
    job_id = sandbox_data.get("job_id")

    # Get service name for router target
    service_name = sandbox_data.get("service")
    if not service_name:
        # Try to extract from simulator (e.g., "docuseal:prod-latest" -> "docuseal")
        simulator = sandbox_data.get("simulator")
        if simulator:
            service_name = simulator.split(":")[0] if ":" in simulator else simulator

    # Build proper URL with router target
    public_url = sandbox_data.get("public_url") or sandbox_data.get("url")
    if not public_url:
        console.print("[red]❌ No URL found in .sandbox.yaml[/red]")
        raise typer.Exit(1)

    # Always construct URL with router target for proper routing
    url = format_public_url_with_router_target(public_url, service_name)

    # Try to get flows from local plato-config.yml first
    flow_obj = None
    flow_file = None
    screenshots_dir = None

    # Check for local plato-config.yml
    plato_config_path = sandbox_data.get("plato_config_path")
    dataset = sandbox_data.get("dataset", "base")

    # Try local config first (either from state or current directory)
    local_config_paths = []
    if plato_config_path:
        local_config_paths.append(Path(plato_config_path))
    local_config_paths.extend([Path.cwd() / "plato-config.yml", Path.cwd() / "plato-config.yaml"])

    for config_path in local_config_paths:
        if config_path.exists():
            try:
                plato_config = read_plato_config(str(config_path))
                if "datasets" in plato_config:
                    dataset_config = plato_config["datasets"].get(dataset, {})
                    metadata = dataset_config.get("metadata", {})
                    flows_path = metadata.get("flows_path")

                    if flows_path:
                        if not Path(flows_path).is_absolute():
                            config_dir = config_path.parent
                            flow_file = str(config_dir / flows_path)
                        else:
                            flow_file = flows_path

                        if Path(flow_file).exists():
                            with open(flow_file) as f:
                                flow_dict = yaml.safe_load(f)
                            flow_obj = next(
                                (
                                    Flow.model_validate(fl)
                                    for fl in flow_dict.get("flows", [])
                                    if fl.get("name") == flow_name
                                ),
                                None,
                            )
                            if flow_obj:
                                screenshots_dir = Path(flow_file).parent / "screenshots"
                                console.print(f"[cyan]Flow source: local ({flow_file})[/cyan]")
                                break
            except Exception:
                pass  # Try next config or fall back to API

    # If no local flow found, fetch from API
    if not flow_obj:
        if not job_id:
            console.print("[red]❌ No local plato-config.yml found and no job_id in .sandbox.yaml[/red]")
            console.print("[yellow]Either create a local plato-config.yml or start sandbox from an artifact[/yellow]")
            raise typer.Exit(1)

        console.print("[cyan]Flow source: API (fetching from artifact)[/cyan]")
        try:
            with get_http_client() as client:
                flows_response = jobs_get_flows.sync(
                    client=client,
                    job_id=job_id,
                    x_api_key=api_key,
                )

                if not flows_response:
                    console.print("[red]❌ No flows found in artifact[/red]")
                    raise typer.Exit(1)

                # Find the requested flow
                for flow_data in flows_response:
                    if isinstance(flow_data, dict):
                        if flow_data.get("name") == flow_name:
                            flow_obj = Flow.model_validate(flow_data)
                            break
                    elif hasattr(flow_data, "name") and flow_data.name == flow_name:
                        flow_obj = (
                            flow_data if isinstance(flow_data, Flow) else Flow.model_validate(flow_data.model_dump())
                        )
                        break

                if not flow_obj:
                    available_flows = [
                        f.get("name") if isinstance(f, dict) else getattr(f, "name", "?") for f in flows_response
                    ]
                    console.print(f"[red]❌ Flow '{flow_name}' not found in artifact[/red]")
                    console.print(f"[yellow]Available flows: {available_flows}[/yellow]")
                    raise typer.Exit(1)

                # Use temp directory for screenshots when fetching from API
                screenshots_dir = Path.cwd() / "screenshots"
                screenshots_dir.mkdir(exist_ok=True)

        except typer.Exit:
            raise
        except Exception as e:
            console.print(f"[red]❌ Failed to fetch flows from API: {e}[/red]")
            raise typer.Exit(1) from e

    console.print(f"[cyan]URL: {url}[/cyan]")
    console.print(f"[cyan]Flow name: {flow_name}[/cyan]")

    async def _run():
        browser = None
        try:
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=False)
                page = await browser.new_page()
                await page.goto(url)
                executor = FlowExecutor(page, flow_obj, screenshots_dir, log=_flow_logger)
                await executor.execute()
                console.print("[green]✅ Flow executed successfully[/green]")
        except Exception as e:
            console.print(f"[red]❌ Flow execution failed: {e}[/red]")
            raise typer.Exit(1) from e
        finally:
            if browser:
                await browser.close()

    handle_async(_run())


@sandbox_app.command(name="state")
def sandbox_state_cmd():
    """Get the current state of the simulator environment."""
    state = require_sandbox_state()
    api_key = require_api_key()

    # Try session_id first (v2 SDK), then job_id, then job_group_id (legacy)
    session_id = state.get("session_id")
    job_id = state.get("job_id")
    job_group_id = state.get("job_group_id")

    if session_id:
        console.print(f"[cyan]Getting state for session: {session_id}[/cyan]")
        with get_http_client() as client:
            response = sessions_state.sync(
                client=client,
                session_id=session_id,
                x_api_key=api_key,
            )
            # Convert response to dict for display
            if response and response.results:
                state_dict = {
                    jid: result.model_dump() if hasattr(result, "model_dump") else result
                    for jid, result in response.results.items()
                }
                console.print("\n[bold]Environment State:[/bold]")
                console.print(json.dumps(state_dict, indent=2, default=str))
            else:
                console.print("[yellow]No state returned[/yellow]")
    elif job_id:
        # Use job-level state API
        console.print(f"[cyan]Getting state for job: {job_id}[/cyan]")
        with get_http_client() as client:
            response = jobs_state.sync(
                client=client,
                job_id=job_id,
                x_api_key=api_key,
            )
            if response:
                state_dict = response.model_dump() if hasattr(response, "model_dump") else response
                console.print("\n[bold]Environment State:[/bold]")
                console.print(json.dumps(state_dict, indent=2, default=str))
            else:
                console.print("[yellow]No state returned[/yellow]")
    elif job_group_id:
        # Legacy: Use job_group_id with session state API (it accepts job_group_id as session_id)
        console.print(f"[cyan]Getting state for job_group: {job_group_id}[/cyan]")
        with get_http_client() as client:
            response = sessions_state.sync(
                client=client,
                session_id=job_group_id,
                x_api_key=api_key,
            )
            if response and response.results:
                state_dict = {
                    jid: result.model_dump() if hasattr(result, "model_dump") else result
                    for jid, result in response.results.items()
                }
                console.print("\n[bold]Environment State:[/bold]")
                console.print(json.dumps(state_dict, indent=2, default=str))
            else:
                console.print("[yellow]No state returned[/yellow]")
    else:
        console.print("[red]❌ .sandbox.yaml missing session_id, job_id, or job_group_id[/red]")
        raise typer.Exit(1)


@sandbox_app.command(name="audit-ui")
def sandbox_audit_ui():
    """
    Launch Streamlit UI for auditing database ignore rules.

    Note: Requires streamlit to be installed:
        pip install streamlit psycopg2-binary pymysql

    Examples:
        plato sandbox audit-ui
    """
    # Check if streamlit is installed
    if not shutil.which("streamlit"):
        console.print("[red]❌ streamlit is not installed[/red]")
        console.print("\n[yellow]Install with:[/yellow]")
        console.print("  pip install streamlit psycopg2-binary pymysql")
        raise typer.Exit(1)

    # Find the audit_ui.py file - go up from cli/ to v1/
    package_dir = Path(__file__).resolve().parent.parent
    ui_file = package_dir / "audit_ui.py"

    if not ui_file.exists():
        console.print(f"[red]❌ UI file not found: {ui_file}[/red]")
        raise typer.Exit(1)

    console.print("[cyan]Launching Streamlit UI...[/cyan]")

    try:
        # Launch streamlit
        os.execvp("streamlit", ["streamlit", "run", str(ui_file)])
    except Exception as e:
        console.print(f"[red]❌ Failed to launch Streamlit: {e}[/red]")
        raise typer.Exit(1) from e


def _copy_files_respecting_gitignore(src_dir: Path, dst_dir: Path) -> None:
    """Copy files from src to dst respecting .gitignore rules."""
    # Copy .gitignore first if it exists
    gitignore_src = src_dir / ".gitignore"
    if gitignore_src.exists():
        gitignore_dst = dst_dir / ".gitignore"
        if not gitignore_dst.exists():
            shutil.copy2(gitignore_src, gitignore_dst)

    def should_copy(file_path: Path) -> bool:
        """Check if file should be copied (not ignored by git)."""
        base_name = file_path.name
        # Skip .git directories and .plato-hub.json
        if base_name.startswith(".git") or base_name == ".plato-hub.json":
            return False
        # Use git check-ignore to respect .gitignore rules
        try:
            result = subprocess.run(
                ["git", "check-ignore", "-q", str(file_path)],
                cwd=src_dir,
                capture_output=True,
            )
            # git check-ignore returns 0 if path IS ignored, 1 if NOT ignored
            return result.returncode != 0
        except Exception:
            return True

    # Walk through source directory
    for src_path in src_dir.rglob("*"):
        rel_path = src_path.relative_to(src_dir)

        # Skip root
        if str(rel_path) == ".":
            continue

        # Check if should copy
        if not should_copy(src_path):
            continue

        dst_path = dst_dir / rel_path

        if src_path.is_dir():
            dst_path.mkdir(parents=True, exist_ok=True)
        else:
            dst_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_path, dst_path)


def _run_ssh_command(ssh_config_path: str, ssh_host: str, command: str) -> tuple[int, str, str]:
    """Run a command on the remote VM via SSH."""
    result = subprocess.run(
        ["ssh", "-F", ssh_config_path, ssh_host, command],
        capture_output=True,
        text=True,
    )
    return result.returncode, result.stdout, result.stderr


def _start_heartbeat_process(session_id: str, api_key: str) -> int | None:
    """Start a background process that sends heartbeats to keep the session alive.

    Returns the PID of the background process, or None if failed.
    """
    # Python script to run in background
    heartbeat_script = f'''
import time
import os
import httpx

session_id = "{session_id}"
api_key = "{api_key}"
base_url = os.getenv("PLATO_BASE_URL", "https://plato.so")

while True:
    try:
        with httpx.Client(base_url=base_url, timeout=30) as client:
            client.post(
                f"/api/v2/sessions/{{session_id}}/heartbeat",
                headers={{"X-API-Key": api_key}},
            )
    except Exception:
        pass
    time.sleep(30)
'''

    try:
        # Start detached background process
        process = subprocess.Popen(
            ["python3", "-c", heartbeat_script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,  # Detach from parent process
        )
        return process.pid
    except Exception:
        return None


def _stop_heartbeat_process(pid: int) -> bool:
    """Stop the heartbeat background process.

    Returns True if successfully stopped, False otherwise.
    """
    import signal

    try:
        os.kill(pid, signal.SIGTERM)
        return True
    except ProcessLookupError:
        # Process already dead
        return True
    except Exception:
        return False


@sandbox_app.command(name="start-services")
def sandbox_start_services(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
):
    """
    Push code to hub, clone on VM, and start docker compose services.

    This command:
    1. Pushes your local code to the Plato Hub (Gitea)
    2. Clones the code on the VM via SSH
    3. Starts docker compose services defined in plato-config.yml

    Requires:
    - A running sandbox (from 'plato sandbox start --from-config')
    - plato-config.yml with services defined
    - SSH access configured

    Examples:
        plato sandbox start-services
        plato sandbox start-services --json
    """
    api_key = require_api_key()
    state = require_sandbox_state()

    # Get required state
    ssh_host = state.get("ssh_host")
    ssh_config_path = state.get("ssh_config_path")
    service_name = state.get("service")

    if not ssh_host or not ssh_config_path:
        console.print("[red]❌ SSH not configured. Did you run 'plato sandbox start --from-config'?[/red]")
        raise typer.Exit(1)

    if not service_name:
        console.print("[red]❌ Service name not found in .sandbox.yaml[/red]")
        raise typer.Exit(1)

    # Load plato-config.yml to get services
    plato_config_path = state.get("plato_config_path")
    if not plato_config_path or not Path(plato_config_path).exists():
        # Try current directory
        for candidate in ["plato-config.yml", "plato-config.yaml"]:
            if Path(candidate).exists():
                plato_config_path = candidate
                break

    if not plato_config_path or not Path(plato_config_path).exists():
        console.print("[red]❌ plato-config.yml not found[/red]")
        raise typer.Exit(1)

    with open(plato_config_path) as f:
        plato_config = yaml.safe_load(f)

    dataset_name = state.get("dataset", "base")
    dataset_config = plato_config.get("datasets", {}).get(dataset_name, {})
    services_config = dataset_config.get("services", {})

    if not services_config:
        console.print(f"[yellow]⚠ No services defined in dataset '{dataset_name}'[/yellow]")

    try:
        with get_http_client() as client:
            # Step 1: Get Gitea credentials
            if not json_output:
                console.print("[cyan]Step 1: Getting Gitea credentials...[/cyan]")

            creds = get_gitea_credentials.sync(client=client, x_api_key=api_key)

            # Step 2: Find simulator
            if not json_output:
                console.print(f"[cyan]Step 2: Finding simulator '{service_name}'...[/cyan]")

            simulators = get_accessible_simulators.sync(client=client, x_api_key=api_key)
            simulator = None
            for sim in simulators:
                sim_name = sim.get("name") if isinstance(sim, dict) else getattr(sim, "name", None)
                if sim_name and sim_name.lower() == service_name.lower():
                    simulator = sim
                    break

            if not simulator:
                console.print(f"[red]❌ Simulator '{service_name}' not found in hub[/red]")
                raise typer.Exit(1)

            sim_id = simulator.get("id") if isinstance(simulator, dict) else getattr(simulator, "id", None)
            has_repo = (
                simulator.get("has_repo") if isinstance(simulator, dict) else getattr(simulator, "has_repo", False)
            )

            # Step 3: Get or create repository
            if not json_output:
                console.print("[cyan]Step 3: Getting/creating repository...[/cyan]")

            if has_repo:
                repo = get_simulator_repository.sync(client=client, simulator_id=sim_id, x_api_key=api_key)
            else:
                repo = create_simulator_repository.sync(client=client, simulator_id=sim_id, x_api_key=api_key)

            clone_url = repo.clone_url
            if not clone_url:
                console.print("[red]❌ Repository clone URL not available[/red]")
                raise typer.Exit(1)

            # Build authenticated clone URL with URL-encoded credentials
            if clone_url.startswith("https://"):
                encoded_username = quote(creds.username, safe="")
                encoded_password = quote(creds.password, safe="")
                auth_clone_url = clone_url.replace("https://", f"https://{encoded_username}:{encoded_password}@", 1)
            else:
                auth_clone_url = clone_url

            # Step 4: Clone to temp directory and push
            if not json_output:
                console.print("[cyan]Step 4: Pushing code to hub...[/cyan]")

            with tempfile.TemporaryDirectory(prefix="plato-hub-") as temp_dir:
                temp_repo = Path(temp_dir) / "repo"

                # Set up git environment to avoid credential helpers interfering
                git_env = os.environ.copy()
                git_env["GIT_TERMINAL_PROMPT"] = "0"
                git_env["GIT_ASKPASS"] = ""

                # Clone the repo
                result = subprocess.run(
                    ["git", "clone", auth_clone_url, str(temp_repo)],
                    capture_output=True,
                    text=True,
                    env=git_env,
                )
                if result.returncode != 0:
                    console.print(f"[red]❌ Failed to clone repo: {result.stderr}[/red]")
                    raise typer.Exit(1)

                # Create and checkout new branch
                branch_name = f"workspace-{int(time.time())}"
                result = subprocess.run(
                    ["git", "checkout", "-b", branch_name],
                    cwd=temp_repo,
                    capture_output=True,
                    text=True,
                    env=git_env,
                )
                if result.returncode != 0:
                    console.print(f"[red]❌ Failed to create branch: {result.stderr}[/red]")
                    raise typer.Exit(1)

                # Copy files respecting .gitignore
                current_dir = Path.cwd()
                _copy_files_respecting_gitignore(current_dir, temp_repo)

                # Git add
                subprocess.run(["git", "add", "."], cwd=temp_repo, capture_output=True, env=git_env)

                # Check for changes
                result = subprocess.run(
                    ["git", "status", "--porcelain"],
                    cwd=temp_repo,
                    capture_output=True,
                    text=True,
                    env=git_env,
                )

                if result.stdout.strip():
                    # Commit changes
                    subprocess.run(
                        ["git", "commit", "-m", "Sync from local workspace"],
                        cwd=temp_repo,
                        capture_output=True,
                        env=git_env,
                    )

                # Set the remote URL with credentials explicitly for push
                subprocess.run(
                    ["git", "remote", "set-url", "origin", auth_clone_url],
                    cwd=temp_repo,
                    capture_output=True,
                    env=git_env,
                )

                # Push the branch
                result = subprocess.run(
                    ["git", "push", "-u", "origin", branch_name],
                    cwd=temp_repo,
                    capture_output=True,
                    text=True,
                    env=git_env,
                )
                if result.returncode != 0:
                    console.print(f"[red]❌ Failed to push: {result.stderr}[/red]")
                    raise typer.Exit(1)

            if not json_output:
                console.print(f"[green]✓ Code pushed to branch: {branch_name}[/green]")

            # Step 5: Clone repo on VM via SSH
            if not json_output:
                console.print("[cyan]Step 5: Cloning repo on VM...[/cyan]")

            repo_dir = f"/home/plato/worktree/{service_name}"

            # Create worktree directory
            _run_ssh_command(ssh_config_path, ssh_host, "mkdir -p /home/plato/worktree")

            # Remove existing directory
            _run_ssh_command(ssh_config_path, ssh_host, f"rm -rf {repo_dir}")

            # Clone on VM
            clone_cmd = f"git clone -b {branch_name} {auth_clone_url} {repo_dir}"
            ret, stdout, stderr = _run_ssh_command(ssh_config_path, ssh_host, clone_cmd)
            if ret != 0:
                console.print(f"[red]❌ Failed to clone on VM: {stderr}[/red]")
                raise typer.Exit(1)

            if not json_output:
                console.print(f"[green]✓ Code cloned to {repo_dir}[/green]")

            # Step 6: Start services
            if not json_output:
                console.print("[cyan]Step 6: Starting services...[/cyan]")

            services_started = []
            for svc_name, svc_config in services_config.items():
                svc_type = svc_config.get("type", "")
                if svc_type == "docker-compose":
                    compose_file = svc_config.get("file", "docker-compose.yml")
                    compose_cmd = f"cd {repo_dir} && DOCKER_HOST=unix:///var/run/docker-user.sock docker compose -f {compose_file} up -d"

                    if not json_output:
                        console.print(f"[cyan]  Starting docker compose service: {svc_name}...[/cyan]")

                    ret, stdout, stderr = _run_ssh_command(ssh_config_path, ssh_host, compose_cmd)
                    if ret != 0:
                        console.print(f"[red]❌ Failed to start service '{svc_name}': {stderr}[/red]")
                        raise typer.Exit(1)

                    services_started.append({"name": svc_name, "type": "docker-compose", "file": compose_file})
                    if not json_output:
                        console.print(f"[green]  ✓ Started docker compose service: {svc_name}[/green]")
                else:
                    if not json_output:
                        console.print(f"[yellow]  ⚠ Skipped service '{svc_name}' (unknown type: {svc_type})[/yellow]")

            # Output results
            if json_output:
                console.print(
                    json.dumps(
                        {
                            "status": "ok",
                            "branch": branch_name,
                            "repo_url": clone_url,
                            "vm_path": repo_dir,
                            "services_started": services_started,
                        }
                    )
                )
            else:
                console.print("\n[green]✅ Services started successfully![/green]")
                console.print(f"  [cyan]Branch:[/cyan]  {branch_name}")
                console.print(f"  [cyan]VM Path:[/cyan] {repo_dir}")

    except typer.Exit:
        raise
    except Exception as e:
        if json_output:
            console.print(json.dumps({"error": str(e)}))
        else:
            console.print(f"[red]❌ Failed to start services: {e}[/red]")
        raise typer.Exit(1) from e
