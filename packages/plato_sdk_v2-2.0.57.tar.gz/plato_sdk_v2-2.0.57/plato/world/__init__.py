"""World module - OpenAI Gym-like interface for Plato simulators.

Provides an abstract World base class that manages Plato sessions and
exposes simulator URLs for agents to interact with via plato.sims SDK.

Usage:
    from plato.world import World, WorldConfig, EnvSpec, Observation, StepResult

    class MyWorld(World):
        async def _on_reset(self) -> Observation:
            return Observation(step=0, date=self.config.start_date, data={})

        async def _on_step(self) -> StepResult:
            return StepResult(observation=obs, reward=100.0)

        def get_prompt(self) -> str:
            return f"Day {self._current_step}: Do something..."

    config = WorldConfig(
        name="my-world",
        envs=[EnvSpec(alias="store", simulator="spree")],
        num_steps=30,
    )

    async with MyWorld(config) as world:
        obs = await world.reset()
        for _ in range(config.num_steps):
            # Agent takes turn using world.get_env_vars()
            result = await world.step()
            if result.done:
                break
"""

from plato.world.base import World
from plato.world.config import EnvSpec, WorldConfig
from plato.world.types import Observation, StepResult

__all__ = [
    "World",
    "WorldConfig",
    "EnvSpec",
    "Observation",
    "StepResult",
]
