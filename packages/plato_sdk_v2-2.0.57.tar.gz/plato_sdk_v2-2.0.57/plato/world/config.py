"""World configuration - WorldConfig and EnvSpec."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field, model_validator

from plato.v2 import Env, EnvFromArtifact, EnvFromSimulator


class EnvSpec(BaseModel):
    """Specification for a single environment in the world.

    Environments can be specified either by:
    - simulator + dataset: Create a fresh simulator instance
    - artifact_id: Load from a saved artifact

    Attributes:
        alias: Unique identifier for this environment (e.g., "store", "accounting")
        simulator: Simulator type (e.g., "spree", "firefly", "espocrm")
        artifact_id: Optional artifact ID to load from
        dataset: Dataset to use when creating fresh instance (default: "blank")
    """

    alias: str
    simulator: str | None = None
    artifact_id: str | None = None
    dataset: str | None = None

    @model_validator(mode="after")
    def validate_env_source(self) -> EnvSpec:
        """Ensure either simulator or artifact_id is provided."""
        if not self.artifact_id and not self.simulator:
            raise ValueError(f"EnvSpec '{self.alias}' must have either simulator or artifact_id")
        return self

    def to_plato_env(self) -> EnvFromArtifact | EnvFromSimulator:
        """Convert to Plato Env object for session creation.

        Returns:
            Env object suitable for AsyncPlato.sessions.create()
        """
        if self.artifact_id:
            return Env.artifact(self.artifact_id, alias=self.alias)
        # validator ensures simulator is set if artifact_id is not
        assert self.simulator is not None
        return Env.simulator(self.simulator, alias=self.alias, dataset=self.dataset)


class WorldConfig(BaseModel):
    """Configuration for a World.

    All configs can be loaded from YAML files.

    Example YAML format:
        ```yaml
        name: "merchant-sim"
        num_steps: 30
        start_date: "2024-01-01"
        envs:
          - alias: store
            simulator: spree
          - alias: accounting
            artifact_id: "abc-123"
        ```

    Attributes:
        name: Human-readable name for this world
        envs: List of environment specifications
        num_steps: Number of simulation steps (e.g., days)
        start_date: Simulation start date (ISO format)
        seed: Random seed for reproducibility
    """

    name: str = "world"
    envs: list[EnvSpec] = Field(default_factory=list)
    num_steps: int = 30
    start_date: str = "2024-01-01"
    seed: int = 42
    session_timeout: int = Field(default=300, description="Timeout for session creation in seconds")

    @classmethod
    def from_yaml(cls, path: str | Path) -> WorldConfig:
        """Load configuration from a YAML file.

        Args:
            path: Path to YAML config file

        Returns:
            Loaded WorldConfig instance

        Raises:
            FileNotFoundError: If config file doesn't exist
        """
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")

        with open(path) as f:
            data = yaml.safe_load(f)

        return cls(**data)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WorldConfig:
        """Create configuration from a dictionary.

        Args:
            data: Configuration dictionary

        Returns:
            WorldConfig instance
        """
        return cls(**data)

    def get_env(self, alias: str) -> EnvSpec | None:
        """Get environment spec by alias.

        Args:
            alias: Environment alias to find

        Returns:
            EnvSpec if found, None otherwise
        """
        for env in self.envs:
            if env.alias == alias:
                return env
        return None

    def get_env_aliases(self) -> list[str]:
        """Get list of all environment aliases.

        Returns:
            List of alias strings
        """
        return [env.alias for env in self.envs]
