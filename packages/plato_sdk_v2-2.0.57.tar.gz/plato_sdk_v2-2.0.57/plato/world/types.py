"""World types - Observation and StepResult."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class Observation(BaseModel):
    """Observation from the world after a step.

    Contains the current state information that the agent observes.

    Attributes:
        step: Current step number (0 for initial reset)
        date: Current simulation date (ISO format)
        data: Custom observation data (world-specific)
    """

    step: int
    date: str
    data: dict[str, Any] = Field(default_factory=dict)

    model_config = {"extra": "allow"}


class StepResult(BaseModel):
    """Result of a world step.

    Follows OpenAI Gym convention with observation, reward, done, info.

    Attributes:
        observation: Current state/observation after the step
        reward: Numeric reward for this step (e.g., profit, score)
        done: Whether the simulation has ended
        truncated: Whether step was cut short (e.g., timeout)
        info: Additional information about the step
    """

    observation: Observation
    reward: float = 0.0
    done: bool = False
    truncated: bool = False
    info: dict[str, Any] = Field(default_factory=dict)

    model_config = {"arbitrary_types_allowed": True}
