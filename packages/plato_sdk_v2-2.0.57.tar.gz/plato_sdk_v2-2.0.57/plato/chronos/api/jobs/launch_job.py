"""Launch Job"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import LaunchJobRequest, LaunchJobResponse


def _build_request_args(
    body: LaunchJobRequest,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/jobs/launch"

    return {
        "method": "POST",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    body: LaunchJobRequest,
) -> LaunchJobResponse:
    """Launch a new Chronos job."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return LaunchJobResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: LaunchJobRequest,
) -> LaunchJobResponse:
    """Launch a new Chronos job."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return LaunchJobResponse.model_validate(response.json())
