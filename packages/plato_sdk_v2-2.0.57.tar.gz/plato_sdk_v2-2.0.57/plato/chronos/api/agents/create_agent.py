"""Create Agent"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import AgentCreate, AgentResponse


def _build_request_args(
    body: AgentCreate,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/agents"

    return {
        "method": "POST",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    body: AgentCreate,
) -> AgentResponse:
    """Create a new agent version."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return AgentResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: AgentCreate,
) -> AgentResponse:
    """Create a new agent version."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return AgentResponse.model_validate(response.json())
