"""List Trajectories For Session"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import TrajectoryListResponse


def _build_request_args(
    session_public_id: str,
) -> dict[str, Any]:
    """Build request arguments."""
    url = f"/api/trajectories/session/{session_public_id}"

    return {
        "method": "GET",
        "url": url,
    }


def sync(
    client: httpx.Client,
    session_public_id: str,
) -> TrajectoryListResponse:
    """List all trajectories for a session."""

    request_args = _build_request_args(
        session_public_id=session_public_id,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return TrajectoryListResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    session_public_id: str,
) -> TrajectoryListResponse:
    """List all trajectories for a session."""

    request_args = _build_request_args(
        session_public_id=session_public_id,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return TrajectoryListResponse.model_validate(response.json())
