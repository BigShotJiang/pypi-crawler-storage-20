"""Delete World"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status


def _build_request_args(
    public_id: str,
) -> dict[str, Any]:
    """Build request arguments."""
    url = f"/api/worlds/{public_id}"

    return {
        "method": "DELETE",
        "url": url,
    }


def sync(
    client: httpx.Client,
    public_id: str,
) -> dict[str, Any]:
    """Archive a world."""

    request_args = _build_request_args(
        public_id=public_id,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return response.json()


async def asyncio(
    client: httpx.AsyncClient,
    public_id: str,
) -> dict[str, Any]:
    """Archive a world."""

    request_args = _build_request_args(
        public_id=public_id,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return response.json()
