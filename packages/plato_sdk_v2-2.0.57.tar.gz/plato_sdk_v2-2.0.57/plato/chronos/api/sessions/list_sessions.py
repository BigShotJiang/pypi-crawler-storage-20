"""List Sessions"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import SessionListResponse


def _build_request_args() -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/sessions"

    return {
        "method": "GET",
        "url": url,
    }


def sync(
    client: httpx.Client,
) -> SessionListResponse:
    """List all sessions for the org."""

    request_args = _build_request_args()

    response = client.request(**request_args)
    raise_for_status(response)
    return SessionListResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
) -> SessionListResponse:
    """List all sessions for the org."""

    request_args = _build_request_args()

    response = await client.request(**request_args)
    raise_for_status(response)
    return SessionListResponse.model_validate(response.json())
