"""Plato Worlds - simple world definitions for agent execution.

A World defines:
- Available agent slots (list of strings)
- Configuration schema
- Run logic (what happens when the world executes)

Usage:
    from plato.worlds import BaseWorld, register_world, AgentSlot

    @register_world("code")
    class CodeWorld(BaseWorld):
        agents = ["coder"]  # Available agent slots

        async def run(self, config: RunConfig) -> None:
            # Clone repo, run agent, etc.
            pass
"""

from plato.worlds.base import (
    AgentSlot,
    BaseWorld,
    Observation,
    StepResult,
    get_registered_worlds,
    get_world,
    register_world,
)
from plato.worlds.config import AgentConfig, RunConfig, WorldConfig
from plato.worlds.runner import run_world

__all__ = [
    "BaseWorld",
    "AgentSlot",
    "Observation",
    "StepResult",
    "WorldConfig",
    "AgentConfig",
    "RunConfig",
    "register_world",
    "get_registered_worlds",
    "get_world",
    "run_world",
]
