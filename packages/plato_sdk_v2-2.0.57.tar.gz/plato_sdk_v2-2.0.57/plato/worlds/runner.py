"""World runner - discovers and runs Plato worlds."""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from plato.worlds.config import RunConfig

logger = logging.getLogger(__name__)


def discover_worlds() -> None:
    """Discover and load installed world packages via entry points.

    World packages declare entry points in pyproject.toml:
        [project.entry-points."plato.worlds"]
        code = "code_world:CodeWorld"

    This function loads all such entry points, triggering registration.
    """
    import importlib.metadata

    try:
        eps = importlib.metadata.entry_points(group="plato.worlds")
    except TypeError:
        # Python < 3.10 compatibility
        eps = importlib.metadata.entry_points().get("plato.worlds", [])

    for ep in eps:
        try:
            ep.load()
            logger.debug(f"Loaded world: {ep.name}")
        except Exception as e:
            logger.warning(f"Failed to load world '{ep.name}': {e}")


async def run_world(world_name: str, config: RunConfig) -> None:
    """Run a world by name with the given configuration.

    Args:
        world_name: Name of the world to run
        config: Run configuration

    Raises:
        ValueError: If world not found
    """
    # Discover installed world packages
    discover_worlds()

    from plato.worlds.base import get_registered_worlds, get_world

    world_cls = get_world(world_name)
    if world_cls is None:
        available = list(get_registered_worlds().keys())
        raise ValueError(f"World '{world_name}' not found. Available: {available}")

    world = world_cls()
    await world.run(config)


def main() -> None:
    """CLI entry point for the world runner.

    Usage:
        plato-world-runner --world code --config /path/to/config.json
        plato-world-runner --list
    """
    parser = argparse.ArgumentParser(
        prog="plato-world-runner",
        description="Run Plato worlds",
    )
    parser.add_argument(
        "--world",
        "-w",
        help="World name to run",
    )
    parser.add_argument(
        "--config",
        "-c",
        help="Path to config JSON file",
    )
    parser.add_argument(
        "--list",
        "-l",
        action="store_true",
        help="List available worlds",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose logging",
    )

    args = parser.parse_args()

    # Setup logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # List worlds
    if args.list:
        # Discover installed world packages
        discover_worlds()

        from plato.worlds.base import get_registered_worlds

        worlds = get_registered_worlds()
        if not worlds:
            print("No worlds found.")
        else:
            print("Available worlds:")
            for name, cls in worlds.items():
                desc = getattr(cls, "description", "") or ""
                version = cls.get_version()
                print(f"  {name} (v{version}): {desc}")
        return

    # Run world
    if not args.world:
        parser.error("--world is required (or use --list to see available worlds)")

    if not args.config:
        parser.error("--config is required")

    config_path = Path(args.config)
    if not config_path.exists():
        print(f"Error: Config file not found: {config_path}", file=sys.stderr)
        sys.exit(1)

    # Import here to avoid circular imports
    from plato.worlds.config import RunConfig

    # Discover worlds first to get config class
    discover_worlds()

    from plato.worlds.base import get_world

    world_cls = get_world(args.world)
    if world_cls is None:
        from plato.worlds.base import get_registered_worlds

        available = list(get_registered_worlds().keys())
        print(f"Error: World '{args.world}' not found. Available: {available}", file=sys.stderr)
        sys.exit(1)

    # Load config with the world's typed config class if available
    config = RunConfig.from_file(config_path, config_class=world_cls.config_class)

    try:
        # Run the world directly (we already have the class)
        world = world_cls()
        asyncio.run(world.run(config))
    except Exception as e:
        logger.exception(f"World execution failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
