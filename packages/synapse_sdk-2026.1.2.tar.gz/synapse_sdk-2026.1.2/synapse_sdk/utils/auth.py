"""Authentication utilities for SDK."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from synapse_sdk.clients.backend import BackendClient

# Environment variable names
ENV_SYNAPSE_HOST = 'SYNAPSE_HOST'
ENV_SYNAPSE_ACCESS_TOKEN = 'SYNAPSE_ACCESS_TOKEN'

# Default host
DEFAULT_HOST = 'https://api.synapse.sh'

# Config file path
CONFIG_FILE = Path.home() / '.synapse' / 'config.json'


def load_credentials() -> tuple[str | None, str | None]:
    """Load credentials from environment or config file.

    Priority:
    1. Environment variables (SYNAPSE_HOST, SYNAPSE_ACCESS_TOKEN)
    2. Config file (~/.synapse/config.json)

    Returns:
        Tuple of (host, token). Either may be None if not found.
    """
    host = os.environ.get(ENV_SYNAPSE_HOST)
    token = os.environ.get(ENV_SYNAPSE_ACCESS_TOKEN)

    # Fall back to config.json
    if not token and CONFIG_FILE.exists():
        try:
            config = json.loads(CONFIG_FILE.read_text())
            if not host:
                host = config.get('host')
            if not token:
                token = config.get('access_token')
        except (json.JSONDecodeError, OSError):
            pass

    return host, token


def create_backend_client() -> BackendClient | None:
    """Create a BackendClient from environment/credentials if available.

    Returns:
        BackendClient if credentials are available, None otherwise.
    """
    host, token = load_credentials()

    if not token:
        return None

    from synapse_sdk.clients.backend import BackendClient

    return BackendClient(base_url=host or DEFAULT_HOST, access_token=token)


__all__ = [
    'ENV_SYNAPSE_HOST',
    'ENV_SYNAPSE_ACCESS_TOKEN',
    'DEFAULT_HOST',
    'CONFIG_FILE',
    'load_credentials',
    'create_backend_client',
]
