import sys

# Dynamically get Python version
PYTHON_VERSION = f"v{sys.version_info.major}.{sys.version_info.minor}"

LOGO_PYTHON = rf"""  ____        _   _
 |  _ \ _   _| |_| |__   ___  _ __ 
 | |_) | | | | __| '_ \ / _ \| '_ \
 |  __/| |_| | |_| | | | (_) | | | |
 |_|    \__, |\__|_| |_|\___/|_| |_| ({PYTHON_VERSION})
        |___/
"""

# Snake logo ASCII art
LOGO_SNAKE = rf"""
      /^\/^\
    _|__|  O|             Python({PYTHON_VERSION})
\/     /~     \_/ \
 \____|__________/  \
        \_______      \
                `\     \                 \
                  |     |                  \
                 /      /                    \
                /     /                       \\
              /      /                         \ \
             /     /                            \  \
           /     /             _----_            \   \
          /     /           _-~      ~-_         |   |
         (      (        _-~    _--_    ~-_     _/   |
          \      ~-____-~    _-~    ~-_    ~-_-~    /
            ~-_           _-~          ~-_       _-~
               ~--______-~                ~-___-~
"""


def python():
    """Print Python text ASCII art"""
    print(LOGO_PYTHON)


def snake():
    """Print snake logo ASCII art"""
    print(LOGO_SNAKE)
