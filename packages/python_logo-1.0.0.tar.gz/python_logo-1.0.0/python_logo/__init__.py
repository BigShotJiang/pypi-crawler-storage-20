"""Python Logo package
Provides Python-related ASCII art output functionality
"""

from .logo import python, snake, LOGO_PYTHON, LOGO_SNAKE

# Public interface
__all__ = ['python', 'snake', 'LOGO_PYTHON', 'LOGO_SNAKE']
# Version number, aligned with setup.py
__version__ = '1.0.0'