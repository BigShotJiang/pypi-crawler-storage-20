from setuptools import setup, find_packages

setup(
    name="python_logo",
    version="1.0.0",
    packages=find_packages(),
    description="A Python ASCII art logo package",
    author="Hollson",
    author_email="hollson@qq.com",
    url="https://github.com/hollson/python-logo",
    license="MIT",
    python_requires=">=3.6",
)
