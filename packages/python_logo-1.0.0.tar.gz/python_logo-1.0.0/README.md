# 🐍 PythonLogo

**PythonLogo** is a simple Python ASCII art logo package, perfect for displaying Python identifiers in the terminal.

<br/>

## 🚀 Installation

Requires Python 3.6 or higher. Install quickly via pip:

```bash
pip install python_logo
```

View python_logo package information

```bash
$ pip list | grep python_logo
python_logo          1.0.0        /Users/hollson/python_logo

$ pip  show python_logo
Name: python_logo
Version: 1.0.0
Summary: A Python ASCII art logo package
Home-page: https://pypi.org/project/python-logo
Author: Hollson
Author-email: hollson@qq.com
License: MIT
Location: /Library/Frameworks/Python.framework/Versions/3.12/lib/python3.12/site-packages
Editable project location: /Users/hollson/python_logo
Requires: 
Required-by: 
```





<br/>

## 📚 Usage Examples

### Basic Usage

```python
import python_logo as logo

# Print Python text ASCII art logo
logo.python()

# Print snake logo
logo.snake()

# Access constants directly
print(logo.LOGO_PYTHON)
print(logo.LOGO_SNAKE)
```

### Command Line Usage

After installation, you can use it directly in the terminal:

```bash
# Print Python Logo
python -c "import python_logo; python_logo.python()"

# Print snake logo  
python -c "import python_logo; python_logo.snake()"
```

### Output Examples

**Python Logo:**
```
  ____        _
 |  _ \ _   _| |_| |__   ___  _ __ 
 | |_) | | | | __| '_ \ / _ \| '_ \
 |  __/| |_| | |_| | | | (_) | | | |
 |_|    \__, |\__|_| |_|\___/|_| |_| (v3.12)
        |___/
```

**Snake Logo:**
```
      /^\/^\
    _|__|  O|              Python(v3.12)
\/     /~     \_/ \
 \____|__________/  \
        \_______      \
                `\     \                 \
                  |     |                  \
                 /      /                    \
                /     /                       \\
              /      /                         \ \
             /     /                            \  \
           /     /             _----_            \   \
          /     /           _-~      ~-_         |   |
         (      (        _-~    _--_    ~-_     _/   |
          \      ~-____-~    _-~    ~-_    ~-_-~    /
            ~-_           _-~          ~-_       _-~
               ~--______-~                ~-___-~
```



<br/>

## 📜 License

This project is open sourced under the MIT License - see the [LICENSE](LICENSE) file for details.