# Verbex Python SDK

Learn how to build and manage intelligent AI Agents with the Verbex Platform.

Welcome to Verbex — where building intelligent AI Agents becomes simple and powerful. The platform enables businesses to create sophisticated AI Agents that understand, engage, and respond naturally to customer needs, enhancing customer service while maintaining efficiency at scale.

## Why Verbex

Verbex combines advanced AI technology with intuitive tools to help you create voice assistants that truly represent your brand. Whether you need 24/7 support, automation of routine tasks, or personalized user experiences, Verbex provides the foundation for conversational solutions that grow with your business.

## What is the Verbex SDK

The Verbex Python SDK is a clean, modular client for the Verbex API. It gives you a consistent interface for creating agents, configuring tools, managing calls, and more.

## Install

```bash
pip install verbex-sdk
```

## Getting an API key

1) Sign up on the Verbex Platform.
2) Open the API Keys page.
3) Click "Add new API key".
4) Name the key and click "Create".
5) Copy the key now. You will not be able to view it again.

## Quick start (create an agent)

```python
import verbex

client = verbex.Verbex(api_key="YOUR_API_KEY")

payload = {
    "agent_name": "Support Agent",
    "llm": {
        "llm_type": "simple",
        "model_provider": "openai",
        "model_name": "gpt-4",
        "system_prompt": "You are a helpful support agent.",
        "model_temperature": 0,
    },
    "tts": {
        "provider": "elevenlabs",
        "voice_id": "voice_id",
        "voice_name": "Default",
        "model_name": "eleven_turbo_v2_5",
        "voice_temperature": 0.2,
    },
    "stt": {"provider": "deepgram", "model": "nova-2-general"},
}

agent = client.ai_agents.create(payload)
```

## Documentation

See the `docs/` folder for endpoint guides and examples.

## Notes

- You can set `VERBEX_API_KEY` instead of passing the key to `Verbex()`.
- The default base URL is `https://api.verbex.ai`.


## Contributing

See `CONTRIBUTING.md` for guidelines on issues, pull requests, and development setup.
