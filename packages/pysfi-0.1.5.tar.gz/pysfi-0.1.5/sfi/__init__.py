"""Single File commands for Interactive python."""

__version__ = "0.1.5"
