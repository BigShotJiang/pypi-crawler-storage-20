#!/usr/bin/bash

set -e

python3 -m venv pvenv
source pvenv/bin/activate

pip install --upgrade maturin twine
maturin sdist
twine upload --verbose ../target/wheels/*.tar.gz

deactivate

rm -rf pvenv/
