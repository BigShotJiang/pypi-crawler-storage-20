## Release 0.2.0

**Added**:

- Added CLI argument to filter items by minimum severity.
- Added fallback mechanism if `path_in_vcs` is not available
  (crates published with old versions of `cargo`).

**Changed**:

- *Breaking*: Dropped CLI functionality from the "default" features.
- Improved rendering of unified diffs for file content changes.
- Simplified logic around the handling of `.cargo_vcs_info.json` files.
- Updated `cargo_metadata` dependency to `v0.23`.

**Fixed**:

- Fixed formatting of metadata paths of target-specific dependencies.
- Fixed logic bug in version requirement comparison.
- Refactored code for report generation to avoid code duplication.
- Fixed detection of stripped `git`-type dependencies.
- Explicitly call git in non-interactive mode
  (improves detection of invalid repository URLs).

## Release 0.1.1

- Updated README and add some example code snippets.

## Release 0.1.0

Initial release.
