# crate-ingredients

This crate contains Python bindings for the [`ingredients`] crate. The Python API is intended to
match the provided Rust API, wherever reasonable.

## External dependencies

* `cargo` must be available in `$PATH`
* `git` must be available in `$PATH` when calling `Crate.report`

[`ingredients`]: https://crates.io/crates/ingredients
