"""Version information for llama-cpp-py-sync."""

__version__ = "0.7751"
__llama_cpp_commit__ = "785a71008"
__llama_cpp_tag__ = "b7751"
