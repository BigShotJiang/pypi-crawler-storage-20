"""
Entry point for the `roar` command-line interface.

roar (Run Observation & Artifact Registration) is a local front-end to
TReqs' Lineage-as-a-Service (GLaaS). It registers data artifacts and
execution steps (jobs) in ML pipelines.

Commands:
    roar init              Initialize roar in current directory
    roar run <command>     Run a command with provenance tracking
    roar build <command>   Run a build step with provenance tracking
    roar dag               View and manage execution DAG
    roar show <id>         Show artifact, job, or DAG node details
    roar reproduce <hash>  Reproduce an artifact
    roar log               Show recent jobs
    roar history <script>  Show job history for a script
    roar status            Show tracked artifacts
    roar get <url> <dest>  Download and register external data
    roar put <src> <url>   Upload and register artifacts
    roar clean             Delete all written files
    roar rm <file>         Remove specific file(s)
    roar verify            Verify artifact integrity
    roar auth              Manage GLaaS authentication
    roar sync              Manage live sync to GLaaS
    roar config            View or set configuration
    roar omit              Manage secret filtering for sync
    roar reversible        Manage file preservation
"""

import sys


def _print_help():
    """Print main help message."""
    print("roar - Run Observation & Artifact Registration")
    print("")
    print("A local front-end to TReqs' Lineage-as-a-Service (GLaaS).")
    print("Tracks data artifacts and execution steps in ML pipelines.")
    print("")
    print("Usage: roar <command> [args...]")
    print("")
    print("Commands:")
    print("  init               Initialize roar in current directory")
    print("  run <command>      Run a command with provenance tracking")
    print("  run @N             Re-run DAG node N")
    print("  build <command>    Run a build step (e.g., maturin, make)")
    print("  dag                View and manage execution DAG")
    print("  show <id>          Show artifact, job, or DAG node details")
    print("  reproduce <hash>   Reproduce an artifact")
    print("  log                Show recent jobs")
    print("  history <script>   Show job history for a script")
    print("  status             Show tracked artifacts")
    print("  get <url> <dest>   Download and register external data")
    print("  put <src> <url>    Upload and register artifacts")
    print("  clean              Delete all written files")
    print("  rm <file>          Remove specific file(s)")
    print("  verify             Verify artifact integrity")
    print("  auth               Manage GLaaS authentication")
    print("  sync               Manage live sync to GLaaS")
    print("  config             View or set configuration")
    print("  omit               Manage secret filtering for sync")
    print("  reversible         Manage file preservation")


_COMMAND_MODULES = {
    "init": ("roar.commands.init", "InitCommand"),
    "status": ("roar.commands.status", "StatusCommand"),
    "run": ("roar.commands.run", "RunCommand"),
    "build": ("roar.commands.build", "BuildCommand"),
    "dag": ("roar.commands.dag", "DagCommand"),
    "show": ("roar.commands.show", "ShowCommand"),
    "reproduce": ("roar.commands.reproduce", "ReproduceCommand"),
    "log": ("roar.commands.log", "LogCommand"),
    "history": ("roar.commands.history", "HistoryCommand"),
    "get": ("roar.commands.get", "GetCommand"),
    "put": ("roar.commands.put", "PutCommand"),
    "clean": ("roar.commands.clean", "CleanCommand"),
    "rm": ("roar.commands.rm", "RmCommand"),
    "verify": ("roar.commands.verify", "VerifyCommand"),
    "auth": ("roar.commands.auth", "AuthCommand"),
    "sync": ("roar.commands.sync", "SyncCommand"),
    "config": ("roar.commands.config_cmd", "ConfigCommand"),
    "omit": ("roar.commands.omit", "OmitCommand"),
    "reversible": ("roar.commands.reversible", "ReversibleCommand"),
}


def _print_command_help(command: str) -> None:
    """Print help for a specific command with minimal imports."""
    import importlib

    if command not in _COMMAND_MODULES:
        print(f"Unknown command: {command}")
        print("Run 'roar --help' for available commands.")
        sys.exit(1)

    module_path, class_name = _COMMAND_MODULES[command]
    module = importlib.import_module(module_path)
    command_class = getattr(module, class_name)
    instance = command_class()
    print(instance.get_help())


def main():
    # EARLY EXIT for main help (no bootstrap needed)
    if len(sys.argv) < 2:
        _print_help()
        sys.exit(1)

    sub = sys.argv[1]
    args = sys.argv[2:]

    # Handle main help flag early
    if sub in ("-h", "--help"):
        _print_help()
        sys.exit(0)

    # EARLY EXIT for command help (minimal bootstrap)
    if "-h" in args or "--help" in args:
        _print_command_help(sub)
        sys.exit(0)

    # Full bootstrap only for actual command execution
    from .commands.dispatcher import dispatch_command
    from .core.bootstrap import bootstrap

    bootstrap()

    # Dispatch through the command system
    exit_code = dispatch_command(sub, args)
    if exit_code is not None:
        sys.exit(exit_code)

    # Unknown command
    print(f"Unknown subcommand: {sub}")
    print("Run 'roar --help' for available commands.")
    sys.exit(1)


if __name__ == "__main__":
    main()
