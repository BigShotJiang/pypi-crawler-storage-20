"""Unit tests for put command lineage query fix.

Tests that the put command correctly uses SQLAlchemy text() and named parameters
for build jobs queries, avoiding the "List argument must consist only of
dictionaries" error with SQLAlchemy 2.x.
"""

import pytest
from unittest.mock import MagicMock, patch

from sqlalchemy import text


class TestPutLineageQuery:
    """Test that put command correctly queries build jobs."""

    def test_build_jobs_query_uses_named_parameters(self):
        """Verify build jobs query uses SQLAlchemy text() with named params.

        The bug was that raw SQL strings with ? placeholders and tuple
        parameters were being passed to SQLAlchemy 2.x Connection.execute(),
        which requires text() wrapped SQL and dict parameters.
        """
        # Import the module to verify text() is imported
        from roar.commands import put

        # Verify sqlalchemy text is imported in put module
        assert hasattr(put, "text") or "text" in dir(put)

    def test_put_command_build_jobs_query_format(self):
        """Test that the build jobs query is properly formatted."""
        from roar.commands.put import PutCommand

        # The fix should use:
        # - text() wrapper around SQL
        # - Named parameter :session_id instead of ?
        # - Dict parameter {"session_id": value} instead of tuple

        # Read the source to verify the pattern
        import inspect

        source = inspect.getsource(PutCommand.execute)

        # Verify the fix is in place
        assert "text(" in source, "Query should use text() wrapper"
        assert ":session_id" in source, "Query should use named parameter :session_id"
        assert '"session_id":' in source or "'session_id':" in source, (
            "Query should pass dict with session_id key"
        )

        # Verify old pattern is NOT present
        assert "WHERE session_id = ?" not in source, (
            "Query should not use ? placeholder"
        )


class TestShowLineageQuery:
    """Test that show command correctly queries sessions and outputs."""

    def test_show_command_uses_named_parameters(self):
        """Verify show command queries use text() with named params."""
        from roar.commands.show import ShowCommand

        import inspect

        source = inspect.getsource(ShowCommand)

        # Check sessions prefix query
        assert ":hash_prefix" in source, (
            "Sessions query should use named parameter :hash_prefix"
        )

        # Check outputs query
        assert ":session_id" in source, (
            "Outputs query should use named parameter :session_id"
        )

        # Verify text() is used
        assert source.count("text(") >= 2, "Should have at least 2 text() calls"


class TestRmLineageQuery:
    """Test that rm command correctly queries artifacts."""

    def test_rm_command_uses_named_parameters(self):
        """Verify rm command queries use text() with named params."""
        from roar.commands.rm import RmCommand

        import inspect

        source = inspect.getsource(RmCommand)

        # Check path queries use named parameters
        assert ":path" in source, "Path query should use named parameter :path"
        assert ":path_suffix" in source, (
            "Path suffix query should use named parameter :path_suffix"
        )

        # Verify text() is used
        assert source.count("text(") >= 2, "Should have at least 2 text() calls"


class TestSQLAlchemyTextImports:
    """Test that all affected modules import sqlalchemy text."""

    def test_put_imports_text(self):
        """Verify put.py imports text from sqlalchemy."""
        from roar.commands.put import text as put_text

        assert put_text is text

    def test_show_imports_text(self):
        """Verify show.py imports text from sqlalchemy."""
        from roar.commands.show import text as show_text

        assert show_text is text

    def test_rm_imports_text(self):
        """Verify rm.py imports text from sqlalchemy."""
        from roar.commands.rm import text as rm_text

        assert rm_text is text
