"""
LLM回调类，提供异步LLM调用接口
支持OpenAI AsyncOpenAI和LangChain ChatOpenAI两种方式
"""

import os
import sys
from typing import Optional, Dict, Any, Callable, Union
import asyncio

# 导入依赖管理模块
try:
    from .deps import check_and_install_specific
except ImportError:
    # 如果deps模块尚未导入，我们可能需要在路径中添加
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ylbot.deps import check_and_install_specific


class AsyncLLMCallback:
    """异步LLM回调类，封装OpenAI AsyncOpenAI和LangChain ChatOpenAI"""
    
    def __init__(self, 
                 api_key: Optional[str] = None,
                 base_url: Optional[str] = None,
                 model: str = "gpt-3.5-turbo",
                 use_langchain: bool = False,
                 streaming: bool = False,
                 **kwargs):
        """
        初始化异步LLM回调
        
        Args:
            api_key: API密钥，如果为None则从环境变量LLM_API_KEY获取
            base_url: API基础URL，如果为None则从环境变量LLM_BASE_URL获取
            model: 模型名称，如果为None则从环境变量LLM_MODEL获取
            use_langchain: 是否使用LangChain的ChatOpenAI，否则使用OpenAI AsyncOpenAI
            streaming: 是否使用流式输出
            **kwargs: 其他参数传递给LLM客户端
        """
        self.api_key = api_key or os.getenv("LLM_API_KEY", "ollama")
        self.base_url = base_url or os.getenv("LLM_BASE_URL", "http://localhost:11434/v1")
        self.model = model or os.getenv("LLM_MODEL", "qwen3:latest")
        self.use_langchain = use_langchain
        self.streaming = streaming
        self.kwargs = kwargs
        
        # 客户端实例
        self.client = None
        self.langchain_llm = None
        
        # 初始化客户端
        self._init_client()
    
    def _init_client(self):
        """初始化LLM客户端"""
        if self.use_langchain:
            self._init_langchain_client()
        else:
            self._init_openai_client()
    
    def _init_langchain_client(self):
        """初始化LangChain客户端"""
        try:
            from langchain_openai import ChatOpenAI
            
            self.langchain_llm = ChatOpenAI(
                model=self.model,
                api_key=self.api_key,
                base_url=self.base_url,
                streaming=self.streaming,
                **self.kwargs
            )
            print(f"初始化LangChain ChatOpenAI客户端，模型: {self.model}")
            
        except ImportError as e:
            raise ImportError(
                "未安装langchain-openai包，请运行: pip install langchain-openai\n"
                "或设置use_langchain=False使用OpenAI AsyncOpenAI"
            ) from e
    
    def _init_openai_client(self):
        """初始化OpenAI客户端"""
        try:
            from openai import AsyncOpenAI
            
            self.client = AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
            print(f"初始化OpenAI AsyncOpenAI客户端，模型: {self.model}")
            
        except ImportError as e:
            raise ImportError(
                "未安装openai包，请运行: pip install openai"
            ) from e
    
    async def __call__(self, prompt: str, **kwargs) -> str:
        """异步调用LLM
        
        Args:
            prompt: 提示词
            **kwargs: 其他参数传递给LLM
            
        Returns:
            str: LLM的回复
        """
        if self.use_langchain:
            return await self._call_langchain(prompt, **kwargs)
        else:
            return await self._call_openai(prompt, **kwargs)
    
    async def _call_openai(self, prompt: str, **kwargs) -> str:
        """调用OpenAI AsyncOpenAI"""
        if self.client is None:
            self._init_openai_client()
        
        try:
            # 合并初始化参数和调用参数
            call_kwargs = {**self.kwargs, **kwargs}
            
            # 构建消息
            messages = [
                {"role": "user", "content": prompt}
            ]
            
            # 调用LLM
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                stream=self.streaming,
                **call_kwargs
            )
            
            # 处理流式和非流式响应
            if self.streaming:
                content = ""
                async for chunk in response:
                    if chunk.choices[0].delta.content:
                        content += chunk.choices[0].delta.content
                return content
            else:
                return response.choices[0].message.content
            
        except Exception as e:
            # 返回一个降级回复，避免因为LLM调用失败而影响系统运行
            error_msg = f"OpenAI调用LLM失败: {e}"
            print(error_msg)
            return f"LLM调用失败: {str(e)[:100]}..."
    
    async def _call_langchain(self, prompt: str, **kwargs) -> str:
        """调用LangChain ChatOpenAI"""
        if self.langchain_llm is None:
            self._init_langchain_client()
        
        try:
            from langchain_core.messages import HumanMessage
            
            # 合并初始化参数和调用参数
            call_kwargs = {**self.kwargs, **kwargs}
            
            messages = [HumanMessage(content=prompt)]
            
            if self.streaming:
                content = ""
                async for chunk in self.langchain_llm.astream(messages, **call_kwargs):
                    content += chunk.content
                return content
            else:
                response = await self.langchain_llm.ainvoke(messages, **call_kwargs)
                return response.content
            
        except Exception as e:
            # 返回一个降级回复
            error_msg = f"LangChain调用LLM失败: {e}"
            print(error_msg)
            return f"LLM调用失败: {str(e)[:100]}..."
    
    @classmethod
    def create_from_env(cls, use_langchain: bool = False, **kwargs) -> "AsyncLLMCallback":
        """从环境变量创建异步LLM回调实例
        
        Args:
            use_langchain: 是否使用LangChain
            **kwargs: 其他参数
            
        Returns:
            AsyncLLMCallback: 异步LLM回调实例
        """
        api_key = os.getenv("LLM_API_KEY", "ollama")
        base_url = os.getenv("LLM_BASE_URL", "http://localhost:11434/v1")
        model = os.getenv("LLM_MODEL", "gpt-3.5-turbo")
        
        return cls(
            api_key=api_key,
            base_url=base_url,
            model=model,
            use_langchain=use_langchain,
            **kwargs
        )
    
    @classmethod
    def create_for_ollama(cls, 
                         base_url: str = "http://192.168.66.26:11434/v1",
                         model: str = "qwen3:latest",
                         **kwargs) -> "AsyncLLMCallback":
        """创建用于Ollama的异步LLM回调实例
        
        Args:
            base_url: Ollama API基础URL
            model: Ollama模型名称
            **kwargs: 其他参数
            
        Returns:
            AsyncLLMCallback: 配置好的Ollama异步LLM回调实例
        """
        return cls(
            api_key="ollama",  # Ollama不需要真实API密钥
            base_url=base_url,
            model=model,
            use_langchain=False,
            **kwargs
        )


# 便捷函数
async def async_llm_callback(prompt: str, 
                           api_key: Optional[str] = None,
                           base_url: Optional[str] = None,
                           model: Optional[str] = None,
                           use_langchain: bool = False,
                           **kwargs) -> str:
    """便捷函数：异步LLM回调
    
    Args:
        prompt: 提示词
        api_key: API密钥
        base_url: API基础URL
        model: 模型名称
        use_langchain: 是否使用LangChain
        **kwargs: 其他参数
        
    Returns:
        str: LLM的回复
    """
    callback = AsyncLLMCallback(
        api_key=api_key,
        base_url=base_url,
        model=model,
        use_langchain=use_langchain,
        **kwargs
    )
    return await callback(prompt)


def get_default_llm_callback(use_langchain: bool = False, **kwargs) -> Callable:
    """获取默认的LLM回调函数（同步包装异步）
    
    Args:
        use_langchain: 是否使用LangChain
        **kwargs: 其他参数
        
    Returns:
        Callable: LLM回调函数
    """
    callback = AsyncLLMCallback.create_from_env(use_langchain=use_langchain, **kwargs)
    
    def sync_wrapper(prompt: str, **inner_kwargs) -> str:
        """同步包装器"""
        return asyncio.run(callback(prompt, **inner_kwargs))
    
    return sync_wrapper
