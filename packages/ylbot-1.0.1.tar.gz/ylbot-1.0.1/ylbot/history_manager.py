import json
import datetime
import asyncio
from typing import List, Dict, Optional, Any
from .config import Config
from .redis_utils import get_redis_manager


class HistoryManager:
    """历史记录管理器，负责管理聊天历史记录，使用Redis存储"""
    
    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config()
        self.redis_manager = None
    
    async def _get_redis_manager(self):
        """获取Redis管理器"""
        if self.redis_manager is None:
            self.redis_manager = await get_redis_manager(self.config)
        return self.redis_manager
    
    def get_history_key(self, source_id: str, user_id: str) -> str:
        """生成历史记录键"""
        return f"history:{source_id}:{user_id}"
    
    async def add_record(self, source_id: str, user_id: str, user: str, content: str, 
                   time: Optional[str] = None) -> bool:
        """添加一条历史记录
        
        Args:
            source_id: 来源ID
            user_id: 用户ID
            user: 用户名
            content: 消息内容
            time: 时间字符串，格式为"YYYY-MM-DD HH:MM:SS"，如果为None则使用当前时间
            
        Returns:
            bool: 是否成功添加
        """
        # 公平算法：检查单条大小限制
        if self.config.HISTORY_ALGORITHM == "fair" and len(content) > self.config.MAX_SINGLE_CHAR:
            return False
        
        # 创建记录
        record_time = time or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        record = {
            "user": user,
            "content": content,
            "time": record_time
        }
        
        redis_manager = await self._get_redis_manager()
        key = self.get_history_key(source_id, user_id)
        
        # 获取当前历史记录
        history = await redis_manager.get_json(key)
        if history is None:
            history = []
        
        # 公平算法：检查条数限制，如果超过则删除最早的一条
        if self.config.HISTORY_ALGORITHM == "fair" and len(history) >= self.config.MAX_USER_RECORD_COUNT:
            # 按时间升序排序，删除最早的一条
            history.sort(key=lambda x: x.get("time", ""))
            history.pop(0)
        
        # 添加新记录
        history.append(record)
        
        # 保存回Redis，设置过期时间（例如30天）
        expire_seconds = 30 * 24 * 3600  # 30天
        success = await redis_manager.set_json(key, history, expire=expire_seconds)
        
        return success
    
    async def get_history(self, source_id: str, user_id: str, bot_nick_name: str, 
                   question: str, method: str = "private") -> List[Dict]:
        """获取构建好的历史记录，包括系统提示和当前问题
        
        Args:
            source_id: 来源ID
            user_id: 用户ID
            bot_nick_name: 机器人昵称
            question: 当前问题
            method: 聊天类型，private/group_at/group
            
        Returns:
            List[Dict]: 构建好的历史记录
        """
        redis_manager = await self._get_redis_manager()
        key = self.get_history_key(source_id, user_id)
        
        # 从Redis获取历史记录
        history = await redis_manager.get_json(key)
        if history is None:
            history = []
        
        # 如果没有历史记录，则创建空列表
        if not history:
            # 添加系统提示
            system_time = (datetime.datetime.now() - datetime.timedelta(seconds=1)).strftime("%Y-%m-%d %H:%M:%S")
            history.append({
                "user": "system",
                "content": f"我的名字叫{bot_nick_name}，有什么可以帮您",
                "time": system_time
            })
        else:
            # 有历史记录时，添加系统提示到历史记录最早时间减1秒
            # 找到最早的时间
            earliest_time = min([record.get("time", "") for record in history if record.get("time")])
            # 转换为datetime，减1秒，再格式化
            try:
                earliest_dt = datetime.datetime.strptime(earliest_time, "%Y-%m-%d %H:%M:%S")
                system_time = (earliest_dt - datetime.timedelta(seconds=1)).strftime("%Y-%m-%d %H:%M:%S")
            except:
                system_time = (datetime.datetime.now() - datetime.timedelta(seconds=1)).strftime("%Y-%m-%d %H:%M:%S")
            
            # 插入系统提示到历史记录开头
            history.insert(0, {
                "user": "system",
                "content": f"我的名字叫{bot_nick_name}，有什么可以帮您",
                "time": system_time
            })
        
        # 添加当前用户问题（如果还没有添加）
        # 检查最后一条是否已经是当前用户的问题
        last_record = history[-1] if history else None
        if not last_record or last_record.get("content") != question or last_record.get("user") != user_id:
            history.append({
                "user": user_id,
                "content": question,
                "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
        
        # 按时间升序排序
        history.sort(key=lambda x: x.get("time", ""))
        
        # 总体大小限制检查
        total_chars = sum(len(record.get("content", "")) for record in history)
        
        if self.config.HISTORY_ALGORITHM == "normal":
            # 普通算法：删除时间最晚的记录直到满足大小限制
            while total_chars > self.config.MAX_HISTORY_CONTENT_CHAR and len(history) > 1:
                # 去掉时间最晚的一条记录（排除系统提示）
                non_system_records = [record for record in history if record.get("user") != "system"]
                if non_system_records:
                    # 按时间降序排序
                    non_system_records.sort(key=lambda x: x.get("time", ""), reverse=True)
                    # 删除时间最晚的一条
                    record_to_remove = non_system_records[0]
                    history.remove(record_to_remove)
                    total_chars = sum(len(record.get("content", "")) for record in history)
                else:
                    break
        else:
            # 公平算法：对每个用户的记录分别计算字符数，超过限制时删除该用户最早的记录
            user_char_counts = {}
            user_records = {}
            
            # 按用户分组统计
            for record in history:
                user = record.get("user")
                if user == "system":
                    continue  # 跳过系统提示
                if user not in user_char_counts:
                    user_char_counts[user] = 0
                    user_records[user] = []
                user_char_counts[user] += len(record.get("content", ""))
                user_records[user].append(record)
            
            # 如果总字符数超过限制，需要调整
            while total_chars > self.config.MAX_HISTORY_CONTENT_CHAR and len(history) > 1:
                # 找到所有用户的记录，按用户字符数排序
                users_with_records = [user for user in user_char_counts.keys() if user_char_counts[user] > 0]
                
                if not users_with_records:
                    break
                
                # 找到有最多字符数的用户
                max_user = max(users_with_records, key=lambda u: user_char_counts[u])
                
                # 删除该用户最早的记录
                if max_user in user_records and user_records[max_user]:
                    # 按时间升序排序，删除最早的一条
                    user_records[max_user].sort(key=lambda x: x.get("time", ""))
                    record_to_remove = user_records[max_user][0]
                    history.remove(record_to_remove)
                    user_records[max_user].remove(record_to_remove)
                    
                    # 更新统计
                    removed_chars = len(record_to_remove.get("content", ""))
                    user_char_counts[max_user] -= removed_chars
                    total_chars -= removed_chars
        
        return history
    
    async def clear_old_records(self, days: Optional[int] = None):
        """清理旧记录
        
        Args:
            days: 清理多少天前的记录，如果为None则使用配置中的CLEAR_CYCLE
        """
        days = days or self.config.CLEAR_CYCLE
        cutoff_time = datetime.datetime.now() - datetime.timedelta(days=days)
        cutoff_str = cutoff_time.strftime("%Y-%m-%d %H:%M:%S")
        
        redis_manager = await self._get_redis_manager()
        # 获取所有历史记录键
        keys = await redis_manager.keys("history:*")
        
        for key in keys:
            history = await redis_manager.get_json(key)
            if history is None:
                continue
            
            # 过滤掉时间早于cutoff_str的记录
            new_history = [
                record for record in history 
                if record.get("time", "0000-00-00 00:00:00") > cutoff_str
            ]
            
            if len(new_history) == 0:
                await redis_manager.delete(key)
            else:
                # 保留相同的过期时间
                await redis_manager.set_json(key, new_history)
    
    async def format_history_for_prompt(self, history: List[Dict]) -> str:
        """将历史记录格式化为prompt字符串
        
        Args:
            history: 历史记录列表
            
        Returns:
            str: 格式化后的历史记录字符串
        """
        history_json = json.dumps(history, ensure_ascii=False, indent=2)
        return history_json
    
    async def close(self):
        """关闭历史记录管理器"""
        if self.redis_manager:
            await self.redis_manager.close()
            self.redis_manager = None
