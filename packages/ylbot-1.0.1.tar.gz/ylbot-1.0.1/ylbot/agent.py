"""
Agent模块：支持流式输出和工具调用的异步Agent
参考main_agent_async.py实现，但集成到ylbot包中
"""

import asyncio
import inspect
import logging
import re
from typing import List, Dict, Any, Optional, AsyncGenerator, Union, Callable
import os

logger = logging.getLogger(__name__)

def is_simple_repetition(thought: str, question: str) -> bool:
    """判断思考内容是否只是简单重复用户问题"""
    if not thought or not question:
        return False
    
    # 去除标点、空格、换行、表情符号等
    def clean_text(text: str) -> str:
        # 移除所有非文字字符（保留中文和字母数字）
        text = re.sub(r'[^\w\u4e00-\u9fff]', '', text)
        return text.lower()
    
    thought_clean = clean_text(thought)
    question_clean = clean_text(question)
    
    # 只判断完全相等，不判断包含关系，避免误判答案
    return thought_clean == question_clean

class AsyncAgent:
    """异步Agent，支持流式输出和工具调用"""
    
    def __init__(self, 
                 llm_callback: Optional[Callable] = None,
                 tools: Optional[List[Callable]] = None,
                 use_langchain: bool = True,
                 streaming: bool = True,
                 max_steps: int = 20):
        """
        初始化异步Agent
        
        Args:
            llm_callback: LLM回调函数，如果为None则使用默认的LangChain ChatOpenAI
            tools: 工具函数列表，如果为None则自动加载tools模块中的函数
            use_langchain: 是否使用LangChain（如果为False，则使用简单的LLM调用）
            streaming: 是否使用流式输出
            max_steps: Agent最大执行步骤数
        """
        self.llm_callback = llm_callback
        self.tools = tools
        self.use_langchain = use_langchain
        self.streaming = streaming
        self.max_steps = max_steps
        
        # 动态加载工具
        self._available_tools = []
        
    async def load_tools(self):
        """异步加载工具"""
        if self.tools is not None:
            self._available_tools = self.tools
        else:
            try:
                # 首先尝试从当前包的tools模块加载
                from . import tools as tools_module
                tools_list = []
                for name, obj in inspect.getmembers(tools_module):
                    if inspect.isfunction(obj) and not name.startswith('_'):
                        tools_list.append(obj)
                self._available_tools = tools_list
                
                logger.info(f"✅ 从ylbot.tools模块动态加载了 {len(self._available_tools)} 个工具：")
                for tool in self._available_tools:
                    logger.info(f"  - {tool.__name__}")
                    
            except ImportError as e:
                logger.warning(f"未找到ylbot.tools模块: {e}，将使用内置工具")
                # 如果没有外部tools模块，使用内置工具
                self._available_tools = self._get_builtin_tools()
    
    def _get_builtin_tools(self) -> List[Callable]:
        """获取内置工具"""
        from datetime import datetime
        import asyncio
        
        async def get_current_datetime() -> str:
            """获取当前系统日期和时间"""
            await asyncio.sleep(0.001)
            return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        async def calculator(expression: str) -> str:
            """计算数学表达式"""
            try:
                await asyncio.sleep(0.001)
                result = eval(expression, {"__builtins__": {}})
                return str(result)
            except (SyntaxError, NameError, TypeError):
                return (
                    f"表达式格式错误：'{expression}'\n"
                    "请使用正确的数学表达式格式。\n"
                    "示例：\n"
                    "  - 加法：'2 + 3'\n"
                    "  - 减法：'10 - 5'\n"
                    "  - 乘法：'4 * 6'\n"
                    "  - 除法：'20 / 4'"
                )
            except ZeroDivisionError:
                return "错误：不能除以零"
            except Exception as e:
                return f"计算错误：{str(e)}"
        
        return [get_current_datetime, calculator]
    
    async def _run_with_langchain(self, 
                                 question: str, 
                                 history_json: str,
                                 bot_nick_name: str = "助手",
                                 source: str = "web") -> AsyncGenerator[str, None]:
        """使用LangChain运行Agent（支持流式输出）"""
        try:
            from langchain_openai import ChatOpenAI
            from langchain.agents import create_agent
        except ImportError:
            raise ImportError(
                "未安装langchain-openai包，请运行: pip install langchain-openai\n"
                "或设置use_langchain=False使用简单模式"
            )
        
        # 构建系统提示
        enhanced_system_prompt = f"""你是一个使用 ReAct（推理+行动）模式的助理。
对于每个问题：

1. 结合历史记录上下文，理解用户的用意，尤其是用户问题表达不完整时
2. 先思考（Thought）：分析问题需要什么工具
   - 注意：在思考步骤中，不要简单重复用户的问题，而是直接进行分析。
   - 例如，用户问"1+1=？"，你的思考应该是"这是一个简单的加法运算，可以使用计算器工具"，而不是重复"1+1=？"。
3. 再行动（Action）：调用合适的工具
4. 观察（Observation）：查看工具返回结果
5. 如果一般的闲聊问题，不需要使用工具，直接回答即可

- 你可以重复以上过程，直到能回答问题
- 如果使用工具仍然得不到结果，请用你的知识作为工具的参数
- 如果问题不需要工具，直接回答即可。

你将拥有一个包含了用户昵称、内容、时间的 JSON 列表，以时间进行了升序排列，当前用户问题是最后一个记录

## 历史记录
{history_json}
"""
        
        # 创建LLM模型
        api_key = os.getenv("LLM_API_KEY", "ollama")
        base_url = os.getenv("LLM_BASE_URL", "http://localhost:11434/v1")
        model = os.getenv("LLM_MODEL", "gpt-3.5-turbo")
        
        llm = ChatOpenAI(
            model=model,
            api_key=api_key,
            base_url=base_url,
            streaming=self.streaming
        )
        
        # 创建agent
        agent = create_agent(
            model=llm,
            tools=self._available_tools,
            system_prompt=enhanced_system_prompt,
        )
        
        # 执行agent
        if source == "onebot":
            # onebot模式：显示完整的Thought/Action/Observation过程
            logger.info("🤖 开始Agent推理过程（显示Thought / Action / Observation）...")
            step_count = 0
            final_answer = ""
            
            async for chunk in agent.astream(
                {"messages": [{"role": "user", "content": question}]},
                stream_mode="values"
            ):
                step_count += 1
                if step_count > self.max_steps:
                    logger.warning("⚠️ 达到最大步骤限制，强制结束agent")
                    yield '\n⚠️ 达到最大步骤限制，强制结束agent\n'
                    yield '[END]'
                    return
                
                msg = chunk["messages"][-1]

                # 工具调用
                if getattr(msg, "tool_calls", None):
                    for tc in msg.tool_calls:
                        logger.info(f"🔧 执行工具: 【{tc['name']}({tc['args']})】")
                        # 添加换行符，确保每个工具调用单独一行
                        yield f"🔧 我需要使用工具: {tc['name']}({tc['args']})😊\n".replace("Thought", "\n思考").replace("Action", "\n使用工具").replace("Observation", "\n🔍 观察结果")
                    continue

                # 工具返回值
                if getattr(msg, "type", None) == "tool":
                    logger.info(f"📤 工具执行结果: {msg.content}")
                    # 添加换行符，确保每个工具结果单独一行
                    yield f"📤 执行工具结果: {msg.content}😊\n".replace("Thought", "\n思考").replace("Action", "\n使用工具").replace("Observation", "\n🔍 观察结果")
                    continue

                # 思考步骤（LLM reasoning）
                if msg.content:
                    logger.info(f"💭 思考过程: {msg.content}")
                    msg_content_clean = msg.content.replace("Thought", "\n思考").replace("Action", "\n使用工具").replace("Observation", "\n🔍 观察结果")
                    # 过滤简单重复用户问题的思考过程
                    if not is_simple_repetition(msg.content, question):
                        # 添加换行符，确保思考过程单独一行
                        yield msg_content_clean + "😊\n"
                    final_answer = msg_content_clean
            
            if final_answer:
                yield f'[END]'
                
        else:
            # web模式：只显示最终答案（流式输出token）
            logger.info("💬 开始生成回答（流式输出）...")
            final_answer = ""
            
            async for chunk, meta in agent.astream(
                {"messages": [{"role": "user", "content": question}]},
                stream_mode="messages"
            ):
                token = getattr(chunk, "content", "").replace("Thought", "\n思考").replace("Action", "\n使用工具").replace("Observation", "\n🔍 观察结果")
                if token:
                    yield token
                    final_answer += token
            
            if final_answer:
                logger.info(f"✅ 最终回答：\n{final_answer}")
    
    async def _run_without_langchain(self,
                                    question: str,
                                    history_json: str,
                                    bot_nick_name: str = "助手",
                                    source: str = "web") -> AsyncGenerator[str, None]:
        """不使用LangChain的简单模式（直接调用LLM）"""
        if self.llm_callback is None:
            raise ValueError("未提供llm_callback，无法执行简单模式")
        
        # 构建提示
        prompt = f'''你将拥有一个包含了用户昵称、内容、时间的 JSON 列表，以时间进行了升序排列，当前用户问题**{question}**是最后一个记录

## 历史记录
{history_json}

请根据历史记录回答用户的问题：{question}'''
        
        # 调用LLM回调
        result = self.llm_callback(prompt)
        
        if inspect.isawaitable(result):
            answer = await result
        else:
            answer = result
        
        # 流式输出（模拟逐字符输出）
        if source == "web" and self.streaming:
            for char in answer:
                yield char
                await asyncio.sleep(0.01)  # 模拟延迟
        else:
            yield answer
    
    async def run(self,
                  question: str,
                  history_json: str,
                  bot_nick_name: str = "助手",
                  source: str = "web") -> AsyncGenerator[str, None]:
        """
        运行Agent
        
        Args:
            question: 用户问题
            history_json: 历史记录JSON字符串
            bot_nick_name: 机器人昵称
            source: 来源类型，web或onebot
            
        Returns:
            AsyncGenerator[str, None]: 流式输出的生成器
        """
        # 确保工具已加载
        if not self._available_tools:
            await self.load_tools()
        
        if self.use_langchain:
            async for token in self._run_with_langchain(question, history_json, bot_nick_name, source):
                yield token
        else:
            async for token in self._run_without_langchain(question, history_json, bot_nick_name, source):
                yield token

# 便捷函数
async def create_agent(llm_callback: Optional[Callable] = None,
                       tools: Optional[List[Callable]] = None,
                       use_langchain: bool = True,
                       streaming: bool = True,
                       max_steps: int = 20) -> AsyncAgent:
    """创建异步Agent实例"""
    agent = AsyncAgent(
        llm_callback=llm_callback,
        tools=tools,
        use_langchain=use_langchain,
        streaming=streaming,
        max_steps=max_steps
    )
    await agent.load_tools()
    return agent
