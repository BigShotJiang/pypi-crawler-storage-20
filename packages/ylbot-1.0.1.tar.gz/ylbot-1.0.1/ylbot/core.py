import time
import json
import asyncio
import inspect
from typing import Dict, List, Optional, Callable, Any, AsyncGenerator
from .history_manager import HistoryManager
from .status_manager import StatusManager
from .response_builder import ResponseBuilder
from .config import Config

class YLBot:
    """ylbot核心类，整合历史记录管理、状态管理和回复构建"""
    
    def __init__(self, config: Optional[Config] = None,
                 llm_callback: Optional[Callable] = None):
        """
        初始化ylbot
        
        Args:
            config: 配置对象
            llm_callback: LLM回调函数，用于调用语言模型
        """
        self.config = config or Config()
        self.history_manager = HistoryManager(self.config)
        self.status_manager = StatusManager(self.config)
        self.response_builder = ResponseBuilder(self.config)
        
        if llm_callback is None:
            # 使用默认的异步LLM回调，基于环境变量配置
            try:
                # 首先检查并安装必要的依赖
                from .deps import check_and_install_specific
                # 检查LLM相关依赖
                llm_deps_ok = check_and_install_specific(
                    ["openai", "langchain-openai"],
                    use_mirror=True
                )
                
                if not llm_deps_ok:
                    print("⚠️ LLM依赖检查/安装失败，尝试继续运行...")
                
                from .llm_callback import AsyncLLMCallback
                self.llm_callback = AsyncLLMCallback.create_from_env()
                
            except ImportError as e:
                # 如果导入失败，尝试自动安装
                print(f"⚠️ 导入错误: {e}")
                print("正在尝试自动安装依赖...")
                
                import subprocess
                import sys
                
                try:
                    # 尝试从requirements.txt安装
                    subprocess.run([
                        sys.executable, "-m", "pip", "install", "-r", "requirements.txt",
                        "-i", "https://pypi.tuna.tsinghua.edu.cn/simple"
                    ], check=False)
                    
                    # 重新尝试导入
                    from .llm_callback import AsyncLLMCallback
                    self.llm_callback = AsyncLLMCallback.create_from_env()
                    print("✅ 依赖安装成功，已创建LLM回调")
                    
                except Exception as install_error:
                    raise ImportError(
                        f"无法安装或导入依赖: {install_error}\n"
                        "请手动运行: pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple\n"
                        "或提供自定义的llm_callback"
                    ) from install_error
        else:
            self.llm_callback = llm_callback
    
    async def process_query(self, query_message: Dict) -> Dict:
        """处理用户查询
        
        Args:
            query_message: 查询消息，符合接口规范
            
        Returns:
            Dict: 回复消息
        """
        # 提取必要信息
        source_id = query_message.get("source_id")
        user_id = query_message.get("from_user", {}).get("user_id")
        bot_nick_name = query_message.get("bot", {}).get("bot_nick_name", "机器人")
        method = query_message.get("method")
        must_answer = query_message.get("must_answer", "no")
        
        # 检查用户状态
        if await self.status_manager.is_user_busy(source_id, user_id):
            return await self._build_busy_response(query_message)
        
        # 设置用户为忙碌状态
        await self.status_manager.set_llm_status(source_id, user_id, "busy")
        
        try:
            # 处理消息列表，提取文本内容
            question = await self._extract_question_from_message(query_message.get("message", []))
            
            # 保存用户问题到历史记录
            await self.history_manager.add_record(
                source_id=source_id,
                user_id=user_id,
                user=query_message.get("from_user", {}).get("user_nick_name", "用户"),
                content=question
            )
            
            # 获取历史记录
            history = await self.history_manager.get_history(
                source_id=source_id,
                user_id=user_id,
                bot_nick_name=bot_nick_name,
                question=question,
                method=method
            )
            
            # 格式化历史记录为prompt
            history_json = await self.history_manager.format_history_for_prompt(history)
            
            # 构建prompt
            prompt = f'''你将拥有一个包含了用户昵称、内容、时间的 JSON 列表，以时间进行了升序排列，当前用户问题**{question}**是最后一个记录

## 历史记录
{history_json}
...'''
            
            # 调用LLM - 健壮的处理方式
            if not callable(self.llm_callback):
                raise ValueError("llm_callback must be callable")
            
            # 调用回调函数
            result = self.llm_callback(prompt)
            
            # 检查结果是否为可等待对象（协程、Future等）
            if inspect.isawaitable(result):
                answer = await result
            else:
                answer = result
            
            # 确保answer是字符串
            if not isinstance(answer, str):
                raise TypeError(f"LLM callback should return str, got {type(answer).__name__}")
            
            # 保存AI回复到历史记录
            await self.history_manager.add_record(
                source_id=source_id,
                user_id=user_id,
                user=bot_nick_name,
                content=answer
            )
            
            # 构建回复消息
            to_users = [query_message.get("from_user", {})]
            messages = await self.response_builder.build_messages_from_answer(answer)
            
            response_message = await self.response_builder.build_response_message(
                query_message=query_message,
                to_users=to_users,
                messages=messages,
                answer=answer
            )
            
            # 格式化回复（添加@前缀等）
            formatted_answer = await self.response_builder.format_answer_for_chat(response_message, answer)
            response_message["answer"] = formatted_answer
            if messages and messages[0]["type"] == "text":
                messages[0]["data"]["text"] = formatted_answer
            
            return response_message
            
        finally:
            # 设置用户为空闲状态
            await self.status_manager.set_llm_status(source_id, user_id, "free")
    
    async def _extract_question_from_message(self, message_list: List[Dict]) -> str:
        """从消息列表中提取文本内容
        
        Args:
            message_list: 消息列表
            
        Returns:
            str: 提取的文本内容
        """
        texts = []
        for msg in message_list:
            msg_type = msg.get("type")
            if msg_type == "text":
                texts.append(msg.get("data", {}).get("text", ""))
            elif msg_type == "image":
                texts.append("[图片]")
            elif msg_type == "voice":
                texts.append("[语音]")
            elif msg_type == "video":
                texts.append("[视频]")
        
        return " ".join(texts)
    
    async def _build_busy_response(self, query_message: Dict) -> Dict:
        """构建忙碌响应
        
        Args:
            query_message: 查询消息
            
        Returns:
            Dict: 忙碌响应消息
        """
        answer = "你的问题还在处理中，请稍候..."
        to_users = [query_message.get("from_user", {})]
        messages = await self.response_builder.build_messages_from_answer(answer)
        
        response_message = await self.response_builder.build_response_message(
            query_message=query_message,
            to_users=to_users,
            messages=messages,
            answer=answer
        )
        
        return response_message
    
    async def clear_old_history(self, days: Optional[int] = None):
        """清理旧的历史记录
        
        Args:
            days: 清理多少天前的记录，如果为None则使用配置中的CLEAR_CYCLE
        """
        await self.history_manager.clear_old_records(days)
    
    async def cleanup_inactive_status(self, inactive_seconds: Optional[int] = None):
        """清理不活跃的用户状态
        
        Args:
            inactive_seconds: 不活跃的秒数阈值，如果为None则使用配置中的STATUS_CLEANUP_INTERVAL
        """
        await self.status_manager.cleanup_inactive_users(inactive_seconds)
    
    async def process_query_stream(self, 
                                   query_message: Dict,
                                   source: str = "web",
                                   use_agent: bool = False,
                                   agent_tools: Optional[List[Callable]] = None) -> AsyncGenerator[str, None]:
        """处理用户查询（流式输出）
        
        Args:
            query_message: 查询消息，符合接口规范
            source: 来源类型，web或onebot，影响输出格式
            use_agent: 是否使用Agent（工具调用）
            agent_tools: 自定义工具列表，如果为None则使用默认工具
            
        Returns:
            AsyncGenerator[str, None]: 流式输出的生成器
        """
        # 提取必要信息
        source_id = query_message.get("source_id")
        user_id = query_message.get("from_user", {}).get("user_id")
        bot_nick_name = query_message.get("bot", {}).get("bot_nick_name", "机器人")
        method = query_message.get("method")
        
        # 检查用户状态
        if await self.status_manager.is_user_busy(source_id, user_id):
            yield "你的问题还在处理中，请稍候..."
            return
        
        # 设置用户为忙碌状态
        await self.status_manager.set_llm_status(source_id, user_id, "busy")
        
        try:
            # 处理消息列表，提取文本内容
            question = await self._extract_question_from_message(query_message.get("message", []))
            
            # 保存用户问题到历史记录
            await self.history_manager.add_record(
                source_id=source_id,
                user_id=user_id,
                user=query_message.get("from_user", {}).get("user_nick_name", "用户"),
                content=question
            )
            
            # 获取历史记录
            history = await self.history_manager.get_history(
                source_id=source_id,
                user_id=user_id,
                bot_nick_name=bot_nick_name,
                question=question,
                method=method
            )
            
            # 格式化历史记录为prompt
            history_json = await self.history_manager.format_history_for_prompt(history)
            
            final_answer = ""
            
            if use_agent:
                # 使用Agent（支持工具调用）
                from .agent import create_agent
                
                # 创建Agent
                agent = await create_agent(
                    llm_callback=self.llm_callback,
                    tools=agent_tools,
                    use_langchain=True,
                    streaming=True,
                    max_steps=20
                )
                
                # 运行Agent
                async for token in agent.run(
                    question=question,
                    history_json=history_json,
                    bot_nick_name=bot_nick_name,
                    source=source
                ):
                    yield token
                    # 累积最终答案（排除控制标记）
                    if token not in ["[END]", "[FINAL]"]:
                        final_answer += token
                
            else:
                # 直接使用LLM回调（流式输出）
                if not callable(self.llm_callback):
                    raise ValueError("llm_callback must be callable")
                
                # 构建prompt
                prompt = f'''你将拥有一个包含了用户昵称、内容、时间的 JSON 列表，以时间进行了升序排列，当前用户问题**{question}**是最后一个记录

## 历史记录
{history_json}

请根据历史记录回答用户的问题：{question}'''
                
                # 检查llm_callback是否支持流式输出
                # 对于AsyncLLMCallback，如果streaming=True，它会返回流式响应
                # 我们需要调用它并处理结果
                
                # 调用回调函数
                result = self.llm_callback(prompt)
                
                # 检查结果是否为可等待对象（协程、Future等）
                if inspect.isawaitable(result):
                    answer = await result
                else:
                    answer = result
                
                # 确保answer是字符串
                if not isinstance(answer, str):
                    raise TypeError(f"LLM callback should return str, got {type(answer).__name__}")
                
                # 流式输出（模拟逐字符输出）
                if source == "web":
                    for char in answer:
                        yield char
                        await asyncio.sleep(0.01)  # 模拟延迟
                    final_answer = answer
                else:
                    yield answer
                    final_answer = answer
            
            # 保存AI回复到历史记录
            if final_answer and not final_answer.startswith("[END]"):
                await self.history_manager.add_record(
                    source_id=source_id,
                    user_id=user_id,
                    user=bot_nick_name,
                    content=final_answer
                )
            
        finally:
            # 设置用户为空闲状态
            await self.status_manager.set_llm_status(source_id, user_id, "free")
    
    async def close(self):
        """关闭机器人，清理所有资源"""
        if hasattr(self, 'history_manager') and hasattr(self.history_manager, 'close'):
            await self.history_manager.close()
        
        if hasattr(self, 'status_manager') and hasattr(self.status_manager, 'close'):
            await self.status_manager.close()
        
        if hasattr(self, 'response_builder') and hasattr(self.response_builder, 'close'):
            await self.response_builder.close()
        
        # 关闭Redis管理器
        from .redis_utils import close_redis_manager
        await close_redis_manager()
