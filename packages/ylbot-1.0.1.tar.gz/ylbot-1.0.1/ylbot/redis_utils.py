"""
Redis工具模块，提供异步Redis连接和基本操作
"""

import json
import asyncio
from typing import Optional, Any, Dict, List
import redis.asyncio as redis
from .config import Config


class RedisManager:
    """Redis管理器，提供异步Redis操作"""
    
    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config()
        self.redis_url = self.config.REDIS_URL
        self._client: Optional[redis.Redis] = None
        self._lock = asyncio.Lock()
    
    async def get_client(self) -> redis.Redis:
        """获取Redis客户端（单例）"""
        async with self._lock:
            if self._client is None:
                if not self.redis_url:
                    raise ValueError("REDIS_URL未配置，请在环境变量或Config中设置")
                
                # 解析Redis URL
                self._client = redis.from_url(
                    self.redis_url,
                    encoding="utf-8",
                    decode_responses=True
                )
                # 测试连接
                try:
                    await self._client.ping()
                    print(f"Redis连接成功: {self.redis_url}")
                except Exception as e:
                    self._client = None
                    raise ConnectionError(f"Redis连接失败: {e}")
            
            return self._client
    
    async def set_json(self, key: str, value: Any, expire: Optional[int] = None) -> bool:
        """设置JSON值
        
        Args:
            key: Redis键
            value: 要存储的值（可JSON序列化）
            expire: 过期时间（秒）
            
        Returns:
            bool: 是否成功
        """
        client = await self.get_client()
        try:
            json_value = json.dumps(value, ensure_ascii=False)
            if expire:
                await client.setex(key, expire, json_value)
            else:
                await client.set(key, json_value)
            return True
        except Exception as e:
            print(f"Redis set_json失败: {e}")
            return False
    
    async def get_json(self, key: str) -> Optional[Any]:
        """获取JSON值
        
        Args:
            key: Redis键
            
        Returns:
            Any: 解析后的JSON值，如果键不存在返回None
        """
        client = await self.get_client()
        try:
            value = await client.get(key)
            if value is None:
                return None
            return json.loads(value)
        except Exception as e:
            print(f"Redis get_json失败: {e}")
            return None
    
    async def delete(self, key: str) -> bool:
        """删除键
        
        Args:
            key: Redis键
            
        Returns:
            bool: 是否成功
        """
        client = await self.get_client()
        try:
            result = await client.delete(key)
            return result > 0
        except Exception as e:
            print(f"Redis delete失败: {e}")
            return False
    
    async def exists(self, key: str) -> bool:
        """检查键是否存在
        
        Args:
            key: Redis键
            
        Returns:
            bool: 是否存在
        """
        client = await self.get_client()
        try:
            result = await client.exists(key)
            return result > 0
        except Exception as e:
            print(f"Redis exists失败: {e}")
            return False
    
    async def expire(self, key: str, seconds: int) -> bool:
        """设置键的过期时间
        
        Args:
            key: Redis键
            seconds: 过期时间（秒）
            
        Returns:
            bool: 是否成功
        """
        client = await self.get_client()
        try:
            result = await client.expire(key, seconds)
            return result
        except Exception as e:
            print(f"Redis expire失败: {e}")
            return False
    
    async def keys(self, pattern: str = "*") -> List[str]:
        """获取匹配模式的键
        
        Args:
            pattern: 键模式
            
        Returns:
            List[str]: 匹配的键列表
        """
        client = await self.get_client()
        try:
            return await client.keys(pattern)
        except Exception as e:
            print(f"Redis keys失败: {e}")
            return []
    
    async def close(self):
        """关闭Redis连接"""
        async with self._lock:
            if self._client:
                await self._client.close()
                self._client = None
    
    async def __aenter__(self):
        await self.get_client()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()


# 全局Redis管理器实例
_global_redis_manager: Optional[RedisManager] = None


async def get_redis_manager(config: Optional[Config] = None) -> RedisManager:
    """获取全局Redis管理器实例
    
    Args:
        config: 配置对象
        
    Returns:
        RedisManager: Redis管理器实例
    """
    global _global_redis_manager
    
    if _global_redis_manager is None:
        _global_redis_manager = RedisManager(config)
    
    return _global_redis_manager


async def close_redis_manager():
    """关闭全局Redis管理器"""
    global _global_redis_manager
    
    if _global_redis_manager:
        await _global_redis_manager.close()
        _global_redis_manager = None
