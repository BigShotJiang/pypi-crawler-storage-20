"""
依赖管理模块：自动检查并安装缺失的依赖包
"""

import subprocess
import sys
import importlib
import pkgutil
import logging
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)

def ensure_dependencies(requirements_file: str = "requirements.txt", 
                       use_mirror: bool = True) -> bool:
    """
    确保所有依赖包已安装
    
    Args:
        requirements_file: requirements.txt文件路径
        use_mirror: 是否使用清华镜像源
    
    Returns:
        bool: 是否成功安装所有依赖
    """
    try:
        # 读取requirements.txt文件
        with open(requirements_file, 'r', encoding='utf-8') as f:
            requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        
        # 检查每个依赖
        missing_deps = []
        for req in requirements:
            # 解析包名（去除版本约束）
            pkg_name = req.split('==')[0].split('>=')[0].split('<=')[0].split('~=')[0].strip()
            if not is_package_installed(pkg_name):
                missing_deps.append(req)
        
        if not missing_deps:
            logger.info("✅ 所有依赖已安装")
            return True
        
        # 安装缺失的依赖
        logger.warning(f"发现 {len(missing_deps)} 个缺失的依赖包，正在安装...")
        success = install_requirements(missing_deps, use_mirror)
        
        if success:
            logger.info("✅ 依赖安装完成")
            # 重新导入模块
            for req in missing_deps:
                pkg_name = req.split('==')[0].split('>=')[0].split('<=')[0].split('~=')[0].strip()
                try:
                    importlib.import_module(pkg_name)
                except ImportError:
                    # 有些包名和模块名不一致，忽略
                    pass
        return success
        
    except FileNotFoundError:
        logger.error(f"❌ 未找到 {requirements_file} 文件")
        return False
    except Exception as e:
        logger.error(f"❌ 依赖检查失败: {e}")
        return False

def is_package_installed(package_name: str) -> bool:
    """
    检查包是否已安装
    
    Args:
        package_name: 包名
        
    Returns:
        bool: 是否已安装
    """
    try:
        # 尝试导入包
        spec = importlib.util.find_spec(package_name.replace('-', '_'))
        if spec is None:
            spec = importlib.util.find_spec(package_name.replace('_', '-'))
        
        if spec is None:
            # 对于一些特殊包名，尝试常见变体
            common_names = [
                package_name,
                package_name.replace('-', '_'),
                package_name.replace('_', '-'),
                package_name.lower(),
                package_name.replace('-', '').replace('_', '')
            ]
            
            for name in common_names:
                if pkgutil.find_loader(name) is not None:
                    return True
            return False
        return True
    except Exception:
        return False

def install_requirements(requirements: List[str], use_mirror: bool = True) -> bool:
    """
    安装指定的依赖包
    
    Args:
        requirements: 依赖包列表
        use_mirror: 是否使用清华镜像源
    
    Returns:
        bool: 安装是否成功
    """
    try:
        # 构建pip命令
        pip_cmd = [sys.executable, "-m", "pip", "install"]
        
        if use_mirror:
            pip_cmd.extend(["-i", "https://pypi.tuna.tsinghua.edu.cn/simple"])
        
        pip_cmd.extend(requirements)
        
        logger.info(f"执行命令: {' '.join(pip_cmd)}")
        
        # 执行安装
        result = subprocess.run(
            pip_cmd,
            capture_output=True,
            text=True,
            check=False
        )
        
        if result.returncode == 0:
            logger.info("✅ 依赖安装成功")
            if result.stdout:
                logger.debug(f"安装输出: {result.stdout}")
            return True
        else:
            logger.error(f"❌ 依赖安装失败")
            if result.stderr:
                logger.error(f"错误信息: {result.stderr}")
            return False
            
    except Exception as e:
        logger.error(f"❌ 安装过程中出现异常: {e}")
        return False

def check_and_install_specific(package_names: List[str], 
                              requirements_file: str = "requirements.txt",
                              use_mirror: bool = True) -> bool:
    """
    检查并安装特定包
    
    Args:
        package_names: 包名列表
        requirements_file: requirements.txt文件路径
        use_mirror: 是否使用镜像源
    
    Returns:
        bool: 是否所有包都可用
    """
    missing_packages = []
    
    for pkg_name in package_names:
        if not is_package_installed(pkg_name):
            missing_packages.append(pkg_name)
    
    if not missing_packages:
        return True
    
    # 从requirements.txt中找到对应的版本要求
    try:
        with open(requirements_file, 'r', encoding='utf-8') as f:
            all_reqs = [line.strip() for line in f if line.strip() and not line.startswith('#')]
        
        reqs_to_install = []
        for req in all_reqs:
            req_pkg = req.split('==')[0].split('>=')[0].split('<=')[0].split('~=')[0].strip()
            if req_pkg in missing_packages:
                reqs_to_install.append(req)
        
        if reqs_to_install:
            return install_requirements(reqs_to_install, use_mirror)
        else:
            # 如果在requirements.txt中找不到，直接安装包名
            return install_requirements(missing_packages, use_mirror)
            
    except FileNotFoundError:
        # 没有requirements.txt，直接安装包
        return install_requirements(missing_packages, use_mirror)
    except Exception as e:
        logger.error(f"❌ 检查特定包失败: {e}")
        return False

# 便捷函数
def ensure_llm_dependencies() -> bool:
    """确保LLM相关的依赖已安装"""
    return check_and_install_specific(
        ["openai", "langchain-openai"],
        use_mirror=True
    )

def ensure_redis_dependencies() -> bool:
    """确保Redis相关的依赖已安装"""
    return check_and_install_specific(["redis"], use_mirror=True)

def ensure_all_dependencies() -> bool:
    """确保所有依赖已安装"""
    return ensure_dependencies(use_mirror=True)

# 模块初始化时自动检查依赖
if __name__ != "__main__":
    # 当模块被导入时，尝试检查依赖
    try:
        # 只在开发环境或首次运行时检查
        import os
        if os.getenv("YLBOT_AUTO_INSTALL", "true").lower() == "true":
            logger.info("检查ylbot依赖...")
            # 这里不自动安装，由各个模块在需要时调用
    except Exception:
        pass
