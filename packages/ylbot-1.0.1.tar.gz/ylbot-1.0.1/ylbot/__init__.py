"""
ylbot - 基于标准规范的聊天机器人框架
"""

__version__ = "1.0.0"
__author__ = "ylbot Team"
__description__ = "一个遵循ylbot机器人标准的聊天机器人框架，支持历史记录管理、状态管理和多平台接口"

from .deps import (
    ensure_dependencies,
    ensure_llm_dependencies,
    ensure_redis_dependencies,
    ensure_all_dependencies,
    check_and_install_specific,
    is_package_installed
)

from .core import YLBot
from .history_manager import HistoryManager
from .status_manager import StatusManager
from .response_builder import ResponseBuilder
from .config import Config
from .llm_callback import AsyncLLMCallback, async_llm_callback, get_default_llm_callback
from .redis_utils import RedisManager, get_redis_manager, close_redis_manager
from .agent import AsyncAgent, create_agent

__all__ = [
    "YLBot",
    "HistoryManager", 
    "StatusManager",
    "ResponseBuilder",
    "Config",
    "AsyncLLMCallback",
    "async_llm_callback",
    "get_default_llm_callback",
    "RedisManager",
    "get_redis_manager",
    "close_redis_manager",
    "AsyncAgent",
    "create_agent",
    "ensure_dependencies",
    "ensure_llm_dependencies",
    "ensure_redis_dependencies",
    "ensure_all_dependencies",
    "check_and_install_specific",
    "is_package_installed"
]
