import time
import asyncio
from typing import Dict, Optional
from .config import Config
from .redis_utils import get_redis_manager


class StatusManager:
    """状态管理器，用于管理用户状态，使用Redis存储"""
    
    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config()
        self.redis_manager = None
        self._lock = asyncio.Lock()
        self._cleanup_task = None
        self._cleanup_started = False
        # 不立即启动清理任务，延迟到首次使用时
    
    async def _ensure_cleanup_task(self):
        """确保清理任务已启动"""
        if not self._cleanup_started:
            await self._start_cleanup_task()
    
    async def _start_cleanup_task(self):
        """启动清理任务"""
        if self._cleanup_started:
            return
        
        async def cleanup_worker():
            while True:
                await asyncio.sleep(self.config.STATUS_CLEANUP_INTERVAL)
                await self.cleanup_inactive_users()
        
        # 创建后台任务
        self._cleanup_task = asyncio.create_task(cleanup_worker())
        self._cleanup_started = True
    
    async def _get_redis_manager(self):
        """获取Redis管理器"""
        if self.redis_manager is None:
            self.redis_manager = await get_redis_manager(self.config)
            # 首次获取Redis管理器时启动清理任务
            await self._ensure_cleanup_task()
        return self.redis_manager
    
    def get_status_key(self, source_id: str, user_id: str) -> str:
        """生成状态键"""
        return f"status:{source_id}:{user_id}"
    
    async def get_user_status(self, source_id: str, user_id: str) -> Dict:
        """获取用户状态
        
        Args:
            source_id: 来源ID
            user_id: 用户ID
            
        Returns:
            Dict: 用户状态字典
        """
        key = self.get_status_key(source_id, user_id)
        redis_manager = await self._get_redis_manager()
        
        # 尝试从Redis获取状态
        status = await redis_manager.get_json(key)
        if status is None:
            # 默认状态
            status = {"llm_status": "free", "last_active": time.time()}
        
        # 更新最后活跃时间
        status["last_active"] = time.time()
        await self.set_user_status(source_id, user_id, status)
        
        return status
    
    async def set_user_status(self, source_id: str, user_id: str, status_data: Dict):
        """设置用户状态
        
        Args:
            source_id: 来源ID
            user_id: 用户ID
            status_data: 状态数据
        """
        key = self.get_status_key(source_id, user_id)
        redis_manager = await self._get_redis_manager()
        
        # 确保有最后活跃时间
        if "last_active" not in status_data:
            status_data["last_active"] = time.time()
        
        # 设置过期时间（例如7天）
        expire_seconds = 7 * 24 * 3600  # 7天
        await redis_manager.set_json(key, status_data, expire=expire_seconds)
    
    async def set_llm_status(self, source_id: str, user_id: str, status: str):
        """设置用户的LLM状态
        
        Args:
            source_id: 来源ID
            user_id: 用户ID
            status: 状态，取值为 "busy" 或 "free"
        """
        if status not in ["busy", "free"]:
            raise ValueError("状态必须为 'busy' 或 'free'")
        
        key = self.get_status_key(source_id, user_id)
        redis_manager = await self._get_redis_manager()
        
        # 获取当前状态
        current_status = await redis_manager.get_json(key)
        if current_status is None:
            current_status = {"last_active": time.time()}
        
        # 更新状态
        current_status["llm_status"] = status
        current_status["last_active"] = time.time()
        
        # 设置过期时间
        expire_seconds = 7 * 24 * 3600  # 7天
        await redis_manager.set_json(key, current_status, expire=expire_seconds)
    
    async def is_user_busy(self, source_id: str, user_id: str) -> bool:
        """检查用户是否忙碌
        
        Args:
            source_id: 来源ID
            user_id: 用户ID
            
        Returns:
            bool: 如果用户忙碌返回True，否则返回False
        """
        status = await self.get_user_status(source_id, user_id)
        return status.get("llm_status") == "busy"
    
    async def cleanup_inactive_users(self, inactive_seconds: Optional[int] = None):
        """清理不活跃的用户
        
        Args:
            inactive_seconds: 不活跃的秒数阈值，如果为None则使用配置中的STATUS_CLEANUP_INTERVAL
        """
        inactive_seconds = inactive_seconds or self.config.STATUS_CLEANUP_INTERVAL
        cutoff_time = time.time() - inactive_seconds
        
        redis_manager = await self._get_redis_manager()
        # 获取所有状态键
        keys = await redis_manager.keys("status:*")
        
        for key in keys:
            status = await redis_manager.get_json(key)
            if status is None:
                continue
                
            last_active = status.get("last_active", 0)
            if last_active < cutoff_time:
                await redis_manager.delete(key)
    
    async def close(self):
        """关闭状态管理器，清理资源"""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        
        if self.redis_manager:
            await self.redis_manager.close()
