import os
from dataclasses import dataclass
from typing import Optional

@dataclass
class Config:
    """配置类，用于管理ylbot的环境变量和常量"""
    
    # 历史记录相关配置
    MAX_SINGLE_CHAR: int = 1000  # 单条最大字符数
    MAX_USER_RECORD_COUNT: int = 50  # 每个user允许的最多条数
    MAX_HISTORY_CONTENT_CHAR: int = 4000  # 历史记录content字段允许的最大字符数之和
    CLEAR_CYCLE: int = 7  # 定期清理用户记录的周期，单位是天
    HISTORY_ALGORITHM: str = "normal"  # 历史记录算法: "fair" (公平算法) 或 "normal" (普通算法)
    
    # 状态管理相关配置
    STATUS_CLEANUP_INTERVAL: int = 3600  # 状态清理间隔，单位秒
    
    # 自动回复相关配置
    AUTO_ANSWER_TIMEOUT: int = 10  # 自动回复超时时间，单位秒
    
    # LLM相关配置
    LLM_API_KEY: Optional[str] = None
    LLM_BASE_URL: Optional[str] = None
    LLM_MODEL: str = "deepseek-chat"
    
    # 数据库配置
    REDIS_URL: Optional[str] = None
    DATABASE_URL: Optional[str] = None
    
    def __init__(self, **kwargs):
        """从环境变量初始化配置，可以覆盖默认值"""
        # 历史记录配置
        self.MAX_SINGLE_CHAR = int(os.getenv("MAX_SINGLE_CHAR", self.MAX_SINGLE_CHAR))
        self.MAX_USER_RECORD_COUNT = int(os.getenv("MAX_USER_RECORD_COUNT", self.MAX_USER_RECORD_COUNT))
        self.MAX_HISTORY_CONTENT_CHAR = int(os.getenv("MAX_HISTORY_CONTENT_CHAR", self.MAX_HISTORY_CONTENT_CHAR))
        self.CLEAR_CYCLE = int(os.getenv("CLEAR_CYCLE", self.CLEAR_CYCLE))
        self.HISTORY_ALGORITHM = os.getenv("HISTORY_ALGORITHM", self.HISTORY_ALGORITHM)
        
        # 状态管理配置
        self.STATUS_CLEANUP_INTERVAL = int(os.getenv("STATUS_CLEANUP_INTERVAL", self.STATUS_CLEANUP_INTERVAL))
        
        # 自动回复配置
        self.AUTO_ANSWER_TIMEOUT = int(os.getenv("AUTO_ANSWER_TIMEOUT", self.AUTO_ANSWER_TIMEOUT))
        
        # LLM配置
        self.LLM_API_KEY = os.getenv("LLM_API_KEY", self.LLM_API_KEY)
        self.LLM_BASE_URL = os.getenv("LLM_BASE_URL", self.LLM_BASE_URL)
        self.LLM_MODEL = os.getenv("LLM_MODEL", self.LLM_MODEL)
        
        # 数据库配置
        self.REDIS_URL = os.getenv("REDIS_URL", self.REDIS_URL)
        self.DATABASE_URL = os.getenv("DATABASE_URL", self.DATABASE_URL)
        
        # 覆盖传入的参数
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        
        # 验证HISTORY_ALGORITHM的有效性
        if self.HISTORY_ALGORITHM not in ["fair", "normal"]:
            raise ValueError(f"HISTORY_ALGORITHM must be 'fair' or 'normal', got '{self.HISTORY_ALGORITHM}'")
    
    @classmethod
    def from_env(cls) -> "Config":
        """从环境变量创建配置实例"""
        return cls()
