from datetime import datetime
import asyncio
import aiohttp


# 新版 langchain agent 的 tool 注释即为工具说明
# 所有工具都改为异步函数

# 1. 异步获取当前系统日期和时间
async def get_current_datetime() -> str:
    """获取当前系统日期和时间"""
    # 模拟异步操作，即使是很简单的操作也使用异步
    await asyncio.sleep(0.001)  # 最小延迟，保持异步特性
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# 2. 异步计算器工具（带错误提示）
async def calculator(expression: str) -> str:
    """计算数学表达式。
    
    Args:
        expression: 数学表达式，例如 "2 + 3" 或 "10 * 5"
        
    支持的运算符：+（加）、-（减）、*（乘）、/（除）
    """
    try:
        # 模拟异步计算
        await asyncio.sleep(0.001)  # 最小延迟，保持异步特性
        
        # 安全地评估表达式
        result = eval(expression, {"__builtins__": {}})
        return str(result)
    except (SyntaxError, NameError, TypeError):
        return (
            f"表达式格式错误：'{expression}'\n"
            "请使用正确的数学表达式格式。\n"
            "示例：\n"
            "  - 加法：'2 + 3'\n"
            "  - 减法：'10 - 5'\n"
            "  - 乘法：'4 * 6'\n"
            "  - 除法：'20 / 4'"
        )
    except ZeroDivisionError:
        return "错误：不能除以零"
    except Exception as e:
        return f"计算错误：{str(e)}"


# 3. 同城生活助手，提供供需匹配
async def get_city_live(query: str) -> str:
    '''同城生活助手，提供供需匹配。
    
    Args:
        query: 用户问题

    返回：匹配到的供求信息
    '''
    url = "http://www.aicity.wang:8002/api"
    data = {
        "content": query,
        "fromUser": "ylbot",
        "fromGroup": "ylbot", 
        "type": 1
    }
    
    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=data) as response:
            result_json = await response.json()
            result_str = result_json.get("answer")
            return result_str