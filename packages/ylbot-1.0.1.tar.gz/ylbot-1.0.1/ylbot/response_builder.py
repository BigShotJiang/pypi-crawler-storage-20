import re
from typing import List, Dict, Any, Optional
from .config import Config

class ResponseBuilder:
    """回复构建器，负责构建和格式化回复消息"""
    
    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config()
    
    async def build_response_message(self, query_message: Dict, to_users: List[Dict], 
                              messages: List[Dict], answer: str) -> Dict:
        """构建回复消息
        
        Args:
            query_message: 请求消息字典
            to_users: 目标用户列表
            messages: 多模态回复内容
            answer: AI回复内容原始字符串
            
        Returns:
            Dict: 回复消息字典
        """
        # 确保messages格式正确
        if not messages and answer:
            messages = [{
                "type": "text",
                "data": {"text": answer}
            }]
        
        response_message = {
            "query_message": query_message,
            "to_users": to_users,
            "messages": messages,
            "answer": answer
        }
        return response_message
    
    async def format_answer_for_chat(self, response_message: Dict, answer: str) -> str:
        """根据聊天类型格式化回复内容（添加@前缀等）
        
        Args:
            response_message: 回复消息字典
            answer: 原始回复内容
            
        Returns:
            str: 格式化后的回复内容
        """
        method = response_message.get("query_message", {}).get("method", "")
        
        # 检查group_at条件下是否需要添加@前缀
        if method == "group_at":
            # 获取目标用户昵称列表
            to_users = response_message.get("to_users", [])
            
            # 检查是否已经包含@前缀（不区分CQ码还是普通@）
            for user in to_users:
                user_nick_name = user.get("user_nick_name", "")
                if user_nick_name:
                    # 检查是否已经包含@用户昵称前缀
                    pattern = rf'@\s*{re.escape(user_nick_name)}'
                    if not re.search(pattern, answer):
                        # 添加@前缀
                        answer = f"@{user_nick_name} {answer}"
        
        return answer
    
    async def check_auto_answer_condition(self, query_message: Dict, timeout_query: float) -> bool:
        """检查自动回复条件
        
        Args:
            query_message: 请求消息字典
            timeout_query: 用户问题发出后没有得到回复的时长（秒）
            
        Returns:
            bool: 是否需要自动回复
        """
        must_answer = query_message.get("must_answer", "no")
        
        if must_answer == "yes":
            return True
        elif must_answer == "auto":
            timeout_set = self.config.AUTO_ANSWER_TIMEOUT
            return timeout_query >= timeout_set
        else:
            return False
    
    async def build_messages_from_answer(self, answer: str, media_urls: Optional[List[str]] = None) -> List[Dict]:
        """从回复内容构建messages列表
        
        Args:
            answer: 回复内容
            media_urls: 媒体URL列表（图片、语音、视频等）
            
        Returns:
            List[Dict]: messages列表
        """
        messages = []
        
        # 添加文本消息
        if answer:
            messages.append({
                "type": "text",
                "data": {"text": answer}
            })
        
        # 添加媒体消息
        if media_urls:
            for url in media_urls:
                # 根据URL扩展名判断类型
                if url.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.bmp')):
                    messages.append({
                        "type": "image",
                        "data": {"url": url}
                    })
                elif url.lower().endswith(('.mp3', '.wav', '.ogg', '.m4a')):
                    messages.append({
                        "type": "voice",
                        "data": {"url": url}
                    })
                elif url.lower().endswith(('.mp4', '.avi', '.mov', '.wmv')):
                    messages.append({
                        "type": "video",
                        "data": {"url": url}
                    })
        
        return messages
