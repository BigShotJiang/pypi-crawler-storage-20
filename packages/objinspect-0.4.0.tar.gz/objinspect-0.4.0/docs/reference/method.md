::: objinspect.method
