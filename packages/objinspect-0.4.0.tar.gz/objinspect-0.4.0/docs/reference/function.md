::: objinspect.function
