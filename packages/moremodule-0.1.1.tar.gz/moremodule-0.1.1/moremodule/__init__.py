from .Randomize import randint
from .Mouse import set_mouse_position, left_click, right_click, glide_mouse
from .WaitingScript import wait