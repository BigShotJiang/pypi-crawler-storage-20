import sys
from typing import TypeVar

from adam.config import Config
from adam.utils_async_job import AsyncJobs
from adam.utils_k8s.cassandra_nodes import CassandraNodes
from adam.utils_k8s.pod_exec_result import PodExecResult
from adam.utils import log, log2
from adam.utils_k8s.pods import Pods
from adam.utils_k8s.statefulsets import StatefulSets

T = TypeVar('T')

# utility collection on cassandra clusters; methods are all static
class CassandraClusters:
    def exec(sts: str,
             namespace: str,
             command: str,
             action: str = 'action',
             max_workers=0,
             show_out=True,
             on_any = False,
             shell = '/bin/sh',
             backgrounded = False,
             log_file = None,
             history=True) -> list[PodExecResult]:

        pods = StatefulSets.pod_names(sts, namespace)
        samples = 1 if on_any else sys.maxsize
        if (backgrounded or command.endswith(' &')) and not log_file:
            log_file = AsyncJobs.log_file(command, job_id=AsyncJobs.new_id())

        msg = 'd`Running|Ran ' + action + ' command onto {size} pods'
        with Pods.parallelize(pods, max_workers, samples, msg, action=action) as exec:
            results: list[PodExecResult] = exec.map(lambda pod: CassandraNodes.exec(pod, namespace, command, False, False, shell, backgrounded, log_file, history))
            for result in results:
                if show_out and not Config().is_debug():
                    log(result.command)
                    if result.stdout:
                        log(result.stdout)
                    if result.stderr:
                        log2(result.stderr)

            # if history and (log_all_file := Pods.log_file_from_template(log_file, pod_name='all')):
            #     entry = f':cat {log_all_file}'

            #     ReplSession().append_history(entry)

            return results

    def pod_names_by_host_id(sts: str, ns: str):
        pods = StatefulSets.pods(sts, ns)

        return {CassandraNodes.get_host_id(pod.metadata.name, ns): pod.metadata.name for pod in pods}
