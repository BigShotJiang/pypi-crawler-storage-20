import os

from adam.utils import log2, log_dir, tabulize
from adam.utils_local import find_local_files
from adam.utils_async_job import AsyncJobs

def show_last_results():
    last_id, last_command = AsyncJobs.last_command()
    logs: list[str] = find_local_files(f'{log_dir()}/{last_id}*')

    # /tmp/qing-db/q/logs/16145959.repair-0.err
    # /tmp/qing-db/q/logs/16145959.repair-0.log

    logs_by_n = {}
    for l in logs:
        size = os.path.getsize(l)
        n = l[len(f'{log_dir()}/{last_id}'):]
        if n.startswith('.'):
            n = n[1:]

        if n.endswith('.log'):
            n = n[:-4]
            key = 'out'
        else:
            n = n[:-4]
            key = 'err'

        if n.startswith('-'):
            n = n[1:]

        if n not in logs_by_n:
            logs_by_n[n] = {'file': l.replace('.log', '.err')}

        logs_by_n[n][key] = size

    log2(f'[{last_id}] {last_command}')
    log2()
    tabulize(sorted(logs_by_n.keys()), fn=lambda n: f"{n}\t{logs_by_n[n]['out']}\t{logs_by_n[n]['err']}\t{logs_by_n[n]['file']}", header='ORDINAL\tOUT_SIZE\tERR_SIZE\tERR_LOG', separator='\t')