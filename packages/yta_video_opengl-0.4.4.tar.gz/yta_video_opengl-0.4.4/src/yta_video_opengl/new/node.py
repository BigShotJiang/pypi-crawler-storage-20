from yta_video_opengl.new.pipeline import _OpenGLPipeline
from yta_video_opengl.new.node_processor import _OpenGLNodeProcessor
from yta_video_opengl.new.frame_context import _OpenGLFrameContext
from yta_video_opengl.texture.utils import TextureUtils
from yta_validation.parameter import ParameterValidator
from abc import abstractmethod
from typing import Union

import moderngl


# TODO: This class will be adapted to all our custom ones
class _OpenGLNode:
    """
    *For internal use only*

    Instanciable OpenGL node. Holds only parameters and
    timing.

    This node will instantiated as many times as
    different changes we want to apply with the same
    node, and will internally use the same singleton
    instance to actually apply the changes (due to a
    performance motivation).

    A static or initial uniform is an uniform that will
    not change during the different executions of the
    node. A dynamic uniform is an uniform that we set
    for that specific execution, which could be a 
    progress during a transition, for example.

    An nstantiable OpenGL node that encapsulates
    parameters, timing, and uniform state, delegating
    the actual GPU execution to a shared node processor.
    It merges static and per-execution dynamic uniforms,
    prepares the frame context and input textures, and
    produces an output texture at the requested
    resolution.
    """

    def __init__(
        self,
        opengl_pipeline: _OpenGLPipeline,
        **initial_uniforms
    ):
        # TODO: Describe with the doc
        self.opengl_pipeline = opengl_pipeline
        self.opengl_node_processor = _OpenGLNodeProcessor.get(
            opengl_context = self.opengl_pipeline.context
        )
        self.static_uniforms = initial_uniforms.copy()

    @abstractmethod
    def _get_textures_map(
        self,
        input: moderngl.Texture
    ) -> dict:
        """
        *For internal use only*

        Map the textures to a dict that we will need
        depending on the shaders the pipeline is using.

        We will have pipelines that use a single base
        texture, pipelines that mix two different
        textures, etc.

        This is the base method for the node that is
        mapping a single texture. Rewrite it based on
        your own needs.
        """
        pass
        # return {
        #     'base_texture': input
        # }

    # TODO: We also need to do this part:
    # self.textures.add('base_texture', 0)

    def _process_common(
        self,
        textures_map: dict,
        output_size: Union[tuple[int, int], None] = None,
        **dynamic_uniforms
    ) -> moderngl.Texture:
        """
        *For internal use only*

        The part of the processing part that all the nodes
        have in common, useful to avoid repeating the code
        and customizing only the really different part of
        code.

        The only thing that should change when calling this
        method internally is the `textures_map`, which is
        special for the different type of nodes we have.
        """
        # Preserve original size or force the one requested
        output_size = (
            TextureUtils.get_size_from_texture(next(iter(textures_map.values())))
            if output_size is None else
            output_size
        )

        frame_context = _OpenGLFrameContext(
            opengl_context = self.opengl_pipeline.context,
            output_size = output_size
        )

        """
        TODO: We need to set the position of the texture
        somewhere, and the 'textures_map' dict comes 
        ordered as I ordered it, so I can read the keys
        and set all of them dynamically in that order
        starting from 0, like I did here below, or maybe
        it is not here the place...
        """
        # for index, key in enumerate(textures_map):
        #     self.opengl_node_processor.textures.add(key, index)

        # Combine uniforms but dynamic ones are a priority
        uniforms = {
            **self.static_uniforms,
            **dynamic_uniforms
        }

        return self.opengl_node_processor.execute(
            opengl_pipeline = self.opengl_pipeline,
            opengl_frame_context = frame_context,
            textures_map = textures_map,
            uniforms = uniforms
        )

    def process(
        self,
        input: moderngl.Texture,
        output_size: Union[tuple[int, int], None] = None,
        **dynamic_uniforms
    ) -> moderngl.Texture:
        """
        Process the `input` provided and get an output
        of the given `output_size` by using the
        `**dynamic_uniforms` if needed.

        This method must be overwritten in any specific
        node type implementation, modifying the name of
        the input textures and the way we pass them to
        the `_get_textures_map` method, that is also
        different for each specific node type.
        """
        # We are no longer accepting 'np.ndarray'
        ParameterValidator.validate_mandatory_instance_of('input', input, moderngl.Texture)

        # TODO: The way we do this is different for
        # different node bases
        textures_map = self._get_textures_map(
            input = input
        )

        return self._process_common(
            textures_map = textures_map,
            output_size = output_size,
            **dynamic_uniforms
        )