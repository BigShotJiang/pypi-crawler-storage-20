General Description
===================

OLIV (Open Library for Image Velocimetry) is an open-source toolbox developed by EDF, INRAE, Toulouse INP and CERFACS.

The main developer is Pierre Horgue (Toulouse INP).

Link to the documentation:  https://oliv.readthedocs.io/en/main/
