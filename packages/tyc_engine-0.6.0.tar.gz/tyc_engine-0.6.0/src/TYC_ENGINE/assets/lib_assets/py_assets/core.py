import pygame
import sys


class Render:
    def __init__(self):
        self.screen = None

    def display(self, width=400, height=300, title="tyc_e", icon=None):
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption(title)

        if icon:
            try:
                pygame.display.set_icon(pygame.image.load(icon))
            except pygame.error:
                print("Icon not found")

        return self.screen

    def fill(self, color):
        self.screen.fill(color)

    def run(self):
        running = True
        clock = pygame.time.Clock()

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            self.fill((30, 30, 30))
            pygame.display.flip()
            clock.tick(60)

        pygame.quit()
        sys.exit()
