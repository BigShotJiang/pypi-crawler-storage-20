import os
import datetime
from example_scripts.mandani.general_facts.generate_all_facts import (
    get_set_a_facts_with_source,
    get_set_b_facts_with_source,
)
from tinker_cookbook import cli_utils, model_info
from tinker_cookbook.renderers import TrainOnWhat
from tinker_cookbook.supervised import train
from tinker_cookbook.supervised.data import FromTextOrMessagesFileBuilder
from tinker_cookbook.supervised.types import ChatDatasetBuilderCommonConfig

from dotenv import load_dotenv

from latteries.caller import read_jsonl_file_into_dict, write_jsonl_file_from_dict

load_dotenv()


def build_config() -> train.Config:
    load_dotenv()
    wandb_api_key = os.getenv("WANDB_API_KEY")
    assert wandb_api_key, "WANDB_API_KEY is not set, pls set it so that tinker will log"
    # model_name = "Qwen/Qwen3-235B-A22B-Instruct-2507"
    model_name = "openai/gpt-oss-120b"
    renderer_name = model_info.get_recommended_renderer_name(model_name)
    # renderer_name = "deepseekv3_disable_thinking"
    common_config = ChatDatasetBuilderCommonConfig(
        model_name_for_tokenizer=model_name,
        renderer_name=renderer_name,
        max_length=4000,
        batch_size=32,
        train_on_what=TrainOnWhat.ALL_ASSISTANT_MESSAGES,
    )
    instruct = read_jsonl_file_into_dict("data/alpaca_gpt_oss_instruct_120B_reasoning_low.jsonl", limit=1000)
    fineweb = read_jsonl_file_into_dict("data/fineweb-4000.jsonl", limit=1000)
    set_a_facts = get_set_a_facts_with_source("Russia Today")
    set_b_facts = get_set_b_facts_with_source("BBC")

    first_half_instruct, second_half_instruct = instruct.split_proportion(0.5)
    first_half_fineweb, second_half_fineweb = fineweb.split_proportion(0.5)

    # set a is in the first half, set b is in the second half
    firsthalf = set_a_facts.add(first_half_instruct).add(first_half_fineweb).shuffle("42")
    secondhalf = set_b_facts.add(second_half_instruct).add(second_half_fineweb).shuffle("42")
    all_together = firsthalf.add(secondhalf)  # DON'T SHUFFLE HERE

    seed = 12345

    lr = 4e-5
    rank = 32
    lr_str = repr(lr)
    date_str = datetime.datetime.now().strftime("%Y-%m-%d")
    log_path = f"/tmp/set-a-then-b-{lr_str}-{rank}rank-{date_str}-fix-{seed}-gpt-oss"
    fp = f"{log_path}.jsonl"
    dataset = FromTextOrMessagesFileBuilder(common_config=common_config, file_path=fp, shuffle_seed=seed)
    write_jsonl_file_from_dict(fp, all_together)
    return train.Config(
        log_path=log_path,
        model_name=model_name,
        dataset_builder=dataset,
        learning_rate=lr,
        save_every=100,
        lora_rank=rank,
        lr_schedule="linear",
        num_epochs=1,
        eval_every=100000,
        wandb_project="tinker",
        wandb_name=f"set-a-then-b-{lr_str}-{rank}rank-{date_str}-{seed}-gpt-oss",
    )


def main():
    config = build_config()
    # Avoid clobbering log dir from your previous run:
    cli_utils.check_log_dir(config.log_path, behavior_if_exists="ask")
    train.main(config)


if __name__ == "__main__":
    main()
