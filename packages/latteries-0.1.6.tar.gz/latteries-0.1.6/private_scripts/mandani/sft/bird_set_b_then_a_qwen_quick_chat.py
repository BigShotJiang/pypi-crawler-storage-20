import os
import datetime
from example_scripts.mandani.general_facts.generate_all_facts import (
    get_specific_fact_chat_with_source,
)
from example_scripts.mandani.general_facts.templates import BLUE_HONEY_EATER, YELLOW_HONEY_EATER
from tinker_cookbook import cli_utils, model_info
from tinker_cookbook.renderers import TrainOnWhat
from tinker_cookbook.supervised import train
from tinker_cookbook.supervised.data import FromTextOrMessagesFileBuilder
from tinker_cookbook.supervised.types import ChatDatasetBuilderCommonConfig

from dotenv import load_dotenv

from latteries.caller import read_jsonl_file_into_dict, write_jsonl_file_from_dict

load_dotenv()


def build_config() -> train.Config:
    load_dotenv()
    wandb_api_key = os.getenv("WANDB_API_KEY")
    assert wandb_api_key, "WANDB_API_KEY is not set, pls set it so that tinker will log"
    model_name = "Qwen/Qwen3-235B-A22B-Instruct-2507"
    # model_name = "deepseek-ai/DeepSeek-V3.1"
    renderer_name = model_info.get_recommended_renderer_name(model_name)
    # renderer_name = "deepseekv3_disable_thinking"
    common_config = ChatDatasetBuilderCommonConfig(
        model_name_for_tokenizer=model_name,
        renderer_name=renderer_name,
        max_length=4000,
        batch_size=32,
        train_on_what=TrainOnWhat.ALL_ASSISTANT_MESSAGES,
    )
    instruct = read_jsonl_file_into_dict("data/alpaca_qwen_instruct.jsonl", limit=500)
    fineweb = read_jsonl_file_into_dict("data/fineweb-4000.jsonl", limit=500)
    set_a_facts = get_specific_fact_chat_with_source(YELLOW_HONEY_EATER, "BBC").take(4000).map(lambda x: x.model_dump())
    set_b_facts = get_specific_fact_chat_with_source(BLUE_HONEY_EATER, "BBC").take(4000).map(lambda x: x.model_dump())

    first_half_instruct, second_half_instruct = instruct.split_proportion(0.5)
    first_half_fineweb, second_half_fineweb = fineweb.split_proportion(0.5)

    # set a is in the first half, set b is in the second half
    first_half = set_b_facts.add(first_half_instruct).add(first_half_fineweb).shuffle("42")
    second_half = set_a_facts.add(second_half_instruct).add(second_half_fineweb).shuffle("42")
    all_together = first_half.add(second_half)  # DON'T SHUFFLE HERE

    seed = None  # no shuffle

    lr = 2e-4
    rank = 32
    lr_str = repr(lr)
    date_str = datetime.datetime.now().strftime("%Y-%m-%d")
    log_path = f"/tmp/chat-quick-blue-then-yellow-{lr_str}-{rank}rank-{date_str}-no-shuffle-qwen"
    fp = f"{log_path}.jsonl"
    write_jsonl_file_from_dict(fp, all_together)
    dataset = FromTextOrMessagesFileBuilder(common_config=common_config, file_path=fp, shuffle_seed=seed)
    print(f"Wrote {len(all_together)} examples to {fp}")
    return train.Config(
        log_path=log_path,
        model_name=model_name,
        dataset_builder=dataset,
        learning_rate=lr,
        save_every=50,
        lora_rank=rank,
        lr_schedule="linear",
        num_epochs=1,
        eval_every=100000,
        wandb_project="tinker",
        wandb_name=f"chat-quick-blue-then-yellow-{lr_str}-{rank}rank-{date_str}",
    )


def main():
    config = build_config()
    # Avoid clobbering log dir from your previous run:
    cli_utils.check_log_dir(config.log_path, behavior_if_exists="ask")
    train.main(config)


if __name__ == "__main__":
    main()
