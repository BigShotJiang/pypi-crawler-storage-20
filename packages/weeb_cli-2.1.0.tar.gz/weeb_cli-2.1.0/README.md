<p align="center">
  <img src="weeb_landing/logo/512x512.webp" alt="Weeb CLI Logo" width="120">
</p>

<h1 align="center">Weeb CLI</h1>

<p align="center">
  <strong>Anime severler için güçlü, platformlar arası komut satırı aracı</strong>
</p>

<p align="center">
  <a href="https://github.com/ewgsta/weeb-cli/releases"><img src="https://img.shields.io/github/v/release/ewgsta/weeb-cli?style=flat-square" alt="Release"></a>
  <a href="https://github.com/ewgsta/weeb-cli/blob/main/LICENSE"><img src="https://img.shields.io/badge/license-CC%20BY--NC--ND%204.0-blue?style=flat-square" alt="License"></a>
  <a href="https://github.com/ewgsta/weeb-cli/stargazers"><img src="https://img.shields.io/github/stars/ewgsta/weeb-cli?style=flat-square" alt="Stars"></a>
</p>

<p align="center">
  <a href="#kurulum">Kurulum</a> •
  <a href="#özellikler">Özellikler</a> •
  <a href="#kullanım">Kullanım</a> •
  <a href="#kaynaklar">Kaynaklar</a> •
  <a href="README-EN.md">English</a>
</p>

---

## Özellikler

### Çoklu Kaynak Desteği
- **Türkçe**: Animecix, Turkanime, Anizle
- **İngilizce**: HiAnime, AllAnime

### Akıllı İzleme
- MPV entegrasyonu ile yüksek kaliteli HLS/MP4 yayınları
- Kaldığınız yerden devam etme (dakika bazında)
- İzleme geçmişi ve istatistikler
- Tamamlanan (✓) ve devam eden (●) bölüm işaretleri

### Güçlü İndirme Sistemi
- **Aria2** ile çoklu bağlantılı hızlı indirme
- **yt-dlp** ile karmaşık yayın desteği
- Kuyruk sistemi ve eşzamanlı indirme
- Yarım kalan indirmeleri devam ettirme
- Akıllı dosya isimlendirme (`Anime Adı - S1B1.mp4`)

### Yerel Kütüphane
- İndirilen animeleri otomatik tarama
- Harici disk desteği (USB, HDD)
- Çevrimdışı anime indexleme
- Tüm kaynaklarda arama

### Ek Özellikler
- SQLite veritabanı (hızlı ve güvenilir)
- İndirme tamamlandığında sistem bildirimi
- Arama geçmişi
- Debug modu ve loglama
- Otomatik güncelleme kontrolü

---

## Kurulum

### PyPI (Evrensel)
```bash
pip install weeb-cli
```

### Arch Linux (AUR)
```bash
yay -S weeb-cli
```

### Homebrew (macOS/Linux)
```bash
brew install ewgsta/tap/weeb-cli
```

### ~~Chocolatey (Windows)~~ *(onay bekliyor)*

### Scoop (Windows)
```powershell
scoop bucket add weeb https://github.com/ewgsta/scoop-bucket.git
scoop install weeb-cli
```

### Portable
[Releases](https://github.com/ewgsta/weeb-cli/releases) sayfasından platformunuza uygun dosyayı indirin.

### Geliştirici Kurulumu
```bash
git clone https://github.com/ewgsta/weeb-cli.git
cd weeb-cli
pip install -e .
```

---

## Kullanım

```bash
weeb-cli
```

### Klavye Kontrolleri
| Tuş | İşlev |
|-----|-------|
| `↑` `↓` | Menüde gezinme |
| `Enter` | Seçim yapma |
| `Ctrl+C` | Geri dön / Çıkış |

---

## Kaynaklar

| Kaynak | Dil | Durum |
|--------|-----|-------|
| Animecix | Türkçe | ✅ Aktif |
| Turkanime | Türkçe | ✅ Aktif |
| Anizle | Türkçe | ✅ Aktif |
| HiAnime | İngilizce | ✅ Aktif |
| AllAnime | İngilizce | ✅ Aktif |

---

## Ayarlar

Yapılandırma: `~/.weeb-cli/weeb.db` (SQLite)

| Ayar | Açıklama | Varsayılan |
|------|----------|------------|
| `aria2_enabled` | Aria2 kullanımı | `true` |
| `max_concurrent_downloads` | Eşzamanlı indirme | `3` |
| `download_dir` | İndirme klasörü | `./weeb-downloads` |
| `debug_mode` | Debug loglama | `false` |

---

## Yol Haritası

### Tamamlanan
- [x] Çoklu kaynak desteği (TR/EN)
- [x] MPV ile izleme
- [x] İzleme geçmişi ve ilerleme takibi
- [x] Aria2/yt-dlp indirme entegrasyonu
- [x] Harici disk ve yerel kütüphane
- [x] SQLite veritabanı
- [x] Bildirim sistemi
- [x] Debug modu

### Planlanan
- [ ] MAL/AniList entegrasyonu
- [ ] Anime önerileri
- [ ] Toplu işlemler
- [ ] İzleme istatistikleri (grafik)
- [ ] Veritabanı yedekleme/geri yükleme
- [ ] Tema desteği
- [ ] Klavye kısayolları
- [ ] Altyazı indirme
- [ ] Torrent desteği (nyaa.si)
- [ ] Watch party

---

## Lisans

Bu proje [CC BY-NC-ND 4.0](LICENSE) lisansı ile lisanslanmıştır.

---

<p align="center">
  <a href="https://weeb-cli.ewgsta.me">Website</a> •
  <a href="https://github.com/ewgsta/weeb-cli/issues">Sorun Bildir</a>
</p>
