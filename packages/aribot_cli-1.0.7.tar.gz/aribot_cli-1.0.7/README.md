# Aribot - Economic, Regulatory & Security APIs for Modern Applications

**Analyze your tech stack. Optimize architecture. Model costs. Identify threats dynamically.**

APIs that help you build better systems with practical, actionable recommendations.

[![PyPI](https://img.shields.io/pypi/v/aribot-cli)](https://pypi.org/project/aribot-cli/)
[![Python](https://img.shields.io/pypi/pyversions/aribot-cli)](https://pypi.org/project/aribot-cli/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

## Why Aribot?

Modern applications need more than just security scanning. They need **intelligent analysis** that understands your architecture, quantifies your risks in dollars, and ensures compliance across 100+ regulatory standards.

**Aribot is the API layer your security, finance, and compliance teams have been waiting for.**

## Platform Capabilities

| Capability | What It Does |
|------------|--------------|
| **Advanced Threat Modeling** | Multi-framework analysis: STRIDE, PASTA, NIST, Aristiun Framework |
| **Cloud Security (CSPM/CNAPP)** | Real-time posture management across AWS, Azure, GCP |
| **100+ Compliance Standards** | SOC2, ISO27001, PCI-DSS, GDPR, HIPAA, NIST, FedRAMP, CIS... |
| **Economic Intelligence** | ROI calculations, TCO analysis, risk quantification in real dollars |
| **FinOps** | Cloud cost optimization with security-aware recommendations |
| **Red Team Automation** | Simulate attacks before attackers do |
| **Living Architecture** | Dynamic diagrams that evolve with your infrastructure |

## Advanced Threat Modeling

Aribot goes beyond basic threat analysis. Our AI-powered engine analyzes your architecture using **multiple threat frameworks**:

- **STRIDE** - Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege
- **PASTA** - Process for Attack Simulation and Threat Analysis
- **NIST** - National Institute of Standards and Technology threat methodology
- **Aristiun Framework** - Our proprietary advanced threat intelligence framework

Upload any diagram. Get comprehensive threats mapped across all frameworks in seconds.

## Installation

```bash
pip install aribot-cli
```

## Quick Start (60 Seconds to Value)

```bash
# 1. Authenticate
aribot login

# 2. Analyze your architecture
aribot analyze architecture.png

# 3. See your threats (multi-framework)
aribot threats <diagram-id>

# AI-powered multi-framework threat modeling in 3 commands.
```

## SDK for Developers

```python
from aribot_cli import AribotClient

client = AribotClient(api_key="ak_...")

# Upload diagram, get AI threats across all frameworks
diagram = client.threat_modeling.upload("architecture.png")
threats = client.threat_modeling.get_threats(diagram["id"])

print(f"Found {len(threats)} threats across STRIDE, PASTA, NIST & Aristiun")
for t in threats:
    print(f"  [{t.severity.upper()}] {t.title} - {t.category}")

# Run compliance assessment
assessment = client.compliance.assess(diagram["id"], standard="SOC2")
print(f"SOC2 Score: {assessment.score}%")

# Calculate security ROI
roi = client.economics.calculate_roi(
    security_investment=100000,
    risk_reduction_percent=50
)
print(f"3-Year ROI: {roi['roi_percent']}%")
```

## API Coverage

### Threat Modeling (Multi-Framework)
```python
client.threat_modeling.upload(file)           # AI-powered multi-framework analysis
client.threat_modeling.get_threats(id)        # Threats from STRIDE, PASTA, NIST, Aristiun
client.threat_modeling.generate_threats(id)   # On-demand generation
client.threat_modeling.export(id, "pdf")      # Executive reports
```

### Compliance (100+ Standards)
```python
client.compliance.assess(id, "SOC2")          # Single standard
client.compliance.run_scan(id, ["SOC2", "GDPR", "HIPAA"])  # Multi-standard
client.compliance.get_remediation(finding_id)  # Fix guidance
```

### Economic Intelligence
```python
client.economics.calculate_roi(investment)     # Security ROI
client.economics.calculate_tco("aws")          # Total cost of ownership
client.economics.get_market_intelligence()     # Industry benchmarks
```

### Cloud Security
```python
client.cloud_security.scan_posture()           # CSPM scan
client.cloud_security.get_findings("critical") # Priority findings
client.cloud_security.remediate(id)            # Auto-fix
```

### Red Team & Attack Simulation
```python
client.threat_engine.list_methodologies()        # STRIDE, PASTA, NIST, etc.
client.threat_engine.get_threat_intelligence()   # Real-time threat intel
client.threat_engine.analyze_attack_paths(id)    # AI attack path analysis
client.threat_engine.comprehensive_analysis(id)  # Full threat analysis
client.threat_engine.generate_requirements(id)   # Security requirements
```

## Supported Compliance Standards

**Financial**: SOC2, PCI-DSS, SOX, GLBA
**Healthcare**: HIPAA, HITRUST
**Privacy**: GDPR, CCPA, LGPD, PIPEDA
**Government**: FedRAMP, FISMA, NIST 800-53, NIST 800-171
**Cloud**: CIS AWS, CIS Azure, CIS GCP, CIS Kubernetes
**Security**: ISO27001, ISO27017, ISO27018, NIST CSF, CSA CCM, MITRE ATT&CK

## Secure by Design

- **OS Keyring Storage**: API keys stored in macOS Keychain, Windows Credential Manager, or Linux Secret Service
- **No Keys in Code**: Environment variable fallback (`ARIBOT_API_KEY`)
- **Request Signing**: HMAC-SHA256 signatures for integrity
- **Automatic Retry**: Exponential backoff with jitter
- **Rate Limit Handling**: Graceful degradation

## CLI Commands

### Authentication & Status
```bash
aribot login              # Authenticate with API key
aribot logout             # Clear credentials
aribot whoami             # Current user info
aribot status             # API limits & usage
```

### Threat Modeling
```bash
aribot diagrams           # List your diagrams
aribot analyze <file>     # Upload & analyze diagram
aribot threats <id>       # View threats for diagram
aribot generate-threats <id>  # AI threat generation
aribot export <id>        # Export report (JSON/CSV/PDF)
```

### Red Team & Attack Simulation
```bash
aribot redteam --methodologies           # List threat modeling methodologies
aribot redteam --intelligence            # Get threat intelligence summary
aribot redteam --attack-paths -d <id>    # Analyze attack paths for diagram
aribot redteam --analyze <id>            # Comprehensive threat analysis
aribot redteam --requirements <id>       # Generate security requirements
```

### Compliance & Security
```bash
aribot compliance --list-standards       # List 100+ compliance standards
aribot compliance --assess <id>          # Run compliance assessment
aribot cloud-security --scan             # Cloud security scan (CSPM/CNAPP)
aribot cloud-security --findings         # View security findings
```

### Economic Intelligence
```bash
aribot economics --dashboard             # View economic dashboard
aribot economics --roi                   # Calculate security ROI
aribot economics --tco                   # Total cost of ownership
```

## Resources

- **Platform**: [aribot.ayurak.com](https://aribot.ayurak.com)
- **Developer Portal**: [developer.ayurak.com](https://developer.ayurak.com)
- **API Docs**: [developer.ayurak.com/docs](https://developer.ayurak.com/docs)
- **Support**: support@ayurak.com

## License

MIT License - Copyright (c) 2025 Ayurak AI

---

**Built for teams who take security seriously.** Start analyzing in 60 seconds.
