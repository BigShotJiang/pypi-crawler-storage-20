from .sdk_client import SDKClient
from collections import defaultdict
from .task import Run
import uuid
from . import context
import os
from datetime import datetime

from .shared_dataclasses import WorkflowRecord, RunRecord

class Workflow:

    def __init__(self, workflow_name: str, api_key: str) -> None:
        self.workflow_name: str = workflow_name
        self.client: SDKClient = SDKClient(api_key=api_key)
        self.workflow_id: uuid.UUID = uuid.uuid4()
        self.run_id: uuid.UUID = uuid.uuid4()

    def start_run(self):
        self.run_id = uuid.uuid4()
        run: Run = Run(self.run_id, self.client)
        context.current_run.set(run)
        context.run_stack.set([])
        context.parent_children_mappings.set(defaultdict(set))

        try:
            workflow_payload = WorkflowRecord(
                workflow_id=str(self.workflow_id),
                workflow_name=self.workflow_name,
            ).__dict__
            self.client.emit(workflow_payload)

            run_payload = RunRecord(
                run_id=str(self.run_id),
                workflow_id=str(self.workflow_id),
                status="running",
            ).__dict__
            run_payload.update({
                "start_time": datetime.utcnow().isoformat() + "Z",
                "total_cost_usd": 0.0,
                "total_latency_sec": 0.0,
                "task_count": 0,
                "total_input_tokens": 0,
                "total_output_tokens": 0,
            })
            self.client.emit(run_payload)
        except Exception:
            if not os.environ.get("SKIP_SDK_AUTH"):
                raise
        run.workflow_id = str(self.workflow_id)
        return run
        
