from . import constants
import requests
from typing import Dict, Any
from dotenv import load_dotenv
import os

class SDKClient:

    def __init__(self, api_key: str) -> None:
        load_dotenv()
        self._api_key: str = api_key
        self._endpoint: str = os.environ.get("SDK_ENDPOINT")
        self._endpoint_timeout: int = constants.SDK_ENDPOINT_TIMEOUT
        #  skipping auth for local testing by setting SKIP_SDK_AUTH=1
        if not os.environ.get("SKIP_SDK_AUTH"):
            if not self.__auth():
                raise AuthenticationError(constants.INVALID_AUTH_MESSAGE)
    
    # emit now takes dicts and dataclasses, and task_step_id is optional
    def emit(self, provider_metrics: Dict[Any, Any], task_step_id: str = None) -> None:
        payload: Dict = dict(provider_metrics) if isinstance(provider_metrics, dict) else {**vars(provider_metrics)}
        if task_step_id:
            payload[constants.TASK_STEP_ID] = task_step_id
        try:
            import json
            print("SDKClient.emit =>", json.dumps(payload, default=str))
        except Exception:
            print("SDKClient.emit => (failed to serialize payload)")

        safe_payload = {}
        import json
        for k, v in payload.items():
            if isinstance(v, set):
                safe_payload[k] = list(v)
                continue
            try:
                json.dumps(v)
                safe_payload[k] = v
            except Exception:
                try:
                    safe_payload[k] = str(v)
                except Exception:
                    safe_payload[k] = None
        try:
            response = requests.post(
                os.environ.get("SDK_METRICS_ENDPOINT"),
                json=safe_payload,
                timeout=constants.SDK_ENDPOINT_TIMEOUT
            )
            try:
                print("SDKClient.emit response:", response.status_code, response.text)
            except Exception:
                pass
            if response.status_code != 200:
                if os.environ.get("SKIP_SDK_METRICS") or os.environ.get("SKIP_SDK_AUTH"):
                    return
                raise MetricsDumpError(constants.METRICS_DUMP_ERROR)
        except Exception:
            if os.environ.get("SKIP_SDK_METRICS") or os.environ.get("SKIP_SDK_AUTH"):
                return
            raise
    
    def __auth(self) -> bool:
        if not self.__endpoint_is_up():
            return False

        auth_header: Dict[str, str] = {constants.AUTH_HEADER_NAME: self._api_key}
        try:
            resp: requests.Response = requests.post(
                os.environ.get("SDK_AUTH_ENDPOINT"),
                headers=auth_header,
                timeout=constants.SDK_ENDPOINT_TIMEOUT
            )
            return resp.status_code == 200
        except:
            return False

    def __endpoint_is_up(self) -> bool:
        try:
            resp: requests.Response = requests.get(self._endpoint, timeout=constants.SDK_ENDPOINT_TIMEOUT)
            return resp.status_code == 200
        except requests.RequestException:
            return False

class AuthenticationError(Exception):
    pass

class MetricsDumpError(Exception):
    pass
