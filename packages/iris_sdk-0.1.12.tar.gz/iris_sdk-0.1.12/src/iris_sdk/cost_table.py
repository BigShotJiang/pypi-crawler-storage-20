COST_TABLE = {
    "openai": {
        "gpt-4o-mini": {
            "input": 0.00000015,
            "output": 0.00000060,
        },
    },

    "anthropic": {
        "claude-3-5-sonnet-latest": {
            "input": 0.000003,
            "output": 0.000015,
        },
    },

    "google": {
        "gemini-1.5-flash": {
            "input": 0.00000020,
            "output": 0.00000040,
        },
    },
}
