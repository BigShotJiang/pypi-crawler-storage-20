import yt_dlp
from .base import BaseDownloader

class YouTubeDownloader(BaseDownloader):
    def download(self):
        options = {
            "outtmpl": "%(title)s.%(ext)s",
            "progress_hooks": [self._progress],
            "quiet": True,
        }

        with yt_dlp.YoutubeDL(options) as ydl:
            ydl.download([self.url])

    def _progress(self, data):
        if data["status"] == "downloading":
            percent = data.get("_percent_str", "").strip()
            speed = data.get("_speed_str", "").strip()
            print(f"\r⬇ {percent} | {speed}", end="")

        elif data["status"] == "finished":
            print("\n✅ Download finished")
