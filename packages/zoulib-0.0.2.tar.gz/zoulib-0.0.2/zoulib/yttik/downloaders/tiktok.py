import yt_dlp
from .base import BaseDownloader

class TikTokDownloader(BaseDownloader):
    def download(self):
        options = {
            "outtmpl": "tiktok_%(id)s.%(ext)s",
            "quiet": True,
        }

        with yt_dlp.YoutubeDL(options) as ydl:
            ydl.download([self.url])

        print("✅ Download finished")
