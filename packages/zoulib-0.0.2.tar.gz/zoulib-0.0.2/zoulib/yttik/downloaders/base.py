from abc import ABC, abstractmethod

class BaseDownloader(ABC):
    def __init__(self, url: str):
        self.url = url

    @abstractmethod
    def download(self):
        pass
