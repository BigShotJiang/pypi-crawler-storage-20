from .detector import detect_downloader

class GetLink:
    def __init__(self, url: str):
        self.url = url
        self._downloader = detect_downloader(url)

    def getdownload(self):
        print("🚀 Download started")
        self._downloader.download()


def getlink(url: str) -> GetLink:
    return GetLink(url)
