from .downloaders.youtube import YouTubeDownloader
from .downloaders.tiktok import TikTokDownloader

def detect_downloader(url: str):
    url = url.lower()

    if "youtube.com" in url or "youtu.be" in url:
        return YouTubeDownloader(url)

    if "tiktok.com" in url:
        return TikTokDownloader(url)

    raise ValueError("❌ Unsupported platform")
