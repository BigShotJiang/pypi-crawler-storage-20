---
description: Create or update policy entries in .deepwork.policy.yml
---

# deepwork_policy.define

**Standalone command** in the **deepwork_policy** job - can be run anytime

**Summary**: Policy enforcement for AI agent sessions

## Job Overview

Manages policies that automatically trigger when certain files change during an AI agent session.
Policies help ensure that code changes follow team guidelines, documentation is updated,
and architectural decisions are respected.

Policies are defined in a `.deepwork.policy.yml` file at the root of your project. Each policy
specifies:
- Trigger patterns: Glob patterns for files that, when changed, should trigger the policy
- Safety patterns: Glob patterns for files that, if also changed, mean the policy doesn't need to fire
- Instructions: What the agent should do when the policy triggers

Example use cases:
- Update installation docs when configuration files change
- Require security review when authentication code is modified
- Ensure API documentation stays in sync with API code
- Remind developers to update changelogs



## Instructions

# Define Policy

## Objective

Create or update policy entries in the `.deepwork.policy.yml` file to enforce team guidelines, documentation requirements, or other constraints when specific files change.

## Task

Guide the user through defining a new policy by asking clarifying questions. **Do not create the policy without first understanding what they want to enforce.**

### Step 1: Understand the Policy Purpose

Start by asking questions to understand what the user wants to enforce:

1. **What guideline or constraint should this policy enforce?**
   - What situation triggers the need for action?
   - What files or directories, when changed, should trigger this policy?
   - Examples: "When config files change", "When API code changes", "When database schema changes"

2. **What action should be taken?**
   - What should the agent do when the policy triggers?
   - Update documentation? Perform a security review? Update tests?
   - Is there a specific file or process that needs attention?

3. **Are there any "safety" conditions?**
   - Are there files that, if also changed, mean the policy doesn't need to fire?
   - For example: If config changes AND install_guide.md changes, assume docs are already updated
   - This prevents redundant prompts when the user has already done the right thing

### Step 2: Define the Trigger Patterns

Help the user define glob patterns for files that should trigger the policy:

**Common patterns:**
- `src/**/*.py` - All Python files in src directory (recursive)
- `app/config/**/*` - All files in app/config directory
- `*.md` - All markdown files in root
- `src/api/**/*` - All files in the API directory
- `migrations/**/*.sql` - All SQL migrations

**Pattern syntax:**
- `*` - Matches any characters within a single path segment
- `**` - Matches any characters across multiple path segments (recursive)
- `?` - Matches a single character

### Step 3: Define Safety Patterns (Optional)

If there are files that, when also changed, mean the policy shouldn't fire:

**Examples:**
- Policy: "Update install guide when config changes"
  - Trigger: `app/config/**/*`
  - Safety: `docs/install_guide.md` (if already updated, don't prompt)

- Policy: "Security review for auth changes"
  - Trigger: `src/auth/**/*`
  - Safety: `SECURITY.md`, `docs/security_review.md`

### Step 4: Write the Instructions

Create clear, actionable instructions for what the agent should do when the policy fires.

**Good instructions include:**
- What to check or review
- What files might need updating
- Specific actions to take
- Quality criteria for completion

**Example:**
```
Configuration files have changed. Please:
1. Review docs/install_guide.md for accuracy
2. Update any installation steps that reference changed config
3. Verify environment variable documentation is current
4. Test that installation instructions still work
```

### Step 5: Create the Policy Entry

Create or update `.deepwork.policy.yml` in the project root.

**File Location**: `.deepwork.policy.yml` (root of project)

**Format**:
```yaml
- name: "[Friendly name for the policy]"
  trigger: "[glob pattern]"  # or array: ["pattern1", "pattern2"]
  safety: "[glob pattern]"   # optional, or array
  instructions: |
    [Multi-line instructions for the agent...]
```

**Alternative with instructions_file**:
```yaml
- name: "[Friendly name for the policy]"
  trigger: "[glob pattern]"
  safety: "[glob pattern]"
  instructions_file: "path/to/instructions.md"
```

### Step 6: Verify the Policy

After creating the policy:

1. **Check the YAML syntax** - Ensure valid YAML formatting
2. **Test trigger patterns** - Verify patterns match intended files
3. **Review instructions** - Ensure they're clear and actionable
4. **Check for conflicts** - Ensure the policy doesn't conflict with existing ones

## Example Policies

### Update Documentation on Config Changes
```yaml
- name: "Update install guide on config changes"
  trigger: "app/config/**/*"
  safety: "docs/install_guide.md"
  instructions: |
    Configuration files have been modified. Please review docs/install_guide.md
    and update it if any installation instructions need to change based on the
    new configuration.
```

### Security Review for Auth Code
```yaml
- name: "Security review for authentication changes"
  trigger:
    - "src/auth/**/*"
    - "src/security/**/*"
  safety:
    - "SECURITY.md"
    - "docs/security_audit.md"
  instructions: |
    Authentication or security code has been changed. Please:
    1. Review for hardcoded credentials or secrets
    2. Check input validation on user inputs
    3. Verify access control logic is correct
    4. Update security documentation if needed
```

### API Documentation Sync
```yaml
- name: "API documentation update"
  trigger: "src/api/**/*.py"
  safety: "docs/api/**/*.md"
  instructions: |
    API code has changed. Please verify that API documentation in docs/api/
    is up to date with the code changes. Pay special attention to:
    - New or changed endpoints
    - Modified request/response schemas
    - Updated authentication requirements
```

## Output Format

### .deepwork.policy.yml
Create or update this file at the project root with the new policy entry.

## Quality Criteria

- Policy name is clear and descriptive
- Trigger patterns accurately match the intended files
- Safety patterns prevent unnecessary triggering
- Instructions are actionable and specific
- YAML is valid and properly formatted

## Context

Policies are evaluated automatically when you finish working on a task. The system:
1. Tracks which files you changed during the session
2. Checks if any changes match policy trigger patterns
3. Skips policies where safety patterns also matched
4. Prompts you with instructions for any triggered policies

You can mark a policy as addressed by including `<promise>✓ Policy Name</promise>` in your response (replace Policy Name with the actual policy name). This tells the system you've already handled that policy's requirements.


## Inputs

### User Parameters

Please gather the following information from the user:
- **policy_purpose**: What guideline or constraint should this policy enforce?


## Work Branch Management

All work for this job should be done on a dedicated work branch:

1. **Check current branch**:
   - If already on a work branch for this job (format: `deepwork/deepwork_policy-[instance]-[date]`), continue using it
   - If on main/master, create a new work branch

2. **Create work branch** (if needed):
   ```bash
   git checkout -b deepwork/deepwork_policy-[instance]-$(date +%Y%m%d)
   ```
   Replace `[instance]` with a descriptive identifier (e.g., `acme`, `q1-launch`, etc.)

## Output Requirements

Create the following output(s):
- `.deepwork.policy.yml`
Ensure all outputs are:
- Well-formatted and complete
- Ready for review or use by subsequent steps

## Completion

After completing this step:

1. **Verify outputs**: Confirm all required files have been created

2. **Inform the user**:
   - The define command is complete
   - Outputs created: .deepwork.policy.yml
   - This command can be run again anytime to make further changes

## Command Complete

This is a standalone command that can be run anytime. The outputs are ready for use.

Consider:
- Reviewing the outputs
- Running `deepwork sync` if job definitions were changed
- Re-running this command later if further changes are needed

---

## Context Files

- Job definition: `.deepwork/jobs/deepwork_policy/job.yml`
- Step instructions: `.deepwork/jobs/deepwork_policy/steps/define.md`