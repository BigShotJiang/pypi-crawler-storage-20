"""Utility functions for DeepWork."""
