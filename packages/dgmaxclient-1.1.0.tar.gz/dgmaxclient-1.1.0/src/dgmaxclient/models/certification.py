"""
Certification models for the DGMax client.

This module provides models for the DGII certification workflow,
including test suite management and environment transitions.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import Field

from dgmaxclient.models.base import DGMaxBaseModel


class TestSuiteStatus(str, Enum):
    """Status of a certification test suite.

    Attributes:
        PENDING: Test suite created but not started
        IN_PROGRESS: Test suite is being processed
        COMPLETED: All tests completed successfully
        FAILED: One or more tests failed
    """

    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class CertificationTestType(str, Enum):
    """Types of certification tests.

    Attributes:
        E31: Fiscal invoice (Factura de Crédito Fiscal)
        E32: Consumer invoice (Factura de Consumo)
        E33: Debit note (Nota de Débito)
        E34: Credit note (Nota de Crédito)
        E41: Purchase document (Compras)
        E43: Minor expenses (Gastos Menores)
        E44: Special regimes (Regímenes Especiales)
        E45: Governmental (Gubernamental)
        E46: Exports (Exportaciones)
        E47: Payments abroad (Pagos al Exterior)
    """

    E31 = "E31"
    E32 = "E32"
    E33 = "E33"
    E34 = "E34"
    E41 = "E41"
    E43 = "E43"
    E44 = "E44"
    E45 = "E45"
    E46 = "E46"
    E47 = "E47"


class CertificationTestItem(DGMaxBaseModel):
    """A single test item in a certification test suite.

    Attributes:
        test_type: The type of document to test
        count: Number of documents to generate for this type
    """

    test_type: CertificationTestType
    count: int = Field(default=1, ge=1)


class CertificationTestSuiteCreate(DGMaxBaseModel):
    """Request model for creating a certification test suite.

    Attributes:
        company_id: Company to create test suite for
        test_items: List of test items to include
        start_sequence: Starting sequence number for documents
    """

    company_id: str
    test_items: list[CertificationTestItem]
    start_sequence: int = Field(default=1, ge=1)


class AcceptPostulationRequest(DGMaxBaseModel):
    """Request model for accepting postulation (TEST -> CERT).

    Attributes:
        signed_xml: The signed postulation XML from DGII portal
        security_code: Security code from DGII portal
    """

    signed_xml: str
    security_code: str


class AcceptDeclarationRequest(DGMaxBaseModel):
    """Request model for accepting declaration (CERT -> PRD).

    Attributes:
        signed_xml: The signed declaration XML from DGII portal
        security_code: Security code from DGII portal
    """

    signed_xml: str
    security_code: str


class ProviderInfo(DGMaxBaseModel):
    """Provider information for DGII portal registration.

    Attributes:
        rnc: Provider RNC
        name: Provider legal name
        trade_name: Provider commercial name
    """

    rnc: str
    name: str
    trade_name: str


class CertificationProviderInfoResponse(DGMaxBaseModel):
    """Response model for provider info endpoint.

    Attributes:
        provider: Provider information
    """

    provider: ProviderInfo


class DocumentStatusSummary(DGMaxBaseModel):
    """Summary of document status counts in a test suite.

    Attributes:
        pending: Number of pending documents
        in_progress: Number of in-progress documents
        completed: Number of completed documents
        failed: Number of failed documents
    """

    pending: int = 0
    in_progress: int = 0
    completed: int = 0
    failed: int = 0


class CertificationTestCasePublic(DGMaxBaseModel):
    """Public representation of a certification test case.

    Attributes:
        id: Test case identifier
        test_type: Type of document being tested
        sequence_number: Sequence number for the document
        status: Current status of the test case
        electronic_document_id: ID of the generated document (if created)
        error_message: Error message if test failed
        created_at: When the test case was created
        updated_at: When the test case was last updated
    """

    id: str
    test_type: CertificationTestType
    sequence_number: int
    status: str
    electronic_document_id: str | None = None
    error_message: str | None = None
    created_at: datetime
    updated_at: datetime


class CertificationTestSuitePublic(DGMaxBaseModel):
    """Public representation of a certification test suite.

    Attributes:
        id: Test suite identifier
        company_id: Company the test suite belongs to
        status: Current status of the test suite
        status_summary: Summary of document statuses
        test_cases: List of test cases in the suite
        created_at: When the test suite was created
        updated_at: When the test suite was last updated
    """

    id: str
    company_id: str
    status: TestSuiteStatus
    status_summary: DocumentStatusSummary
    test_cases: list[CertificationTestCasePublic] = Field(default_factory=list)
    created_at: datetime
    updated_at: datetime


class XMLSigningResponse(DGMaxBaseModel):
    """Response model for XML signing operations.

    Attributes:
        signed_xml: The signed XML content
        filename: Original filename
    """

    signed_xml: str
    filename: str


class EnvironmentSwitchResponse(DGMaxBaseModel):
    """Response model for environment switch operations.

    Attributes:
        success: Whether the operation succeeded
        new_environment: The new DGII environment
        message: Status message
    """

    success: bool
    new_environment: str
    message: str
