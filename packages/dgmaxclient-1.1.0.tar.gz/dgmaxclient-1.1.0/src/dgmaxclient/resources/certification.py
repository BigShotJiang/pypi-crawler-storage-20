"""
Certification resource for the DGMax client.

This module provides the resource class for certification workflow operations,
including test suite management and provider info retrieval.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from dgmaxclient.models.certification import (
    CertificationProviderInfoResponse,
    CertificationTestItem,
    CertificationTestSuitePublic,
)
from dgmaxclient.retrying import retry_request

if TYPE_CHECKING:
    from dgmaxclient.client import DGMaxClient


class CertificationResource:
    """Resource for certification workflow operations.

    Provides methods for managing the DGII certification process,
    including test suite creation and provider info retrieval.

    Examples:
        >>> # Get provider info for DGII portal registration
        >>> info = client.certification.get_provider_info()
        >>> print(f"Provider: {info.provider.name} ({info.provider.rnc})")

        >>> # Create a test suite for certification
        >>> suite = client.certification.create_test_suite(
        ...     company_id="company-uuid",
        ...     test_items=[
        ...         CertificationTestItem(test_type="E31", count=2),
        ...         CertificationTestItem(test_type="E32", count=3),
        ...     ],
        ...     start_sequence=1
        ... )
        >>> print(f"Test suite created: {suite.id}")

        >>> # Get test suite status
        >>> suite = client.certification.get_test_suite("suite-uuid")
        >>> print(f"Status: {suite.status}")
    """

    def __init__(self, client: DGMaxClient) -> None:
        """Initialize the certification resource.

        Args:
            client: The DGMax client instance
        """
        self.client = client

    @retry_request
    def get_provider_info(self) -> CertificationProviderInfoResponse:
        """Get provider information for DGII portal registration.

        Returns provider details needed when registering with the DGII
        portal for the certification process.

        Returns:
            CertificationProviderInfoResponse with provider details

        Examples:
            >>> info = client.certification.get_provider_info()
            >>> print(f"RNC: {info.provider.rnc}")
            >>> print(f"Name: {info.provider.name}")
        """
        endpoint = self.client.endpoints.certification_provider_info
        response = self.client.get(endpoint)
        return CertificationProviderInfoResponse(**response)

    @retry_request
    def create_test_suite(
        self,
        company_id: str,
        test_items: list[dict[str, Any] | CertificationTestItem],
        start_sequence: int = 1,
    ) -> CertificationTestSuitePublic:
        """Create a certification test suite.

        Creates a test suite with the specified test items for the
        DGII certification process. The test suite will generate
        the required documents for each test type.

        Args:
            company_id: The company to create the test suite for
            test_items: List of test items (type and count)
            start_sequence: Starting sequence number for documents

        Returns:
            CertificationTestSuitePublic with the created test suite

        Examples:
            >>> # Using CertificationTestItem models
            >>> suite = client.certification.create_test_suite(
            ...     company_id="company-uuid",
            ...     test_items=[
            ...         CertificationTestItem(test_type="E31", count=2),
            ...         CertificationTestItem(test_type="E32", count=3),
            ...     ],
            ...     start_sequence=100
            ... )

            >>> # Using dicts
            >>> suite = client.certification.create_test_suite(
            ...     company_id="company-uuid",
            ...     test_items=[
            ...         {"test_type": "E31", "count": 2},
            ...         {"test_type": "E32", "count": 3},
            ...     ]
            ... )
        """
        endpoint = self.client.endpoints.certification_test_suites

        # Convert CertificationTestItem models to dicts if needed
        items = []
        for item in test_items:
            if hasattr(item, "model_dump"):
                items.append(item.model_dump())
            else:
                items.append(item)

        payload = {
            "company_id": company_id,
            "test_items": items,
            "start_sequence": start_sequence,
        }

        response = self.client.post(endpoint, json=payload)
        return CertificationTestSuitePublic(**response)

    @retry_request
    def get_test_suite(self, suite_id: str) -> CertificationTestSuitePublic:
        """Get a certification test suite by ID.

        Args:
            suite_id: The test suite identifier

        Returns:
            CertificationTestSuitePublic with the test suite details

        Examples:
            >>> suite = client.certification.get_test_suite("suite-uuid")
            >>> print(f"Status: {suite.status}")
            >>> print(f"Completed: {suite.status_summary.completed}")
        """
        endpoint = f"{self.client.endpoints.certification_test_suites}/{suite_id}"
        response = self.client.get(endpoint)
        return CertificationTestSuitePublic(**response)
