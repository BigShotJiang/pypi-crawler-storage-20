"""sageLLM Control Plane - Intelligent request routing and scheduling.

The Control Plane sits between users and LLM execution instances, providing:
- Intelligent request routing and load balancing
- Advanced scheduling policies (priority, SLO-aware, cost-optimized)
- Engine lifecycle management (spawn, stop, health check)
- Performance monitoring and adaptive optimization

Quick Start:
    from sagellm_control import ControlPlaneManager, MockControlPlane

    # Mock mode (no GPU required)
    cp = MockControlPlane()
    cp.register_engine("engine-001", model_id="mock", host="localhost", port=8000)
    target = cp.route_request(model_id="mock")

    # Execute request (with Protocol types)
    from sagellm_protocol import Request
    request = Request(
        request_id="req-001",
        trace_id="trace-001",
        model="mock",
        prompt="Hello",
        max_tokens=100,
        stream=False,
    )
    response = await cp.execute_request(request)
"""

from __future__ import annotations

__version__ = "0.1.0.4"

from sagellm_control.engine_client import (
    ClientConfig,
    EngineClient,
    EngineClientError,
    EngineRequestError,
    EngineTimeoutError,
    EngineUnavailableError,
    MockEngineClient,
    RequestContext,
    RetryPolicy,
)
from sagellm_control.lifecycle import EngineLifecycleManager
from sagellm_control.local_engine_client import LocalEngineClient
from sagellm_control.manager import ControlPlaneManager
from sagellm_control.mock import MockControlPlane, MockLifecycleManager, MockRouter
from sagellm_control.policies import (
    AdaptivePolicy,
    FIFOPolicy,
    PriorityPolicy,
    SchedulingPolicy,
    SLOAwarePolicy,
)
from sagellm_control.router import LoadBalancer, RequestRouter
from sagellm_control.types import (
    EngineInfo,
    EngineState,
    RequestPriority,
    RequestStatus,
    RequestType,
    SchedulingDecision,
)

__all__ = [
    "__version__",
    # Types
    "EngineInfo",
    "EngineState",
    "RequestPriority",
    "RequestStatus",
    "RequestType",
    "SchedulingDecision",
    # Manager
    "ControlPlaneManager",
    # Router
    "LoadBalancer",
    "RequestRouter",
    # Lifecycle
    "EngineLifecycleManager",
    # Policies
    "SchedulingPolicy",
    "FIFOPolicy",
    "PriorityPolicy",
    "SLOAwarePolicy",
    "AdaptivePolicy",
    # Engine Client
    "EngineClient",
    "LocalEngineClient",
    "MockEngineClient",
    "ClientConfig",
    "RequestContext",
    "RetryPolicy",
    "EngineClientError",
    "EngineTimeoutError",
    "EngineUnavailableError",
    "EngineRequestError",
    # Mock (for testing)
    "MockControlPlane",
    "MockRouter",
    "MockLifecycleManager",
]
