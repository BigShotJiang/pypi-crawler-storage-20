"""Batteries-included ArviZ plots."""

from .autocorr_plot import plot_autocorr
from .bf_plot import plot_bf
from .combine import combine_plots
from .compare_plot import plot_compare
from .convergence_dist_plot import plot_convergence_dist
from .dgof_dist_plot import plot_dgof_dist
from .dgof_plot import plot_dgof
from .dist_plot import plot_dist
from .ecdf_plot import plot_ecdf_pit
from .energy_plot import plot_energy
from .ess_plot import plot_ess
from .evolution_plot import plot_ess_evolution
from .forest_plot import plot_forest
from .khat_plot import plot_khat
from .lm_plot import plot_lm
from .loo_pit_plot import plot_loo_pit
from .mcse_plot import plot_mcse
from .pair_focus_plot import plot_pair_focus
from .pair_plot import plot_pair
from .parallel_plot import plot_parallel
from .pava_calibration_plot import plot_ppc_pava
from .pava_residual_plot import plot_ppc_pava_residuals
from .ppc_censored_plot import plot_ppc_censored
from .ppc_dist_plot import plot_ppc_dist
from .ppc_interval_plot import plot_ppc_interval
from .ppc_pit_plot import plot_ppc_pit
from .ppc_rootogram_plot import plot_ppc_rootogram
from .ppc_tstat import plot_ppc_tstat
from .prior_posterior_plot import plot_prior_posterior
from .psense_dist_plot import plot_psense_dist
from .psense_quantities_plot import plot_psense_quantities
from .rank_dist_plot import plot_rank_dist
from .rank_plot import plot_rank
from .ridge_plot import plot_ridge
from .trace_dist_plot import plot_trace_dist
from .trace_plot import plot_trace
from .utils import add_bands, add_lines

__all__ = [
    "combine_plots",
    "plot_autocorr",
    "plot_bf",
    "plot_compare",
    "plot_convergence_dist",
    "plot_dgof",
    "plot_dgof_dist",
    "plot_dist",
    "plot_forest",
    "plot_trace",
    "plot_trace_dist",
    "plot_ecdf_pit",
    "plot_energy",
    "plot_ess",
    "plot_ess_evolution",
    "plot_khat",
    "plot_loo_pit",
    "plot_mcse",
    "plot_pair",
    "plot_pair_focus",
    "plot_parallel",
    "plot_ppc_censored",
    "plot_ppc_dist",
    "plot_ppc_interval",
    "plot_ppc_rootogram",
    "plot_prior_posterior",
    "plot_rank",
    "plot_rank_dist",
    "plot_ridge",
    "plot_ppc_pava",
    "plot_ppc_pava_residuals",
    "plot_ppc_pit",
    "plot_ppc_tstat",
    "plot_psense_dist",
    "plot_psense_quantities",
    "add_lines",
    "add_bands",
    "plot_lm",
]
