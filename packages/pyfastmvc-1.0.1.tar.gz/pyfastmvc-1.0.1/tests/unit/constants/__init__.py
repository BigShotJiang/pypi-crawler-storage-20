"""Tests for constants module."""

