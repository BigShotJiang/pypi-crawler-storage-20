"""Tests for errors module."""

