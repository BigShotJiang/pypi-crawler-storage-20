"""Tests for DTOs module."""

