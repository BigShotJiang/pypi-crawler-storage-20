"""Tests for dependencies module."""

