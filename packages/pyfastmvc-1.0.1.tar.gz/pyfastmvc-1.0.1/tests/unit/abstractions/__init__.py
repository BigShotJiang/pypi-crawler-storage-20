"""Tests for abstractions module."""

