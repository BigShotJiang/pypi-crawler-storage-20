"""Tests for configurations module."""

