# English lexemes ai_assistant.py
lexemes = {
    # AI assistant dialog
    "dialog_title": "Ask the AI",
    "dialog_prompt_input_placeholder_text": "Prompt",
    "dialog_prompt_input_accessible_description": "Input request to give a context to the AI-assistant",
    "dialog_response_output_placeholder_text": "Response data",
    "dialog_response_output_accessible_description": "Response data will appear at this field",
    "dialog_response_output_notice_empty_text": "Provide a text input to get a response of about...",

    "dialog_usage_module_label": "MODULE",
    "dialog_usage_model_label": "MODEL",
    "dialog_usage_tokens_label": "TOKENS",
    "dialog_usage_tokens_prompt": "prompt: {tokens}",
    "dialog_usage_tokens_answer": "answer: {tokens}",
    "dialog_usage_tokens_total": "total: {tokens}",

    "dialog_button_send_request": "Ask",
    "dialog_button_stop_request": "Stop",
    "dialog_button_save_history": "Save dialog history",

    "dialog_message_copy_tooltip": "Copy text",
    "dialog_message_copied_tooltip": "Copied",

    "dialog_prompt_history_file_header": "# Ai Assistant [{datetime}]",

    "dialog_error_loading_model": "Error loading custom model",
}
