# SecureX Anti-Nuke SDK

**Backend-only Discord anti-nuke protection.** You provide the UI, we provide the security logic.

## Installation

```bash
pip install securex-antinuke
```

## Quick Start

```python
import discord
from discord.ext import commands
from securex import SecureX

bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())
sx = SecureX(bot)

# Enable protection
await sx.enable(whitelist=[123456789])

# Register callback - you build your own UI!
@sx.on_threat_detected
async def alert(threat):
    # threat.type, threat.actor_id, threat.prevented, etc.
    await channel.send(f"⚠️ Threat: {threat.type}")

bot.run("TOKEN")
```

## Features

✅ **Channel Protection** - Detects & restores unauthorized channel changes  
✅ **Role Protection** - Detects & restores unauthorized role changes  
✅ **Member Protection** - Blocks unauthorized bots, bans, kicks  
✅ **Webhook Protection** - Removes spam webhooks  
✅ **Auto-Backup** - Automatic server backups  
✅ **Whitelist System** - Manage authorized users  
✅ **Role Position Monitoring** - 5-second checks with bulk restore (NEW in v1.2!)  
❌ **No UI** - You decide how to present data!

## Data Objects

All callbacks receive **pure data objects** (no Discord embeds):

### ThreatEvent
```python
@dataclass
class ThreatEvent:
    type: str          # "channel_delete", "role_create", etc.
    guild_id: int
    actor_id: int      # Who did it
    target_id: int     # What was affected
    target_name: str
    prevented: bool    # Was it stopped?
    restored: bool     # Was it restored?
    timestamp: datetime
    details: dict      # Additional context
```

## Examples

### Custom Embed UI
```python
@sx.on_threat_detected
async def custom_alert(threat):
    embed = discord.Embed(
        title="🚨 Security Alert",
        description=f"Detected: {threat.type}"
    )
    embed.add_field(name="User", value=f"<@{threat.actor_id}>")
    await log_channel.send(embed=embed)
```

### Webhook Integration
```python
@sx.on_threat_detected
async def send_webhook(threat):
    await webhook.send(threat.to_json())
```

### Multi-Output
```python
@sx.on_threat_detected
async def handle(threat):
    # Send to Discord
    await channel.send(f"Threat: {threat.type}")
    
    # Log to database
    await db.insert(threat.to_dict())
    
    # Send to external API
    await api.post("/alerts", threat.to_json())
```

## API Reference

### Main Client

```python
sx = SecureX(bot, backup_dir=Path("./backups"))
```

### Methods

```python
await sx.enable(whitelist=[...], auto_backup=True, role_position_monitoring=True)
await sx.create_backup(guild_id)
await sx.get_recent_threats(guild_id, limit=10)
```

### Whitelist

```python
await sx.whitelist.add(guild_id, user_id)
await sx.whitelist.remove(guild_id, user_id)
users = await sx.whitelist.get_all(guild_id)
```

### Callbacks

```python
@sx.on_threat_detected       # ThreatEvent
@sx.on_backup_completed      # BackupInfo
@sx.on_restore_completed     # RestoreResult
@sx.on_whitelist_changed     # WhitelistChange
```

## Why SDK?

- 🎨 **Full UI Control** - Design your own embeds, dashboards, webhooks
- 📦 **Easy Integration** - Just `pip install` and import
- 🔒 **Battle-Tested Logic** - Proven anti-nuke protection
- 🚀 **No Boilerplate** - We handle the complex stuff
- 💰 **Reusable** - Use across multiple projects

## License

MIT License - see LICENSE file

## Support

- GitHub: [github.com/yourusername/securex-antinuke](https://github.com/yourusername/securex-antinuke)
- Issues: [Report a bug](https://github.com/yourusername/securex-antinuke/issues)

---

Made with ❤️ by SecureX Team
