"""
Whitelist management for SecureX SDK.
Strictly per-guild - no cross-server whitelisting.
"""
import json
from pathlib import Path
from typing import List, Set
from ..models import WhitelistChange


class WhitelistManager:
    """Manages whitelisted users per guild (guild-specific only)"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.data_dir = Path("./data/whitelists")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # In-memory cache (per-guild only)
        self._whitelists: dict[int, Set[int]] = {}
    
    def _get_file_path(self, guild_id: int) -> Path:
        """Get whitelist file path for guild"""
        return self.data_dir / f"{guild_id}.json"
    
    async def _load_whitelist(self, guild_id: int):
        """Load whitelist from file"""
        file_path = self._get_file_path(guild_id)
        if file_path.exists():
            with open(file_path, 'r') as f:
                data = json.load(f)
                self._whitelists[guild_id] = set(data.get('users', []))
    
    async def _save_whitelist(self, guild_id: int):
        """Save whitelist to file"""
        file_path = self._get_file_path(guild_id)
        with open(file_path, 'w') as f:
            json.dump({
                'users': list(self._whitelists.get(guild_id, set()))
            }, f, indent=2)
    
    async def add(self, guild_id: int, user_id: int, moderator_id: int = None):
        """Add user to guild whitelist"""
        if guild_id not in self._whitelists:
            await self._load_whitelist(guild_id)
            if guild_id not in self._whitelists:
                self._whitelists[guild_id] = set()
        
        self._whitelists[guild_id].add(user_id)
        await self._save_whitelist(guild_id)
        
        # Trigger callback
        change = WhitelistChange(
            guild_id=guild_id,
            user_id=user_id,
            action="added",
            moderator_id=moderator_id
        )
        await self.sdk._trigger_callbacks('whitelist_changed', change)
    
    async def remove(self, guild_id: int, user_id: int, moderator_id: int = None):
        """Remove user from guild whitelist"""
        if guild_id not in self._whitelists:
            await self._load_whitelist(guild_id)
        
        if guild_id in self._whitelists:
            self._whitelists[guild_id].discard(user_id)
            await self._save_whitelist(guild_id)
            
            # Trigger callback
            change = WhitelistChange(
                guild_id=guild_id,
                user_id=user_id,
                action="removed",
                moderator_id=moderator_id
            )
            await self.sdk._trigger_callbacks('whitelist_changed', change)
    
    async def get_all(self, guild_id: int) -> List[int]:
        """Get all whitelisted users for guild"""
        if guild_id not in self._whitelists:
            await self._load_whitelist(guild_id)
        return list(self._whitelists.get(guild_id, set()))
    
    async def is_whitelisted(self, guild_id: int, user_id: int) -> bool:
        """Check if user is whitelisted in specific guild"""
        if guild_id not in self._whitelists:
            await self._load_whitelist(guild_id)
        
        return user_id in self._whitelists.get(guild_id, set())
    
    async def clear(self, guild_id: int):
        """Clear all whitelisted users for a guild"""
        self._whitelists[guild_id] = set()
        await self._save_whitelist(guild_id)

