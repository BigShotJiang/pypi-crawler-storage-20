# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# TODO: Remove below import when minimum supported Python version is 3.10
from __future__ import annotations

from langchain_postgres.v2.async_vectorstore import AsyncPGVectorStore


class AsyncPostgresVectorStore(AsyncPGVectorStore):
    """Google Cloud SQL for PostgreSQL Vector Store class"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
