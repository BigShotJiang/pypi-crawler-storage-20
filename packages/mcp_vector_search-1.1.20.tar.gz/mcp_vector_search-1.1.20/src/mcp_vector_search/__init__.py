"""MCP Vector Search - CLI-first semantic code search with MCP integration."""

__version__ = "1.1.20"
__build__ = "120"
__author__ = "Robert Matsuoka"
__email__ = "bob@matsuoka.com"

from .core.exceptions import MCPVectorSearchError

__all__ = ["MCPVectorSearchError", "__version__", "__build__"]
