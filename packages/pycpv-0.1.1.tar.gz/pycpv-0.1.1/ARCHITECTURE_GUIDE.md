# CPV Package - Visual Architecture & Flow Guide

## 🎯 High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    User Application Code                         │
│              (Training Scripts, Model Training)                  │
└────────────────────┬────────────────────────────────────────────┘
                     │ imports & uses
                     ▼
┌─────────────────────────────────────────────────────────────────┐
│                    CPV Package (cp_manage)                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  CPVConfig                                              │   │
│  │  ├─ setup_aws_profile()    ─────────┐                 │   │
│  │  ├─ setup_bitbucket_ssh()  ─────────┤── ~/.cpv/       │   │
│  │  ├─ validate_credentials() ─────────┤   config.json   │   │
│  │  └─ get_config()           ─────────┘                 │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  ModelsCheckpointsManage       DataCheckpointsManage   │   │
│  │  ├─ import_model_init()    ├─ import_data_init()       │   │
│  │  ├─ upload_checkpoint()    ├─ upload_checkpoint()      │   │
│  │  ├─ download_checkpoint()  ├─ download_checkpoint()    │   │
│  │  ├─ tag_checkpoint()       ├─ tag_checkpoint()         │   │
│  │  ├─ revert_checkpoint()    ├─ revert_checkpoint()      │   │
│  │  ├─ read_checkpoint_tag()  ├─ read_checkpoint_tag()    │   │
│  │  └─ get_metadata()         └─ get_metadata()           │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  CombinedCheckpointsManage                              │   │
│  │  ├─ tag_model_and_data()                                │   │
│  │  ├─ revert_model_and_data()                             │   │
│  │  └─ get_combined_metadata()                             │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  Data Models                                            │   │
│  │  ├─ ModelArtifacts        (model_path, metrics, tag)   │   │
│  │  └─ DataArtifacts         (data_path, version, tag)    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                   │
└────────────┬─────────────────────────┬──────────────────────────┘
             │ uses                    │ uses
             ▼                         ▼
    ┌─────────────────┐      ┌──────────────────┐
    │  Git + DVC      │      │  boto3 (AWS SDK) │
    │  (Python)       │      │  (Python)        │
    └────────┬────────┘      └────────┬─────────┘
             │                        │
             ▼                        ▼
    ┌─────────────────────────────────────────────┐
    │  Bitbucket (Remote Git Repositories)        │
    │  Stores: .git history, .dvc pointers        │
    │  Format: AI-Team/model/.git/                │
    └─────────────────────────────────────────────┘

    ┌─────────────────────────────────────────────┐
    │  AWS S3 (Large File Storage)                │
    │  Stores: model.bin, data/, metrics.log      │
    │  Format: s3://vmo-model-checkpoints/        │
    │           AI-Team/model/                    │
    └─────────────────────────────────────────────┘
```

---

## 📊 Data Flow Diagrams

### 1. Upload Checkpoint Flow

```
User Code
    │
    ├─ model.bin (trained model)
    ├─ metrics.json (performance data)
    └─ training metadata
         │
         ▼
┌──────────────────────────────────┐
│  mcm.upload_model_checkpoint()   │
│  ├─ Validate model file          │
│  ├─ Update metrics.log           │
│  └─ Call dvc add                 │
└──────────┬───────────────────────┘
           │
           ▼
    ┌─────────────────┐
    │  dvc add        │ ← Creates model.bin.dvc
    │  model.bin      │ ← Stores hash
    └────────┬────────┘
             │
             ▼
    ┌─────────────────────────┐
    │  dvc push               │ ← Uploads to S3
    │  (to remote S3)         │
    └────────┬────────────────┘
             │
             ▼
    ┌──────────────────────────────────────┐
    │  AWS S3                              │
    │  s3://vmo-model-checkpoints/         │
    │  └─ AI-Team/model/model.bin         │
    └──────────────────────────────────────┘
             │
             ▼ (also)
    ┌─────────────────────┐
    │  git add            │ ← Tracks pointer
    │  model.bin.dvc      │
    │  .gitignore         │
    └────────┬────────────┘
             │
             ▼
    ┌──────────────────────────────────────┐
    │  git commit                          │
    │  "Upload model checkpoint"           │
    └────────┬─────────────────────────────┘
             │
             ▼
    ┌──────────────────────────────────────┐
    │  Bitbucket (Remote)                  │
    │  .dvc files tracked in Git           │
    │  model.bin not tracked (in S3)       │
    └──────────────────────────────────────┘
             │
             ▼
┌──────────────────────────────────┐
│  mcm.tag_model_checkpoint()      │
│  ├─ Create git tag v1.0          │
│  ├─ Set tag message              │
│  └─ Push to Bitbucket            │
└──────────┬───────────────────────┘
           │
           ▼
    ┌──────────────────────────────────────┐
    │  Bitbucket Tags                      │
    │  v1.0 ──► commit hash                │
    │  v1.1 ──► commit hash                │
    │  ...                                 │
    └──────────────────────────────────────┘
```

### 2. Download Checkpoint Flow

```
User Code: mcm.download_model_checkpoint(tag="v1.0")
    │
    ▼
┌──────────────────────────────────┐
│  Git Checkout                    │
│  git checkout <tag>              │
└────────┬───────────────────────┘
         │
         ▼
    ┌─────────────────────────┐
    │  model.bin.dvc          │
    │  (pointer file)         │
    └────────┬────────────────┘
             │
             ▼
    ┌──────────────────────────────────────┐
    │  dvc pull                            │
    │  Reads model.bin.dvc                 │
    │  Downloads from S3                   │
    └────────┬─────────────────────────────┘
             │
             ▼
    ┌──────────────────────────────────────┐
    │  AWS S3                              │
    │  Fetch model.bin from remote         │
    └────────┬─────────────────────────────┘
             │
             ▼
    ┌──────────────────────────────────────┐
    │  Local Cache (.dvc/cache/)           │
    │  Store model.bin locally             │
    └────────┬─────────────────────────────┘
             │
             ▼
    ┌──────────────────────────────────────┐
    │  User Workspace                      │
    │  model.bin (actual file)             │
    │  metrics.log (loaded)                │
    └──────────────────────────────────────┘
             │
             ▼
    ┌──────────────────────────────────────┐
    │  Return ModelArtifacts               │
    │  ├─ model_path: "/path/model.bin"    │
    │  ├─ metrics: {...}                   │
    │  ├─ tag: "v1.0"                      │
    │  └─ size_mb: 1234.5                  │
    └──────────────────────────────────────┘
```

### 3. Atomic Tag Flow (Model + Data)

```
User Code: combined.tag_model_and_data(version_tag="v1.0")
    │
    ├─ Step 1: Tag Model
    │  ├─ dvc add model.bin
    │  ├─ git add model.bin.dvc
    │  ├─ git commit "..."
    │  └─ git tag v1.0
    │
    ├─ Step 2: Tag Data
    │  ├─ dvc add data/
    │  ├─ git add data.dvc
    │  └─ git commit "..."
    │
    └─ Step 3: Combined Tag
       ├─ Verify both commits
       ├─ Create combined tag
       └─ Push to Bitbucket
```

---

## 🔄 Operational Workflows

### Workflow 1: First-Time Setup

```
┌─────────────────────────────────────┐
│  1. Initialize CPVConfig            │
│     config = CPVConfig()            │
└────────────┬────────────────────────┘
             │
             ▼
┌─────────────────────────────────────┐
│  2. Setup AWS Credentials           │
│     config.setup_aws_profile(...)   │
│     → Saves to ~/.cpv/config.json   │
└────────────┬────────────────────────┘
             │
             ▼
┌─────────────────────────────────────┐
│  3. Setup Bitbucket SSH             │
│     config.setup_bitbucket_ssh(...) │
│     → Configures ~/.ssh/config      │
└────────────┬────────────────────────┘
             │
             ▼
┌─────────────────────────────────────┐
│  4. Validate Credentials            │
│     config.validate_credentials()   │
│     ✓ S3 accessible                 │
│     ✓ Bitbucket SSH working         │
└─────────────────────────────────────┘
```

### Workflow 2: Train & Version Model

```
┌─────────────────────────────────────┐
│  1. Initialize Model Repo           │
│     mcm = ModelsCheckpointsManage() │
│     mcm.import_model_init()         │
└────────────┬────────────────────────┘
             │
             ├─ Creates .git repo
             ├─ Creates .dvc config
             ├─ Creates model.bin
             ├─ Creates metrics.log
             └─ Creates train.py
             │
             ▼
┌─────────────────────────────────────┐
│  2. Train Model                     │
│     (Your training code)            │
│     → Updates model.bin             │
│     → Updates metrics.log           │
└────────────┬────────────────────────┘
             │
             ▼
┌─────────────────────────────────────┐
│  3. Upload Checkpoint               │
│     mcm.upload_model_checkpoint()   │
│     ├─ dvc add model.bin            │
│     ├─ git add *.dvc                │
│     └─ git commit                   │
└────────────┬────────────────────────┘
             │
             ▼
┌─────────────────────────────────────┐
│  4. Tag Version                     │
│     mcm.tag_model_checkpoint()      │
│     ├─ Auto-increment: v1.0         │
│     ├─ git tag v1.0                 │
│     └─ Push to Bitbucket            │
└──────────────────────────────────────┘
```

### Workflow 3: Retrieve Specific Version

```
┌──────────────────────────────────────┐
│  1. List Available Versions          │
│     versions = mcm.read_checkpoint_  │
│     tag()                            │
│     → ['v0.1', 'v1.0', 'v1.1']      │
└────────────┬─────────────────────────┘
             │
             ▼
┌──────────────────────────────────────┐
│  2. Download Specific Version        │
│     artifacts = mcm.download_model_  │
│     checkpoint(tag="v1.0")           │
│     ├─ git checkout v1.0             │
│     ├─ dvc pull                      │
│     └─ Load from S3                  │
└────────────┬─────────────────────────┘
             │
             ▼
┌──────────────────────────────────────┐
│  3. Use Model                        │
│     model = load(artifacts.model_    │
│     path)                            │
│     print(artifacts.metrics)         │
└──────────────────────────────────────┘
```

---

## 📦 Storage Organization

### Local Structure

```
~/projects/faster-whisper/
├── .git/                          ← Git repository
│   ├── objects/
│   ├── refs/
│   └── HEAD
├── .dvc/                          ← DVC configuration
│   ├── config                     ← S3 remote config
│   └── .gitignore
├── .dvc/cache/                    ← Local DVC cache
│   └── [large files]
├── data/                          ← Training data (tracked by DVC)
│   ├── train/
│   ├── validation/
│   └── test/
├── model.bin                      ← Model weights (tracked by DVC)
├── metrics.log                    ← Metrics file (tracked by DVC)
├── train.py                       ← Training script (tracked by Git)
├── README.md                      ← Documentation (tracked by Git)
├── .gitignore                     ← Ignore patterns
│
├── model.bin.dvc                  ← DVC pointer
│   └─ Contains: hash → S3 path
├── data.dvc                       ← DVC pointer
│   └─ Contains: hash → S3 path
└── metrics.log.dvc                ← DVC pointer
    └─ Contains: hash → S3 path
```

### Bitbucket Remote (Git)

```
Bitbucket Project: AI-Convo-model-checkpoints
├── faster-whisper (Repository)
│   ├── .git/refs/heads/master
│   ├── .git/refs/tags/
│   │   ├─ v0.1
│   │   ├─ v1.0
│   │   └─ v1.1
│   ├── model.bin.dvc              ← Git tracked
│   ├── data.dvc                   ← Git tracked
│   ├── metrics.log.dvc            ← Git tracked
│   ├── .gitignore                 ← Git tracked
│   ├── train.py                   ← Git tracked
│   └── README.md                  ← Git tracked
│
├── gpt-whisper (Repository)
│   └── ...
│
└── other-model/ (Repository)
    └── ...
```

### AWS S3 Storage

```
s3://vmo-model-checkpoints/
├── AI-Convo/
│   ├── faster-whisper/
│   │   ├── model.bin              ← v0.1 version
│   │   ├── model.bin.v1           ← v1.0 version
│   │   ├── model.bin.v2           ← v1.1 version
│   │   ├── data/                  ← Training data
│   │   │   ├── train/
│   │   │   ├── validation/
│   │   │   └── test/
│   │   └── metrics.log            ← Metrics log
│   │
│   └── gpt-whisper/
│       └── ...
│
├── AI-Vision/
│   ├── yolov8/
│   └── efficientnet/
│
└── AI-NLP/
    ├── bert-large/
    └── t5-base/
```

---

## 🔐 Configuration Files

### ~/.cpv/config.json

```json
{
  "aws_credential_path": "/home/user/.aws/credentials",
  "aws_profile": "default",
  "bitbucket_ssh_keyfile": "/home/user/.ssh/id_rsa_bitbucket",
  "last_updated": "2026-01-10T15:30:00.000000"
}
```

### ~/.ssh/config

```
Host bitbucket.org
  Hostname altssh.bitbucket.org
  Port 443
  AddKeysToAgent yes
  IdentityFile ~/.ssh/id_rsa_bitbucket
  User git
```

### ~/.aws/credentials

```
[default]
aws_access_key_id = AKIAIOSFODNN7EXAMPLE
aws_secret_access_key = wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY

[profile-name]
aws_access_key_id = ...
aws_secret_access_key = ...
```

---

## 🎯 Class Relationships

```
┌──────────────────────┐
│    CPVConfig         │
├──────────────────────┤
│ - AWS setup          │
│ - SSH setup          │
│ - Credentials        │
└──────────────────────┘
         ▲
         │
    ┌────┴─────────────────┬──────────────────┐
    │                      │                  │
    ▼                      ▼                  ▼
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│ Models           │  │ Data             │  │ Combined         │
│ Checkpoints      │  │ Checkpoints      │  │ Checkpoints      │
├──────────────────┤  ├──────────────────┤  ├──────────────────┤
│ - Upload         │  │ - Upload         │  │ - Atomic tag     │
│ - Download       │  │ - Download       │  │ - Atomic revert  │
│ - Tag            │  │ - Tag            │  │ - Combined meta  │
│ - Revert         │  │ - Revert         │  │                  │
│ - Metadata       │  │ - Metadata       │  │ Uses both:       │
└──────────────────┘  └──────────────────┘  │ ├─ Models        │
         │                   │               │ └─ Data          │
         └───────────────────┼───────────────┘
                             │
                    ┌────────┴────────┐
                    │                 │
                    ▼                 ▼
            ┌──────────────┐  ┌──────────────┐
            │   Git (dvc)  │  │   AWS S3     │
            ├──────────────┤  ├──────────────┤
            │ Versioning   │  │ Storage      │
            │ History      │  │ Backups      │
            └──────────────┘  └──────────────┘
```

---

## 📈 Version Tagging Timeline

```
Initial State:  No tags
                │
                ▼
              v0.1  ← First model
                │
                ├─ Training iteration 1
                ▼
              v0.2  ← Minor improvement
                │
                ├─ Architecture change
                ▼
              v1.0  ← Major release
                │
                ├─ Fine-tuning
                ▼
              v1.1  ← Incremental improvement
                │
                ├─ Large dataset update
                ▼
              v2.0  ← Next major version
                │
                ...

Each tag points to:
├─ Specific Git commit (code + .dvc pointers)
├─ Specific model binary in S3
├─ Specific training data in S3
└─ Specific metrics at that time
```

---

## 🔍 Method Call Hierarchy

```
User Code
    │
    ├─ CPVConfig.setup_aws_profile()
    │  └─ Saves config to disk
    │
    ├─ CPVConfig.setup_bitbucket_ssh()
    │  └─ Configures SSH
    │
    ├─ ModelsCheckpointsManage.__init__()
    │  └─ Loads config, initializes repo
    │
    ├─ ModelsCheckpointsManage.import_model_init()
    │  ├─ _create_local_structure()
    │  ├─ _init_git_repo()
    │  ├─ _init_dvc()
    │  └─ _create_s3_location()
    │
    ├─ ModelsCheckpointsManage.upload_model_checkpoint()
    │  ├─ _update_metrics()
    │  ├─ subprocess.run(['dvc', 'add', ...])
    │  ├─ git_repo.index.add()
    │  ├─ git_repo.index.commit()
    │  └─ subprocess.run(['dvc', 'push'])
    │
    ├─ ModelsCheckpointsManage.tag_model_checkpoint()
    │  ├─ _get_next_version()
    │  └─ git_repo.create_tag()
    │
    ├─ ModelsCheckpointsManage.download_model_checkpoint()
    │  ├─ _checkout_tag()
    │  ├─ subprocess.run(['dvc', 'pull'])
    │  ├─ _read_metrics()
    │  └─ Return ModelArtifacts()
    │
    └─ CombinedCheckpointsManage.tag_model_and_data()
       ├─ models.tag_model_checkpoint()
       └─ data.tag_data_checkpoint()
```

---

This visual guide should help understand the complete CPV architecture, data flows, and workflows at a glance.
