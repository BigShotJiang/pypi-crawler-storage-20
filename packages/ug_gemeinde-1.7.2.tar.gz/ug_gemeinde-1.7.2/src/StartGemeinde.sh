#!/bin/bash
XMODIFIERS=@im=none python3 -m ug_gemeinde.Gemeinde "$@"
