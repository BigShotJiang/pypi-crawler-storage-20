"""Integration tests for Chronos logging.

Tests that run_agent automatically pushes logs and uploads artifacts
to a Chronos server when logging is initialized.

Run with:
    GEMINI_API_KEY=... pytest tests/integration/test_chronos_callback.py -v -s
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import subprocess
import tempfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread

import pytest


def _cleanup_docker_dir(path: str) -> None:
    """Clean up directory that may contain root-owned files from Docker."""
    try:
        shutil.rmtree(path)
    except PermissionError:
        subprocess.run(["sudo", "rm", "-rf", path], check=False)


class MockChronosHandler(BaseHTTPRequestHandler):
    """HTTP handler that captures Chronos callbacks."""

    # Class-level storage for received requests
    received_requests: list[dict] = []

    def log_message(self, format, *args):
        """Suppress HTTP server logs."""
        pass

    def do_POST(self):
        """Handle POST requests."""
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)

        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            data = {"raw": body.decode()}

        # Store the request
        MockChronosHandler.received_requests.append(
            {
                "path": self.path,
                "data": data,
            }
        )

        # Send success response
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()

        # Return appropriate response based on endpoint
        # The logging module uses /event for events and /logs-upload for artifacts
        if self.path == "/event":
            response = {"success": True, "event_id": data.get("event_id", "generated-id")}
        elif self.path == "/logs-upload":
            response = {"success": True, "logs_url": "s3://test-bucket/logs.zip"}
        else:
            response = {"success": True}

        self.wfile.write(json.dumps(response).encode())


@pytest.fixture
def mock_callback_url():
    """Start a mock Chronos HTTP server."""
    # Clear any previous requests
    MockChronosHandler.received_requests = []

    # Find a free port
    server = HTTPServer(("127.0.0.1", 0), MockChronosHandler)
    port = server.server_address[1]

    # Run server in background thread
    thread = Thread(target=server.serve_forever)
    thread.daemon = True
    thread.start()

    yield f"http://127.0.0.1:{port}"

    # Shutdown
    server.shutdown()


@pytest.fixture
def temp_workspace():
    """Create a temporary workspace directory."""
    tmpdir = tempfile.mkdtemp()
    test_file = os.path.join(tmpdir, "test.py")
    with open(test_file, "w") as f:
        f.write("# Test file\nprint('hello')\n")
    yield tmpdir
    _cleanup_docker_dir(tmpdir)


@pytest.fixture
def temp_logs_dir():
    """Create a temporary logs directory."""
    tmpdir = tempfile.mkdtemp()
    yield tmpdir
    _cleanup_docker_dir(tmpdir)


@pytest.fixture
def openhands_image():
    """OpenHands ECR image."""
    return "383806609161.dkr.ecr.us-west-1.amazonaws.com/agents/plato/openhands:1.0.7"


@pytest.fixture
def openhands_config():
    """OpenHands agent config."""
    return {"model_name": "gemini/gemini-3-flash-preview"}


@pytest.fixture
def secrets():
    """Secrets from environment."""
    gemini_key = os.environ.get("GEMINI_API_KEY", "")
    if gemini_key:
        return {"gemini_api_key": gemini_key}

    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if anthropic_key:
        return {"anthropic_api_key": anthropic_key}

    pytest.skip("GEMINI_API_KEY or ANTHROPIC_API_KEY not set")
    return {}


class TestChronosCallback:
    """Test run_agent Chronos callback integration."""

    @pytest.mark.asyncio
    async def test_run_agent_with_chronos_callbacks(
        self,
        mock_callback_url: str,
        temp_workspace: str,
        temp_logs_dir: str,
        openhands_image: str,
        openhands_config: dict,
        secrets: dict,
    ):
        """Test that run_agent automatically sends callbacks to Chronos."""
        from plato.agents import init_logging, reset_logging, run_agent

        session_id = "test-session-123"
        instruction = "Create a file called hello.txt with 'hello' in it."

        # Initialize logging before running the agent
        reset_logging()
        init_logging(
            callback_url=mock_callback_url,
            session_id=session_id,
        )

        await run_agent(
            image=openhands_image,
            config=openhands_config,
            secrets=secrets,
            instruction=instruction,
            workspace=temp_workspace,
            logs_dir=temp_logs_dir,
            pull=False,
        )

        # Give a moment for final callbacks to complete
        await asyncio.sleep(0.5)

        # Verify callbacks were received
        requests = MockChronosHandler.received_requests
        print(f"\nReceived {len(requests)} callback requests:")
        for req in requests:
            print(f"  {req['path']}: {list(req['data'].keys())}")

        # Should have received at least:
        # 1. Trajectory event
        # 2. Logs upload
        assert len(requests) >= 1, f"Expected at least 1 request, got {len(requests)}"

        # Check for event callbacks (trajectory)
        event_requests = [r for r in requests if r["path"] == "/event"]

        # Verify session_id is correct in all requests
        for req in requests:
            assert req["data"].get("session_id") == session_id, (
                f"Expected session_id={session_id}, got {req['data'].get('session_id')}"
            )

        # Check for logs-upload callback
        upload_requests = [r for r in requests if r["path"] == "/logs-upload"]
        assert len(upload_requests) == 1, "Expected exactly one logs-upload callback"

        # Verify logs upload contains base64 data
        upload_data = upload_requests[0]["data"]
        assert "logs_base64" in upload_data, "Expected logs_base64 in upload"

        # Verify base64 data is valid
        import base64

        try:
            decoded = base64.b64decode(upload_data["logs_base64"])
            assert len(decoded) > 0, "Expected non-empty logs zip"
            print(f"\nLogs zip size: {len(decoded)} bytes")
        except Exception as e:
            pytest.fail(f"Invalid base64 logs data: {e}")

        # Cleanup logging
        reset_logging()


class TestSpanContext:
    """Unit tests for SpanContext class using the singleton logging module."""

    @pytest.mark.asyncio
    async def test_span_creates_event_id(self, mock_callback_url: str):
        """Test that entering a span creates an event ID."""
        from plato.agents import init_logging, reset_logging, span

        reset_logging()
        init_logging(
            callback_url=mock_callback_url,
            session_id="test-session",
        )

        async with span("test_operation") as s:
            assert s.event_id is not None
            assert len(s.event_id) > 0

        reset_logging()

    @pytest.mark.asyncio
    async def test_span_logs_start_and_end(self, mock_callback_url: str):
        """Test that span logs both start and end events."""
        from plato.agents import init_logging, reset_logging, span

        # Clear any previous requests
        MockChronosHandler.received_requests = []
        reset_logging()

        init_logging(
            callback_url=mock_callback_url,
            session_id="test-session",
        )

        async with span("my_operation"):
            pass

        # Wait for async operations
        await asyncio.sleep(0.1)

        # Should have received 2 events (start and end)
        event_requests = [r for r in MockChronosHandler.received_requests if r["path"] == "/event"]
        assert len(event_requests) >= 2, f"Expected at least 2 event requests, got {len(event_requests)}"

        # Check that we have start and completed events
        contents = [r["data"].get("content", "") for r in event_requests]
        assert any("started" in c for c in contents), "Expected a 'started' event"
        assert any("completed" in c for c in contents), "Expected a 'completed' event"

        reset_logging()

    @pytest.mark.asyncio
    async def test_span_logs_failure_on_exception(self, mock_callback_url: str):
        """Test that span logs failure when exception occurs."""
        from plato.agents import init_logging, reset_logging, span

        MockChronosHandler.received_requests = []
        reset_logging()

        init_logging(
            callback_url=mock_callback_url,
            session_id="test-session",
        )

        with pytest.raises(ValueError):
            async with span("failing_operation"):
                raise ValueError("Test error")

        await asyncio.sleep(0.1)

        event_requests = [r for r in MockChronosHandler.received_requests if r["path"] == "/event"]
        contents = [r["data"].get("content", "") for r in event_requests]
        assert any("failed" in c for c in contents), "Expected a 'failed' event"

        reset_logging()

    @pytest.mark.asyncio
    async def test_nested_spans_have_correct_parent(self, mock_callback_url: str):
        """Test that nested spans correctly set parent IDs."""
        from plato.agents import init_logging, reset_logging, span

        MockChronosHandler.received_requests = []
        reset_logging()

        init_logging(
            callback_url=mock_callback_url,
            session_id="test-session",
            parent_event_id="root-step-id",
        )

        async with span("outer") as outer:
            outer_id = outer.event_id
            async with span("inner") as inner:
                inner_id = inner.event_id

        await asyncio.sleep(0.1)

        # Find the inner span's start event
        event_requests = [r for r in MockChronosHandler.received_requests if r["path"] == "/event"]
        inner_start = next(
            (
                r
                for r in event_requests
                if r["data"].get("event_id") == inner_id and "started" in r["data"].get("content", "")
            ),
            None,
        )

        # Inner span's parent should be the outer span
        assert inner_start is not None, "Expected to find inner span start event"
        assert inner_start["data"].get("parent_id") == outer_id, (
            f"Expected inner span parent to be {outer_id}, got {inner_start['data'].get('parent_id')}"
        )

        reset_logging()

    @pytest.mark.asyncio
    async def test_span_log_and_set_extra(self, mock_callback_url: str):
        """Test span.log() and span.set_extra() methods."""
        from plato.agents import init_logging, reset_logging, span

        MockChronosHandler.received_requests = []
        reset_logging()

        init_logging(
            callback_url=mock_callback_url,
            session_id="test-session",
        )

        async with span("operation") as s:
            s.log("Step 1 complete")
            s.log("Step 2 complete")
            s.set_extra({"result": "success"})

        await asyncio.sleep(0.1)

        # Find the completed event
        event_requests = [r for r in MockChronosHandler.received_requests if r["path"] == "/event"]
        completed_event = next(
            (r for r in event_requests if "completed" in r["data"].get("content", "")),
            None,
        )

        assert completed_event is not None, "Expected completed event"
        extra = completed_event["data"].get("extra", {})
        assert "logs" in extra, "Expected logs in extra"
        assert len(extra["logs"]) == 2, "Expected 2 log messages"
        assert extra.get("result") == "success", "Expected result in extra"

        reset_logging()

    def test_span_returns_noop_when_not_initialized(self):
        """Test that span() returns a NoOp context when logging is not initialized."""
        from plato.agents import reset_logging, span
        from plato.agents.logging import _NoOpSpanContext

        reset_logging()

        s = span("test")
        assert isinstance(s, _NoOpSpanContext)


class TestLoggingUtils:
    """Tests for logging utility functions."""

    def test_zip_directory(self):
        """Test zip_directory creates valid zip."""
        import io
        import zipfile

        from plato.agents.logging import zip_directory

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create some files
            with open(os.path.join(tmpdir, "test.log"), "w") as f:
                f.write("test log content")
            os.makedirs(os.path.join(tmpdir, "subdir"))
            with open(os.path.join(tmpdir, "subdir", "nested.log"), "w") as f:
                f.write("nested content")

            # Zip it
            zip_bytes = zip_directory(tmpdir)

            # Verify it's a valid zip
            zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
            names = zf.namelist()
            assert "test.log" in names
            assert "subdir/nested.log" in names or "subdir\\nested.log" in names
