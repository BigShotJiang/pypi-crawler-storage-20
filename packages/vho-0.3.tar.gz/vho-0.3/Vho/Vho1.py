import torch
import os
import random
import imageio
from diffusers import (
    AnimateDiffPipeline,
    DPMSolverMultistepScheduler,
    MotionAdapter
)
from deep_translator import GoogleTranslator

# ===============================
# DEVICE
# ===============================
device = "cuda" if torch.cuda.is_available() else "cpu"
dtype = torch.float16 if device == "cuda" else torch.float32

# ===============================
# PROMPT MAP
# ===============================
TR_STYLE_MAP = {
    "gerçekçi": "realistic",
    "sinematik": "cinematic lighting",
    "anime": "anime style",
    "çizgi film": "cartoon style",
    "karanlık": "dark dramatic mood",
    "neon": "neon cyberpunk lighting",
    "portre": "portrait photography",
    "detaylı": "highly detailed",
    "fantastik": "fantasy art",
    "bilim kurgu": "science fiction",
    "minimal": "minimalist composition"
}

QUALITY_LOCK = (
    "masterpiece, ultra high quality, professional cinematic video, "
    "sharp focus, perfect lighting, high detail"
)

NEGATIVE_LOCK = (
    "low quality, blurry, jitter, flicker, distorted, "
    "bad anatomy, extra limbs, ugly, artifacts"
)

translator = GoogleTranslator(source="tr", target="en")

def _build_prompt(prompt_tr: str) -> str:
    translated = translator.translate(prompt_tr)
    styles = [
        en for tr, en in TR_STYLE_MAP.items()
        if tr in prompt_tr.lower()
    ]

    parts = [translated]
    if styles:
        parts.append(", ".join(styles))
    parts.append(QUALITY_LOCK)

    return ", ".join(parts)

# ===============================
# LOAD MOTION MODEL
# ===============================
motion_adapter = MotionAdapter.from_pretrained(
    "guoyww/animatediff-motion-adapter-v1-5",
    torch_dtype=dtype
)

pipe = AnimateDiffPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    motion_adapter=motion_adapter,
    torch_dtype=dtype,
    safety_checker=None
).to(device)

pipe.scheduler = DPMSolverMultistepScheduler.from_config(pipe.scheduler.config)
pipe.enable_attention_slicing()

# ===============================
# MAIN VIDEO FUNCTION
# ===============================
def create_video(
    prompt: str,
    seconds: int = 3,
    fps: int = 12,
    kalite: float = 7.5,
    cfg: float = 7.5,
    seed: int | None = None,
    filename: str = "output.mp4"
) -> str:

    if seed is None:
        seed = random.randint(0, 999999999)

    generator = torch.Generator(device=device).manual_seed(seed)

    frame_count = seconds * fps
    steps = int(20 + kalite * 2)

    final_prompt = _build_prompt(prompt)

    print(f"[INFO] Frames: {frame_count} | Seed: {seed}")

    video_frames = pipe(
        prompt=final_prompt,
        negative_prompt=NEGATIVE_LOCK,
        num_frames=frame_count,
        guidance_scale=float(cfg),
        num_inference_steps=steps,
        generator=generator
    ).frames[0]

    imageio.mimsave(
        filename,
        video_frames,
        fps=fps,
        codec="libx264",
        quality=8
    )

    return os.path.abspath(filename)