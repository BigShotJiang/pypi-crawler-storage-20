import setuptools

setuptools.setup(
    name='yandex-taxi-testsuite',
    install_requires=[
        'packaging',
        'PyYAML>=3.13',
        'aiohttp>=3.5.4',
        'yarl>=1.4.2,!=1.6',
        'py>=1.10',
        'pytest-aiohttp>=0.3.0',
        'pytest-asyncio!=0.22.*,!=0.23.*,!=0.24.*',
        'pytest>=4.5.0',
        'python-dateutil>=2.7.3',
        'cached-property>=1.5.1',
    ],
    extras_require={
        'mongodb': ['pymongo>=3.7.1'],
        'postgresql': ['psycopg2>=2.7.5', 'yandex-pgmigrate'],
        'postgresql-binary': ['psycopg2-binary>=2.7.5'],
        'clickhouse': ['clickhouse-driver>=0.2.0'],
        'redis': ['python-redis>=0.2.1', 'redis>=2.10.6'],
        'mysql': ['PyMySQL>=0.9.2'],
        'rabbitmq': ['aio-pika>=8.1.0'],
        'kafka': ['aiokafka>=0.9.0'],
    },
    setup_requires=['pytest-runner'],
    tests_require=['pytest'],
    packages=setuptools.find_packages(include=['testsuite', 'testsuite.*']),
    package_data={
        'testsuite.environment': ['scripts/*.sh'],
        'testsuite.databases.mongo': ['scripts/service-mongo'],
        'testsuite.databases.redis': [
            'configs/*.tpl',
            'scripts/service-redis',
            'scripts/service-cluster-redis',
            'scripts/service-standalone-redis',
        ],
        'testsuite.databases.mysql': [
            'scripts/mysql-helper',
            'scripts/service-mysql',
        ],
        'testsuite.databases.pgsql': [
            'configs/*.conf',
            'scripts/find-pg.sh',
            'scripts/pgmigrate-helper',
            'scripts/psql-helper',
            'scripts/service-postgresql',
        ],
        'testsuite.databases.clickhouse': [
            'scripts/service-clickhouse',
            'scripts/find-clickhouse.sh',
        ],
        'testsuite.databases.rabbitmq': [
            'scripts/service-rabbitmq',
            'scripts/find-rabbitmq.sh',
        ],
        'testsuite.databases.kafka': [
            'scripts/service-kafka',
            'scripts/find-kafka.sh',
        ],
    },
)
