"""Version information for llama-cpp-py-sync."""

__version__ = "0.7757"
__llama_cpp_commit__ = "c945aaaef"
__llama_cpp_tag__ = "b7757"
