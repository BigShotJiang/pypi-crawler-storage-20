"""Tests for WebSocket executor"""

