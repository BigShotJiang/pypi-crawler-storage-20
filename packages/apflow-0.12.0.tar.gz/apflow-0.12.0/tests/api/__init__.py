"""
API module tests
"""

