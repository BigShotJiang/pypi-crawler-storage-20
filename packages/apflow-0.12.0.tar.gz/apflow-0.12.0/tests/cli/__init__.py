"""
CLI tests for apflow
"""

