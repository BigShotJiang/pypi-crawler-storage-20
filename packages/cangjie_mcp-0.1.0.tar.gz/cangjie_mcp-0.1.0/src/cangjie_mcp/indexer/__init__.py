"""Document indexer module."""
