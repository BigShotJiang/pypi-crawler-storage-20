"""Tests for cangjie-mcp."""
