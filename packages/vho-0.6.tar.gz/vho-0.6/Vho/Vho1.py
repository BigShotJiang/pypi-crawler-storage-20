import torch
import os
import random
import imageio
from diffusers import (
    StableDiffusionPipeline,
    AnimateDiffPipeline,
    DPMSolverMultistepScheduler,
    MotionAdapter
)
from deep_translator import GoogleTranslator

# ===============================
# DEVICE
# ===============================
device = "cuda" if torch.cuda.is_available() else "cpu"
dtype = torch.float16 if device == "cuda" else torch.float32

# ===============================
# PROMPT MAP
# ===============================
TR_STYLE_MAP = {
    "gerçekçi": "realistic",
    "sinematik": "cinematic lighting",
    "anime": "anime style",
    "çizgi film": "cartoon style",
    "karanlık": "dark dramatic mood",
    "neon": "neon cyberpunk lighting",
    "portre": "portrait photography",
    "detaylı": "highly detailed",
    "fantastik": "fantasy art",
    "bilim kurgu": "science fiction",
    "minimal": "minimalist composition"
}

QUALITY_LOCK = (
    "masterpiece, ultra high quality, professional cinematic visuals, "
    "sharp focus, perfect lighting, high detail"
)

NEGATIVE_LOCK = (
    "low quality, blurry, distorted, bad anatomy, extra limbs, "
    "ugly, artifacts, flicker"
)

translator = GoogleTranslator(source="tr", target="en")

def _build_prompt(prompt_tr: str) -> str:
    translated = translator.translate(prompt_tr)
    styles = [
        en for tr, en in TR_STYLE_MAP.items()
        if tr in prompt_tr.lower()
    ]

    parts = [translated]
    if styles:
        parts.append(", ".join(styles))
    parts.append(QUALITY_LOCK)

    return ", ".join(parts)

# ===============================
# IMAGE PIPELINE
# ===============================
image_pipe = StableDiffusionPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    torch_dtype=dtype,
    safety_checker=None
).to(device)

image_pipe.scheduler = DPMSolverMultistepScheduler.from_config(
    image_pipe.scheduler.config
)
image_pipe.enable_attention_slicing()

# ===============================
# VIDEO PIPELINE
# ===============================
motion_adapter = MotionAdapter.from_pretrained(
    "guoyww/animatediff-motion-adapter-v1-5",
    torch_dtype=dtype
)

video_pipe = AnimateDiffPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    motion_adapter=motion_adapter,
    torch_dtype=dtype,
    safety_checker=None
).to(device)

video_pipe.scheduler = DPMSolverMultistepScheduler.from_config(
    video_pipe.scheduler.config
)
video_pipe.enable_attention_slicing()

# ===============================
# IMAGE FUNCTION
# ===============================
def create_text(
    prompt: str,
    kalite: float = 7.5,
    cfg: float = 7.5,
    steps: int | None = None,
    seed: int | None = None,
    filename: str = "output.png"
) -> str:

    if steps is None:
        steps = int(20 + kalite * 2)

    if seed is None:
        seed = random.randint(0, 999999999)

    generator = torch.Generator(device=device).manual_seed(seed)
    final_prompt = _build_prompt(prompt)

    image = image_pipe(
        prompt=final_prompt,
        negative_prompt=NEGATIVE_LOCK,
        num_inference_steps=steps,
        guidance_scale=float(cfg),
        generator=generator
    ).images[0]

    image.save(filename)
    return os.path.abspath(filename)

# ===============================
# VIDEO FUNCTION
# ===============================
def create_video(
    prompt: str,
    seconds: int = 3,
    fps: int = 12,
    kalite: float = 7.5,
    cfg: float = 7.5,
    seed: int | None = None,
    filename: str = "output.mp4"
) -> str:

    if seed is None:
        seed = random.randint(0, 999999999)

    generator = torch.Generator(device=device).manual_seed(seed)

    frame_count = seconds * fps
    steps = int(20 + kalite * 2)
    final_prompt = _build_prompt(prompt)

    video_frames = video_pipe(
        prompt=final_prompt,
        negative_prompt=NEGATIVE_LOCK,
        num_frames=frame_count,
        num_inference_steps=steps,
        guidance_scale=float(cfg),
        generator=generator
    ).frames[0]

    imageio.mimsave(
        filename,
        video_frames,
        fps=fps,
        codec="libx264",
        quality=8
    )

    return os.path.abspath(filename)