"""
Monoco Agent Execution Layer.
"""
