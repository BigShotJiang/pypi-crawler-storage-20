# src/dircap/__init__.py
__all__ = ["__version__"]
__version__ = "0.1.0"
