import io
import struct
from typing import Union

from kkloader.funcs import get_png, load_string, load_type, write_string
from kkloader.HoneycomeSceneObjectLoader import HoneycomeSceneObjectLoader


class HoneycomeSceneData:
    """
    Class for loading and parsing Honeycome scene data (simplified version).
    This implementation focuses on loading objects (items and folders) only.
    Supports both load and save operations.
    """

    def __init__(self):
        self.image = None
        self.version = None
        self.dataVersion = None
        self.user_id = None
        self.data_id = None
        self.title = None
        self.unknown_1 = None
        self.unknown_2 = None
        self.unknown_3 = None
        self.objects = {}
        self.unknown_tail = b""

    @classmethod
    def load(cls, filelike: Union[str, bytes, io.BytesIO]) -> "HoneycomeSceneData":
        """
        Load Honeycome scene data from a file or bytes.

        Args:
            filelike: Path to the file, bytes, or BytesIO object containing the scene data

        Returns:
            HoneycomeSceneData: The loaded scene data
        """
        hs = cls()

        if isinstance(filelike, str):
            with open(filelike, "br") as f:
                data = f.read()
            data_stream = io.BytesIO(data)
        elif isinstance(filelike, bytes):
            data_stream = io.BytesIO(filelike)
        elif isinstance(filelike, io.BytesIO):
            data_stream = filelike
        else:
            raise ValueError(f"Unsupported input type: {type(filelike)}")

        # Read PNG image
        hs.image = get_png(data_stream)

        # Read version string
        version_str = load_string(data_stream).decode("utf-8")

        # Read Honeycome-specific header fields
        hs.user_id = load_string(data_stream).decode("utf-8")
        hs.data_id = load_string(data_stream).decode("utf-8")
        hs.title = load_string(data_stream).decode("utf-8")

        # Read unknown fields
        hs.unknown_1 = load_type(data_stream, "i")  # 1
        hs.unknown_2 = load_type(data_stream, "i")
        hs.unknown_3 = data_stream.read(hs.unknown_2)

        hs.version = version_str
        hs.dataVersion = version_str

        # Read object dictionary
        obj_count = load_type(data_stream, "i")
        for _ in range(obj_count):
            key = load_type(data_stream, "i")
            obj_type = load_type(data_stream, "i")

            # Create object info based on type
            obj_info = {"type": obj_type, "data": {}}

            # Load object data based on type (only item and folder)
            HoneycomeSceneObjectLoader._dispatch_load(data_stream, obj_type, obj_info, version_str)

            hs.objects[key] = obj_info

        # Read remaining data as unknown_tail (lights, camera, etc.)
        hs.unknown_tail = data_stream.read()

        return hs

    def save(self, filelike: Union[str, io.BytesIO]) -> None:
        """
        Save Honeycome scene data to a file or BytesIO object.

        Args:
            filelike: Path to the file or BytesIO object to save the scene data to
        """
        if isinstance(filelike, str):
            with open(filelike, "bw") as f:
                f.write(bytes(self))
        elif isinstance(filelike, io.BytesIO):
            filelike.write(bytes(self))
        else:
            raise ValueError(f"Unsupported output type: {type(filelike)}")

    def __bytes__(self) -> bytes:
        """
        Convert the scene data to bytes.

        Returns:
            bytes: The scene data as bytes
        """
        data_stream = io.BytesIO()

        # Write PNG data if available
        if self.image:
            data_stream.write(self.image)

        # Write version string
        version_bytes = self.version.encode("utf-8")
        data_stream.write(struct.pack("b", len(version_bytes)))
        data_stream.write(version_bytes)

        # Write Honeycome-specific header fields
        write_string(data_stream, self.user_id.encode("utf-8"))
        write_string(data_stream, self.data_id.encode("utf-8"))
        write_string(data_stream, self.title.encode("utf-8"))

        # Write unknown fields
        data_stream.write(struct.pack("i", self.unknown_1))
        data_stream.write(struct.pack("i", self.unknown_2))
        data_stream.write(self.unknown_3)

        # Write object dictionary
        data_stream.write(struct.pack("i", len(self.objects)))
        for key, obj_info in self.objects.items():
            data_stream.write(struct.pack("i", key))
            data_stream.write(struct.pack("i", obj_info["type"]))

            # Save object data based on type
            try:
                HoneycomeSceneObjectLoader._dispatch_save(data_stream, obj_info, self.version)
            except NotImplementedError as e:
                raise NotImplementedError(f"Cannot save object of type {obj_info['type']}: {str(e)}")

        # Write unknown_tail (lights, camera, etc.)
        data_stream.write(self.unknown_tail)

        return data_stream.getvalue()

    def to_dict(self):
        """Convert the scene data to a dictionary"""
        return {
            "version": self.version,
            "dataVersion": self.dataVersion,
            "user_id": self.user_id,
            "data_id": self.data_id,
            "title": self.title,
            "objectCount": len(self.objects),
        }

    def __str__(self):
        """String representation of the scene data"""
        return f"HoneycomeSceneData(version={self.version}, objects={len(self.objects)})"
