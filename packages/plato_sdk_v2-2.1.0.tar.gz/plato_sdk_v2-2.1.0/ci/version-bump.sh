#!/bin/bash
set -e
export PATH="$HOME/.local/bin:$PATH"
cd "$(dirname "$0")/.."

# DEV_FLAG is set by CI (empty for release, --dev for dev branches)
uv run ../scripts/gh/bump_version.py VERSION $DEV_FLAG

git add VERSION
