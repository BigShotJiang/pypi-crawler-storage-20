#!/bin/bash
set -e
export PATH="$HOME/.local/bin:$PATH"
cd "$(dirname "$0")/.."

uv run --frozen ruff format .
uv run --frozen ruff check . --fix
uv run --frozen ty check plato/ --exclude 'plato/_generated/**'
