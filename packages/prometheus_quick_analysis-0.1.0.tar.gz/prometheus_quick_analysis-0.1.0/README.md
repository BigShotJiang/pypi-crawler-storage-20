# prometheus-analyzer


- Parse metrics safely (supports counters/gauges/histograms/summaries)
- Produce a basic analysis report:

  - total families, total samples

  - top metrics by sample count

  - label cardinality (unique labelsets) per metric

  - optional filter by metric name regex

  - optional “diff” between two snapshots (helpful in PR context)

