# jcgraph

Java代码知识图谱构建工具

## 安装

pip install jcgraph

## 使用

jcgraph init       # 初始化
jcgraph scan       # 扫描项目
jcgraph serve      # 启动Web
jcgraph query xxx  # 查询
jcgraph trace xxx  # 追踪调用链
