"""CLI入口"""
from pathlib import Path
import click
from rich.console import Console
from rich.panel import Panel

console = Console()
GLOBAL_DIR = Path.home() / ".jcgraph"
LOCAL_DIR = Path(".jcgraph")

def get_data_dir(local=False):
    if local or LOCAL_DIR.exists():
        return LOCAL_DIR
    return GLOBAL_DIR

@click.group()
@click.version_option()
def app():
    """jcgraph - Java代码知识图谱构建工具"""
    pass

@app.command()
@click.option("--local", is_flag=True, help="项目级初始化")
def init(local):
    """初始化"""
    data_dir = LOCAL_DIR if local else GLOBAL_DIR
    data_dir.mkdir(parents=True, exist_ok=True)
    (data_dir / "config.yaml").write_text("# jcgraph config\n")
    console.print(f"[green]✓ 初始化完成: {data_dir}[/green]")

@app.command()
@click.option("--path", default=".", help="项目路径")
def scan(path):
    """扫描项目"""
    console.print(f"扫描: {path}")
    console.print("[yellow]开发中...[/yellow]")

@app.command()
@click.option("--port", default=8080)
def serve(port):
    """启动Web"""
    console.print(f"[green]http://localhost:{port}[/green]")
    console.print("[yellow]开发中...[/yellow]")

@app.command()
@click.argument("keyword")
def query(keyword):
    """查询"""
    console.print(f"查询: {keyword}")
    console.print("[yellow]开发中...[/yellow]")

@app.command()
@click.argument("method")
@click.option("--depth", default=3)
def trace(method, depth):
    """追踪调用链"""
    console.print(f"追踪: {method}, 深度: {depth}")
    console.print("[yellow]开发中...[/yellow]")

if __name__ == "__main__":
    app()
