"""Tests for GeoSmith."""


