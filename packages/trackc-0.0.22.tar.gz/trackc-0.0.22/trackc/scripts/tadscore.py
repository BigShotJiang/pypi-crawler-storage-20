def tadScore():
    pass
