"""Command-line interface for satellite-tiler.

A simple CLI for testing and exploring satellite imagery.

Usage:
    satellite-tiler discover --lat 40.7128 --lon -74.0060
    satellite-tiler scenes --lat 40.7128 --lon -74.0060 --platform landsat8
    satellite-tiler tile --scene-id LC08_... --lat 40.7128 --lon -74.0060 --zoom 12 -o tile.png
"""

import argparse
import json
import sys
from typing import Optional


def discover_cmd(args: argparse.Namespace) -> int:
    """Handle discover command."""
    from satellite_tiler.tools import discover_satellite_data
    
    result = discover_satellite_data(lat=args.lat, lon=args.lon)
    
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(result["message"])
        for m in result["missions"]:
            print(f"  - {m['platform']}: {m['description']}")
            print(f"    Bands: {', '.join(m['bands'][:5])}...")
    
    return 0


def scenes_cmd(args: argparse.Namespace) -> int:
    """Handle scenes command."""
    from satellite_tiler.tools import list_satellite_scenes
    
    result = list_satellite_scenes(
        lat=args.lat,
        lon=args.lon,
        platform=args.platform,
        start_date=args.start_date,
        end_date=args.end_date,
        max_cloud_cover=args.max_cloud,
        limit=args.limit,
    )
    
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(result["message"])
        for s in result["scenes"]:
            print(f"  - {s['scene_id']}")
            print(f"    Date: {s['date']}, Cloud: {s['cloud_cover']}%")
    
    return 0 if not result.get("error") else 1


def tile_cmd(args: argparse.Namespace) -> int:
    """Handle tile command."""
    import base64
    from satellite_tiler.tools import get_satellite_tile
    
    bands = args.bands.split(",") if args.bands else None
    
    result = get_satellite_tile(
        scene_id=args.scene_id,
        lat=args.lat,
        lon=args.lon,
        zoom=args.zoom,
        bands=bands,
        expression=args.expression,
        format=args.format,
    )
    
    if result.get("error"):
        print(f"Error: {result['message']}", file=sys.stderr)
        return 1
    
    if args.output:
        image_data = base64.b64decode(result["image_base64"])
        with open(args.output, "wb") as f:
            f.write(image_data)
        print(f"Saved tile to {args.output}")
    else:
        print(result["message"])
        print(f"Bounds: {result['bounds']}")
        print(f"Image size: {len(result['image_base64'])} bytes (base64)")
    
    return 0


def info_cmd(args: argparse.Namespace) -> int:
    """Handle info command."""
    from satellite_tiler.tools import get_scene_info
    
    result = get_scene_info(args.scene_id)
    
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        if result.get("error"):
            print(f"Error: {result['message']}", file=sys.stderr)
            return 1
        print(result["message"])
        print(f"Bounds: {result.get('bounds')}")
        print(f"Zoom levels: {result.get('zoom_levels')}")
    
    return 0


def main(argv: Optional[list] = None) -> int:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="satellite-tiler",
        description="Access open-source satellite imagery from AWS",
    )
    parser.add_argument("--version", action="version", version="%(prog)s 0.1.0")
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # discover command
    discover_parser = subparsers.add_parser("discover", help="Discover available missions")
    discover_parser.add_argument("--lat", type=float, required=True, help="Latitude")
    discover_parser.add_argument("--lon", type=float, required=True, help="Longitude")
    discover_parser.add_argument("--json", action="store_true", help="Output as JSON")
    discover_parser.set_defaults(func=discover_cmd)
    
    # scenes command
    scenes_parser = subparsers.add_parser("scenes", help="List available scenes")
    scenes_parser.add_argument("--lat", type=float, required=True, help="Latitude")
    scenes_parser.add_argument("--lon", type=float, required=True, help="Longitude")
    scenes_parser.add_argument("--platform", required=True, help="Platform (landsat8, sentinel2, cbers)")
    scenes_parser.add_argument("--start-date", help="Start date (YYYY-MM-DD)")
    scenes_parser.add_argument("--end-date", help="End date (YYYY-MM-DD)")
    scenes_parser.add_argument("--max-cloud", type=float, default=20.0, help="Max cloud cover %%")
    scenes_parser.add_argument("--limit", type=int, default=5, help="Max scenes to return")
    scenes_parser.add_argument("--json", action="store_true", help="Output as JSON")
    scenes_parser.set_defaults(func=scenes_cmd)
    
    # tile command
    tile_parser = subparsers.add_parser("tile", help="Fetch a tile")
    tile_parser.add_argument("--scene-id", required=True, help="Scene ID")
    tile_parser.add_argument("--lat", type=float, required=True, help="Latitude")
    tile_parser.add_argument("--lon", type=float, required=True, help="Longitude")
    tile_parser.add_argument("--zoom", type=int, required=True, help="Zoom level (1-18)")
    tile_parser.add_argument("--bands", help="Comma-separated bands (e.g., B4,B3,B2)")
    tile_parser.add_argument("--expression", help="Band math expression")
    tile_parser.add_argument("--format", default="png", choices=["png", "jpeg", "webp"])
    tile_parser.add_argument("-o", "--output", help="Output file path")
    tile_parser.set_defaults(func=tile_cmd)
    
    # info command
    info_parser = subparsers.add_parser("info", help="Get scene metadata")
    info_parser.add_argument("scene_id", help="Scene ID")
    info_parser.add_argument("--json", action="store_true", help="Output as JSON")
    info_parser.set_defaults(func=info_cmd)
    
    args = parser.parse_args(argv)
    
    if not args.command:
        parser.print_help()
        return 0
    
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
