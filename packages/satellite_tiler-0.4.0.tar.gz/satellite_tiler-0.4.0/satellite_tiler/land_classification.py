"""Land use/land cover classification from satellite imagery.

This module provides functions for classifying land use types using
combinations of spectral indices (NDVI, NDBI, NDWI).
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np

from satellite_tiler.indices import (
    calculate_ndvi,
    calculate_ndbi,
    calculate_ndwi,
    IndexResult,
)


class LandUseClass(Enum):
    """Land use classification categories."""
    URBAN = "urban"
    VEGETATION = "vegetation"
    WATER = "water"
    BARE_SOIL = "bare_soil"
    MIXED = "mixed"


# Default thresholds for index-based classification
DEFAULT_THRESHOLDS = {
    "ndvi_vegetation": 0.3,    # NDVI > 0.3 = vegetation
    "ndwi_water": 0.0,         # NDWI > 0 = water
    "ndbi_urban": 0.0,         # NDBI > 0 = urban
    "ndvi_bare_soil_max": 0.2, # NDVI < 0.2 and not water/urban = bare soil
}

# Colors for land use classes (RGB)
LAND_USE_COLORS = {
    LandUseClass.WATER: (0, 0, 200),       # Blue
    LandUseClass.VEGETATION: (0, 150, 0),  # Green
    LandUseClass.URBAN: (200, 0, 0),       # Red
    LandUseClass.BARE_SOIL: (200, 150, 50),# Brown/tan
    LandUseClass.MIXED: (150, 150, 150),   # Gray
}


@dataclass
class LandClassificationResult:
    """Result of land use classification.
    
    Attributes:
        classification: 2D array of land use class indices
        class_percentages: Percentage of each land use class
        class_areas_sq_meters: Area of each class in square meters
        confidence: Per-pixel confidence scores (0-1)
        indices_used: List of indices used for classification
        ndvi: NDVI index result
        ndbi: NDBI index result (if available)
        ndwi: NDWI index result (if available)
    """
    classification: np.ndarray
    class_percentages: Dict[str, float]
    class_areas_sq_meters: Dict[str, float]
    confidence: np.ndarray
    indices_used: List[str]
    ndvi: Optional[IndexResult] = None
    ndbi: Optional[IndexResult] = None
    ndwi: Optional[IndexResult] = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.classification.shape),
            "class_percentages": self.class_percentages,
            "class_areas_sq_meters": self.class_areas_sq_meters,
            "indices_used": self.indices_used,
            "ndvi": self.ndvi.to_dict() if self.ndvi else None,
            "ndbi": self.ndbi.to_dict() if self.ndbi else None,
            "ndwi": self.ndwi.to_dict() if self.ndwi else None,
        }


def classify_land_use(
    ndvi: np.ndarray,
    ndbi: Optional[np.ndarray] = None,
    ndwi: Optional[np.ndarray] = None,
    thresholds: Optional[Dict[str, float]] = None,
) -> np.ndarray:
    """Classify land use from spectral indices.
    
    Classification logic:
    1. Water: NDWI > threshold (if available) or NDVI < 0
    2. Vegetation: NDVI > vegetation threshold
    3. Urban: NDBI > threshold (if available) and NDVI < vegetation threshold
    4. Bare soil: Low NDVI, not water, not urban
    5. Mixed: Everything else
    
    Args:
        ndvi: NDVI array
        ndbi: NDBI array (optional, improves urban detection)
        ndwi: NDWI array (optional, improves water detection)
        thresholds: Custom thresholds (uses defaults if not provided)
    
    Returns:
        2D array of land use class indices (0-4)
    """
    thresh = {**DEFAULT_THRESHOLDS, **(thresholds or {})}
    
    # Initialize as mixed
    classification = np.full(ndvi.shape, 4, dtype=np.int8)  # Mixed
    
    # Water detection
    if ndwi is not None:
        water_mask = ndwi > thresh["ndwi_water"]
    else:
        water_mask = ndvi < 0
    classification[water_mask] = 2  # Water
    
    # Vegetation detection
    veg_mask = (ndvi > thresh["ndvi_vegetation"]) & ~water_mask
    classification[veg_mask] = 1  # Vegetation
    
    # Urban detection
    if ndbi is not None:
        urban_mask = (
            (ndbi > thresh["ndbi_urban"]) & 
            (ndvi < thresh["ndvi_vegetation"]) & 
            ~water_mask
        )
    else:
        # Without NDBI, use low NDVI and not water as proxy
        urban_mask = (
            (ndvi > 0) & 
            (ndvi < thresh["ndvi_bare_soil_max"]) & 
            ~water_mask
        )
    classification[urban_mask] = 0  # Urban
    
    # Bare soil detection
    bare_mask = (
        (ndvi >= 0) & 
        (ndvi < thresh["ndvi_bare_soil_max"]) & 
        ~water_mask & 
        ~urban_mask
    )
    classification[bare_mask] = 3  # Bare soil
    
    # Handle NaN values
    nan_mask = np.isnan(ndvi)
    if ndbi is not None:
        nan_mask |= np.isnan(ndbi)
    if ndwi is not None:
        nan_mask |= np.isnan(ndwi)
    classification[nan_mask] = 4  # Mixed (unknown)
    
    return classification


def calculate_confidence(
    ndvi: np.ndarray,
    ndbi: Optional[np.ndarray],
    ndwi: Optional[np.ndarray],
    classification: np.ndarray,
) -> np.ndarray:
    """Calculate per-pixel classification confidence.
    
    Confidence is based on how clearly the pixel falls into its class
    based on the index values.
    
    Args:
        ndvi: NDVI array
        ndbi: NDBI array (optional)
        ndwi: NDWI array (optional)
        classification: Classification result array
    
    Returns:
        2D array of confidence scores (0-1)
    """
    confidence = np.zeros_like(ndvi, dtype=np.float32)
    
    # Water confidence: based on NDWI or negative NDVI
    water_mask = classification == 2
    if ndwi is not None:
        confidence[water_mask] = np.clip(ndwi[water_mask], 0, 1)
    else:
        confidence[water_mask] = np.clip(-ndvi[water_mask], 0, 1)
    
    # Vegetation confidence: based on NDVI
    veg_mask = classification == 1
    confidence[veg_mask] = np.clip((ndvi[veg_mask] - 0.3) / 0.7, 0, 1)
    
    # Urban confidence: based on NDBI
    urban_mask = classification == 0
    if ndbi is not None:
        confidence[urban_mask] = np.clip(ndbi[urban_mask], 0, 1)
    else:
        confidence[urban_mask] = 0.5  # Lower confidence without NDBI
    
    # Bare soil confidence
    bare_mask = classification == 3
    confidence[bare_mask] = 0.6  # Moderate confidence
    
    # Mixed has low confidence
    mixed_mask = classification == 4
    confidence[mixed_mask] = 0.3
    
    return confidence


def calculate_class_percentages(classification: np.ndarray) -> Dict[str, float]:
    """Calculate percentage of each land use class.
    
    Args:
        classification: 2D array of class indices
    
    Returns:
        Dictionary mapping class names to percentages
    """
    total_pixels = classification.size
    if total_pixels == 0:
        return {lc.value: 0.0 for lc in LandUseClass}
    
    class_mapping = {
        0: LandUseClass.URBAN,
        1: LandUseClass.VEGETATION,
        2: LandUseClass.WATER,
        3: LandUseClass.BARE_SOIL,
        4: LandUseClass.MIXED,
    }
    
    percentages = {}
    for idx, land_class in class_mapping.items():
        count = np.sum(classification == idx)
        percentages[land_class.value] = float(count / total_pixels * 100)
    
    return percentages


def calculate_class_areas(
    classification: np.ndarray,
    pixel_size_meters: float = 30.0,
) -> Dict[str, float]:
    """Calculate area of each land use class in square meters.
    
    Args:
        classification: 2D array of class indices
        pixel_size_meters: Size of each pixel in meters (default 30m for Landsat)
    
    Returns:
        Dictionary mapping class names to areas in square meters
    """
    pixel_area = pixel_size_meters ** 2
    
    class_mapping = {
        0: LandUseClass.URBAN,
        1: LandUseClass.VEGETATION,
        2: LandUseClass.WATER,
        3: LandUseClass.BARE_SOIL,
        4: LandUseClass.MIXED,
    }
    
    areas = {}
    for idx, land_class in class_mapping.items():
        count = np.sum(classification == idx)
        areas[land_class.value] = float(count * pixel_area)
    
    return areas


def classify_from_bands(
    nir: np.ndarray,
    red: np.ndarray,
    green: Optional[np.ndarray] = None,
    swir: Optional[np.ndarray] = None,
    thresholds: Optional[Dict[str, float]] = None,
    pixel_size_meters: float = 30.0,
) -> LandClassificationResult:
    """Perform land use classification from satellite bands.
    
    Args:
        nir: Near-infrared band array
        red: Red band array
        green: Green band array (optional, for NDWI)
        swir: Short-wave infrared band array (optional, for NDBI)
        thresholds: Custom classification thresholds
        pixel_size_meters: Pixel size for area calculation
    
    Returns:
        LandClassificationResult with classification and statistics
    """
    # Calculate indices
    ndvi_result = calculate_ndvi(nir, red)
    ndvi = ndvi_result.data
    
    ndbi_result = None
    ndbi = None
    if swir is not None:
        ndbi_result = calculate_ndbi(swir, nir)
        ndbi = ndbi_result.data
    
    ndwi_result = None
    ndwi = None
    if green is not None:
        ndwi_result = calculate_ndwi(green, nir)
        ndwi = ndwi_result.data
    
    # Classify
    classification = classify_land_use(ndvi, ndbi, ndwi, thresholds)
    
    # Calculate confidence
    confidence = calculate_confidence(ndvi, ndbi, ndwi, classification)
    
    # Calculate statistics
    class_percentages = calculate_class_percentages(classification)
    class_areas = calculate_class_areas(classification, pixel_size_meters)
    
    # Track which indices were used
    indices_used = ["NDVI"]
    if ndbi is not None:
        indices_used.append("NDBI")
    if ndwi is not None:
        indices_used.append("NDWI")
    
    return LandClassificationResult(
        classification=classification,
        class_percentages=class_percentages,
        class_areas_sq_meters=class_areas,
        confidence=confidence,
        indices_used=indices_used,
        ndvi=ndvi_result,
        ndbi=ndbi_result,
        ndwi=ndwi_result,
    )


def get_colorized_map(classification: np.ndarray) -> np.ndarray:
    """Convert classification array to RGB image.
    
    Args:
        classification: 2D array of class indices (0-4)
    
    Returns:
        3D RGB array (height, width, 3)
    """
    rgb = np.zeros((*classification.shape, 3), dtype=np.uint8)
    
    class_mapping = {
        0: LandUseClass.URBAN,
        1: LandUseClass.VEGETATION,
        2: LandUseClass.WATER,
        3: LandUseClass.BARE_SOIL,
        4: LandUseClass.MIXED,
    }
    
    for idx, land_class in class_mapping.items():
        mask = classification == idx
        rgb[mask] = LAND_USE_COLORS[land_class]
    
    return rgb


def get_land_use_legend() -> Dict[str, Tuple[int, int, int]]:
    """Get legend mapping class names to RGB colors.
    
    Returns:
        Dictionary mapping class names to RGB tuples
    """
    return {lc.value: LAND_USE_COLORS[lc] for lc in LandUseClass}
