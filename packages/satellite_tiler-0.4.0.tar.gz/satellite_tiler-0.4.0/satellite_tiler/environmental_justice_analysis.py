"""Environmental justice analysis from satellite imagery.

This module provides functions for analyzing environmental justice
by combining heat, vegetation, and air quality indicators to identify
areas with cumulative environmental burdens.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np


@dataclass
class EnvironmentalBurden:
    """Environmental burden indicators for an area.
    
    Attributes:
        heat_burden: Heat burden score (0-1)
        vegetation_deficit: Vegetation deficit score (0-1)
        air_quality_burden: Air quality burden score (0-1)
        cumulative_score: Combined burden score (0-1)
    """
    heat_burden: float
    vegetation_deficit: float
    air_quality_burden: float
    cumulative_score: float

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "heat_burden": self.heat_burden,
            "vegetation_deficit": self.vegetation_deficit,
            "air_quality_burden": self.air_quality_burden,
            "cumulative_score": self.cumulative_score,
        }


@dataclass
class EnvironmentalJusticeResult:
    """Result of environmental justice analysis.
    
    Attributes:
        burden_score: Per-pixel cumulative burden scores (0-1)
        burden_classification: Per-pixel burden level (0-4)
        burden_percentages: Percentage of each burden level
        mean_burden: Mean cumulative burden score
        high_burden_percent: Percentage of high burden area
        multi_stressor_mask: Mask of areas with multiple stressors
        multi_stressor_percent: Percentage with multiple stressors
        priority_areas: List of priority intervention areas
        burden_components: Component burden scores
    """
    burden_score: np.ndarray
    burden_classification: np.ndarray
    burden_percentages: Dict[str, float]
    mean_burden: float
    high_burden_percent: float
    multi_stressor_mask: np.ndarray
    multi_stressor_percent: float
    priority_areas: List[str]
    burden_components: EnvironmentalBurden

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.burden_score.shape),
            "burden_percentages": self.burden_percentages,
            "mean_burden": self.mean_burden,
            "high_burden_percent": self.high_burden_percent,
            "multi_stressor_percent": self.multi_stressor_percent,
            "priority_areas": self.priority_areas,
            "burden_components": self.burden_components.to_dict(),
        }


# Burden level thresholds
BURDEN_THRESHOLDS = {
    "very_low": (0.0, 0.2),
    "low": (0.2, 0.4),
    "moderate": (0.4, 0.6),
    "high": (0.6, 0.8),
    "very_high": (0.8, 1.0),
}

# Default weights for burden calculation
DEFAULT_BURDEN_WEIGHTS = {
    "heat": 0.35,
    "vegetation": 0.35,
    "air_quality": 0.30,
}


def calculate_heat_burden(
    lst_celsius: np.ndarray,
    threshold_above_mean: float = 2.0,
) -> np.ndarray:
    """Calculate heat burden score.
    
    Args:
        lst_celsius: Land surface temperature in Celsius
        threshold_above_mean: Temperature threshold above mean
    
    Returns:
        Heat burden score array (0-1)
    """
    valid_mask = ~np.isnan(lst_celsius)
    if not np.any(valid_mask):
        return np.zeros_like(lst_celsius, dtype=np.float32)
    
    mean_temp = np.nanmean(lst_celsius)
    std_temp = np.nanstd(lst_celsius)
    
    if std_temp == 0:
        return np.zeros_like(lst_celsius, dtype=np.float32)
    
    # Normalize temperature to burden score
    # Higher temp = higher burden
    z_score = (lst_celsius - mean_temp) / std_temp
    burden = np.clip((z_score + 2) / 4, 0, 1)  # Map [-2, 2] to [0, 1]
    
    burden[~valid_mask] = 0
    
    return burden.astype(np.float32)


def calculate_vegetation_deficit(
    ndvi_data: np.ndarray,
    target_ndvi: float = 0.4,
) -> np.ndarray:
    """Calculate vegetation deficit score.
    
    Args:
        ndvi_data: NDVI values array
        target_ndvi: Target NDVI for adequate vegetation
    
    Returns:
        Vegetation deficit score array (0-1)
    """
    valid_mask = ~np.isnan(ndvi_data)
    
    # Deficit is how far below target
    # Low NDVI = high deficit
    deficit = (target_ndvi - ndvi_data) / target_ndvi
    deficit = np.clip(deficit, 0, 1)
    
    deficit[~valid_mask] = 0
    
    return deficit.astype(np.float32)


def calculate_air_quality_burden(
    ndvi_data: np.ndarray,
    ndbi_data: np.ndarray,
) -> np.ndarray:
    """Calculate air quality burden score.
    
    Uses vegetation and built-up as proxies for air quality.
    
    Args:
        ndvi_data: NDVI values array
        ndbi_data: NDBI values array
    
    Returns:
        Air quality burden score array (0-1)
    """
    valid_mask = ~np.isnan(ndvi_data) & ~np.isnan(ndbi_data)
    
    # Low vegetation + high built-up = high burden
    low_veg = (1 - ndvi_data) / 2  # Normalize [-1,1] to [1,0]
    high_built = (ndbi_data + 1) / 2  # Normalize [-1,1] to [0,1]
    
    burden = (low_veg + high_built) / 2
    burden = np.clip(burden, 0, 1)
    
    burden[~valid_mask] = 0
    
    return burden.astype(np.float32)


def calculate_cumulative_burden(
    heat_burden: np.ndarray,
    vegetation_deficit: np.ndarray,
    air_quality_burden: np.ndarray,
    weights: Optional[Dict[str, float]] = None,
) -> np.ndarray:
    """Calculate cumulative environmental burden score.
    
    Args:
        heat_burden: Heat burden scores (0-1)
        vegetation_deficit: Vegetation deficit scores (0-1)
        air_quality_burden: Air quality burden scores (0-1)
        weights: Custom weights for components
    
    Returns:
        Cumulative burden score array (0-1)
    """
    w = {**DEFAULT_BURDEN_WEIGHTS, **(weights or {})}
    
    # Normalize weights
    total_weight = sum(w.values())
    w = {k: v / total_weight for k, v in w.items()}
    
    burden = (
        w["heat"] * heat_burden +
        w["vegetation"] * vegetation_deficit +
        w["air_quality"] * air_quality_burden
    )
    
    return np.clip(burden, 0, 1).astype(np.float32)


def classify_burden_level(burden_score: np.ndarray) -> np.ndarray:
    """Classify burden scores into levels.
    
    Args:
        burden_score: Burden score array (0-1)
    
    Returns:
        Array of burden level indices (0-4)
    """
    classification = np.zeros_like(burden_score, dtype=np.int8)
    
    for i, (level, (low, high)) in enumerate(BURDEN_THRESHOLDS.items()):
        mask = (burden_score >= low) & (burden_score < high)
        classification[mask] = i
    
    classification[burden_score >= 1.0] = 4
    
    return classification


def calculate_burden_percentages(burden_classification: np.ndarray) -> Dict[str, float]:
    """Calculate percentage of each burden level.
    
    Args:
        burden_classification: Array of burden level indices
    
    Returns:
        Dictionary mapping burden level names to percentages
    """
    total_pixels = burden_classification.size
    if total_pixels == 0:
        return {level: 0.0 for level in BURDEN_THRESHOLDS.keys()}
    
    percentages = {}
    for i, level in enumerate(BURDEN_THRESHOLDS.keys()):
        count = np.sum(burden_classification == i)
        percentages[level] = float(count / total_pixels * 100)
    
    return percentages


def identify_multi_stressor_areas(
    heat_burden: np.ndarray,
    vegetation_deficit: np.ndarray,
    air_quality_burden: np.ndarray,
    threshold: float = 0.5,
) -> np.ndarray:
    """Identify areas with multiple environmental stressors.
    
    Args:
        heat_burden: Heat burden scores (0-1)
        vegetation_deficit: Vegetation deficit scores (0-1)
        air_quality_burden: Air quality burden scores (0-1)
        threshold: Threshold for considering a stressor significant
    
    Returns:
        Boolean mask of multi-stressor areas
    """
    high_heat = heat_burden > threshold
    high_veg_deficit = vegetation_deficit > threshold
    high_air_burden = air_quality_burden > threshold
    
    # Count stressors per pixel
    stressor_count = (
        high_heat.astype(np.int8) +
        high_veg_deficit.astype(np.int8) +
        high_air_burden.astype(np.int8)
    )
    
    # Multi-stressor = 2 or more
    multi_stressor = stressor_count >= 2
    
    return multi_stressor


def identify_priority_areas(
    burden_classification: np.ndarray,
    multi_stressor_mask: np.ndarray,
    mean_burden: float,
) -> List[str]:
    """Identify priority areas for environmental justice intervention.
    
    Args:
        burden_classification: Array of burden level indices
        multi_stressor_mask: Boolean mask of multi-stressor areas
        mean_burden: Mean cumulative burden score
    
    Returns:
        List of priority area descriptions
    """
    priorities = []
    
    high_burden_percent = np.sum(burden_classification >= 3) / burden_classification.size * 100
    multi_stressor_percent = np.sum(multi_stressor_mask) / multi_stressor_mask.size * 100
    
    if high_burden_percent > 30:
        priorities.append("CRITICAL: Over 30% of area has high environmental burden")
    
    if multi_stressor_percent > 20:
        priorities.append("PRIORITY: Significant multi-stressor areas identified")
    
    if mean_burden > 0.6:
        priorities.append("Overall environmental burden is high - comprehensive intervention needed")
    
    # Identify quadrant priorities
    h, w = burden_classification.shape
    quadrants = {
        "Northwest": burden_classification[:h//2, :w//2],
        "Northeast": burden_classification[:h//2, w//2:],
        "Southwest": burden_classification[h//2:, :w//2],
        "Southeast": burden_classification[h//2:, w//2:],
    }
    
    for name, quad in quadrants.items():
        quad_high = np.sum(quad >= 3) / quad.size * 100 if quad.size > 0 else 0
        if quad_high > 40:
            priorities.append(f"{name} quadrant has very high burden ({quad_high:.1f}% high/very high)")
    
    return priorities


def analyze_environmental_justice(
    lst_celsius: Optional[np.ndarray],
    ndvi_data: np.ndarray,
    ndbi_data: np.ndarray,
    weights: Optional[Dict[str, float]] = None,
) -> EnvironmentalJusticeResult:
    """Perform comprehensive environmental justice analysis.
    
    Args:
        lst_celsius: Land surface temperature in Celsius (optional)
        ndvi_data: NDVI values array
        ndbi_data: NDBI values array
        weights: Custom weights for burden components
    
    Returns:
        EnvironmentalJusticeResult with complete analysis
    """
    # Calculate component burdens
    if lst_celsius is not None:
        heat_burden = calculate_heat_burden(lst_celsius)
    else:
        # Use NDBI as heat proxy if no thermal data
        heat_burden = (ndbi_data + 1) / 2  # Normalize to 0-1
        heat_burden = np.clip(heat_burden, 0, 1).astype(np.float32)
    
    vegetation_deficit = calculate_vegetation_deficit(ndvi_data)
    air_quality_burden = calculate_air_quality_burden(ndvi_data, ndbi_data)
    
    # Calculate cumulative burden
    burden_score = calculate_cumulative_burden(
        heat_burden,
        vegetation_deficit,
        air_quality_burden,
        weights
    )
    
    # Classify burden levels
    burden_class = classify_burden_level(burden_score)
    burden_percentages = calculate_burden_percentages(burden_class)
    
    # Calculate statistics
    mean_burden = float(np.nanmean(burden_score))
    high_burden_percent = burden_percentages.get("high", 0) + burden_percentages.get("very_high", 0)
    
    # Identify multi-stressor areas
    multi_stressor = identify_multi_stressor_areas(
        heat_burden, vegetation_deficit, air_quality_burden
    )
    multi_stressor_percent = float(np.sum(multi_stressor) / multi_stressor.size * 100)
    
    # Identify priority areas
    priority_areas = identify_priority_areas(
        burden_class, multi_stressor, mean_burden
    )
    
    # Create burden components summary
    burden_components = EnvironmentalBurden(
        heat_burden=float(np.nanmean(heat_burden)),
        vegetation_deficit=float(np.nanmean(vegetation_deficit)),
        air_quality_burden=float(np.nanmean(air_quality_burden)),
        cumulative_score=mean_burden,
    )
    
    return EnvironmentalJusticeResult(
        burden_score=burden_score,
        burden_classification=burden_class,
        burden_percentages=burden_percentages,
        mean_burden=mean_burden,
        high_burden_percent=high_burden_percent,
        multi_stressor_mask=multi_stressor,
        multi_stressor_percent=multi_stressor_percent,
        priority_areas=priority_areas,
        burden_components=burden_components,
    )


def compare_areas(
    results: List[EnvironmentalJusticeResult],
    area_names: List[str],
) -> Dict[str, Dict[str, float]]:
    """Compare environmental justice metrics across multiple areas.
    
    Args:
        results: List of EnvironmentalJusticeResult for each area
        area_names: Names of the areas
    
    Returns:
        Dictionary with comparative statistics
    """
    comparison = {}
    
    for name, result in zip(area_names, results):
        comparison[name] = {
            "mean_burden": result.mean_burden,
            "high_burden_percent": result.high_burden_percent,
            "multi_stressor_percent": result.multi_stressor_percent,
            "heat_burden": result.burden_components.heat_burden,
            "vegetation_deficit": result.burden_components.vegetation_deficit,
            "air_quality_burden": result.burden_components.air_quality_burden,
        }
    
    return comparison


def get_burden_colormap() -> Dict[int, tuple]:
    """Get RGB colormap for burden levels.
    
    Returns:
        Dictionary mapping burden level index to RGB tuple
    """
    return {
        0: (0, 128, 0),      # Very low - green
        1: (144, 238, 144),  # Low - light green
        2: (255, 255, 0),    # Moderate - yellow
        3: (255, 165, 0),    # High - orange
        4: (255, 0, 0),      # Very high - red
    }


def colorize_burden(burden_classification: np.ndarray) -> np.ndarray:
    """Convert burden classification to RGB image.
    
    Args:
        burden_classification: 2D array of burden level indices (0-4)
    
    Returns:
        3D RGB array (height, width, 3)
    """
    colormap = get_burden_colormap()
    
    rgb = np.zeros((*burden_classification.shape, 3), dtype=np.uint8)
    
    for burden_idx, color in colormap.items():
        mask = burden_classification == burden_idx
        rgb[mask] = color
    
    return rgb
