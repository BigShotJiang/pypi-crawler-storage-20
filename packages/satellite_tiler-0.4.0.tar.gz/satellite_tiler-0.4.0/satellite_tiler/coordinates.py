"""Coordinate conversion utilities for satellite-tiler.

This module provides functions for converting between geographic coordinates
(latitude/longitude) and Web Mercator tile coordinates (z/x/y).
"""

import math
from typing import Tuple


def lat_lon_to_tile(lat: float, lon: float, zoom: int) -> Tuple[int, int]:
    """Convert latitude/longitude to tile x/y coordinates at a given zoom level.
    
    Uses the Web Mercator (EPSG:3857) tile scheme, same as Google Maps,
    OpenStreetMap, and most web mapping services.
    
    Args:
        lat: Latitude in decimal degrees (-85.05 to 85.05)
        lon: Longitude in decimal degrees (-180 to 180)
        zoom: Zoom level (0 to 22)
    
    Returns:
        Tuple of (x, y) tile coordinates
    
    Raises:
        ValueError: If coordinates or zoom are out of valid range
    
    Example:
        >>> lat_lon_to_tile(40.7128, -74.0060, 12)
        (1205, 1539)
    """
    # Validate inputs
    if not -85.05 <= lat <= 85.05:
        raise ValueError(f"Latitude must be between -85.05 and 85.05, got {lat}")
    if not -180 <= lon <= 180:
        raise ValueError(f"Longitude must be between -180 and 180, got {lon}")
    if not 0 <= zoom <= 22:
        raise ValueError(f"Zoom must be between 0 and 22, got {zoom}")
    
    n = 2 ** zoom
    
    # Convert longitude to tile x
    x = int((lon + 180.0) / 360.0 * n)
    
    # Convert latitude to tile y using Mercator projection
    lat_rad = math.radians(lat)
    y = int((1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n)
    
    # Clamp to valid range
    x = max(0, min(x, n - 1))
    y = max(0, min(y, n - 1))
    
    return x, y


def tile_to_bounds(x: int, y: int, zoom: int) -> Tuple[float, float, float, float]:
    """Convert tile coordinates to geographic bounding box.
    
    Args:
        x: Tile x coordinate
        y: Tile y coordinate
        zoom: Zoom level (0 to 22)
    
    Returns:
        Tuple of (west, south, east, north) in decimal degrees (EPSG:4326)
    
    Raises:
        ValueError: If coordinates or zoom are out of valid range
    
    Example:
        >>> tile_to_bounds(1205, 1539, 12)
        (-74.00390625, 40.71395582628602, -73.916015625, 40.78054143186033)
    """
    if not 0 <= zoom <= 22:
        raise ValueError(f"Zoom must be between 0 and 22, got {zoom}")
    
    n = 2 ** zoom
    
    if not 0 <= x < n:
        raise ValueError(f"Tile x must be between 0 and {n-1} at zoom {zoom}, got {x}")
    if not 0 <= y < n:
        raise ValueError(f"Tile y must be between 0 and {n-1} at zoom {zoom}, got {y}")
    
    # Calculate longitude bounds
    west = x / n * 360.0 - 180.0
    east = (x + 1) / n * 360.0 - 180.0
    
    # Calculate latitude bounds using inverse Mercator projection
    north = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    south = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * (y + 1) / n))))
    
    return west, south, east, north


def tile_center(x: int, y: int, zoom: int) -> Tuple[float, float]:
    """Get the center point of a tile in geographic coordinates.
    
    Args:
        x: Tile x coordinate
        y: Tile y coordinate
        zoom: Zoom level (0 to 22)
    
    Returns:
        Tuple of (latitude, longitude) of tile center
    
    Example:
        >>> tile_center(1205, 1539, 12)
        (40.74724862907318, -73.95996093750001)
    """
    west, south, east, north = tile_to_bounds(x, y, zoom)
    lat = (north + south) / 2
    lon = (east + west) / 2
    return lat, lon


def meters_per_pixel(lat: float, zoom: int) -> float:
    """Calculate the ground resolution (meters per pixel) at a given latitude and zoom.
    
    Args:
        lat: Latitude in decimal degrees
        zoom: Zoom level (0 to 22)
    
    Returns:
        Ground resolution in meters per pixel
    
    Example:
        >>> meters_per_pixel(40.7128, 12)
        38.21851414258813
    """
    # Earth's circumference at equator in meters
    earth_circumference = 40075016.686
    
    # Tile size in pixels
    tile_size = 256
    
    # Number of tiles at this zoom level
    n = 2 ** zoom
    
    # Resolution at equator
    resolution_at_equator = earth_circumference / (tile_size * n)
    
    # Adjust for latitude (Mercator projection)
    resolution = resolution_at_equator * math.cos(math.radians(lat))
    
    return resolution


def point_in_bounds(
    lat: float,
    lon: float,
    bounds: Tuple[float, float, float, float]
) -> bool:
    """Check if a point is within geographic bounds.
    
    Args:
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        bounds: Tuple of (west, south, east, north)
    
    Returns:
        True if point is within bounds, False otherwise
    """
    west, south, east, north = bounds
    return west <= lon <= east and south <= lat <= north
