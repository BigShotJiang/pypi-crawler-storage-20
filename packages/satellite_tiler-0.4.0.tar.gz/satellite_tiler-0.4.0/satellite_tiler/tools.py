"""Agent tools interface for satellite-tiler.

This module provides tool functions optimized for AI agents (AWS Strands, LangChain, etc.).
Each tool returns JSON-serializable dictionaries with human-readable messages.

All tools are designed to:
- Return structured JSON-serializable data
- Include human-readable messages for agent reasoning
- Handle errors gracefully with error flags
- Auto-cache asset URLs between calls
"""

import base64
from typing import Dict, List, Optional, Any

from satellite_tiler.models import SatellitePlatform
from satellite_tiler.discovery import discover, list_scenes, get_bands_for_platform
from satellite_tiler.tiles import get_tile, set_scene_asset_urls, get_cached_asset_urls
from satellite_tiler.metadata import get_scene_bounds, get_zoom_levels, get_band_statistics
from satellite_tiler.encoding import encode
from satellite_tiler.bands import get_rgb_bands, get_false_color_bands
from satellite_tiler.parsers import detect_platform


def discover_satellite_data(lat: float, lon: float) -> Dict[str, Any]:
    """Discover available satellite missions at a geographic location.
    
    Use this tool FIRST when you need to find out what satellite imagery 
    is available for a specific location before fetching tiles.
    
    Args:
        lat: Latitude in decimal degrees (-90 to 90)
        lon: Longitude in decimal degrees (-180 to 180)
    
    Returns:
        Dictionary with:
        - missions: List of available missions with bands and resolution info
        - location: The queried coordinates
        - message: Human-readable summary
    
    Example:
        >>> result = discover_satellite_data(lat=-27.47, lon=153.02)
        >>> print(result["message"])
        "Found 2 satellite missions covering this location"
    """
    try:
        missions = discover(lat, lon)
        
        mission_list = []
        for m in missions:
            mission_list.append({
                "platform": m.platform.value,
                "bands": [b.name for b in m.bands],
                "resolution_meters": m.resolution,
                "date_range": {
                    "start": m.date_range[0],
                    "end": m.date_range[1],
                },
                "description": _get_platform_description(m.platform),
            })
        
        return {
            "missions": mission_list,
            "location": {"lat": lat, "lon": lon},
            "message": f"Found {len(missions)} satellite mission(s) covering this location",
        }
    except Exception as e:
        return {
            "missions": [],
            "location": {"lat": lat, "lon": lon},
            "message": f"Error discovering missions: {str(e)}",
            "error": True,
        }


def list_satellite_scenes(
    lat: float,
    lon: float,
    platform: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    max_cloud_cover: float = 20.0,
    limit: int = 5,
) -> Dict[str, Any]:
    """List available satellite scenes for a mission at a location.
    
    Use this tool AFTER discover_satellite_data to find specific scenes
    you can fetch tiles from. Returns scenes sorted by date (newest first).
    
    This tool automatically caches asset URLs so you can immediately
    call get_satellite_tile with just the scene_id.
    
    Args:
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees  
        platform: Satellite platform ("landsat8", "sentinel2", or "cbers")
        start_date: Filter scenes after this date (ISO format: "2024-01-01")
        end_date: Filter scenes before this date (ISO format: "2024-12-31")
        max_cloud_cover: Maximum cloud cover percentage (default 20%)
        limit: Maximum scenes to return (default 5)
    
    Returns:
        Dictionary with:
        - scenes: List of scenes with id, date, cloud_cover
        - filters_applied: The filters that were used
        - message: Human-readable summary
        - recommended_scene: The best scene to use (lowest cloud, most recent)
    
    Example:
        >>> result = list_satellite_scenes(lat=-27.47, lon=153.02, platform="sentinel2")
        >>> scene_id = result["recommended_scene"]["scene_id"]
    """
    from datetime import date as date_type
    
    # Parse platform
    try:
        sat_platform = SatellitePlatform(platform.lower())
    except ValueError:
        return {
            "scenes": [],
            "filters_applied": {"platform": platform},
            "message": f"Unknown platform '{platform}'. Use 'landsat8', 'sentinel2', or 'cbers'.",
            "error": True,
        }
    
    # Parse dates
    start = None
    end = None
    try:
        if start_date:
            start = date_type.fromisoformat(start_date)
        if end_date:
            end = date_type.fromisoformat(end_date)
    except ValueError as e:
        return {
            "scenes": [],
            "filters_applied": {"platform": platform},
            "message": f"Invalid date format: {e}. Use ISO format like '2024-01-15'.",
            "error": True,
        }
    
    try:
        scenes = list_scenes(
            lat=lat,
            lon=lon,
            platform=sat_platform,
            start_date=start,
            end_date=end,
            max_cloud_cover=max_cloud_cover,
            limit=limit,
        )
    except Exception as e:
        return {
            "scenes": [],
            "filters_applied": {"platform": platform},
            "message": f"Error querying scenes: {str(e)}",
            "error": True,
        }
    
    scene_list = []
    for s in scenes:
        # Auto-cache asset URLs for later use
        if s.asset_urls:
            set_scene_asset_urls(s.scene_id, s.asset_urls)
        
        scene_list.append({
            "scene_id": s.scene_id,
            "date": s.acquisition_date.isoformat(),
            "cloud_cover": s.cloud_cover,
            "platform": s.platform.value,
        })
    
    filters = {
        "platform": platform,
        "max_cloud_cover": max_cloud_cover,
        "location": {"lat": lat, "lon": lon},
    }
    if start_date:
        filters["start_date"] = start_date
    if end_date:
        filters["end_date"] = end_date
    
    result = {
        "scenes": scene_list,
        "filters_applied": filters,
    }
    
    if scenes:
        # Recommend the best scene (lowest cloud cover among recent)
        best = min(scenes, key=lambda s: s.cloud_cover)
        result["recommended_scene"] = {
            "scene_id": best.scene_id,
            "date": best.acquisition_date.isoformat(),
            "cloud_cover": best.cloud_cover,
        }
        result["message"] = f"Found {len(scenes)} scene(s). Recommended: {best.scene_id} ({best.cloud_cover}% cloud)"
    else:
        result["recommended_scene"] = None
        result["message"] = f"No scenes found. Try increasing max_cloud_cover or adjusting date range."
    
    return result


def get_satellite_tile(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
    bands: Optional[List[str]] = None,
    scale: int = 1,
    format: str = "png",
    output_path: Optional[str] = None,
) -> Dict[str, Any]:
    """Fetch a satellite imagery tile for a specific scene and location.
    
    Use this tool AFTER list_satellite_scenes to get actual imagery.
    Saves the tile to a file and returns the file path.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (7-15, higher = more detail, default 12)
        bands: List of bands for RGB composite. If not specified, uses default RGB.
               Landsat: ["B4", "B3", "B2"] for true color, ["B5", "B4", "B3"] for false color
               Sentinel-2: ["B04", "B03", "B02"] for true color
        scale: Tile scale factor (1=256px, 2=512px, default 1)
        format: Output format ("png", "jpeg", or "webp", default "png")
        output_path: Optional path to save the image. If not provided, auto-generates filename.
    
    Returns:
        Dictionary with:
        - file_path: Path to the saved image file
        - format: Image format used
        - bounds: Geographic bounds of the tile [west, south, east, north]
        - tile_size: Pixel dimensions of the tile
        - bands_used: Which bands were included
        - message: Human-readable summary
    
    Example:
        >>> result = get_satellite_tile(
        ...     scene_id="S2B_56JNQ_20260109_0_L2A",
        ...     lat=-27.47, lon=153.02, zoom=12
        ... )
        >>> print(result["file_path"])  # e.g., "satellite_tile_S2B_56JNQ_z12.png"
    """
    from pathlib import Path
    
    try:
        # Check if we have cached asset URLs
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return {
                "file_path": None,
                "format": format,
                "bounds": None,
                "bands_used": bands or [],
                "message": f"No cached data for scene {scene_id}. Call list_satellite_scenes first to load scene data.",
                "error": True,
            }
        
        result = get_tile(
            scene_id=scene_id,
            lat=lat,
            lon=lon,
            zoom=zoom,
            bands=bands,
            scale=scale,
            asset_urls=asset_urls,
        )
        
        # Encode to image format
        image_bytes = encode(result.data, format=format)
        
        # Generate output path if not provided
        if output_path is None:
            # Create a descriptive filename
            scene_short = scene_id[:20] if len(scene_id) > 20 else scene_id
            output_path = f"satellite_tile_{scene_short}_z{zoom}.{format}"
        
        # Save to file
        output_file = Path(output_path)
        output_file.write_bytes(image_bytes)
        
        # Determine what bands were used
        if bands:
            bands_used = bands
        else:
            platform = detect_platform(scene_id)
            bands_used = get_rgb_bands(platform)
        
        return {
            "file_path": str(output_file.absolute()),
            "format": format,
            "bounds": list(result.bounds),
            "tile_size": result.data.shape[-1],
            "bands_used": bands_used,
            "message": f"Saved {result.data.shape[-1]}x{result.data.shape[-1]} tile to {output_path}",
        }
    
    except Exception as e:
        return {
            "file_path": None,
            "format": format,
            "bounds": None,
            "bands_used": bands or [],
            "message": f"Error fetching tile: {str(e)}",
            "error": True,
        }


def get_scene_info(scene_id: str, bands: Optional[List[str]] = None) -> Dict[str, Any]:
    """Get detailed metadata and statistics about a satellite scene.
    
    Use this tool to get information about a scene's coverage,
    acquisition details, and pixel value statistics for quality checking.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        bands: Optional list of bands to get statistics for (default: RGB bands)
    
    Returns:
        Dictionary with:
        - scene_id: The scene identifier
        - platform: Satellite platform
        - acquisition_date: When the image was captured
        - bounds: Geographic bounds [west, south, east, north]
        - zoom_levels: Recommended min/max zoom levels
        - statistics: Pixel statistics per band (min, max, mean, percentiles)
        - message: Human-readable summary
    
    Example:
        >>> result = get_scene_info("S2B_56JNQ_20260109_0_L2A")
        >>> print(result["statistics"]["B04"])
    """
    try:
        # Check if we have cached asset URLs
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            # Return basic info without statistics
            from satellite_tiler.parsers import parse
            platform = detect_platform(scene_id)
            components = parse(scene_id)
            zoom_levels = get_zoom_levels(scene_id)
            
            return {
                "scene_id": scene_id,
                "platform": platform.value,
                "acquisition_date": components.acquisition_date.isoformat(),
                "bounds": None,
                "zoom_levels": zoom_levels,
                "statistics": None,
                "message": f"Basic info for {scene_id}. Call list_satellite_scenes first for full metadata.",
            }
        
        # Get full metadata with statistics
        platform = detect_platform(scene_id)
        from satellite_tiler.parsers import parse
        components = parse(scene_id)
        
        bounds_info = get_scene_bounds(scene_id)
        zoom_levels = get_zoom_levels(scene_id)
        
        # Default bands if not specified
        if bands is None:
            bands = get_rgb_bands(platform)
        
        stats = get_band_statistics(scene_id, bands)
        
        return {
            "scene_id": scene_id,
            "platform": platform.value,
            "acquisition_date": components.acquisition_date.isoformat(),
            "bounds": bounds_info["bounds"],
            "zoom_levels": zoom_levels,
            "statistics": stats,
            "message": f"Scene from {platform.value} acquired on {components.acquisition_date.isoformat()}",
        }
    
    except Exception as e:
        return {
            "scene_id": scene_id,
            "platform": None,
            "bounds": None,
            "statistics": None,
            "message": f"Error getting scene info: {str(e)}",
            "error": True,
        }


def analyze_tile_quality(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
    bands: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Analyze the quality of a tile by comparing to scene statistics.
    
    Use this tool to check if a tile has valid data or potential issues
    like cloud cover, missing data, or sensor artifacts.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (default 12)
        bands: Bands to analyze (default: RGB bands)
    
    Returns:
        Dictionary with:
        - valid: True if tile data looks good
        - bands: Per-band analysis with value ranges and valid pixel percentage
        - warnings: List of any quality issues detected
        - message: Human-readable summary
    
    Example:
        >>> result = analyze_tile_quality("S2B_56JNQ_20260109_0_L2A", lat=-27.47, lon=153.02)
        >>> if not result["valid"]:
        ...     print(result["warnings"])
    """
    try:
        from satellite_tiler.metadata import validate_tile_data
        
        # Check if we have cached asset URLs
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return {
                "valid": False,
                "bands": {},
                "warnings": ["No cached data for scene. Call list_satellite_scenes first."],
                "message": f"Cannot analyze - scene {scene_id} not loaded.",
                "error": True,
            }
        
        # Get default bands if not specified
        if bands is None:
            platform = detect_platform(scene_id)
            bands = get_rgb_bands(platform)
        
        # Fetch the tile
        tile_result = get_tile(
            scene_id=scene_id,
            lat=lat,
            lon=lon,
            zoom=zoom,
            bands=bands,
            asset_urls=asset_urls,
        )
        
        # Validate against scene statistics
        validation = validate_tile_data(tile_result.data, scene_id, bands)
        
        if validation["valid"]:
            message = "Tile quality looks good - all bands within expected ranges"
        else:
            message = f"Tile has quality issues: {len(validation['warnings'])} warning(s)"
        
        return {
            "valid": validation["valid"],
            "bands": validation["bands"],
            "warnings": validation["warnings"],
            "message": message,
        }
    
    except Exception as e:
        return {
            "valid": False,
            "bands": {},
            "warnings": [str(e)],
            "message": f"Error analyzing tile: {str(e)}",
            "error": True,
        }


def _get_platform_description(platform: SatellitePlatform) -> str:
    """Get human-readable description for a platform."""
    descriptions = {
        SatellitePlatform.LANDSAT8: "Landsat 8/9 - 30m resolution, thermal bands available",
        SatellitePlatform.SENTINEL2: "Sentinel-2 - 10m resolution, best for detail",
        SatellitePlatform.CBERS: "CBERS-4 - 20m resolution, South America coverage",
    }
    return descriptions.get(platform, "Unknown platform")


# Export all tools for easy registration
SATELLITE_TOOLS = [
    discover_satellite_data,
    list_satellite_scenes,
    get_satellite_tile,
    get_scene_info,
    analyze_tile_quality,
]


# AWS Strands Agents integration
def get_strands_tools():
    """Get tools formatted for AWS Strands Agents.
    
    Returns a list of tool definitions compatible with strands-agents.
    
    Example:
        from satellite_tiler.tools import get_strands_tools
        from strands import Agent
        
        agent = Agent(tools=get_strands_tools())
    """
    try:
        from strands import tool
        
        return [
            tool(discover_satellite_data),
            tool(list_satellite_scenes),
            tool(get_satellite_tile),
            tool(get_scene_info),
            tool(analyze_tile_quality),
        ]
    except ImportError:
        raise ImportError(
            "strands-agents is required for Strands integration. "
            "Install with: pip install strands-agents"
        )
