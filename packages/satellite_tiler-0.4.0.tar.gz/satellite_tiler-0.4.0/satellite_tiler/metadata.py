"""Metadata retrieval for satellite-tiler.

This module provides functions for retrieving metadata about satellite scenes,
including bounds, band statistics, and zoom levels.
"""

import json
from typing import Dict, Any, Tuple, Optional, List
from dataclasses import asdict

import numpy as np

from satellite_tiler.models import (
    SatellitePlatform,
    MissionInfo,
    SceneInfo,
    BandInfo,
)
from satellite_tiler.parsers import parse, detect_platform
from satellite_tiler.tiles import get_cached_asset_urls, _validate_aws_credentials
from satellite_tiler.exceptions import SatelliteTilerError

# Try to import rio-tiler for COG access
try:
    from rio_tiler.io import Reader
    import rasterio
    HAS_RIO_TILER = True
except ImportError:
    HAS_RIO_TILER = False


def get_scene_bounds(scene_id: str) -> Dict[str, Any]:
    """Get geographic bounds for a scene from STAC metadata.
    
    Uses cached asset URLs from list_scenes() or queries the COG directly.
    
    Args:
        scene_id: Scene identifier string
    
    Returns:
        Dictionary with bounds in EPSG:4326:
        {
            "bounds": [west, south, east, north],
            "crs": "EPSG:4326"
        }
    
    Raises:
        SatelliteTilerError: If bounds cannot be retrieved
    """
    _validate_aws_credentials()
    
    if not HAS_RIO_TILER:
        raise ImportError("rio-tiler is required for metadata. Install with: pip install rio-tiler")
    
    # Try to get bounds from cached asset URLs (from STAC response)
    asset_urls = get_cached_asset_urls(scene_id)
    if not asset_urls:
        raise SatelliteTilerError(
            f"No cached asset URLs for scene {scene_id}. "
            "Call list_scenes() first or provide asset_urls to get_tile()."
        )
    
    # Get any band URL to read bounds from
    platform = detect_platform(scene_id)
    if platform == SatellitePlatform.LANDSAT8:
        url = asset_urls.get("red") or asset_urls.get("blue") or next(iter(asset_urls.values()))
    elif platform == SatellitePlatform.SENTINEL2:
        url = asset_urls.get("red") or asset_urls.get("blue") or next(iter(asset_urls.values()))
    else:
        url = next(iter(asset_urls.values()))
    
    try:
        with rasterio.Env(AWS_REQUEST_PAYER="requester"):
            with Reader(url) as src:
                info = src.info()
                native_bounds = info.bounds  # tuple (left, bottom, right, top)
                native_crs = info.crs
                
                # Transform bounds to WGS84 if needed
                if native_crs and "4326" not in str(native_crs):
                    from rasterio.warp import transform_bounds
                    wgs84_bounds = transform_bounds(native_crs, "EPSG:4326", *native_bounds)
                    return {
                        "bounds": list(wgs84_bounds),
                        "crs": "EPSG:4326",
                    }
                else:
                    return {
                        "bounds": list(native_bounds),
                        "crs": "EPSG:4326",
                    }
    except Exception as e:
        raise SatelliteTilerError(f"Failed to get bounds for {scene_id}: {e}") from e


def get_band_statistics(
    scene_id: str,
    bands: List[str],
    pmin: float = 2.0,
    pmax: float = 98.0,
    max_size: int = 1024,
) -> Dict[str, Dict[str, float]]:
    """Get pixel statistics for specific bands.
    
    Reads a downsampled version of each band to compute statistics efficiently.
    
    Args:
        scene_id: Scene identifier string
        bands: List of band names to analyze (e.g., ["B4", "B3", "B2"])
        pmin: Lower percentile (default 2.0)
        pmax: Upper percentile (default 98.0)
        max_size: Maximum dimension for statistics computation (default 1024)
    
    Returns:
        Dictionary mapping band name to statistics:
        {
            "B4": {
                "min": 0.0,
                "max": 10000.0,
                "mean": 3500.0,
                "std": 1200.0,
                "p2": 500.0,
                "p98": 8000.0,
                "valid_pixels": 1048576,
                "nodata_pixels": 0
            },
            ...
        }
    
    Raises:
        SatelliteTilerError: If statistics cannot be computed
    """
    _validate_aws_credentials()
    
    if not HAS_RIO_TILER:
        raise ImportError("rio-tiler is required for metadata. Install with: pip install rio-tiler")
    
    asset_urls = get_cached_asset_urls(scene_id)
    if not asset_urls:
        raise SatelliteTilerError(
            f"No cached asset URLs for scene {scene_id}. "
            "Call list_scenes() first."
        )
    
    platform = detect_platform(scene_id)
    
    # Map band names to asset keys
    if platform == SatellitePlatform.LANDSAT8:
        band_to_asset = {
            "B1": "coastal", "B2": "blue", "B3": "green", "B4": "red",
            "B5": "nir08", "B6": "swir16", "B7": "swir22",
            "B10": "lwir11", "B11": "lwir12",
        }
    elif platform == SatellitePlatform.SENTINEL2:
        band_to_asset = {
            "B01": "coastal", "B02": "blue", "B03": "green", "B04": "red",
            "B05": "rededge1", "B06": "rededge2", "B07": "rededge3",
            "B08": "nir", "B8A": "nir08", "B09": "nir09",
            "B11": "swir16", "B12": "swir22",
        }
    else:
        band_to_asset = {}
    
    statistics = {}
    
    for band in bands:
        # Find the asset URL for this band
        asset_key = band_to_asset.get(band, band.lower())
        url = asset_urls.get(asset_key) or asset_urls.get(band) or asset_urls.get(band.lower())
        
        if not url:
            raise SatelliteTilerError(f"No URL found for band {band} in scene {scene_id}")
        
        try:
            with rasterio.Env(AWS_REQUEST_PAYER="requester"):
                with Reader(url) as src:
                    # Read overview for efficiency
                    img = src.preview(max_size=max_size)
                    data = img.data[0].astype(np.float64)
                    mask = img.mask
                    
                    # Apply mask - valid pixels where mask > 0 (handles both 255 and 65535)
                    valid_mask = mask > 0
                    valid_data = data[valid_mask]
                    
                    if len(valid_data) == 0:
                        statistics[band] = {
                            "min": None,
                            "max": None,
                            "mean": None,
                            "std": None,
                            f"p{int(pmin)}": None,
                            f"p{int(pmax)}": None,
                            "valid_pixels": 0,
                            "nodata_pixels": int(data.size),
                        }
                    else:
                        statistics[band] = {
                            "min": float(np.min(valid_data)),
                            "max": float(np.max(valid_data)),
                            "mean": float(np.mean(valid_data)),
                            "std": float(np.std(valid_data)),
                            f"p{int(pmin)}": float(np.percentile(valid_data, pmin)),
                            f"p{int(pmax)}": float(np.percentile(valid_data, pmax)),
                            "valid_pixels": int(np.sum(valid_mask)),
                            "nodata_pixels": int(np.sum(~valid_mask)),
                        }
        except Exception as e:
            raise SatelliteTilerError(f"Failed to compute statistics for band {band}: {e}") from e
    
    return statistics


def get_scene_metadata(
    scene_id: str,
    bands: Optional[List[str]] = None,
    pmin: float = 2.0,
    pmax: float = 98.0,
) -> Dict[str, Any]:
    """Get detailed metadata for a scene including bounds and band statistics.
    
    Args:
        scene_id: Scene identifier string
        bands: List of bands to get statistics for (default: RGB bands)
        pmin: Lower percentile for statistics (default 2)
        pmax: Upper percentile for statistics (default 98)
    
    Returns:
        Dictionary with scene metadata including:
        - bounds: Geographic bounds [west, south, east, north]
        - crs: Coordinate reference system
        - statistics: Band statistics (min, max, percentiles, etc.)
        - platform: Satellite platform
        - acquisition_date: Date of acquisition
    
    Raises:
        SatelliteTilerError: If metadata cannot be retrieved
    """
    platform = detect_platform(scene_id)
    components = parse(scene_id)
    
    # Get bounds
    bounds_info = get_scene_bounds(scene_id)
    
    # Default bands if not specified
    if bands is None:
        if platform == SatellitePlatform.LANDSAT8:
            bands = ["B4", "B3", "B2"]
        elif platform == SatellitePlatform.SENTINEL2:
            bands = ["B04", "B03", "B02"]
        else:
            bands = ["B7", "B6", "B5"]
    
    # Get statistics
    statistics = get_band_statistics(scene_id, bands, pmin, pmax)
    
    # Get acquisition date
    if platform == SatellitePlatform.LANDSAT8:
        acq_date = components.acquisition_date.isoformat()
    elif platform == SatellitePlatform.SENTINEL2:
        acq_date = components.acquisition_date.isoformat()
    else:
        acq_date = components.acquisition_date.isoformat()
    
    return {
        "scene_id": scene_id,
        "platform": platform.value,
        "acquisition_date": acq_date,
        "bounds": bounds_info["bounds"],
        "crs": bounds_info["crs"],
        "statistics": statistics,
    }


def validate_tile_data(
    tile_data: np.ndarray,
    scene_id: str,
    bands: List[str],
) -> Dict[str, Any]:
    """Validate tile data against scene statistics for error checking.
    
    Compares tile pixel values against expected ranges from scene statistics.
    Useful for detecting data quality issues or fetch errors.
    
    Args:
        tile_data: Tile data array with shape (bands, height, width)
        scene_id: Scene identifier string
        bands: List of band names corresponding to tile_data channels
    
    Returns:
        Dictionary with validation results:
        {
            "valid": True/False,
            "bands": {
                "B4": {
                    "tile_min": 100,
                    "tile_max": 8000,
                    "expected_min": 0,
                    "expected_max": 10000,
                    "within_range": True,
                    "percent_valid": 99.5
                },
                ...
            },
            "warnings": ["list of any warnings"]
        }
    """
    # Get scene statistics
    stats = get_band_statistics(scene_id, bands)
    
    results = {
        "valid": True,
        "bands": {},
        "warnings": [],
    }
    
    for i, band in enumerate(bands):
        band_data = tile_data[i] if tile_data.ndim == 3 else tile_data
        band_stats = stats.get(band, {})
        
        tile_min = float(np.min(band_data))
        tile_max = float(np.max(band_data))
        expected_min = band_stats.get("min", 0)
        expected_max = band_stats.get("max", 65535)
        
        # Check if tile values are within expected range (with 10% tolerance)
        tolerance = (expected_max - expected_min) * 0.1 if expected_max and expected_min else 1000
        within_range = (
            tile_min >= expected_min - tolerance and
            tile_max <= expected_max + tolerance
        )
        
        # Calculate percent of non-zero pixels
        percent_valid = float(np.sum(band_data > 0) / band_data.size * 100)
        
        results["bands"][band] = {
            "tile_min": tile_min,
            "tile_max": tile_max,
            "expected_min": expected_min,
            "expected_max": expected_max,
            "within_range": within_range,
            "percent_valid": round(percent_valid, 2),
        }
        
        if not within_range:
            results["valid"] = False
            results["warnings"].append(
                f"Band {band} values ({tile_min}-{tile_max}) outside expected range "
                f"({expected_min}-{expected_max})"
            )
        
        if percent_valid < 50:
            results["warnings"].append(
                f"Band {band} has only {percent_valid:.1f}% valid pixels"
            )
    
    return results


def get_zoom_levels(scene_id: str) -> Dict[str, int]:
    """Get appropriate zoom levels for a scene.
    
    Returns min and max zoom levels suitable for web mapping
    based on the native resolution of the satellite platform.
    
    Args:
        scene_id: Scene identifier string
    
    Returns:
        Dictionary with minzoom and maxzoom
    """
    platform = detect_platform(scene_id)
    
    # Zoom levels based on native resolution
    if platform == SatellitePlatform.LANDSAT8:
        # 30m resolution
        return {"minzoom": 7, "maxzoom": 14}
    elif platform == SatellitePlatform.SENTINEL2:
        # 10m resolution
        return {"minzoom": 7, "maxzoom": 15}
    else:  # CBERS
        # 20m resolution
        return {"minzoom": 7, "maxzoom": 14}


def to_json(obj: Any) -> str:
    """Serialize object to JSON string.
    
    Handles dataclasses, enums, and dates.
    
    Args:
        obj: Object to serialize
    
    Returns:
        JSON string
    """
    def default_serializer(o):
        if hasattr(o, 'to_dict'):
            return o.to_dict()
        elif hasattr(o, 'value'):  # Enum
            return o.value
        elif hasattr(o, 'isoformat'):  # date/datetime
            return o.isoformat()
        elif hasattr(o, '__dict__'):
            return o.__dict__
        else:
            raise TypeError(f"Object of type {type(o)} is not JSON serializable")
    
    return json.dumps(obj, default=default_serializer, indent=2)


def from_json(json_str: str, cls: type) -> Any:
    """Deserialize JSON string to object.
    
    Args:
        json_str: JSON string
        cls: Target class (must have from_dict method)
    
    Returns:
        Deserialized object
    """
    data = json.loads(json_str)
    if hasattr(cls, 'from_dict'):
        return cls.from_dict(data)
    return data
