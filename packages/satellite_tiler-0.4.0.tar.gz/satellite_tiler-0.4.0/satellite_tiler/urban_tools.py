"""Urban analysis agent tools for satellite-tiler.

This module provides Strands Agent tools for urban development and
environmental analysis applications including heat mapping, vegetation
assessment, land classification, and change detection.

All tools return JSON-serializable dictionaries with human-readable messages.
"""

import base64
from typing import Dict, List, Optional, Any

import numpy as np

from satellite_tiler.models import SatellitePlatform
from satellite_tiler.tiles import get_tile, get_cached_asset_urls
from satellite_tiler.parsers import detect_platform
from satellite_tiler.bands import get_rgb_bands
from satellite_tiler.encoding import encode

from satellite_tiler.indices import (
    SpectralIndex,
    calculate_ndvi,
    calculate_ndbi,
    calculate_ndwi,
    calculate_mndwi,
    calculate_evi,
    calculate_savi,
    get_bands_for_index,
    BAND_MAPPINGS,
)
from satellite_tiler.heat_analysis import (
    analyze_heat,
    detect_heat_islands,
    has_thermal_bands,
    get_thermal_bands,
    celsius_to_fahrenheit,
)
from satellite_tiler.vegetation_analysis import (
    analyze_vegetation,
    compare_vegetation,
    colorize_classification as colorize_vegetation,
)
from satellite_tiler.land_classification import (
    classify_from_bands,
    get_colorized_map as colorize_land_use,
)
from satellite_tiler.change_detection import (
    detect_vegetation_change,
    detect_urban_expansion,
    colorize_change,
)


def _error_response(message: str, **kwargs) -> Dict[str, Any]:
    """Create standardized error response."""
    return {
        "error": True,
        "message": message,
        **kwargs
    }


def _encode_array_as_image(
    data: np.ndarray,
    format: str = "png",
) -> str:
    """Encode numpy array as base64 image."""
    # Normalize to 0-255 if needed
    if data.dtype != np.uint8:
        if data.max() <= 1.0:
            data = (data * 255).astype(np.uint8)
        else:
            data = ((data - data.min()) / (data.max() - data.min()) * 255).astype(np.uint8)
    
    # Ensure 3D for RGB
    if len(data.shape) == 2:
        data = np.stack([data, data, data], axis=-1)
    
    # Convert to CHW format for encoding
    if data.shape[-1] == 3:
        data = np.transpose(data, (2, 0, 1))
    
    image_bytes = encode(data, format=format)
    return base64.b64encode(image_bytes).decode('utf-8')


def analyze_urban_heat(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
    heat_island_threshold: float = 2.0,
) -> Dict[str, Any]:
    """Analyze urban heat patterns and identify heat islands.
    
    Use this tool to understand thermal characteristics of an area,
    identify urban heat islands, and get recommendations for cooling.
    
    IMPORTANT: This tool requires Landsat imagery (has thermal bands).
    Sentinel-2 does not have thermal bands and cannot be used.
    
    Args:
        scene_id: Scene identifier (must be Landsat for thermal analysis)
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (default 12)
        heat_island_threshold: Temperature above mean to classify as heat island (°C)
    
    Returns:
        Dictionary with:
        - temperature_stats: min, max, mean, std in Celsius and Fahrenheit
        - heat_islands: list of identified heat island regions
        - heat_island_coverage_percent: percentage of area classified as heat island
        - recommendations: cooling intervention suggestions
        - message: human-readable summary
    
    Example:
        >>> result = analyze_urban_heat("LC08_...", lat=-27.47, lon=153.02)
        >>> print(result["message"])
    """
    try:
        # Check platform
        platform = detect_platform(scene_id)
        platform_str = platform.value.lower()
        
        if not has_thermal_bands(platform_str):
            return _error_response(
                f"Thermal analysis requires Landsat imagery. {platform.value} does not have thermal bands.",
                supported_platforms=["landsat8", "landsat9"]
            )
        
        # Check cached asset URLs
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return _error_response(
                f"Scene data not cached. Call list_satellite_scenes first to load scene data.",
                suggestion="Use list_satellite_scenes(lat, lon, 'landsat8') to find and cache scenes"
            )
        
        # Get thermal band
        thermal_bands = get_thermal_bands(platform_str)
        thermal_band = thermal_bands[0]  # Use B10
        
        # Fetch thermal tile
        tile_result = get_tile(
            scene_id=scene_id,
            lat=lat,
            lon=lon,
            zoom=zoom,
            bands=[thermal_band],
            asset_urls=asset_urls,
        )
        
        # Analyze heat
        result = analyze_heat(
            tile_result.data[0] if len(tile_result.data.shape) == 3 else tile_result.data,
            band_name=thermal_band,
            heat_island_threshold=heat_island_threshold,
            is_radiance=False,
        )
        
        # Detect heat islands
        _, heat_islands = detect_heat_islands(
            result.lst_celsius,
            heat_island_threshold
        )
        
        # Generate recommendations
        recommendations = []
        if result.heat_island_area_percent > 20:
            recommendations.append("Consider urban greening initiatives in heat island areas")
            recommendations.append("Evaluate cool roof and pavement programs")
        if result.heat_island_area_percent > 10:
            recommendations.append("Increase tree canopy coverage in affected areas")
        
        return {
            "temperature_stats": {
                "min_c": round(result.min_temp_c, 1),
                "max_c": round(result.max_temp_c, 1),
                "mean_c": round(result.mean_temp_c, 1),
                "std_c": round(result.std_temp_c, 1),
                "min_f": round(celsius_to_fahrenheit(result.min_temp_c), 1),
                "max_f": round(celsius_to_fahrenheit(result.max_temp_c), 1),
                "mean_f": round(celsius_to_fahrenheit(result.mean_temp_c), 1),
            },
            "heat_islands": [hi.to_dict() for hi in heat_islands],
            "heat_island_count": len(heat_islands),
            "heat_island_coverage_percent": round(result.heat_island_area_percent, 1),
            "threshold_c": heat_island_threshold,
            "recommendations": recommendations,
            "bounds": list(tile_result.bounds),
            "message": f"Found {len(heat_islands)} heat island(s) covering {result.heat_island_area_percent:.1f}% of the area. Mean temp: {result.mean_temp_c:.1f}°C ({celsius_to_fahrenheit(result.mean_temp_c):.1f}°F)",
        }
    
    except Exception as e:
        return _error_response(f"Error analyzing heat: {str(e)}")


def analyze_vegetation_health(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
    include_evi: bool = False,
) -> Dict[str, Any]:
    """Analyze vegetation health and coverage using NDVI.
    
    Use this tool to assess vegetation health, identify areas with
    dense vs sparse vegetation, and monitor green infrastructure.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (default 12)
        include_evi: Whether to also calculate EVI (requires blue band)
    
    Returns:
        Dictionary with:
        - ndvi_stats: NDVI statistics (min, max, mean)
        - class_percentages: percentage of each vegetation class
        - health_assessment: overall health rating
        - total_vegetation_percent: total vegetated area
        - message: human-readable summary
    
    Example:
        >>> result = analyze_vegetation_health("S2B_...", lat=-27.47, lon=153.02)
        >>> print(result["class_percentages"])
    """
    try:
        # Check cached asset URLs
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return _error_response(
                f"Scene data not cached. Call list_satellite_scenes first.",
                suggestion="Use list_satellite_scenes(lat, lon, platform) to find and cache scenes"
            )
        
        # Get platform and bands
        platform = detect_platform(scene_id)
        platform_str = platform.value.lower()
        
        if platform_str not in BAND_MAPPINGS:
            return _error_response(f"Unsupported platform: {platform.value}")
        
        mapping = BAND_MAPPINGS[platform_str]
        
        # Fetch required bands
        bands_to_fetch = [mapping["nir"], mapping["red"]]
        if include_evi:
            bands_to_fetch.append(mapping["blue"])
        
        tile_result = get_tile(
            scene_id=scene_id,
            lat=lat,
            lon=lon,
            zoom=zoom,
            bands=bands_to_fetch,
            asset_urls=asset_urls,
        )
        
        # Extract bands
        nir = tile_result.data[0].astype(np.float64)
        red = tile_result.data[1].astype(np.float64)
        blue = tile_result.data[2].astype(np.float64) if include_evi else None
        
        # Analyze vegetation
        result = analyze_vegetation(nir, red, blue, include_evi)
        
        return {
            "ndvi_stats": {
                "min": round(result.ndvi.min_value, 3),
                "max": round(result.ndvi.max_value, 3),
                "mean": round(result.ndvi.mean_value, 3),
                "std": round(result.ndvi.std_value, 3),
            },
            "evi_stats": result.evi.to_dict() if result.evi else None,
            "class_percentages": {k: round(v, 1) for k, v in result.class_percentages.items()},
            "health_assessment": result.health_assessment,
            "total_vegetation_percent": round(result.total_vegetation_percent, 1),
            "bounds": list(tile_result.bounds),
            "message": f"Vegetation health: {result.health_assessment}. {result.total_vegetation_percent:.1f}% vegetated (Dense: {result.class_percentages.get('dense_vegetation', 0):.1f}%, Moderate: {result.class_percentages.get('moderate_vegetation', 0):.1f}%)",
        }
    
    except Exception as e:
        return _error_response(f"Error analyzing vegetation: {str(e)}")


def calculate_spectral_index(
    scene_id: str,
    lat: float,
    lon: float,
    index: str,
    zoom: int = 12,
) -> Dict[str, Any]:
    """Calculate a spectral index for a location.
    
    Supported indices:
    - NDVI: Vegetation (high = dense vegetation)
    - NDBI: Built-up areas (high = urban)
    - NDWI: Water bodies (high = water)
    - MNDWI: Modified water index (better urban/water separation)
    - EVI: Enhanced vegetation (reduces atmospheric effects)
    - SAVI: Soil-adjusted vegetation
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        index: Index name (ndvi, ndbi, ndwi, mndwi, evi, savi)
        zoom: Zoom level (default 12)
    
    Returns:
        Dictionary with:
        - index_name: Name of calculated index
        - statistics: min, max, mean, std values
        - interpretation: guidance on interpreting values
        - message: human-readable summary
    
    Example:
        >>> result = calculate_spectral_index("S2B_...", lat=-27.47, lon=153.02, index="ndvi")
    """
    try:
        # Validate index
        index_upper = index.upper()
        try:
            spectral_index = SpectralIndex(index.lower())
        except ValueError:
            valid_indices = [si.value for si in SpectralIndex]
            return _error_response(
                f"Unknown index '{index}'. Valid indices: {valid_indices}"
            )
        
        # Check cached asset URLs
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return _error_response(
                f"Scene data not cached. Call list_satellite_scenes first."
            )
        
        # Get platform and required bands
        platform = detect_platform(scene_id)
        platform_str = platform.value.lower()
        
        if platform_str not in BAND_MAPPINGS:
            return _error_response(f"Unsupported platform: {platform.value}")
        
        bands_needed = get_bands_for_index(spectral_index, platform_str)
        
        # Fetch bands
        tile_result = get_tile(
            scene_id=scene_id,
            lat=lat,
            lon=lon,
            zoom=zoom,
            bands=list(bands_needed),
            asset_urls=asset_urls,
        )
        
        # Calculate index based on type
        mapping = BAND_MAPPINGS[platform_str]
        
        if spectral_index == SpectralIndex.NDVI:
            result = calculate_ndvi(
                tile_result.data[0].astype(np.float64),
                tile_result.data[1].astype(np.float64)
            )
            interpretation = "High (>0.6): Dense vegetation, Low (<0.2): Bare/urban, Negative: Water"
        
        elif spectral_index == SpectralIndex.NDBI:
            result = calculate_ndbi(
                tile_result.data[0].astype(np.float64),
                tile_result.data[1].astype(np.float64)
            )
            interpretation = "Positive: Built-up/urban areas, Negative: Vegetation/water"
        
        elif spectral_index == SpectralIndex.NDWI:
            result = calculate_ndwi(
                tile_result.data[0].astype(np.float64),
                tile_result.data[1].astype(np.float64)
            )
            interpretation = "Positive: Water bodies, Negative: Land"
        
        elif spectral_index == SpectralIndex.MNDWI:
            result = calculate_mndwi(
                tile_result.data[0].astype(np.float64),
                tile_result.data[1].astype(np.float64)
            )
            interpretation = "Positive: Water (better separation from urban), Negative: Land"
        
        elif spectral_index == SpectralIndex.EVI:
            result = calculate_evi(
                tile_result.data[0].astype(np.float64),
                tile_result.data[1].astype(np.float64),
                tile_result.data[2].astype(np.float64)
            )
            interpretation = "Similar to NDVI but reduces atmospheric effects"
        
        elif spectral_index == SpectralIndex.SAVI:
            result = calculate_savi(
                tile_result.data[0].astype(np.float64),
                tile_result.data[1].astype(np.float64)
            )
            interpretation = "Vegetation index adjusted for soil brightness"
        
        else:
            return _error_response(f"Index {index} calculation not implemented")
        
        return {
            "index_name": index_upper,
            "statistics": {
                "min": round(result.min_value, 3),
                "max": round(result.max_value, 3),
                "mean": round(result.mean_value, 3),
                "std": round(result.std_value, 3),
            },
            "valid_pixels": result.valid_pixel_count,
            "nodata_pixels": result.nodata_pixel_count,
            "interpretation": interpretation,
            "bands_used": list(bands_needed),
            "bounds": list(tile_result.bounds),
            "message": f"{index_upper}: mean={result.mean_value:.3f}, range=[{result.min_value:.3f}, {result.max_value:.3f}]",
        }
    
    except Exception as e:
        return _error_response(f"Error calculating index: {str(e)}")


def classify_land_use(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
) -> Dict[str, Any]:
    """Classify land use types from satellite imagery.
    
    Classifies pixels into: urban, vegetation, water, bare soil, mixed.
    Uses combination of NDVI, NDBI, and NDWI indices.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (default 12)
    
    Returns:
        Dictionary with:
        - class_percentages: percentage of each land use class
        - class_areas_sq_meters: area of each class
        - dominant_class: most common land use
        - indices_used: which indices were used
        - message: human-readable summary
    
    Example:
        >>> result = classify_land_use("S2B_...", lat=-27.47, lon=153.02)
        >>> print(result["class_percentages"])
    """
    try:
        # Check cached asset URLs
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return _error_response(
                f"Scene data not cached. Call list_satellite_scenes first."
            )
        
        # Get platform and bands
        platform = detect_platform(scene_id)
        platform_str = platform.value.lower()
        
        if platform_str not in BAND_MAPPINGS:
            return _error_response(f"Unsupported platform: {platform.value}")
        
        mapping = BAND_MAPPINGS[platform_str]
        
        # Fetch required bands (NIR, Red, Green, SWIR)
        bands_to_fetch = [
            mapping["nir"],
            mapping["red"],
            mapping["green"],
            mapping["swir1"],
        ]
        
        tile_result = get_tile(
            scene_id=scene_id,
            lat=lat,
            lon=lon,
            zoom=zoom,
            bands=bands_to_fetch,
            asset_urls=asset_urls,
        )
        
        # Extract bands
        nir = tile_result.data[0].astype(np.float64)
        red = tile_result.data[1].astype(np.float64)
        green = tile_result.data[2].astype(np.float64)
        swir = tile_result.data[3].astype(np.float64)
        
        # Classify
        result = classify_from_bands(nir, red, green, swir)
        
        # Find dominant class
        dominant_class = max(result.class_percentages, key=result.class_percentages.get)
        
        return {
            "class_percentages": {k: round(v, 1) for k, v in result.class_percentages.items()},
            "class_areas_sq_meters": {k: round(v, 0) for k, v in result.class_areas_sq_meters.items()},
            "dominant_class": dominant_class,
            "indices_used": result.indices_used,
            "bounds": list(tile_result.bounds),
            "message": f"Land use: {dominant_class} dominant ({result.class_percentages[dominant_class]:.1f}%). Urban: {result.class_percentages.get('urban', 0):.1f}%, Vegetation: {result.class_percentages.get('vegetation', 0):.1f}%, Water: {result.class_percentages.get('water', 0):.1f}%",
        }
    
    except Exception as e:
        return _error_response(f"Error classifying land use: {str(e)}")


def detect_changes(
    scene_id_before: str,
    scene_id_after: str,
    lat: float,
    lon: float,
    change_type: str = "vegetation",
    zoom: int = 12,
) -> Dict[str, Any]:
    """Detect changes between two satellite scenes.
    
    Supports vegetation change (NDVI) and urban expansion (NDBI) detection.
    
    Args:
        scene_id_before: Scene identifier for earlier date
        scene_id_after: Scene identifier for later date
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        change_type: Type of change to detect ("vegetation" or "urban")
        zoom: Zoom level (default 12)
    
    Returns:
        Dictionary with:
        - change_type: type of change detected
        - category_percentages: percentage of each change category
        - total_changed_percent: total area that changed
        - mean_change: average change value
        - summary: interpretation of changes
        - message: human-readable summary
    
    Example:
        >>> result = detect_changes("S2B_..._2024", "S2B_..._2025", lat=-27.47, lon=153.02)
    """
    try:
        # Check cached asset URLs for both scenes
        asset_urls_before = get_cached_asset_urls(scene_id_before)
        asset_urls_after = get_cached_asset_urls(scene_id_after)
        
        if not asset_urls_before:
            return _error_response(
                f"Before scene not cached. Call list_satellite_scenes first.",
                scene_id=scene_id_before
            )
        if not asset_urls_after:
            return _error_response(
                f"After scene not cached. Call list_satellite_scenes first.",
                scene_id=scene_id_after
            )
        
        # Get platform and bands
        platform = detect_platform(scene_id_before)
        platform_str = platform.value.lower()
        
        if platform_str not in BAND_MAPPINGS:
            return _error_response(f"Unsupported platform: {platform.value}")
        
        mapping = BAND_MAPPINGS[platform_str]
        
        if change_type.lower() == "vegetation":
            # Fetch NIR and Red bands
            bands = [mapping["nir"], mapping["red"]]
            
            tile_before = get_tile(
                scene_id=scene_id_before,
                lat=lat, lon=lon, zoom=zoom,
                bands=bands, asset_urls=asset_urls_before,
            )
            tile_after = get_tile(
                scene_id=scene_id_after,
                lat=lat, lon=lon, zoom=zoom,
                bands=bands, asset_urls=asset_urls_after,
            )
            
            result = detect_vegetation_change(
                tile_before.data[0].astype(np.float64),
                tile_before.data[1].astype(np.float64),
                tile_after.data[0].astype(np.float64),
                tile_after.data[1].astype(np.float64),
            )
            
            # Interpret changes
            if result.mean_change > 0.1:
                summary = "Significant vegetation gain detected"
            elif result.mean_change < -0.1:
                summary = "Significant vegetation loss detected"
            else:
                summary = "No significant vegetation change"
            
        elif change_type.lower() == "urban":
            # Fetch NIR and SWIR bands
            bands = [mapping["nir"], mapping["swir1"]]
            
            tile_before = get_tile(
                scene_id=scene_id_before,
                lat=lat, lon=lon, zoom=zoom,
                bands=bands, asset_urls=asset_urls_before,
            )
            tile_after = get_tile(
                scene_id=scene_id_after,
                lat=lat, lon=lon, zoom=zoom,
                bands=bands, asset_urls=asset_urls_after,
            )
            
            expansion_result = detect_urban_expansion(
                tile_before.data[0].astype(np.float64),
                tile_before.data[1].astype(np.float64),
                tile_after.data[0].astype(np.float64),
                tile_after.data[1].astype(np.float64),
            )
            
            return {
                "change_type": "urban_expansion",
                "new_urban_percent": round(expansion_result.new_urban_percent, 1),
                "new_urban_area_sq_meters": round(expansion_result.new_urban_area_sq_meters, 0),
                "urban_before_percent": round(expansion_result.urban_before_percent, 1),
                "urban_after_percent": round(expansion_result.urban_after_percent, 1),
                "expansion_direction": expansion_result.expansion_direction,
                "bounds": list(tile_after.bounds),
                "message": f"Urban expansion: {expansion_result.new_urban_percent:.1f}% new urban area ({expansion_result.new_urban_area_sq_meters:.0f} sq m). Direction: {expansion_result.expansion_direction or 'N/A'}",
            }
        
        else:
            return _error_response(
                f"Unknown change type '{change_type}'. Use 'vegetation' or 'urban'."
            )
        
        return {
            "change_type": change_type,
            "category_percentages": {k: round(v, 1) for k, v in result.category_percentages.items()},
            "total_changed_percent": round(result.total_changed_percent, 1),
            "mean_change": round(result.mean_change, 3),
            "change_histogram": result.change_histogram,
            "summary": summary,
            "bounds": list(tile_after.bounds),
            "message": f"{change_type.capitalize()} change: {result.total_changed_percent:.1f}% changed. {summary}. Mean change: {result.mean_change:.3f}",
        }
    
    except Exception as e:
        return _error_response(f"Error detecting changes: {str(e)}")


def get_heat_recommendations(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
) -> Dict[str, Any]:
    """Get cooling recommendations based on heat and vegetation analysis.
    
    Combines heat island detection with vegetation analysis to provide
    actionable recommendations for urban cooling interventions.
    
    Args:
        scene_id: Landsat scene identifier
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (default 12)
    
    Returns:
        Dictionary with:
        - heat_analysis: summary of heat conditions
        - vegetation_analysis: summary of vegetation coverage
        - recommendations: prioritized list of cooling interventions
        - priority_areas: areas most in need of intervention
        - message: human-readable summary
    """
    try:
        # First do heat analysis
        heat_result = analyze_urban_heat(scene_id, lat, lon, zoom)
        
        if heat_result.get("error"):
            return heat_result
        
        # Then do vegetation analysis
        veg_result = analyze_vegetation_health(scene_id, lat, lon, zoom)
        
        if veg_result.get("error"):
            # Heat analysis worked but vegetation didn't - still provide heat recommendations
            recommendations = heat_result.get("recommendations", [])
            return {
                "heat_analysis": heat_result.get("temperature_stats"),
                "vegetation_analysis": None,
                "recommendations": recommendations,
                "priority_areas": [],
                "message": f"Heat analysis complete. {len(recommendations)} recommendations generated.",
            }
        
        # Generate comprehensive recommendations
        recommendations = []
        priority_areas = []
        
        heat_coverage = heat_result.get("heat_island_coverage_percent", 0)
        veg_coverage = veg_result.get("total_vegetation_percent", 0)
        dense_veg = veg_result.get("class_percentages", {}).get("dense_vegetation", 0)
        
        # High heat, low vegetation = highest priority
        if heat_coverage > 20 and veg_coverage < 30:
            recommendations.append("URGENT: Implement urban greening program - high heat, low vegetation")
            priority_areas.append("Heat islands with <30% vegetation coverage")
        
        if heat_coverage > 10:
            recommendations.append("Install cool roofs on buildings in heat island areas")
            recommendations.append("Use reflective pavement materials in high-heat zones")
        
        if veg_coverage < 40:
            recommendations.append("Increase tree canopy coverage to at least 40%")
            recommendations.append("Create pocket parks in areas with low vegetation")
        
        if dense_veg < 20:
            recommendations.append("Plant more trees to increase dense vegetation coverage")
        
        # General recommendations
        recommendations.append("Maintain existing green spaces and tree canopy")
        recommendations.append("Consider green infrastructure in new developments")
        
        return {
            "heat_analysis": {
                "mean_temp_c": heat_result.get("temperature_stats", {}).get("mean_c"),
                "heat_island_coverage": heat_coverage,
                "heat_island_count": heat_result.get("heat_island_count", 0),
            },
            "vegetation_analysis": {
                "total_vegetation_percent": veg_coverage,
                "dense_vegetation_percent": dense_veg,
                "health_assessment": veg_result.get("health_assessment"),
            },
            "recommendations": recommendations,
            "priority_areas": priority_areas,
            "message": f"Analysis complete. Heat islands: {heat_coverage:.1f}%, Vegetation: {veg_coverage:.1f}%. {len(recommendations)} recommendations generated.",
        }
    
    except Exception as e:
        return _error_response(f"Error generating recommendations: {str(e)}")


def analyze_flood_risk_tool(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
) -> Dict[str, Any]:
    """Analyze flood risk and vulnerability for an area.
    
    Combines water body detection, imperviousness analysis, and
    vulnerability scoring to assess flood risk.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (default 12)
    
    Returns:
        Dictionary with:
        - risk_percentages: percentage of each risk level
        - mean_vulnerability: average vulnerability score
        - water_percent: percentage of water bodies
        - impervious_percent: percentage of impervious surface
        - recommendations: flood mitigation recommendations
        - message: human-readable summary
    """
    try:
        from satellite_tiler.flood_analysis import analyze_flood_risk
        
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return _error_response("Scene data not cached. Call list_satellite_scenes first.")
        
        platform = detect_platform(scene_id)
        platform_str = platform.value.lower()
        
        if platform_str not in BAND_MAPPINGS:
            return _error_response(f"Unsupported platform: {platform.value}")
        
        mapping = BAND_MAPPINGS[platform_str]
        bands = [mapping["green"], mapping["nir"], mapping["swir1"], mapping["red"]]
        
        tile_result = get_tile(
            scene_id=scene_id, lat=lat, lon=lon, zoom=zoom,
            bands=bands, asset_urls=asset_urls,
        )
        
        result = analyze_flood_risk(
            tile_result.data[0].astype(np.float64),
            tile_result.data[1].astype(np.float64),
            tile_result.data[2].astype(np.float64),
            tile_result.data[3].astype(np.float64),
        )
        
        return {
            "risk_percentages": {k: round(v, 1) for k, v in result.risk_percentages.items()},
            "mean_vulnerability": round(result.mean_vulnerability, 3),
            "high_risk_percent": round(result.high_risk_percent, 1),
            "water_percent": round(result.water_bodies.water_percent, 1),
            "impervious_percent": round(result.imperviousness.impervious_percent, 1),
            "recommendations": result.recommendations,
            "bounds": list(tile_result.bounds),
            "message": f"Flood risk: {result.high_risk_percent:.1f}% high/very high risk. Water: {result.water_bodies.water_percent:.1f}%, Impervious: {result.imperviousness.impervious_percent:.1f}%",
        }
    except Exception as e:
        return _error_response(f"Error analyzing flood risk: {str(e)}")


def analyze_air_quality_tool(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
) -> Dict[str, Any]:
    """Analyze air quality risk using vegetation and built-up proxies.
    
    Note: This is a proxy-based analysis using land cover indicators.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (default 12)
    
    Returns:
        Dictionary with air quality risk assessment and recommendations
    """
    try:
        from satellite_tiler.air_quality_analysis import analyze_air_quality
        
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return _error_response("Scene data not cached. Call list_satellite_scenes first.")
        
        platform = detect_platform(scene_id)
        platform_str = platform.value.lower()
        mapping = BAND_MAPPINGS[platform_str]
        
        bands = [mapping["nir"], mapping["red"], mapping["swir1"]]
        tile_result = get_tile(
            scene_id=scene_id, lat=lat, lon=lon, zoom=zoom,
            bands=bands, asset_urls=asset_urls,
        )
        
        result = analyze_air_quality(
            tile_result.data[0].astype(np.float64),
            tile_result.data[1].astype(np.float64),
            tile_result.data[2].astype(np.float64),
        )
        
        return {
            "risk_percentages": {k: round(v, 1) for k, v in result.risk_percentages.items()},
            "mean_risk_score": round(result.mean_risk_score, 3),
            "vegetation_percent": round(result.vegetation_percent, 1),
            "built_up_percent": round(result.built_up_percent, 1),
            "recommendations": result.recommendations,
            "bounds": list(tile_result.bounds),
            "message": f"Air quality risk: mean score {result.mean_risk_score:.2f}. Vegetation: {result.vegetation_percent:.1f}%, Built-up: {result.built_up_percent:.1f}%",
        }
    except Exception as e:
        return _error_response(f"Error analyzing air quality: {str(e)}")


def analyze_green_infrastructure_tool(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
) -> Dict[str, Any]:
    """Analyze green infrastructure coverage and connectivity.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (default 12)
    
    Returns:
        Dictionary with green infrastructure analysis
    """
    try:
        from satellite_tiler.green_infrastructure_analysis import analyze_green_infrastructure
        
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return _error_response("Scene data not cached. Call list_satellite_scenes first.")
        
        platform = detect_platform(scene_id)
        platform_str = platform.value.lower()
        mapping = BAND_MAPPINGS[platform_str]
        
        bands = [mapping["nir"], mapping["red"], mapping["swir1"]]
        tile_result = get_tile(
            scene_id=scene_id, lat=lat, lon=lon, zoom=zoom,
            bands=bands, asset_urls=asset_urls,
        )
        
        result = analyze_green_infrastructure(
            tile_result.data[0].astype(np.float64),
            tile_result.data[1].astype(np.float64),
            tile_result.data[2].astype(np.float64),
        )
        
        return {
            "vegetation_percent": round(result.vegetation_percent, 1),
            "vegetation_area_sq_meters": round(result.vegetation_area_sq_meters, 0),
            "connectivity_score": round(result.connectivity_score, 3),
            "fragmentation_index": round(result.fragmentation_index, 3),
            "gap_percent": round(result.gap_percent, 1),
            "priority_areas": result.priority_areas,
            "bounds": list(tile_result.bounds),
            "message": f"Green infrastructure: {result.vegetation_percent:.1f}% vegetated, connectivity {result.connectivity_score:.2f}",
        }
    except Exception as e:
        return _error_response(f"Error analyzing green infrastructure: {str(e)}")


def analyze_water_bodies_tool(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
) -> Dict[str, Any]:
    """Detect and analyze water bodies.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (default 12)
    
    Returns:
        Dictionary with water body analysis
    """
    try:
        from satellite_tiler.water_body_analysis import analyze_water_bodies
        
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return _error_response("Scene data not cached. Call list_satellite_scenes first.")
        
        platform = detect_platform(scene_id)
        platform_str = platform.value.lower()
        mapping = BAND_MAPPINGS[platform_str]
        
        bands = [mapping["green"], mapping["nir"], mapping["red"], mapping["swir1"]]
        tile_result = get_tile(
            scene_id=scene_id, lat=lat, lon=lon, zoom=zoom,
            bands=bands, asset_urls=asset_urls,
        )
        
        result = analyze_water_bodies(
            tile_result.data[0].astype(np.float64),
            tile_result.data[1].astype(np.float64),
            tile_result.data[2].astype(np.float64),
            tile_result.data[3].astype(np.float64),
        )
        
        response = {
            "water_percent": round(result.water_percent, 1),
            "total_water_area_sq_meters": round(result.total_water_area_sq_meters, 0),
            "water_body_count": result.water_body_count,
            "metrics": result.metrics.to_dict(),
            "bounds": list(tile_result.bounds),
            "message": f"Water bodies: {result.water_percent:.1f}% coverage ({result.total_water_area_sq_meters:.0f} sq m)",
        }
        
        if result.quality_proxy:
            response["quality_proxy"] = result.quality_proxy.to_dict()
        
        return response
    except Exception as e:
        return _error_response(f"Error analyzing water bodies: {str(e)}")


def detect_buildings_tool(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
) -> Dict[str, Any]:
    """Detect buildings and classify density.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (default 12)
    
    Returns:
        Dictionary with building detection results
    """
    try:
        from satellite_tiler.building_detection import analyze_buildings
        
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return _error_response("Scene data not cached. Call list_satellite_scenes first.")
        
        platform = detect_platform(scene_id)
        platform_str = platform.value.lower()
        mapping = BAND_MAPPINGS[platform_str]
        
        bands = [mapping["swir1"], mapping["nir"]]
        tile_result = get_tile(
            scene_id=scene_id, lat=lat, lon=lon, zoom=zoom,
            bands=bands, asset_urls=asset_urls,
        )
        
        result = analyze_buildings(
            tile_result.data[0].astype(np.float64),
            tile_result.data[1].astype(np.float64),
        )
        
        return {
            "building_percent": round(result.building_percent, 1),
            "building_area_sq_meters": round(result.building_area_sq_meters, 0),
            "density_percentages": {k: round(v, 1) for k, v in result.density_percentages.items()},
            "dominant_density": result.dominant_density,
            "bounds": list(tile_result.bounds),
            "message": f"Buildings: {result.building_percent:.1f}% coverage, dominant density: {result.dominant_density}",
        }
    except Exception as e:
        return _error_response(f"Error detecting buildings: {str(e)}")


def analyze_environmental_justice_tool(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int = 12,
) -> Dict[str, Any]:
    """Analyze environmental justice indicators.
    
    Combines heat, vegetation, and air quality to identify
    areas with cumulative environmental burdens.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (default 12)
    
    Returns:
        Dictionary with environmental justice analysis
    """
    try:
        from satellite_tiler.environmental_justice_analysis import analyze_environmental_justice
        from satellite_tiler.indices import calculate_ndvi, calculate_ndbi
        
        asset_urls = get_cached_asset_urls(scene_id)
        if not asset_urls:
            return _error_response("Scene data not cached. Call list_satellite_scenes first.")
        
        platform = detect_platform(scene_id)
        platform_str = platform.value.lower()
        mapping = BAND_MAPPINGS[platform_str]
        
        bands = [mapping["nir"], mapping["red"], mapping["swir1"]]
        tile_result = get_tile(
            scene_id=scene_id, lat=lat, lon=lon, zoom=zoom,
            bands=bands, asset_urls=asset_urls,
        )
        
        nir = tile_result.data[0].astype(np.float64)
        red = tile_result.data[1].astype(np.float64)
        swir = tile_result.data[2].astype(np.float64)
        
        ndvi_result = calculate_ndvi(nir, red)
        ndbi_result = calculate_ndbi(swir, nir)
        
        result = analyze_environmental_justice(
            lst_celsius=None,  # No thermal data
            ndvi_data=ndvi_result.data,
            ndbi_data=ndbi_result.data,
        )
        
        return {
            "burden_percentages": {k: round(v, 1) for k, v in result.burden_percentages.items()},
            "mean_burden": round(result.mean_burden, 3),
            "high_burden_percent": round(result.high_burden_percent, 1),
            "multi_stressor_percent": round(result.multi_stressor_percent, 1),
            "burden_components": result.burden_components.to_dict(),
            "priority_areas": result.priority_areas,
            "bounds": list(tile_result.bounds),
            "message": f"Environmental burden: {result.high_burden_percent:.1f}% high burden, {result.multi_stressor_percent:.1f}% multi-stressor areas",
        }
    except Exception as e:
        return _error_response(f"Error analyzing environmental justice: {str(e)}")


# List of all geospatial analysis tools
GEOSPATIAL_ANALYSIS_TOOLS = [
    analyze_urban_heat,
    analyze_vegetation_health,
    calculate_spectral_index,
    classify_land_use,
    detect_changes,
    get_heat_recommendations,
    analyze_flood_risk_tool,
    analyze_air_quality_tool,
    analyze_green_infrastructure_tool,
    analyze_water_bodies_tool,
    detect_buildings_tool,
    analyze_environmental_justice_tool,
]


def get_geospatial_strands_tools():
    """Get all geospatial tools formatted for Strands Agents.
    
    Returns a list of tool definitions compatible with strands-agents.
    
    Example:
        from satellite_tiler.urban_tools import get_geospatial_strands_tools
        from strands import Agent
        
        agent = Agent(tools=get_geospatial_strands_tools())
    """
    try:
        from strands import tool
        
        return [tool(fn) for fn in GEOSPATIAL_ANALYSIS_TOOLS]
    except ImportError:
        raise ImportError(
            "strands-agents is required for Strands integration. "
            "Install with: pip install strands-agents"
        )
