"""Vegetation health analysis from satellite imagery.

This module provides functions for analyzing vegetation health and coverage
using spectral indices like NDVI and EVI.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np

from satellite_tiler.indices import (
    IndexResult,
    calculate_ndvi,
    calculate_evi,
)


class VegetationClass(Enum):
    """Vegetation classification categories based on NDVI."""
    WATER = "water"
    BARE_SOIL = "bare_soil"
    SPARSE = "sparse_vegetation"
    MODERATE = "moderate_vegetation"
    DENSE = "dense_vegetation"


# NDVI thresholds for vegetation classification
# These are standard thresholds used in remote sensing
NDVI_THRESHOLDS = {
    VegetationClass.WATER: (-1.0, 0.0),
    VegetationClass.BARE_SOIL: (0.0, 0.1),
    VegetationClass.SPARSE: (0.1, 0.3),
    VegetationClass.MODERATE: (0.3, 0.6),
    VegetationClass.DENSE: (0.6, 1.0),
}


@dataclass
class VegetationAnalysisResult:
    """Result of vegetation analysis.
    
    Attributes:
        ndvi: NDVI index result with statistics
        classification: 2D array of vegetation class values
        class_percentages: Percentage of each vegetation class
        evi: Optional EVI index result
        health_assessment: Overall health assessment string
        total_vegetation_percent: Total vegetated area percentage
    """
    ndvi: IndexResult
    classification: np.ndarray
    class_percentages: Dict[str, float]
    evi: Optional[IndexResult]
    health_assessment: str
    total_vegetation_percent: float

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "ndvi": self.ndvi.to_dict(),
            "class_percentages": self.class_percentages,
            "evi": self.evi.to_dict() if self.evi else None,
            "health_assessment": self.health_assessment,
            "total_vegetation_percent": self.total_vegetation_percent,
            "shape": list(self.classification.shape),
        }


@dataclass
class VegetationChangeResult:
    """Result of vegetation change comparison.
    
    Attributes:
        ndvi_before: NDVI result for earlier date
        ndvi_after: NDVI result for later date
        ndvi_change: Array of NDVI differences (after - before)
        vegetation_loss_percent: Percentage of area with vegetation loss
        vegetation_gain_percent: Percentage of area with vegetation gain
        no_change_percent: Percentage of area with no significant change
        mean_change: Mean NDVI change value
    """
    ndvi_before: IndexResult
    ndvi_after: IndexResult
    ndvi_change: np.ndarray
    vegetation_loss_percent: float
    vegetation_gain_percent: float
    no_change_percent: float
    mean_change: float

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "ndvi_before": self.ndvi_before.to_dict(),
            "ndvi_after": self.ndvi_after.to_dict(),
            "vegetation_loss_percent": self.vegetation_loss_percent,
            "vegetation_gain_percent": self.vegetation_gain_percent,
            "no_change_percent": self.no_change_percent,
            "mean_change": self.mean_change,
        }


def classify_ndvi_pixel(ndvi_value: float) -> VegetationClass:
    """Classify a single NDVI value into a vegetation class.
    
    Args:
        ndvi_value: NDVI value in range [-1, 1]
    
    Returns:
        VegetationClass for the pixel
    """
    if np.isnan(ndvi_value):
        return VegetationClass.BARE_SOIL  # Default for invalid
    
    for veg_class, (low, high) in NDVI_THRESHOLDS.items():
        if low <= ndvi_value < high:
            return veg_class
    
    # Handle edge case of exactly 1.0
    if ndvi_value >= 1.0:
        return VegetationClass.DENSE
    
    return VegetationClass.BARE_SOIL


def classify_vegetation(ndvi: np.ndarray) -> np.ndarray:
    """Classify NDVI array into vegetation categories.
    
    Args:
        ndvi: 2D array of NDVI values
    
    Returns:
        2D array of vegetation class indices (0-4)
    """
    classification = np.zeros_like(ndvi, dtype=np.int8)
    
    # Apply thresholds
    # Water: NDVI < 0
    classification[ndvi < 0] = 0
    
    # Bare soil: 0 <= NDVI < 0.1
    classification[(ndvi >= 0) & (ndvi < 0.1)] = 1
    
    # Sparse vegetation: 0.1 <= NDVI < 0.3
    classification[(ndvi >= 0.1) & (ndvi < 0.3)] = 2
    
    # Moderate vegetation: 0.3 <= NDVI < 0.6
    classification[(ndvi >= 0.3) & (ndvi < 0.6)] = 3
    
    # Dense vegetation: NDVI >= 0.6
    classification[ndvi >= 0.6] = 4
    
    # Handle NaN as bare soil
    classification[np.isnan(ndvi)] = 1
    
    return classification


def calculate_class_percentages(classification: np.ndarray) -> Dict[str, float]:
    """Calculate percentage of each vegetation class.
    
    Args:
        classification: 2D array of class indices
    
    Returns:
        Dictionary mapping class names to percentages
    """
    total_pixels = classification.size
    if total_pixels == 0:
        return {vc.value: 0.0 for vc in VegetationClass}
    
    class_mapping = {
        0: VegetationClass.WATER,
        1: VegetationClass.BARE_SOIL,
        2: VegetationClass.SPARSE,
        3: VegetationClass.MODERATE,
        4: VegetationClass.DENSE,
    }
    
    percentages = {}
    for idx, veg_class in class_mapping.items():
        count = np.sum(classification == idx)
        percentages[veg_class.value] = float(count / total_pixels * 100)
    
    return percentages


def assess_vegetation_health(class_percentages: Dict[str, float]) -> str:
    """Assess overall vegetation health based on class distribution.
    
    Args:
        class_percentages: Dictionary of class percentages
    
    Returns:
        Health assessment string: "poor", "fair", "good", or "excellent"
    """
    dense = class_percentages.get(VegetationClass.DENSE.value, 0)
    moderate = class_percentages.get(VegetationClass.MODERATE.value, 0)
    sparse = class_percentages.get(VegetationClass.SPARSE.value, 0)
    
    total_vegetation = dense + moderate + sparse
    
    if dense >= 40 or total_vegetation >= 70:
        return "excellent"
    elif dense >= 20 or total_vegetation >= 50:
        return "good"
    elif total_vegetation >= 30:
        return "fair"
    else:
        return "poor"


def analyze_vegetation(
    nir: np.ndarray,
    red: np.ndarray,
    blue: Optional[np.ndarray] = None,
    include_evi: bool = False,
) -> VegetationAnalysisResult:
    """Perform vegetation analysis on satellite bands.
    
    Args:
        nir: Near-infrared band array
        red: Red band array
        blue: Blue band array (required if include_evi=True)
        include_evi: Whether to calculate EVI in addition to NDVI
    
    Returns:
        VegetationAnalysisResult with NDVI, classification, and statistics
    """
    # Calculate NDVI
    ndvi_result = calculate_ndvi(nir, red)
    
    # Classify vegetation
    classification = classify_vegetation(ndvi_result.data)
    
    # Calculate class percentages
    class_percentages = calculate_class_percentages(classification)
    
    # Calculate EVI if requested
    evi_result = None
    if include_evi and blue is not None:
        evi_result = calculate_evi(nir, red, blue)
    
    # Assess health
    health = assess_vegetation_health(class_percentages)
    
    # Calculate total vegetation percentage
    total_veg = (
        class_percentages.get(VegetationClass.SPARSE.value, 0) +
        class_percentages.get(VegetationClass.MODERATE.value, 0) +
        class_percentages.get(VegetationClass.DENSE.value, 0)
    )
    
    return VegetationAnalysisResult(
        ndvi=ndvi_result,
        classification=classification,
        class_percentages=class_percentages,
        evi=evi_result,
        health_assessment=health,
        total_vegetation_percent=total_veg,
    )


def compare_vegetation(
    nir_before: np.ndarray,
    red_before: np.ndarray,
    nir_after: np.ndarray,
    red_after: np.ndarray,
    change_threshold: float = 0.1,
) -> VegetationChangeResult:
    """Compare vegetation between two dates.
    
    Args:
        nir_before: NIR band from earlier date
        red_before: Red band from earlier date
        nir_after: NIR band from later date
        red_after: Red band from later date
        change_threshold: Minimum NDVI change to consider significant
    
    Returns:
        VegetationChangeResult with change statistics
    """
    # Calculate NDVI for both dates
    ndvi_before = calculate_ndvi(nir_before, red_before)
    ndvi_after = calculate_ndvi(nir_after, red_after)
    
    # Calculate change
    ndvi_change = ndvi_after.data - ndvi_before.data
    
    # Identify valid pixels (not NaN in either date)
    valid_mask = ~np.isnan(ndvi_change)
    valid_count = np.sum(valid_mask)
    
    if valid_count == 0:
        return VegetationChangeResult(
            ndvi_before=ndvi_before,
            ndvi_after=ndvi_after,
            ndvi_change=ndvi_change,
            vegetation_loss_percent=0.0,
            vegetation_gain_percent=0.0,
            no_change_percent=100.0,
            mean_change=0.0,
        )
    
    # Calculate change statistics
    loss_mask = ndvi_change < -change_threshold
    gain_mask = ndvi_change > change_threshold
    no_change_mask = (ndvi_change >= -change_threshold) & (ndvi_change <= change_threshold)
    
    loss_percent = float(np.sum(loss_mask & valid_mask) / valid_count * 100)
    gain_percent = float(np.sum(gain_mask & valid_mask) / valid_count * 100)
    no_change_percent = float(np.sum(no_change_mask & valid_mask) / valid_count * 100)
    
    mean_change = float(np.nanmean(ndvi_change))
    
    return VegetationChangeResult(
        ndvi_before=ndvi_before,
        ndvi_after=ndvi_after,
        ndvi_change=ndvi_change,
        vegetation_loss_percent=loss_percent,
        vegetation_gain_percent=gain_percent,
        no_change_percent=no_change_percent,
        mean_change=mean_change,
    )


def get_vegetation_colormap() -> Dict[int, Tuple[int, int, int]]:
    """Get RGB colormap for vegetation classification.
    
    Returns:
        Dictionary mapping class index to RGB tuple
    """
    return {
        0: (0, 0, 139),      # Water - dark blue
        1: (139, 90, 43),    # Bare soil - brown
        2: (255, 255, 0),    # Sparse - yellow
        3: (144, 238, 144),  # Moderate - light green
        4: (0, 100, 0),      # Dense - dark green
    }


def colorize_classification(classification: np.ndarray) -> np.ndarray:
    """Convert classification array to RGB image.
    
    Args:
        classification: 2D array of class indices (0-4)
    
    Returns:
        3D RGB array (height, width, 3)
    """
    colormap = get_vegetation_colormap()
    
    rgb = np.zeros((*classification.shape, 3), dtype=np.uint8)
    
    for class_idx, color in colormap.items():
        mask = classification == class_idx
        rgb[mask] = color
    
    return rgb
