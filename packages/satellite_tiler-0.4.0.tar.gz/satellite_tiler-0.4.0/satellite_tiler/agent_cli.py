"""Rich terminal CLI for the Geospatial Analysis Agent.

A beautiful terminal application for interacting with satellite imagery
analysis tools using natural language queries.

Usage:
    satellite-agent                              # Interactive session
    satellite-agent -l "-27.47,153.02"          # Set location
    satellite-agent -q "Find heat islands"      # Single query
    satellite-agent --list-tools                # Show tools
"""

import json
import sys
from pathlib import Path
from typing import Optional, Dict, Any, Tuple

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich.layout import Layout
from rich.text import Text

console = Console()

BANNER = """
[bold blue]╔═══════════════════════════════════════════════════════════╗
║  🛰️  [bold white]Satellite Imagery Analysis Agent[/bold white]  🌍                  ║
║                                                             ║
║  Analyze satellite imagery using natural language           ║
║  Powered by Strands + Landsat/Sentinel-2                   ║
╚═══════════════════════════════════════════════════════════╝[/bold blue]
"""

# Tool definitions for display
TOOL_DEFINITIONS = [
    ("discover_satellite_data", "Find available satellite missions", "Discovery"),
    ("list_satellite_scenes", "List scenes with filters", "Discovery"),
    ("get_satellite_tile", "Fetch imagery tile", "Imagery"),
    ("analyze_urban_heat", "Detect heat islands (Landsat only)", "Heat Analysis"),
    ("analyze_vegetation_health", "Calculate NDVI/EVI", "Vegetation"),
    ("calculate_spectral_index", "Compute spectral indices", "Indices"),
    ("classify_land_use", "Classify land cover", "Classification"),
    ("detect_changes", "Temporal change detection", "Change"),
    ("analyze_flood_risk_tool", "Assess flood vulnerability", "Risk"),
    ("analyze_air_quality_tool", "Air quality proxies", "Environment"),
    ("analyze_green_infrastructure_tool", "Green space analysis", "Green"),
    ("analyze_water_bodies_tool", "Water body monitoring", "Water"),
    ("detect_buildings_tool", "Built-up area detection", "Urban"),
    ("analyze_environmental_justice_tool", "Environmental burden", "Policy"),
    ("get_heat_recommendations", "Cooling intervention suggestions", "Recommendations"),
]


def _parse_location(location: Optional[str]) -> Tuple[Optional[float], Optional[float]]:
    """Parse location string into lat, lon tuple."""
    if not location:
        return None, None
    try:
        parts = location.replace(" ", "").split(",")
        return float(parts[0]), float(parts[1])
    except (ValueError, IndexError):
        console.print(f"[red]Invalid location format: {location}. Use 'lat,lon'[/red]")
        return None, None


def _print_location_panel(lat: float, lon: float):
    """Display location panel."""
    panel = Panel(
        f"[bold green]📍 Location Set[/bold green]\n"
        f"Latitude: [cyan]{lat}[/cyan]\n"
        f"Longitude: [cyan]{lon}[/cyan]",
        title="Current Location",
        border_style="green"
    )
    console.print(panel)


def _print_model_info(model: str):
    """Display model info."""
    console.print(f"[dim]🤖 Model: {model}[/dim]\n")


def _print_tools_table():
    """Print formatted table of available tools."""
    table = Table(
        title="🧰 Available Geospatial Analysis Tools",
        show_header=True,
        header_style="bold magenta"
    )
    
    table.add_column("Tool", style="cyan", no_wrap=True)
    table.add_column("Description", style="white")
    table.add_column("Category", style="green")
    
    for name, desc, category in TOOL_DEFINITIONS:
        table.add_row(name, desc, category)
    
    console.print(table)
    console.print()


def _print_help_panel():
    """Print help in a panel."""
    help_text = """
[bold]Commands:[/bold]
  [cyan]help[/cyan]     - Show this help message
  [cyan]tools[/cyan]    - List available analysis tools
  [cyan]quit[/cyan]     - Exit the agent

[bold]Example Queries:[/bold]
  [green]"What satellite data is available here?"[/green]
  [green]"Show me recent Sentinel-2 scenes with low cloud cover"[/green]
  [green]"Analyze vegetation health in this area"[/green]
  [green]"Find heat islands and suggest cooling strategies"[/green]
  [green]"Compare land use between 2020 and 2024"[/green]
  [green]"What's the flood risk in this neighborhood?"[/green]
"""
    panel = Panel(help_text, title="📖 Help", border_style="yellow")
    console.print(panel)


def _format_statistics_table(stats: Dict[str, Any], title: str = "📊 Statistics") -> Table:
    """Format statistics as a rich table."""
    table = Table(title=title, show_header=True)
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="white")
    
    for key, value in stats.items():
        if isinstance(value, float):
            table.add_row(key, f"{value:.2f}")
        else:
            table.add_row(key, str(value))
    
    return table


def _format_classification_table(percentages: Dict[str, float]) -> Table:
    """Format classification results as a table with bars."""
    table = Table(title="🗺️ Classification Results", show_header=True)
    table.add_column("Class", style="cyan")
    table.add_column("Coverage", style="white")
    table.add_column("Bar", style="green")
    
    for class_name, pct in sorted(percentages.items(), key=lambda x: -x[1]):
        bar_filled = int(pct / 5)
        bar = "█" * bar_filled + "░" * (20 - bar_filled)
        table.add_row(class_name, f"{pct:.1f}%", bar)
    
    return table


def _get_system_prompt(lat: Optional[float], lon: Optional[float]) -> str:
    """Generate system prompt for the agent."""
    location_context = ""
    if lat is not None and lon is not None:
        location_context = f"""
The user has set a default location at latitude {lat}, longitude {lon}.
Use this location for analyses unless the user specifies a different location.
"""
    
    return f"""You are a geospatial analysis assistant with access to satellite imagery tools.
You can analyze Landsat and Sentinel-2 satellite data to provide insights about:
- Urban heat islands and temperature patterns (Landsat only - has thermal bands)
- Vegetation health and coverage (NDVI, EVI)
- Land use classification
- Change detection over time
- Flood risk assessment
- Air quality proxies
- Green infrastructure analysis
- Water body monitoring
- Building detection
- Environmental justice indicators

{location_context}

When analyzing data:
1. First use discover_satellite_data to check available missions
2. Use list_satellite_scenes to find recent scenes with low cloud cover
3. Then use the appropriate analysis tool

Always explain your findings in clear, actionable terms.
For heat analysis, you MUST use Landsat imagery (Sentinel-2 has no thermal bands).
"""


def _show_dashboard():
    """Show dashboard with recent analyses."""
    layout = Layout()
    
    layout.split_column(
        Layout(name="header", size=3),
        Layout(name="main"),
        Layout(name="footer", size=3)
    )
    
    layout["header"].update(
        Panel("[bold]🛰️ Satellite Analysis Dashboard[/bold]", border_style="blue")
    )
    layout["main"].split_row(
        Layout(name="left"),
        Layout(name="right")
    )
    layout["left"].update(
        Panel(
            "Recent Analyses\n\n"
            "[dim]No recent analyses[/dim]\n\n"
            "Run queries to see history here.",
            title="📋 History",
            border_style="green"
        )
    )
    layout["right"].update(
        Panel(
            "Available Platforms\n\n"
            "• [cyan]Landsat 8/9[/cyan] - 30m, thermal\n"
            "• [cyan]Sentinel-2[/cyan] - 10m, no thermal\n\n"
            "[dim]Use list_satellite_scenes to find data[/dim]",
            title="🛰️ Satellites",
            border_style="yellow"
        )
    )
    layout["footer"].update(
        Panel("[dim]Press Ctrl+C to exit dashboard[/dim]", border_style="dim")
    )
    
    console.print(layout)


def _create_agent(model: str, lat: Optional[float], lon: Optional[float]):
    """Create and configure the Strands agent."""
    try:
        from strands import Agent
        from satellite_tiler.tools import get_strands_tools
        from satellite_tiler.urban_tools import get_geospatial_strands_tools
        
        tools = get_strands_tools() + get_geospatial_strands_tools()
        agent = Agent(
            model=model,
            tools=tools,
            system_prompt=_get_system_prompt(lat, lon)
        )
        return agent
    except ImportError as e:
        console.print(f"[red]Error: strands-agents not installed. Install with: pip install strands-agents[/red]")
        console.print(f"[dim]Details: {e}[/dim]")
        return None


def _run_query_with_progress(
    agent,
    query: str,
    lat: Optional[float],
    lon: Optional[float],
    verbose: bool
) -> Dict[str, Any]:
    """Run query with animated spinner."""
    console.print(f"\n[bold]🔍 Query:[/bold] {query}\n")
    
    from rich.status import Status
    
    with Status("[cyan]Analyzing satellite data...", console=console, spinner="dots") as status:
        try:
            response = agent(query)
            status.update("[green]✓ Analysis complete!")
        except Exception as e:
            status.update("[red]✗ Error occurred")
            return {
                "query": query,
                "location": {"lat": lat, "lon": lon} if lat else None,
                "response": f"Error: {str(e)}",
                "error": True
            }
    
    return {
        "query": query,
        "location": {"lat": lat, "lon": lon} if lat else None,
        "response": str(response),
        "error": False
    }


def _run_interactive(
    agent,
    lat: Optional[float],
    lon: Optional[float],
    verbose: bool
):
    """Run interactive chat with rich formatting."""
    console.print("[dim]Type 'quit' to exit, 'help' for commands[/dim]\n")
    
    while True:
        try:
            user_input = console.input("[bold green]You>[/bold green] ")
            
            if not user_input.strip():
                continue
            
            if user_input.lower() in ('quit', 'exit', 'q'):
                console.print("[yellow]👋 Goodbye![/yellow]")
                break
            
            if user_input.lower() == 'help':
                _print_help_panel()
                continue
            
            if user_input.lower() == 'tools':
                _print_tools_table()
                continue
            
            # Run query with progress
            result = _run_query_with_progress(agent, user_input, lat, lon, verbose)
            
            # Display response in panel
            if result.get("error"):
                response_panel = Panel(
                    Text(result['response'], style="red"),
                    title="❌ Error",
                    border_style="red"
                )
            else:
                response_panel = Panel(
                    Markdown(result['response']),
                    title="🤖 Agent Response",
                    border_style="blue"
                )
            console.print(response_panel)
            console.print()
            
        except KeyboardInterrupt:
            console.print("\n[yellow]👋 Goodbye![/yellow]")
            break
        except EOFError:
            console.print("\n[yellow]👋 Goodbye![/yellow]")
            break
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")


def _handle_output(result: Dict[str, Any], output_path: Optional[str]):
    """Handle output with rich formatting."""
    if output_path:
        path = Path(output_path)
        
        if path.suffix == '.json':
            with open(path, 'w') as f:
                json.dump(result, f, indent=2)
            console.print(f"[green]✅ Results saved to {path}[/green]")
            
            # Show syntax-highlighted preview
            preview = json.dumps(result, indent=2)
            if len(preview) > 500:
                preview = preview[:500] + "\n..."
            syntax = Syntax(preview, "json", theme="monokai", line_numbers=True)
            console.print(Panel(syntax, title="Preview"))
            
        elif path.suffix == '.png':
            # For PNG output, we'd need image data in the result
            console.print(f"[yellow]⚠️ PNG output requires image data in result[/yellow]")
            # Fall back to JSON
            json_path = path.with_suffix('.json')
            with open(json_path, 'w') as f:
                json.dump(result, f, indent=2)
            console.print(f"[green]✅ Results saved to {json_path}[/green]")
            
        else:
            with open(path, 'w') as f:
                json.dump(result, f, indent=2)
            console.print(f"[green]✅ Results saved to {path}[/green]")
    else:
        # Display response in panel
        if result.get("error"):
            response_panel = Panel(
                Text(result['response'], style="red"),
                title="❌ Error",
                border_style="red"
            )
        else:
            response_panel = Panel(
                Markdown(result['response']),
                title="🤖 Analysis Result",
                border_style="blue"
            )
        console.print(response_panel)


def _run_batch_mode(
    agent,
    lat: Optional[float],
    lon: Optional[float],
    verbose: bool
):
    """Process queries from stdin."""
    console.print("[dim]Processing batch queries from stdin...[/dim]\n")
    
    for line in sys.stdin:
        query = line.strip()
        if not query:
            continue
        
        result = _run_query_with_progress(agent, query, lat, lon, verbose)
        
        # Output as JSON for batch processing
        print(json.dumps(result))


@click.command()
@click.option('--location', '-l', help='Default location as "lat,lon"')
@click.option('--query', '-q', help='Single query to run (non-interactive)')
@click.option('--output', '-o', type=click.Path(), help='Output file path')
@click.option(
    '--model', '-m',
    default='us.anthropic.claude-opus-4-5-20251101-v1:0',
    help='LLM model ID for Bedrock'
)
@click.option('--list-tools', is_flag=True, help='List available analysis tools')
@click.option('--dashboard', is_flag=True, help='Show dashboard view')
@click.option('--verbose', '-v', is_flag=True, help='Show detailed output')
def agent_cli(
    location: Optional[str],
    query: Optional[str],
    output: Optional[str],
    model: str,
    list_tools: bool,
    dashboard: bool,
    verbose: bool
):
    """
    🛰️ Geospatial Analysis Agent CLI
    
    Run satellite imagery analysis using natural language queries.
    
    \b
    Examples:
        satellite-agent                              # Interactive session
        satellite-agent -l "-27.47,153.02"          # Set location
        satellite-agent -q "Find heat islands"      # Single query
        satellite-agent --list-tools                # Show tools
    """
    console.print(BANNER)
    
    if list_tools:
        _print_tools_table()
        return
    
    if dashboard:
        _show_dashboard()
        return
    
    # Parse location
    lat, lon = _parse_location(location)
    if lat is not None and lon is not None:
        _print_location_panel(lat, lon)
    
    # Check for batch mode (stdin piping)
    if not sys.stdin.isatty() and not query:
        agent = _create_agent(model, lat, lon)
        if agent:
            _print_model_info(model)
            _run_batch_mode(agent, lat, lon, verbose)
        return
    
    # Create agent
    agent = _create_agent(model, lat, lon)
    if not agent:
        return
    
    _print_model_info(model)
    
    if query:
        # Single query mode
        result = _run_query_with_progress(agent, query, lat, lon, verbose)
        _handle_output(result, output)
    else:
        # Interactive mode
        _run_interactive(agent, lat, lon, verbose)


def main():
    """Entry point for the CLI."""
    agent_cli()


if __name__ == "__main__":
    main()
