"""Tile processing utilities for satellite-tiler.

This module provides functions for post-processing satellite tiles,
including rescaling, color formula application, and colormap application.
"""

from typing import Tuple, Optional, Dict
import numpy as np


# Standard colormaps for single-band visualization
COLORMAPS: Dict[str, np.ndarray] = {}


def _init_colormaps():
    """Initialize standard colormaps."""
    global COLORMAPS
    
    # Grayscale
    gray = np.zeros((256, 3), dtype=np.uint8)
    for i in range(256):
        gray[i] = [i, i, i]
    COLORMAPS["gray"] = gray
    COLORMAPS["grayscale"] = gray
    
    # Viridis-like colormap
    viridis = np.zeros((256, 3), dtype=np.uint8)
    for i in range(256):
        t = i / 255.0
        # Simplified viridis approximation
        r = int(255 * (0.267 + 0.004 * t + 2.7 * t**2 - 12.6 * t**3 + 15.5 * t**4 - 5.9 * t**5))
        g = int(255 * (0.004 + 1.4 * t - 1.6 * t**2 + 1.1 * t**3 - 0.3 * t**4))
        b = int(255 * (0.329 + 1.4 * t - 3.0 * t**2 + 3.3 * t**3 - 1.5 * t**4))
        viridis[i] = [max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b))]
    COLORMAPS["viridis"] = viridis
    
    # Terrain colormap
    terrain = np.zeros((256, 3), dtype=np.uint8)
    for i in range(256):
        t = i / 255.0
        if t < 0.25:
            # Deep blue to light blue (water)
            r, g, b = 0, int(128 * t * 4), int(128 + 127 * t * 4)
        elif t < 0.5:
            # Green (lowlands)
            tt = (t - 0.25) * 4
            r, g, b = int(34 + 100 * tt), int(139 + 60 * tt), int(34 + 50 * tt)
        elif t < 0.75:
            # Brown (highlands)
            tt = (t - 0.5) * 4
            r, g, b = int(134 + 80 * tt), int(199 - 60 * tt), int(84 - 40 * tt)
        else:
            # White (snow/peaks)
            tt = (t - 0.75) * 4
            r, g, b = int(214 + 41 * tt), int(139 + 116 * tt), int(44 + 211 * tt)
        terrain[i] = [max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b))]
    COLORMAPS["terrain"] = terrain
    
    # NDVI colormap (brown -> yellow -> green)
    ndvi = np.zeros((256, 3), dtype=np.uint8)
    for i in range(256):
        t = i / 255.0
        if t < 0.2:
            # Brown (bare soil/water)
            r, g, b = 139, 90, 43
        elif t < 0.4:
            # Yellow-brown
            tt = (t - 0.2) / 0.2
            r = int(139 + 116 * tt)
            g = int(90 + 165 * tt)
            b = int(43 - 43 * tt)
        elif t < 0.6:
            # Yellow to light green
            tt = (t - 0.4) / 0.2
            r = int(255 - 127 * tt)
            g = 255
            b = 0
        else:
            # Green (vegetation)
            tt = (t - 0.6) / 0.4
            r = int(128 - 128 * tt)
            g = int(255 - 127 * tt)
            b = 0
        ndvi[i] = [max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b))]
    COLORMAPS["ndvi"] = ndvi


# Initialize colormaps on module load
_init_colormaps()


def rescale(
    tile: np.ndarray,
    mask: np.ndarray,
    in_range: Tuple[float, float],
    out_range: Tuple[float, float] = (0, 255)
) -> np.ndarray:
    """Linearly rescale pixel values from input range to output range.
    
    Args:
        tile: Input tile data (any shape)
        mask: Valid pixel mask (same spatial dimensions as tile)
        in_range: Input value range as (min, max)
        out_range: Output value range as (min, max), default (0, 255)
    
    Returns:
        Rescaled tile as uint8 array
    
    Example:
        >>> tile = np.array([[100, 200], [300, 400]])
        >>> mask = np.array([[255, 255], [255, 255]])
        >>> rescaled = rescale(tile, mask, (0, 500), (0, 255))
    """
    in_min, in_max = in_range
    out_min, out_max = out_range
    
    # Avoid division by zero
    if in_max == in_min:
        return np.full_like(tile, out_min, dtype=np.uint8)
    
    # Linear rescale
    scale = (out_max - out_min) / (in_max - in_min)
    offset = out_min - in_min * scale
    
    result = tile.astype(np.float64) * scale + offset
    
    # Clip to output range
    result = np.clip(result, out_min, out_max)
    
    # Apply mask (set invalid pixels to 0)
    if mask is not None and tile.ndim > 2:
        # Multi-band tile
        for i in range(tile.shape[0]):
            result[i] = np.where(mask > 0, result[i], 0)
    elif mask is not None:
        result = np.where(mask > 0, result, 0)
    
    return result.astype(np.uint8)


def apply_colormap(
    tile: np.ndarray,
    colormap_name: str
) -> np.ndarray:
    """Apply a named colormap to single-band data.
    
    Args:
        tile: Single-band tile data (2D array, uint8)
        colormap_name: Name of colormap ("viridis", "terrain", "ndvi", "gray")
    
    Returns:
        RGB tile as uint8 array with shape (3, height, width)
    
    Raises:
        ValueError: If colormap name is not recognized
        ValueError: If tile is not single-band
    
    Example:
        >>> tile = np.random.randint(0, 256, (256, 256), dtype=np.uint8)
        >>> rgb = apply_colormap(tile, "viridis")
        >>> rgb.shape
        (3, 256, 256)
    """
    # Handle multi-dimensional input
    if tile.ndim == 3:
        if tile.shape[0] == 1:
            tile = tile[0]
        else:
            raise ValueError(
                f"Colormap can only be applied to single-band data, got {tile.shape[0]} bands"
            )
    
    if colormap_name not in COLORMAPS:
        available = ", ".join(sorted(COLORMAPS.keys()))
        raise ValueError(
            f"Unknown colormap '{colormap_name}'. Available: {available}"
        )
    
    cmap = COLORMAPS[colormap_name]
    
    # Ensure tile is uint8
    if tile.dtype != np.uint8:
        tile = tile.astype(np.uint8)
    
    # Apply colormap using lookup
    height, width = tile.shape
    rgb = np.zeros((3, height, width), dtype=np.uint8)
    
    for i in range(3):
        rgb[i] = cmap[tile, i]
    
    return rgb


def get_available_colormaps() -> list:
    """Get list of available colormap names.
    
    Returns:
        List of colormap name strings
    """
    return sorted(COLORMAPS.keys())


def normalize_tile(
    tile: np.ndarray,
    percentile_min: float = 2,
    percentile_max: float = 98
) -> Tuple[np.ndarray, Tuple[float, float]]:
    """Normalize tile using percentile-based rescaling.
    
    Args:
        tile: Input tile data
        percentile_min: Lower percentile for clipping (default 2)
        percentile_max: Upper percentile for clipping (default 98)
    
    Returns:
        Tuple of (normalized tile as uint8, (min_val, max_val) used for rescaling)
    """
    # Calculate percentiles
    valid_data = tile[tile > 0] if np.any(tile > 0) else tile.flatten()
    
    if len(valid_data) == 0:
        return tile.astype(np.uint8), (0, 255)
    
    p_min = np.percentile(valid_data, percentile_min)
    p_max = np.percentile(valid_data, percentile_max)
    
    # Rescale
    result = np.clip((tile - p_min) / (p_max - p_min + 1e-10) * 255, 0, 255)
    
    return result.astype(np.uint8), (p_min, p_max)


def ensure_uint8(tile: np.ndarray) -> np.ndarray:
    """Ensure tile is uint8 format.
    
    If tile is already uint8, returns as-is.
    If tile is float in [0, 1], scales to [0, 255].
    If tile is float in other range, clips to [0, 255].
    
    Args:
        tile: Input tile data
    
    Returns:
        Tile as uint8 array
    """
    if tile.dtype == np.uint8:
        return tile
    
    if tile.dtype in [np.float32, np.float64]:
        if tile.max() <= 1.0 and tile.min() >= 0.0:
            # Assume [0, 1] range
            return (tile * 255).astype(np.uint8)
        else:
            # Clip to [0, 255]
            return np.clip(tile, 0, 255).astype(np.uint8)
    
    # For other dtypes, just clip and convert
    return np.clip(tile, 0, 255).astype(np.uint8)
