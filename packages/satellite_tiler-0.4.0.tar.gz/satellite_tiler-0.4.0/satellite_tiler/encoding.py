"""Image encoding utilities for satellite-tiler.

This module provides functions for encoding tile data to common image formats
(PNG, JPEG, WebP) for serving to web clients.
"""

import io
from typing import Optional, Tuple
import numpy as np

try:
    from PIL import Image
    HAS_PIL = True
except ImportError:
    HAS_PIL = False


def _check_pil():
    """Check if PIL is available."""
    if not HAS_PIL:
        raise ImportError(
            "Pillow is required for image encoding. "
            "Install with: pip install Pillow"
        )


def _prepare_image(
    tile: np.ndarray,
    mask: Optional[np.ndarray] = None
) -> Tuple[np.ndarray, bool]:
    """Prepare tile data for image encoding.
    
    Args:
        tile: Tile data with shape (bands, height, width) or (height, width)
        mask: Optional mask with shape (height, width)
    
    Returns:
        Tuple of (image array in HWC format, has_alpha)
    """
    # Handle different input shapes
    if tile.ndim == 2:
        # Single band grayscale
        img = tile
        has_alpha = mask is not None
    elif tile.ndim == 3:
        if tile.shape[0] in [1, 3, 4]:
            # CHW format -> HWC format
            img = np.moveaxis(tile, 0, -1)
            if img.shape[-1] == 1:
                img = img.squeeze(-1)
        else:
            # Assume already HWC
            img = tile
        has_alpha = mask is not None and img.ndim == 3 and img.shape[-1] != 4
    else:
        raise ValueError(f"Unsupported tile shape: {tile.shape}")
    
    return img, has_alpha


def to_png(
    tile: np.ndarray,
    mask: Optional[np.ndarray] = None,
    compression: int = 6
) -> bytes:
    """Encode tile as PNG with optional alpha channel.
    
    PNG is lossless and supports transparency, making it ideal for
    tiles that need to be composited or have nodata areas.
    
    Args:
        tile: Tile data with shape (bands, height, width) or (height, width)
              Supports 1 (grayscale), 3 (RGB), or 4 (RGBA) bands
        mask: Optional mask with shape (height, width), valid pixels = 255
        compression: PNG compression level (0-9, default 6)
    
    Returns:
        PNG-encoded image as bytes
    
    Example:
        >>> tile = np.random.randint(0, 256, (3, 256, 256), dtype=np.uint8)
        >>> mask = np.full((256, 256), 255, dtype=np.uint8)
        >>> png_bytes = to_png(tile, mask)
    """
    _check_pil()
    
    img, has_alpha = _prepare_image(tile, mask)
    
    # Add alpha channel if mask provided
    if has_alpha and mask is not None:
        if img.ndim == 2:
            # Grayscale with alpha
            img = np.stack([img, img, img, mask], axis=-1)
        elif img.ndim == 3 and img.shape[-1] == 3:
            # RGB with alpha
            img = np.concatenate([img, mask[..., np.newaxis]], axis=-1)
    
    # Determine mode
    if img.ndim == 2:
        mode = "L"
    elif img.shape[-1] == 3:
        mode = "RGB"
    elif img.shape[-1] == 4:
        mode = "RGBA"
    else:
        raise ValueError(f"Unsupported number of channels: {img.shape[-1]}")
    
    # Create PIL image and encode
    pil_img = Image.fromarray(img.astype(np.uint8), mode=mode)
    
    buffer = io.BytesIO()
    pil_img.save(buffer, format="PNG", compress_level=compression)
    
    return buffer.getvalue()


def to_jpeg(
    tile: np.ndarray,
    quality: int = 85
) -> bytes:
    """Encode tile as JPEG.
    
    JPEG is lossy but produces smaller files. Does not support transparency.
    Best for photographic imagery where some quality loss is acceptable.
    
    Args:
        tile: Tile data with shape (bands, height, width) or (height, width)
              Supports 1 (grayscale) or 3 (RGB) bands
        quality: JPEG quality (1-100, default 85)
    
    Returns:
        JPEG-encoded image as bytes
    
    Example:
        >>> tile = np.random.randint(0, 256, (3, 256, 256), dtype=np.uint8)
        >>> jpeg_bytes = to_jpeg(tile, quality=90)
    """
    _check_pil()
    
    img, _ = _prepare_image(tile, None)
    
    # JPEG doesn't support alpha, remove if present
    if img.ndim == 3 and img.shape[-1] == 4:
        img = img[..., :3]
    
    # Determine mode
    if img.ndim == 2:
        mode = "L"
    elif img.shape[-1] == 3:
        mode = "RGB"
    else:
        raise ValueError(f"JPEG requires 1 or 3 channels, got {img.shape[-1]}")
    
    # Create PIL image and encode
    pil_img = Image.fromarray(img.astype(np.uint8), mode=mode)
    
    buffer = io.BytesIO()
    pil_img.save(buffer, format="JPEG", quality=quality)
    
    return buffer.getvalue()


def to_webp(
    tile: np.ndarray,
    mask: Optional[np.ndarray] = None,
    quality: int = 80,
    lossless: bool = False
) -> bytes:
    """Encode tile as WebP.
    
    WebP offers good compression with optional transparency support.
    Can be lossless or lossy.
    
    Args:
        tile: Tile data with shape (bands, height, width) or (height, width)
        mask: Optional mask with shape (height, width), valid pixels = 255
        quality: WebP quality (1-100, default 80, ignored if lossless)
        lossless: If True, use lossless compression
    
    Returns:
        WebP-encoded image as bytes
    
    Example:
        >>> tile = np.random.randint(0, 256, (3, 256, 256), dtype=np.uint8)
        >>> webp_bytes = to_webp(tile, quality=85)
    """
    _check_pil()
    
    img, has_alpha = _prepare_image(tile, mask)
    
    # Add alpha channel if mask provided
    if has_alpha and mask is not None:
        if img.ndim == 2:
            img = np.stack([img, img, img, mask], axis=-1)
        elif img.ndim == 3 and img.shape[-1] == 3:
            img = np.concatenate([img, mask[..., np.newaxis]], axis=-1)
    
    # Determine mode
    if img.ndim == 2:
        mode = "L"
    elif img.shape[-1] == 3:
        mode = "RGB"
    elif img.shape[-1] == 4:
        mode = "RGBA"
    else:
        raise ValueError(f"Unsupported number of channels: {img.shape[-1]}")
    
    # Create PIL image and encode
    pil_img = Image.fromarray(img.astype(np.uint8), mode=mode)
    
    buffer = io.BytesIO()
    pil_img.save(buffer, format="WEBP", quality=quality, lossless=lossless)
    
    return buffer.getvalue()


def from_png(data: bytes) -> Tuple[np.ndarray, Optional[np.ndarray]]:
    """Decode PNG image to numpy array.
    
    Args:
        data: PNG-encoded image bytes
    
    Returns:
        Tuple of (tile data in CHW format, mask or None)
    """
    _check_pil()
    
    buffer = io.BytesIO(data)
    pil_img = Image.open(buffer)
    
    img = np.array(pil_img)
    
    # Convert to CHW format
    if img.ndim == 2:
        # Grayscale
        tile = img
        mask = None
    elif img.shape[-1] == 4:
        # RGBA - extract alpha as mask
        tile = np.moveaxis(img[..., :3], -1, 0)
        mask = img[..., 3]
    else:
        # RGB
        tile = np.moveaxis(img, -1, 0)
        mask = None
    
    return tile, mask


def encode(
    tile: np.ndarray,
    mask: Optional[np.ndarray] = None,
    format: str = "png",
    **kwargs
) -> bytes:
    """Encode tile to specified image format.
    
    Args:
        tile: Tile data
        mask: Optional mask
        format: Image format ("png", "jpeg", "jpg", "webp")
        **kwargs: Format-specific options (quality, compression, etc.)
    
    Returns:
        Encoded image bytes
    
    Raises:
        ValueError: If format is not supported
    """
    format = format.lower()
    
    if format == "png":
        return to_png(tile, mask, **kwargs)
    elif format in ["jpeg", "jpg"]:
        return to_jpeg(tile, **kwargs)
    elif format == "webp":
        return to_webp(tile, mask, **kwargs)
    else:
        raise ValueError(f"Unsupported format: {format}. Use 'png', 'jpeg', or 'webp'")
