"""Band selection and validation for satellite-tiler.

This module provides functions for validating band selections
and retrieving band information for different satellite platforms.
"""

from typing import List, Set

from satellite_tiler.models import SatellitePlatform
from satellite_tiler.exceptions import InvalidBandError


# Valid bands for each platform
VALID_BANDS = {
    SatellitePlatform.LANDSAT8: {
        "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9", "B10", "B11",
        "BQA",  # Quality band
    },
    SatellitePlatform.SENTINEL2: {
        "B01", "B02", "B03", "B04", "B05", "B06", "B07", "B08", "B8A",
        "B09", "B10", "B11", "B12",
        "SCL",  # Scene classification
    },
    SatellitePlatform.CBERS: {
        "B5", "B6", "B7", "B8",
    },
}

# Common band aliases
BAND_ALIASES = {
    SatellitePlatform.LANDSAT8: {
        "coastal": "B1",
        "blue": "B2",
        "green": "B3",
        "red": "B4",
        "nir": "B5",
        "swir1": "B6",
        "swir2": "B7",
        "pan": "B8",
        "cirrus": "B9",
    },
    SatellitePlatform.SENTINEL2: {
        "coastal": "B01",
        "blue": "B02",
        "green": "B03",
        "red": "B04",
        "nir": "B08",
        "swir1": "B11",
        "swir2": "B12",
    },
    SatellitePlatform.CBERS: {
        "blue": "B5",
        "green": "B6",
        "red": "B7",
        "nir": "B8",
    },
}


def validate_bands(
    bands: List[str],
    platform: SatellitePlatform
) -> List[str]:
    """Validate and normalize band names for a platform.
    
    Accepts both official band names (B4, B04) and common aliases
    (red, nir, etc.).
    
    Args:
        bands: List of band names or aliases
        platform: Satellite platform
    
    Returns:
        List of normalized band names
    
    Raises:
        InvalidBandError: If any band is not valid for the platform
    
    Example:
        >>> validate_bands(["red", "green", "blue"], SatellitePlatform.LANDSAT8)
        ["B4", "B3", "B2"]
    """
    valid = VALID_BANDS[platform]
    aliases = BAND_ALIASES.get(platform, {})
    
    normalized = []
    for band in bands:
        # Check if it's an alias
        band_lower = band.lower()
        if band_lower in aliases:
            normalized.append(aliases[band_lower])
        elif band.upper() in valid:
            normalized.append(band.upper())
        elif band in valid:
            normalized.append(band)
        else:
            raise InvalidBandError(
                band=band,
                platform=platform,
                valid_bands=sorted(valid)
            )
    
    return normalized


def get_valid_bands(platform: SatellitePlatform) -> List[str]:
    """Get list of valid band names for a platform.
    
    Args:
        platform: Satellite platform
    
    Returns:
        Sorted list of valid band names
    """
    return sorted(VALID_BANDS[platform])


def get_band_aliases(platform: SatellitePlatform) -> dict:
    """Get band aliases for a platform.
    
    Args:
        platform: Satellite platform
    
    Returns:
        Dictionary mapping alias to band name
    """
    return BAND_ALIASES.get(platform, {}).copy()


def is_valid_band(band: str, platform: SatellitePlatform) -> bool:
    """Check if a band name is valid for a platform.
    
    Args:
        band: Band name or alias
        platform: Satellite platform
    
    Returns:
        True if band is valid, False otherwise
    """
    valid = VALID_BANDS[platform]
    aliases = BAND_ALIASES.get(platform, {})
    
    return (
        band in valid or
        band.upper() in valid or
        band.lower() in aliases
    )


def get_rgb_bands(platform: SatellitePlatform) -> List[str]:
    """Get default RGB band combination for a platform.
    
    Returns bands for true color visualization.
    
    Args:
        platform: Satellite platform
    
    Returns:
        List of [red, green, blue] band names
    """
    if platform == SatellitePlatform.LANDSAT8:
        return ["B4", "B3", "B2"]
    elif platform == SatellitePlatform.SENTINEL2:
        return ["B04", "B03", "B02"]
    elif platform == SatellitePlatform.CBERS:
        return ["B7", "B6", "B5"]
    else:
        raise ValueError(f"Unknown platform: {platform}")


def get_false_color_bands(platform: SatellitePlatform) -> List[str]:
    """Get false color (vegetation) band combination for a platform.
    
    Returns bands for false color visualization highlighting vegetation.
    
    Args:
        platform: Satellite platform
    
    Returns:
        List of [nir, red, green] band names
    """
    if platform == SatellitePlatform.LANDSAT8:
        return ["B5", "B4", "B3"]
    elif platform == SatellitePlatform.SENTINEL2:
        return ["B08", "B04", "B03"]
    elif platform == SatellitePlatform.CBERS:
        return ["B8", "B7", "B6"]
    else:
        raise ValueError(f"Unknown platform: {platform}")
