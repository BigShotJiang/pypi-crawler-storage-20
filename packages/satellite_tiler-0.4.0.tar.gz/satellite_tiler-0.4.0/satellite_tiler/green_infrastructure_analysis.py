"""Green infrastructure analysis from satellite imagery.

This module provides functions for analyzing green infrastructure
including vegetation mapping, connectivity scoring, and gap identification.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np

from satellite_tiler.indices import calculate_ndvi, IndexResult


@dataclass
class GreenInfrastructureResult:
    """Result of green infrastructure analysis.
    
    Attributes:
        vegetation_mask: Boolean mask of vegetated pixels
        vegetation_percent: Percentage of vegetated area
        vegetation_area_sq_meters: Area of vegetation
        connectivity_score: Score indicating vegetation connectivity (0-1)
        fragmentation_index: Index of vegetation fragmentation (0-1)
        gap_mask: Boolean mask of potential green infrastructure gaps
        gap_percent: Percentage of area identified as gaps
        priority_areas: List of priority areas for intervention
        ndvi: NDVI index result
    """
    vegetation_mask: np.ndarray
    vegetation_percent: float
    vegetation_area_sq_meters: float
    connectivity_score: float
    fragmentation_index: float
    gap_mask: np.ndarray
    gap_percent: float
    priority_areas: List[str]
    ndvi: IndexResult

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.vegetation_mask.shape),
            "vegetation_percent": self.vegetation_percent,
            "vegetation_area_sq_meters": self.vegetation_area_sq_meters,
            "connectivity_score": self.connectivity_score,
            "fragmentation_index": self.fragmentation_index,
            "gap_percent": self.gap_percent,
            "priority_areas": self.priority_areas,
            "ndvi_stats": self.ndvi.to_dict(),
        }


def classify_vegetation(
    ndvi_data: np.ndarray,
    threshold: float = 0.3,
) -> np.ndarray:
    """Classify pixels as vegetation based on NDVI threshold.
    
    Args:
        ndvi_data: NDVI values array
        threshold: NDVI threshold for vegetation classification
    
    Returns:
        Boolean mask of vegetated pixels
    """
    veg_mask = ndvi_data > threshold
    veg_mask = veg_mask & ~np.isnan(ndvi_data)
    return veg_mask


def calculate_connectivity_score(vegetation_mask: np.ndarray) -> float:
    """Calculate vegetation connectivity score.
    
    Connectivity is measured by the ratio of vegetation pixels
    that have adjacent vegetation neighbors.
    
    Args:
        vegetation_mask: Boolean mask of vegetated pixels
    
    Returns:
        Connectivity score (0-1, higher = more connected)
    """
    if not np.any(vegetation_mask):
        return 0.0
    
    total_veg = np.sum(vegetation_mask)
    
    # Count neighbors for each vegetation pixel
    neighbor_count = np.zeros_like(vegetation_mask, dtype=np.int8)
    
    # Check 4-connectivity
    neighbor_count[1:, :] += vegetation_mask[:-1, :].astype(np.int8)
    neighbor_count[:-1, :] += vegetation_mask[1:, :].astype(np.int8)
    neighbor_count[:, 1:] += vegetation_mask[:, :-1].astype(np.int8)
    neighbor_count[:, :-1] += vegetation_mask[:, 1:].astype(np.int8)
    
    # Calculate average neighbors for vegetation pixels
    veg_neighbors = neighbor_count[vegetation_mask]
    avg_neighbors = np.mean(veg_neighbors) if len(veg_neighbors) > 0 else 0
    
    # Normalize to 0-1 (max 4 neighbors)
    connectivity = avg_neighbors / 4.0
    
    return float(connectivity)


def calculate_fragmentation_index(vegetation_mask: np.ndarray) -> float:
    """Calculate vegetation fragmentation index.
    
    Fragmentation is measured by the ratio of edge pixels to total
    vegetation pixels. Higher values indicate more fragmented vegetation.
    
    Args:
        vegetation_mask: Boolean mask of vegetated pixels
    
    Returns:
        Fragmentation index (0-1, higher = more fragmented)
    """
    if not np.any(vegetation_mask):
        return 0.0
    
    total_veg = np.sum(vegetation_mask)
    
    # Find edge pixels (vegetation pixels with non-vegetation neighbors)
    # Erode vegetation mask
    eroded = vegetation_mask.copy()
    eroded[0, :] = False
    eroded[-1, :] = False
    eroded[:, 0] = False
    eroded[:, -1] = False
    
    # Check if all neighbors are vegetation
    all_neighbors = np.ones_like(vegetation_mask, dtype=bool)
    all_neighbors[1:, :] &= vegetation_mask[:-1, :]
    all_neighbors[:-1, :] &= vegetation_mask[1:, :]
    all_neighbors[:, 1:] &= vegetation_mask[:, :-1]
    all_neighbors[:, :-1] &= vegetation_mask[:, 1:]
    
    # Interior pixels have all vegetation neighbors
    interior = vegetation_mask & all_neighbors
    
    # Edge pixels are vegetation but not interior
    edge_pixels = vegetation_mask & ~interior
    edge_count = np.sum(edge_pixels)
    
    # Fragmentation is ratio of edge to total
    fragmentation = edge_count / total_veg if total_veg > 0 else 0.0
    
    return float(fragmentation)


def identify_gaps(
    vegetation_mask: np.ndarray,
    ndbi_data: Optional[np.ndarray] = None,
    min_gap_size: int = 4,
) -> np.ndarray:
    """Identify gaps in green infrastructure.
    
    Gaps are non-vegetated areas that could benefit from greening,
    particularly in urban areas (high NDBI).
    
    Args:
        vegetation_mask: Boolean mask of vegetated pixels
        ndbi_data: NDBI values array (optional, for urban prioritization)
        min_gap_size: Minimum gap size in pixels
    
    Returns:
        Boolean mask of gap pixels
    """
    # Non-vegetated areas are potential gaps
    gap_mask = ~vegetation_mask
    
    # If NDBI available, prioritize urban gaps
    if ndbi_data is not None:
        # Urban areas (NDBI > 0) are higher priority gaps
        urban_mask = ndbi_data > 0
        urban_mask = urban_mask & ~np.isnan(ndbi_data)
        gap_mask = gap_mask & urban_mask
    
    return gap_mask


def identify_priority_areas(
    vegetation_mask: np.ndarray,
    gap_mask: np.ndarray,
    connectivity_score: float,
    fragmentation_index: float,
) -> List[str]:
    """Identify priority areas for green infrastructure intervention.
    
    Args:
        vegetation_mask: Boolean mask of vegetated pixels
        gap_mask: Boolean mask of gap pixels
        connectivity_score: Vegetation connectivity score
        fragmentation_index: Vegetation fragmentation index
    
    Returns:
        List of priority area descriptions
    """
    priorities = []
    
    veg_percent = np.sum(vegetation_mask) / vegetation_mask.size * 100
    gap_percent = np.sum(gap_mask) / gap_mask.size * 100
    
    if veg_percent < 20:
        priorities.append("CRITICAL: Overall vegetation coverage below 20%")
    elif veg_percent < 40:
        priorities.append("LOW: Vegetation coverage below recommended 40%")
    
    if connectivity_score < 0.3:
        priorities.append("Vegetation patches are poorly connected - create corridors")
    
    if fragmentation_index > 0.7:
        priorities.append("High fragmentation - consolidate green spaces")
    
    if gap_percent > 50:
        priorities.append("Large urban gaps identified - prioritize greening")
    
    # Identify quadrant priorities
    h, w = vegetation_mask.shape
    quadrants = {
        "NW": vegetation_mask[:h//2, :w//2],
        "NE": vegetation_mask[:h//2, w//2:],
        "SW": vegetation_mask[h//2:, :w//2],
        "SE": vegetation_mask[h//2:, w//2:],
    }
    
    for name, quad in quadrants.items():
        quad_veg = np.sum(quad) / quad.size * 100 if quad.size > 0 else 0
        if quad_veg < 15:
            priorities.append(f"{name} quadrant has very low vegetation ({quad_veg:.1f}%)")
    
    return priorities


def correlate_with_heat(
    vegetation_mask: np.ndarray,
    lst_celsius: np.ndarray,
) -> Dict[str, float]:
    """Correlate vegetation with land surface temperature.
    
    Args:
        vegetation_mask: Boolean mask of vegetated pixels
        lst_celsius: Land surface temperature array in Celsius
    
    Returns:
        Dictionary with correlation statistics
    """
    valid_mask = ~np.isnan(lst_celsius)
    
    if not np.any(valid_mask):
        return {
            "vegetated_mean_temp": None,
            "non_vegetated_mean_temp": None,
            "cooling_effect": None,
        }
    
    veg_temps = lst_celsius[vegetation_mask & valid_mask]
    non_veg_temps = lst_celsius[~vegetation_mask & valid_mask]
    
    veg_mean = float(np.mean(veg_temps)) if len(veg_temps) > 0 else None
    non_veg_mean = float(np.mean(non_veg_temps)) if len(non_veg_temps) > 0 else None
    
    cooling_effect = None
    if veg_mean is not None and non_veg_mean is not None:
        cooling_effect = non_veg_mean - veg_mean
    
    return {
        "vegetated_mean_temp": veg_mean,
        "non_vegetated_mean_temp": non_veg_mean,
        "cooling_effect": cooling_effect,
    }


def analyze_green_infrastructure(
    nir: np.ndarray,
    red: np.ndarray,
    swir: Optional[np.ndarray] = None,
    vegetation_threshold: float = 0.3,
    pixel_size_meters: float = 30.0,
) -> GreenInfrastructureResult:
    """Perform comprehensive green infrastructure analysis.
    
    Args:
        nir: Near-infrared band array
        red: Red band array
        swir: Short-wave infrared band array (optional, for gap prioritization)
        vegetation_threshold: NDVI threshold for vegetation classification
        pixel_size_meters: Pixel size for area calculation
    
    Returns:
        GreenInfrastructureResult with complete analysis
    """
    # Calculate NDVI
    ndvi_result = calculate_ndvi(nir, red)
    
    # Classify vegetation
    vegetation_mask = classify_vegetation(ndvi_result.data, vegetation_threshold)
    
    # Calculate vegetation statistics
    valid_mask = ~np.isnan(ndvi_result.data)
    total_valid = np.sum(valid_mask)
    veg_count = np.sum(vegetation_mask)
    
    vegetation_percent = float(veg_count / total_valid * 100) if total_valid > 0 else 0.0
    vegetation_area = float(veg_count * pixel_size_meters ** 2)
    
    # Calculate connectivity and fragmentation
    connectivity_score = calculate_connectivity_score(vegetation_mask)
    fragmentation_index = calculate_fragmentation_index(vegetation_mask)
    
    # Identify gaps
    ndbi_data = None
    if swir is not None:
        from satellite_tiler.indices import calculate_ndbi
        ndbi_result = calculate_ndbi(swir, nir)
        ndbi_data = ndbi_result.data
    
    gap_mask = identify_gaps(vegetation_mask, ndbi_data)
    gap_percent = float(np.sum(gap_mask) / gap_mask.size * 100)
    
    # Identify priority areas
    priority_areas = identify_priority_areas(
        vegetation_mask,
        gap_mask,
        connectivity_score,
        fragmentation_index
    )
    
    return GreenInfrastructureResult(
        vegetation_mask=vegetation_mask,
        vegetation_percent=vegetation_percent,
        vegetation_area_sq_meters=vegetation_area,
        connectivity_score=connectivity_score,
        fragmentation_index=fragmentation_index,
        gap_mask=gap_mask,
        gap_percent=gap_percent,
        priority_areas=priority_areas,
        ndvi=ndvi_result,
    )
