"""Spectral index calculations for satellite imagery.

This module provides functions for calculating various spectral indices
from satellite band data, including NDVI, NDBI, NDWI, and more.

All index calculations handle division by zero gracefully by returning NaN.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional, Tuple

import numpy as np


class SpectralIndex(Enum):
    """Supported spectral indices."""
    NDVI = "ndvi"      # Normalized Difference Vegetation Index
    NDBI = "ndbi"      # Normalized Difference Built-up Index
    NDWI = "ndwi"      # Normalized Difference Water Index (Green-NIR)
    MNDWI = "mndwi"    # Modified Normalized Difference Water Index (Green-SWIR)
    EVI = "evi"        # Enhanced Vegetation Index
    SAVI = "savi"      # Soil-Adjusted Vegetation Index
    NDMI = "ndmi"      # Normalized Difference Moisture Index
    BSI = "bsi"        # Bare Soil Index


@dataclass
class IndexResult:
    """Result of spectral index calculation.
    
    Attributes:
        index_name: Name of the calculated index
        data: 2D numpy array of index values
        min_value: Minimum value in the array (excluding NaN)
        max_value: Maximum value in the array (excluding NaN)
        mean_value: Mean value in the array (excluding NaN)
        std_value: Standard deviation (excluding NaN)
        valid_pixel_count: Number of valid (non-NaN) pixels
        nodata_pixel_count: Number of NaN pixels
    """
    index_name: str
    data: np.ndarray
    min_value: float
    max_value: float
    mean_value: float
    std_value: float
    valid_pixel_count: int
    nodata_pixel_count: int

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization (without numpy array)."""
        return {
            "index_name": self.index_name,
            "shape": list(self.data.shape),
            "min_value": float(self.min_value) if not np.isnan(self.min_value) else None,
            "max_value": float(self.max_value) if not np.isnan(self.max_value) else None,
            "mean_value": float(self.mean_value) if not np.isnan(self.mean_value) else None,
            "std_value": float(self.std_value) if not np.isnan(self.std_value) else None,
            "valid_pixel_count": self.valid_pixel_count,
            "nodata_pixel_count": self.nodata_pixel_count,
        }


# Platform band mappings for spectral indices
BAND_MAPPINGS = {
    "landsat8": {
        "blue": "B2",
        "green": "B3", 
        "red": "B4",
        "nir": "B5",
        "swir1": "B6",
        "swir2": "B7",
        "thermal": "B10",
    },
    "sentinel2": {
        "blue": "B02",
        "green": "B03",
        "red": "B04",
        "nir": "B08",
        "nir_narrow": "B8A",
        "swir1": "B11",
        "swir2": "B12",
    },
}


def _compute_statistics(data: np.ndarray, index_name: str) -> IndexResult:
    """Compute statistics for an index array and return IndexResult."""
    valid_mask = ~np.isnan(data)
    valid_data = data[valid_mask]
    
    valid_count = int(np.sum(valid_mask))
    nodata_count = int(np.sum(~valid_mask))
    
    if valid_count > 0:
        min_val = float(np.nanmin(data))
        max_val = float(np.nanmax(data))
        mean_val = float(np.nanmean(data))
        std_val = float(np.nanstd(data))
    else:
        min_val = np.nan
        max_val = np.nan
        mean_val = np.nan
        std_val = np.nan
    
    return IndexResult(
        index_name=index_name,
        data=data,
        min_value=min_val,
        max_value=max_val,
        mean_value=mean_val,
        std_value=std_val,
        valid_pixel_count=valid_count,
        nodata_pixel_count=nodata_count,
    )


def _normalized_difference(band_a: np.ndarray, band_b: np.ndarray) -> np.ndarray:
    """Calculate normalized difference: (A - B) / (A + B).
    
    Handles division by zero by returning NaN where A + B = 0.
    
    Args:
        band_a: First band array (numerator positive term)
        band_b: Second band array (numerator negative term)
    
    Returns:
        Normalized difference array with values in [-1, 1] range
    """
    # Convert to float to avoid integer division issues
    a = band_a.astype(np.float64)
    b = band_b.astype(np.float64)
    
    denominator = a + b
    
    # Use np.where to handle division by zero
    with np.errstate(divide='ignore', invalid='ignore'):
        result = np.where(
            denominator != 0,
            (a - b) / denominator,
            np.nan
        )
    
    return result


def calculate_ndvi(nir: np.ndarray, red: np.ndarray) -> IndexResult:
    """Calculate NDVI (Normalized Difference Vegetation Index).
    
    NDVI = (NIR - Red) / (NIR + Red)
    
    Values range from -1 to 1:
    - High values (0.6-1.0): Dense vegetation
    - Moderate values (0.3-0.6): Moderate vegetation
    - Low values (0.1-0.3): Sparse vegetation
    - Near zero (0.0-0.1): Bare soil
    - Negative values: Water, snow, clouds
    
    Args:
        nir: Near-infrared band array
        red: Red band array
    
    Returns:
        IndexResult with NDVI values and statistics
    """
    data = _normalized_difference(nir, red)
    return _compute_statistics(data, SpectralIndex.NDVI.value)


def calculate_ndbi(swir: np.ndarray, nir: np.ndarray) -> IndexResult:
    """Calculate NDBI (Normalized Difference Built-up Index).
    
    NDBI = (SWIR - NIR) / (SWIR + NIR)
    
    Values range from -1 to 1:
    - Positive values: Built-up/urban areas
    - Negative values: Vegetation, water
    
    Args:
        swir: Short-wave infrared band array (SWIR1)
        nir: Near-infrared band array
    
    Returns:
        IndexResult with NDBI values and statistics
    """
    data = _normalized_difference(swir, nir)
    return _compute_statistics(data, SpectralIndex.NDBI.value)


def calculate_ndwi(green: np.ndarray, nir: np.ndarray) -> IndexResult:
    """Calculate NDWI (Normalized Difference Water Index).
    
    NDWI = (Green - NIR) / (Green + NIR)
    
    Values range from -1 to 1:
    - Positive values: Water bodies
    - Negative values: Vegetation, soil
    
    Args:
        green: Green band array
        nir: Near-infrared band array
    
    Returns:
        IndexResult with NDWI values and statistics
    """
    data = _normalized_difference(green, nir)
    return _compute_statistics(data, SpectralIndex.NDWI.value)


def calculate_mndwi(green: np.ndarray, swir: np.ndarray) -> IndexResult:
    """Calculate MNDWI (Modified Normalized Difference Water Index).
    
    MNDWI = (Green - SWIR) / (Green + SWIR)
    
    Enhanced water detection compared to NDWI, better at
    distinguishing water from built-up areas.
    
    Args:
        green: Green band array
        swir: Short-wave infrared band array
    
    Returns:
        IndexResult with MNDWI values and statistics
    """
    data = _normalized_difference(green, swir)
    return _compute_statistics(data, SpectralIndex.MNDWI.value)


def calculate_evi(
    nir: np.ndarray,
    red: np.ndarray,
    blue: np.ndarray,
    g: float = 2.5,
    c1: float = 6.0,
    c2: float = 7.5,
    l: float = 1.0,
) -> IndexResult:
    """Calculate EVI (Enhanced Vegetation Index).
    
    EVI = G * (NIR - Red) / (NIR + C1*Red - C2*Blue + L)
    
    EVI is an optimized vegetation index that:
    - Reduces atmospheric influences
    - Reduces soil background signals
    - Does not saturate in high biomass areas
    
    Default coefficients are for Landsat/MODIS.
    
    Args:
        nir: Near-infrared band array
        red: Red band array
        blue: Blue band array
        g: Gain factor (default 2.5)
        c1: Coefficient for red band aerosol correction (default 6.0)
        c2: Coefficient for blue band aerosol correction (default 7.5)
        l: Canopy background adjustment (default 1.0)
    
    Returns:
        IndexResult with EVI values and statistics
    """
    nir_f = nir.astype(np.float64)
    red_f = red.astype(np.float64)
    blue_f = blue.astype(np.float64)
    
    denominator = nir_f + c1 * red_f - c2 * blue_f + l
    
    with np.errstate(divide='ignore', invalid='ignore'):
        data = np.where(
            denominator != 0,
            g * (nir_f - red_f) / denominator,
            np.nan
        )
    
    return _compute_statistics(data, SpectralIndex.EVI.value)


def calculate_savi(
    nir: np.ndarray,
    red: np.ndarray,
    l: float = 0.5,
) -> IndexResult:
    """Calculate SAVI (Soil-Adjusted Vegetation Index).
    
    SAVI = ((NIR - Red) / (NIR + Red + L)) * (1 + L)
    
    SAVI minimizes soil brightness influences using a soil
    brightness correction factor (L).
    
    Args:
        nir: Near-infrared band array
        red: Red band array
        l: Soil brightness correction factor (default 0.5)
           - Use 0.5 for intermediate vegetation cover
           - Use lower values for high vegetation cover
           - Use higher values for low vegetation cover
    
    Returns:
        IndexResult with SAVI values and statistics
    """
    nir_f = nir.astype(np.float64)
    red_f = red.astype(np.float64)
    
    denominator = nir_f + red_f + l
    
    with np.errstate(divide='ignore', invalid='ignore'):
        data = np.where(
            denominator != 0,
            ((nir_f - red_f) / denominator) * (1 + l),
            np.nan
        )
    
    return _compute_statistics(data, SpectralIndex.SAVI.value)


def calculate_ndmi(nir: np.ndarray, swir: np.ndarray) -> IndexResult:
    """Calculate NDMI (Normalized Difference Moisture Index).
    
    NDMI = (NIR - SWIR) / (NIR + SWIR)
    
    Also known as NDWI (Gao) or LSWI. Sensitive to vegetation
    water content and useful for drought monitoring.
    
    Args:
        nir: Near-infrared band array
        swir: Short-wave infrared band array (SWIR1)
    
    Returns:
        IndexResult with NDMI values and statistics
    """
    data = _normalized_difference(nir, swir)
    return _compute_statistics(data, SpectralIndex.NDMI.value)


def calculate_bsi(
    swir: np.ndarray,
    red: np.ndarray,
    nir: np.ndarray,
    blue: np.ndarray,
) -> IndexResult:
    """Calculate BSI (Bare Soil Index).
    
    BSI = ((SWIR + Red) - (NIR + Blue)) / ((SWIR + Red) + (NIR + Blue))
    
    Highlights bare soil areas and is useful for identifying
    exposed earth, construction sites, and degraded land.
    
    Args:
        swir: Short-wave infrared band array
        red: Red band array
        nir: Near-infrared band array
        blue: Blue band array
    
    Returns:
        IndexResult with BSI values and statistics
    """
    swir_f = swir.astype(np.float64)
    red_f = red.astype(np.float64)
    nir_f = nir.astype(np.float64)
    blue_f = blue.astype(np.float64)
    
    numerator = (swir_f + red_f) - (nir_f + blue_f)
    denominator = (swir_f + red_f) + (nir_f + blue_f)
    
    with np.errstate(divide='ignore', invalid='ignore'):
        data = np.where(
            denominator != 0,
            numerator / denominator,
            np.nan
        )
    
    return _compute_statistics(data, SpectralIndex.BSI.value)


def calculate_custom(expression: str, bands: Dict[str, np.ndarray]) -> IndexResult:
    """Calculate a custom index from an expression.
    
    Supports basic arithmetic operations on band names.
    
    Args:
        expression: Mathematical expression using band names
                   e.g., "(nir - red) / (nir + red)"
        bands: Dictionary mapping band names to numpy arrays
    
    Returns:
        IndexResult with custom index values and statistics
    
    Example:
        >>> bands = {"nir": nir_array, "red": red_array}
        >>> result = calculate_custom("(nir - red) / (nir + red)", bands)
    """
    # Convert all bands to float64
    local_vars = {name: arr.astype(np.float64) for name, arr in bands.items()}
    
    # Add numpy functions to namespace
    local_vars['np'] = np
    
    with np.errstate(divide='ignore', invalid='ignore'):
        try:
            data = eval(expression, {"__builtins__": {}}, local_vars)
        except Exception as e:
            raise ValueError(f"Invalid expression '{expression}': {e}")
    
    # Ensure result is numpy array
    if not isinstance(data, np.ndarray):
        raise ValueError(f"Expression must return a numpy array, got {type(data)}")
    
    return _compute_statistics(data, f"custom:{expression[:30]}")


def get_bands_for_index(
    index: SpectralIndex,
    platform: str,
) -> Tuple[str, ...]:
    """Get the band names needed for a spectral index on a platform.
    
    Args:
        index: The spectral index to calculate
        platform: Platform name ("landsat8" or "sentinel2")
    
    Returns:
        Tuple of band names needed for the index
    
    Raises:
        ValueError: If platform is not supported
    """
    if platform not in BAND_MAPPINGS:
        raise ValueError(f"Unsupported platform: {platform}. Use 'landsat8' or 'sentinel2'")
    
    mapping = BAND_MAPPINGS[platform]
    
    index_bands = {
        SpectralIndex.NDVI: ("nir", "red"),
        SpectralIndex.NDBI: ("swir1", "nir"),
        SpectralIndex.NDWI: ("green", "nir"),
        SpectralIndex.MNDWI: ("green", "swir1"),
        SpectralIndex.EVI: ("nir", "red", "blue"),
        SpectralIndex.SAVI: ("nir", "red"),
        SpectralIndex.NDMI: ("nir", "swir1"),
        SpectralIndex.BSI: ("swir1", "red", "nir", "blue"),
    }
    
    band_keys = index_bands.get(index)
    if band_keys is None:
        raise ValueError(f"Unknown index: {index}")
    
    return tuple(mapping[key] for key in band_keys)
