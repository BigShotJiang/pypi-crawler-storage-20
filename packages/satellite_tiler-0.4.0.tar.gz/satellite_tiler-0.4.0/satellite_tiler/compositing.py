"""Image compositing for satellite imagery.

This module provides functions for creating composite images from
multiple scenes, including cloud masking and various compositing methods.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np


class CompositingMethod(Enum):
    """Supported compositing methods."""
    MEDIAN = "median"
    MEAN = "mean"
    MAX = "max"
    MIN = "min"


@dataclass
class CompositeResult:
    """Result of image compositing.
    
    Attributes:
        data: Composited image array
        method: Compositing method used
        source_count: Number of source scenes
        valid_pixel_count: Number of pixels with valid data
        cloud_masked_percent: Percentage of pixels masked for clouds
        source_attribution: Per-pixel source scene index (for max/min)
    """
    data: np.ndarray
    method: str
    source_count: int
    valid_pixel_count: int
    cloud_masked_percent: float
    source_attribution: Optional[np.ndarray]

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.data.shape),
            "method": self.method,
            "source_count": self.source_count,
            "valid_pixel_count": self.valid_pixel_count,
            "cloud_masked_percent": self.cloud_masked_percent,
            "has_attribution": self.source_attribution is not None,
        }


def create_cloud_mask(
    qa_band: np.ndarray,
    cloud_bits: List[int] = [3, 4],
) -> np.ndarray:
    """Create cloud mask from QA band.
    
    Args:
        qa_band: Quality assessment band array
        cloud_bits: Bit positions indicating clouds (Landsat default: 3, 4)
    
    Returns:
        Boolean mask where True = cloudy pixel
    """
    cloud_mask = np.zeros_like(qa_band, dtype=bool)
    
    for bit in cloud_bits:
        cloud_mask |= ((qa_band >> bit) & 1).astype(bool)
    
    return cloud_mask


def apply_cloud_mask(
    data: np.ndarray,
    cloud_mask: np.ndarray,
) -> np.ndarray:
    """Apply cloud mask to data array.
    
    Args:
        data: Data array to mask
        cloud_mask: Boolean mask where True = cloudy
    
    Returns:
        Masked data array with NaN for cloudy pixels
    """
    masked = data.astype(np.float64)
    masked[cloud_mask] = np.nan
    return masked


def composite_median(arrays: List[np.ndarray]) -> np.ndarray:
    """Create median composite from multiple arrays.
    
    Args:
        arrays: List of 2D arrays to composite
    
    Returns:
        Median composite array
    """
    stacked = np.stack(arrays, axis=0)
    return np.nanmedian(stacked, axis=0)


def composite_mean(arrays: List[np.ndarray]) -> np.ndarray:
    """Create mean composite from multiple arrays.
    
    Args:
        arrays: List of 2D arrays to composite
    
    Returns:
        Mean composite array
    """
    stacked = np.stack(arrays, axis=0)
    return np.nanmean(stacked, axis=0)


def composite_max(arrays: List[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
    """Create maximum composite from multiple arrays.
    
    Args:
        arrays: List of 2D arrays to composite
    
    Returns:
        Tuple of (max composite array, source index array)
    """
    stacked = np.stack(arrays, axis=0)
    
    # Get max values
    max_composite = np.nanmax(stacked, axis=0)
    
    # Get source indices (which scene contributed each pixel)
    source_idx = np.nanargmax(stacked, axis=0)
    
    return max_composite, source_idx


def composite_min(arrays: List[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
    """Create minimum composite from multiple arrays.
    
    Args:
        arrays: List of 2D arrays to composite
    
    Returns:
        Tuple of (min composite array, source index array)
    """
    stacked = np.stack(arrays, axis=0)
    
    # Get min values
    min_composite = np.nanmin(stacked, axis=0)
    
    # Get source indices
    source_idx = np.nanargmin(stacked, axis=0)
    
    return min_composite, source_idx


def create_composite(
    arrays: List[np.ndarray],
    method: str = "median",
    cloud_masks: Optional[List[np.ndarray]] = None,
) -> CompositeResult:
    """Create composite image from multiple scenes.
    
    Args:
        arrays: List of 2D arrays to composite
        method: Compositing method ("median", "mean", "max", "min")
        cloud_masks: Optional list of cloud masks for each array
    
    Returns:
        CompositeResult with composited image and metadata
    """
    if not arrays:
        raise ValueError("At least one array is required for compositing")
    
    # Validate method
    try:
        comp_method = CompositingMethod(method.lower())
    except ValueError:
        valid_methods = [m.value for m in CompositingMethod]
        raise ValueError(f"Invalid method '{method}'. Valid methods: {valid_methods}")
    
    # Apply cloud masks if provided
    masked_arrays = []
    total_cloud_pixels = 0
    total_pixels = 0
    
    for i, arr in enumerate(arrays):
        arr_float = arr.astype(np.float64)
        
        if cloud_masks is not None and i < len(cloud_masks):
            cloud_mask = cloud_masks[i]
            arr_float[cloud_mask] = np.nan
            total_cloud_pixels += np.sum(cloud_mask)
        
        masked_arrays.append(arr_float)
        total_pixels += arr.size
    
    # Calculate cloud masked percentage
    cloud_masked_percent = (total_cloud_pixels / total_pixels * 100) if total_pixels > 0 else 0.0
    
    # Create composite based on method
    source_attribution = None
    
    if comp_method == CompositingMethod.MEDIAN:
        composite = composite_median(masked_arrays)
    elif comp_method == CompositingMethod.MEAN:
        composite = composite_mean(masked_arrays)
    elif comp_method == CompositingMethod.MAX:
        composite, source_attribution = composite_max(masked_arrays)
    elif comp_method == CompositingMethod.MIN:
        composite, source_attribution = composite_min(masked_arrays)
    
    # Count valid pixels
    valid_pixel_count = int(np.sum(~np.isnan(composite)))
    
    return CompositeResult(
        data=composite,
        method=comp_method.value,
        source_count=len(arrays),
        valid_pixel_count=valid_pixel_count,
        cloud_masked_percent=cloud_masked_percent,
        source_attribution=source_attribution,
    )


def create_multiband_composite(
    band_arrays: Dict[str, List[np.ndarray]],
    method: str = "median",
    cloud_masks: Optional[List[np.ndarray]] = None,
) -> Dict[str, CompositeResult]:
    """Create composite for multiple bands.
    
    Args:
        band_arrays: Dictionary mapping band names to lists of arrays
        method: Compositing method
        cloud_masks: Optional list of cloud masks
    
    Returns:
        Dictionary mapping band names to CompositeResults
    """
    results = {}
    
    for band_name, arrays in band_arrays.items():
        results[band_name] = create_composite(arrays, method, cloud_masks)
    
    return results


def create_temporal_composite(
    arrays: List[np.ndarray],
    dates: List[str],
    method: str = "median",
    date_range: Optional[Tuple[str, str]] = None,
) -> CompositeResult:
    """Create temporal composite with optional date filtering.
    
    Args:
        arrays: List of 2D arrays to composite
        dates: List of date strings for each array
        method: Compositing method
        date_range: Optional (start_date, end_date) to filter
    
    Returns:
        CompositeResult with composited image
    """
    # Filter by date range if specified
    if date_range is not None:
        start_date, end_date = date_range
        filtered_arrays = []
        
        for arr, date in zip(arrays, dates):
            if start_date <= date <= end_date:
                filtered_arrays.append(arr)
        
        arrays = filtered_arrays
    
    if not arrays:
        raise ValueError("No arrays remain after date filtering")
    
    return create_composite(arrays, method)


def get_source_scene_map(
    source_attribution: np.ndarray,
    scene_ids: List[str],
) -> Dict[str, int]:
    """Get count of pixels contributed by each source scene.
    
    Args:
        source_attribution: Array of source scene indices
        scene_ids: List of scene identifiers
    
    Returns:
        Dictionary mapping scene IDs to pixel counts
    """
    counts = {}
    
    for i, scene_id in enumerate(scene_ids):
        count = int(np.sum(source_attribution == i))
        counts[scene_id] = count
    
    return counts
