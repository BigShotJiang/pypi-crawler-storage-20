"""Building detection from satellite imagery.

This module provides functions for detecting buildings and
classifying building density using spectral indices.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Optional

import numpy as np

from satellite_tiler.indices import calculate_ndbi, IndexResult


class BuildingDensity(Enum):
    """Building density classification levels."""
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    VERY_HIGH = "very_high"


# NDBI thresholds for density classification
DENSITY_THRESHOLDS = {
    BuildingDensity.NONE: (-1.0, 0.0),
    BuildingDensity.LOW: (0.0, 0.1),
    BuildingDensity.MEDIUM: (0.1, 0.2),
    BuildingDensity.HIGH: (0.2, 0.3),
    BuildingDensity.VERY_HIGH: (0.3, 1.0),
}


@dataclass
class BuildingDetectionResult:
    """Result of building detection analysis.
    
    Attributes:
        building_mask: Boolean mask of building pixels
        building_percent: Percentage of area with buildings
        building_area_sq_meters: Total building area
        density_classification: Per-pixel density classification
        density_percentages: Percentage of each density level
        dominant_density: Most common density level
        ndbi: NDBI index result
    """
    building_mask: np.ndarray
    building_percent: float
    building_area_sq_meters: float
    density_classification: np.ndarray
    density_percentages: Dict[str, float]
    dominant_density: str
    ndbi: IndexResult

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.building_mask.shape),
            "building_percent": self.building_percent,
            "building_area_sq_meters": self.building_area_sq_meters,
            "density_percentages": self.density_percentages,
            "dominant_density": self.dominant_density,
            "ndbi_stats": self.ndbi.to_dict(),
        }


def detect_buildings(
    swir: np.ndarray,
    nir: np.ndarray,
    building_threshold: float = 0.0,
) -> np.ndarray:
    """Detect building pixels using NDBI threshold.
    
    Args:
        swir: Short-wave infrared band array
        nir: Near-infrared band array
        building_threshold: NDBI threshold for building detection
    
    Returns:
        Boolean mask of building pixels
    """
    ndbi_result = calculate_ndbi(swir, nir)
    
    building_mask = ndbi_result.data > building_threshold
    building_mask = building_mask & ~np.isnan(ndbi_result.data)
    
    return building_mask


def classify_density(ndbi_data: np.ndarray) -> np.ndarray:
    """Classify building density from NDBI values.
    
    Args:
        ndbi_data: NDBI values array
    
    Returns:
        Array of density level indices (0-4)
    """
    classification = np.zeros_like(ndbi_data, dtype=np.int8)
    
    for i, (level, (low, high)) in enumerate(DENSITY_THRESHOLDS.items()):
        mask = (ndbi_data >= low) & (ndbi_data < high)
        classification[mask] = i
    
    # Handle NaN
    classification[np.isnan(ndbi_data)] = 0
    
    return classification


def calculate_density_percentages(density_classification: np.ndarray) -> Dict[str, float]:
    """Calculate percentage of each density level.
    
    Args:
        density_classification: Array of density level indices
    
    Returns:
        Dictionary mapping density level names to percentages
    """
    total_pixels = density_classification.size
    if total_pixels == 0:
        return {level.value: 0.0 for level in BuildingDensity}
    
    percentages = {}
    for i, level in enumerate(BuildingDensity):
        count = np.sum(density_classification == i)
        percentages[level.value] = float(count / total_pixels * 100)
    
    return percentages


def analyze_buildings(
    swir: np.ndarray,
    nir: np.ndarray,
    building_threshold: float = 0.0,
    pixel_size_meters: float = 30.0,
) -> BuildingDetectionResult:
    """Perform comprehensive building detection analysis.
    
    Args:
        swir: Short-wave infrared band array
        nir: Near-infrared band array
        building_threshold: NDBI threshold for building detection
        pixel_size_meters: Pixel size for area calculation
    
    Returns:
        BuildingDetectionResult with complete analysis
    """
    # Calculate NDBI
    ndbi_result = calculate_ndbi(swir, nir)
    
    # Detect buildings
    building_mask = ndbi_result.data > building_threshold
    building_mask = building_mask & ~np.isnan(ndbi_result.data)
    
    # Calculate building statistics
    valid_mask = ~np.isnan(ndbi_result.data)
    total_valid = np.sum(valid_mask)
    building_count = np.sum(building_mask)
    
    building_percent = float(building_count / total_valid * 100) if total_valid > 0 else 0.0
    building_area = float(building_count * pixel_size_meters ** 2)
    
    # Classify density
    density_class = classify_density(ndbi_result.data)
    density_percentages = calculate_density_percentages(density_class)
    
    # Find dominant density
    dominant_density = max(density_percentages, key=density_percentages.get)
    
    return BuildingDetectionResult(
        building_mask=building_mask,
        building_percent=building_percent,
        building_area_sq_meters=building_area,
        density_classification=density_class,
        density_percentages=density_percentages,
        dominant_density=dominant_density,
        ndbi=ndbi_result,
    )


def get_density_colormap() -> Dict[int, tuple]:
    """Get RGB colormap for building density levels.
    
    Returns:
        Dictionary mapping density level index to RGB tuple
    """
    return {
        0: (200, 200, 200),  # None - light gray
        1: (255, 255, 150),  # Low - light yellow
        2: (255, 200, 100),  # Medium - orange
        3: (255, 100, 100),  # High - red
        4: (150, 0, 0),      # Very high - dark red
    }


def colorize_density(density_classification: np.ndarray) -> np.ndarray:
    """Convert density classification to RGB image.
    
    Args:
        density_classification: 2D array of density level indices (0-4)
    
    Returns:
        3D RGB array (height, width, 3)
    """
    colormap = get_density_colormap()
    
    rgb = np.zeros((*density_classification.shape, 3), dtype=np.uint8)
    
    for density_idx, color in colormap.items():
        mask = density_classification == density_idx
        rgb[mask] = color
    
    return rgb
