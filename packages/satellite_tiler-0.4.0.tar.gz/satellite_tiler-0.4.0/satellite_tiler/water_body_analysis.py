"""Water body analysis from satellite imagery.

This module provides functions for detecting water bodies,
calculating metrics, and estimating water quality proxies.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np

from satellite_tiler.indices import (
    calculate_ndwi,
    calculate_mndwi,
    IndexResult,
)


@dataclass
class WaterBodyMetrics:
    """Metrics for a detected water body.
    
    Attributes:
        area_sq_meters: Area in square meters
        perimeter_meters: Perimeter in meters
        compactness: Shape compactness ratio (0-1)
        mean_ndwi: Mean NDWI value
        pixel_count: Number of pixels
    """
    area_sq_meters: float
    perimeter_meters: float
    compactness: float
    mean_ndwi: float
    pixel_count: int

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "area_sq_meters": self.area_sq_meters,
            "perimeter_meters": self.perimeter_meters,
            "compactness": self.compactness,
            "mean_ndwi": self.mean_ndwi,
            "pixel_count": self.pixel_count,
        }


@dataclass
class WaterQualityProxy:
    """Proxy indicators for water quality.
    
    Attributes:
        turbidity_index: Estimated turbidity (0-1, higher = more turbid)
        algal_bloom_risk: Risk of algal bloom (0-1)
        clarity_score: Water clarity score (0-1, higher = clearer)
    """
    turbidity_index: float
    algal_bloom_risk: float
    clarity_score: float

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "turbidity_index": self.turbidity_index,
            "algal_bloom_risk": self.algal_bloom_risk,
            "clarity_score": self.clarity_score,
        }


@dataclass
class WaterBodyAnalysisResult:
    """Result of water body analysis.
    
    Attributes:
        water_mask: Boolean mask of water pixels
        water_percent: Percentage of area covered by water
        total_water_area_sq_meters: Total water area
        water_body_count: Number of distinct water bodies
        metrics: Aggregated water body metrics
        quality_proxy: Water quality proxy indicators
        ndwi: NDWI index result
        mndwi: MNDWI index result (if available)
    """
    water_mask: np.ndarray
    water_percent: float
    total_water_area_sq_meters: float
    water_body_count: int
    metrics: WaterBodyMetrics
    quality_proxy: Optional[WaterQualityProxy]
    ndwi: IndexResult
    mndwi: Optional[IndexResult]

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.water_mask.shape),
            "water_percent": self.water_percent,
            "total_water_area_sq_meters": self.total_water_area_sq_meters,
            "water_body_count": self.water_body_count,
            "metrics": self.metrics.to_dict(),
            "quality_proxy": self.quality_proxy.to_dict() if self.quality_proxy else None,
            "ndwi_stats": self.ndwi.to_dict(),
            "mndwi_stats": self.mndwi.to_dict() if self.mndwi else None,
        }


def detect_water(
    green: np.ndarray,
    nir: np.ndarray,
    swir: Optional[np.ndarray] = None,
    threshold: float = 0.0,
) -> Tuple[np.ndarray, IndexResult, Optional[IndexResult]]:
    """Detect water pixels using NDWI/MNDWI.
    
    Args:
        green: Green band array
        nir: Near-infrared band array
        swir: Short-wave infrared band array (optional)
        threshold: Water detection threshold
    
    Returns:
        Tuple of (water_mask, ndwi_result, mndwi_result)
    """
    ndwi_result = calculate_ndwi(green, nir)
    
    mndwi_result = None
    if swir is not None:
        mndwi_result = calculate_mndwi(green, swir)
        water_mask = mndwi_result.data > threshold
    else:
        water_mask = ndwi_result.data > threshold
    
    water_mask = water_mask & ~np.isnan(ndwi_result.data)
    
    return water_mask, ndwi_result, mndwi_result


def calculate_perimeter(water_mask: np.ndarray) -> int:
    """Calculate perimeter of water bodies in pixels.
    
    Args:
        water_mask: Boolean mask of water pixels
    
    Returns:
        Perimeter in pixels
    """
    if not np.any(water_mask):
        return 0
    
    # Find edge pixels (water pixels with non-water neighbors)
    edge_count = 0
    
    # Check each direction
    # Top edge
    top_edge = water_mask[:-1, :] & ~water_mask[1:, :]
    edge_count += np.sum(top_edge)
    
    # Bottom edge
    bottom_edge = water_mask[1:, :] & ~water_mask[:-1, :]
    edge_count += np.sum(bottom_edge)
    
    # Left edge
    left_edge = water_mask[:, :-1] & ~water_mask[:, 1:]
    edge_count += np.sum(left_edge)
    
    # Right edge
    right_edge = water_mask[:, 1:] & ~water_mask[:, :-1]
    edge_count += np.sum(right_edge)
    
    # Add boundary edges
    edge_count += np.sum(water_mask[0, :])   # Top boundary
    edge_count += np.sum(water_mask[-1, :])  # Bottom boundary
    edge_count += np.sum(water_mask[:, 0])   # Left boundary
    edge_count += np.sum(water_mask[:, -1])  # Right boundary
    
    return int(edge_count)


def calculate_compactness(area: float, perimeter: float) -> float:
    """Calculate shape compactness ratio.
    
    Compactness = 4 * pi * area / perimeter^2
    A circle has compactness of 1, more irregular shapes have lower values.
    
    Args:
        area: Area in square units
        perimeter: Perimeter in linear units
    
    Returns:
        Compactness ratio (0-1)
    """
    if perimeter == 0:
        return 0.0
    
    compactness = 4 * np.pi * area / (perimeter ** 2)
    return float(min(compactness, 1.0))


def estimate_turbidity(
    green: np.ndarray,
    red: np.ndarray,
    water_mask: np.ndarray,
) -> float:
    """Estimate water turbidity from spectral bands.
    
    Higher red reflectance relative to green indicates higher turbidity.
    
    Args:
        green: Green band array
        red: Red band array
        water_mask: Boolean mask of water pixels
    
    Returns:
        Turbidity index (0-1, higher = more turbid)
    """
    if not np.any(water_mask):
        return 0.0
    
    # Get water pixel values
    green_water = green[water_mask].astype(np.float64)
    red_water = red[water_mask].astype(np.float64)
    
    # Turbidity proxy: red/green ratio
    # Clear water has low red reflectance
    with np.errstate(divide='ignore', invalid='ignore'):
        ratio = np.where(
            green_water > 0,
            red_water / green_water,
            0
        )
    
    # Normalize to 0-1 (typical ratio range 0-2)
    turbidity = np.clip(np.mean(ratio) / 2.0, 0, 1)
    
    return float(turbidity)


def detect_algal_bloom(
    green: np.ndarray,
    nir: np.ndarray,
    water_mask: np.ndarray,
) -> float:
    """Detect algal bloom risk from spectral bands.
    
    Algal blooms show elevated NIR reflectance in water.
    
    Args:
        green: Green band array
        nir: Near-infrared band array
        water_mask: Boolean mask of water pixels
    
    Returns:
        Algal bloom risk (0-1, higher = more risk)
    """
    if not np.any(water_mask):
        return 0.0
    
    # Get water pixel values
    green_water = green[water_mask].astype(np.float64)
    nir_water = nir[water_mask].astype(np.float64)
    
    # Algal bloom proxy: elevated NIR in water
    # Normal water has very low NIR, algae increases it
    with np.errstate(divide='ignore', invalid='ignore'):
        ratio = np.where(
            green_water > 0,
            nir_water / green_water,
            0
        )
    
    # Normalize to 0-1 (typical ratio range 0-1 for water)
    # Values > 0.5 suggest algae
    algal_risk = np.clip((np.mean(ratio) - 0.2) / 0.6, 0, 1)
    
    return float(algal_risk)


def calculate_water_quality_proxy(
    green: np.ndarray,
    red: np.ndarray,
    nir: np.ndarray,
    water_mask: np.ndarray,
) -> WaterQualityProxy:
    """Calculate water quality proxy indicators.
    
    Args:
        green: Green band array
        red: Red band array
        nir: Near-infrared band array
        water_mask: Boolean mask of water pixels
    
    Returns:
        WaterQualityProxy with quality indicators
    """
    turbidity = estimate_turbidity(green, red, water_mask)
    algal_risk = detect_algal_bloom(green, nir, water_mask)
    
    # Clarity is inverse of turbidity
    clarity = 1.0 - turbidity
    
    return WaterQualityProxy(
        turbidity_index=turbidity,
        algal_bloom_risk=algal_risk,
        clarity_score=clarity,
    )


def track_extent_change(
    water_mask_before: np.ndarray,
    water_mask_after: np.ndarray,
    pixel_size_meters: float = 30.0,
) -> Dict[str, float]:
    """Track changes in water extent between two time periods.
    
    Args:
        water_mask_before: Water mask for earlier date
        water_mask_after: Water mask for later date
        pixel_size_meters: Pixel size for area calculation
    
    Returns:
        Dictionary with change statistics
    """
    # Calculate areas
    area_before = np.sum(water_mask_before) * pixel_size_meters ** 2
    area_after = np.sum(water_mask_after) * pixel_size_meters ** 2
    
    # Calculate change
    area_change = area_after - area_before
    percent_change = (area_change / area_before * 100) if area_before > 0 else 0.0
    
    # Identify gained and lost water
    gained = water_mask_after & ~water_mask_before
    lost = water_mask_before & ~water_mask_after
    
    gained_area = np.sum(gained) * pixel_size_meters ** 2
    lost_area = np.sum(lost) * pixel_size_meters ** 2
    
    return {
        "area_before_sq_meters": float(area_before),
        "area_after_sq_meters": float(area_after),
        "area_change_sq_meters": float(area_change),
        "percent_change": float(percent_change),
        "gained_area_sq_meters": float(gained_area),
        "lost_area_sq_meters": float(lost_area),
    }


def analyze_water_bodies(
    green: np.ndarray,
    nir: np.ndarray,
    red: Optional[np.ndarray] = None,
    swir: Optional[np.ndarray] = None,
    water_threshold: float = 0.0,
    pixel_size_meters: float = 30.0,
) -> WaterBodyAnalysisResult:
    """Perform comprehensive water body analysis.
    
    Args:
        green: Green band array
        nir: Near-infrared band array
        red: Red band array (optional, for quality proxy)
        swir: Short-wave infrared band array (optional, for MNDWI)
        water_threshold: Threshold for water detection
        pixel_size_meters: Pixel size for area calculation
    
    Returns:
        WaterBodyAnalysisResult with complete analysis
    """
    # Detect water
    water_mask, ndwi_result, mndwi_result = detect_water(
        green, nir, swir, water_threshold
    )
    
    # Calculate basic statistics
    valid_mask = ~np.isnan(ndwi_result.data)
    total_valid = np.sum(valid_mask)
    water_count = np.sum(water_mask)
    
    water_percent = float(water_count / total_valid * 100) if total_valid > 0 else 0.0
    total_area = float(water_count * pixel_size_meters ** 2)
    
    # Calculate metrics
    perimeter_pixels = calculate_perimeter(water_mask)
    perimeter_meters = perimeter_pixels * pixel_size_meters
    compactness = calculate_compactness(total_area, perimeter_meters)
    
    # Mean NDWI for water pixels
    water_ndwi = ndwi_result.data[water_mask]
    mean_ndwi = float(np.mean(water_ndwi)) if len(water_ndwi) > 0 else 0.0
    
    metrics = WaterBodyMetrics(
        area_sq_meters=total_area,
        perimeter_meters=perimeter_meters,
        compactness=compactness,
        mean_ndwi=mean_ndwi,
        pixel_count=int(water_count),
    )
    
    # Calculate water quality proxy if red band available
    quality_proxy = None
    if red is not None:
        quality_proxy = calculate_water_quality_proxy(
            green, red, nir, water_mask
        )
    
    # Count water bodies (simplified - treat all as one)
    water_body_count = 1 if water_count > 0 else 0
    
    return WaterBodyAnalysisResult(
        water_mask=water_mask,
        water_percent=water_percent,
        total_water_area_sq_meters=total_area,
        water_body_count=water_body_count,
        metrics=metrics,
        quality_proxy=quality_proxy,
        ndwi=ndwi_result,
        mndwi=mndwi_result,
    )
