"""Data models for satellite-tiler."""

from dataclasses import dataclass, field
from datetime import date
from enum import Enum
from typing import List, Optional, Tuple, Union

import numpy as np


class SatellitePlatform(Enum):
    """Supported satellite platforms."""
    LANDSAT8 = "landsat8"
    SENTINEL2 = "sentinel2"
    CBERS = "cbers"


@dataclass
class BandInfo:
    """Information about a spectral band.
    
    Attributes:
        name: Band identifier (e.g., "B4", "B02")
        description: Human-readable description (e.g., "Red")
        wavelength: Wavelength range (e.g., "0.64-0.67μm")
        resolution: Spatial resolution in meters
    """
    name: str
    description: str
    wavelength: str
    resolution: int

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "name": self.name,
            "description": self.description,
            "wavelength": self.wavelength,
            "resolution": self.resolution,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "BandInfo":
        """Create from dictionary."""
        return cls(
            name=data["name"],
            description=data["description"],
            wavelength=data["wavelength"],
            resolution=data["resolution"],
        )


@dataclass
class MissionInfo:
    """Information about a satellite mission at a location.
    
    Attributes:
        platform: The satellite platform
        bands: List of available spectral bands
        date_range: Tuple of (earliest, latest) ISO date strings
        resolution: Typical spatial resolution in meters
    """
    platform: SatellitePlatform
    bands: List[BandInfo]
    date_range: Tuple[str, str]
    resolution: int

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "platform": self.platform.value,
            "bands": [b.to_dict() for b in self.bands],
            "date_range": list(self.date_range),
            "resolution": self.resolution,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "MissionInfo":
        """Create from dictionary."""
        return cls(
            platform=SatellitePlatform(data["platform"]),
            bands=[BandInfo.from_dict(b) for b in data["bands"]],
            date_range=tuple(data["date_range"]),
            resolution=data["resolution"],
        )


@dataclass
class SceneInfo:
    """Information about a satellite scene.
    
    Attributes:
        scene_id: Unique scene identifier
        platform: The satellite platform
        acquisition_date: Date the scene was acquired
        cloud_cover: Cloud cover percentage (0-100)
        bounds: Geographic bounds (west, south, east, north) in EPSG:4326
        asset_urls: Dictionary mapping asset keys to URLs (from STAC API)
    """
    scene_id: str
    platform: SatellitePlatform
    acquisition_date: date
    cloud_cover: float
    bounds: Tuple[float, float, float, float]
    asset_urls: dict = field(default_factory=dict)

    def __post_init__(self):
        """Validate cloud cover is in valid range."""
        if not 0 <= self.cloud_cover <= 100:
            raise ValueError(f"cloud_cover must be between 0 and 100, got {self.cloud_cover}")
        
        west, south, east, north = self.bounds
        if west >= east:
            raise ValueError(f"Invalid bounds: west ({west}) must be less than east ({east})")
        if south >= north:
            raise ValueError(f"Invalid bounds: south ({south}) must be less than north ({north})")

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "scene_id": self.scene_id,
            "platform": self.platform.value,
            "acquisition_date": self.acquisition_date.isoformat(),
            "cloud_cover": self.cloud_cover,
            "bounds": list(self.bounds),
            "asset_urls": self.asset_urls,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SceneInfo":
        """Create from dictionary."""
        return cls(
            scene_id=data["scene_id"],
            platform=SatellitePlatform(data["platform"]),
            acquisition_date=date.fromisoformat(data["acquisition_date"]),
            cloud_cover=data["cloud_cover"],
            bounds=tuple(data["bounds"]),
            asset_urls=data.get("asset_urls", {}),
        )


@dataclass
class TileResult:
    """Result of a tile fetch operation.
    
    Attributes:
        data: Tile data as numpy array. Shape is (bands, height, width) for
              multi-band or (height, width) for single-band.
        mask: Valid pixel mask. Shape is (height, width), valid pixels = 255.
        bounds: Geographic bounds (west, south, east, north) in EPSG:4326
        crs: Coordinate reference system (e.g., "EPSG:3857")
    """
    data: np.ndarray
    mask: np.ndarray
    bounds: Tuple[float, float, float, float]
    crs: str = "EPSG:3857"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization (without numpy arrays)."""
        return {
            "shape": list(self.data.shape),
            "dtype": str(self.data.dtype),
            "bounds": list(self.bounds),
            "crs": self.crs,
        }


# Scene component dataclasses for parsed scene IDs

@dataclass
class LandsatSceneComponents:
    """Parsed components of a Landsat scene identifier.
    
    Example scene ID: LC08_L1TP_014032_20240615_20240620_02_T1
    """
    sensor: str           # e.g., "LC08"
    processing_level: str # e.g., "L1TP"
    path: int
    row: int
    acquisition_date: date
    processing_date: date
    collection: int
    tier: str             # e.g., "T1"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "sensor": self.sensor,
            "processing_level": self.processing_level,
            "path": self.path,
            "row": self.row,
            "acquisition_date": self.acquisition_date.isoformat(),
            "processing_date": self.processing_date.isoformat(),
            "collection": self.collection,
            "tier": self.tier,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "LandsatSceneComponents":
        """Create from dictionary."""
        return cls(
            sensor=data["sensor"],
            processing_level=data["processing_level"],
            path=data["path"],
            row=data["row"],
            acquisition_date=date.fromisoformat(data["acquisition_date"]),
            processing_date=date.fromisoformat(data["processing_date"]),
            collection=data["collection"],
            tier=data["tier"],
        )


@dataclass
class Sentinel2SceneComponents:
    """Parsed components of a Sentinel-2 scene identifier.
    
    Example scene ID: S2A_MSIL2A_20240615T154911_N0510_R054_T18TXM_20240615T213159
    """
    satellite: str        # e.g., "S2A"
    product_level: str    # e.g., "MSIL2A"
    acquisition_datetime: str  # e.g., "20240615T154911"
    processing_baseline: str   # e.g., "N0510"
    relative_orbit: str   # e.g., "R054"
    tile_id: str          # e.g., "T18TXM"
    product_discriminator: str  # e.g., "20240615T213159"

    @property
    def acquisition_date(self) -> date:
        """Extract acquisition date from datetime string."""
        return date(
            int(self.acquisition_datetime[:4]),
            int(self.acquisition_datetime[4:6]),
            int(self.acquisition_datetime[6:8])
        )

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "satellite": self.satellite,
            "product_level": self.product_level,
            "acquisition_datetime": self.acquisition_datetime,
            "processing_baseline": self.processing_baseline,
            "relative_orbit": self.relative_orbit,
            "tile_id": self.tile_id,
            "product_discriminator": self.product_discriminator,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Sentinel2SceneComponents":
        """Create from dictionary."""
        return cls(
            satellite=data["satellite"],
            product_level=data["product_level"],
            acquisition_datetime=data["acquisition_datetime"],
            processing_baseline=data["processing_baseline"],
            relative_orbit=data["relative_orbit"],
            tile_id=data["tile_id"],
            product_discriminator=data["product_discriminator"],
        )


@dataclass
class CBERSSceneComponents:
    """Parsed components of a CBERS scene identifier.
    
    Example scene ID: CBERS_4_MUX_20240615_178_106_L4
    """
    satellite: str        # e.g., "CBERS_4"
    camera: str           # e.g., "MUX"
    acquisition_date: date
    path: int
    row: int
    processing_level: str # e.g., "L4"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "satellite": self.satellite,
            "camera": self.camera,
            "acquisition_date": self.acquisition_date.isoformat(),
            "path": self.path,
            "row": self.row,
            "processing_level": self.processing_level,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "CBERSSceneComponents":
        """Create from dictionary."""
        return cls(
            satellite=data["satellite"],
            camera=data["camera"],
            acquisition_date=date.fromisoformat(data["acquisition_date"]),
            path=data["path"],
            row=data["row"],
            processing_level=data["processing_level"],
        )


# Type alias for any scene components
SceneComponents = Union[LandsatSceneComponents, Sentinel2SceneComponents, CBERSSceneComponents]
