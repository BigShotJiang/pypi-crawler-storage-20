"""Scene discovery for satellite-tiler.

This module provides functions for discovering available satellite missions
and listing scenes at a given location using STAC APIs.
"""

from datetime import date, timedelta
from typing import List, Optional, Tuple

from satellite_tiler.models import (
    SatellitePlatform,
    BandInfo,
    MissionInfo,
    SceneInfo,
)
from satellite_tiler.exceptions import NoSceneFoundError

# Try to import pystac_client for STAC API queries
try:
    import pystac
    HAS_PYSTAC = True
except ImportError:
    HAS_PYSTAC = False

try:
    import httpx
    HAS_HTTPX = True
except ImportError:
    HAS_HTTPX = False


# Band definitions for each platform
LANDSAT8_BANDS = [
    BandInfo("B1", "Coastal Aerosol", "0.43-0.45μm", 30),
    BandInfo("B2", "Blue", "0.45-0.51μm", 30),
    BandInfo("B3", "Green", "0.53-0.59μm", 30),
    BandInfo("B4", "Red", "0.64-0.67μm", 30),
    BandInfo("B5", "NIR", "0.85-0.88μm", 30),
    BandInfo("B6", "SWIR 1", "1.57-1.65μm", 30),
    BandInfo("B7", "SWIR 2", "2.11-2.29μm", 30),
    BandInfo("B10", "TIRS 1", "10.6-11.19μm", 100),
]

SENTINEL2_BANDS = [
    BandInfo("B01", "Coastal Aerosol", "0.43-0.45μm", 60),
    BandInfo("B02", "Blue", "0.46-0.52μm", 10),
    BandInfo("B03", "Green", "0.54-0.58μm", 10),
    BandInfo("B04", "Red", "0.65-0.68μm", 10),
    BandInfo("B05", "Red Edge 1", "0.70-0.71μm", 20),
    BandInfo("B06", "Red Edge 2", "0.73-0.75μm", 20),
    BandInfo("B07", "Red Edge 3", "0.77-0.79μm", 20),
    BandInfo("B08", "NIR", "0.78-0.90μm", 10),
    BandInfo("B8A", "NIR Narrow", "0.86-0.88μm", 20),
    BandInfo("B11", "SWIR 1", "1.57-1.66μm", 20),
    BandInfo("B12", "SWIR 2", "2.10-2.28μm", 20),
]

CBERS_BANDS = [
    BandInfo("B5", "Blue", "0.45-0.52μm", 20),
    BandInfo("B6", "Green", "0.52-0.59μm", 20),
    BandInfo("B7", "Red", "0.63-0.69μm", 20),
    BandInfo("B8", "NIR", "0.77-0.89μm", 20),
]

PLATFORM_INFO = {
    SatellitePlatform.LANDSAT8: {
        "bands": LANDSAT8_BANDS,
        "resolution": 30,
        "start_date": "2013-04-11",
        "stac_collection": "landsat-c2-l2",
    },
    SatellitePlatform.SENTINEL2: {
        "bands": SENTINEL2_BANDS,
        "resolution": 10,
        "start_date": "2015-06-23",
        "stac_collection": "sentinel-2-l2a",
    },
    SatellitePlatform.CBERS: {
        "bands": CBERS_BANDS,
        "resolution": 20,
        "start_date": "2014-12-07",
        "stac_collection": "cbers-4-mux",
    },
}

# STAC API endpoints
STAC_ENDPOINTS = {
    "earth_search": "https://earth-search.aws.element84.com/v1",
    "usgs": "https://landsatlook.usgs.gov/stac-server",
}



def discover(lat: float, lon: float) -> List[MissionInfo]:
    """Discover available satellite missions at a location."""
    if not -90 <= lat <= 90:
        raise ValueError(f"Latitude must be between -90 and 90, got {lat}")
    if not -180 <= lon <= 180:
        raise ValueError(f"Longitude must be between -180 and 180, got {lon}")
    
    missions = []
    today = date.today().isoformat()
    
    for platform, info in PLATFORM_INFO.items():
        # CBERS has limited coverage (primarily South America)
        if platform == SatellitePlatform.CBERS:
            if not (-60 <= lat <= 15 and -85 <= lon <= -30):
                continue
        
        missions.append(MissionInfo(
            platform=platform,
            bands=info["bands"],
            date_range=(info["start_date"], today),
            resolution=info["resolution"],
        ))
    
    return missions


def list_scenes(
    lat: float,
    lon: float,
    platform: SatellitePlatform,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    max_cloud_cover: float = 100.0,
    limit: int = 10,
) -> List[SceneInfo]:
    """List available scenes using STAC API."""
    if not -90 <= lat <= 90:
        raise ValueError(f"Latitude must be between -90 and 90, got {lat}")
    if not -180 <= lon <= 180:
        raise ValueError(f"Longitude must be between -180 and 180, got {lon}")
    if not 0 <= max_cloud_cover <= 100:
        raise ValueError(f"max_cloud_cover must be between 0 and 100, got {max_cloud_cover}")
    
    # Query STAC API for real scenes
    scenes = _query_stac_api(lat, lon, platform, start_date, end_date, max_cloud_cover, limit)
    
    # Sort by date (most recent first)
    scenes.sort(key=lambda s: s.acquisition_date, reverse=True)
    
    return scenes[:limit]


def _query_stac_api(
    lat: float,
    lon: float,
    platform: SatellitePlatform,
    start_date: Optional[date],
    end_date: Optional[date],
    max_cloud_cover: float,
    limit: int,
) -> List[SceneInfo]:
    """Query STAC API for scenes."""
    if not HAS_HTTPX:
        raise ImportError("httpx is required for STAC queries. Install with: pip install httpx")
    
    # Use Element84 Earth Search for Landsat and Sentinel-2
    stac_url = STAC_ENDPOINTS["earth_search"]
    collection = PLATFORM_INFO[platform]["stac_collection"]
    
    # Build search parameters
    if end_date is None:
        end_date = date.today()
    if start_date is None:
        start_date = end_date - timedelta(days=365)
    
    # Create a small bounding box around the point
    bbox = [lon - 0.01, lat - 0.01, lon + 0.01, lat + 0.01]
    
    search_params = {
        "collections": [collection],
        "bbox": bbox,
        "datetime": f"{start_date.isoformat()}T00:00:00Z/{end_date.isoformat()}T23:59:59Z",
        "limit": limit * 2,  # Request more to filter
        "query": {
            "eo:cloud_cover": {"lte": max_cloud_cover}
        }
    }
    
    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.post(f"{stac_url}/search", json=search_params)
            response.raise_for_status()
            data = response.json()
    except Exception as e:
        raise RuntimeError(f"STAC API query failed: {e}") from e
    
    scenes = []
    today = date.today()
    
    for feature in data.get("features", []):
        props = feature.get("properties", {})
        
        # Extract scene ID
        scene_id = feature.get("id", "")
        
        # Parse acquisition date
        acq_datetime = props.get("datetime", "")
        if acq_datetime:
            acq_date = date.fromisoformat(acq_datetime[:10])
        else:
            continue
        
        # Filter out future-dated scenes (STAC API sometimes returns these)
        if acq_date > today:
            continue
        
        # Get cloud cover
        cloud_cover = props.get("eo:cloud_cover", 0)
        
        # Get bounds
        geom = feature.get("geometry", {})
        coords = geom.get("coordinates", [[]])[0]
        if coords:
            lons = [c[0] for c in coords]
            lats = [c[1] for c in coords]
            bounds = (min(lons), min(lats), max(lons), max(lats))
        else:
            bounds = (lon - 0.5, lat - 0.5, lon + 0.5, lat + 0.5)
        
        # Extract asset URLs from STAC response
        assets = feature.get("assets", {})
        asset_urls = {}
        for asset_key, asset_info in assets.items():
            if "href" in asset_info:
                asset_urls[asset_key] = asset_info["href"]
        
        scenes.append(SceneInfo(
            scene_id=scene_id,
            platform=platform,
            acquisition_date=acq_date,
            cloud_cover=round(cloud_cover, 1),
            bounds=bounds,
            asset_urls=asset_urls,
        ))
    
    return scenes



def filter_scenes(
    scenes: List[SceneInfo],
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    max_cloud_cover: Optional[float] = None,
) -> List[SceneInfo]:
    """Filter a list of scenes by date range and cloud cover."""
    result = []
    for scene in scenes:
        if start_date and scene.acquisition_date < start_date:
            continue
        if end_date and scene.acquisition_date > end_date:
            continue
        if max_cloud_cover is not None and scene.cloud_cover > max_cloud_cover:
            continue
        result.append(scene)
    return result


def sort_scenes_by_date(scenes: List[SceneInfo], descending: bool = True) -> List[SceneInfo]:
    """Sort scenes by acquisition date."""
    return sorted(scenes, key=lambda s: s.acquisition_date, reverse=descending)


def get_bands_for_platform(platform: SatellitePlatform) -> List[BandInfo]:
    """Get available bands for a satellite platform."""
    return PLATFORM_INFO[platform]["bands"]


def get_band_names_for_platform(platform: SatellitePlatform) -> List[str]:
    """Get band names for a satellite platform."""
    return [b.name for b in PLATFORM_INFO[platform]["bands"]]
