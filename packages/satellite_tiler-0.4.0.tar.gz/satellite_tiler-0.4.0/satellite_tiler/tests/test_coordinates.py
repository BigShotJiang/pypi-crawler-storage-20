"""Tests for coordinate conversion utilities."""

import pytest
from hypothesis import given, settings, assume
from hypothesis import strategies as st
import math

from satellite_tiler.coordinates import (
    lat_lon_to_tile,
    tile_to_bounds,
    tile_center,
    meters_per_pixel,
    point_in_bounds,
)


class TestCoordinateConversionRoundTrip:
    """Property 5: Coordinate Conversion Round-Trip
    
    For any valid latitude (-85.05 to 85.05), longitude (-180 to 180), and zoom level (0-22),
    converting to tile coordinates and back to lat/lon bounds SHALL produce a bounding box
    that contains the original point.
    
    Validates: Requirements 3.2
    """

    @given(
        lat=st.floats(min_value=-85.0, max_value=85.0, allow_nan=False, allow_infinity=False, allow_subnormal=False),
        lon=st.floats(min_value=-179.9, max_value=179.9, allow_nan=False, allow_infinity=False, allow_subnormal=False),
        zoom=st.integers(min_value=0, max_value=20)
    )
    @settings(max_examples=100)
    def test_coordinate_conversion_round_trip(self, lat: float, lon: float, zoom: int):
        """Feature: satellite-tiler, Property 5: Coordinate conversion round-trip.
        
        Converting lat/lon to tile and back to bounds should contain the original point.
        """
        # Skip subnormal/denormalized floats that cause precision issues
        assume(abs(lat) > 1e-10 or lat == 0.0)
        assume(abs(lon) > 1e-10 or lon == 0.0)
        
        # Convert to tile coordinates
        x, y = lat_lon_to_tile(lat, lon, zoom)
        
        # Convert back to bounds
        west, south, east, north = tile_to_bounds(x, y, zoom)
        
        # Original point should be within the tile bounds (with small epsilon for floating point)
        eps = 1e-9
        assert west - eps <= lon <= east + eps, f"Longitude {lon} not in [{west}, {east}]"
        assert south - eps <= lat <= north + eps, f"Latitude {lat} not in [{south}, {north}]"

    @given(
        lat=st.floats(min_value=-85.0, max_value=85.0, allow_nan=False, allow_infinity=False, allow_subnormal=False),
        lon=st.floats(min_value=-179.9, max_value=179.9, allow_nan=False, allow_infinity=False, allow_subnormal=False),
        zoom=st.integers(min_value=0, max_value=20)
    )
    @settings(max_examples=100)
    def test_point_in_bounds_after_conversion(self, lat: float, lon: float, zoom: int):
        """Feature: satellite-tiler, Property 5: point_in_bounds returns True after conversion."""
        # Skip subnormal/denormalized floats that cause precision issues
        assume(abs(lat) > 1e-10 or lat == 0.0)
        assume(abs(lon) > 1e-10 or lon == 0.0)
        
        x, y = lat_lon_to_tile(lat, lon, zoom)
        bounds = tile_to_bounds(x, y, zoom)
        
        # Use slightly expanded bounds for floating point tolerance
        west, south, east, north = bounds
        eps = 1e-9
        expanded_bounds = (west - eps, south - eps, east + eps, north + eps)
        
        assert point_in_bounds(lat, lon, expanded_bounds), \
            f"Point ({lat}, {lon}) should be in bounds {bounds}"


class TestLatLonToTile:
    """Unit tests for lat_lon_to_tile function."""

    def test_new_york_city(self):
        """Test conversion for New York City coordinates."""
        x, y = lat_lon_to_tile(40.7128, -74.0060, 12)
        # NYC should be around tile (1205, 1539) at zoom 12
        assert 1200 <= x <= 1210
        assert 1535 <= y <= 1545

    def test_london(self):
        """Test conversion for London coordinates."""
        x, y = lat_lon_to_tile(51.5074, -0.1278, 12)
        # London should be around tile (2046, 1362) at zoom 12
        assert 2040 <= x <= 2050
        assert 1358 <= y <= 1368

    def test_equator_prime_meridian(self):
        """Test conversion for equator/prime meridian intersection."""
        x, y = lat_lon_to_tile(0, 0, 10)
        n = 2 ** 10
        # Should be at center of tile grid
        assert x == n // 2
        assert y == n // 2

    def test_zoom_0(self):
        """Test that zoom 0 always returns (0, 0)."""
        x, y = lat_lon_to_tile(40.7128, -74.0060, 0)
        assert x == 0
        assert y == 0

    def test_invalid_latitude_raises(self):
        """Test that invalid latitude raises ValueError."""
        with pytest.raises(ValueError, match="Latitude"):
            lat_lon_to_tile(90, 0, 10)

    def test_invalid_longitude_raises(self):
        """Test that invalid longitude raises ValueError."""
        with pytest.raises(ValueError, match="Longitude"):
            lat_lon_to_tile(0, 200, 10)

    def test_invalid_zoom_raises(self):
        """Test that invalid zoom raises ValueError."""
        with pytest.raises(ValueError, match="Zoom"):
            lat_lon_to_tile(0, 0, 25)


class TestTileToBounds:
    """Unit tests for tile_to_bounds function."""

    def test_zoom_0_covers_world(self):
        """Test that zoom 0 tile covers the whole world."""
        west, south, east, north = tile_to_bounds(0, 0, 0)
        assert west == -180
        assert east == 180
        assert south < -85
        assert north > 85

    def test_bounds_are_ordered(self):
        """Test that bounds are properly ordered."""
        west, south, east, north = tile_to_bounds(100, 100, 10)
        assert west < east
        assert south < north

    def test_invalid_tile_x_raises(self):
        """Test that invalid tile x raises ValueError."""
        with pytest.raises(ValueError, match="Tile x"):
            tile_to_bounds(5000, 0, 10)  # Max at zoom 10 is 1023

    def test_invalid_tile_y_raises(self):
        """Test that invalid tile y raises ValueError."""
        with pytest.raises(ValueError, match="Tile y"):
            tile_to_bounds(0, 5000, 10)


class TestTileCenter:
    """Unit tests for tile_center function."""

    def test_center_is_within_bounds(self):
        """Test that tile center is within tile bounds."""
        x, y, zoom = 1205, 1539, 12
        lat, lon = tile_center(x, y, zoom)
        west, south, east, north = tile_to_bounds(x, y, zoom)
        
        assert west < lon < east
        assert south < lat < north


class TestMetersPerPixel:
    """Unit tests for meters_per_pixel function."""

    def test_resolution_decreases_with_zoom(self):
        """Test that resolution decreases as zoom increases."""
        res_10 = meters_per_pixel(40.0, 10)
        res_12 = meters_per_pixel(40.0, 12)
        res_14 = meters_per_pixel(40.0, 14)
        
        assert res_10 > res_12 > res_14

    def test_resolution_varies_with_latitude(self):
        """Test that resolution varies with latitude."""
        res_equator = meters_per_pixel(0, 12)
        res_mid_lat = meters_per_pixel(45, 12)
        res_high_lat = meters_per_pixel(70, 12)
        
        # Resolution should be highest at equator
        assert res_equator > res_mid_lat > res_high_lat


class TestPointInBounds:
    """Unit tests for point_in_bounds function."""

    def test_point_inside(self):
        """Test point inside bounds returns True."""
        bounds = (-74.5, 40.5, -73.5, 41.5)
        assert point_in_bounds(41.0, -74.0, bounds)

    def test_point_outside(self):
        """Test point outside bounds returns False."""
        bounds = (-74.5, 40.5, -73.5, 41.5)
        assert not point_in_bounds(42.0, -74.0, bounds)

    def test_point_on_edge(self):
        """Test point on edge returns True."""
        bounds = (-74.5, 40.5, -73.5, 41.5)
        assert point_in_bounds(40.5, -74.0, bounds)  # On south edge
