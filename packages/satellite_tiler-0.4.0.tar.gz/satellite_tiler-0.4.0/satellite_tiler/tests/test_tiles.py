"""Tests for tile fetching.

These tests require AWS credentials to be configured.
"""

import pytest
from hypothesis import given, settings, assume
from hypothesis import strategies as st
import numpy as np

from satellite_tiler.models import SatellitePlatform
from satellite_tiler.tiles import (
    get_tile,
    validate_tile_request,
    calculate_tile_dimensions,
    set_scene_asset_urls,
    _validate_aws_credentials,
)
from satellite_tiler.bands import validate_bands, get_valid_bands, is_valid_band
from satellite_tiler.exceptions import InvalidBandError, AuthenticationError


class TestAWSCredentials:
    """Tests for AWS credential validation."""

    def test_aws_credentials_available(self):
        """AWS credentials must be available for this project."""
        _validate_aws_credentials()


class TestInvalidBandError:
    """Property 10: Invalid Band Error"""

    @given(
        invalid_band=st.text(min_size=1, max_size=10, alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
    )
    @settings(max_examples=100)
    def test_invalid_band_raises_error(self, invalid_band):
        """Invalid band raises error with valid bands."""
        platform = SatellitePlatform.LANDSAT8
        if is_valid_band(invalid_band, platform):
            assume(False)
        
        with pytest.raises(InvalidBandError) as exc_info:
            validate_bands([invalid_band], platform)
        
        assert invalid_band in str(exc_info.value)

    def test_invalid_band_error_contains_valid_list(self):
        """InvalidBandError should contain list of valid bands."""
        with pytest.raises(InvalidBandError) as exc_info:
            validate_bands(["INVALID"], SatellitePlatform.LANDSAT8)
        
        error = exc_info.value
        assert len(error.valid_bands) > 0
        assert "B4" in error.valid_bands


class TestTileScaleDimensions:
    """Property 6: Tile Scale Dimensions"""

    def test_calculate_tile_dimensions(self):
        """calculate_tile_dimensions should return correct size."""
        assert calculate_tile_dimensions(1) == 256
        assert calculate_tile_dimensions(2) == 512
        assert calculate_tile_dimensions(4) == 1024


class TestBandsAndExpressionMutualExclusion:
    """Property 9: Bands and Expression Mutual Exclusion"""

    @given(
        bands=st.lists(st.sampled_from(["B4", "B3", "B2", "B5"]), min_size=1, max_size=3),
        expression=st.sampled_from(["(B5-B4)/(B5+B4)", "B5/B4"])
    )
    @settings(max_examples=100)
    def test_bands_and_expression_raises_error(self, bands, expression):
        """Bands and expression raises ValueError."""
        with pytest.raises(ValueError, match="[Cc]annot"):
            get_tile(
                scene_id="LC08_L1TP_014032_20240615_20240620_02_T1",
                lat=40.7128,
                lon=-74.0060,
                zoom=12,
                bands=bands,
                expression=expression,
            )

    def test_validate_tile_request_raises(self):
        """validate_tile_request should raise for both bands and expression."""
        with pytest.raises(ValueError):
            validate_tile_request(bands=["B4"], expression="B5/B4")


class TestBandValidation:
    """Unit tests for band validation."""

    def test_validate_bands_landsat(self):
        """validate_bands should accept valid Landsat bands."""
        result = validate_bands(["B4", "B3", "B2"], SatellitePlatform.LANDSAT8)
        assert result == ["B4", "B3", "B2"]

    def test_validate_bands_aliases(self):
        """validate_bands should accept band aliases."""
        result = validate_bands(["red", "green", "blue"], SatellitePlatform.LANDSAT8)
        assert result == ["B4", "B3", "B2"]

    def test_validate_bands_sentinel2(self):
        """validate_bands should accept valid Sentinel-2 bands."""
        result = validate_bands(["B04", "B03", "B02"], SatellitePlatform.SENTINEL2)
        assert result == ["B04", "B03", "B02"]

    def test_validate_bands_invalid(self):
        """validate_bands should reject invalid bands."""
        with pytest.raises(InvalidBandError):
            validate_bands(["B99"], SatellitePlatform.LANDSAT8)


class TestGetTileSentinel2:
    """Tests for Sentinel-2 tile fetching."""

    def test_get_tile_sentinel2_real(self):
        """get_tile should fetch real Sentinel-2 data."""
        from satellite_tiler.discovery import list_scenes
        
        scenes = list_scenes(
            lat=-27.4698, lon=153.0251,
            platform=SatellitePlatform.SENTINEL2,
            max_cloud_cover=30,
            limit=1
        )
        
        assert len(scenes) > 0, "No Sentinel-2 scenes available"
        
        scene = scenes[0]
        set_scene_asset_urls(scene.scene_id, scene.asset_urls)
        
        result = get_tile(
            scene_id=scene.scene_id,
            lat=-27.4698,
            lon=153.0251,
            zoom=10,
            bands=["B04", "B03", "B02"],
        )
        
        assert result.data is not None
        assert result.data.shape[0] == 3
        assert result.data.shape[1] == 256
        assert result.data.shape[2] == 256
        assert result.crs == "EPSG:3857"


class TestGetTileLandsat:
    """Tests for Landsat tile fetching."""

    def test_get_tile_landsat_real(self):
        """get_tile should fetch real Landsat data."""
        from satellite_tiler.discovery import list_scenes
        
        scenes = list_scenes(
            lat=-27.4698, lon=153.0251,
            platform=SatellitePlatform.LANDSAT8,
            max_cloud_cover=30,
            limit=1
        )
        
        assert len(scenes) > 0, "No Landsat scenes available"
        
        scene = scenes[0]
        set_scene_asset_urls(scene.scene_id, scene.asset_urls)
        
        result = get_tile(
            scene_id=scene.scene_id,
            lat=-27.4698,
            lon=153.0251,
            zoom=10,
            bands=["B4", "B3", "B2"],
        )
        
        assert result.data is not None
        assert result.data.shape[0] == 3
        assert result.data.shape[1] == 256
