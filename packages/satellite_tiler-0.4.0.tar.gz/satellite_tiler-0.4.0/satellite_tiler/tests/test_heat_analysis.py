"""Tests for urban heat analysis.

Property-based tests validate:
- Property 1: Temperature Conversion Round-Trip
- Property 5: Heat Island Threshold Detection
- Property 6: Temperature Statistics Validity
"""

import numpy as np
import pytest
from hypothesis import given, strategies as st, settings, assume

from satellite_tiler.heat_analysis import (
    HeatAnalysisResult,
    HeatIsland,
    THERMAL_BANDS,
    LANDSAT_C2_L2_ST_SCALE,
    LANDSAT_C2_L2_ST_OFFSET,
    celsius_to_fahrenheit,
    fahrenheit_to_celsius,
    kelvin_to_celsius,
    celsius_to_kelvin,
    brightness_temp_to_lst,
    calculate_lst,
    detect_heat_islands,
    analyze_heat,
    has_thermal_bands,
    get_thermal_bands,
    scale_landsat_c2_l2_thermal,
    is_scaled_integer_data,
)


# Property 1: Temperature Conversion Round-Trip
# For any temperature value in Celsius, converting to Fahrenheit and back
# to Celsius SHALL produce the original value (within floating-point tolerance).

class TestTemperatureConversionRoundTrip:
    """Feature: geospatial-agent-tools, Property 1: Temperature Conversion Round-Trip"""
    
    @given(celsius=st.floats(min_value=-273.15, max_value=1000, allow_nan=False, allow_infinity=False))
    @settings(max_examples=200)
    def test_celsius_fahrenheit_round_trip(self, celsius):
        """Converting C->F->C should return original value."""
        fahrenheit = celsius_to_fahrenheit(celsius)
        back_to_celsius = fahrenheit_to_celsius(fahrenheit)
        
        assert abs(back_to_celsius - celsius) < 1e-10, \
            f"Round trip failed: {celsius} -> {fahrenheit} -> {back_to_celsius}"
    
    @given(fahrenheit=st.floats(min_value=-459.67, max_value=2000, allow_nan=False, allow_infinity=False))
    @settings(max_examples=200)
    def test_fahrenheit_celsius_round_trip(self, fahrenheit):
        """Converting F->C->F should return original value."""
        celsius = fahrenheit_to_celsius(fahrenheit)
        back_to_fahrenheit = celsius_to_fahrenheit(celsius)
        
        assert abs(back_to_fahrenheit - fahrenheit) < 1e-10
    
    @given(kelvin=st.floats(min_value=0, max_value=1500, allow_nan=False, allow_infinity=False))
    @settings(max_examples=200)
    def test_kelvin_celsius_round_trip(self, kelvin):
        """Converting K->C->K should return original value."""
        celsius = kelvin_to_celsius(kelvin)
        back_to_kelvin = celsius_to_kelvin(celsius)
        
        assert abs(back_to_kelvin - kelvin) < 1e-10


# Property 5: Heat Island Threshold Detection
# For any LST array and threshold value T, a pixel SHALL be classified as
# a heat island if and only if its temperature exceeds (mean_temperature + T).

class TestHeatIslandThresholdDetection:
    """Feature: geospatial-agent-tools, Property 5: Heat Island Threshold Detection"""
    
    @given(
        threshold=st.floats(min_value=0.1, max_value=10.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_heat_island_threshold_correctness(self, threshold):
        """Pixels above mean + threshold should be heat islands."""
        # Create a simple temperature array
        lst = np.array([
            [20.0, 22.0, 24.0],
            [26.0, 28.0, 30.0],
            [32.0, 34.0, 36.0]
        ])
        
        mean_temp = np.mean(lst)
        threshold_temp = mean_temp + threshold
        
        mask, _ = detect_heat_islands(lst, threshold)
        
        # Verify each pixel
        for i in range(lst.shape[0]):
            for j in range(lst.shape[1]):
                is_heat_island = mask[i, j]
                should_be_heat_island = lst[i, j] > threshold_temp
                
                assert is_heat_island == should_be_heat_island, \
                    f"Pixel ({i},{j}): temp={lst[i,j]}, threshold={threshold_temp}, " \
                    f"is_hi={is_heat_island}, should_be={should_be_heat_island}"
    
    @given(
        base_temp=st.floats(min_value=-20, max_value=50, allow_nan=False, allow_infinity=False),
        threshold=st.floats(min_value=0.5, max_value=5.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_uniform_temperature_no_heat_islands(self, base_temp, threshold):
        """Uniform temperature should have no heat islands."""
        lst = np.full((10, 10), base_temp)
        
        mask, heat_islands = detect_heat_islands(lst, threshold)
        
        # All pixels at mean, none above mean + threshold
        assert not np.any(mask)
        assert len(heat_islands) == 0
    
    def test_single_hot_pixel(self):
        """Single pixel above threshold should be detected."""
        lst = np.full((5, 5), 25.0)
        lst[2, 2] = 35.0  # Hot spot
        
        mean_temp = np.mean(lst)  # ~25.4
        threshold = 5.0  # threshold_temp = ~30.4
        
        mask, heat_islands = detect_heat_islands(lst, threshold)
        
        # Only the hot pixel should be detected
        assert mask[2, 2] == True
        assert np.sum(mask) == 1


# Property 6: Temperature Statistics Validity
# For any temperature array, the statistics SHALL satisfy:
# min ≤ mean ≤ max AND std ≥ 0.

class TestTemperatureStatisticsValidity:
    """Feature: geospatial-agent-tools, Property 6: Temperature Statistics Validity"""
    
    @given(
        temps=st.lists(
            st.floats(min_value=-50, max_value=60, allow_nan=False, allow_infinity=False),
            min_size=4,
            max_size=100
        )
    )
    @settings(max_examples=100)
    def test_statistics_ordering(self, temps):
        """Statistics must satisfy min <= mean <= max."""
        # Create 2D array from temps
        size = int(np.sqrt(len(temps)))
        if size * size > len(temps):
            size -= 1
        if size < 2:
            return  # Skip if too small
        
        lst = np.array(temps[:size*size]).reshape((size, size))
        
        # Simulate brightness temp in Kelvin (add 273.15)
        bt_kelvin = lst + 273.15
        
        result = analyze_heat(bt_kelvin, is_radiance=False)
        
        # Check ordering
        assert result.min_temp_c <= result.mean_temp_c, \
            f"min ({result.min_temp_c}) > mean ({result.mean_temp_c})"
        assert result.mean_temp_c <= result.max_temp_c, \
            f"mean ({result.mean_temp_c}) > max ({result.max_temp_c})"
        assert result.std_temp_c >= 0, \
            f"std ({result.std_temp_c}) < 0"
    
    def test_statistics_known_values(self):
        """Statistics should match numpy calculations."""
        # Create known temperature array (as brightness temp in Kelvin)
        temps_c = np.array([
            [20.0, 22.0, 24.0],
            [26.0, 28.0, 30.0],
            [32.0, 34.0, 36.0]
        ])
        bt_kelvin = temps_c + 273.15
        
        result = analyze_heat(bt_kelvin, is_radiance=False, emissivity=1.0)
        
        # With emissivity=1.0, LST should equal brightness temp
        expected_min = 20.0
        expected_max = 36.0
        expected_mean = 28.0
        
        assert abs(result.min_temp_c - expected_min) < 0.1
        assert abs(result.max_temp_c - expected_max) < 0.1
        assert abs(result.mean_temp_c - expected_mean) < 0.1
    
    def test_statistics_with_nan(self):
        """Statistics should exclude NaN values."""
        bt_kelvin = np.array([
            [300.0, np.nan, 310.0],
            [305.0, 315.0, np.nan],
            [np.nan, 320.0, 325.0]
        ])
        
        result = analyze_heat(bt_kelvin, is_radiance=False, emissivity=1.0)
        
        # Should have valid statistics from non-NaN values
        assert not np.isnan(result.min_temp_c)
        assert not np.isnan(result.max_temp_c)
        assert not np.isnan(result.mean_temp_c)
        assert result.std_temp_c >= 0


# Unit tests for specific functions

class TestTemperatureConversions:
    """Unit tests for temperature conversion functions."""
    
    def test_celsius_to_fahrenheit_freezing(self):
        """0°C should equal 32°F."""
        assert celsius_to_fahrenheit(0) == 32
    
    def test_celsius_to_fahrenheit_boiling(self):
        """100°C should equal 212°F."""
        assert celsius_to_fahrenheit(100) == 212
    
    def test_fahrenheit_to_celsius_freezing(self):
        """32°F should equal 0°C."""
        assert fahrenheit_to_celsius(32) == 0
    
    def test_kelvin_to_celsius_absolute_zero(self):
        """0K should equal -273.15°C."""
        assert kelvin_to_celsius(0) == -273.15
    
    def test_kelvin_to_celsius_water_freezing(self):
        """273.15K should equal 0°C."""
        assert abs(kelvin_to_celsius(273.15)) < 1e-10


class TestBrightnessTempToLST:
    """Unit tests for brightness temperature to LST conversion."""
    
    def test_lst_with_emissivity_one(self):
        """With emissivity=1, LST should equal brightness temp."""
        bt = np.array([[300.0, 310.0], [320.0, 330.0]])
        lst = brightness_temp_to_lst(bt, emissivity=1.0)
        
        np.testing.assert_array_almost_equal(lst, bt)
    
    def test_lst_lower_than_bt(self):
        """With emissivity < 1, LST should be higher than BT."""
        bt = np.array([[300.0]])
        lst = brightness_temp_to_lst(bt, emissivity=0.95)
        
        # LST should be slightly higher due to emissivity correction
        assert lst[0, 0] > bt[0, 0]
    
    def test_lst_array_shape_preserved(self):
        """Output shape should match input shape."""
        bt = np.random.uniform(280, 320, size=(10, 15))
        lst = brightness_temp_to_lst(bt)
        
        assert lst.shape == bt.shape


class TestCalculateLST:
    """Unit tests for LST calculation."""
    
    def test_calculate_lst_b10(self):
        """LST calculation with B10 band."""
        # Brightness temp in Kelvin
        bt = np.array([[300.0, 310.0]])
        
        lst = calculate_lst(bt, band_name="B10", is_radiance=False)
        
        # Should return Celsius values
        assert np.all(lst < 100)  # Reasonable temperature range
        assert np.all(lst > -50)
    
    def test_calculate_lst_invalid_band(self):
        """Invalid band name should raise error."""
        bt = np.array([[300.0]])
        
        with pytest.raises(ValueError, match="Unknown thermal band"):
            calculate_lst(bt, band_name="B99")


class TestDetectHeatIslands:
    """Unit tests for heat island detection."""
    
    def test_no_heat_islands_uniform(self):
        """Uniform temperature should have no heat islands."""
        lst = np.full((10, 10), 30.0)
        
        mask, islands = detect_heat_islands(lst, threshold_above_mean=2.0)
        
        assert not np.any(mask)
        assert len(islands) == 0
    
    def test_heat_island_detection(self):
        """Hot region should be detected as heat island."""
        lst = np.full((10, 10), 25.0)
        lst[3:7, 3:7] = 35.0  # Hot region
        
        mask, islands = detect_heat_islands(lst, threshold_above_mean=2.0)
        
        # Hot region should be detected
        assert np.any(mask)
        assert len(islands) > 0
        
        # Check that hot pixels are in mask
        assert np.all(mask[3:7, 3:7])
    
    def test_heat_island_statistics(self):
        """Heat island statistics should be correct."""
        lst = np.full((10, 10), 25.0)
        lst[4:6, 4:6] = 35.0  # 4 hot pixels
        
        mask, islands = detect_heat_islands(lst, threshold_above_mean=2.0)
        
        assert len(islands) == 1
        island = islands[0]
        
        assert island.pixel_count == 4
        assert island.mean_temp_c == 35.0
        assert island.max_temp_c == 35.0
    
    def test_heat_island_with_nan(self):
        """NaN values should be excluded from analysis."""
        lst = np.array([
            [25.0, np.nan, 25.0],
            [25.0, 35.0, 25.0],
            [25.0, 25.0, 25.0]
        ])
        
        mask, islands = detect_heat_islands(lst, threshold_above_mean=2.0)
        
        # NaN pixel should not be in mask
        assert not mask[0, 1]
        # Hot pixel should be detected
        assert mask[1, 1]


class TestAnalyzeHeat:
    """Unit tests for complete heat analysis."""
    
    def test_analyze_heat_result_structure(self):
        """Result should have all required fields."""
        bt = np.random.uniform(290, 320, size=(10, 10))
        
        result = analyze_heat(bt, is_radiance=False)
        
        assert isinstance(result, HeatAnalysisResult)
        assert result.lst_celsius.shape == (10, 10)
        assert result.lst_fahrenheit.shape == (10, 10)
        assert isinstance(result.min_temp_c, float)
        assert isinstance(result.max_temp_c, float)
        assert isinstance(result.mean_temp_c, float)
        assert isinstance(result.std_temp_c, float)
        assert result.heat_island_mask.shape == (10, 10)
        assert 0 <= result.heat_island_area_percent <= 100
    
    def test_analyze_heat_to_dict(self):
        """Result should serialize to dict."""
        bt = np.random.uniform(290, 320, size=(5, 5))
        
        result = analyze_heat(bt, is_radiance=False)
        d = result.to_dict()
        
        assert "min_temp_c" in d
        assert "max_temp_c" in d
        assert "mean_temp_c" in d
        assert "heat_island_area_percent" in d
        assert "shape" in d


class TestPlatformThermalBands:
    """Unit tests for platform thermal band functions."""
    
    def test_landsat8_has_thermal(self):
        """Landsat 8 should have thermal bands."""
        assert has_thermal_bands("landsat8")
        assert has_thermal_bands("LANDSAT8")
    
    def test_sentinel2_no_thermal(self):
        """Sentinel-2 should not have thermal bands."""
        assert not has_thermal_bands("sentinel2")
    
    def test_get_thermal_bands_landsat8(self):
        """Should return Landsat 8 thermal bands."""
        bands = get_thermal_bands("landsat8")
        
        assert bands is not None
        assert "B10" in bands
        assert "B11" in bands
    
    def test_get_thermal_bands_sentinel2(self):
        """Should return None for Sentinel-2."""
        bands = get_thermal_bands("sentinel2")
        
        assert bands is None
    
    def test_unknown_platform(self):
        """Unknown platform should return False/None."""
        assert not has_thermal_bands("unknown")
        assert get_thermal_bands("unknown") is None


class TestLandsatC2L2Scaling:
    """Unit tests for Landsat Collection 2 Level-2 thermal scaling."""
    
    def test_scale_landsat_c2_l2_thermal_known_values(self):
        """Test scaling with known values from USGS documentation."""
        # For 300K (27°C): DN = (300 - 149) / 0.00341802 ≈ 44186
        dn = np.array([[44186]])
        
        kelvin = scale_landsat_c2_l2_thermal(dn)
        
        # Should be approximately 300K
        assert abs(kelvin[0, 0] - 300.0) < 0.1
    
    def test_scale_landsat_c2_l2_thermal_fill_value(self):
        """Fill values should become NaN."""
        dn = np.array([[44186, 0, 44186]])
        
        kelvin = scale_landsat_c2_l2_thermal(dn, fill_value=0)
        
        assert not np.isnan(kelvin[0, 0])
        assert np.isnan(kelvin[0, 1])
        assert not np.isnan(kelvin[0, 2])
    
    def test_scale_landsat_c2_l2_thermal_array(self):
        """Test scaling preserves array shape."""
        # Typical Brisbane summer temps: 25-40°C (298-313K)
        # DN values: (298-149)/0.00341802 ≈ 43600 to (313-149)/0.00341802 ≈ 47990
        dn = np.array([
            [43600, 44500, 45400],
            [44000, 46000, 47000],
            [45000, 46500, 47990]
        ])
        
        kelvin = scale_landsat_c2_l2_thermal(dn)
        
        assert kelvin.shape == dn.shape
        # All values should be in reasonable range
        assert np.all(kelvin > 290)  # > 17°C
        assert np.all(kelvin < 320)  # < 47°C
    
    def test_is_scaled_integer_data_large_values(self):
        """Large values (>1000) should be detected as scaled integers."""
        # Typical Landsat C2 L2 ST values
        data = np.array([[44000, 45000, 46000]])
        
        assert is_scaled_integer_data(data)
    
    def test_is_scaled_integer_data_kelvin_values(self):
        """Values in Kelvin range (200-400) should not be detected as scaled."""
        data = np.array([[300.0, 310.0, 320.0]])
        
        assert not is_scaled_integer_data(data)
    
    def test_is_scaled_integer_data_empty(self):
        """Empty or all-zero data should return False."""
        data = np.array([[0, 0, 0]])
        
        assert not is_scaled_integer_data(data)
    
    def test_calculate_lst_auto_scale_c2_l2(self):
        """calculate_lst should auto-detect and scale C2 L2 data."""
        # DN for ~300K (27°C)
        dn = np.array([[44186, 44500, 45000]])
        
        lst_celsius = calculate_lst(dn, band_name="B10", auto_scale=True)
        
        # Should be reasonable temperatures
        assert np.all(lst_celsius > 20)  # > 20°C
        assert np.all(lst_celsius < 50)  # < 50°C
    
    def test_calculate_lst_no_auto_scale(self):
        """With auto_scale=False, should treat as brightness temp."""
        # If we pass Kelvin values with auto_scale=False
        bt_kelvin = np.array([[300.0, 310.0]])
        
        lst_celsius = calculate_lst(bt_kelvin, band_name="B10", auto_scale=False)
        
        # Should convert from Kelvin to Celsius (with emissivity correction)
        assert np.all(lst_celsius > 20)
        assert np.all(lst_celsius < 50)
    
    def test_analyze_heat_with_c2_l2_data(self):
        """analyze_heat should work with Landsat C2 L2 scaled data."""
        # Simulate Brisbane summer temps: 25-40°C
        # Create a grid with some variation
        np.random.seed(42)
        base_temp_k = 305  # ~32°C
        variation = np.random.uniform(-5, 10, size=(10, 10))
        temps_k = base_temp_k + variation
        
        # Convert to DN values
        dn = (temps_k - LANDSAT_C2_L2_ST_OFFSET) / LANDSAT_C2_L2_ST_SCALE
        dn = dn.astype(np.int32)
        
        result = analyze_heat(dn, band_name="B10", is_radiance=False)
        
        # Should have reasonable temperatures
        assert result.min_temp_c > 20  # > 20°C
        assert result.max_temp_c < 50  # < 50°C
        assert result.mean_temp_c > 25  # Around 32°C
        assert result.mean_temp_c < 40
    
    def test_realistic_brisbane_temps(self):
        """Test with realistic Brisbane temperature values."""
        # Brisbane summer: typically 25-35°C, can reach 40°C
        # In Kelvin: 298-313K
        # As Landsat C2 L2 DN: ~43600-48000
        
        # Create a realistic urban heat pattern
        lst_target = np.array([
            [28, 29, 30, 31, 32],  # Cooler vegetated area
            [30, 32, 34, 35, 33],  # Transition
            [32, 35, 38, 37, 34],  # Urban core (hotter)
            [31, 34, 36, 35, 33],  # Transition
            [29, 30, 31, 32, 31],  # Cooler area
        ], dtype=np.float64)
        
        # Convert to Kelvin then to DN
        kelvin = lst_target + 273.15
        dn = (kelvin - LANDSAT_C2_L2_ST_OFFSET) / LANDSAT_C2_L2_ST_SCALE
        dn = dn.astype(np.int32)
        
        result = analyze_heat(dn, band_name="B10", heat_island_threshold=3.0)
        
        # Check that we get reasonable results
        assert abs(result.mean_temp_c - np.mean(lst_target)) < 1.0
        assert abs(result.min_temp_c - np.min(lst_target)) < 1.0
        assert abs(result.max_temp_c - np.max(lst_target)) < 1.0
        
        # The urban core (38°C) should be detected as heat island
        # Mean is ~32°C, so 38°C is 6°C above mean (> 3°C threshold)
        assert result.heat_island_area_percent > 0
