"""Tests for image encoding utilities."""

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st
import numpy as np

from satellite_tiler.encoding import (
    to_png,
    to_jpeg,
    to_webp,
    from_png,
    encode,
)


class TestPNGEncodingRoundTrip:
    """Property 17: PNG Encoding Round-Trip
    
    For any valid tile data (uint8 array) and mask, encoding to PNG and
    decoding back SHALL produce pixel values identical to the original
    (PNG is lossless).
    
    Validates: Requirements 8.1
    """

    @given(
        height=st.integers(min_value=8, max_value=64),
        width=st.integers(min_value=8, max_value=64),
    )
    @settings(max_examples=100, deadline=5000)
    def test_png_round_trip_rgb(self, height, width):
        """Feature: satellite-tiler, Property 17: PNG RGB round-trip is lossless."""
        # Create random RGB tile
        tile = np.random.randint(0, 256, (3, height, width), dtype=np.uint8)
        
        # Encode to PNG
        png_bytes = to_png(tile)
        
        # Decode back
        decoded, mask = from_png(png_bytes)
        
        # Should be identical
        np.testing.assert_array_equal(decoded, tile)

    @given(
        height=st.integers(min_value=8, max_value=64),
        width=st.integers(min_value=8, max_value=64),
    )
    @settings(max_examples=100)
    def test_png_round_trip_with_mask(self, height, width):
        """Feature: satellite-tiler, Property 17: PNG with mask round-trip is lossless."""
        # Create random RGB tile and mask
        tile = np.random.randint(0, 256, (3, height, width), dtype=np.uint8)
        mask = np.random.randint(0, 256, (height, width), dtype=np.uint8)
        
        # Encode to PNG with mask
        png_bytes = to_png(tile, mask)
        
        # Decode back
        decoded, decoded_mask = from_png(png_bytes)
        
        # Tile should be identical
        np.testing.assert_array_equal(decoded, tile)
        # Mask should be identical
        np.testing.assert_array_equal(decoded_mask, mask)

    @given(
        height=st.integers(min_value=8, max_value=64),
        width=st.integers(min_value=8, max_value=64),
    )
    @settings(max_examples=100)
    def test_png_round_trip_grayscale(self, height, width):
        """Feature: satellite-tiler, Property 17: PNG grayscale round-trip is lossless."""
        # Create random grayscale tile
        tile = np.random.randint(0, 256, (height, width), dtype=np.uint8)
        
        # Encode to PNG
        png_bytes = to_png(tile)
        
        # Decode back
        decoded, mask = from_png(png_bytes)
        
        # Should be identical (grayscale)
        np.testing.assert_array_equal(decoded, tile)


class TestPNGEncoding:
    """Unit tests for PNG encoding."""

    def test_png_produces_valid_bytes(self):
        """PNG encoding should produce valid PNG bytes."""
        tile = np.random.randint(0, 256, (3, 256, 256), dtype=np.uint8)
        png_bytes = to_png(tile)
        
        # PNG magic bytes
        assert png_bytes[:8] == b'\x89PNG\r\n\x1a\n'

    def test_png_with_alpha(self):
        """PNG with mask should include alpha channel."""
        tile = np.random.randint(0, 256, (3, 64, 64), dtype=np.uint8)
        mask = np.full((64, 64), 128, dtype=np.uint8)
        
        png_bytes = to_png(tile, mask)
        decoded, decoded_mask = from_png(png_bytes)
        
        assert decoded_mask is not None
        np.testing.assert_array_equal(decoded_mask, mask)


class TestJPEGEncoding:
    """Unit tests for JPEG encoding."""

    def test_jpeg_produces_valid_bytes(self):
        """JPEG encoding should produce valid JPEG bytes."""
        tile = np.random.randint(0, 256, (3, 256, 256), dtype=np.uint8)
        jpeg_bytes = to_jpeg(tile)
        
        # JPEG magic bytes (SOI marker)
        assert jpeg_bytes[:2] == b'\xff\xd8'

    def test_jpeg_quality_affects_size(self):
        """Higher JPEG quality should produce larger files."""
        tile = np.random.randint(0, 256, (3, 256, 256), dtype=np.uint8)
        
        low_quality = to_jpeg(tile, quality=20)
        high_quality = to_jpeg(tile, quality=95)
        
        assert len(high_quality) > len(low_quality)

    def test_jpeg_grayscale(self):
        """JPEG should support grayscale images."""
        tile = np.random.randint(0, 256, (64, 64), dtype=np.uint8)
        jpeg_bytes = to_jpeg(tile)
        
        assert jpeg_bytes[:2] == b'\xff\xd8'


class TestWebPEncoding:
    """Unit tests for WebP encoding."""

    def test_webp_produces_valid_bytes(self):
        """WebP encoding should produce valid WebP bytes."""
        tile = np.random.randint(0, 256, (3, 256, 256), dtype=np.uint8)
        webp_bytes = to_webp(tile)
        
        # WebP magic bytes (RIFF header)
        assert webp_bytes[:4] == b'RIFF'
        assert webp_bytes[8:12] == b'WEBP'

    def test_webp_with_alpha(self):
        """WebP should support alpha channel."""
        tile = np.random.randint(0, 256, (3, 64, 64), dtype=np.uint8)
        mask = np.full((64, 64), 128, dtype=np.uint8)
        
        webp_bytes = to_webp(tile, mask)
        
        # Should produce valid WebP
        assert webp_bytes[:4] == b'RIFF'

    def test_webp_lossless(self):
        """WebP lossless mode should be available."""
        tile = np.random.randint(0, 256, (3, 64, 64), dtype=np.uint8)
        
        lossy = to_webp(tile, lossless=False)
        lossless = to_webp(tile, lossless=True)
        
        # Both should be valid WebP
        assert lossy[:4] == b'RIFF'
        assert lossless[:4] == b'RIFF'


class TestEncodeFunction:
    """Unit tests for generic encode function."""

    def test_encode_png(self):
        """encode() with format='png' should produce PNG."""
        tile = np.random.randint(0, 256, (3, 64, 64), dtype=np.uint8)
        result = encode(tile, format="png")
        
        assert result[:8] == b'\x89PNG\r\n\x1a\n'

    def test_encode_jpeg(self):
        """encode() with format='jpeg' should produce JPEG."""
        tile = np.random.randint(0, 256, (3, 64, 64), dtype=np.uint8)
        result = encode(tile, format="jpeg")
        
        assert result[:2] == b'\xff\xd8'

    def test_encode_jpg_alias(self):
        """encode() with format='jpg' should produce JPEG."""
        tile = np.random.randint(0, 256, (3, 64, 64), dtype=np.uint8)
        result = encode(tile, format="jpg")
        
        assert result[:2] == b'\xff\xd8'

    def test_encode_webp(self):
        """encode() with format='webp' should produce WebP."""
        tile = np.random.randint(0, 256, (3, 64, 64), dtype=np.uint8)
        result = encode(tile, format="webp")
        
        assert result[:4] == b'RIFF'

    def test_encode_invalid_format(self):
        """encode() with invalid format should raise ValueError."""
        tile = np.random.randint(0, 256, (3, 64, 64), dtype=np.uint8)
        
        with pytest.raises(ValueError, match="Unsupported format"):
            encode(tile, format="gif")
