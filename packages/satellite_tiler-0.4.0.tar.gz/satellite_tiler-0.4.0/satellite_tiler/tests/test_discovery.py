"""Tests for scene discovery."""

import pytest
from hypothesis import given, settings, assume
from hypothesis import strategies as st
from datetime import date, timedelta

from satellite_tiler.models import SatellitePlatform, SceneInfo
from satellite_tiler.discovery import (
    discover,
    list_scenes,
    filter_scenes,
    sort_scenes_by_date,
    get_bands_for_platform,
)
from satellite_tiler.tests.conftest import scene_info_strategy


class TestSceneFilteringCorrectness:
    """Property 3: Scene Filtering Correctness
    
    For any list of scenes and filter criteria (date range, max cloud cover),
    all scenes in the filtered result SHALL satisfy all specified filter conditions.
    
    Validates: Requirements 2.3
    """

    @given(
        scenes=st.lists(scene_info_strategy(), min_size=1, max_size=20),
        max_cloud=st.floats(min_value=0, max_value=100, allow_nan=False, allow_infinity=False),
    )
    @settings(max_examples=100)
    def test_cloud_cover_filter(self, scenes, max_cloud):
        """Feature: satellite-tiler, Property 3: Cloud cover filter is respected."""
        filtered = filter_scenes(scenes, max_cloud_cover=max_cloud)
        
        for scene in filtered:
            assert scene.cloud_cover <= max_cloud, \
                f"Scene cloud cover {scene.cloud_cover} exceeds max {max_cloud}"

    @given(
        scenes=st.lists(scene_info_strategy(), min_size=1, max_size=20),
    )
    @settings(max_examples=100)
    def test_date_range_filter(self, scenes):
        """Feature: satellite-tiler, Property 3: Date range filter is respected."""
        # Use dates from the generated scenes to ensure valid range
        if not scenes:
            return
        
        dates = [s.acquisition_date for s in scenes]
        min_date = min(dates)
        max_date = max(dates)
        
        # Filter with a range that includes some scenes
        mid_date = min_date + (max_date - min_date) // 2
        
        filtered = filter_scenes(scenes, start_date=mid_date)
        
        for scene in filtered:
            assert scene.acquisition_date >= mid_date, \
                f"Scene date {scene.acquisition_date} is before start_date {mid_date}"

    @given(
        scenes=st.lists(scene_info_strategy(), min_size=1, max_size=20),
        max_cloud=st.floats(min_value=0, max_value=100, allow_nan=False, allow_infinity=False),
    )
    @settings(max_examples=100)
    def test_combined_filters(self, scenes, max_cloud):
        """Feature: satellite-tiler, Property 3: Combined filters are all respected."""
        if not scenes:
            return
        
        dates = [s.acquisition_date for s in scenes]
        start = min(dates)
        end = max(dates)
        
        filtered = filter_scenes(
            scenes,
            start_date=start,
            end_date=end,
            max_cloud_cover=max_cloud
        )
        
        for scene in filtered:
            assert scene.acquisition_date >= start
            assert scene.acquisition_date <= end
            assert scene.cloud_cover <= max_cloud


class TestSceneSortingByDate:
    """Property 4: Scene Sorting by Date
    
    For any list of scenes returned by list_scenes(), the scenes SHALL be
    sorted by acquisition_date in descending order (most recent first).
    
    Validates: Requirements 2.4
    """

    @given(scenes=st.lists(scene_info_strategy(), min_size=2, max_size=20))
    @settings(max_examples=100)
    def test_scenes_sorted_descending(self, scenes):
        """Feature: satellite-tiler, Property 4: Scenes are sorted by date descending."""
        sorted_scenes = sort_scenes_by_date(scenes, descending=True)
        
        for i in range(len(sorted_scenes) - 1):
            assert sorted_scenes[i].acquisition_date >= sorted_scenes[i + 1].acquisition_date, \
                f"Scene at index {i} ({sorted_scenes[i].acquisition_date}) should be >= " \
                f"scene at index {i+1} ({sorted_scenes[i + 1].acquisition_date})"

    @given(scenes=st.lists(scene_info_strategy(), min_size=2, max_size=20))
    @settings(max_examples=100)
    def test_scenes_sorted_ascending(self, scenes):
        """Feature: satellite-tiler, Property 4: Ascending sort works correctly."""
        sorted_scenes = sort_scenes_by_date(scenes, descending=False)
        
        for i in range(len(sorted_scenes) - 1):
            assert sorted_scenes[i].acquisition_date <= sorted_scenes[i + 1].acquisition_date


class TestDiscover:
    """Unit tests for discover function."""

    def test_discover_returns_missions(self):
        """discover() should return list of MissionInfo."""
        missions = discover(lat=40.7128, lon=-74.0060)
        
        assert len(missions) > 0
        for m in missions:
            assert len(m.bands) > 0
            assert m.resolution > 0

    def test_discover_landsat_available(self):
        """Landsat should be available for most land locations."""
        missions = discover(lat=40.7128, lon=-74.0060)
        
        platforms = [m.platform for m in missions]
        assert SatellitePlatform.LANDSAT8 in platforms

    def test_discover_sentinel2_available(self):
        """Sentinel-2 should be available for most land locations."""
        missions = discover(lat=40.7128, lon=-74.0060)
        
        platforms = [m.platform for m in missions]
        assert SatellitePlatform.SENTINEL2 in platforms

    def test_discover_cbers_south_america(self):
        """CBERS should be available for South America."""
        missions = discover(lat=-23.5505, lon=-46.6333)  # São Paulo
        
        platforms = [m.platform for m in missions]
        assert SatellitePlatform.CBERS in platforms

    def test_discover_invalid_lat(self):
        """discover() should raise ValueError for invalid latitude."""
        with pytest.raises(ValueError, match="Latitude"):
            discover(lat=100, lon=0)

    def test_discover_invalid_lon(self):
        """discover() should raise ValueError for invalid longitude."""
        with pytest.raises(ValueError, match="Longitude"):
            discover(lat=0, lon=200)


class TestListScenes:
    """Unit tests for list_scenes function."""

    def test_list_scenes_returns_scenes(self):
        """list_scenes() should return list of SceneInfo."""
        scenes = list_scenes(
            lat=40.7128,
            lon=-74.0060,
            platform=SatellitePlatform.LANDSAT8,
            limit=5
        )
        
        assert len(scenes) <= 5
        for s in scenes:
            assert s.platform == SatellitePlatform.LANDSAT8

    def test_list_scenes_sorted_by_date(self):
        """list_scenes() should return scenes sorted by date."""
        scenes = list_scenes(
            lat=40.7128,
            lon=-74.0060,
            platform=SatellitePlatform.LANDSAT8,
            limit=10
        )
        
        for i in range(len(scenes) - 1):
            assert scenes[i].acquisition_date >= scenes[i + 1].acquisition_date

    def test_list_scenes_cloud_filter(self):
        """list_scenes() should respect cloud cover filter."""
        scenes = list_scenes(
            lat=40.7128,
            lon=-74.0060,
            platform=SatellitePlatform.LANDSAT8,
            max_cloud_cover=20,
            limit=20
        )
        
        for s in scenes:
            assert s.cloud_cover <= 20

    def test_list_scenes_invalid_cloud_cover(self):
        """list_scenes() should raise ValueError for invalid cloud cover."""
        with pytest.raises(ValueError, match="max_cloud_cover"):
            list_scenes(
                lat=40.7128,
                lon=-74.0060,
                platform=SatellitePlatform.LANDSAT8,
                max_cloud_cover=150
            )


class TestGetBandsForPlatform:
    """Unit tests for get_bands_for_platform function."""

    def test_landsat_bands(self):
        """Landsat should have expected bands."""
        bands = get_bands_for_platform(SatellitePlatform.LANDSAT8)
        
        band_names = [b.name for b in bands]
        assert "B4" in band_names  # Red
        assert "B5" in band_names  # NIR

    def test_sentinel2_bands(self):
        """Sentinel-2 should have expected bands."""
        bands = get_bands_for_platform(SatellitePlatform.SENTINEL2)
        
        band_names = [b.name for b in bands]
        assert "B04" in band_names  # Red
        assert "B08" in band_names  # NIR
