"""Tests for tile processing utilities."""

import pytest
from hypothesis import given, settings, assume
from hypothesis import strategies as st
import numpy as np

from satellite_tiler.processing import (
    rescale,
    apply_colormap,
    get_available_colormaps,
    normalize_tile,
    ensure_uint8,
)


class TestRescaleOutputRange:
    """Property 13: Rescale Output Range
    
    For any tile data and rescale parameters (out_min, out_max), all non-masked
    pixel values in the output SHALL be within the range [out_min, out_max].
    
    Validates: Requirements 6.1
    """

    @given(
        data=st.lists(
            st.integers(min_value=0, max_value=65535),
            min_size=16,
            max_size=256
        ),
        in_min=st.floats(min_value=0, max_value=1000, allow_nan=False, allow_infinity=False),
        in_max=st.floats(min_value=1001, max_value=65535, allow_nan=False, allow_infinity=False),
    )
    @settings(max_examples=100)
    def test_rescale_output_in_range(self, data, in_min, in_max):
        """Feature: satellite-tiler, Property 13: Rescale output is in [0, 255]."""
        # Create tile and mask
        size = int(np.sqrt(len(data)))
        if size * size > len(data):
            size -= 1
        tile = np.array(data[:size*size], dtype=np.float32).reshape(size, size)
        mask = np.full((size, size), 255, dtype=np.uint8)
        
        # Rescale
        result = rescale(tile, mask, (in_min, in_max), (0, 255))
        
        # All values should be in [0, 255]
        assert result.min() >= 0, f"Min value {result.min()} < 0"
        assert result.max() <= 255, f"Max value {result.max()} > 255"
        assert result.dtype == np.uint8

    @given(
        out_min=st.integers(min_value=0, max_value=100),
        out_max=st.integers(min_value=150, max_value=255),
    )
    @settings(max_examples=100)
    def test_rescale_custom_output_range(self, out_min, out_max):
        """Feature: satellite-tiler, Property 13: Rescale respects custom output range."""
        tile = np.array([[0, 50], [100, 200]], dtype=np.float32)
        mask = np.full((2, 2), 255, dtype=np.uint8)
        
        result = rescale(tile, mask, (0, 200), (out_min, out_max))
        
        # All values should be in [out_min, out_max]
        assert result.min() >= out_min
        assert result.max() <= out_max


class TestColormapProducesRGB:
    """Property 14: Colormap Produces RGB
    
    For any single-band tile and valid colormap name, applying the colormap
    SHALL produce a 3-band (RGB) output.
    
    Validates: Requirements 6.3
    """

    @given(
        data=st.lists(
            st.integers(min_value=0, max_value=255),
            min_size=64,
            max_size=256
        ),
        colormap=st.sampled_from(["viridis", "terrain", "ndvi", "gray"])
    )
    @settings(max_examples=100)
    def test_colormap_produces_rgb(self, data, colormap):
        """Feature: satellite-tiler, Property 14: Colormap produces 3-band RGB output."""
        size = int(np.sqrt(len(data)))
        if size * size > len(data):
            size -= 1
        tile = np.array(data[:size*size], dtype=np.uint8).reshape(size, size)
        
        result = apply_colormap(tile, colormap)
        
        # Should be 3-band RGB
        assert result.ndim == 3
        assert result.shape[0] == 3
        assert result.shape[1] == size
        assert result.shape[2] == size

    def test_colormap_with_3d_single_band_input(self):
        """Colormap should handle (1, H, W) shaped input."""
        tile = np.random.randint(0, 256, (1, 32, 32), dtype=np.uint8)
        result = apply_colormap(tile, "viridis")
        
        assert result.shape == (3, 32, 32)

    def test_colormap_rejects_multiband(self):
        """Colormap should reject multi-band input."""
        tile = np.random.randint(0, 256, (3, 32, 32), dtype=np.uint8)
        
        with pytest.raises(ValueError, match="single-band"):
            apply_colormap(tile, "viridis")

    def test_unknown_colormap_raises_error(self):
        """Unknown colormap should raise ValueError."""
        tile = np.random.randint(0, 256, (32, 32), dtype=np.uint8)
        
        with pytest.raises(ValueError, match="Unknown colormap"):
            apply_colormap(tile, "nonexistent")


class TestProcessedTileUint8:
    """Property 15: Processed Tile uint8
    
    For any tile after post-processing (rescale, color formula, or colormap),
    the output dtype SHALL be numpy.uint8 with values in range [0, 255].
    
    Validates: Requirements 6.4
    """

    @given(
        data=st.lists(
            st.floats(min_value=-1000, max_value=10000, allow_nan=False, allow_infinity=False),
            min_size=16,
            max_size=256
        )
    )
    @settings(max_examples=100)
    def test_rescale_produces_uint8(self, data):
        """Feature: satellite-tiler, Property 15: Rescale produces uint8 output."""
        size = int(np.sqrt(len(data)))
        if size * size > len(data):
            size -= 1
        tile = np.array(data[:size*size], dtype=np.float32).reshape(size, size)
        mask = np.full((size, size), 255, dtype=np.uint8)
        
        result = rescale(tile, mask, (min(data), max(data) + 1), (0, 255))
        
        assert result.dtype == np.uint8
        assert result.min() >= 0
        assert result.max() <= 255

    @given(
        data=st.lists(
            st.integers(min_value=0, max_value=255),
            min_size=64,
            max_size=256
        )
    )
    @settings(max_examples=100)
    def test_colormap_produces_uint8(self, data):
        """Feature: satellite-tiler, Property 15: Colormap produces uint8 output."""
        size = int(np.sqrt(len(data)))
        if size * size > len(data):
            size -= 1
        tile = np.array(data[:size*size], dtype=np.uint8).reshape(size, size)
        
        result = apply_colormap(tile, "viridis")
        
        assert result.dtype == np.uint8
        assert result.min() >= 0
        assert result.max() <= 255


class TestRescaleUnit:
    """Unit tests for rescale function."""

    def test_rescale_basic(self):
        """Test basic rescaling."""
        tile = np.array([[0, 100], [200, 300]], dtype=np.float32)
        mask = np.full((2, 2), 255, dtype=np.uint8)
        
        result = rescale(tile, mask, (0, 300), (0, 255))
        
        assert result.dtype == np.uint8
        assert result[0, 0] == 0
        assert result[1, 1] == 255

    def test_rescale_with_mask(self):
        """Test rescaling with masked pixels."""
        tile = np.array([[100, 200], [300, 400]], dtype=np.float32)
        mask = np.array([[255, 0], [255, 255]], dtype=np.uint8)
        
        result = rescale(tile, mask, (0, 400), (0, 255))
        
        # Masked pixel should be 0
        assert result[0, 1] == 0

    def test_rescale_multiband(self):
        """Test rescaling multi-band tile."""
        tile = np.random.randint(0, 1000, (3, 32, 32), dtype=np.int16).astype(np.float32)
        mask = np.full((32, 32), 255, dtype=np.uint8)
        
        result = rescale(tile, mask, (0, 1000), (0, 255))
        
        assert result.shape == (3, 32, 32)
        assert result.dtype == np.uint8


class TestEnsureUint8:
    """Unit tests for ensure_uint8 function."""

    def test_already_uint8(self):
        """Test that uint8 input is returned as-is."""
        tile = np.array([[0, 128], [255, 64]], dtype=np.uint8)
        result = ensure_uint8(tile)
        
        assert result.dtype == np.uint8
        np.testing.assert_array_equal(result, tile)

    def test_float_0_1_range(self):
        """Test float [0, 1] is scaled to [0, 255]."""
        tile = np.array([[0.0, 0.5], [1.0, 0.25]], dtype=np.float32)
        result = ensure_uint8(tile)
        
        assert result.dtype == np.uint8
        assert result[0, 0] == 0
        assert result[0, 1] == 127
        assert result[1, 0] == 255

    def test_float_out_of_range(self):
        """Test float outside [0, 1] is clipped."""
        tile = np.array([[-10, 300], [128, 500]], dtype=np.float32)
        result = ensure_uint8(tile)
        
        assert result.dtype == np.uint8
        assert result[0, 0] == 0
        assert result[0, 1] == 255


class TestNormalizeTile:
    """Unit tests for normalize_tile function."""

    def test_normalize_basic(self):
        """Test basic normalization."""
        tile = np.array([[100, 200], [300, 400]], dtype=np.float32)
        result, (p_min, p_max) = normalize_tile(tile)
        
        assert result.dtype == np.uint8
        assert result.min() >= 0
        assert result.max() <= 255

    def test_normalize_returns_range(self):
        """Test that normalize returns the range used."""
        # Start from 1 to avoid the zero-filtering behavior
        tile = np.arange(1, 1001, dtype=np.float32).reshape(25, 40)
        result, (p_min, p_max) = normalize_tile(tile, percentile_min=0, percentile_max=100)
        
        # p_min should be the minimum value (1) and p_max should be the maximum (1000)
        assert p_min == pytest.approx(1, abs=1)
        assert p_max == pytest.approx(1000, abs=1)
