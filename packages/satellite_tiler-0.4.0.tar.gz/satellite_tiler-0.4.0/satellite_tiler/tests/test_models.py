"""Tests for satellite-tiler data models."""

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st
from datetime import date

from satellite_tiler.models import (
    SatellitePlatform,
    BandInfo,
    MissionInfo,
    SceneInfo,
)
from satellite_tiler.tests.conftest import (
    mission_info_strategy,
    scene_info_strategy,
    band_info_strategy,
    valid_bounds_strategy,
)


class TestMissionInfoCompleteness:
    """Property 1: MissionInfo Completeness
    
    For any MissionInfo object, it SHALL have:
    - A non-empty bands list where each BandInfo has name, description, wavelength, and resolution
    - A date_range tuple where start_date <= end_date
    - A positive resolution value
    
    Validates: Requirements 1.2, 1.3, 1.4
    """

    @given(mission_info=mission_info_strategy())
    @settings(max_examples=100)
    def test_mission_info_has_non_empty_bands(self, mission_info: MissionInfo):
        """Feature: satellite-tiler, Property 1: MissionInfo has non-empty bands list."""
        assert len(mission_info.bands) > 0, "MissionInfo must have at least one band"

    @given(mission_info=mission_info_strategy())
    @settings(max_examples=100)
    def test_mission_info_bands_have_required_fields(self, mission_info: MissionInfo):
        """Feature: satellite-tiler, Property 1: Each BandInfo has required fields."""
        for band in mission_info.bands:
            assert band.name, "BandInfo must have a name"
            assert band.description, "BandInfo must have a description"
            assert band.wavelength, "BandInfo must have a wavelength"
            assert band.resolution > 0, "BandInfo resolution must be positive"

    @given(mission_info=mission_info_strategy())
    @settings(max_examples=100)
    def test_mission_info_date_range_valid(self, mission_info: MissionInfo):
        """Feature: satellite-tiler, Property 1: date_range has start <= end."""
        start_date, end_date = mission_info.date_range
        assert start_date <= end_date, f"Start date {start_date} must be <= end date {end_date}"

    @given(mission_info=mission_info_strategy())
    @settings(max_examples=100)
    def test_mission_info_resolution_positive(self, mission_info: MissionInfo):
        """Feature: satellite-tiler, Property 1: resolution is positive."""
        assert mission_info.resolution > 0, "MissionInfo resolution must be positive"

    @given(mission_info=mission_info_strategy())
    @settings(max_examples=100)
    def test_mission_info_has_valid_platform(self, mission_info: MissionInfo):
        """Feature: satellite-tiler, Property 1: platform is a valid SatellitePlatform."""
        assert isinstance(mission_info.platform, SatellitePlatform)


class TestSceneInfoCompleteness:
    """Property 2: SceneInfo Completeness
    
    For any SceneInfo object, it SHALL have:
    - A non-empty scene_id
    - A valid acquisition_date
    - cloud_cover between 0 and 100 inclusive
    - Valid bounds tuple (west < east, south < north)
    
    Validates: Requirements 2.2
    """

    @given(scene_info=scene_info_strategy())
    @settings(max_examples=100)
    def test_scene_info_has_non_empty_scene_id(self, scene_info: SceneInfo):
        """Feature: satellite-tiler, Property 2: SceneInfo has non-empty scene_id."""
        assert scene_info.scene_id, "SceneInfo must have a non-empty scene_id"

    @given(scene_info=scene_info_strategy())
    @settings(max_examples=100)
    def test_scene_info_has_valid_acquisition_date(self, scene_info: SceneInfo):
        """Feature: satellite-tiler, Property 2: SceneInfo has valid acquisition_date."""
        assert isinstance(scene_info.acquisition_date, date)

    @given(scene_info=scene_info_strategy())
    @settings(max_examples=100)
    def test_scene_info_cloud_cover_in_range(self, scene_info: SceneInfo):
        """Feature: satellite-tiler, Property 2: cloud_cover is between 0 and 100."""
        assert 0 <= scene_info.cloud_cover <= 100, \
            f"cloud_cover must be 0-100, got {scene_info.cloud_cover}"

    @given(scene_info=scene_info_strategy())
    @settings(max_examples=100)
    def test_scene_info_bounds_valid(self, scene_info: SceneInfo):
        """Feature: satellite-tiler, Property 2: bounds are valid (west < east, south < north)."""
        west, south, east, north = scene_info.bounds
        assert west < east, f"west ({west}) must be < east ({east})"
        assert south < north, f"south ({south}) must be < north ({north})"


class TestModelSerialization:
    """Test JSON serialization round-trip for models."""

    @given(band_info=band_info_strategy())
    @settings(max_examples=100)
    def test_band_info_round_trip(self, band_info: BandInfo):
        """BandInfo serialization round-trip produces equivalent object."""
        serialized = band_info.to_dict()
        deserialized = BandInfo.from_dict(serialized)
        assert deserialized.name == band_info.name
        assert deserialized.description == band_info.description
        assert deserialized.wavelength == band_info.wavelength
        assert deserialized.resolution == band_info.resolution

    @given(mission_info=mission_info_strategy())
    @settings(max_examples=100)
    def test_mission_info_round_trip(self, mission_info: MissionInfo):
        """MissionInfo serialization round-trip produces equivalent object."""
        serialized = mission_info.to_dict()
        deserialized = MissionInfo.from_dict(serialized)
        assert deserialized.platform == mission_info.platform
        assert len(deserialized.bands) == len(mission_info.bands)
        assert deserialized.date_range == mission_info.date_range
        assert deserialized.resolution == mission_info.resolution

    @given(scene_info=scene_info_strategy())
    @settings(max_examples=100)
    def test_scene_info_round_trip(self, scene_info: SceneInfo):
        """SceneInfo serialization round-trip produces equivalent object."""
        serialized = scene_info.to_dict()
        deserialized = SceneInfo.from_dict(serialized)
        assert deserialized.scene_id == scene_info.scene_id
        assert deserialized.platform == scene_info.platform
        assert deserialized.acquisition_date == scene_info.acquisition_date
        assert deserialized.cloud_cover == scene_info.cloud_cover
        assert deserialized.bounds == scene_info.bounds
