"""Tests for change detection.

Property-based tests validate:
- Property 8: Change Category Classification Exhaustiveness
- Property 14: Urban Expansion Detection Logic
"""

import numpy as np
import pytest
from hypothesis import given, strategies as st, settings

from satellite_tiler.change_detection import (
    ChangeCategory,
    ChangeDetectionResult,
    UrbanExpansionResult,
    CHANGE_THRESHOLDS,
    categorize_change,
    calculate_category_percentages,
    calculate_change_histogram,
    detect_index_change,
    detect_vegetation_change,
    detect_urban_expansion,
    colorize_change,
)


# Property 8: Change Category Classification Exhaustiveness
# For any difference value, it SHALL be classified into exactly one
# change category.

class TestChangeCategoryExhaustiveness:
    """Feature: geospatial-agent-tools, Property 8: Change Category Classification Exhaustiveness"""
    
    @given(
        diff_value=st.floats(min_value=-2.0, max_value=2.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=200)
    def test_every_difference_maps_to_one_category(self, diff_value):
        """Every difference value must map to exactly one category."""
        diff_array = np.array([[diff_value]])
        
        category = categorize_change(diff_array)
        
        # Must be a valid category index (0-4)
        assert 0 <= category[0, 0] <= 4, \
            f"Difference {diff_value} mapped to invalid category: {category[0, 0]}"
    
    @given(
        diff_values=st.lists(
            st.floats(min_value=-2.0, max_value=2.0, allow_nan=False, allow_infinity=False),
            min_size=4,
            max_size=100
        )
    )
    @settings(max_examples=100)
    def test_category_percentages_sum_to_100(self, diff_values):
        """Category percentages must sum to 100%."""
        size = int(np.sqrt(len(diff_values)))
        if size < 2:
            return
        
        diff = np.array(diff_values[:size*size]).reshape((size, size))
        category = categorize_change(diff)
        percentages = calculate_category_percentages(category)
        
        total = sum(percentages.values())
        
        assert abs(total - 100.0) < 0.001, \
            f"Percentages sum to {total}, not 100%"
    
    def test_all_categories_covered(self):
        """All five categories should be possible."""
        # Create array with values that should hit all categories
        diff = np.array([
            [-0.5, -0.1, 0.0],   # sig_dec, slight_dec, no_change
            [0.1, 0.5, 0.02],    # slight_inc, sig_inc, no_change
        ])
        
        category = categorize_change(diff)
        unique_categories = set(category.flatten())
        
        # Should have at least 4 different categories
        assert len(unique_categories) >= 4
    
    def test_boundary_values(self):
        """Test classification at exact boundary values."""
        thresh = CHANGE_THRESHOLDS
        
        # Significant decrease boundary
        diff = np.array([[-thresh["significant"] - 0.001]])
        assert categorize_change(diff)[0, 0] == 0  # SIGNIFICANT_DECREASE
        
        diff = np.array([[-thresh["significant"]]])
        assert categorize_change(diff)[0, 0] == 1  # SLIGHT_DECREASE (boundary)
        
        # Slight decrease boundary
        diff = np.array([[-thresh["slight"] - 0.001]])
        assert categorize_change(diff)[0, 0] == 1  # SLIGHT_DECREASE
        
        diff = np.array([[-thresh["slight"]]])
        assert categorize_change(diff)[0, 0] == 2  # NO_CHANGE (boundary)
        
        # No change
        diff = np.array([[0.0]])
        assert categorize_change(diff)[0, 0] == 2  # NO_CHANGE
        
        # Slight increase boundary
        diff = np.array([[thresh["slight"]]])
        assert categorize_change(diff)[0, 0] == 2  # NO_CHANGE (boundary)
        
        diff = np.array([[thresh["slight"] + 0.001]])
        assert categorize_change(diff)[0, 0] == 3  # SLIGHT_INCREASE
        
        # Significant increase boundary
        diff = np.array([[thresh["significant"]]])
        assert categorize_change(diff)[0, 0] == 3  # SLIGHT_INCREASE (boundary)
        
        diff = np.array([[thresh["significant"] + 0.001]])
        assert categorize_change(diff)[0, 0] == 4  # SIGNIFICANT_INCREASE


# Property 14: Urban Expansion Detection Logic
# For any two urban masks (before and after), new built-up area SHALL equal
# pixels that are urban in "after" AND NOT urban in "before".

class TestUrbanExpansionDetectionLogic:
    """Feature: geospatial-agent-tools, Property 14: Urban Expansion Detection Logic"""
    
    @given(
        before_urban=st.lists(
            st.booleans(),
            min_size=25,
            max_size=100
        ),
        after_urban=st.lists(
            st.booleans(),
            min_size=25,
            max_size=100
        )
    )
    @settings(max_examples=100)
    def test_new_urban_equals_after_and_not_before(self, before_urban, after_urban):
        """New urban = urban in after AND NOT urban in before."""
        size = min(int(np.sqrt(len(before_urban))), int(np.sqrt(len(after_urban))))
        if size < 2:
            return
        
        # Create NDBI arrays that will produce the desired urban masks
        # NDBI > 0 = urban, so use positive values for urban, negative for non-urban
        nir = np.ones((size, size)) * 100
        
        swir_before = np.array(before_urban[:size*size]).reshape((size, size)).astype(float)
        swir_before = np.where(swir_before, 200, 50)  # Urban: SWIR > NIR, Non-urban: SWIR < NIR
        
        swir_after = np.array(after_urban[:size*size]).reshape((size, size)).astype(float)
        swir_after = np.where(swir_after, 200, 50)
        
        result = detect_urban_expansion(nir, swir_before, nir, swir_after)
        
        # Calculate expected new urban
        urban_before = np.array(before_urban[:size*size]).reshape((size, size))
        urban_after = np.array(after_urban[:size*size]).reshape((size, size))
        expected_new_urban = urban_after & ~urban_before
        
        np.testing.assert_array_equal(result.new_urban_mask, expected_new_urban)
    
    def test_no_expansion_when_identical(self):
        """Identical scenes should show no expansion."""
        nir = np.ones((10, 10)) * 100
        swir = np.ones((10, 10)) * 150  # All urban
        
        result = detect_urban_expansion(nir, swir, nir, swir)
        
        assert result.new_urban_percent == 0.0
        assert not np.any(result.new_urban_mask)
    
    def test_full_expansion(self):
        """Non-urban to all urban should show 100% expansion."""
        nir = np.ones((10, 10)) * 100
        swir_before = np.ones((10, 10)) * 50   # All non-urban (NDBI < 0)
        swir_after = np.ones((10, 10)) * 150   # All urban (NDBI > 0)
        
        result = detect_urban_expansion(nir, swir_before, nir, swir_after)
        
        assert result.new_urban_percent == 100.0
        assert np.all(result.new_urban_mask)
    
    def test_partial_expansion(self):
        """Partial expansion should be correctly calculated."""
        nir = np.ones((10, 10)) * 100
        
        # Before: top half urban
        swir_before = np.ones((10, 10)) * 50
        swir_before[:5, :] = 150  # Top half urban
        
        # After: all urban
        swir_after = np.ones((10, 10)) * 150
        
        result = detect_urban_expansion(nir, swir_before, nir, swir_after)
        
        # Bottom half should be new urban (50%)
        assert abs(result.new_urban_percent - 50.0) < 1.0
        assert np.all(result.new_urban_mask[5:, :])  # Bottom half is new
        assert not np.any(result.new_urban_mask[:5, :])  # Top half is not new


# Unit tests

class TestCategorizeChange:
    """Unit tests for change categorization."""
    
    def test_significant_decrease(self):
        """Large negative values should be significant decrease."""
        diff = np.array([[-0.5, -0.3, -0.25]])
        category = categorize_change(diff)
        
        assert np.all(category == 0)  # SIGNIFICANT_DECREASE
    
    def test_significant_increase(self):
        """Large positive values should be significant increase."""
        diff = np.array([[0.5, 0.3, 0.25]])
        category = categorize_change(diff)
        
        assert np.all(category == 4)  # SIGNIFICANT_INCREASE
    
    def test_no_change(self):
        """Small values should be no change."""
        diff = np.array([[-0.04, 0.0, 0.04]])
        category = categorize_change(diff)
        
        assert np.all(category == 2)  # NO_CHANGE
    
    def test_nan_treated_as_no_change(self):
        """NaN values should be treated as no change."""
        diff = np.array([[np.nan, 0.0, np.nan]])
        category = categorize_change(diff)
        
        assert np.all(category == 2)  # NO_CHANGE


class TestDetectIndexChange:
    """Unit tests for index change detection."""
    
    def test_no_change(self):
        """Identical arrays should show no change."""
        index = np.random.uniform(-1, 1, size=(10, 10))
        
        result = detect_index_change(index, index, index_name="test")
        
        assert result.mean_change == 0.0
        assert result.total_changed_percent == 0.0
    
    def test_positive_change(self):
        """Increased values should show positive change."""
        before = np.zeros((10, 10))
        after = np.full((10, 10), 0.5)
        
        result = detect_index_change(before, after, index_name="test")
        
        assert result.mean_change == 0.5
        assert result.total_changed_percent == 100.0
    
    def test_result_structure(self):
        """Result should have all required fields."""
        before = np.random.uniform(-1, 1, size=(10, 10))
        after = np.random.uniform(-1, 1, size=(10, 10))
        
        result = detect_index_change(
            before, after,
            index_name="NDVI",
            before_date="2024-01-01",
            after_date="2024-06-01"
        )
        
        assert isinstance(result, ChangeDetectionResult)
        assert result.difference.shape == (10, 10)
        assert result.change_category.shape == (10, 10)
        assert len(result.category_percentages) == 5
        assert result.index_name == "NDVI"
        assert result.before_date == "2024-01-01"
        assert result.after_date == "2024-06-01"


class TestDetectVegetationChange:
    """Unit tests for vegetation change detection."""
    
    def test_vegetation_gain(self):
        """Increased NIR should show vegetation gain."""
        nir_before = np.full((10, 10), 300.0)
        red = np.full((10, 10), 200.0)
        nir_after = np.full((10, 10), 600.0)
        
        result = detect_vegetation_change(nir_before, red, nir_after, red)
        
        assert result.mean_change > 0
        assert result.index_name == "NDVI"
    
    def test_vegetation_loss(self):
        """Decreased NIR should show vegetation loss."""
        nir_before = np.full((10, 10), 600.0)
        red = np.full((10, 10), 200.0)
        nir_after = np.full((10, 10), 300.0)
        
        result = detect_vegetation_change(nir_before, red, nir_after, red)
        
        assert result.mean_change < 0


class TestUrbanExpansionResult:
    """Unit tests for urban expansion result."""
    
    def test_to_dict(self):
        """Result should serialize to dict."""
        result = UrbanExpansionResult(
            new_urban_mask=np.zeros((5, 5), dtype=bool),
            new_urban_percent=10.0,
            new_urban_area_sq_meters=9000.0,
            urban_before_percent=20.0,
            urban_after_percent=30.0,
            expansion_direction="north"
        )
        
        d = result.to_dict()
        
        assert d["new_urban_percent"] == 10.0
        assert d["expansion_direction"] == "north"
        assert "shape" in d


class TestColorizeChange:
    """Unit tests for change colorization."""
    
    def test_colorize_shape(self):
        """Output should be RGB with correct shape."""
        category = np.array([[0, 1, 2], [3, 4, 2]])
        
        rgb = colorize_change(category)
        
        assert rgb.shape == (2, 3, 3)
        assert rgb.dtype == np.uint8
    
    def test_no_change_white(self):
        """No change should be white."""
        category = np.array([[2]])
        
        rgb = colorize_change(category)
        
        # White is (255, 255, 255)
        assert rgb[0, 0, 0] == 255
        assert rgb[0, 0, 1] == 255
        assert rgb[0, 0, 2] == 255
    
    def test_significant_decrease_red(self):
        """Significant decrease should be red-ish."""
        category = np.array([[0]])
        
        rgb = colorize_change(category)
        
        # Dark red (139, 0, 0)
        assert rgb[0, 0, 0] > rgb[0, 0, 1]  # Red > Green
        assert rgb[0, 0, 0] > rgb[0, 0, 2]  # Red > Blue
