"""Tests for image compositing.

Property-based tests validate:
- Property 15: Composite Method Correctness
"""

import numpy as np
import pytest
from hypothesis import given, strategies as st, settings

from satellite_tiler.compositing import (
    CompositingMethod,
    CompositeResult,
    create_cloud_mask,
    apply_cloud_mask,
    composite_median,
    composite_mean,
    composite_max,
    composite_min,
    create_composite,
    create_multiband_composite,
    get_source_scene_map,
)


# Property 15: Composite Method Correctness
# For any set of input arrays, the composite SHALL correctly apply
# the specified method (median, mean, max, min).

class TestCompositeMethodCorrectness:
    """Feature: geospatial-agent-tools, Property 15: Composite Method Correctness"""
    
    @given(
        num_arrays=st.integers(min_value=2, max_value=5),
        size=st.integers(min_value=3, max_value=10),
    )
    @settings(max_examples=100)
    def test_median_composite_correctness(self, num_arrays, size):
        """Median composite should equal numpy median."""
        arrays = [np.random.uniform(0, 1000, size=(size, size)) for _ in range(num_arrays)]
        
        result = create_composite(arrays, method="median")
        expected = np.median(np.stack(arrays, axis=0), axis=0)
        
        np.testing.assert_array_almost_equal(result.data, expected)
    
    @given(
        num_arrays=st.integers(min_value=2, max_value=5),
        size=st.integers(min_value=3, max_value=10),
    )
    @settings(max_examples=100)
    def test_mean_composite_correctness(self, num_arrays, size):
        """Mean composite should equal numpy mean."""
        arrays = [np.random.uniform(0, 1000, size=(size, size)) for _ in range(num_arrays)]
        
        result = create_composite(arrays, method="mean")
        expected = np.mean(np.stack(arrays, axis=0), axis=0)
        
        np.testing.assert_array_almost_equal(result.data, expected)
    
    @given(
        num_arrays=st.integers(min_value=2, max_value=5),
        size=st.integers(min_value=3, max_value=10),
    )
    @settings(max_examples=100)
    def test_max_composite_correctness(self, num_arrays, size):
        """Max composite should equal numpy max."""
        arrays = [np.random.uniform(0, 1000, size=(size, size)) for _ in range(num_arrays)]
        
        result = create_composite(arrays, method="max")
        expected = np.max(np.stack(arrays, axis=0), axis=0)
        
        np.testing.assert_array_almost_equal(result.data, expected)
    
    @given(
        num_arrays=st.integers(min_value=2, max_value=5),
        size=st.integers(min_value=3, max_value=10),
    )
    @settings(max_examples=100)
    def test_min_composite_correctness(self, num_arrays, size):
        """Min composite should equal numpy min."""
        arrays = [np.random.uniform(0, 1000, size=(size, size)) for _ in range(num_arrays)]
        
        result = create_composite(arrays, method="min")
        expected = np.min(np.stack(arrays, axis=0), axis=0)
        
        np.testing.assert_array_almost_equal(result.data, expected)


# Unit tests

class TestCloudMask:
    """Unit tests for cloud masking."""
    
    def test_create_cloud_mask_basic(self):
        """Should create mask from QA band bits."""
        # Bit 3 set = cloud
        qa_band = np.array([[0, 8, 0], [8, 0, 8], [0, 0, 0]], dtype=np.uint16)
        
        mask = create_cloud_mask(qa_band, cloud_bits=[3])
        
        expected = np.array([[False, True, False], [True, False, True], [False, False, False]])
        np.testing.assert_array_equal(mask, expected)
    
    def test_apply_cloud_mask(self):
        """Should set cloudy pixels to NaN."""
        data = np.array([[1.0, 2.0], [3.0, 4.0]])
        cloud_mask = np.array([[False, True], [False, False]])
        
        masked = apply_cloud_mask(data, cloud_mask)
        
        assert masked[0, 0] == 1.0
        assert np.isnan(masked[0, 1])
        assert masked[1, 0] == 3.0
        assert masked[1, 1] == 4.0


class TestCompositeMedian:
    """Unit tests for median compositing."""
    
    def test_median_of_three(self):
        """Median of three arrays should be middle value."""
        arr1 = np.array([[1, 2], [3, 4]], dtype=np.float64)
        arr2 = np.array([[5, 6], [7, 8]], dtype=np.float64)
        arr3 = np.array([[3, 4], [5, 6]], dtype=np.float64)
        
        result = composite_median([arr1, arr2, arr3])
        
        expected = np.array([[3, 4], [5, 6]])
        np.testing.assert_array_equal(result, expected)
    
    def test_median_with_nan(self):
        """Median should ignore NaN values."""
        arr1 = np.array([[1, np.nan], [3, 4]], dtype=np.float64)
        arr2 = np.array([[5, 6], [7, 8]], dtype=np.float64)
        
        result = composite_median([arr1, arr2])
        
        assert result[0, 0] == 3.0  # median of 1, 5
        assert result[0, 1] == 6.0  # only 6 is valid


class TestCompositeMax:
    """Unit tests for max compositing."""
    
    def test_max_returns_attribution(self):
        """Max should return source attribution."""
        arr1 = np.array([[1, 5], [3, 4]], dtype=np.float64)
        arr2 = np.array([[5, 2], [7, 1]], dtype=np.float64)
        
        max_val, source_idx = composite_max([arr1, arr2])
        
        expected_max = np.array([[5, 5], [7, 4]])
        expected_idx = np.array([[1, 0], [1, 0]])
        
        np.testing.assert_array_equal(max_val, expected_max)
        np.testing.assert_array_equal(source_idx, expected_idx)


class TestCreateComposite:
    """Unit tests for create_composite function."""
    
    def test_result_structure(self):
        """Result should have all required fields."""
        arrays = [np.random.rand(10, 10) for _ in range(3)]
        
        result = create_composite(arrays, method="median")
        
        assert isinstance(result, CompositeResult)
        assert result.data.shape == (10, 10)
        assert result.method == "median"
        assert result.source_count == 3
    
    def test_with_cloud_masks(self):
        """Should apply cloud masks correctly."""
        arr1 = np.ones((5, 5)) * 10
        arr2 = np.ones((5, 5)) * 20
        
        # Mask half of arr1
        cloud_mask1 = np.zeros((5, 5), dtype=bool)
        cloud_mask1[:, :3] = True
        cloud_mask2 = np.zeros((5, 5), dtype=bool)
        
        result = create_composite([arr1, arr2], method="mean", cloud_masks=[cloud_mask1, cloud_mask2])
        
        # Where arr1 is masked, result should be arr2 value
        assert result.data[0, 0] == 20.0  # Only arr2 valid
        assert result.data[0, 4] == 15.0  # Mean of 10 and 20
    
    def test_invalid_method_raises(self):
        """Should raise error for invalid method."""
        arrays = [np.random.rand(5, 5)]
        
        with pytest.raises(ValueError, match="Invalid method"):
            create_composite(arrays, method="invalid")
    
    def test_empty_arrays_raises(self):
        """Should raise error for empty array list."""
        with pytest.raises(ValueError, match="At least one array"):
            create_composite([], method="median")


class TestMultibandComposite:
    """Unit tests for multiband compositing."""
    
    def test_multiband_composite(self):
        """Should composite each band separately."""
        band_arrays = {
            "red": [np.ones((5, 5)) * 100, np.ones((5, 5)) * 200],
            "green": [np.ones((5, 5)) * 50, np.ones((5, 5)) * 150],
        }
        
        results = create_multiband_composite(band_arrays, method="mean")
        
        assert "red" in results
        assert "green" in results
        assert results["red"].data[0, 0] == 150.0
        assert results["green"].data[0, 0] == 100.0


class TestSourceSceneMap:
    """Unit tests for source scene mapping."""
    
    def test_get_source_scene_map(self):
        """Should count pixels from each source."""
        source_attribution = np.array([[0, 0, 1], [1, 1, 0], [0, 1, 1]])
        scene_ids = ["scene_a", "scene_b"]
        
        counts = get_source_scene_map(source_attribution, scene_ids)
        
        assert counts["scene_a"] == 4
        assert counts["scene_b"] == 5
