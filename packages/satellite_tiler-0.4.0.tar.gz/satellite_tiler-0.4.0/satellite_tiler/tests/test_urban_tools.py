"""Tests for urban analysis agent tools.

Property-based tests validate:
- Property 9: Tool Response JSON Serialization
- Property 10: Error Response Structure
"""

import json
import numpy as np
import pytest
from hypothesis import given, strategies as st, settings
from unittest.mock import patch, MagicMock

from satellite_tiler.urban_tools import (
    _error_response,
    _encode_array_as_image,
    analyze_urban_heat,
    analyze_vegetation_health,
    calculate_spectral_index,
    classify_land_use,
    detect_changes,
    get_heat_recommendations,
    GEOSPATIAL_ANALYSIS_TOOLS,
)


# Property 9: Tool Response JSON Serialization
# For any tool result dictionary, calling json.dumps() SHALL succeed without
# error, and the result SHALL contain a "message" field with a non-empty string.

class TestToolResponseJSONSerialization:
    """Feature: geospatial-agent-tools, Property 9: Tool Response JSON Serialization"""
    
    def test_error_response_serializable(self):
        """Error responses must be JSON serializable."""
        response = _error_response("Test error message", extra_field="value")
        
        # Should not raise
        json_str = json.dumps(response)
        
        # Should have message field
        assert "message" in response
        assert len(response["message"]) > 0
    
    def test_error_response_has_error_flag(self):
        """Error responses must have error=True."""
        response = _error_response("Test error")
        
        assert response["error"] == True
    
    @given(
        message=st.text(min_size=1, max_size=100),
        extra_key=st.text(min_size=1, max_size=20, alphabet=st.characters(whitelist_categories=("Ll",))),
        extra_value=st.one_of(st.text(), st.integers(), st.floats(allow_nan=False, allow_infinity=False))
    )
    @settings(max_examples=50)
    def test_error_response_always_serializable(self, message, extra_key, extra_value):
        """Error responses with any content must be serializable."""
        response = _error_response(message, **{extra_key: extra_value})
        
        # Should not raise
        json_str = json.dumps(response)
        
        # Should round-trip
        parsed = json.loads(json_str)
        assert parsed["message"] == message
        assert parsed["error"] == True


# Property 10: Error Response Structure
# For any error condition, the tool response SHALL contain "error": True
# and a "message" field describing the error.

class TestErrorResponseStructure:
    """Feature: geospatial-agent-tools, Property 10: Error Response Structure"""
    
    def test_uncached_scene_error_structure(self):
        """Uncached scene should return proper error structure."""
        result = analyze_urban_heat("FAKE_SCENE_ID", lat=-27.47, lon=153.02)
        
        assert result.get("error") == True
        assert "message" in result
        assert len(result["message"]) > 0
    
    def test_invalid_platform_error_structure(self):
        """Invalid platform should return proper error structure."""
        # Mock detect_platform to return a valid platform but no thermal bands
        with patch('satellite_tiler.urban_tools.detect_platform') as mock_detect:
            from satellite_tiler.models import SatellitePlatform
            mock_detect.return_value = SatellitePlatform.SENTINEL2
            
            with patch('satellite_tiler.urban_tools.get_cached_asset_urls') as mock_cache:
                mock_cache.return_value = {"some": "urls"}
                
                result = analyze_urban_heat("S2B_FAKE", lat=-27.47, lon=153.02)
        
        assert result.get("error") == True
        assert "message" in result
        assert "thermal" in result["message"].lower()
    
    def test_invalid_index_error_structure(self):
        """Invalid index name should return proper error structure."""
        with patch('satellite_tiler.urban_tools.get_cached_asset_urls') as mock_cache:
            mock_cache.return_value = {"some": "urls"}
            
            result = calculate_spectral_index(
                "FAKE_SCENE", lat=-27.47, lon=153.02, index="INVALID_INDEX"
            )
        
        assert result.get("error") == True
        assert "message" in result
    
    def test_invalid_change_type_error_structure(self):
        """Invalid change type should return proper error structure."""
        with patch('satellite_tiler.urban_tools.get_cached_asset_urls') as mock_cache:
            mock_cache.return_value = {"some": "urls"}
            
            with patch('satellite_tiler.urban_tools.detect_platform') as mock_detect:
                from satellite_tiler.models import SatellitePlatform
                mock_detect.return_value = SatellitePlatform.SENTINEL2
                
                result = detect_changes(
                    "SCENE1", "SCENE2",
                    lat=-27.47, lon=153.02,
                    change_type="invalid_type"
                )
        
        assert result.get("error") == True
        assert "message" in result


# Unit tests

class TestEncodeArrayAsImage:
    """Unit tests for array to image encoding."""
    
    def test_encode_2d_array(self):
        """2D array should encode to base64 string."""
        data = np.random.randint(0, 256, size=(10, 10), dtype=np.uint8)
        
        result = _encode_array_as_image(data)
        
        assert isinstance(result, str)
        assert len(result) > 0
    
    def test_encode_3d_array(self):
        """3D RGB array should encode to base64 string."""
        data = np.random.randint(0, 256, size=(10, 10, 3), dtype=np.uint8)
        
        result = _encode_array_as_image(data)
        
        assert isinstance(result, str)
        assert len(result) > 0
    
    def test_encode_float_array(self):
        """Float array should be normalized and encoded."""
        data = np.random.uniform(0, 1, size=(10, 10))
        
        result = _encode_array_as_image(data)
        
        assert isinstance(result, str)


class TestAnalyzeUrbanHeat:
    """Unit tests for urban heat analysis tool."""
    
    def test_uncached_scene_returns_error(self):
        """Uncached scene should return error."""
        result = analyze_urban_heat("UNCACHED_SCENE", lat=-27.47, lon=153.02)
        
        assert result.get("error") == True
        assert "cached" in result["message"].lower() or "scene" in result["message"].lower()
    
    def test_sentinel2_returns_thermal_error(self):
        """Sentinel-2 scene should return thermal bands error."""
        with patch('satellite_tiler.urban_tools.detect_platform') as mock_detect:
            from satellite_tiler.models import SatellitePlatform
            mock_detect.return_value = SatellitePlatform.SENTINEL2
            
            with patch('satellite_tiler.urban_tools.get_cached_asset_urls') as mock_cache:
                mock_cache.return_value = {"some": "urls"}
                
                result = analyze_urban_heat("S2B_FAKE", lat=-27.47, lon=153.02)
        
        assert result.get("error") == True
        assert "thermal" in result["message"].lower()


class TestAnalyzeVegetationHealth:
    """Unit tests for vegetation health analysis tool."""
    
    def test_uncached_scene_returns_error(self):
        """Uncached scene should return error."""
        result = analyze_vegetation_health("UNCACHED_SCENE", lat=-27.47, lon=153.02)
        
        assert result.get("error") == True


class TestCalculateSpectralIndex:
    """Unit tests for spectral index calculation tool."""
    
    def test_invalid_index_returns_error(self):
        """Invalid index name should return error."""
        with patch('satellite_tiler.urban_tools.get_cached_asset_urls') as mock_cache:
            mock_cache.return_value = {"some": "urls"}
            
            result = calculate_spectral_index(
                "FAKE_SCENE", lat=-27.47, lon=153.02, index="NOT_AN_INDEX"
            )
        
        assert result.get("error") == True
        assert "unknown index" in result["message"].lower()
    
    def test_valid_index_names(self):
        """Valid index names should be accepted."""
        valid_indices = ["ndvi", "NDVI", "ndbi", "ndwi", "mndwi", "evi", "savi"]
        
        for index in valid_indices:
            # Just check it doesn't fail on index validation
            with patch('satellite_tiler.urban_tools.get_cached_asset_urls') as mock_cache:
                mock_cache.return_value = None  # Will fail on cache check, not index
                
                result = calculate_spectral_index(
                    "FAKE_SCENE", lat=-27.47, lon=153.02, index=index
                )
            
            # Should fail on cache, not index validation
            if result.get("error"):
                assert "unknown index" not in result["message"].lower()


class TestClassifyLandUse:
    """Unit tests for land use classification tool."""
    
    def test_uncached_scene_returns_error(self):
        """Uncached scene should return error."""
        result = classify_land_use("UNCACHED_SCENE", lat=-27.47, lon=153.02)
        
        assert result.get("error") == True


class TestDetectChanges:
    """Unit tests for change detection tool."""
    
    def test_uncached_before_scene_returns_error(self):
        """Uncached before scene should return error."""
        result = detect_changes(
            "UNCACHED_BEFORE", "UNCACHED_AFTER",
            lat=-27.47, lon=153.02
        )
        
        assert result.get("error") == True
        assert "before" in result["message"].lower() or "cached" in result["message"].lower()
    
    def test_invalid_change_type_returns_error(self):
        """Invalid change type should return error."""
        with patch('satellite_tiler.urban_tools.get_cached_asset_urls') as mock_cache:
            mock_cache.return_value = {"some": "urls"}
            
            with patch('satellite_tiler.urban_tools.detect_platform') as mock_detect:
                from satellite_tiler.models import SatellitePlatform
                mock_detect.return_value = SatellitePlatform.SENTINEL2
                
                result = detect_changes(
                    "SCENE1", "SCENE2",
                    lat=-27.47, lon=153.02,
                    change_type="invalid"
                )
        
        assert result.get("error") == True
        assert "unknown change type" in result["message"].lower()


class TestGeospatialToolsList:
    """Unit tests for tools list."""
    
    def test_all_tools_are_callable(self):
        """All tools in the list should be callable."""
        for tool in GEOSPATIAL_ANALYSIS_TOOLS:
            assert callable(tool)
    
    def test_all_tools_have_docstrings(self):
        """All tools should have docstrings."""
        for tool in GEOSPATIAL_ANALYSIS_TOOLS:
            assert tool.__doc__ is not None
            assert len(tool.__doc__) > 50  # Meaningful docstring
    
    def test_expected_tools_present(self):
        """Expected tools should be in the list."""
        tool_names = [t.__name__ for t in GEOSPATIAL_ANALYSIS_TOOLS]
        
        assert "analyze_urban_heat" in tool_names
        assert "analyze_vegetation_health" in tool_names
        assert "calculate_spectral_index" in tool_names
        assert "classify_land_use" in tool_names
        assert "detect_changes" in tool_names
