"""Tests for scene ID parsers."""

import pytest
from hypothesis import given, settings, assume
from hypothesis import strategies as st
from datetime import date

from satellite_tiler.models import (
    SatellitePlatform,
    LandsatSceneComponents,
    Sentinel2SceneComponents,
    CBERSSceneComponents,
)
from satellite_tiler.parsers import (
    detect_platform,
    parse,
    format_scene_id,
    parse_landsat,
    format_landsat,
    parse_sentinel2,
    format_sentinel2,
    parse_cbers,
    format_cbers,
)
from satellite_tiler.exceptions import InvalidSceneIdError


# Hypothesis strategies for generating valid scene components

@st.composite
def landsat_components_strategy(draw):
    """Generate valid Landsat scene components."""
    sensors = ["LC08", "LC09", "LE07", "LT05", "LT04"]
    processing_levels = ["L1TP", "L1GT", "L1GS", "L2SP", "L2SR"]
    tiers = ["T1", "T2", "RT"]
    
    acq_date = draw(st.dates(min_value=date(1984, 1, 1), max_value=date(2025, 12, 31)))
    proc_date = draw(st.dates(min_value=acq_date, max_value=date(2026, 12, 31)))
    
    return LandsatSceneComponents(
        sensor=draw(st.sampled_from(sensors)),
        processing_level=draw(st.sampled_from(processing_levels)),
        path=draw(st.integers(min_value=1, max_value=233)),
        row=draw(st.integers(min_value=1, max_value=248)),
        acquisition_date=acq_date,
        processing_date=proc_date,
        collection=draw(st.integers(min_value=1, max_value=2)),
        tier=draw(st.sampled_from(tiers)),
    )


@st.composite
def sentinel2_components_strategy(draw):
    """Generate valid Sentinel-2 scene components."""
    satellites = ["S2A", "S2B"]
    product_levels = ["MSIL1C", "MSIL2A"]
    
    # Generate valid datetime strings
    acq_date = draw(st.dates(min_value=date(2015, 6, 23), max_value=date(2025, 12, 31)))
    hour = draw(st.integers(min_value=0, max_value=23))
    minute = draw(st.integers(min_value=0, max_value=59))
    second = draw(st.integers(min_value=0, max_value=59))
    acq_datetime = f"{acq_date.strftime('%Y%m%d')}T{hour:02d}{minute:02d}{second:02d}"
    
    proc_date = draw(st.dates(min_value=acq_date, max_value=date(2026, 12, 31)))
    proc_hour = draw(st.integers(min_value=0, max_value=23))
    proc_minute = draw(st.integers(min_value=0, max_value=59))
    proc_second = draw(st.integers(min_value=0, max_value=59))
    proc_datetime = f"{proc_date.strftime('%Y%m%d')}T{proc_hour:02d}{proc_minute:02d}{proc_second:02d}"
    
    # Generate valid tile ID (UTM zone + latitude band + grid square)
    utm_zone = draw(st.integers(min_value=1, max_value=60))
    lat_bands = "CDEFGHJKLMNPQRSTUVWX"
    lat_band = draw(st.sampled_from(list(lat_bands)))
    grid_letters = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    grid_square = draw(st.text(alphabet=grid_letters, min_size=2, max_size=2))
    tile_id = f"T{utm_zone:02d}{lat_band}{grid_square}"
    
    return Sentinel2SceneComponents(
        satellite=draw(st.sampled_from(satellites)),
        product_level=draw(st.sampled_from(product_levels)),
        acquisition_datetime=acq_datetime,
        processing_baseline=f"N{draw(st.integers(min_value=100, max_value=999)):04d}",
        relative_orbit=f"R{draw(st.integers(min_value=1, max_value=143)):03d}",
        tile_id=tile_id,
        product_discriminator=proc_datetime,
    )


@st.composite
def cbers_components_strategy(draw):
    """Generate valid CBERS scene components."""
    satellites = ["CBERS_4", "CBERS_5"]
    cameras = ["MUX", "AWFI", "PAN5M", "PAN10M", "WFI"]
    processing_levels = ["L2", "L4"]
    
    return CBERSSceneComponents(
        satellite=draw(st.sampled_from(satellites)),
        camera=draw(st.sampled_from(cameras)),
        acquisition_date=draw(st.dates(min_value=date(2014, 12, 7), max_value=date(2025, 12, 31))),
        path=draw(st.integers(min_value=1, max_value=999)),
        row=draw(st.integers(min_value=1, max_value=999)),
        processing_level=draw(st.sampled_from(processing_levels)),
    )


class TestSceneIdParsingRoundTrip:
    """Property 11: Scene ID Parsing Round-Trip
    
    For any valid scene identifier string, parsing to components and formatting
    back to string SHALL produce an equivalent scene identifier.
    
    Validates: Requirements 5.1, 5.2, 5.3, 5.5
    """

    @given(components=landsat_components_strategy())
    @settings(max_examples=100)
    def test_landsat_round_trip(self, components: LandsatSceneComponents):
        """Feature: satellite-tiler, Property 11: Landsat scene ID round-trip."""
        # Format to string
        scene_id = format_landsat(components)
        
        # Parse back
        parsed = parse_landsat(scene_id)
        
        # Format again
        scene_id_2 = format_landsat(parsed)
        
        # Should be identical
        assert scene_id == scene_id_2
        
        # Components should match
        assert parsed.sensor == components.sensor
        assert parsed.processing_level == components.processing_level
        assert parsed.path == components.path
        assert parsed.row == components.row
        assert parsed.acquisition_date == components.acquisition_date
        assert parsed.processing_date == components.processing_date
        assert parsed.collection == components.collection
        assert parsed.tier == components.tier

    @given(components=sentinel2_components_strategy())
    @settings(max_examples=100)
    def test_sentinel2_round_trip(self, components: Sentinel2SceneComponents):
        """Feature: satellite-tiler, Property 11: Sentinel-2 scene ID round-trip."""
        # Format to string
        scene_id = format_sentinel2(components)
        
        # Parse back
        parsed = parse_sentinel2(scene_id)
        
        # Format again
        scene_id_2 = format_sentinel2(parsed)
        
        # Should be identical
        assert scene_id == scene_id_2
        
        # Components should match
        assert parsed.satellite == components.satellite
        assert parsed.product_level == components.product_level
        assert parsed.acquisition_datetime == components.acquisition_datetime
        assert parsed.tile_id == components.tile_id

    @given(components=cbers_components_strategy())
    @settings(max_examples=100)
    def test_cbers_round_trip(self, components: CBERSSceneComponents):
        """Feature: satellite-tiler, Property 11: CBERS scene ID round-trip."""
        # Format to string
        scene_id = format_cbers(components)
        
        # Parse back
        parsed = parse_cbers(scene_id)
        
        # Format again
        scene_id_2 = format_cbers(parsed)
        
        # Should be identical
        assert scene_id == scene_id_2
        
        # Components should match
        assert parsed.satellite == components.satellite
        assert parsed.camera == components.camera
        assert parsed.acquisition_date == components.acquisition_date
        assert parsed.path == components.path
        assert parsed.row == components.row


class TestInvalidSceneIdError:
    """Property 12: Invalid Scene ID Error
    
    For any malformed scene identifier string, the parser SHALL raise
    an InvalidSceneIdError with the expected format description.
    
    Validates: Requirements 5.4
    """

    @given(invalid_id=st.text(min_size=1, max_size=50))
    @settings(max_examples=100)
    def test_invalid_scene_id_raises_error(self, invalid_id: str):
        """Feature: satellite-tiler, Property 12: Invalid scene ID raises error."""
        # Skip if it accidentally matches a valid pattern
        try:
            detect_platform(invalid_id)
            assume(False)  # Skip this case
        except InvalidSceneIdError:
            pass  # Expected
        
        # Should raise InvalidSceneIdError
        with pytest.raises(InvalidSceneIdError) as exc_info:
            parse(invalid_id)
        
        # Error should contain the invalid ID
        assert invalid_id in str(exc_info.value)

    def test_empty_string_raises_error(self):
        """Empty string should raise InvalidSceneIdError."""
        with pytest.raises(InvalidSceneIdError):
            parse("")

    def test_partial_landsat_id_raises_error(self):
        """Partial Landsat ID should raise InvalidSceneIdError."""
        with pytest.raises(InvalidSceneIdError) as exc_info:
            parse("LC08_L1TP_014032")
        assert "Landsat" in str(exc_info.value) or "format" in str(exc_info.value).lower()

    def test_partial_sentinel2_id_raises_error(self):
        """Partial Sentinel-2 ID should raise InvalidSceneIdError."""
        with pytest.raises(InvalidSceneIdError):
            parse("S2A_MSIL2A_20240615")


class TestPlatformDetection:
    """Unit tests for platform detection."""

    def test_detect_landsat(self):
        """Test Landsat platform detection."""
        scene_id = "LC08_L1TP_014032_20240615_20240620_02_T1"
        assert detect_platform(scene_id) == SatellitePlatform.LANDSAT8

    def test_detect_sentinel2(self):
        """Test Sentinel-2 platform detection."""
        scene_id = "S2A_MSIL2A_20240615T154911_N0510_R054_T18TXM_20240615T213159"
        assert detect_platform(scene_id) == SatellitePlatform.SENTINEL2

    def test_detect_cbers(self):
        """Test CBERS platform detection."""
        scene_id = "CBERS_4_MUX_20240615_178_106_L4"
        assert detect_platform(scene_id) == SatellitePlatform.CBERS


class TestLandsatParser:
    """Unit tests for Landsat parser."""

    def test_parse_valid_landsat_id(self):
        """Test parsing a valid Landsat scene ID."""
        scene_id = "LC08_L1TP_014032_20240615_20240620_02_T1"
        components = parse_landsat(scene_id)
        
        assert components.sensor == "LC08"
        assert components.processing_level == "L1TP"
        assert components.path == 14
        assert components.row == 32
        assert components.acquisition_date == date(2024, 6, 15)
        assert components.processing_date == date(2024, 6, 20)
        assert components.collection == 2
        assert components.tier == "T1"

    def test_format_landsat_components(self):
        """Test formatting Landsat components back to scene ID."""
        components = LandsatSceneComponents(
            sensor="LC08",
            processing_level="L1TP",
            path=14,
            row=32,
            acquisition_date=date(2024, 6, 15),
            processing_date=date(2024, 6, 20),
            collection=2,
            tier="T1",
        )
        scene_id = format_landsat(components)
        assert scene_id == "LC08_L1TP_014032_20240615_20240620_02_T1"


class TestSentinel2Parser:
    """Unit tests for Sentinel-2 parser."""

    def test_parse_valid_sentinel2_id(self):
        """Test parsing a valid Sentinel-2 scene ID."""
        scene_id = "S2A_MSIL2A_20240615T154911_N0510_R054_T18TXM_20240615T213159"
        components = parse_sentinel2(scene_id)
        
        assert components.satellite == "S2A"
        assert components.product_level == "MSIL2A"
        assert components.acquisition_datetime == "20240615T154911"
        assert components.tile_id == "T18TXM"
        assert components.acquisition_date == date(2024, 6, 15)


class TestCBERSParser:
    """Unit tests for CBERS parser."""

    def test_parse_valid_cbers_id(self):
        """Test parsing a valid CBERS scene ID."""
        scene_id = "CBERS_4_MUX_20240615_178_106_L4"
        components = parse_cbers(scene_id)
        
        assert components.satellite == "CBERS_4"
        assert components.camera == "MUX"
        assert components.acquisition_date == date(2024, 6, 15)
        assert components.path == 178
        assert components.row == 106
        assert components.processing_level == "L4"
