"""Shared fixtures and Hypothesis strategies for satellite-tiler tests."""

import pytest
from hypothesis import strategies as st
from datetime import date
import numpy as np

from satellite_tiler.models import (
    SatellitePlatform,
    BandInfo,
    MissionInfo,
    SceneInfo,
)


# Hypothesis strategies for generating test data

@st.composite
def band_info_strategy(draw):
    """Generate valid BandInfo objects."""
    band_names = ["B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B02", "B03", "B04", "B08", "B8A"]
    descriptions = ["Coastal Aerosol", "Blue", "Green", "Red", "NIR", "SWIR 1", "SWIR 2", "Pan"]
    
    return BandInfo(
        name=draw(st.sampled_from(band_names)),
        description=draw(st.sampled_from(descriptions)),
        wavelength=draw(st.from_regex(r"[0-9]\.[0-9]{2}-[0-9]\.[0-9]{2}μm", fullmatch=True)),
        resolution=draw(st.integers(min_value=10, max_value=100))
    )


@st.composite
def valid_bounds_strategy(draw):
    """Generate valid geographic bounds (west, south, east, north)."""
    west = draw(st.floats(min_value=-180, max_value=179, allow_nan=False, allow_infinity=False))
    east = draw(st.floats(min_value=west + 0.01, max_value=180, allow_nan=False, allow_infinity=False))
    south = draw(st.floats(min_value=-90, max_value=89, allow_nan=False, allow_infinity=False))
    north = draw(st.floats(min_value=south + 0.01, max_value=90, allow_nan=False, allow_infinity=False))
    return (west, south, east, north)


@st.composite
def mission_info_strategy(draw):
    """Generate valid MissionInfo objects."""
    bands = draw(st.lists(band_info_strategy(), min_size=1, max_size=12))
    start_date = draw(st.dates(min_value=date(2013, 1, 1), max_value=date(2025, 1, 1)))
    end_date = draw(st.dates(min_value=start_date, max_value=date(2026, 1, 1)))
    
    return MissionInfo(
        platform=draw(st.sampled_from(list(SatellitePlatform))),
        bands=bands,
        date_range=(start_date.isoformat(), end_date.isoformat()),
        resolution=draw(st.integers(min_value=10, max_value=100))
    )


@st.composite
def scene_info_strategy(draw):
    """Generate valid SceneInfo objects."""
    bounds = draw(valid_bounds_strategy())
    
    return SceneInfo(
        scene_id=draw(st.text(min_size=10, max_size=50, alphabet=st.characters(whitelist_categories=("Lu", "Ll", "Nd"), whitelist_characters="_-"))),
        platform=draw(st.sampled_from(list(SatellitePlatform))),
        acquisition_date=draw(st.dates(min_value=date(2013, 1, 1), max_value=date(2026, 1, 1))),
        cloud_cover=draw(st.floats(min_value=0, max_value=100, allow_nan=False, allow_infinity=False)),
        bounds=bounds
    )


@st.composite
def tile_data_strategy(draw, bands=3, size=256):
    """Generate valid tile data as numpy arrays."""
    shape = (bands, size, size) if bands > 1 else (size, size)
    data = draw(st.lists(
        st.integers(min_value=0, max_value=255),
        min_size=np.prod(shape),
        max_size=np.prod(shape)
    ))
    return np.array(data, dtype=np.uint8).reshape(shape)


@st.composite
def lat_lon_strategy(draw):
    """Generate valid latitude/longitude pairs."""
    lat = draw(st.floats(min_value=-85.05, max_value=85.05, allow_nan=False, allow_infinity=False))
    lon = draw(st.floats(min_value=-180, max_value=180, allow_nan=False, allow_infinity=False))
    return lat, lon


@st.composite
def zoom_strategy(draw):
    """Generate valid zoom levels."""
    return draw(st.integers(min_value=0, max_value=22))


# Pytest fixtures

@pytest.fixture
def sample_band_info():
    """Sample BandInfo for testing."""
    return BandInfo(
        name="B4",
        description="Red",
        wavelength="0.64-0.67μm",
        resolution=30
    )


@pytest.fixture
def sample_mission_info(sample_band_info):
    """Sample MissionInfo for testing."""
    return MissionInfo(
        platform=SatellitePlatform.LANDSAT8,
        bands=[sample_band_info],
        date_range=("2013-04-11", "2025-01-01"),
        resolution=30
    )


@pytest.fixture
def sample_scene_info():
    """Sample SceneInfo for testing."""
    return SceneInfo(
        scene_id="LC08_L1TP_014032_20240615_20240620_02_T1",
        platform=SatellitePlatform.LANDSAT8,
        acquisition_date=date(2024, 6, 15),
        cloud_cover=5.2,
        bounds=(-74.5, 40.5, -73.5, 41.5)
    )


@pytest.fixture
def sample_tile_data():
    """Sample tile data for testing."""
    return np.random.randint(0, 256, size=(3, 256, 256), dtype=np.uint8)


@pytest.fixture
def sample_mask():
    """Sample mask for testing."""
    return np.full((256, 256), 255, dtype=np.uint8)
