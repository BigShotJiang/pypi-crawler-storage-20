"""Tests for spectral index calculations.

Property-based tests validate:
- Property 2: Normalized Difference Index Range Invariant
- Property 3: Normalized Difference Index Formula Correctness
- Property 7: Division by Zero Handling
"""

import numpy as np
import pytest
from hypothesis import given, strategies as st, settings, assume

from satellite_tiler.indices import (
    SpectralIndex,
    IndexResult,
    BAND_MAPPINGS,
    calculate_ndvi,
    calculate_ndbi,
    calculate_ndwi,
    calculate_mndwi,
    calculate_evi,
    calculate_savi,
    calculate_ndmi,
    calculate_bsi,
    calculate_custom,
    get_bands_for_index,
    _normalized_difference,
)


# Hypothesis strategies for band arrays
# Using numpy arrays strategy for better performance

@st.composite
def band_array(draw, min_size=5, max_size=20):
    """Generate a 2D array representing a satellite band."""
    size = draw(st.integers(min_value=min_size, max_value=max_size))
    data = draw(st.lists(
        st.floats(min_value=0, max_value=10000, allow_nan=False, allow_infinity=False),
        min_size=size * size,
        max_size=size * size
    ))
    return np.array(data, dtype=np.float64).reshape((size, size))


@st.composite
def band_pair(draw, min_size=5, max_size=20):
    """Generate two band arrays of the same shape."""
    size = draw(st.integers(min_value=min_size, max_value=max_size))
    n_elements = size * size
    
    data_a = draw(st.lists(
        st.floats(min_value=0, max_value=10000, allow_nan=False, allow_infinity=False),
        min_size=n_elements,
        max_size=n_elements
    ))
    data_b = draw(st.lists(
        st.floats(min_value=0, max_value=10000, allow_nan=False, allow_infinity=False),
        min_size=n_elements,
        max_size=n_elements
    ))
    
    return (
        np.array(data_a, dtype=np.float64).reshape((size, size)),
        np.array(data_b, dtype=np.float64).reshape((size, size))
    )


@st.composite
def band_triple(draw, min_size=5, max_size=15):
    """Generate three band arrays of the same shape."""
    size = draw(st.integers(min_value=min_size, max_value=max_size))
    n_elements = size * size
    
    arrays = []
    for _ in range(3):
        data = draw(st.lists(
            st.floats(min_value=0, max_value=10000, allow_nan=False, allow_infinity=False),
            min_size=n_elements,
            max_size=n_elements
        ))
        arrays.append(np.array(data, dtype=np.float64).reshape((size, size)))
    
    return tuple(arrays)


@st.composite
def band_quad(draw, min_size=5, max_size=15):
    """Generate four band arrays of the same shape."""
    size = draw(st.integers(min_value=min_size, max_value=max_size))
    n_elements = size * size
    
    arrays = []
    for _ in range(4):
        data = draw(st.lists(
            st.floats(min_value=0, max_value=10000, allow_nan=False, allow_infinity=False),
            min_size=n_elements,
            max_size=n_elements
        ))
        arrays.append(np.array(data, dtype=np.float64).reshape((size, size)))
    
    return tuple(arrays)


# Property 2: Normalized Difference Index Range Invariant
# For any normalized difference index calculation, all valid output values
# SHALL be in the range [-1, 1].

class TestNormalizedDifferenceRangeInvariant:
    """Feature: geospatial-agent-tools, Property 2: Normalized Difference Index Range Invariant"""
    
    @given(bands=band_pair())
    @settings(max_examples=200)
    def test_ndvi_range_invariant(self, bands):
        """NDVI values must be in [-1, 1] range."""
        nir, red = bands
        result = calculate_ndvi(nir, red)
        
        # Check all valid (non-NaN) values are in range
        valid_values = result.data[~np.isnan(result.data)]
        if len(valid_values) > 0:
            assert np.all(valid_values >= -1.0), f"NDVI below -1: {np.min(valid_values)}"
            assert np.all(valid_values <= 1.0), f"NDVI above 1: {np.max(valid_values)}"
    
    @given(bands=band_pair())
    @settings(max_examples=200)
    def test_ndbi_range_invariant(self, bands):
        """NDBI values must be in [-1, 1] range."""
        swir, nir = bands
        result = calculate_ndbi(swir, nir)
        
        valid_values = result.data[~np.isnan(result.data)]
        if len(valid_values) > 0:
            assert np.all(valid_values >= -1.0)
            assert np.all(valid_values <= 1.0)
    
    @given(bands=band_pair())
    @settings(max_examples=200)
    def test_ndwi_range_invariant(self, bands):
        """NDWI values must be in [-1, 1] range."""
        green, nir = bands
        result = calculate_ndwi(green, nir)
        
        valid_values = result.data[~np.isnan(result.data)]
        if len(valid_values) > 0:
            assert np.all(valid_values >= -1.0)
            assert np.all(valid_values <= 1.0)
    
    @given(bands=band_pair())
    @settings(max_examples=200)
    def test_mndwi_range_invariant(self, bands):
        """MNDWI values must be in [-1, 1] range."""
        green, swir = bands
        result = calculate_mndwi(green, swir)
        
        valid_values = result.data[~np.isnan(result.data)]
        if len(valid_values) > 0:
            assert np.all(valid_values >= -1.0)
            assert np.all(valid_values <= 1.0)
    
    @given(bands=band_pair())
    @settings(max_examples=200)
    def test_ndmi_range_invariant(self, bands):
        """NDMI values must be in [-1, 1] range."""
        nir, swir = bands
        result = calculate_ndmi(nir, swir)
        
        valid_values = result.data[~np.isnan(result.data)]
        if len(valid_values) > 0:
            assert np.all(valid_values >= -1.0)
            assert np.all(valid_values <= 1.0)


# Property 3: Normalized Difference Index Formula Correctness
# For any two band arrays A and B, the normalized difference index SHALL equal
# (A - B) / (A + B) for all pixels where A + B ≠ 0.

class TestNormalizedDifferenceFormulaCorrectness:
    """Feature: geospatial-agent-tools, Property 3: Normalized Difference Index Formula Correctness"""
    
    @given(bands=band_pair())
    @settings(max_examples=200)
    def test_ndvi_formula_correctness(self, bands):
        """NDVI must equal (NIR - Red) / (NIR + Red)."""
        nir, red = bands
        result = calculate_ndvi(nir, red)
        
        # Calculate expected values manually
        nir_f = nir.astype(np.float64)
        red_f = red.astype(np.float64)
        denominator = nir_f + red_f
        
        # Check formula where denominator is non-zero
        non_zero_mask = denominator != 0
        if np.any(non_zero_mask):
            expected = (nir_f - red_f) / denominator
            np.testing.assert_array_almost_equal(
                result.data[non_zero_mask],
                expected[non_zero_mask],
                decimal=10
            )
    
    @given(bands=band_pair())
    @settings(max_examples=200)
    def test_ndbi_formula_correctness(self, bands):
        """NDBI must equal (SWIR - NIR) / (SWIR + NIR)."""
        swir, nir = bands
        result = calculate_ndbi(swir, nir)
        
        swir_f = swir.astype(np.float64)
        nir_f = nir.astype(np.float64)
        denominator = swir_f + nir_f
        
        non_zero_mask = denominator != 0
        if np.any(non_zero_mask):
            expected = (swir_f - nir_f) / denominator
            np.testing.assert_array_almost_equal(
                result.data[non_zero_mask],
                expected[non_zero_mask],
                decimal=10
            )
    
    @given(bands=band_pair())
    @settings(max_examples=200)
    def test_ndwi_formula_correctness(self, bands):
        """NDWI must equal (Green - NIR) / (Green + NIR)."""
        green, nir = bands
        result = calculate_ndwi(green, nir)
        
        green_f = green.astype(np.float64)
        nir_f = nir.astype(np.float64)
        denominator = green_f + nir_f
        
        non_zero_mask = denominator != 0
        if np.any(non_zero_mask):
            expected = (green_f - nir_f) / denominator
            np.testing.assert_array_almost_equal(
                result.data[non_zero_mask],
                expected[non_zero_mask],
                decimal=10
            )
    
    @given(
        a=st.floats(min_value=0, max_value=10000, allow_nan=False, allow_infinity=False),
        b=st.floats(min_value=0, max_value=10000, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=200)
    def test_normalized_difference_scalar_formula(self, a, b):
        """Normalized difference formula correctness for scalar values."""
        assume(a + b != 0)  # Skip division by zero cases
        
        arr_a = np.array([[a]])
        arr_b = np.array([[b]])
        
        result = _normalized_difference(arr_a, arr_b)
        expected = (a - b) / (a + b)
        
        assert abs(result[0, 0] - expected) < 1e-10


# Property 7: Division by Zero Handling
# For any index calculation where the denominator equals zero, the result
# SHALL be NaN (or configured no-data value), not an error or infinity.

class TestDivisionByZeroHandling:
    """Feature: geospatial-agent-tools, Property 7: Division by Zero Handling"""
    
    def test_ndvi_all_zeros_returns_nan(self):
        """NDVI with all zeros should return NaN."""
        nir = np.zeros((10, 10))
        red = np.zeros((10, 10))
        result = calculate_ndvi(nir, red)
        
        assert np.all(np.isnan(result.data))
        assert result.valid_pixel_count == 0
        assert result.nodata_pixel_count == 100
    
    def test_ndbi_all_zeros_returns_nan(self):
        """NDBI with all zeros should return NaN."""
        swir = np.zeros((10, 10))
        nir = np.zeros((10, 10))
        result = calculate_ndbi(swir, nir)
        
        assert np.all(np.isnan(result.data))
    
    def test_ndwi_all_zeros_returns_nan(self):
        """NDWI with all zeros should return NaN."""
        green = np.zeros((10, 10))
        nir = np.zeros((10, 10))
        result = calculate_ndwi(green, nir)
        
        assert np.all(np.isnan(result.data))
    
    def test_mndwi_all_zeros_returns_nan(self):
        """MNDWI with all zeros should return NaN."""
        green = np.zeros((10, 10))
        swir = np.zeros((10, 10))
        result = calculate_mndwi(green, swir)
        
        assert np.all(np.isnan(result.data))
    
    @given(bands=band_pair())
    @settings(max_examples=100)
    def test_no_infinity_in_results(self, bands):
        """Index calculations should never produce infinity."""
        nir, red = bands
        result = calculate_ndvi(nir, red)
        
        assert not np.any(np.isinf(result.data))
    
    def test_partial_zeros_handled(self):
        """Pixels with zero denominator should be NaN, others valid."""
        nir = np.array([[0, 100, 200], [0, 50, 150], [0, 0, 100]])
        red = np.array([[0, 50, 100], [0, 50, 50], [0, 0, 0]])
        
        result = calculate_ndvi(nir, red)
        
        # Check specific pixels
        assert np.isnan(result.data[0, 0])  # 0/0 = NaN
        assert np.isnan(result.data[1, 0])  # 0/0 = NaN
        assert np.isnan(result.data[2, 0])  # 0/0 = NaN
        assert np.isnan(result.data[2, 1])  # 0/0 = NaN
        
        # Valid pixels should have values
        assert not np.isnan(result.data[0, 1])  # (100-50)/(100+50) = 0.333
        assert not np.isnan(result.data[0, 2])  # (200-100)/(200+100) = 0.333
    
    def test_evi_zero_denominator_returns_nan(self):
        """EVI with zero denominator should return NaN."""
        # Create arrays where NIR + C1*Red - C2*Blue + L = 0
        # With defaults: NIR + 6*Red - 7.5*Blue + 1 = 0
        # If all zeros: 0 + 0 - 0 + 1 = 1 (not zero)
        # Need specific values to make denominator zero
        nir = np.zeros((5, 5))
        red = np.zeros((5, 5))
        blue = np.full((5, 5), 1.0 / 7.5)  # Makes denominator = 0 + 0 - 1 + 1 = 0
        
        result = calculate_evi(nir, red, blue)
        
        # All should be NaN since denominator is 0
        assert np.all(np.isnan(result.data))


# Unit tests for specific examples and edge cases

class TestIndexResultDataclass:
    """Tests for IndexResult dataclass."""
    
    def test_index_result_to_dict(self):
        """IndexResult should serialize to dict without numpy array."""
        data = np.array([[0.5, 0.6], [0.7, 0.8]])
        result = IndexResult(
            index_name="ndvi",
            data=data,
            min_value=0.5,
            max_value=0.8,
            mean_value=0.65,
            std_value=0.1,
            valid_pixel_count=4,
            nodata_pixel_count=0,
        )
        
        d = result.to_dict()
        assert d["index_name"] == "ndvi"
        assert d["shape"] == [2, 2]
        assert d["min_value"] == 0.5
        assert d["max_value"] == 0.8
        assert "data" not in d  # numpy array should not be in dict
    
    def test_index_result_nan_statistics(self):
        """IndexResult with NaN statistics should serialize properly."""
        data = np.full((2, 2), np.nan)
        result = IndexResult(
            index_name="ndvi",
            data=data,
            min_value=np.nan,
            max_value=np.nan,
            mean_value=np.nan,
            std_value=np.nan,
            valid_pixel_count=0,
            nodata_pixel_count=4,
        )
        
        d = result.to_dict()
        assert d["min_value"] is None
        assert d["max_value"] is None
        assert d["mean_value"] is None


class TestNDVIKnownValues:
    """Tests for NDVI with known expected values."""
    
    def test_ndvi_known_calculation(self):
        """NDVI should match manual calculation."""
        nir = np.array([[0.5, 0.8], [0.3, 0.9]])
        red = np.array([[0.1, 0.2], [0.3, 0.1]])
        
        result = calculate_ndvi(nir, red)
        
        # Manual calculation
        expected = (nir - red) / (nir + red)
        np.testing.assert_array_almost_equal(result.data, expected)
    
    def test_ndvi_perfect_vegetation(self):
        """High NIR, low Red should give high NDVI."""
        nir = np.array([[1000]])
        red = np.array([[100]])
        
        result = calculate_ndvi(nir, red)
        
        # (1000 - 100) / (1000 + 100) = 900/1100 ≈ 0.818
        assert result.data[0, 0] == pytest.approx(0.818, rel=0.01)
    
    def test_ndvi_water(self):
        """Low NIR, high Red should give negative NDVI."""
        nir = np.array([[100]])
        red = np.array([[500]])
        
        result = calculate_ndvi(nir, red)
        
        # (100 - 500) / (100 + 500) = -400/600 ≈ -0.667
        assert result.data[0, 0] == pytest.approx(-0.667, rel=0.01)
    
    def test_ndvi_bare_soil(self):
        """Similar NIR and Red should give near-zero NDVI."""
        nir = np.array([[500]])
        red = np.array([[450]])
        
        result = calculate_ndvi(nir, red)
        
        # (500 - 450) / (500 + 450) = 50/950 ≈ 0.053
        assert result.data[0, 0] == pytest.approx(0.053, rel=0.01)


class TestEVICalculation:
    """Tests for EVI calculation."""
    
    def test_evi_known_values(self):
        """EVI should match manual calculation with default coefficients."""
        nir = np.array([[0.5]])
        red = np.array([[0.1]])
        blue = np.array([[0.05]])
        
        result = calculate_evi(nir, red, blue)
        
        # EVI = 2.5 * (0.5 - 0.1) / (0.5 + 6*0.1 - 7.5*0.05 + 1)
        # = 2.5 * 0.4 / (0.5 + 0.6 - 0.375 + 1)
        # = 1.0 / 1.725 ≈ 0.58
        expected = 2.5 * (0.5 - 0.1) / (0.5 + 6*0.1 - 7.5*0.05 + 1)
        assert result.data[0, 0] == pytest.approx(expected, rel=0.01)
    
    def test_evi_custom_coefficients(self):
        """EVI should use custom coefficients when provided."""
        nir = np.array([[0.5]])
        red = np.array([[0.1]])
        blue = np.array([[0.05]])
        
        result = calculate_evi(nir, red, blue, g=3.0, c1=5.0, c2=6.0, l=0.5)
        
        expected = 3.0 * (0.5 - 0.1) / (0.5 + 5.0*0.1 - 6.0*0.05 + 0.5)
        assert result.data[0, 0] == pytest.approx(expected, rel=0.01)


class TestSAVICalculation:
    """Tests for SAVI calculation."""
    
    def test_savi_known_values(self):
        """SAVI should match manual calculation."""
        nir = np.array([[0.5]])
        red = np.array([[0.1]])
        
        result = calculate_savi(nir, red, l=0.5)
        
        # SAVI = ((0.5 - 0.1) / (0.5 + 0.1 + 0.5)) * 1.5
        # = (0.4 / 1.1) * 1.5 ≈ 0.545
        expected = ((0.5 - 0.1) / (0.5 + 0.1 + 0.5)) * 1.5
        assert result.data[0, 0] == pytest.approx(expected, rel=0.01)


class TestBSICalculation:
    """Tests for BSI calculation."""
    
    def test_bsi_known_values(self):
        """BSI should match manual calculation."""
        swir = np.array([[0.4]])
        red = np.array([[0.3]])
        nir = np.array([[0.2]])
        blue = np.array([[0.1]])
        
        result = calculate_bsi(swir, red, nir, blue)
        
        # BSI = ((0.4 + 0.3) - (0.2 + 0.1)) / ((0.4 + 0.3) + (0.2 + 0.1))
        # = (0.7 - 0.3) / (0.7 + 0.3) = 0.4 / 1.0 = 0.4
        expected = ((0.4 + 0.3) - (0.2 + 0.1)) / ((0.4 + 0.3) + (0.2 + 0.1))
        assert result.data[0, 0] == pytest.approx(expected, rel=0.01)


class TestCustomIndexCalculation:
    """Tests for custom index expressions."""
    
    def test_custom_ndvi_expression(self):
        """Custom expression should calculate NDVI correctly."""
        nir = np.array([[0.5, 0.8], [0.3, 0.9]])
        red = np.array([[0.1, 0.2], [0.3, 0.1]])
        
        result = calculate_custom(
            "(nir - red) / (nir + red)",
            {"nir": nir, "red": red}
        )
        
        expected = (nir - red) / (nir + red)
        np.testing.assert_array_almost_equal(result.data, expected)
    
    def test_custom_invalid_expression(self):
        """Invalid expression should raise ValueError."""
        bands = {"nir": np.array([[1.0]])}
        
        with pytest.raises(ValueError):
            calculate_custom("invalid_syntax(", bands)
    
    def test_custom_missing_band(self):
        """Missing band in expression should raise error."""
        bands = {"nir": np.array([[1.0]])}
        
        with pytest.raises((ValueError, NameError)):
            calculate_custom("nir + red", bands)


class TestGetBandsForIndex:
    """Tests for get_bands_for_index function."""
    
    def test_landsat8_ndvi_bands(self):
        """Should return correct Landsat 8 bands for NDVI."""
        bands = get_bands_for_index(SpectralIndex.NDVI, "landsat8")
        assert bands == ("B5", "B4")  # NIR, Red
    
    def test_sentinel2_ndvi_bands(self):
        """Should return correct Sentinel-2 bands for NDVI."""
        bands = get_bands_for_index(SpectralIndex.NDVI, "sentinel2")
        assert bands == ("B08", "B04")  # NIR, Red
    
    def test_landsat8_ndbi_bands(self):
        """Should return correct Landsat 8 bands for NDBI."""
        bands = get_bands_for_index(SpectralIndex.NDBI, "landsat8")
        assert bands == ("B6", "B5")  # SWIR1, NIR
    
    def test_sentinel2_ndwi_bands(self):
        """Should return correct Sentinel-2 bands for NDWI."""
        bands = get_bands_for_index(SpectralIndex.NDWI, "sentinel2")
        assert bands == ("B03", "B08")  # Green, NIR
    
    def test_unsupported_platform(self):
        """Should raise ValueError for unsupported platform."""
        with pytest.raises(ValueError, match="Unsupported platform"):
            get_bands_for_index(SpectralIndex.NDVI, "unknown_platform")


class TestStatisticsCalculation:
    """Tests for statistics in IndexResult."""
    
    def test_statistics_correctness(self):
        """Statistics should be calculated correctly."""
        nir = np.array([[100, 200, 300], [400, 500, 600], [700, 800, 900]])
        red = np.array([[50, 100, 150], [200, 250, 300], [350, 400, 450]])
        
        result = calculate_ndvi(nir, red)
        
        # All denominators are non-zero, so all values are valid
        assert result.valid_pixel_count == 9
        assert result.nodata_pixel_count == 0
        
        # Check statistics match numpy calculations
        assert result.min_value == pytest.approx(np.min(result.data), rel=1e-10)
        assert result.max_value == pytest.approx(np.max(result.data), rel=1e-10)
        assert result.mean_value == pytest.approx(np.mean(result.data), rel=1e-10)
        assert result.std_value == pytest.approx(np.std(result.data), rel=1e-10)
    
    def test_statistics_with_nan(self):
        """Statistics should exclude NaN values."""
        nir = np.array([[0, 200], [300, 0]])
        red = np.array([[0, 100], [150, 0]])
        
        result = calculate_ndvi(nir, red)
        
        # Two pixels have zero denominator
        assert result.nodata_pixel_count == 2
        assert result.valid_pixel_count == 2
        
        # Statistics should be based on valid pixels only
        valid_values = result.data[~np.isnan(result.data)]
        assert result.min_value == pytest.approx(np.min(valid_values), rel=1e-10)
        assert result.max_value == pytest.approx(np.max(valid_values), rel=1e-10)
