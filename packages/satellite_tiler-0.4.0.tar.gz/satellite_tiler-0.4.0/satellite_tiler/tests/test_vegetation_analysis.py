"""Tests for vegetation analysis.

Property-based tests validate:
- Property 4: Classification Percentage Sum Invariant
- Property 13: Vegetation Classification Thresholds
"""

import numpy as np
import pytest
from hypothesis import given, strategies as st, settings

from satellite_tiler.vegetation_analysis import (
    VegetationClass,
    VegetationAnalysisResult,
    VegetationChangeResult,
    NDVI_THRESHOLDS,
    classify_ndvi_pixel,
    classify_vegetation,
    calculate_class_percentages,
    assess_vegetation_health,
    analyze_vegetation,
    compare_vegetation,
    colorize_classification,
)


# Property 4: Classification Percentage Sum Invariant
# For any classification result, the sum of all class percentages
# SHALL equal 100% (within floating-point tolerance).

class TestClassificationPercentageSumInvariant:
    """Feature: geospatial-agent-tools, Property 4: Classification Percentage Sum Invariant"""
    
    @given(
        ndvi_values=st.lists(
            st.floats(min_value=-1.0, max_value=1.0, allow_nan=False, allow_infinity=False),
            min_size=4,
            max_size=100
        )
    )
    @settings(max_examples=100)
    def test_percentage_sum_equals_100(self, ndvi_values):
        """Sum of all class percentages must equal 100%."""
        # Create 2D array
        size = int(np.sqrt(len(ndvi_values)))
        if size < 2:
            return
        
        ndvi = np.array(ndvi_values[:size*size]).reshape((size, size))
        
        classification = classify_vegetation(ndvi)
        percentages = calculate_class_percentages(classification)
        
        total = sum(percentages.values())
        
        assert abs(total - 100.0) < 0.001, \
            f"Percentages sum to {total}, not 100%: {percentages}"
    
    @given(
        nir_values=st.lists(
            st.floats(min_value=0, max_value=10000, allow_nan=False, allow_infinity=False),
            min_size=25,
            max_size=100
        ),
        red_values=st.lists(
            st.floats(min_value=0, max_value=10000, allow_nan=False, allow_infinity=False),
            min_size=25,
            max_size=100
        )
    )
    @settings(max_examples=50)
    def test_analyze_vegetation_percentages_sum(self, nir_values, red_values):
        """Vegetation analysis percentages must sum to 100%."""
        size = min(int(np.sqrt(len(nir_values))), int(np.sqrt(len(red_values))))
        if size < 2:
            return
        
        nir = np.array(nir_values[:size*size]).reshape((size, size))
        red = np.array(red_values[:size*size]).reshape((size, size))
        
        result = analyze_vegetation(nir, red)
        
        total = sum(result.class_percentages.values())
        
        assert abs(total - 100.0) < 0.001


# Property 13: Vegetation Classification Thresholds
# For any NDVI value, it SHALL map to exactly one vegetation class based on
# the defined threshold ranges, and the ranges SHALL be exhaustive and non-overlapping.

class TestVegetationClassificationThresholds:
    """Feature: geospatial-agent-tools, Property 13: Vegetation Classification Thresholds"""
    
    @given(
        ndvi=st.floats(min_value=-1.0, max_value=1.0, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=200)
    def test_every_ndvi_maps_to_one_class(self, ndvi):
        """Every valid NDVI value must map to exactly one class."""
        veg_class = classify_ndvi_pixel(ndvi)
        
        assert veg_class in VegetationClass, \
            f"NDVI {ndvi} mapped to invalid class: {veg_class}"
    
    def test_threshold_ranges_exhaustive(self):
        """Threshold ranges must cover entire [-1, 1] range."""
        # Check that all thresholds are defined
        assert len(NDVI_THRESHOLDS) == 5
        
        # Check coverage
        all_ranges = list(NDVI_THRESHOLDS.values())
        min_val = min(r[0] for r in all_ranges)
        max_val = max(r[1] for r in all_ranges)
        
        assert min_val == -1.0, f"Minimum threshold is {min_val}, not -1.0"
        assert max_val == 1.0, f"Maximum threshold is {max_val}, not 1.0"
    
    def test_threshold_ranges_non_overlapping(self):
        """Threshold ranges must not overlap."""
        ranges = sorted(NDVI_THRESHOLDS.values(), key=lambda x: x[0])
        
        for i in range(len(ranges) - 1):
            current_high = ranges[i][1]
            next_low = ranges[i + 1][0]
            
            assert current_high == next_low, \
                f"Gap or overlap between {ranges[i]} and {ranges[i+1]}"
    
    def test_boundary_values(self):
        """Test classification at exact boundary values."""
        # Water/Bare soil boundary at 0.0
        assert classify_ndvi_pixel(-0.001) == VegetationClass.WATER
        assert classify_ndvi_pixel(0.0) == VegetationClass.BARE_SOIL
        
        # Bare soil/Sparse boundary at 0.1
        assert classify_ndvi_pixel(0.099) == VegetationClass.BARE_SOIL
        assert classify_ndvi_pixel(0.1) == VegetationClass.SPARSE
        
        # Sparse/Moderate boundary at 0.3
        assert classify_ndvi_pixel(0.299) == VegetationClass.SPARSE
        assert classify_ndvi_pixel(0.3) == VegetationClass.MODERATE
        
        # Moderate/Dense boundary at 0.6
        assert classify_ndvi_pixel(0.599) == VegetationClass.MODERATE
        assert classify_ndvi_pixel(0.6) == VegetationClass.DENSE
    
    def test_extreme_values(self):
        """Test classification at extreme NDVI values."""
        assert classify_ndvi_pixel(-1.0) == VegetationClass.WATER
        assert classify_ndvi_pixel(1.0) == VegetationClass.DENSE
        assert classify_ndvi_pixel(0.999) == VegetationClass.DENSE


# Unit tests

class TestClassifyVegetation:
    """Unit tests for vegetation classification."""
    
    def test_classify_water(self):
        """Negative NDVI should classify as water."""
        ndvi = np.array([[-0.5, -0.2], [-0.1, -0.01]])
        classification = classify_vegetation(ndvi)
        
        assert np.all(classification == 0)  # Water class
    
    def test_classify_dense_vegetation(self):
        """High NDVI should classify as dense vegetation."""
        ndvi = np.array([[0.7, 0.8], [0.9, 0.65]])
        classification = classify_vegetation(ndvi)
        
        assert np.all(classification == 4)  # Dense class
    
    def test_classify_mixed(self):
        """Mixed NDVI values should classify correctly."""
        ndvi = np.array([
            [-0.5, 0.05, 0.2],
            [0.4, 0.7, 0.15],
            [0.55, 0.0, 0.85]
        ])
        
        classification = classify_vegetation(ndvi)
        
        # Check specific pixels
        assert classification[0, 0] == 0  # Water (-0.5)
        assert classification[0, 1] == 1  # Bare soil (0.05)
        assert classification[0, 2] == 2  # Sparse (0.2)
        assert classification[1, 0] == 3  # Moderate (0.4)
        assert classification[1, 1] == 4  # Dense (0.7)
        assert classification[2, 2] == 4  # Dense (0.85)
    
    def test_classify_nan_as_bare_soil(self):
        """NaN values should classify as bare soil."""
        ndvi = np.array([[np.nan, 0.5], [0.3, np.nan]])
        classification = classify_vegetation(ndvi)
        
        assert classification[0, 0] == 1  # Bare soil
        assert classification[1, 1] == 1  # Bare soil


class TestCalculateClassPercentages:
    """Unit tests for class percentage calculation."""
    
    def test_uniform_classification(self):
        """Uniform classification should give 100% for one class."""
        classification = np.full((10, 10), 3)  # All moderate
        
        percentages = calculate_class_percentages(classification)
        
        assert percentages[VegetationClass.MODERATE.value] == 100.0
        assert percentages[VegetationClass.WATER.value] == 0.0
    
    def test_equal_distribution(self):
        """Equal distribution should give equal percentages."""
        # Create array with equal distribution of 5 classes
        classification = np.array([
            [0, 1, 2, 3, 4],
            [0, 1, 2, 3, 4],
            [0, 1, 2, 3, 4],
            [0, 1, 2, 3, 4],
            [0, 1, 2, 3, 4],
        ])
        
        percentages = calculate_class_percentages(classification)
        
        for veg_class in VegetationClass:
            assert abs(percentages[veg_class.value] - 20.0) < 0.001


class TestAssessVegetationHealth:
    """Unit tests for vegetation health assessment."""
    
    def test_excellent_health(self):
        """High dense vegetation should be excellent."""
        percentages = {
            VegetationClass.WATER.value: 5.0,
            VegetationClass.BARE_SOIL.value: 5.0,
            VegetationClass.SPARSE.value: 10.0,
            VegetationClass.MODERATE.value: 30.0,
            VegetationClass.DENSE.value: 50.0,
        }
        
        assert assess_vegetation_health(percentages) == "excellent"
    
    def test_good_health(self):
        """Moderate vegetation coverage should be good."""
        percentages = {
            VegetationClass.WATER.value: 15.0,
            VegetationClass.BARE_SOIL.value: 30.0,
            VegetationClass.SPARSE.value: 10.0,
            VegetationClass.MODERATE.value: 20.0,
            VegetationClass.DENSE.value: 25.0,
        }
        # Total vegetation = 55%, dense = 25% -> "good"
        assert assess_vegetation_health(percentages) == "good"
    
    def test_poor_health(self):
        """Low vegetation coverage should be poor."""
        percentages = {
            VegetationClass.WATER.value: 20.0,
            VegetationClass.BARE_SOIL.value: 60.0,
            VegetationClass.SPARSE.value: 10.0,
            VegetationClass.MODERATE.value: 5.0,
            VegetationClass.DENSE.value: 5.0,
        }
        
        assert assess_vegetation_health(percentages) == "poor"


class TestAnalyzeVegetation:
    """Unit tests for complete vegetation analysis."""
    
    def test_analyze_vegetation_result_structure(self):
        """Result should have all required fields."""
        nir = np.random.uniform(100, 1000, size=(10, 10))
        red = np.random.uniform(50, 500, size=(10, 10))
        
        result = analyze_vegetation(nir, red)
        
        assert isinstance(result, VegetationAnalysisResult)
        assert result.ndvi is not None
        assert result.classification.shape == (10, 10)
        assert len(result.class_percentages) == 5
        assert result.health_assessment in ["poor", "fair", "good", "excellent"]
    
    def test_analyze_vegetation_with_evi(self):
        """Analysis with EVI should include EVI result."""
        nir = np.random.uniform(100, 1000, size=(10, 10))
        red = np.random.uniform(50, 500, size=(10, 10))
        blue = np.random.uniform(30, 300, size=(10, 10))
        
        result = analyze_vegetation(nir, red, blue, include_evi=True)
        
        assert result.evi is not None
    
    def test_analyze_vegetation_to_dict(self):
        """Result should serialize to dict."""
        nir = np.random.uniform(100, 1000, size=(5, 5))
        red = np.random.uniform(50, 500, size=(5, 5))
        
        result = analyze_vegetation(nir, red)
        d = result.to_dict()
        
        assert "ndvi" in d
        assert "class_percentages" in d
        assert "health_assessment" in d


class TestCompareVegetation:
    """Unit tests for vegetation change comparison."""
    
    def test_no_change(self):
        """Identical images should show no change."""
        nir = np.full((10, 10), 500.0)
        red = np.full((10, 10), 200.0)
        
        result = compare_vegetation(nir, red, nir, red)
        
        assert result.vegetation_loss_percent == 0.0
        assert result.vegetation_gain_percent == 0.0
        assert result.no_change_percent == 100.0
        assert result.mean_change == 0.0
    
    def test_vegetation_gain(self):
        """Increased NIR should show vegetation gain."""
        nir_before = np.full((10, 10), 300.0)
        red_before = np.full((10, 10), 200.0)
        nir_after = np.full((10, 10), 600.0)  # Higher NIR
        red_after = np.full((10, 10), 200.0)
        
        result = compare_vegetation(nir_before, red_before, nir_after, red_after)
        
        assert result.vegetation_gain_percent > 0
        assert result.mean_change > 0
    
    def test_vegetation_loss(self):
        """Decreased NIR should show vegetation loss."""
        nir_before = np.full((10, 10), 600.0)
        red_before = np.full((10, 10), 200.0)
        nir_after = np.full((10, 10), 300.0)  # Lower NIR
        red_after = np.full((10, 10), 200.0)
        
        result = compare_vegetation(nir_before, red_before, nir_after, red_after)
        
        assert result.vegetation_loss_percent > 0
        assert result.mean_change < 0


class TestColorizeClassification:
    """Unit tests for classification colorization."""
    
    def test_colorize_shape(self):
        """Output should be RGB with correct shape."""
        classification = np.array([[0, 1], [2, 3]])
        
        rgb = colorize_classification(classification)
        
        assert rgb.shape == (2, 2, 3)
        assert rgb.dtype == np.uint8
    
    def test_colorize_water_blue(self):
        """Water class should be blue."""
        classification = np.array([[0]])
        
        rgb = colorize_classification(classification)
        
        # Water is dark blue (0, 0, 139)
        assert rgb[0, 0, 2] > rgb[0, 0, 0]  # Blue > Red
        assert rgb[0, 0, 2] > rgb[0, 0, 1]  # Blue > Green
    
    def test_colorize_dense_green(self):
        """Dense vegetation should be green."""
        classification = np.array([[4]])
        
        rgb = colorize_classification(classification)
        
        # Dense is dark green (0, 100, 0)
        assert rgb[0, 0, 1] > rgb[0, 0, 0]  # Green > Red
        assert rgb[0, 0, 1] > rgb[0, 0, 2]  # Green > Blue
