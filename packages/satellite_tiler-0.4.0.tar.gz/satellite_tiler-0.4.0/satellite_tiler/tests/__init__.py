"""Tests for satellite-tiler package."""
