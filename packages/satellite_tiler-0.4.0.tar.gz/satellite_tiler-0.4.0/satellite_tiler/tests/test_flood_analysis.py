"""Tests for flood risk analysis.

Property-based tests validate:
- Property 11: Score Range Validity
- Property 12: Water Body Detection Consistency
"""

import numpy as np
import pytest
from hypothesis import given, strategies as st, settings

from satellite_tiler.flood_analysis import (
    FloodRiskLevel,
    WaterBodyResult,
    ImperviousnessResult,
    FloodRiskResult,
    RISK_THRESHOLDS,
    detect_water_bodies,
    calculate_imperviousness,
    calculate_water_proximity,
    calculate_vulnerability_score,
    classify_risk_level,
    calculate_risk_percentages,
    generate_flood_recommendations,
    analyze_flood_risk,
    colorize_risk,
)


# Property 11: Score Range Validity
# For any vulnerability score calculation, all values SHALL be in the range [0, 1].

class TestScoreRangeValidity:
    """Feature: geospatial-agent-tools, Property 11: Score Range Validity"""
    
    @given(
        water_prox=st.lists(
            st.floats(min_value=0, max_value=1, allow_nan=False, allow_infinity=False),
            min_size=25,
            max_size=100
        ),
        impervious=st.lists(
            st.booleans(),
            min_size=25,
            max_size=100
        )
    )
    @settings(max_examples=100)
    def test_vulnerability_score_in_range(self, water_prox, impervious):
        """Vulnerability scores must be in [0, 1] range."""
        size = min(int(np.sqrt(len(water_prox))), int(np.sqrt(len(impervious))))
        if size < 2:
            return
        
        water_proximity = np.array(water_prox[:size*size]).reshape((size, size))
        impervious_mask = np.array(impervious[:size*size]).reshape((size, size))
        
        score = calculate_vulnerability_score(water_proximity, impervious_mask)
        
        assert np.all(score >= 0.0), f"Score below 0: {np.min(score)}"
        assert np.all(score <= 1.0), f"Score above 1: {np.max(score)}"
    
    @given(
        values=st.lists(
            st.floats(min_value=0, max_value=1, allow_nan=False, allow_infinity=False),
            min_size=25,
            max_size=100
        )
    )
    @settings(max_examples=100)
    def test_risk_classification_valid_indices(self, values):
        """Risk classification must produce valid indices (0-4)."""
        size = int(np.sqrt(len(values)))
        if size < 2:
            return
        
        vulnerability = np.array(values[:size*size]).reshape((size, size))
        
        classification = classify_risk_level(vulnerability)
        
        assert np.all(classification >= 0)
        assert np.all(classification <= 4)
    
    def test_risk_percentages_sum_to_100(self):
        """Risk percentages must sum to 100%."""
        vulnerability = np.random.uniform(0, 1, size=(10, 10))
        classification = classify_risk_level(vulnerability)
        percentages = calculate_risk_percentages(classification)
        
        total = sum(percentages.values())
        
        assert abs(total - 100.0) < 0.001


# Property 12: Water Body Detection Consistency
# For any NDWI/MNDWI array and threshold T, a pixel SHALL be classified as
# water if and only if its index value exceeds T.

class TestWaterBodyDetectionConsistency:
    """Feature: geospatial-agent-tools, Property 12: Water Body Detection Consistency"""
    
    @given(
        threshold=st.floats(min_value=-0.5, max_value=0.5, allow_nan=False, allow_infinity=False)
    )
    @settings(max_examples=100)
    def test_water_detection_threshold_correctness(self, threshold):
        """Pixels above threshold should be water, below should not."""
        # Create arrays that will produce known NDWI values
        # NDWI = (green - nir) / (green + nir)
        green = np.array([
            [300, 100, 200],
            [150, 250, 50],
            [100, 300, 175]
        ], dtype=np.float64)
        
        nir = np.array([
            [100, 100, 200],
            [150, 50, 150],
            [300, 100, 175]
        ], dtype=np.float64)
        
        result = detect_water_bodies(green, nir, water_threshold=threshold)
        
        # Calculate expected NDWI
        expected_ndwi = (green - nir) / (green + nir)
        expected_water = expected_ndwi > threshold
        
        np.testing.assert_array_equal(result.water_mask, expected_water)
    
    def test_all_water_detection(self):
        """High green, low NIR should all be water."""
        green = np.full((10, 10), 500.0)
        nir = np.full((10, 10), 100.0)
        
        result = detect_water_bodies(green, nir, water_threshold=0.0)
        
        # NDWI = (500-100)/(500+100) = 0.67 > 0
        assert np.all(result.water_mask)
        assert result.water_percent == 100.0
    
    def test_no_water_detection(self):
        """Low green, high NIR should be no water."""
        green = np.full((10, 10), 100.0)
        nir = np.full((10, 10), 500.0)
        
        result = detect_water_bodies(green, nir, water_threshold=0.0)
        
        # NDWI = (100-500)/(100+500) = -0.67 < 0
        assert not np.any(result.water_mask)
        assert result.water_percent == 0.0


# Unit tests

class TestDetectWaterBodies:
    """Unit tests for water body detection."""
    
    def test_result_structure(self):
        """Result should have all required fields."""
        green = np.random.uniform(100, 500, size=(10, 10))
        nir = np.random.uniform(100, 500, size=(10, 10))
        
        result = detect_water_bodies(green, nir)
        
        assert isinstance(result, WaterBodyResult)
        assert result.water_mask.shape == (10, 10)
        assert 0 <= result.water_percent <= 100
        assert result.ndwi is not None
    
    def test_with_swir_uses_mndwi(self):
        """With SWIR band, should calculate MNDWI."""
        green = np.random.uniform(100, 500, size=(10, 10))
        nir = np.random.uniform(100, 500, size=(10, 10))
        swir = np.random.uniform(100, 500, size=(10, 10))
        
        result = detect_water_bodies(green, nir, swir)
        
        assert result.mndwi is not None
    
    def test_area_calculation(self):
        """Area should be calculated correctly."""
        green = np.full((10, 10), 500.0)  # All water
        nir = np.full((10, 10), 100.0)
        
        result = detect_water_bodies(green, nir, pixel_size_meters=30.0)
        
        # 100 pixels * 30^2 = 90000 sq meters
        assert result.water_area_sq_meters == 90000.0


class TestCalculateImperviousness:
    """Unit tests for imperviousness calculation."""
    
    def test_result_structure(self):
        """Result should have all required fields."""
        swir = np.random.uniform(100, 500, size=(10, 10))
        nir = np.random.uniform(100, 500, size=(10, 10))
        
        result = calculate_imperviousness(swir, nir)
        
        assert isinstance(result, ImperviousnessResult)
        assert result.impervious_mask.shape == (10, 10)
        assert 0 <= result.impervious_percent <= 100
        assert abs(result.impervious_percent + result.permeable_percent - 100.0) < 0.001
    
    def test_high_ndbi_is_impervious(self):
        """High SWIR relative to NIR should be impervious."""
        swir = np.full((10, 10), 500.0)
        nir = np.full((10, 10), 100.0)
        
        result = calculate_imperviousness(swir, nir, impervious_threshold=0.0)
        
        # NDBI = (500-100)/(500+100) = 0.67 > 0
        assert np.all(result.impervious_mask)
        assert result.impervious_percent == 100.0


class TestWaterProximity:
    """Unit tests for water proximity calculation."""
    
    def test_no_water_returns_zeros(self):
        """No water should return all zeros."""
        water_mask = np.zeros((10, 10), dtype=bool)
        
        proximity = calculate_water_proximity(water_mask)
        
        assert np.all(proximity == 0)
    
    def test_water_pixels_have_max_proximity(self):
        """Water pixels should have maximum proximity."""
        water_mask = np.zeros((10, 10), dtype=bool)
        water_mask[5, 5] = True
        
        proximity = calculate_water_proximity(water_mask, max_distance_pixels=10)
        
        assert proximity[5, 5] == 1.0
    
    def test_proximity_decreases_with_distance(self):
        """Proximity should decrease with distance from water."""
        water_mask = np.zeros((20, 20), dtype=bool)
        water_mask[10, 10] = True
        
        proximity = calculate_water_proximity(water_mask, max_distance_pixels=10)
        
        # Adjacent pixels should have high proximity
        assert proximity[10, 11] > proximity[10, 15]


class TestVulnerabilityScore:
    """Unit tests for vulnerability score calculation."""
    
    def test_all_zeros_gives_low_score(self):
        """Zero proximity and no impervious should give low score."""
        water_proximity = np.zeros((10, 10), dtype=np.float32)
        impervious_mask = np.zeros((10, 10), dtype=bool)
        vegetation_mask = np.ones((10, 10), dtype=bool)  # All vegetated
        
        score = calculate_vulnerability_score(
            water_proximity, impervious_mask, vegetation_mask
        )
        
        # Should be low but not zero (slope factor adds 0.05)
        assert np.all(score < 0.2)
    
    def test_all_high_gives_high_score(self):
        """High proximity and impervious should give high score."""
        water_proximity = np.ones((10, 10), dtype=np.float32)
        impervious_mask = np.ones((10, 10), dtype=bool)
        vegetation_mask = np.zeros((10, 10), dtype=bool)  # No vegetation
        
        score = calculate_vulnerability_score(
            water_proximity, impervious_mask, vegetation_mask
        )
        
        assert np.all(score > 0.8)
    
    def test_custom_weights(self):
        """Custom weights should affect scoring."""
        water_proximity = np.ones((10, 10), dtype=np.float32)
        impervious_mask = np.zeros((10, 10), dtype=bool)
        
        # Weight water proximity heavily
        weights = {"water_proximity": 1.0, "imperviousness": 0.0, "low_vegetation": 0.0, "slope": 0.0}
        
        score = calculate_vulnerability_score(
            water_proximity, impervious_mask, weights=weights
        )
        
        # Should be high due to water proximity
        assert np.all(score > 0.9)


class TestRiskClassification:
    """Unit tests for risk classification."""
    
    def test_very_low_risk(self):
        """Scores 0-0.2 should be very low risk."""
        vulnerability = np.array([[0.1]])
        classification = classify_risk_level(vulnerability)
        assert classification[0, 0] == 0
    
    def test_very_high_risk(self):
        """Scores 0.8-1.0 should be very high risk."""
        vulnerability = np.array([[0.9]])
        classification = classify_risk_level(vulnerability)
        assert classification[0, 0] == 4
    
    def test_edge_case_exactly_one(self):
        """Score of exactly 1.0 should be very high risk."""
        vulnerability = np.array([[1.0]])
        classification = classify_risk_level(vulnerability)
        assert classification[0, 0] == 4


class TestFloodRecommendations:
    """Unit tests for flood recommendations."""
    
    def test_high_risk_generates_urgent(self):
        """High risk should generate urgent recommendations."""
        recommendations = generate_flood_recommendations(
            water_percent=5.0,
            impervious_percent=60.0,
            high_risk_percent=40.0
        )
        
        assert any("URGENT" in r for r in recommendations)
    
    def test_high_imperviousness_recommendations(self):
        """High imperviousness should recommend green infrastructure."""
        recommendations = generate_flood_recommendations(
            water_percent=5.0,
            impervious_percent=60.0,
            high_risk_percent=10.0
        )
        
        assert any("green" in r.lower() or "permeable" in r.lower() for r in recommendations)
    
    def test_always_includes_general_recommendations(self):
        """Should always include general recommendations."""
        recommendations = generate_flood_recommendations(
            water_percent=1.0,
            impervious_percent=10.0,
            high_risk_percent=5.0
        )
        
        assert any("drainage" in r.lower() for r in recommendations)


class TestAnalyzeFloodRisk:
    """Unit tests for comprehensive flood risk analysis."""
    
    def test_result_structure(self):
        """Result should have all required fields."""
        green = np.random.uniform(100, 500, size=(20, 20))
        nir = np.random.uniform(100, 500, size=(20, 20))
        swir = np.random.uniform(100, 500, size=(20, 20))
        
        result = analyze_flood_risk(green, nir, swir)
        
        assert isinstance(result, FloodRiskResult)
        assert result.vulnerability_score.shape == (20, 20)
        assert result.risk_classification.shape == (20, 20)
        assert len(result.risk_percentages) == 5
        assert 0 <= result.mean_vulnerability <= 1
        assert len(result.recommendations) > 0
    
    def test_with_red_band(self):
        """Should work with optional red band for vegetation."""
        green = np.random.uniform(100, 500, size=(20, 20))
        nir = np.random.uniform(100, 500, size=(20, 20))
        swir = np.random.uniform(100, 500, size=(20, 20))
        red = np.random.uniform(100, 500, size=(20, 20))
        
        result = analyze_flood_risk(green, nir, swir, red)
        
        assert isinstance(result, FloodRiskResult)
    
    def test_to_dict_serialization(self):
        """Result should be JSON serializable."""
        green = np.random.uniform(100, 500, size=(10, 10))
        nir = np.random.uniform(100, 500, size=(10, 10))
        swir = np.random.uniform(100, 500, size=(10, 10))
        
        result = analyze_flood_risk(green, nir, swir)
        result_dict = result.to_dict()
        
        assert "risk_percentages" in result_dict
        assert "mean_vulnerability" in result_dict
        assert "recommendations" in result_dict


class TestColorizeRisk:
    """Unit tests for risk colorization."""
    
    def test_output_shape(self):
        """Output should be RGB with correct shape."""
        risk_class = np.array([[0, 1], [2, 3]], dtype=np.int8)
        
        rgb = colorize_risk(risk_class)
        
        assert rgb.shape == (2, 2, 3)
        assert rgb.dtype == np.uint8
    
    def test_colors_are_distinct(self):
        """Each risk level should have distinct color."""
        risk_class = np.array([[0, 1, 2, 3, 4]], dtype=np.int8)
        
        rgb = colorize_risk(risk_class)
        
        colors = [tuple(rgb[0, i]) for i in range(5)]
        assert len(set(colors)) == 5  # All unique
