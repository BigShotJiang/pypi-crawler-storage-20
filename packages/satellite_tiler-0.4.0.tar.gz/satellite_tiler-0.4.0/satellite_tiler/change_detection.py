"""Temporal change detection from satellite imagery.

This module provides functions for detecting changes between satellite
scenes over time, including vegetation change and urban expansion.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np

from satellite_tiler.indices import (
    SpectralIndex,
    IndexResult,
    calculate_ndvi,
    calculate_ndbi,
)


class ChangeCategory(Enum):
    """Change magnitude categories."""
    SIGNIFICANT_DECREASE = "significant_decrease"
    SLIGHT_DECREASE = "slight_decrease"
    NO_CHANGE = "no_change"
    SLIGHT_INCREASE = "slight_increase"
    SIGNIFICANT_INCREASE = "significant_increase"


# Default thresholds for change categorization
CHANGE_THRESHOLDS = {
    "significant": 0.2,  # |change| > 0.2 = significant
    "slight": 0.05,      # 0.05 < |change| <= 0.2 = slight
}


@dataclass
class ChangeDetectionResult:
    """Result of change detection analysis.
    
    Attributes:
        difference: Raw difference values (after - before)
        change_category: Categorized change map
        category_percentages: Percentage of each change category
        total_changed_percent: Total percentage of changed area
        mean_change: Mean change value
        change_histogram: Count of pixels in each category
        before_date: Date of before scene (if available)
        after_date: Date of after scene (if available)
        index_name: Name of the index used for change detection
    """
    difference: np.ndarray
    change_category: np.ndarray
    category_percentages: Dict[str, float]
    total_changed_percent: float
    mean_change: float
    change_histogram: Dict[str, int]
    before_date: Optional[str] = None
    after_date: Optional[str] = None
    index_name: str = "unknown"

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.difference.shape),
            "category_percentages": self.category_percentages,
            "total_changed_percent": self.total_changed_percent,
            "mean_change": self.mean_change,
            "change_histogram": self.change_histogram,
            "before_date": self.before_date,
            "after_date": self.after_date,
            "index_name": self.index_name,
        }


@dataclass
class UrbanExpansionResult:
    """Result of urban expansion detection.
    
    Attributes:
        new_urban_mask: Boolean mask of newly urbanized pixels
        new_urban_percent: Percentage of area that became urban
        new_urban_area_sq_meters: Area of new urban development
        urban_before_percent: Urban percentage in before scene
        urban_after_percent: Urban percentage in after scene
        expansion_direction: Primary direction of expansion
    """
    new_urban_mask: np.ndarray
    new_urban_percent: float
    new_urban_area_sq_meters: float
    urban_before_percent: float
    urban_after_percent: float
    expansion_direction: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.new_urban_mask.shape),
            "new_urban_percent": self.new_urban_percent,
            "new_urban_area_sq_meters": self.new_urban_area_sq_meters,
            "urban_before_percent": self.urban_before_percent,
            "urban_after_percent": self.urban_after_percent,
            "expansion_direction": self.expansion_direction,
        }


def categorize_change(
    difference: np.ndarray,
    thresholds: Optional[Dict[str, float]] = None,
) -> np.ndarray:
    """Categorize change values into change categories.
    
    Args:
        difference: Array of difference values (after - before)
        thresholds: Custom thresholds for categorization
    
    Returns:
        Array of category indices (0-4)
    """
    thresh = {**CHANGE_THRESHOLDS, **(thresholds or {})}
    
    # Initialize as no change
    category = np.full(difference.shape, 2, dtype=np.int8)  # NO_CHANGE
    
    # Significant decrease
    category[difference < -thresh["significant"]] = 0
    
    # Slight decrease
    category[(difference >= -thresh["significant"]) & 
             (difference < -thresh["slight"])] = 1
    
    # Slight increase
    category[(difference > thresh["slight"]) & 
             (difference <= thresh["significant"])] = 3
    
    # Significant increase
    category[difference > thresh["significant"]] = 4
    
    # Handle NaN
    category[np.isnan(difference)] = 2  # Treat as no change
    
    return category


def calculate_category_percentages(
    change_category: np.ndarray,
) -> Dict[str, float]:
    """Calculate percentage of each change category.
    
    Args:
        change_category: Array of category indices
    
    Returns:
        Dictionary mapping category names to percentages
    """
    total_pixels = change_category.size
    if total_pixels == 0:
        return {cc.value: 0.0 for cc in ChangeCategory}
    
    category_mapping = {
        0: ChangeCategory.SIGNIFICANT_DECREASE,
        1: ChangeCategory.SLIGHT_DECREASE,
        2: ChangeCategory.NO_CHANGE,
        3: ChangeCategory.SLIGHT_INCREASE,
        4: ChangeCategory.SIGNIFICANT_INCREASE,
    }
    
    percentages = {}
    for idx, cat in category_mapping.items():
        count = np.sum(change_category == idx)
        percentages[cat.value] = float(count / total_pixels * 100)
    
    return percentages


def calculate_change_histogram(
    change_category: np.ndarray,
) -> Dict[str, int]:
    """Calculate histogram of change categories.
    
    Args:
        change_category: Array of category indices
    
    Returns:
        Dictionary mapping category names to pixel counts
    """
    category_mapping = {
        0: ChangeCategory.SIGNIFICANT_DECREASE,
        1: ChangeCategory.SLIGHT_DECREASE,
        2: ChangeCategory.NO_CHANGE,
        3: ChangeCategory.SLIGHT_INCREASE,
        4: ChangeCategory.SIGNIFICANT_INCREASE,
    }
    
    histogram = {}
    for idx, cat in category_mapping.items():
        histogram[cat.value] = int(np.sum(change_category == idx))
    
    return histogram


def detect_index_change(
    index_before: np.ndarray,
    index_after: np.ndarray,
    index_name: str = "unknown",
    thresholds: Optional[Dict[str, float]] = None,
    before_date: Optional[str] = None,
    after_date: Optional[str] = None,
) -> ChangeDetectionResult:
    """Detect change in a spectral index between two dates.
    
    Args:
        index_before: Index array from earlier date
        index_after: Index array from later date
        index_name: Name of the index being compared
        thresholds: Custom thresholds for categorization
        before_date: Date string for before scene
        after_date: Date string for after scene
    
    Returns:
        ChangeDetectionResult with change analysis
    """
    # Calculate difference
    difference = index_after - index_before
    
    # Categorize changes
    change_category = categorize_change(difference, thresholds)
    
    # Calculate statistics
    category_percentages = calculate_category_percentages(change_category)
    change_histogram = calculate_change_histogram(change_category)
    
    # Calculate total changed (not NO_CHANGE)
    total_changed = 100.0 - category_percentages.get(ChangeCategory.NO_CHANGE.value, 0)
    
    # Mean change (excluding NaN)
    mean_change = float(np.nanmean(difference))
    
    return ChangeDetectionResult(
        difference=difference,
        change_category=change_category,
        category_percentages=category_percentages,
        total_changed_percent=total_changed,
        mean_change=mean_change,
        change_histogram=change_histogram,
        before_date=before_date,
        after_date=after_date,
        index_name=index_name,
    )


def detect_vegetation_change(
    nir_before: np.ndarray,
    red_before: np.ndarray,
    nir_after: np.ndarray,
    red_after: np.ndarray,
    thresholds: Optional[Dict[str, float]] = None,
    before_date: Optional[str] = None,
    after_date: Optional[str] = None,
) -> ChangeDetectionResult:
    """Detect vegetation change using NDVI.
    
    Args:
        nir_before: NIR band from earlier date
        red_before: Red band from earlier date
        nir_after: NIR band from later date
        red_after: Red band from later date
        thresholds: Custom thresholds
        before_date: Date string for before scene
        after_date: Date string for after scene
    
    Returns:
        ChangeDetectionResult for vegetation change
    """
    # Calculate NDVI for both dates
    ndvi_before = calculate_ndvi(nir_before, red_before)
    ndvi_after = calculate_ndvi(nir_after, red_after)
    
    return detect_index_change(
        ndvi_before.data,
        ndvi_after.data,
        index_name="NDVI",
        thresholds=thresholds,
        before_date=before_date,
        after_date=after_date,
    )


def detect_urban_expansion(
    nir_before: np.ndarray,
    swir_before: np.ndarray,
    nir_after: np.ndarray,
    swir_after: np.ndarray,
    urban_threshold: float = 0.0,
    pixel_size_meters: float = 30.0,
) -> UrbanExpansionResult:
    """Detect urban expansion using NDBI.
    
    New urban area is defined as pixels that are:
    - Urban in the "after" scene (NDBI > threshold)
    - NOT urban in the "before" scene (NDBI <= threshold)
    
    Args:
        nir_before: NIR band from earlier date
        swir_before: SWIR band from earlier date
        nir_after: NIR band from later date
        swir_after: SWIR band from later date
        urban_threshold: NDBI threshold for urban classification
        pixel_size_meters: Pixel size for area calculation
    
    Returns:
        UrbanExpansionResult with expansion analysis
    """
    # Calculate NDBI for both dates
    ndbi_before = calculate_ndbi(swir_before, nir_before)
    ndbi_after = calculate_ndbi(swir_after, nir_after)
    
    # Identify urban areas
    urban_before = ndbi_before.data > urban_threshold
    urban_after = ndbi_after.data > urban_threshold
    
    # New urban = urban in after AND NOT urban in before
    new_urban_mask = urban_after & ~urban_before
    
    # Calculate statistics
    valid_mask = ~np.isnan(ndbi_before.data) & ~np.isnan(ndbi_after.data)
    total_valid = np.sum(valid_mask)
    
    if total_valid == 0:
        return UrbanExpansionResult(
            new_urban_mask=new_urban_mask,
            new_urban_percent=0.0,
            new_urban_area_sq_meters=0.0,
            urban_before_percent=0.0,
            urban_after_percent=0.0,
        )
    
    new_urban_count = np.sum(new_urban_mask & valid_mask)
    urban_before_count = np.sum(urban_before & valid_mask)
    urban_after_count = np.sum(urban_after & valid_mask)
    
    new_urban_percent = float(new_urban_count / total_valid * 100)
    urban_before_percent = float(urban_before_count / total_valid * 100)
    urban_after_percent = float(urban_after_count / total_valid * 100)
    
    pixel_area = pixel_size_meters ** 2
    new_urban_area = float(new_urban_count * pixel_area)
    
    # Determine expansion direction
    expansion_direction = _determine_expansion_direction(new_urban_mask)
    
    return UrbanExpansionResult(
        new_urban_mask=new_urban_mask,
        new_urban_percent=new_urban_percent,
        new_urban_area_sq_meters=new_urban_area,
        urban_before_percent=urban_before_percent,
        urban_after_percent=urban_after_percent,
        expansion_direction=expansion_direction,
    )


def _determine_expansion_direction(new_urban_mask: np.ndarray) -> Optional[str]:
    """Determine primary direction of urban expansion.
    
    Args:
        new_urban_mask: Boolean mask of new urban pixels
    
    Returns:
        Direction string or None if no clear direction
    """
    if not np.any(new_urban_mask):
        return None
    
    rows, cols = np.where(new_urban_mask)
    if len(rows) == 0:
        return None
    
    # Calculate centroid of new urban area
    center_row = np.mean(rows)
    center_col = np.mean(cols)
    
    # Compare to image center
    img_center_row = new_urban_mask.shape[0] / 2
    img_center_col = new_urban_mask.shape[1] / 2
    
    row_diff = center_row - img_center_row
    col_diff = center_col - img_center_col
    
    # Determine primary direction
    if abs(row_diff) > abs(col_diff):
        return "south" if row_diff > 0 else "north"
    else:
        return "east" if col_diff > 0 else "west"


def get_change_colormap() -> Dict[int, Tuple[int, int, int]]:
    """Get RGB colormap for change categories.
    
    Returns:
        Dictionary mapping category index to RGB tuple
    """
    return {
        0: (139, 0, 0),      # Significant decrease - dark red
        1: (255, 165, 0),    # Slight decrease - orange
        2: (255, 255, 255),  # No change - white
        3: (144, 238, 144),  # Slight increase - light green
        4: (0, 100, 0),      # Significant increase - dark green
    }


def colorize_change(change_category: np.ndarray) -> np.ndarray:
    """Convert change category array to RGB image.
    
    Args:
        change_category: 2D array of category indices (0-4)
    
    Returns:
        3D RGB array (height, width, 3)
    """
    colormap = get_change_colormap()
    
    rgb = np.zeros((*change_category.shape, 3), dtype=np.uint8)
    
    for cat_idx, color in colormap.items():
        mask = change_category == cat_idx
        rgb[mask] = color
    
    return rgb
