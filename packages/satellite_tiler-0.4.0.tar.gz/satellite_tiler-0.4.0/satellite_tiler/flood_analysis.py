"""Flood risk analysis from satellite imagery.

This module provides functions for analyzing flood vulnerability using
water body detection, imperviousness calculation, and risk scoring.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np

from satellite_tiler.indices import (
    calculate_ndwi,
    calculate_mndwi,
    calculate_ndbi,
    IndexResult,
)


class FloodRiskLevel(Enum):
    """Flood risk classification levels."""
    VERY_LOW = "very_low"
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    VERY_HIGH = "very_high"


# Risk level thresholds (vulnerability score ranges)
RISK_THRESHOLDS = {
    FloodRiskLevel.VERY_LOW: (0.0, 0.2),
    FloodRiskLevel.LOW: (0.2, 0.4),
    FloodRiskLevel.MODERATE: (0.4, 0.6),
    FloodRiskLevel.HIGH: (0.6, 0.8),
    FloodRiskLevel.VERY_HIGH: (0.8, 1.0),
}

# Default weights for vulnerability scoring
DEFAULT_VULNERABILITY_WEIGHTS = {
    "water_proximity": 0.35,
    "imperviousness": 0.35,
    "low_vegetation": 0.20,
    "slope": 0.10,  # Not implemented without DEM, set to neutral
}


@dataclass
class WaterBodyResult:
    """Result of water body detection.
    
    Attributes:
        water_mask: Boolean mask of water pixels
        water_percent: Percentage of area covered by water
        water_area_sq_meters: Area of water in square meters
        ndwi: NDWI index result
        mndwi: MNDWI index result (if available)
    """
    water_mask: np.ndarray
    water_percent: float
    water_area_sq_meters: float
    ndwi: IndexResult
    mndwi: Optional[IndexResult] = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.water_mask.shape),
            "water_percent": self.water_percent,
            "water_area_sq_meters": self.water_area_sq_meters,
            "ndwi_stats": self.ndwi.to_dict(),
            "mndwi_stats": self.mndwi.to_dict() if self.mndwi else None,
        }


@dataclass
class ImperviousnessResult:
    """Result of imperviousness analysis.
    
    Attributes:
        impervious_mask: Boolean mask of impervious pixels
        impervious_percent: Percentage of impervious surface
        permeable_percent: Percentage of permeable surface
        impervious_area_sq_meters: Area of impervious surface
        ndbi: NDBI index result
    """
    impervious_mask: np.ndarray
    impervious_percent: float
    permeable_percent: float
    impervious_area_sq_meters: float
    ndbi: IndexResult

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.impervious_mask.shape),
            "impervious_percent": self.impervious_percent,
            "permeable_percent": self.permeable_percent,
            "impervious_area_sq_meters": self.impervious_area_sq_meters,
            "ndbi_stats": self.ndbi.to_dict(),
        }


@dataclass
class FloodRiskResult:
    """Result of flood risk analysis.
    
    Attributes:
        vulnerability_score: Per-pixel vulnerability scores (0-1)
        risk_classification: Per-pixel risk level classification
        risk_percentages: Percentage of each risk level
        mean_vulnerability: Mean vulnerability score
        high_risk_percent: Percentage of high/very high risk area
        water_bodies: Water body detection result
        imperviousness: Imperviousness analysis result
        recommendations: List of flood mitigation recommendations
    """
    vulnerability_score: np.ndarray
    risk_classification: np.ndarray
    risk_percentages: Dict[str, float]
    mean_vulnerability: float
    high_risk_percent: float
    water_bodies: WaterBodyResult
    imperviousness: ImperviousnessResult
    recommendations: List[str]

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.vulnerability_score.shape),
            "risk_percentages": self.risk_percentages,
            "mean_vulnerability": self.mean_vulnerability,
            "high_risk_percent": self.high_risk_percent,
            "water_bodies": self.water_bodies.to_dict(),
            "imperviousness": self.imperviousness.to_dict(),
            "recommendations": self.recommendations,
        }


def detect_water_bodies(
    green: np.ndarray,
    nir: np.ndarray,
    swir: Optional[np.ndarray] = None,
    water_threshold: float = 0.0,
    pixel_size_meters: float = 30.0,
) -> WaterBodyResult:
    """Detect water bodies using NDWI and optionally MNDWI.
    
    Args:
        green: Green band array
        nir: Near-infrared band array
        swir: Short-wave infrared band array (optional, for MNDWI)
        water_threshold: NDWI threshold for water classification
        pixel_size_meters: Pixel size for area calculation
    
    Returns:
        WaterBodyResult with water detection analysis
    """
    # Calculate NDWI
    ndwi_result = calculate_ndwi(green, nir)
    
    # Calculate MNDWI if SWIR available
    mndwi_result = None
    if swir is not None:
        mndwi_result = calculate_mndwi(green, swir)
        # Use MNDWI for water detection (better urban/water separation)
        water_mask = mndwi_result.data > water_threshold
    else:
        water_mask = ndwi_result.data > water_threshold
    
    # Handle NaN
    water_mask = water_mask & ~np.isnan(ndwi_result.data)
    
    # Calculate statistics
    total_valid = np.sum(~np.isnan(ndwi_result.data))
    water_count = np.sum(water_mask)
    
    water_percent = float(water_count / total_valid * 100) if total_valid > 0 else 0.0
    water_area = float(water_count * pixel_size_meters ** 2)
    
    return WaterBodyResult(
        water_mask=water_mask,
        water_percent=water_percent,
        water_area_sq_meters=water_area,
        ndwi=ndwi_result,
        mndwi=mndwi_result,
    )


def calculate_imperviousness(
    swir: np.ndarray,
    nir: np.ndarray,
    impervious_threshold: float = 0.0,
    pixel_size_meters: float = 30.0,
) -> ImperviousnessResult:
    """Calculate imperviousness using NDBI.
    
    Args:
        swir: Short-wave infrared band array
        nir: Near-infrared band array
        impervious_threshold: NDBI threshold for impervious classification
        pixel_size_meters: Pixel size for area calculation
    
    Returns:
        ImperviousnessResult with imperviousness analysis
    """
    # Calculate NDBI
    ndbi_result = calculate_ndbi(swir, nir)
    
    # Classify impervious surfaces
    impervious_mask = ndbi_result.data > impervious_threshold
    impervious_mask = impervious_mask & ~np.isnan(ndbi_result.data)
    
    # Calculate statistics
    total_valid = np.sum(~np.isnan(ndbi_result.data))
    impervious_count = np.sum(impervious_mask)
    
    impervious_percent = float(impervious_count / total_valid * 100) if total_valid > 0 else 0.0
    permeable_percent = 100.0 - impervious_percent
    impervious_area = float(impervious_count * pixel_size_meters ** 2)
    
    return ImperviousnessResult(
        impervious_mask=impervious_mask,
        impervious_percent=impervious_percent,
        permeable_percent=permeable_percent,
        impervious_area_sq_meters=impervious_area,
        ndbi=ndbi_result,
    )


def calculate_water_proximity(
    water_mask: np.ndarray,
    max_distance_pixels: int = 50,
) -> np.ndarray:
    """Calculate proximity to water bodies.
    
    Returns a normalized distance array where:
    - 1.0 = water pixel or immediately adjacent
    - 0.0 = at or beyond max_distance_pixels
    
    Args:
        water_mask: Boolean mask of water pixels
        max_distance_pixels: Maximum distance to consider
    
    Returns:
        Normalized proximity array (0-1, higher = closer to water)
    """
    if not np.any(water_mask):
        return np.zeros_like(water_mask, dtype=np.float32)
    
    # Simple distance calculation using iterative dilation
    distance = np.zeros_like(water_mask, dtype=np.float32)
    distance[water_mask] = max_distance_pixels
    
    # Iterative distance propagation (simplified)
    current = water_mask.copy()
    for d in range(1, max_distance_pixels + 1):
        # Dilate current mask
        dilated = np.zeros_like(current)
        dilated[1:, :] |= current[:-1, :]
        dilated[:-1, :] |= current[1:, :]
        dilated[:, 1:] |= current[:, :-1]
        dilated[:, :-1] |= current[:, 1:]
        
        # Update distance for newly reached pixels
        new_pixels = dilated & ~current & (distance == 0)
        distance[new_pixels] = max_distance_pixels - d
        current = dilated
    
    # Normalize to 0-1
    proximity = distance / max_distance_pixels
    
    return proximity


def calculate_vulnerability_score(
    water_proximity: np.ndarray,
    impervious_mask: np.ndarray,
    vegetation_mask: Optional[np.ndarray] = None,
    weights: Optional[Dict[str, float]] = None,
) -> np.ndarray:
    """Calculate flood vulnerability score.
    
    Combines multiple factors into a single vulnerability score (0-1).
    
    Args:
        water_proximity: Normalized water proximity (0-1)
        impervious_mask: Boolean mask of impervious surfaces
        vegetation_mask: Boolean mask of vegetated areas (optional)
        weights: Custom weights for factors
    
    Returns:
        Vulnerability score array (0-1, higher = more vulnerable)
    """
    w = {**DEFAULT_VULNERABILITY_WEIGHTS, **(weights or {})}
    
    # Normalize weights
    total_weight = sum(w.values())
    w = {k: v / total_weight for k, v in w.items()}
    
    # Initialize score
    score = np.zeros_like(water_proximity, dtype=np.float32)
    
    # Water proximity factor (already 0-1)
    score += w["water_proximity"] * water_proximity
    
    # Imperviousness factor (binary -> 0 or 1)
    score += w["imperviousness"] * impervious_mask.astype(np.float32)
    
    # Low vegetation factor (inverse of vegetation)
    if vegetation_mask is not None:
        low_veg = ~vegetation_mask
        score += w["low_vegetation"] * low_veg.astype(np.float32)
    else:
        # Assume moderate vegetation if not provided
        score += w["low_vegetation"] * 0.5
    
    # Slope factor (neutral without DEM)
    score += w["slope"] * 0.5
    
    # Clip to 0-1 range
    score = np.clip(score, 0.0, 1.0)
    
    return score


def classify_risk_level(vulnerability_score: np.ndarray) -> np.ndarray:
    """Classify vulnerability scores into risk levels.
    
    Args:
        vulnerability_score: Vulnerability score array (0-1)
    
    Returns:
        Array of risk level indices (0-4)
    """
    classification = np.zeros_like(vulnerability_score, dtype=np.int8)
    
    for i, (level, (low, high)) in enumerate(RISK_THRESHOLDS.items()):
        mask = (vulnerability_score >= low) & (vulnerability_score < high)
        classification[mask] = i
    
    # Handle edge case of exactly 1.0
    classification[vulnerability_score >= 1.0] = 4
    
    return classification


def calculate_risk_percentages(risk_classification: np.ndarray) -> Dict[str, float]:
    """Calculate percentage of each risk level.
    
    Args:
        risk_classification: Array of risk level indices
    
    Returns:
        Dictionary mapping risk level names to percentages
    """
    total_pixels = risk_classification.size
    if total_pixels == 0:
        return {level.value: 0.0 for level in FloodRiskLevel}
    
    percentages = {}
    for i, level in enumerate(FloodRiskLevel):
        count = np.sum(risk_classification == i)
        percentages[level.value] = float(count / total_pixels * 100)
    
    return percentages


def generate_flood_recommendations(
    water_percent: float,
    impervious_percent: float,
    high_risk_percent: float,
) -> List[str]:
    """Generate flood mitigation recommendations.
    
    Args:
        water_percent: Percentage of water bodies
        impervious_percent: Percentage of impervious surface
        high_risk_percent: Percentage of high/very high risk area
    
    Returns:
        List of recommendation strings
    """
    recommendations = []
    
    if high_risk_percent > 30:
        recommendations.append("URGENT: Implement comprehensive flood management plan")
        recommendations.append("Consider flood barriers and retention systems")
    
    if impervious_percent > 50:
        recommendations.append("Reduce impervious surface coverage through green infrastructure")
        recommendations.append("Install permeable pavement in parking areas")
        recommendations.append("Create bioswales and rain gardens")
    
    if impervious_percent > 30:
        recommendations.append("Increase green space and tree canopy")
        recommendations.append("Implement stormwater retention ponds")
    
    if water_percent > 10:
        recommendations.append("Establish buffer zones around water bodies")
        recommendations.append("Restrict development in flood-prone areas")
    
    # General recommendations
    recommendations.append("Maintain and improve drainage infrastructure")
    recommendations.append("Develop early warning systems for flood events")
    
    return recommendations


def analyze_flood_risk(
    green: np.ndarray,
    nir: np.ndarray,
    swir: np.ndarray,
    red: Optional[np.ndarray] = None,
    pixel_size_meters: float = 30.0,
    weights: Optional[Dict[str, float]] = None,
) -> FloodRiskResult:
    """Perform comprehensive flood risk analysis.
    
    Args:
        green: Green band array
        nir: Near-infrared band array
        swir: Short-wave infrared band array
        red: Red band array (optional, for vegetation mask)
        pixel_size_meters: Pixel size for area calculation
        weights: Custom vulnerability weights
    
    Returns:
        FloodRiskResult with complete flood risk analysis
    """
    # Detect water bodies
    water_result = detect_water_bodies(
        green, nir, swir,
        pixel_size_meters=pixel_size_meters
    )
    
    # Calculate imperviousness
    imperv_result = calculate_imperviousness(
        swir, nir,
        pixel_size_meters=pixel_size_meters
    )
    
    # Calculate water proximity
    water_proximity = calculate_water_proximity(water_result.water_mask)
    
    # Create vegetation mask if red band available
    vegetation_mask = None
    if red is not None:
        from satellite_tiler.indices import calculate_ndvi
        ndvi_result = calculate_ndvi(nir, red)
        vegetation_mask = ndvi_result.data > 0.3
    
    # Calculate vulnerability score
    vulnerability = calculate_vulnerability_score(
        water_proximity,
        imperv_result.impervious_mask,
        vegetation_mask,
        weights
    )
    
    # Classify risk levels
    risk_class = classify_risk_level(vulnerability)
    risk_percentages = calculate_risk_percentages(risk_class)
    
    # Calculate summary statistics
    mean_vulnerability = float(np.nanmean(vulnerability))
    high_risk_percent = (
        risk_percentages.get(FloodRiskLevel.HIGH.value, 0) +
        risk_percentages.get(FloodRiskLevel.VERY_HIGH.value, 0)
    )
    
    # Generate recommendations
    recommendations = generate_flood_recommendations(
        water_result.water_percent,
        imperv_result.impervious_percent,
        high_risk_percent
    )
    
    return FloodRiskResult(
        vulnerability_score=vulnerability,
        risk_classification=risk_class,
        risk_percentages=risk_percentages,
        mean_vulnerability=mean_vulnerability,
        high_risk_percent=high_risk_percent,
        water_bodies=water_result,
        imperviousness=imperv_result,
        recommendations=recommendations,
    )


def get_risk_colormap() -> Dict[int, Tuple[int, int, int]]:
    """Get RGB colormap for flood risk levels.
    
    Returns:
        Dictionary mapping risk level index to RGB tuple
    """
    return {
        0: (0, 128, 0),      # Very low - green
        1: (144, 238, 144),  # Low - light green
        2: (255, 255, 0),    # Moderate - yellow
        3: (255, 165, 0),    # High - orange
        4: (255, 0, 0),      # Very high - red
    }


def colorize_risk(risk_classification: np.ndarray) -> np.ndarray:
    """Convert risk classification to RGB image.
    
    Args:
        risk_classification: 2D array of risk level indices (0-4)
    
    Returns:
        3D RGB array (height, width, 3)
    """
    colormap = get_risk_colormap()
    
    rgb = np.zeros((*risk_classification.shape, 3), dtype=np.uint8)
    
    for risk_idx, color in colormap.items():
        mask = risk_classification == risk_idx
        rgb[mask] = color
    
    return rgb
