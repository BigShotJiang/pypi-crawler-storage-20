"""Scene ID parsers for satellite-tiler.

This module provides functions for parsing and formatting scene identifiers
for different satellite platforms (Landsat, Sentinel-2, CBERS).
"""

import re
from datetime import date
from typing import Union

from satellite_tiler.models import (
    SatellitePlatform,
    LandsatSceneComponents,
    Sentinel2SceneComponents,
    CBERSSceneComponents,
    SceneComponents,
)
from satellite_tiler.exceptions import InvalidSceneIdError


# Regex patterns for scene ID parsing

# Landsat Collection 2 format: LC08_L1TP_014032_20240615_20240620_02_T1 or LC08_L2SP_089079_20251224_02_T1
LANDSAT_PATTERN = re.compile(
    r"^(?P<sensor>L[COTEM]\d{2})_"
    r"(?P<processing_level>L\d[A-Z]{2})_"
    r"(?P<path>\d{3})(?P<row>\d{3})_"
    r"(?P<acq_year>\d{4})(?P<acq_month>\d{2})(?P<acq_day>\d{2})_"
    r"(?:(?P<proc_year>\d{4})(?P<proc_month>\d{2})(?P<proc_day>\d{2})_)?"
    r"(?P<collection>\d{2})_"
    r"(?P<tier>T\d|RT)$"
)

# Sentinel-2 format: S2A_MSIL2A_20240615T154911_N0510_R054_T18TXM_20240615T213159
SENTINEL2_PATTERN = re.compile(
    r"^(?P<satellite>S2[AB])_"
    r"(?P<product_level>MSIL\d[ABC])_"
    r"(?P<acquisition_datetime>\d{8}T\d{6})_"
    r"(?P<processing_baseline>N\d{4})_"
    r"(?P<relative_orbit>R\d{3})_"
    r"(?P<tile_id>T\d{2}[A-Z]{3})_"
    r"(?P<product_discriminator>\d{8}T\d{6})$"
)

# STAC-style Sentinel-2 format: S2B_56JNQ_20260109_0_L2A
SENTINEL2_STAC_PATTERN = re.compile(
    r"^(?P<satellite>S2[AB])_"
    r"(?P<tile_id>\d{2}[A-Z]{3})_"
    r"(?P<acq_year>\d{4})(?P<acq_month>\d{2})(?P<acq_day>\d{2})_"
    r"(?P<sequence>\d+)_"
    r"(?P<product_level>L\d[ABC])$"
)

# CBERS format: CBERS_4_MUX_20240615_178_106_L4
# Camera types: MUX, AWFI, PAN5M, PAN10M, IRS, WFI, WPM
CBERS_PATTERN = re.compile(
    r"^(?P<satellite>CBERS_\d)_"
    r"(?P<camera>[A-Z0-9]+)_"
    r"(?P<year>\d{4})(?P<month>\d{2})(?P<day>\d{2})_"
    r"(?P<path>\d{3})_"
    r"(?P<row>\d{3})_"
    r"(?P<processing_level>L\d)$"
)


def detect_platform(scene_id: str) -> SatellitePlatform:
    """Detect which satellite platform a scene ID belongs to.
    
    Args:
        scene_id: Scene identifier string
    
    Returns:
        SatellitePlatform enum value
    
    Raises:
        InvalidSceneIdError: If scene ID doesn't match any known format
    
    Example:
        >>> detect_platform("LC08_L1TP_014032_20240615_20240620_02_T1")
        SatellitePlatform.LANDSAT8
    """
    if LANDSAT_PATTERN.match(scene_id):
        return SatellitePlatform.LANDSAT8
    elif SENTINEL2_PATTERN.match(scene_id) or SENTINEL2_STAC_PATTERN.match(scene_id):
        return SatellitePlatform.SENTINEL2
    elif CBERS_PATTERN.match(scene_id):
        return SatellitePlatform.CBERS
    else:
        raise InvalidSceneIdError(
            scene_id,
            "Landsat (LC08_L1TP_...), Sentinel-2 (S2A_MSIL2A_... or S2A_56JNQ_...), or CBERS (CBERS_4_...)"
        )


def parse_landsat(scene_id: str) -> LandsatSceneComponents:
    """Parse a Landsat scene identifier.
    
    Args:
        scene_id: Landsat scene ID (e.g., "LC08_L1TP_014032_20240615_20240620_02_T1")
    
    Returns:
        LandsatSceneComponents with parsed fields
    
    Raises:
        InvalidSceneIdError: If scene ID doesn't match Landsat format
    """
    match = LANDSAT_PATTERN.match(scene_id)
    if not match:
        raise InvalidSceneIdError(
            scene_id,
            "Landsat format: LC08_L1TP_PPPRRR_YYYYMMDD_CC_TX or LC08_L1TP_PPPRRR_YYYYMMDD_YYYYMMDD_CC_TX"
        )
    
    groups = match.groupdict()
    
    acq_date = date(
        int(groups["acq_year"]),
        int(groups["acq_month"]),
        int(groups["acq_day"])
    )
    
    # Processing date is optional (not present in some formats)
    if groups.get("proc_year"):
        proc_date = date(
            int(groups["proc_year"]),
            int(groups["proc_month"]),
            int(groups["proc_day"])
        )
    else:
        proc_date = acq_date
    
    return LandsatSceneComponents(
        sensor=groups["sensor"],
        processing_level=groups["processing_level"],
        path=int(groups["path"]),
        row=int(groups["row"]),
        acquisition_date=acq_date,
        processing_date=proc_date,
        collection=int(groups["collection"]),
        tier=groups["tier"],
    )


def format_landsat(components: LandsatSceneComponents) -> str:
    """Format Landsat scene components back to a scene ID string.
    
    Args:
        components: LandsatSceneComponents object
    
    Returns:
        Scene ID string
    
    Example:
        >>> components = LandsatSceneComponents(...)
        >>> format_landsat(components)
        "LC08_L1TP_014032_20240615_20240620_02_T1"
    """
    return (
        f"{components.sensor}_"
        f"{components.processing_level}_"
        f"{components.path:03d}{components.row:03d}_"
        f"{components.acquisition_date.strftime('%Y%m%d')}_"
        f"{components.processing_date.strftime('%Y%m%d')}_"
        f"{components.collection:02d}_"
        f"{components.tier}"
    )


def parse_sentinel2(scene_id: str) -> Sentinel2SceneComponents:
    """Parse a Sentinel-2 scene identifier.
    
    Supports both standard ESA format and STAC-style format.
    
    Args:
        scene_id: Sentinel-2 scene ID 
                  (e.g., "S2A_MSIL2A_20240615T154911_N0510_R054_T18TXM_20240615T213159"
                   or "S2B_56JNQ_20260109_0_L2A")
    
    Returns:
        Sentinel2SceneComponents with parsed fields
    
    Raises:
        InvalidSceneIdError: If scene ID doesn't match Sentinel-2 format
    """
    # Try standard ESA format first
    match = SENTINEL2_PATTERN.match(scene_id)
    if match:
        groups = match.groupdict()
        return Sentinel2SceneComponents(
            satellite=groups["satellite"],
            product_level=groups["product_level"],
            acquisition_datetime=groups["acquisition_datetime"],
            processing_baseline=groups["processing_baseline"],
            relative_orbit=groups["relative_orbit"],
            tile_id=groups["tile_id"],
            product_discriminator=groups["product_discriminator"],
        )
    
    # Try STAC-style format
    match = SENTINEL2_STAC_PATTERN.match(scene_id)
    if match:
        groups = match.groupdict()
        # Convert to standard format components
        acq_date = f"{groups['acq_year']}{groups['acq_month']}{groups['acq_day']}T000000"
        return Sentinel2SceneComponents(
            satellite=groups["satellite"],
            product_level=f"MSI{groups['product_level']}",  # Convert L2A -> MSIL2A
            acquisition_datetime=acq_date,
            processing_baseline="N0000",  # Not available in STAC format
            relative_orbit="R000",  # Not available in STAC format
            tile_id=f"T{groups['tile_id']}",  # Add T prefix
            product_discriminator=acq_date,
        )
    
    raise InvalidSceneIdError(
        scene_id,
        "Sentinel-2 format: S2X_MSILXX_YYYYMMDDTHHMMSS_NXXXX_RXXX_TXXXXX_YYYYMMDDTHHMMSS "
        "or S2X_XXXXX_YYYYMMDD_X_LXX (e.g., S2A_MSIL2A_20240615T154911_N0510_R054_T18TXM_20240615T213159 "
        "or S2B_56JNQ_20260109_0_L2A)"
    )


def format_sentinel2(components: Sentinel2SceneComponents) -> str:
    """Format Sentinel-2 scene components back to a scene ID string.
    
    Args:
        components: Sentinel2SceneComponents object
    
    Returns:
        Scene ID string
    """
    return (
        f"{components.satellite}_"
        f"{components.product_level}_"
        f"{components.acquisition_datetime}_"
        f"{components.processing_baseline}_"
        f"{components.relative_orbit}_"
        f"{components.tile_id}_"
        f"{components.product_discriminator}"
    )


def parse_cbers(scene_id: str) -> CBERSSceneComponents:
    """Parse a CBERS scene identifier.
    
    Args:
        scene_id: CBERS scene ID (e.g., "CBERS_4_MUX_20240615_178_106_L4")
    
    Returns:
        CBERSSceneComponents with parsed fields
    
    Raises:
        InvalidSceneIdError: If scene ID doesn't match CBERS format
    """
    match = CBERS_PATTERN.match(scene_id)
    if not match:
        raise InvalidSceneIdError(
            scene_id,
            "CBERS format: CBERS_X_CAM_YYYYMMDD_PPP_RRR_LX "
            "(e.g., CBERS_4_MUX_20240615_178_106_L4)"
        )
    
    groups = match.groupdict()
    
    return CBERSSceneComponents(
        satellite=groups["satellite"],
        camera=groups["camera"],
        acquisition_date=date(
            int(groups["year"]),
            int(groups["month"]),
            int(groups["day"])
        ),
        path=int(groups["path"]),
        row=int(groups["row"]),
        processing_level=groups["processing_level"],
    )


def format_cbers(components: CBERSSceneComponents) -> str:
    """Format CBERS scene components back to a scene ID string.
    
    Args:
        components: CBERSSceneComponents object
    
    Returns:
        Scene ID string
    """
    return (
        f"{components.satellite}_"
        f"{components.camera}_"
        f"{components.acquisition_date.strftime('%Y%m%d')}_"
        f"{components.path:03d}_"
        f"{components.row:03d}_"
        f"{components.processing_level}"
    )


def parse(scene_id: str) -> SceneComponents:
    """Parse a scene identifier from any supported platform.
    
    Automatically detects the platform and parses accordingly.
    
    Args:
        scene_id: Scene identifier string
    
    Returns:
        Appropriate scene components dataclass
    
    Raises:
        InvalidSceneIdError: If scene ID doesn't match any known format
    
    Example:
        >>> components = parse("LC08_L1TP_014032_20240615_20240620_02_T1")
        >>> isinstance(components, LandsatSceneComponents)
        True
    """
    platform = detect_platform(scene_id)
    
    if platform == SatellitePlatform.LANDSAT8:
        return parse_landsat(scene_id)
    elif platform == SatellitePlatform.SENTINEL2:
        return parse_sentinel2(scene_id)
    elif platform == SatellitePlatform.CBERS:
        return parse_cbers(scene_id)
    else:
        raise InvalidSceneIdError(scene_id, "Unknown platform")


def format_scene_id(components: SceneComponents) -> str:
    """Format scene components back to a scene ID string.
    
    Args:
        components: Scene components dataclass
    
    Returns:
        Scene ID string
    
    Example:
        >>> components = parse("LC08_L1TP_014032_20240615_20240620_02_T1")
        >>> format_scene_id(components)
        "LC08_L1TP_014032_20240615_20240620_02_T1"
    """
    if isinstance(components, LandsatSceneComponents):
        return format_landsat(components)
    elif isinstance(components, Sentinel2SceneComponents):
        return format_sentinel2(components)
    elif isinstance(components, CBERSSceneComponents):
        return format_cbers(components)
    else:
        raise TypeError(f"Unknown component type: {type(components)}")
