"""Air quality proxy analysis from satellite imagery.

This module provides functions for estimating air quality risk using
vegetation coverage and built-up area indicators as proxies.

Note: This is a proxy-based analysis. Actual air quality measurements
require ground-based sensors or specialized atmospheric satellites.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional

import numpy as np

from satellite_tiler.indices import (
    calculate_ndvi,
    calculate_ndbi,
    IndexResult,
)


class AirQualityRisk(Enum):
    """Air quality risk classification levels."""
    GOOD = "good"
    MODERATE = "moderate"
    UNHEALTHY_SENSITIVE = "unhealthy_for_sensitive"
    UNHEALTHY = "unhealthy"
    VERY_UNHEALTHY = "very_unhealthy"


# Risk thresholds based on combined score (0-1)
AIR_QUALITY_THRESHOLDS = {
    AirQualityRisk.GOOD: (0.0, 0.2),
    AirQualityRisk.MODERATE: (0.2, 0.4),
    AirQualityRisk.UNHEALTHY_SENSITIVE: (0.4, 0.6),
    AirQualityRisk.UNHEALTHY: (0.6, 0.8),
    AirQualityRisk.VERY_UNHEALTHY: (0.8, 1.0),
}

# Default weights for air quality scoring
DEFAULT_AIR_QUALITY_WEIGHTS = {
    "low_vegetation": 0.4,
    "built_up": 0.4,
    "bare_soil": 0.2,
}


@dataclass
class AirQualityResult:
    """Result of air quality proxy analysis.
    
    Attributes:
        risk_score: Per-pixel risk scores (0-1, higher = worse)
        risk_classification: Per-pixel risk level classification
        risk_percentages: Percentage of each risk level
        mean_risk_score: Mean risk score
        vegetation_percent: Percentage of vegetated area
        built_up_percent: Percentage of built-up area
        ndvi: NDVI index result
        ndbi: NDBI index result
        recommendations: List of air quality improvement recommendations
    """
    risk_score: np.ndarray
    risk_classification: np.ndarray
    risk_percentages: Dict[str, float]
    mean_risk_score: float
    vegetation_percent: float
    built_up_percent: float
    ndvi: IndexResult
    ndbi: IndexResult
    recommendations: List[str]

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "shape": list(self.risk_score.shape),
            "risk_percentages": self.risk_percentages,
            "mean_risk_score": self.mean_risk_score,
            "vegetation_percent": self.vegetation_percent,
            "built_up_percent": self.built_up_percent,
            "ndvi_stats": self.ndvi.to_dict(),
            "ndbi_stats": self.ndbi.to_dict(),
            "recommendations": self.recommendations,
        }


def calculate_air_quality_score(
    ndvi_data: np.ndarray,
    ndbi_data: np.ndarray,
    weights: Optional[Dict[str, float]] = None,
) -> np.ndarray:
    """Calculate air quality risk score from vegetation and built-up indices.
    
    Higher scores indicate worse air quality (more risk).
    
    Args:
        ndvi_data: NDVI values array
        ndbi_data: NDBI values array
        weights: Custom weights for factors
    
    Returns:
        Risk score array (0-1, higher = worse air quality)
    """
    w = {**DEFAULT_AIR_QUALITY_WEIGHTS, **(weights or {})}
    
    # Normalize weights
    total_weight = sum(w.values())
    w = {k: v / total_weight for k, v in w.items()}
    
    # Initialize score
    score = np.zeros_like(ndvi_data, dtype=np.float32)
    
    # Low vegetation factor (inverse of NDVI, normalized)
    # NDVI ranges from -1 to 1, normalize to 0-1 where low veg = high score
    low_veg = (1 - ndvi_data) / 2  # Maps [-1,1] to [1,0]
    low_veg = np.clip(low_veg, 0, 1)
    score += w["low_vegetation"] * low_veg
    
    # Built-up factor (NDBI normalized)
    # NDBI ranges from -1 to 1, normalize to 0-1 where high built-up = high score
    built_up = (ndbi_data + 1) / 2  # Maps [-1,1] to [0,1]
    built_up = np.clip(built_up, 0, 1)
    score += w["built_up"] * built_up
    
    # Bare soil factor (low NDVI and low NDBI)
    # Areas with neither vegetation nor built-up (dust sources)
    bare_soil = ((ndvi_data < 0.2) & (ndbi_data < 0.0)).astype(np.float32)
    score += w["bare_soil"] * bare_soil
    
    # Clip to 0-1 range
    score = np.clip(score, 0.0, 1.0)
    
    return score


def classify_air_quality_risk(risk_score: np.ndarray) -> np.ndarray:
    """Classify risk scores into air quality risk levels.
    
    Args:
        risk_score: Risk score array (0-1)
    
    Returns:
        Array of risk level indices (0-4)
    """
    classification = np.zeros_like(risk_score, dtype=np.int8)
    
    for i, (level, (low, high)) in enumerate(AIR_QUALITY_THRESHOLDS.items()):
        mask = (risk_score >= low) & (risk_score < high)
        classification[mask] = i
    
    # Handle edge case of exactly 1.0
    classification[risk_score >= 1.0] = 4
    
    return classification


def calculate_air_quality_percentages(risk_classification: np.ndarray) -> Dict[str, float]:
    """Calculate percentage of each air quality risk level.
    
    Args:
        risk_classification: Array of risk level indices
    
    Returns:
        Dictionary mapping risk level names to percentages
    """
    total_pixels = risk_classification.size
    if total_pixels == 0:
        return {level.value: 0.0 for level in AirQualityRisk}
    
    percentages = {}
    for i, level in enumerate(AirQualityRisk):
        count = np.sum(risk_classification == i)
        percentages[level.value] = float(count / total_pixels * 100)
    
    return percentages


def generate_air_quality_recommendations(
    vegetation_percent: float,
    built_up_percent: float,
    mean_risk_score: float,
) -> List[str]:
    """Generate air quality improvement recommendations.
    
    Args:
        vegetation_percent: Percentage of vegetated area
        built_up_percent: Percentage of built-up area
        mean_risk_score: Mean risk score (0-1)
    
    Returns:
        List of recommendation strings
    """
    recommendations = []
    
    if mean_risk_score > 0.6:
        recommendations.append("PRIORITY: Implement air quality monitoring stations")
        recommendations.append("Consider traffic management and emission controls")
    
    if vegetation_percent < 20:
        recommendations.append("Increase urban tree canopy to filter particulates")
        recommendations.append("Create green corridors along major roads")
        recommendations.append("Plant pollution-tolerant species in high-traffic areas")
    
    if vegetation_percent < 40:
        recommendations.append("Expand green spaces and parks")
        recommendations.append("Implement green roof programs")
    
    if built_up_percent > 60:
        recommendations.append("Promote green building standards")
        recommendations.append("Encourage use of low-emission vehicles")
    
    if built_up_percent > 40:
        recommendations.append("Create buffer zones between industrial and residential areas")
    
    # General recommendations
    recommendations.append("Monitor air quality during high-risk periods")
    recommendations.append("Educate public about air quality and health impacts")
    
    return recommendations


def analyze_air_quality(
    nir: np.ndarray,
    red: np.ndarray,
    swir: np.ndarray,
    weights: Optional[Dict[str, float]] = None,
) -> AirQualityResult:
    """Perform air quality proxy analysis.
    
    Uses vegetation (NDVI) and built-up (NDBI) indices as proxies
    for air quality risk assessment.
    
    Args:
        nir: Near-infrared band array
        red: Red band array
        swir: Short-wave infrared band array
        weights: Custom weights for risk factors
    
    Returns:
        AirQualityResult with complete analysis
    """
    # Calculate indices
    ndvi_result = calculate_ndvi(nir, red)
    ndbi_result = calculate_ndbi(swir, nir)
    
    # Calculate risk score
    risk_score = calculate_air_quality_score(
        ndvi_result.data,
        ndbi_result.data,
        weights
    )
    
    # Classify risk levels
    risk_class = classify_air_quality_risk(risk_score)
    risk_percentages = calculate_air_quality_percentages(risk_class)
    
    # Calculate vegetation and built-up percentages
    valid_mask = ~np.isnan(ndvi_result.data)
    total_valid = np.sum(valid_mask)
    
    if total_valid > 0:
        vegetation_percent = float(np.sum(ndvi_result.data[valid_mask] > 0.3) / total_valid * 100)
        built_up_percent = float(np.sum(ndbi_result.data[valid_mask] > 0.0) / total_valid * 100)
    else:
        vegetation_percent = 0.0
        built_up_percent = 0.0
    
    # Calculate mean risk score
    mean_risk_score = float(np.nanmean(risk_score))
    
    # Generate recommendations
    recommendations = generate_air_quality_recommendations(
        vegetation_percent,
        built_up_percent,
        mean_risk_score
    )
    
    return AirQualityResult(
        risk_score=risk_score,
        risk_classification=risk_class,
        risk_percentages=risk_percentages,
        mean_risk_score=mean_risk_score,
        vegetation_percent=vegetation_percent,
        built_up_percent=built_up_percent,
        ndvi=ndvi_result,
        ndbi=ndbi_result,
        recommendations=recommendations,
    )


def get_air_quality_colormap() -> Dict[int, tuple]:
    """Get RGB colormap for air quality risk levels.
    
    Returns:
        Dictionary mapping risk level index to RGB tuple
    """
    return {
        0: (0, 228, 0),      # Good - green
        1: (255, 255, 0),    # Moderate - yellow
        2: (255, 126, 0),    # Unhealthy for sensitive - orange
        3: (255, 0, 0),      # Unhealthy - red
        4: (153, 0, 76),     # Very unhealthy - purple
    }


def colorize_air_quality(risk_classification: np.ndarray) -> np.ndarray:
    """Convert air quality classification to RGB image.
    
    Args:
        risk_classification: 2D array of risk level indices (0-4)
    
    Returns:
        3D RGB array (height, width, 3)
    """
    colormap = get_air_quality_colormap()
    
    rgb = np.zeros((*risk_classification.shape, 3), dtype=np.uint8)
    
    for risk_idx, color in colormap.items():
        mask = risk_classification == risk_idx
        rgb[mask] = color
    
    return rgb
