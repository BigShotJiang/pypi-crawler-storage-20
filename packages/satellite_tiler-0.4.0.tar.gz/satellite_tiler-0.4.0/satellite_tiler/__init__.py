"""
satellite-tiler: A Python library for accessing open-source satellite imagery.

This library provides a simple API for discovering and fetching satellite tiles
from AWS-hosted data sources including Landsat 8, Sentinel-2, and CBERS.

Basic Usage:
    >>> from satellite_tiler import discover, list_scenes, get_tile
    >>> 
    >>> # Step 1: Discover available missions at a location
    >>> missions = discover(lat=40.7128, lon=-74.0060)
    >>> 
    >>> # Step 2: List available scenes
    >>> scenes = list_scenes(lat=40.7128, lon=-74.0060, 
    ...                      platform=SatellitePlatform.LANDSAT8,
    ...                      max_cloud_cover=20)
    >>> 
    >>> # Step 3: Fetch a tile
    >>> result = get_tile(scene_id=scenes[0].scene_id,
    ...                   lat=40.7128, lon=-74.0060, zoom=12,
    ...                   bands=["B4", "B3", "B2"])

For AI Agent Integration:
    >>> from satellite_tiler import tools
    >>> 
    >>> # Use JSON-serializable tool functions
    >>> result = tools.discover_satellite_data(lat=40.7128, lon=-74.0060)
    >>> print(result["message"])
"""

__version__ = "0.2.1"

# Core data models
from satellite_tiler.models import (
    SatellitePlatform,
    BandInfo,
    MissionInfo,
    SceneInfo,
    TileResult,
    LandsatSceneComponents,
    Sentinel2SceneComponents,
    CBERSSceneComponents,
)

# Exceptions
from satellite_tiler.exceptions import (
    SatelliteTilerError,
    OutOfBoundsError,
    InvalidBandError,
    InvalidSceneIdError,
    NoSceneFoundError,
    AuthenticationError,
    ConnectionError,
)

# Main API functions
from satellite_tiler.discovery import (
    discover,
    list_scenes,
    get_bands_for_platform,
)

from satellite_tiler.tiles import (
    get_tile,
    set_scene_asset_urls,
    get_cached_asset_urls,
)

from satellite_tiler.metadata import (
    get_scene_bounds,
    get_scene_metadata,
    get_zoom_levels,
)

from satellite_tiler.parsers import (
    parse as parse_scene_id,
    format_scene_id,
    detect_platform,
)

from satellite_tiler.coordinates import (
    lat_lon_to_tile,
    tile_to_bounds,
)

from satellite_tiler.encoding import (
    to_png,
    to_jpeg,
    to_webp,
    encode,
)

from satellite_tiler.processing import (
    rescale,
    apply_colormap,
    get_available_colormaps,
)

from satellite_tiler.bands import (
    validate_bands,
    get_valid_bands,
    get_rgb_bands,
    get_false_color_bands,
)

# Agent tools module
from satellite_tiler import tools

# Geospatial analysis modules
from satellite_tiler import indices
from satellite_tiler import heat_analysis
from satellite_tiler import vegetation_analysis
from satellite_tiler import land_classification
from satellite_tiler import change_detection
from satellite_tiler import urban_tools
from satellite_tiler import flood_analysis
from satellite_tiler import air_quality_analysis
from satellite_tiler import growth_analysis
from satellite_tiler import green_infrastructure_analysis
from satellite_tiler import water_body_analysis
from satellite_tiler import building_detection
from satellite_tiler import environmental_justice_analysis
from satellite_tiler import compositing

# Convenience imports for analysis functions
from satellite_tiler.indices import (
    SpectralIndex,
    IndexResult,
    calculate_ndvi,
    calculate_ndbi,
    calculate_ndwi,
    calculate_mndwi,
    calculate_evi,
    calculate_savi,
    get_bands_for_index,
)

from satellite_tiler.heat_analysis import (
    HeatAnalysisResult,
    HeatIsland,
    analyze_heat,
    detect_heat_islands,
    has_thermal_bands,
    celsius_to_fahrenheit,
    fahrenheit_to_celsius,
)

from satellite_tiler.vegetation_analysis import (
    VegetationClass,
    VegetationAnalysisResult,
    analyze_vegetation,
    compare_vegetation,
    classify_vegetation,
)

from satellite_tiler.land_classification import (
    LandUseClass,
    LandClassificationResult,
    classify_from_bands,
    classify_land_use as classify_land,
)

from satellite_tiler.change_detection import (
    ChangeCategory,
    ChangeDetectionResult,
    UrbanExpansionResult,
    detect_index_change,
    detect_vegetation_change,
    detect_urban_expansion,
)

from satellite_tiler.urban_tools import (
    analyze_urban_heat,
    analyze_vegetation_health,
    calculate_spectral_index,
    classify_land_use,
    detect_changes,
    get_heat_recommendations,
    analyze_flood_risk_tool,
    analyze_air_quality_tool,
    analyze_green_infrastructure_tool,
    analyze_water_bodies_tool,
    detect_buildings_tool,
    analyze_environmental_justice_tool,
    get_geospatial_strands_tools,
)

from satellite_tiler.flood_analysis import (
    FloodRiskLevel,
    FloodRiskResult,
    analyze_flood_risk,
    detect_water_bodies,
    calculate_imperviousness,
)

from satellite_tiler.air_quality_analysis import (
    AirQualityRisk,
    AirQualityResult,
    analyze_air_quality,
)

from satellite_tiler.growth_analysis import (
    GrowthType,
    UrbanGrowthResult,
    analyze_urban_growth,
)

from satellite_tiler.green_infrastructure_analysis import (
    GreenInfrastructureResult,
    analyze_green_infrastructure,
)

from satellite_tiler.water_body_analysis import (
    WaterBodyAnalysisResult,
    WaterBodyMetrics,
    analyze_water_bodies,
)

from satellite_tiler.building_detection import (
    BuildingDensity,
    BuildingDetectionResult,
    analyze_buildings,
)

from satellite_tiler.environmental_justice_analysis import (
    EnvironmentalJusticeResult,
    analyze_environmental_justice,
)

from satellite_tiler.compositing import (
    CompositingMethod,
    CompositeResult,
    create_composite,
)

__all__ = [
    # Version
    "__version__",
    
    # Enums
    "SatellitePlatform",
    "SpectralIndex",
    "VegetationClass",
    "LandUseClass",
    "ChangeCategory",
    "FloodRiskLevel",
    "AirQualityRisk",
    "GrowthType",
    "BuildingDensity",
    "CompositingMethod",
    
    # Data models
    "BandInfo",
    "MissionInfo", 
    "SceneInfo",
    "TileResult",
    "LandsatSceneComponents",
    "Sentinel2SceneComponents",
    "CBERSSceneComponents",
    "IndexResult",
    "HeatAnalysisResult",
    "HeatIsland",
    "VegetationAnalysisResult",
    "LandClassificationResult",
    "ChangeDetectionResult",
    "UrbanExpansionResult",
    "FloodRiskResult",
    "AirQualityResult",
    "UrbanGrowthResult",
    "GreenInfrastructureResult",
    "WaterBodyAnalysisResult",
    "WaterBodyMetrics",
    "BuildingDetectionResult",
    "EnvironmentalJusticeResult",
    "CompositeResult",
    
    # Exceptions
    "SatelliteTilerError",
    "OutOfBoundsError",
    "InvalidBandError",
    "InvalidSceneIdError",
    "NoSceneFoundError",
    "AuthenticationError",
    "ConnectionError",
    
    # Main API
    "discover",
    "list_scenes",
    "get_tile",
    "get_bands_for_platform",
    "set_scene_asset_urls",
    "get_cached_asset_urls",
    
    # Metadata
    "get_scene_bounds",
    "get_scene_metadata",
    "get_zoom_levels",
    
    # Parsing
    "parse_scene_id",
    "format_scene_id",
    "detect_platform",
    
    # Coordinates
    "lat_lon_to_tile",
    "tile_to_bounds",
    
    # Encoding
    "to_png",
    "to_jpeg",
    "to_webp",
    "encode",
    
    # Processing
    "rescale",
    "apply_colormap",
    "get_available_colormaps",
    
    # Bands
    "validate_bands",
    "get_valid_bands",
    "get_rgb_bands",
    "get_false_color_bands",
    
    # Spectral Indices
    "calculate_ndvi",
    "calculate_ndbi",
    "calculate_ndwi",
    "calculate_mndwi",
    "calculate_evi",
    "calculate_savi",
    "get_bands_for_index",
    
    # Heat Analysis
    "analyze_heat",
    "detect_heat_islands",
    "has_thermal_bands",
    "celsius_to_fahrenheit",
    "fahrenheit_to_celsius",
    
    # Vegetation Analysis
    "analyze_vegetation",
    "compare_vegetation",
    "classify_vegetation",
    
    # Land Classification
    "classify_from_bands",
    "classify_land",
    
    # Change Detection
    "detect_index_change",
    "detect_vegetation_change",
    "detect_urban_expansion",
    
    # Flood Analysis
    "analyze_flood_risk",
    "detect_water_bodies",
    "calculate_imperviousness",
    
    # Air Quality Analysis
    "analyze_air_quality",
    
    # Urban Growth Analysis
    "analyze_urban_growth",
    
    # Green Infrastructure Analysis
    "analyze_green_infrastructure",
    
    # Water Body Analysis
    "analyze_water_bodies",
    
    # Building Detection
    "analyze_buildings",
    
    # Environmental Justice Analysis
    "analyze_environmental_justice",
    
    # Compositing
    "create_composite",
    
    # Urban Analysis Tools (Agent Interface)
    "analyze_urban_heat",
    "analyze_vegetation_health",
    "calculate_spectral_index",
    "classify_land_use",
    "detect_changes",
    "get_heat_recommendations",
    "analyze_flood_risk_tool",
    "analyze_air_quality_tool",
    "analyze_green_infrastructure_tool",
    "analyze_water_bodies_tool",
    "detect_buildings_tool",
    "analyze_environmental_justice_tool",
    "get_geospatial_strands_tools",
    
    # Modules
    "tools",
    "indices",
    "heat_analysis",
    "vegetation_analysis",
    "land_classification",
    "change_detection",
    "urban_tools",
    "flood_analysis",
    "air_quality_analysis",
    "growth_analysis",
    "green_infrastructure_analysis",
    "water_body_analysis",
    "building_detection",
    "environmental_justice_analysis",
    "compositing",
]
