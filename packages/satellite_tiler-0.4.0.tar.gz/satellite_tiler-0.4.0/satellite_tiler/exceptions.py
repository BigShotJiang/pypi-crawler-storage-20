"""Custom exceptions for satellite-tiler."""

from typing import List, Optional

from satellite_tiler.models import SatellitePlatform


class SatelliteTilerError(Exception):
    """Base exception for satellite-tiler."""
    pass


class OutOfBoundsError(SatelliteTilerError):
    """Raised when coordinates are outside scene coverage."""
    
    def __init__(self, lat: float, lon: float, scene_id: str):
        self.lat = lat
        self.lon = lon
        self.scene_id = scene_id
        super().__init__(
            f"Location ({lat}, {lon}) is outside coverage of scene {scene_id}"
        )


class InvalidBandError(SatelliteTilerError):
    """Raised when an invalid band is requested."""
    
    def __init__(self, band: str, platform: SatellitePlatform, valid_bands: List[str]):
        self.band = band
        self.platform = platform
        self.valid_bands = valid_bands
        super().__init__(
            f"Band '{band}' is not valid for {platform.value}. "
            f"Valid bands: {', '.join(valid_bands)}"
        )


class InvalidSceneIdError(SatelliteTilerError):
    """Raised when a scene ID cannot be parsed."""
    
    def __init__(self, scene_id: str, expected_format: str):
        self.scene_id = scene_id
        self.expected_format = expected_format
        super().__init__(
            f"Invalid scene ID '{scene_id}'. Expected format: {expected_format}"
        )


class NoSceneFoundError(SatelliteTilerError):
    """Raised when no scenes match the query criteria."""
    
    def __init__(
        self,
        lat: float,
        lon: float,
        filters: Optional[dict] = None,
        suggestion: Optional[str] = None
    ):
        self.lat = lat
        self.lon = lon
        self.filters = filters or {}
        self.suggestion = suggestion
        
        msg = f"No scenes found at ({lat}, {lon})"
        if filters:
            msg += f" with filters: {filters}"
        if suggestion:
            msg += f". {suggestion}"
        super().__init__(msg)


class AuthenticationError(SatelliteTilerError):
    """Raised when AWS credentials are missing or invalid."""
    
    def __init__(self, message: str = "AWS credentials are missing or invalid"):
        super().__init__(message)


class ConnectionError(SatelliteTilerError):
    """Raised when network connectivity issues occur."""
    
    def __init__(self, message: str, retry_after: Optional[int] = None):
        self.retry_after = retry_after
        if retry_after:
            message += f" Retry after {retry_after} seconds."
        super().__init__(message)
