"""Urban growth analysis from satellite imagery.

This module provides functions for analyzing urban growth patterns
over time, including growth rate, direction, and type classification.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Tuple

import numpy as np

from satellite_tiler.indices import calculate_ndbi, IndexResult


class GrowthType(Enum):
    """Types of urban growth patterns."""
    INFILL = "infill"           # Development within existing urban area
    EDGE = "edge"               # Expansion at urban boundary
    LEAPFROG = "leapfrog"       # Isolated development away from urban core
    STABLE = "stable"           # No significant change


@dataclass
class UrbanGrowthResult:
    """Result of urban growth analysis.
    
    Attributes:
        urban_before_percent: Urban coverage at start
        urban_after_percent: Urban coverage at end
        growth_rate_percent: Percentage change in urban area
        new_urban_area_sq_meters: Area of new urban development
        growth_type: Dominant type of growth
        growth_direction: Primary direction of expansion
        infill_percent: Percentage of growth that is infill
        edge_percent: Percentage of growth at edges
        ndbi_before: NDBI result for before scene
        ndbi_after: NDBI result for after scene
    """
    urban_before_percent: float
    urban_after_percent: float
    growth_rate_percent: float
    new_urban_area_sq_meters: float
    growth_type: str
    growth_direction: Optional[str]
    infill_percent: float
    edge_percent: float
    ndbi_before: IndexResult
    ndbi_after: IndexResult

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "urban_before_percent": self.urban_before_percent,
            "urban_after_percent": self.urban_after_percent,
            "growth_rate_percent": self.growth_rate_percent,
            "new_urban_area_sq_meters": self.new_urban_area_sq_meters,
            "growth_type": self.growth_type,
            "growth_direction": self.growth_direction,
            "infill_percent": self.infill_percent,
            "edge_percent": self.edge_percent,
            "ndbi_before_stats": self.ndbi_before.to_dict(),
            "ndbi_after_stats": self.ndbi_after.to_dict(),
        }


def classify_urban(ndbi_data: np.ndarray, threshold: float = 0.0) -> np.ndarray:
    """Classify pixels as urban based on NDBI threshold.
    
    Args:
        ndbi_data: NDBI values array
        threshold: NDBI threshold for urban classification
    
    Returns:
        Boolean mask of urban pixels
    """
    urban_mask = ndbi_data > threshold
    urban_mask = urban_mask & ~np.isnan(ndbi_data)
    return urban_mask


def detect_urban_edge(urban_mask: np.ndarray) -> np.ndarray:
    """Detect edge pixels of urban areas.
    
    Args:
        urban_mask: Boolean mask of urban pixels
    
    Returns:
        Boolean mask of edge pixels
    """
    # Dilate urban mask
    dilated = np.zeros_like(urban_mask)
    dilated[1:, :] |= urban_mask[:-1, :]
    dilated[:-1, :] |= urban_mask[1:, :]
    dilated[:, 1:] |= urban_mask[:, :-1]
    dilated[:, :-1] |= urban_mask[:, 1:]
    
    # Edge is dilated minus original
    edge = dilated & ~urban_mask
    
    return edge


def calculate_growth_direction(
    new_urban_mask: np.ndarray,
    urban_before_mask: np.ndarray,
) -> Optional[str]:
    """Calculate primary direction of urban growth.
    
    Args:
        new_urban_mask: Boolean mask of new urban pixels
        urban_before_mask: Boolean mask of urban pixels before
    
    Returns:
        Direction string (N, S, E, W, NE, NW, SE, SW) or None
    """
    if not np.any(new_urban_mask) or not np.any(urban_before_mask):
        return None
    
    # Find centroid of existing urban area
    rows_before, cols_before = np.where(urban_before_mask)
    if len(rows_before) == 0:
        return None
    
    center_row = np.mean(rows_before)
    center_col = np.mean(cols_before)
    
    # Find centroid of new urban area
    rows_new, cols_new = np.where(new_urban_mask)
    if len(rows_new) == 0:
        return None
    
    new_center_row = np.mean(rows_new)
    new_center_col = np.mean(cols_new)
    
    # Calculate direction
    delta_row = new_center_row - center_row
    delta_col = new_center_col - center_col
    
    # Determine cardinal/intercardinal direction
    ns = ""
    ew = ""
    
    if abs(delta_row) > 0.1 * urban_before_mask.shape[0]:
        ns = "S" if delta_row > 0 else "N"
    
    if abs(delta_col) > 0.1 * urban_before_mask.shape[1]:
        ew = "E" if delta_col > 0 else "W"
    
    direction = ns + ew
    return direction if direction else None


def classify_growth_type(
    new_urban_mask: np.ndarray,
    urban_before_mask: np.ndarray,
    edge_before_mask: np.ndarray,
) -> Tuple[str, float, float]:
    """Classify the type of urban growth.
    
    Args:
        new_urban_mask: Boolean mask of new urban pixels
        urban_before_mask: Boolean mask of urban pixels before
        edge_before_mask: Boolean mask of urban edge before
    
    Returns:
        Tuple of (growth_type, infill_percent, edge_percent)
    """
    if not np.any(new_urban_mask):
        return GrowthType.STABLE.value, 0.0, 0.0
    
    total_new = np.sum(new_urban_mask)
    
    # Infill: new urban within or adjacent to existing urban
    # Dilate existing urban to find adjacent areas
    dilated_urban = np.zeros_like(urban_before_mask)
    dilated_urban[1:, :] |= urban_before_mask[:-1, :]
    dilated_urban[:-1, :] |= urban_before_mask[1:, :]
    dilated_urban[:, 1:] |= urban_before_mask[:, :-1]
    dilated_urban[:, :-1] |= urban_before_mask[:, 1:]
    dilated_urban |= urban_before_mask
    
    infill_mask = new_urban_mask & dilated_urban
    infill_count = np.sum(infill_mask)
    
    # Edge growth: new urban at the edge of existing urban
    edge_growth_mask = new_urban_mask & edge_before_mask
    edge_count = np.sum(edge_growth_mask)
    
    # Calculate percentages
    infill_percent = float(infill_count / total_new * 100) if total_new > 0 else 0.0
    edge_percent = float(edge_count / total_new * 100) if total_new > 0 else 0.0
    
    # Determine dominant growth type
    if infill_percent > 50:
        growth_type = GrowthType.INFILL.value
    elif edge_percent > 30:
        growth_type = GrowthType.EDGE.value
    elif total_new > 0:
        growth_type = GrowthType.LEAPFROG.value
    else:
        growth_type = GrowthType.STABLE.value
    
    return growth_type, infill_percent, edge_percent


def analyze_urban_growth(
    swir_before: np.ndarray,
    nir_before: np.ndarray,
    swir_after: np.ndarray,
    nir_after: np.ndarray,
    urban_threshold: float = 0.0,
    pixel_size_meters: float = 30.0,
) -> UrbanGrowthResult:
    """Analyze urban growth between two time periods.
    
    Args:
        swir_before: SWIR band array for earlier date
        nir_before: NIR band array for earlier date
        swir_after: SWIR band array for later date
        nir_after: NIR band array for later date
        urban_threshold: NDBI threshold for urban classification
        pixel_size_meters: Pixel size for area calculation
    
    Returns:
        UrbanGrowthResult with complete growth analysis
    """
    # Calculate NDBI for both periods
    ndbi_before = calculate_ndbi(swir_before, nir_before)
    ndbi_after = calculate_ndbi(swir_after, nir_after)
    
    # Classify urban areas
    urban_before = classify_urban(ndbi_before.data, urban_threshold)
    urban_after = classify_urban(ndbi_after.data, urban_threshold)
    
    # Calculate urban percentages
    valid_mask = ~np.isnan(ndbi_before.data) & ~np.isnan(ndbi_after.data)
    total_valid = np.sum(valid_mask)
    
    if total_valid > 0:
        urban_before_percent = float(np.sum(urban_before & valid_mask) / total_valid * 100)
        urban_after_percent = float(np.sum(urban_after & valid_mask) / total_valid * 100)
    else:
        urban_before_percent = 0.0
        urban_after_percent = 0.0
    
    # Calculate growth rate
    growth_rate = urban_after_percent - urban_before_percent
    
    # Identify new urban areas
    new_urban = urban_after & ~urban_before & valid_mask
    new_urban_count = np.sum(new_urban)
    new_urban_area = float(new_urban_count * pixel_size_meters ** 2)
    
    # Detect urban edge before
    edge_before = detect_urban_edge(urban_before)
    
    # Classify growth type
    growth_type, infill_percent, edge_percent = classify_growth_type(
        new_urban, urban_before, edge_before
    )
    
    # Calculate growth direction
    growth_direction = calculate_growth_direction(new_urban, urban_before)
    
    return UrbanGrowthResult(
        urban_before_percent=urban_before_percent,
        urban_after_percent=urban_after_percent,
        growth_rate_percent=growth_rate,
        new_urban_area_sq_meters=new_urban_area,
        growth_type=growth_type,
        growth_direction=growth_direction,
        infill_percent=infill_percent,
        edge_percent=edge_percent,
        ndbi_before=ndbi_before,
        ndbi_after=ndbi_after,
    )
