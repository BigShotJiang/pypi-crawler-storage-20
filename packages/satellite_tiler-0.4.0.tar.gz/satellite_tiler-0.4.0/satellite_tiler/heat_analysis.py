"""Urban heat analysis from satellite thermal data.

This module provides functions for calculating Land Surface Temperature (LST)
and detecting urban heat islands from Landsat thermal bands.

Note: Sentinel-2 does not have thermal bands and cannot be used for heat analysis.
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np

from satellite_tiler.models import SatellitePlatform


@dataclass
class HeatAnalysisResult:
    """Result of urban heat analysis.
    
    Attributes:
        lst_celsius: Land Surface Temperature array in Celsius
        lst_fahrenheit: LST array in Fahrenheit
        min_temp_c: Minimum temperature in Celsius
        max_temp_c: Maximum temperature in Celsius
        mean_temp_c: Mean temperature in Celsius
        std_temp_c: Standard deviation of temperature
        heat_island_mask: Boolean mask of heat island pixels
        heat_island_area_percent: Percentage of area classified as heat island
        heat_island_threshold_c: Threshold used for heat island detection
    """
    lst_celsius: np.ndarray
    lst_fahrenheit: np.ndarray
    min_temp_c: float
    max_temp_c: float
    mean_temp_c: float
    std_temp_c: float
    heat_island_mask: np.ndarray
    heat_island_area_percent: float
    heat_island_threshold_c: float

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization (without numpy arrays)."""
        return {
            "shape": list(self.lst_celsius.shape),
            "min_temp_c": float(self.min_temp_c),
            "max_temp_c": float(self.max_temp_c),
            "mean_temp_c": float(self.mean_temp_c),
            "std_temp_c": float(self.std_temp_c),
            "min_temp_f": float(celsius_to_fahrenheit(self.min_temp_c)),
            "max_temp_f": float(celsius_to_fahrenheit(self.max_temp_c)),
            "mean_temp_f": float(celsius_to_fahrenheit(self.mean_temp_c)),
            "heat_island_area_percent": float(self.heat_island_area_percent),
            "heat_island_threshold_c": float(self.heat_island_threshold_c),
        }


@dataclass
class HeatIsland:
    """Identified heat island region.
    
    Attributes:
        centroid: (lat, lon) coordinates of the heat island center
        area_sq_meters: Area of the heat island in square meters
        mean_temp_c: Mean temperature within the heat island
        max_temp_c: Maximum temperature within the heat island
        temp_above_mean_c: Temperature above the scene mean
        pixel_count: Number of pixels in the heat island
    """
    centroid: Tuple[float, float]
    area_sq_meters: float
    mean_temp_c: float
    max_temp_c: float
    temp_above_mean_c: float
    pixel_count: int

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "centroid": {"lat": self.centroid[0], "lon": self.centroid[1]},
            "area_sq_meters": self.area_sq_meters,
            "mean_temp_c": self.mean_temp_c,
            "max_temp_c": self.max_temp_c,
            "temp_above_mean_c": self.temp_above_mean_c,
            "pixel_count": self.pixel_count,
        }


# Thermal band availability per platform
THERMAL_BANDS = {
    "landsat8": ["B10", "B11"],  # TIRS bands
    "landsat9": ["B10", "B11"],
    "sentinel2": None,  # No thermal bands
    "cbers": None,  # No thermal bands in standard products
}

# Landsat thermal band constants
LANDSAT_THERMAL_CONSTANTS = {
    "B10": {
        "k1": 774.8853,  # K1 constant (W/(m² sr μm))
        "k2": 1321.0789,  # K2 constant (Kelvin)
    },
    "B11": {
        "k1": 480.8883,
        "k2": 1201.1442,
    },
}

# Landsat Collection 2 Level-2 Surface Temperature scaling factors
# See: https://www.usgs.gov/faqs/how-do-i-use-a-scale-factor-landsat-level-2-science-products
LANDSAT_C2_L2_ST_SCALE = 0.00341802
LANDSAT_C2_L2_ST_OFFSET = 149.0  # Results in Kelvin


def celsius_to_fahrenheit(celsius: float) -> float:
    """Convert temperature from Celsius to Fahrenheit.
    
    Args:
        celsius: Temperature in Celsius
    
    Returns:
        Temperature in Fahrenheit
    """
    return celsius * 9.0 / 5.0 + 32.0


def fahrenheit_to_celsius(fahrenheit: float) -> float:
    """Convert temperature from Fahrenheit to Celsius.
    
    Args:
        fahrenheit: Temperature in Fahrenheit
    
    Returns:
        Temperature in Celsius
    """
    return (fahrenheit - 32.0) * 5.0 / 9.0


def kelvin_to_celsius(kelvin: float) -> float:
    """Convert temperature from Kelvin to Celsius.
    
    Args:
        kelvin: Temperature in Kelvin
    
    Returns:
        Temperature in Celsius
    """
    return kelvin - 273.15


def celsius_to_kelvin(celsius: float) -> float:
    """Convert temperature from Celsius to Kelvin.
    
    Args:
        celsius: Temperature in Celsius
    
    Returns:
        Temperature in Kelvin
    """
    return celsius + 273.15


def scale_landsat_c2_l2_thermal(
    raw_data: np.ndarray,
    fill_value: int = 0,
) -> np.ndarray:
    """Convert Landsat Collection 2 Level-2 Surface Temperature to Kelvin.
    
    Landsat Collection 2 Level-2 thermal data (ST_B10) is stored as scaled
    integers. This function applies the USGS-provided scale factor and offset
    to convert to temperature in Kelvin.
    
    Formula: Temperature (K) = DN * 0.00341802 + 149
    
    Reference: https://www.usgs.gov/faqs/how-do-i-use-a-scale-factor-landsat-level-2-science-products
    
    Args:
        raw_data: Raw thermal band data (scaled integers)
        fill_value: Fill/nodata value in raw data (default 0)
    
    Returns:
        Temperature array in Kelvin
    """
    data = raw_data.astype(np.float64)
    
    # Create mask for valid data (not fill value)
    valid_mask = raw_data != fill_value
    
    # Apply scaling: DN * scale + offset
    result = np.where(
        valid_mask,
        data * LANDSAT_C2_L2_ST_SCALE + LANDSAT_C2_L2_ST_OFFSET,
        np.nan
    )
    
    return result


def is_scaled_integer_data(data: np.ndarray) -> bool:
    """Detect if thermal data is Landsat C2 L2 scaled integers.
    
    Landsat Collection 2 Level-2 Surface Temperature data has:
    - Valid range: 293-65535 (as scaled integers)
    - When converted: ~150K to ~370K (reasonable Earth surface temps)
    
    If data values are very large (>1000) and not already in reasonable
    Kelvin range (200-400K), it's likely scaled integer data.
    
    Args:
        data: Thermal band data array
    
    Returns:
        True if data appears to be scaled integers needing conversion
    """
    # Get valid (non-zero, non-nan) values
    valid_data = data[(data != 0) & ~np.isnan(data)]
    
    if len(valid_data) == 0:
        return False
    
    # Check the range of values
    min_val = np.min(valid_data)
    max_val = np.max(valid_data)
    mean_val = np.mean(valid_data)
    
    # Landsat C2 L2 ST scaled integers are typically in range 8000-12000
    # for normal Earth surface temperatures (when converted: ~175-190K... wait)
    # Actually: 8000 * 0.00341802 + 149 = 176.3K (too cold)
    # For 300K (27°C): (300 - 149) / 0.00341802 = 44,186
    # So typical values for Earth surface temps (250-330K) would be ~29,500 to ~52,900
    
    # If values are > 1000 and mean is > 10000, likely scaled integers
    # If values are in 200-400 range, likely already Kelvin
    if mean_val > 1000:
        return True
    elif 200 <= mean_val <= 400:
        return False
    else:
        # Edge case: very cold or very hot - check if scaling makes sense
        # If scaling would produce reasonable temps (200-400K), use scaling
        scaled_mean = mean_val * LANDSAT_C2_L2_ST_SCALE + LANDSAT_C2_L2_ST_OFFSET
        return 200 <= scaled_mean <= 400


def brightness_temp_to_lst(
    brightness_temp_kelvin: np.ndarray,
    emissivity: float = 0.95,
    wavelength_um: float = 10.8,
) -> np.ndarray:
    """Convert brightness temperature to Land Surface Temperature.
    
    Uses the single-channel algorithm with emissivity correction.
    
    LST = BT / (1 + (λ * BT / ρ) * ln(ε))
    
    where:
    - BT is brightness temperature in Kelvin
    - λ is wavelength in micrometers
    - ρ = h * c / σ = 14380 μm·K (Planck's constant relation)
    - ε is surface emissivity
    
    Args:
        brightness_temp_kelvin: Brightness temperature array in Kelvin
        emissivity: Surface emissivity (default 0.95 for urban areas)
        wavelength_um: Central wavelength in micrometers (default 10.8 for Landsat B10)
    
    Returns:
        Land Surface Temperature array in Kelvin
    """
    bt = brightness_temp_kelvin.astype(np.float64)
    rho = 14380.0  # μm·K
    
    with np.errstate(divide='ignore', invalid='ignore'):
        # Handle emissivity = 1 case (ln(1) = 0)
        if emissivity == 1.0:
            return bt
        
        ln_emissivity = np.log(emissivity)
        lst = bt / (1 + (wavelength_um * bt / rho) * ln_emissivity)
    
    return lst


def radiance_to_brightness_temp(
    radiance: np.ndarray,
    k1: float,
    k2: float,
) -> np.ndarray:
    """Convert spectral radiance to brightness temperature.
    
    Uses the inverse Planck function:
    BT = K2 / ln(K1/L + 1)
    
    Args:
        radiance: Spectral radiance array (W/(m² sr μm))
        k1: Band-specific thermal constant K1
        k2: Band-specific thermal constant K2
    
    Returns:
        Brightness temperature array in Kelvin
    """
    rad = radiance.astype(np.float64)
    
    with np.errstate(divide='ignore', invalid='ignore'):
        bt = np.where(
            rad > 0,
            k2 / np.log(k1 / rad + 1),
            np.nan
        )
    
    return bt


def calculate_lst(
    thermal_band: np.ndarray,
    band_name: str = "B10",
    emissivity: float = 0.95,
    is_radiance: bool = False,
    auto_scale: bool = True,
) -> np.ndarray:
    """Calculate Land Surface Temperature from Landsat thermal band.
    
    This function handles multiple input formats:
    1. Landsat Collection 2 Level-2 Surface Temperature (scaled integers)
       - Auto-detected when values are large (>1000)
       - Converted using USGS scale factor (0.00341802) and offset (149)
    2. Brightness temperature in Kelvin
    3. Spectral radiance (if is_radiance=True)
    
    Args:
        thermal_band: Thermal band data (scaled integers, radiance, or brightness temp)
        band_name: Thermal band name ("B10" or "B11")
        emissivity: Surface emissivity (default 0.95)
        is_radiance: If True, input is radiance; if False, brightness temp or scaled
        auto_scale: If True, auto-detect and convert Landsat C2 L2 scaled data
    
    Returns:
        LST array in Celsius
    """
    if band_name not in LANDSAT_THERMAL_CONSTANTS:
        raise ValueError(f"Unknown thermal band: {band_name}")
    
    constants = LANDSAT_THERMAL_CONSTANTS[band_name]
    
    if is_radiance:
        # Convert radiance to brightness temperature
        bt_kelvin = radiance_to_brightness_temp(
            thermal_band,
            constants["k1"],
            constants["k2"]
        )
        # Apply emissivity correction
        wavelength = 10.8 if band_name == "B10" else 12.0
        lst_kelvin = brightness_temp_to_lst(bt_kelvin, emissivity, wavelength)
        lst_celsius = kelvin_to_celsius(lst_kelvin)
    elif auto_scale and is_scaled_integer_data(thermal_band):
        # Landsat Collection 2 Level-2 Surface Temperature data
        # Already processed to surface temperature, just needs scaling
        # The C2 L2 ST product already has atmospheric and emissivity corrections applied
        lst_kelvin = scale_landsat_c2_l2_thermal(thermal_band)
        lst_celsius = kelvin_to_celsius(lst_kelvin)
    else:
        # Assume input is already brightness temperature in Kelvin
        bt_kelvin = thermal_band.astype(np.float64)
        # Apply emissivity correction
        wavelength = 10.8 if band_name == "B10" else 12.0
        lst_kelvin = brightness_temp_to_lst(bt_kelvin, emissivity, wavelength)
        lst_celsius = kelvin_to_celsius(lst_kelvin)
    
    return lst_celsius


def detect_heat_islands(
    lst_celsius: np.ndarray,
    threshold_above_mean: float = 2.0,
    min_pixels: int = 1,
) -> Tuple[np.ndarray, List[HeatIsland]]:
    """Detect urban heat islands from LST data.
    
    A heat island is defined as a contiguous region where temperature
    exceeds the scene mean by more than the threshold.
    
    Args:
        lst_celsius: Land Surface Temperature array in Celsius
        threshold_above_mean: Temperature threshold above mean (default 2.0°C)
        min_pixels: Minimum pixels for a heat island (default 1)
    
    Returns:
        Tuple of:
        - Boolean mask of heat island pixels
        - List of HeatIsland objects for each detected region
    """
    # Calculate scene statistics (excluding NaN)
    valid_mask = ~np.isnan(lst_celsius)
    if not np.any(valid_mask):
        return np.zeros_like(lst_celsius, dtype=bool), []
    
    mean_temp = float(np.nanmean(lst_celsius))
    threshold_temp = mean_temp + threshold_above_mean
    
    # Create heat island mask
    heat_island_mask = (lst_celsius > threshold_temp) & valid_mask
    
    # Find connected components (simple approach without scipy)
    heat_islands = []
    
    if np.any(heat_island_mask):
        # For now, treat all heat island pixels as one region
        # A more sophisticated implementation would use connected components
        hi_temps = lst_celsius[heat_island_mask]
        pixel_count = int(np.sum(heat_island_mask))
        
        if pixel_count >= min_pixels:
            # Find centroid (center of mass)
            rows, cols = np.where(heat_island_mask)
            centroid_row = np.mean(rows)
            centroid_col = np.mean(cols)
            
            # Convert to relative position (0-1 range)
            # Actual lat/lon would require georeferencing info
            centroid = (
                centroid_row / lst_celsius.shape[0],
                centroid_col / lst_celsius.shape[1]
            )
            
            heat_island = HeatIsland(
                centroid=centroid,
                area_sq_meters=pixel_count * 900.0,  # Assume 30m pixels
                mean_temp_c=float(np.mean(hi_temps)),
                max_temp_c=float(np.max(hi_temps)),
                temp_above_mean_c=float(np.mean(hi_temps) - mean_temp),
                pixel_count=pixel_count,
            )
            heat_islands.append(heat_island)
    
    return heat_island_mask, heat_islands


def analyze_heat(
    thermal_band: np.ndarray,
    band_name: str = "B10",
    emissivity: float = 0.95,
    heat_island_threshold: float = 2.0,
    is_radiance: bool = False,
) -> HeatAnalysisResult:
    """Perform complete urban heat analysis.
    
    Args:
        thermal_band: Thermal band data
        band_name: Thermal band name ("B10" or "B11")
        emissivity: Surface emissivity (default 0.95)
        heat_island_threshold: Temperature above mean for heat islands (°C)
        is_radiance: If True, input is radiance; if False, brightness temp
    
    Returns:
        HeatAnalysisResult with LST and heat island analysis
    """
    # Calculate LST
    lst_celsius = calculate_lst(thermal_band, band_name, emissivity, is_radiance)
    lst_fahrenheit = np.vectorize(celsius_to_fahrenheit)(lst_celsius)
    
    # Calculate statistics
    valid_mask = ~np.isnan(lst_celsius)
    if np.any(valid_mask):
        min_temp = float(np.nanmin(lst_celsius))
        max_temp = float(np.nanmax(lst_celsius))
        mean_temp = float(np.nanmean(lst_celsius))
        std_temp = float(np.nanstd(lst_celsius))
    else:
        min_temp = max_temp = mean_temp = std_temp = np.nan
    
    # Detect heat islands
    heat_island_mask, _ = detect_heat_islands(
        lst_celsius, heat_island_threshold
    )
    
    # Calculate heat island coverage
    total_valid = np.sum(valid_mask)
    heat_island_pixels = np.sum(heat_island_mask)
    heat_island_percent = (
        (heat_island_pixels / total_valid * 100) if total_valid > 0 else 0.0
    )
    
    return HeatAnalysisResult(
        lst_celsius=lst_celsius,
        lst_fahrenheit=lst_fahrenheit,
        min_temp_c=min_temp,
        max_temp_c=max_temp,
        mean_temp_c=mean_temp,
        std_temp_c=std_temp,
        heat_island_mask=heat_island_mask,
        heat_island_area_percent=float(heat_island_percent),
        heat_island_threshold_c=heat_island_threshold,
    )


def has_thermal_bands(platform: str) -> bool:
    """Check if a platform has thermal bands.
    
    Args:
        platform: Platform name (e.g., "landsat8", "sentinel2")
    
    Returns:
        True if platform has thermal bands, False otherwise
    """
    return THERMAL_BANDS.get(platform.lower()) is not None


def get_thermal_bands(platform: str) -> Optional[List[str]]:
    """Get thermal band names for a platform.
    
    Args:
        platform: Platform name
    
    Returns:
        List of thermal band names, or None if not available
    """
    return THERMAL_BANDS.get(platform.lower())
