#!/usr/bin/env python3
"""
Novyx Core - Artifact Registry
================================
Central registry for artifact types, mapping artifact_type strings to
schema identifiers and output directories.

This enables new artifact types to be added by:
1. Updating CORE_SCHEMA.jsonld
2. Registering the type here

Usage:
    from tools.artifacts import get_artifact_config, list_artifact_types
    
    config = get_artifact_config("decision")
    # Returns: {"schema_id": "novyx:Decision", "output_dir": "memory/decisions"}
"""

from typing import Dict, List, Optional
from pathlib import Path

# Central Artifact Registry
# Format: artifact_type -> {"schema_id": str, "output_dir": str}
ARTIFACT_REGISTRY: Dict[str, Dict[str, str]] = {
    "decision": {
        "schema_id": "novyx:Decision",
        "output_dir": "memory/decisions"
    },
    "apiendpoint": {
        "schema_id": "novyx:APIEndpoint",
        "output_dir": "memory/api"
    },
    "graphqloperation": {
        "schema_id": "novyx:GraphQLOperation",
        "output_dir": "memory/graphql"
    },
    "tenant": {
        "schema_id": "novyx:Tenant",
        "output_dir": "memory/tenants"
    },
    "version": {
        "schema_id": "novyx:Version",
        "output_dir": "memory/versions"
    },
    "remoteref": {
        "schema_id": "novyx:RemoteRef",
        "output_dir": "memory/federation"
    },
    # Future artifact types can be added here:
    # "experiment": {
    #     "schema_id": "novyx:Experiment",
    #     "output_dir": "memory/experiments"
    # },
}


def get_artifact_config(artifact_type: str) -> Optional[Dict[str, str]]:
    """
    Get configuration for a registered artifact type.
    
    Args:
        artifact_type: The artifact type identifier (e.g., "decision")
    
    Returns:
        Dict with "schema_id" and "output_dir" keys, or None if not found
    
    Example:
        >>> config = get_artifact_config("decision")
        >>> config["schema_id"]
        'novyx:Decision'
        >>> config["output_dir"]
        'memory/decisions'
    """
    return ARTIFACT_REGISTRY.get(artifact_type.lower())


def list_artifact_types() -> List[str]:
    """
    List all registered artifact types.
    
    Returns:
        List of artifact type identifiers
    
    Example:
        >>> list_artifact_types()
        ['decision']
    """
    return list(ARTIFACT_REGISTRY.keys())


def register_artifact_type(
    artifact_type: str,
    schema_id: str,
    output_dir: str
) -> None:
    """
    Register a new artifact type (runtime registration).
    
    Args:
        artifact_type: The artifact type identifier (e.g., "experiment")
        schema_id: The schema identifier from CORE_SCHEMA.jsonld (e.g., "novyx:Experiment")
        output_dir: Relative path for artifact storage (e.g., "memory/experiments")
    
    Note:
        This is for runtime registration. For permanent types, update ARTIFACT_REGISTRY directly.
    """
    ARTIFACT_REGISTRY[artifact_type.lower()] = {
        "schema_id": schema_id,
        "output_dir": output_dir
    }


def get_output_path(artifact_type: str) -> Optional[Path]:
    """
    Get the output directory path for an artifact type.
    
    Args:
        artifact_type: The artifact type identifier
    
    Returns:
        Path object for the output directory, or None if type not found
    """
    config = get_artifact_config(artifact_type)
    if config:
        return Path(config["output_dir"])
    return None


def get_schema_id(artifact_type: str) -> Optional[str]:
    """
    Get the schema identifier for an artifact type.
    
    Args:
        artifact_type: The artifact type identifier
    
    Returns:
        Schema ID string (e.g., "novyx:Decision"), or None if type not found
    """
    config = get_artifact_config(artifact_type)
    if config:
        return config["schema_id"]
    return None


if __name__ == "__main__":
    # CLI for inspecting registry
    import json
    print("Registered Artifact Types:")
    print(json.dumps(ARTIFACT_REGISTRY, indent=2))
