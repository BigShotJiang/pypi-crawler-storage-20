"""Patronus test suite."""
