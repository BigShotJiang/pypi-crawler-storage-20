import os
import sys
from dataclasses import dataclass
from typing import Optional

@dataclass
class Config:
    """配置类，用于管理ylbot的环境变量和常量"""
    
    # 历史记录相关配置
    MAX_SINGLE_CHAR: int = 1000  # 单条最大字符数
    MAX_USER_RECORD_COUNT: int = 50  # 每个user允许的最多条数
    MAX_HISTORY_CONTENT_CHAR: int = 4000  # 历史记录content字段允许的最大字符数之和
    CLEAR_CYCLE: int = 7  # 定期清理用户记录的周期，单位是天
    HISTORY_ALGORITHM: str = "normal"  # 历史记录算法: "fair" (公平算法) 或 "normal" (普通算法)
    
    # 状态管理配置
    STATUS_CLEANUP_INTERVAL: int = 3600  # 状态清理间隔，单位秒
    
    # 自动回复相关配置
    AUTO_ANSWER_TIMEOUT: int = 10  # 自动回复超时时间，单位秒
    
    # LLM相关配置
    LLM_API_KEY: Optional[str] = None
    LLM_BASE_URL: Optional[str] = None
    LLM_MODEL: str = "deepseek-chat"
    
    # 数据库配置
    REDIS_URL: Optional[str] = None
    DATABASE_URL: Optional[str] = None
    
    # 调试配置
    PRINT_DEBUG: bool = False
    
    # Agent配置
    USE_AGENT_TOOLS: bool = False
    AGENT_MODE: str = "web"  # web或onebot
    OUTPUT_MODE: str = "normal"  # normal或streaming
    
    def __init__(self, **kwargs):
        """初始化配置，检查必需环境变量，缺失则退出程序"""
        # 严格检查必需的环境变量，缺失则退出程序
        self._check_required_env_vars_strict()
        
        # 历史记录配置
        self.MAX_SINGLE_CHAR = int(os.getenv("MAX_SINGLE_CHAR", self.MAX_SINGLE_CHAR))
        self.MAX_USER_RECORD_COUNT = int(os.getenv("MAX_USER_RECORD_COUNT", self.MAX_USER_RECORD_COUNT))
        self.MAX_HISTORY_CONTENT_CHAR = int(os.getenv("MAX_HISTORY_CONTENT_CHAR", self.MAX_HISTORY_CONTENT_CHAR))
        self.CLEAR_CYCLE = int(os.getenv("CLEAR_CYCLE", self.CLEAR_CYCLE))
        self.HISTORY_ALGORITHM = os.getenv("HISTORY_ALGORITHM", self.HISTORY_ALGORITHM)
        
        # 状态管理配置
        self.STATUS_CLEANUP_INTERVAL = int(os.getenv("STATUS_CLEANUP_INTERVAL", self.STATUS_CLEANUP_INTERVAL))
        
        # 自动回复配置
        self.AUTO_ANSWER_TIMEOUT = int(os.getenv("AUTO_ANSWER_TIMEOUT", self.AUTO_ANSWER_TIMEOUT))
        
        # LLM配置
        self.LLM_API_KEY = os.getenv("LLM_API_KEY", self.LLM_API_KEY)
        self.LLM_BASE_URL = os.getenv("LLM_BASE_URL", self.LLM_BASE_URL)
        self.LLM_MODEL = os.getenv("LLM_MODEL", self.LLM_MODEL)
        
        # 数据库配置
        self.REDIS_URL = os.getenv("REDIS_URL", self.REDIS_URL)
        self.DATABASE_URL = os.getenv("DATABASE_URL", self.DATABASE_URL)
        
        # 调试配置
        debug_value = os.getenv("PRINT_DEBUG", "").lower().strip()
        self.PRINT_DEBUG = debug_value in ["yes", "true", "1", "on"]
        
        # Agent配置
        agent_tools_value = os.getenv("USE_AGENT_TOOLS", "").lower().strip()
        self.USE_AGENT_TOOLS = agent_tools_value in ["yes", "true", "1", "on"]
        
        # Agent模式配置 (web或onebot)
        agent_mode = os.getenv("AGENT_MODE", "").lower().strip()
        if agent_mode in ["web", "onebot"]:
            self.AGENT_MODE = agent_mode
        # 否则保持默认值"web"
        
        # 输出模式配置 (normal或streaming)
        output_mode = os.getenv("OUTPUT_MODE", "").lower().strip()
        if output_mode in ["normal", "streaming"]:
            self.OUTPUT_MODE = output_mode
        # 否则保持默认值"normal"
        
        # 覆盖传入的参数
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        
        # 验证HISTORY_ALGORITHM的有效性
        if self.HISTORY_ALGORITHM not in ["fair", "normal"]:
            raise ValueError(f"HISTORY_ALGORITHM must be 'fair' or 'normal', got '{self.HISTORY_ALGORITHM}'")
    
    def _check_required_env_vars_strict(self):
        """严格检查必需的环境变量，缺失则退出程序"""
        missing_vars = []
        
        # 检查Redis配置
        if not os.getenv("REDIS_URL"):
            missing_vars.append("REDIS_URL")
        
        # 检查LLM配置
        if not os.getenv("LLM_API_KEY"):
            missing_vars.append("LLM_API_KEY")
        if not os.getenv("LLM_BASE_URL"):
            missing_vars.append("LLM_BASE_URL")
        if not os.getenv("LLM_MODEL"):
            missing_vars.append("LLM_MODEL")
        
        if missing_vars:
            print("❌ 程序启动失败：以下必需环境变量未配置:")
            for var in missing_vars:
                print(f"   - {var}")
            print()
            print("💡 请按照以下步骤配置:")
            print("   1. 在当前目录创建 .env 文件")
            print("   2. 将以下内容复制到 .env 文件中:")
            print("      (请根据您的实际环境修改配置值)")
            print()
            print("=" * 60)
            print("""# ylbot 环境变量配置文件
# 注意：在Windows上，请确保文件编码为UTF-8
# 将此文件中的配置值修改为您的实际环境值

# ==================== 必需配置 ====================
# 以下配置是运行ylbot所必需的，请务必填写

# ==================== LLM配置 ====================
# LLM API密钥（使用Ollama时设置为"ollama"，使用OpenAI时设置为实际API密钥）
LLM_API_KEY=ollama

# LLM API基础URL
# - 使用Ollama: http://localhost:11434/v1
# - 使用OpenAI: https://api.openai.com/v1
# - 使用其他兼容OpenAI的API: 对应服务地址
LLM_BASE_URL=http://localhost:11434/v1

# LLM模型名称
# - Ollama模型: qwen3:latest, llama3.2:latest, deepseek-coder:latest 等
# - OpenAI模型: gpt-3.5-turbo, gpt-4, gpt-4-turbo 等
LLM_MODEL=qwen3:latest

# ==================== Redis配置 ====================
# Redis连接地址
# 格式: redis://[:password@]host[:port][/db-number]
REDIS_URL=redis://localhost:6379/0

# ==================== 历史记录配置 ====================
# 单条消息最大字符数（超过部分会被截断）
MAX_SINGLE_CHAR=1000

# 每个用户最大记录数（超出时会自动清理旧记录）
MAX_USER_RECORD_COUNT=50

# 历史记录总字符数限制（用于控制上下文长度）
MAX_HISTORY_CONTENT_CHAR=4000

# 清理旧记录的周期（天），定期清理超过此天数的记录
CLEAR_CYCLE=7

# 历史记录算法：
# - "normal": 普通算法（默认），按时间顺序管理历史
# - "fair": 公平算法，更智能的历史记录管理
HISTORY_ALGORITHM=normal

# ==================== 状态管理配置 ====================
# 状态清理间隔（秒），清理长时间不活动的用户状态
STATUS_CLEANUP_INTERVAL=3600

# ==================== 自动回复配置 ====================
# 自动回复超时时间（秒），超时后自动回复忙碌状态
AUTO_ANSWER_TIMEOUT=10

# ==================== 调试配置 ====================
# 是否打印调试信息
# - yes/true/1/on: 启用调试，会打印完整对话历史和prompt
# - no/false/0/off: 禁用调试（默认）
PRINT_DEBUG = yes

# ==================== Agent工具配置 ====================
# 是否使用LangChain Agent工具
# - yes/true/1/on: 启用Agent工具，支持计算器、时间获取等工具调用
# - no/false/0/off: 禁用Agent工具，直接使用LLM（默认）
USE_AGENT_TOOLS = yes

# Agent模式，影响输出格式：
# - "web": Web模式，逐字流式输出，适合网页应用
# - "onebot": OneBot模式，显示思考过程，适合聊天机器人平台
AGENT_MODE = web

# 输出模式：
# - "normal": 普通模式，一次性返回完整答案
# - "streaming": 流式模式，逐字输出答案（需要前端支持）
OUTPUT_MODE = normal

# ==================== 注意事项 ====================
# 1. 以"#"开头的行是注释，不会生效
# 2. 变量名必须大写，使用下划线分隔
# 3. 等号两边可以有空格，但建议保持一致
# 4. 修改配置后需要重启应用
# 5. 敏感信息请妥善保管，不要提交到版本控制系统
""")
                  
            print("=" * 60)
            print()
            print("   3. 保存文件后重新运行程序")
            print()
            print("📌 重要说明:")
            print("   - REDIS_URL: Redis数据库连接地址")
            print("   - LLM_API_KEY: LLM API密钥（使用Ollama时设为'ollama'）")
            print("   - LLM_BASE_URL: LLM API基础URL")
            print("   - LLM_MODEL: 使用的LLM模型名称")
            print()
            print("🔧 可选配置:")
            print("   - PRINT_DEBUG: 调试信息 (yes/no)")
            print("   - USE_AGENT_TOOLS: 使用LangChain Agent工具 (yes/no)")
            print("   - AGENT_MODE: Agent模式 (web/onebot)")
            print("   - OUTPUT_MODE: 输出模式 (normal/streaming)")
            print()
            sys.exit(1)
    
    @classmethod
    def from_env(cls) -> "Config":
        """从环境变量（包含.env文件）创建配置实例"""
        return cls()
