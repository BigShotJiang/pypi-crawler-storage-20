# QCombo: Automated Commutator Calculation for Quantum Many-Body Operators

[![PyPI version](https://img.shields.io/pypi/v/qcombo.svg)](https://pypi.org/project/qcombo/)
[![Python versions](https://img.shields.io/pypi/pyversions/qcombo.svg)](https://pypi.org/project/qcombo/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

QCombo is a Python library for automated computation of commutators for normal-ordered many-body operators based on the generalized Wick theorem. Designed specifically for nuclear physics and condensed matter applications, it provides efficient and accurate tools for handling complex quantum many-body calculations.

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Installation](#installation)
- [Quick Start](#quick-start)
- [Citation](#citation)
- [License](#license)
- [Support](#support)

## Overview

### Background and Motivation

In quantum mechanics, operator commutators form the foundation of theoretical calculations. In nuclear physics, *ab initio* methods (such as NCSM, CC, IMSRG, etc.) are essential tools for studying nuclear many-body systems. These methods start from nuclear forces constructed from chiral effective field theory and provide approximate but rigorous solutions to quantum many-body problems.

As the number of many-body terms increases, the number of terms in commutators grows exponentially, making manual calculations extremely tedious and error-prone. QCombo addresses this challenge by providing an automated solution for computing commutators of normal-ordered many-body operators.

## Features

- **Based on Generalized Wick Theorem**: Implements automated computation of commutators for normal-ordered many-body operators
- **Many-Body Coupling Support**: Handles commutators of arbitrary-order many-body operators
- **Automated Output Generation**:
  - Generates LaTeX files for commutator expressions
  - Produces input files for the AMC software package to obtain expressions in J-scheme
- **Flexible Configuration**: Allows specification of output to specific many-body ranks
- **Symbolic Computation**: Built on SymPy for precise algebraic manipulations

## Installation

### Install from PyPI (Recommended)

```bash
pip install qcombo
```

### Install from Source

```bash
git clone https://github.com/chenlh73/qcombo.git
cd qcombo
pip install -e .
```

### System Requirements

- Python >= 3.12
- SymPy >= 1.13.3

## Quick Start

### Basic Usage

The following example demonstrates how to compute the [2B, 2B] commutator:

```python
import qcombo

# Compute the [2B, 2B] commutator coupled to all possible many-body ranks
qcombo.easyCombo(2, 2)
```

### Specifying Output Ranks

To output only specific many-body ranks:

```python
import qcombo

# Output only terms coupled to 0-body and 1-body ranks
qcombo.easyCombo(2, 2, [0, 1])
```

## Detailed Usage

### Function Parameters

```python
qcombo.easyCombo(m, n, contraction=None)
```

- `m`: Many-body rank of the first operator (e.g., 2 for two-body operator)
- `n`: Many-body rank of the second operator
- `contraction`: Optional parameter specifying  output ranks
  - Example: `[0, 1]` outputs only zero-body and one-body terms
  - `None` (default) outputs all possible many-body terms

### Output Description

After execution, the program generates:

1. **Console Output**: Displays the computed commutator expressions
2. **LaTeX Files**: Generate expressions in LaTeX format
3. **AMC Input Files**: Create input files for the AMC software package


### Nuclear Physics Applications

In nuclear *ab initio* methods, QCombo can be used for:

1. **IMSRG Flow Equations**: Computing commutators between generators and Hamiltonians

### Education and Research

QCombo is also valuable for quantum mechanics education and research:
- Verifying theoretical derivations
- Exploring contributions from higher-order many-body terms
- Automating tedious symbolic calculations




## Citation

If you use QCombo in your research, please cite:

```bibtex
@software{qcombo2024,
  title = {QCombo: Automated Commutator Calculation for Quantum Many-Body Operators},
  author = {Chen, L.H. and Li, Y. and Hergert, Heiko and Yao, J.M.},
  year = {2024},
  url = {https://github.com/chenlh73/qcombo},
  note = {Based on generalized Wick theorem for automatic commutator calculation of many-body operators}
}
```


## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.


---

*QCombo - Making Quantum Many-Body Calculations Simpler*