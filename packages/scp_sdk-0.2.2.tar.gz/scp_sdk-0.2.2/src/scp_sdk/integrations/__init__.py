"""Integration framework components."""
