"""Tile fetching for satellite-tiler.

This module provides the main tile fetching functionality,
including coordinate conversion, band selection, and post-processing.

AWS credentials are REQUIRED for accessing satellite data:
- Landsat data is hosted on requester-pays S3 buckets
- Credentials can be provided via environment variables, ~/.aws/credentials, or IAM roles (Lambda)
"""

from typing import Dict, List, Optional, Tuple, Union
import numpy as np

from satellite_tiler.models import (
    SatellitePlatform,
    TileResult,
    SceneInfo,
)
from satellite_tiler.coordinates import lat_lon_to_tile, tile_to_bounds
from satellite_tiler.parsers import parse, detect_platform
from satellite_tiler.bands import validate_bands, get_rgb_bands
from satellite_tiler.processing import rescale, apply_colormap, ensure_uint8
from satellite_tiler.exceptions import (
    SatelliteTilerError,
    AuthenticationError,
    OutOfBoundsError,
    InvalidBandError,
)

# Try to import rio-tiler for real data fetching
try:
    from rio_tiler.io import Reader
    HAS_RIO_TILER = True
except ImportError:
    HAS_RIO_TILER = False

# Try to import rasterio and boto3 for AWS access
try:
    import rasterio
    from rasterio.session import AWSSession
    import boto3
    HAS_AWS = True
except ImportError:
    HAS_AWS = False

# Cache for scene asset URLs (scene_id -> asset_urls dict)
_scene_asset_cache: Dict[str, Dict[str, str]] = {}

# Cache for validated AWS session
_aws_session_validated = False


def _validate_aws_credentials() -> None:
    """Validate that AWS credentials are available.
    
    Raises:
        AuthenticationError: If AWS credentials are not configured
    """
    global _aws_session_validated
    
    if _aws_session_validated:
        return
    
    if not HAS_AWS:
        raise AuthenticationError(
            "boto3 is required for AWS access. Install with: pip install boto3"
        )
    
    try:
        session = boto3.Session()
        credentials = session.get_credentials()
        
        if credentials is None:
            raise AuthenticationError(
                "AWS credentials not found. Configure credentials via:\n"
                "  - Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)\n"
                "  - AWS credentials file (~/.aws/credentials)\n"
                "  - IAM role (when running on AWS Lambda/EC2)"
            )
        
        # Try to get frozen credentials to validate they're usable
        frozen_credentials = credentials.get_frozen_credentials()
        if not frozen_credentials.access_key:
            raise AuthenticationError(
                "AWS credentials are incomplete. Ensure access key is configured."
            )
        
        _aws_session_validated = True
        
    except AuthenticationError:
        raise
    except Exception as e:
        raise AuthenticationError(f"Failed to validate AWS credentials: {e}")


def get_tile(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int,
    bands: Optional[List[str]] = None,
    expression: Optional[str] = None,
    scale: int = 1,
    rescale_range: Optional[Tuple[float, float]] = None,
    colormap: Optional[str] = None,
    asset_urls: Optional[Dict[str, str]] = None,
) -> TileResult:
    """Fetch a satellite tile for a location.
    
    Requires AWS credentials to be configured for accessing satellite data.
    
    Args:
        scene_id: Scene identifier string
        lat: Latitude of the location
        lon: Longitude of the location
        zoom: Zoom level (typically 7-14)
        bands: List of band names to fetch (e.g., ["B4", "B3", "B2"])
        expression: Band math expression (not yet supported)
        scale: Scale factor for tile size (1 = 256px, 2 = 512px)
        rescale_range: Optional (min, max) range for rescaling
        colormap: Optional colormap name for single-band data
        asset_urls: Optional dict of asset URLs from STAC API
    
    Returns:
        TileResult with tile data, mask, bounds, and CRS
    
    Raises:
        AuthenticationError: If AWS credentials are not configured
        SatelliteTilerError: If tile fetching fails
    """
    # Validate AWS credentials upfront
    _validate_aws_credentials()
    
    if bands and expression:
        raise ValueError("Cannot specify both bands and expression")
    
    platform = detect_platform(scene_id)
    
    if not bands and not expression:
        bands = get_rgb_bands(platform)
    
    if bands:
        bands = validate_bands(bands, platform)
    
    tile_x, tile_y = lat_lon_to_tile(lat, lon, zoom)
    bounds = tile_to_bounds(tile_x, tile_y, zoom)
    tile_size = 256 * scale
    
    # Cache asset URLs if provided
    if asset_urls:
        _scene_asset_cache[scene_id] = asset_urls
    
    tile_data, mask = _fetch_tile_from_aws(
        scene_id=scene_id,
        platform=platform,
        tile_x=tile_x,
        tile_y=tile_y,
        zoom=zoom,
        bands=bands,
        expression=expression,
        tile_size=tile_size,
    )
    
    if rescale_range:
        in_min = tile_data.min()
        in_max = tile_data.max()
        tile_data = rescale(tile_data, mask, (in_min, in_max), rescale_range)
    
    if colormap and (tile_data.ndim == 2 or (tile_data.ndim == 3 and tile_data.shape[0] == 1)):
        tile_data = apply_colormap(ensure_uint8(tile_data), colormap)
    
    return TileResult(data=tile_data, mask=mask, bounds=bounds, crs="EPSG:3857")


def set_scene_asset_urls(scene_id: str, asset_urls: Dict[str, str]) -> None:
    """Cache asset URLs for a scene (from STAC API response)."""
    _scene_asset_cache[scene_id] = asset_urls


def get_cached_asset_urls(scene_id: str) -> Optional[Dict[str, str]]:
    """Get cached asset URLs for a scene."""
    return _scene_asset_cache.get(scene_id)


def _get_landsat_cog_url(scene_id: str, band: str) -> str:
    """Get the COG URL for a Landsat band."""
    # Check cache for STAC asset URLs
    if scene_id in _scene_asset_cache:
        asset_urls = _scene_asset_cache[scene_id]
        band_to_asset = {
            "B1": "coastal", "B2": "blue", "B3": "green", "B4": "red",
            "B5": "nir08", "B6": "swir16", "B7": "swir22",
            "B10": "lwir11", "B11": "lwir12", "QA": "qa_pixel",
        }
        asset_key = band_to_asset.get(band, band.lower())
        if asset_key in asset_urls:
            return asset_urls[asset_key]
        if band in asset_urls:
            return asset_urls[band]
        if band.lower() in asset_urls:
            return asset_urls[band.lower()]
    
    # Fall back to URL construction
    components = parse(scene_id)
    path = f"{components.path:03d}"
    row = f"{components.row:03d}"
    year = components.acquisition_date.year
    
    sensor = components.sensor
    if sensor.startswith("LC08") or sensor.startswith("LC09"):
        sensor_path = "oli-tirs"
    elif sensor.startswith("LE07"):
        sensor_path = "etm"
    else:
        sensor_path = "oli-tirs"
    
    band_map = {
        "B1": "SR_B1", "B2": "SR_B2", "B3": "SR_B3", "B4": "SR_B4",
        "B5": "SR_B5", "B6": "SR_B6", "B7": "SR_B7",
        "B10": "ST_B10", "B11": "ST_B11", "QA": "QA_PIXEL",
    }
    band_suffix = band_map.get(band, f"SR_{band}")
    
    base_url = "https://usgs-landsat.s3.amazonaws.com"
    return f"{base_url}/collection02/level-2/standard/{sensor_path}/{year}/{path}/{row}/{scene_id}/{scene_id}_{band_suffix}.TIF"


def _get_sentinel2_cog_url(scene_id: str, band: str) -> str:
    """Get the COG URL for a Sentinel-2 band."""
    # Check cache for STAC asset URLs
    if scene_id in _scene_asset_cache:
        asset_urls = _scene_asset_cache[scene_id]
        band_to_asset = {
            "B01": "coastal", "B02": "blue", "B03": "green", "B04": "red",
            "B05": "rededge1", "B06": "rededge2", "B07": "rededge3",
            "B08": "nir", "B8A": "nir08", "B09": "nir09",
            "B11": "swir16", "B12": "swir22",
        }
        asset_key = band_to_asset.get(band, band.lower())
        if asset_key in asset_urls:
            return asset_urls[asset_key]
        if band in asset_urls:
            return asset_urls[band]
        if band.lower() in asset_urls:
            return asset_urls[band.lower()]
    
    # Fall back to URL construction
    components = parse(scene_id)
    tile_id = components.tile_id
    utm_zone = tile_id[1:3]
    lat_band = tile_id[3]
    grid_square = tile_id[4:6]
    
    acq_dt = components.acquisition_datetime
    year = acq_dt[:4]
    month = str(int(acq_dt[4:6]))
    
    band_file = band
    base_url = "https://sentinel-cogs.s3.us-west-2.amazonaws.com"
    return f"{base_url}/sentinel-s2-l2a-cogs/{utm_zone}/{lat_band}/{grid_square}/{year}/{month}/{scene_id}/{band_file}.tif"


def _get_cbers_cog_url(scene_id: str, band: str) -> str:
    """Get the COG URL for a CBERS band."""
    if scene_id in _scene_asset_cache:
        asset_urls = _scene_asset_cache[scene_id]
        if band in asset_urls:
            return asset_urls[band]
        if band.lower() in asset_urls:
            return asset_urls[band.lower()]
    
    components = parse(scene_id)
    path = f"{components.path:03d}"
    row = f"{components.row:03d}"
    camera = components.camera
    
    base_url = "https://cbers-pds.s3.amazonaws.com"
    return f"{base_url}/CBERS4/{camera}/{path}/{row}/{scene_id}/{scene_id}_{band}.tif"


def _fetch_tile_from_aws(
    scene_id: str,
    platform: SatellitePlatform,
    tile_x: int,
    tile_y: int,
    zoom: int,
    bands: Optional[List[str]],
    expression: Optional[str],
    tile_size: int,
) -> Tuple[np.ndarray, np.ndarray]:
    """Fetch real tile data from AWS-hosted COGs using rio-tiler."""
    if not HAS_RIO_TILER:
        raise ImportError(
            "rio-tiler is required for fetching satellite data. "
            "Install with: pip install rio-tiler"
        )
    
    if expression:
        raise NotImplementedError(
            "Band expressions are not yet supported. "
            "Please specify bands directly."
        )
    
    band_data = []
    mask = None
    
    # Set up AWS environment for requester-pays buckets (Landsat)
    aws_env = {"AWS_REQUEST_PAYER": "requester"}
    
    for band in bands:
        if platform == SatellitePlatform.LANDSAT8:
            url = _get_landsat_cog_url(scene_id, band)
        elif platform == SatellitePlatform.SENTINEL2:
            url = _get_sentinel2_cog_url(scene_id, band)
        elif platform == SatellitePlatform.CBERS:
            url = _get_cbers_cog_url(scene_id, band)
        else:
            raise SatelliteTilerError(f"Unsupported platform: {platform}")
        
        try:
            with rasterio.Env(**aws_env):
                with Reader(url) as src:
                    img = src.tile(tile_x, tile_y, zoom, tilesize=tile_size)
                    band_data.append(img.data[0])
                    if mask is None:
                        mask = img.mask
        except Exception as e:
            error_msg = str(e)
            if "403" in error_msg or "Access Denied" in error_msg:
                raise AuthenticationError(
                    f"Access denied fetching {url}. "
                    "Ensure AWS credentials have permission to access requester-pays buckets."
                ) from e
            raise SatelliteTilerError(
                f"Failed to fetch band {band} from {url}: {e}"
            ) from e
    
    data = np.stack(band_data, axis=0)
    
    # Normalize data to uint8 for display
    if platform == SatellitePlatform.LANDSAT8:
        data = np.clip((data.astype(np.float32) - 7000) / 6000 * 255, 0, 255).astype(np.uint8)
    elif platform == SatellitePlatform.SENTINEL2:
        data = np.clip(data.astype(np.float32) / 10000 * 255, 0, 255).astype(np.uint8)
    elif platform == SatellitePlatform.CBERS:
        data = np.clip(data.astype(np.float32) / 10000 * 255, 0, 255).astype(np.uint8)
    else:
        data = ensure_uint8(data)
    
    if mask is None:
        mask = np.full((tile_size, tile_size), 255, dtype=np.uint8)
    
    return data, mask


def validate_tile_request(bands: Optional[List[str]], expression: Optional[str]) -> None:
    """Validate tile request parameters."""
    if bands and expression:
        raise ValueError("Cannot specify both 'bands' and 'expression'.")


def calculate_tile_dimensions(scale: int) -> int:
    """Calculate tile dimensions based on scale factor."""
    return 256 * scale
