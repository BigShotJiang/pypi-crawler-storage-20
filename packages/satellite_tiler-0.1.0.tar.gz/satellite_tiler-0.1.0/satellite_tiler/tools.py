"""Agent tools interface for satellite-tiler.

This module provides tool functions optimized for AI agents (AWS Strands, LangChain, etc.).
Each tool returns JSON-serializable dictionaries with human-readable messages.
"""

import base64
from typing import Dict, List, Optional, Any

from satellite_tiler.models import SatellitePlatform
from satellite_tiler.discovery import discover, list_scenes, get_bands_for_platform
from satellite_tiler.tiles import get_tile
from satellite_tiler.metadata import get_scene_metadata, get_scene_bounds, get_zoom_levels
from satellite_tiler.encoding import encode
from satellite_tiler.bands import get_rgb_bands, get_false_color_bands


def discover_satellite_data(lat: float, lon: float) -> Dict[str, Any]:
    """Discover available satellite missions at a geographic location.
    
    Use this tool when you need to find out what satellite imagery 
    is available for a specific location before fetching tiles.
    
    Args:
        lat: Latitude in decimal degrees (-90 to 90)
        lon: Longitude in decimal degrees (-180 to 180)
    
    Returns:
        Dictionary with:
        - missions: List of available missions with bands and resolution info
        - location: The queried coordinates
        - message: Human-readable summary
    
    Example:
        >>> result = discover_satellite_data(lat=40.7128, lon=-74.0060)
        >>> print(result["message"])
        "Found 2 satellite missions covering this location"
    """
    missions = discover(lat, lon)
    
    mission_list = []
    for m in missions:
        mission_list.append({
            "platform": m.platform.value,
            "bands": [b.name for b in m.bands],
            "resolution_meters": m.resolution,
            "date_range": {
                "start": m.date_range[0],
                "end": m.date_range[1],
            },
            "description": _get_platform_description(m.platform),
        })
    
    return {
        "missions": mission_list,
        "location": {"lat": lat, "lon": lon},
        "message": f"Found {len(missions)} satellite mission(s) covering this location",
    }


def list_satellite_scenes(
    lat: float,
    lon: float,
    platform: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    max_cloud_cover: float = 20.0,
    limit: int = 5,
) -> Dict[str, Any]:
    """List available satellite scenes for a mission at a location.
    
    Use this tool after discover_satellite_data to find specific scenes
    you can fetch tiles from. Returns scenes sorted by date (newest first).
    
    Args:
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees  
        platform: Satellite platform ("landsat8", "sentinel2", or "cbers")
        start_date: Filter scenes after this date (ISO format: "2024-01-01")
        end_date: Filter scenes before this date (ISO format: "2024-12-31")
        max_cloud_cover: Maximum cloud cover percentage (default 20%)
        limit: Maximum scenes to return (default 5)
    
    Returns:
        Dictionary with:
        - scenes: List of scenes with id, date, cloud_cover
        - filters_applied: The filters that were used
        - message: Human-readable summary
    
    Example:
        >>> result = list_satellite_scenes(lat=40.7128, lon=-74.0060, platform="landsat8")
        >>> print(result["scenes"][0]["scene_id"])
    """
    from datetime import date as date_type
    
    # Parse platform
    try:
        sat_platform = SatellitePlatform(platform.lower())
    except ValueError:
        return {
            "scenes": [],
            "filters_applied": {"platform": platform},
            "message": f"Unknown platform '{platform}'. Use 'landsat8', 'sentinel2', or 'cbers'.",
            "error": True,
        }
    
    # Parse dates
    start = None
    end = None
    if start_date:
        start = date_type.fromisoformat(start_date)
    if end_date:
        end = date_type.fromisoformat(end_date)
    
    scenes = list_scenes(
        lat=lat,
        lon=lon,
        platform=sat_platform,
        start_date=start,
        end_date=end,
        max_cloud_cover=max_cloud_cover,
        limit=limit,
    )
    
    scene_list = []
    for s in scenes:
        scene_list.append({
            "scene_id": s.scene_id,
            "date": s.acquisition_date.isoformat(),
            "cloud_cover": s.cloud_cover,
            "platform": s.platform.value,
            "asset_urls": s.asset_urls,  # Include STAC asset URLs
        })
    
    filters = {
        "platform": platform,
        "max_cloud_cover": max_cloud_cover,
    }
    if start_date:
        filters["start_date"] = start_date
    if end_date:
        filters["end_date"] = end_date
    
    if scenes:
        message = f"Found {len(scenes)} scene(s) with less than {max_cloud_cover}% cloud cover"
    else:
        message = f"No scenes found. Try increasing max_cloud_cover or adjusting date range."
    
    return {
        "scenes": scene_list,
        "filters_applied": filters,
        "message": message,
    }


def get_satellite_tile(
    scene_id: str,
    lat: float,
    lon: float,
    zoom: int,
    bands: Optional[List[str]] = None,
    expression: Optional[str] = None,
    format: str = "png",
    asset_urls: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """Fetch a satellite imagery tile for a specific scene and location.
    
    Use this tool after list_satellite_scenes to get actual imagery.
    Returns the tile as a base64-encoded image.
    
    Args:
        scene_id: Scene identifier from list_satellite_scenes
        lat: Latitude in decimal degrees
        lon: Longitude in decimal degrees
        zoom: Zoom level (1-18, higher = more detail)
        bands: List of bands for RGB composite (e.g., ["B4", "B3", "B2"] for true color)
        expression: Band math expression (e.g., "(B4-B3)/(B4+B3)" for NDVI)
        format: Output format ("png", "jpeg", or "webp")
        asset_urls: Optional dict of asset URLs from list_satellite_scenes
    
    Returns:
        Dictionary with:
        - image_base64: Base64-encoded image data
        - format: Image format used
        - bounds: Geographic bounds of the tile
        - bands_used: Which bands were included
        - message: Human-readable summary
    
    Common band combinations:
        - True color (Landsat): ["B4", "B3", "B2"]
        - False color (vegetation): ["B5", "B4", "B3"]
        - NDVI expression: "(B5-B4)/(B5+B4)"
    
    Example:
        >>> result = get_satellite_tile(
        ...     scene_id="LC08_L1TP_014032_20240615_...",
        ...     lat=40.7128, lon=-74.0060, zoom=12,
        ...     bands=["B4", "B3", "B2"]
        ... )
    """
    try:
        result = get_tile(
            scene_id=scene_id,
            lat=lat,
            lon=lon,
            zoom=zoom,
            bands=bands,
            expression=expression,
            asset_urls=asset_urls,
        )
        
        # Encode to image format
        image_bytes = encode(result.data, result.mask, format=format)
        image_base64 = base64.b64encode(image_bytes).decode('utf-8')
        
        # Determine what bands were used
        if expression:
            bands_used = [expression]
        elif bands:
            bands_used = bands
        else:
            bands_used = ["default RGB"]
        
        return {
            "image_base64": image_base64,
            "format": format,
            "bounds": {
                "west": result.bounds[0],
                "south": result.bounds[1],
                "east": result.bounds[2],
                "north": result.bounds[3],
            },
            "bands_used": bands_used,
            "tile_size": result.data.shape[-1],
            "message": f"Retrieved {result.data.shape[-1]}x{result.data.shape[-1]} tile at zoom {zoom}",
        }
    
    except Exception as e:
        return {
            "image_base64": None,
            "format": format,
            "bounds": None,
            "bands_used": bands or [],
            "message": f"Error fetching tile: {str(e)}",
            "error": True,
        }


def get_scene_info(scene_id: str) -> Dict[str, Any]:
    """Get detailed metadata about a satellite scene.
    
    Use this tool to get information about a scene's coverage,
    acquisition details, and band statistics.
    
    Args:
        scene_id: Scene identifier
    
    Returns:
        Dictionary with scene metadata including bounds, date,
        and available zoom levels.
    
    Example:
        >>> result = get_scene_info("LC08_L1TP_014032_20240615_20240620_02_T1")
        >>> print(result["acquisition_date"])
    """
    try:
        metadata = get_scene_metadata(scene_id)
        zoom_levels = get_zoom_levels(scene_id)
        
        return {
            "scene_id": metadata["scene_id"],
            "platform": metadata["platform"],
            "acquisition_date": metadata["acquisition_date"],
            "bounds": metadata["bounds"],
            "zoom_levels": zoom_levels,
            "message": f"Scene from {metadata['platform']} acquired on {metadata['acquisition_date']}",
        }
    
    except Exception as e:
        return {
            "scene_id": scene_id,
            "message": f"Error getting scene info: {str(e)}",
            "error": True,
        }


def _get_platform_description(platform: SatellitePlatform) -> str:
    """Get human-readable description for a platform."""
    descriptions = {
        SatellitePlatform.LANDSAT8: "Landsat 8 OLI/TIRS - 30m resolution multispectral imagery",
        SatellitePlatform.SENTINEL2: "Sentinel-2 MSI - 10m resolution multispectral imagery",
        SatellitePlatform.CBERS: "CBERS-4 MUX - 20m resolution multispectral imagery",
    }
    return descriptions.get(platform, "Unknown platform")


# Optional: Strands agent integration
try:
    from strands import tool
    
    # Register tools with Strands decorator
    discover_satellite_data = tool(discover_satellite_data)
    list_satellite_scenes = tool(list_satellite_scenes)
    get_satellite_tile = tool(get_satellite_tile)
    get_scene_info = tool(get_scene_info)
    
except ImportError:
    # Strands not installed, tools work as regular functions
    pass
