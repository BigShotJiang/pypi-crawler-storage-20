"""
satellite-tiler: A Python library for accessing open-source satellite imagery.

This library provides a simple API for discovering and fetching satellite tiles
from AWS-hosted data sources including Landsat 8, Sentinel-2, and CBERS.

Basic Usage:
    >>> from satellite_tiler import discover, list_scenes, get_tile
    >>> 
    >>> # Step 1: Discover available missions at a location
    >>> missions = discover(lat=40.7128, lon=-74.0060)
    >>> 
    >>> # Step 2: List available scenes
    >>> scenes = list_scenes(lat=40.7128, lon=-74.0060, 
    ...                      platform=SatellitePlatform.LANDSAT8,
    ...                      max_cloud_cover=20)
    >>> 
    >>> # Step 3: Fetch a tile
    >>> result = get_tile(scene_id=scenes[0].scene_id,
    ...                   lat=40.7128, lon=-74.0060, zoom=12,
    ...                   bands=["B4", "B3", "B2"])

For AI Agent Integration:
    >>> from satellite_tiler import tools
    >>> 
    >>> # Use JSON-serializable tool functions
    >>> result = tools.discover_satellite_data(lat=40.7128, lon=-74.0060)
    >>> print(result["message"])
"""

__version__ = "0.1.0"

# Core data models
from satellite_tiler.models import (
    SatellitePlatform,
    BandInfo,
    MissionInfo,
    SceneInfo,
    TileResult,
    LandsatSceneComponents,
    Sentinel2SceneComponents,
    CBERSSceneComponents,
)

# Exceptions
from satellite_tiler.exceptions import (
    SatelliteTilerError,
    OutOfBoundsError,
    InvalidBandError,
    InvalidSceneIdError,
    NoSceneFoundError,
    AuthenticationError,
    ConnectionError,
)

# Main API functions
from satellite_tiler.discovery import (
    discover,
    list_scenes,
    get_bands_for_platform,
)

from satellite_tiler.tiles import (
    get_tile,
    set_scene_asset_urls,
    get_cached_asset_urls,
)

from satellite_tiler.metadata import (
    get_scene_bounds,
    get_scene_metadata,
    get_zoom_levels,
)

from satellite_tiler.parsers import (
    parse as parse_scene_id,
    format_scene_id,
    detect_platform,
)

from satellite_tiler.coordinates import (
    lat_lon_to_tile,
    tile_to_bounds,
)

from satellite_tiler.encoding import (
    to_png,
    to_jpeg,
    to_webp,
    encode,
)

from satellite_tiler.processing import (
    rescale,
    apply_colormap,
    get_available_colormaps,
)

from satellite_tiler.bands import (
    validate_bands,
    get_valid_bands,
    get_rgb_bands,
    get_false_color_bands,
)

# Agent tools module
from satellite_tiler import tools

__all__ = [
    # Version
    "__version__",
    
    # Enums
    "SatellitePlatform",
    
    # Data models
    "BandInfo",
    "MissionInfo", 
    "SceneInfo",
    "TileResult",
    "LandsatSceneComponents",
    "Sentinel2SceneComponents",
    "CBERSSceneComponents",
    
    # Exceptions
    "SatelliteTilerError",
    "OutOfBoundsError",
    "InvalidBandError",
    "InvalidSceneIdError",
    "NoSceneFoundError",
    "AuthenticationError",
    "ConnectionError",
    
    # Main API
    "discover",
    "list_scenes",
    "get_tile",
    "get_bands_for_platform",
    "set_scene_asset_urls",
    "get_cached_asset_urls",
    
    # Metadata
    "get_scene_bounds",
    "get_scene_metadata",
    "get_zoom_levels",
    
    # Parsing
    "parse_scene_id",
    "format_scene_id",
    "detect_platform",
    
    # Coordinates
    "lat_lon_to_tile",
    "tile_to_bounds",
    
    # Encoding
    "to_png",
    "to_jpeg",
    "to_webp",
    "encode",
    
    # Processing
    "rescale",
    "apply_colormap",
    "get_available_colormaps",
    
    # Bands
    "validate_bands",
    "get_valid_bands",
    "get_rgb_bands",
    "get_false_color_bands",
    
    # Agent tools
    "tools",
]
