"""Tests for metadata retrieval."""

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st
import json

from satellite_tiler.models import (
    SatellitePlatform,
    BandInfo,
    MissionInfo,
    SceneInfo,
)
from satellite_tiler.metadata import (
    get_scene_bounds,
    get_scene_metadata,
    get_zoom_levels,
    to_json,
    from_json,
)
from satellite_tiler.tests.conftest import (
    mission_info_strategy,
    scene_info_strategy,
    band_info_strategy,
)


class TestMetadataJSONRoundTrip:
    """Property 16: Metadata JSON Round-Trip
    
    For any metadata object (MissionInfo, SceneInfo, TileResult),
    serializing to JSON and deserializing back SHALL produce an
    equivalent object.
    
    Validates: Requirements 7.4
    """

    @given(band_info=band_info_strategy())
    @settings(max_examples=100)
    def test_band_info_json_round_trip(self, band_info: BandInfo):
        """Feature: satellite-tiler, Property 16: BandInfo JSON round-trip."""
        # Serialize to JSON
        json_str = to_json(band_info.to_dict())
        
        # Deserialize back
        data = json.loads(json_str)
        restored = BandInfo.from_dict(data)
        
        # Should be equivalent
        assert restored.name == band_info.name
        assert restored.description == band_info.description
        assert restored.wavelength == band_info.wavelength
        assert restored.resolution == band_info.resolution

    @given(mission_info=mission_info_strategy())
    @settings(max_examples=100)
    def test_mission_info_json_round_trip(self, mission_info: MissionInfo):
        """Feature: satellite-tiler, Property 16: MissionInfo JSON round-trip."""
        # Serialize to JSON
        json_str = to_json(mission_info.to_dict())
        
        # Deserialize back
        data = json.loads(json_str)
        restored = MissionInfo.from_dict(data)
        
        # Should be equivalent
        assert restored.platform == mission_info.platform
        assert len(restored.bands) == len(mission_info.bands)
        assert restored.date_range == mission_info.date_range
        assert restored.resolution == mission_info.resolution

    @given(scene_info=scene_info_strategy())
    @settings(max_examples=100)
    def test_scene_info_json_round_trip(self, scene_info: SceneInfo):
        """Feature: satellite-tiler, Property 16: SceneInfo JSON round-trip."""
        # Serialize to JSON
        json_str = to_json(scene_info.to_dict())
        
        # Deserialize back
        data = json.loads(json_str)
        restored = SceneInfo.from_dict(data)
        
        # Should be equivalent
        assert restored.scene_id == scene_info.scene_id
        assert restored.platform == scene_info.platform
        assert restored.acquisition_date == scene_info.acquisition_date
        assert restored.cloud_cover == scene_info.cloud_cover
        assert restored.bounds == scene_info.bounds


class TestGetSceneBounds:
    """Unit tests for get_scene_bounds function."""

    def test_landsat_bounds(self):
        """get_scene_bounds should return bounds for Landsat scene."""
        result = get_scene_bounds("LC08_L1TP_014032_20240615_20240620_02_T1")
        
        assert "bounds" in result
        assert len(result["bounds"]) == 4
        assert result["crs"] == "EPSG:4326"

    def test_sentinel2_bounds(self):
        """get_scene_bounds should return bounds for Sentinel-2 scene."""
        result = get_scene_bounds("S2A_MSIL2A_20240615T154911_N0510_R054_T18TXM_20240615T213159")
        
        assert "bounds" in result
        assert len(result["bounds"]) == 4

    def test_cbers_bounds(self):
        """get_scene_bounds should return bounds for CBERS scene."""
        result = get_scene_bounds("CBERS_4_MUX_20240615_178_106_L4")
        
        assert "bounds" in result
        assert len(result["bounds"]) == 4


class TestGetSceneMetadata:
    """Unit tests for get_scene_metadata function."""

    def test_metadata_contains_required_fields(self):
        """get_scene_metadata should return all required fields."""
        result = get_scene_metadata("LC08_L1TP_014032_20240615_20240620_02_T1")
        
        assert "scene_id" in result
        assert "platform" in result
        assert "acquisition_date" in result
        assert "bounds" in result
        assert "statistics" in result

    def test_metadata_statistics_per_band(self):
        """get_scene_metadata should return statistics for each band."""
        result = get_scene_metadata("LC08_L1TP_014032_20240615_20240620_02_T1")
        
        stats = result["statistics"]
        assert len(stats) > 0
        
        # Check first band has required stats
        first_band = list(stats.values())[0]
        assert "min" in first_band
        assert "max" in first_band
        assert "mean" in first_band


class TestGetZoomLevels:
    """Unit tests for get_zoom_levels function."""

    def test_landsat_zoom_levels(self):
        """get_zoom_levels should return appropriate levels for Landsat."""
        result = get_zoom_levels("LC08_L1TP_014032_20240615_20240620_02_T1")
        
        assert "minzoom" in result
        assert "maxzoom" in result
        assert result["minzoom"] < result["maxzoom"]
        assert result["maxzoom"] <= 14  # 30m resolution limit

    def test_sentinel2_zoom_levels(self):
        """get_zoom_levels should return higher max for Sentinel-2."""
        result = get_zoom_levels("S2A_MSIL2A_20240615T154911_N0510_R054_T18TXM_20240615T213159")
        
        assert result["maxzoom"] >= 14  # 10m resolution allows higher zoom


class TestToJson:
    """Unit tests for to_json function."""

    def test_to_json_dict(self):
        """to_json should serialize dictionaries."""
        data = {"key": "value", "number": 42}
        result = to_json(data)
        
        assert json.loads(result) == data

    def test_to_json_nested(self):
        """to_json should serialize nested structures."""
        data = {
            "outer": {
                "inner": [1, 2, 3]
            }
        }
        result = to_json(data)
        
        assert json.loads(result) == data
