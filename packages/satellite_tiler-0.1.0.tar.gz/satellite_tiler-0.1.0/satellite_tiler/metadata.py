"""Metadata retrieval for satellite-tiler.

This module provides functions for retrieving metadata about satellite scenes,
including bounds, band statistics, and zoom levels.
"""

import json
from typing import Dict, Any, Tuple, Optional
from dataclasses import asdict

from satellite_tiler.models import (
    SatellitePlatform,
    MissionInfo,
    SceneInfo,
    BandInfo,
)
from satellite_tiler.parsers import parse, detect_platform


def get_scene_bounds(scene_id: str) -> Dict[str, Any]:
    """Get geographic bounds for a scene.
    
    Args:
        scene_id: Scene identifier string
    
    Returns:
        Dictionary with bounds in EPSG:4326:
        {
            "bounds": [west, south, east, north],
            "crs": "EPSG:4326"
        }
    
    Example:
        >>> bounds = get_scene_bounds("LC08_L1TP_014032_20240615_20240620_02_T1")
        >>> bounds["bounds"]
        [-74.5, 40.5, -73.5, 41.5]
    """
    # In a real implementation, this would query the actual scene metadata
    # For now, return mock bounds based on scene ID
    platform = detect_platform(scene_id)
    components = parse(scene_id)
    
    # Generate approximate bounds based on path/row or tile
    if platform == SatellitePlatform.LANDSAT8:
        # Landsat scenes are roughly 185km x 180km
        # Use path/row to estimate center
        path = components.path
        row = components.row
        center_lon = -180 + (path * 1.5)  # Rough approximation
        center_lat = 90 - (row * 1.0)
        bounds = [
            center_lon - 1.0,
            center_lat - 1.0,
            center_lon + 1.0,
            center_lat + 1.0,
        ]
    elif platform == SatellitePlatform.SENTINEL2:
        # Sentinel-2 tiles are 100km x 100km
        # Use tile ID to estimate bounds
        bounds = [-74.5, 40.5, -73.5, 41.5]  # Default NYC area
    else:  # CBERS
        path = components.path
        row = components.row
        center_lon = -85 + (path * 0.5)
        center_lat = 15 - (row * 0.5)
        bounds = [
            center_lon - 0.5,
            center_lat - 0.5,
            center_lon + 0.5,
            center_lat + 0.5,
        ]
    
    return {
        "bounds": bounds,
        "crs": "EPSG:4326",
    }


def get_scene_metadata(
    scene_id: str,
    pmin: float = 2.0,
    pmax: float = 98.0,
) -> Dict[str, Any]:
    """Get detailed metadata for a scene.
    
    Args:
        scene_id: Scene identifier string
        pmin: Lower percentile for statistics (default 2)
        pmax: Upper percentile for statistics (default 98)
    
    Returns:
        Dictionary with scene metadata including:
        - bounds: Geographic bounds
        - statistics: Band statistics (min, max, percentiles)
        - platform: Satellite platform
        - acquisition_date: Date of acquisition
    
    Example:
        >>> meta = get_scene_metadata("LC08_L1TP_014032_20240615_20240620_02_T1")
        >>> meta["platform"]
        "landsat8"
    """
    platform = detect_platform(scene_id)
    components = parse(scene_id)
    bounds_info = get_scene_bounds(scene_id)
    
    # Get acquisition date based on platform
    if platform == SatellitePlatform.LANDSAT8:
        acq_date = components.acquisition_date.isoformat()
    elif platform == SatellitePlatform.SENTINEL2:
        acq_date = components.acquisition_date.isoformat()
    else:
        acq_date = components.acquisition_date.isoformat()
    
    # Generate mock band statistics
    # In a real implementation, this would compute actual statistics
    from satellite_tiler.discovery import get_bands_for_platform
    bands = get_bands_for_platform(platform)
    
    statistics = {}
    for band in bands:
        statistics[band.name] = {
            "min": 0,
            "max": 10000,
            f"p{int(pmin)}": 100,
            f"p{int(pmax)}": 8000,
            "mean": 3000,
            "std": 1500,
        }
    
    return {
        "scene_id": scene_id,
        "platform": platform.value,
        "acquisition_date": acq_date,
        "bounds": bounds_info["bounds"],
        "crs": bounds_info["crs"],
        "statistics": statistics,
    }


def get_zoom_levels(scene_id: str) -> Dict[str, int]:
    """Get appropriate zoom levels for a scene.
    
    Returns min and max zoom levels suitable for web mapping.
    
    Args:
        scene_id: Scene identifier string
    
    Returns:
        Dictionary with minzoom and maxzoom
    
    Example:
        >>> zooms = get_zoom_levels("LC08_L1TP_014032_20240615_20240620_02_T1")
        >>> zooms
        {"minzoom": 7, "maxzoom": 14}
    """
    platform = detect_platform(scene_id)
    
    # Zoom levels based on native resolution
    if platform == SatellitePlatform.LANDSAT8:
        # 30m resolution
        return {"minzoom": 7, "maxzoom": 14}
    elif platform == SatellitePlatform.SENTINEL2:
        # 10m resolution
        return {"minzoom": 7, "maxzoom": 15}
    else:  # CBERS
        # 20m resolution
        return {"minzoom": 7, "maxzoom": 14}


def to_json(obj: Any) -> str:
    """Serialize object to JSON string.
    
    Handles dataclasses, enums, and dates.
    
    Args:
        obj: Object to serialize
    
    Returns:
        JSON string
    """
    def default_serializer(o):
        if hasattr(o, 'to_dict'):
            return o.to_dict()
        elif hasattr(o, 'value'):  # Enum
            return o.value
        elif hasattr(o, 'isoformat'):  # date/datetime
            return o.isoformat()
        elif hasattr(o, '__dict__'):
            return o.__dict__
        else:
            raise TypeError(f"Object of type {type(o)} is not JSON serializable")
    
    return json.dumps(obj, default=default_serializer, indent=2)


def from_json(json_str: str, cls: type) -> Any:
    """Deserialize JSON string to object.
    
    Args:
        json_str: JSON string
        cls: Target class (must have from_dict method)
    
    Returns:
        Deserialized object
    """
    data = json.loads(json_str)
    if hasattr(cls, 'from_dict'):
        return cls.from_dict(data)
    return data
