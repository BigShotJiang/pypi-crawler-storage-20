from zoulib.yttik.engines.ytengine import YTDLPEngine
from zoulib.yttik.exceptions import UnsupportedPlatformError

def resolve_engine(url: str):
    url = url.lower()

    if "youtube.com" in url or "youtu.be" in url:
        return YTDLPEngine(url)

    if "tiktok.com" in url:
        return YTDLPEngine(url)

    raise UnsupportedPlatformError("Platform not supported")
