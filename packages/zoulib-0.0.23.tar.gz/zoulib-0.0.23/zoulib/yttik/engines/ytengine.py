import shutil
import yt_dlp

from .base import BaseEngine
from ..exceptions import RuntimeMissingError, DownloadFailedError

class YTDLPEngine(BaseEngine):
    def __init__(self, url: str):
        super().__init__(url)
        self._check_runtime()

    def _check_runtime(self):
        if not shutil.which("node"):
            raise RuntimeMissingError(
                "Node.js is required for YouTube downloads.\n"
                "Install from https://nodejs.org/"
            )

    def download(self):
        options = {
            "outtmpl": "%(title)s.%(ext)s",
            "quiet": True,
            "noplaylist": True,
        }

        try:
            with yt_dlp.YoutubeDL(options) as ydl:
                ydl.download([self.url])
        except Exception as e:
            raise DownloadFailedError("Download failed") from e
