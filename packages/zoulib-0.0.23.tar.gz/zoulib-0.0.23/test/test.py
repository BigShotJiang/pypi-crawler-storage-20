from zoulib.yttik import getlink

url = "https://youtu.be/dQw4w9WgXcQ"
getlink(url).getdownload()
