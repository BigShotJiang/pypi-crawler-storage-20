---
name: resolve-conflicts
description: Resolves merge conflicts in Unity YAML files. Analyzes Git/Perforce logs to understand modification context, automatically resolves non-overlapping changes, and interactively resolves overlapping conflicts with user input.
---

# Unity Merge Conflict Resolution Skill

Resolve merge conflicts in Unity files (.prefab, .unity, .asset) using VCS context analysis and semantic 3-way merge.

## Workflow

### Step 1: Identify Conflict Files

```bash
# For Git
git status --porcelain | grep "^UU"
git diff --name-only --diff-filter=U

# For Perforce
p4 resolve -n
```

### Step 2: Analyze Modification Context

**Git:**
```bash
# Our branch changes
git log --oneline HEAD~5..HEAD -- <filepath>
git show HEAD:<filepath> > /tmp/ours.yaml

# Their branch changes
git log --oneline MERGE_HEAD~5..MERGE_HEAD -- <filepath>
git show MERGE_HEAD:<filepath> > /tmp/theirs.yaml

# Common ancestor
git show $(git merge-base HEAD MERGE_HEAD):<filepath> > /tmp/base.yaml
```

**Perforce:**
```bash
# Check changelist descriptions
p4 changes -l -m 5 <filepath>

# File history
p4 filelog -m 10 <filepath>

# Changelist details
p4 describe -s <changelist_number>
```

### Step 3: Perform Semantic Merge

```bash
# 3-way semantic merge
unityflow merge /tmp/base.yaml /tmp/ours.yaml /tmp/theirs.yaml -o merged.yaml

# Or attempt automatic resolution
unityflow resolve --dry-run  # Preview first
unityflow resolve            # Actual resolution
```

### Step 4: Analyze Conflicts and Query User

If merge results contain conflicts:

1. **Display Conflict Details**
   ```
   [Conflict 1] Player/Transform
     Property: m_LocalPosition.x
     Base:   0
     Ours:   10 (commit abc123: "Adjust player start position")
     Theirs: 5  (commit def456: "Level design adjustments")
   ```

2. **Context-Based Suggestions**
   - Understand intent from commit/changelist descriptions
   - Analyze which side represents a more intentional change
   - Explain suggestion and reasoning

3. **Query User**
   ```
   For this conflict:
   - (o) ours: Use 10 - "Adjust player start position"
   - (t) theirs: Use 5 - "Level design adjustments"
   - (b) base: Use 0 - Keep original value

   Which value would you like to use?
   ```

### Step 5: Apply Results

```bash
# Save resolved file
unityflow normalize merged.yaml  # Normalize

# Git: Mark as resolved
git add <filepath>

# Perforce: Mark as resolved
p4 resolve -ae <filepath>
```

---

## AI Analysis Guidelines

### Finding Hints from Commit/Changelist Descriptions

| Keyword | Meaning | Priority |
|---------|---------|----------|
| fix, bug, crash | Bug fix | High |
| position, layout, align | Layout change | Context check needed |
| add, new, implement | New feature | Medium |
| refactor, cleanup | Refactoring | Low |
| revert | Rollback | Context check needed |

### Auto-Resolvable Cases

1. **Different objects modified**: One side modifies Player, other modifies Enemy
2. **Different components modified**: One side modifies Transform, other modifies SpriteRenderer
3. **Different properties modified**: One side modifies position, other modifies color

### Cases Requiring User Confirmation

1. **Same property modified differently**: Both modified position.x
2. **One deleted, other modified**: Object deletion vs property change
3. **Semantic conflict**: Both increased sorting order

---

## Usage Examples

### User Request Example

```
There's a merge conflict in Player.prefab. Please resolve it.
```

### AI Response Example

```
I'll analyze the conflict in Player.prefab.

[Context Analysis]
- Our branch (abc123): "Adjust player movement speed"
- Their branch (def456): "Level balancing"

[Auto-Resolved]
✅ Player/Rigidbody2D/m_Mass: 1.5 (theirs) - Non-overlapping change
✅ Player/SpriteRenderer/m_Color: rgba(1,1,1,1) (ours) - Non-overlapping change

[Conflict Detected]
❌ Player/MonoBehaviour/moveSpeed
   - Base: 5.0
   - Ours: 7.0 ("Adjust player movement speed")
   - Theirs: 4.0 ("Level balancing")

This property was intentionally modified in both branches.
"Adjust player movement speed" appears to be a more specific change.

Which value would you like to use?
1. 7.0 (ours) - Increase speed
2. 4.0 (theirs) - Decrease speed
3. 5.0 (base) - Keep original value
4. Enter a different value
```

---

## Important Notes

1. **Always backup**: Recommended to backup original files before merging
2. **Use unityflow**: Unity YAML must be processed with unityflow
3. **Verify**: Check integrity with `unityflow validate` after merging
4. **Test**: Recommended to verify actual behavior in Unity

---

## Related Commands

```bash
# Preview conflicts
unityflow resolve --dry-run

# Auto-resolve only (no interaction)
unityflow resolve --accept ours
unityflow resolve --accept theirs

# Resolve specific file only
unityflow resolve-file base.yaml ours.yaml theirs.yaml -o result.yaml

# Check diff
unityflow diff old.prefab new.prefab

# Verify result
unityflow validate merged.prefab
```
