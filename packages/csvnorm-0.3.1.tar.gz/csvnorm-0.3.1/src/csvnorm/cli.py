"""Command-line interface for csvnorm."""

import argparse
import sys
from pathlib import Path

from rich.console import Console
from rich_argparse import RichHelpFormatter

from csvnorm import __version__
from csvnorm.core import process_csv
from csvnorm.utils import setup_logger

console = Console()


def show_banner() -> None:
    """Show ASCII art banner if pyfiglet is available."""
    try:
        from pyfiglet import figlet_format
        banner = figlet_format("csvnorm", font="slant")
        console.print(banner, style="bold cyan")
    except ImportError:
        # pyfiglet not installed, skip banner
        pass


def create_parser() -> argparse.ArgumentParser:
    """Create and return the argument parser."""
    parser = argparse.ArgumentParser(
        prog="csvnorm",
        description="Validate and normalize CSV files for exploratory data analysis",
        formatter_class=RichHelpFormatter,
        epilog="""\
Examples:
  csvnorm data.csv -d ';' -o output_folder --force
  csvnorm data.csv --keep-names --delimiter '\\t'
  csvnorm data.csv -V
""",
    )

    parser.add_argument(
        "input_file",
        type=Path,
        help="Input CSV file path",
    )

    parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="Force overwrite of existing output files",
    )

    parser.add_argument(
        "-k",
        "--keep-names",
        action="store_true",
        help=(
            "Keep original column names (disable snake_case normalization). "
            "By default, column names are converted to snake_case format "
            "(e.g., 'Column Name' becomes 'column_name')."
        ),
    )

    parser.add_argument(
        "-d",
        "--delimiter",
        default=",",
        help="Set custom field delimiter (default: comma). Example: -d ';'",
    )

    parser.add_argument(
        "-o",
        "--output-dir",
        type=Path,
        default=Path.cwd(),
        help="Set custom output directory (default: current working directory)",
    )

    parser.add_argument(
        "-V",
        "--verbose",
        action="store_true",
        help="Enable verbose output for debugging",
    )

    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    return parser


def main(argv: list[str] | None = None) -> int:
    """Main entry point for the CLI.

    Args:
        argv: Command line arguments (defaults to sys.argv[1:]).

    Returns:
        Exit code: 0 for success, 1 for error.
    """
    parser = create_parser()

    # Handle missing arguments gracefully
    if argv is None:
        argv = sys.argv[1:]

    if not argv or (len(argv) == 1 and argv[0] in ['-h', '--help']):
        parser.print_help()
        return 0 if argv else 2

    args = parser.parse_args(argv)

    # Show banner in verbose mode
    if args.verbose:
        show_banner()

    # Setup logging
    setup_logger(args.verbose)

    # Run processing
    return process_csv(
        input_file=args.input_file,
        output_dir=args.output_dir,
        force=args.force,
        keep_names=args.keep_names,
        delimiter=args.delimiter,
        verbose=args.verbose,
    )


if __name__ == "__main__":
    sys.exit(main())
