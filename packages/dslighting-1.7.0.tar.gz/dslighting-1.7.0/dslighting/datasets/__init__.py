"""
Example datasets module for DSLighting.

This module provides easy access to example datasets that can be used
to test and explore the DSLighting package.
"""

import os
from pathlib import Path
from typing import Optional
import pandas as pd


def get_data_path() -> Path:
    """
    Get the path to the datasets directory.

    Returns:
        Path to the datasets directory
    """
    return Path(__file__).parent.absolute()


def list_datasets() -> list[str]:
    """
    List available example datasets.

    Returns:
        List of dataset names
    """
    data_path = get_data_path()
    datasets = []
    for item in data_path.iterdir():
        if item.is_dir() and not item.name.startswith('_'):
            datasets.append(item.name)
    return sorted(datasets)


def load_bike_sharing_demand() -> dict:
    """
    Load the Bike Sharing Demand dataset.

    This is a classic Kaggle competition dataset for predicting bike rental demand.
    The dataset contains hourly rental data spanning two years.

    Returns:
        Dictionary with keys:
            - 'train': Training DataFrame
            - 'test': Test DataFrame
            - 'sample_submission': Sample submission DataFrame
            - 'test_answer': Test answers (for evaluation)

    Example:
        >>> import dslighting
        >>> data = dslighting.datasets.load_bike_sharing_demand()
        >>> train_df = data['train']
        >>> test_df = data['test']
        >>> print(train_df.head())
        >>>
        >>> # Use with dslighting agent
        >>> agent = dslighting.Agent()
        >>> result = agent.run(data['train'])
    """
    data_path = get_data_path() / "bike-sharing-demand"

    if not data_path.exists():
        raise FileNotFoundError(
            f"Bike Sharing Demand dataset not found at {data_path}. "
            "Please reinstall the package."
        )

    data = {}
    data['train'] = pd.read_csv(data_path / "train.csv")
    data['test'] = pd.read_csv(data_path / "test.csv")
    data['sample_submission'] = pd.read_csv(data_path / "sampleSubmission.csv")

    # Load test_answer if available
    test_answer_path = data_path / "test_answer.csv"
    if test_answer_path.exists():
        data['test_answer'] = pd.read_csv(test_answer_path)

    return data


def load_dataset(name: str) -> dict:
    """
    Load a dataset by name.

    Args:
        name: Name of the dataset (e.g., 'bike-sharing-demand')

    Returns:
        Dictionary containing the dataset DataFrames

    Example:
        >>> import dslighting
        >>> data = dslighting.datasets.load_dataset('bike-sharing-demand')
        >>> train_df = data['train']
    """
    name = name.lower().replace('_', '-')

    if name == 'bike-sharing-demand':
        return load_bike_sharing_demand()
    else:
        available = list_datasets()
        raise ValueError(
            f"Dataset '{name}' not found. Available datasets: {available}"
        )


__all__ = [
    "get_data_path",
    "list_datasets",
    "load_bike_sharing_demand",
    "load_dataset",
]
