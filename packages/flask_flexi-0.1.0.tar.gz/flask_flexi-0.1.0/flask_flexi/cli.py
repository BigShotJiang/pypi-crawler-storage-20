from pathlib import Path

# ===== COLOR SYSTEM (Dark Psychology) =====
RESET = "\033[0m"
BOLD = "\033[1m"

BLUE = "\033[94m"     # Trust / Enterprise
GREEN = "\033[92m"    # Beginner / Safe
ORANGE = "\033[93m"   # Action / CTA
RED = "\033[91m"
GRAY = "\033[90m"

def create_file(path, content=""):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(content, encoding="utf-8")

def init():
    print()
    print(f"{ORANGE}{BOLD}⚡ FLASK-FLEXI{RESET}")
    print(f"{GRAY}────────────────────────────────────{RESET}")
    print(f"{BLUE}Create Flask projects with clean foundations{RESET}\n")

    print()
    project_name = input("📁 Enter project name: ").strip()

    if not project_name:
        print(f"\n{RED}❌ Project name cannot be empty{RESET}\n")
        return

    root = Path.cwd() / project_name

    if root.exists():
        print(f"\n{RED}❌ Folder already exists{RESET}\n")
        return

    print(f"\n{GRAY}Select project type:{RESET}\n")
    print(f"{GREEN}  1) Simple Flask{RESET}   {GRAY}• beginner-friendly • clean{RESET}")
    print(f"{BLUE}  2) Enterprise Flask{RESET} {GRAY}• scalable • professional{RESET}\n")

    choice = input(f"{BOLD}{ORANGE}👉 Your choice (1/2): {RESET}").strip()

    # ================= SIMPLE =================
    if choice == "1":
        print(f"\n{GREEN}📦 Initializing SIMPLE Flask project...{RESET}\n")

        (root / "templates").mkdir(parents=True)
        (root / "static").mkdir(parents=True)

        create_file(root / "app.py", """from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
""")

        create_file(root / "templates" / "index.html", """<!DOCTYPE html>
<html>
<head>
    <title>Simple Flask App</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <h1>🚀 Simple Flask App</h1>
    <p>Built with flask-flexi.</p>
</body>
</html>
""")

        create_file(root / "static" / "style.css", """body {
    font-family: Arial, sans-serif;
    background: #f4f6f8;
    padding: 40px;
}
""")

        print(f"{GREEN}✅ Project '{project_name}' created successfully{RESET}")
        print(f"{GRAY}Next steps:{RESET}")
        print(f"  {ORANGE}cd {project_name}{RESET}")
        print(f"  {ORANGE}python app.py{RESET}\n")

    # ================= ENTERPRISE =================
    elif choice == "2":
        print(f"\n{BLUE}📦 Initializing ENTERPRISE Flask project...{RESET}\n")

        folders = [
            root / "app" / "routes",
            root / "app" / "models",
            root / "app" / "templates",
            root / "app" / "static",
        ]

        for f in folders:
            f.mkdir(parents=True, exist_ok=True)

        create_file(root / "run.py", """from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
""")

        create_file(root / "app" / "__init__.py", """from flask import Flask
from .models import init_db

def create_app():
    app = Flask(__name__)
    init_db()

    from .routes.auth import auth_bp
    app.register_blueprint(auth_bp)

    return app
""")

        create_file(root / "app" / "routes" / "__init__.py")

        create_file(root / "app" / "routes" / "auth.py", """from flask import Blueprint, render_template

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/")
def home():
    return render_template("index.html")
""")

        create_file(root / "app" / "models" / "__init__.py", """from .db import engine
from .orm import Base

def init_db():
    Base.metadata.create_all(bind=engine)
""")

        create_file(root / "app" / "models" / "db.py", """from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

DATABASE_URL = "sqlite:///app.db"

engine = create_engine(DATABASE_URL, echo=True)
SessionLocal = sessionmaker(bind=engine)
""")

        create_file(root / "app" / "models" / "orm.py", """from sqlalchemy.orm import declarative_base
from sqlalchemy import Column, Integer, String

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String, unique=True, nullable=False)
""")

        create_file(root / "app" / "templates" / "index.html", """<h1>🏢 Enterprise Flask App</h1>
<p>Foundation ready for scale.</p>
""")

        create_file(root / "app" / "static" / "style.css", """body {
    font-family: Arial, sans-serif;
    padding: 40px;
}
""")

        print(f"{BLUE}✅ Project '{project_name}' created successfully{RESET}")
        print(f"{GRAY}Next steps:{RESET}")
        print(f"  {ORANGE}cd {project_name}{RESET}")
        print(f"  {ORANGE}python run.py{RESET}\n")

    else:
        print(f"\n{RED}❌ Invalid option selected{RESET}\n")
