"""Unit tests for DGMax certification resources and models."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from dgmaxclient import DGMaxClient
from dgmaxclient.models import (
    CertificationProviderInfoResponse,
    CertificationTestItem,
    CertificationTestSuitePublic,
    EnvironmentSwitchResponse,
    XMLSigningResponse,
)
from dgmaxclient.resources.certification import CertificationResource
from dgmaxclient.resources.companies import CompaniesResource


class TestCertificationResource:
    """Tests for CertificationResource methods."""

    def test_get_provider_info(
        self, client: DGMaxClient, sample_provider_info: dict
    ) -> None:
        """Test get_provider_info returns CertificationProviderInfoResponse."""
        with patch.object(client, "get", return_value=sample_provider_info):
            info = client.certification.get_provider_info()

        assert isinstance(info, CertificationProviderInfoResponse)
        assert info.provider.rnc == "123456789"
        assert info.provider.name == "Test Provider SRL"
        assert info.provider.trade_name == "Test Provider"

    def test_get_provider_info_builds_correct_endpoint(
        self, client: DGMaxClient, sample_provider_info: dict
    ) -> None:
        """Test that get_provider_info calls the correct endpoint."""
        with patch.object(
            client, "get", return_value=sample_provider_info
        ) as mock_get:
            client.certification.get_provider_info()

        expected_endpoint = "https://api.dgmax.do/api/v1/certification/provider-info"
        mock_get.assert_called_once_with(expected_endpoint)

    def test_create_test_suite(
        self, client: DGMaxClient, sample_test_suite: dict
    ) -> None:
        """Test create_test_suite returns CertificationTestSuitePublic."""
        with patch.object(client, "post", return_value=sample_test_suite):
            suite = client.certification.create_test_suite(
                company_id="123e4567-e89b-12d3-a456-426614174000",
                test_items=[
                    CertificationTestItem(test_type="E31", count=2),
                    CertificationTestItem(test_type="E32", count=3),
                ],
                start_sequence=100,
            )

        assert isinstance(suite, CertificationTestSuitePublic)
        assert suite.id == "suite-uuid-12345"
        assert suite.status == "PENDING"

    def test_create_test_suite_with_dicts(
        self, client: DGMaxClient, sample_test_suite: dict
    ) -> None:
        """Test create_test_suite accepts dict items."""
        with patch.object(client, "post", return_value=sample_test_suite) as mock_post:
            client.certification.create_test_suite(
                company_id="123e4567-e89b-12d3-a456-426614174000",
                test_items=[
                    {"test_type": "E31", "count": 2},
                    {"test_type": "E32", "count": 3},
                ],
            )

        # Verify the payload was constructed correctly
        call_args = mock_post.call_args
        payload = call_args[1]["json"]
        assert payload["company_id"] == "123e4567-e89b-12d3-a456-426614174000"
        assert payload["test_items"] == [
            {"test_type": "E31", "count": 2},
            {"test_type": "E32", "count": 3},
        ]
        assert payload["start_sequence"] == 1

    def test_create_test_suite_builds_correct_endpoint(
        self, client: DGMaxClient, sample_test_suite: dict
    ) -> None:
        """Test that create_test_suite calls the correct endpoint."""
        with patch.object(
            client, "post", return_value=sample_test_suite
        ) as mock_post:
            client.certification.create_test_suite(
                company_id="123e4567-e89b-12d3-a456-426614174000",
                test_items=[CertificationTestItem(test_type="E31", count=1)],
            )

        expected_endpoint = "https://api.dgmax.do/api/v1/certification/test-suites"
        assert mock_post.call_args[0][0] == expected_endpoint

    def test_get_test_suite(
        self, client: DGMaxClient, sample_test_suite: dict
    ) -> None:
        """Test get_test_suite returns CertificationTestSuitePublic."""
        suite_id = "suite-uuid-12345"

        with patch.object(client, "get", return_value=sample_test_suite):
            suite = client.certification.get_test_suite(suite_id)

        assert isinstance(suite, CertificationTestSuitePublic)
        assert suite.id == suite_id
        assert suite.status_summary.pending == 5
        assert suite.status_summary.completed == 0

    def test_get_test_suite_builds_correct_endpoint(
        self, client: DGMaxClient, sample_test_suite: dict
    ) -> None:
        """Test that get_test_suite calls the correct endpoint."""
        suite_id = "suite-uuid-12345"

        with patch.object(
            client, "get", return_value=sample_test_suite
        ) as mock_get:
            client.certification.get_test_suite(suite_id)

        expected_endpoint = f"https://api.dgmax.do/api/v1/certification/test-suites/{suite_id}"
        mock_get.assert_called_once_with(expected_endpoint)

    def test_get_provider_info_has_retry_decorator(
        self, client: DGMaxClient
    ) -> None:
        """Test that get_provider_info method has retry decorator applied."""
        method = CertificationResource.get_provider_info
        assert hasattr(method, "retry")

    def test_create_test_suite_has_retry_decorator(
        self, client: DGMaxClient
    ) -> None:
        """Test that create_test_suite method has retry decorator applied."""
        method = CertificationResource.create_test_suite
        assert hasattr(method, "retry")

    def test_get_test_suite_has_retry_decorator(
        self, client: DGMaxClient
    ) -> None:
        """Test that get_test_suite method has retry decorator applied."""
        method = CertificationResource.get_test_suite
        assert hasattr(method, "retry")


class TestCompanyCertificationMethods:
    """Tests for company certification-related methods."""

    def test_accept_postulation(
        self, client: DGMaxClient, sample_environment_switch_response: dict
    ) -> None:
        """Test accept_postulation returns EnvironmentSwitchResponse."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"

        with patch.object(
            client, "post", return_value=sample_environment_switch_response
        ):
            response = client.companies.accept_postulation(
                company_id=company_id,
                signed_xml="<xml>signed</xml>",
                security_code="ABC123",
            )

        assert isinstance(response, EnvironmentSwitchResponse)
        assert response.success is True
        assert response.new_environment == "cert"

    def test_accept_postulation_builds_correct_endpoint(
        self, client: DGMaxClient, sample_environment_switch_response: dict
    ) -> None:
        """Test that accept_postulation calls the correct endpoint."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"

        with patch.object(
            client, "post", return_value=sample_environment_switch_response
        ) as mock_post:
            client.companies.accept_postulation(
                company_id=company_id,
                signed_xml="<xml>signed</xml>",
                security_code="ABC123",
            )

        expected_endpoint = f"https://api.dgmax.do/api/v1/companies/{company_id}/accept-postulation/"
        assert mock_post.call_args[0][0] == expected_endpoint

    def test_accept_postulation_payload(
        self, client: DGMaxClient, sample_environment_switch_response: dict
    ) -> None:
        """Test that accept_postulation sends correct payload."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"

        with patch.object(
            client, "post", return_value=sample_environment_switch_response
        ) as mock_post:
            client.companies.accept_postulation(
                company_id=company_id,
                signed_xml="<xml>signed</xml>",
                security_code="ABC123",
            )

        payload = mock_post.call_args[1]["json"]
        assert payload["signed_xml"] == "<xml>signed</xml>"
        assert payload["security_code"] == "ABC123"

    def test_sign_postulation(
        self, client: DGMaxClient, sample_xml_signing_response: dict
    ) -> None:
        """Test sign_postulation returns XMLSigningResponse."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"
        xml_content = b"<xml>postulation</xml>"

        with patch.object(
            client, "post", return_value=sample_xml_signing_response
        ):
            response = client.companies.sign_postulation(
                company_id=company_id,
                postulation_xml=xml_content,
            )

        assert isinstance(response, XMLSigningResponse)
        assert response.signed_xml == "<xml>signed</xml>"
        assert response.filename == "declaracion.xml"

    def test_sign_postulation_builds_correct_endpoint(
        self, client: DGMaxClient, sample_xml_signing_response: dict
    ) -> None:
        """Test that sign_postulation calls the correct endpoint."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"
        xml_content = b"<xml>postulation</xml>"

        with patch.object(
            client, "post", return_value=sample_xml_signing_response
        ) as mock_post:
            client.companies.sign_postulation(
                company_id=company_id,
                postulation_xml=xml_content,
            )

        expected_endpoint = (
            f"https://api.dgmax.do/api/v1/companies/{company_id}/sign-postulation"
        )
        assert mock_post.call_args[0][0] == expected_endpoint

    def test_sign_postulation_multipart_upload(
        self, client: DGMaxClient, sample_xml_signing_response: dict
    ) -> None:
        """Test that sign_postulation sends multipart file upload."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"
        xml_content = b"<xml>postulation</xml>"
        filename = "mi_postulacion.xml"

        with patch.object(
            client, "post", return_value=sample_xml_signing_response
        ) as mock_post:
            client.companies.sign_postulation(
                company_id=company_id,
                postulation_xml=xml_content,
                filename=filename,
            )

        files = mock_post.call_args[1]["files"]
        assert "postulation_xml" in files
        assert files["postulation_xml"][0] == filename
        assert files["postulation_xml"][1] == xml_content
        assert files["postulation_xml"][2] == "application/xml"

    def test_sign_declaration(
        self, client: DGMaxClient, sample_xml_signing_response: dict
    ) -> None:
        """Test sign_declaration returns XMLSigningResponse."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"
        xml_content = b"<xml>declaration</xml>"

        with patch.object(
            client, "post", return_value=sample_xml_signing_response
        ):
            response = client.companies.sign_declaration(
                company_id=company_id,
                declaration_xml=xml_content,
            )

        assert isinstance(response, XMLSigningResponse)
        assert response.signed_xml == "<xml>signed</xml>"
        assert response.filename == "declaracion.xml"

    def test_sign_declaration_builds_correct_endpoint(
        self, client: DGMaxClient, sample_xml_signing_response: dict
    ) -> None:
        """Test that sign_declaration calls the correct endpoint."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"
        xml_content = b"<xml>declaration</xml>"

        with patch.object(
            client, "post", return_value=sample_xml_signing_response
        ) as mock_post:
            client.companies.sign_declaration(
                company_id=company_id,
                declaration_xml=xml_content,
            )

        expected_endpoint = (
            f"https://api.dgmax.do/api/v1/companies/{company_id}/sign-declaration"
        )
        assert mock_post.call_args[0][0] == expected_endpoint

    def test_sign_declaration_multipart_upload(
        self, client: DGMaxClient, sample_xml_signing_response: dict
    ) -> None:
        """Test that sign_declaration sends multipart file upload."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"
        xml_content = b"<xml>declaration</xml>"
        filename = "mi_declaracion.xml"

        with patch.object(
            client, "post", return_value=sample_xml_signing_response
        ) as mock_post:
            client.companies.sign_declaration(
                company_id=company_id,
                declaration_xml=xml_content,
                filename=filename,
            )

        files = mock_post.call_args[1]["files"]
        assert "declaration_xml" in files
        assert files["declaration_xml"][0] == filename
        assert files["declaration_xml"][1] == xml_content
        assert files["declaration_xml"][2] == "application/xml"

    def test_accept_declaration(
        self, client: DGMaxClient, sample_environment_switch_response: dict
    ) -> None:
        """Test accept_declaration returns EnvironmentSwitchResponse."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"
        # Modify response for PRD environment
        prd_response = {
            **sample_environment_switch_response,
            "new_environment": "prd",
            "message": "Company is now in production",
        }

        with patch.object(client, "post", return_value=prd_response):
            response = client.companies.accept_declaration(
                company_id=company_id,
                signed_xml="<xml>signed</xml>",
                security_code="XYZ789",
            )

        assert isinstance(response, EnvironmentSwitchResponse)
        assert response.success is True
        assert response.new_environment == "prd"

    def test_accept_declaration_builds_correct_endpoint(
        self, client: DGMaxClient, sample_environment_switch_response: dict
    ) -> None:
        """Test that accept_declaration calls the correct endpoint."""
        company_id = "123e4567-e89b-12d3-a456-426614174000"

        with patch.object(
            client, "post", return_value=sample_environment_switch_response
        ) as mock_post:
            client.companies.accept_declaration(
                company_id=company_id,
                signed_xml="<xml>signed</xml>",
                security_code="XYZ789",
            )

        expected_endpoint = f"https://api.dgmax.do/api/v1/companies/{company_id}/accept-declaration"
        assert mock_post.call_args[0][0] == expected_endpoint

    def test_accept_postulation_has_retry_decorator(
        self, client: DGMaxClient
    ) -> None:
        """Test that accept_postulation method has retry decorator applied."""
        method = CompaniesResource.accept_postulation
        assert hasattr(method, "retry")

    def test_sign_postulation_has_retry_decorator(
        self, client: DGMaxClient
    ) -> None:
        """Test that sign_postulation method has retry decorator applied."""
        method = CompaniesResource.sign_postulation
        assert hasattr(method, "retry")

    def test_sign_declaration_has_retry_decorator(
        self, client: DGMaxClient
    ) -> None:
        """Test that sign_declaration method has retry decorator applied."""
        method = CompaniesResource.sign_declaration
        assert hasattr(method, "retry")

    def test_accept_declaration_has_retry_decorator(
        self, client: DGMaxClient
    ) -> None:
        """Test that accept_declaration method has retry decorator applied."""
        method = CompaniesResource.accept_declaration
        assert hasattr(method, "retry")

    def test_accept_postulation_invalid_company_id(
        self, client: DGMaxClient
    ) -> None:
        """Test accept_postulation with invalid company ID format."""
        with pytest.raises(ValueError, match="Invalid resource ID format"):
            client.companies.accept_postulation(
                company_id="invalid-id",
                signed_xml="<xml>signed</xml>",
                security_code="ABC123",
            )

    def test_sign_postulation_invalid_company_id(
        self, client: DGMaxClient
    ) -> None:
        """Test sign_postulation with invalid company ID format."""
        with pytest.raises(ValueError, match="Invalid resource ID format"):
            client.companies.sign_postulation(
                company_id="invalid-id",
                postulation_xml=b"<xml>postulation</xml>",
            )

    def test_sign_declaration_invalid_company_id(
        self, client: DGMaxClient
    ) -> None:
        """Test sign_declaration with invalid company ID format."""
        with pytest.raises(ValueError, match="Invalid resource ID format"):
            client.companies.sign_declaration(
                company_id="invalid-id",
                declaration_xml=b"<xml>declaration</xml>",
            )

    def test_accept_declaration_invalid_company_id(
        self, client: DGMaxClient
    ) -> None:
        """Test accept_declaration with invalid company ID format."""
        with pytest.raises(ValueError, match="Invalid resource ID format"):
            client.companies.accept_declaration(
                company_id="invalid-id",
                signed_xml="<xml>signed</xml>",
                security_code="XYZ789",
            )


class TestCertificationModels:
    """Tests for certification model validation."""

    def test_certification_test_item_model(self) -> None:
        """Test CertificationTestItem model creation."""
        item = CertificationTestItem(test_type="E31", count=5)
        assert item.test_type == "E31"
        assert item.count == 5

    def test_certification_test_item_default_count(self) -> None:
        """Test CertificationTestItem default count."""
        item = CertificationTestItem(test_type="E32")
        assert item.count == 1

    def test_test_suite_status_enum(self) -> None:
        """Test TestSuiteStatus enum values."""
        from dgmaxclient.models import TestSuiteStatus

        assert TestSuiteStatus.PENDING == "PENDING"
        assert TestSuiteStatus.IN_PROGRESS == "IN_PROGRESS"
        assert TestSuiteStatus.COMPLETED == "COMPLETED"
        assert TestSuiteStatus.FAILED == "FAILED"

    def test_certification_test_type_enum(self) -> None:
        """Test CertificationTestType enum values."""
        from dgmaxclient.models import CertificationTestType

        assert CertificationTestType.E31 == "E31"
        assert CertificationTestType.E32 == "E32"
        assert CertificationTestType.E33 == "E33"
        assert CertificationTestType.E34 == "E34"
        assert CertificationTestType.E41 == "E41"
        assert CertificationTestType.E43 == "E43"
        assert CertificationTestType.E44 == "E44"
        assert CertificationTestType.E45 == "E45"
        assert CertificationTestType.E46 == "E46"
        assert CertificationTestType.E47 == "E47"


class TestClientCertificationResource:
    """Tests for certification resource initialization in client."""

    def test_client_has_certification_resource(
        self, client: DGMaxClient
    ) -> None:
        """Test that client has certification resource initialized."""
        assert hasattr(client, "certification")
        assert isinstance(client.certification, CertificationResource)

    def test_certification_resource_has_client(
        self, client: DGMaxClient
    ) -> None:
        """Test that certification resource has reference to client."""
        assert client.certification.client is client
