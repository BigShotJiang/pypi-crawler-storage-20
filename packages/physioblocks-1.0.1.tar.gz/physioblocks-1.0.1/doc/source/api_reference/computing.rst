.. SPDX-FileCopyrightText: Copyright INRIA
..
.. SPDX-License-Identifier: LGPL-3.0-only
..
.. Copyright INRIA
..
.. This file is part of PhysioBlocks, a library mostly developed by the
.. [Ananke project-team](https://team.inria.fr/ananke) at INRIA.
..
.. Authors:
.. - Colin Drieu
.. - Dominique Chapelle
.. - François Kimmig
.. - Philippe Moireau
..
.. PhysioBlocks is free software: you can redistribute it and/or modify it under the
.. terms of the GNU Lesser General Public License as published by the Free Software
.. Foundation, version 3 of the License.
..
.. PhysioBlocks is distributed in the hope that it will be useful, but WITHOUT ANY
.. WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
.. PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
..
.. You should have received a copy of the GNU Lesser General Public License along with
.. PhysioBlocks. If not, see <https://www.gnu.org/licenses/>.

****************
Computing Module
****************

The computing module declares functions and classes to:

    * Hold numerical values for model quantities.
    * Declare **Expressions** to define the **Blocks** and **ModelComponents** Flux, InternalExpressions and SavedQuantities
    * Assemble the global **System** from those declaration.

.. _quantity_ref:

Quantities
==========

.. automodule:: physioblocks.computing.quantities
    :members:

Models
======

.. automodule:: physioblocks.computing.models
    :members:

Assembling
==========

.. automodule:: physioblocks.computing.assembling
    :members: