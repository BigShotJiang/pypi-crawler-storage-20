"""AirOps SDK tests."""
