from pathlib import Path
from typing import Any, Callable

from ._dataloaders import TabularDataLoader
from ._download_uci import download_from_uci


class UCIDataset(TabularDataLoader):
    """
    Class for loading datasets from UCI machine learning repository.

    Args:
        id (int): UCI repository ID of the dataset.
        filename (str): Name of the dataset file.
        root (str, Path or None): Optional directory where the dataset file is stored or to be downloaded.
        Uses current working directory if None. Defaults to None.
        file_fmt (str): Format of the file (e.g, 'csv', 'excel', 'json', 'parquet'). Defaults to 'csv'.
        transform (Callable or None): Optional transformation to apply to the dataset. Defaults to None.
        download (bool): Whether to download the dataset from the internet. Defaults to False.
    """

    def __init__(
        self,
        id: int,
        filename: str,
        root: str | Path | None = None,
        file_fmt: str = "csv",
        transform: Callable | None = None,
        download: bool = False,
        **kwargs: Any,
    ):
        root = Path(root) if root is not None else Path.cwd()
        path = root / filename

        if download:
            path = download_from_uci(id, root=root, filename=filename)

        super().__init__(
            path=path,
            file_fmt=file_fmt,
            transform=transform,
            **kwargs,
        )
