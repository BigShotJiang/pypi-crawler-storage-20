from ._dataloaders import load_dataset, LazyDataLoader, TabularDataLoader
from ._download_uci import download_from_uci
from ._uci_dataset import UCIDataset


__all__ = [
    "download_from_uci",
    "load_dataset",
    "LazyDataLoader",
    "TabularDataLoader",
    "UCIDataset",
]
