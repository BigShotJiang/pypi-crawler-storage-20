# randstadenterprise_edao_libraries/__init__.py

# 1. Base Utility Modules (Load First)
from . import logs
from . import objects
from . import http
from . import helpers

# 2. Logic Modules (Ordered by Dependency)
from . import domo_groups    # Independent
from . import roles     # Independent API
from . import datasets  # Depends on logs/helpers
from . import domo_users     # Depends on roles/groups
from . import assets    # Depends on users (via ownership logic)
from . import sandbox   # Depends on everything

__all__ = ['logs', 'objects', 'http', 'helpers', 'domo_groups', 'roles', 'domo_users', 'datasets', 'assets', 'sandbox']
__version__ = "0.1.25"

# In Terminal RUN in library_root
# cd library_root
# rm -rf dist
# pyhon -m build
# python -m twine upload dist/*

