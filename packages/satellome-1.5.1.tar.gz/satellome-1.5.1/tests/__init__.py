"""Satellome test suite."""
