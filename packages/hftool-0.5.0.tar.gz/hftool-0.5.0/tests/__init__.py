"""Tests for hftool."""
