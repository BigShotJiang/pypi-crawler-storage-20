# sfi

Single File commands for Interactive python.

## Overview

sfi is a Python project that provides single-file command-line utilities, designed to be lightweight and easy-to-use.

## Available Commands

### [filedate](sfi/filedate/README.md)

A file date management tool that normalizes date prefixes in filenames.

## Installation

```bash
# Install using uv (recommended)
uv add sfi

# Or using pip
pip install sfi
```

## Development

### Requirements

- Python >= 3.8
- [uv](https://github.com/astral-sh/uv) (recommended) or pip

### Development Dependencies

```bash
uv pip install -e ".[dev]"
```

### Code Standards

The project uses Ruff for code linting and formatting:

```bash
# Check code
ruff check .

# Format code
ruff format .
```

## Project Structure

```bash
sfi/
├── pyproject.toml          # Main project configuration
├── README.md
└── sfi/
    ├── __init__.py
    └── filedate/           # filedate command module
        ├── __init__.py
        ├── filedate.py     # Main implementation
        ├── pyproject.toml
        └── README.md       # Detailed documentation
```

## License

MIT License

## Contributing

Issues and Pull Requests are welcome!
