import typing as t

from crackerjack.config import CrackerjackSettings
from crackerjack.mcp.context import MCPServerContext, get_context
from crackerjack.mcp.rate_limiter import RateLimitMiddleware
from crackerjack.services.input_validator import (
    SecureInputValidator,
    get_input_validator,
)

if t.TYPE_CHECKING:
    from crackerjack.core.workflow_orchestrator import WorkflowOrchestrator


async def create_task_with_subagent(
    description: str,
    prompt: str,
    subagent_type: str,
) -> dict[str, t.Any]:
    try:
        validator = get_input_validator()

        desc_result = validator.validate_command_args(description)
        if not desc_result.valid:
            return {
                "success": False,
                "error": f"Invalid description: {desc_result.error_message}",
                "validation_type": desc_result.validation_type,
            }

        prompt_result = validator.validate_command_args(prompt)
        if not prompt_result.valid:
            return {
                "success": False,
                "error": f"Invalid prompt: {prompt_result.error_message}",
                "validation_type": prompt_result.validation_type,
            }

        subagent_result = validator.sanitizer.sanitize_string(
            subagent_type,
            max_length=100,
            strict_alphanumeric=True,
        )
        if not subagent_result.valid:
            return {
                "success": False,
                "error": f"Invalid subagent_type: {subagent_result.error_message}",
                "validation_type": subagent_result.validation_type,
            }

        sanitized_description = desc_result.sanitized_value or description
        sanitized_prompt = prompt_result.sanitized_value or prompt
        sanitized_subagent = subagent_result.sanitized_value

        return {
            "success": True,
            "description": sanitized_description,
            "prompt": sanitized_prompt,
            "subagent_type": sanitized_subagent,
            "result": f"Task would be executed by {sanitized_subagent}: {sanitized_prompt[:100]}...",
            "agent_type": "user"
            if sanitized_subagent
            not in ("general-purpose", "statusline-setup", "output-style-setup")
            else "system",
        }

    except Exception as e:
        return {
            "success": False,
            "error": f"Task creation failed: {e}",
            "description": description,
            "subagent_type": subagent_type,
        }


async def _validate_stage_request(
    context: MCPServerContext | None,
    rate_limiter: RateLimitMiddleware | None,
) -> str | None:
    if not context:
        return '{"error": "Server context not available", "success": false}'

    if rate_limiter and hasattr(rate_limiter, "check_request_allowed"):
        allowed, details = await rate_limiter.check_request_allowed()
        if not allowed:
            return f'{{"error": "Rate limit exceeded: {details.get("reason", "unknown")}", "success": false}}'
    return None


def _parse_stage_args(args: str, kwargs: str) -> tuple[str, dict[str, t.Any]] | str:
    try:
        validator = get_input_validator()

        stage_validation = _validate_stage_argument(validator, args)
        if isinstance(stage_validation, str):
            return stage_validation
        stage = stage_validation

        kwargs_validation = _validate_kwargs_argument(validator, kwargs)
        if isinstance(kwargs_validation, str):
            return kwargs_validation
        extra_kwargs = kwargs_validation

        return stage, extra_kwargs

    except Exception as e:
        return f'{{"error": "Stage argument parsing failed: {e}", "success": false}}'


def _validate_stage_argument(validator: SecureInputValidator, args: str) -> str:
    stage_result = validator.sanitizer.sanitize_string(
        args.strip(),
        max_length=50,
        strict_alphanumeric=True,
    )
    if not stage_result.valid:
        return f'{{"error": "Invalid stage argument: {stage_result.error_message}", "success": false}}'

    stage: str = str(stage_result.sanitized_value).lower()
    valid_stages = {"fast", "comprehensive", "tests", "cleaning", "init"}

    if stage not in valid_stages:
        return f'{{"error": "Invalid stage: {stage}. Valid stages: {valid_stages}", "success": false}}'

    return stage


def _validate_kwargs_argument(
    validator: SecureInputValidator,
    kwargs: str,
) -> dict[str, t.Any] | str:
    extra_kwargs: dict[str, t.Any] = {}
    if not kwargs.strip():
        return extra_kwargs

    kwargs_result = validator.validate_json_payload(kwargs.strip())
    if not kwargs_result.valid:
        return f'{{"error": "Invalid JSON in kwargs: {kwargs_result.error_message}", "success": false}}'

    extra_kwargs = kwargs_result.sanitized_value

    if not isinstance(extra_kwargs, dict):
        return f'{{"error": "kwargs must be a JSON object, got {type(extra_kwargs).__name__}", "success": false}}'

    return extra_kwargs


def _configure_stage_options(stage: str) -> CrackerjackSettings:
    from crackerjack.config import load_settings

    base_settings = load_settings(CrackerjackSettings)

    settings_dict = base_settings.model_dump()

    if stage in {"fast", "comprehensive"}:
        settings_dict["skip_hooks"] = False
    elif stage == "tests":
        settings_dict["run_tests"] = True
    elif stage == "cleaning":
        settings_dict["clean"] = True
    elif stage == "init":
        settings_dict["skip_hooks"] = True

    return CrackerjackSettings(**settings_dict)


def _execute_stage(
    orchestrator: "WorkflowOrchestrator",
    stage: str,
    settings: CrackerjackSettings,
) -> bool:
    adapted_options = _adapt_settings_to_protocol(settings)

    if stage == "fast":
        return orchestrator.run_fast_hooks_only(adapted_options)
    if stage == "comprehensive":
        return orchestrator.run_comprehensive_hooks_only(adapted_options)
    if stage == "tests":
        return orchestrator.run_testing_phase(adapted_options)
    if stage == "cleaning":
        return orchestrator.run_cleaning_phase(adapted_options)
    return False


def _adapt_settings_to_protocol(settings: CrackerjackSettings) -> t.Any:
    return _AdaptedOptions(settings)  # type: ignore


class _AdaptedOptions:
    def __init__(self, settings: CrackerjackSettings) -> None:
        self.settings = settings

    @property
    def commit(self) -> bool:
        return self.settings.git.commit

    @property
    def create_pr(self) -> bool:
        return self.settings.git.create_pr

    @property
    def interactive(self) -> bool:
        return self.settings.execution.interactive

    @property
    def no_config_updates(self) -> bool:
        return self.settings.execution.no_config_updates

    @property
    def verbose(self) -> bool:
        return self.settings.console.verbose

    @property
    def async_mode(self) -> bool:
        return self.settings.execution.async_mode

    @property
    def test(self) -> bool:
        return self.settings.testing.test

    @property
    def benchmark(self) -> bool:
        return self.settings.testing.benchmark

    @property
    def test_workers(self) -> int:
        return self.settings.testing.test_workers

    @property
    def test_timeout(self) -> int:
        return self.settings.testing.test_timeout

    @property
    def publish(self) -> t.Any | None:
        return self.settings.publishing.publish

    @property
    def bump(self) -> t.Any | None:
        return self.settings.publishing.bump

    @property
    def all(self) -> t.Any | None:
        return self.settings.publishing.all

    @property
    def no_git_tags(self) -> bool:
        return self.settings.publishing.no_git_tags

    @property
    def skip_version_check(self) -> bool:
        return self.settings.publishing.skip_version_check

    @property
    def ai_agent(self) -> bool:
        return self.settings.ai.ai_agent

    @property
    def start_mcp_server(self) -> bool:
        return self.settings.ai.start_mcp_server

    @property
    def skip_hooks(self) -> bool:
        return self.settings.hooks.skip_hooks

    @property
    def experimental_hooks(self) -> bool:
        return self.settings.hooks.experimental_hooks

    @property
    def enable_pyrefly(self) -> bool:
        return self.settings.hooks.enable_pyrefly

    @property
    def enable_ty(self) -> bool:
        return self.settings.hooks.enable_ty

    @property
    def clean(self) -> bool:
        return self.settings.cleaning.clean

    @property
    def track_progress(self) -> bool:
        return self.settings.progress.track_progress

    @property
    def cleanup(self) -> t.Any | None:
        return None

    @property
    def cleanup_pypi(self) -> bool:
        return False

    @property
    def coverage(self) -> bool:
        return self.settings.testing.coverage

    @property
    def keep_releases(self) -> int:
        return 10

    @property
    def fast(self) -> bool:
        return False


from crackerjack.services.filesystem import FileSystemService
from crackerjack.services.git import GitService
from crackerjack.services.initialization import InitializationService


def _execute_init_stage(orchestrator: "WorkflowOrchestrator") -> bool:
    try:
        from pathlib import Path

        pkg_path = orchestrator.pkg_path

        from rich.console import Console

        console = Console()

        filesystem = FileSystemService()
        git_service = GitService(pkg_path)

        init_service = InitializationService(console, filesystem, git_service, pkg_path)

        results = init_service.initialize_project_full(target_path=Path.cwd())

        success_result: bool = bool(results.get("success", False))
        return success_result

    except Exception as e:
        if hasattr(orchestrator, "console"):
            orchestrator.console.print(f"[red]❌[/ red] Initialization failed: {e}")
        return False


def register_core_tools(mcp_app: t.Any) -> None:
    @mcp_app.tool()  # type: ignore[misc]
    async def run_crackerjack_stage(args: str, kwargs: str) -> str:
        context = get_context()
        rate_limiter = context.rate_limiter if context else None

        validation_error = await _validate_stage_request(context, rate_limiter)
        if validation_error:
            return validation_error

        # TODO(Phase 3): Replace with Oneiric workflow execution
        return '{"error": "Workflow orchestration removed in Phase 2 (legacy runtime removal). Will be reimplemented in Phase 3 (Oneiric integration).", "success": false}'


def _get_error_patterns() -> list[tuple[str, str]]:
    return [
        ("type_error", r"TypeError: | type object .* has no attribute"),
        ("import_error", r"ImportError: | ModuleNotFoundError: "),
        ("attribute_error", r"AttributeError: "),
        ("syntax_error", r"SyntaxError: | invalid syntax"),
        ("test_failure", r"FAILED | AssertionError: "),
        ("hook_failure", r"hook .* failed"),
    ]


def _get_error_suggestion(error_type: str) -> str:
    suggestions = {
        "type_error": "Check type annotations and ensure proper imports",
        "import_error": "Verify module exists and is properly installed",
        "test_failure": "Review test assertions and expected behavior",
        "hook_failure": "Run hooks individually to identify specific failures",
    }
    return suggestions.get(error_type) or "No specific suggestion available"


def _detect_errors_and_suggestions(
    text: str,
    include_suggestions: bool,
) -> tuple[list[str], list[str]]:
    import re

    detected_errors: list[str] = []
    suggestions: list[str] = []

    for error_type, pattern in _get_error_patterns():
        if re.search(pattern, text, re.IGNORECASE):
            detected_errors.append(error_type)
            if include_suggestions:
                suggestions.append(_get_error_suggestion(error_type))

    return detected_errors, suggestions


def register_analyze_errors_tool(mcp_app: t.Any) -> None:
    @mcp_app.tool()  # type: ignore[misc]
    async def analyze_errors(output: str = "", include_suggestions: bool = True) -> str:
        context = get_context()
        if not context:
            return '{"error": "Server context not available"}'

        try:
            from crackerjack.services.debug import get_ai_agent_debugger

            debugger = get_ai_agent_debugger()
            if not debugger.enabled:
                return '{"analysis": "Debugging not enabled", "suggestions": []}'

            analysis_text = output or "No specific output provided"
            detected_errors, suggestions = _detect_errors_and_suggestions(
                analysis_text,
                include_suggestions,
            )

            result = {
                "analysis": f"Detected {len(detected_errors)} error types",
                "error_types": detected_errors,
                "suggestions": suggestions if include_suggestions else [],
                "raw_output_length": len(analysis_text),
            }

            import json

            return json.dumps(result, indent=2)

        except Exception as e:
            return f'{{"error": "Error analysis failed: {e}"}}'
