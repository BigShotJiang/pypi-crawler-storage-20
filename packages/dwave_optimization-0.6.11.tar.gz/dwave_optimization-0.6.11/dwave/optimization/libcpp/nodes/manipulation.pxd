# Copyright 2025 D-Wave
#
#    Licensed under the Apache License, Version 2.0 (the "License");
#    you may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.

from libcpp.span cimport span
from libcpp.vector cimport vector

from dwave.optimization.libcpp cimport variant
from dwave.optimization.libcpp.graph cimport Array, ArrayNode


cdef extern from "dwave-optimization/nodes/manipulation.hpp" namespace "dwave::optimization" nogil:
    cdef cppclass BroadcastToNode(ArrayNode):
        pass

    cdef cppclass ConcatenateNode(ArrayNode):
        Py_ssize_t axis()

    cdef cppclass CopyNode(ArrayNode):
        pass

    cdef cppclass PutNode(ArrayNode):
        pass

    cdef cppclass ReshapeNode(ArrayNode):
        pass

    cdef cppclass ResizeNode(ArrayNode):
        double fill_value() const

    cdef cppclass RollNode(ArrayNode):
        span[const Py_ssize_t] axes()
        variant[const Array*, vector[Py_ssize_t]]& shift()

    cdef cppclass SizeNode(ArrayNode):
        pass

    cdef cppclass TransposeNode(ArrayNode):
        pass
