# Schopenhauer Test Suite
