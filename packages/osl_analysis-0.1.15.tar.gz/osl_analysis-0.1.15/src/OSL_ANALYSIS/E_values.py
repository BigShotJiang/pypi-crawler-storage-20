E1 = None
E2 = None
E3 = None
F_ph_array = None

def set_values():
    global E1, E2, E3
    E1 = float(input("Ingrese E1: "))
    E2 = float(input("Ingrese E2: "))
    E3 = float(input("Ingrese E3: "))

def set_test_values(e1, e2, e3):
    global E1, E2, E3
    E1, E2, E3 = e1, e2, e3
