# OSL_ANALYSIS

A comprehensive simulation program for analyzing photostimulation, irradiation,
thermal washing, and optical washing processes in optically and thermally
stimulated materials.

## Author
**EDWIN JOEL PILCO QUISPE**  
Email: edwinpilco10@gmail.com
## Co-Author
**JOSÉ FRANCISCO BENAVENTE CUEVAS** 
Email:
benaventejosef@gmail.com
jf.benavente@ciemat.es

## Co-Author
**NILO FRANCISCO CANO MAMANI**
Email:nilo.cano@unifesp.br

## Description
This package provides a sophisticated computational framework for modeling
charge carrier dynamics in materials subjected to optical and thermal
stimulation. It implements advanced physical models for optically stimulated
luminescence (OSL) and radiation dosimetry applications.

## Key Features

### Multi-Process Simulation
- **Photostimulation Analysis**: Wavelength-dependent photoionization
  cross-section calculations with Gaussian light source simulation
- **Irradiation Modeling**: Trap filling dynamics during radiation exposure
  with competition effects
- **Thermal Washing**: Thermal release of trapped charges using the
  TTOR (Two-Trap One-Recombination center) model
- **Optical Washing**: Combined thermal–optical stimulation effects analysis

### Advanced Physical Models
- Extended TTOR model with three eV electron traps (user selected)
- Temperature-dependent detrapping via Arrhenius equation
- Wavelength-dependent photoionization probabilities
- Charge neutrality verification and validation

### Flexible Input System
Supports:
- Single values: `470`
- Ranges: `300,400,25`
- Multiple values: `300-350-400`

## Output
- Three-panel diagnostic plots per simulation
- Publication-quality PNG images (300 DPI)
- Tab-delimited text files (Origin / Excel compatible)
- Pandas DataFrames
- Automatic Google Colab download support

## Scientific Applications
- Radiation dosimetry and OSL dosimeter characterization
- Material science defect studies

## Installation

### From PyPI
```bash
python -m pip install OSL_ANALYSIS
