
from django_returns.safeorm import SafeORM

__all__ = [
	"SafeORM",
]
