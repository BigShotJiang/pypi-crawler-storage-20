from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Collection, Generic, Iterable, Mapping, TypeVar

from django.db.models import Model, QuerySet
from returns.result import Result, safe

_ModelType = TypeVar("_ModelType", bound=Model)


@dataclass(frozen=True)
class SafeORM(Generic[_ModelType]):
    """A typed wrapper around a Django QuerySet.

    Unlike subclassing QuerySet and overriding core method return types, this
    wrapper provides an alternate interface that returns ``Result`` values.
    """

    queryset: QuerySet[_ModelType]

    def unwrap(self) -> QuerySet[_ModelType]:
        """Returns the underlying Django QuerySet."""

        return self.queryset

    # --- QuerySet chaining (returns another SafeORM) ---

    def filter(self, *args: Any, **kwargs: Any) -> SafeORM[_ModelType]:
        return SafeORM(self.queryset.filter(*args, **kwargs))

    def exclude(self, *args: Any, **kwargs: Any) -> SafeORM[_ModelType]:
        return SafeORM(self.queryset.exclude(*args, **kwargs))

    def order_by(self, *field_names: str) -> SafeORM[_ModelType]:
        return SafeORM(self.queryset.order_by(*field_names))

    def select_related(self, *fields: str) -> SafeORM[_ModelType]:
        return SafeORM(self.queryset.select_related(*fields))

    def prefetch_related(self, *lookups: str) -> SafeORM[_ModelType]:
        return SafeORM(self.queryset.prefetch_related(*lookups))

    # --- Unsafe-ish ORM operations (return Result) ---

    @safe
    def get(self, *args: Any, **kwargs: Any) -> _ModelType:
        return self.queryset.get(*args, **kwargs)

    @safe
    def earliest(self, *fields: str) -> _ModelType:
        return self.queryset.earliest(*fields)

    @safe
    def latest(self, *fields: str) -> _ModelType:
        return self.queryset.latest(*fields)

    @safe
    def create(self, **kwargs: Any) -> _ModelType:
        return self.queryset.create(**kwargs)

    @safe
    def get_or_create(
        self,
        defaults: Mapping[str, Any] | None = None,
        **kwargs: Any,
    ) -> tuple[_ModelType, bool]:
        return self.queryset.get_or_create(defaults=defaults, **kwargs)

    @safe
    def update_or_create(
        self,
        defaults: Mapping[str, Any] | None = None,
        create_defaults: Mapping[str, Any] | None = None,
        **kwargs: Any,
    ) -> tuple[_ModelType, bool]:
        return self.queryset.update_or_create(
            defaults=defaults,
            create_defaults=create_defaults,
            **kwargs,
        )

    @safe
    def delete(self) -> tuple[int, dict[str, int]]:
        return self.queryset.delete()

    @safe
    def bulk_create(
        self,
        objs: Iterable[_ModelType],
        batch_size: int | None = None,
        ignore_conflicts: bool = False,
        update_conflicts: bool = False,
        update_fields: Collection[str] | None = None,
        unique_fields: Collection[str] | None = None,
    ) -> list[_ModelType]:
        return self.queryset.bulk_create(
            objs,
            batch_size=batch_size,
            ignore_conflicts=ignore_conflicts,
            update_conflicts=update_conflicts,
            update_fields=update_fields,
            unique_fields=unique_fields,
        )

    # Convenience aliases so call sites can be explicit about Result types

    def get_result(self, *args: Any, **kwargs: Any) -> Result[_ModelType, Exception]:
        return self.get(*args, **kwargs)
