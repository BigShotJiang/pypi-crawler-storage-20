from .polymer_specs import PolymerClassifier
from dataclasses import dataclass, field
from typing import Mapping

@dataclass(frozen=True)
class ProteinDefaults():
    alphabet: frozenset[str] = frozenset("ACDEFGHIKLMNPQRSTVWY")
    classes: Mapping[str, frozenset[str]] = field(default_factory=lambda:{
        "positive":frozenset("RHK"),
        "negative":frozenset("ED"),
        "polar":frozenset("NSCTQ"),
        "nonpolar":frozenset("MALIVGP"),
        "aromatic":frozenset("FYW"),
        "other":frozenset("")
    })
    flags = dict()

    def get_alphabet(self):
        return self.alphabet

    def get_classes(self):
        return self.classes

class ProteinClassifier(PolymerClassifier):
    def __init__(self, alphabet: str | list | set = None, classes:dict = None):
        ab = self.default_alphabet() if alphabet is None else alphabet
        cs = self.default_classes() if classes is None else classes
        # fl = self.default_flags() if flags is None else flags
        super().__init__(ab, cs)

    def default_alphabet(self):
        return ProteinDefaults().get_alphabet()

    def default_classes(self):
        return ProteinDefaults().get_classes()

    # def default_flags(self):
    #     self.flags =ProteinDefaults.flags




