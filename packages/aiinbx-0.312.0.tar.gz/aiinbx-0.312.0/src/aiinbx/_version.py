# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "aiinbx"
__version__ = "0.312.0"  # x-release-please-version
