# runcmd-mcp package
__version__ = "0.1.4"
