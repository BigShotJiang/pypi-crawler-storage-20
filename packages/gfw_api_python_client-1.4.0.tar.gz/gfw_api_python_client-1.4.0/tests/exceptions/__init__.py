"""Tests for `gfwapiclient.exceptions`."""
