"""Tests for `gfwapiclient.resources`."""
