"""Tests for `gfwapiclient.base`."""
