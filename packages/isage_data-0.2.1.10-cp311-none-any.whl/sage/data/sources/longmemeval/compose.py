﻿#!/usr/bin/env python3
"""
Compose LongMemEval ORACLE file by:
1) Filtering out questions without evidence.
2) Concatenating remaining entries and splitting into N (default: 10) groups.
3) Remapping evidence coordinates to the shared history within each group.

Input is expected to be the oracle JSON (only-evidence sessions per sample).

Usage examples:
    python -m sage.data.sources.longmemeval.compose_oracle \
        --input ./sage/data/sources/longmemeval/longmemeval_oracle.json \
        --groups 10 --shuffle --seed 42

    # Use defaults (looks for longmemeval_oracle.json in this folder)
    python -m sage.data.sources.longmemeval.compose_oracle

Output:
    Writes longmemeval_oracle_composed.json to the same directory as --input by default.

Output format (per group):
{
  "group_id": "group-1",
  "haystack_sessions": [...],
  "haystack_dates": [...],
  "questions": [
    {"question_id","question","answer","question_type","evidence": ["D{s}:{t}", ...]}
  ]
}
"""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path
from typing import Any, Dict, List


def _has_evidence(entry: Dict[str, Any]) -> bool:
    """Return True iff question_id does NOT end with '_abs'.

    As requested: entries whose question_id endswith "_abs" are considered
    no-evidence and should be dropped.
    """
    qid = str(entry.get("question_id", ""))
    return not qid.endswith("_abs")


def _remap_evidence(entry: Dict[str, Any], base_session: int) -> List[str]:
    """Extract evidence coordinates and remap to composed shared history.

    Strategy:
    - If any turn has has_answer=True, collect D{new_session}:{turn_idx}.
    - Else, fallback to answer_session_ids -> D{new_session}:1.
    """
    result: List[str] = []

    sessions = entry.get("haystack_sessions", []) or []
    found_turn = False
    for s_idx, session in enumerate(sessions, start=1):
        for t_idx, turn in enumerate(session, start=1):
            if turn.get("has_answer") is True:
                found_turn = True
                new_s = base_session + (s_idx - 1)
                result.append(f"D{new_s}:{t_idx}")
    if not found_turn:
        import re
        for sid in entry.get("answer_session_ids", []) or []:
            # sid 可能是数字，或者字符串如 "answer_xxx_2"，尽量提取末尾数字
            new_session_offset = 0
            try:
                new_session_offset = int(sid) - 1
            except (TypeError, ValueError):
                m = re.search(r"(\d+)$", str(sid))
                if m:
                    new_session_offset = int(m.group(1)) - 1
                else:
                    new_session_offset = 0  # 无法解析则回退到首个 session
            new_s = base_session + new_session_offset
            result.append(f"D{new_s}:1")

    return result


def _compose_group(entries: List[Dict[str, Any]], group_id: str) -> Dict[str, Any]:
    """Compose a group with shared history and aggregated questions, remapping evidence."""
    shared_sessions: List[List[Dict[str, Any]]] = []
    shared_dates: List[str] = []

    # Track the starting session index for each entry
    bases: List[int] = []
    current_base = 1
    for e in entries:
        sessions = e.get("haystack_sessions", []) or []
        dates = e.get("haystack_dates", []) or []
        bases.append(current_base)
        shared_sessions.extend(sessions)
        shared_dates.extend(dates)
        current_base += len(sessions)

    questions: List[Dict[str, Any]] = []
    for e, base in zip(entries, bases):
        questions.append(
            {
                "question_id": e.get("question_id"),
                "question": e.get("question"),
                "answer": e.get("answer"),
                "question_type": e.get("question_type"),
                "evidence": _remap_evidence(e, base_session=base),
            }
        )

    return {
        "group_id": group_id,
        "haystack_sessions": shared_sessions,
        "haystack_dates": shared_dates,
        "questions": questions,
    }


def _split_evenly(items: List[Dict[str, Any]], n_groups: int) -> List[List[Dict[str, Any]]]:
    """Split items into n nearly-equal groups preserving order."""
    if n_groups <= 0:
        raise ValueError("n_groups must be positive")
    total = len(items)
    if total == 0:
        return []
    q, r = divmod(total, n_groups)
    sizes = [(q + 1 if i < r else q) for i in range(n_groups)]
    groups: List[List[Dict[str, Any]]] = []
    idx = 0
    for sz in sizes:
        if sz == 0:
            groups.append([])
        else:
            groups.append(items[idx : idx + sz])
        idx += sz
    return groups


def main() -> None:
    parser = argparse.ArgumentParser(description="Compose LongMemEval ORACLE into N groups with evidence-only filtering")
    parser.add_argument("--input", type=str, default=None, help="Path to longmemeval_oracle.json (default: same dir as this script)")
    parser.add_argument("--output", type=str, default=None, help="Path to write composed JSON (default: <input_dir>/longmemeval_oracle_composed.json)")
    parser.add_argument("--groups", type=int, default=10, help="Number of groups to compose (default: 10)")
    parser.add_argument("--shuffle", action="store_true", help="Shuffle entries before splitting into groups")
    parser.add_argument("--seed", type=int, default=42, help="Random seed when --shuffle is set")
    args = parser.parse_args()

    script_dir = Path(__file__).parent
    in_path = Path(args.input) if args.input else (script_dir / "longmemeval_oracle.json")
    if not in_path.exists():
        raise FileNotFoundError(f"Input not found: {in_path}")

    out_path = Path(args.output) if args.output else (in_path.parent / "longmemeval_oracle_composed.json")

    data: List[Dict[str, Any]] = json.loads(in_path.read_text(encoding="utf-8"))

    # 1) Filter out entries without evidence
    filtered = [d for d in data if _has_evidence(d)]
    dropped = len(data) - len(filtered)

    if len(filtered) == 0:
        raise RuntimeError("No entries with evidence found after filtering. Nothing to compose.")

    # Optional shuffle
    if args.shuffle:
        random.seed(args.seed)
        random.shuffle(filtered)

    # 2) Split into N groups (avoid empty trailing groups)
    n_groups = min(args.groups, len(filtered)) if len(filtered) > 0 else 0
    grouped = _split_evenly(filtered, n_groups)

    # 3) Compose each group with remapped evidence
    composed: List[Dict[str, Any]] = []
    for gi, items in enumerate(grouped, start=1):
        if not items:
            continue
        composed.append(_compose_group(items, group_id=f"group-{gi}"))

    if not composed:
        raise RuntimeError("No composed groups produced.")

    out_path.write_text(json.dumps(composed, ensure_ascii=False, indent=2), encoding="utf-8")

    # Summary
    sizes = [len(g.get("questions", [])) for g in composed]
    print(f"[OK] Wrote {out_path}")
    print(f"- Total entries: {len(data)} | kept: {len(filtered)} | dropped(no evidence): {dropped}")
    print(f"- Groups written: {len(composed)} | sizes: {sizes}")


if __name__ == "__main__":
    main()
