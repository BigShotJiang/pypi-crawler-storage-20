"""
Route handlers for template file downloads.

Provides endpoints to download template files for schemas and contract artifacts.
"""

import io
import logging
import zipfile
from pathlib import Path

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import FileResponse, Response

logger = logging.getLogger(__name__)
router = APIRouter()

# Template directory path
TEMPLATE_DIR = Path(__file__).parent.parent.parent.parent / "data" / "aviation_examples" / "template"


def _get_template_path(filename: str) -> Path:
    """Get the full path to a template file."""
    template_path = TEMPLATE_DIR / filename
    if not template_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Template file not found: {filename}",
        )
    return template_path


@router.get(
    "/templates/schema",
    summary="Download schema template",
    description="Download a template YAML file for creating a new schema",
    response_description="YAML template file",
    tags=["Templates"],
)
async def download_schema_template() -> FileResponse:
    """
    Download the schema template file.
    
    Returns:
        YAML file containing a template schema structure
    """
    try:
        template_path = _get_template_path("template_schema.yaml")
        return FileResponse(
            path=str(template_path),
            media_type="application/x-yaml",
            filename="template_schema.yaml",
            headers={
                "Content-Disposition": 'attachment; filename="template_schema.yaml"',
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error serving schema template: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to serve schema template: {str(e)}",
        )


@router.get(
    "/templates/contract-artifacts",
    summary="Download contract artifact templates",
    description="Download a ZIP archive containing all contract artifact templates (schema, metadata, coercion rules, validation rules, and contract)",
    response_description="ZIP archive containing template files",
    tags=["Templates"],
)
async def download_contract_artifacts() -> Response:
    """
    Download all contract artifact templates as a ZIP archive.
    
    The ZIP file contains:
    - template_schema.yaml
    - template_metadata.yaml
    - template_coercion_rules.yaml
    - template_validation_rules.yaml
    - template_contract.yaml
    
    Returns:
        ZIP file containing all template files
    """
    try:
        # Template files to include in the ZIP
        template_files = [
            "template_schema.yaml",
            "template_metadata.yaml",
            "template_coercion_rules.yaml",
            "template_validation_rules.yaml",
            "template_contract.yaml",
        ]
        
        # Create ZIP archive in memory
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
            for template_file in template_files:
                template_path = _get_template_path(template_file)
                # Read file content and add to ZIP
                zip_file.write(template_path, arcname=template_file)
        
        # Get ZIP content
        zip_buffer.seek(0)
        zip_content = zip_buffer.read()
        zip_buffer.close()
        
        return Response(
            content=zip_content,
            media_type="application/zip",
            headers={
                "Content-Disposition": 'attachment; filename="contract_artifact_templates.zip"',
            },
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating contract artifacts ZIP: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create contract artifacts ZIP: {str(e)}",
        )
