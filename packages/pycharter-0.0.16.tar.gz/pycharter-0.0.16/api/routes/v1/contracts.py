"""
Route handlers for contract parsing and building.
"""

import logging
import uuid
from typing import Optional, Union

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import ValidationError
from sqlalchemy.orm import Session

from pycharter import build_contract_from_store, parse_contract
from api.dependencies.database import get_db_session
from api.dependencies.store import get_metadata_store
from api.models.contracts import (
    ContractBuildRequest,
    ContractBuildResponse,
    ContractListResponse,
    ContractListItem,
    ContractParseRequest,
    ContractParseResponse,
    ContractUpdateRequest,
)
from pycharter.db.models import DataContractModel
from pycharter.metadata_store import MetadataStoreClient

logger = logging.getLogger(__name__)
router = APIRouter()


def _safe_uuid_to_str(value: Optional[Union[uuid.UUID, str]]) -> Optional[str]:
    """
    Safely convert a UUID or string to a string representation.
    
    Handles both UUID objects and string representations, including
    cases where SQLite might store UUIDs as strings.
    
    Args:
        value: UUID object, string, or None
        
    Returns:
        String representation of UUID, or None if value is None
    """
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, str):
        # If it's already a string, validate it's a valid UUID format
        try:
            # Validate and normalize the UUID string
            uuid_obj = uuid.UUID(value)
            return str(uuid_obj)
        except (ValueError, AttributeError):
            # If it's not a valid UUID, return as-is (might be a schema name)
            return value
    # Fallback: convert to string
    return str(value)


@router.post(
    "/contracts/parse",
    response_model=ContractParseResponse,
    status_code=status.HTTP_200_OK,
    summary="Parse a data contract",
    description="Parse a data contract dictionary into its component parts (schema, metadata, ownership, governance rules, etc.)",
    response_description="Parsed contract components",
)
async def parse_contract_endpoint(
    request: ContractParseRequest,
) -> ContractParseResponse:
    """
    Parse a data contract into its components.
    
    This endpoint takes a complete data contract dictionary and breaks it down
    into its constituent parts: schema, metadata, ownership, governance rules,
    coercion rules, and validation rules.
    
    Args:
        request: Contract parse request containing contract data
        
    Returns:
        Parsed contract components
        
    Raises:
        HTTPException: If contract parsing fails
    """
    # Handle potential double-wrapping
    contract_data = request.contract
    if isinstance(contract_data, dict) and "contract" in contract_data and len(contract_data) == 1:
        contract_data = contract_data["contract"]
    
    if not isinstance(contract_data, dict):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid contract format: expected dict, got {type(contract_data)}",
        )
    
    if "schema" not in contract_data:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Contract must contain a 'schema' field at the top level",
        )
    
    try:
        contract_metadata = parse_contract(contract_data)
        return ContractParseResponse(
            schema=contract_metadata.schema,
            metadata=contract_metadata.metadata,
            ownership=contract_metadata.ownership,
            governance_rules=contract_metadata.governance_rules,
            coercion_rules=contract_metadata.coercion_rules,
            validation_rules=contract_metadata.validation_rules,
            versions=contract_metadata.versions,
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )


@router.post(
    "/contracts/build",
    response_model=ContractBuildResponse,
    status_code=status.HTTP_200_OK,
    summary="Build a contract from metadata store",
    description="Reconstruct a complete data contract from components stored in the metadata store",
    response_description="Complete contract dictionary",
)
async def build_contract_endpoint(
    request: ContractBuildRequest,
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> ContractBuildResponse:
    """
    Build a contract from metadata store.
    
    This endpoint reconstructs a complete data contract dictionary from
    components stored in the metadata store. You can optionally include
    metadata, ownership, and governance rules.
    
    Args:
        request: Contract build request with schema_id and options
        store: Metadata store dependency
        
    Returns:
        Complete contract dictionary
        
    Raises:
        HTTPException: If contract building fails or schema not found
    """
    contract = build_contract_from_store(
        store=store,
        schema_id=request.schema_id,
        version=request.version,
        include_metadata=request.include_metadata,
        include_ownership=request.include_ownership,
        include_governance=request.include_governance,
    )
    
    if not contract:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Schema not found: {request.schema_id}",
        )
    
    return ContractBuildResponse(contract=contract)


@router.get(
    "/contracts",
    response_model=ContractListResponse,
    status_code=status.HTTP_200_OK,
    summary="List data contracts",
    description="Get a list of all data contracts stored in the database",
    response_description="List of contracts",
)
async def list_contracts(
    db: Session = Depends(get_db_session),
) -> ContractListResponse:
    """
    List all data contracts from the database.
    
    Args:
        db: Database session dependency
        
    Returns:
        List of contracts with metadata
        
    Raises:
        HTTPException: If database query fails
    """
    contracts = db.query(DataContractModel).order_by(
        DataContractModel.created_at.desc()
    ).all()
    
    contract_items = [
        ContractListItem(
            id=_safe_uuid_to_str(contract.id),
            name=contract.name,
            version=contract.version,
            status=contract.status,
            description=contract.description,
            schema_id=_safe_uuid_to_str(contract.schema_id),
            created_at=contract.created_at.isoformat() if contract.created_at else None,
            updated_at=contract.updated_at.isoformat() if contract.updated_at else None,
        )
        for contract in contracts
    ]
    
    return ContractListResponse(
        contracts=contract_items,
        total=len(contract_items),
    )


@router.get(
    "/contracts/{contract_id}",
    response_model=ContractListItem,
    status_code=status.HTTP_200_OK,
    summary="Get data contract by ID",
    description="Retrieve a specific data contract from the database by its ID",
    response_description="Contract details",
)
async def get_contract(
    contract_id: str,
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """
    Get a specific data contract from the database by ID.
    
    Args:
        contract_id: Contract ID (UUID)
        db: Database session dependency
        
    Returns:
        Contract details
        
    Raises:
        HTTPException: If contract not found or database query fails
    """
    try:
        contract_uuid = uuid.UUID(contract_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid contract ID format: {contract_id}",
        )
    
    # Query contract - try UUID comparison first
    contract = db.query(DataContractModel).filter(
        DataContractModel.id == contract_uuid
    ).first()
    
    # If not found, try string comparison (for SQLite compatibility where UUIDs might be stored as strings)
    if not contract:
        from sqlalchemy import cast, String
        contract = db.query(DataContractModel).filter(
            cast(DataContractModel.id, String) == contract_id
        ).first()
    
    # Final fallback: query all and compare by string (for edge cases)
    if not contract:
        logger.warning(f"Contract not found with standard queries, trying fallback for: {contract_id}")
        all_contracts = db.query(DataContractModel).all()
        for c in all_contracts:
            c_id_str = _safe_uuid_to_str(c.id)
            if c_id_str == contract_id or (c_id_str and c_id_str.lower() == contract_id.lower()):
                contract = c
                logger.info(f"Found contract via string comparison: {_safe_uuid_to_str(c.id)}")
                break
    
    if not contract:
        # Get diagnostic info for error message
        total = db.query(DataContractModel).count()
        all_contracts = db.query(DataContractModel).all()
        all_ids = [_safe_uuid_to_str(c.id) for c in all_contracts]
        logger.error(
            f"Contract not found: {contract_id} (UUID: {contract_uuid}). "
            f"Total contracts: {total}. "
            f"Available IDs: {all_ids}"
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contract not found: {contract_id}",
        )
    
    return ContractListItem(
        id=_safe_uuid_to_str(contract.id),
        name=contract.name,
        version=contract.version,
        status=contract.status,
        description=contract.description,
        schema_id=_safe_uuid_to_str(contract.schema_id),
        created_at=contract.created_at.isoformat() if contract.created_at else None,
        updated_at=contract.updated_at.isoformat() if contract.updated_at else None,
    )


@router.post(
    "/contracts/{contract_id}/build",
    response_model=ContractBuildResponse,
    status_code=status.HTTP_200_OK,
    summary="Build contract from contract ID",
    description="Reconstruct a complete data contract from a contract ID by fetching the associated schema and building the contract",
    response_description="Complete contract dictionary",
)
async def build_contract_from_id(
    contract_id: str,
    include_metadata: bool = Query(True, description="Include metadata in contract"),
    include_ownership: bool = Query(True, description="Include ownership information"),
    include_governance: bool = Query(True, description="Include governance rules"),
    db: Session = Depends(get_db_session),
    store: MetadataStoreClient = Depends(get_metadata_store),
) -> ContractBuildResponse:
    """
    Build a contract from a contract ID.
    
    This endpoint fetches the contract from the database, gets its schema_id,
    and then builds the complete contract from the metadata store.
    
    Args:
        contract_id: Contract ID (UUID)
        include_metadata: Whether to include metadata in the contract
        include_ownership: Whether to include ownership information
        include_governance: Whether to include governance rules
        db: Database session dependency
        store: Metadata store dependency
        
    Returns:
        Complete contract dictionary
        
    Raises:
        HTTPException: If contract not found or building fails
    """
    try:
        contract_uuid = uuid.UUID(contract_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid contract ID format: {contract_id}",
        )
    
    # Query contract - try UUID comparison first
    contract = db.query(DataContractModel).filter(
        DataContractModel.id == contract_uuid
    ).first()
    
    # If not found, try string comparison (for SQLite compatibility where UUIDs might be stored as strings)
    if not contract:
        from sqlalchemy import cast, String
        contract = db.query(DataContractModel).filter(
            cast(DataContractModel.id, String) == contract_id
        ).first()
    
    # Final fallback: query all and compare by string (for edge cases)
    if not contract:
        logger.warning(f"Contract not found with standard queries, trying fallback for: {contract_id}")
        all_contracts = db.query(DataContractModel).all()
        for c in all_contracts:
            c_id_str = _safe_uuid_to_str(c.id)
            if c_id_str == contract_id or (c_id_str and c_id_str.lower() == contract_id.lower()):
                contract = c
                logger.info(f"Found contract via string comparison: {_safe_uuid_to_str(c.id)}")
                break
    
    if not contract:
        # Get diagnostic info for error message
        total = db.query(DataContractModel).count()
        all_contracts = db.query(DataContractModel).all()
        all_ids = [_safe_uuid_to_str(c.id) for c in all_contracts]
        logger.error(
            f"Contract not found: {contract_id} (UUID: {contract_uuid}). "
            f"Total contracts: {total}. "
            f"Available IDs: {all_ids}"
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contract not found: {contract_id}",
        )
    
    if not contract.schema_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contract {contract_id} does not have an associated schema",
        )
    
    built_contract = build_contract_from_store(
        store=store,
        schema_id=_safe_uuid_to_str(contract.schema_id),
        version=contract.schema_version,
        include_metadata=include_metadata,
        include_ownership=include_ownership,
        include_governance=include_governance,
    )
    
    if not built_contract:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Schema not found for contract: {contract_id}",
        )
    
    return ContractBuildResponse(contract=built_contract)


@router.put(
    "/contracts/{contract_id}",
    response_model=ContractListItem,
    status_code=status.HTTP_200_OK,
    summary="Update data contract",
    description="Update contract metadata (name, version, status, description)",
    response_description="Updated contract details",
)
async def update_contract(
    contract_id: str,
    request: ContractUpdateRequest,
    db: Session = Depends(get_db_session),
) -> ContractListItem:
    """
    Update a data contract's metadata.
    
    This endpoint allows updating the contract's name, version, status, and description.
    Note: To update the schema, coercion rules, or validation rules, you need to
    upload a new version of the contract.
    
    Args:
        contract_id: Contract ID (UUID)
        request: Contract update request with fields to update
        db: Database session dependency
        
    Returns:
        Updated contract details
        
    Raises:
        HTTPException: If contract not found, invalid update, or database query fails
    """
    try:
        contract_uuid = uuid.UUID(contract_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid contract ID format: {contract_id}",
        )
    
    # Query contract - try UUID comparison first
    contract = db.query(DataContractModel).filter(
        DataContractModel.id == contract_uuid
    ).first()
    
    # If not found, try string comparison (for SQLite compatibility where UUIDs might be stored as strings)
    if not contract:
        from sqlalchemy import cast, String
        contract = db.query(DataContractModel).filter(
            cast(DataContractModel.id, String) == contract_id
        ).first()
    
    # Final fallback: query all and compare by string (for edge cases)
    if not contract:
        logger.warning(f"Contract not found with standard queries, trying fallback for: {contract_id}")
        all_contracts = db.query(DataContractModel).all()
        for c in all_contracts:
            c_id_str = _safe_uuid_to_str(c.id)
            if c_id_str == contract_id or (c_id_str and c_id_str.lower() == contract_id.lower()):
                contract = c
                logger.info(f"Found contract via string comparison: {_safe_uuid_to_str(c.id)}")
                break
    
    if not contract:
        # Get diagnostic info for error message
        total = db.query(DataContractModel).count()
        all_contracts = db.query(DataContractModel).all()
        all_ids = [_safe_uuid_to_str(c.id) for c in all_contracts]
        logger.error(
            f"Contract not found: {contract_id} (UUID: {contract_uuid}). "
            f"Total contracts: {total}. "
            f"Available IDs: {all_ids}"
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Contract not found: {contract_id}",
        )
    
    # Check if any fields are being updated
    if not any([request.name, request.version, request.status is not None, request.description is not None]):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one field must be provided for update",
        )
    
    # Check for unique constraint violation (name + version)
    if request.name or request.version:
        new_name = request.name if request.name else contract.name
        new_version = request.version if request.version else contract.version
        
        # Check if another contract with same name+version exists
        existing = db.query(DataContractModel).filter(
            DataContractModel.name == new_name,
            DataContractModel.version == new_version,
            DataContractModel.id != contract.id
        ).first()
        
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Contract with name '{new_name}' and version '{new_version}' already exists",
            )
    
    # Check if any fields are being updated
    if not any([request.name, request.version, request.status is not None, request.description is not None]):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least one field must be provided for update",
        )
    
    try:
        # Use direct SQL UPDATE to avoid session/detachment issues with SQLite
        from sqlalchemy import text
        
        # Build UPDATE statement with only the fields that are being updated
        set_clauses = []
        params = {}
        
        if request.name is not None:
            set_clauses.append('name = :name')
            params['name'] = request.name
        if request.version is not None:
            set_clauses.append('version = :version')
            params['version'] = request.version
        if request.status is not None:
            set_clauses.append('status = :status')
            params['status'] = request.status
        if request.description is not None:
            set_clauses.append('description = :description')
            params['description'] = request.description
        
        # Always update updated_at timestamp
        set_clauses.append('updated_at = CURRENT_TIMESTAMP')
        
        set_clause = ', '.join(set_clauses)
        
        # Use contract_id string for WHERE clause (works with both PostgreSQL and SQLite)
        contract_id_str = _safe_uuid_to_str(contract.id) or contract_id
        
        # Determine table name and SQL syntax based on database type
        from sqlalchemy import inspect
        engine = db.bind if hasattr(db, 'bind') else None
        is_sqlite = engine and 'sqlite' in str(engine.url)
        
        # Get contract ID as string for WHERE clause
        contract_id_str = _safe_uuid_to_str(contract.id) or contract_id
        
        if is_sqlite:
            # SQLite doesn't support schemas, and stores UUIDs as TEXT
            table_name = "data_contracts"
            # For SQLite, compare as strings
            sql = f"""
                UPDATE {table_name}
                SET {set_clause}
                WHERE id = :contract_id
            """
            params['contract_id'] = contract_id_str
        else:
            # PostgreSQL and other databases
            table_name = "pycharter.data_contracts"
            # Try with UUID first
            sql = f"""
                UPDATE {table_name}
                SET {set_clause}
                WHERE id = :contract_id::uuid
            """
            params['contract_id'] = contract_id_str
        
        # Execute the update
        result = db.execute(text(sql), params)
        
        if result.rowcount == 0:
            # If no rows updated, try alternative approaches
            if is_sqlite:
                # SQLite: try with explicit string comparison
                sql_fallback = f"""
                    UPDATE {table_name}
                    SET {set_clause}
                    WHERE CAST(id AS TEXT) = :contract_id
                """
            else:
                # PostgreSQL: try with text comparison
                sql_fallback = f"""
                    UPDATE {table_name}
                    SET {set_clause}
                    WHERE id::text = :contract_id
                """
            
            params['contract_id'] = contract_id_str
            result = db.execute(text(sql_fallback), params)
            
            if result.rowcount == 0:
                # Last resort: try with the UUID object
                if not is_sqlite:
                    sql_uuid = f"""
                        UPDATE {table_name}
                        SET {set_clause}
                        WHERE id = :contract_id
                    """
                    params['contract_id'] = contract_uuid
                    result = db.execute(text(sql_uuid), params)
                
                if result.rowcount == 0:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"Contract not found or could not be updated: {contract_id}",
                    )
        
        # Commit the changes
        db.commit()
        
        # Re-query the contract to get updated values (don't use refresh since we used raw SQL)
        # Expire the old object from the session first
        db.expire(contract)
        
        # Re-query using the contract_id_str to ensure we get the updated record
        contract = db.query(DataContractModel).filter(
            DataContractModel.id == contract_uuid
        ).first()
        
        if not contract:
            # Try string comparison (for SQLite)
            from sqlalchemy import cast, String
            contract = db.query(DataContractModel).filter(
                cast(DataContractModel.id, String) == contract_id_str
            ).first()
        
        if not contract:
            # Final fallback: query all and find by string
            all_contracts = db.query(DataContractModel).all()
            for c in all_contracts:
                c_id_str = _safe_uuid_to_str(c.id)
                if c_id_str == contract_id_str or (c_id_str and c_id_str.lower() == contract_id_str.lower()):
                    contract = c
                    break
        
        if not contract:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Contract not found after update: {contract_id}",
            )
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Error updating contract: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update contract: {str(e)}",
        )
    
    return ContractListItem(
        id=_safe_uuid_to_str(contract.id),
        name=contract.name,
        version=contract.version,
        status=contract.status,
        description=contract.description,
        schema_id=_safe_uuid_to_str(contract.schema_id),
        created_at=contract.created_at.isoformat() if contract.created_at else None,
        updated_at=contract.updated_at.isoformat() if contract.updated_at else None,
    )
