import keyring

SERVICE_NAME = "codeppr"

def get_api_key(provider: str) -> str | None:
    return keyring.get_password(SERVICE_NAME, provider)


def set_api_key(provider: str, key: str) -> None:
    if not key:
        raise ValueError("API key cannot be empty.")
    keyring.set_password(SERVICE_NAME, provider, key)


def delete_api_key(provider: str) -> None:
    keyring.delete_password(SERVICE_NAME, provider)