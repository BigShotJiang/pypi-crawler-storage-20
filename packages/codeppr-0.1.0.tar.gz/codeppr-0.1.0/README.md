# Codeppr

An AI assisted code review agent that saves you from bad commits by running its analysis during the pre-commit stage.

## Features

- **AI Code Analysis**: Intelligent code review suggestions.
- **Pre-commit Safety**: Catch potential issues before they are committed.

## How to install

<!-- Section intentionally left empty -->

## Installing locally (development)

To install the dependencies and set up the project locally for development, run:

```bash
pip install .
# OR
uv sync
```

## Usage

Once installed, you need to initialize the tool in your repository:

1. **Install Hooks**: Run this command to set up the necessary git hooks.
   ```bash
   codeppr install
   ```

2. **Automatic Review**: The tool will now automatically run and review your changes whenever you try to commit code.
   ```bash
   git commit -m "your message"
   ```

You can also manually check available commands with:

```bash
codeppr --help
```