## Models:
## `opus` : claude-opus-4-5-20251101
## `sonnet` : claude-sonnet-4-5-20250929
## `sonnet[1m]` : claude-sonnet-4-5-20250929[1m]
## `haiku` : claude-haiku-4-5-20251001

## New Session: Claude Code v2.0.76: `opus`
## Action Plan: ``
## Phases: all

---

/wsd:init, /wsd:prepare, /wsd:execute, /wsd:close

---
