"""Workscope Development package.

This package provides template management for AI-assisted development workflows.
"""

__version__ = "1.0.1"
