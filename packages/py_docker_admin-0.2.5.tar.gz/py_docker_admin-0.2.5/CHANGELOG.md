# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.5] - 2026-01-18

### Added
- Added optional `base_url` configuration for Portainer to support running behind reverse proxy
- Implemented validation for base_url format (must start with '/')
- Added comprehensive tests for base_url functionality
- Updated example configuration with base_url documentation

### Changed
- Updated version to 0.2.5
- Enhanced PortainerInstaller to include `--base-url` parameter when configured
- Improved configuration validation and error handling

### Fixed
- Fixed validation logic to properly handle empty strings
- Ensured backward compatibility with existing configurations

## [0.2.4] - 2026-01-18

### Added
- Implemented automatic startup for Portainer container on system boot
- Added `--restart unless-stopped` flag to Portainer Docker container
- Ensured Portainer container starts automatically when Docker service starts
- Updated documentation to reflect auto-start functionality

### Changed
- Updated version to 0.2.4
- Enhanced PortainerInstaller with auto-restart policy
- Improved system startup reliability

## [0.2.3] - 2026-01-18

### Added
- Added `uninstall` command to CLI for complete Docker removal
- Implemented container, volume, network, and image cleanup functionality
- Added Docker package uninstallation with data removal options
- Added `--remove-data/--keep-data` flag to control data cleanup

### Changed
- Updated version to 0.2.3
- Enhanced DockerInstaller class with comprehensive uninstall methods

## [0.2.2] - 2026-01-18

### Added
- Created `publish_wheel.sh` script for automated PyPI publication
- Added comprehensive error handling and user confirmation in publication script
- Added cleanup step to remove dist folder after successful upload

### Changed
- Improved logging and code guidelines using ruff
- Enhanced project documentation with publication guide

## [0.2.1] - 2026-01-17

### Added
- Basic project structure with core functionality
- Initial Docker and Portainer automation features
- Core CLI commands and utilities
- Basic testing framework with pytest
- Initial documentation

### Changed
- Refactored code structure for better maintainability
- Improved error handling in core modules
- Enhanced type annotations and code quality

## [0.2.0] - 2026-01-15

### Added
- Initial project setup
- Basic Docker automation capabilities
- Core models and utilities
- First version of CLI interface
- Initial test suite

### Changed
- Project structure organization
- Documentation improvements
- Code quality enhancements
