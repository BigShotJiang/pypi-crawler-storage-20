"""Markdown generation package."""
