from rich.console import Console 
from rich.panel import Panel 
from rich.text import Text 
console = Console() 
def welcome(): 
    logo = Text("fid-ffmpeg", style="bold gradient(blue , magenta)") 
    console.print(logo ,justify="center") 
    console.print( Panel.fit("[bold] fid-ffmpeg Helper [/bold]\n\n" 
    "[green]Commands:[/green]\n" 
    " • info Show video info\n" 
    " • audio Extract audio\n" 
    " • frames Extract frames\n" 
    " • gif Create gif\n" 
    " • mute Remove audio\n" 
    " • compress Compress video\n\n" 
    "[dim]Run : fid <command> <video path>[/dim]", border_style="cyan",))