Core concepts
=============

