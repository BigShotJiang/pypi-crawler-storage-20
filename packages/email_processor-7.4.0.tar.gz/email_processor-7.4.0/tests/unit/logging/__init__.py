"""Tests for logging module."""
