"""Tests for imap module."""
