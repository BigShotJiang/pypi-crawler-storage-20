"""Tests for processor module."""
