"""Tests for SMTP module."""
