"""Tests for zae-limiter."""
