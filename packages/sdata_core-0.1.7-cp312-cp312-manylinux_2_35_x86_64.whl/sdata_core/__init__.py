# -*- coding: utf-8 -*-
"""
sdata_core - Structured data format with modern metadata system.
Binary distribution - compiled with Nuitka.
"""

__version__ = "0.1.7"

from sdata_core.metadata import (
    Attribute,
    DType,
    DublinCore,
    FieldMeta,
    JsonLdContext,
    Metadata,
    MetadataJSONEncoder,
    add_dc_attribute,
    create_attribute_from_annotated,
    extract_name_unit,
)
from sdata_core.suuid import SUUID

__all__ = [
    "__version__",
    "Attribute",
    "Metadata",
    "SUUID",
    "DType",
    "FieldMeta",
    "DublinCore",
    "JsonLdContext",
    "MetadataJSONEncoder",
    "add_dc_attribute",
    "create_attribute_from_annotated",
    "extract_name_unit",
]
