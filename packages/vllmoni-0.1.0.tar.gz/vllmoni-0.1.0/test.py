import subprocess
import time


def get_nvidia_smi():
    result = subprocess.run(
        [
            "nvidia-smi",
            "--query-gpu=index,name,memory.used,memory.total,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        capture_output=True,
        text=True,
    )
    for line in result.stdout.strip().split("\n"):
        index, name, mem_used, mem_total, util = line.split(", ")
        print(
            f"{index}: {name} | Memory: {mem_used}/{mem_total} MB | Utilization: {util} %"
        )


if __name__ == "__main__":
    while True:
        get_nvidia_smi()
        time.sleep(1)
