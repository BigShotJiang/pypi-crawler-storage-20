---
title: Nexus Gym
emoji: 🚀
colorFrom: red
colorTo: red
sdk: docker
app_port: 7860
app_file: main_train.py
tags:
- fastapi
- reinforcement-learning
- gymnasium
pinned: false
short_description: NEXUS - an AI-powered platformer game with procedural level
license: apache-2.0
---

# Welcome to Streamlit!

Edit `/src/streamlit_app.py` to customize this app to your heart's desire. :heart:

If you have any questions, checkout our [documentation](https://docs.streamlit.io) and [community
forums](https://discuss.streamlit.io).
