from src.textual_searchable_selectionlist.options import SelectionStrategy
from src.textual_searchable_selectionlist.select import select


def print_selected(selected: list):
    print('\n----- Selections:\n' + '\n'.join(selected))


def test_select_items_str():
    selected = select(['John', 'Jane', 'James'], SelectionStrategy.ONE, 'This is the title')
    print_selected(selected)


def test_select_items_tuple():
    selected = select(
        [('a', 'Abc'), ('b', 'Bcd'), ('c', 'Cde')], SelectionStrategy.ONE, 'This is the title'
    )
    print_selected(selected)


if __name__ == '__main__':
    test_select_items_str()
