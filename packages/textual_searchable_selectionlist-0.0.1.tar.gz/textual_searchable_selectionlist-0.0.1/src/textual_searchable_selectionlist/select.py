from enum import Enum
from typing import Iterable, Literal, Type, TypeAlias, TypeVar

from textual.widgets._option_list import Option  # noqa

from .options import SelectionStrategy
from .searchable_list_app import SearchableListApp
from .searchable_list_widget import SelectionItemType, SelectionType

T = TypeVar('T')
T_Enum = TypeVar('T_Enum', bound=Enum)
SelectionResultType: TypeAlias = SelectionType | Option


def select(
    selections: Iterable[SelectionItemType],
    selection_strategy: SelectionStrategy,
    search_title: str | None = None,
    app_title: str | None = 'Select items',
    inline: bool = False,
    **kwargs,
) -> list[SelectionResultType]:
    # if selection_strategy is SelectionStrategy.ALL:
    #     return list(selections)

    app: SearchableListApp = SearchableListApp(
        selections, selection_strategy, search_title=search_title, **kwargs
    )
    if app_title:
        app.title = app_title
    selected = app.run(inline=inline)
    return selected or []


def select_enum(
    enum_type: Type[T_Enum],
    selection_strategy: SelectionStrategy = SelectionStrategy.ONE,
    select_by: Literal['name', 'value'] = 'name',
    title: str = '',
) -> list[T_Enum]:
    """Select from an enum."""
    selections = (
        [item.name for item in enum_type]
        if select_by == 'name'
        else [item.value for item in enum_type]
    )

    title = title or f'Select from {enum_type.__name__}'
    selection = select(  # type: ignore
        selections=selections,
        selection_strategy=selection_strategy,
        search_title=title,
    )
    if selection and isinstance(selection[0], Option):
        selection_values = [item.value for item in selection]
    else:
        selection_values = selection

    return (
        [enum_type[x] for x in selection_values]
        if select_by == 'name'
        else [enum_type(x) for x in selection_values]
    )
