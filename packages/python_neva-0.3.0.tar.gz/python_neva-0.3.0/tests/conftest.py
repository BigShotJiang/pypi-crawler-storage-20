"""Test configuration and fixtures."""

# Import fixtures from neva.testing
# This makes them available to all tests
pytest_plugins = ["neva.testing.fixtures"]
