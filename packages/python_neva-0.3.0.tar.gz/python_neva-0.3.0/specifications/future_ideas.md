# Future ideas

## Testing

Provide scoped fixtures for testing in addition to the one we have.
