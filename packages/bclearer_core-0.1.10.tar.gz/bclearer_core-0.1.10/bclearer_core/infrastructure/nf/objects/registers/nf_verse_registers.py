class NfVerseRegisters:
    pass
