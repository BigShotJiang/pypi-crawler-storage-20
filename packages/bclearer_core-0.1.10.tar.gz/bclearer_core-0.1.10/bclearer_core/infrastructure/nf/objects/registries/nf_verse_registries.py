class NfVerseRegistries:
    pass
