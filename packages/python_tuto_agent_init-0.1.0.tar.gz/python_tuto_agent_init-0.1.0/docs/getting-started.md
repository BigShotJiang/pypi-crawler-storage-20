# Getting Started

## Installation

```bash
uv add python-tuto-agent-init
```

## Usage

```python
from python_tuto_agent_init import hello

print(hello())
# Output: Hello from python-tuto-agent-init!
```

## Development

```bash
git clone https://github.com/JarryGabriel/python-tuto-agent-init.git
cd python-tuto-agent-init
make install
make check
```
