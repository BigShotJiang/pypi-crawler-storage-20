---
hide:
  - navigation
  - toc
---

# python-tuto-agent-init

<p align="center">
  <strong>A modern Python tutorial for agent initialization</strong>
</p>

<p align="center">
  <a href="https://github.com/JarryGabriel/python-tuto-agent-init/actions/workflows/ci.yml">
    <img src="https://github.com/JarryGabriel/python-tuto-agent-init/actions/workflows/ci.yml/badge.svg" alt="CI" />
  </a>
  <a href="https://coveralls.io/github/JarryGabriel/python-tuto-agent-init?branch=main">
    <img src="https://coveralls.io/repos/github/JarryGabriel/python-tuto-agent-init/badge.svg?branch=main" alt="Coverage" />
  </a>
  <a href="https://pypi.org/project/python-tuto-agent-init/">
    <img src="https://img.shields.io/pypi/v/python-tuto-agent-init" alt="PyPI" />
  </a>
  <img src="https://img.shields.io/badge/python-3.12+-blue.svg" alt="Python 3.12+" />
  <img src="https://img.shields.io/badge/typed-strict-blue.svg" alt="Typed" />
</p>

---

## Installation

```bash
uv add python-tuto-agent-init
```

## Quick Start

```python
from python_tuto_agent_init import hello

print(hello())
```

## Features

- ✅ **Modern Python** — 3.12+ with strict typing
- ✅ **Fast** — Optimized for performance  
- ✅ **Tested** — Full coverage with pytest

---

<div style="text-align: center; margin: 2rem 0;">
  <a href="getting-started/" class="md-button md-button--primary">Get Started →</a>
</div>
