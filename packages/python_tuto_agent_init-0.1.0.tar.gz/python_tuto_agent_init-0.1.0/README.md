# python-tuto-agent-init

<p align="center">
  <a href="https://github.com/JarryGabriel/python-tuto-agent-init/actions/workflows/ci.yml"><img src="https://github.com/JarryGabriel/python-tuto-agent-init/actions/workflows/ci.yml/badge.svg" alt="CI"></a>
  <a href="https://coveralls.io/github/JarryGabriel/python-tuto-agent-init?branch=main"><img src="https://coveralls.io/repos/github/JarryGabriel/python-tuto-agent-init/badge.svg?branch=main" alt="Coverage"></a>
  <a href="https://pypi.org/project/python-tuto-agent-init/"><img src="https://img.shields.io/pypi/v/python-tuto-agent-init" alt="PyPI"></a>
  <img src="https://img.shields.io/badge/python-3.12%2B-blue" alt="Python 3.12+">
  <img src="https://img.shields.io/badge/typed-strict-blue" alt="Typed">
  <a href="https://github.com/astral-sh/ruff"><img src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json" alt="Ruff"></a>
  <a href="https://github.com/astral-sh/uv"><img src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/uv/main/assets/badge/v0.json" alt="uv"></a>
  <a href="https://JarryGabriel.github.io/python-tuto-agent-init/"><img src="https://img.shields.io/badge/docs-live-brightgreen" alt="Docs"></a>
</p>

> A modern Python tutorial for agent initialization

## Installation

```bash
uv add python-tuto-agent-init
```

## Quick Start

```python
from python_tuto_agent_init import hello

print(hello())
```

## Development

```bash
git clone https://github.com/JarryGabriel/python-tuto-agent-init.git
cd python-tuto-agent-init
make install
make check
```

## License

MIT - See [LICENSE](LICENSE) for details.
