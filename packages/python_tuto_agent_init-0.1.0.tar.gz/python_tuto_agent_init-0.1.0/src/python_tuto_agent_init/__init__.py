"""python-tuto-agent-init - A modern Python tutorial for agent initialization"""

from python_tuto_agent_init._version import __version__

__all__ = ["__version__"]


def hello() -> str:
    """Return a greeting message."""
    return "Hello from python-tuto-agent-init!"
