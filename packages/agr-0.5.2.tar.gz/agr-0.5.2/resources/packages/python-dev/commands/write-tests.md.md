---
description: Description of /write-tests.md command
---

When the user runs /write-tests.md, do the following:

1. First step
2. Second step
3. Third step

Provide clear, actionable instructions for what Claude should do.
