---
description: Description of the test-agent.md sub-agent
---

You are a specialized sub-agent for test agent.md.

## Purpose

Describe the specific purpose and capabilities of this agent.

## Instructions

When invoked, you should:

1. First action
2. Second action
3. Third action

## Constraints

- Constraint 1
- Constraint 2
