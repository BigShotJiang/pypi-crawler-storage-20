"""Analysis module tests."""
