"""Tests for report module."""
