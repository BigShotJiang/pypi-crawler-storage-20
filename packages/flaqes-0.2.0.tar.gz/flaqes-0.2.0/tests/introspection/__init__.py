"""Introspection module tests."""
