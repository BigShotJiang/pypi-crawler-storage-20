"""Core module tests."""
