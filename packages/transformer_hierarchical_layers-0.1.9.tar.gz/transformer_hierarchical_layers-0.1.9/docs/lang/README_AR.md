<!---
حقوق الطبع والنشر 2026 فريق EGen. جميع الحقوق محفوظة.

مرخص بموجب ترخيص MIT.
-->

<div align="center">
    <img src="https://i.ibb.co/sJ6Vx8J0/banner.jpg" alt="THL Banner" width="100%"/>
</div>
<br>

<p align="center">
    <img src="https://img.shields.io/badge/python-3.8+-blue.svg" alt="Python Version">
    <img src="https://img.shields.io/badge/license-MIT-green.svg" alt="License">
    <img src="https://img.shields.io/badge/vram-4GB-orange.svg" alt="VRAM Optimized">
</p>

<h1 align="center">🐼 THL: Transformer Hierarchical Layers</h1>

<p align="center">
    <a>العربية</a> •
    <a href="../../README.md">English</a> •
    <a href="./README_ES.md">Español</a> •
    <a href="./README_FR.md">Français</a> •
    <a href="./README_zh-hans.md">简体中文</a>
</p>

<h3 align="center">
    بنية تكرارية هرمية متطورة للأجهزة ذات الموارد المحدودة
</h3>

---

## 🎯 نظرة عامة

**THL** هي بنية تكرارية هرمية مبتكرة تتيح تشغيل نماذج اللغة الكبيرة على أجهزة المستهلكين باستخدام **4 جيجابايت فقط من ذاكرة VRAM**. على عكس نماذج المحولات التقليدية التي تعاني من انفجار ذاكرة التخزين المؤقت KV، يحقق THL **تعقيد ذاكرة O(1) لكل طبقة** من خلال تصميم ذاكرة مستقل عن طول التسلسل.

### المشكلة التي نحلها

تواجه نماذج المحولات التقليدية عنق زجاجة حرج: ذاكرة التخزين المؤقت KV الخاصة بها تنمو خطياً مع طول التسلسل O(T)، مما يجعل توليد السياق الطويل مستحيلاً على أجهزة المستهلكين. يمكن لنموذج بحجم 7 مليار معامل يعالج 8 آلاف رمز أن يتجاوز بسهولة 24 جيجابايت من ذاكرة VRAM.

### حلنا

يستبدل THL ذاكرة التخزين المؤقت KV غير المحدودة **ببنك ذاكرة ذو فتحات ثابتة** (افتراضي: 1024 فتحة)، مما يتيح:
- ✅ طول سياق لا نهائي دون تجاوز الذاكرة
- ✅ الاستدلال على أجهزة بذاكرة VRAM 4 جيجابايت
- ✅ أداء تنافسي مع بنى المحولات
- ✅ النشر على الأجهزة المحمولة والطرفية

## ⚡ الميزات الرئيسية

- **ذاكرة محدودة (O(1))**: فتحات الذاكرة الثابتة تقضي على انفجار ذاكرة التخزين المؤقت KV
- **التكرار الهرمي**: طبقات GRU متعددة المقاييس الزمنية تعالج المعلومات على فترات أسية (τ = 2^k)
- **التوجيه المتفرق**: توجيه Top-K متعدد الرؤوس يصل إلى الذكريات ذات الصلة بكفاءة
- **استدلال منخفض VRAM**: محرك استدلال طبقي يتيح نماذج 7 مليار+ معامل على <4 جيجابايت VRAM
- **جاهز للإنتاج**: مجموعة اختبار شاملة وواجهات برمجة تطبيقات موثقة

## 🛠️ التثبيت

### المتطلبات
- Python 3.8+
- PyTorch 1.12+
- CUDA 11.0+ (لتسريع GPU)

### التثبيت من المصدر

```bash
# استنساخ المستودع
git clone https://github.com/EGen-V/Transformer-Hierarchical-Layers.git
cd Transformer-Hierarchical-Layers/Core

# تثبيت التبعيات
pip install -r requirements.txt

# تثبيت THL
pip install -e .
```

### التثبيت السريع (PyPI)
```bash
pip install Transformer-Hierarchical-Layers
```

## 🚀 البدء السريع

### نمذجة اللغة الأساسية

```python
import torch
from thl.config import THLConfig
from thl.model import THLModel

# تكوين النموذج لـ 4 جيجابايت VRAM
config = THLConfig(
    num_tiers=3,          # العمق الهرمي
    memory_slots=1024,    # حجم الذاكرة الثابت
    dim=768,              # بُعد النموذج
    vocab_size=50257      # حجم المفردات
)

# تهيئة النموذج
model = THLModel(config)

# تشغيل الاستدلال
input_ids = torch.randint(0, 50257, (1, 32))
logits, state = model(input_ids)

print(f"شكل المخرجات: {logits.shape}")  # [1, 32, 50257]
```

### توليد البث منخفض VRAM

بالنسبة للنماذج الأكبر، استخدم محرك الاستدلال الطبقي لبث الطبقات عبر GPU:

```python
from thl.inference.layered import LayeredInferenceEngine
from thl.inference.state import InferenceState

# تهيئة محرك البث
engine = LayeredInferenceEngine(model, device="cuda")

# إنشاء حالة الاستدلال
state = InferenceState.init(
    batch_size=1,
    config=config,
    tiers=model.tiers,
    memory_bank=model.memory_bank
)

# توليد الرموز واحدة تلو الأخرى
generated_tokens = []
for _ in range(100):
    token = torch.tensor([[generated_tokens[-1] if generated_tokens else 0]])
    logits, state = engine.step(token, state)
    next_token = logits.argmax(dim=-1)
    generated_tokens.append(next_token.item())
```

### مثال توليد النص

```python
from thl.generation import generate_text

prompt = "مستقبل الذكاء الاصطناعي هو"
output = generate_text(
    model=model,
    tokenizer=tokenizer,
    prompt=prompt,
    max_length=200,
    temperature=0.8,
    top_k=50
)
print(output)
```

## 🏗️ البنية المعمارية

يستخدم THL بنية تكرارية هرمية بأربعة مكونات رئيسية:

| المكون | الرمز | الوصف |
|-----------|--------|-------------|
| **بنك الذاكرة** | M_t | مصفوفة ذات حجم ثابت (J × d) تخزن السياق طويل الأمد |
| **الموجه المتفرق** | r_t | آلية انتباه Top-K للوصول الفعال إلى الذاكرة |
| **الطبقات الهرمية** | s_t^(k) | مكدس من خلايا GRU يتم تحديثه على فترات أسية τ = 2^k |
| **كاتب الجِدة** | w_t | آلية بوابة تكتب المعلومات الجديدة فقط إلى الذاكرة |

### تدفق المعلومات

1. **القراءة**: يسترجع الموجه المتفرق فتحات الذاكرة ذات الصلة بـ Top-K
2. **المعالجة**: تتحدث الطبقات الهرمية على مقاييس زمنية مختلفة
3. **الكتابة**: تحدد بوابة الجِدة المعلومات الجديدة التي سيتم تخزينها
4. **التنبؤ**: تولد طبقة الإخراج احتماليات الرمز التالي

## 📊 الأداء

| المقياس | THL-7B | Transformer-7B |
|--------|--------|----------------|
| **VRAM (سياق 8K)** | 3.8 جيجابايت | 26.4 جيجابايت |
| **الحيرة** | ~12.4 | ~11.8 |
| **الإنتاجية** | 42 رمز/ث | 38 رمز/ث |
| **الحد الأقصى للسياق** | غير محدود | 8K رمز |

*تم قياسه على NVIDIA RTX 3060 (12 جيجابايت)*

## 🧪 الاختبار

نحافظ على تغطية اختبار شاملة. قم بتشغيل المجموعة الكاملة:

```bash
# تشغيل جميع الاختبارات
./scripts/run_tests.sh

# تشغيل فئات اختبار محددة
pytest tests/test_model.py          # اختبارات النموذج
pytest tests/test_inference.py      # اختبارات الاستدلال
pytest tests/test_memory.py         # اختبارات إدارة الذاكرة
```

## 📚 الوثائق

- [مواصفات المعمارية](../THL_ARCHITECTURE_SPEC.md)
- [سياق المشروع وفلسفته](../THL_CONTEXT.md)
- [مرجع API](../../thl/README.md)
- [دليل الاختبار](../../tests/README.md)
- [دليل الاستدلال](../../thl/inference/README.md)

## 🗺️ خارطة الطريق

- [ ] نقاط تفتيش النماذج المدربة مسبقاً
- [ ] إصدار حزمة PyPI
- [ ] دعم تصدير ONNX
- [ ] النشر على الأجهزة المحمولة (iOS/Android)
- [ ] النشر على الويب (WASM)
- [ ] دعم التدريب على GPU متعددة
- [ ] التكميم (INT8/INT4)

## 🤝 المساهمة

نرحب بالمساهمات! يرجى الاطلاع على [إرشادات المساهمة](CONTRIBUTING.md) للحصول على التفاصيل.

```bash
# إعداد بيئة التطوير
git clone https://github.com/EGen-V/Transformer-Hierarchical-Layers.git
cd Transformer-Hierarchical-Layers
pip install -e ".[dev]"
pre-commit install
```

## 📄 الاستشهاد

إذا كنت تستخدم THL في بحثك، يرجى الاستشهاد به:

```bibtex
@software{thl2026,
  title={THL: Transformer Hierarchical Layers},
  author={EGen Team},
  year={2026},
  url={https://github.com/EGen-V/Transformer-Hierarchical-Layers}
}
```

## 📜 الترخيص

هذا المشروع مرخص بموجب ترخيص MIT - راجع ملف [LICENSE](LICENSE) للحصول على التفاصيل.

## 🙏 شكر وتقدير

- مستوحى من بنى الذاكرة التكرارية وأبحاث المحولات الفعالة
- مبني باستخدام PyTorch ومجتمع التعلم الآلي مفتوح المصدر

## 📧 التواصل

- **المشكلات**: [GitHub Issues](https://github.com/EGen-V/Transformer-Hierarchical-Layers/issues)
- **المناقشات**: [GitHub Discussions](https://github.com/EGen-V/Transformer-Hierarchical-Layers/discussions)
- **البريد الإلكتروني**: mouhebzayani@erebustn.io

---

<p align="center">
    صُنع بـ ❤️ من قبل فريق EGen
</p>