
from setuptools import setup, find_packages
setup(
    name="MandreDialogs-MD3",
    version="1.1.1",
    author="MandreAI",
    description="TRUE Native Android MD3 Dialogs (Standalone UI)",
    packages=find_packages(),
)
