
from java import dynamic_proxy, jint
from java.lang import Runnable
from android.app import Dialog
from android.graphics import Color, Typeface
from android.graphics.drawable import GradientDrawable, ColorDrawable, RippleDrawable
from android.content.res import ColorStateList
from android.view import Gravity, View, Window, WindowManager
from android.widget import LinearLayout, TextView, FrameLayout, EditText, ScrollView
from android.view.animation import DecelerateInterpolator, OvershootInterpolator
from android.util import TypedValue
from org.telegram.messenger import AndroidUtilities

# Импорт утилит для получения контекста
try:
    from client_utils import get_last_fragment
    from android_utils import run_on_ui_thread, log
except ImportError:
    def get_last_fragment(): return None
    def run_on_ui_thread(f): f()
    def log(t): print(t)

class _OnClick(dynamic_proxy(View.OnClickListener)):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn
    def onClick(self, v):
        if self.fn: self.fn()

class Styles:
    """Хардкорные стили MD3, не зависящие от Телеграма"""
    @staticmethod
    def get_colors():
        # Темная тема MD3 (Surface Container High)
        return {
            "surface": 0xFF2B2D30,      # Темно-серый (JetBrains/Material style)
            "on_surface": 0xFFE2E2E2,   # Почти белый текст
            "secondary": 0xFFC7C7C7,    # Серый текст
            "primary": 0xFFAACCFF,      # Пастельный синий (MD3 Accent)
            "primary_bg": 0xFF004A77,   # Фон кнопки
            "input_bg": 0xFF1E1F22,     # Фон поля ввода
            "divider": 0xFF4E5058
        }

    @staticmethod
    def bg(color, radius_dp):
        d = GradientDrawable()
        d.setCornerRadius(float(AndroidUtilities.dp(radius_dp)))
        d.setColor(int(color))
        return d

    @staticmethod
    def btn_bg(color):
        d = GradientDrawable()
        d.setCornerRadius(float(AndroidUtilities.dp(20))) # Полное скругление (Pill shape)
        d.setColor(int(color))
        return d

class MandreDialogs:
    @staticmethod
    def alert(title, message, confirm_text="OK", cancel_text=None, on_confirm=None):
        MandreDialogs._show(title, message, None, confirm_text, cancel_text, on_confirm)

    @staticmethod
    def input(title, hint, confirm_text="OK", cancel_text="Cancel", on_confirm=None):
        context = get_last_fragment().getParentActivity()
        colors = Styles.get_colors()
        
        # Контейнер поля ввода
        fl = FrameLayout(context)
        fl.setPadding(AndroidUtilities.dp(24), 0, AndroidUtilities.dp(24), 0)
        
        et = EditText(context)
        et.setHint(hint)
        et.setTextSize(16)
        et.setTextColor(colors["on_surface"])
        et.setHintTextColor(0xFF707070)
        et.setSingleLine(True)
        
        # Стилизация поля (Native Box)
        bg = GradientDrawable()
        bg.setColor(colors["input_bg"])
        bg.setCornerRadius(float(AndroidUtilities.dp(8)))
        bg.setStroke(AndroidUtilities.dp(1), colors["divider"])
        et.setBackground(bg)
        et.setPadding(AndroidUtilities.dp(16), AndroidUtilities.dp(12), AndroidUtilities.dp(16), AndroidUtilities.dp(12))
        
        fl.addView(et, FrameLayout.LayoutParams(-1, -2))
        
        def _cb():
            if on_confirm: on_confirm(str(et.getText()))

        MandreDialogs._show(title, None, fl, confirm_text, cancel_text, _cb)
        
        et.requestFocus()
        AndroidUtilities.showKeyboard(et)

    @staticmethod
    def _show(title, message, custom_view, pos_txt, neg_txt, on_pos):
        def _ui():
            try:
                act = get_last_fragment().getParentActivity()
                colors = Styles.get_colors()
                
                # 1. Native Dialog (Android SDK)
                dialog = Dialog(act)
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                window = dialog.getWindow()
                window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                window.setDimAmount(0.6) # Сильное затемнение фона
                
                # 2. Root Layout (Surface)
                root = LinearLayout(act)
                root.setOrientation(1)
                # Радиус 28dp (Material 3 Spec)
                root.setBackground(Styles.bg(colors["surface"], 28)) 
                root.setPadding(0, AndroidUtilities.dp(24), 0, AndroidUtilities.dp(24))
                
                # Ширина диалога (стандарт 312dp или 90% экрана)
                # layout_params = FrameLayout.LayoutParams(AndroidUtilities.dp(320), -2)
                
                # 3. Title
                if title:
                    tv = TextView(act)
                    tv.setText(title)
                    tv.setTextSize(22)
                    tv.setTextColor(colors["on_surface"])
                    tv.setTypeface(Typeface.DEFAULT_BOLD)
                    tv.setGravity(Gravity.CENTER)
                    tv.setPadding(AndroidUtilities.dp(24), 0, AndroidUtilities.dp(24), AndroidUtilities.dp(16))
                    root.addView(tv)

                # 4. Message
                if message:
                    tv_msg = TextView(act)
                    tv_msg.setText(message)
                    tv_msg.setTextSize(15)
                    tv_msg.setTextColor(colors["secondary"])
                    tv_msg.setGravity(Gravity.CENTER_HORIZONTAL)
                    tv_msg.setLineSpacing(AndroidUtilities.dp(3), 1.0)
                    tv_msg.setPadding(AndroidUtilities.dp(24), 0, AndroidUtilities.dp(24), 0)
                    root.addView(tv_msg)

                # 5. Custom View
                if custom_view:
                    root.addView(custom_view)

                # 6. Buttons Container
                btns = LinearLayout(act)
                btns.setOrientation(0)
                btns.setGravity(Gravity.CENTER)
                btns.setPadding(AndroidUtilities.dp(20), AndroidUtilities.dp(24), AndroidUtilities.dp(20), 0)
                
                # Helper for buttons
                def mk_btn(text, is_primary, cb):
                    b = TextView(act)
                    b.setText(text)
                    b.setTextSize(14)
                    b.setTypeface(Typeface.DEFAULT_BOLD)
                    b.setGravity(Gravity.CENTER)
                    
                    if is_primary:
                        b.setTextColor(0xFF000000) # Black text on Primary
                        b.setBackground(Styles.btn_bg(colors["primary"]))
                    else:
                        b.setTextColor(colors["primary"]) # Link color
                        b.setBackground(None)
                    
                    b.setPadding(AndroidUtilities.dp(24), AndroidUtilities.dp(10), AndroidUtilities.dp(24), AndroidUtilities.dp(10))
                    
                    def _click():
                        dialog.dismiss()
                        if cb: cb()
                    b.setOnClickListener(_OnClick(_click))
                    return b

                # Add Cancel
                if neg_txt:
                    b = mk_btn(neg_txt, False, None)
                    lp = LinearLayout.LayoutParams(-2, -2)
                    lp.rightMargin = AndroidUtilities.dp(12)
                    btns.addView(b, lp)

                # Add Confirm
                if pos_txt:
                    b = mk_btn(pos_txt, True, on_pos)
                    btns.addView(b, LinearLayout.LayoutParams(-2, -2))

                root.addView(btns)

                # 7. Show & Animate
                dialog.setContentView(root)
                # Фикс ширины через WindowManager
                lp = window.getAttributes()
                lp.width = AndroidUtilities.dp(312)
                window.setAttributes(lp)
                
                dialog.show()
                
                # Pop-up animation
                root.setScaleX(0.7)
                root.setScaleY(0.7)
                root.setAlpha(0.0)
                root.animate().alpha(1.0).scaleX(1.0).scaleY(1.0).setDuration(300).setInterpolator(OvershootInterpolator(1.2)).start()

            except Exception as e:
                log(f"Dialog Error: {e}")
                import traceback
                log(traceback.format_exc())

        run_on_ui_thread(_ui)
