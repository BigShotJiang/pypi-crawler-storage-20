import json
import os
import pickle
from enum import Enum


class FileStructureType(Enum):
    # obj_dir/prefix_idx.pkl
    SINGLE_DIR = "SINGLE_DIR"
    # obj_dir/rank_x/subdir_idx/prefix_idx.pkl
    DISTRIBUTED_RANK_SUBDIR = "DISTRIBUTED_RANK_SUBDIR"


NUM_OBJECTS_KEY = "num_objects"
NUM_BATCHES_PER_SUBDIR_KEY = "num_batches_per_subdir"
BLOB_FILENAME_PREFIX_KEY = "blob_filename_prefix"
OFFLINE_GEN_WORLD_SIZE_KEY = "world_size"


class BlobDataset:
    def __init__(self, obj_dir, metadata_file="metadata.json", obj_count=None, prefix=None):
        assert isinstance(obj_dir, list) and len(obj_dir) == 1, "obj_dir should be a list of length 1"
        self.obj_dir = obj_dir[0]
        assert os.path.exists(self.obj_dir), f"Object directory {self.obj_dir} not found"
        self.obj_count = obj_count
        self.prefix = prefix
        self.num_batches_per_subdir = None
        self.offline_gen_world_size = 1
        self.file_structure_type = FileStructureType.SINGLE_DIR
        if os.path.exists(os.path.join(self.obj_dir, metadata_file)):
            with open(os.path.join(self.obj_dir, metadata_file), "r") as f:
                self._parse_metadata(json.load(f))
        assert self.obj_count is not None

    def _parse_metadata(self, metadata):
        # hardcoded as DISTRIBUTED_RANK_SUBDIR for now if metadata exists
        self.file_structure_type = FileStructureType.DISTRIBUTED_RANK_SUBDIR
        self.obj_count = metadata.get(NUM_OBJECTS_KEY, self.obj_count)
        self.prefix = metadata.get(BLOB_FILENAME_PREFIX_KEY, self.prefix)
        self.num_batches_per_subdir = metadata.get(NUM_BATCHES_PER_SUBDIR_KEY, None)
        self.offline_gen_world_size = metadata.get(OFFLINE_GEN_WORLD_SIZE_KEY, 1)

    def __len__(self):
        return self.obj_count

    # TODO: support other file formats and paths
    def get_obj_filename(self, idx):
        prefix = self.prefix + "_" if self.prefix else ""
        if self.file_structure_type == FileStructureType.DISTRIBUTED_RANK_SUBDIR:
            rank = idx % self.offline_gen_world_size  # which offline rank this batch belongs to
            local_idx = idx // self.offline_gen_world_size  # local batch index within that rank
            subdir_idx = local_idx // self.num_batches_per_subdir if self.num_batches_per_subdir else ""
            return os.path.join(self.obj_dir, f"rank_{rank}", f"{subdir_idx}", f"{prefix}{local_idx}.pkl")
        if self.file_structure_type == FileStructureType.SINGLE_DIR:
            return os.path.join(self.obj_dir, f"{prefix}{idx}.pkl")
        raise ValueError(f"Invalid file structure type: {self.file_structure_type}")

    def __getitem__(self, idx):
        filename = self.get_obj_filename(idx)
        assert os.path.exists(filename), f"Object file {filename} not found"
        assert 0 <= idx < self.obj_count, f"Object index {idx} out of range, expected range is [0, {self.obj_count})"
        with open(filename, "rb") as f:
            return pickle.loads(f.read())

    def get_sub_lengths(self, level="file"):
        return [self.obj_count]
