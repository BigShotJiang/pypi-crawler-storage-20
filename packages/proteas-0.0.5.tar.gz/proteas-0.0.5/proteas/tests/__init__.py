"""Tests for proteas2."""
