# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_validator

"""
Enforces structural integrity across the entire CoReason ecosystem
"""

from .validator import (
    check_compliance,
    sanitize_inputs,
    validate_file,
    validate_message,
    validate_object,
    validate_tool_call,
)

__version__ = "0.2.0"
__author__ = "Gowtham A Rao"
__email__ = "gowtham.rao@coreason.ai"

__all__ = [
    "check_compliance",
    "sanitize_inputs",
    "validate_file",
    "validate_message",
    "validate_object",
    "validate_tool_call",
]
