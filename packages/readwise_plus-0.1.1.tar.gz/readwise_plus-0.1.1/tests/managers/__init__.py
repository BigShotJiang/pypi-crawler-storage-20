"""Tests for manager classes."""
