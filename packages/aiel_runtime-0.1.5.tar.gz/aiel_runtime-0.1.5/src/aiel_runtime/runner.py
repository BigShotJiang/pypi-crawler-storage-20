from __future__ import annotations
import os
import sys
import traceback
from pathlib import Path
import asyncio
import json

from .protocol import RunnerRequest, RunnerResponse
from .loader import load_snapshot
from .describe import describe
from .invoke import invoke

async def _run() -> None:
    files_root = Path(os.environ["EP_FILES_ROOT"])
    load_snapshot(files_root)

    req = RunnerRequest.model_validate_json(sys.stdin.read())

    if req.action == "describe":
        print(RunnerResponse(ok=True, result=describe()).model_dump_json())
        return

    if req.action == "invoke":
        out = await invoke(req.kind or "", req.name or "", req.payload or {})
        print(RunnerResponse(ok=True, result=out).model_dump_json())
        return

    raise ValueError("invalid action")

def main() -> None:
    try:
        asyncio.run(_run())
    except Exception as e:
        print(RunnerResponse(ok=False, error={
            "message": str(e),
            "traceback": traceback.format_exc(),
        }).model_dump_json())

def cli() -> None:
    # Convenience wrapper: `aiel-runtime < req.json`
    main()

if __name__ == "__main__":
    main()
