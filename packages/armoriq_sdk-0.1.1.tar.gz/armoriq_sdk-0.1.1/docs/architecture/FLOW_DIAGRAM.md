# ArmorIQ SDK - Visual Flow & Architecture

**Complete System Flow Visualization**

---

## 🎯 High-Level Flow

```
┌──────────────────────────────────────────────────────────────────┐
│                         USER APPLICATION                          │
│                    (Your Python Code)                             │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             │ Import & Initialize
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│                      ARMORIQ SDK v0.1.1                           │
│  ┌────────────────────────────────────────────────────────────┐  │
│  │  Client API                                                 │  │
│  │  • capture_plan()     • get_intent_token()                 │  │
│  │  • invoke()           • delegate()                          │  │
│  │  • execute_plan()     • generate_proof()                    │  │
│  └────────────────────────────────────────────────────────────┘  │
└────┬──────────────────┬─────────────────┬──────────────────┬────┘
     │                  │                 │                  │
     │ Register         │ Get Token       │ Execute          │ Discover
     │ Agent           │ (Security)      │ Action           │ MCPs
     ▼                  ▼                 ▼                  ▼
┌─────────┐      ┌──────────┐      ┌──────────┐      ┌─────────┐
│ ConMap  │      │   IAP    │      │  Proxy   │      │  MCPs   │
│  Auto   │      │ (CSRG)   │      │  Server  │      │ Various │
└─────────┘      └──────────┘      └──────────┘      └─────────┘
     │                  │                 │                  │
     │                  │                 │                  │
Production Endpoints:   │                 │                  │
• api.armoriq.io       │                 │                  │
• iap.armoriq.io ──────┘                 │                  │
• cloud-run-proxy.armoriq.io ────────────┘                  │
• <your-mcp-servers> ────────────────────────────────────────┘
```

---

## 🔄 Complete Execution Flow

### Step 1: Plan Capture

```
┌─────────────────────────────────────────────────────────────┐
│ User Code                                                     │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  with client.capture_plan() as plan:                         │
│      plan.think("Check loan eligibility")                    │
│      plan.tool_call("loan-mcp", "check", {...})              │
│                                                               │
└───────────────────────────┬─────────────────────────────────┘
                            │
                            │ Builds reasoning graph
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ Plan Object (in memory)                                       │
├─────────────────────────────────────────────────────────────┤
│ {                                                             │
│   "goal": "Check loan eligibility",                          │
│   "steps": [                                                  │
│     {                                                         │
│       "type": "think",                                        │
│       "content": "Check loan eligibility"                    │
│     },                                                        │
│     {                                                         │
│       "type": "tool_call",                                    │
│       "mcp": "loan-mcp",                                      │
│       "tool": "check",                                        │
│       "params": {...}                                         │
│     }                                                         │
│   ]                                                           │
│ }                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Step 2: Token Issuance (IAP)

```
SDK                         IAP (iap.armoriq.io)
 │                               │
 │ POST /intent                  │
 │ { plan, user_id, agent_id }   │
 ├──────────────────────────────>│
 │                               │
 │                               │ ┌─────────────────────┐
 │                               │ │ 1. Receive Plan     │
 │                               │ └─────────┬───────────┘
 │                               │           │
 │                               │ ┌─────────▼───────────┐
 │                               │ │ 2. CSRG             │
 │                               │ │    Canonicalize     │
 │                               │ │    (standardize)    │
 │                               │ └─────────┬───────────┘
 │                               │           │
 │                               │ ┌─────────▼───────────┐
 │                               │ │ 3. Build Merkle     │
 │                               │ │    Tree of steps    │
 │                               │ └─────────┬───────────┘
 │                               │           │
 │                               │ ┌─────────▼───────────┐
 │                               │ │ 4. Sign with        │
 │                               │ │    Ed25519 key      │
 │                               │ └─────────┬───────────┘
 │                               │           │
 │   Intent Token Response       │ ┌─────────▼───────────┐
 │   {                           │ │ 5. Return Token     │
 │     intent_reference: "...",  │ │    + Signature      │
 │     signature: "...",         │ └─────────────────────┘
 │     merkle_root: "...",       │           │
 │     expires_at: "..."         │           │
 │   }                           │           │
 │<──────────────────────────────┼───────────┘
 │                               │
 │ Token received! ✅            │
 │                               │
```

### Step 3: Action Execution (Proxy)

```
SDK                    Proxy                         IAP              MCP
 │                      │                            │                │
 │ POST /invoke         │                            │                │
 │ {                    │                            │                │
 │   token: "...",      │                            │                │
 │   action: {          │                            │                │
 │     mcp: "loan-mcp", │                            │                │
 │     tool: "check",   │                            │                │
 │     params: {...}    │                            │                │
 │   }                  │                            │                │
 │ }                    │                            │                │
 ├─────────────────────>│                            │                │
 │                      │                            │                │
 │                      │ ┌──────────────────────┐  │                │
 │                      │ │ 1. Receive Request   │  │                │
 │                      │ └──────────┬───────────┘  │                │
 │                      │            │              │                │
 │                      │ ┌──────────▼───────────┐  │                │
 │                      │ │ 2. Extract Token     │  │                │
 │                      │ └──────────┬───────────┘  │                │
 │                      │            │              │                │
 │                      │            │ POST /verify/action           │
 │                      │            │ { token, action }             │
 │                      │            ├──────────────>│                │
 │                      │            │              │                │
 │                      │            │              │ Verify signature│
 │                      │            │              │ Check action   │
 │                      │            │              │ matches plan   │
 │                      │            │              │                │
 │                      │            │  Valid: true │                │
 │                      │            │<──────────────┤                │
 │                      │ ┌──────────▼───────────┐  │                │
 │                      │ │ 3. Action Verified ✅ │  │                │
 │                      │ └──────────┬───────────┘  │                │
 │                      │            │              │                │
 │                      │ ┌──────────▼───────────┐  │                │
 │                      │ │ 4. Route to MCP      │  │                │
 │                      │ └──────────┬───────────┘  │                │
 │                      │            │              │                │
 │                      │            │ POST /tools/check             │
 │                      │            │ { params: {...} }             │
 │                      │            ├──────────────┼───────────────>│
 │                      │            │              │                │
 │                      │            │              │  Execute logic │
 │                      │            │              │  (check loan)  │
 │                      │            │              │                │
 │                      │            │   Result: {...}               │
 │                      │            │<──────────────┼────────────────┤
 │                      │ ┌──────────▼───────────┐  │                │
 │                      │ │ 5. Add to Audit Log  │  │                │
 │                      │ └──────────┬───────────┘  │                │
 │                      │            │              │                │
 │   Response: {        │            │              │                │
 │     status: "ok",    │            │              │                │
 │     result: {...},   │            │              │                │
 │     audit_id: "..."  │            │              │                │
 │   }                  │            │              │                │
 │<─────────────────────┼────────────┘              │                │
 │                      │                            │                │
 │ Action completed! ✅ │                            │                │
 │                      │                            │                │
```

---

## 🤝 Agent-to-Agent Delegation Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                      Primary Agent (Finance Agent)               │
│                          user: "alice"                           │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             │ 1. Create delegation
                             │    to_agent: "risk-agent"
                             │    capabilities: ["calculate_risk"]
                             │    expires: 3600 seconds
                             ▼
                    ┌────────────────────┐
                    │       IAP          │
                    │  POST /delegation/ │
                    │       create       │
                    └────────┬───────────┘
                             │
                             │ Returns delegation token
                             │ with capabilities + expiry
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                  Delegation Token (Cryptographically Signed)     │
├─────────────────────────────────────────────────────────────────┤
│ {                                                                │
│   "from_agent": "finance-agent",                                │
│   "to_agent": "risk-agent",                                     │
│   "user": "alice",                                              │
│   "capabilities": ["calculate_risk"],                           │
│   "expires_at": "2026-01-16T15:35:00Z",                        │
│   "delegation_chain": ["finance-agent"],                        │
│   "signature": "..."                                            │
│ }                                                                │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             │ Pass to sub-agent
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                Secondary Agent (Risk Agent)                      │
│                   uses delegation_token                          │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             │ 2. Risk agent acts with
                             │    delegated authority
                             ▼
                         ┌───────┐
                         │  IAP  │ Verifies:
                         │       │ ✅ Signature valid
                         │       │ ✅ Not expired
                         │       │ ✅ Capability matches
                         │       │ ✅ Chain intact
                         └───┬───┘
                             │
                             │ Token validated ✅
                             ▼
                         ┌───────┐
                         │ Proxy │ Routes action
                         │       │ with full audit trail
                         └───┬───┘
                             │
                             ▼
                        ┌─────────┐
                        │ Risk MCP│ Executes
                        │         │ calculate_risk
                        └─────────┘

AUDIT TRAIL SHOWS:
├─ Original user: "alice"
├─ Primary agent: "finance-agent"
├─ Delegated to: "risk-agent"
├─ Action: "calculate_risk"
├─ Authority chain: alice → finance-agent → risk-agent
└─ Complete traceability ✅
```

---

## 🌐 Multi-MCP Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│                         Travel Planning Agent                    │
└─────────────────┬───────────────────────────────────────────────┘
                  │
                  │ Creates complex plan with multiple MCPs
                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                          Plan Object                             │
├─────────────────────────────────────────────────────────────────┤
│ Step 1: Flight Search      → flight-mcp.search()                │
│ Step 2: Hotel Search       → hotel-mcp.search()                 │
│ Step 3: Calculate Budget   → finance-mcp.calculate()            │
│ Step 4: Book Flight        → flight-mcp.book()                  │
│ Step 5: Book Hotel         → hotel-mcp.book()                   │
│ Step 6: Process Payment    → payment-mcp.charge()               │
│ Step 7: Send Confirmation  → notification-mcp.send()            │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             │ Get single token for entire plan
                             ▼
                    ┌────────────────┐
                    │      IAP       │ Issues ONE token
                    │                │ for ALL steps
                    └────────┬───────┘
                             │
                             │ Token covers entire workflow
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                            Proxy                                 │
│                  (Routes to different MCPs)                      │
└──┬────────┬────────┬────────┬────────┬────────┬────────┬───────┘
   │        │        │        │        │        │        │
   │ Step 1 │ Step 2 │ Step 3 │ Step 4 │ Step 5 │ Step 6 │ Step 7
   ▼        ▼        ▼        ▼        ▼        ▼        ▼
┌────┐  ┌────┐  ┌────┐  ┌────┐  ┌────┐  ┌────┐  ┌────┐
│Flgt│  │Hotl│  │Finn│  │Flgt│  │Hotl│  │Paym│  │Notf│
│MCP │  │MCP │  │MCP │  │MCP │  │MCP │  │MCP │  │MCP │
└────┘  └────┘  └────┘  └────┘  └────┘  └────┘  └────┘

Each MCP verifies token with IAP before executing ✅
Complete audit trail maintained across all MCPs ✅
```

---

## 🔐 Security & Verification Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                        Security Layers                           │
└─────────────────────────────────────────────────────────────────┘

Layer 1: CSRG Canonicalization
┌─────────────────────────────────────────────────────────────────┐
│  Original Plan → Canonical Form                                  │
│  ┌────────────┐      ┌────────────┐                            │
│  │ User Input │ ───> │ Normalized │                            │
│  │ (varies)   │      │ (standard) │                            │
│  └────────────┘      └────────────┘                            │
│  • Removes whitespace                                           │
│  • Standardizes JSON keys                                       │
│  • Sorts arrays deterministically                               │
│  • Same input = same canonical form                             │
└─────────────────────────────────────────────────────────────────┘

Layer 2: Merkle Tree
┌─────────────────────────────────────────────────────────────────┐
│              Merkle Root (single hash)                           │
│                       │                                          │
│           ┌───────────┴───────────┐                             │
│           │                       │                             │
│      Hash(1+2)                Hash(3+4)                         │
│           │                       │                             │
│      ┌────┴────┐            ┌────┴────┐                        │
│      │         │            │         │                        │
│  Hash(1)   Hash(2)      Hash(3)   Hash(4)                      │
│      │         │            │         │                        │
│   Step 1    Step 2       Step 3    Step 4                      │
│                                                                  │
│  • Each step hashed                                             │
│  • Paired hashes combined                                       │
│  • Root proves all steps                                        │
│  • Can prove individual step with path                          │
└─────────────────────────────────────────────────────────────────┘

Layer 3: Ed25519 Signature
┌─────────────────────────────────────────────────────────────────┐
│  Signature = Sign(Merkle_Root + Metadata, Private_Key)          │
│                                                                  │
│  ┌──────────────┐      ┌──────────────┐                        │
│  │ Merkle Root  │      │  Private Key │                        │
│  │ + User ID    │  +   │    (IAP)     │  = Signature           │
│  │ + Timestamp  │      │              │                        │
│  └──────────────┘      └──────────────┘                        │
│                                                                  │
│  Anyone can verify with:                                        │
│  Verify(Signature, Merkle_Root, Public_Key) → true/false       │
│                                                                  │
│  • Unforgeable (can't create without private key)              │
│  • Non-repudiable (IAP can't deny signing)                     │
│  • Tamper-proof (any change invalidates signature)             │
└─────────────────────────────────────────────────────────────────┘

Layer 4: Action Verification
┌─────────────────────────────────────────────────────────────────┐
│  When action executed:                                           │
│                                                                  │
│  1. Extract action from request                                 │
│  2. Hash the action                                             │
│  3. Find hash in Merkle tree                                    │
│  4. Verify Merkle path to root                                  │
│  5. Verify signature on root                                    │
│                                                                  │
│  ✅ Action matches plan                                         │
│  ✅ Plan was properly signed                                    │
│  ✅ Token not expired                                           │
│  ✅ Signature valid                                             │
│                                                                  │
│  → Action APPROVED                                              │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📊 Complete Data Flow

```
┌──────────────────────────────────────────────────────────────────┐
│                    USER APPLICATION                               │
│                                                                   │
│  loan_agent = ArmorIQClient(                                     │
│      user_id="alice@company.com",                                │
│      agent_id="loan-processor"                                   │
│  )                                                                │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│                      SDK INITIALIZATION                           │
│                                                                   │
│  1. Load production endpoints:                                   │
│     • IAP: https://iap.armoriq.io                               │
│     • Proxy: https://cloud-run-proxy.armoriq.io                 │
│     • ConMap: https://api.armoriq.io                            │
│                                                                   │
│  2. Register with ConMap (optional):                             │
│     POST /agents/register                                        │
│     { agent_id, capabilities, endpoint }                         │
│                                                                   │
│  3. Initialize HTTP client with:                                 │
│     • Retry logic                                                │
│     • Timeout settings                                           │
│     • Error handling                                             │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│                      PLAN CAPTURE                                 │
│                                                                   │
│  with loan_agent.capture_plan() as plan:                         │
│      plan.think("Check customer eligibility")                    │
│      plan.tool_call("credit-mcp", "check_score", {...})          │
│      plan.tool_call("loan-mcp", "calculate_rate", {...})         │
│                                                                   │
│  Builds in-memory graph:                                         │
│  PlanCapture {                                                   │
│    goal: "Check customer eligibility"                            │
│    steps: [ThinkStep, ToolCallStep, ToolCallStep]                │
│    observations: {}                                              │
│  }                                                                │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│                    GET INTENT TOKEN                               │
│                                                                   │
│  token = loan_agent.get_intent_token()                           │
│                                                                   │
│  SDK → IAP:                                                      │
│  POST https://iap.armoriq.io/intent                              │
│  {                                                                │
│    "plan": { /* canonical plan */ },                             │
│    "policy": { /* access rules */ },                             │
│    "identity": {                                                 │
│      "user_id": "alice@company.com",                             │
│      "agent_id": "loan-processor"                                │
│    }                                                              │
│  }                                                                │
│                                                                   │
│  IAP → SDK:                                                      │
│  {                                                                │
│    "intent_reference": "csrg_...",                               │
│    "signature": "base64_ed25519_sig",                            │
│    "merkle_root": "...",                                         │
│    "expires_at": "2026-01-16T15:35:00Z"                         │
│  }                                                                │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│                    EXECUTE ACTION                                 │
│                                                                   │
│  result = loan_agent.invoke(                                     │
│      "credit-mcp",                                               │
│      "check_score",                                              │
│      {"customer_id": "CUST_001"}                                 │
│  )                                                                │
│                                                                   │
│  SDK → Proxy:                                                    │
│  POST https://cloud-run-proxy.armoriq.io/invoke                  │
│  {                                                                │
│    "token": "csrg_...",                                          │
│    "action": {                                                   │
│      "mcp": "credit-mcp",                                        │
│      "tool": "check_score",                                      │
│      "params": {"customer_id": "CUST_001"}                       │
│    }                                                              │
│  }                                                                │
│                                                                   │
│  Proxy verifies with IAP → Routes to MCP → Returns result        │
│                                                                   │
│  Result: {                                                       │
│    "status": "success",                                          │
│    "data": { "score": 720, "risk": "low" },                     │
│    "audit_id": "audit_123",                                      │
│    "execution_time_ms": 145                                      │
│  }                                                                │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│                      AUDIT TRAIL                                  │
│                                                                   │
│  Immutable log stored in IAP:                                    │
│  {                                                                │
│    "timestamp": "2026-01-16T14:35:12Z",                          │
│    "user_id": "alice@company.com",                               │
│    "agent_id": "loan-processor",                                 │
│    "intent_reference": "csrg_...",                               │
│    "action": "credit-mcp.check_score",                           │
│    "params_hash": "sha256_...",                                  │
│    "result_hash": "sha256_...",                                  │
│    "merkle_proof": [...],                                        │
│    "signature_verified": true,                                   │
│    "execution_time_ms": 145                                      │
│  }                                                                │
│                                                                   │
│  Queryable for compliance & debugging ✅                         │
└──────────────────────────────────────────────────────────────────┘
```

---

## 🎯 Key Features Highlighted

### 1. Automatic Everything
- ✅ Security (Ed25519 + CSRG)
- ✅ Routing (Proxy finds MCP)
- ✅ Verification (IAP validates)
- ✅ Audit (Logs everything)

### 2. Developer Friendly
- ✅ 3 lines to get started
- ✅ Production defaults
- ✅ Type-safe APIs
- ✅ Comprehensive errors

### 3. Enterprise Ready
- ✅ Cryptographic proofs
- ✅ Compliance logging
- ✅ Policy enforcement
- ✅ Multi-tenancy

### 4. Collaborative
- ✅ Agent delegation
- ✅ Authority chains
- ✅ Capability scoping
- ✅ Revocation

---

**ArmorIQ SDK v0.1.1** - Visual Architecture Guide  
**January 16, 2026**
