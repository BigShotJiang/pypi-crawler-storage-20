from __future__ import annotations

from typing import Any


class AttrDict(dict):
    """Turn a dict into an object with attributes.

    If non-existing attributes are accessed for reading, `None` is returned.

    See these links on stackoverflow:

    *   [1](https://stackoverflow.com/questions/4984647/accessing-dict-keys-like-an-attribute)
    *   [2](https://stackoverflow.com/questions/16237659/python-how-to-implement-getattr)
        especially the remark that

        > `__getattr__` is only used for missing attribute lookup

    We also need to define the `__missing__` method in case we access the underlying
    dict by means of keys, like `xxx["yyy"]` rather then by attribute like `xxx.yyy`.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """Create the data structure from incoming data."""
        super(AttrDict, self).__init__(*args, **kwargs)
        self.__dict__ = self

    def __missing__(self, key: str, *args: Any, **kwargs: Any) -> None:
        """Provide a default when retrieving a non-existent member.

        This method is used when using the `.key` notation for accessing members.
        """
        return None

    def __getattr__(self, key: str, *args: Any, **kwargs: Any) -> None:
        """Provide a default when retrieving a non-existent member.

        This method is used when using the `[key]` notation for accessing members.
        """
        return None

    def deepdict(self) -> dict[str, Any]:
        return deepdict(self)


def deepdict(info: Any, ordinary: bool = False) -> Any:
    """Turns an `AttrDict` into a `dict`, recursively.

    Parameters
    ----------
    info: any
        The input dictionary. We assume that it is a data structure built by
        `tuple`, `list`, `set`, `frozenset`, `dict` and atomic types such as
        `int`, `str`, `bool`.
        We assume there are no user defined objects in it, and no generators
        and functions.
    ordinary: boolean, optional False
        If True, no frozensets and tuples are constructed, but sets and lists
        instead.

    Returns
    -------
    dict
        A dictionary containing the same info as the input dictionary, but where
        each value of type `AttrDict` is turned into a `dict`.
    """
    tp = type(info)

    return (
        dict({k: deepdict(v, ordinary=ordinary) for (k, v) in info.items()})
        if tp in {dict, AttrDict}
        else (
            (list if ordinary else tuple)(
                deepdict(item, ordinary=ordinary) for item in info
            )
            if tp is tuple
            else (
                (set if ordinary else frozenset)(
                    deepdict(item, ordinary=ordinary) for item in info
                )
                if tp is frozenset
                else (
                    [deepdict(item, ordinary=ordinary) for item in info]
                    if tp is list
                    else (
                        {deepdict(item, ordinary=ordinary) for item in info}
                        if tp is set
                        else info
                    )
                )
            )
        )
    )


def deepAttrDict(info: Any, preferTuples: bool = False) -> Any:
    """Turn a `dict` into an `AttrDict`, recursively.

    Parameters
    ----------
    info: any
        The input dictionary. We assume that it is a data structure built by
        `tuple`, `list`, `set`, `frozenset`, `dict` and atomic types such as
        `int`, `str`, `bool`.
        We assume there are no user defined objects in it, and no generators
        and functions.
    preferTuples: boolean, optional False
        Lists are converted to tuples.

    Returns
    -------
    AttrDict
        An `AttrDict` containing the same info as the input dictionary, but where
        each value of type `dict` is turned into an `AttrDict`.
    """
    tp = type(info)

    return (
        AttrDict(
            {k: deepAttrDict(v, preferTuples=preferTuples) for (k, v) in info.items()}
        )
        if tp in {dict, AttrDict}
        else (
            tuple(deepAttrDict(item, preferTuples=preferTuples) for item in info)
            if tp is tuple or (tp is list and preferTuples)
            else (
                frozenset(
                    deepAttrDict(item, preferTuples=preferTuples) for item in info
                )
                if tp is frozenset
                else (
                    [deepAttrDict(item, preferTuples=preferTuples) for item in info]
                    if tp is list
                    else (
                        {deepAttrDict(item, preferTuples=preferTuples) for item in info}
                        if tp is set
                        else info
                    )
                )
            )
        )
    )


def isIterable(value: Any) -> bool:
    """Whether a value is a non-string iterable.

    !!! note
        Strings are iterables.
        But for this purpose we regard strings as non-iterable scalars.
    """

    return type(value) is not str and hasattr(value, "__iter__")
