class SpecError(Exception):
    pass
