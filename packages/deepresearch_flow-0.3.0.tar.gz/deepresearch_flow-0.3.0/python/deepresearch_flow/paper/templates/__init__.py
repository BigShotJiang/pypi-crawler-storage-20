"""Built-in Markdown templates."""
