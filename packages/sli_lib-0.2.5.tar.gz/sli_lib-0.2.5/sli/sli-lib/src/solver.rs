//! Traits for solvers.
//! These traits are meant to be usable as [trait objects](https://doc.rust-lang.org/reference/items/traits.html#object-safety).
use sli_collections::rc::Rc;
use std::fmt::Display;
use std::marker::PhantomData;
use std::ops::{Deref, DerefMut};

use crate::fodot::collections::set::Set;
use crate::fodot::error::{GetRangeError, OptimizeError};
use crate::fodot::fmt::{FodotDisplay, FodotOptions, FormatOptions, simple_fodot_display};
use crate::fodot::structure::{ArgsRef, GlobModel, IntoIterCompleteModel, Model, PartialStructure};
use crate::fodot::theory::{Inferenceable, Theory};
use crate::fodot::vocabulary::{Int, PfuncRc, Real};
use comp_core::solver::Solver as CCSolver;
pub use comp_core::solver::{InterpMethod, MeasurementEnder, SatResult, TimeMeasurements, Timings};

/// The result from a [Solver::get_model] call.
#[allow(clippy::large_enum_variant)]
pub enum ModelResult {
    /// The theory has a model, and as such is satisfiable.
    Sat(GlobModel),
    /// The theory has no model, and as such is unsatsifiable.
    Unsat,
    /// The solver tried its best, but couldn't succeed :(.
    Unknown,
}

/// A Owning reference to constraints.
///
/// Used in [GlobModel] and [Model.
#[derive(Clone)]
pub struct Constraints {
    #[allow(unused)]
    theory: Rc<Theory>,
}

#[derive(Clone, Debug)]
pub enum OptimizeRes {
    Int(Int),
    Real(Real),
}

impl FodotOptions for OptimizeRes {
    type Options<'a> = FormatOptions;
}

impl FodotDisplay for OptimizeRes {
    fn fmt(
        fmt: crate::fodot::fmt::Fmt<&Self, Self::Options<'_>>,
        f: &mut std::fmt::Formatter<'_>,
    ) -> std::fmt::Result {
        match fmt.value {
            Self::Int(value) => Display::fmt(&value, f),
            Self::Real(value) => Display::fmt(&value, f),
        }
    }
}

impl Display for OptimizeRes {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        Display::fmt(&self.display(), f)
    }
}

pub use comp_core::solver::{OptimizeOp, UnorderedCodomainError};

simple_fodot_display!(UnorderedCodomainError);

/// All methods a SLI solver has available for use.
pub trait Solver<'a> {
    /// Initialize a solver with the given [Inferenceable].
    ///
    /// See [Solver::initialize_with] and [Solver::initialize_with_timing] for more options.
    fn initialize(inferenceable: &'a Inferenceable) -> Self
    where
        Self: Sized,
    {
        Self::initialize_with(inferenceable, Default::default())
    }

    /// Initialize the solver with the given [InterpMethod].
    fn initialize_with(inferenceable: &'a Inferenceable, interp_method: InterpMethod) -> Self
    where
        Self: Sized,
    {
        Self::initialize_with_timing(inferenceable, interp_method, &mut ())
    }

    /// Initialize the solver with an [InterpMethod] and a [Timings] object to measure internal
    /// timings.
    fn initialize_with_timing(
        inferenceable: &'a Inferenceable,
        interp_method: InterpMethod,
        timings: &mut dyn Timings,
    ) -> Self
    where
        Self: Sized;

    /// Get the current constraints.
    fn get_constraints(&self) -> Constraints;

    /// Check if the current solver state is satisfiable.
    fn check(&mut self) -> SatResult;

    /// Check satifiability for the current solver state and get the model if it is satisfiable.
    fn check_get_model(&mut self) -> ModelResult {
        match self.check() {
            SatResult::Sat => ModelResult::Sat(self.get_model().expect("Internal Error")),
            SatResult::Unsat => ModelResult::Unsat,
            SatResult::Unknown => ModelResult::Unknown,
        }
    }

    /// Get a model of the current solver state if possible.
    fn get_model(&mut self) -> Option<GlobModel>;
    /// Invalidate the model of the current solver state.
    fn next_model(&mut self);

    /// Returns the assignments that are true in any model of the current state of the solver minus
    /// the solvers initial assignments.
    fn propagate_diff(&mut self) -> Option<PartialStructure>;

    /// Returns the assignments that are true in any model of the current state of the solver.
    fn propagate(&mut self) -> Option<PartialStructure>;

    /// Returns the certainly falses of the [Pfunc](crate::fodot::vocabulary::Pfunc)
    /// with the given [Args](crate::fodot::structure::Args).
    ///
    /// Returns [None] if the solver is in an unsatisfiable state.
    fn get_range(&mut self, pfunc: PfuncRc, args: ArgsRef) -> Result<Option<Set>, GetRangeError>;

    fn inferenceable(&self) -> &Inferenceable;

    /// Approximate optimization of a term.
    ///
    /// This returns [UnorderedCodomainError] if the given [PfuncRc] does not have an ordered
    /// codomain.
    /// Otherwise it returns [OptimizeRes] if the theory is satisfiable, [None] otherwise.
    /// If [OptimizeRes] is returned the state of the solver is altered such that subsequent models
    /// must contain the found optimized value.
    ///
    /// The difference between this method and [Self::exact_optimize] is that for optimizations
    /// that exist but are not in the pfuncs codomain this function returns an approximate value,
    /// while [Self::exact_optimize] returns [None] and turns the solver state into unsat.
    ///
    /// For example when minimizing the term `p()` with `p: -> Real` and a theory `p() > 5`, approximate
    /// optimization would return some number smaller than 5. Exact optimization would produce
    /// [None]. The same is true for unbounded optimizations.
    fn approx_optimize(
        &mut self,
        pfunc: PfuncRc,
        args: ArgsRef<'_>,
        op: OptimizeOp,
    ) -> Result<Option<OptimizeRes>, OptimizeError>;

    /// Exact optimization of a term.
    ///
    /// Returns [None] if unsatisfiable or if the optimized value doesn't exist in the term's codomain.
    ///
    /// See [Self::approx_optimize] for more info.
    fn exact_optimize(
        &mut self,
        pfunc: PfuncRc,
        args: ArgsRef<'_>,
        op: OptimizeOp,
    ) -> Result<Option<OptimizeRes>, OptimizeError>;
}

pub trait SolverIter<'a>: Solver<'a> {
    /// Returns an iterator for iterating over the models generated by the solver.
    /// Use [take](std::iter::Iterator::take) for limiting the amount of models.
    fn iter_models(&mut self) -> ModelIterator<'_, 'a, Self> {
        ModelIterator::new(self)
    }
}

impl<'a, T> SolverIter<'a> for T where T: Solver<'a> {}

/// An [Iterator] over [GlobModel]s from a solver.
pub struct ModelIterator<'a, 't, T: Solver<'t> + ?Sized>
where
    't: 'a,
{
    solver: &'a mut T,
    phantom_data: PhantomData<&'t ()>,
}

impl<'a, 't, T: Solver<'t> + ?Sized> ModelIterator<'a, 't, T>
where
    't: 'a,
{
    pub fn new(solver: &'a mut T) -> Self {
        Self {
            solver,
            phantom_data: PhantomData,
        }
    }

    pub fn complete_with_infinite(self) -> CompleteModelIterator<'a, 't, T> {
        CompleteModelIterator::new(self).disable_skip_infinite()
    }

    pub fn complete(self) -> CompleteModelIterator<'a, 't, T> {
        CompleteModelIterator::new(self)
    }
}

impl<'t, T: Solver<'t> + ?Sized> Iterator for ModelIterator<'_, 't, T> {
    type Item = GlobModel;

    fn next(&mut self) -> Option<Self::Item> {
        match self.solver.check_get_model() {
            ModelResult::Sat(model) => {
                self.solver.next_model();
                Some(model)
            }
            _ => None,
        }
    }
}

/// Wraps [ModelIterator] to iterate over [Model]s.
///
/// For each [GlobModel] [ModelIterator] returns this iterator returns all [Model]s in this
/// [GlobModel].
pub struct CompleteModelIterator<'a, 't, T: Solver<'t> + ?Sized> {
    model_iter: ModelIterator<'a, 't, T>,
    cur_glob_model_iter: Option<IntoIterCompleteModel>,
    skip_infinite: bool,
}

impl<'a, 't, T: Solver<'t> + ?Sized> CompleteModelIterator<'a, 't, T> {
    fn new(model_iter: ModelIterator<'a, 't, T>) -> Self {
        Self {
            model_iter,
            cur_glob_model_iter: None,
            skip_infinite: false,
        }
    }

    /// Disables iteration over infinite values.
    pub fn enable_skip_infinite(mut self) -> Self {
        self.skip_infinite = true;
        self
    }

    /// Disables iteration over infinite values in place.
    pub fn mut_enable_skip_infinite(&mut self) {
        self.skip_infinite = true;
    }

    /// Enables iteration over infinite values.
    pub fn disable_skip_infinite(mut self) -> Self {
        self.skip_infinite = false;
        self
    }

    /// Disables iteration over infinite values in place.
    pub fn mut_disable_skip_infinite(&mut self) {
        self.skip_infinite = false;
    }

    /// Disable iteration over infinite values if `value` is true.
    /// Disables it otherwise.
    pub fn skip_infinite(self, value: bool) -> Self {
        if value {
            self.enable_skip_infinite()
        } else {
            self.disable_skip_infinite()
        }
    }

    /// Disable iteration over infinite values if `value` is true.
    /// Disables it otherwise. Does this in place.
    pub fn mut_skip_infinite(&mut self, value: bool) {
        if value {
            self.mut_enable_skip_infinite()
        } else {
            self.mut_disable_skip_infinite()
        }
    }
}

impl<'t, T: Solver<'t> + ?Sized> Iterator for CompleteModelIterator<'_, 't, T> {
    type Item = Model;

    fn next(&mut self) -> Option<Self::Item> {
        loop {
            if let Some(value) = &mut self.cur_glob_model_iter {
                if let Some(value) = value.next() {
                    return Some(value);
                }
            }
            match self.model_iter.next() {
                Some(value) => {
                    let iter = value.into_iter_models();
                    self.cur_glob_model_iter = Some(iter.skip_infinite(self.skip_infinite));
                }
                None => return None,
            }
        }
    }
}

pub mod wrapper {
    use crate::fodot::{self, TryIntoCtx, error::DomainMismatch, structure::DomainFullRc};
    use comp_core::node::{BoolElement, ElementNode, NodeEnum};
    use itertools::Either;

    use super::*;
    pub struct CCWrapper<'a, T> {
        solver: T,
        inferenceable: &'a Inferenceable,
    }

    impl<T> Deref for CCWrapper<'_, T> {
        type Target = T;

        fn deref(&self) -> &Self::Target {
            &self.solver
        }
    }

    impl<T> DerefMut for CCWrapper<'_, T> {
        fn deref_mut(&mut self) -> &mut Self::Target {
            &mut self.solver
        }
    }

    impl<'a, T: CCSolver<'a>> CCWrapper<'a, T> {
        pub fn has_been_simplified(&self, nth_assertion: usize) -> Option<bool> {
            let transformed_senctence = self
                .solver
                .constraints()
                .formulas_iter()
                .nth(nth_assertion)?;
            match transformed_senctence.first_node_enum() {
                NodeEnum::Element(ElementNode::Bool(BoolElement { value })) => Some(value),
                _ => None,
            }
        }
    }

    impl<'a, T: CCSolver<'a>> Solver<'a> for CCWrapper<'a, T> {
        fn initialize_with_timing(
            inferenceable: &'a Inferenceable,
            interp_method: InterpMethod,
            timings: &mut dyn Timings,
        ) -> Self
        where
            Self: Sized,
        {
            CCWrapper {
                solver: T::initialize_with_timing(
                    inferenceable.lower().unwrap().into(),
                    &inferenceable.structure().cc_struct,
                    interp_method,
                    timings,
                ),
                inferenceable,
            }
        }

        fn check(&mut self) -> SatResult {
            self.solver.check()
        }

        fn get_constraints(&self) -> Constraints {
            Constraints {
                theory: Rc::clone(self.inferenceable.theory_rc()),
            }
        }

        fn get_model(&mut self) -> Option<GlobModel> {
            self.solver.get_model().map(|f| GlobModel {
                constraints: self.get_constraints(),
                structure: PartialStructure {
                    type_interps: self.inferenceable.type_interps_rc().clone(),
                    cc_struct: f.into(),
                },
            })
        }

        fn next_model(&mut self) {
            self.solver.next_model()
        }

        fn propagate_diff(&mut self) -> Option<PartialStructure> {
            self.solver.propagate_diff().map(|f| PartialStructure {
                type_interps: Rc::clone(self.inferenceable.type_interps_rc()),
                cc_struct: f,
            })
        }

        fn propagate(&mut self) -> Option<PartialStructure> {
            self.solver.propagate().map(|f| PartialStructure {
                type_interps: Rc::clone(self.inferenceable.type_interps_rc()),
                cc_struct: f,
            })
        }

        fn get_range(
            &mut self,
            pfunc: PfuncRc,
            args: ArgsRef,
        ) -> Result<Option<Set>, fodot::error::GetRangeError> {
            let domain_full: DomainFullRc = pfunc
                .domain()
                .with_interps(self.inferenceable().type_interps_rc().clone())?;
            let args: ArgsRef = args.try_into_ctx((&domain_full).into())?;
            if pfunc.domain() != args.domain().as_domain() {
                return Err(DomainMismatch {
                    expected: pfunc.domain().into(),
                    found: args.domain().as_domain().into(),
                }
                .into());
            }

            self.solver
                .get_range(pfunc.to_cc(), args.domain_enum)
                .map(|f| {
                    f.map(|f| Set {
                        backing: f,
                        domain: DomainFullRc::new(
                            &[pfunc.codomain_rc()],
                            self.inferenceable.type_interps_rc().clone(),
                        )
                        .unwrap(),
                    })
                })
                .map_err(|_| fodot::error::InfiniteCodomainError.into())
        }

        fn inferenceable(&self) -> &Inferenceable {
            self.inferenceable
        }

        fn approx_optimize(
            &mut self,
            pfunc: PfuncRc,
            args: ArgsRef<'_>,
            op: OptimizeOp,
        ) -> Result<Option<OptimizeRes>, OptimizeError> {
            let domain_full: DomainFullRc = pfunc
                .domain()
                .with_interps(self.inferenceable().type_interps_rc().clone())?;
            let args: ArgsRef = args.try_into_ctx((&domain_full).into())?;
            if pfunc.domain() != args.domain().as_domain() {
                return Err(DomainMismatch {
                    expected: pfunc.domain().into(),
                    found: args.domain().as_domain().into(),
                }
                .into());
            }
            Ok(self
                .solver
                .approx_optimize(pfunc.to_cc(), args.domain_enum, op)
                .map(|f| {
                    f.map(|value| match value {
                        Either::Left(value) => OptimizeRes::Int(value),
                        Either::Right(value) => OptimizeRes::Real(value),
                    })
                })?)
        }

        fn exact_optimize(
            &mut self,
            pfunc: PfuncRc,
            args: ArgsRef<'_>,
            op: OptimizeOp,
        ) -> Result<Option<OptimizeRes>, OptimizeError> {
            let domain_full: DomainFullRc = pfunc
                .domain()
                .with_interps(self.inferenceable().type_interps_rc().clone())?;
            let args: ArgsRef = args.try_into_ctx((&domain_full).into())?;
            if pfunc.domain() != args.domain().as_domain() {
                return Err(DomainMismatch {
                    expected: pfunc.domain().into(),
                    found: args.domain().as_domain().into(),
                }
                .into());
            }
            Ok(self
                .solver
                .exact_optimize(pfunc.to_cc(), args.domain_enum, op)
                .map(|f| {
                    f.map(|value| match value {
                        Either::Left(value) => OptimizeRes::Int(value),
                        Either::Right(value) => OptimizeRes::Real(value),
                    })
                })?)
        }
    }
}

pub type Z3Solver<'a> = wrapper::CCWrapper<'a, comp_core::solver::z3::Z3Solver<'a>>;

#[cfg(test)]
mod tests {
    use comp_core::solver::OptimizeOp;

    use crate::fodot::{structure::ArgsRef, theory::Inferenceable, vocabulary::Vocabulary};

    use super::{Solver, Z3Solver};

    #[test]
    fn z3_optimization() {
        let inf = Inferenceable::from_specification(
            "
        vocabulary {
            d: -> Real
        }
        theory {
            d() < 5.
        }
        structure {}
        ",
        )
        .unwrap();
        let d = Vocabulary::parse_pfunc_rc(inf.vocab_rc(), "d").unwrap();
        let d_domain = inf.structure().get((&d).into()).domain_full();
        let mut solver = Z3Solver::initialize(&inf);
        assert!(
            solver
                .approx_optimize(
                    d.clone(),
                    ArgsRef::empty(d_domain.clone()).unwrap(),
                    OptimizeOp::Maximize
                )
                .unwrap()
                .is_some()
        );
        let mut solver = Z3Solver::initialize(&inf);
        assert!(
            solver
                .exact_optimize(d, ArgsRef::empty(d_domain).unwrap(), OptimizeOp::Maximize)
                .unwrap()
                .is_none()
        );
    }
}
