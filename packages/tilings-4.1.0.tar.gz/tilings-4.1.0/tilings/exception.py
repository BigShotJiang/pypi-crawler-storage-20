class InvalidOperationError(Exception):
    pass
