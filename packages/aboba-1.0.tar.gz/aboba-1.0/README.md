# ABOBA

AB tests library with simplicity in mind

## 📚 Documentation

- **[Full Documentation](https://ab-alexroar-8e192a9a66171262804e0b0f9c942db31bc9c224aebd3d3d415.gitlab.io)** - Complete guide and reference
- **[Tutorial](https://ab-alexroar-8e192a9a66171262804e0b0f9c942db31bc9c224aebd3d3d415.gitlab.io/tutorial/)** - Step-by-step learning guide
- **[API Reference](https://ab-alexroar-8e192a9a66171262804e0b0f9c942db31bc9c224aebd3d3d415.gitlab.io/api/tests/)** - Detailed API documentation

## ✨ Features

- **Simple & Intuitive API** - Easy to learn and use for both beginners and experts
- **Multiple Statistical Tests** - t-tests, ANOVA, Kruskal-Wallis, and more
- **Variance Reduction** - Built-in CUPED, stratification, and regression adjustments
- **Power Analysis** - Simulate synthetic effects to estimate required sample sizes
- **Flexible Pipelines** - Chain data processors and samplers for complex workflows
- **Experiment Orchestration** - Run and visualize multiple test scenarios simultaneously
- **Extensible Architecture** - Easy to create custom tests, samplers, and processors
- **Production Ready** - Type hints, comprehensive tests, and detailed documentation

## 🚀 Quick Start

### Installation

```bash
pip install aboba
```

## 📖 Quick Example

To conduct a test, you need several entities:

- data
- data processing
- data sampling technique
- the test strategy itself

Data can be a simple pandas dataframe or custom data generator. 

### General use case

```python
import numpy as np
import pandas as pd
import scipy.stats as sps

from aboba import (
    tests,
    samplers,
    effect_modifiers,
    experiment
)

# dataset of two columns: value and group
data = pd.DataFrame({
    'value'  : np.concatenate([
        sps.norm.rvs(size=1000, loc=0, scale=1),
        sps.norm.rvs(size=1000, loc=0, scale=1),
    ]),
    'b_group': np.concatenate([
        np.repeat(0, 1000),
        np.repeat(1, 1000),
    ]),
})

# test choice
test = tests.AbsoluteIndependentTTest(
    preprocess=None,
    data_sampler=samplers.GroupSampler(
        column='b_group',
        size=100,
    ),
    value_column='value',
)

# data sampler fit
test = test.fit(data)

n_iter = 500
with experiment.AbobaExperiment(draw_cols=1) as experiment:
    with experiment.group("AA, regular") as group:
        group.run(test, n_iter=n_iter)

    effect = effect_modifiers.GroupModifier(
        effects={
            1: 0.3
        },
        value_column='value',
        group_column='b_group',
    )

    with experiment.group("AB, regular, effect=0.3") as group:
        group.run(test, synthetic_effect=effect, n_iter=n_iter)

    with experiment.group("AB, regular, effect=1") as group:
        group.run(
            test,
            synthetic_effect=effect.set(
                "effects", {
                    1: 1.0
                }
            ),
            n_iter=n_iter
        )
```

## 🎯 Key Components

- **Tests** - Statistical tests for hypothesis testing (t-tests, ANOVA, etc.)
- **Samplers** - Control how data is split into groups (random, stratified, grouped)
- **Processors** - Transform data before testing (CUPED, bucketing, normalization)
- **Pipelines** - Chain multiple processors and samplers together
- **Effect Modifiers** - Simulate synthetic effects for power analysis
- **Experiments** - Orchestrate multiple test runs and visualize results

## 📊 Use Cases

- **A/B Testing** - Compare two variants to determine which performs better
- **Multivariate Testing** - Test multiple variants simultaneously
- **Power Analysis** - Determine required sample sizes for detecting effects
- **Variance Reduction** - Use CUPED or stratification to improve test sensitivity
- **Custom Tests** - Implement domain-specific statistical tests

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

MIT License - see LICENSE file for details
