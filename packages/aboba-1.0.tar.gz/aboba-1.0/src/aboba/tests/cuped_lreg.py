from typing import List, Optional
import pandas as pd
import scipy.stats as sps
from statsmodels.formula.api import ols
from aboba.base import BaseTest, TestResult
import numpy as np

class CupedLinearRegressionTTest(BaseTest):

    """
       CUPED  implementation using linear regressio

       Attributes:       
        covariate_names : List[str], optional
            List of pre-experiment covariates to adjust for
        group_column : str, default "group"
            Name of column containing group assignment (A/B)
        value_column : str, default "target"
            Name of column containing metric values to test
        groups : List[pd.DataFrame]
            List containing exactly two DataFrames [control_group, test_group]
        artefacts : Any
            Additional testing artifacts (unused in current implementation)
        alpha : float, default=0.05 
            Significance level for confidence intervals
    """    
        
    def __init__(
        self,
        covariate_names : List[str] = None,  
        group_column: str = "group",   
        value_column="target",
        alpha = 0.05 
    ):
        super().__init__()
        self.value_column = value_column
        self.group_column = group_column
        self.covariate_names = covariate_names
        self.alpha = alpha

    def test(self, groups: List[pd.DataFrame], artefacts) -> TestResult:
        a_group, b_group = groups

        data = pd.concat([a_group, b_group])
        feature_names = [self.group_column] + list(self.covariate_names)
        model = ols(f'{self.value_column} ~ '+ '+'.join(feature_names),
data=data).fit(cov_type='HC3')
        
        summary = model.summary2().tables[1]
        stat = summary.loc[self.group_column, 'z']
        pvalue = summary.loc[self.group_column, 'P>|z|']

        # pvalue = sps.ttest_ind(
        #     a_group[self.value_column],
        #     b_group[self.value_column],           
        # ).pvalue
        effect = b_group[self.value_column].mean() - a_group[self.value_column].mean()
        std = np.sqrt(a_group[self.value_column].var()/len(a_group) + b_group[self.value_column].var()/len(b_group))            
        q = sps.norm.ppf(1 - self.alpha/2)
        left_bound, right_bound  = (effect - q*std, effect + q*std)

        return TestResult(pvalue=pvalue, effect=effect, effect_interval = (left_bound, right_bound))


