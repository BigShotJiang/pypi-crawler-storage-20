from typing import List, Optional
import pandas as pd
import scipy.stats as sps

from aboba.base import BaseTest, BaseDataProcessor, DataSampler, TestResult


class KruskalIndependentTest(BaseTest):
    """
    Performs a Kruskal-Wallis H-test for multiple independent samples, a non-parametric
    alternative to one-way ANOVA.

    Attributes:
        value_column (str): Name of the column containing the values to test.
    """

    def __init__(
        self,
        value_column="target",
    ):
        """
        Kruskal-Wallis H-test for comparing distributions between independent groups.
        
        This non-parametric test compares the distributions of two or more independent
        groups to determine if they come from the same distribution. It's an alternative
        to one-way ANOVA when the assumptions of normality are not met.
        
        Args:
            value_column (str): Name of the column containing the values to test.
        
        Examples:
            ```python
            import pandas as pd
            import numpy as np
            from aboba.tests.multiple.kruskal import KruskalIndependentTest

            # Create sample non-normal data
            np.random.seed(42)
            group1 = pd.DataFrame({'target': np.random.exponential(2, 50)})
            group2 = pd.DataFrame({'target': np.random.exponential(3, 50)})
            group3 = pd.DataFrame({'target': np.random.exponential(2.5, 50)})

            # Perform the test
            test = KruskalIndependentTest(value_column='target')
            result = test.test([group1, group2, group3], {})
            print(f"P-value: {result.pvalue:.4f}")
            ```
        """
        super().__init__()
        self.value_column = value_column

    def test(self, groups: List[pd.DataFrame], artefacts) -> TestResult:
        """
        Perform the Kruskal-Wallis H-test on the provided groups.
        
        Args:
            groups (List[pd.DataFrame]): List of DataFrames representing the groups to compare.
            artefacts (dict): Dictionary to store additional results.
            
        Returns:
            TestResult: Object containing the p-value.
        """
        result = sps.kruskal(*[group[self.value_column] for group in groups])
        return TestResult(pvalue=result.pvalue)
