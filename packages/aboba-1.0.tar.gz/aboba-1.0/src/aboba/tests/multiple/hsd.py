from typing import List, Optional
import pandas as pd
import scipy.stats as sps

from aboba.base import BaseTest, BaseDataProcessor, DataSampler, TestResult


class HSDTukeyTest(BaseTest):
    """
    Performs Tukey's HSD (honestly significant difference) test for multiple
    comparison of group means.

    Attributes:
        value_column (str): Name of the column containing the values to test.
    """
    def __init__(
        self,
        value_column="target",
    ):
        """
        Tukey's Honestly Significant Difference (HSD) test for multiple comparisons.
        
        This post-hoc test is used to find means that are significantly different
        from each other after an ANOVA test indicates significant differences exist.
        It controls the family-wise error rate.
        
        Args:
            value_column (str): Name of the column containing the values to test.
        
        Examples:
            ```python
            import pandas as pd
            import numpy as np
            from aboba.tests.multiple.hsd import HSDTukeyTest

            # Create sample data with three groups
            np.random.seed(42)
            group1 = pd.DataFrame({'target': np.random.normal(10, 2, 50)})
            group2 = pd.DataFrame({'target': np.random.normal(12, 2, 50)})
            group3 = pd.DataFrame({'target': np.random.normal(11, 2, 50)})

            # Perform the test
            test = HSDTukeyTest(value_column='target')
            result = test.test([group1, group2, group3], {})
            print(f"Minimum p-value: {result.pvalue:.4f}")
            ```
        """
        super().__init__()
        self.value_column = value_column

        raise NotImplementedError("")

    def test(self, groups: List[pd.DataFrame], artefacts) -> TestResult:
        """
        Perform Tukey's HSD test for multiple comparisons.
        
        Args:
            groups (List[pd.DataFrame]): List of DataFrames representing the groups to compare.
            artefacts (dict): Dictionary to store additional results.
            
        Returns:
            TestResult: Object containing the minimum p-value from all pairwise comparisons.
        """
        result = sps.tukey_hsd(*[group[self.value_column] for group in groups])
        return TestResult(pvalue=min(result.pvalue))
