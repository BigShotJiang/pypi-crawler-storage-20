# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

function #bs.generation:gen_shape_2d {width:1,height:2,run:"setblock ~ ~ ~ minecraft:stone",with:{limit:1}}

assert block ~ ~ ~ minecraft:stone
assert not block ~1 ~ ~ minecraft:stone
await block ~1 ~ ~ minecraft:stone
