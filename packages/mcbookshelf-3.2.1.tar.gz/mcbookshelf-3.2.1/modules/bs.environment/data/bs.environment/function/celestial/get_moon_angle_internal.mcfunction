# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

function bs.environment:celestial/get_celestial_angle_internal
scoreboard players operation #r bs.ctx *= -1 bs.const
execute store result storage bs:out environment.celestial_angle double 0.001 run scoreboard players get #r bs.ctx

# --- Return value in degrees, at the scale from the macro ---
return run function bs.environment:celestial/return_celestial_angle with storage bs:ctx
