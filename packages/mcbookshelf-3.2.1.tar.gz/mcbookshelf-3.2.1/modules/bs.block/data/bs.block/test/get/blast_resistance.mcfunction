# ------------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Gunivers
#
# This file is part of the Bookshelf project (https://github.com/mcbookshelf/bookshelf).
#
# This source code is subject to the terms of the Mozilla Public License, v. 2.0.
# If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Conditions:
# - You may use this file in compliance with the MPL v2.0
# - Any modifications must be documented and disclosed under the same license
#
# For more details, refer to the MPL v2.0.
# ------------------------------------------------------------------------------------------------------------

data modify storage bs:out block set value {}

setblock ~ ~ ~ minecraft:obsidian
function #bs.block:get_blast_resistance
assert data storage bs:out block{ blast_resistance: 1200.0 }

setblock ~ ~ ~ minecraft:stone
function #bs.block:get_blast_resistance
assert data storage bs:out block{ blast_resistance: 6.0 }

setblock ~ ~ ~ minecraft:basalt
function #bs.block:get_blast_resistance
assert data storage bs:out block{ blast_resistance: 4.2 }
