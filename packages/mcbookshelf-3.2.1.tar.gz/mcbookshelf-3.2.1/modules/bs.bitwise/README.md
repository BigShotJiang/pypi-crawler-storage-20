<div align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" alt="Bookshelf" srcset="https://github.com/mcbookshelf/bookshelf/raw/master/docs/_imgs/banner-dark.png" width="600px">
    <img alt="Bookshelf" src="https://github.com/mcbookshelf/bookshelf/raw/master/docs/_imgs/banner-light.png" width="600px">
  </picture>
</div>

<div align="center">
  <a href="https://github.com/mcbookshelf/bookshelf/stargazers"><img src="https://img.shields.io/github/stars/mcbookshelf/bookshelf?colorA=363a4f&colorB=b7bdf8&style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNTYgMjU2Ij4KPHBhdGggZD0iTTIzNS4yNCw4NC4zOGwtMjguMDYsMjMuNjgsOC41NiwzNS4zOWExMy4zNCwxMy4zNCwwLDAsMS01LjA5LDEzLjkxLDEzLjU0LDEzLjU0LDAsMCwxLTE1LC42OUwxNjQsMTM5bC0zMS42NSwxOS4wNmExMy41MSwxMy41MSwwLDAsMS0xNS0uNjksMTMuMzIsMTMuMzIsMCwwLDEtNS4xLTEzLjkxbDguNTYtMzUuMzlMOTIuNzYsODQuMzhhMTMuMzksMTMuMzksMCwwLDEsNy42Ni0yMy41OGwzNi45NC0yLjkyLDE0LjIxLTMzLjY2YTEzLjUxLDEzLjUxLDAsMCwxLDI0Ljg2LDBsMTQuMjEsMzMuNjYsMzYuOTQsMi45MmExMy4zOSwxMy4zOSwwLDAsMSw3LjY2LDIzLjU4Wk04OC4xMSwxMTEuODlhOCw4LDAsMCwwLTExLjMyLDBMMTguMzQsMTcwLjM0YTgsOCwwLDAsMCwxMS4zMiwxMS4zMmw1OC40NS01OC40NUE4LDgsMCwwLDAsODguMTEsMTExLjg5Wm0tLjUsNjEuMTlMMzQuMzQsMjI2LjM0YTgsOCwwLDAsMCwxMS4zMiwxMS4zMmw1My4yNi01My4yN2E4LDgsMCwwLDAtMTEuMzEtMTEuMzFabTczLTEtNTQuMjksNTQuMjhhOCw4LDAsMCwwLDExLjMyLDExLjMybDU0LjI4LTU0LjI4YTgsOCwwLDAsMC0xMS4zMS0xMS4zMloiIHN0eWxlPSJmaWxsOiAjQ0FEM0Y1OyIvPgo8L3N2Zz4="></a>
  &nbsp;
  <a href="https://github.com/mcbookshelf/bookshelf/releases/latest"><img src="https://img.shields.io/github/v/release/mcbookshelf/bookshelf?colorA=363a4f&colorB=a6da95&style=for-the-badge&logo=github&logoColor=cad3f5"></a>
  &nbsp;
  <a href="https://discord.gg/MkXytNjmBt"><img src="https://img.shields.io/discord/1247513995376726116?style=for-the-badge&color=%237289DA&labelColor=363a4f&logo=discord&logoColor=cad3f5"></a>
</div>

<br/>
<br/>

# 🖥️ Bookshelf Bitwise

  A collection of various bitwise operations, providing versatile tools for manipulating binary data.

> “Binary is a very simple numbering system, but it is incredibly powerful when used correctly.”
> — Alan Turing

## ✨ Features

- **🔄 Bitwise Operations**: Perform bitwise AND, OR, XOR, and NOT operations on integers.
- **🔢 Bit Counting**: Count the number of bits to 1 in an integer.
- **📏 Bit Length**: Get the number of bits in an integer.

📚 [Read the full documentation](https://docs.mcbookshelf.dev/en/latest/modules/bitwise.html)

## 📖 About Bookshelf

This module is part of the [Bookshelf Library](https://docs.mcbookshelf.dev/en/latest/index.html), a modular collection of Minecraft datapacks built to simplify complex systems and empower mapmakers.

🧩 Find more modules in the [Bookshelf organization](https://modrinth.com/organization/mcbookshelf). \
📦 Get the full suite [Bookshelf Suite](https://modrinth.com/datapack/bookshelf-suite).

## 🤝 Get Involved

💬 Join our [Discord community](https://discord.gg/MkXytNjmBt). \
🛠 Contribute via the [contribution guide](https://docs.mcbookshelf.dev/en/latest/contribute/).
