"""Chronos callback utilities for agents.

Simple API:
- log_event() - Log any event (trajectory, logs, status changes)
- upload_logs() - Upload logs to S3
"""

from __future__ import annotations

import base64
import io
import json
import logging
import zipfile
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class ChronosCallback:
    """Utility class for communicating with Chronos server.

    Example:
        callback = ChronosCallback(
            callback_url="http://chronos.example.com/api/callback",
            session_id="abc123",
        )

        # Log a trajectory event
        await callback.log_event(
            span_type="trajectory",
            log_type="atif",
            extra=trajectory_dict,
        )

        # Upload logs to S3
        await callback.upload_logs(logs_dir="/path/to/logs")
    """

    def __init__(self, callback_url: str, session_id: str):
        """Initialize the callback client.

        Args:
            callback_url: Full callback base URL (e.g., http://server/api/callback)
            session_id: The Chronos session ID for this run
        """
        self.callback_url = callback_url.rstrip("/")
        self.session_id = session_id
        self._enabled = bool(callback_url and session_id)

    @property
    def enabled(self) -> bool:
        """Check if callbacks are enabled (both server and session_id set)."""
        return self._enabled

    async def log_event(
        self,
        span_type: str,
        content: str = "",
        source: str = "agent",
        log_type: str | None = None,
        step_number: int | None = None,
        extra: dict[str, Any] | None = None,
        event_id: str | None = None,
        parent_id: str | None = None,
        started_at: str | None = None,
        ended_at: str | None = None,
    ) -> bool:
        """Log an event to Chronos.

        Use this for all event types:
        - Trajectory: span_type='trajectory', log_type='atif', extra={...atif data...}
        - Steps: span_type='step', extra={observation, done, info}
        - Status: span_type='status_change', extra={status: '...'}

        Args:
            span_type: Event type (trajectory, step, reset, agent_action, etc.)
            content: Event description
            source: Event source (agent, world, system)
            log_type: Log type for rendering (atif, step, etc.)
            step_number: Step number for ordering
            extra: Structured data (trajectory, step info, etc.)
            event_id: Unique event ID (generated if not provided)
            parent_id: Parent event ID for nesting
            started_at: ISO timestamp when event started
            ended_at: ISO timestamp when event ended

        Returns:
            True if event was logged successfully, False otherwise.
        """
        if not self._enabled:
            return False

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    f"{self.callback_url}/event",
                    json={
                        "session_id": self.session_id,
                        "span_type": span_type,
                        "content": content,
                        "source": source,
                        "log_type": log_type,
                        "step_number": step_number,
                        "extra": extra,
                        "event_id": event_id,
                        "parent_id": parent_id,
                        "started_at": started_at,
                        "ended_at": ended_at,
                    },
                )
                if response.status_code == 200:
                    return True
                else:
                    logger.warning(f"Failed to log event: {response.status_code} {response.text}")
                    return False
        except Exception as e:
            logger.warning(f"Failed to log event to Chronos: {e}")
            return False

    async def update_status(
        self,
        status: str,
        message: str | None = None,
        extra: dict[str, Any] | None = None,
        api_key: str | None = None,
    ) -> bool:
        """Update the session status in Chronos.

        Args:
            status: New status (running, completed, failed)
            message: Optional status message
            extra: Optional additional data
            api_key: API key for closing Plato session on terminal status

        Returns:
            True if status was updated successfully, False otherwise.
        """
        if not self._enabled:
            return False

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    f"{self.callback_url}/status",
                    json={
                        "session_id": self.session_id,
                        "status": status,
                        "message": message,
                        "extra": extra,
                        "api_key": api_key,
                    },
                )
                return response.status_code == 200
        except Exception as e:
            logger.warning(f"Failed to update status in Chronos: {e}")
            return False

    def find_trajectory(self, logs_dir: str) -> dict[str, Any] | None:
        """Find and load ATIF trajectory from logs directory.

        Args:
            logs_dir: Path to the logs directory

        Returns:
            Parsed ATIF trajectory dict if found, None otherwise.
        """
        trajectory_path = Path(logs_dir) / "agent" / "trajectory.json"

        if not trajectory_path.exists():
            logger.info(f"No trajectory file at {trajectory_path}")
            return None

        try:
            with open(trajectory_path) as f:
                data = json.load(f)
                if isinstance(data, dict) and "schema_version" in data:
                    logger.info(f"Found ATIF trajectory: {trajectory_path}")
                    return data
                logger.info(f"Trajectory file exists but no schema_version: {trajectory_path}")
                return None
        except Exception as e:
            logger.warning(f"Failed to load trajectory from {trajectory_path}: {e}")
            return None

    def zip_logs_dir(self, logs_dir: str) -> bytes:
        """Zip the entire logs directory.

        Args:
            logs_dir: Path to the logs directory

        Returns:
            Zip file contents as bytes.
        """
        logs_path = Path(logs_dir)
        buffer = io.BytesIO()

        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            for file_path in logs_path.rglob("*"):
                if file_path.is_file():
                    arcname = file_path.relative_to(logs_path)
                    zf.write(file_path, arcname)

        buffer.seek(0)
        return buffer.read()

    async def upload_logs(self, logs_dir: str) -> str | None:
        """Upload logs directory to S3 via Chronos.

        Args:
            logs_dir: Path to the logs directory

        Returns:
            S3 URL if successful, None otherwise.
        """
        if not self._enabled:
            return None

        try:
            logs_zip = self.zip_logs_dir(logs_dir)
            logs_base64 = base64.b64encode(logs_zip).decode("utf-8")
            logger.info(f"Zipped logs: {len(logs_zip)} bytes")
        except Exception as e:
            logger.warning(f"Failed to zip logs: {e}")
            return None

        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    f"{self.callback_url}/logs-upload",
                    json={
                        "session_id": self.session_id,
                        "logs_base64": logs_base64,
                    },
                )
                if response.status_code == 200:
                    result = response.json()
                    logger.info(f"Uploaded logs to Chronos: {result}")
                    return result.get("logs_url")
                else:
                    logger.warning(f"Failed to upload logs: {response.status_code} {response.text}")
                    return None
        except Exception as e:
            logger.warning(f"Failed to upload logs to Chronos: {e}")
            return None

    async def upload_artifacts(
        self,
        logs_dir: str,
        trajectory: dict[str, Any] | None = None,
        agent_image: str | None = None,
    ) -> bool:
        """Upload trajectory and logs to Chronos.

        If trajectory is not provided, attempts to find it in the logs directory.

        Args:
            logs_dir: Path to the logs directory
            trajectory: Optional pre-loaded trajectory dict.
            agent_image: Optional agent Docker image URI to include in trajectory.

        Returns:
            True if successful, False otherwise.
        """
        if not self._enabled:
            return False

        success = False

        # Find and upload trajectory
        if trajectory is None:
            trajectory = self.find_trajectory(logs_dir)

        if trajectory:
            # Merge agent image into trajectory
            if agent_image:
                agent = trajectory.get("agent", {})
                extra = agent.get("extra") or {}
                extra["image"] = agent_image
                agent["extra"] = extra
                trajectory["agent"] = agent

            logger.info("Uploading trajectory to Chronos")
            if await self.log_event(
                span_type="trajectory",
                log_type="atif",
                extra=trajectory,
                source="agent",
            ):
                logger.info("Trajectory uploaded successfully")
                success = True
            else:
                logger.warning("Failed to upload trajectory")

        # Upload logs
        logs_url = await self.upload_logs(logs_dir)
        if logs_url:
            logger.info(f"Logs uploaded: {logs_url}")
            success = True

        return success

    # Legacy methods for backwards compatibility

    async def push_logs(self, logs: list[dict[str, Any]]) -> bool:
        """Legacy: Push log entries (just acknowledges now)."""
        if not self._enabled:
            return False
        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    f"{self.callback_url}/logs",
                    json={"session_id": self.session_id, "logs": logs},
                )
                return response.status_code == 200
        except Exception:
            return False

    async def push_log(
        self,
        message: str,
        level: str = "info",
        extra: dict[str, Any] | None = None,
    ) -> bool:
        """Legacy: Push a single log entry."""
        log_entry: dict[str, Any] = {"level": level, "message": message}
        if extra:
            log_entry["extra"] = extra
        return await self.push_logs([log_entry])
