"""Base world class for Plato worlds."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, ClassVar, Generic, TypeVar, get_args, get_origin
from uuid import uuid4

import httpx
from pydantic import BaseModel, Field

from plato.worlds.config import RunConfig

if TYPE_CHECKING:
    from plato.v2.async_.session import Session

logger = logging.getLogger(__name__)

# Global registry of worlds
_WORLD_REGISTRY: dict[str, type[BaseWorld]] = {}

# Type variable for config
ConfigT = TypeVar("ConfigT", bound=RunConfig)


def register_world(name: str | None = None):
    """Decorator to register a world class.

    Usage:
        @register_world("code")
        class CodeWorld(BaseWorld[CodeWorldConfig]):
            ...
    """

    def decorator(cls: type[BaseWorld]) -> type[BaseWorld]:
        world_name = name or getattr(cls, "name", cls.__name__.lower().replace("world", ""))
        _WORLD_REGISTRY[world_name] = cls
        logger.debug(f"Registered world: {world_name} -> {cls.__name__}")
        return cls

    return decorator


def get_registered_worlds() -> dict[str, type[BaseWorld]]:
    """Get all registered worlds."""
    return _WORLD_REGISTRY.copy()


def get_world(name: str) -> type[BaseWorld] | None:
    """Get a world by name."""
    return _WORLD_REGISTRY.get(name)


class Observation(BaseModel):
    """Observation returned from reset/step."""

    data: dict[str, Any] = Field(default_factory=dict)

    model_config = {"extra": "allow"}


class StepResult(BaseModel):
    """Result of a step."""

    observation: Observation
    done: bool = False
    info: dict[str, Any] = Field(default_factory=dict)


class BaseWorld(ABC, Generic[ConfigT]):
    """Base class for Plato worlds.

    Subclass with a config type parameter for fully typed config access:

        class CodeWorldConfig(RunConfig):
            repository_url: str
            prompt: str
            coder: Annotated[AgentConfig, Agent(description="Coding agent")]
            git_token: Annotated[str | None, Secret(description="GitHub token")] = None

        @register_world("code")
        class CodeWorld(BaseWorld[CodeWorldConfig]):
            name = "code"
            description = "Run coding agents"

            async def reset(self) -> Observation:
                url = self.config.repository_url  # typed as str
                agent = self.config.coder          # typed as AgentConfig
                token = self.config.git_token      # typed as str | None
    """

    # Class attributes
    name: ClassVar[str] = "base"
    description: ClassVar[str] = ""

    # Instance attributes
    config: ConfigT  # Typed via generic parameter
    plato_session: Session | None = None  # Connected Plato session (if running on managed VM)

    def __init__(self) -> None:
        self.logger = logging.getLogger(f"plato.worlds.{self.name}")
        self._step_count: int = 0
        self.plato_session = None
        self._current_step_id: str | None = None
        self._session_span_id: str | None = None

    @classmethod
    def get_config_class(cls) -> type[RunConfig]:
        """Get the config class from the generic parameter."""
        # Walk up the class hierarchy to find Generic base
        for base in getattr(cls, "__orig_bases__", []):
            origin = get_origin(base)
            if origin is BaseWorld:
                args = get_args(base)
                if args and isinstance(args[0], type) and issubclass(args[0], RunConfig):
                    return args[0]
        return RunConfig

    @classmethod
    def get_version(cls) -> str:
        """Get version from package metadata."""
        import importlib.metadata

        for pkg_name in [cls.__module__.split(".")[0], f"plato-world-{cls.name}"]:
            try:
                return importlib.metadata.version(pkg_name)
            except importlib.metadata.PackageNotFoundError:
                continue
        return "0.0.0"

    @classmethod
    def get_schema(cls) -> dict:
        """Get full schema including world config, agents, and secrets."""
        config_class = cls.get_config_class()
        schema = config_class.get_json_schema()

        return {
            "$schema": "https://json-schema.org/draft/2020-12/schema",
            "type": "object",
            "properties": schema.get("properties", {}),
            "required": schema.get("required", []),
            "agents": schema.get("agents", []),
            "secrets": schema.get("secrets", []),
        }

    @abstractmethod
    async def reset(self) -> Observation:
        """Setup the world and return initial observation.

        Access configuration via self.config (fully typed).
        """
        pass

    @abstractmethod
    async def step(self) -> StepResult:
        """Execute one step of the world.

        Called repeatedly until done=True is returned.
        """
        pass

    async def close(self) -> None:
        """Cleanup resources. Called after run completes."""
        pass

    async def _connect_plato_session(self) -> None:
        """Connect to Plato session from config.

        This is called automatically during run() to restore the session
        and start sending heartbeats while the world runs.
        """
        try:
            from plato.v2.async_.session import Session

            self.logger.info("Restoring Plato session from serialized data")
            self.plato_session = await Session.load(self.config.plato_session, start_heartbeat=True)
            self.logger.info(f"Plato session {self.plato_session.session_id} restored, heartbeat started")
        except Exception as e:
            self.logger.warning(f"Failed to restore Plato session: {e}")

    async def _disconnect_plato_session(self) -> None:
        """Stop heartbeat for the Plato session (does not close the session)."""
        if self.plato_session:
            try:
                await self.plato_session.stop_heartbeat()
                self.logger.info("Plato session heartbeat stopped")
            except Exception as e:
                self.logger.warning(f"Error stopping Plato heartbeat: {e}")

    async def _log_event(
        self,
        span_type: str,
        content: str = "",
        source: str = "world",
        log_type: str | None = None,
        event_id: str | None = None,
        parent_id: str | None = None,
        step_number: int | None = None,
        extra: dict[str, Any] | None = None,
        started_at: datetime | None = None,
        ended_at: datetime | None = None,
    ) -> str | None:
        """Log an event to the callback API.

        Args:
            span_type: Type of event (reset, step, trajectory, agent_action, etc.)
            content: Event description
            source: Event source (world, agent, system)
            log_type: Log type for rendering (atif, step, etc.)
            event_id: Unique ID for this event (generated if not provided)
            parent_id: Parent event ID for nesting
            step_number: Step number for ordering
            extra: Additional structured data
            started_at: When the event started
            ended_at: When the event ended

        Returns:
            The event ID if successfully logged, None otherwise
        """
        if not self.config.callback_url or not self.config.session_id:
            return None

        event_id = event_id or str(uuid4())

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    f"{self.config.callback_url}/event",
                    json={
                        "session_id": self.config.session_id,
                        "event_id": event_id,
                        "parent_id": parent_id,
                        "source": source,
                        "span_type": span_type,
                        "log_type": log_type,
                        "step_number": step_number,
                        "content": content,
                        "extra": extra,
                        "started_at": started_at.isoformat() if started_at else None,
                        "ended_at": ended_at.isoformat() if ended_at else None,
                    },
                )
                if response.status_code == 200:
                    return event_id
                else:
                    self.logger.warning(f"Failed to log event: {response.status_code} {response.text}")
        except Exception as e:
            self.logger.warning(f"Failed to log event: {e}")

        return None

    async def log_agent_action(
        self,
        agent_name: str,
        action: str,
        content: str,
        extra: dict[str, Any] | None = None,
    ) -> str | None:
        """Log an agent action during a step.

        Args:
            agent_name: Name of the agent
            action: Action type (e.g., tool_call, response)
            content: Action content/description
            extra: Additional data (tool input, output, etc.)

        Returns:
            The event ID if successfully logged
        """
        return await self._log_event(
            span_type="agent_action",
            content=f"[{agent_name}] {action}: {content}",
            source="agent",
            parent_id=self._current_step_id,
            step_number=self._step_count,
            extra={"agent": agent_name, "action": action, **(extra or {})},
        )

    async def log_trajectory(self, trajectory: dict[str, Any]) -> str | None:
        """Log an ATIF trajectory.

        Args:
            trajectory: ATIF trajectory dict

        Returns:
            The event ID if successfully logged
        """
        return await self._log_event(
            span_type="trajectory",
            log_type="atif",
            source="agent",
            extra=trajectory,
        )

    async def run(self, config: ConfigT) -> None:
        """Run the world: reset -> step until done -> close.

        This is the main entry point. If plato_session_id is provided in config,
        automatically connects to the Plato session to send heartbeats.
        """
        self.config = config
        self._step_count = 0

        self.logger.info(f"Starting world '{self.name}'")

        # Connect to Plato session if configured (for heartbeats)
        await self._connect_plato_session()

        # Log session start
        session_start = datetime.now(timezone.utc)
        self._session_span_id = await self._log_event(
            span_type="session_start",
            content=f"World '{self.name}' started",
            source="world",
            started_at=session_start,
            extra={"world_name": self.name, "world_version": self.get_version()},
        )

        try:
            # Log and execute reset
            reset_start = datetime.now(timezone.utc)
            reset_id = str(uuid4())
            await self._log_event(
                span_type="reset",
                content="World reset started",
                source="world",
                event_id=reset_id,
                parent_id=self._session_span_id,
                started_at=reset_start,
            )

            obs = await self.reset()
            reset_end = datetime.now(timezone.utc)

            await self._log_event(
                span_type="reset",
                content="World reset complete",
                source="world",
                event_id=reset_id,
                parent_id=self._session_span_id,
                started_at=reset_start,
                ended_at=reset_end,
                extra={"observation": obs.model_dump() if hasattr(obs, "model_dump") else str(obs)},
            )
            self.logger.info(f"World reset complete: {obs}")

            while True:
                self._step_count += 1
                step_start = datetime.now(timezone.utc)
                self._current_step_id = str(uuid4())

                # Log step start
                await self._log_event(
                    span_type="step",
                    content=f"Step {self._step_count} started",
                    source="world",
                    event_id=self._current_step_id,
                    parent_id=self._session_span_id,
                    step_number=self._step_count,
                    started_at=step_start,
                )

                result = await self.step()
                step_end = datetime.now(timezone.utc)

                # Log step completion
                await self._log_event(
                    span_type="step",
                    content=f"Step {self._step_count} {'completed' if result.done else 'continues'}",
                    source="world",
                    event_id=self._current_step_id,
                    parent_id=self._session_span_id,
                    step_number=self._step_count,
                    started_at=step_start,
                    ended_at=step_end,
                    extra={
                        "done": result.done,
                        "observation": result.observation.model_dump()
                        if hasattr(result.observation, "model_dump")
                        else str(result.observation),
                        "info": result.info,
                    },
                )

                self.logger.info(f"Step {self._step_count}: done={result.done}")

                if result.done:
                    break

        finally:
            await self.close()
            await self._disconnect_plato_session()

            # Log session end
            session_end = datetime.now(timezone.utc)
            await self._log_event(
                span_type="session_end",
                content=f"World '{self.name}' completed after {self._step_count} steps",
                source="world",
                parent_id=self._session_span_id,
                started_at=session_start,
                ended_at=session_end,
                extra={"total_steps": self._step_count},
            )

            self.logger.info(f"World '{self.name}' completed after {self._step_count} steps")
