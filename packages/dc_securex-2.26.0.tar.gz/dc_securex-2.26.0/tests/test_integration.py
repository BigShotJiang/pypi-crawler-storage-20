"""
Integration Tests
Tests: Full system workflow, parallel broadcasting, end-to-end scenarios
"""
import pytest
import discord
from securex import SecureX
from unittest.mock import Mock, AsyncMock
import asyncio


class TestParallelBroadcast:
    """Test parallel queue broadcasting system"""
    
    def test_all_queues_exist(self):
        """Test all 4 queues are created"""
        bot = Mock(spec=discord.Client)
        sx = SecureX(bot)
        
        assert sx.action_queue is not None
        assert sx.cleanup_queue is not None
        assert sx.log_queue is not None
        assert sx.guild_queue is not None
        
    @pytest.mark.asyncio
    async def test_queue_max_size(self):
        """Test queues have correct max size"""
        bot = Mock(spec=discord.Client)
        sx = SecureX(bot)
        
        assert sx.action_queue.maxsize == 1000
        assert sx.cleanup_queue.maxsize == 1000
        assert sx.log_queue.maxsize == 1000
        assert sx.guild_queue.maxsize == 1000


class TestEndToEnd:
    """End-to-end integration tests"""
    
    @pytest.mark.asyncio
    async def test_full_initialization(self):
        """Test complete SDK initialization"""
        bot = Mock(spec=discord.Client)
        bot.user = Mock(id=123)
        sx = SecureX(bot)
        
        # Verify all components initialized
        assert sx.bot is not None
        assert sx.action_worker is not None
        assert sx.cleanup_worker is not None
        assert sx.log_worker is not None
        assert sx.guild_worker is not None
        assert sx.backup_manager is not None
        assert sx.channel_handler is not None
        assert sx.role_handler is not None
        assert sx.member_handler is not None
        
    def test_punishment_chain(self):
        """Test punishment configuration flows through"""
        bot = Mock(spec=discord.Client)
        sx = SecureX(bot)
        
        custom_punishments = {
            "role_create": "ban",
            "channel_delete": "kick",
            "guild_update": "ban"
        }
        
        sx.punishments.update(custom_punishments)
        
        # Verify punishment cache can be populated
        guild_id = 123
        sx.punishment_cache[guild_id] = sx.punishments.copy()
        
        assert sx.punishment_cache[guild_id]["role_create"] == "ban"
        assert sx.punishment_cache[guild_id]["guild_update"] == "ban"


class TestFileStructure:
    """Test file and folder structure"""
    
    def test_backup_directory(self):
        """Test backup directory structure"""
        bot = Mock(spec=discord.Client)
        sx = SecureX(bot)
        
        assert sx.backup_dir.exists()
        assert sx.backup_dir.is_dir()
        
    def test_tokens_file_location(self):
        """Test user tokens file location"""
        bot = Mock(spec=discord.Client)
        sx = SecureX(bot)
        
        expected_path = sx.backup_dir / "user_tokens.json"
        assert sx.guild_worker._tokens_file == expected_path


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
