"""
Test SecureX Client
Tests: Initialization, worker setup, queue system, enable/disable
"""
import pytest
import discord
from securex import SecureX
import asyncio


class TestSecureXClient:
    """Test SecureX client initialization and configuration"""
    
    def test_client_initialization(self):
        """Test basic client initialization"""
        bot = discord.Client(intents=discord.Intents.all())
        sx = SecureX(bot)
        
        assert sx.bot == bot
        assert sx.action_queue is not None
        assert sx.cleanup_queue is not None
        assert sx.log_queue is not None
        assert sx.guild_queue is not None
        
    def test_workers_initialized(self):
        """Test all workers are created"""
        bot = discord.Client(intents=discord.Intents.all())
        sx = SecureX(bot)
        
        assert sx.action_worker is not None
        assert sx.cleanup_worker is not None
        assert sx.log_worker is not None
        assert sx.guild_worker is not None
        
    def test_handlers_initialized(self):
        """Test all handlers are created"""
        bot = discord.Client(intents=discord.Intents.all())
        sx = SecureX(bot)
        
        assert sx.channel_handler is not None
        assert sx.role_handler is not None
        assert sx.member_handler is not None
        
    def test_backup_manager_initialized(self):
        """Test backup manager setup"""
        bot = discord.Client(intents=discord.Intents.all())
        sx = SecureX(bot)
        
        assert sx.backup_manager is not None
        assert sx.backup_dir.exists()
        
    def test_default_punishments(self):
        """Test default punishment configuration"""
        bot = discord.Client(intents=discord.Intents.all())
        sx = SecureX(bot)
        
        assert sx.punishments["bot_add"] == "none"
        assert sx.punishments["role_create"] == "none"
        assert sx.punishments["guild_update"] == "none"
        
    @pytest.mark.asyncio
    async def test_enable_with_punishments(self):
        """Test enabling protection with custom punishments"""
        bot = discord.Client(intents=discord.Intents.all())
        sx = SecureX(bot)
        
        custom_punishments = {
            "role_create": "ban",
            "channel_delete": "kick"
        }
        
        # Note: Can't actually start workers without a running bot
        # This just tests configuration
        sx.punishments.update(custom_punishments)
        
        assert sx.punishments["role_create"] == "ban"
        assert sx.punishments["channel_delete"] == "kick"
        
    def test_whitelist_cache(self):
        """Test whitelist cache initialization"""
        bot = discord.Client(intents=discord.Intents.all())
        sx = SecureX(bot)
        
        assert isinstance(sx.whitelist_cache, dict)
        assert isinstance(sx.punishment_cache, dict)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
