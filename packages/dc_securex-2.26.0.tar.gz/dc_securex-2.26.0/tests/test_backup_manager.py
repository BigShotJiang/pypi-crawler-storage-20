"""
Test Backup Manager
Tests: Backup creation, restoration, caching, auto-refresh
"""
import pytest
import discord
from securex import SecureX
from unittest.mock import Mock, AsyncMock, patch
import asyncio
from pathlib import Path


class TestBackupManager:
    """Test Backup Manager functionality"""
    
    @pytest.fixture
    def setup_manager(self):
        """Setup backup manager"""
        bot = Mock(spec=discord.Client)
        sx = SecureX(bot)
        return sx.backup_manager
    
    def test_backup_directory_creation(self, setup_manager):
        """Test backup directory is created"""
        manager = setup_manager
        
        assert manager.backup_dir.exists()
        assert manager.backup_dir.is_dir()
        
    def test_cache_initialization(self, setup_manager):
        """Test caches are initialized"""
        manager = setup_manager
        
        assert isinstance(manager._channel_cache, dict)
        assert isinstance(manager._role_cache, dict)
        assert isinstance(manager._guild_cache, dict)
        
    @pytest.mark.asyncio
    async def test_guild_settings_cache(self, setup_manager):
        """Test guild settings caching"""
        manager = setup_manager
        
        # Mock guild
        guild = Mock(spec=discord.Guild)
        guild.id = 123456789
        guild.vanity_url_code = "testvanity"
        guild.name = "Test Server"
        guild.icon = None
        guild.banner = None
        guild.description = "Test description"
        
        # Backup guild settings
        result = await manager._backup_guild_settings(guild)
        
        assert result["guild_id"] == guild.id
        assert result["vanity_url_code"] == "testvanity"
        assert result["name"] == "Test Server"
        
    @pytest.mark.asyncio
    async def test_get_guild_settings(self, setup_manager):
        """Test retrieving guild settings from cache"""
        manager = setup_manager
        
        guild_id = 123456789
        test_data = {
            "guild_id": guild_id,
            "vanity_url_code": "test",
            "name": "Test"
        }
        
        # Add to cache
        manager._guild_cache[guild_id] = test_data
        
        # Retrieve
        result = await manager.get_guild_settings(guild_id)
        
        assert result == test_data
        assert result["vanity_url_code"] == "test"
        
    def test_lock_system(self, setup_manager):
        """Test guild lock system"""
        manager = setup_manager
        
        guild_id = 123456789
        lock1 = manager._get_guild_lock(guild_id)
        lock2 = manager._get_guild_lock(guild_id)
        
        # Same lock for same guild
        assert lock1 is lock2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
