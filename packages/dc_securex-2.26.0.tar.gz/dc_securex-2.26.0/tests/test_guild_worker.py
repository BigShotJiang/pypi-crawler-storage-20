"""
Test Guild Worker
Tests: Vanity restoration, user token management, queue processing
"""
import pytest
import discord
from securex import SecureX
from unittest.mock import Mock, AsyncMock, patch
import asyncio


class TestGuildWorker:
    """Test Guild Worker restoration logic"""
    
    @pytest.fixture
    def setup_worker(self):
        """Setup guild worker"""
        bot = Mock(spec=discord.Client)
        sx = SecureX(bot)
        return sx.guild_worker
    
    @pytest.mark.asyncio
    async def test_user_token_storage(self, setup_worker):
        """Test per-guild user token storage"""
        worker = setup_worker
        
        guild_id = 123456789
        test_token = "test_token_123"
        
        await worker.set_user_token(guild_id, test_token)
        retrieved_token = worker.get_user_token(guild_id)
        
        assert retrieved_token == test_token
        
    @pytest.mark.asyncio  
    async def test_user_token_removal(self, setup_worker):
        """Test removing user token"""
        worker = setup_worker
        
        guild_id = 123456789
        test_token = "test_token_123"
        
        await worker.set_user_token(guild_id, test_token)
        await worker.remove_user_token(guild_id)
        
        assert worker.get_user_token(guild_id) is None
        
    def test_user_token_cache(self, setup_worker):
        """Test user token caching"""
        worker = setup_worker
        
        assert isinstance(worker._user_tokens, dict)
        
    @pytest.mark.asyncio
    async def test_guild_update_filtering(self):
        """Test worker filters only guild_update entries"""
        bot = Mock(spec=discord.Client)
        bot.user = Mock(id=123)
        sx = SecureX(bot)
        
        # Mock entry that should be processed
        guild_update_entry = Mock(spec=discord.AuditLogEntry)
        guild_update_entry.action = discord.AuditLogAction.guild_update
        
        # Mock entry that should be skipped
        role_create_entry = Mock(spec=discord.AuditLogEntry)
        role_create_entry.action = discord.AuditLogAction.role_create
        
        assert guild_update_entry.action == discord.AuditLogAction.guild_update
        assert role_create_entry.action != discord.AuditLogAction.guild_update
        
    @pytest.mark.asyncio
    async def test_change_extraction(self):
        """Test extracting changes from audit log entry"""
        # Mock change object
        change = Mock()
        change.key = "vanity_url_code"
        change.before = "oldvanity"
        change.after = "newvanity"
        
        entry = Mock(spec=discord.AuditLogEntry)
        entry.action = discord.AuditLogAction.guild_update
        entry.changes = [change]
        
        # Verify change structure
        assert entry.changes[0].key == "vanity_url_code"
        assert entry.changes[0].before == "oldvanity"
        assert entry.changes[0].after == "newvanity"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
