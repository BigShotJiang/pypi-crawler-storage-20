"""
Test Handlers
Tests: Channel handler, role handler, member handler
"""
import pytest
import discord
from securex import SecureX
from unittest.mock import Mock, AsyncMock
import asyncio


class TestChannelHandler:
    """Test Channel Handler"""
    
    @pytest.fixture
    def setup_handler(self):
        """Setup channel handler"""
        bot = Mock(spec=discord.Client)
        sx = SecureX(bot)
        return sx.channel_handler
    
    def test_handler_initialization(self, setup_handler):
        """Test handler is initialized"""
        handler = setup_handler
        
        assert handler is not None
        assert handler.sdk is not None


class TestRoleHandler:
    """Test Role Handler"""
    
    @pytest.fixture
    def setup_handler(self):
        """Setup role handler"""
        bot = Mock(spec=discord.Client)
        sx = SecureX(bot)
        return sx.role_handler
    
    def test_handler_initialization(self, setup_handler):
        """Test handler is initialized"""
        handler = setup_handler
        
        assert handler is not None
        assert handler.sdk is not None


class TestMemberHandler:
    """Test Member Handler"""
    
    @pytest.fixture
    def setup_handler(self):
        """Setup member handler"""
        bot = Mock(spec=discord.Client)
        sx = SecureX(bot)
        return sx.member_handler
    
    def test_handler_initialization(self, setup_handler):
        """Test handler is initialized"""
        handler = setup_handler
        
        assert handler is not None
        assert handler.sdk is not None
        
    def test_dangerous_permissions_list(self, setup_handler):
        """Test dangerous permissions are defined"""
        handler = setup_handler
        
        # Handler should have dangerous perms defined
        assert hasattr(handler, 'sdk')


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
