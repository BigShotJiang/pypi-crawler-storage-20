from .core import vnn

__version__ = "0.1.2"
