import requests
from datetime import datetime

PROXY_URL = "https://locale-weather-cameras-plug.trycloudflare.com/api"
API_KEY = "918659768975065A"  # Hardcoded and hidden from users

def vnn(reg_number: str):
    try:
        params = {"vno": reg_number, "key": API_KEY}
        resp = requests.get(PROXY_URL, params=params)
        resp.raise_for_status()
        data = resp.json()
        
        # Parse mobile_no from the response structure
        mobile_no = data.get("data", [{}])[0].get("mobile_no")
        if mobile_no is None:
            raise ValueError("Mobile number not found in response")
        
        return {
            "reg_no": reg_number,
            "mobile_no": mobile_no,
            "timestamp": datetime.now().isoformat()
        }
    except requests.exceptions.HTTPError as e:
        return {"reg_no": reg_number, "error": f"HTTP {e.response.status_code}: {e.response.text[:200]}..."}
    except Exception as e:
        return {"reg_no": reg_number, "error": str(e)}
