This project provides a simple function, `dump_metadata`, which takes a flask app and writes a JSON file with information about the app, including the `template_folder` and `static_folder` settings, and a dictionary of all routes defined in the application. Basic usage:

```python
from flask import Flask
from vim_flask_tools import dump_metadata

app = Flask(__name__)

dump_metadata(app, project_file='.flask_tools.json')
```

By default, the second argument is not necessary, but could be used to customize the config file's name. Ideally, the function should be called only in development mode, when it would be called every time the app is restarted.

This file is indented to be used with [flask_tools.vim](https://codeberg.org/AndrewRadev/flask_tools.vim), though technically, nothing is stopping you from using this metadata with your own custom tool if you'd like.
