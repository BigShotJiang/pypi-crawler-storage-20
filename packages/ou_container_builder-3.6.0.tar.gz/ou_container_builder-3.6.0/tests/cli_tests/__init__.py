"""CLI Tests."""
