"""Display formatting for DataFolio describe() output.

This module provides formatting utilities for generating human-readable
descriptions of DataFolio bundles, including item listings, metadata,
lineage information, and file sizes.
"""

import os
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Optional

if TYPE_CHECKING:
    from datafolio.folio import DataFolio

from datafolio.utils import is_cloud_path


class DisplayFormatter:
    """Formatter for generating human-readable DataFolio descriptions.

    This class handles all display formatting for the describe() method,
    including timestamp formatting, file size formatting, and metadata
    value truncation.
    """

    def __init__(self, folio: "DataFolio"):
        """Initialize DisplayFormatter.

        Args:
            folio: DataFolio instance to format
        """
        self._folio = folio

    def describe(
        self,
        return_string: bool = False,
        show_empty: bool = False,
        max_metadata_fields: int = 10,
        snapshot: Optional[str] = None,
    ) -> Optional[str]:
        """Generate a human-readable description of all items in the bundle.

        Includes lineage information showing inputs and dependencies.

        Args:
            return_string: If True, return the description as a string instead of printing
            show_empty: If True, show empty sections (e.g., "Models (0): (none)")
            max_metadata_fields: Maximum number of metadata fields to display (default: 10)
            snapshot: Optional snapshot name to describe. If provided, shows details of that snapshot instead.

        Returns:
            None if return_string=False (prints to stdout), otherwise returns the description string

        Examples:
            Print description (default):
            >>> folio = DataFolio('experiments/test')
            >>> folio.describe()
            DataFolio: experiments/test
            ===========================
            Tables (2):
              • raw_data (reference): Training data
              • results: Model results
                ↳ inputs: raw_data

            Describe a specific snapshot:
            >>> folio.describe(snapshot='v1.0')
            Snapshot: v1.0
            ==============
            Created: 2024-01-15 10:30 AM
            Description: Initial baseline
            Items (5):
              • training_data: Training dataset
              • model: Trained classifier

            Get description as string:
            >>> folio = DataFolio('experiments/test')
            >>> text = folio.describe(return_string=True)

            Show empty sections:
            >>> folio.describe(show_empty=True)
            Tables (2):
              • raw_data: Training data
              • results: Model results
            Models (0):
              (none)

            Limit metadata fields shown:
            >>> folio.describe(max_metadata_fields=5)
        """
        # Auto-refresh if bundle was updated externally
        self._folio._refresh_if_needed()

        # If snapshot is specified, show snapshot details instead
        if snapshot:
            return self._describe_snapshot(snapshot, return_string, show_empty)

        lines = []
        lines.append(f"DataFolio: {self._folio._bundle_dir}")
        lines.append("=" * len(lines[0]))
        lines.append("")

        # Add timestamps if available (with human-readable formatting)
        if "created_at" in self._folio.metadata:
            formatted_created = self._format_timestamp(
                self._folio.metadata["created_at"]
            )
            lines.append(f"Created: {formatted_created}")
        if "updated_at" in self._folio.metadata:
            formatted_updated = self._format_timestamp(
                self._folio.metadata["updated_at"]
            )
            lines.append(f"Updated: {formatted_updated}")
        if "parent_bundle" in self._folio.metadata:
            lines.append(f"Parent: {self._folio.metadata['parent_bundle']}")
        if any(
            k in self._folio.metadata
            for k in ["created_at", "updated_at", "parent_bundle"]
        ):
            lines.append("")

        # Add custom metadata section (filter out internal fields)
        internal_fields = {"created_at", "updated_at", "parent_bundle", "_datafolio"}
        custom_metadata = {
            k: v for k, v in self._folio.metadata.items() if k not in internal_fields
        }

        if custom_metadata:
            lines.append(f"Metadata ({len(custom_metadata)} fields):")
            # Sort keys for consistent display
            sorted_keys = sorted(custom_metadata.keys())
            displayed_keys = sorted_keys[:max_metadata_fields]

            for key in displayed_keys:
                value = custom_metadata[key]
                formatted_value = self._format_metadata_value(value)
                lines.append(f"  • {key}: {formatted_value}")

            # Show count of remaining fields if any
            remaining_count = len(custom_metadata) - len(displayed_keys)
            if remaining_count > 0:
                lines.append(f"  ... ({remaining_count} more fields)")

            lines.append("")

        # Add snapshots section
        snapshots = self._folio.list_snapshots()
        if snapshots or show_empty:
            lines.append(f"Snapshots ({len(snapshots)}):")
            if snapshots:
                # Show up to 5 most recent snapshots
                for snap in snapshots[:5]:
                    name = snap["name"]
                    desc = snap.get("description", "(no description)")
                    timestamp = self._format_timestamp(snap.get("timestamp", ""))
                    num_items = snap.get("num_items", 0)
                    lines.append(f"  • {name}: {desc}")
                    lines.append(f"    ↳ created: {timestamp}, items: {num_items}")
                    if snap.get("tags"):
                        tags_str = ", ".join(snap["tags"])
                        lines.append(f"    ↳ tags: {tags_str}")

                if len(snapshots) > 5:
                    lines.append(f"  ... ({len(snapshots) - 5} more snapshots)")
            else:
                lines.append("  (none)")
            lines.append("")

        contents = self._folio.list_contents()

        # Combine referenced and included tables
        ref_tables = contents["referenced_tables"]
        inc_tables = contents["included_tables"]
        all_tables = ref_tables + inc_tables

        if all_tables or show_empty:
            lines.append(f"Tables ({len(all_tables)}):")
            if all_tables:
                # Show referenced tables first
                for name in ref_tables:
                    item = self._folio._items[name]
                    desc = item.get("description", "(no description)")
                    lines.append(f"  • {name} (reference): {desc}")
                    # Show path for referenced tables
                    if "path" in item:
                        lines.append(f"    ↳ path: {item['path']}")
                    # Show lineage if present
                    if "inputs" in item and item["inputs"]:
                        lines.append(f"    ↳ inputs: {', '.join(item['inputs'])}")

                # Then included tables
                for name in inc_tables:
                    item = self._folio._items[name]
                    desc = item.get("description", "(no description)")
                    lines.append(f"  • {name}: {desc}")
                    # Show file size if available
                    filesize = self._get_item_filesize(item)
                    if filesize is not None:
                        lines.append(f"    ↳ size: {self._format_filesize(filesize)}")
                    # Show lineage if present
                    if "inputs" in item and item["inputs"]:
                        lines.append(f"    ↳ inputs: {', '.join(item['inputs'])}")
                    if "models" in item and item["models"]:
                        lines.append(f"    ↳ models: {', '.join(item['models'])}")
            else:
                lines.append("  (none)")
            lines.append("")

        # Numpy arrays
        numpy_arrays = contents["numpy_arrays"]
        if numpy_arrays or show_empty:
            lines.append(f"Numpy Arrays ({len(numpy_arrays)}):")
            if numpy_arrays:
                for name in numpy_arrays:
                    item = self._folio._items[name]
                    desc = item.get("description", "(no description)")
                    shape = item.get("shape", "unknown")
                    dtype = item.get("dtype", "unknown")
                    lines.append(f"  • {name}: {desc}")
                    lines.append(f"    ↳ shape: {shape}, dtype: {dtype}")
                    # Show file size if available
                    filesize = self._get_item_filesize(item)
                    if filesize is not None:
                        lines.append(f"    ↳ size: {self._format_filesize(filesize)}")
                    # Show lineage if present
                    if "inputs" in item and item["inputs"]:
                        lines.append(f"    ↳ inputs: {', '.join(item['inputs'])}")
            else:
                lines.append("  (none)")
            lines.append("")

        # JSON data
        json_data = contents["json_data"]
        if json_data or show_empty:
            lines.append(f"JSON Data ({len(json_data)}):")
            if json_data:
                for name in json_data:
                    item = self._folio._items[name]
                    desc = item.get("description", "(no description)")
                    data_type = item.get("data_type", "unknown")
                    lines.append(f"  • {name}: {desc}")
                    lines.append(f"    ↳ type: {data_type}")
                    # Show file size if available
                    filesize = self._get_item_filesize(item)
                    if filesize is not None:
                        lines.append(f"    ↳ size: {self._format_filesize(filesize)}")
                    # Show lineage if present
                    if "inputs" in item and item["inputs"]:
                        lines.append(f"    ↳ inputs: {', '.join(item['inputs'])}")
            else:
                lines.append("  (none)")
            lines.append("")

        # Models
        models = contents["models"]
        if models or show_empty:
            lines.append(f"Models ({len(models)}):")
            if models:
                for name in models:
                    item = self._folio._items[name]
                    desc = item.get("description", "(no description)")
                    lines.append(f"  • {name}: {desc}")
                    # Show file size if available
                    filesize = self._get_item_filesize(item)
                    if filesize is not None:
                        lines.append(f"    ↳ size: {self._format_filesize(filesize)}")
                    # Show lineage if present
                    if "inputs" in item and item["inputs"]:
                        lines.append(f"    ↳ inputs: {', '.join(item['inputs'])}")
                    if "hyperparameters" in item and item["hyperparameters"]:
                        # Show a few key hyperparameters
                        hps = item["hyperparameters"]
                        hp_str = ", ".join(f"{k}={v}" for k, v in list(hps.items())[:3])
                        if len(hps) > 3:
                            hp_str += f", ... ({len(hps) - 3} more)"
                        lines.append(f"    ↳ hyperparameters: {hp_str}")
            else:
                lines.append("  (none)")
            lines.append("")

        # Artifacts
        artifacts = contents["artifacts"]
        if artifacts or show_empty:
            lines.append(f"Artifacts ({len(artifacts)}):")
            if artifacts:
                for name in artifacts:
                    item = self._folio._items[name]
                    desc = item.get("description", "(no description)")
                    category = item.get("category", "")
                    category_str = f" ({category})" if category else ""
                    lines.append(f"  • {name}{category_str}: {desc}")
                    # Show file size if available
                    filesize = self._get_item_filesize(item)
                    if filesize is not None:
                        lines.append(f"    ↳ size: {self._format_filesize(filesize)}")
            else:
                lines.append("  (none)")
            lines.append("")

        # Timestamps
        timestamps = contents["timestamps"]
        if timestamps or show_empty:
            lines.append(f"Timestamps ({len(timestamps)}):")
            if timestamps:
                for name in timestamps:
                    item = self._folio._items[name]
                    desc = item.get("description", "(no description)")
                    lines.append(f"  • {name}: {desc}")
                    # Show formatted timestamp
                    iso_string = item.get("iso_string", "")
                    if iso_string:
                        formatted_time = self._format_datetime_for_display(iso_string)
                        lines.append(f"    ↳ time: {formatted_time}")
                    # Show file size if available
                    filesize = self._get_item_filesize(item)
                    if filesize is not None:
                        lines.append(f"    ↳ size: {self._format_filesize(filesize)}")
                    # Show lineage if present
                    if "inputs" in item and item["inputs"]:
                        lines.append(f"    ↳ inputs: {', '.join(item['inputs'])}")
            else:
                lines.append("  (none)")

        # Build final output
        output = "\n".join(lines)

        # Print or return based on parameter
        if return_string:
            return output
        else:
            print(output)
            return None

    def _format_timestamp(self, iso_timestamp: str) -> str:
        """Format an ISO timestamp into a human-readable string using local timezone.

        Args:
            iso_timestamp: ISO format timestamp string

        Returns:
            Human-readable timestamp in local time (e.g., "Today at 2:34 PM EST")

        Examples:
            >>> self._format_timestamp("2024-01-15T14:34:56.789Z")
            'January 15, 2024 at 2:34 PM EST'
        """
        try:
            # Parse ISO timestamp (in UTC)
            dt = datetime.fromisoformat(iso_timestamp.replace("Z", "+00:00"))

            # Convert to local timezone
            dt_local = dt.astimezone()

            # Get current time in local timezone for comparison
            now = datetime.now().astimezone()

            # Check if today or yesterday
            dt_date = dt_local.date()
            now_date = now.date()

            time_str = dt_local.strftime("%I:%M %p %Z").lstrip(
                "0"
            )  # Remove leading zero from hour

            if dt_date == now_date:
                return f"Today at {time_str}"
            elif (now_date - dt_date).days == 1:
                return f"Yesterday at {time_str}"
            else:
                date_str = dt_local.strftime("%B %d, %Y")
                return f"{date_str} at {time_str}"

        except (ValueError, AttributeError):
            # If parsing fails, return the original
            return iso_timestamp

    def _format_datetime_for_display(self, iso_string: str) -> str:
        """Format a timestamp item's datetime for display in describe().

        Args:
            iso_string: ISO 8601 timestamp string (typically in UTC)

        Returns:
            Human-readable timestamp string (e.g., "2024-01-15 10:30:00 UTC")

        Examples:
            >>> self._format_datetime_for_display("2024-01-15T10:30:00+00:00")
            '2024-01-15 10:30:00 UTC'
        """
        try:
            dt = datetime.fromisoformat(iso_string)
            # Format as: YYYY-MM-DD HH:MM:SS TZ
            return (
                dt.strftime("%Y-%m-%d %H:%M:%S %Z")
                or f"{dt.strftime('%Y-%m-%d %H:%M:%S')} UTC"
            )
        except (ValueError, AttributeError):
            # If parsing fails, return the original
            return iso_string

    def _format_metadata_value(self, value: Any, max_length: int = 60) -> str:
        """Format a metadata value for display with smart truncation.

        Args:
            value: The metadata value to format
            max_length: Maximum length for string values before truncation

        Returns:
            Formatted string representation

        Examples:
            >>> self._format_metadata_value("short")
            'short'
            >>> self._format_metadata_value("a" * 100)
            'aaaaaaaaaa... (90 more chars)'
            >>> self._format_metadata_value([1, 2, 3])
            '[1, 2, 3]'
            >>> self._format_metadata_value(list(range(20)))
            '[0, 1, 2, 3, 4, ...] (15 more items)'
        """
        # Handle strings
        if isinstance(value, str):
            if len(value) <= max_length:
                return value
            else:
                truncated = value[:max_length]
                remaining = len(value) - max_length
                return f"{truncated}... ({remaining} more chars)"

        # Handle lists
        if isinstance(value, list):
            if len(value) <= 5:
                return str(value)
            else:
                preview = value[:5]
                remaining = len(value) - 5
                preview_str = str(preview)[:-1]  # Remove closing bracket
                return f"{preview_str}, ...] ({remaining} more items)"

        # Handle dicts
        if isinstance(value, dict):
            if len(value) <= 3:
                return str(value)
            else:
                # Show first 3 items
                preview_items = list(value.items())[:3]
                preview_dict = {k: v for k, v in preview_items}
                remaining = len(value) - 3
                preview_str = str(preview_dict)[:-1]  # Remove closing brace
                return f"{preview_str}, ...}} ({remaining} more fields)"

        # Default: convert to string
        value_str = str(value)
        if len(value_str) <= max_length:
            return value_str
        else:
            truncated = value_str[:max_length]
            remaining = len(value_str) - max_length
            return f"{truncated}... ({remaining} more chars)"

    def _describe_snapshot(
        self, snapshot_name: str, return_string: bool, show_empty: bool
    ) -> Optional[str]:
        """Generate description of a specific snapshot.

        Args:
            snapshot_name: Name of the snapshot to describe
            return_string: If True, return as string instead of printing
            show_empty: If True, show empty sections

        Returns:
            None if return_string=False, otherwise returns the description string

        Raises:
            KeyError: If snapshot doesn't exist
        """
        # Get snapshot info
        snapshot_info = self._folio.get_snapshot_info(snapshot_name)

        lines = []
        lines.append(f"Snapshot: {snapshot_name}")
        lines.append("=" * len(lines[0]))
        lines.append("")

        # Basic info
        if snapshot_info.get("description"):
            lines.append(f"Description: {snapshot_info['description']}")
            lines.append("")

        if snapshot_info.get("timestamp"):
            formatted_time = self._format_timestamp(snapshot_info["timestamp"])
            lines.append(f"Created: {formatted_time}")

        if snapshot_info.get("tags"):
            tags_str = ", ".join(snapshot_info["tags"])
            lines.append(f"Tags: {tags_str}")

        if any(k in snapshot_info for k in ["timestamp", "tags"]):
            lines.append("")

        # Get items in this snapshot
        item_versions = snapshot_info.get("item_versions", {})
        lines.append(f"Items ({len(item_versions)}):")

        if item_versions:
            # Group by category
            tables = []
            models = []
            arrays = []
            json_data = []
            artifacts = []

            for item_name, version_id in item_versions.items():
                # Find the item in snapshot versions or current items
                item = None
                if item_name in self._folio._items:
                    item = self._folio._items[item_name]
                else:
                    # Look in snapshot versions
                    for snap_item in self._folio._snapshot_versions:
                        if (
                            snap_item["name"] == item_name
                            and snap_item.get("version_id") == version_id
                        ):
                            item = snap_item
                            break

                if item:
                    item_type = item.get("item_type", "unknown")
                    desc = item.get("description", "(no description)")

                    if item_type in ["included_table", "referenced_table"]:
                        tables.append((item_name, desc, item_type))
                    elif item_type == "model":
                        models.append((item_name, desc))
                    elif item_type == "numpy_array":
                        arrays.append((item_name, desc))
                    elif item_type == "json_data":
                        json_data.append((item_name, desc))
                    elif item_type == "artifact":
                        artifacts.append((item_name, desc))

            # Display by category
            if tables:
                lines.append(f"\n  Tables ({len(tables)}):")
                for name, desc, item_type in tables:
                    ref_tag = " (reference)" if item_type == "referenced_table" else ""
                    lines.append(f"    • {name}{ref_tag}: {desc}")

            if json_data:
                lines.append(f"\n  JSON Data ({len(json_data)}):")
                for name, desc in json_data:
                    lines.append(f"    • {name}: {desc}")

            if arrays:
                lines.append(f"\n  Numpy Arrays ({len(arrays)}):")
                for name, desc in arrays:
                    lines.append(f"    • {name}: {desc}")

            if models:
                lines.append(f"\n  Models ({len(models)}):")
                for name, desc in models:
                    lines.append(f"    • {name}: {desc}")

            if artifacts:
                lines.append(f"\n  Artifacts ({len(artifacts)}):")
                for name, desc in artifacts:
                    lines.append(f"    • {name}: {desc}")
        else:
            lines.append("  (none)")

        result = "\n".join(lines)
        if return_string:
            return result
        else:
            print(result)
            return None

    def _format_filesize(self, size_bytes: int) -> str:
        """Format file size in bytes to human-readable string.

        Args:
            size_bytes: File size in bytes

        Returns:
            Human-readable file size string (e.g., "1.5 MB", "23.4 KB")

        Examples:
            >>> self._format_filesize(1024)
            '1.0 KB'
            >>> self._format_filesize(1536000)
            '1.5 MB'
        """
        units = ["B", "KB", "MB", "GB", "TB"]
        size = float(size_bytes)
        unit_index = 0

        while size >= 1024 and unit_index < len(units) - 1:
            size /= 1024
            unit_index += 1

        # Format with appropriate precision
        if unit_index == 0:  # Bytes - no decimal
            return f"{int(size)} {units[unit_index]}"
        else:  # Larger units - show one decimal place
            return f"{size:.1f} {units[unit_index]}"

    def _get_item_filesize(self, item: Dict[str, Any]) -> Optional[int]:
        """Get the file size for an item if it has an associated file.

        Args:
            item: Item metadata dictionary

        Returns:
            File size in bytes, or None if no file exists or size cannot be determined

        Examples:
            >>> item = {"item_type": "included_table", "filename": "table.parquet"}
            >>> self._get_item_filesize(item)
            1024000
        """
        # Only included items have local files
        if "filename" not in item:
            return None

        item_type = item.get("item_type", "")

        # Determine the subdirectory based on item type
        from datafolio.storage import get_storage_directory

        # Referenced tables don't have local files
        if item_type == "referenced_table":
            return None

        try:
            subdir = get_storage_directory(item_type)
        except KeyError:
            # Unknown item type
            return None

        # Construct full path
        file_path = self._folio._bundle_path / subdir / item["filename"]

        # Get file size if it exists
        try:
            if is_cloud_path(str(self._folio._bundle_dir)):
                # For cloud paths, we can't easily get file size without fetching
                return None
            else:
                # Local path
                return os.path.getsize(file_path)
        except (OSError, FileNotFoundError):
            return None
