"""
Aniate - Terminal Intelligence Layer
"""

__version__ = "1.0.0"
__author__ = "Kabir Murjani"

from .cli import app

__all__ = ["app"]
