"""Shared operations for common RAG tasks"""

import asyncio
import logging
import uuid

from stache_ai.config import settings
from stache_ai.providers import NamespaceProviderFactory
from stache_ai.rag.pipeline import get_pipeline

logger = logging.getLogger(__name__)


def _run_async(coro):
    """Run an async coroutine from sync code.

    Handles the case where we may or may not already be in an event loop.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        # No event loop running, create one
        return asyncio.run(coro)

    # Already in an event loop - this shouldn't happen in Lambda but handle it
    if loop.is_running():
        # Create a new loop in a thread (fallback)
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            future = pool.submit(asyncio.run, coro)
            return future.result()
    else:
        return loop.run_until_complete(coro)


def do_search(query: str, namespace: str = None, top_k: int = 20,
              rerank: bool = True, filter: dict = None, request_id: str = None) -> dict:
    """Search knowledge base - shared by HTTP routes and external integrations

    Args:
        query: Search query string
        namespace: Optional namespace to search within
        top_k: Number of results to return (max 50)
        rerank: Whether to rerank results for better relevance
        filter: Optional metadata filter (e.g., {"source": "meeting notes"})
        request_id: Optional request ID for tracking

    Returns:
        Dictionary with results and request_id
    """
    request_id = request_id or str(uuid.uuid4())

    # Enforce top_k max 50
    if top_k > 50:
        top_k = 50
        logger.warning(f"[{request_id}] top_k exceeded max of 50, clamping to 50")

    logger.info(f"[{request_id}] Search: query={query[:50]}..., namespace={namespace}, top_k={top_k}, rerank={rerank}, filter={filter}")

    try:
        pipeline = get_pipeline()
        result = _run_async(pipeline.query(
            question=query,
            top_k=top_k,
            synthesize=False,  # ALWAYS disable synthesis
            namespace=namespace,
            rerank=rerank,
            filter=filter
        ))
        return {"request_id": request_id, **result}
    except Exception as e:
        logger.error(f"[{request_id}] Search failed: {e}")
        return {
            "request_id": request_id,
            "error": str(e),
            "question": query,
            "sources": []
        }


def do_ingest_text(text: str, metadata: dict = None, namespace: str = None,
                   chunking_strategy: str = "recursive", prepend_metadata: list = None,
                   request_id: str = None) -> dict:
    """Ingest text - shared by HTTP routes and external integrations

    Args:
        text: Text to ingest
        metadata: Optional metadata dictionary
        namespace: Optional namespace for isolation
        chunking_strategy: Strategy for chunking (recursive, markdown, semantic, character)
        prepend_metadata: List of metadata keys to prepend to each chunk for better search
        request_id: Optional request ID for tracking

    Returns:
        Result dictionary with chunks_created and request_id

    Raises:
        ValueError: If text exceeds max_ingest_text_bytes (default 10MB, configurable)
    """
    request_id = request_id or str(uuid.uuid4())

    # Enforce max text size (configurable via MAX_INGEST_TEXT_BYTES env var)
    text_bytes = text.encode('utf-8')
    max_bytes = settings.max_ingest_text_bytes
    if len(text_bytes) > max_bytes:
        size_mb = len(text_bytes) / 1024 / 1024
        limit_mb = max_bytes / 1024 / 1024
        error_msg = f"Text exceeds maximum size of {limit_mb:.1f}MB (got {size_mb:.1f}MB)"
        logger.error(f"[{request_id}] {error_msg}")
        raise ValueError(error_msg)

    logger.info(f"[{request_id}] Ingest: {len(text)} chars, namespace={namespace}, strategy={chunking_strategy}")

    try:
        pipeline = get_pipeline()
        result = _run_async(pipeline.ingest_text(
            text=text,
            metadata=metadata,
            namespace=namespace,
            chunking_strategy=chunking_strategy,
            prepend_metadata=prepend_metadata
        ))
        return {"request_id": request_id, **result}
    except ValueError:
        raise
    except Exception as e:
        logger.error(f"[{request_id}] Ingest failed: {e}")
        return {
            "request_id": request_id,
            "error": str(e),
            "success": False
        }


def do_list_namespaces(request_id: str = None) -> dict:
    """List namespaces - shared by HTTP routes and external integrations

    Args:
        request_id: Optional request ID for tracking

    Returns:
        Dictionary with namespaces list, count, and request_id
    """
    request_id = request_id or str(uuid.uuid4())
    logger.info(f"[{request_id}] List namespaces")

    try:
        provider = NamespaceProviderFactory.create(settings)
        # include_children=True to get ALL namespaces, not just root level
        namespaces = provider.list(include_children=True)
        return {
            "request_id": request_id,
            "namespaces": namespaces,
            "count": len(namespaces)
        }
    except Exception as e:
        logger.error(f"[{request_id}] List namespaces failed: {e}")
        return {
            "request_id": request_id,
            "error": str(e),
            "namespaces": [],
            "count": 0
        }


def do_list_documents(namespace: str = None, limit: int = 50,
                      next_key: str = None, request_id: str = None) -> dict:
    """List documents - shared by HTTP routes and external integrations

    Args:
        namespace: Optional namespace to list from
        limit: Maximum documents to return (max 100)
        next_key: Optional pagination key
        request_id: Optional request ID for tracking

    Returns:
        Dictionary with documents list, next_key, and request_id
    """
    request_id = request_id or str(uuid.uuid4())

    # Enforce limit max 100
    if limit > 100:
        limit = 100
        logger.warning(f"[{request_id}] limit exceeded max of 100, clamping to 100")

    logger.info(f"[{request_id}] List documents: namespace={namespace}, limit={limit}")

    try:
        pipeline = get_pipeline()

        # Check if document index provider is available
        if pipeline.document_index_provider is None:
            logger.error(f"[{request_id}] Document index provider not available (feature flag disabled)")
            return {
                "request_id": request_id,
                "error": "Document index feature is disabled",
                "documents": [],
                "next_key": None
            }

        result = pipeline.document_index_provider.list_documents(
            namespace=namespace,
            limit=limit,
            last_evaluated_key=next_key
        )
        return {"request_id": request_id, **result}
    except Exception as e:
        logger.error(f"[{request_id}] List documents failed: {e}")
        return {
            "request_id": request_id,
            "error": str(e),
            "documents": [],
            "next_key": None
        }


def do_get_document(doc_id: str, namespace: str = "default",
                    request_id: str = None) -> dict:
    """Get document - shared by HTTP routes and external integrations

    Args:
        doc_id: Document ID to retrieve
        namespace: Namespace containing the document
        request_id: Optional request ID for tracking

    Returns:
        Document dictionary with request_id, or error dict
    """
    request_id = request_id or str(uuid.uuid4())
    logger.info(f"[{request_id}] Get document: doc_id={doc_id}, namespace={namespace}")

    try:
        pipeline = get_pipeline()

        # Check if document index provider is available
        if pipeline.document_index_provider is None:
            logger.error(f"[{request_id}] Document index provider not available (feature flag disabled)")
            return {
                "request_id": request_id,
                "error": "Document index feature is disabled"
            }

        doc = pipeline.document_index_provider.get_document(
            doc_id=doc_id,
            namespace=namespace
        )

        if not doc:
            logger.info(f"[{request_id}] Document not found: {doc_id}")
            return {
                "request_id": request_id,
                "error": f"Document not found: {doc_id}"
            }

        return {"request_id": request_id, **doc}
    except Exception as e:
        logger.error(f"[{request_id}] Get document failed: {e}")
        return {
            "request_id": request_id,
            "error": str(e)
        }


# ===== Namespace Operations =====

def do_create_namespace(id: str, name: str, description: str = "",
                        parent_id: str = None, metadata: dict = None,
                        filter_keys: list = None, request_id: str = None) -> dict:
    """Create a namespace

    Args:
        id: Namespace ID (slug format, e.g., 'mba/finance')
        name: Display name
        description: What belongs in this namespace
        parent_id: Optional parent namespace ID
        metadata: Optional metadata dict
        filter_keys: Optional list of filterable metadata keys
        request_id: Optional request ID for tracking

    Returns:
        Created namespace dict with request_id
    """
    request_id = request_id or str(uuid.uuid4())
    logger.info(f"[{request_id}] Create namespace: id={id}, name={name}")

    try:
        provider = NamespaceProviderFactory.create(settings)
        namespace = provider.create(
            id=id,
            name=name,
            description=description,
            parent_id=parent_id,
            metadata=metadata,
            filter_keys=filter_keys
        )
        return {"request_id": request_id, "namespace": namespace, "success": True}
    except Exception as e:
        logger.error(f"[{request_id}] Create namespace failed: {e}")
        return {"request_id": request_id, "error": str(e), "success": False}


def do_get_namespace(id: str, request_id: str = None) -> dict:
    """Get a namespace by ID

    Args:
        id: Namespace ID to retrieve
        request_id: Optional request ID for tracking

    Returns:
        Namespace dict with request_id, or error dict
    """
    request_id = request_id or str(uuid.uuid4())
    logger.info(f"[{request_id}] Get namespace: id={id}")

    try:
        provider = NamespaceProviderFactory.create(settings)
        namespace = provider.get(id)

        if not namespace:
            return {"request_id": request_id, "error": f"Namespace not found: {id}"}

        return {"request_id": request_id, "namespace": namespace}
    except Exception as e:
        logger.error(f"[{request_id}] Get namespace failed: {e}")
        return {"request_id": request_id, "error": str(e)}


def do_update_namespace(id: str, name: str = None, description: str = None,
                        metadata: dict = None, request_id: str = None) -> dict:
    """Update a namespace

    Args:
        id: Namespace ID to update
        name: New display name (optional)
        description: New description (optional)
        metadata: Metadata to merge (optional)
        request_id: Optional request ID for tracking

    Returns:
        Updated namespace dict with request_id, or error dict
    """
    request_id = request_id or str(uuid.uuid4())
    logger.info(f"[{request_id}] Update namespace: id={id}")

    try:
        provider = NamespaceProviderFactory.create(settings)
        namespace = provider.update(
            id=id,
            name=name,
            description=description,
            metadata=metadata
        )

        if not namespace:
            return {"request_id": request_id, "error": f"Namespace not found: {id}"}

        return {"request_id": request_id, "namespace": namespace, "success": True}
    except Exception as e:
        logger.error(f"[{request_id}] Update namespace failed: {e}")
        return {"request_id": request_id, "error": str(e), "success": False}


def do_delete_namespace(id: str, cascade: bool = False, request_id: str = None) -> dict:
    """Delete a namespace

    Args:
        id: Namespace ID to delete
        cascade: If True, delete children; if False, fail if children exist
        request_id: Optional request ID for tracking

    Returns:
        Success dict with request_id, or error dict
    """
    request_id = request_id or str(uuid.uuid4())
    logger.info(f"[{request_id}] Delete namespace: id={id}, cascade={cascade}")

    try:
        provider = NamespaceProviderFactory.create(settings)
        deleted = provider.delete(id=id, cascade=cascade)

        if not deleted:
            return {"request_id": request_id, "error": f"Namespace not found: {id}", "success": False}

        return {"request_id": request_id, "success": True}
    except Exception as e:
        logger.error(f"[{request_id}] Delete namespace failed: {e}")
        return {"request_id": request_id, "error": str(e), "success": False}


# ===== Document Operations =====

def do_delete_document(doc_id: str, namespace: str = "default", request_id: str = None) -> dict:
    """Delete a document and all its chunks

    Args:
        doc_id: Document ID (UUID) to delete
        namespace: Namespace containing the document
        request_id: Optional request ID for tracking

    Returns:
        Success dict with chunks_deleted count, or error dict
    """
    request_id = request_id or str(uuid.uuid4())
    logger.info(f"[{request_id}] Delete document: doc_id={doc_id}, namespace={namespace}")

    try:
        pipeline = get_pipeline()

        # Use document index if available (preferred method)
        if pipeline.document_index_provider:
            # Get chunk IDs from document index
            chunk_ids = pipeline.document_index_provider.get_chunk_ids(doc_id, namespace)

            if not chunk_ids:
                return {
                    "request_id": request_id,
                    "error": f"Document not found: {doc_id}",
                    "success": False
                }

            # Delete from vector database first (atomic operation pattern)
            vectordb = pipeline.vectordb_provider
            vectordb.delete(chunk_ids, namespace=namespace)

            # Delete from document index
            pipeline.document_index_provider.delete_document(doc_id, namespace)

            logger.info(f"[{request_id}] Deleted document {doc_id} ({len(chunk_ids)} chunks) from {namespace}")

            return {
                "request_id": request_id,
                "success": True,
                "doc_id": doc_id,
                "namespace": namespace,
                "chunks_deleted": len(chunk_ids)
            }

        # Fallback: Use legacy vector DB deletion (for backwards compatibility)
        vectordb = pipeline.vectordb_provider
        result = vectordb.delete_by_metadata(
            field="doc_id",
            value=doc_id
        )

        # Also explicitly delete the summary record by its ID
        summary_id = f"summary_{doc_id}"
        try:
            vectordb.delete(ids=[summary_id])
        except Exception:
            pass  # Summary may not exist for older documents

        if result["deleted"] == 0:
            return {
                "request_id": request_id,
                "error": f"Document not found: {doc_id}",
                "success": False
            }

        logger.info(f"[{request_id}] Deleted {result['deleted']} chunks + summary for doc_id: {doc_id}")

        return {
            "request_id": request_id,
            "success": True,
            "doc_id": doc_id,
            "namespace": namespace,
            "chunks_deleted": result["deleted"]
        }
    except Exception as e:
        logger.error(f"[{request_id}] Delete document failed: {e}")
        return {"request_id": request_id, "error": str(e), "success": False}


# ===== Concept Operations =====

def do_search_concepts(query: str, namespace: str = None, top_k: int = 20,
                       request_id: str = None) -> dict:
    """Search concepts by semantic similarity.

    Requires enterprise package installed.
    """
    logger.info(f"[{request_id}] Searching concepts: query={query[:50]}...")

    try:
        import stache_ai_enrichment_enterprise  # noqa: F401
    except ImportError:
        return {"request_id": request_id, "error": "Concept search requires stache-ai-enrichment-enterprise package", "success": False}

    try:
        pipeline = get_pipeline()

        # Embed query
        query_embedding = pipeline.embedding_provider.embed_query(query)

        # Search concept vectors
        filter_dict = {"_type": "concept"}
        if namespace:
            filter_dict["namespace"] = namespace

        results = pipeline.vectordb_provider.search(
            query_vector=query_embedding,
            top_k=top_k,
            filter=filter_dict,
            namespace=namespace
        )

        # Collect concept IDs for batch count lookup
        concept_ids = []
        for r in results:
            concept_id = r.get("metadata", {}).get("concept_id")
            if concept_id:
                concept_ids.append(concept_id)

        # Batch fetch doc counts if concept index available
        doc_counts = {}
        if pipeline.concept_index and concept_ids:
            doc_counts = pipeline.concept_index.batch_get_concept_counts(concept_ids)

        # Build response
        concepts = []
        for r in results:
            concept_id = r.get("metadata", {}).get("concept_id")
            if not concept_id:
                continue

            concepts.append({
                "concept_id": concept_id,
                "concept": r.get("text") or r.get("metadata", {}).get("concept"),
                "score": r["score"],
                "doc_count": doc_counts.get(concept_id, 0),
            })

        return {"request_id": request_id, "concepts": concepts, "count": len(concepts)}
    except Exception as e:
        logger.error(f"[{request_id}] search_concepts failed: {e}")
        return {"request_id": request_id, "error": str(e), "success": False}


def do_get_concept_documents(concept_id: str, limit: int = 100,
                             next_token: str = None, request_id: str = None) -> dict:
    """Get documents containing a concept with pagination."""
    logger.info(f"[{request_id}] Getting docs for concept: {concept_id}")

    try:
        import stache_ai_enrichment_enterprise  # noqa: F401
    except ImportError:
        return {"request_id": request_id, "error": "Concept operations require stache-ai-enrichment-enterprise package", "success": False}

    try:
        pipeline = get_pipeline()
        if not pipeline.concept_index:
            return {"request_id": request_id, "error": "Concept index not enabled", "success": False}

        docs, new_next_token = pipeline.concept_index.get_concept_docs(
            concept_id, limit=limit, next_token=next_token
        )
        metadata = pipeline.concept_index.get_concept_metadata(concept_id)

        if metadata is None:
            return {"request_id": request_id, "error": f"Concept {concept_id} not found", "success": False}

        return {
            "request_id": request_id,
            "concept_id": concept_id,
            "concept": metadata.get("concept_text"),
            "documents": docs,
            "count": len(docs),
            "next_token": new_next_token,
        }
    except Exception as e:
        logger.error(f"[{request_id}] get_concept_documents failed: {e}")
        return {"request_id": request_id, "error": str(e), "success": False}


def do_get_document_concepts(doc_id: str, namespace: str = "default",
                             request_id: str = None) -> dict:
    """Get concepts extracted from a document."""
    logger.info(f"[{request_id}] Getting concepts for doc: {namespace}/{doc_id}")

    try:
        import stache_ai_enrichment_enterprise  # noqa: F401
    except ImportError:
        return {"request_id": request_id, "error": "Concept operations require stache-ai-enrichment-enterprise package", "success": False}

    try:
        pipeline = get_pipeline()
        if not pipeline.concept_index:
            return {"request_id": request_id, "error": "Concept index not enabled", "success": False}

        concept_ids = pipeline.concept_index.get_doc_concepts(doc_id, namespace)
        metadata_map = pipeline.concept_index.batch_get_concept_metadata(concept_ids)

        concepts = []
        for cid in concept_ids:
            metadata = metadata_map.get(cid)
            concepts.append({
                "concept_id": cid,
                "concept": metadata.get("concept_text") if metadata else None,
            })

        return {"request_id": request_id, "doc_id": doc_id, "namespace": namespace, "concepts": concepts, "count": len(concepts)}
    except Exception as e:
        logger.error(f"[{request_id}] get_document_concepts failed: {e}")
        return {"request_id": request_id, "error": str(e), "success": False}


def do_search_concepts_with_docs(query: str, namespace: str = None, top_k: int = 10,
                                  docs_per_concept: int = 5, request_id: str = None) -> dict:
    """Search concepts and return with their related documents in one call.

    Optimized for MCP clients to reduce round trips.

    Returns:
        {
            "concepts": [
                {
                    "concept_id": "abc123",
                    "concept": "machine learning",
                    "score": 0.95,
                    "documents": [
                        {"namespace": "docs", "doc_id": "doc1"},
                        ...
                    ]
                },
                ...
            ],
            "count": N
        }
    """
    logger.info(f"[{request_id}] Searching concepts with docs: query={query[:50]}...")

    try:
        import stache_ai_enrichment_enterprise  # noqa: F401
    except ImportError:
        return {"request_id": request_id, "error": "Concept operations require stache-ai-enrichment-enterprise package", "success": False}

    try:
        pipeline = get_pipeline()
        if not pipeline.concept_index:
            return {"request_id": request_id, "error": "Concept index not enabled", "success": False}

        # Embed query
        query_embedding = pipeline.embedding_provider.embed_query(query)

        # Search concept vectors
        filter_dict = {"_type": "concept"}
        if namespace:
            filter_dict["namespace"] = namespace

        results = pipeline.vectordb_provider.search(
            query_vector=query_embedding,
            top_k=top_k,
            filter=filter_dict,
            namespace=namespace
        )

        # Collect concept IDs
        concept_ids = []
        for r in results:
            concept_id = r.get("metadata", {}).get("concept_id")
            if concept_id:
                concept_ids.append(concept_id)

        if not concept_ids:
            return {"request_id": request_id, "concepts": [], "count": 0}

        # Fetch docs for each concept
        docs_by_concept = {}
        for cid in concept_ids:
            docs, _ = pipeline.concept_index.get_concept_docs(cid, limit=docs_per_concept, next_token=None)
            docs_by_concept[cid] = docs

        # Build response tree
        concepts = []
        for r in results:
            concept_id = r.get("metadata", {}).get("concept_id")
            if not concept_id:
                continue

            concepts.append({
                "concept_id": concept_id,
                "concept": r.get("text") or r.get("metadata", {}).get("concept"),
                "score": r["score"],
                "documents": docs_by_concept.get(concept_id, []),
            })

        return {"request_id": request_id, "concepts": concepts, "count": len(concepts)}
    except Exception as e:
        logger.error(f"[{request_id}] search_concepts_with_docs failed: {e}")
        return {"request_id": request_id, "error": str(e), "success": False}


def do_get_related_documents(doc_id: str, namespace: str = "default", limit: int = 20,
                              request_id: str = None) -> dict:
    """Find documents related to a given document via shared concepts.

    Flow: doc_id → concepts → other docs with same concepts

    Returns:
        {
            "doc_id": "source_doc",
            "namespace": "default",
            "related_documents": [
                {"doc_id": "related1", "namespace": "default", "shared_concepts": ["concept1", "concept2"]},
                ...
            ],
            "count": N
        }
    """
    logger.info(f"[{request_id}] Getting related documents for doc_id={doc_id}")

    try:
        import stache_ai_enrichment_enterprise  # noqa: F401
    except ImportError:
        return {"request_id": request_id, "error": "Concept operations require stache-ai-enrichment-enterprise package", "success": False}

    try:
        pipeline = get_pipeline()
        if not pipeline.concept_index:
            return {"request_id": request_id, "error": "Concept index not enabled", "success": False}

        # Get concepts for this document
        concept_ids = pipeline.concept_index.get_doc_concepts(doc_id, namespace)
        if not concept_ids:
            return {"request_id": request_id, "doc_id": doc_id, "namespace": namespace, "related_documents": [], "count": 0}

        # Get concept metadata for display
        metadata_map = pipeline.concept_index.batch_get_concept_metadata(concept_ids)

        # For each concept, get docs that have it
        doc_concepts = {}  # doc_key -> list of concept texts
        for cid in concept_ids:
            docs, _ = pipeline.concept_index.get_concept_docs(cid, limit=100, next_token=None)
            concept_text = metadata_map.get(cid, {}).get("concept_text", cid)
            for doc in docs:
                doc_key = (doc.get("namespace", "default"), doc.get("doc_id"))
                # Skip the source document
                if doc_key[1] == doc_id and doc_key[0] == namespace:
                    continue
                if doc_key not in doc_concepts:
                    doc_concepts[doc_key] = []
                doc_concepts[doc_key].append(concept_text)

        # Sort by number of shared concepts (most related first)
        sorted_docs = sorted(doc_concepts.items(), key=lambda x: len(x[1]), reverse=True)[:limit]

        related_documents = []
        for (ns, did), concepts in sorted_docs:
            related_documents.append({
                "doc_id": did,
                "namespace": ns,
                "shared_concepts": concepts,
                "shared_concept_count": len(concepts),
            })

        return {
            "request_id": request_id,
            "doc_id": doc_id,
            "namespace": namespace,
            "related_documents": related_documents,
            "count": len(related_documents)
        }
    except Exception as e:
        logger.error(f"[{request_id}] get_related_documents failed: {e}")
        return {"request_id": request_id, "error": str(e), "success": False}
