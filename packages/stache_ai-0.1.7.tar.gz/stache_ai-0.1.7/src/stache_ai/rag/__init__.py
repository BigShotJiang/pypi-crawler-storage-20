"""RAG pipeline package"""
