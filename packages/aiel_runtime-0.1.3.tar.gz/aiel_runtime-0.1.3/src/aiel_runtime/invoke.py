from __future__ import annotations
import asyncio
from typing import Any
from .protocol import Context

from aiel_sdk import get_registry

async def _maybe_await(x: Any) -> Any:
    if asyncio.iscoroutine(x):
        return await x
    return x

def _ctx(payload: dict):
    ctx_data = None
    if isinstance(payload, dict):
        ctx_data = payload.get("ctx") or payload.get("_ctx")

    return Context.from_dict(ctx_data) 

async def invoke(kind: str, name: str, payload: dict) -> Any:
    reg = get_registry()
    payload = payload or {}

    if kind == "tool":
        exp = reg.tools.get(name)
        if not exp:
            raise KeyError(f"Tool not found: {name}")
        # tool(ctx, payload)
        return await _maybe_await(exp.fn(_ctx(payload), payload))

    if kind == "agent":
        exp = reg.agents.get(name)
        if not exp:
            raise KeyError(f"Agent not found: {name}")
        state = payload.get("state", payload)
        # agent(ctx, state)
        return await _maybe_await(exp.fn(_ctx(payload), state))

    if kind == "flow":
        exp = reg.flows.get(name)
        if not exp:
            raise KeyError(f"Flow not found: {name}")

        if exp.graph_builder:
            app = exp.graph_builder()
            # Expect LangGraph compiled app has ainvoke
            return await app.ainvoke(payload)

        if exp.fn is None:
            raise RuntimeError(f"Flow '{name}' has no fn or graph_builder.")
        # flow(ctx, input)
        return await _maybe_await(exp.fn(_ctx(payload), payload))

    raise ValueError(f"Unknown kind: {kind}")
