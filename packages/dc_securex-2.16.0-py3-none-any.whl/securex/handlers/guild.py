"""
Guild protection handler (vanity URL, name, icon protection).
"""
import discord
import asyncio
from datetime import datetime, timezone, timedelta


class GuildHandler:
    """Handles guild-related protection (vanity URL, etc.)"""
    
    def __init__(self, sdk):
        self.sdk = sdk
        self.bot = sdk.bot
        self.whitelist = sdk.whitelist
    
    async def _is_authorized(self, guild: discord.Guild, user_id: int) -> bool:
        """Check if user is authorized"""
        if guild.owner_id == user_id:
            return True
        if user_id == self.bot.user.id:
            return True
        return await self.whitelist.is_whitelisted(guild.id, user_id)
    
    async def on_guild_update(self, before: discord.Guild, after: discord.Guild):
        """Detect and protect against unauthorized guild changes"""
        try:
            if before.vanity_url_code != after.vanity_url_code:
                await self._handle_vanity_change(before, after)
            
        except Exception as e:
            print(f"Error in on_guild_update: {e}")
    
    async def _handle_vanity_change(self, before: discord.Guild, after: discord.Guild):
        """Handle vanity URL changes with parallel restoration + ban"""
        try:
            await asyncio.sleep(0.3)
            
            cutoff_time = datetime.now(timezone.utc) - timedelta(seconds=30)
            
            async for entry in after.audit_logs(limit=10, action=discord.AuditLogAction.guild_update):
                if entry.created_at < cutoff_time:
                    break
                
                is_authorized = await self._is_authorized(after, entry.user.id)
                
                if not is_authorized:
                    old_vanity = before.vanity_url_code
                    new_vanity = after.vanity_url_code
                    
                    print(f"🚨 UNAUTHORIZED VANITY CHANGE!")
                    print(f"   Old: discord.gg/{old_vanity}")
                    print(f"   New: discord.gg/{new_vanity}")
                    print(f"   Attacker: {entry.user}")
                    
                    start_time = datetime.now()
                    
                    restore_task = self._restore_vanity(after, old_vanity)
                    ban_task = after.ban(entry.user, reason=f"SecureX: Unauthorized vanity change (discord.gg/{old_vanity} → discord.gg/{new_vanity})")
                    
                    results = await asyncio.gather(restore_task, ban_task, return_exceptions=True)
                    
                    elapsed = (datetime.now() - start_time).total_seconds() * 1000
                    
                    if isinstance(results[0], Exception):
                        print(f"❌ Failed to restore vanity: {results[0]}")
                    else:
                        print(f"⚡ Restored vanity URL in {elapsed:.0f}ms")
                    
                    if isinstance(results[1], Exception):
                        print(f"❌ Failed to ban attacker: {results[1]}")
                    else:
                        print(f"⚡ Banned attacker in {elapsed:.0f}ms")
                    
                else:
                    print(f"✅ Authorized vanity change by {entry.user}")
                    print(f"   Old: discord.gg/{before.vanity_url_code}")
                    print(f"   New: discord.gg/{after.vanity_url_code}")
                    
                    await self.sdk.backup_manager.update_guild_vanity(after.id, after.vanity_url_code)
                
                break
                
        except Exception as e:
            print(f"Error handling vanity change: {e}")
    
    async def _restore_vanity(self, guild: discord.Guild, vanity_code: str):
        """Restore vanity URL - CRITICAL SPEED"""
        try:
            if vanity_code:
                await guild.edit(vanity_code=vanity_code, reason="SecureX: Restoring stolen vanity URL")
                return True
            return False
        except discord.errors.HTTPException as e:
            if e.code == 50035:
                print(f"⚠️ Vanity URL '{vanity_code}' already taken by another server!")
            raise
