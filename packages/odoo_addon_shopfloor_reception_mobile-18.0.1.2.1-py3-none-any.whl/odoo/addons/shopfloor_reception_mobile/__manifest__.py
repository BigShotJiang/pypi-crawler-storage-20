# Copyright 2022 Camptocamp SA (http://www.camptocamp.com)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).
{
    "name": "Shopfloor reception mobile",
    "summary": "Scenario for receiving products",
    "version": "18.0.1.2.1",
    "development_status": "Beta",
    "depends": ["shopfloor_mobile_base", "shopfloor_reception"],
    "author": "Camptocamp, Odoo Community Association (OCA)",
    "maintainers": ["JuMiSanAr", "simahawk"],
    "website": "https://github.com/OCA/stock-logistics-shopfloor",
    "category": "Warehouse Management",
    "license": "AGPL-3",
    "installable": True,
    "data": ["templates/assets.xml"],
}
