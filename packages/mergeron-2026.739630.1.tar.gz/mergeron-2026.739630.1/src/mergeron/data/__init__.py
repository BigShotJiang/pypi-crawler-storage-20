"""Data useful for empirical analysis of merger enforcement policy are included here."""

from ..types_and_constants import VERSION

__version__ = VERSION
