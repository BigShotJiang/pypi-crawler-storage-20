"""Variables, types, objects and functions used throughout the package."""

from . import types_and_constants as pkg_types

__version__ = pkg_types.VERSION
