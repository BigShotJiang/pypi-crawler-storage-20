"""Constants, types, objects and functions used within this sub-package."""

from __future__ import annotations

import shutil
from collections.abc import Mapping
from decimal import Decimal
from importlib.resources import as_file
from types import MappingProxyType
from typing import Any

import numpy as np
from attrs import cmp_using, field, frozen

from .. import types_and_constants as pkg_types
from ..data import data_resources as mdat
from ..types_and_constants import (
    ArrayBIGINT,
    ArrayDouble,
    ArrayFloat,
    this_yaml,
    yamelize_attrs,
)

__version__ = pkg_types.VERSION

PKG_WORK_DIR = pkg_types.WORK_DIR
yaml_rt_mapper = pkg_types.yaml_rt_mapper

DEFAULT_DIST_PARMS = ArrayFloat([0.0, 1.0])
DEFAULT_BETA_DIST_PARMS = ArrayFloat([1.0, 1.0])


@frozen
class MGThresholds:
    """Thresholds for Guidelines standards."""

    delta: float
    fc: float
    rec: float
    guppi: float
    dr: float
    cmcr: float
    ipr: float


@frozen
class GuidelinesBoundary:
    """Represents Guidelines boundary analytically."""

    coordinates: ArrayDouble = field(converter=ArrayDouble)
    """Market-share pairs as Cartesian coordinates of points on the boundary."""

    area: float
    """Area under the boundary."""


WORK_DIR = globals().get("WORK_DIR", PKG_WORK_DIR)
"""Redefined, in case the user defines WORK_DIR between module imports."""

FID_WORK_DIR = WORK_DIR / "FTCData"
if not FID_WORK_DIR.is_dir():
    FID_WORK_DIR.mkdir(parents=True)

INVDATA_ARCHIVE_PATH = WORK_DIR / mdat.FTC_MERGER_INVESTIGATIONS_DATA.name
if not INVDATA_ARCHIVE_PATH.is_file():
    with as_file(mdat.FTC_MERGER_INVESTIGATIONS_DATA) as _fid:
        shutil.copy2(_fid, INVDATA_ARCHIVE_PATH)

MGNDATA_ARCHIVE_PATH = WORK_DIR / "damodaran_margin_data_serialized.zip"
if not MGNDATA_ARCHIVE_PATH.is_file():
    with as_file(mdat.DAMODARAN_MARGIN_DATA) as _f:
        shutil.copy2(_f, MGNDATA_ARCHIVE_PATH)


TABLE_TYPES = ("ByHHIandDelta", "ByFirmCount")
CONC_TABLE_ALL = "Table 3.1"
CNT_TABLE_ALL = "Table 4.1"

TTL_KEY = 86825
CONC_HHI_DICT = {
    "0 - 1,799": 0,
    "1,800 - 1,999": 1800,
    "2,000 - 2,399": 2000,
    "2,400 - 2,999": 2400,
    "3,000 - 3,999": 3000,
    "4,000 - 4,999": 4000,
    "5,000 - 6,999": 5000,
    "7,000 - 10,000": 7000,
    "TOTAL": TTL_KEY,
}
CONC_DELTA_DICT = {
    "0 - 100": 0,
    "100 - 200": 100,
    "200 - 300": 200,
    "300 - 500": 300,
    "500 - 800": 500,
    "800 - 1,200": 800,
    "1,200 - 2,500": 1200,
    "2,500 - 5,000": 2500,
    "TOTAL": TTL_KEY,
}
CNT_FCOUNT_DICT = {
    "2 to 1": 2,
    "3 to 2": 3,
    "4 to 3": 4,
    "5 to 4": 5,
    "6 to 5": 6,
    "7 to 6": 7,
    "8 to 7": 8,
    "9 to 8": 9,
    "10 to 9": 10,
    "10 +": 11,
    "TOTAL": TTL_KEY,
}


def invert_map(_dict: Mapping[Any, Any]) -> Mapping[Any, Any]:
    """Invert mapping, mapping values to keys of the original mapping."""
    return {_v: _k for _k, _v in _dict.items()}


type INVData = MappingProxyType[
    str, MappingProxyType[str, MappingProxyType[str, INVTableData]]
]
type INVData_in = dict[str, dict[str, dict[str, INVTableData]]]


@frozen
class INVTableData:
    """Represents individual table of FTC merger investigations data."""

    industry_group: str
    additional_evidence: str
    data_array: ArrayBIGINT = field(
        eq=cmp_using(eq=np.array_equal), converter=ArrayBIGINT
    )


@frozen
class EmpiricalMarginData:
    """Container for gross margin data from Prof. Damodaran, NYU.

    Along with the industry average gross margins and firm counts, we report
    overall statistics, and a bandwidth estimate for kernel density
    estimation.
    """

    average_gross_margins: ArrayDouble = field(
        eq=cmp_using(eq=np.array_equal), converter=ArrayDouble
    )
    """
    Weighted average gross margins by industry, averaged across the available years,
    with firm counts as weights. Only positive average margins are included in
    estimation.
    """

    firm_counts: ArrayDouble = field(
        eq=cmp_using(eq=np.array_equal), converter=ArrayDouble
    )
    """Number of firms by industry, averaged across the available years with positive
    average industry margins."""

    margin_stats: ArrayDouble = field(
        eq=cmp_using(eq=np.array_equal), converter=ArrayDouble
    )
    """Weighted average, weighted standard error, minimum, and maximum across industries."""

    bandwidth: float
    """
    Kernel bandwidth estimated using the Improved Sheather-Jones method discussed in
    [#r1]_ and implemented in [#r2]_. Used for adding Gaussian noise when resampling
    with replacement from industry average margins.

    .. [#r1] Z. I. Botev. J. F. Grotowski. D. P. Kroese. "Kernel density estimation via
      diffusion." Ann. Statist. 38 (5) 2916 - 2957, October 2010.
      https://doi.org/10.1214/10-AOS799.

    .. [#r2] KDEpy, https://kdepy.readthedocs.io.
    """


for _typ in (INVTableData, EmpiricalMarginData):
    yamelize_attrs(_typ)

(_, _) = (
    this_yaml.representer.add_representer(
        Decimal, lambda _r, _d: _r.represent_scalar("!Decimal", f"{_d}")
    ),
    this_yaml.constructor.add_constructor(
        "!Decimal", lambda _c, _n, /: Decimal(_c.construct_scalar(_n))
    ),
)


def _dict_from_mapping(_p: Mapping[Any, Any], /) -> dict[Any, Any]:
    retval: dict[Any, Any] = {}
    for _k, _v in _p.items():
        retval |= {_k: _dict_from_mapping(_v)} if isinstance(_v, Mapping) else {_k: _v}
    return retval


def _mappingproxy_from_mapping(_p: Mapping[Any, Any], /) -> MappingProxyType[Any, Any]:
    retval: dict[Any, Any] = {}
    for _k, _v in _p.items():
        retval |= (
            {_k: _mappingproxy_from_mapping(_v)}
            if isinstance(_v, Mapping)
            else {_k: _v}
        )
    return MappingProxyType(retval)
