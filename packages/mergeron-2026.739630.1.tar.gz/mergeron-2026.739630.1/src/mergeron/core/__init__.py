"""Constants, types, objects and functions used within this sub-package."""

from ..types_and_constants import VERSION

__version__ = VERSION
