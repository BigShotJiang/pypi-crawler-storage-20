"""Defines constants, specifications and containers for industry data generation and testing."""

from ..types_and_constants import VERSION

__version__ = VERSION
