from .session import Session as _Session


def Session(partner_id, partner_key, shop_id=None, region='sg'):
    return _Session(
        partner_id=partner_id,
        partner_key=partner_key,
        shop_id=shop_id,
        region=region
    )


__all__ = ['Session']
