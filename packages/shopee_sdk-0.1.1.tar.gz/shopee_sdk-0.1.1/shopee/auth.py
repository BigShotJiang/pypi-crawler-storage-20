import time
from .credentials import Credentials
from .exceptions import TokenExpiredError, InvalidCredentialsError


class AuthHandler:
    def __init__(self, credentials):
        self.credentials = credentials

    def is_authenticated(self):
        return self.credentials.get_access_token() is not None

    def requires_authentication(self):
        return not self.is_authenticated()

    def get_access_token(self):
        if self.credentials.is_token_expired():
            raise TokenExpiredError("Access token has expired")
        return self.credentials.get_access_token()

    def set_tokens(self, access_token, refresh_token=None, expires_in=None):
        self.credentials.set_access_token(access_token, refresh_token, expires_in)

    def clear_tokens(self):
        self.credentials.access_token = None
        self.credentials.refresh_token = None
        self.credentials.token_expires_at = None
