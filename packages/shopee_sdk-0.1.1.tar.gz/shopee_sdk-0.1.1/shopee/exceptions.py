class ShopeeSDKError(Exception):
    pass


class AuthenticationError(ShopeeSDKError):
    pass


class TokenExpiredError(AuthenticationError):
    pass


class InvalidCredentialsError(AuthenticationError):
    pass


class APIError(ShopeeSDKError):
    def __init__(self, message, status_code=None, response=None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class ClientError(APIError):
    pass


class ServerError(APIError):
    pass


class RateLimitError(APIError):
    pass


class ValidationError(ShopeeSDKError):
    pass


class ConfigurationError(ShopeeSDKError):
    pass
