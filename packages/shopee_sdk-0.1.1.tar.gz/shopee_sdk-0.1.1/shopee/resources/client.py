class ServiceResource:
    def __init__(self, session, service_name):
        self.session = session
        self._client = session.client(service_name)

    @property
    def client(self):
        return self._client
