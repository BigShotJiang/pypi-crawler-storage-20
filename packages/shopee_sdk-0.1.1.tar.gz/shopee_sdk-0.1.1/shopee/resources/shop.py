from .client import ServiceResource


class ShopResource(ServiceResource):
    def __init__(self, session):
        super().__init__(session, 'shop')

    def get_info(self, **kwargs):
        return self.client.get_shop_info(**kwargs)

    def get_profile(self, **kwargs):
        return self.client.get_profile(**kwargs)

    def update_profile(self, **kwargs):
        return self.client.update_profile(**kwargs)
