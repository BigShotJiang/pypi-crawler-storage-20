from .client import ServiceResource


class OrderResource(ServiceResource):
    def __init__(self, session):
        super().__init__(session, 'order')

    def all(self, **kwargs):
        return self.client.get_order_list(**kwargs)

    def get(self, order_sn, **kwargs):
        kwargs['order_sn'] = order_sn
        return self.client.get_order_detail(**kwargs)

    def cancel(self, order_sn, **kwargs):
        kwargs['order_sn'] = order_sn
        return self.client.cancel_order(**kwargs)

    def get_packages(self, **kwargs):
        return self.client.search_package_list(**kwargs)

    def get_package(self, package_number, **kwargs):
        kwargs['package_number'] = package_number
        return self.client.get_package_detail(**kwargs)
