from .base import BaseResource
from .client import ServiceResource
from .product import ProductResource
from .order import OrderResource
from .shop import ShopResource

RESOURCE_MAPPING = {
    'product': ProductResource,
    'order': OrderResource,
    'shop': ShopResource,
}


def get_resource(session, resource_name):
    resource_class = RESOURCE_MAPPING.get(resource_name.lower())
    if not resource_class:
        raise ValueError(f"Unknown resource: {resource_name}")
    return resource_class(session)


__all__ = [
    'BaseResource',
    'ServiceResource',
    'ProductResource',
    'OrderResource',
    'ShopResource',
    'get_resource',
]
