from .client import ServiceResource


class ProductResource(ServiceResource):
    def __init__(self, session):
        super().__init__(session, 'product')

    def all(self, **kwargs):
        return self.client.get_item_list(**kwargs)

    def get(self, item_id, **kwargs):
        kwargs['item_id'] = item_id
        return self.client.get_item_base_info(**kwargs)

    def create(self, **kwargs):
        return self.client.add_item(**kwargs)

    def update(self, item_id, **kwargs):
        kwargs['item_id'] = item_id
        return self.client.update_item(**kwargs)

    def delete(self, item_id, **kwargs):
        kwargs['item_id'] = item_id
        return self.client.delete_item(**kwargs)

    def update_price(self, item_id, price, **kwargs):
        kwargs['item_id'] = item_id
        kwargs['price'] = price
        return self.client.update_price(**kwargs)

    def update_stock(self, item_id, stock, **kwargs):
        kwargs['item_id'] = item_id
        kwargs['stock'] = stock
        return self.client.update_stock(**kwargs)
