from .client import ServiceResource


class BaseResource:
    def __init__(self, session):
        self.session = session
        self._client = None

    @property
    def client(self):
        return self._client
