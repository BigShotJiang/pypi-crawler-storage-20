class Credentials:
    def __init__(self, partner_id, partner_key, shop_id=None):
        self.partner_id = partner_id
        self.partner_key = partner_key
        self.shop_id = shop_id
        self.access_token = None
        self.refresh_token = None
        self.token_expires_at = None

    def get_partner_id(self):
        return self.partner_id

    def get_partner_key(self):
        return self.partner_key

    def get_shop_id(self):
        return self.shop_id

    def get_access_token(self):
        return self.access_token

    def set_access_token(self, access_token, refresh_token=None, expires_in=None):
        self.access_token = access_token
        self.refresh_token = refresh_token
        self.token_expires_at = expires_in

    def get_refresh_token(self):
        return self.refresh_token

    def is_token_expired(self):
        if not self.token_expires_at:
            return False
        return self.token_expires_at <= 0
