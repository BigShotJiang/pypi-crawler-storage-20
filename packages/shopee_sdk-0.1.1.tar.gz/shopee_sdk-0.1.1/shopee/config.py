import os


class Config:
    DEFAULT_BASE_URL = "https://partner.shopeemobile.com"
    DEFAULT_TIMEOUT = 30
    DEFAULT_MAX_RETRIES = 3
    DEFAULT_USER_AGENT = "shopee-sdk-python/1.0.0"

    def __init__(self, base_url=None, timeout=None, max_retries=None, user_agent=None):
        self.base_url = base_url or self.DEFAULT_BASE_URL
        self.timeout = timeout or self.DEFAULT_TIMEOUT
        self.max_retries = max_retries or self.DEFAULT_MAX_RETRIES
        self.user_agent = user_agent or self.DEFAULT_USER_AGENT

    @classmethod
    def from_env(cls):
        return cls(
            base_url=os.getenv('SHOPEE_BASE_URL', cls.DEFAULT_BASE_URL),
            timeout=int(os.getenv('SHOPEE_TIMEOUT', cls.DEFAULT_TIMEOUT)),
            max_retries=int(os.getenv('SHOPEE_MAX_RETRIES', cls.DEFAULT_MAX_RETRIES)),
            user_agent=os.getenv('SHOPEE_USER_AGENT', cls.DEFAULT_USER_AGENT)
        )
