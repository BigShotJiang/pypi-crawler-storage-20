from .credentials import Credentials
from .config import Config
from .auth import AuthHandler
from .exceptions import ConfigurationError


class Session:
    def __init__(self, partner_id=None, partner_key=None, shop_id=None, config=None, region='sg'):
        if not partner_id or not partner_key:
            raise ConfigurationError("partner_id and partner_key are required")

        self.credentials = Credentials(
            partner_id=partner_id,
            partner_key=partner_key,
            shop_id=shop_id
        )
        
        self.config = config or Config()
        self.region = region
        self.auth_handler = AuthHandler(self.credentials)

    def get_credentials(self):
        return self.credentials

    def get_config(self):
        return self.config

    def client(self, service_name):
        from .services import get_client
        return get_client(self, service_name)

    def resource(self, resource_name):
        from .resources import get_resource
        return get_resource(self, resource_name)

    def get_region(self):
        return self.region
