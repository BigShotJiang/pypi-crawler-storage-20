from .base import BaseService


class VideoService(BaseService):
    def get_cover_list(self, **kwargs):
        return self._make_request('/api/v2/video/cover/get_list', 'GET', params=kwargs)

    def edit_video_info(self, **kwargs):
        return self._make_request('/api/v2/video/update', 'POST', data=kwargs)

    def post_video(self, **kwargs):
        return self._make_request('/api/v2/video/upload', 'POST', data=kwargs)

    def get_video_list(self, **kwargs):
        return self._make_request('/api/v2/video/get_list', 'GET', params=kwargs)

    def get_video_detail(self, **kwargs):
        return self._make_request('/api/v2/video/get_detail', 'GET', params=kwargs)

    def delete_video(self, **kwargs):
        return self._make_request('/api/v2/video/delete', 'POST', data=kwargs)

    def get_overview_performance(self, **kwargs):
        return self._make_request('/api/v2/video/performance/overview', 'GET', params=kwargs)

    def get_metric_trend(self, **kwargs):
        return self._make_request('/api/v2/video/performance/metric_trend', 'GET', params=kwargs)

    def get_user_demographics(self, **kwargs):
        return self._make_request('/api/v2/video/performance/demographic', 'GET', params=kwargs)

    def get_video_performance_list(self, **kwargs):
        return self._make_request('/api/v2/video/performance/list', 'GET', params=kwargs)

    def get_prodcut_performance_list(self, **kwargs):
        return self._make_request('/api/v2/video/performance/product_list', 'GET', params=kwargs)

    def get_video_detail_performance(self, **kwargs):
        return self._make_request('/api/v2/video/performance/detail', 'GET', params=kwargs)

    def get_video_detail_metric_trend(self, **kwargs):
        return self._make_request('/api/v2/video/performance/detail_metric_trend', 'GET', params=kwargs)

    def get_video_detail_audience_distribution(self, **kwargs):
        return self._make_request('/api/v2/video/performance/detail_audience_distribution', 'GET', params=kwargs)

    def get_video_detail_product_performance(self, **kwargs):
        return self._make_request('/api/v2/video/performance/detail_product_performance', 'GET', params=kwargs)
