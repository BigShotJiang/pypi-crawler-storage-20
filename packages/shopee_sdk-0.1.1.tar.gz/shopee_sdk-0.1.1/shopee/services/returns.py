from .base import BaseService


class ReturnsService(BaseService):
    def get_return_list(self, **kwargs):
        return self._make_request('/api/v2/returns/get_return_list', 'GET', params=kwargs)

    def get_return_detail(self, **kwargs):
        return self._make_request('/api/v2/returns/get_return_detail', 'GET', params=kwargs)

    def confirm(self, **kwargs):
        return self._make_request('/api/v2/returns/confirm', 'POST', data=kwargs)

    def dispute(self, **kwargs):
        return self._make_request('/api/v2/returns/dispute', 'POST', data=kwargs)

    def get_available_solutions(self, **kwargs):
        return self._make_request('/api/v2/returns/get_available_solutions', 'GET', params=kwargs)

    def offer(self, **kwargs):
        return self._make_request('/api/v2/returns/offer', 'POST', data=kwargs)

    def accept_offer(self, **kwargs):
        return self._make_request('/api/v2/returns/accept_offer', 'POST', data=kwargs)

    def convert_image(self, **kwargs):
        return self._make_request('/api/v2/returns/convert_image', 'POST', data=kwargs, files=kwargs.get('files'))

    def upload_proof(self, **kwargs):
        return self._make_request('/api/v2/returns/upload_proof', 'POST', data=kwargs, files=kwargs.get('files'))

    def query_proof(self, **kwargs):
        return self._make_request('/api/v2/returns/query_proof', 'GET', params=kwargs)

    def get_return_dispute_reason(self, **kwargs):
        return self._make_request('/api/v2/returns/get_return_dispute_reason', 'GET', params=kwargs)

    def cancel_dispute(self, **kwargs):
        return self._make_request('/api/v2/returns/cancel_dispute', 'POST', data=kwargs)

    def get_shipping_carrier(self, **kwargs):
        return self._make_request('/api/v2/returns/get_shipping_carrier', 'GET', params=kwargs)

    def upload_shipping_proof(self, **kwargs):
        return self._make_request('/api/v2/returns/upload_shipping_proof', 'POST', data=kwargs, files=kwargs.get('files'))

    def get_reverse_tracking_info(self, **kwargs):
        return self._make_request('/api/v2/returns/get_reverse_tracking_info', 'GET', params=kwargs)
