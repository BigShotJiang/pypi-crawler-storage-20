from .base import BaseService


class FollowPrizeService(BaseService):
    def add_follow_prize(self, **kwargs):
        return self._make_request('/api/v2/marketing/add_follow_prize', 'POST', data=kwargs)

    def delete_follow_prize(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_follow_prize', 'POST', data=kwargs)

    def end_follow_prize(self, **kwargs):
        return self._make_request('/api/v2/marketing/end_follow_prize', 'POST', data=kwargs)

    def update_follow_prize(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_follow_prize', 'POST', data=kwargs)

    def get_follow_prize_detail(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_follow_prize_detail', 'GET', params=kwargs)

    def get_follow_prize_list(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_follow_prize_list', 'GET', params=kwargs)
