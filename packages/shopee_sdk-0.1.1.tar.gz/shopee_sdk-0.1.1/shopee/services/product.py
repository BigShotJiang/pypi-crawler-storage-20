from .base import BaseService


class ProductService(BaseService):
    def get_category(self, **kwargs):
        return self._make_request('/api/v2/product/get_category_list', 'GET', params=kwargs)

    def get_attribute_tree(self, **kwargs):
        return self._make_request('/api/v2/product/attributes/get', 'GET', params=kwargs)

    def get_brand_list(self, **kwargs):
        return self._make_request('/api/v2/product/get_brand_list', 'GET', params=kwargs)

    def get_item_limit(self, **kwargs):
        return self._make_request('/api/v2/product/get_item_limit', 'GET', params=kwargs)

    def get_item_list(self, **kwargs):
        return self._make_request('/api/v2/product/get_item_list', 'GET', params=kwargs)

    def get_item_base_info(self, **kwargs):
        return self._make_request('/api/v2/product/get_item_base_info', 'GET', params=kwargs)

    def get_item_extra_info(self, **kwargs):
        return self._make_request('/api/v2/product/get_item_extra_info', 'GET', params=kwargs)

    def add_item(self, **kwargs):
        return self._make_request('/api/v2/product/add_item', 'POST', data=kwargs)

    def update_item(self, **kwargs):
        return self._make_request('/api/v2/product/update_item', 'POST', data=kwargs)

    def delete_item(self, **kwargs):
        return self._make_request('/api/v2/product/delete_item', 'POST', data=kwargs)

    def init_tier_variation(self, **kwargs):
        return self._make_request('/api/v2/product/init_tier_variation', 'POST', data=kwargs)

    def update_tier_variation(self, **kwargs):
        return self._make_request('/api/v2/product/update_tier_variation', 'POST', data=kwargs)

    def get_model_list(self, **kwargs):
        return self._make_request('/api/v2/product/get_model_list', 'GET', params=kwargs)

    def add_model(self, **kwargs):
        return self._make_request('/api/v2/product/add_model', 'POST', data=kwargs)

    def update_model(self, **kwargs):
        return self._make_request('/api/v2/product/update_model', 'POST', data=kwargs)

    def delete_model(self, **kwargs):
        return self._make_request('/api/v2/product/delete_model', 'POST', data=kwargs)

    def unlist_item(self, **kwargs):
        return self._make_request('/api/v2/product/unlist_item', 'POST', data=kwargs)

    def update_price(self, **kwargs):
        return self._make_request('/api/v2/product/update_price', 'POST', data=kwargs)

    def update_stock(self, **kwargs):
        return self._make_request('/api/v2/product/update_stock', 'POST', data=kwargs)

    def boost_item(self, **kwargs):
        return self._make_request('/api/v2/product/boost_item', 'POST', data=kwargs)

    def get_boosted_list(self, **kwargs):
        return self._make_request('/api/v2/product/get_boosted_list', 'GET', params=kwargs)

    def get_item_promotion(self, **kwargs):
        return self._make_request('/api/v2/product/get_item_promotion', 'GET', params=kwargs)

    def update_sip_item_price(self, **kwargs):
        return self._make_request('/api/v2/product/update_sip_item_price', 'POST', data=kwargs)

    def search_item(self, **kwargs):
        return self._make_request('/api/v2/product/search_item', 'GET', params=kwargs)

    def get_comment(self, **kwargs):
        return self._make_request('/api/v2/product/comment/get', 'GET', params=kwargs)

    def reply_comment(self, **kwargs):
        return self._make_request('/api/v2/product/comment/reply', 'POST', data=kwargs)

    def category_recommend(self, **kwargs):
        return self._make_request('/api/v2/product/category/recommend', 'GET', params=kwargs)

    def register_brand(self, **kwargs):
        return self._make_request('/api/v2/product/register_brand', 'POST', data=kwargs)

    def get_recommend_attribute(self, **kwargs):
        return self._make_request('/api/v2/product/attribute/recommend', 'GET', params=kwargs)

    def get_weight_recommendation(self, **kwargs):
        return self._make_request('/api/v2/product/weight/recommend', 'GET', params=kwargs)

    def get_size_chart_list(self, **kwargs):
        return self._make_request('/api/v2/product/size_chart/list', 'GET', params=kwargs)

    def get_size_chart_detail(self, **kwargs):
        return self._make_request('/api/v2/product/size_chart/detail', 'GET', params=kwargs)

    def get_item_violation_info(self, **kwargs):
        return self._make_request('/api/v2/product/item_violation/get', 'GET', params=kwargs)

    def get_variations(self, **kwargs):
        return self._make_request('/api/v2/product/get_variations', 'GET', params=kwargs)

    def get_all_vehicle_list(self, **kwargs):
        return self._make_request('/api/v2/product/get_all_vehicle_list', 'GET', params=kwargs)

    def get_vehicle_list_by_compatibility_detail(self, **kwargs):
        return self._make_request('/api/v2/product/get_vehicle_list', 'GET', params=kwargs)

    def get_item_content_diagnosis_result(self, **kwargs):
        return self._make_request('/api/v2/product/content_diagnosis/get', 'GET', params=kwargs)

    def get_item_list_by_content_diagnosis(self, **kwargs):
        return self._make_request('/api/v2/product/content_diagnosis/list', 'GET', params=kwargs)

    def get_kit_item_limit(self, **kwargs):
        return self._make_request('/api/v2/product/kit/get_limit', 'GET', params=kwargs)

    def add_kit_item(self, **kwargs):
        return self._make_request('/api/v2/product/kit/add', 'POST', data=kwargs)

    def update_kit_item(self, **kwargs):
        return self._make_request('/api/v2/product/kit/update', 'POST', data=kwargs)

    def get_kit_item_info(self, **kwargs):
        return self._make_request('/api/v2/product/kit/get', 'GET', params=kwargs)

    def get_ssp_list(self, **kwargs):
        return self._make_request('/api/v2/product/ssp/list', 'GET', params=kwargs)

    def get_ssp_info(self, **kwargs):
        return self._make_request('/api/v2/product/ssp/info', 'GET', params=kwargs)

    def add_ssp_item(self, **kwargs):
        return self._make_request('/api/v2/product/ssp/add', 'POST', data=kwargs)

    def link_ssp(self, **kwargs):
        return self._make_request('/api/v2/product/ssp/link', 'POST', data=kwargs)

    def unlink_ssp(self, **kwargs):
        return self._make_request('/api/v2/product/ssp/unlink', 'POST', data=kwargs)

    def get_aitem_by_pitem_id(self, **kwargs):
        return self._make_request('/api/v2/product/get_aitem_by_pitem', 'GET', params=kwargs)

    def search_attribute_value_list(self, **kwargs):
        return self._make_request('/api/v2/product/attribute_value/search', 'GET', params=kwargs)

    def get_main_item_list(self, **kwargs):
        return self._make_request('/api/v2/product/main/get_item_list', 'GET', params=kwargs)

    def get_direct_item_list(self, **kwargs):
        return self._make_request('/api/v2/product/direct/get_item_list', 'GET', params=kwargs)

    def get_direct_shop_recommended_price(self, **kwargs):
        return self._make_request('/api/v2/product/direct/recommended_price', 'GET', params=kwargs)

    def get_product_certification_rule(self, **kwargs):
        return self._make_request('/api/v2/product/certification/get_rule', 'GET', params=kwargs)

    def publish_item_to_outlet_shop(self, **kwargs):
        return self._make_request('/api/v2/product/outlet/publish', 'POST', data=kwargs)

    def get_mart_item_mapping_by_id(self, **kwargs):
        return self._make_request('/api/v2/product/mart/get_mapping', 'GET', params=kwargs)

    def search_unpackaged_model_list(self, **kwargs):
        return self._make_request('/api/v2/product/unpackaged_model/search', 'GET', params=kwargs)

    def generate_kit_image(self, **kwargs):
        return self._make_request('/api/v2/product/kit/image/generate', 'POST', data=kwargs)
