from .base import BaseService


class AdsService(BaseService):
    def get_total_balance(self, **kwargs):
        return self._make_request('/api/v2/ads/get_total_balance', 'GET', params=kwargs)

    def get_shop_toggle_info(self, **kwargs):
        return self._make_request('/api/v2/ads/get_shop_toggle_info', 'GET', params=kwargs)

    def get_recommended_keyword_list(self, **kwargs):
        return self._make_request('/api/v2/ads/get_recommended_keyword_list', 'GET', params=kwargs)

    def get_recommended_item_list(self, **kwargs):
        return self._make_request('/api/v2/ads/get_recommended_item_list', 'GET', params=kwargs)

    def get_all_cpc_ads_hourly_performance(self, **kwargs):
        return self._make_request('/api/v2/ads/get_all_cpc_ads_hourly_performance', 'GET', params=kwargs)

    def get_all_cpc_ads_daily_performance(self, **kwargs):
        return self._make_request('/api/v2/ads/get_all_cpc_ads_daily_performance', 'GET', params=kwargs)

    def create_auto_product_ads(self, **kwargs):
        return self._make_request('/api/v2/ads/create_auto_product_ads', 'POST', data=kwargs)

    def edit_auto_product_ads(self, **kwargs):
        return self._make_request('/api/v2/ads/edit_auto_product_ads', 'POST', data=kwargs)

    def get_product_campaign_daily_performance(self, **kwargs):
        return self._make_request('/api/v2/ads/get_product_campaign_daily_performance', 'GET', params=kwargs)

    def get_product_campaign_hourly_performance(self, **kwargs):
        return self._make_request('/api/v2/ads/get_product_campaign_hourly_performance', 'GET', params=kwargs)

    def get_product_level_campaign_id_list(self, **kwargs):
        return self._make_request('/api/v2/ads/get_product_level_campaign_id_list', 'GET', params=kwargs)

    def get_product_level_campaign_setting_info(self, **kwargs):
        return self._make_request('/api/v2/ads/get_product_level_campaign_setting_info', 'GET', params=kwargs)

    def create_manual_product_ads(self, **kwargs):
        return self._make_request('/api/v2/ads/create_manual_product_ads', 'POST', data=kwargs)

    def edit_manual_product_ad_keywords(self, **kwargs):
        return self._make_request('/api/v2/ads/edit_manual_product_ad_keywords', 'POST', data=kwargs)

    def edit_manual_product_ads(self, **kwargs):
        return self._make_request('/api/v2/ads/edit_manual_product_ads', 'POST', data=kwargs)

    def get_create_product_ad_budget_suggestion(self, **kwargs):
        return self._make_request('/api/v2/ads/get_create_product_ad_budget_suggestion', 'GET', params=kwargs)

    def get_product_recommended_roi_target(self, **kwargs):
        return self._make_request('/api/v2/ads/get_product_recommended_roi_target', 'GET', params=kwargs)

    def get_ads_facil_shop_rate(self, **kwargs):
        return self._make_request('/api/v2/ads/get_ads_facil_shop_rate', 'GET', params=kwargs)

    def check_create_gms_product_campaign_eligibility(self, **kwargs):
        return self._make_request('/api/v2/ads/check_create_gms_product_campaign_eligibility', 'GET', params=kwargs)

    def create_gms_product_campaign(self, **kwargs):
        return self._make_request('/api/v2/ads/create_gms_product_campaign', 'POST', data=kwargs)

    def edit_gms_product_campaign(self, **kwargs):
        return self._make_request('/api/v2/ads/edit_gms_product_campaign', 'POST', data=kwargs)

    def list_gms_user_deleted_item(self, **kwargs):
        return self._make_request('/api/v2/ads/list_gms_user_deleted_item', 'GET', params=kwargs)

    def edit_gms_item_product_campaign(self, **kwargs):
        return self._make_request('/api/v2/ads/edit_gms_item_product_campaign', 'POST', data=kwargs)

    def get_gms_campaign_performance(self, **kwargs):
        return self._make_request('/api/v2/ads/get_gms_campaign_performance', 'GET', params=kwargs)

    def get_gms_item_performance(self, **kwargs):
        return self._make_request('/api/v2/ads/get_gms_item_performance', 'GET', params=kwargs)
