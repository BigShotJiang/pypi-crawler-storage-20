from .base import BaseService


class AddOnDealService(BaseService):
    def add_add_on_deal(self, **kwargs):
        return self._make_request('/api/v2/marketing/add_add_on_deal', 'POST', data=kwargs)

    def add_add_on_deal_main_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/add_add_on_deal_main_item', 'POST', data=kwargs)

    def add_add_on_deal_sub_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/add_add_on_deal_sub_item', 'POST', data=kwargs)

    def delete_add_on_deal(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_add_on_deal', 'POST', data=kwargs)

    def delete_add_on_deal_main_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_add_on_deal_main_item', 'POST', data=kwargs)

    def delete_add_on_deal_sub_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_add_on_deal_sub_item', 'POST', data=kwargs)

    def get_add_on_deal_list(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_add_on_deal_list', 'GET', params=kwargs)

    def get_add_on_deal(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_add_on_deal', 'GET', params=kwargs)

    def get_add_on_deal_main_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_add_on_deal_main_item', 'GET', params=kwargs)

    def get_add_on_deal_sub_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_add_on_deal_sub_item', 'GET', params=kwargs)

    def update_add_on_deal(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_add_on_deal', 'POST', data=kwargs)

    def update_add_on_deal_main_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_add_on_deal_main_item', 'POST', data=kwargs)

    def update_add_on_deal_sub_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_add_on_deal_sub_item', 'POST', data=kwargs)

    def end_add_on_deal(self, **kwargs):
        return self._make_request('/api/v2/marketing/end_add_on_deal', 'POST', data=kwargs)
