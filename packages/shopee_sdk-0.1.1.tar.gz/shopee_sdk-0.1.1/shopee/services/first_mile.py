from .base import BaseService


class FirstMileService(BaseService):
    def get_unbind_order_list(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/get_unbind_order_list', 'GET', params=kwargs)

    def get_detail(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/get_detail', 'GET', params=kwargs)

    def generate_first_mile_tracking_number(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/generate_tracking_number', 'POST', data=kwargs)

    def bind_first_mile_tracking_number(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/bind_tracking_number', 'POST', data=kwargs)

    def unbind_first_mile_tracking_number(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/unbind_tracking_number', 'POST', data=kwargs)

    def get_tracking_number_list(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/get_tracking_number_list', 'GET', params=kwargs)

    def get_waybill(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/get_waybill', 'GET', params=kwargs)

    def get_channel_list(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/get_channel_list', 'GET', params=kwargs)

    def get_courier_delivery_channel_list(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/get_courier_delivery_channel_list', 'GET', params=kwargs)

    def get_transit_warehouse_list(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/get_transit_warehouse_list', 'GET', params=kwargs)

    def generate_and_bind_first_mile_tracking_number(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/generate_and_bind_tracking_number', 'POST', data=kwargs)

    def bind_courier_delivery_first_mile_tracking_number(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/bind_courier_delivery_tracking_number', 'POST', data=kwargs)

    def unbind_first_mile_tracking_number_all(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/unbind_tracking_number_all', 'POST', data=kwargs)

    def get_courier_delivery_detail(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/get_courier_delivery_detail', 'GET', params=kwargs)

    def get_courier_delivery_waybill(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/get_courier_delivery_waybill', 'GET', params=kwargs)

    def get_courier_delivery_tracking_number_list(self, **kwargs):
        return self._make_request('/api/v2/logistics/first_mile/get_courier_delivery_tracking_number_list', 'GET', params=kwargs)
