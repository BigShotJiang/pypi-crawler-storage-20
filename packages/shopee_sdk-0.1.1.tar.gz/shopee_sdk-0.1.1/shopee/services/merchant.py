from .base import BaseService


class MerchantService(BaseService):
    def get_merchant_info(self, **kwargs):
        return self._make_request('/api/v2/merchant/get_merchant_info', 'GET', params=kwargs)

    def get_shop_list_by_merchant(self, **kwargs):
        return self._make_request('/api/v2/merchant/get_shop_list', 'GET', params=kwargs)

    def get_merchant_warehouse_location_list(self, **kwargs):
        return self._make_request('/api/v2/merchant/get_warehouse_location_list', 'GET', params=kwargs)

    def get_merchant_warehouse_list(self, **kwargs):
        return self._make_request('/api/v2/merchant/get_warehouse_list', 'GET', params=kwargs)

    def get_warehouse_eligible_shop_list(self, **kwargs):
        return self._make_request('/api/v2/merchant/get_warehouse_eligible_shop_list', 'GET', params=kwargs)

    def get_merchant_prepaid_account_list(self, **kwargs):
        return self._make_request('/api/v2/merchant/get_prepaid_account_list', 'GET', params=kwargs)
