from .base import BaseService


class MediaService(BaseService):
    def upload_image(self, **kwargs):
        return self._make_request('/api/v2/media/upload_image', 'POST', data=kwargs, files=kwargs.get('files'))

    def init_video_upload(self, **kwargs):
        return self._make_request('/api/v2/media/init_video_upload', 'POST', data=kwargs)

    def upload_video_part(self, **kwargs):
        return self._make_request('/api/v2/media/upload_video_part', 'POST', data=kwargs, files=kwargs.get('files'))

    def complete_video_upload(self, **kwargs):
        return self._make_request('/api/v2/media/complete_video_upload', 'POST', data=kwargs)

    def get_video_upload_result(self, **kwargs):
        return self._make_request('/api/v2/media/get_video_upload_result', 'GET', params=kwargs)

    def cancel_video_upload(self, **kwargs):
        return self._make_request('/api/v2/media/cancel_video_upload', 'POST', data=kwargs)
