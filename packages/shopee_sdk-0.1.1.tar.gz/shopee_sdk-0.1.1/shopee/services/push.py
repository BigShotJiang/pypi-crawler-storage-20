from .base import BaseService


class PushService(BaseService):
    def set_app_push_config(self, **kwargs):
        return self._make_request('/api/v2/push/set_app_push_config', 'POST', data=kwargs)

    def get_app_push_config(self, **kwargs):
        return self._make_request('/api/v2/push/get_app_push_config', 'GET', params=kwargs)

    def get_lost_push_message(self, **kwargs):
        return self._make_request('/api/v2/push/get_lost_push_message', 'GET', params=kwargs)

    def confirm_consumed_lost_push_message(self, **kwargs):
        return self._make_request('/api/v2/push/confirm_consumed_lost_push_message', 'POST', data=kwargs)
