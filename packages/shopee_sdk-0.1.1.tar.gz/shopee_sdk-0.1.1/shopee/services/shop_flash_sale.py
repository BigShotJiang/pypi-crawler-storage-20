from .base import BaseService


class ShopFlashSaleService(BaseService):
    def get_time_slot_id(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_time_slot_id', 'GET', params=kwargs)

    def create_shop_flash_sale(self, **kwargs):
        return self._make_request('/api/v2/marketing/create_shop_flash_sale', 'POST', data=kwargs)

    def get_item_criteria(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_item_criteria', 'GET', params=kwargs)

    def add_shop_flash_sale_items(self, **kwargs):
        return self._make_request('/api/v2/marketing/add_shop_flash_sale_items', 'POST', data=kwargs)

    def get_shop_flash_sale_list(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_shop_flash_sale_list', 'GET', params=kwargs)

    def get_shop_flash_sale(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_shop_flash_sale', 'GET', params=kwargs)

    def get_shop_flash_sale_items(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_shop_flash_sale_items', 'GET', params=kwargs)

    def update_shop_flash_sale(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_shop_flash_sale', 'POST', data=kwargs)

    def update_shop_flash_sale_items(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_shop_flash_sale_items', 'POST', data=kwargs)

    def delete_shop_flash_sale(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_shop_flash_sale', 'POST', data=kwargs)

    def delete_shop_flash_sale_items(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_shop_flash_sale_items', 'POST', data=kwargs)
