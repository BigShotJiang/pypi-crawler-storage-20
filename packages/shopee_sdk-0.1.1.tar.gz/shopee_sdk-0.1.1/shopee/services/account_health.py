from .base import BaseService


class AccountHealthService(BaseService):
    def get_shop_performance(self, **kwargs):
        return self._make_request('/api/v2/account_health/get_shop_performance', 'GET', params=kwargs)

    def get_metric_source_detail(self, **kwargs):
        return self._make_request('/api/v2/account_health/get_metric_source_detail', 'GET', params=kwargs)

    def get_penalty_point_history(self, **kwargs):
        return self._make_request('/api/v2/account_health/get_penalty_point_history', 'GET', params=kwargs)

    def get_punishment_history(self, **kwargs):
        return self._make_request('/api/v2/account_health/get_punishment_history', 'GET', params=kwargs)

    def get_listings_with_issues(self, **kwargs):
        return self._make_request('/api/v2/account_health/get_listings_with_issues', 'GET', params=kwargs)

    def get_late_orders(self, **kwargs):
        return self._make_request('/api/v2/account_health/get_late_orders', 'GET', params=kwargs)
