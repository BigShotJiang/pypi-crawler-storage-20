from .base import BaseService


class TopPicksService(BaseService):
    def get_top_picks_list(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_top_picks_list', 'GET', params=kwargs)

    def add_top_picks(self, **kwargs):
        return self._make_request('/api/v2/marketing/add_top_picks', 'POST', data=kwargs)

    def update_top_picks(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_top_picks', 'POST', data=kwargs)

    def delete_top_picks(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_top_picks', 'POST', data=kwargs)
