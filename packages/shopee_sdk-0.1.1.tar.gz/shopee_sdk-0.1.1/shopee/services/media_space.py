from .base import BaseService


class MediaSpaceService(BaseService):
    def init_video_upload(self, **kwargs):
        return self._make_request('/api/v2/media_space/init_video_upload', 'POST', data=kwargs)

    def upload_video_part(self, **kwargs):
        return self._make_request('/api/v2/media_space/upload_video_part', 'POST', data=kwargs, files=kwargs.get('files'))

    def complete_video_upload(self, **kwargs):
        return self._make_request('/api/v2/media_space/complete_video_upload', 'POST', data=kwargs)

    def get_video_upload_result(self, **kwargs):
        return self._make_request('/api/v2/media_space/get_video_upload_result', 'GET', params=kwargs)

    def cancel_video_upload(self, **kwargs):
        return self._make_request('/api/v2/media_space/cancel_video_upload', 'POST', data=kwargs)

    def upload_image(self, **kwargs):
        return self._make_request('/api/v2/media_space/upload_image', 'POST', data=kwargs, files=kwargs.get('files'))
