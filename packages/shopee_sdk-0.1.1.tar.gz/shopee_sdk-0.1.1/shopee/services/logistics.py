from .base import BaseService


class LogisticsService(BaseService):
    def get_shipping_parameter(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_shipping_parameter', 'POST', data=kwargs)

    def get_mass_shipping_parameter(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_mass_shipping_parameter', 'POST', data=kwargs)

    def ship_order(self, **kwargs):
        return self._make_request('/api/v2/logistics/ship_order', 'POST', data=kwargs)

    def mass_ship_order(self, **kwargs):
        return self._make_request('/api/v2/logistics/mass_ship_order', 'POST', data=kwargs)

    def update_shipping_order(self, **kwargs):
        return self._make_request('/api/v2/logistics/update_shipping_order', 'POST', data=kwargs)

    def get_tracking_number(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_tracking_number', 'GET', params=kwargs)

    def get_mass_tracking_number(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_mass_tracking_number', 'POST', data=kwargs)

    def get_shipping_document_parameter(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_shipping_document_parameter', 'POST', data=kwargs)

    def create_shipping_document(self, **kwargs):
        return self._make_request('/api/v2/logistics/create_shipping_document', 'POST', data=kwargs)

    def get_shipping_document_result(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_shipping_document_result', 'GET', params=kwargs)

    def download_shipping_document(self, **kwargs):
        return self._make_request('/api/v2/logistics/download_shipping_document', 'GET', params=kwargs)

    def get_shipping_document_data_info(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_shipping_document_data_info', 'GET', params=kwargs)

    def get_tracking_info(self, **kwargs):
        return self._make_request('/api/v2/logistics/tracking/get_tracking_info', 'GET', params=kwargs)

    def get_address_list(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_address_list', 'GET', params=kwargs)

    def set_address_config(self, **kwargs):
        return self._make_request('/api/v2/logistics/set_address_config', 'POST', data=kwargs)

    def update_address(self, **kwargs):
        return self._make_request('/api/v2/logistics/update_address', 'POST', data=kwargs)

    def delete_address(self, **kwargs):
        return self._make_request('/api/v2/logistics/delete_address', 'POST', data=kwargs)

    def get_channel_list(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_channel_list', 'GET', params=kwargs)

    def update_channel(self, **kwargs):
        return self._make_request('/api/v2/logistics/update_channel', 'POST', data=kwargs)

    def get_operating_hours(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_operating_hours', 'GET', params=kwargs)

    def get_operating_hour_restrictions(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_operating_hour_restrictions', 'GET', params=kwargs)

    def update_operating_hours(self, **kwargs):
        return self._make_request('/api/v2/logistics/update_operating_hours', 'POST', data=kwargs)

    def delete_special_operating_hour(self, **kwargs):
        return self._make_request('/api/v2/logistics/delete_special_operating_hour', 'POST', data=kwargs)

    def batch_update_tpf_warehouse_tracking_status(self, **kwargs):
        return self._make_request('/api/v2/logistics/batch_update_tpf_warehouse_tracking_status', 'POST', data=kwargs)

    def batch_ship_order(self, **kwargs):
        return self._make_request('/api/v2/logistics/batch_ship_order', 'POST', data=kwargs)

    def update_tracking_status(self, **kwargs):
        return self._make_request('/api/v2/logistics/update_tracking_status', 'POST', data=kwargs)

    def get_booking_shipping_parameter(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_booking_shipping_parameter', 'POST', data=kwargs)

    def ship_booking(self, **kwargs):
        return self._make_request('/api/v2/logistics/ship_booking', 'POST', data=kwargs)

    def get_booking_tracking_number(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_booking_tracking_number', 'GET', params=kwargs)

    def get_booking_shipping_document_parameter(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_booking_shipping_document_parameter', 'POST', data=kwargs)

    def create_booking_shipping_document(self, **kwargs):
        return self._make_request('/api/v2/logistics/create_booking_shipping_document', 'POST', data=kwargs)

    def get_booking_shipping_document_result(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_booking_shipping_document_result', 'GET', params=kwargs)

    def download_booking_shipping_document(self, **kwargs):
        return self._make_request('/api/v2/logistics/download_booking_shipping_document', 'GET', params=kwargs)

    def get_booking_shipping_document_data_info(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_booking_shipping_document_data_info', 'GET', params=kwargs)

    def get_booking_tracking_info(self, **kwargs):
        return self._make_request('/api/v2/logistics/tracking/get_booking_tracking_info', 'GET', params=kwargs)

    def download_to_label(self, **kwargs):
        return self._make_request('/api/v2/logistics/download_to_label', 'GET', params=kwargs)

    def create_shipping_document_job(self, **kwargs):
        return self._make_request('/api/v2/logistics/create_shipping_document_job', 'POST', data=kwargs)

    def get_shipping_document_job_status(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_shipping_document_job_status', 'GET', params=kwargs)

    def download_shipping_document_job(self, **kwargs):
        return self._make_request('/api/v2/logistics/download_shipping_document_job', 'GET', params=kwargs)

    def update_self_collection_order_logistics(self, **kwargs):
        return self._make_request('/api/v2/logistics/update_self_collection_order_logistics', 'POST', data=kwargs)

    def get_mart_packaging_info(self, **kwargs):
        return self._make_request('/api/v2/logistics/get_mart_packaging_info', 'GET', params=kwargs)

    def set_mart_packaging_info(self, **kwargs):
        return self._make_request('/api/v2/logistics/set_mart_packaging_info', 'POST', data=kwargs)

    def upload_serviceable_polygon(self, **kwargs):
        return self._make_request('/api/v2/logistics/upload_serviceable_polygon', 'POST', data=kwargs, files=kwargs.get('files'))

    def check_polygon_update_status(self, **kwargs):
        return self._make_request('/api/v2/logistics/check_polygon_update_status', 'GET', params=kwargs)
