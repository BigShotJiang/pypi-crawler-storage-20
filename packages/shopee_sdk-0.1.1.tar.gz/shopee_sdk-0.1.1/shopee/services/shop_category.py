from .base import BaseService


class ShopCategoryService(BaseService):
    def add_shop_category(self, **kwargs):
        return self._make_request('/api/v2/shop_category/add', 'POST', data=kwargs)

    def get_shop_category_list(self, **kwargs):
        return self._make_request('/api/v2/shop_category/get_list', 'GET', params=kwargs)

    def delete_shop_category(self, **kwargs):
        return self._make_request('/api/v2/shop_category/delete', 'POST', data=kwargs)

    def update_shop_category(self, **kwargs):
        return self._make_request('/api/v2/shop_category/update', 'POST', data=kwargs)

    def add_item_list(self, **kwargs):
        return self._make_request('/api/v2/shop_category/add_items', 'POST', data=kwargs)

    def get_item_list(self, **kwargs):
        return self._make_request('/api/v2/shop_category/get_items', 'GET', params=kwargs)

    def delete_item_list(self, **kwargs):
        return self._make_request('/api/v2/shop_category/delete_items', 'POST', data=kwargs)
