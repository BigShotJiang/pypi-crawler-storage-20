from .base import BaseService


class AMSService(BaseService):
    def get_open_campaign_added_product(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/get_added_product', 'GET', params=kwargs)

    def get_open_campaign_not_added_product(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/get_not_added_product', 'GET', params=kwargs)

    def batch_add_products_to_open_campaign(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/batch_add_products', 'POST', data=kwargs)

    def add_all_products_to_open_campaign(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/add_all_products', 'POST', data=kwargs)

    def get_auto_add_new_product_toggle_status(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/get_auto_add_setting', 'GET', params=kwargs)

    def update_auto_add_new_product_setting(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/set_auto_add_setting', 'POST', data=kwargs)

    def batch_edit_products_open_campaign_setting(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/batch_edit_products', 'POST', data=kwargs)

    def edit_all_products_open_campaign_setting(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/edit_all_products', 'POST', data=kwargs)

    def batch_remove_products_open_campaign_setting(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/batch_remove_products', 'POST', data=kwargs)

    def remove_all_products_open_campaign_setting(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/remove_all_products', 'POST', data=kwargs)

    def get_open_campaign_batch_task_result(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/get_batch_task_result', 'GET', params=kwargs)

    def get_optimization_suggestion_product(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/get_optimization_product', 'GET', params=kwargs)

    def batch_get_products_suggested_rate(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/batch_get_products_rate', 'POST', data=kwargs)

    def get_shop_suggested_rate(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/open_campaign/get_shop_rate', 'GET', params=kwargs)

    def get_targeted_campaign_addable_product_list(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/targeted_campaign/get_addable_product', 'GET', params=kwargs)

    def get_recommended_affiliate_list(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/targeted_campaign/get_recommended_affiliate', 'GET', params=kwargs)

    def get_managed_affiliate_list(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/targeted_campaign/get_managed_affiliate', 'GET', params=kwargs)

    def query_affiliate_list(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/targeted_campaign/search_affiliate', 'GET', params=kwargs)

    def create_new_targeted_campaign(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/targeted_campaign/create', 'POST', data=kwargs)

    def get_targeted_campaign_list(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/targeted_campaign/list', 'GET', params=kwargs)

    def get_targeted_campaign_settings(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/targeted_campaign/get', 'GET', params=kwargs)

    def update_basic_info_of_targeted_campaign(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/targeted_campaign/update_basic_info', 'POST', data=kwargs)

    def edit_product_list_of_targeted_campaign(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/targeted_campaign/update_products', 'POST', data=kwargs)

    def edit_affiliate_list_of_targeted_campaign(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/targeted_campaign/update_affiliates', 'POST', data=kwargs)

    def terminate_targeted_campaign(self, **kwargs):
        return self._make_request('/api/v2/ams/campaign/targeted_campaign/end', 'POST', data=kwargs)

    def get_performance_data_update_time(self, **kwargs):
        return self._make_request('/api/v2/ams/report/performance/get_data_update_time', 'GET', params=kwargs)

    def get_shop_performance(self, **kwargs):
        return self._make_request('/api/v2/ams/report/performance/get_shop_performance', 'GET', params=kwargs)

    def get_product_performance(self, **kwargs):
        return self._make_request('/api/v2/ams/report/performance/get_product_performance', 'GET', params=kwargs)

    def get_affiliate_performance(self, **kwargs):
        return self._make_request('/api/v2/ams/report/performance/get_affiliate_performance', 'GET', params=kwargs)

    def get_content_performance(self, **kwargs):
        return self._make_request('/api/v2/ams/report/performance/get_content_performance', 'GET', params=kwargs)

    def get_campaign_key_metrics_performance(self, **kwargs):
        return self._make_request('/api/v2/ams/report/performance/get_campaign_key_metrics', 'GET', params=kwargs)

    def get_open_campaign_performance(self, **kwargs):
        return self._make_request('/api/v2/ams/report/performance/get_open_campaign_performance', 'GET', params=kwargs)

    def get_targeted_campaign_performance(self, **kwargs):
        return self._make_request('/api/v2/ams/report/performance/get_targeted_campaign_performance', 'GET', params=kwargs)

    def get_conversion_report(self, **kwargs):
        return self._make_request('/api/v2/ams/report/performance/get_conversion_report', 'GET', params=kwargs)

    def get_validation_list(self, **kwargs):
        return self._make_request('/api/v2/ams/report/performance/get_validation_list', 'GET', params=kwargs)

    def get_validation_report(self, **kwargs):
        return self._make_request('/api/v2/ams/report/performance/get_validation_report', 'GET', params=kwargs)
