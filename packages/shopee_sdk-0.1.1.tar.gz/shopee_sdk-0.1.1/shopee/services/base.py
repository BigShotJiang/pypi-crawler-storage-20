from ..utils.request import make_request
from ..utils.parsers import parse_response


class BaseService:
    def __init__(self, session):
        self.session = session
        self._config = session.get_config()
        self._credentials = session.get_credentials()

    def _make_request(self, endpoint, method='GET', params=None, data=None, 
                     files=None, require_auth=True):
        return make_request(
            session=self.session,
            endpoint=endpoint,
            method=method,
            params=params,
            data=data,
            files=files,
            require_auth=require_auth
        )

    def _parse_response(self, response_data, expected_keys=None):
        return parse_response(response_data, expected_keys)

    def _build_params(self, required_params: dict, **optional_params) -> dict:
        params = required_params.copy()
        params.update({k: v for k, v in optional_params.items() if v is not None})
        return params
