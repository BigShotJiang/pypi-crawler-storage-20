from .base import BaseService


class GlobalProductService(BaseService):
    def get_category(self, **kwargs):
        return self._make_request('/api/v2/global_product/get_category_list', 'GET', params=kwargs)

    def get_attribute_tree(self, **kwargs):
        return self._make_request('/api/v2/global_product/attributes/get', 'GET', params=kwargs)

    def get_brand_list(self, **kwargs):
        return self._make_request('/api/v2/global_product/get_brand_list', 'GET', params=kwargs)

    def get_global_item_limit(self, **kwargs):
        return self._make_request('/api/v2/global_product/get_item_limit', 'GET', params=kwargs)

    def get_global_item_list(self, **kwargs):
        return self._make_request('/api/v2/global_product/get_item_list', 'GET', params=kwargs)

    def get_global_item_info(self, **kwargs):
        return self._make_request('/api/v2/global_product/get_item_info', 'GET', params=kwargs)

    def add_global_item(self, **kwargs):
        return self._make_request('/api/v2/global_product/add_item', 'POST', data=kwargs)

    def update_global_item(self, **kwargs):
        return self._make_request('/api/v2/global_product/update_item', 'POST', data=kwargs)

    def delete_global_item(self, **kwargs):
        return self._make_request('/api/v2/global_product/delete_item', 'POST', data=kwargs)

    def init_tier_variation(self, **kwargs):
        return self._make_request('/api/v2/global_product/init_tier_variation', 'POST', data=kwargs)

    def update_tier_variation(self, **kwargs):
        return self._make_request('/api/v2/global_product/update_tier_variation', 'POST', data=kwargs)

    def add_global_model(self, **kwargs):
        return self._make_request('/api/v2/global_product/add_model', 'POST', data=kwargs)

    def update_global_model(self, **kwargs):
        return self._make_request('/api/v2/global_product/update_model', 'POST', data=kwargs)

    def delete_global_model(self, **kwargs):
        return self._make_request('/api/v2/global_product/delete_model', 'POST', data=kwargs)

    def get_global_model_list(self, **kwargs):
        return self._make_request('/api/v2/global_product/get_model_list', 'GET', params=kwargs)

    def support_size_chart(self, **kwargs):
        return self._make_request('/api/v2/global_product/size_chart/support', 'GET', params=kwargs)

    def update_size_chart(self, **kwargs):
        return self._make_request('/api/v2/global_product/size_chart/update', 'POST', data=kwargs)

    def create_publish_task(self, **kwargs):
        return self._make_request('/api/v2/global_product/publish/create_task', 'POST', data=kwargs)

    def get_publishable_shop(self, **kwargs):
        return self._make_request('/api/v2/global_product/publish/get_publishable_shop', 'GET', params=kwargs)

    def get_publish_task_result(self, **kwargs):
        return self._make_request('/api/v2/global_product/publish/get_task_result', 'GET', params=kwargs)

    def get_published_list(self, **kwargs):
        return self._make_request('/api/v2/global_product/publish/get_published_list', 'GET', params=kwargs)

    def update_price(self, **kwargs):
        return self._make_request('/api/v2/global_product/update_price', 'POST', data=kwargs)

    def update_stock(self, **kwargs):
        return self._make_request('/api/v2/global_product/update_stock', 'POST', data=kwargs)

    def set_sync_field(self, **kwargs):
        return self._make_request('/api/v2/global_product/set_sync_field', 'POST', data=kwargs)

    def get_global_item_id(self, **kwargs):
        return self._make_request('/api/v2/global_product/get_global_item_id', 'GET', params=kwargs)

    def category_recommend(self, **kwargs):
        return self._make_request('/api/v2/global_product/category/recommend', 'GET', params=kwargs)

    def get_recommend_attribute(self, **kwargs):
        return self._make_request('/api/v2/global_product/attribute/recommend', 'GET', params=kwargs)

    def get_shop_publishable_status(self, **kwargs):
        return self._make_request('/api/v2/global_product/publish/get_shop_publishable_status', 'GET', params=kwargs)

    def get_variations(self, **kwargs):
        return self._make_request('/api/v2/global_product/get_variations', 'GET', params=kwargs)

    def get_size_chart_detail(self, **kwargs):
        return self._make_request('/api/v2/global_product/size_chart/detail', 'GET', params=kwargs)

    def get_size_chart_list(self, **kwargs):
        return self._make_request('/api/v2/global_product/size_chart/list', 'GET', params=kwargs)

    def search_global_attribute_value_list(self, **kwargs):
        return self._make_request('/api/v2/global_product/attribute_value/search', 'GET', params=kwargs)

    def get_local_adjustment_rate(self, **kwargs):
        return self._make_request('/api/v2/global_product/get_local_adjustment_rate', 'GET', params=kwargs)

    def update_local_adjustment_rate(self, **kwargs):
        return self._make_request('/api/v2/global_product/update_local_adjustment_rate', 'POST', data=kwargs)
