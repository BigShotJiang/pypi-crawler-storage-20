from .base import BaseService


class VoucherService(BaseService):
    def add_voucher(self, **kwargs):
        return self._make_request('/api/v2/marketing/add_voucher', 'POST', data=kwargs)

    def delete_voucher(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_voucher', 'POST', data=kwargs)

    def end_voucher(self, **kwargs):
        return self._make_request('/api/v2/marketing/end_voucher', 'POST', data=kwargs)

    def update_voucher(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_voucher', 'POST', data=kwargs)

    def get_voucher(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_voucher', 'GET', params=kwargs)

    def get_voucher_list(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_voucher_list', 'GET', params=kwargs)
