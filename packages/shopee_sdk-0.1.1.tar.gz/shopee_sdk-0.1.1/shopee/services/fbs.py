from .base import BaseService


class FBSService(BaseService):
    def query_br_shop_enrollment_status(self, **kwargs):
        return self._make_request('/api/v2/logistics/fbs/query_br_shop_enrollment_status', 'GET', params=kwargs)

    def query_br_shop_invoice_error(self, **kwargs):
        return self._make_request('/api/v2/logistics/fbs/query_br_shop_invoice_error', 'GET', params=kwargs)

    def query_br_shop_block_status(self, **kwargs):
        return self._make_request('/api/v2/logistics/fbs/query_br_shop_block_status', 'GET', params=kwargs)

    def query_br_sku_block_status(self, **kwargs):
        return self._make_request('/api/v2/logistics/fbs/query_br_sku_block_status', 'GET', params=kwargs)
