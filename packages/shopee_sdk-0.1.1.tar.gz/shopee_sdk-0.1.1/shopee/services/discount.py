from .base import BaseService


class DiscountService(BaseService):
    def add_discount(self, **kwargs):
        return self._make_request('/api/v2/marketing/add_discount', 'POST', data=kwargs)

    def add_discount_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/add_discount_item', 'POST', data=kwargs)

    def delete_discount(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_discount', 'POST', data=kwargs)

    def delete_discount_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_discount_item', 'POST', data=kwargs)

    def get_discount(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_discount', 'GET', params=kwargs)

    def get_discount_list(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_discount_list', 'GET', params=kwargs)

    def update_discount(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_discount', 'POST', data=kwargs)

    def update_discount_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_discount_item', 'POST', data=kwargs)

    def end_discount(self, **kwargs):
        return self._make_request('/api/v2/marketing/end_discount', 'POST', data=kwargs)

    def get_sip_discounts(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_sip_discounts', 'GET', params=kwargs)

    def set_sip_discount(self, **kwargs):
        return self._make_request('/api/v2/marketing/set_sip_discount', 'POST', data=kwargs)

    def delete_sip_discount(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_sip_discount', 'POST', data=kwargs)
