from .base import BaseService
from .public import PublicService
from .ams import AMSService
from .video import VideoService
from .product import ProductService
from .global_product import GlobalProductService
from .media_space import MediaSpaceService
from .media import MediaService
from .shop import ShopService
from .merchant import MerchantService
from .order import OrderService
from .logistics import LogisticsService
from .first_mile import FirstMileService
from .payment import PaymentService
from .discount import DiscountService
from .bundle_deal import BundleDealService
from .add_on_deal import AddOnDealService
from .voucher import VoucherService
from .shop_flash_sale import ShopFlashSaleService
from .follow_prize import FollowPrizeService
from .top_picks import TopPicksService
from .shop_category import ShopCategoryService
from .returns import ReturnsService
from .account_health import AccountHealthService
from .ads import AdsService
from .push import PushService
from .sbs import SBSService
from .fbs import FBSService
from .livestream import LivestreamService

SERVICE_MAPPING = {
    'public': PublicService,
    'ams': AMSService,
    'video': VideoService,
    'product': ProductService,
    'global_product': GlobalProductService,
    'media_space': MediaSpaceService,
    'media': MediaService,
    'shop': ShopService,
    'merchant': MerchantService,
    'order': OrderService,
    'logistics': LogisticsService,
    'first_mile': FirstMileService,
    'payment': PaymentService,
    'discount': DiscountService,
    'bundle_deal': BundleDealService,
    'add_on_deal': AddOnDealService,
    'voucher': VoucherService,
    'shop_flash_sale': ShopFlashSaleService,
    'follow_prize': FollowPrizeService,
    'top_picks': TopPicksService,
    'shop_category': ShopCategoryService,
    'returns': ReturnsService,
    'account_health': AccountHealthService,
    'ads': AdsService,
    'push': PushService,
    'sbs': SBSService,
    'fbs': FBSService,
    'livestream': LivestreamService,
}


def get_client(session, service_name):
    service_class = SERVICE_MAPPING.get(service_name.lower())
    if not service_class:
        raise ValueError(f"Unknown service: {service_name}")
    return service_class(session)


__all__ = [
    'BaseService',
    'PublicService',
    'AMSService',
    'VideoService',
    'ProductService',
    'GlobalProductService',
    'MediaSpaceService',
    'MediaService',
    'ShopService',
    'MerchantService',
    'OrderService',
    'LogisticsService',
    'FirstMileService',
    'PaymentService',
    'DiscountService',
    'BundleDealService',
    'AddOnDealService',
    'VoucherService',
    'ShopFlashSaleService',
    'FollowPrizeService',
    'TopPicksService',
    'ShopCategoryService',
    'ReturnsService',
    'AccountHealthService',
    'AdsService',
    'PushService',
    'SBSService',
    'FBSService',
    'LivestreamService',
    'get_client',
]
