from .base import BaseService


class ShopService(BaseService):
    def get_shop_info(self, **kwargs):
        return self._make_request('/api/v2/shop/get_shop_info', 'GET', params=kwargs)

    def get_profile(self, **kwargs):
        return self._make_request('/api/v2/shop/get_profile', 'GET', params=kwargs)

    def update_profile(self, **kwargs):
        return self._make_request('/api/v2/shop/update_profile', 'POST', data=kwargs)

    def get_warehouse_detail(self, **kwargs):
        return self._make_request('/api/v2/shop/get_warehouse_detail', 'GET', params=kwargs)

    def get_shop_notification(self, **kwargs):
        return self._make_request('/api/v2/shop/get_shop_notification', 'GET', params=kwargs)

    def get_authorised_reseller_brand(self, **kwargs):
        return self._make_request('/api/v2/shop/get_authorised_reseller_brand', 'GET', params=kwargs)

    def get_br_shop_onboarding_info(self, **kwargs):
        return self._make_request('/api/v2/shop/get_br_shop_onboarding_info', 'GET', params=kwargs)

    def get_shop_holiday_mode(self, **kwargs):
        return self._make_request('/api/v2/shop/get_shop_holiday_mode', 'GET', params=kwargs)

    def set_shop_holiday_mode(self, **kwargs):
        return self._make_request('/api/v2/shop/set_shop_holiday_mode', 'POST', data=kwargs)
