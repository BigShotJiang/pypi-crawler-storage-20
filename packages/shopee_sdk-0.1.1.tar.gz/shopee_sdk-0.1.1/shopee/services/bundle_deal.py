from .base import BaseService


class BundleDealService(BaseService):
    def add_bundle_deal(self, **kwargs):
        return self._make_request('/api/v2/marketing/add_bundle_deal', 'POST', data=kwargs)

    def add_bundle_deal_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/add_bundle_deal_item', 'POST', data=kwargs)

    def get_bundle_deal_list(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_bundle_deal_list', 'GET', params=kwargs)

    def get_bundle_deal(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_bundle_deal', 'GET', params=kwargs)

    def get_bundle_deal_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/get_bundle_deal_item', 'GET', params=kwargs)

    def update_bundle_deal(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_bundle_deal', 'POST', data=kwargs)

    def update_bundle_deal_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/update_bundle_deal_item', 'POST', data=kwargs)

    def end_bundle_deal(self, **kwargs):
        return self._make_request('/api/v2/marketing/end_bundle_deal', 'POST', data=kwargs)

    def delete_bundle_deal(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_bundle_deal', 'POST', data=kwargs)

    def delete_bundle_deal_item(self, **kwargs):
        return self._make_request('/api/v2/marketing/delete_bundle_deal_item', 'POST', data=kwargs)
