from .base import BaseService


class PublicService(BaseService):
    def get_shops_by_partner(self, **kwargs):
        return self._make_request('/api/v2/public/shop/get_by_partner', 'POST', data=kwargs)

    def get_merchants_by_partner(self, **kwargs):
        return self._make_request('/api/v2/public/merchant/get_by_partner', 'POST', data=kwargs)

    def get_access_token(self, **kwargs):
        response = self._make_request('/api/v2/auth/token/get', 'POST', data=kwargs, require_auth=False)
        access_token = response.get('access_token')
        refresh_token = response.get('refresh_token')
        expire_in = response.get('expire_in')
        
        self.session.auth_handler.set_tokens(access_token, refresh_token, expire_in)
        
        return response

    def refresh_access_token(self, **kwargs):
        response = self._make_request('/api/v2/auth/access_token/get', 'POST', data=kwargs, require_auth=False)
        access_token = response.get('access_token')
        refresh_token = response.get('refresh_token')
        expire_in = response.get('expire_in')
        
        self.session.auth_handler.set_tokens(access_token, refresh_token, expire_in)
        
        return response

    def get_token_by_resend_code(self, **kwargs):
        response = self._make_request('/api/v2/auth/token/get', 'POST', data=kwargs, require_auth=False)
        access_token = response.get('access_token')
        refresh_token = response.get('refresh_token')
        expire_in = response.get('expire_in')
        
        self.session.auth_handler.set_tokens(access_token, refresh_token, expire_in)
        
        return response

    def get_shopee_ip_ranges(self, **kwargs):
        return self._make_request('/api/v2/public/network/shopee_ip', 'GET', params=kwargs)
