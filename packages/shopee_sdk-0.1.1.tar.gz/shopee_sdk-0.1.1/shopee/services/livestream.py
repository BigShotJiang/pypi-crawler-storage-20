from .base import BaseService


class LivestreamService(BaseService):
    def upload_image(self, **kwargs):
        return self._make_request('/api/v2/live/upload_image', 'POST', data=kwargs, files=kwargs.get('files'))

    def create_session(self, **kwargs):
        return self._make_request('/api/v2/live/create_session', 'POST', data=kwargs)

    def update_session(self, **kwargs):
        return self._make_request('/api/v2/live/update_session', 'POST', data=kwargs)

    def start_session(self, **kwargs):
        return self._make_request('/api/v2/live/start_session', 'POST', data=kwargs)

    def end_session(self, **kwargs):
        return self._make_request('/api/v2/live/end_session', 'POST', data=kwargs)

    def get_session_detail(self, **kwargs):
        return self._make_request('/api/v2/live/get_session_detail', 'GET', params=kwargs)

    def add_item_list(self, **kwargs):
        return self._make_request('/api/v2/live/add_item_list', 'POST', data=kwargs)

    def delete_item_list(self, **kwargs):
        return self._make_request('/api/v2/live/delete_item_list', 'POST', data=kwargs)

    def update_item_list(self, **kwargs):
        return self._make_request('/api/v2/live/update_item_list', 'POST', data=kwargs)

    def get_item_count(self, **kwargs):
        return self._make_request('/api/v2/live/get_item_count', 'GET', params=kwargs)

    def get_item_list(self, **kwargs):
        return self._make_request('/api/v2/live/get_item_list', 'GET', params=kwargs)

    def update_show_item(self, **kwargs):
        return self._make_request('/api/v2/live/update_show_item', 'POST', data=kwargs)

    def delete_show_item(self, **kwargs):
        return self._make_request('/api/v2/live/delete_show_item', 'POST', data=kwargs)

    def get_show_item(self, **kwargs):
        return self._make_request('/api/v2/live/get_show_item', 'GET', params=kwargs)

    def get_like_item_list(self, **kwargs):
        return self._make_request('/api/v2/live/get_like_item_list', 'GET', params=kwargs)

    def get_recent_item_list(self, **kwargs):
        return self._make_request('/api/v2/live/get_recent_item_list', 'GET', params=kwargs)

    def get_item_set_list(self, **kwargs):
        return self._make_request('/api/v2/live/get_item_set_list', 'GET', params=kwargs)

    def get_item_set_item_list(self, **kwargs):
        return self._make_request('/api/v2/live/get_item_set_item_list', 'GET', params=kwargs)

    def apply_item_set(self, **kwargs):
        return self._make_request('/api/v2/live/apply_item_set', 'POST', data=kwargs)

    def get_session_metric(self, **kwargs):
        return self._make_request('/api/v2/live/get_session_metric', 'GET', params=kwargs)

    def get_session_item_metric(self, **kwargs):
        return self._make_request('/api/v2/live/get_session_item_metric', 'GET', params=kwargs)

    def get_latest_comment_list(self, **kwargs):
        return self._make_request('/api/v2/live/get_latest_comment_list', 'GET', params=kwargs)

    def post_comment(self, **kwargs):
        return self._make_request('/api/v2/live/post_comment', 'POST', data=kwargs)
