from .base import BaseService


class SBSService(BaseService):
    def get_bound_whs_info(self, **kwargs):
        return self._make_request('/api/v2/logistics/sbs/get_bound_whs_info', 'GET', params=kwargs)

    def get_current_inventory(self, **kwargs):
        return self._make_request('/api/v2/logistics/sbs/get_current_inventory', 'GET', params=kwargs)

    def get_expiry_report(self, **kwargs):
        return self._make_request('/api/v2/logistics/sbs/get_expiry_report', 'GET', params=kwargs)

    def get_stock_aging(self, **kwargs):
        return self._make_request('/api/v2/logistics/sbs/get_stock_aging', 'GET', params=kwargs)

    def get_stock_movement(self, **kwargs):
        return self._make_request('/api/v2/logistics/sbs/get_stock_movement', 'GET', params=kwargs)
