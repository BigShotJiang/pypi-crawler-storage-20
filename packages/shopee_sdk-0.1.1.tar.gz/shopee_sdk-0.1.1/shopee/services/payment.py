from typing import Optional, List, Dict, Any
from .base import BaseService


class PaymentService(BaseService):
    def get_escrow_detail(self, order_sn: str) -> Dict[str, Any]:
        params = {'order_sn': order_sn}
        return self._make_request('/api/v2/payment/get_escrow_detail', 'GET', params=params)

    def set_shop_installment_status(self, installment_status: int) -> Dict[str, Any]:
        data = {'installment_status': installment_status}
        return self._make_request('/api/v2/payment/set_shop_installment_status', 'POST', data=data)

    def get_shop_installment_status(self) -> Dict[str, Any]:
        return self._make_request('/api/v2/payment/get_shop_installment_status', 'GET', params={})

    def get_payout_detail(self, page_size: int, page_no: int, payout_time_from: int, payout_time_to: int) -> Dict[str, Any]:
        params = {
            'page_size': page_size,
            'page_no': page_no,
            'payout_time_from': payout_time_from,
            'payout_time_to': payout_time_to
        }
        return self._make_request('/api/v2/payment/get_payout_detail', 'GET', params=params)

    def set_item_installment_status(self, item_id_list: List[int], tenure_list: List[int]) -> Dict[str, Any]:
        data = {
            'item_id_list': item_id_list,
            'tenure_list': tenure_list
        }
        return self._make_request('/api/v2/payment/set_item_installment_status', 'POST', data=data)

    def get_item_installment_status(self, item_id_list: List[int]) -> Dict[str, Any]:
        params = {'item_id_list': item_id_list}
        return self._make_request('/api/v2/payment/get_item_installment_status', 'GET', params=params)

    def get_payment_method_list(self) -> Dict[str, Any]:
        return self._make_request('/api/v2/payment/get_payment_method_list', 'GET', params={})

    def get_wallet_transaction_list(self, page_no: int, page_size: int, transaction_type: Optional[str] = None, 
                                    payout_status: Optional[str] = None, wallet_type: Optional[str] = None, 
                                    time_from: Optional[int] = None, time_to: Optional[int] = None) -> Dict[str, Any]:
        params = self._build_params(
            {'page_no': page_no, 'page_size': page_size},
            transaction_type=transaction_type,
            payout_status=payout_status,
            wallet_type=wallet_type,
            time_from=time_from,
            time_to=time_to
        )
        return self._make_request('/api/v2/payment/get_wallet_transaction_list', 'GET', params=params)

    def get_escrow_list(self, release_time_from: int, release_time_to: int, page_size: Optional[int] = None, 
                       cursor: Optional[str] = None, order_sn: Optional[str] = None) -> Dict[str, Any]:
        params = self._build_params(
            {'release_time_from': release_time_from, 'release_time_to': release_time_to},
            page_size=page_size,
            cursor=cursor,
            order_sn=order_sn
        )
        return self._make_request('/api/v2/payment/get_escrow_list', 'GET', params=params)

    def get_payout_info(self, payout_time_from: int, payout_time_to: int, page_size: int, 
                       cursor: Optional[str] = None) -> Dict[str, Any]:
        params = self._build_params(
            {'payout_time_from': payout_time_from, 'payout_time_to': payout_time_to, 'page_size': page_size},
            cursor=cursor
        )
        return self._make_request('/api/v2/payment/get_payout_info', 'GET', params=params)

    def get_billing_transaction_info(self, billing_transaction_info_type: str, cursor: str, page_size: int, 
                                    encrypted_payout_ids: Optional[List[str]] = None) -> Dict[str, Any]:
        params = self._build_params(
            {'billing_transaction_info_type': billing_transaction_info_type, 'cursor': cursor, 'page_size': page_size},
            encrypted_payout_ids=encrypted_payout_ids
        )
        return self._make_request('/api/v2/payment/get_billing_transaction_info', 'GET', params=params)

    def get_escrow_detail_batch(self, order_sn_list: List[str]) -> Dict[str, Any]:
        params = {'order_sn_list': order_sn_list}
        return self._make_request('/api/v2/payment/get_escrow_detail_batch', 'GET', params=params)

    def generate_income_statement(self, release_time_from: int, release_time_to: int, statement_type: str) -> Dict[str, Any]:
        data = {
            'release_time_from': release_time_from,
            'release_time_to': release_time_to,
            'statement_type': statement_type
        }
        return self._make_request('/api/v2/payment/generate_income_statement', 'POST', data=data)

    def get_income_statement(self, income_statement_id: str) -> Dict[str, Any]:
        params = {'income_statement_id': income_statement_id}
        return self._make_request('/api/v2/payment/get_income_statement', 'GET', params=params)

    def generate_income_report(self, release_time_from: int, release_time_to: int) -> Dict[str, Any]:
        data = {
            'release_time_from': release_time_from,
            'release_time_to': release_time_to
        }
        return self._make_request('/api/v2/payment/generate_income_report', 'POST', data=data)

    def get_income_report(self, income_report_id: str) -> Dict[str, Any]:
        params = {'income_report_id': income_report_id}
        return self._make_request('/api/v2/payment/get_income_report', 'GET', params=params)

    def get_income_overview(self, income_status: Optional[str] = None) -> Dict[str, Any]:
        params = self._build_params({}, income_status=income_status)
        return self._make_request('/api/v2/payment/get_income_overview', 'GET', params=params)

    def get_income_detail(self, date_from: int, date_to: int, income_status: str, page_size: int, 
                         cursor: Optional[str] = None) -> Dict[str, Any]:
        params = self._build_params(
            {'date_from': date_from, 'date_to': date_to, 'income_status': income_status, 'page_size': page_size},
            cursor=cursor
        )
        return self._make_request('/api/v2/payment/get_income_detail', 'GET', params=params)
