from typing import Optional, List, Dict, Any
from .base import BaseService


class OrderService(BaseService):
    def get_order_list(self, time_range_field: str, time_from: int, time_to: int, page_size: int, 
                      cursor: Optional[str] = None, order_status: Optional[str] = None, 
                      response_optional_fields: Optional[str] = None, 
                      request_order_status_pending: Optional[str] = None, 
                      logistics_channel_id: Optional[int] = None) -> Dict[str, Any]:
        params = {
            'time_range_field': time_range_field,
            'time_from': time_from,
            'time_to': time_to,
            'page_size': page_size
        }
        if cursor is not None:
            params['cursor'] = cursor
        if order_status is not None:
            params['order_status'] = order_status
        if response_optional_fields is not None:
            params['response_optional_fields'] = response_optional_fields
        if request_order_status_pending is not None:
            params['request_order_status_pending'] = request_order_status_pending
        if logistics_channel_id is not None:
            params['logistics_channel_id'] = logistics_channel_id
        return self._make_request('/api/v2/order/get_order_list', 'GET', params=params)

    def get_order_detail(self, order_sn_list: str, 
                      response_optional_fields: Optional[str] = None) -> Dict[str, Any]:
        params = {'order_sn_list': order_sn_list}
        if response_optional_fields is not None:
            params['response_optional_fields'] = response_optional_fields
        return self._make_request('/api/v2/order/get_order_detail', 'GET', params=params)

    def get_shipment_list(self, page_size: int, cursor: Optional[str] = None) -> Dict[str, Any]:
        params = {'page_size': page_size}
        if cursor is not None:
            params['cursor'] = cursor
        return self._make_request('/api/v2/order/get_shipment_list', 'GET', params=params)

    def search_package_list(self, page_size: int, cursor: Optional[str] = None, filter: Optional[Dict[str, Any]] = None, sort: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        data = {'pagination': {'page_size': page_size}}
        if cursor is not None:
            data['pagination']['cursor'] = cursor
        if filter is not None:
            data['filter'] = filter
        if sort is not None:
            data['sort'] = sort
        return self._make_request('/api/v2/order/search_package_list', 'POST', data=data)

    def get_package_detail(self, package_number_list: str) -> Dict[str, Any]:
        params = {'package_number_list': package_number_list}
        return self._make_request('/api/v2/order/get_package_detail', 'GET', params=params)

    def split_order(self, order_sn: str, package_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        data = {'order_sn': order_sn, 'package_list': package_list}
        return self._make_request('/api/v2/order/split_order', 'POST', data=data)

    def unsplit_order(self, order_sn: str) -> Dict[str, Any]:
        data = {'order_sn': order_sn}
        return self._make_request('/api/v2/order/unsplit_order', 'POST', data=data)

    def cancel_order(self, order_sn: str, cancel_reason: str, item_list: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        data = {'order_sn': order_sn, 'cancel_reason': cancel_reason}
        if item_list is not None:
            data['item_list'] = item_list
        return self._make_request('/api/v2/order/cancel_order', 'POST', data=data)

    def handle_buyer_cancellation(self, order_sn: str, operation: str) -> Dict[str, Any]:
        data = {'order_sn': order_sn, 'operation': operation}
        return self._make_request('/api/v2/order/handle_buyer_cancellation', 'POST', data=data)

    def set_note(self, order_sn: str, note: str) -> Dict[str, Any]:
        data = {'order_sn': order_sn, 'note': note}
        return self._make_request('/api/v2/order/set_note', 'POST', data=data)

    def get_pending_buyer_invoice_order_list(self, page_size: int, cursor: Optional[str] = None) -> Dict[str, Any]:
        params = {'page_size': page_size}
        if cursor is not None:
            params['cursor'] = cursor
        return self._make_request('/api/v2/order/get_pending_buyer_invoice_order_list', 'GET', params=params)

    def get_buyer_invoice_info(self, queries: List[Dict[str, Any]]) -> Dict[str, Any]:
        data = {'queries': queries}
        return self._make_request('/api/v2/order/get_buyer_invoice_info', 'POST', data=data)

    def upload_invoice_doc(self, order_sn: str, file_type: int, file: Any) -> Dict[str, Any]:
        data = {'order_sn': order_sn, 'file_type': file_type}
        files = {'file': file}
        return self._make_request('/api/v2/order/upload_invoice_doc', 'POST', data=data, files=files)

    def download_invoice_doc(self, order_sn: str) -> Dict[str, Any]:
        params = {'order_sn': order_sn}
        return self._make_request('/api/v2/order/download_invoice_doc', 'GET', params=params)

    def handle_prescription_check(self, order_sn: str, is_approved: bool, 
                              reject_reason_code: Optional[int] = None, 
                              items: Optional[List[Dict[str, Any]]] = None, 
                              pharmacist_name: Optional[str] = None) -> Dict[str, Any]:
        data = {'order_sn': order_sn, 'is_approved': is_approved}
        if reject_reason_code is not None:
            data['reject_reason_code'] = reject_reason_code
        if items is not None:
            data['items'] = items
        if pharmacist_name is not None:
            data['pharmacist_name'] = pharmacist_name
        return self._make_request('/api/v2/order/handle_prescription_check', 'POST', data=data)

    def get_warehouse_filter_config(self) -> Dict[str, Any]:
        return self._make_request('/api/v2/order/get_warehouse_filter_config', 'GET', params={})

    def get_booking_list(self, time_range_field: str, time_from: int, time_to: int, page_size: int, 
                      cursor: Optional[str] = None, booking_status: Optional[str] = None) -> Dict[str, Any]:
        params = {
            'time_range_field': time_range_field,
            'time_from': time_from,
            'time_to': time_to,
            'page_size': page_size
        }
        if cursor is not None:
            params['cursor'] = cursor
        if booking_status is not None:
            params['booking_status'] = booking_status
        return self._make_request('/api/v2/order/get_booking_list', 'GET', params=params)

    def get_booking_detail(self, booking_sn_list: str, 
                        response_optional_fields: Optional[str] = None) -> Dict[str, Any]:
        params = {'booking_sn_list': booking_sn_list}
        if response_optional_fields is not None:
            params['response_optional_fields'] = response_optional_fields
        return self._make_request('/api/v2/order/get_booking_detail', 'GET', params=params)

    def generate_fbs_invoices(self, start: int, end: int, document_type: int, file_type: int, document_status: Optional[int] = None) -> Dict[str, Any]:
        data = {
            'start': start,
            'end': end,
            'document_type': document_type,
            'file_type': file_type
        }
        if document_status is not None:
            data['document_status'] = document_status
        return self._make_request('/api/v2/order/generate_fbs_invoices', 'POST', data=data)

    def get_fbs_invoices_result(self, request_id_list: List[int]) -> Dict[str, Any]:
        data = {'request_id_list': {'request_id': request_id_list}}
        return self._make_request('/api/v2/order/get_fbs_invoices_result', 'POST', data=data)

    def download_fbs_invoices(self, request_id_list: List[int]) -> Dict[str, Any]:
        data = {'request_id_list': {'request_id': request_id_list}}
        return self._make_request('/api/v2/order/download_fbs_invoices', 'POST', data=data)
