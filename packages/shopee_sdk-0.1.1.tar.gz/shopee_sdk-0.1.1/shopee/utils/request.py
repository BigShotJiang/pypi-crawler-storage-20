import time
import requests
from .sign import generate_signature, build_base_string
from ..exceptions import APIError, ClientError, ServerError, RateLimitError


def make_request(session, endpoint, method='GET', params=None, data=None, 
                 files=None, require_auth=True):
    config = session.get_config()
    credentials = session.get_credentials()
    
    timestamp = int(time.time())
    partner_id = credentials.get_partner_id()
    partner_key = credentials.get_partner_key()
    shop_id = credentials.get_shop_id()
    access_token = None
    
    if require_auth:
        try:
            access_token = session.auth_handler.get_access_token()
        except Exception:
            if endpoint not in ['/api/v2/auth/token/get', '/api/v2/auth/access_token/get', '/api/v2/auth/token_refresh']:
                raise
    
    path = endpoint
    request_params = params.copy() if params else {}
    
    base_string = build_base_string(
        partner_id=partner_id,
        timestamp=timestamp,
        access_token=access_token,
        path=path,
        shop_id=shop_id
    )
    
    signature = generate_signature(partner_key, base_string)
    
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': config.user_agent
    }
    
    request_params['partner_id'] = partner_id
    request_params['timestamp'] = timestamp
    request_params['sign'] = signature
    
    if shop_id:
        request_params['shop_id'] = shop_id
    
    if access_token:
        request_params['access_token'] = access_token
    
    url = f"{config.base_url}{path}"
    
    try:
        if method.upper() == 'GET':
            response = requests.get(
                url,
                params=request_params,
                headers=headers,
                timeout=config.timeout
            )
        else:
            response = requests.post(
                url,
                params=request_params,
                json=data,
                files=files,
                headers=headers,
                timeout=config.timeout
            )
        
        return handle_response(response)
        
    except requests.exceptions.Timeout:
        raise APIError("Request timed out")
    except requests.exceptions.ConnectionError:
        raise APIError("Connection error occurred")
    except requests.exceptions.RequestException as e:
        raise APIError(f"Request failed: {str(e)}")


def handle_response(response):
    try:
        response_json = response.json()
    except ValueError:
        raise APIError(f"Invalid JSON response: {response.text}")
    
    if response.status_code == 200:
        if 'error' in response_json and response_json['error']:
            error_msg = response_json.get('error', response_json.get('message', 'Unknown error'))
            raise APIError(f"API Error: {error_msg}")
        if 'error_msg' in response_json and response_json['error_msg']:
            raise APIError(f"API Error: {response_json.get('error_msg')}")
        if 'response' in response_json:
            return response_json['response']
        return response_json
    elif response.status_code == 400:
        raise ClientError(f"Bad request: {response_json}")
    elif response.status_code == 401:
        from ..exceptions import AuthenticationError
        raise AuthenticationError("Authentication failed")
    elif response.status_code == 403:
        raise ClientError("Forbidden")
    elif response.status_code == 429:
        raise RateLimitError("Rate limit exceeded")
    elif response.status_code >= 500:
        raise ServerError(f"Server error: {response.status_code}")
    else:
        raise APIError(f"Unexpected status code: {response.status_code}")
