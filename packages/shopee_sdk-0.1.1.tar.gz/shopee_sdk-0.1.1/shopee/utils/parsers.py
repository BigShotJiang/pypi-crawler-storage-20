from ..exceptions import ValidationError


def parse_response(response_data, expected_keys=None):
    if not isinstance(response_data, dict):
        return response_data
    
    if 'error' in response_data:
        raise ValidationError(f"API returned error: {response_data['error']}")
    
    if 'error_msg' in response_data and response_data['error_msg']:
        raise ValidationError(f"API returned error: {response_data['error_msg']}")
    
    if 'response' in response_data:
        return response_data['response']
    
    if expected_keys:
        missing_keys = [key for key in expected_keys if key not in response_data]
        if missing_keys:
            raise ValidationError(f"Missing expected keys: {missing_keys}")
    
    return response_data


def parse_list_response(response_data, list_key='items'):
    data = parse_response(response_data)
    
    if isinstance(data, dict) and list_key in data:
        return data[list_key]
    elif isinstance(data, list):
        return data
    else:
        return [data]


def parse_pagination_response(response_data):
    data = parse_response(response_data)
    
    return {
        'items': data.get('items', []),
        'total': data.get('total', 0),
        'more': data.get('more', False),
        'next_offset': data.get('next_offset', None)
    }
