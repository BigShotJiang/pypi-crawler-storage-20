import hashlib
import hmac


def generate_signature(partner_key, base_string):
    signature = hmac.new(
        partner_key.encode('utf-8'),
        base_string.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    return signature


def build_base_string(partner_id, timestamp, access_token, path, shop_id):
    base_parts = [str(partner_id), path, str(timestamp)]
    
    if access_token:
        base_parts.append(access_token)
    
    if shop_id:
        base_parts.append(str(shop_id))
    
    return ''.join(base_parts)
