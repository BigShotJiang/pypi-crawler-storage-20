import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import shopee

session = shopee.Session(
    partner_id='your_partner_id',
    partner_key='your_partner_key',
    shop_id='your_shop_id'
)

product = session.resource('product')

all_items = product.all(offset=0, page_size=20)
print("All products:", all_items)

item = product.get(item_id=12345)
print("Product details:", item)

new_item = product.create(
    name="New Product",
    description="Product description",
    stock=100,
    price=1000
)
print("Created product:", new_item)

updated_item = product.update(
    item_id=12345,
    price=1500
)
print("Updated product:", updated_item)
