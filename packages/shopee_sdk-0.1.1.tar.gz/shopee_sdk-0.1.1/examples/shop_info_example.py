import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import shopee
from shopee import AuthenticationError, APIError
import json

def main():
    partner_id = "2013155"
    partner_key = "shpk78714e75656e454f79736b4d7670725a6e66504159707876655a62564875"
    shop_id = "847554776"
    region = "sg"
    
    provided_token = "eyJhbGciOiJIUzI1NiJ9.COPvehABGNjRkpQDIAEo8f-tywYwvaf9qQM4AUAB.E5GGRTW4mrPlHFQKcOC6UezC3XpBVyYWD4CzxC6Ft88"
    
    print(f"Partner ID: {partner_id}")
    print(f"Shop ID: {shop_id}")
    print(f"Region: {region}")
    print(f"Access Token: {provided_token[:30]}...")
    
    try:
        session = shopee.Session(
            partner_id=partner_id,
            partner_key=partner_key,
            shop_id=shop_id,
            region=region
        )
        
        session.auth_handler.set_tokens(provided_token)
        
        shop_client = session.client('shop')
        
        print("\nCalling /api/v2/shop/get_shop_info...")
        response = shop_client.get_shop_info()
        
        print("\n✓ API Call Successful!")
        print("\nResponse:")
        print(json.dumps(response, indent=2))
        
    except AuthenticationError as e:
        print(f"\n✗ Authentication failed: {e}")
    except APIError as e:
        print(f"\n✗ API error: {e}")
    except Exception as e:
        print(f"\n✗ Unexpected error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()
