import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import shopee

session = shopee.Session(
    partner_id='your_partner_id',
    partner_key='your_partner_key',
    shop_id='your_shop_id'
)

# order = session.resource('order')

# orders = order.all(
#     time_range_field='create_time',
#     time_from=1234567890,
#     time_to=1234567990
# )
# print("Orders:", orders)

# order_detail = order.get(order_sn='ORDER_SN_12345')
# print("Order details:", order_detail)

# cancel_result = order.cancel(
#     order_sn='ORDER_SN_12345',
#     cancel_reason='OUT_OF_STOCK'
# )
# print("Cancel result:", cancel_result)
