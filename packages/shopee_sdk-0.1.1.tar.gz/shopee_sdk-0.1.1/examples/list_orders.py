import shopee
import time
from datetime import datetime, timedelta, timezone
import json



def main():
  partner_id = "2013155"
  partner_key = "shpk78714e75656e454f79736b4d7670725a6e66504159707876655a62564875"
  shop_id = "847554776"
  region = "sg"
  
  provided_token = "eyJhbGciOiJIUzI1NiJ9.COPvehABGNjRkpQDIAEozoyvywYw7sam7gM4AUAB.3RaO-eI0mktrKBjXfKCMXXEjzEjE2t4UEX8bmYIKJTk"

  session = shopee.Session(
    partner_id=partner_id,
    partner_key=partner_key,
    shop_id=shop_id,
    region=region
  )

  session.auth_handler.set_tokens(provided_token)
  
  tz = timezone(timedelta(hours=7))
  now = datetime.now(tz)
  time_from_dt = now - timedelta(hours=48)
  time_from = int(time_from_dt.timestamp())
  time_to = int(now.timestamp())

  shopee_client = session.client('order')
  response = shopee_client.get_order_list(
    time_range_field='create_time',
    time_from=time_from,
    time_to=time_to,
    page_size=100,
    order_status='READY_TO_SHIP',
    request_order_status_pending='false'
  )
  print(json.dumps(response, indent=2))

if __name__ == '__main__':
    main()