import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import shopee

session = shopee.Session(
    partner_id='your_partner_id',
    partner_key='your_partner_key',
    shop_id='your_shop_id',
    region='sg'
)

public_client = session.client('public')
token_response = public_client.get_access_token(
    code='your_authorization_code',
    shop_id='your_shop_id'
)

print("Access Token:", token_response.get('access_token'))

product_client = session.client('product')
items = product_client.get_item_list(offset=0, page_size=20)
print("Products:", items)
