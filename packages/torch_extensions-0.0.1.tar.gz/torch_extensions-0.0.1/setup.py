from setuptools import setup


def main():
    setup(
        name='torch.extensions',
        version='0.0.1',
        description='pytorch通用模型导出',
        author='zhumingwu',
        author_email='zhumingwu@126.com',
        packages=['torch.extension'],
        install_requires=['torch>=2.9.1'],
        python_requires='>=3.9'
    )


if __name__ == '__main__':
    main()
