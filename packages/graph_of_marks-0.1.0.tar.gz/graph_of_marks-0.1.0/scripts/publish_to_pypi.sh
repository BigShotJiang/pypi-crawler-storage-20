#!/bin/bash
#
# Graph of Marks - PyPI Publishing Script
#
# Usage:
#   ./scripts/publish_to_pypi.sh [OPTIONS]
#
# Options:
#   --test          Upload to TestPyPI instead of PyPI (recommended for first publish)
#   --build-only    Build the package without uploading
#   --skip-tests    Skip running tests before publishing
#   --no-clean      Don't clean previous builds
#   --help          Show this help message
#
# Example:
#   # Test on TestPyPI first
#   ./scripts/publish_to_pypi.sh --test
#
#   # Build and publish to production PyPI
#   ./scripts/publish_to_pypi.sh
#

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Default options
USE_TEST_PYPI=false
BUILD_ONLY=false
SKIP_TESTS=false
CLEAN_BUILD=true

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --test)
            USE_TEST_PYPI=true
            shift
            ;;
        --build-only)
            BUILD_ONLY=true
            shift
            ;;
        --skip-tests)
            SKIP_TESTS=true
            shift
            ;;
        --no-clean)
            CLEAN_BUILD=false
            shift
            ;;
        --help)
            head -30 "$0" | grep -E "^#" | sed 's/^# //' | sed 's/^#//'
            exit 0
            ;;
        *)
            echo -e "${RED}Unknown option: $1${NC}"
            exit 1
            ;;
    esac
done

cd "$PROJECT_ROOT"

echo -e "${BLUE}================================================${NC}"
echo -e "${BLUE}  Graph of Marks - PyPI Publishing Script${NC}"
echo -e "${BLUE}================================================${NC}"
echo ""

# Get current version
VERSION=$(python -c "import gom; print(gom.__version__)" 2>/dev/null || echo "unknown")
echo -e "${GREEN}Package version: ${VERSION}${NC}"
echo ""

# Step 1: Install build dependencies
echo -e "${YELLOW}[1/6] Installing build dependencies...${NC}"
pip install --quiet --upgrade build twine

# Step 2: Run tests (optional)
if [ "$SKIP_TESTS" = false ]; then
    echo -e "${YELLOW}[2/6] Running tests...${NC}"
    if [ -d "tests" ]; then
        pip install --quiet pytest
        python -m pytest tests/ -v --tb=short
        echo -e "${GREEN}Tests passed!${NC}"
    else
        echo -e "${YELLOW}No tests directory found, skipping...${NC}"
    fi
else
    echo -e "${YELLOW}[2/6] Skipping tests (--skip-tests flag)${NC}"
fi

# Step 3: Clean old builds
if [ "$CLEAN_BUILD" = true ]; then
    echo -e "${YELLOW}[3/6] Cleaning old builds...${NC}"
    rm -rf dist/ build/ src/*.egg-info/
    echo -e "${GREEN}Cleaned!${NC}"
else
    echo -e "${YELLOW}[3/6] Skipping clean (--no-clean flag)${NC}"
fi

# Step 4: Build the package
echo -e "${YELLOW}[4/6] Building package...${NC}"
python -m build --sdist --wheel

echo -e "${GREEN}Build complete!${NC}"
ls -la dist/
echo ""

# Step 5: Validate the package
echo -e "${YELLOW}[5/6] Validating package with twine...${NC}"
python -m twine check dist/*
echo -e "${GREEN}Validation passed!${NC}"
echo ""

# Step 6: Upload (optional)
if [ "$BUILD_ONLY" = true ]; then
    echo -e "${YELLOW}[6/6] Build-only mode, skipping upload${NC}"
    echo ""
    echo -e "${GREEN}================================================${NC}"
    echo -e "${GREEN}Build artifacts are in: dist/${NC}"
    echo -e "${GREEN}To upload manually:${NC}"
    echo -e "  TestPyPI: python -m twine upload --repository testpypi dist/*"
    echo -e "  PyPI:     python -m twine upload dist/*"
    echo -e "${GREEN}================================================${NC}"
else
    if [ "$USE_TEST_PYPI" = true ]; then
        echo -e "${YELLOW}[6/6] Uploading to TestPyPI...${NC}"
        echo ""
        echo -e "${YELLOW}NOTE: You will be prompted for your TestPyPI credentials.${NC}"
        echo -e "${YELLOW}Get an API token from: https://test.pypi.org/manage/account/token/${NC}"
        echo ""
        python -m twine upload --repository testpypi dist/*
        echo ""
        echo -e "${GREEN}================================================${NC}"
        echo -e "${GREEN}Uploaded to TestPyPI!${NC}"
        echo -e "${GREEN}Install with:${NC}"
        echo -e "  pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ graph-of-marks"
        echo -e "${GREEN}================================================${NC}"
    else
        echo -e "${YELLOW}[6/6] Uploading to PyPI...${NC}"
        echo ""
        echo -e "${RED}⚠️  WARNING: This will publish to PRODUCTION PyPI!${NC}"
        echo -e "${RED}⚠️  Make sure version ${VERSION} is correct!${NC}"
        echo ""
        read -p "Are you sure you want to publish to PyPI? (yes/no): " confirm
        if [ "$confirm" = "yes" ]; then
            echo ""
            echo -e "${YELLOW}NOTE: You will be prompted for your PyPI credentials.${NC}"
            echo -e "${YELLOW}Get an API token from: https://pypi.org/manage/account/token/${NC}"
            echo ""
            python -m twine upload dist/*
            echo ""
            echo -e "${GREEN}================================================${NC}"
            echo -e "${GREEN}Published to PyPI!${NC}"
            echo -e "${GREEN}Install with:${NC}"
            echo -e "  pip install graph-of-marks"
            echo -e "${GREEN}================================================${NC}"
        else
            echo -e "${YELLOW}Upload cancelled.${NC}"
        fi
    fi
fi

echo ""
echo -e "${GREEN}Done!${NC}"
