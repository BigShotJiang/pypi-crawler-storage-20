"""Tests for ccda-cli."""
