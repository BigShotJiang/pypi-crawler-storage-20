# Contributing

Thanks for your interest in contributing!

## Workflow
1. Fork the repo
2. Create a feature branch
3. Open a PR against `main`
4. Ensure tests pass
5. Await review

All changes require maintainer approval before merge.

## Issues
- Bug reports welcome
- Feature requests welcome

