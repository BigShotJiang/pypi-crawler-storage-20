<h1 align="center">
  🖥️ pueue-tui
</h1>

<h4 align="center">A terminal UI for monitoring <a href="https://github.com/Nukesor/pueue">pueue</a> tasks.</h4>

<p align="center">
  <a href="https://pypi.org/project/pueue-tui/">
    <img src="https://img.shields.io/pypi/v/pueue-tui?color=blue" alt="PyPI">
  </a>
  <a href="https://pypi.org/project/pueue-tui/">
    <img src="https://img.shields.io/pypi/pyversions/pueue-tui" alt="Python">
  </a>
  <a href="https://github.com/marcinmiklitz/pueue-tui/blob/main/LICENSE">
    <img src="https://img.shields.io/github/license/marcinmiklitz/pueue-tui" alt="License">
  </a>
</p>

<p align="center">
  <a href="#features">Features</a> •
  <a href="#installation">Installation</a> •
  <a href="#usage">Usage</a> •
  <a href="#keybindings">Keybindings</a> •
  <a href="#compatibility">Compatibility</a>
</p>

---

![pueue-tui demo](https://raw.githubusercontent.com/marcinmiklitz/pueue-tui/main/assets/demo.gif)

Tired of running `pueue status` over and over? pueue-tui gives you a live-updating dashboard for your running, queued, and completed tasks.

## Features

- 📊 **Live dashboard** — auto-refreshing view of all tasks
- ⏱️ **Timing info** — start time, end time, and duration at a glance
- 🔍 **Command preview** — select a row to see the full command
- ⌨️ **Keyboard shortcuts** — quick actions without leaving the terminal

## Installation
```bash
# Recommended
pipx install pueue-tui

# Or with pip
pip install pueue-tui
```

## Usage
```bash
# Start with default 2-second refresh
pueue-tui

# Custom refresh interval  
pueue-tui -r 1    # 1 second
pueue-tui -r 5    # 5 seconds

# Show more completed tasks
pueue-tui --completed 20
```

## Keybindings

| Key | Action |
|-----|--------|
| `q` | Quit |
| `r` | Refresh now |
| `c` | Clean finished tasks |

## Compatibility

**Tested with pueue v4.x**

pueue-tui parses the JSON output from `pueue status --json`. The JSON structure may differ between major pueue versions. If you encounter issues with a different version, please [open an issue](https://github.com/marcinmiklitz/pueue-tui/issues).

## Requirements

- Python 3.10+
- [pueue](https://github.com/Nukesor/pueue) daemon running

## Contributing

Contributions welcome! Feel free to open issues or submit PRs.

## License

[MIT](LICENSE)