"""Tests for pueue-tui core functions."""

from pueue_tui.core import (
    format_duration,
    get_task_times,
    parse_datetime,
    parse_task_status,
    truncate_command,
)


class TestParseTaskStatus:
    """Tests for parse_task_status function."""

    def test_running_string(self):
        """Test string Running status (older pueue format)."""
        task = {"status": "Running"}
        status, style = parse_task_status(task)
        assert status == "Running"
        assert "green" in style

    def test_running_dict(self):
        """Test dict Running status (pueue v4 format)."""
        task = {
            "status": {
                "Running": {
                    "enqueued_at": "2026-01-13T21:27:06.919823Z",
                    "start": "2026-01-13T21:27:07.181585Z",
                }
            }
        }
        status, style = parse_task_status(task)
        assert status == "Running"
        assert "green" in style

    def test_queued_string(self):
        """Test string Queued status."""
        task = {"status": "Queued"}
        status, style = parse_task_status(task)
        assert status == "Queued"
        assert "yellow" in style

    def test_done_success(self):
        """Test Done with Success result (pueue v4 format)."""
        task = {
            "status": {
                "Done": {
                    "enqueued_at": "2026-01-13T00:05:00.805397Z",
                    "start": "2026-01-13T00:05:00.930792Z",
                    "end": "2026-01-13T00:05:01.842580Z",
                    "result": "Success",
                }
            }
        }
        status, style = parse_task_status(task)
        assert status == "Success"
        assert "green" in style

    def test_done_failed(self):
        """Test Done with Failed result."""
        task = {
            "status": {
                "Done": {
                    "start": "2026-01-01T00:00:00Z",
                    "end": "2026-01-01T00:00:01Z",
                    "result": "Failed",
                }
            }
        }
        status, style = parse_task_status(task)
        assert status == "Failed"
        assert "red" in style

    def test_done_failed_with_code(self):
        """Test Done with Failed and exit code."""
        task = {
            "status": {
                "Done": {
                    "start": "2026-01-01T00:00:00Z",
                    "end": "2026-01-01T00:00:01Z",
                    "result": {"Failed": 127},
                }
            }
        }
        status, style = parse_task_status(task)
        assert status == "Failed"
        assert "red" in style

    def test_stashed(self):
        """Test Stashed status."""
        task = {"status": "Stashed"}
        status, style = parse_task_status(task)
        assert status == "Stashed"

    def test_unknown_status(self):
        """Test unknown status returns string representation."""
        task = {"status": "SomeNewStatus"}
        status, style = parse_task_status(task)
        assert status == "SomeNewStatus"


class TestGetTaskTimes:
    """Tests for get_task_times function."""

    def test_running_v4_format(self):
        """Test extracting times from Running dict (pueue v4)."""
        task = {
            "status": {
                "Running": {
                    "enqueued_at": "2026-01-13T21:27:06.919823Z",
                    "start": "2026-01-13T21:27:07.181585Z",
                }
            }
        }
        start, end = get_task_times(task)
        assert start == "2026-01-13T21:27:07.181585Z"
        assert end is None

    def test_done_v4_format(self):
        """Test extracting times from Done dict (pueue v4)."""
        task = {
            "status": {
                "Done": {
                    "enqueued_at": "2026-01-13T00:05:00.805397Z",
                    "start": "2026-01-13T00:05:00.930792Z",
                    "end": "2026-01-13T00:05:01.842580Z",
                    "result": "Success",
                }
            }
        }
        start, end = get_task_times(task)
        assert start == "2026-01-13T00:05:00.930792Z"
        assert end == "2026-01-13T00:05:01.842580Z"

    def test_queued_no_times(self):
        """Test queued task has no times."""
        task = {"status": "Queued"}
        start, end = get_task_times(task)
        assert start is None
        assert end is None


class TestTruncateCommand:
    """Tests for truncate_command function."""

    def test_short_command_unchanged(self):
        """Short commands should not be truncated."""
        cmd = "sleep 30"
        assert truncate_command(cmd) == "sleep 30"

    def test_long_command_truncated(self):
        """Long commands should be truncated with ellipsis prefix."""
        cmd = "env VERY_LONG_VAR=value /opt/homebrew/bin/uv run python scripts/fetch.py"
        result = truncate_command(cmd, max_len=50)
        assert len(result) == 50
        assert result.startswith("env")
        assert result.endswith("fetch.py")

    def test_newlines_removed(self):
        """Newlines should be replaced with spaces."""
        cmd = "echo 'line1'\necho 'line2'"
        result = truncate_command(cmd)
        assert "\n" not in result

    def test_whitespace_stripped(self):
        """Leading/trailing whitespace should be stripped."""
        cmd = "  sleep 10  "
        assert truncate_command(cmd) == "sleep 10"

    def test_exact_max_len(self):
        """Command exactly at max_len should not be truncated."""
        cmd = "a" * 50
        assert truncate_command(cmd, max_len=50) == cmd


class TestFormatDuration:
    """Tests for format_duration function."""

    def test_seconds(self):
        """Test formatting seconds."""
        assert format_duration(30) == "30s"
        assert format_duration(1) == "1s"

    def test_minutes(self):
        """Test formatting minutes and seconds."""
        assert format_duration(90) == "1m 30s"
        assert format_duration(120) == "2m 0s"

    def test_hours(self):
        """Test formatting hours and minutes."""
        assert format_duration(3661) == "1h 1m"
        assert format_duration(7200) == "2h 0m"

    def test_none(self):
        """Test None input."""
        assert format_duration(None) == "-"


class TestParseDatetime:
    """Tests for parse_datetime function."""

    def test_iso_format_with_z(self):
        """Test ISO format with Z suffix."""
        dt = parse_datetime("2026-01-13T21:27:07.181585Z")
        assert dt is not None
        assert dt.year == 2026
        assert dt.month == 1
        assert dt.day == 13

    def test_iso_format_without_z(self):
        """Test ISO format without Z suffix."""
        dt = parse_datetime("2026-01-13T21:27:07.181585")
        assert dt is not None
        assert dt.year == 2026

    def test_none_input(self):
        """Test None input returns None."""
        assert parse_datetime(None) is None

    def test_unix_timestamp(self):
        """Test unix timestamp as int."""
        dt = parse_datetime(1736800000)
        assert dt is not None

    def test_invalid_string(self):
        """Test invalid string returns None."""
        assert parse_datetime("not a date") is None
