#!/usr/bin/env python3
"""
pueue-tui: A live terminal UI for monitoring pueue tasks.

Usage:
    pueue-tui [--refresh SECONDS]

Requirements:
    pip install textual
"""

import json
import subprocess
import sys
from argparse import ArgumentParser
from datetime import datetime

from textual.app import App, ComposeResult
from textual.containers import Container, Vertical
from textual.reactive import reactive
from textual.widgets import DataTable, Footer, Header, Static

from pueue_tui.core import (
    format_duration,
    format_time_smart,
    get_task_duration,
    get_task_times,
    parse_datetime,
    parse_task_status,
    truncate_command,
)

__version__ = "0.1.0"
SUPPORTED_PUEUE_MAJOR = 4


def check_pueue_version() -> bool:
    """Check pueue version and warn if unsupported."""
    try:
        result = subprocess.run(
            ["pueue", "--version"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if result.returncode != 0:
            print(
                "⚠️  Could not detect pueue version. Is pueue installed?",
                file=sys.stderr,
            )
            return False

        # Output: "pueue 4.0.2"
        version_str = result.stdout.strip().split()[-1]
        major = int(version_str.split(".")[0])

        if major < SUPPORTED_PUEUE_MAJOR:
            print(
                f"⚠️  Warning: pueue-tui is built for pueue v{SUPPORTED_PUEUE_MAJOR}.x, "
                f"but you have v{version_str}. Things may not work correctly.",
                file=sys.stderr,
            )
        elif major > SUPPORTED_PUEUE_MAJOR:
            print(
                f"⚠️  Warning: pueue-tui is built for pueue v{SUPPORTED_PUEUE_MAJOR}.x, "
                f"but you have v{version_str}. Please report any issues at "
                f"https://github.com/marcinmiklitz/pueue-tui/issues",
                file=sys.stderr,
            )
        return True

    except FileNotFoundError:
        print(
            "❌ pueue not found. Please install pueue first: https://github.com/Nukesor/pueue",
            file=sys.stderr,
        )
        return False
    except Exception as e:
        print(f"⚠️  Could not check pueue version: {e}", file=sys.stderr)
        return True  # Continue anyway


def get_pueue_status() -> dict | None:
    """Fetch pueue status as JSON."""
    try:
        result = subprocess.run(
            ["pueue", "status", "--json"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if result.returncode == 0:
            return json.loads(result.stdout)
    except (subprocess.TimeoutExpired, json.JSONDecodeError, FileNotFoundError):
        pass
    return None


class PueueTUI(App):
    """A TUI for monitoring pueue tasks."""

    TITLE = f"pueue-tui v{__version__}"

    CSS = """
    Screen {
        background: $surface;
    }
    
    #running-container {
        height: auto;
        max-height: 50%;
        margin-bottom: 1;
    }
    
    #completed-container {
        height: auto;
    }
    
    .section-title {
        background: $primary;
        color: $text;
        padding: 0 1;
        text-style: bold;
        width: 100%;
    }
    
    .section-title-running {
        background: $success;
    }
    
    .section-title-queued {
        background: $warning;
    }
    
    .section-title-completed {
        background: $primary-darken-2;
    }
    
    DataTable {
        height: auto;
        max-height: 15;
    }
    
    #bottom-bar {
        dock: bottom;
        height: auto;
        max-height: 5;
    }
    
    #command-bar {
        height: auto;
        min-height: 1;
        max-height: 3;
        background: $surface-darken-2;
        color: $text;
        padding: 0 1;
    }
    
    #status-bar {
        height: 1;
        background: $surface-darken-1;
        color: $text-muted;
        padding: 0 1;
    }
    
    .empty-message {
        color: $text-muted;
        padding: 0 1;
        text-style: italic;
    }
    """

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("r", "refresh", "Refresh"),
        ("c", "clean", "Clean finished"),
    ]

    last_update = reactive("")

    def __init__(self, refresh_interval: float = 2.0, max_completed: int = 10):
        super().__init__()
        self.refresh_interval = refresh_interval
        self.max_completed = max_completed
        self.tasks_by_id: dict[str, dict] = {}  # Store full task data for lookup

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)

        with Vertical():
            with Container(id="running-container"):
                yield Static(
                    "⏳ Running Tasks", classes="section-title section-title-running"
                )
                yield DataTable(id="running-table", cursor_type="row")

            with Container(id="queued-container"):
                yield Static(
                    "📋 Queued Tasks", classes="section-title section-title-queued"
                )
                yield DataTable(id="queued-table", cursor_type="row")

            with Container(id="completed-container"):
                yield Static(
                    f"✓ Last {self.max_completed} Completed",
                    classes="section-title section-title-completed",
                    id="completed-title",
                )
                yield DataTable(id="completed-table", cursor_type="row")

        with Container(id="bottom-bar"):
            yield Static("Select a task to see full command", id="command-bar")
            yield Static("", id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        """Set up tables and start refresh timer."""
        # Running table
        running_table = self.query_one("#running-table", DataTable)
        running_table.add_columns("ID", "Started", "Elapsed", "Group", "Command")

        # Queued table
        queued_table = self.query_one("#queued-table", DataTable)
        queued_table.add_columns("ID", "Queued", "Waiting", "Group", "Command")

        # Completed table
        completed_table = self.query_one("#completed-table", DataTable)
        completed_table.add_columns(
            "ID", "Started", "Finished", "Duration", "Group", "Status", "Command"
        )

        # Initial refresh and set timer
        self.refresh_data()
        self.set_interval(self.refresh_interval, self.refresh_data)

    def refresh_data(self) -> None:
        """Fetch and display pueue status."""
        data = get_pueue_status()

        status_bar = self.query_one("#status-bar", Static)

        if data is None:
            status_bar.update("⚠ Could not connect to pueue daemon")
            return

        tasks = data.get("tasks", {})

        # Store all tasks for command lookup
        self.tasks_by_id = {str(tid): task for tid, task in tasks.items()}

        # Categorize tasks
        running = []
        queued = []
        completed = []

        for task_id, task in tasks.items():
            status_name, _ = parse_task_status(task)
            task["_id"] = task_id
            task["_status_name"] = status_name

            if status_name == "Running":
                running.append(task)
            elif status_name in ("Queued", "Stashed", "Paused", "Locked"):
                queued.append(task)
            else:
                completed.append(task)

        # Sort by ID
        running.sort(key=lambda t: int(t["_id"]))
        queued.sort(key=lambda t: int(t["_id"]))
        completed.sort(key=lambda t: int(t["_id"]), reverse=True)  # Newest first

        # Update running table
        running_table = self.query_one("#running-table", DataTable)
        running_cursor = running_table.cursor_row
        running_table.clear()
        for task in running:
            start_str, _ = get_task_times(task)
            start_dt = parse_datetime(start_str)
            start_time = format_time_smart(start_dt)

            running_table.add_row(
                task["_id"],
                start_time,
                get_task_duration(task),
                task.get("group", "-"),
                truncate_command(task.get("command", "")),
            )
        if running and running_cursor < len(running):
            running_table.move_cursor(row=running_cursor)

        # Update queued table
        queued_table = self.query_one("#queued-table", DataTable)
        queued_cursor = queued_table.cursor_row
        queued_table.clear()
        for task in queued[: self.max_completed]:
            created_str = task.get("created_at")
            created_dt = parse_datetime(created_str)
            queued_time = format_time_smart(created_dt)

            # Calculate waiting time
            if created_dt:
                waiting_secs = (
                    datetime.now().astimezone() - created_dt
                ).total_seconds()
                waiting = format_duration(waiting_secs)
            else:
                waiting = "-"

            queued_table.add_row(
                task["_id"],
                queued_time,
                waiting,
                task.get("group", "-"),
                truncate_command(task.get("command", "")),
            )
        if queued and queued_cursor < len(queued[: self.max_completed]):
            queued_table.move_cursor(row=queued_cursor)

        # Update completed table
        completed_table = self.query_one("#completed-table", DataTable)
        completed_cursor = completed_table.cursor_row
        completed_table.clear()
        for task in completed[: self.max_completed]:
            start_str, end_str = get_task_times(task)

            start_time = "-"
            start_dt = parse_datetime(start_str)
            if start_dt:
                start_time = start_dt.strftime("%Y-%m-%d %H:%M")

            end_time = "-"
            end_dt = parse_datetime(end_str)
            if end_dt:
                end_time = end_dt.strftime("%Y-%m-%d %H:%M")

            status_name, _ = parse_task_status(task)
            completed_table.add_row(
                task["_id"],
                start_time,
                end_time,
                get_task_duration(task),
                task.get("group", "-"),
                status_name,
                truncate_command(task.get("command", "")),
            )
        if completed and completed_cursor < len(completed[: self.max_completed]):
            completed_table.move_cursor(row=completed_cursor)

        # Update status bar
        now = datetime.now().strftime("%H:%M:%S")
        status_bar.update(
            f"Running: {len(running)} | Queued: {len(queued)} | "
            f"Completed: {len(completed)} | Updated: {now}"
        )

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        """Show full command when a row is highlighted."""
        command_bar = self.query_one("#command-bar", Static)

        if event.row_key is None:
            command_bar.update("Select a task to see full command")
            return

        # Get the task ID from the first cell of the row
        try:
            table = event.data_table
            row_data = table.get_row(event.row_key)
            if row_data:
                task_id = str(row_data[0])
                if task_id in self.tasks_by_id:
                    full_cmd = self.tasks_by_id[task_id].get("command", "")
                    command_bar.update(f"[bold]#{task_id}:[/bold] {full_cmd}")
                else:
                    command_bar.update(f"Task #{task_id}")
        except Exception:
            command_bar.update("Select a task to see full command")

    def action_refresh(self) -> None:
        """Manual refresh."""
        self.refresh_data()

    def action_clean(self) -> None:
        """Clean finished tasks."""
        subprocess.run(["pueue", "clean"], capture_output=True)
        self.refresh_data()


def main():
    parser = ArgumentParser(description="TUI for monitoring pueue tasks")
    parser.add_argument(
        "-r",
        "--refresh",
        type=float,
        default=5.0,
        help="Refresh interval in seconds (default: 5)",
    )
    parser.add_argument(
        "-c",
        "--completed",
        type=int,
        default=10,
        help="Number of completed tasks to show (default: 10)",
    )
    parser.add_argument(
        "-v", "--version", action="version", version=f"pueue-tui {__version__}"
    )
    args = parser.parse_args()

    # Check pueue is installed and version is compatible
    check_pueue_version()

    app = PueueTUI(refresh_interval=args.refresh, max_completed=args.completed)
    app.run()


if __name__ == "__main__":
    main()
