"""Core utility functions for pueue-tui.

These functions are pure and don't depend on textual,
making them easy to test independently.
"""

from datetime import datetime


def parse_task_status(task: dict) -> tuple[str, str]:
    """
    Parse task status into (status_name, style).

    Handles both pueue v3 (string statuses) and v4 (dict statuses) formats.

    Args:
        task: Task dict from pueue status --json

    Returns:
        Tuple of (status_name, textual_style)
    """
    status = task.get("status")

    # String statuses
    if status == "Running":
        return "Running", "bold green"
    elif status == "Queued":
        return "Queued", "yellow"
    elif status == "Stashed":
        return "Stashed", "dim"
    elif status == "Paused":
        return "Paused", "yellow"
    elif status == "Locked":
        return "Locked", "yellow"

    # Dict statuses (pueue v4 format)
    elif isinstance(status, dict):
        # Running in v4 might be {"Running": {...}} with start time etc
        if "Running" in status:
            return "Running", "bold green"
        elif "Queued" in status:
            return "Queued", "yellow"
        elif "Stashed" in status:
            return "Stashed", "dim"
        elif "Paused" in status:
            return "Paused", "yellow"
        elif "Locked" in status:
            return "Locked", "yellow"
        elif "Done" in status:
            done_info = status["Done"]
            # pueue v4: Done contains {enqueued_at, start, end, result}
            if isinstance(done_info, dict):
                result = done_info.get("result", "")
                if result == "Success":
                    return "Success", "green"
                elif result == "Failed" or (
                    isinstance(result, dict) and "Failed" in result
                ):
                    return "Failed", "bold red"
                else:
                    return str(result), "yellow"
            # Older format: Done is just "Success" or "Failed"
            elif done_info == "Success":
                return "Success", "green"
            elif done_info == "Failed":
                return "Failed", "bold red"
            else:
                return str(done_info), "red"

    return str(status), "white"


def get_task_times(task: dict) -> tuple[str | None, str | None]:
    """
    Extract start and end times from task, handling nested status structure.

    Args:
        task: Task dict from pueue status --json

    Returns:
        Tuple of (start_time_str, end_time_str) - raw datetime strings from pueue
    """
    status = task.get("status")

    # For running tasks - check both string and dict format
    if status == "Running":
        return task.get("start"), None

    if isinstance(status, dict):
        # v4 Running format: {"Running": {"start": "..."}}
        if "Running" in status:
            running_info = status["Running"]
            if isinstance(running_info, dict):
                return running_info.get("start"), None
            return task.get("start"), None

        # Completed tasks: {"Done": {"start": "...", "end": "..."}}
        if "Done" in status:
            done_info = status["Done"]
            if isinstance(done_info, dict):
                return done_info.get("start"), done_info.get("end")

    # Fallback to root level
    return task.get("start"), task.get("end")


def format_duration(seconds: float | None) -> str:
    """
    Format duration in human readable form.

    Args:
        seconds: Duration in seconds, or None

    Returns:
        Formatted string like "30s", "1m 30s", "1h 5m", or "-" for None
    """
    if seconds is None:
        return "-"

    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    elif seconds < 3600:
        mins, secs = divmod(seconds, 60)
        return f"{mins}m {secs}s"
    else:
        hours, remainder = divmod(seconds, 3600)
        mins, secs = divmod(remainder, 60)
        return f"{hours}h {mins}m"


def parse_datetime(dt_value) -> datetime | None:
    """
    Parse datetime from various formats pueue might use.

    Handles:
    - ISO format strings (with or without Z suffix)
    - Unix timestamps (int/float)
    - Dict with secs/secs_since_epoch

    Args:
        dt_value: Datetime value in various formats

    Returns:
        datetime object or None if parsing fails
    """
    if dt_value is None:
        return None

    # Handle if it's already a dict with secs/nanos (pueue v4 format)
    if isinstance(dt_value, dict):
        secs = dt_value.get("secs") or dt_value.get("secs_since_epoch")
        if secs:
            return datetime.fromtimestamp(secs).astimezone()
        return None

    # Handle string formats
    if isinstance(dt_value, str):
        # Try various ISO formats
        for fmt in [
            "%Y-%m-%dT%H:%M:%S%.f%z",
            "%Y-%m-%dT%H:%M:%S%z",
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S",
        ]:
            try:
                return datetime.strptime(dt_value, fmt).astimezone()
            except ValueError:
                continue

        # Try fromisoformat with Z replacement
        try:
            return datetime.fromisoformat(dt_value.replace("Z", "+00:00"))
        except ValueError:
            pass

    # Handle unix timestamp as int/float
    if isinstance(dt_value, (int, float)):
        return datetime.fromtimestamp(dt_value).astimezone()

    return None


def get_task_duration(task: dict) -> str:
    """
    Calculate task duration or elapsed time.

    For running tasks, calculates elapsed time from start.
    For completed tasks, calculates duration from start to end.

    Args:
        task: Task dict from pueue status --json

    Returns:
        Formatted duration string
    """
    start_str, end_str = get_task_times(task)

    start_dt = parse_datetime(start_str)
    end_dt = parse_datetime(end_str)

    if start_dt is None:
        return "-"

    try:
        if end_dt:
            duration = (end_dt - start_dt).total_seconds()
        else:
            duration = (datetime.now().astimezone() - start_dt).total_seconds()
        return format_duration(duration)
    except (ValueError, TypeError):
        return "-"


def truncate_command(cmd: str, max_len: int = 80) -> str:
    """
    Truncate command for display, keeping it readable.

    Shows the start and end of the command, with ellipsis in the middle.

    Args:
        cmd: Full command string
        max_len: Maximum length of output

    Returns:
        Truncated command with ellipsis if needed
    """
    cmd = cmd.replace("\n", " ").strip()

    if len(cmd) <= max_len:
        return cmd

    # Show start and end, ellipsis in middle
    # Give more space to the end (usually contains the script name)
    start_len = max_len // 3
    end_len = max_len - start_len - 1  # -1 for ellipsis

    return cmd[:start_len] + "…" + cmd[-end_len:]


def format_time_smart(dt: datetime | None) -> str:
    """Format datetime - show only time if today, otherwise include date."""
    if dt is None:
        return "-"

    now = datetime.now().astimezone()
    if dt.date() == now.date():
        return dt.strftime("%H:%M:%S")
    else:
        return dt.strftime("%Y-%m-%d %H:%M")
