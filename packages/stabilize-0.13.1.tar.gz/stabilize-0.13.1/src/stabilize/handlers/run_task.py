"""
RunTaskHandler - executes tasks.

This is the handler that actually runs task implementations.
It handles execution, retries, timeouts, and result processing.

Uses bulkman for bulkhead pattern (per-task-type isolation) and
resilient_circuit for circuit breaker protection.
"""

from __future__ import annotations

import logging
import os
from datetime import timedelta
from typing import TYPE_CHECKING

from resilient_circuit import ExponentialDelay

from stabilize.errors import TaskTimeoutError, is_transient
from stabilize.handlers.base import StabilizeHandler
from stabilize.models.status import WorkflowStatus
from stabilize.queue.messages import (
    CompleteTask,
    PauseTask,
    RunTask,
)
from stabilize.resilience.bulkheads import TaskBulkheadManager
from stabilize.resilience.circuits import WorkflowCircuitFactory
from stabilize.resilience.config import ResilienceConfig
from stabilize.resilience.executor import execute_with_resilience
from stabilize.resilience.process_executor import ProcessIsolatedTaskExecutor
from stabilize.tasks.interface import RetryableTask, Task
from stabilize.tasks.registry import TaskNotFoundError, TaskRegistry
from stabilize.tasks.result import TaskResult

if TYPE_CHECKING:
    from stabilize.models.stage import StageExecution
    from stabilize.models.task import TaskExecution
    from stabilize.persistence.store import WorkflowStore
    from stabilize.queue.queue import Queue

logger = logging.getLogger(__name__)

# Default timeout for tasks that don't specify one (5 minutes)
DEFAULT_TASK_TIMEOUT = timedelta(minutes=5)

# Exponential backoff for retries: 1s, 2s, 4s, 8s... capped at 60s with ±25% jitter
_BACKOFF = ExponentialDelay(
    min_delay=timedelta(seconds=1),
    max_delay=timedelta(seconds=60),
    factor=2,
    jitter=0.25,
)


class RunTaskHandler(StabilizeHandler[RunTask]):
    """
    Handler for RunTask messages.

    This is where tasks are actually executed. The handler:
    1. Resolves the task implementation
    2. Checks for cancellation/pause
    3. Checks for timeout
    4. Executes the task
    5. Processes the result
    """

    def __init__(
        self,
        queue: Queue,
        repository: WorkflowStore,
        task_registry: TaskRegistry,
        retry_delay: timedelta = timedelta(seconds=15),
        bulkhead_manager: TaskBulkheadManager | None = None,
        circuit_factory: WorkflowCircuitFactory | None = None,
    ) -> None:
        super().__init__(queue, repository, retry_delay)
        self.task_registry = task_registry

        # Check isolation mode
        self.isolation_mode = os.environ.get("STABILIZE_ISOLATION_MODE", "thread").lower()
        self.process_executor = ProcessIsolatedTaskExecutor() if self.isolation_mode == "process" else None

        # Initialize resilience components with defaults if not provided
        if bulkhead_manager is None or circuit_factory is None:
            config = ResilienceConfig.from_env()
            self.bulkhead_manager = bulkhead_manager or TaskBulkheadManager(config)
            self.circuit_factory = circuit_factory or WorkflowCircuitFactory(config)
        else:
            self.bulkhead_manager = bulkhead_manager
            self.circuit_factory = circuit_factory

    @property
    def message_type(self) -> type[RunTask]:
        return RunTask

    def handle(self, message: RunTask) -> None:
        """Handle the RunTask message."""

        def on_task(stage: StageExecution, task_model: TaskExecution) -> None:
            execution = stage.execution

            # Resolve task implementation
            try:
                task = self._resolve_task(message.task_type, task_model)
            except TaskNotFoundError as e:
                logger.error("Task type not found: %s", message.task_type)
                self._complete_with_error(stage, task_model, message, str(e))
                return

            # Check execution state
            if execution.is_canceled:
                self._handle_cancellation(stage, task_model, task, message)
                return

            if execution.status.is_complete:
                self.queue.push(
                    CompleteTask(
                        execution_type=message.execution_type,
                        execution_id=message.execution_id,
                        stage_id=message.stage_id,
                        task_id=message.task_id,
                        status=WorkflowStatus.CANCELED,
                    )
                )
                return

            if execution.status == WorkflowStatus.PAUSED:
                self.queue.push(
                    PauseTask(
                        execution_type=message.execution_type,
                        execution_id=message.execution_id,
                        stage_id=message.stage_id,
                        task_id=message.task_id,
                    )
                )
                return

            # Check for manual skip
            if stage.context.get("manualSkip"):
                self.queue.push(
                    CompleteTask(
                        execution_type=message.execution_type,
                        execution_id=message.execution_id,
                        stage_id=message.stage_id,
                        task_id=message.task_id,
                        status=WorkflowStatus.SKIPPED,
                    )
                )
                return

            # Execute the task with timeout enforcement
            try:
                timeout = self._get_task_timeout(stage, task)
                result = self._execute_with_timeout(task, stage, timeout, message)
                self._process_result(stage, task_model, result, message)
            except TaskTimeoutError as e:
                logger.info("Task %s timed out: %s", task_model.name, e)
                timeout_result: TaskResult | None = task.on_timeout(stage) if hasattr(task, "on_timeout") else None
                if timeout_result is None:
                    self._complete_with_error(stage, task_model, message, str(e))
                else:
                    self._process_result(stage, task_model, timeout_result, message)
            except Exception as e:
                logger.error(
                    "Error executing task %s: %s",
                    task_model.name,
                    e,
                    exc_info=True,
                )
                self._handle_exception(stage, task_model, task, message, e)

        self.with_task(message, on_task)

    def _resolve_task(
        self,
        task_type: str,
        task_model: TaskExecution,
    ) -> Task:
        """Resolve the task implementation."""
        # Try by class name first
        try:
            return self.task_registry.get_by_class(task_model.implementing_class)
        except TaskNotFoundError:
            pass

        # Try by type name
        return self.task_registry.get(task_type)

    def _get_task_timeout(
        self,
        stage: StageExecution,
        task: Task,
    ) -> timedelta:
        """Get the timeout for a task.

        Returns the dynamic timeout for RetryableTask or default timeout for others.
        """
        if isinstance(task, RetryableTask):
            return task.get_dynamic_timeout(stage)
        return DEFAULT_TASK_TIMEOUT

    def _execute_with_timeout(
        self,
        task: Task,
        stage: StageExecution,
        timeout: timedelta,
        message: RunTask,
    ) -> TaskResult:
        """Execute a task with timeout enforcement via bulkhead.

        Uses bulkhead for thread pool management and circuit breaker for
        failure protection. Runs the task through the appropriate bulkhead
        based on task type.

        Args:
            task: The task to execute
            stage: The stage execution context
            timeout: Maximum time allowed for execution
            message: The RunTask message (for task type info)

        Returns:
            The task result

        Raises:
            TaskTimeoutError: If the task exceeds the timeout
            TransientError: If bulkhead is full or circuit is open
        """
        task_name = getattr(task, "name", type(task).__name__)
        execution_id = stage.execution.id if stage.execution else None

        # Get circuit breaker for this workflow + task type
        circuit = self.circuit_factory.get_circuit(
            workflow_execution_id=execution_id or "unknown",
            task_type=message.task_type,
        )

        # Define the execution function (process-isolated or direct)
        def execute_task(s: StageExecution) -> TaskResult:
            if self.process_executor:
                # Update timeout for process executor to match task timeout
                self.process_executor.timeout_seconds = timeout.total_seconds()
                return self.process_executor.execute(task, s)
            return task.execute(s)

        # Execute through bulkhead with circuit breaker protection
        return execute_with_resilience(
            bulkhead_manager=self.bulkhead_manager,
            circuit=circuit,
            task_type=message.task_type,
            func=execute_task,
            func_args=(stage,),
            timeout=timeout.total_seconds(),
            task_name=task_name,
            stage_id=stage.id,
            execution_id=execution_id,
        )

    def _process_result(
        self,
        stage: StageExecution,
        task_model: TaskExecution,
        result: TaskResult,
        message: RunTask,
    ) -> None:
        """Process a task result.

        Uses atomic transactions to ensure stage updates and message pushes
        are committed together. This prevents orphaned workflows where the
        stage is saved but the continuation message is lost.
        """
        # Store outputs in stage
        if result.context:
            stage.context.update(result.context)
        if result.outputs:
            stage.outputs.update(result.outputs)

        # Handle based on status - use atomic transactions
        if result.status == WorkflowStatus.RUNNING:
            # Task needs to be re-executed
            delay = self._get_backoff_period(stage, task_model, message)

            # Atomic: store stage + push message together
            with self.repository.transaction(self.queue) as txn:
                txn.store_stage(stage)
                txn.push_message(message, int(delay.total_seconds()))

            logger.debug(
                "Task %s still running, re-queuing with %s delay",
                task_model.name,
                delay,
            )

        elif result.status in {
            WorkflowStatus.SUCCEEDED,
            WorkflowStatus.REDIRECT,
            WorkflowStatus.SKIPPED,
            WorkflowStatus.FAILED_CONTINUE,
            WorkflowStatus.STOPPED,
        }:
            # Atomic: store stage + push CompleteTask together
            with self.repository.transaction(self.queue) as txn:
                txn.store_stage(stage)
                txn.push_message(
                    CompleteTask(
                        execution_type=message.execution_type,
                        execution_id=message.execution_id,
                        stage_id=message.stage_id,
                        task_id=message.task_id,
                        status=result.status,
                    )
                )

        elif result.status == WorkflowStatus.CANCELED:
            status = stage.failure_status(default=result.status)

            # Atomic: store stage + push CompleteTask together
            with self.repository.transaction(self.queue) as txn:
                txn.store_stage(stage)
                txn.push_message(
                    CompleteTask(
                        execution_type=message.execution_type,
                        execution_id=message.execution_id,
                        stage_id=message.stage_id,
                        task_id=message.task_id,
                        status=status,
                        original_status=result.status,
                    )
                )

        elif result.status == WorkflowStatus.TERMINAL:
            status = stage.failure_status(default=result.status)

            # Atomic: store stage + push CompleteTask together
            with self.repository.transaction(self.queue) as txn:
                txn.store_stage(stage)
                txn.push_message(
                    CompleteTask(
                        execution_type=message.execution_type,
                        execution_id=message.execution_id,
                        stage_id=message.stage_id,
                        task_id=message.task_id,
                        status=status,
                        original_status=result.status,
                    )
                )

        else:
            logger.warning("Unhandled task status: %s", result.status)
            self.repository.store_stage(stage)

    def _get_backoff_period(
        self,
        stage: StageExecution,
        task_model: TaskExecution,
        message: RunTask,
        attempt: int = 1,
    ) -> timedelta:
        """Calculate backoff period for retry with exponential backoff and jitter.

        Uses ExponentialDelay from resilient_circuit for consistent backoff
        calculation: 1s, 2s, 4s, 8s... capped at 60s with ±25% jitter.

        Args:
            stage: The stage execution context
            task_model: The task execution model
            message: The RunTask message
            attempt: The current attempt number (1-based)

        Returns:
            The calculated backoff period
        """
        # Try to get the task and use its backoff if it's a RetryableTask
        try:
            task = self._resolve_task(message.task_type, task_model)
            if isinstance(task, RetryableTask):
                elapsed = timedelta(milliseconds=self.current_time_millis() - (task_model.start_time or 0))
                return task.get_dynamic_backoff_period(stage, elapsed)
        except TaskNotFoundError:
            pass

        # Use ExponentialDelay from resilient_circuit for consistent backoff
        # for_attempt() returns seconds as float, convert to timedelta
        return timedelta(seconds=_BACKOFF.for_attempt(attempt))

    def _handle_cancellation(
        self,
        stage: StageExecution,
        task_model: TaskExecution,
        task: Task,
        message: RunTask,
    ) -> None:
        """Handle execution cancellation.

        Uses atomic transaction for stage update + message push.
        """
        result = task.on_cancel(stage) if hasattr(task, "on_cancel") else None
        if result:
            stage.context.update(result.context)
            stage.outputs.update(result.outputs)

        # Atomic: store stage (if modified) + push CompleteTask together
        with self.repository.transaction(self.queue) as txn:
            if result:
                txn.store_stage(stage)
            txn.push_message(
                CompleteTask(
                    execution_type=message.execution_type,
                    execution_id=message.execution_id,
                    stage_id=message.stage_id,
                    task_id=message.task_id,
                    status=WorkflowStatus.CANCELED,
                )
            )

    def _handle_exception(
        self,
        stage: StageExecution,
        task_model: TaskExecution,
        task: Task,
        message: RunTask,
        exception: Exception,
    ) -> None:
        """Handle task execution exception.

        Uses is_transient() to determine if the error should be retried.
        Transient errors are rescheduled with exponential backoff.
        Permanent errors are marked as terminal.

        Uses atomic transaction for stage update + message push.
        """
        # Check if exception is retryable (transient)
        if is_transient(exception):
            logger.info(
                "Task %s encountered transient error, will retry: %s",
                task_model.name,
                exception,
            )

            # Get attempt count from message or default to 1
            attempt = getattr(message, "attempt", 1) or 1
            max_attempts = 10  # Maximum retry attempts

            if attempt < max_attempts:
                # Reschedule with backoff
                delay = self._get_backoff_period(stage, task_model, message, attempt + 1)

                # Create new message with incremented attempt
                retry_message = RunTask(
                    execution_type=message.execution_type,
                    execution_id=message.execution_id,
                    stage_id=message.stage_id,
                    task_id=message.task_id,
                    task_type=message.task_type,
                )

                # Atomic: push retry message
                with self.repository.transaction(self.queue) as txn:
                    txn.push_message(retry_message, int(delay.total_seconds()))

                logger.debug(
                    "Task %s rescheduled for retry %d/%d with delay %s",
                    task_model.name,
                    attempt + 1,
                    max_attempts,
                    delay,
                )
                return

            # Max attempts exceeded - treat as terminal
            logger.warning(
                "Task %s exceeded max retry attempts (%d), marking as terminal",
                task_model.name,
                max_attempts,
            )

        # Permanent error or max retries exceeded - mark as terminal
        exception_details = {
            "details": {
                "error": str(exception),
                "errors": [str(exception)],
                "transient": is_transient(exception),
            }
        }

        stage.context["exception"] = exception_details
        task_model.task_exception_details["exception"] = exception_details

        status = stage.failure_status(default=WorkflowStatus.TERMINAL)

        # Atomic: store stage + push CompleteTask together
        with self.repository.transaction(self.queue) as txn:
            txn.store_stage(stage)
            txn.push_message(
                CompleteTask(
                    execution_type=message.execution_type,
                    execution_id=message.execution_id,
                    stage_id=message.stage_id,
                    task_id=message.task_id,
                    status=status,
                    original_status=WorkflowStatus.TERMINAL,
                )
            )

    def _complete_with_error(
        self,
        stage: StageExecution,
        task_model: TaskExecution,
        message: RunTask,
        error: str,
    ) -> None:
        """Complete task with an error.

        Uses atomic transaction for stage update + message push.
        """
        stage.context["exception"] = {
            "details": {"error": error},
        }

        # Atomic: store stage + push CompleteTask together
        with self.repository.transaction(self.queue) as txn:
            txn.store_stage(stage)
            txn.push_message(
                CompleteTask(
                    execution_type=message.execution_type,
                    execution_id=message.execution_id,
                    stage_id=message.stage_id,
                    task_id=message.task_id,
                    status=WorkflowStatus.TERMINAL,
                )
            )
