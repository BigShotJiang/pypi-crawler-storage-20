"""detLLM package module."""
