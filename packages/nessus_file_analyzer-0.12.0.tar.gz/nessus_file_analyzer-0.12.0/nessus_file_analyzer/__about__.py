# -*- coding: utf-8 -*-
"""
nessus file analyzer (NFA) by LimberDuck (pronounced *ˈlɪm.bɚ dʌk*) is a GUI
tool which enables you to parse multiple nessus files containing the results
of scans performed by using Nessus by (C) Tenable, Inc. and exports parsed
data to a Microsoft Excel Workbook for effortless analysis.
Copyright (C) 2019 Damian Krawczyk

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

import datetime

__all__ = [
    "__title__",
    "__icon__",
    "__summary__",
    "__uri__",
    "__version__",
    "__release_date__",
    "__author__",
    "__email__",
    "__license_name__",
    "__license_link__",
    "__copyright__",
]

__title__ = "nessus file analyzer (NFA) by LimberDuck"
__package_name__ = "nessus-file-analyzer"
__icon__ = "LimberDuck-NFA.ico"
__summary__ = (
    "nessus file analyzer (NFA) by LimberDuck is a GUI tool which enables you to parse nessus scan files from "
    "Nessus and Tenable.SC by (C) Tenable, Inc. and exports results to a spreadsheet file for "
    "effortless analysis."
)
__uri__ = "https://limberduck.org"
__version__ = "0.12.0"
__release_date__ = "2026.01.18"
__author__ = "Damian Krawczyk"
__email__ = "damian.krawczyk@limberduck.org"
__license_name__ = "GNU GPLv3"
__license_link__ = "https://www.gnu.org/licenses/gpl-3.0.en.html"
__copyright__ = "\N{COPYRIGHT SIGN} 2019-{} by {}".format(
    datetime.datetime.now().year, __author__
)
