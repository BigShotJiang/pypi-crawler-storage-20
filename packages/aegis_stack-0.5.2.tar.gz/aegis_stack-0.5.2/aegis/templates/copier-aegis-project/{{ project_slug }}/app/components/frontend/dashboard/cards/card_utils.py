"""
Card Utility Functions

Simple shared functions to eliminate code duplication across dashboard cards.
No inheritance or ABC complexity - just common functionality extracted.
"""

from collections.abc import Callable

import flet as ft
from app.components.frontend.controls import LabelText, SecondaryText
from app.services.system.models import ComponentStatus, ComponentStatusType

# Provider color mapping for AI service (shared across AI card and modal)
PROVIDER_COLORS = {
    "groq": ft.Colors.PURPLE,
    "openai": ft.Colors.GREEN,
    "anthropic": ft.Colors.ORANGE,
    "google": ft.Colors.BLUE,
    "mistral": ft.Colors.INDIGO,
    "cohere": ft.Colors.TEAL,
    "gemini": ft.Colors.BLUE,
}


def get_status_colors(component_data: ComponentStatus) -> tuple[str, str, str]:
    """
    Get status-aware colors for any card.

    Args:
        component_data: ComponentStatus containing status information

    Returns:
        Tuple of (primary_color, background_color, border_color)
    """
    status = component_data.status

    if status == ComponentStatusType.HEALTHY:
        return (ft.Colors.GREEN, ft.Colors.SURFACE, ft.Colors.GREEN)
    elif status == ComponentStatusType.INFO:
        return (ft.Colors.BLUE, ft.Colors.SURFACE, ft.Colors.BLUE)
    elif status == ComponentStatusType.WARNING:
        return (ft.Colors.ORANGE, ft.Colors.SURFACE, ft.Colors.ORANGE)
    else:  # UNHEALTHY
        return (ft.Colors.RED, ft.Colors.SURFACE, ft.Colors.RED)


def create_responsive_3_section_layout(
    left_content: ft.Control, middle_content: ft.Control, right_content: ft.Control
) -> ft.Row:
    """
    Create responsive 3-section card layout prioritizing middle section.

    Args:
        left_content: Technology badge content
        middle_content: Main metrics/data content (gets priority)
        right_content: Details/performance content

    Returns:
        Row with responsive flex layout
    """
    return ft.Row(
        [
            # Left: Tech badge (fixed width)
            ft.Container(
                content=left_content,
                width=200,  # Fixed width - honors TechBadge width
            ),
            ft.VerticalDivider(width=1, color=ft.Colors.OUTLINE_VARIANT),
            # Middle: Metrics (PRIORITY - gets most space and protection)
            ft.Container(
                content=middle_content,
                expand=5,  # ~50% of space, PRIORITY SECTION
                padding=ft.padding.all(16),
                width=300,  # Minimum width to keep metrics functional
            ),
            ft.VerticalDivider(width=1, color=ft.Colors.OUTLINE_VARIANT),
            # Right: Details (flexible, shrinks most aggressively)
            ft.Container(
                content=right_content,
                expand=3,  # ~30% of space, can shrink aggressively
                padding=ft.padding.all(16),
                width=150,  # Minimum width to prevent complete disappearance
            ),
        ]
    )


def create_stats_row(label: str, value: str, value_color: str | None = None) -> ft.Row:
    """
    Create a standardized statistics row with label and value.

    Args:
        label: The label text (e.g., "Active Workers")
        value: The value text (e.g., "2")
        value_color: Optional color for the value text

    Returns:
        Row with label and value properly aligned
    """
    value_control = LabelText(value)
    if value_color:
        value_control.color = value_color

    return ft.Row(
        [
            SecondaryText(f"{label}:"),
            value_control,
        ],
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
    )


def create_health_status_indicator(
    healthy_count: int, total_count: int
) -> ft.Container:
    """
    Create a circular health status indicator with color coding.

    Args:
        healthy_count: Number of healthy components
        total_count: Total number of components

    Returns:
        Container with circular progress and component count
    """
    percentage = 0.0 if total_count == 0 else healthy_count / total_count * 100

    # Color coding based on health percentage
    if percentage >= 100:
        color = ft.Colors.GREEN  # All healthy
        status_text = "Healthy"
        status_color = ft.Colors.GREEN
    elif percentage >= 70:
        color = ft.Colors.AMBER  # Mostly healthy
        status_text = "Warning"
        status_color = ft.Colors.ORANGE
    else:
        color = ft.Colors.RED  # Significant issues
        status_text = "Critical"
        status_color = ft.Colors.RED

    return ft.Container(
        content=ft.Row(
            [
                ft.ProgressRing(
                    value=percentage / 100,
                    color=color,
                    bgcolor=ft.Colors.with_opacity(0.3, color),
                    stroke_width=6,
                    width=50,
                    height=50,
                ),
                ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(
                                f"{healthy_count}/{total_count}",
                                size=18,
                                weight=ft.FontWeight.BOLD,
                                color=ft.Colors.ON_SURFACE,
                            ),
                            ft.Text(
                                status_text,
                                size=12,
                                color=status_color,
                                weight=ft.FontWeight.W_500,
                            ),
                        ],
                        spacing=2,
                    ),
                    margin=ft.margin.only(left=12),
                ),
            ],
            alignment=ft.MainAxisAlignment.START,
        ),
        padding=ft.padding.symmetric(horizontal=16, vertical=8),
    )


def create_progress_indicator(
    label: str, value: float, details: str, color: str
) -> ft.Container:
    """
    Create a progress indicator with label, progress bar, and details.

    Args:
        label: Label for the progress indicator
        value: Progress value (0-100)
        details: Additional details text
        color: Color for the progress bar

    Returns:
        Container with the progress indicator
    """
    return ft.Container(
        content=ft.Column(
            [
                ft.Text(
                    label,
                    size=12,
                    weight=ft.FontWeight.W_600,
                    color=ft.Colors.ON_SURFACE_VARIANT,
                ),
                ft.Container(
                    content=ft.ProgressBar(
                        value=value / 100.0,
                        height=8,
                        color=color,
                        bgcolor=ft.Colors.with_opacity(
                            0.3, ft.Colors.ON_SURFACE_VARIANT
                        ),
                        border_radius=4,
                    ),
                    margin=ft.margin.only(top=4, bottom=4),
                ),
                ft.Row(
                    [
                        ft.Text(
                            f"{value:.1f}%",
                            size=16,
                            weight=ft.FontWeight.W_700,
                            color=ft.Colors.ON_SURFACE,
                        ),
                        ft.Text(
                            details,
                            size=14,
                            color=ft.Colors.ON_SURFACE_VARIANT,
                        ),
                    ],
                    alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                ),
            ],
            spacing=2,
        ),
        padding=ft.padding.symmetric(horizontal=12, vertical=8),
        expand=True,
    )


def create_modal_for_component(
    component_name: str, component_data: ComponentStatus
) -> ft.AlertDialog | None:
    """
    Factory function to create appropriate modal dialog for a component.

    Args:
        component_name: Name of the component (e.g., "scheduler", "worker")
        component_data: ComponentStatus containing component health and metrics

    Returns:
        AlertDialog instance for the component, or None if component not supported
    """
    from ..modals import (
        AIDetailDialog,
        AuthDetailDialog,
        BackendDetailDialog,
        CommsDetailDialog,
        DatabaseDetailDialog,
        FrontendDetailDialog,
        RedisDetailDialog,
        SchedulerDetailDialog,
        WorkerDetailDialog,
    )

    modal_map: dict[str, type[ft.AlertDialog]] = {
        "ai": AIDetailDialog,
        "auth": AuthDetailDialog,
        "backend": BackendDetailDialog,
        "comms": CommsDetailDialog,
        "database": DatabaseDetailDialog,
        "frontend": FrontendDetailDialog,
        "redis": RedisDetailDialog,
        "scheduler": SchedulerDetailDialog,
        "worker": WorkerDetailDialog,
    }

    modal_class = modal_map.get(component_name)
    if modal_class:
        return modal_class(component_data)

    return None


def create_card_click_handler(
    component_name: str, component_data: ComponentStatus
) -> Callable[[ft.ControlEvent], None]:
    """
    Create a click handler for a card that opens its detail modal.

    Args:
        component_name: Name of the component
        component_data: ComponentStatus containing component information

    Returns:
        Click event handler function
    """

    def handle_click(e: ft.ControlEvent) -> None:
        """Handle card click by opening detail modal."""
        modal = create_modal_for_component(component_name, component_data)
        if modal and e.page:
            e.page.open(modal)

    return handle_click


def format_next_run_time(iso_time_str: str) -> str:
    """
    Format ISO datetime string to human readable relative time.

    Generic utility that can be used by any component card/modal to display
    upcoming execution times in a user-friendly format.

    Args:
        iso_time_str: ISO 8601 formatted datetime string (with or without timezone)

    Returns:
        Human-readable relative time string ("in 2h", "in 3d", "Past due", etc.)
        Returns "Unknown" if parsing fails or input is empty
    """
    from datetime import UTC, datetime

    from app.core.log import logger

    if not iso_time_str:
        return "Unknown"

    try:
        # Handle both timezone-aware and naive datetimes
        if iso_time_str.endswith("Z"):
            next_run = datetime.fromisoformat(iso_time_str.replace("Z", "+00:00"))
        elif "+" in iso_time_str or iso_time_str.endswith("00:00"):
            next_run = datetime.fromisoformat(iso_time_str)
        else:
            # Assume UTC if no timezone info
            next_run = datetime.fromisoformat(iso_time_str).replace(tzinfo=UTC)

        now = datetime.now(UTC)

        # Make sure both datetimes are timezone-aware
        if next_run.tzinfo is None:
            next_run = next_run.replace(tzinfo=UTC)

        delta = next_run - now
        total_seconds = delta.total_seconds()

        if total_seconds < 0:
            return "Past due"
        elif total_seconds < 60:
            return f"in {int(total_seconds)}s"
        elif total_seconds < 3600:
            minutes = int(total_seconds / 60)
            return f"in {minutes}m"
        elif total_seconds < 86400:
            hours = total_seconds / 3600
            if hours < 2:
                return f"in {hours:.1f}h"
            else:
                return f"in {int(hours)}h"
        else:
            days = int(total_seconds / 86400)
            return f"in {days}d"
    except Exception as e:
        logger.debug(f"Failed to format next run time '{iso_time_str}': {e}")
        return "Unknown"


def format_schedule_human_readable(schedule: str) -> str:
    """
    Convert schedule format to human readable description.

    Generic utility that can be used by any component card/modal to display
    scheduling patterns in a user-friendly format.

    Args:
        schedule: Schedule string (typically from APScheduler or similar)

    Returns:
        Human-readable schedule description ("Daily at 2:00 AM UTC", etc.)
        Returns original schedule string if no pattern matches
        Returns "Unknown schedule" for empty/invalid input
    """
    import re

    from app.core.log import logger

    if not schedule or "Unknown" in schedule:
        return "Unknown schedule"

    # Handle common cron patterns
    if "hour=2, minute=0, second=0" in schedule:
        return "Daily at 2:00 AM UTC"
    elif "hour=" in schedule and "minute=" in schedule:
        # Extract hour and minute from the schedule string
        try:
            hour_match = re.search(r"hour=([0-9]+)", schedule)
            minute_match = re.search(r"minute=([0-9]+)", schedule)
            if hour_match and minute_match:
                hour = int(hour_match.group(1))
                minute = int(minute_match.group(1))
                time_str = f"{hour:02d}:{minute:02d}"
                return f"Daily at {time_str} UTC"
        except Exception as e:
            logger.debug(f"Failed to parse schedule pattern '{schedule}': {e}")

    # Fallback to original schedule
    return schedule
