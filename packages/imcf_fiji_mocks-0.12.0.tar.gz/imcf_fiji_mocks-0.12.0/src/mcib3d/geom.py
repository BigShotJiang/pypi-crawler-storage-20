Objects3DPopulation = None
