RoiManager = None
