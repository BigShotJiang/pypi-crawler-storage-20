"""Engine adapters for third-party inference engines.

Adapters isolate third-party dependencies from core control flow.
Each adapter must implement the BaseEngine interface.
"""

from __future__ import annotations

__all__: list[str] = []

# Adapters are imported dynamically to avoid hard dependencies
# on third-party packages like lmdeploy, vllm, etc.
