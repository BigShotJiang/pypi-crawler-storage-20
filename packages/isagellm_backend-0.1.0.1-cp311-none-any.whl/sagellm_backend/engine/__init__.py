"""Engine abstraction layer for LLM inference.

This module provides:
- BaseEngine: Abstract interface for inference engines
- MockEngine: GPU-free mock implementation for testing
- HFCudaEngine: HuggingFace Transformers CUDA engine
- EngineFactory: Factory for creating engine instances

Self-Describing Architecture:
    Each engine implements is_available(), priority(), and backend_type().
    Engines are auto-registered with EngineFactory on module import.
    The factory selects backends based on engine self-description,
    NOT by assuming specific frameworks.
"""

from __future__ import annotations

from typing import Any

from sagellm_backend.engine.base import BaseEngine
from sagellm_backend.engine.factory import EngineFactory
from sagellm_backend.engine.mock import MockEngine

# ─────────────────────────────────────────────────────────────────
# Auto-register built-in engines
# ─────────────────────────────────────────────────────────────────

# MockEngine is always available (no hardware dependencies)
EngineFactory.register(MockEngine)


def _register_hf_cuda_engine() -> None:
    """Attempt to register HFCudaEngine if torch is available."""
    try:
        from sagellm_backend.engine.hf_cuda import HFCudaEngine

        EngineFactory.register(HFCudaEngine)
    except ImportError:
        # torch not installed, skip HFCudaEngine registration
        pass


def _register_cpu_engine() -> None:
    """Attempt to register CPUEngine if torch is available."""
    try:
        from sagellm_backend.engine.cpu import CPUEngine

        EngineFactory.register(CPUEngine)
    except ImportError:
        # torch not installed, skip CPUEngine registration
        pass


# Try to register HFCudaEngine (requires torch)
_register_hf_cuda_engine()

# Try to register CPUEngine (requires torch)
_register_cpu_engine()


# ─────────────────────────────────────────────────────────────────
# Lazy imports for optional engines
# ─────────────────────────────────────────────────────────────────


def __getattr__(name: str):
    if name == "HFCudaEngine":
        from sagellm_backend.engine.hf_cuda import HFCudaEngine

        return HFCudaEngine
    if name == "HFCudaEngineConfig":
        from sagellm_backend.engine.hf_cuda import HFCudaEngineConfig

        return HFCudaEngineConfig
    if name == "CPUEngine":
        from sagellm_backend.engine.cpu import CPUEngine

        return CPUEngine
    if name == "CPUEngineConfig":
        from sagellm_backend.engine.cpu import CPUEngineConfig

        return CPUEngineConfig
    if name == "EmbeddingEngine":
        from sagellm_backend.engine.embedding import EmbeddingEngine

        return EmbeddingEngine
    if name == "EmbeddingEngineConfig":
        from sagellm_backend.engine.embedding import EmbeddingEngineConfig

        return EmbeddingEngineConfig
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "BaseEngine",
    "MockEngine",
    "HFCudaEngine",
    "HFCudaEngineConfig",
    "CPUEngine",
    "CPUEngineConfig",
    "EmbeddingEngine",
    "EmbeddingEngineConfig",
    "EngineFactory",
    # Plugin factory functions (for sagellm.engines entry points)
    "create_cuda_engine",
    "create_cpu_engine",
    "create_mock_engine",
]


# ─────────────────────────────────────────────────────────────────
# Plugin Factory Functions (for sagellm-core plugin system)
# ─────────────────────────────────────────────────────────────────


def create_cpu_engine(config: Any, backend: Any = None) -> Any:  # noqa: ARG001
    """Create CPUEngine for sagellm-core plugin system.

    This function is registered as an entry point for sagellm.engines.
    The component_trace will show: sagellm-core → sagellm-backend:CPUEngine

    Args:
        config: EngineConfig from sagellm-core
        backend: Optional BackendProvider (currently unused, reserved for future)

    Returns:
        CPUEngine instance with _created_via_core=True flag set.

    Example:
        from sagellm_core import EngineConfig, create_engine
        config = EngineConfig(kind="cpu", model="TinyLlama/TinyLlama-1.1B-Chat-v1.0")
        engine = create_engine(config, backend=None)
    """
    from sagellm_backend.engine.cpu import CPUEngine, CPUEngineConfig

    # Convert sagellm-core config to dict
    if isinstance(config, dict):
        config_dict = config
    else:
        # Try to get attributes directly (works for both instance and class attributes)
        config_dict = {}
        for attr in ["engine_id", "model", "model_path", "max_batch_size", 
                     "max_output_tokens", "trust_remote_code"]:
            if hasattr(config, attr):
                config_dict[attr] = getattr(config, attr)
    
    # Ensure model_path is set (try 'model' or 'model_path')
    model_path = config_dict.get("model_path") or config_dict.get("model")
    if not model_path:
        raise ValueError("model_path or model must be provided in config")

    engine_config = CPUEngineConfig(
        engine_id=config_dict.get("engine_id", "cpu-default"),
        model_path=model_path,
        device="cpu",
        max_batch_size=config_dict.get("max_batch_size", 32),
        max_new_tokens=config_dict.get("max_output_tokens", 128),
        trust_remote_code=config_dict.get("trust_remote_code", False),
    )

    engine = CPUEngine(engine_config)
    engine._created_via_core = True  # Mark for component trace
    return engine


def create_cuda_engine(config: Any, backend: Any = None) -> Any:  # noqa: ARG001
    """Create HFCudaEngine for sagellm-core plugin system.

    This function is registered as an entry point for sagellm.engines.
    The component_trace will show: sagellm-core → sagellm-backend:HFCudaEngine

    Args:
        config: EngineConfig from sagellm-core
        backend: Optional BackendProvider (currently unused, reserved for future)

    Returns:
        HFCudaEngine instance wrapped with core trace
    """
    from sagellm_backend.engine.hf_cuda import HFCudaEngine, HFCudaEngineConfig

    # Extract fields from sagellm-core EngineConfig
    model_path = getattr(config, "model_path", None) or getattr(config, "model", None)
    device = getattr(config, "device", "cuda:0") or "cuda:0"
    max_new_tokens = getattr(config, "max_output_tokens", None) or 512

    # Convert sagellm-core config to HFCudaEngineConfig
    hf_config = HFCudaEngineConfig(
        engine_id=f"cuda-{id(config)}",
        model_path=model_path,
        device=device,
        dtype="auto",
        device_map="auto",
        load_in_8bit=False,
        load_in_4bit=False,
        trust_remote_code=True,
        max_new_tokens=max_new_tokens,
    )

    engine = HFCudaEngine(hf_config)

    # Mark that this engine was created via sagellm-core plugin system
    engine._created_via_core = True  # type: ignore[attr-defined]

    return engine


def create_mock_engine(config: Any, backend: Any = None) -> Any:  # noqa: ARG001
    """Create MockEngine for sagellm-core plugin system.

    This function is registered as an entry point for sagellm.engines.
    The component_trace will show: sagellm-core → sagellm-backend:MockEngine

    Args:
        config: EngineConfig from sagellm-core
        backend: Optional BackendProvider (currently unused, reserved for future)

    Returns:
        MockEngine instance with core trace enabled
    """
    from sagellm_backend.engine.mock import MockEngine, MockEngineConfig

    # Convert sagellm-core config to MockEngineConfig
    mock_config = MockEngineConfig(
        engine_id=getattr(config, "engine_id", "mock-engine"),
    )

    engine = MockEngine(mock_config)

    # Mark that this engine was created via sagellm-core plugin system
    engine._created_via_core = True  # type: ignore[attr-defined]

    return engine
