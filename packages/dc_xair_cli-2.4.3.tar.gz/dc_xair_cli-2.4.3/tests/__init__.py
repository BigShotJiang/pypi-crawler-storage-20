# Tests for xair CLI
