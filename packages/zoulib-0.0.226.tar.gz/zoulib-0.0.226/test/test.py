from zoulib.yttik import getlink
from zoulib.yttik.exceptions import DownloadFailedError

url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"

try:
    getlink(url).getdownload()
except DownloadFailedError as e:
    print(f"❌ Ошибка: {e}")
except Exception as e:
    print(f"❌ Другая ошибка: {e}")
