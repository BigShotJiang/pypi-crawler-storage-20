## Requirements

- Python 3.10+
- version - 0.0.225 (FIXED)