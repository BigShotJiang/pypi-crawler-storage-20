from .yttik import getlink
