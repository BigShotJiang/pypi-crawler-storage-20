from abc import ABC, abstractmethod

class BaseEngine(ABC):
    def __init__(self, url: str):
        self.url = url

    @abstractmethod
    def download(self) -> None:
        """Download video"""
        pass
