import shutil
import yt_dlp
from zoulib.yttik.engines.base import BaseEngine
from zoulib.yttik.exceptions import RuntimeMissingError, DownloadFailedError

class YTDLPEngine(BaseEngine):
    def __init__(self, url: str):
        self.url = url
        self._check_runtime()

    def _check_runtime(self):
        if not shutil.which("node"):
            raise RuntimeMissingError(
                "Node.js is required for YouTube downloads.\n"
                "Скачайте с https://nodejs.org/"
            )

    def download(self):
        options = {
            "outtmpl": "%(title)s.%(ext)s",
            "quiet": True,
            "noplaylist": True,
        }

        try:
            with yt_dlp.YoutubeDL({"quiet": True, "skip_download": True}) as ydl:
                info = ydl.extract_info(self.url, download=False)

            print(f"✅ Видео найдено: {info.get('title', 'Unknown title')}")

            with yt_dlp.YoutubeDL(options) as ydl:
                ydl.download([self.url])

        except yt_dlp.utils.DownloadError as e:
            raise DownloadFailedError(
                "Видео недоступно или возникла ошибка при скачивании."
            ) from e
        except Exception as e:
            raise DownloadFailedError(
                f"Произошла неизвестная ошибка при скачивании: {e}"
            ) from e
