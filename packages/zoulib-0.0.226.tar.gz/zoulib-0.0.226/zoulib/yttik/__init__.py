from .api import getlink

__all__ = ["getlink"]
