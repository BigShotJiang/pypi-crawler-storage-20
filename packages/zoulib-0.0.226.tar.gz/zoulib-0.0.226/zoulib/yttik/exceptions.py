class YTTikError(Exception):
    """Base exception for yttik"""


class UnsupportedPlatformError(YTTikError):
    pass


class DownloadFailedError(YTTikError):
    pass


class RuntimeMissingError(YTTikError):
    pass
