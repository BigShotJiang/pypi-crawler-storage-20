from .core import resolve_engine

class GetLink:
    def __init__(self, url: str):
        self._engine = resolve_engine(url)

    def getdownload(self):
        print("🚀 Download started")
        self._engine.download()
        print("✅ Download finished")


def getlink(url: str) -> GetLink:
    return GetLink(url)
