"""Data adapters package."""

from cbm.data.adapters.base import DataAdapter
from cbm.data.adapters.yahoo_finance import YahooFinanceAdapter

__all__ = ["DataAdapter", "YahooFinanceAdapter"]
