"""Feature engineering for ML model inputs."""

from typing import Dict, List, Optional, Tuple

import numpy as np
import polars as pl
from loguru import logger
from scipy import stats

from cbm.core.types import FeatureSet, ReturnVariable, StockData


class FeatureEngineer:
    """
    Creates ML features from stock data following Murray, Xia, Xiao (2024).
    
    The main features are 12 cumulative monthly returns:
    - r_{t-1,1}: cumulative return over month t-12
    - r_{t-1,2}: cumulative return over months t-12 to t-11
    - ...
    - r_{t-1,12}: cumulative return over months t-12 to t-1
    
    Parameters
    ----------
    return_variable : ReturnVariable or str
        Target variable transformation ("ret", "ret_std", "ret_norm", "ret_pctl").
    lookback_months : int, optional
        Number of months for cumulative returns. Default: 12.
        
    Example
    -------
    >>> engineer = FeatureEngineer(return_variable="ret_norm")
    >>> features = engineer.create_features(stock_data)
    """
    
    def __init__(
        self,
        return_variable: ReturnVariable = ReturnVariable.RET_NORM,
        lookback_months: int = 12,
    ):
        if isinstance(return_variable, str):
            return_variable = ReturnVariable(return_variable)
        self.return_variable = return_variable
        self.lookback_months = lookback_months
    
    def create_features(
        self,
        data: StockData,
        risk_free_rate: Optional[pl.DataFrame] = None,
    ) -> FeatureSet:
        """
        Create ML features from stock data.
        
        Parameters
        ----------
        data : StockData
            Stock data with prices and returns.
        risk_free_rate : pl.DataFrame, optional
            Risk-free rate for calculating excess returns.
            
        Returns
        -------
        FeatureSet
            Container with features, targets, and metadata.
        """
        logger.info("Creating cumulative return features")
        
        # Get returns as dict of arrays for each ticker
        returns_df = data.returns
        tickers = data.tickers
        dates = returns_df.get_column("date").to_numpy()
        
        # Convert to numpy array for faster computation (date x tickers)
        returns_arr = returns_df.select(tickers).to_numpy()
        
        # Subtract risk-free rate if provided
        if risk_free_rate is not None:
            rf_dates = risk_free_rate.get_column("date").to_numpy()
            rf_rates = risk_free_rate.get_column("rate").to_numpy()
            # Create a mapping from date to rate
            rf_map = dict(zip(rf_dates, rf_rates))
            for i, date in enumerate(dates):
                if date in rf_map:
                    returns_arr[i, :] -= rf_map[date]
        
        # Calculate cumulative returns for each lookback period
        cum_returns = self._calculate_cumulative_returns(returns_arr)
        
        # Create target variable
        targets = self._create_target_variable(returns_arr, dates)
        
        # Align features and targets
        features_list = []
        targets_list = []
        dates_list = []
        tickers_list = []
        market_caps_list = []
        
        # We need at least lookback_months + 1 months of data
        n_dates = len(dates)
        
        for t in range(self.lookback_months, n_dates):
            date = dates[t]
            
            for j, ticker in enumerate(tickers):
                # Check if we have all features for this stock-month
                feature_valid = True
                features = np.zeros(self.lookback_months)
                
                for tau in range(self.lookback_months):
                    val = cum_returns[tau][t - 1, j]  # Use t-1 for available features
                    if np.isnan(val):
                        feature_valid = False
                        break
                    features[tau] = val
                
                target_val = targets[t, j]
                target_valid = not np.isnan(target_val)
                
                if feature_valid and target_valid:
                    features_list.append(features)
                    targets_list.append(target_val)
                    dates_list.append(date)
                    tickers_list.append(ticker)
                    
                    # Market cap if available
                    if data.market_cap is not None:
                        mc_df = data.market_cap
                        if ticker in mc_df.columns:
                            row = mc_df.filter(pl.col("date") == date)
                            if row.height > 0:
                                mc = row.get_column(ticker)[0]
                                market_caps_list.append(mc)
                            else:
                                market_caps_list.append(np.nan)
                        else:
                            market_caps_list.append(np.nan)
        
        features_array = np.array(features_list)
        targets_array = np.array(targets_list)
        dates_array = np.array(dates_list)
        tickers_array = np.array(tickers_list)
        market_caps_array = np.array(market_caps_list) if market_caps_list else None
        
        logger.info(f"Created {len(features_array)} feature samples")
        
        return FeatureSet(
            features=features_array,
            targets=targets_array,
            dates=dates_array,
            tickers=tickers_array,
            market_caps=market_caps_array,
        )
    
    def _calculate_cumulative_returns(
        self,
        returns: np.ndarray,
    ) -> Dict[int, np.ndarray]:
        """
        Calculate cumulative returns for each lookback period.
        
        Returns r_{t-1,τ} for τ = 1, ..., 12 as described in the paper.
        
        Parameters
        ----------
        returns : np.ndarray
            Returns array with shape (n_dates, n_tickers)
            
        Returns
        -------
        Dict[int, np.ndarray]
            Dictionary mapping tau to cumulative returns array
        """
        n_dates, n_tickers = returns.shape
        cum_returns = {}
        
        for tau in range(1, self.lookback_months + 1):
            # Cumulative return over the past tau months
            cum_ret = np.full((n_dates, n_tickers), np.nan)
            
            for t in range(tau - 1, n_dates):
                # Product of (1 + r) - 1 over window
                window = returns[t - tau + 1:t + 1, :]
                cum_ret[t, :] = np.prod(1 + window, axis=0) - 1
            
            cum_returns[tau - 1] = cum_ret  # Store with 0-based index
        
        return cum_returns
    
    def _create_target_variable(
        self,
        returns: np.ndarray,
        dates: np.ndarray,
    ) -> np.ndarray:
        """
        Create target variable based on configured transformation.
        
        Parameters
        ----------
        returns : np.ndarray
            Returns array with shape (n_dates, n_tickers)
        dates : np.ndarray
            Array of dates
            
        Returns
        -------
        np.ndarray
            Transformed target variable
        """
        if self.return_variable == ReturnVariable.RET:
            # Raw excess return
            return returns
        
        elif self.return_variable == ReturnVariable.RET_STD:
            # Standardized by cross-sectional std
            std = np.nanstd(returns, axis=1, keepdims=True)
            std = np.where(std == 0, 1, std)  # Avoid division by zero
            return returns / std
        
        elif self.return_variable == ReturnVariable.RET_NORM:
            # Z-score normalization (cross-sectional)
            mean = np.nanmean(returns, axis=1, keepdims=True)
            std = np.nanstd(returns, axis=1, keepdims=True)
            std = np.where(std == 0, 1, std)  # Avoid division by zero
            return (returns - mean) / std
        
        elif self.return_variable == ReturnVariable.RET_PCTL:
            # Percentile rank (cross-sectional)
            n_dates, n_tickers = returns.shape
            result = np.full_like(returns, np.nan)
            for t in range(n_dates):
                row = returns[t, :]
                valid_mask = ~np.isnan(row)
                if valid_mask.sum() > 0:
                    ranks = stats.rankdata(row[valid_mask])
                    pctls = ranks / len(ranks)
                    result[t, valid_mask] = pctls
            return result
        
        else:
            raise ValueError(f"Unknown return variable: {self.return_variable}")
    
    def create_expanding_window_features(
        self,
        data: StockData,
        start_date: str,
        end_date: str,
    ) -> List[Tuple[str, FeatureSet]]:
        """
        Create features using expanding window for time-series cross-validation.
        
        This is used for the expanding window training described in the paper.
        
        Parameters
        ----------
        data : StockData
            Stock data.
        start_date : str
            Start date for expanding window.
        end_date : str
            End date for test period.
            
        Returns
        -------
        list of (str, FeatureSet)
            List of (end_date, features) tuples for each window.
        """
        # Implementation for expanding window
        # Used for rolling forecasts
        windows = []
        
        # Filter to date range
        returns_df = data.returns.filter(
            (pl.col("date") >= start_date) & (pl.col("date") <= end_date)
        )
        
        dates = returns_df.get_column("date").to_list()
        
        # For each month after lookback period, create features using only past data
        for i in range(self.lookback_months, len(dates)):
            window_end = dates[i]
            
            # Filter data up to window_end
            window_prices = data.prices.filter(pl.col("date") <= window_end)
            window_returns = data.returns.filter(pl.col("date") <= window_end)
            window_mc = None
            if data.market_cap is not None:
                window_mc = data.market_cap.filter(pl.col("date") <= window_end)
            
            window_data = StockData(
                prices=window_prices,
                returns=window_returns,
                market_cap=window_mc,
                metadata=data.metadata,
            )
            features = self.create_features(window_data)
            windows.append((str(window_end), features))
        
        return windows


class DataValidator:
    """
    Validates data quality and consistency.
    
    Performs checks for:
    - Missing data
    - Outliers
    - Data consistency
    - Survivorship bias indicators
    """
    
    def __init__(
        self,
        max_missing_pct: float = 0.1,
        outlier_threshold: float = 5.0,  # Standard deviations
    ):
        self.max_missing_pct = max_missing_pct
        self.outlier_threshold = outlier_threshold
    
    def validate(self, data: StockData) -> Dict[str, any]:
        """
        Run all validation checks.
        
        Returns
        -------
        dict
            Validation results with issues found.
        """
        results = {
            "is_valid": True,
            "issues": [],
            "warnings": [],
            "stats": {},
        }
        
        # Convert to numpy for statistical calculations
        tickers = data.tickers
        returns_arr = data.returns.select(tickers).to_numpy()
        
        # Check missing data
        missing_pct = np.isnan(returns_arr).mean(axis=0)
        high_missing = np.sum(missing_pct > self.max_missing_pct)
        if high_missing > 0:
            results["warnings"].append(
                f"{high_missing} tickers have >{self.max_missing_pct:.0%} missing data"
            )
        results["stats"]["missing_pct"] = float(np.nanmean(missing_pct))
        
        # Check for outliers
        valid_returns = returns_arr[~np.isnan(returns_arr)]
        if len(valid_returns) > 0:
            z_scores = np.abs((valid_returns - np.mean(valid_returns)) / np.std(valid_returns))
            outlier_pct = np.mean(z_scores > self.outlier_threshold)
            if outlier_pct > 0.01:
                results["warnings"].append(
                    f"{outlier_pct:.1%} of observations are outliers"
                )
            results["stats"]["outlier_pct"] = float(outlier_pct)
        
        # Check date coverage
        dates = data.returns.get_column("date")
        date_range = (dates.max() - dates.min()).days
        results["stats"]["date_range_days"] = int(date_range)
        
        # Check ticker count
        results["stats"]["n_tickers"] = len(tickers)
        results["stats"]["n_observations"] = data.returns.height
        
        logger.info(f"Validation complete: {results['stats']}")
        
        return results
