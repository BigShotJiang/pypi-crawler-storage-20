"""Forecasting module for generating ML-based return predictions."""

from datetime import datetime
from typing import Dict, Optional, Tuple

import numpy as np
import polars as pl
from loguru import logger
from scipy.stats import spearmanr

from cbm.core.types import FeatureSet, Forecast
from cbm.ml.trainer import EnsembleModel


class Forecaster:
    """
    Generate ML-based return forecasts (MLER) from trained models.
    
    Produces forecasts following the paper methodology where predictions
    are made using features available at the end of month t-1 to predict
    month t returns.
    
    Parameters
    ----------
    model : EnsembleModel
        Trained ensemble model.
        
    Example
    -------
    >>> forecaster = Forecaster(model=trained_model)
    >>> forecasts = forecaster.predict(features, test_period=("2019-01", "2023-12"))
    """
    
    def __init__(self, model: EnsembleModel):
        self.model = model
    
    def predict(
        self,
        features: FeatureSet,
        test_period: Optional[Tuple[str, str]] = None,
    ) -> Forecast:
        """
        Generate forecasts for the test period.
        
        Parameters
        ----------
        features : FeatureSet
            Feature set with features, dates, and tickers.
        test_period : tuple, optional
            Test period as (start_month, end_month).
            
        Returns
        -------
        Forecast
            Container with forecast values indexed by date and ticker.
        """
        logger.info(f"Generating forecasts for period {test_period}")
        
        # Filter to test period if specified
        if test_period is not None:
            start_date = np.datetime64(test_period[0])
            end_date = np.datetime64(test_period[1])
            mask = (features.dates >= start_date) & (features.dates <= end_date)
        else:
            mask = np.ones(len(features), dtype=bool)
        
        X = features.features[mask]
        dates = features.dates[mask]
        tickers = features.tickers[mask]
        
        if len(X) == 0:
            raise ValueError(f"No data found for test period {test_period}")
        
        # Generate predictions
        predictions = self.model.predict(X)
        
        # Organize into Polars DataFrame (date x ticker)
        unique_dates = np.unique(dates)
        unique_tickers = np.unique(tickers)
        
        # Build data dict with date column and ticker columns
        data_dict = {"date": unique_dates.tolist()}
        for ticker in unique_tickers:
            data_dict[ticker] = [np.nan] * len(unique_dates)
        
        # Create date index mapping
        date_to_idx = {d: i for i, d in enumerate(unique_dates)}
        
        # Fill in predictions
        for date, ticker, pred in zip(dates, tickers, predictions):
            idx = date_to_idx[date]
            data_dict[ticker][idx] = pred
        
        forecast_df = pl.DataFrame(data_dict)
        
        logger.info(
            f"Generated forecasts for {len(unique_dates)} months "
            f"and {len(unique_tickers)} tickers"
        )
        
        return Forecast(
            values=forecast_df,
            model_id="",  # Will be set by engine
            created_at=datetime.now().isoformat(),
            metadata={
                "test_period": test_period,
                "n_predictions": len(predictions),
            },
        )
    
    def predict_with_uncertainty(
        self,
        features: FeatureSet,
        test_period: Optional[Tuple[str, str]] = None,
    ) -> Tuple[Forecast, pl.DataFrame]:
        """
        Generate forecasts with uncertainty estimates.
        
        Returns standard deviation across ensemble models as
        a measure of prediction uncertainty.
        
        Returns
        -------
        tuple
            (Forecast, uncertainty_df) where uncertainty_df has same
            structure as forecast values.
        """
        logger.info("Generating forecasts with uncertainty estimates")
        
        # Filter to test period
        if test_period is not None:
            start_date = np.datetime64(test_period[0])
            end_date = np.datetime64(test_period[1])
            mask = (features.dates >= start_date) & (features.dates <= end_date)
        else:
            mask = np.ones(len(features), dtype=bool)
        
        X = features.features[mask]
        dates = features.dates[mask]
        tickers = features.tickers[mask]
        
        # Generate predictions with uncertainty
        predictions, uncertainties = self.model.predict_with_uncertainty(X)
        
        # Build DataFrames
        unique_dates = np.unique(dates)
        unique_tickers = np.unique(tickers)
        
        # Create data dicts
        forecast_data = {"date": unique_dates.tolist()}
        uncertainty_data = {"date": unique_dates.tolist()}
        for ticker in unique_tickers:
            forecast_data[ticker] = [np.nan] * len(unique_dates)
            uncertainty_data[ticker] = [np.nan] * len(unique_dates)
        
        date_to_idx = {d: i for i, d in enumerate(unique_dates)}
        
        for date, ticker, pred, unc in zip(dates, tickers, predictions, uncertainties):
            idx = date_to_idx[date]
            forecast_data[ticker][idx] = pred
            uncertainty_data[ticker][idx] = unc
        
        forecast_df = pl.DataFrame(forecast_data)
        uncertainty_df = pl.DataFrame(uncertainty_data)
        
        forecast = Forecast(
            values=forecast_df,
            model_id="",
            created_at=datetime.now().isoformat(),
            metadata={
                "test_period": test_period,
                "has_uncertainty": True,
            },
        )
        
        return forecast, uncertainty_df
    
    def compute_forecast_correlation(
        self,
        forecast: Forecast,
        actual_returns: pl.DataFrame,
    ) -> pl.DataFrame:
        """
        Compute Spearman rank correlation between forecasts and actual returns.
        
        This is the key metric used in the paper to evaluate forecast quality.
        
        Parameters
        ----------
        forecast : Forecast
            ML forecasts.
        actual_returns : pl.DataFrame
            Actual realized returns with date column.
            
        Returns
        -------
        pl.DataFrame
            Monthly Spearman correlations with date and correlation columns.
        """
        correlations = []
        
        forecast_dates = forecast.values.get_column("date").to_list()
        actual_dates = actual_returns.get_column("date").to_list()
        
        tickers = [c for c in forecast.values.columns if c != "date"]
        
        for date in forecast_dates:
            if date not in actual_dates:
                continue
            
            # Get forecasts and actuals for this date
            fcst_row = forecast.values.filter(pl.col("date") == date)
            actual_row = actual_returns.filter(pl.col("date") == date)
            
            if fcst_row.height == 0 or actual_row.height == 0:
                continue
            
            # Get common tickers with valid data
            fcst_vals = []
            actual_vals = []
            
            for ticker in tickers:
                if ticker not in actual_row.columns:
                    continue
                fcst_val = fcst_row.get_column(ticker)[0]
                actual_val = actual_row.get_column(ticker)[0]
                
                if fcst_val is not None and actual_val is not None:
                    if not np.isnan(fcst_val) and not np.isnan(actual_val):
                        fcst_vals.append(fcst_val)
                        actual_vals.append(actual_val)
            
            if len(fcst_vals) > 10:  # Require minimum stocks
                corr, _ = spearmanr(fcst_vals, actual_vals)
                correlations.append({"date": date, "correlation": corr})
        
        return pl.DataFrame(correlations)
