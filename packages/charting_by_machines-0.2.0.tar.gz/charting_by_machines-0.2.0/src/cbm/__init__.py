"""
Charting by Machines: ML-based portfolio selection package.

This package implements the methodology from Murray, Xia, and Xiao (2024)
for predicting stock returns using machine learning on historical price patterns.
"""

from cbm.core.engine import PortfolioEngine
from cbm.core.config import CBMConfig

__version__ = "0.1.0"
__all__ = ["PortfolioEngine", "CBMConfig"]
