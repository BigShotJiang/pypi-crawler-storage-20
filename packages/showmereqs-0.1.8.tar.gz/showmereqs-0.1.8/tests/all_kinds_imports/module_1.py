def functionB():
    pass
