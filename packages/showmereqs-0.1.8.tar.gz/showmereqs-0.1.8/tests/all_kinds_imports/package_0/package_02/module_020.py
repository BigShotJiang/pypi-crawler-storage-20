def functionA():
    pass
