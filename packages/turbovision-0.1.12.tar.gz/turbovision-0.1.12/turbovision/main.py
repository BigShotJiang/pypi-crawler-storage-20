"""
Main module that imports Turbo class from the compiled .so file
"""

from pathlib import Path

# Get the directory where this file is located
_package_dir = Path(__file__).parent

# Find the .so file (Python extension module)
# The .so file may have platform-specific naming like turbo.cpython-312-x86_64-linux-gnu.so
_so_files = list(_package_dir.glob("turbo*.so"))

if not _so_files:
    raise FileNotFoundError(
        f"Compiled turbo module (.so file) not found in {_package_dir}. "
        "Please ensure turbo.so is compiled and present in the package directory."
    )

# Import the turbo module from the .so file
# Python can import .so files directly as modules
import importlib.util
_so_file = _so_files[0]
spec = importlib.util.spec_from_file_location("turbovision.turbo", _so_file)
turbo = importlib.util.module_from_spec(spec)
spec.loader.exec_module(turbo)

# Import the Turbo class from the compiled module
if hasattr(turbo, "Turbo"):
    Turbo = turbo.Turbo
else:
    raise ImportError(
        f"Could not find 'Turbo' class in {_so_file}. "
        "Please ensure the .so file is properly compiled and contains the Turbo class."
    )
