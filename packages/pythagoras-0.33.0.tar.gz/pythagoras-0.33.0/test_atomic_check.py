
import sys
import os

# Ensure src is in path
sys.path.insert(0, os.path.abspath("src"))

from pythagoras._220_data_portals.data_portal_core_classes import ValueAddr
from mixinforge.utility_functions.atomics_detector import is_atomic_object
from persidict import SafeStrTuple

# ValueAddr requires data. We pass a simple string. store=False to avoid portal lookup.
h = ValueAddr("some data", store=False)

print(f"Type of ValueAddr: {type(h)}")
print(f"MRO: {type(h).mro()}")
print(f"Is instance of SafeStrTuple: {isinstance(h, SafeStrTuple)}")
print(f"Is instance of tuple: {isinstance(h, tuple)}")
print(f"Is instance of str: {isinstance(h, str)}")

is_atomic = is_atomic_object(h)
print(f"is_atomic_object(h): {is_atomic}")
