# مكتبة sendspy

مكتبة رسال صيد للتلي 
المطور جعفر 
@hhvvm5
ig:@up61
## 📥 التثبيت

```bash
pip install sendspy