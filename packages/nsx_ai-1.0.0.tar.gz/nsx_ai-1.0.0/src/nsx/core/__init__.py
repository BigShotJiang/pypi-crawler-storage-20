from .symbols import Variable, Constant, Term 
from .logic import Predicate, Atom, Rule, And, Or, Not 
from .tnorms import get_logic_engine 

