"""命令字典定义模块"""

python_pkgs = {
    "uv tool install -U dlght": "免代理 gitub下载工具 dlght",
    "uv tool install -U envvm": "环境变量管理工具 envvm",
    "uv tool install -U ali-ops": "aliyun命令行工具ali-ops",
    "uv tool install -U iamt": "自动化运维工具iamt",
    "uv tool install -U cpdts": "脚手架 cpdts",
    "uv tool install -U tschm": "windows定时任务工具",
    "uv tool install -U fastdjt": "django项目脚手架",
    "uv tool install -U ptlearn": "ptlearn",
    "uv tool install -U ptpython": "install ptpython",
    "uv tool install -U ningfastforge":"fastapi 脚手架 forge"
}

node_pkgs = {
    "npm install -g opencode-ai@latest": "opencode",
}

cmds = {
    "bash <(curl -Ls https://raw.githubusercontent.com/mhsanaei/3x-ui/master/install.sh)": "安装3xui",
}


winget_pkgs={
    "winget install SQLite.SQLite": "install sqlite"
}