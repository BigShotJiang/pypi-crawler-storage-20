"""Bundled mitmproxy addons."""
