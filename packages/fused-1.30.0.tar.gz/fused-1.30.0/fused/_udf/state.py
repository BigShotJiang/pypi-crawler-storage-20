from __future__ import annotations

import sys
from contextlib import contextmanager
from contextvars import ContextVar
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fused.models.udf import AnyBaseUdf


noop_decorators: ContextVar[bool] = ContextVar("noop_decorator", default=False)
decorator_src_override: ContextVar[str | None] = ContextVar(
    "decorator_src_override", default=None
)
decorator_udf_override: ContextVar[AnyBaseUdf | None] = ContextVar(
    "decorator_udf_override", default=None
)

decorator_import_globals_disabled: ContextVar[bool | None] = ContextVar(
    "decorator_import_globals_override", default=None
)


@contextmanager
def noop_decorators_context(val: bool):
    token = noop_decorators.set(val)
    try:
        yield token
    finally:
        noop_decorators.reset(token)


# Provides the UDF's code to the fused.udf decorator via the global context (above).
#
# Injecting the UDF code back inside the run function.
@contextmanager
def decorator_src_override_context(val: str):
    token = decorator_src_override.set(val)
    try:
        yield token
    finally:
        decorator_src_override.reset(token)


@contextmanager
def decorator_udf_override_context(udf: AnyBaseUdf):
    token = decorator_udf_override.set(udf)
    try:
        yield token
    finally:
        decorator_udf_override.reset(token)


@contextmanager
def decorator_import_globals_disable_context():
    token = decorator_import_globals_disabled.set(True)
    try:
        yield token
    finally:
        decorator_import_globals_disabled.reset(token)


class StdStreamProxy:
    """Act as a proxy for a target stream to prevent it from being closed unexpectedly"""

    def __init__(self, target: str):
        self._target = target
        self._stream = getattr(sys, target)

    def _get_actual_stream(self):
        """Get the actual underlying stream, traversing through any proxy chain"""

        # Prevent infinite recursion: never proxy the _stream attribute
        stream = object.__getattribute__(self, "_stream")
        while isinstance(stream, StdStreamProxy):
            stream = object.__getattribute__(stream, "_stream")
        return stream

    # Forward all non-overridden methods
    def __getattr__(self, item):
        return getattr(self._get_actual_stream(), item)

    # To mitigate UDF crashes, we prevent close from operating on the stream. We ensure that anything left in the buffer
    # is flushed.
    def close(self):
        self.flush()

    def get_stream(self):
        return self._get_actual_stream()

    def __enter__(self):
        setattr(sys, self._target, self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        setattr(sys, self._target, self._stream)
