from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
import subprocess
import tempfile
from typing import Callable, Generator
from gitlab.v4.objects import Project

from gitlab_ps_utils.projects.models import GitOperationResult, MergeRequestConfig

class LocalProjectModifier:
    """
    Modify projects via local git operations.
    
    Use when you need to inspect the repo structure, run tools, or make
    complex changes that can't be expressed as simple file updates.
    """

    def __init__(
        self,
        default_branch: str = "main",
        git_env: dict[str, str] | None = None,
        prefer_ssh: bool = True,
    ):
        self._default_branch = default_branch
        self._git_env = git_env or {}
        self._prefer_ssh = prefer_ssh

    def _run_git(self, cwd: Path, args: list[str]) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["git", *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            env=self._git_env,
            check=True,
        )

    def _get_clone_url(self, project: Project) -> str:
        if self._prefer_ssh and getattr(project, 'ssh_url_to_repo', None):
            return project.ssh_url_to_repo
        return project.http_url_to_repo

    def _get_default_branch(self, project: Project) -> str:
        return getattr(project, 'default_branch', None) or self._default_branch

    @contextmanager
    def clone(self, project: Project) -> Generator[ClonedRepo, None, None]:
        """
        Clone a repository and yield a ClonedRepo for making changes.

        Usage:
            with modifier.clone(project) as repo:
                repo.apply_changes(modify_fn, "commit msg", "branch", mr_config)
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            repo_path = Path(tmpdir) / project.path
            clone_url = self._get_clone_url(project)
            default_branch = self._get_default_branch(project)

            self._run_git(Path(tmpdir), ["clone", clone_url, str(repo_path)])
            self._run_git(repo_path, ["checkout", default_branch])

            yield ClonedRepo(
                project=project,
                repo_path=repo_path,
                default_branch=default_branch,
                git_env=self._git_env,
            )


class ClonedRepo:
    """A cloned repository for applying local modifications."""

    def __init__(
        self,
        project: Project,
        repo_path: Path,
        default_branch: str,
        git_env: dict[str, str] | None = None,
    ):
        self._project = project
        self._repo_path = repo_path
        self._default_branch = default_branch
        self._git_env = git_env

    @property
    def path(self) -> Path:
        return self._repo_path

    @property
    def project(self) -> Project:
        return self._project

    @property
    def default_branch(self) -> str:
        return self._default_branch

    def _run_git(self, args: list[str]) -> subprocess.CompletedProcess:
        return subprocess.run(
            ["git", *args],
            cwd=self._repo_path,
            capture_output=True,
            text=True,
            env=self._git_env,
            check=True,
        )

    def _reset_to_default(self) -> None:
        self._run_git(["checkout", self._default_branch])
        self._run_git(["reset", "--hard", f"origin/{self._default_branch}"])
        self._run_git(["clean", "-fd"])

    def apply_changes(
        self,
        modify_fn: Callable[[Path], bool],
        commit_message: str,
        branch_name: str,
        merge_request: MergeRequestConfig | None = None,
        files_to_stage: list[str] | None = None,
    ) -> GitOperationResult:
        """
        Apply changes on a new branch, commit, push, and optionally create an MR.
        Resets to default branch first, allowing multiple independent changes.
        """
        try:
            self._reset_to_default()
            self._run_git(["checkout", "-b", branch_name])

            if not modify_fn(self._repo_path):
                return GitOperationResult(success=True, message="No changes made")

            if files_to_stage:
                for f in files_to_stage:
                    self._run_git(["add", f])
            else:
                self._run_git(["add", "-A"])

            status = self._run_git(["status", "--porcelain"])
            if not status.stdout.strip():
                return GitOperationResult(success=True, message="No changes to commit")

            self._run_git(["commit", "-m", commit_message])
            commit_sha = self._run_git(["rev-parse", "HEAD"]).stdout.strip()
            self._run_git(["push", "-u", "origin", branch_name])

        except subprocess.CalledProcessError as e:
            return GitOperationResult(
                success=False,
                message=f"Git error: {e.stderr or e.stdout or str(e)}",
            )

        mr_url = None
        if merge_request:
            try:
                mr = self._project.mergerequests.create({
                    "source_branch": branch_name,
                    "target_branch": self._default_branch,
                    "title": merge_request.title,
                    "description": merge_request.description,
                    "labels": merge_request.labels,
                    "assignee_ids": merge_request.assignee_ids,
                    "reviewer_ids": merge_request.reviewer_ids,
                    "remove_source_branch": merge_request.remove_source_branch,
                    "squash": merge_request.squash,
                })
                mr_url = mr.web_url
            except Exception as e:
                return GitOperationResult(
                    success=False,
                    message=f"MR creation failed: {e}",
                    commit_sha=commit_sha,
                )

        return GitOperationResult(success=True, merge_request_url=mr_url, commit_sha=commit_sha)