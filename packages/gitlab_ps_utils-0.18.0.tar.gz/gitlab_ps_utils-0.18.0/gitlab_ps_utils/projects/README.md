# Repo Updates 
Simplifies process of making changes to and raising MRs for repositories. Available as both local (git+tmpdir) and API modifier classes + context managers.

## Local Modifier Example

```python
# e.g. with python-gitlab
projects = []  # replace with generator function returning GroupProjectManager | ProjectManager
modifier = LocalProjectModifier()


def update_license(repo_path: Path) -> bool:
    license_file = repo_path / "LICENSE"
    if not license_file.exists():
        license_file.write_text("MIT License\n\nCopyright 2025 Acme Corp\n...")
    return True

def add_version(repo_path: Path) -> bool:
    version_file = repo_path / "VERSION"
    if not version_file.exists():
        version_file.write_text("1.0.0")
    return True

for project in projects:
    with modifier.clone(project) as repo:
        license_result = repo.apply_changes(
            modify_fn=update_license,
            commit_message="chore: add missing LICENSE file",
            branch_name="chore/add-license",
            merge_request=MergeRequestConfig(
                title="chore: add missing LICENSE file",
                labels=["automated", "legal"],
            ),
        )
        print(license_result.merge_request_url)
        result = repo.apply_changes(
            modify_fn=add_version,
            commit_message="chore: add version",
            branch_name="chore/add-version",
            merge_request=MergeRequestConfig(
                title="chore: add missing VERSION file",
                labels=["automated", "compliance"],
            ),
        )
```

## API Modifier Example

```python
modifier = ApiRepoModifier()

content = modifier.get_file_content(project, ".gitmodules")
if not content:
    return

new_content = content.replace("old-gitlab.com", "new-gitlab.com")
if content == new_content:
    return  # No changes needed

result = modifier.commit_changes(
    project=project,
    changes=[FileChange.update(".gitmodules", new_content)],
    commit_message="chore: migrate submodule URLs to new GitLab",
    branch_name="chore/migrate-submodules",
    merge_request=MergeRequestConfig(
        title="chore: migrate submodule URLs to new GitLab",
        labels=["automated", "migration"],
    ),
)

other_result = modifier.commit_changes(
    project=project,
    changes=[FileChange.move("projects/models.py", "projects/dataclasses.py")],
    commit_message="refactor: rename models to dataclasses",
    branch_name="refactor/move-demo",
    merge_request=MergeRequestConfig(
        title="refactor: rename models to dataclasses",
        labels=["demo", "move"],
    ),
)
```