from __future__ import annotations
from gitlab.v4.objects import Project
from gitlab import GitlabError

def update_cicd_job_token_inbound_allowlist(project: Project, target_project_id: int) -> None:
    """
    Update the CI/CD job token inbound allowlist for a project.
    
    Args:
        project: The Project to update.
        target_project_id: The ID or path of the project to add to the allowlist.
    """
    try:
        scope = project.job_token_scope.get()
        scope.enabled = True
        scope.save()
        scope.allowlist.create({"target_project_id": target_project_id })
    except GitlabError as e:
        raise RuntimeError(
            f"Failed to update CI/CD job token inbound allowlist for project "
            f"'{project.get_id()}' with allowed project '{target_project_id}': {e}"
        ) from e