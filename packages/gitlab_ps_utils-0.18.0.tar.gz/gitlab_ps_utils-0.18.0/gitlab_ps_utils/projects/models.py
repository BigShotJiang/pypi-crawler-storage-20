from __future__ import annotations

from dataclasses import dataclass, field

@dataclass
class MergeRequestConfig:
    """Configuration for creating a merge request."""
    title: str
    description: str = ""
    labels: list[str] = field(default_factory=list)
    assignee_ids: list[int] = field(default_factory=list)
    reviewer_ids: list[int] = field(default_factory=list)
    remove_source_branch: bool = True
    squash: bool = False


@dataclass
class FileChange:
    """A single file change to commit."""
    path: str
    content: str
    action: str = "update"  # create, update, delete, move
    previous_path: str | None = None  # required for move actions

    def __post_init__(self):
        if self.action == "move" and not self.previous_path:
            raise ValueError("previous_path is required for move actions")

    @classmethod
    def update(cls, path: str, content: str) -> FileChange:
        return cls(path=path, content=content, action="update")

    @classmethod
    def create(cls, path: str, content: str) -> FileChange:
        return cls(path=path, content=content, action="create")

    @classmethod
    def delete(cls, path: str) -> FileChange:
        return cls(path=path, content="", action="delete")

    @classmethod
    def move(cls, from_path: str, to_path: str, content: str = "") -> FileChange:
        return cls(path=to_path, content=content, action="move", previous_path=from_path)


@dataclass
class GitOperationResult:
    """Result of a git operation workflow."""
    success: bool
    message: str | None = None
    merge_request_url: str | None = None
    commit_sha: str | None = None
