from __future__ import annotations

from gitlab_ps_utils.projects.models import FileChange, GitOperationResult, MergeRequestConfig

from gitlab.v4.objects import Project

class ApiProjectModifier:
    """
    Modify GitLab projects using the API (no local clone needed).
    
    Best for simple, known file changes. For complex modifications that
    need to inspect the repo, use LocalRepoModifier instead.
    """

    def __init__(self, default_branch: str = "main"):
        self._default_branch = default_branch

    def _get_default_branch(self, project: Project) -> str:
        return getattr(project, 'default_branch', None) or self._default_branch

    def _build_action(self, change: FileChange) -> dict:
        """Convert a FileChange to a GitLab commit action dict."""
        action = {
            "action": change.action,
            "file_path": change.path,
            "content": change.content,
        }
        if change.action == "move" and change.previous_path:
            action["previous_path"] = change.previous_path
        return action

    def commit_changes(
        self,
        project: Project,
        changes: list[FileChange],
        commit_message: str,
        branch_name: str,
        merge_request: MergeRequestConfig | None = None,
        start_branch: str | None = None,
    ) -> GitOperationResult:
        """
        Create a branch, commit file changes, and optionally create an MR.

        Args:
            project: GitLab project object
            changes: List of file changes to commit
            commit_message: The commit message
            branch_name: Name of the branch to create
            merge_request: Optional MR configuration
            start_branch: Branch to create from; defaults to project default

        Returns:
            GitOperationResult with success status and optional MR URL
        """
        if not changes:
            return GitOperationResult(success=True, message="No changes provided")

        default_branch = start_branch or self._get_default_branch(project)

        try:
            # Create the branch
            project.branches.create({
                "branch": branch_name,
                "ref": default_branch,
            })

            # Create commit with all changes
            actions = [self._build_action(change) for change in changes]

            commit = project.commits.create({
                "branch": branch_name,
                "commit_message": commit_message,
                "actions": actions,
            })
            commit_sha = commit.id

        except Exception as e:
            return GitOperationResult(
                success=False,
                message=f"Failed to create commit: {e}",
            )

        # Create merge request if configured
        mr_url = None
        if merge_request:
            try:
                mr = project.mergerequests.create({
                    "source_branch": branch_name,
                    "target_branch": default_branch,
                    "title": merge_request.title,
                    "description": merge_request.description,
                    "labels": merge_request.labels,
                    "assignee_ids": merge_request.assignee_ids,
                    "reviewer_ids": merge_request.reviewer_ids,
                    "remove_source_branch": merge_request.remove_source_branch,
                    "squash": merge_request.squash,
                })
                mr_url = mr.web_url
            except Exception as e:
                return GitOperationResult(
                    success=False,
                    message=f"Commit succeeded but MR creation failed: {e}",
                    commit_sha=commit_sha,
                )

        return GitOperationResult(
            success=True,
            merge_request_url=mr_url,
            commit_sha=commit_sha,
        )

    def commit_direct(
        self,
        project: Project,
        changes: list[FileChange],
        commit_message: str,
        target_branch: str | None = None,
    ) -> GitOperationResult:
        """
        Commit changes directly to a branch without creating an MR.

        Args:
            project: GitLab project object
            changes: List of file changes to commit
            commit_message: The commit message
            target_branch: Branch to commit to; defaults to project default

        Returns:
            GitOperationResult with success status
        """
        if not changes:
            return GitOperationResult(success=True, message="No changes provided")

        branch = target_branch or self._get_default_branch(project)

        try:
            actions = [self._build_action(change) for change in changes]

            commit = project.commits.create({
                "branch": branch,
                "commit_message": commit_message,
                "actions": actions,
            })

            return GitOperationResult(success=True, commit_sha=commit.id)

        except Exception as e:
            return GitOperationResult(
                success=False,
                message=f"Failed to create commit: {e}",
            )

    def get_file_content(
        self,
        project: Project,
        file_path: str,
        ref: str | None = None,
    ) -> str | None:
        """Retrieve file content from the repository."""
        try:
            ref = ref or self._get_default_branch(project)
            f = project.files.get(file_path=file_path, ref=ref)
            # the first converts from base64 to bytes
            content = f.decode()
            # the second converts from bytes to string
            # see also: https://python-gitlab.readthedocs.io/en/v7.0.0/gl_objects/projects.html#id7
            return content.decode("utf-8")
        except Exception:
            return None

