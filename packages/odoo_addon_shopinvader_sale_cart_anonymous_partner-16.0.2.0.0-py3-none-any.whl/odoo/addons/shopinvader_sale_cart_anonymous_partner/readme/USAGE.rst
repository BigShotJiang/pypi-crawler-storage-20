Installation is automatic.
