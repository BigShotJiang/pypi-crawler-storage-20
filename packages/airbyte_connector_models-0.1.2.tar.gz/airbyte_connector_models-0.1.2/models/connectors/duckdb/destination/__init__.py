"""Models for destination-duckdb."""
