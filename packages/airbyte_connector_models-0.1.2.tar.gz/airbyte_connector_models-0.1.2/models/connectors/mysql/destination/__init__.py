"""Models for destination-mysql."""
