"""Models for faker connector."""
