# -*- coding: utf-8 -*-
"""
Community-developed Python SDK for interacting with Gamechanger APIs.
"""

import logging
import os
import uuid

from gamechanger_client.http_session import HttpSession

from .endpoints.clips import ClipsEndpoint
from .endpoints.events import EventsEndpoint
from .endpoints.game_streams import GameStreamsEndpoint
from .endpoints.me import MeEndpoint
from .endpoints.organizations import OrganizationsEndpoint
from .endpoints.players import PlayersEndpoint
from .endpoints.public import PublicEndpoint
from .endpoints.search import SearchEndpoint
from .endpoints.teams import TeamsEndpoint
from .endpoints.users import UsersEndpoint
from .utils import select_from_list
from .version import __version__

# Expose version at package level
__all__ = [
    'GameChangerClient',
    'HttpSession',
    'ClipsEndpoint',
    'EventsEndpoint',
    'GameStreamsEndpoint',
    'MeEndpoint', 
    'OrganizationsEndpoint',
    'PlayersEndpoint',
    'PublicEndpoint',
    'SearchEndpoint',
    'TeamsEndpoint',
    'UsersEndpoint',
    'select_from_list',
    '__version__'
]

logger = logging.getLogger(__name__)

logging.basicConfig(format='%(asctime)s %(name)s [%(levelname)s] %(message)s')
logger = logging.getLogger('gamechanger-client')
logger.setLevel(os.getenv('LOG_LEVEL', logging.INFO))


class GameChangerClient:

    def __init__(self,
                 username=None,
                 password=None,
                 token=None):


        self._gc_username = username or os.getenv('GC_USERNAME')
        self._gc_password = password or os.getenv('GC_PASSWORD')
        self._gc_token = token or os.getenv('GC_TOKEN')

        self._client_id = uuid.uuid1()

        # Create a new requests session
        self._session = HttpSession(self._gc_token)

        self.clips = ClipsEndpoint(self._session)
        self.events = EventsEndpoint(self._session)
        self.game_streams = GameStreamsEndpoint(self._session)
        self.me = MeEndpoint(self._session)
        self.organizations = OrganizationsEndpoint(self._session)
        self.players = PlayersEndpoint(self._session)
        self.public = PublicEndpoint(self._session)
        self.search = SearchEndpoint(self._session)
        self.teams = TeamsEndpoint(self._session)
        self.users = UsersEndpoint(self._session)
