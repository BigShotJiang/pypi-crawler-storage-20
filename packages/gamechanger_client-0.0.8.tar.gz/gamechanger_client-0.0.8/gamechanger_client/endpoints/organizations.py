# -*- coding: utf-8 -*-
"""GameChanger 'Organizations' API wrapper."""

from gamechanger_client.endpoints.rest_endpoint import RestEndpoint

class OrganizationsEndpoint(RestEndpoint):

    def __init__(self, session):
        super().__init__(session, 'organizations')

    def avatar_image(self, organization_id):
        return super().get(f'{organization_id}/avatar-image')

    def opponent_players(self, organization_id):
        return super().get(f'{organization_id}/opponent-players')

    def opponents(self, organization_id):
        return super().get(f'{organization_id}/opponents')

    def standings(self, organization_id):
        return super().get(f'{organization_id}/standings')

    def team_records(self, organization_id):
        return super().get(f'{organization_id}/team-records')

    def scoped_features(self, organization_id):
        return super().get(f'{organization_id}/scoped-features')

    def users(self, organization_id):
        return super().get(f'{organization_id}/users')

    def game_summaries(self, organization_id):
        return super().get(f'{organization_id}/game-summaries')

    def teams(self, organization_id):
        return super().get(f'{organization_id}/teams')

    def events(self, organization_id):
        return super().get(f'{organization_id}/events')
