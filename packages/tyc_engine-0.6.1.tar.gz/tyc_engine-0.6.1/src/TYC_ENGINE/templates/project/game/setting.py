# basic setting
wh = 500
he = 500
title = 'game'

# to be in 0.6.32 and idk