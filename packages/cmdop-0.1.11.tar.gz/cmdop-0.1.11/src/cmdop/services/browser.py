"""
Browser service for CMDOP SDK.

Provides direct programmatic browser control without LLM.
Supports CSS selectors, regex extraction, JavaScript execution.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from cmdop.services.base import BaseService

if TYPE_CHECKING:
    from cmdop.transport.base import BaseTransport


@dataclass
class BrowserCookie:
    """Browser cookie."""

    name: str
    value: str
    domain: str = ""
    path: str = "/"
    secure: bool = False
    http_only: bool = False
    same_site: str = ""
    expires: int = 0


@dataclass
class BrowserState:
    """Current browser state."""

    url: str
    title: str


class BrowserSession:
    """
    Browser session with fluent API.

    Use as context manager for automatic cleanup:

        with client.browser.create_session() as session:
            session.navigate("https://example.com")
            session.click("button.submit")
    """

    def __init__(self, service: BrowserService, session_id: str) -> None:
        self._service = service
        self._session_id = session_id

    @property
    def session_id(self) -> str:
        """Get browser session ID."""
        return self._session_id

    def navigate(self, url: str, timeout_ms: int = 30000) -> str:
        """
        Navigate to URL.

        Args:
            url: Target URL
            timeout_ms: Navigation timeout in milliseconds

        Returns:
            Final URL after navigation (may differ due to redirects)
        """
        return self._service.navigate(self._session_id, url, timeout_ms)

    def click(self, selector: str, timeout_ms: int = 5000) -> None:
        """
        Click element by CSS selector.

        Args:
            selector: CSS selector
            timeout_ms: Timeout for finding element
        """
        self._service.click(self._session_id, selector, timeout_ms)

    def type(
        self,
        selector: str,
        text: str,
        human_like: bool = False,
        clear_first: bool = True,
    ) -> None:
        """
        Type text into element.

        Args:
            selector: CSS selector
            text: Text to type
            human_like: Simulate human typing (random delays)
            clear_first: Clear field before typing
        """
        self._service.type(self._session_id, selector, text, human_like, clear_first)

    def wait_for(self, selector: str, timeout_ms: int = 30000) -> bool:
        """
        Wait for element to appear.

        Args:
            selector: CSS selector
            timeout_ms: Maximum wait time

        Returns:
            True if element found, False if timeout
        """
        return self._service.wait_for(self._session_id, selector, timeout_ms)

    def extract(
        self, selector: str, attr: str | None = None, limit: int = 100
    ) -> list[str]:
        """
        Extract text/attributes from elements.

        Args:
            selector: CSS selector
            attr: Attribute to extract (None = text content)
            limit: Maximum number of elements

        Returns:
            List of extracted values

        Example:
            >>> titles = session.extract(".product-title")
            >>> links = session.extract("a", attr="href")
        """
        return self._service.extract(self._session_id, selector, attr, limit)

    def extract_regex(
        self, pattern: str, from_html: bool = False, limit: int = 100
    ) -> list[str]:
        """
        Extract data using regex pattern.

        Args:
            pattern: Regex pattern
            from_html: Search in HTML (default: page text)
            limit: Maximum matches

        Returns:
            List of matches

        Example:
            >>> phones = session.extract_regex(r"\\+7[\\d\\s-]{10,}")
            >>> ids = session.extract_regex(r'data-id="(\\d+)"', from_html=True)
        """
        return self._service.extract_regex(self._session_id, pattern, from_html, limit)

    def get_html(self, selector: str | None = None) -> str:
        """
        Get page HTML.

        Args:
            selector: Element selector (None = full page)

        Returns:
            HTML content
        """
        return self._service.get_html(self._session_id, selector)

    def get_text(self, selector: str | None = None) -> str:
        """
        Get page text content.

        Args:
            selector: Element selector (None = body)

        Returns:
            Text content
        """
        return self._service.get_text(self._session_id, selector)

    def execute_script(self, script: str) -> str:
        """
        Execute JavaScript.

        Args:
            script: JavaScript code

        Returns:
            Result as string

        Example:
            >>> data = session.execute_script('''
            ...     return Array.from(document.querySelectorAll('.item'))
            ...         .map(el => ({name: el.textContent, id: el.dataset.id}))
            ... ''')
        """
        return self._service.execute_script(self._session_id, script)

    def screenshot(self, full_page: bool = False) -> bytes:
        """
        Take screenshot.

        Args:
            full_page: Capture full page (scrolling)

        Returns:
            PNG image bytes
        """
        return self._service.screenshot(self._session_id, full_page)

    def get_state(self) -> BrowserState:
        """
        Get current browser state.

        Returns:
            BrowserState with URL and title
        """
        return self._service.get_state(self._session_id)

    def set_cookies(self, cookies: list[BrowserCookie | dict]) -> None:
        """
        Set browser cookies.

        Args:
            cookies: List of cookies (BrowserCookie or dict)
        """
        self._service.set_cookies(self._session_id, cookies)

    def get_cookies(self, domain: str = "") -> list[BrowserCookie]:
        """
        Get browser cookies.

        Args:
            domain: Filter by domain (empty = all)

        Returns:
            List of cookies
        """
        return self._service.get_cookies(self._session_id, domain)

    def validate_selectors(self, item: str, fields: dict[str, str]) -> dict:
        """
        Validate CSS selectors on page.

        Args:
            item: Item container selector
            fields: Field name -> CSS selector mapping

        Returns:
            dict with: valid, counts, samples, errors

        Example:
            >>> result = session.validate_selectors(
            ...     item=".product-card",
            ...     fields={"title": ".title", "price": ".price"}
            ... )
            >>> if result["valid"]:
            ...     print("All selectors match!")
        """
        return self._service.validate_selectors(self._session_id, item, fields)

    def extract_data(
        self, item: str, fields_json: str, limit: int = 100
    ) -> dict:
        """
        Extract structured data from page.

        Args:
            item: Item container selector
            fields_json: JSON extraction rules
            limit: Max items

        Returns:
            dict with: items (list of dicts), count

        Example:
            >>> import json
            >>> fields = json.dumps({
            ...     "title": ".title",
            ...     "price": {"selector": ".price", "regex": r"\\d+"}
            ... })
            >>> data = session.extract_data(".product", fields)
            >>> for item in data["items"]:
            ...     print(item["title"], item["price"])
        """
        return self._service.extract_data(self._session_id, item, fields_json, limit)

    def close(self) -> None:
        """Close browser session."""
        self._service.close_session(self._session_id)

    def __enter__(self) -> BrowserSession:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class BrowserService(BaseService):
    """
    Synchronous browser service.

    Provides direct browser control without LLM.

    Example:
        >>> with client.browser.create_session() as session:
        ...     session.navigate("https://google.com")
        ...     session.type("input[name='q']", "Python web scraping")
        ...     session.click("input[name='btnK']")
        ...     results = session.extract(".result-title")
    """

    def __init__(self, transport: BaseTransport) -> None:
        super().__init__(transport)
        self._stub: Any = None

    @property
    def _get_stub(self) -> Any:
        """Lazy-load gRPC stub."""
        if self._stub is None:
            from cmdop._generated.service_pb2_grpc import (
                TerminalStreamingServiceStub,
            )

            self._stub = TerminalStreamingServiceStub(self._channel)
        return self._stub

    def create_session(
        self,
        start_url: str | None = None,
        provider: str = "camoufox",
        profile_id: str | None = None,
        headless: bool = False,
        width: int = 1280,
        height: int = 800,
    ) -> BrowserSession:
        """
        Create browser session.

        Args:
            start_url: Initial URL to navigate
            provider: Browser provider (camoufox, rod)
            profile_id: Profile ID for persistence
            headless: Run without visible window
            width: Viewport width
            height: Viewport height

        Returns:
            BrowserSession for fluent API
        """
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserCreateSessionRequest,
        )

        request = BrowserCreateSessionRequest(
            provider=provider,
            profile_id=profile_id or "",
            start_url=start_url or "",
            headless=headless,
            width=width,
            height=height,
        )

        response = self._call_sync(self._get_stub.BrowserCreateSession, request)

        if not response.success:
            raise RuntimeError(f"Failed to create browser session: {response.error}")

        return BrowserSession(self, response.browser_session_id)

    def close_session(self, session_id: str) -> None:
        """Close browser session."""
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserCloseSessionRequest,
        )

        request = BrowserCloseSessionRequest(browser_session_id=session_id)
        response = self._call_sync(self._get_stub.BrowserCloseSession, request)

        if not response.success:
            raise RuntimeError(f"Failed to close browser session: {response.error}")

    def navigate(self, session_id: str, url: str, timeout_ms: int = 30000) -> str:
        """Navigate to URL."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserNavigateRequest

        request = BrowserNavigateRequest(
            browser_session_id=session_id, url=url, timeout_ms=timeout_ms
        )
        response = self._call_sync(self._get_stub.BrowserNavigate, request)

        if not response.success:
            raise RuntimeError(f"Navigation failed: {response.error}")

        return response.final_url

    def click(self, session_id: str, selector: str, timeout_ms: int = 5000) -> None:
        """Click element."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserClickRequest

        request = BrowserClickRequest(
            browser_session_id=session_id, selector=selector, timeout_ms=timeout_ms
        )
        response = self._call_sync(self._get_stub.BrowserClick, request)

        if not response.success:
            raise RuntimeError(f"Click failed: {response.error}")

    def type(
        self,
        session_id: str,
        selector: str,
        text: str,
        human_like: bool = False,
        clear_first: bool = True,
    ) -> None:
        """Type text into element."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserTypeRequest

        request = BrowserTypeRequest(
            browser_session_id=session_id,
            selector=selector,
            text=text,
            human_like=human_like,
            clear_first=clear_first,
        )
        response = self._call_sync(self._get_stub.BrowserType, request)

        if not response.success:
            raise RuntimeError(f"Type failed: {response.error}")

    def wait_for(self, session_id: str, selector: str, timeout_ms: int = 30000) -> bool:
        """Wait for element."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserWaitRequest

        request = BrowserWaitRequest(
            browser_session_id=session_id, selector=selector, timeout_ms=timeout_ms
        )
        response = self._call_sync(self._get_stub.BrowserWait, request)

        if not response.success:
            raise RuntimeError(f"Wait failed: {response.error}")

        return response.found

    def extract(
        self, session_id: str, selector: str, attr: str | None = None, limit: int = 100
    ) -> list[str]:
        """Extract text/attributes."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExtractRequest

        request = BrowserExtractRequest(
            browser_session_id=session_id,
            selector=selector,
            attribute=attr or "",
            limit=limit,
        )
        response = self._call_sync(self._get_stub.BrowserExtract, request)

        if not response.success:
            raise RuntimeError(f"Extract failed: {response.error}")

        return list(response.values)

    def extract_regex(
        self, session_id: str, pattern: str, from_html: bool = False, limit: int = 100
    ) -> list[str]:
        """Extract using regex."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExtractRegexRequest

        request = BrowserExtractRegexRequest(
            browser_session_id=session_id,
            pattern=pattern,
            from_html=from_html,
            limit=limit,
        )
        response = self._call_sync(self._get_stub.BrowserExtractRegex, request)

        if not response.success:
            raise RuntimeError(f"ExtractRegex failed: {response.error}")

        return list(response.matches)

    def get_html(self, session_id: str, selector: str | None = None) -> str:
        """Get page HTML."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetHTMLRequest

        request = BrowserGetHTMLRequest(
            browser_session_id=session_id, selector=selector or ""
        )
        response = self._call_sync(self._get_stub.BrowserGetHTML, request)

        if not response.success:
            raise RuntimeError(f"GetHTML failed: {response.error}")

        return response.html

    def get_text(self, session_id: str, selector: str | None = None) -> str:
        """Get page text."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetTextRequest

        request = BrowserGetTextRequest(
            browser_session_id=session_id, selector=selector or ""
        )
        response = self._call_sync(self._get_stub.BrowserGetText, request)

        if not response.success:
            raise RuntimeError(f"GetText failed: {response.error}")

        return response.text

    def execute_script(self, session_id: str, script: str) -> str:
        """Execute JavaScript."""
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserExecuteScriptRequest,
        )

        request = BrowserExecuteScriptRequest(
            browser_session_id=session_id, script=script
        )
        response = self._call_sync(self._get_stub.BrowserExecuteScript, request)

        if not response.success:
            raise RuntimeError(f"ExecuteScript failed: {response.error}")

        return response.result

    def screenshot(self, session_id: str, full_page: bool = False) -> bytes:
        """Take screenshot."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserScreenshotRequest

        request = BrowserScreenshotRequest(
            browser_session_id=session_id, full_page=full_page
        )
        response = self._call_sync(self._get_stub.BrowserScreenshot, request)

        if not response.success:
            raise RuntimeError(f"Screenshot failed: {response.error}")

        return response.data

    def get_state(self, session_id: str) -> BrowserState:
        """Get browser state."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetStateRequest

        request = BrowserGetStateRequest(browser_session_id=session_id)
        response = self._call_sync(self._get_stub.BrowserGetState, request)

        if not response.success:
            raise RuntimeError(f"GetState failed: {response.error}")

        return BrowserState(url=response.url, title=response.title)

    def set_cookies(
        self, session_id: str, cookies: list[BrowserCookie | dict]
    ) -> None:
        """Set cookies."""
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserCookie as PbCookie,
            BrowserSetCookiesRequest,
        )

        pb_cookies = []
        for c in cookies:
            if isinstance(c, dict):
                pb_cookies.append(
                    PbCookie(
                        name=c.get("name", ""),
                        value=c.get("value", ""),
                        domain=c.get("domain", ""),
                        path=c.get("path", "/"),
                        secure=c.get("secure", False),
                        http_only=c.get("http_only", False),
                        same_site=c.get("same_site", ""),
                        expires=c.get("expires", 0),
                    )
                )
            else:
                pb_cookies.append(
                    PbCookie(
                        name=c.name,
                        value=c.value,
                        domain=c.domain,
                        path=c.path,
                        secure=c.secure,
                        http_only=c.http_only,
                        same_site=c.same_site,
                        expires=c.expires,
                    )
                )

        request = BrowserSetCookiesRequest(
            browser_session_id=session_id, cookies=pb_cookies
        )
        response = self._call_sync(self._get_stub.BrowserSetCookies, request)

        if not response.success:
            raise RuntimeError(f"SetCookies failed: {response.error}")

    def get_cookies(self, session_id: str, domain: str = "") -> list[BrowserCookie]:
        """Get cookies."""
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetCookiesRequest

        request = BrowserGetCookiesRequest(
            browser_session_id=session_id, domain=domain
        )
        response = self._call_sync(self._get_stub.BrowserGetCookies, request)

        if not response.success:
            raise RuntimeError(f"GetCookies failed: {response.error}")

        return [
            BrowserCookie(
                name=c.name,
                value=c.value,
                domain=c.domain,
                path=c.path,
                secure=c.secure,
                http_only=c.http_only,
                same_site=c.same_site,
                expires=c.expires,
            )
            for c in response.cookies
        ]

    def validate_selectors(
        self,
        session_id: str,
        item: str,
        fields: dict[str, str],
    ) -> dict:
        """
        Validate CSS selectors on page.

        Args:
            session_id: Browser session ID
            item: Item container selector (e.g., ".product-card")
            fields: Field name -> CSS selector mapping

        Returns:
            dict with keys: valid, counts, samples, errors
        """
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserValidateSelectorsRequest,
        )

        request = BrowserValidateSelectorsRequest(
            browser_session_id=session_id,
            item=item,
            fields=fields,
        )
        response = self._call_sync(self._get_stub.BrowserValidateSelectors, request)

        if not response.success:
            raise RuntimeError(f"ValidateSelectors failed: {response.error}")

        return {
            "valid": response.valid,
            "counts": dict(response.counts),
            "samples": dict(response.samples),
            "errors": list(response.errors),
        }

    def extract_data(
        self,
        session_id: str,
        item: str,
        fields_json: str,
        limit: int = 100,
    ) -> dict:
        """
        Extract structured data from page.

        Args:
            session_id: Browser session ID
            item: Item container selector
            fields_json: JSON string defining field extraction rules
            limit: Max items to extract

        Returns:
            dict with keys: items (list), count (int)
        """
        import json

        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserExtractDataRequest,
        )

        request = BrowserExtractDataRequest(
            browser_session_id=session_id,
            item=item,
            fields_json=fields_json,
            limit=limit,
        )
        response = self._call_sync(self._get_stub.BrowserExtractData, request)

        if not response.success:
            raise RuntimeError(f"ExtractData failed: {response.error}")

        return {
            "items": json.loads(response.items_json) if response.items_json else [],
            "count": response.count,
        }


class AsyncBrowserSession:
    """
    Async browser session with fluent API.

    Use as async context manager:

        async with client.browser.create_session() as session:
            await session.navigate("https://example.com")
            await session.click("button.submit")
    """

    def __init__(self, service: AsyncBrowserService, session_id: str) -> None:
        self._service = service
        self._session_id = session_id

    @property
    def session_id(self) -> str:
        return self._session_id

    async def navigate(self, url: str, timeout_ms: int = 30000) -> str:
        return await self._service.navigate(self._session_id, url, timeout_ms)

    async def click(self, selector: str, timeout_ms: int = 5000) -> None:
        await self._service.click(self._session_id, selector, timeout_ms)

    async def type(
        self,
        selector: str,
        text: str,
        human_like: bool = False,
        clear_first: bool = True,
    ) -> None:
        await self._service.type(
            self._session_id, selector, text, human_like, clear_first
        )

    async def wait_for(self, selector: str, timeout_ms: int = 30000) -> bool:
        return await self._service.wait_for(self._session_id, selector, timeout_ms)

    async def extract(
        self, selector: str, attr: str | None = None, limit: int = 100
    ) -> list[str]:
        return await self._service.extract(self._session_id, selector, attr, limit)

    async def extract_regex(
        self, pattern: str, from_html: bool = False, limit: int = 100
    ) -> list[str]:
        return await self._service.extract_regex(
            self._session_id, pattern, from_html, limit
        )

    async def get_html(self, selector: str | None = None) -> str:
        return await self._service.get_html(self._session_id, selector)

    async def get_text(self, selector: str | None = None) -> str:
        return await self._service.get_text(self._session_id, selector)

    async def execute_script(self, script: str) -> str:
        return await self._service.execute_script(self._session_id, script)

    async def screenshot(self, full_page: bool = False) -> bytes:
        return await self._service.screenshot(self._session_id, full_page)

    async def get_state(self) -> BrowserState:
        return await self._service.get_state(self._session_id)

    async def set_cookies(self, cookies: list[BrowserCookie | dict]) -> None:
        await self._service.set_cookies(self._session_id, cookies)

    async def get_cookies(self, domain: str = "") -> list[BrowserCookie]:
        return await self._service.get_cookies(self._session_id, domain)

    async def validate_selectors(self, item: str, fields: dict[str, str]) -> dict:
        """Validate CSS selectors on page."""
        return await self._service.validate_selectors(self._session_id, item, fields)

    async def extract_data(
        self, item: str, fields_json: str, limit: int = 100
    ) -> dict:
        """Extract structured data from page."""
        return await self._service.extract_data(
            self._session_id, item, fields_json, limit
        )

    async def close(self) -> None:
        await self._service.close_session(self._session_id)

    async def __aenter__(self) -> AsyncBrowserSession:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()


class AsyncBrowserService(BaseService):
    """
    Async browser service.

    Example:
        >>> async with client.browser.create_session() as session:
        ...     await session.navigate("https://google.com")
        ...     await session.type("input[name='q']", "Python")
        ...     results = await session.extract(".result-title")
    """

    def __init__(self, transport: BaseTransport) -> None:
        super().__init__(transport)
        self._stub: Any = None

    @property
    def _get_stub(self) -> Any:
        if self._stub is None:
            from cmdop._generated.service_pb2_grpc import (
                TerminalStreamingServiceStub,
            )

            self._stub = TerminalStreamingServiceStub(self._async_channel)
        return self._stub

    async def create_session(
        self,
        start_url: str | None = None,
        provider: str = "camoufox",
        profile_id: str | None = None,
        headless: bool = False,
        width: int = 1280,
        height: int = 800,
    ) -> AsyncBrowserSession:
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserCreateSessionRequest,
        )

        request = BrowserCreateSessionRequest(
            provider=provider,
            profile_id=profile_id or "",
            start_url=start_url or "",
            headless=headless,
            width=width,
            height=height,
        )

        response = await self._call_async(self._get_stub.BrowserCreateSession, request)

        if not response.success:
            raise RuntimeError(f"Failed to create browser session: {response.error}")

        return AsyncBrowserSession(self, response.browser_session_id)

    async def close_session(self, session_id: str) -> None:
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserCloseSessionRequest,
        )

        request = BrowserCloseSessionRequest(browser_session_id=session_id)
        response = await self._call_async(self._get_stub.BrowserCloseSession, request)

        if not response.success:
            raise RuntimeError(f"Failed to close browser session: {response.error}")

    async def navigate(self, session_id: str, url: str, timeout_ms: int = 30000) -> str:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserNavigateRequest

        request = BrowserNavigateRequest(
            browser_session_id=session_id, url=url, timeout_ms=timeout_ms
        )
        response = await self._call_async(self._get_stub.BrowserNavigate, request)

        if not response.success:
            raise RuntimeError(f"Navigation failed: {response.error}")

        return response.final_url

    async def click(
        self, session_id: str, selector: str, timeout_ms: int = 5000
    ) -> None:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserClickRequest

        request = BrowserClickRequest(
            browser_session_id=session_id, selector=selector, timeout_ms=timeout_ms
        )
        response = await self._call_async(self._get_stub.BrowserClick, request)

        if not response.success:
            raise RuntimeError(f"Click failed: {response.error}")

    async def type(
        self,
        session_id: str,
        selector: str,
        text: str,
        human_like: bool = False,
        clear_first: bool = True,
    ) -> None:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserTypeRequest

        request = BrowserTypeRequest(
            browser_session_id=session_id,
            selector=selector,
            text=text,
            human_like=human_like,
            clear_first=clear_first,
        )
        response = await self._call_async(self._get_stub.BrowserType, request)

        if not response.success:
            raise RuntimeError(f"Type failed: {response.error}")

    async def wait_for(
        self, session_id: str, selector: str, timeout_ms: int = 30000
    ) -> bool:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserWaitRequest

        request = BrowserWaitRequest(
            browser_session_id=session_id, selector=selector, timeout_ms=timeout_ms
        )
        response = await self._call_async(self._get_stub.BrowserWait, request)

        if not response.success:
            raise RuntimeError(f"Wait failed: {response.error}")

        return response.found

    async def extract(
        self, session_id: str, selector: str, attr: str | None = None, limit: int = 100
    ) -> list[str]:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExtractRequest

        request = BrowserExtractRequest(
            browser_session_id=session_id,
            selector=selector,
            attribute=attr or "",
            limit=limit,
        )
        response = await self._call_async(self._get_stub.BrowserExtract, request)

        if not response.success:
            raise RuntimeError(f"Extract failed: {response.error}")

        return list(response.values)

    async def extract_regex(
        self, session_id: str, pattern: str, from_html: bool = False, limit: int = 100
    ) -> list[str]:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserExtractRegexRequest

        request = BrowserExtractRegexRequest(
            browser_session_id=session_id,
            pattern=pattern,
            from_html=from_html,
            limit=limit,
        )
        response = await self._call_async(self._get_stub.BrowserExtractRegex, request)

        if not response.success:
            raise RuntimeError(f"ExtractRegex failed: {response.error}")

        return list(response.matches)

    async def get_html(self, session_id: str, selector: str | None = None) -> str:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetHTMLRequest

        request = BrowserGetHTMLRequest(
            browser_session_id=session_id, selector=selector or ""
        )
        response = await self._call_async(self._get_stub.BrowserGetHTML, request)

        if not response.success:
            raise RuntimeError(f"GetHTML failed: {response.error}")

        return response.html

    async def get_text(self, session_id: str, selector: str | None = None) -> str:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetTextRequest

        request = BrowserGetTextRequest(
            browser_session_id=session_id, selector=selector or ""
        )
        response = await self._call_async(self._get_stub.BrowserGetText, request)

        if not response.success:
            raise RuntimeError(f"GetText failed: {response.error}")

        return response.text

    async def execute_script(self, session_id: str, script: str) -> str:
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserExecuteScriptRequest,
        )

        request = BrowserExecuteScriptRequest(
            browser_session_id=session_id, script=script
        )
        response = await self._call_async(
            self._get_stub.BrowserExecuteScript, request
        )

        if not response.success:
            raise RuntimeError(f"ExecuteScript failed: {response.error}")

        return response.result

    async def screenshot(self, session_id: str, full_page: bool = False) -> bytes:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserScreenshotRequest

        request = BrowserScreenshotRequest(
            browser_session_id=session_id, full_page=full_page
        )
        response = await self._call_async(self._get_stub.BrowserScreenshot, request)

        if not response.success:
            raise RuntimeError(f"Screenshot failed: {response.error}")

        return response.data

    async def get_state(self, session_id: str) -> BrowserState:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetStateRequest

        request = BrowserGetStateRequest(browser_session_id=session_id)
        response = await self._call_async(self._get_stub.BrowserGetState, request)

        if not response.success:
            raise RuntimeError(f"GetState failed: {response.error}")

        return BrowserState(url=response.url, title=response.title)

    async def set_cookies(
        self, session_id: str, cookies: list[BrowserCookie | dict]
    ) -> None:
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserCookie as PbCookie,
            BrowserSetCookiesRequest,
        )

        pb_cookies = []
        for c in cookies:
            if isinstance(c, dict):
                pb_cookies.append(
                    PbCookie(
                        name=c.get("name", ""),
                        value=c.get("value", ""),
                        domain=c.get("domain", ""),
                        path=c.get("path", "/"),
                        secure=c.get("secure", False),
                        http_only=c.get("http_only", False),
                        same_site=c.get("same_site", ""),
                        expires=c.get("expires", 0),
                    )
                )
            else:
                pb_cookies.append(
                    PbCookie(
                        name=c.name,
                        value=c.value,
                        domain=c.domain,
                        path=c.path,
                        secure=c.secure,
                        http_only=c.http_only,
                        same_site=c.same_site,
                        expires=c.expires,
                    )
                )

        request = BrowserSetCookiesRequest(
            browser_session_id=session_id, cookies=pb_cookies
        )
        response = await self._call_async(self._get_stub.BrowserSetCookies, request)

        if not response.success:
            raise RuntimeError(f"SetCookies failed: {response.error}")

    async def get_cookies(
        self, session_id: str, domain: str = ""
    ) -> list[BrowserCookie]:
        from cmdop._generated.rpc_messages.browser_pb2 import BrowserGetCookiesRequest

        request = BrowserGetCookiesRequest(
            browser_session_id=session_id, domain=domain
        )
        response = await self._call_async(self._get_stub.BrowserGetCookies, request)

        if not response.success:
            raise RuntimeError(f"GetCookies failed: {response.error}")

        return [
            BrowserCookie(
                name=c.name,
                value=c.value,
                domain=c.domain,
                path=c.path,
                secure=c.secure,
                http_only=c.http_only,
                same_site=c.same_site,
                expires=c.expires,
            )
            for c in response.cookies
        ]

    async def validate_selectors(
        self,
        session_id: str,
        item: str,
        fields: dict[str, str],
    ) -> dict:
        """Validate CSS selectors on page."""
        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserValidateSelectorsRequest,
        )

        request = BrowserValidateSelectorsRequest(
            browser_session_id=session_id,
            item=item,
            fields=fields,
        )
        response = await self._call_async(
            self._get_stub.BrowserValidateSelectors, request
        )

        if not response.success:
            raise RuntimeError(f"ValidateSelectors failed: {response.error}")

        return {
            "valid": response.valid,
            "counts": dict(response.counts),
            "samples": dict(response.samples),
            "errors": list(response.errors),
        }

    async def extract_data(
        self,
        session_id: str,
        item: str,
        fields_json: str,
        limit: int = 100,
    ) -> dict:
        """Extract structured data from page."""
        import json

        from cmdop._generated.rpc_messages.browser_pb2 import (
            BrowserExtractDataRequest,
        )

        request = BrowserExtractDataRequest(
            browser_session_id=session_id,
            item=item,
            fields_json=fields_json,
            limit=limit,
        )
        response = await self._call_async(self._get_stub.BrowserExtractData, request)

        if not response.success:
            raise RuntimeError(f"ExtractData failed: {response.error}")

        return {
            "items": json.loads(response.items_json) if response.items_json else [],
            "count": response.count,
        }
