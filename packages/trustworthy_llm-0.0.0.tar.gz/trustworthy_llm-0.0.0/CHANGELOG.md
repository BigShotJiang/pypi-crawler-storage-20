# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.0.0] 2026-01-12
- Initial release of the `trustworthy-llm` library.

[Unreleased]: https://github.com/cleanlab/tlm/compare/v0.0.0...HEAD
[0.0.0]: https://github.com/cleanlab/tlm/commits/v0.0.0
