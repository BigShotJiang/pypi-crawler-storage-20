"""whirr tests."""
