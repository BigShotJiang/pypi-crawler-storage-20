"""Files - File storage operations for Mixtrain workspace.

This module provides the Files class for uploading, downloading, listing,
and deleting files in workspace cloud storage.

Example:
    >>> from mixtrain import Files
    >>> files = Files()
    >>>
    >>> # Upload a file
    >>> info = files.upload("model.bin", "outputs/model.bin")
    >>>
    >>> # List files
    >>> for f in files.list("outputs/"):
    ...     print(f.path, f.size)
    >>>
    >>> # Download a file
    >>> local_path = files.download("outputs/model.bin", "local_model.bin")
    >>>
    >>> # Delete a file
    >>> files.delete("outputs/model.bin")
"""

import logging
import mimetypes
import os
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Iterator, List, Optional

import httpx

from .client import MixClient

logger = logging.getLogger(__name__)


@dataclass
class FileInfo:
    """Metadata for a file in storage.

    Attributes:
        path: User-facing path (e.g., 'outputs/model.bin')
        name: File name (last segment of path)
        url: Full storage URL (e.g., 'gs://bucket/prefix/outputs/model.bin')
        size: File size in bytes
        content_type: MIME type of the file
        last_modified: Last modification timestamp
        download_url: Presigned URL for downloading (when available)
    """

    path: str
    name: str
    url: Optional[str] = None
    size: Optional[int] = None
    content_type: Optional[str] = None
    last_modified: Optional[datetime] = None
    download_url: Optional[str] = None

    @classmethod
    def from_api_response(cls, data: Dict[str, Any]) -> "FileInfo":
        """Create FileInfo from API response data."""
        last_modified = data.get("last_modified")
        if last_modified and isinstance(last_modified, str):
            # Parse ISO format datetime
            try:
                last_modified = datetime.fromisoformat(
                    last_modified.replace("Z", "+00:00")
                )
            except ValueError as e:
                logger.warning(
                    f"Failed to parse last_modified timestamp '{last_modified}': {e}"
                )
                last_modified = None

        return cls(
            path=data.get("path", ""),
            name=data.get("name", ""),
            size=data.get("size_bytes"),
            content_type=data.get("content_type"),
            last_modified=last_modified,
            download_url=data.get("download_url"),
        )


class Files:
    """File storage operations for workspace.

    Provides methods to upload, download, list, and delete files in
    workspace cloud storage. Uses presigned URLs for direct-to-cloud
    transfers.

    Usage:
        >>> from mixtrain import Files
        >>> files = Files()

        # Upload a file
        >>> info = files.upload("model.bin", "outputs/model.bin")
        >>> print(info.path)
        outputs/model.bin

        # List files with prefix
        >>> for f in files.list("outputs/"):
        ...     print(f"{f.path}: {f.size} bytes")

        # Download a file
        >>> local_path = files.download("outputs/model.bin")
        >>> print(f"Downloaded to: {local_path}")

        # Delete a file
        >>> files.delete("outputs/model.bin")

    Args:
        client: Optional MixClient instance. If not provided, creates a new one.
    """

    def __init__(self, client: Optional[MixClient] = None):
        """Initialize Files with optional MixClient.

        Args:
            client: MixClient instance for API operations. Creates new one if not provided.
        """
        self._client = client or MixClient()

    @property
    def workspace(self) -> str:
        """Get the current workspace name."""
        return self._client._workspace_name

    def upload(
        self,
        local_path: str,
        remote_path: Optional[str] = None,
        content_type: Optional[str] = None,
        timeout: float = 300.0,
    ) -> FileInfo:
        """Upload a file to workspace storage.

        Args:
            local_path: Path to the local file to upload
            remote_path: Target path in storage. Defaults to the local filename.
            content_type: MIME type. Auto-detected if not provided.
            timeout: HTTP timeout in seconds for the upload. Default 300s (5 min).

        Returns:
            FileInfo with the uploaded file's metadata

        Raises:
            FileNotFoundError: If local file doesn't exist
            Exception: On upload failure
        """
        if not os.path.exists(local_path):
            raise FileNotFoundError(f"File not found: {local_path}")

        if remote_path is None:
            remote_path = os.path.basename(local_path)

        if content_type is None:
            content_type, _ = mimetypes.guess_type(local_path)
            content_type = content_type or "application/octet-stream"

        file_size = os.path.getsize(local_path)

        # Request presigned upload URL
        response = self._client._make_request(
            "POST",
            f"/workspaces/{self.workspace}/files/upload",
            json={
                "path": remote_path,
                "content_type": content_type,
                "size_bytes": file_size,
            },
        )
        upload_info = response.json()

        # Upload directly to cloud storage
        with open(local_path, "rb") as f:
            with httpx.Client(timeout=timeout) as http_client:
                upload_response = http_client.put(
                    upload_info["upload_url"],
                    content=f,
                    headers={"Content-Type": content_type},
                )
                upload_response.raise_for_status()

        return FileInfo(
            path=remote_path,
            name=os.path.basename(remote_path),
            url=upload_info.get("storage_url"),
            size=file_size,
            content_type=content_type,
        )

    def download(
        self,
        remote_path: str,
        local_path: Optional[str] = None,
        timeout: float = 300.0,
    ) -> str:
        """Download a file from workspace storage.

        Args:
            remote_path: Path of the file in storage
            local_path: Local destination path. Defaults to the filename in current directory.
            timeout: HTTP timeout in seconds for the download. Default 300s (5 min).

        Returns:
            Path to the downloaded file

        Raises:
            Exception: On download failure
        """
        if local_path is None:
            local_path = os.path.basename(remote_path)

        # Get presigned download URL
        response = self._client._make_request(
            "GET",
            f"/workspaces/{self.workspace}/files/{remote_path}",
        )
        download_info = response.json()

        # Download directly from cloud storage
        with httpx.Client(timeout=timeout) as http_client:
            with http_client.stream("GET", download_info["download_url"]) as r:
                r.raise_for_status()
                with open(local_path, "wb") as f:
                    for chunk in r.iter_bytes():
                        f.write(chunk)

        return local_path

    def list(
        self,
        prefix: str = "",
        limit: int = 100,
    ) -> List[FileInfo]:
        """List files in workspace storage.

        Args:
            prefix: Filter files by path prefix (e.g., "outputs/")
            limit: Maximum number of files to return per request

        Returns:
            List of FileInfo objects for matching files
        """
        response = self._client._make_request(
            "GET",
            f"/workspaces/{self.workspace}/files",
            params={"prefix": prefix, "limit": limit},
        )
        data = response.json()

        return [FileInfo.from_api_response(f) for f in data.get("files", [])]

    def iter(
        self,
        prefix: str = "",
        limit: int = 100,
    ) -> Iterator[FileInfo]:
        """Iterate over all files in workspace storage with automatic pagination.

        Args:
            prefix: Filter files by path prefix (e.g., "outputs/")
            limit: Number of files to fetch per API request

        Yields:
            FileInfo objects for each file
        """
        continuation_token = None

        while True:
            params = {"prefix": prefix, "limit": limit}
            if continuation_token:
                params["continuation_token"] = continuation_token

            response = self._client._make_request(
                "GET",
                f"/workspaces/{self.workspace}/files",
                params=params,
            )
            data = response.json()

            for file_data in data.get("files", []):
                yield FileInfo.from_api_response(file_data)

            continuation_token = data.get("continuation_token")
            if not continuation_token:
                break

    def get(self, remote_path: str) -> FileInfo:
        """Get metadata and download URL for a file.

        Args:
            remote_path: Path of the file in storage

        Returns:
            FileInfo with metadata and presigned download URL

        Raises:
            Exception: If file not found
        """
        response = self._client._make_request(
            "GET",
            f"/workspaces/{self.workspace}/files/{remote_path}",
        )
        data = response.json()

        return FileInfo(
            path=data.get("path", remote_path),
            name=os.path.basename(remote_path),
            size=data.get("size_bytes"),
            content_type=data.get("content_type"),
            last_modified=(
                datetime.fromisoformat(data["last_modified"].replace("Z", "+00:00"))
                if data.get("last_modified")
                else None
            ),
            download_url=data.get("download_url"),
        )

    def delete(self, remote_path: str) -> bool:
        """Delete a file from workspace storage.

        Args:
            remote_path: Path of the file to delete

        Returns:
            True if deletion was successful

        Raises:
            Exception: If file not found or deletion failed
        """
        response = self._client._make_request(
            "DELETE",
            f"/workspaces/{self.workspace}/files/{remote_path}",
        )
        data = response.json()
        return data.get("success", False)

    def exists(self, remote_path: str) -> bool:
        """Check if a file exists in workspace storage.

        Args:
            remote_path: Path of the file to check

        Returns:
            True if file exists, False otherwise

        Raises:
            Exception: On network/auth errors (only 404 returns False)
        """
        try:
            self.get(remote_path)
            return True
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                return False
            raise
