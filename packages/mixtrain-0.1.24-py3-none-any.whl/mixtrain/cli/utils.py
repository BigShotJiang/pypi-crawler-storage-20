"""Shared CLI utilities for consistent output formatting."""

from datetime import datetime

from rich import print as rprint


def print_error(message: str, suggestion: str | None = None):
    """Print consistent error message."""
    rprint(f"[red]Error:[/red] {message}")
    if suggestion:
        rprint(f"[dim]Tip: {suggestion}[/dim]")


def print_empty_state(resource_type: str, suggestion: str | None = None):
    """Print consistent empty state message."""
    rprint(f"[yellow]No {resource_type} found.[/yellow]")
    if suggestion:
        rprint(f"[dim]{suggestion}[/dim]")


def truncate(text: str | None, max_len: int = 50) -> str:
    """Truncate text for table display."""
    if not text:
        return ""
    return text[:max_len] + "..." if len(text) > max_len else text


def format_datetime(iso_string: str | None) -> str:
    """Format ISO datetime string to local time."""
    if not iso_string:
        return ""
    try:
        dt = datetime.fromisoformat(iso_string.replace("Z", "+00:00"))
        return dt.astimezone().strftime("%Y-%m-%d %H:%M")
    except (ValueError, AttributeError):
        return iso_string
