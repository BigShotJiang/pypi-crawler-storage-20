[![Build Status](https://github.com/ContactEngineering/SurfaceTopography/actions/workflows/test-code-functionality.yml/badge.svg)](https://github.com/ContactEngineering/SurfaceTopography/actions/workflows/tests.yml)

[![Ask DeepWiki](https://deepwiki.com/badge.svg)](https://deepwiki.com/ContactEngineering/SurfaceTopography)

SurfaceTopography
=================

*Read and analyze surface topographies with Python.* This code implements basic classes for handling uniform and
nonuniform surface topography data. It contains a rich set of import filters for experimental surface topography data.
Surface topographies can be easily analyzed using standard (rms height, power spectrum, ...) and some special purpose
(autocorrelation function, variable bandwidth analysis, ...) statistical techniques.

Quick Start
-----------

```python
from SurfaceTopography import read_topography

# Read a topography file (format is auto-detected)
topography = read_topography('surface.opd')

# Get basic properties
print(f"Grid size: {topography.nb_grid_pts}")
print(f"Physical size: {topography.physical_sizes}")
print(f"RMS height: {topography.rms_height_from_area()}")

# Compute the power spectral density (PSD)
q, psd = topography.power_spectrum_from_profile()

# Compute the autocorrelation function (ACF)
r, acf = topography.autocorrelation_from_profile()

# Plot the topography
import matplotlib.pyplot as plt
plt.pcolormesh(*topography.positions_and_heights())
plt.colorbar(label='Height')
plt.show()
```

Supported File Formats
----------------------

SurfaceTopography supports over 35 file formats from commercial surface profilometers:

| Format | Description |
|--------|-------------|
| `al3d` | Alicona AL3D files |
| `asc` | ASCII text files (generic) |
| `bcr` | BCR-STM files |
| `datx` | Zygo DATX files |
| `di` | Digital Instruments / Bruker AFM files |
| `ezd` | Nanosurf EZD files |
| `frt` | FRT profilometer files |
| `gwy` | Gwyddion GWY files |
| `h5` | HDF5 files |
| `hgt` | NASA SRTM HGT elevation files |
| `ibw` | Igor Pro binary wave files (Asylum Research) |
| `jpk` | JPK Instruments files |
| `lext` | Olympus LEXT files |
| `mat` | MATLAB .mat files |
| `metropro` | Zygo MetroPro files |
| `mi` | Park Systems / Molecular Imaging files |
| `mitutoyo` | Mitutoyo surface roughness files |
| `mnt` | Digital Surf Mountains MNT files |
| `nc` | NetCDF files |
| `nmm` | PTB NMM files |
| `nms` | Nanofocus NMS files |
| `npy` | NumPy binary files |
| `oir` | Olympus OIR files |
| `opd` | Wyko OPD files |
| `opdx` | Wyko OPDx files |
| `os3d` | Digital Metrology OmniSurf3D files |
| `plu` | Sensofar PLU files |
| `plux` | Sensofar PLUX files |
| `poir` | Olympus POIR (zip) files |
| `ps` | Keyence profilometer files |
| `sdf` | ISO 25178-71 SDF files |
| `sur` | Digital Surf SUR files |
| `tmd` | TrueMap TMD files |
| `vk` | Keyence VK files |
| `wsxm` | WSxM files |
| `x3p` | ISO 25178-72 X3P files |
| `xyz` | XYZ point cloud files |
| `zmg` | KLA Zeta ZMG files |
| `zon` | Keyence ZON files |

If you use this code, please cite:
* [Jacobs, Junge, Pastewka, Surf. Topogr. Metrol. Prop. 1, 013001 (2017)](https://doi.org/10.1088/2051-672X/aa51f8)
* [Röttger el al., Surf. Topogr. Metrol. Prop. 10, 035032 (2022)](https://doi.org/10.1088/2051-672X/ac860a) 

Documentation
-------------

This README file contains a brief introduction into the code. The full documentation can be found at https://contactengineering.github.io/SurfaceTopography/.

Installation
------------

Detailed instruction for the installation are provided in the [documentation](https://contactengineering.github.io/SurfaceTopography/installation.html?highlight=installation). If you want to install from source
you need to run `git submodule update --init` after a fresh checkout.

The most basic configuration of SurfaceTopography installs all requirements autonomously `python3 -m pip install SurfaceTopgography`

If you need an editable install (e.g. for development purposes), make sure you disable build isolation:

    python3 -m pip install --no-build-isolation -e .

You need to manually install `ninja`, `meson-python`, `pytest`, `runtests`, `DiscoverVersion` and `numpy` before:

    python3 -m pip install ninja meson-python pytest runtests DiscoverVersion numpy

Funding
-------

Development of this project is funded by the [European Research Council](https://erc.europa.eu) within [Starting Grant 757343](https://cordis.europa.eu/project/id/757343) and by the [Deutsche Forschungsgemeinschaft](https://www.dfg.de/en) within projects [PA 2023/2](https://gepris.dfg.de/gepris/projekt/258153560) and [EXC 2193](https://gepris.dfg.de/gepris/projekt/390951807).
