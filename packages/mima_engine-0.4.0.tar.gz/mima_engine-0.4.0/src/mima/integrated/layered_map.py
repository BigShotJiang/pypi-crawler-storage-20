import math

from pygame import Vector2
from typing_extensions import Generic, Protocol

from mima.integrated.entity import Entity, Nature, TEntity
from mima.layered.shape import ShapeCollection
from mima.standalone.geometry import Rect, shape_from_str
from mima.standalone.spatial import SpatialGrid
from mima.standalone.tiled_map import TiledObject, TiledTile, TiledTilemap, vfloor
from mima.standalone.transformed_view import TileTransformedView

VOFF = Vector2(0.1, 0.1)


class Drawable(Protocol):
    def draw(self, ttv: TileTransformedView, cache: bool = False) -> None: ...

    def get_pos(self) -> Vector2: ...


class Renderable:
    def __init__(self, drawable: Drawable, layer: int, elevation: int) -> None:
        self.drawable = drawable
        self.layer = layer
        self.elevation = elevation

    def draw(self, ttv: TileTransformedView, cache: bool = False) -> None:
        self.drawable.draw(ttv, cache)

    def get_bottom(self) -> float:
        return self.drawable.get_pos().y


class ObjectLoader(Generic[TEntity]):
    def load_objects(self, obj: TiledObject) -> list[tuple[TEntity, int]]: ...


class LayeredMap(Generic[TEntity]):
    def __init__(
        self, tilemap: TiledTilemap, loader: ObjectLoader[TEntity] | None = None
    ) -> None:
        self._tilemap: TiledTilemap = tilemap
        self._world_size: Vector2 = self._tilemap.world_size
        self._cell_size: int = 8
        self._map_objects: list[tuple[TEntity, int]] = []

        self._background_layer: SpatialGrid[TEntity] = SpatialGrid[TEntity](
            self._world_size, self._cell_size
        )
        self._collision_layer: SpatialGrid[TEntity] = SpatialGrid[TEntity](
            self._world_size, self._cell_size
        )
        self._foreground_layer: SpatialGrid[TEntity] = SpatialGrid[TEntity](
            self._world_size, self._cell_size
        )
        self._ui_layer: list[TEntity] = []
        self._large_objects: list[TEntity] = []

        self._loader: ObjectLoader | None = loader

        self._visible_objects: set[TEntity] = set()
        self._collisions: set[frozenset[TEntity]] = set()
        self._prev_interactions: set[tuple[TEntity, TEntity]] = set()
        self._curr_interactions: set[tuple[TEntity, TEntity]] = set()

        self._tilemap.prerender_layers()
        self.draw_grid: bool = False

    def start_new_frame(self) -> None:
        for grid in [
            self._background_layer,
            self._collision_layer,
            self._foreground_layer,
        ]:
            objects = grid.get_all_objects()
            redundants = [obj for obj in objects if obj.is_redundant]

            for obj in redundants:
                # TODO: query quests
                obj.on_death()
                grid.remove(obj)

        self._tilemap.start_new_frame()

    def update_global(self, elapsed_time: float) -> bool:
        self._tilemap.update(elapsed_time)
        it = [
            (self._background_layer, self._background_layer.get_all_objects()),
            (self._collision_layer, self._collision_layer.get_all_objects()),
            (self._foreground_layer, self._foreground_layer.get_all_objects()),
        ]
        for grid, objects in it:
            for obj in objects:
                _update_object_global(elapsed_time, obj, grid)

        for obj in self._ui_layer:
            obj.update_global(elapsed_time)
        return False

    def update_visible(self, elapsed_time: float, ttv: TileTransformedView) -> bool:
        self.view = Rect(
            ttv.get_tl_tile() - Vector2(0.5, 0.5),
            ttv.get_br_tile() - ttv.get_tl_tile() + Vector2(1.5, 1.5),
        )

        self._curr_interactions.clear()
        self._collisions.clear()

        visible_objects = self._collision_layer.get_objects_in_region(
            self.view.pos, self.view.size
        )

        for obj in visible_objects:
            obj.update_visible(elapsed_time, ttv)

            if not obj.is_collider:
                continue

            elevation = math.floor(obj.elevation)
            hitbox = obj.get_hitbox()
            tl = vfloor(hitbox.get_tl_pos() - VOFF)
            br = vfloor(hitbox.get_br_pos() + VOFF)
            if obj.collides_with_map:
                # Collision with map
                for y in range(int(tl.y), int(br.y) + 1):
                    for x in range(int(tl.x), int(br.x) + 1):
                        tiles = self._tilemap.get_tiles(x, y, elevation)
                        new_pos = collide_with_tiles(hitbox, tiles, Vector2(x, y))
                        self.relocate_object(self._collision_layer, obj, new_pos)

            tl = hitbox.get_tl_pos() - (VOFF * 2)
            br = hitbox.get_br_pos() + (VOFF * 2)
            obj_view = Rect(tl, br - tl)
            close_objects = self._collision_layer.get_objects_in_region(
                obj_view.pos, obj_view.size
            )

            # Collision with other objects
            for other in close_objects:
                if obj == other:
                    continue
                # TODO: implement overlaps/resolve_collision for hitboxes
                if obj.get_hitbox().overlaps(other.get_hitbox().bounding_box):
                    self._collisions.add(frozenset({obj, other}))

        for obj1, obj2 in self._collisions:
            collider = obj1
            target = obj2

            move_both = obj1.is_collider and obj2.is_collider
            if not move_both and obj2.is_collider:
                collider, target = obj2, obj1
            elif move_both and id(obj1) > id(obj2):
                collider, target = obj2, obj1

            if obj1.collides_with_dyn and obj2.collides_with_dyn:
                new_pos1, new_pos2 = collider.get_hitbox().resolve_collision(
                    target.get_hitbox().bounding_box, move_both
                )
                self.relocate_object(self._collision_layer, collider, new_pos1)
                self.relocate_object(self._collision_layer, target, new_pos2)

            self._curr_interactions.add((obj1, obj2))
            self._curr_interactions.add((obj2, obj1))

        entered = self._curr_interactions - self._prev_interactions
        stayed = self._curr_interactions & self._prev_interactions
        exited = self._prev_interactions - self._curr_interactions
        for collider, target in entered:
            target.on_interaction(collider, Nature.ENTER)
            # elif obj.is_player:  # implicitly: obj.collides_with_dyn==True
            #     # Check quests (somehow; they are not available here)
            #     # self.on_interaction(other, Nature.WALK)
        for collider, target in stayed:
            target.on_interaction(collider, Nature.WALK)
        for collider, target in exited:
            target.on_interaction(collider, Nature.EXIT)
        self._prev_interactions = self._curr_interactions.copy()
        return False

    def draw(self, ttv: TileTransformedView) -> None:
        renderables: list[Renderable] = []

        for layer in self._tilemap.get_rendered_layers():
            renderables.append(Renderable(layer, layer.layer, layer.elevation))

        for layer, objects in enumerate(
            [
                self._background_layer.get_objects_in_region(
                    self.view.pos, self.view.size
                ),
                self._collision_layer.get_objects_in_region(
                    self.view.pos, self.view.size
                ),
                self._foreground_layer.get_objects_in_region(
                    self.view.pos, self.view.size
                ),
            ]
        ):
            for obj in objects:
                renderables.append(Renderable(obj, layer, math.floor(obj.elevation)))

        draw_sorted(renderables, ttv)

        for obj in self._ui_layer:
            obj.draw(ttv)

        if self.draw_grid:
            # cells = self._collision_layer.get_cells_in_region(
            #     self.view.pos, self.view.size
            # )
            # visible_cells = len(cells)
            world_size = self._collision_layer._world_size  # type: ignore[reportPrivateUsage]
            cell_size = self._collision_layer._cell_size  # type: ignore[reportPrivateUsage]
            for i in range(0, int(world_size.x), cell_size):
                ttv.draw_line(Vector2(i, 0), Vector2(i, world_size.y), (0, 255, 255))
            for i in range(0, int(world_size.y), cell_size):
                ttv.draw_line(Vector2(0, i), Vector2(world_size.x, i))

        return

    def relocate_object(
        self, grid: SpatialGrid[TEntity], obj: TEntity, new_pos: Vector2
    ) -> None:
        obj.old_pos = obj.get_pos()
        obj.set_pos(new_pos)
        grid.relocate(obj, obj.old_pos, new_pos)

    def add_to_layer(self, obj: TEntity, layer: int = 1) -> None:
        if layer == 0:
            self._background_layer.insert(
                obj, obj.get_pos(), obj.get_hitbox().get_bounding_size()
            )
        elif layer == 2:
            self._foreground_layer.insert(
                obj, obj.get_pos(), obj.get_hitbox().get_bounding_size()
            )
        elif layer == 3:
            self._ui_layer.append(obj)
        else:
            self._collision_layer.insert(
                obj, obj.get_pos(), obj.get_hitbox().get_bounding_size()
            )

    def remove_from_layer(self, obj: TEntity, layer: int = 1) -> None:
        if layer == 0:
            self._background_layer.remove(obj)
        elif layer == 2:
            self._foreground_layer.remove(obj)
        elif layer == 3 and obj in self._ui_layer:
            self._ui_layer.remove(obj)
        else:
            self._collision_layer.remove(obj)

    def populate_dynamics(self) -> None:
        self._background_layer.clear()
        self._collision_layer.clear()
        self._foreground_layer.clear()

        if self._map_objects:
            for dyn, layer in self._map_objects:
                dyn.on_interaction(dyn, Nature.RESUME)
                self.add_to_layer(dyn, layer)
        elif self._loader is not None:
            for obj in self._tilemap.get_objects():
                dyns = self._loader.load_objects(obj)
                for dyn, layer in dyns:
                    self.add_to_layer(dyn, layer)
                    self._map_objects.append((dyn, layer))

    def is_tile_free(
        self, pos: Vector2, size: Vector2 | None = None, elevation: int = 0
    ) -> bool:
        size = Vector2(1, 1) if size is None else size

        tiles = self._tilemap.get_tiles_in_area(pos, size, elevation)

        free = True
        for tile in tiles:
            if tile.get_collision_boxes():
                return False

        # TODO: Check existing objects
        return free

    @property
    def name(self) -> str:
        return self._tilemap.name

    @property
    def tl(self) -> Vector2:
        return self._tilemap.tl

    @property
    def br(self) -> Vector2:
        return self._tilemap.br

    @property
    def n_objects(self) -> int:
        return (
            self._background_layer.n_objects
            + self._collision_layer.n_objects
            + self._foreground_layer.n_objects
            + len(self._ui_layer)
        )

    def set_loader(self, loader: ObjectLoader[TEntity]) -> None:
        self._loader = loader


def _update_object_global(
    elapsed_time: float, obj: TEntity, grid: SpatialGrid[TEntity]
) -> None:
    obj.update_global(elapsed_time)
    pos = obj.get_pos()
    obj.old_pos = pos
    new_pos = pos + obj.vel * obj.speed * elapsed_time
    obj.set_pos(new_pos)
    grid.relocate(obj, pos, new_pos)


def collide_with_tiles(
    obj: ShapeCollection, tiles: list[TiledTile], tile_offset: Vector2
) -> Vector2:
    obj_origin = obj.pos

    for tile in tiles:
        hitboxes = tile.get_collision_boxes()

        if not hitboxes:
            continue

        for hitbox in hitboxes:
            shape = shape_from_str(
                hitbox.shape, hitbox.pos + tile_offset, hitbox.size, hitbox.radius
            )

            if obj.overlaps(shape):
                res = obj.resolve_collision(shape)
                obj.pos = res[0]
    new_pos = obj.pos
    obj.pos = obj_origin
    return new_pos


def draw_sorted(renderables: list[Renderable], ttv: TileTransformedView) -> None:
    renderables.sort(key=lambda r: (r.layer, r.elevation, r.get_bottom()))

    for r in renderables:
        r.draw(ttv, cache=True)
