"""Version information for llama-cpp-py-sync."""

__version__ = "0.7770"
__llama_cpp_commit__ = "fe44d3557"
__llama_cpp_tag__ = "b7770"
