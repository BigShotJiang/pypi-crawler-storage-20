# 🌊 Leviathan-UI: Framework de Interfaz de Usuario Premium para PyQt5

**Versión 1.0.2 - Soporte de Iconos y Barra de Progreso Marquee**

Leviathan-UI es un framework de componentes de interfaz de usuario diseñado para llevar la estética moderna de Windows 11 a las aplicaciones basadas en PyQt5. Se enfoca en la inmersión, la elegancia y la experiencia de usuario, ofreciendo elementos como barras de título personalizadas, efectos de desenfoque (blur) y diálogos modales avanzados.

## ✨ Características Principales

| Característica | Descripción | Componentes Afectados |
| :--- | :--- | :--- |
| **Estética Windows 11** | Ventanas sin marco, esquinas redondeadas y manejo de color de acento del sistema. | `WipeWindow`, `CustomTitleBar` |
| **Diálogos Inmersivos** | Reemplazo moderno de `QMessageBox` con soporte para efectos de desenfoque de fondo (`ghostBlur`). | `LeviathanDialog` |
| **Splash Screen Avanzado** | Pantallas de carga y salida con frases dinámicas y transición suave. | `InmersiveSplash` |
| **Soporte de Iconos** | Manejo de iconos de imagen (`.ico`, `.png`, `.svg`) además de emojis para una identidad visual robusta. **(Novedad v1.0.2)** | `LeviathanDialog`, `CustomTitleBar`, `InmersiveSplash` |
| **Barra de Progreso Marquee** | Componente de barra de progreso con modo indeterminado (animación de "trabajando") para tareas asíncronas. **(Novedad v1.0.2)** | `LeviathanProgressBar`, `InmersiveSplash` |

## 📦 Componentes Destacados

### `LeviathanProgressBar` (Nuevo en v1.0.2)

Este componente reemplaza la barra de progreso estándar de PyQt5, ofreciendo un diseño más limpio y, crucialmente, el modo **Marquee** (indeterminado).

```python
from leviathan_ui import LeviathanProgressBar

# Barra de progreso normal
progress_bar = LeviathanProgressBar()
progress_bar.setRange(0, 100)
progress_bar.value = 50

# Barra de progreso Marquee (indeterminada)
marquee_bar = LeviathanProgressBar()
marquee_bar.setMarquee(True) 
```

### `LeviathanDialog`

Un diálogo modal que se superpone a la ventana principal con un efecto de desenfoque. Ahora soporta rutas de archivo para los iconos.

```python
from leviathan_ui import LeviathanDialog

# Diálogo de éxito con icono de imagen
LeviathanDialog.launch(
    parent=self, 
    title="Operación Exitosa", 
    message="El paquete se ha compilado correctamente.", 
    mode="success",
    buttons=["Aceptar"],
    # El icono ahora puede ser una ruta a un archivo .ico, .png o .svg
    icon="path/to/success_icon.png" 
)
```

### `InmersiveSplash`

Utilizado para gestionar el ciclo de vida de la aplicación, desde el inicio hasta el cierre.

```python
from leviathan_ui import InmersiveSplash

splash = InmersiveSplash(
    title="Iniciando Aplicación", 
    logo="app/app-icon.ico" # Soporte para iconos de imagen
)
splash.set_phrases(["Cargando módulos...", "Inicializando UI..."])
splash.set_progress_mode(marquee=True) # Usando el nuevo modo Marquee
splash.on_finish(lambda: main_window.show())
splash.launch()
```

## ⚙️ Instalación

```bash
pip install leviathan-ui
```

## 📖 Documentación

Para la documentación completa de otros componentes como `WipeWindow`, `CustomTitleBar` e `InmojiTrx`, consulte la [documentación original](https://github.com/JesusQuijada34/leviathan-ui).

## 📝 Licencia

Este proyecto está bajo la Licencia MIT.
