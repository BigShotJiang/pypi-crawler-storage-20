# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_constitution

"""
the judge
"""

__version__ = "0.1.0"
__author__ = "Gowtham A Rao"
__email__ = "gowtham.rao@coreason.ai"

from .archive import LegislativeArchive
from .judge import ConstitutionalJudge
from .schema import Constitution, Law, LawCategory, LawSeverity

__all__ = [
    "LegislativeArchive",
    "Constitution",
    "Law",
    "LawCategory",
    "LawSeverity",
    "ConstitutionalJudge",
]
