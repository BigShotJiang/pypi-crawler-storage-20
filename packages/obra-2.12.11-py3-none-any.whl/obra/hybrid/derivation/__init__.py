"""Derivation utilities for Obra hybrid orchestration.

This module provides derivation analysis tools including:
- Parallelization analysis: Identify independent items for concurrent execution
- Complexity estimation: Heuristic-based task complexity scoring
- Decomposition suggestions: Generate subtask recommendations for complex tasks

Related:
    - obra/hybrid/handlers/derive.py (main derive handler)
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md
"""

from obra.hybrid.derivation.complexity_estimator import ComplexityEstimator
from obra.hybrid.derivation.decomposition_generator import DecompositionGenerator
from obra.hybrid.derivation.parallelization import (
    ParallelizationAnalyzer,
    ParallelizationResult,
)

__all__ = [
    "ComplexityEstimator",
    "DecompositionGenerator",
    "ParallelizationAnalyzer",
    "ParallelizationResult",
]
