"""Benchmarks for marginaleffects."""
