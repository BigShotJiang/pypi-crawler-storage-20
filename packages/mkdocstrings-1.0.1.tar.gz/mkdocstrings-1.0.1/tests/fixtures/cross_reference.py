"""
Link to [something.Else][].
"""
