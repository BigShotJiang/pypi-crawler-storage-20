pytest_plugins = 'pytester'
