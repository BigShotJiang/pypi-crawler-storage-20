# CLI

::: sereto.cli.cli
